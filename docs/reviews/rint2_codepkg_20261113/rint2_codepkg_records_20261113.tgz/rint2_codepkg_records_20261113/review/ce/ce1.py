import sys, os, json
scripts, store, mode = sys.argv[1], sys.argv[2], sys.argv[3]
if mode == 'mut':
    sys.path.insert(0, sys.argv[4])
sys.path.insert(1 if mode == 'mut' else 0, scripts)
import numpy as np
import fibre_segment_raster as FSR
import carbon_junction as CJ, step3_sigma as S3, cjunc_store as CS
import contextlib, io
with contextlib.redirect_stdout(io.StringIO()):
    import test_cjunc_store as T
inp = T.dense_inputs(7)
st = CS.Store(store)
key = st.key(**inp)
cnt = [0]
reg, out = st.get_or_build(T.build_of(inp, cnt), **inp)
fresh = T.build_of(inp)()
print(json.dumps({'mode': mode, 'fsr': os.path.relpath(FSR.__file__, os.path.dirname(scripts)), 'code_in_key': sorted(st.code),
                  'key': key[:16], 'status': out['status'], 'builds_by_store': cnt[0], 'sid_fp': CJ._grid_fp(inp['sid'])[:12],
                  'store_reg_fp': reg['fp']['registry'][:12], 'fresh_reg_fp': fresh['fp']['registry'][:12],
                  'n_pos_store': int(len(reg['positions']['lin'])), 'n_pos_fresh': int(len(fresh['positions']['lin']))}, ensure_ascii=False))

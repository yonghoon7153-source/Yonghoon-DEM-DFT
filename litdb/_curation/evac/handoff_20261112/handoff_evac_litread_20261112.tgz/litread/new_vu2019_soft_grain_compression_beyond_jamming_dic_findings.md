# 정독 근거 — vu2019_soft_grain_compression_beyond_jamming_dic (Vu & Barés, Phys. Rev. E 100, 042907, 2019)

카드: `litdb/papers/vu2019_soft_grain_compression_beyond_jamming_dic.md` (정본 · 2026-11-10 digest).  쪽 = 042907-N.

## a. 순수 SE (LPSCl · 황화물) 압력별 기공 곡선
이 배치에 없음 (모델 재료 · 실리콘 / 한천 2D).

## b. 압력을 뺄 때 되돌아오는 양
이 배치에 없음 — 하중 단계만 (카드 §0-1 (iv) · p. 2–3) · 소성 입자의 영구 변형은 하중을 건 채의 모양으로만 보임.

## c. 항복 · 경도 · 크리프 값과 정의
- [c] vu2019_soft_grain_compression_beyond_jamming_dic | 한천 1 % 하이드로겔: E 10 kPa · ν 0.15 · 소성 계수 Ep 1.8 kPa · 항복 응력 σy 500 Pa ("almost like a perfect elastoplastic material" · 준정적) · 실리콘 E 0.45 MPa · ν 0.495 | 카드 §3-1 · p. 2 (값의 출처 = ref [50] Exp. Mech. 59, 453) | 본문 | 모델 재료 (SE 아님) · 일축 항복 세기와 견줄 환산 없음 · 'perfect' 와 Ep 1.8 kPa (선형 경화) 가 어긋남 (카드 §12-B 7)

## d. 단단한 + 무른 입자 혼합 · 하중 몫 · 재밍
- [d] vu2019_soft_grain_compression_beyond_jamming_dic | 혼합 없음 (무른 입자만) · 재밍 φc 0.737 ± 0.02 (RCP 0.842 보다 낮은 이유 다섯: 마찰 · 벽 마찰 · 모세관 다리 · 일축 · 작은 계) · 재밍에서 Z ≈ 4 · f_NR ≈ 0.9 | 카드 §3-2 · p. 5 | 본문 | 2D · 실리콘 · 혼합은 형제 카드 `cardenasbarrantes2022_soft_hard_grains_compaction_experiment_dic`

## e. 점접촉 법칙이 큰 변형에서 깨지는 범위와 대안
- [e] vu2019_soft_grain_compression_beyond_jamming_dic | 초탄성 응력이 재밍 뒤 초선형 — "not what is expected for Hookean particles [31] or for soap bubbles [9] where a linear regime is observed" · 지수 σ − σc ∝ (φ − φc)^β, β ≈ 1.19 (φ − φc 0.013–0.038) → 1.47 (0.038–0.098) | 카드 §0-1 (i) · §3-4 · p. 12 · 그림 2a | 본문 (문장) · [판독 + 카드 산술] (지수) | 2D · 실험만 · 대안 접촉 법칙 제시 없음 · 맞춘 값 0 개 · 응력 단위 불확실

## f. MPM 접촉 · 다물체 · 해상도 규칙 · 수치 오차
이 배치에 없음 (실험).  측정 해상도만: 상관 칸 40 px = 0.42 mm (작은 지름의 2.1 %) · 변위 0.01 px (100 nm) · 경계 = 칸 중심의 볼록 껍질 (실제 가장자리보다 반 칸 ≈ 0.2 mm 안쪽 · 카드 추론) (카드 §3-4 · §4-2 · p. 3–4).

## g. 2D → 3D 경고나 증거
- [g] vu2019_soft_grain_compression_beyond_jamming_dic | 원문에 3D 전이 문장 없음 · 2D 실험 (바닥면 · 위 자유) 에서 비압축 초탄성 (ν 0.495) 도 I2 평균 0.958 → 바닥면 넓이 −2 % (높이 +2 % 추정) · 소성 한천은 −25 % | 카드 §0-1 (iii) · §3-4 · 그림 8b · 8e | [판독 + 카드 산술] · 추론 | 2D 실험 ≠ 2D 평면 변형률 계산 — 같은 '2D φ' 로 견주기 전에 차이를 적을 것

## h. DEM 에서 FE · MPM 으로 넘긴 선례
이 배치에 없음 (계산 없음).  수치 모형 지도만: Nezamabadi 외 [45] MPM + bonded particle · Boromand 외 [46] 변형 다각형 (카드 §5 · `eq_00b` · p. 1).

## i. 복합 양극 압력별 기공
이 배치에 없음.

## j. 카드가 스스로 적은 한계 (가압 · 탈압 관련)
- [j] vu2019_soft_grain_compression_beyond_jamming_dic | 하중 쪽만 (탈압 · 잔류 형상 없음) · 응력 단위 · 정의 불확실 ('힘 ÷ 계 너비' ↔ 축 MPa / kPa) · 대표 실험 한 번 · 수치 대조 없음 · 한천 압축성 (깊은 끝 = 재료 압축 체제 · 비압축 SE 에 없음) | 카드 §12-A · §12-B · §12-C | 본문 + 카드 산술 | —

## k. DEM 의 한계 (인용 서지: Vu & Barés, Phys. Rev. E 100, 042907 (2019))
- [k] vu2019_soft_grain_compression_beyond_jamming_dic (Vu & Barés 2019, PRE) | **'DEM' 낱말 없음 — 말 없음.**  닿는 문장: "Around the jamming point it is possible to consider that these particles are ruled by a linear elastic behavior since the stress and so the deformations are assumed to be small [12–14]. However, far beyond the jamming point it is necessary to consider a more complicated local behavior for the particle materials; different mechanisms more complicated than elasticity are at play: hyperelasticity, plasticity, damage, fracture, etc." · 열린 질문 "(ii) Are some elements of the Hertz contact framework still valid in this state?" (답하지 않음) | p. 1 · 카드 §0-1 (i) · `eq_00a` | 본문 | 실험 논문 · DEM 대조 없음 · 수치 한계값 (믿을 수 있는 변형 상한) 없음
- [k] vu2019_soft_grain_compression_beyond_jamming_dic (Vu & Barés 2019, PRE) | "the stress grows superlinearly with φ (see Fig. 2) which is not what is expected for Hookean particles [31] or for soap bubbles [9] where a linear regime is observed." · 입자가 다각형이 되고 접촉 길이가 둘레의 41 % (초탄성) · 77 % (소성) 까지 [판독] | p. 12 · 그림 1f · 3 · 카드 §0-1 (i) | 본문 · [판독] | 2D · 모델 재료

## l. 소성변형이 왜 어려운가 (인용 서지: Vu & Barés, Phys. Rev. E 100, 042907 (2019))
- [l] vu2019_soft_grain_compression_beyond_jamming_dic (Vu & Barés 2019, PRE) | 어려움 (측정 쪽): "nothing exists for local (subgranular) measurements in soft granular systems in a highly strained state" · 수치 모형은 "produced few experimental results [47] and they all only focus on particle geometry variations and macroscopic observable changes without looking at the material evolution down to the particle scale" | p. 1 · 카드 §0-1 (ii) · `eq_00b` | 본문 | 계산 쪽 어려움 (비용 · 접촉 · 구성식) 은 말하지 않음
- [l] vu2019_soft_grain_compression_beyond_jamming_dic (Vu & Barés 2019, PRE) | 우회 = 계산 대신 측정 · 구성식 가정을 피하려 응력 · 에너지 장을 내지 않음 ("not to make any further assumptions about the exact material behaviors, we do not deal with the stress tensor nor the energy fields") · 맞춘 값 0 개 · 비용 = 실험마다 사진 100–200 장 (한 장 스캔 ≈ 10 분 · ≈ 520 Mpx) · 큰 재배열은 손으로 첫 추정 · 입자 ≈ 100 개 · 재료마다 3 회 · [카드 산술] 실험 한 번 ≈ 22 h (초탄성) · ≈ 40 h (소성) | p. 2–4 · 카드 §0-1 (ii) · §3-4 | 본문 · [카드 산술] | 단위 시간은 스캔 외 미기재 (처음 길이 270 mm 가정)
- [l] vu2019_soft_grain_compression_beyond_jamming_dic (Vu & Barés 2019, PRE) | 소성 입자에서 보인 것: "In the plastic case for φ > 1.15, the curves collapse, which means that the contact network of the packing is frozen. In this case the individual contact lengths barely increase, the evolution of the system is mainly due to the compressibility of the particle material." · "plastic materials do not resist well shear strain and tend to plastically deform homogeneously in the whole particle" | p. 6–7 · p. 12 · 카드 §5-3 · §5-6 | 본문 | 한천은 압축성 (ν 0.15) — 비압축 SE 에 그대로 옮기지 않음

## m. 받아들일 통찰
- [m] vu2019_soft_grain_compression_beyond_jamming_dic | **무엇**: 접촉 = 근접 문턱 (경계 0.5 mm = 작은 지름의 2.5 %) 그리고 하중 문턱 (경계 1.5 mm 띠 안 abs(𝒞 − 1) > 0.01 ≈ 출발 잡음 표준편차의 14 배) — '힘 받는 접촉' 정의 · **어디**: 단계 0; 단계 7 (피복 정의 · `MPMC-02` 의 씨앗 치우침 ↔ 소성 증분 가르기); 후보 A′ · B 의 배위수 정의 · **왜**: p. 4 · 카드 §4-6
- [m] vu2019_soft_grain_compression_beyond_jamming_dic | **무엇**: 재밍점 정의만 바꿔도 Z − ZJ = k(φ − φJ)^0.5 의 k 가 2.0 ↔ 4.8 (같은 그림 2c 자료) — 재밍 판정 규칙 · 문턱을 결과 전에 적고 D0 궤적에서 정의별 퍼짐을 기록 · **어디**: 단계 0; 후보 D0 · **왜**: 카드 §3-4 · [판독 + 카드 산술]
- [m] vu2019_soft_grain_compression_beyond_jamming_dic | **무엇**: 공칭 φ (처음 넓이) 는 압축성 입자에서 1 을 넘는다 (1.34) — I2 = det C 로 보면 실제 넓이 분율 ≤ 0.99 · 두 번째 교차 0.99 → 실제 ≈ 0.91 · 보고에 공칭 · 실제 · 질량 기준 기공률을 나란히 · **어디**: 단계 0 (기공률 연산자 정의); 단계 7 · **왜**: p. 4 · 그림 8e · 카드 §3-4
- [m] vu2019_soft_grain_compression_beyond_jamming_dic | **무엇**: 2D 외부 대조 명세 — 실리콘 (E 0.45 MPa · ν 0.495) / 한천 (E 10 kPa · ν 0.15 · Ep 1.8 kPa · σy 500 Pa) 원판 20 / 30 mm · N ≈ 100 · 작은 : 큰 ≈ 3 · 마찰 ≈ 0 · 일축 0.5 mm 단계 + 1 분 이완 · 관측량 Z · f_NR · L · a_n · a_s · 𝒞 · λ1 · I2 분포 · 저자가 "benchmark numerical models" 권고 — 한 속도장 ↔ 입자별 장 비교의 꼴 대조 (⚠ 위 자유 · 응력 단위 불확실) · **어디**: 단계 2; 단계 3; 결과 전 대조 항목 · **왜**: p. 2–4 · p. 13 · 카드 §10-2

## 카드 문제
없음 (원문 자체의 어긋남 — 그림 3a · 3b 기울기 · 그림 3a 눈금 글자 · 그림 2a 단위 · 'Fig. 10(d)' 오기 · 충전율 정의 문장 — 은 카드 §3-3b · §12-B 에 적었다).  형제 카드 관련: `cardenasbarrantes2022_soft_hard_grains_compaction_experiment_dic` 이 이 논문에서 옮긴 값 (0.5 mm · 1.5 mm · 1 % · "~20 % 에서 멈춤" · 𝒞 = √(C : C) 의 정규화 · σ_𝒞 기울기 0.08 · 0.28) 은 원문과 같다 (σ_𝒞 기울기는 초탄성의 재밍 아래 · φh0 위 값) · 그 카드 §12-C 17 (움직이는 변) 은 이 논문 p. 2 "moves one of the walls along the major direction" 으로 메울 수 있다 (같은 장치라는 가정) · 2022 Letter 의 "C_c 0.991 = [12] 의 두 체제" 는 이 논문 수치 (m_𝒞 최소 0.9961) 와 맞지 않는다 (체제의 존재만 같음).

# 정독 · 종합 작업 폴더 (본 세션 scratchpad/litread · 2026-11-12 인계)

- 본 세션 지시서 · 출력의 `/tmp/claude-0/…/scratchpad/litread/` 경로 = 이 폴더.
- batch_NN.tsv · batch_NN_findings.md = 정독 출력 (본 세션 NN 01–76 · 대피 세션은 정본 `litdb/_curation/reading/` 의 101 부터).
- synth/ · synth2/ = 종합 (S1–S8 · S6_1–3 · out/) · verify 결과 · package_test/ = build_package 시험.
- 남은 일 (본 세션 할 일 목록 #6): 정독 남은 배치 + 종합 고침 적용 → build_package → 산출 커밋 (본 세션 STATE_tail 참고).

# new_hu2018_mls_mpm_cpic_two_way_rigid_coupling 정독 근거 (카드 1 장 · 2026-11-10)

읽은 카드: `hu2018_mls_mpm_cpic_two_way_rigid_coupling` (653 줄 · 원문 본문 14 쪽 + 보충 5 쪽을 직접 읽고 쓴 카드).
서지: Yuanming Hu · Yu Fang · Ziheng Ge · Ziyin Qu · Yixin Zhu · Andre Pradhana · Chenfanfu Jiang, “A Moving Least Squares Material Point Method with Displacement Discontinuity and Two-Way Rigid Body Coupling”, ACM Trans. Graph. 37, 4, Article 150 (August 2018), 14 pages, DOI 10.1145/3197517.3201293.

적는 법: 위치의 `L숫자` = 카드 줄 번호 · 표지는 카드에 적힌 그대로 (`인쇄` · `[카드 산술]` · `[판독]` · `[미확인]` · `[우리 코드 판독]` · `[카드 추론]` · `[카드 확인]`).  "우리 쪽 기록" = 논문 값이 아니라 카드가 적은 우리 코드 · 계산.

형식: `- [글자] slug | 내용 (값 · 단위) | 위치 | 표지 | 한계`

## a. 순수 SE (LPSCl · 황화물) 의 압력별 기공 곡선 · 진밀도 · 질량 기준 · 누른 채 / 뺀 뒤

이 카드에 없음 (압밀 · 기공 계산이 없는 논문 — 카드 §3-5 L177).

## b. 압력을 뺄 때 되돌아오는 양과 잰 방법

되돌아온 양의 수치는 없음.  닿는 것만 적는다.

- [b] hu2018_mls_mpm_cpic_two_way_rigid_coupling | 값 없음 — 탈압을 다루지 않는다 ('unload' · 'rebound' · 'springback' 0 회).  닿는 것 둘: 경계 유형 separate (다가오면 법선 제거 · 멀어지면 구속 없음 · 식 25) · 늘려 둔 탄성체를 자르면 되튀는 Fig. 7 (정성) | §0-2 (iv) L53 · §4-7 L328–329 · 논문 p.150:10 식 25 · Fig. 7 | [카드 확인] · 인쇄 · 정성 | 그래픽스 탄성체 · 수치 없음
- [b] hu2018_mls_mpm_cpic_two_way_rigid_coupling | 분리 판정이 속도뿐 (v·n > 0 이면 그대로) — 견인력 판정 없음.  침투는 '색 지속 + 약한 벌칙력 f = −k_h d_p n_p' 로 막는다 (k_h 값 미인쇄) | §4-6 L309–310 · §4-7 L332 · §9-⑥ L555 · 논문 식 22 · 25 | 인쇄 · [카드 산술] · [카드 추론] | 탈압 시험 없음 · k_h [미확인]
- [b] hu2018_mls_mpm_cpic_two_way_rigid_coupling (우리 쪽 기록) | 우리 MPM 판은 식 (25) 로 읽으면 slip 꼴 (법선 양방향 고정 · 분리 규칙 없음) — 판이 물러나는 동안 핵 폭 안의 SE 가 판 속도를 일부 물려받는다 (크기 미측정) | §8-2 L516 · §9-⑦ L557 | [우리 코드 판독 · 카드 추론] | 논문 값 아님

## c. 항복 · 경도 · 크리프 값과 정의 · 일축 항복 세기 환산

LPSCl 값 없음.  경도 · 크리프 없음.  일축 항복 환산식 없음.

- [c] hu2018_mls_mpm_cpic_two_way_rigid_coupling | Table 3 의 '항복응력' 10 · 10 · 5 (Cheese · Goo blocks · Banana · 단위 미인쇄) 와 영률 4 × 10⁵ · 5 × 10⁴ · 4 × 10⁵ → E/σ_y = 4 × 10⁴ · 5 × 10³ · 8 × 10⁴ | §3-2 L130–132 · L142 · 논문 Table 3 | 인쇄 · [카드 산술 · 같은 단위 가정] | 그래픽스 재료 · 재료 모델 식 (St. Venant–Kirchhoff + von Mises [Gao et al. 2017]) 은 이 논문에 없음 [미확인]
- [c] hu2018_mls_mpm_cpic_two_way_rigid_coupling (우리 쪽 기록) | 우리 생산 설정 E/σ_y ≈ 5.1 · 항복에서 탄성 편차 변형률 σ_y/(2μ) ≈ 0.29 (= 0.30 / (2 × 0.5134)) · 응력은 fixed corotated ↔ 반환 사상은 Hencky 변형률 | §9-⑧ L559 · §8-1 L506 | [카드 산술] · [우리 코드 판독] · [우리 기록] | 논문 값 아님

## d. 단단한 입자와 무른 입자를 섞어 누를 때 단단한 입자의 하중 몫 · 재밍

하중 몫 · 재밍 값 없음.

- [d] hu2018_mls_mpm_cpic_two_way_rigid_coupling | 강체 + 소성 연속체 결합의 시연만: 밀도 400 · 2000 · 5000 강체 블록을 von Mises 젤 (ρ 400 · E 5 × 10⁴ · 항복 10) 에 떨어뜨림 — 그림에서는 무거운 블록일수록 깊이 박혀 있다 | §5-4 L430 · Fig. 8 · Table 3 | [판독 · 정성] · 인쇄 | 중력 하중 · 판이 미는 압축 아님 · 박힌 깊이 수치 없음
- [d] hu2018_mls_mpm_cpic_two_way_rigid_coupling (우리 쪽 기록) | 우리 코드는 판 반력 `wallf` 와 얼린 AM 이 받아낸 운동량 `amf_dn` · `amf_up` 을 이미 재고 버린다 → 후보 A = 그 임펄스를 AM 강체 운동에 돌려주는 것 | §8-2 L521 | [우리 코드 판독] · [카드 추론] | 논문 값 아님

## e. 점접촉 법칙이 큰 변형에서 깨지는 범위와 대안

이 카드에 없음 (DEM · 접촉 법칙 언급 0 회 — 카드 §0-2 (i) L50).

## f. MPM 의 접촉 · 다물체 · 강체 결합 방법과 해상도 규칙 · 수치 오차 추정

- [f] hu2018_mls_mpm_cpic_two_way_rigid_coupling | 강체 결합 = CPIC: 강체 표면에서 뿌린 색칠 거리장 (노드당 64 비트 = 부호 없는 거리 32 + 강체당 2 비트) → 입자–노드 호환 → 호환 노드에만 질량 · 운동량 (식 23–24) · 비호환 노드 몫은 Proj (sticky / slip / separate + 동마찰 μ · 식 25) 를 거쳐 가장 가까운 강체에 임펄스 m_p (v_p − Proj) N_j · 비호환 노드는 유령 속도 (식 27–28) · 침투한 입자에 벌칙력 (식 22) | §4-6–§4-7 L290–354 · §3-4 L167 · 논문 p.150:8–150:11 | 인쇄 | 변형체끼리의 접촉 (다물체) 없음 · 강체–강체는 외부 해법 · 약결합 · 토크 식 미인쇄
- [f] hu2018_mls_mpm_cpic_two_way_rigid_coupling | 해상도 규칙: 지름당 셀 수 규칙 없음.  있는 것 — CPIC 는 “only resolves features at a scale of grid Δx” (좁은 틈 · 뾰족한 모서리 불가) · 강체 입자 간격 < Δx · 핵 = 2차 B-spline (“the smallest kernel that makes all constitutive models stable”) | §11 L596 · §3-4 L169 · §3-1 L100 · 논문 §8 p.150:12 · 보충 p.4 | 인쇄 | 수 없는 정성 규칙
- [f] hu2018_mls_mpm_cpic_two_way_rigid_coupling | 수치 오차 추정: 없음 — 해석해 · 수렴 차수 · 오차 노름 0 건.  있는 것 = 에너지 곡선 두 개 (MLS-MPM ↔ 전통 MPM 끼리 · 끝값 0.329 ↔ 0.311 (젤 · t 2.0) · 0.508 ↔ 0.517 (공 · t 0.6) · 두 방법 모두 젤 시험에서 에너지 ≈ 85 % 소산) 와 로봇 영상의 정성 대조 | §3-3 L146–159 · §3-5 L180 · Fig. 17 · Fig. 16 | [판독 · 벡터 경로] · [카드 산술] | 시험 조건 (재료 · 격자 · Δt · 단위) [미확인]
- [f] hu2018_mls_mpm_cpic_two_way_rigid_coupling | 접촉이 걸리는 거리: 입자 핵이 표면 건너편 노드에 닿는 순간 (2차 B-spline 이면 표면에서 ≈ 1.5 Δx 안) 부터 임펄스가 오간다 | §4-7 L341 | [카드 추론] | 논문에 그 수는 없음
- [f] hu2018_mls_mpm_cpic_two_way_rigid_coupling | 비용: CPIC 덧비용 6 % (바나나 131.9 → 140.5 sec/frame) · 블록의 ≈ 90 % 는 보통 전달 · 전달 연산 MLS-MPM ≈ 전통 MPM 의 ½ (P2G 2.09× · G2P 1.94×) · 입자 8 M 의 P2G + G2P 491 ms (4 스레드) | §3-4 L165–166 · §3-1 L107–113 · 논문 p.150:11–150:12 · Table 2 · 보충 p.5 | 인쇄 · [카드 산술] | CPU 4 코어 · 강체가 몇 개뿐인 장면 · GPU 수치 없음
- [f] hu2018_mls_mpm_cpic_two_way_rigid_coupling | 시간 간격: 규칙 · CFL 미인쇄.  Table 3 값으로 계산한 Courant 수 c_P Δt/Δx = 0.018–1.72 (1 초과 넷: Sand stir 1.11 · Sand paddles 1.72 · Robot 1.06 두 건) | §3-2 L124–141 | [카드 산술 · 한 단위계 가정] | 단위 미인쇄 · 예제별 적분 방식 (명시 / 암시) [미확인]

## g. 2D 결과를 3D 로 옮길 때의 경고나 증거

- [g] hu2018_mls_mpm_cpic_two_way_rigid_coupling | 말 없음.  유도는 d = 2 또는 3 · 시연 3D 12 건 + 2D 1 건 (Fig. 5 · 입자 4.1K · 0.3 sec/frame).  차원에 따라 달라지는 것은 구현 수뿐 (강체 요소 선분 / 삼각형 · 뿌림 9 / 27 노드 · 병렬 색 4 / 8 묶음) · “Our discussion is focused on 3D cases, which are significantly more computationally expensive than 2D ones.” | §0-2 (iii) L52 · 논문 보충 p.4 | 인쇄 | 물리 결과의 2D → 3D 전이에 대한 진술 없음

## h. DEM 에서 FE · MPM 으로 넘긴 선례와 넘긴 시점

이 카드에 없음.

## i. 복합 양극 (AM + SE) 의 압력별 기공

이 카드에 없음.

## j. 카드가 스스로 "아직 못 한다 · 한계" 라고 적은 것 가운데 가압 · 탈압 계산과 닿는 것

- [j] hu2018_mls_mpm_cpic_two_way_rigid_coupling | CPIC 는 Δx 규모만 해상 — “we cannot handle sub-grid level boundary configurations such as sharp corners and narrow gaps” → 하중을 지는 AM–SE–AM 다리가 곧 좁은 틈: 틈 ≲ 3 Δx (dx 0.141 µm 이면 ≈ 0.42 µm) 아래에서는 SE 입자가 온전한 호환 노드 집합을 갖지 못한다 | §11 L596 · §9-⑤ L553 · 논문 §8 p.150:12 | 인쇄 · [카드 산술] · [카드 추론] | 3 Δx 문턱은 카드 추론
- [j] hu2018_mls_mpm_cpic_two_way_rigid_coupling | 강체–MPM 강결합 미정식 (“Fully implicit rigid-MPM strong coupling is not formulated in this work”) · 강체–강체는 외부 해법 (“We will skip the details”) | §11 L599 · L607 · 논문 §8 · §5.1 | 인쇄 | —
- [j] hu2018_mls_mpm_cpic_two_way_rigid_coupling | 강체 저장: 강체당 2 비트 · 32 비트 → 16 개까지 ↔ real_14 AM 457 개 | §3-4 L168 · §9-④ L551 | [카드 산술] · [카드 추론] | 논문에 '16' 은 미인쇄
- [j] hu2018_mls_mpm_cpic_two_way_rigid_coupling | 힘 · 토크 전달의 수치 확인 없음 · 이 방법이 고밀도 압밀 · 탈압에서 어떻게 행동하는지는 이 논문으로 알 수 없다 | §3-5 L181 · §12 L618 | 카드 서술 (표지 없음) | —

## k. DEM 의 한계

- [k] hu2018_mls_mpm_cpic_two_way_rigid_coupling (Hu, Fang, Ge, Qu, Zhu, Pradhana & Jiang, ACM Trans. Graph. 37(4), Article 150, 2018) | **말 없음** — 본문 14 쪽 + 보충 5 쪽에 'discrete element' · 'DEM' 0 회, 'contact' 는 참고문헌 제목 한 곳뿐.  DEM 을 쓰지도 말하지도 않는 논문 | §0-2 (i) L50 | [카드 확인: 텍스트 층 전문 검색] | —
- [k] hu2018_mls_mpm_cpic_two_way_rigid_coupling (같은 서지 · DEM 이 아니라 **MPM 단일 속도장**의 한계 — 후보 A · A′ 가 필요한 이유의 인용처) | “Despite its high efficacy in many situations, traditional MPM fails to model sharp separation of material points and cannot represent discontinuous velocities.” (p.150:2 §1) · “The main issue is that particle kernels in MPM are nonconforming to boundaries.  Each particle exchanges data with grid nodes in its entire kernel support across the boundary which naturally causes velocity field smoothing.” (p.150:2 §1) · “Due to the adoption of a single velocity field, it remains challenging to separate continuum materials in MPM.” (p.150:3 §2.3) | §0-2 (i) L50 | 인쇄 (카드가 따옴표로 옮김) | 이 논문은 그 한계를 강체 표면에 대해서만 푼다 (변형체끼리는 그대로)

## l. 소성변형이 왜 어려운가

- [l] hu2018_mls_mpm_cpic_two_way_rigid_coupling (Hu, Fang, Ge, Qu, Zhu, Pradhana & Jiang, ACM Trans. Graph. 37(4), Article 150, 2018) | 어렵다는 설명 **없음** — 소성은 입자마다 변형구배를 항복면으로 사상하는 한 단계 (“Project particle deformation gradient for plasticity (if there is any)”) 이고 재료 모델은 [Gao et al. 2017] (von Mises) · [Klár et al. 2016] (Drucker–Prager) 에 맡긴다 | §0-2 (ii) L51 · §4-5 L281 · 논문 §4 p.150:8 · Table 3 캡션 | 인쇄 | 알갱이 계산이 아니라 연속체 · 가공 경화 · 이웃 접촉 · 하중 이력 · 탈압 언급 없음
- [l] hu2018_mls_mpm_cpic_two_way_rigid_coupling (같은 서지) | 소성이 문제로 나오는 유일한 곳: 재료 **분리**를 소성 연화 · 손상으로 흉내 내면 “results in too many debris particles” (p.150:2 · Fig. 2b) · “causes mesh dependent volume loss as well as undesirable debris” (p.150:3 §2.3) → 우회 = 분리를 구성식이 아니라 운동학 (CPIC) 으로 | §0-2 (ii) L51 · §5-2 L418 | 인쇄 (카드가 따옴표로 옮김) | 절단 문제 · 압밀 아님
- [l] hu2018_mls_mpm_cpic_two_way_rigid_coupling (같은 서지) | 우회의 값: 맞춘 값 0 개 · 맞춘 대상 없음 (재료값 근거 미인쇄) · 검증 = 에너지 곡선 2 (이산화끼리) + 로봇 영상 정성 · 비용 (소성 예제 3 건): 입자 1.2–1.8 M · 105.3–227.1 sec/frame · Intel i7-7700K 4 코어 | §0-2 (ii) L51 · §3-2 L130–132 · §3-3 L146–159 | 인쇄 · [판독] | 프레임 길이 미인쇄라 걸음당 비용으로 환산 불가

## m. 받아들일 통찰

- [m] hu2018_mls_mpm_cpic_two_way_rigid_coupling | 무엇: 우리 MPM 한 걸음이 이 논문 §4 여섯 단계와 줄 단위로 같다는 대응표와 인용할 식 (16 · 17 · 18 · 26).  단 인쇄된 융합 행렬 Q_p 는 응력 항 부호가 `+` (식 18 · 26 과 맞추면 `−` · 우리 코드도 `−`) → 원고에는 Q_p 가 아니라 식 (18) · (26) 을 옮긴다 | 어디에: 단계 2 · 조건 R6 (이산화의 원전) · 흐름 밖: 원고 Methods 의 MPM 이산화 인용 | 왜: §0 L24–31 · §4-5 L288 · §9-⑪ L565 ([우리 코드 판독] · [카드 산술])
- [m] hu2018_mls_mpm_cpic_two_way_rigid_coupling | 무엇: 원전이 정량 검증을 주지 않는다 (에너지 곡선 2 개 · 두 이산화끼리) + MLS-MPM 힘은 전통 MPM 힘과 점별로 다르다 (∇N ↔ M_p⁻¹ N (x_i − x_p) · 노드 옆 1.5 배 · 선형장 재현과 합 0 만 공유) → 1차 B-spline 접촉 문헌 (Bardenhagen 2000) 의 '지름당 8 요소' 수치를 그대로 옮기지 말고 우리 이산화로 다시 잰다 | 어디에: U1 · U6 · 단계 3 의 해상도 문장 | 왜: §4-3 L259 · §9-① L545 · §9-② L547 ([카드 산술] · [카드 추론])
- [m] hu2018_mls_mpm_cpic_two_way_rigid_coupling | 무엇: 경계 투영 식 (25) 를 판 · 벽 · AM 접촉 규칙으로 — separate = 법선 제거 + 접선을 μ‖v_n‖ 만큼 줄임 + 멀어지면 그대로 (Bardenhagen 2000 식 23 과 같은 보정 · 기준 속도만 강체 속도).  우리 경계는 지금 AM = sticky · 판 = slip 꼴 (분리 규칙 없음) · 바닥 / 옆벽 = separate μ 0.  기본값은 지금 거동과 비트 같게 두고 바꾼 팔만 새 거동 | 어디에: 후보 A′-0 · U2 · U4 · 단계 6 · 조건 R2 | 왜: §4-7 L320–332 · §8-2 L513–519 · §10 L573 · L583 (인쇄 · [우리 코드 판독] · [카드 추론])
- [m] hu2018_mls_mpm_cpic_two_way_rigid_coupling | 무엇: 후보 A 의 함정 셋 — (1) 저자 명시 한계 '좁은 틈 불가' 가 AM–SE–AM 다리와 겹친다 → 두 강체 구 사이 소성 막을 틈 / Δx = 6 · 4 · 3 · 2 사다리로 재는 단위 시험을 먼저 (2) 강체당 2 비트 저장은 16 개까지 → AM 457 개에는 노드당 '가장 가까운 AM 번호 + 해석적 부호 거리' (384³ × 8 B ≈ 0.45 GB) (3) AM–AM 접촉은 외부 강체 해법 = DEM 접촉 법칙을 따로 정해야 하고 결합은 약결합.  단위 시험의 표적값은 이 논문이 하나도 주지 않는다 (접촉역학 카드에서 가져온다) | 어디에: 후보 A · 단계 1 · 단계 5 · U3 · 조건 R1 | 왜: §9-④ L551 · §9-⑤ L553 · §10 L585–587 · §11 L596 · L599 (인쇄 · [카드 산술] · [카드 추론])

## 카드 문제

없음.  (원문의 인쇄 어긋남 — Q_p 첫 항 부호 · 식 (15) 의 N_i · §5.5 본문 ↔ 식 (27)(28) · Table 1 의 ρ 형 · 본문 M_p⁻¹ ↔ 보충 D_p⁻¹ — 은 카드 §12 L616 에 [카드 판독] 으로 적혀 있다.  이는 논문 쪽 사항이고 카드 안의 모순은 아니다.)

"""Exercise the first8 guard (submit_one.py.txt) of a SCRATCH launch folder once, for one case,
through that folder's own synthetic fixture (test_mla_boundaries.Fixture = fake scheduler).
No real process / network: an audit hook denies them.
Usage: python3 -I -B guard_case.py <F8_dir> <case> <new_work_dir>
Prints 'GUARD rc=0 …' (fake sbatch reached) or 'GUARD rc=2 HOLD: <reason>'."""
import contextlib, importlib.util, io, sys
from pathlib import Path
def audit(event, args):
    if event in ('subprocess.Popen', 'os.system', 'os.posix_spawn', 'socket.connect') or event.startswith('os.exec'):
        raise RuntimeError('guard_case denies ' + event)
f8, case, work = Path(sys.argv[1]), sys.argv[2], Path(sys.argv[3])
work.mkdir()
spec = importlib.util.spec_from_file_location('f8_fixture', str(f8 / 'test_mla_boundaries.py'))
mod = importlib.util.module_from_spec(spec); spec.loader.exec_module(mod)
sys.addaudithook(audit)
fx = mod.Fixture(str(work))
c, ap, files, put = fx.make(case)
try:
    with contextlib.redirect_stdout(io.StringIO()):
        fx.submit(ap)
    print('GUARD rc=0 case=%s fake_sbatch_calls=%d' % (case, len(fx.calls)))
except Exception as e:
    print('GUARD rc=2 case=%s HOLD: %s fake_sbatch_calls=%d' % (case, e, len(fx.calls)))

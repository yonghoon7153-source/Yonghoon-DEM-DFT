#!/bin/bash
#SBATCH --job-name=ps_7_3_r45_r5
#SBATCH --output=logs/output_ps_7_3_r45_r5_%j.out
#SBATCH --qos=cpu-60
#SBATCH --partition=cpu
#SBATCH -n 4
#SBATCH --time=5-00:00:00

source ~/.bashrc
conda activate myenv

export OMP_NUM_THREADS=1
export MKL_NUM_THREADS=1
export OPENBLAS_NUM_THREADS=1
export NUMEXPR_NUM_THREADS=1

cd /lustre/home/yonghoon/dem_test/ps45/ps_7_3_r45
mpirun --oversubscribe -np 4 lmp_mpi -in input_ps_7_3_r45_r5.liggghts

# 독립 리뷰 재현 — 실제 호스트 실행 금지

대상 핀: `c8a55c8ae1021ec80634ee8c6533deeebc67ce61`.
이 증거 묶음은 리뷰 파일이며 실행/배포 승인서가 아니다. 전체 게이트 HOLD 유지.

`received/`는 사용자 제공 ZIP의 파일 바이트다. 구현 측 `tests_after*.log`와
`DELIVERY_VALIDATION/`는 받은 기록이며 독립 검증으로 이름을 바꾸지 않았다.
리뷰 탐침은 별도 `parser_review/`, `paths_review/`, `contract_review/`에 있다.

아래 명령은 추출한 증거 폴더에서 실행한다. Python 3.12를 권장한다.
`pressure_inventory.sh ibb|wsl`이나 B7 압력 기록기를 실행하는 명령은 포함하지 않는다.

```text
python -I -X utf8 -B verify_received.py
python -I -X utf8 -B parser_review/probe_parser.py
python -I -X utf8 -B paths_review/test_exact_path_functions.py
python -I -X utf8 -B contract_review/probe_contract.py
```

- 첫 명령: SNAPSHOT 17개 SHA256 및 Git blob SHA1을 고정 핀에서 받은 원격 목록과 대조;
  PACKAGE 68개 검증. 실행 시 네트워크를 사용하지 않음. 원격 응답 자체를 새로 인증하는
  명령은 아니며 URL과 blob 목록은 `remote_blob_listing.json`에 보존.
- 둘째: 실제 AST 파서 7,179개 대조, 재개 계수/값 비출력, 잘못된 인자/신원의 고정 거부.
  긴 비정상 줄은 합성 자식 프로세스에서 각각 5초까지만 실행. 시간은 기계별로 달라짐.
- 셋째: 실제 AST 함수의 OS/IO 모의 오류 22개. POSIX/Lustre syscall 검증 아님.
- 넷째: 고정 집합·신원 조건·300개 계수 조합 및 stdout 실패 반례.
  연구 파일은 열지 않으며 자기 폴더의 `probe_result.json` 리뷰 결과만 씀.

원본 시험 `received/docs/reviews/lhs_pressure_inventory_20261104/test_pressure_inventory.py`는
POSIX 가정을 가진 구현 측 시험이다. 이 리뷰에서는 Windows에서 실행한 것으로 세지 않았다.
Git shell 시작 실패 기록도 성공/대상 실패 시험으로 세지 않는다.

`intake.json`의 ZIP SHA는 원래 첨부 ZIP에서 계산했다. 증거 ZIP은 별도 포장이므로 다른 SHA를 가진다.
`verification.json`은 리뷰 종료 시 수령 소스가 그대로임을 다시 대조한 출력이다.
`SHA256SUMS`는 이 증거 폴더의 자체 파일 목록이다. 재현 후 결과 JSON을 덮어쓰면 자체 해시는 달라질 수 있다.

새 관찰 ID는 최종 판정문의 LPI-01/LPI-02를 사용한다. 독립 분담 메모의 LHSPI-C01은
LPI-01과 같은 stdout 반례이며 세 번째 지적이 아니다. 분담 메모는 근거 보존용이며
최종 판정과 범위는 `codex_review_lhs_pressure_inventory_20261104.md`가 정리한다.

# 질문 d — 배치별 근거 묶음 (원문 줄 그대로 · 파일 41 개)

### [batch_01] d. 단단한 입자 + 무른 입자를 섞어 누를 때 단단한 입자의 하중 몫 · 재밍

하중 몫의 **수치는 이 배치에 없음** (단단 + 무른 혼합을 누른 계산 · 실험 카드가 없음).

- [d] bardenhagen2000_mpm_granular_multibody_frictional_contact | 값 없음. 논문: 힘 사슬은 알갱이가 "bind" 할 때 생기고 (63 % · 71 % 전단의 주응력차 지도), 일축 압축에서는 사슬망이 "stationary in time over a range of deformation" (이 문장엔 인용 번호 없음). 카드: 우리 scaffold MPM 은 AM 을 얼려 AM 을 지나는 사슬이 없고 AM 하중 분담 f 를 DEM 에서 빌림 — AM 을 움직이는 물체로 넣으면 f 를 계산할 수 있음 | §5-2 Fig 7 (L253) · §6 Fig 7 행 (L271) | stated (정성) / [우리 추론] | 2D · 한 재료 (HMX 근사) 원판 · 전단 — 단단 + 무른 혼합 아님
- [d] bardenhagen2001_mpm_improved_contact_granular_stress_waves | 값 없음. 접촉이 미끄러질 수 있으면 (μ 0.5) 하중 경로가 먼저 "원판 접촉 ↔ 벽" 으로 생기고, 붙으면 (μ ∞) 원판 접촉점 사이로 바로 생김 | §6-3 (L255–256) · Fig 10–11 | stated (정성) | 같은 재료 원판 5 개 · 동적 응력파 · 혼합 아님
- [d] nam2026_dpe_microstructure_review | 값 없음. 건식전극은 고체-고체 직접 접촉이라 캘린더링 응력이 입자에 직접 전달 · high-stress compaction 구간에서 입자 재배열이 제한돼 AM 입자에 응력 집중 · 두 크기 혼합은 기하 재배열로 치밀화 | §3.4.2 (L291–294) · §3.4.1 (L278–280) · Fig 6b · 6d | 표지 없음 (정성) | Li-ion 건식전극 · 롤 캘린더링
- [d] lim2025_virtual_calendering_framework | 하중 몫 값 없음. 밀도 ↑ → AM 내부 von Mises 응력 ↑ (접촉점과 입자 내부); 카드의 우리 쪽 기록: a9_50 에서 "severe fracture 63 % @p10 (전부 큰 AM_P → 하중 독점 → 분쇄)" | §6.1 (L217–218) · §9(D) (L332–333) | 표지 없음 | NCM622 + CBD 액체계 · 선형 탄성 계산 · 우리 쪽 기록은 논문 밖
- [d] 관련 카드 지목만 (이 배치 밖): `cardenasbarrantes2020_rigid_deformable_mixture_compaction_nscd` · `cardenasbarrantes2022_soft_hard_grains_compaction_experiment_dic` | bardenhagen2000 §15 (L413) · bardenhagen2001 §16 (L405) | "반입 예정" (카드 표기) | —


### [batch_02] d. 단단한 입자 + 무른 입자를 섞어 누를 때 단단한 입자의 하중 몫 · 재밍

단단한 입자와 무른 입자를 섞어 누르고 **하중 몫을 잰 카드는 이 배치에 없음**. 닿는 것:

- [d] nezamabadi2022_mpm_cd_plastic_particle_compaction | 단일 재료 2D: 재밍 (체제 전환) Φc ≃ 0.8 · 그때 응력 σc ≈ 0.18–0.19 MPa (네 계열 공통) · 재밍 뒤 "particle rearrangement is negligible and the particle shape change controls essentially the packing evolution" (논문 p.5) | §3.3 (L130–131) · §10 (L463–464) | stated (Φc · 인용문) / digitized (σc) | 2D · "강체 입자 (우리 AM) 혼합 없음" (§4.7 L228) · 시작 Φ0 0.78 이 재밍 바로 아래
- [d] nezamabadi2022_mpm_cd_plastic_particle_compaction | 거시 소성 분기 (0.875 σ_y) 가 입자 항복보다 먼저 = 하중 분담의 이질성 (모든 입자가 동시에 항복하지 않음) | §8-④ (L406–408) | 저자 문장은 stated · "하중 분담의 이질성" 은 카드의 풀이 | 단일 재료 안의 이질성 — 단단 / 무른 두 상의 몫 아님
- [d] nguyen2017_mpm_bpm_deformable_particle_compaction | 2D: 재밍 (응력 시작) ε ≈ 0.08 · Z ≈ 3 · Φ ≈ 0.75 — "the assembly remains fragile (rearrangements of particles) until … Φ0 ≃ 0.8"; Φ0 = 0.8 에서 Z ≈ 3.7–4.5 · 최대 Z 5.5 | §3.3 (L120–122) | stated / digitized (3.7–4.5) | 2D · 카드: "재밍은 두 개 (응력 시작 ↔ √ 법칙 기준 Φ0)" — 정의를 결과 전에 고정 (§8-③ L291–292 · "우리 해석")
- [d] pycompact2025_dem_mpfem_workflow | 단상 금속 3D: 세 단계 ① 재배열 (응력 거의 0) → ② 변형에 의한 치밀화 → ③ 부분 탄성 회복; 응력 개시 ε ≈ 0.365 (Coarse) / 0.285 (Fine) | §9.4 (L403–405) · Fig 4a | stated (세 단계) / digitized (개시 ε) | 단상 · 변형 정규화 길이 미기재
- [d] alabdali2023_cgmd_wet_manufacturing_ssb_cathode | AM + SE + CBD 복합 (강체 구 · 응력 좌표 없음): 50 % 압연에서 상부 (24–28 µm) pore · CBD ≈ 0.03–0.05 로 붕괴 · 같은 자리 AM 최대 0.74 | §3-1 (L129) · §5 Fig 3c 행 (L310) | digitized | 하중 몫은 없음 (압력 미보고) · "강체 구가 흐르지 못해 생기는 기하 붕괴" 는 카드의 해석 (L270–272 · "우리 해석")
- [d] 우리 쪽 기록 (카드 안) | "R1 의 정직한 압축이 ε_sphere 1.125 % 까지 과압축 … 주원인은 얼린 AM 이 하중을 0 지는 것" | nezamabadi2022 §8-② (L398–399) | 표지 없음 | 논문 값 아님
- 카드가 가리키는 이 배치 밖 카드: `martinbouvard2003_dem_composite_cold_compaction` · `bouvard2000_hard_soft_powder_densification` (nezamabadi2022 §12 L506 — "강체 + 무른 입자 혼합 (이 논문에 없는 축)").


### [batch_03] d. 단단한 입자 + 무른 입자를 섞어 누를 때 단단한 입자의 하중 몫 · 재밍

단단한 입자의 **하중 몫을 숫자로 준 카드는 없음**. 밀도 · 임계 분율 · 최대 충전률로 본 근거만.

- [d] bouvard2000_hard_soft_powder_densification | 두 체제: (A) 저압 (σ_y_soft ≫ P) = 재배열 지배 · 경입자 많은 쪽이 유리 (WC–Co 상온 die: Co 0 % > 5 > 10 > 16 > 24 %) / (B) 고압 = 연입자 변형 지배 · 경입자가 압밀을 방해 | §1 (L10) · §3 (L31) · Fig 8 (L70) | stated + digitized | 금속 + 세라믹 · 고온 포함 · 하중 몫 수치 없음
- [d] bouvard2000_hard_soft_powder_densification | 경입자 분율 ↑ → 상대밀도 ↓: Astroloy 0.995 → +18 vol% alumina 0.95 → +35 vol% 0.86 (100 MPa · 1000 °C · 3 h HIP) | §3 (L24–26) · Fig 1 | stated | HIP (크리프 포함) · LPSCl 아님
- [d] bouvard2000_hard_soft_powder_densification | 경상 percolating 망이 응력 일부를 받는다는 미세구조 증거 = alumina inclusion 균열 (break-up) | Fig 2 (L64) · §9 (L108) | 표지 없음 (SEM 정성) | 하중 몫 수치 없음
- [d] bouvard2000_hard_soft_powder_densification | 경입자 percolation 임계 f_hard = 0.32 (단분산 r = 1 · bonded) · sliding 허용 시 0.96 (Jagota–Scherer) · r = 2 → 0.18 · r ≈ 3–4 → ~0.13; 클러스터: f_incl 0.1 → 58 % 고립 · 0.2 → 32 % 고립 · 0.35 첫 percolation · 0.5 → 95 % 단일 클러스터 | §3 (L32–34) · Fig 10 · 11 | stated (r = 1 · 2 · 클러스터) · digitized (r ≈ 3–4) | 힘 없는 순기하 패킹 모사 (L46) · 0.32 ↔ 0.35 두 값 (카드 문제) · 우리 계 매핑 r = d_SE/d_AM ≈ 0.1–0.4 → 임계 ~0.3–0.4 는 카드 추정 (L41 · 표지 없음)
- [d] bouvard2000_hard_soft_powder_densification | Al + 60 vol% carbide: carbide 충진이 초기 ρ ≈ 0.5 에서 30 % 부피 → ρ = 0.91 에서 55 % 부피 (최대 패킹) — 경입자 골격이 재배열로 치밀화 (carbide 변형 · 파쇄 없음) | §3 (L30) | stated | 450 °C die · 금속 기지
- [d] cardenasbarrantes2020_rigid_deformable_mixture_compaction_nscd | 강체가 많을수록 최대 충전률이 낮다 — φmax (Eq. 12 적합) μ 0: κ 0.2 / 0.5 / 0.8 / 1.0 = 0.877 / 0.932 / 0.974 / 0.994 · μ 0.2: 0.862 / ≈ 0.914 / ≈ 0.955 / 0.982 (κ = 무른 부피분율) | §3-3 표 (L143–147) · 그림 5 | digitized(vector) | 2D 원판 · 초탄성 · 등방 · 두 상 같은 크기 · φmax 는 적합 형식에 묶인 양 (L154–155)
- [d] cardenasbarrantes2020_rigid_deformable_mixture_compaction_nscd | K/E 발산 위치: κ 0.2 → φ ≈ 0.85 (μ 0.2) · 0.87 (μ 0) / κ 0.5 → ≈ 0.91–0.92 / κ 0.8 → ≈ 0.95–0.96 / κ 1 → ≈ 0.96–0.98 · Platzer 특성 압력 P0(κ)/E: κ 0.2 에서 0.17 (μ 0) · 0.33 (μ 0.2) | §3-2 (L119–120 · L133) · 그림 4 · 7 · Table I | digitized (발산 위치 — 카드가 범례 대신 "곡선 · 물리 기준" 으로 μ 를 붙임 L381–382) · stated (P0) | 2D · 초탄성
- [d] cardenasbarrantes2020_rigid_deformable_mixture_compaction_nscd | 하중 몫 분해 없음 — "강체–강체 / 강체–무른 / 무른–무른 접촉 유형별 분해 없음 (평균량만)" · 강체 효과는 φmax(κ) 하나로만 들어옴 · 본문 설명은 기하 (강체 상은 자기 jammed 충전률에 묶인다 — 식 14 · 15) | §3-5 (L172) · §12-B 3 (L581–583) · §8-6 (L469–471) | 표지 없음 (카드 판독 · 해석) | 2D
- [d] cardenasbarrantes2020_rigid_deformable_mixture_compaction_nscd | 카드가 적은 우리 쪽 기록: AM 을 얼리고 SE 가 판 하중을 전부 지게 누르면 ε_sphere 1.13 % (실험 15.6 % 대비 14.5 %p 과압밀) · f = 0 서보 두께 25.842 µm (DEM 30.28 µm 의 −14.7 %) · 우리 real_14 의 SE 고체 부피분율 ≈ 0.26 = κ 0.2 와 0.5 사이 | §8-6 (L467–468) · §8-3 (L443–444) | 표지 없음 (우리 쪽 기록) | 논문 값 아님
- [d] cardenasbarrantes2021_soft_rigid_mix_compaction_proceedings | jammed 시작 상태: φ0 = 0.815 / 0.811 / 0.807 / 0.807 (μ 0.0 · κ 0.2 / 0.5 / 0.8 / 1) · Z0 = 3.4 / 3.6 / 3.5 / 3.4 (μ 0.0) · 3.3 / 3.7 / 3.5 / 3.5 (μ 0.2) | §3-1 Table 1 (L66–71) | stated | 2D · Z0 정의 (rattler 포함 여부) [미확인] (L77)
- [d] cardenasbarrantes2022_soft_hard_grains_compaction_experiment_dic | 힘–변형 곡선: κ 0.2 는 작은 ε 에서 힘이 가파르게 오르고 톱니 (급격한 재배열) — 끝 ≈ 170 N @ ε ≈ 0.10 (κ 0.2) · ≈ 95 N @ 0.17 (κ 1) · 힘이 오르기 시작하는 ε: κ 0.2 ≈ 0.02 · κ 0.5 ≈ 0.07 | §3-3 (L117–118) · 그림 1c | digitized | 2D · 실리콘 / PVC · kPa · 입자 약 100 개
- [d] cardenasbarrantes2022_soft_hard_grains_compaction_experiment_dic | φmax: κ = 1 → 0.97 · κ = 0.2 → 0.88 ("closer to the random close packing") · 원문 "φmax goes ideally from 1 for purely soft systems to φJ for purely rigid systems" | §3-2 (L106) · §11 (L383–384 · p. L022901-3) | stated | κ 0.5 · 0.8 값은 본문에 없음 [미확인] · κ = 개수 분율
- [d] cardenasbarrantes2022_soft_hard_grains_compaction_experiment_dic | 강체가 많으면 무른 입자에 변형이 몰린다: 변형 분포 폭 σ_C 의 선형 구간 끝 (cut-off) κ 0.2 ≈ 0.002 · 0.5 ≈ 0.032 · 0.8 ≈ 0.062 · 1.0 ≈ 0.072 (φ − φJ) · 혼합 유효 영률 E* 는 κ 가 작을수록 큼 (κ 1 / 0.8 / 0.5 / 0.2 = 0.30 / 0.375 / 0.60 / 1.50 MPa) | §3-3 (L126) · §3-4 (L132) · §5-6 (L236) | digitized (cut-off) · derived(ours) (E*) | 하중 몫 측정 없음 (접촉력 없음 L274)
- [d] arzt1982_particle_coordination_densification_spheres | 혼합 없음 (단분산). 카드의 우리 쪽 서술만: 포화한 입자는 평균 고체 응력 (p/D ≈ 0.36 GPa) 의 약 2.4 배 이상을 받는 입자 · 가설 = SE 가 많은 침대의 고립 AM 은 무른 기지 속 강성 포함체라 응력 집중 · 방향 참고 = real_14 300 MPa AM 하중분담 0.675 (AM–AM 규약) · 0.794 (phase 규약) | §L-3 (L322) | "우리 유도" · 가설 (미검증) · CLAUDE.md 인용 | 논문 값 아님


### [batch_04] d. 단단한 입자 + 무른 입자를 섞어 누를 때 단단한 입자의 하중 몫 · 재밍

하중 몫의 **수치는 이 배치에 없음** (단단 + 무른 혼합을 누른 카드가 없다).

- [d] giannis2021_stress_based_multicontact_dem | 논문은 한 재료의 두 크기뿐 (1921 이봉 하이드로겔 = 1573 개 ⌀1.6 cm + 348 개 ⌀2.1 cm · 크기비 1.31). 카드의 우리 쪽 기록: 순수 SE (SE 가 하중 지지) ⟨δ⟩ ≈ 지름의 11 % ↔ production 복합 (AM 차폐) ⟨δ⟩ = 1.75 % — "AM 골격이 SE 를 차폐해 ⟨δ⟩ 가 작기 때문" | §4.7 (L243–245) · §7-4 표 (L395–396) · 판정 3 (L402–403) | 논문 = 표지 없음 (카드 서술) · 우리 값 = 표지 없음 ("우리 값") | 하중 몫 (분율) 수치 없음 · 1.75 % 의 정의는 카드 문제 A-4
- [d] giannis2021_stress_based_multicontact_dem | 다접촉 항의 상대 강화 ΔF/F = k·β·ν·C·(δ/d) — 배위수 C 에 비례 (같은 겹침이라도 잘 구속된 입자의 접촉이 더 뻣뻣) | §7-4 (L383–388) · §7-2 (L360–363) | "우리 유도 — 논문 수치 아님" | 동일 구 · 같은 C · f · δ 가정 · 논문은 C 를 한 번도 보고하지 않음 (L234–235)
- [d] coetzee2017_dem_calibration_review | 값 없음. 닿는 것: Paulick [235] "the denser the system, the more important the stiffness value becomes" (p.136) · Ng & Asce [193] 입자 강성을 낮추면 배위수가 오르고 두 효과가 상쇄돼 벌크 탄성계수는 거의 불변 (삼축 · p.130) | §5-Q2(b) 표 (L231) · §5-Q2(c) (L277–281) | 리뷰 stated (소환) · 원문 인용 | 한 재료 · 저응력 · 혼합 아님
- [d] electromechanical_contact_model_particulate_systems | 값 없음. 전류 경로 = force chain (식 25 I_in = (F_n/F_ext)·I_0 · Fig 11 · 15) · HPT 조각층에서 작은 조각은 접촉 못 해 전류 0 · 큰 조각이 force chain 에 참여 (electroactivity index · 식 29 · Fig 18) | §4 (L89–90 · L101–103) · §5 Fig 11 · 18 행 (L119 · L126) | 식 = stated · 그림 = 정성 | 금속 · 같은 재료 조각 · 하중 몫 분율 없음
- [d] dmt1975_adhesion_contact_deformation · deng2021_mechanical_surface_energy_tester_bond_number | 이 배치에 없음 | — | — | —


### [batch_05] d. 단단한 입자 + 무른 입자를 섞어 누를 때 단단한 입자의 하중 몫 · 재밍

하중 몫의 **수치는 이 배치의 논문 값으로는 없음** (단단 + 무른 소성 혼합을 누른 카드가 없음).

- [d] gonzalez2012_nonlocal_contact_confined_granular | 하중 몫 수치 없음. 2 종 혼합 침대 (E 19 GPa · ν 0.30 · 반지름 cut-off 75 / 80 µm + E 7 GPa · ν 0.20 · cut-off 125 / 167 µm · 125 개 · 다이 1 × 1 mm) 의 적용 하중 + 횡반력 vs 상대밀도 (0.4–0.9 · 0–600 MPa) 를 Hertz ↔ 비국소로 비교; 다짐 (재배열) 국면 ρ_R 0.42 → 0.56 에서는 두 법칙이 비슷한 변형 패턴 · 그 뒤 압밀 국면에서 갈라짐 (Δ ≈ 50 %) | §3.2 (L80–89) · §6.3 (L420–428) · Fig 18 · 19 | stated (곡선값은 판독 0) | 강성비 2.7 의 탄성 유기 분말 (단단 + 무른 소성 혼합 아님) · 실현 1 개
- [d] gonzalez2012_nonlocal_contact_confined_granular | 단일 구속 구에서 Hertz 는 횡반력 = 0 을 주지만 FEM 은 유한하고 비국소가 재현 ("agreement ... remarkable") | §5.3 (L335–336) · Fig 8 · 14 · 17 | stated | 탄성 고무
- [d] he2026_dem_calendering_inhomogeneity_areal_density | 단단한 입자만 있는 극한 (AM ≈ 100 wt% · 카드: 하중 분담 ≡ 1): 판 응력 98.2 MPa (ρ_c 2.933) → ≈ 278 MPa (3.20) → ≈ 1.0 GPa (3.50) → ≈ 1.9 GPa (3.77 종점); 카드의 3 점 Heckel 은 선형 구간 없음 (구간 P_y 1,010 → 2,921 MPa) | §12.2 (L579–585) · §12.3 (L590–604) · §7 표 (L363 · L368) | 98.2 = stated (Table 4) → derived(ours) · 나머지 digitized (±20 %) | NCM622 강체 구 · E 47 GPa 미출처 · 3 점 추정
- [d] he2026_dem_calendering_inhomogeneity_areal_density | 힘 사슬: 입자 압축력 컬러바 0–233 mN (최대 / 평균 ≈ 11 배) — 논문은 정량화하지 않음; 카드 복원 배위수 Z = 5.27–5.29 (면적로딩 무관) | §3.6 (L162–163) · §12.5 (L616–627) | label(fig) · Z = derived(ours) | 단일 상
- [d] he2026_dem_calendering_inhomogeneity_areal_density | 카드가 적은 우리 쪽 값 (논문 밖): AM–AM 하중 분담 0.517 / 0.598 / 0.675 / 0.620 (100 / 200 / 300 / 600 MPa) · 상 (phase) 규약 0.726 / 0.768 / 0.794 / 0.763 | §7 표 (L368) | 표지 없음 (우리 쪽 기록 · 출처는 규범 문서라고 카드 L356–357) | 논문 값 아님
- [d] heck2026_densification_sulfide_se_binder_scalable | 값 없음 — 참고문헌 61 (Ohashi 외 · J. Power Sources 470 (2020) 228437 · 복합 전극 응력 분포 · 강성 높은 상으로 응력 집중) 지목만; 저자 해석: 바인더가 "buffer" 로 응력을 흡수해 입자 소성 변형을 줄임 | §11 (L305) · §3-8 (L153) | [인쇄] (서지 · 해석) | 그 서지의 내용 연결은 카드가 [미확인] 으로 둠


### [batch_06] d. 단단한 입자와 무른 입자를 섞어 누를 때 단단한 입자의 하중 몫 · 재밍

- [d] martinbouvard2003_dem_composite_cold_compaction | 평균 접촉력 비 N₂₂/N₁₁ (경–경 / 연–연) ~3.5 (경질 40 vol%) · ~2 (20 %) — 마찰 0.1; 무마찰이면 ~1.0–1.3 · N₁₂/N₁₁ (연–경 / 연–연) ~1.0–1.27 | §3 (L27–28) · Fig 5 · 6 | digitized (Fig 6b · 5/6a) | 금속 모델 · 같은 크기 구 · 3D · 회전 없음
- [d] martinbouvard2003_dem_composite_cold_compaction | 구속계수 K_h (복합 압력 / 균질 압력 @ 같은 D · isostatic) ≈ 1.3 (20 vol%) / 1.8 (40 vol%) · close die K_cd ≈ 1.3 / 1.6 @ D ≈ 0.80–0.85 · 실험 (Table 1) 1.3 / 1.7–2.0 | §3 (L25–26) · Fig 8–10 | stated/digitized | 무차원 · μ 0.1 · 1/m 0.2–0.4 에서 실험과 정합
- [d] martinbouvard2003_dem_composite_cold_compaction | 경질 강성은 거의 무관: E₂/E₁ 10 → 100 에서 거시응력 < 3 % 변화 · 연–경 접촉의 들여쓰기 h 가 균질 대비 20–40 % 더 큼 (f₂ = 40 %) · 배위수 Z 는 경질 분율에 거의 무관하고 Z₂₂/f₂ 만 마스터 곡선에서 약간 이탈 | §3 (L29) · §4 (L44) · Fig 3 · 4 | stated | 같은 한계
- [d] mesarovicfleck2000_dissimilar_elastoplastic_indentation | 이질 접촉: 큰 접촉에서 변형이 무른 쪽에 집중하고 뻣뻣한 쪽은 사실상 강체 (Fig 6) · 연 + 경 B2 단위셀은 D ≈ 0.82–0.826 에서 새 접촉 6 개가 동시에 생겨 (8 → 14) 접촉력이 급증 | L119–121 · L128–130 | stated | 단위셀 하나 · m = 3 · 하중 몫 숫자는 없음
- [d] luding2008_cohesive_frictional_contact_models | (우리 쪽 기록 · 논문 값 아님) real_14 dump 의 실제 접촉력 σzz 분해 AM–AM 0.670 · AM–SE 0.276 · SE–SE 0.053 · 원자별 virial 의 AM 상 0.809; Hertz 재구성은 0.843 (E 1.35) / 0.258 (E 24) | §7.3 (L209–225) | 표지 없음 (카드가 든 출처 = `docs/mpm_wallP_conditional_troubleshooting.md §12`) | 우리 DEM 값 — 논문 근거로 쓰지 않음
- [d] mcgeary1961_bimodal_sphere_packing | 하중 몫 자료 없음 — 강체 구의 기하 충전만: 작은 구가 큰 구 틈을 지나 채우려면 d_c/d_f ≥ 약 7 · 이성분 최대 86.0 % (조대 ~72.7 %) | §3 (L29 · L32) | stated | 무압 · 강체 · 금속 shot
- [d] oh2026_bimodal_composite_cathode | 가압 중 하중 몫 자료 없음. (사이클 중) ΔP_avg 는 CAM 질량분율이 정한다: CAM8:2 측정 0.303 ≈ 질량가중 0.304 MPa · 시뮬의 CAM–CAM 접촉점 11 → 304 (CAM10:0 → 0:10) | §4.4 (L310–323) · Table S12 (L353) | 표지 없음 | 사이클 부피 변화이고 가압이 아님


### [batch_07] d. 단단한 입자 + 무른 입자를 섞어 누를 때 단단한 입자의 하중 몫 · 재밍

단단한 입자의 **하중 몫을 숫자로 준 카드는 없음**.

- [d] so2022_dem_contact_model_assb_compaction_sintering | 단단한 쪽 (AM · H 11.2 GPa) 은 소성 거의 안 함 · 무른 SE (LPS · H 1.9 GPa) 만 소성 · 쌍의 항복은 min(σ_i^yield, σ_j^yield) 로 무른 쪽이 정함 · 융착은 SE 에만 | §3 표 (L32–33) · §4.3 eq 5 (L116–119) · §4.4 (L137) | stated | 하중 몫 수치 없음 · LPS + NCM/LiCoO₂
- [d] so2022_dem_contact_model_assb_compaction_sintering | 재밍의 표현: 평형 겹침 상한 h_ov^max = 0.6 R_eff ("consolidation limit") 에서 힘–변위 곡선이 수직으로 급상승 | §4.6 (L163–168) · Fig 4b | stated | 0.6 은 맞춘 값 (0.4 / 0.6 / 0.8 중) · 접촉 한 쌍 수준
- [d] so2022_dem_contact_model_assb_compaction_sintering | 혼합 (SE 코팅 AM) 계산은 360 MPa 한 점 (AM 10,746 + SE 27,263 · 상자 23.9 µm) — AM 하중 몫 · 재밍 분석 없음 | §3 표 (L45 · L47) · §4.9 (L183–184) | stated | 결과 수치는 동반 JPS 논문 소관 (L272)
- [d] sharma2023_nmc_single_crystal_anisotropic_nanoindentation | 하중 몫 수치 아님 — AM 접촉 지지압의 문헌 자리: 결정립 안 작은 압흔 경도 9.4–14.3 GPa (이 논문) 는 "입자 스케일 크라운 지지압의 상한 쪽" · 우리 하중 분담 모듈 밴드 3–6 GPa 와 안 겹침 · 밴드와 겹치는 것은 다른 부류 (압흔 ≥ 결정립 3.2–5.5 GPa · 입자 파괴 명목 접촉압 3.6 ± 0.9 GPa — 둘 다 다른 카드) | §7-4 (L370–384) | stated (이 논문 H) · 다른 카드 값은 2 차 인용 | NMC · 우리 쪽 판정 문장 · "두께 예측 자체는 H_AM 에 둔감" (L384)
- [d] schreiner2020_dem_calendering_lib | 정성 한 줄: "CAM 입자가 anode보다 단단 → 더 큰 힘이 입자-입자 재배열(입자마찰 동반)을 일으킨다" [16,17] | §4.3 (L76) | 표지 없음 (카드의 우리말 옮김) | LIB · 수치 없음
- [d] pasha2014_linear_elastoplastic_adhesive_contact · paulick2015_elastic_particle_properties_dem_review · roessler2019_dem_cohesive_aor_cylinder_lift_calibration | 해당 없음 (단일 재료 · 리뷰는 단단 / 무른 혼합의 하중 몫을 다루지 않음) | — | — | —


### [batch_08] d. 단단한 입자 + 무른 입자를 섞어 누를 때 단단한 입자의 하중 몫 · 재밍

하중 몫의 수치는 **이 배치에 없음**. 닿는 근거만.

- [d] storakers1997_similarity_inelastic_contact | 서로 다른 두 변형체의 상호 압입 (§5): 결합 강도 1/σ₀^q = 1/σ₁^q + 1/σ₂^q (eq82 · 1/q = 1/m + 1/n) · 결합 곡률 (eq84) — 원문 "spheres of different rigidities and sizes related to composite compaction problems have recently been investigated by Storåkers (1996)" | §7.3 (L142–149) | stated (식 · 인용문) | 두 물체가 지수 m · n 을 공유할 때 · 접촉 하나 — 하중 몫 · 재밍 값 없음
- [d] varkey2026_multicontact_elastoplastic_dem | 같은 모델에서 SE 단독 층 기공 21 % ↔ AM 많은 양극 37 % (350 MPa) · 양극은 125 → 350 MPa 에서 39 → 37 % 로 거의 안 줄어듦 | §3 표 (L18 · L20) · Fig 10 · 13 | digitized | 할라이드 · 강체 구 · 조성 값과 하중 몫 수치는 카드에 없음 ("AM-rich floor" 는 카드 표현 · L64)
- [d] vanlew2015_modifying_youngs_modulus_distribution | 침대 접촉력: 거시 응답은 E 가 지배 — "the largest contributor to stress–strain response is the Young's modulus. The coefficient of friction and radius distribution had comparatively insignificant influence." · 힘 분포 본체는 7 침대가 겹치고 꼬리 (F ≳ 3 N) 만 갈리며 "higher coefficients of friction generally have higher peak contact forces" | §6.1–6.2 (L307–308 · L320–329) · §3.2 Fig 5 (L114–122) | 인용문 = 원문 · 꼬리 값 = DIGITIZED | 단일 재료 침대 (단단 + 무른 혼합 아님) · 6 MPa · 시드 1 개 (꼬리는 접촉 수십 개 수준)
- [d] stallard2022_cathode_mechanical_properties_review | 단단한 입자 (NMC) 쪽 접촉 지지압의 부류: 압흔 ≥ 결정립 (stage III) 압입 경도 3.2–5.5 GPa — 우리 하중분담 모듈의 밴드 3–6 GPa · 역산 3.83–3.85 GPa 와 사후 부합 (압흔 크기 ≈1.72 µm 점) | §0 #4 (L26) · §7-4 (L403–412) | vector-read (2차) + derived(ours) D11 · "사후 부합" 은 카드 판정 | 우리 쪽 기록과의 대조 — 논문이 하중 몫을 말한 것이 아님 · NMC532 · 소급 정당화 금지 (L409–410)
- [d] thorntonning1998_adhesive_elastoplastic_contact | (우리 쪽 기록) 가압 300 MPa 와 LPSCl p_y ≈ 0.08–0.48 GPa 가 같은 자릿수 → σ_y 상한이면 일부 접촉만 항복 · 하한이면 대부분 항복 — 결과가 σ_y 선택에 민감 (Fig 10 이 p_y 0.5 → 1.0 → 3.04 GPa 에서 거동 급변을 보임) | §7.1 (L218–222) | 표지 없음 (카드 산술) | 논문 값 아님
- [d] tovar2026_cold_spray_cathode_composite_dem_plastic_elastic_bond | 단단한 쪽이 무른 쪽에 부딪힐 때 변형은 무른 쪽이 가져감 — Al 기판은 대부분 소성 · NMC 입자는 "the particle yields but does not undergo substantial plastic behavior … permanent deformation of the particle remains minimal" | §4-5 (L128) · §4b 3.2 (L186) | stated (원문 인용) | 160 m/s 충돌 · 결합구 · 준정적 혼합 가압 아님
- [d] thakur2014 · thompson2026 · wang2024 | 해당 없음 (단일 재료) | — | — | —


### [batch_09] d. 단단한 입자 + 무른 입자를 섞어 누를 때 단단한 입자의 하중 몫 · 재밍

단단한 입자의 **하중 몫을 논문이 수치로 준 카드는 없음** (Zunker 세 편은 단일 재료).

- [d] zunker2025_dem_large_deformation_compaction | 서로 다른 재료는 다루지 않음: "we focus on developing and testing a many-interacting particle methodology that properly handles varying radii, leaving the additional task of considering varying material properties as future work." | 머리 (L12–14) · 논문 §2.2 · §15 (L531–532) | 원문 인용 | —
- [d] zunker2025_dem_large_deformation_compaction | 같은 재료 · 다른 크기 쌍: 가상 강체 평면을 기하 교차점에 두면 겹침 분배가 δ_i,geo/δ ≈ R_j/(R_i+R_j) — 작은 입자가 겹침을 거의 다 가짐 (카드 계산: 12 : 1 이면 작은 쪽 92 % · 큰 쪽 8 %) · 카드 해석 "큰 쪽은 사실상 강체처럼 · 작은 쪽만 소성" | §4 (L128–146) · eq 3–4 | stated (식) · DERIVED (92 % / 8 %) | 재료가 같은 쌍의 기하 분배 — 하중 몫이 아님
- [d] zunker2025_dem_large_deformation_compaction | 반경비 0.25 에서 전방 재하 일치가 가장 나쁨 — 이유 (i) 기하 교차가 접촉 면적을 잘 못 나타냄 (ii) 작은 입자는 완전 항복인데 큰 입자는 거의 미항복이라 소성 누적 격차가 큼 | §4 (L149–152) · App C · Fig C.10 | stated (서술) | 검증 범위 반경비 0.25 까지
- [d] zunker2025_dem_large_deformation_compaction | 카드 계산 — 가짜 접촉 페널티가 강한 다분산에서 큰 입자끼리의 정당한 접촉을 지울 수 있음: R 6 µm 두 개 (중심 거리 11.9) + 홈에 낀 r 0.5 µm (6.4 × 2) → 작은 입자가 "중심" 으로 지정 · α = 136.8° → 가중 w = 0 (큰 입자끼리 접촉력 0) | §5-3 b (L207–221) | DERIVED ("논문의 오류 주장이 아니다" · 미검증 영역) | 논문 검증은 단분산 + 삼분산 (±20 %) 뿐
- [d] zunker2024_bulk_elastic_partII | 구속 (재밍에 해당하는 표현): 벌크탄성 발동 δ_o/R_o = 0.21 (삼축) · 0.49 (die 1차 접촉) · 단축은 발동 없음 — 같은 ψ_b 0.08 에서 구속의 정도가 발동 시점을 정함 | §3 (L51–53) · Fig 1 행 (L133) | stated | 단일 입자 · E/Y 20
- [d] zunker2024_bulk_elastic_partII | 1차 접촉이 만드는 원거리 인장응력이 2차 접촉 근처를 조기 항복시킴 (die · 0.2 < δ_o/R_o < 0.5 · Fig 5c) → 카드의 우리 쪽 추정: 하중을 받는 단단한 AM 골격이 주변 SE 를 조기 항복시킬 것 ("정량화 전 인용 금지") | §5 (L137) · §8 ⑤ (L240–242) | stated (저자 설명) · 추정 (우리 쪽) | 수치 없음
- [d] xu2017_nmc532_nanoindentation_modulus_hardness_toughness | 카드의 우리 쪽 기록: H_NMC 8.6 ↔ (우리) H_SE 0.85 GPa → 비 ≈ 10 = "AM 은 강체에 가깝고 SE 가 변형" 비대칭의 크기 근거 · 하중 분담 모듈의 "NCM811 압입 경도 문헌대 3–6 GPa" 는 출처 없음 · 역산 H_AM 3.83 GPa (real_14) 는 pristine 8.6 의 0.45× · 나노 경도는 입자 스케일 접촉압의 상한 쪽 양 | §7 표 (L321 · L327) · §9-3 (L418–423) | 표지 없음 (우리 코드 값 · 카드 판정) | 논문 값은 8.6 뿐 · 0.85 의 출처는 이 카드에 없음


### [batch_10] d. 단단한 입자와 무른 입자를 섞어 누를 때 단단한 입자의 하중 몫 · 재밍

하중 몫의 **수치는 이 배치에 없음**. 닿는 정성 서술만 있다.

- [d] bazzoun2025_dem_parameter_sensitivity_assb_cathode | 하중 몫 없음. 닿는 것 둘: ① 기공 계산에서 SE–CAM 겹침 영역의 점을 CAM 으로 귀속 (E_CAM ≫ E_SE 라 CAM 이 SE 를 압입) ② f_CAM 80–85 wt% 에서 모델–실험 불일치 + 민감도 급증 · 모델의 압력 감도는 "유의 추세 없음" | §4 (L68) · §3 (L51) · §10 (L150 · L155) | 표지 없음 (② 는 카드의 "저자 명시") | 캡 없는 탄성 Hertz · NMC532
- [d] faka2026_particle_size_consolidation_strain_lpscl | (한 재료 · 크기 불균일) DEM 입자 응력 (1.6 GPa 인가): 실측 PSD 중앙값 ≈ 4.4 / 3.85 / 3.6 / 3.5 GPa (4 / 11 / 20 / 40 µm) · 꼬리 > 10 GPa · 단일 크기는 ≈ 3.57 / 3.46 / 3.46 / 3.46 GPa (좁음) · 크기별 평균은 작은 입자 ≈ 4–4.5 → 큰 입자 ≈ 1.5 GPa. 저자: *"In polydisperse packings, smaller particles tend to exhibit higher contact pressure and stress, especially under uniaxial compaction. This results from Hertzian contact mechanics, sample geometry …"* (Radjai 2015 인용) | §3-6 (L113–114 · L119–120) · 논문 Fig 4b · c · S19 · S20 · p.8 | 값 = [판독] · 인용문 = [인쇄] | 단단 + 무른 혼합이 아님 · "입자 응력" 정의 [미확인] · 경계 20 % 제외
- [d] kim2024_optimal_cathode_composite_mechanical_mixing_se_coverage | 값 없음 — "껍질이 있어도 연성 SE 가 냉간 압축에서 옆으로 퍼져 NCM 끼리 닿는다 (SI S15 — NCM@5SE)" · 다 입힌 MM23 은 커진 입자 사이에 공극 · 고립된 NCM | §3-3 (L107–108) | [인쇄 p.4] | 정성 (SEM) · FEA 의 NCM / SE von Mises (L127) 는 충전 중 확산 변형이라 가압 하중 몫이 아님
- [d] lin2025_submicron_lpscl_cathode_li_kinetics | 값 없음 — 큰 SE (D50 11.88 µm) 양극 단면에 NCM811 끼리 직접 (점) 접촉 · 작은 SE (D50 2.34 µm) 는 NCM 이 SE 에 둘러싸임 | §3c (L100) · §5.4 (L230) · 논문 Fig 4a | stated | 정성 (FIB-SEM)
- [d] lei2026_se_particle_size_effects_review | 값 없음 — 표 2: 높은 제조 압력에서 작은 입자 *"Rearrangement"* · 큰 입자 *"Particle fragmentation"* · 복합양극은 지나친 압력이 SE 망을 끊는다 (예: AM 이 SE 상으로 파고듦) | §3-5 (L109–110) | [인쇄 Table 2 · p.17] · [리뷰 서술] | 2차 정리 · 수치 없음
- [d] lee2025_heckel_argyrodite_powder_densification_nanoindentation | (카드의 교차 언급) "복합체 회복은 AM 골격이 지배할 수 있다 (miss2026 AMI: pc-NMC622 단일상 7.9 % @300 MPa) — 이 논문 (SE 만) 은 그 몫을 주지 않는다" | §7-2 (L183) | 표지 없음 | 다른 카드의 값
- [d] minnmann2021_jes_charge_transport_bottlenecks · minnmann2024_microstructure_porosity_visualization · bazzoun2026_dem_fem_rnm_ionic · frankenberg2025_milling_dry_processed_sulfide_cathode_microstructure | 이 카드들에 없음 | — | — | —


### [batch_11] d. 단단한 입자와 무른 입자를 섞어 누를 때 단단한 입자의 하중 몫 · 재밍

하중 몫을 숫자로 낸 카드는 이 배치에 없다. 정성 힘사슬 = otani2025 한 장.

- [d] otani2025_dem_se_dispersion_aggregation_compression | 입자별 "총힘" 지도 (@1000 MPa): 응집수 N=1 은 전 침대 균일 · N=6 은 AM 이 0.02–0.05 N (한 알 ~0.07 N) · 0.04 N 넘는 입자만 뽑으면 **위아래를 관통하는 AM 기둥** → 분산이 나쁠수록 AM–AM 힘사슬과 AM 응력 집중 | §1 (L47) · §5 Fig 4 (L306) | 표지 없음 (그림 서술 · 정성) | 하중 분율 수치 없음 · "total force" 의 정의 (합력인지 접촉력 크기 합인지) 미기재 (L527) · AM 이 NCM111 (E 71 GPa) · 100× 조대화 · 탄성 접촉
- [d] otani2025_dem_se_dispersion_aggregation_compression | 우리 쪽 기록 (논문 값 아님): AM 하중 몫 AM–AM 규약 0.517 / 0.598 / 0.675 / 0.620 · 상 규약 0.726 / 0.768 / 0.794 / 0.763 @100 / 200 / 300 / 600 MPa · 카드 예측 "f_AM 은 분산도의 증가함수여야 한다" | §8-⑤ (L448–454) | 표지 없음 (카드 L361–363 이 "우리 값은 작업 브랜치 CLAUDE.md 에서 옮긴 것 · 정본 미확인" 이라 고지) | 카드 작성 시점 (09-19) 의 우리 값
- [d] park2020_dimension_controlled_se_percolation_contact_area | 역학 없음 — 강체 판 (2D 5000 · 7500 nm) 이 흑연 사이를 못 채워 전극 두께 ≈1.56 배 · ≈2.2 배 (목표 기공 30 % 를 못 맞춤) | §3-C (L85–89) | 판독 (두께) · 파생 (배수) | 배치 알고리즘의 결과이지 하중 계산이 아님 (L89)
- [d] 그 밖 5 장 | 이 카드들에 없음 | — | — | —


### [batch_12] d. 단단한 입자와 무른 입자를 섞어 누를 때 단단한 입자의 하중 몫 · 재밍

하중 몫의 **수치 (분율) 는 이 배치에 없음**. 가장 가까운 것은 so2021 의 접촉 쌍별 응력 · 겹침이다.

- [d] so2021_dem_mold_pressure_assb_coldpress | Si (단단) + LPS (무름) 3D DEM: 접촉 쌍별 평균 압축 응력 AM–AM 2.5 → 5.9 GPa · AM–SE ~1.0 (평탄) · SE–SE 0.2 → 1.1 GPa (몰드압 25 → 400 MPa); 평형 겹침 비 (h_ov/4R_eff) SE–SE ≈ 0.10 (압력 무관) · AM–SE 0.025 → 0.082 · AM–AM ≈ 0.007; @600 MPa 상대밀도 f_AM 0 / 30 / 50 / 70 % = ≈0.98 / 0.93 / 0.86 / 0.76 (AM 이 많을수록 덜 치밀) | §3 (L28 · L36–37) · §5 Fig 4c · 5 · 6 (L75–77) | digitized | LPS + Si (LPSCl + NCM 아님) · 하중 "몫" 이 아니라 쌍별 평균 응력 · 단일 실현으로 보임 · SE–SE 가 어느 값에서 막히는지 카드 안 서술이 둘 (카드 문제 9)
- [d] benhadjali2026_wip_vs_cup_pressing_assb_cathode_dem | 상별 응력 · 하중 분담 보고 없음 (FEM 물성 [미확인]). DEM 접촉력 분포 · 힘 사슬은 출력에서 제외 (p.19) | §8-0 EM-03 (L351) · §3-8 (L162) | [인쇄] (제외 사실) | —
- [d] yano2026_se_psd_width_ionic_tortuosity_dem | 하중 몫 없음. 닿는 정성: 볼밀 분말은 NCM–NCM 접촉엔 영향이 작다 (저자 · p.6) · DEM 상대밀도는 SE 입도 폭에 거의 안 움직임 (0.728 → 0.722) | §3d (L108) · §3c (L90) | [인쇄] · [벡터 판독] | —
- [d] diener2022_roll_gap_springback_calendering | (단단한 입자 + 무른 바인더 · 정성) 고하중일수록 바인더 영향이 사라짐 = 입자 직접 접촉 · *"the SB effect is mainly a result of the elasticity of the AM particles"* — 바인더 경향에서 추론 (직접 측정 아님) · 극단적으로 입자 한 층이면 입자 소성 없이는 공극 변화가 거의 없음 | §0 (L25) · §3-4 (L79) · §3-6 (L103) | [인쇄] (저자 추론) | LIB · SE 없음 · 하중 몫 수치 아님
- [d] sangros2019_dem_calendering_lib_electrode | (한 재료 · 참고) 내부 응력 σ_zz/σ_xx 가 C1 ≈ 2 → C2 1.4 → C3 1.17 → C4 1.08 (고압에서 등방화) · 편차 fabric F'_zz 가 C1 +0.047 → C3 · C4 음 | §5 Fig 12 · 13 (L137–138) | digitized | NMC 한 종류 — 단단 + 무른 혼합이 아님
- [d] yadav2021_lpscl_sieved_psd_impedance_tortuosity · larson2025_hot_pressing_argyrodite_low_stack_pressure_conductivity · demirtas2021_mpfem_hollow_sphere_die_compaction · sangros2020_lib_electrode_dem_mech_elec_ionic | 이 카드에 없음 | — | — | —


### [batch_13] d. 단단한 입자와 무른 입자를 섞어 누를 때 단단한 입자의 하중 몫 · 재밍

단단한 입자의 하중 몫을 **수로** 준 카드는 이 배치에 없다. 가까운 근거: zhang2026 (하중이 bond 망에서 NMC 직접 접촉으로 넘어감 · Z < 3 · 측압 계수 0.40 → 0.68) · lyu2025 (평균 응력 σ_zz 165 ↔ σ_xx 130 MPa) · ngandjong2021 (기공 바닥 26.2 % = 골격 재밍이라는 카드 풀이) · xu2023 (풀어 둔 AM 도 거의 안 변함) · miss2026_insitu (두 상 **단독** 의 양 끝) · miss2026_pressure (수송으로 본 간접 추론). LIB 카드 넷의 무른 상은 SE 가 아니라 탄소 – 바인더 4–6 wt% 다.

- [d] zhang2026_xct_dem_cathode_calendering_peel_calibration | 하중이 무른 bond 망에서 단단한 NMC 직접 접촉으로 넘어감: 초기에는 bond 가 힘 사슬 망을 지배 → 압력이 오르면 Hertz (NMC–NMC) 접촉 수 증가. 논문 (카드의 한국어 옮김): "힘사슬은 주로 NMC 가 지고, NMC–NMC 힘이 bond 로 전달되는 힘보다 훨씬 크다". 배위수 (N_c/N_p · NMC–NMC 만) 0.906 / 1.29 / 2.05 @30 / 60 / 200 MPa → Z = 2·CN = 1.81 / 2.58 / 4.10 — 30 · 60 MPa 에서 Z < 3 이라 NMC 골격만으로는 하중망이 서지 않음 | §3.6 (L186–198) · §3.8 (L221) · §12 D4 (L529–530) · 논문 Fig 5 · 8 | CN = stated · Z · 풀이 = derived(ours) | 상별 하중 몫의 수는 없음 (Fig 8 에 범례 · 힘 척도 없음) · CN 이 누른 채인지 뺀 뒤인지 [미확인] · 무른 상은 CBD 4 wt% (SE 아님)
- [d] zhang2026_xct_dem_cathode_calendering_peel_calibration | RVE 평균 응력 (Love–Weber): σ_xx / σ_yy / σ_zz = 13.4 / 11.2 / 30.4 (30 MPa) · ≈ 35.5 / ≈ 30 / ≈ 66.5 (60) · 145.6 / 124.1 / 198.5 MPa (200) → 측압 계수 K = σ_면내/σ_zz 0.40 → ≈ 0.49 → 0.68 · q/p 0.99 → 0.41 (눌릴수록 정수압 지배) · σ_xx/σ_yy 는 1.196 → 1.173 으로 일정 | §3.9 (L225–236) · §12 D3 (L521–527) · 논문 Fig 10 | 30 · 200 MPa = stated · 60 MPa = figure-read ≈ · K · q/p = derived(ours) | 누른 채 값 · 1 RVE (측면 ≈ 3 d_max) · 논문의 "200 MPa 에서 이방성 개시" 는 이 수와 어긋남 (카드 판정)
- [d] zhang2026_xct_dem_cathode_calendering_peel_calibration | 가압 경로의 톱니: ≈ 63–65 · ≈ 95 · ≈ 105 · ≈ 118 MPa 에서 압력이 잠깐 떨어지며 기공은 계속 줆 = 변위 제어에서의 하중 강하 (구조 붕괴 · bond 파단 류 사건) · 접촉력 꼬리 최대 / 평균 ≈ 24 (≈ 177 / > 7.3 mN) @200 MPa · 누른 채 기공 ≈ 0.152 | §3.5 (L182) · §3.8 (L216–218) · §10 L16 (L479) | figure-read ≈ · 풀이는 카드 (논문은 언급 없음) | 카드: 0.152 는 넓은 실측 입도 + CBD 소구 + 탄성 겹침 + 미기재 기공 관례가 겹친 값 — "~20 % 강체구 바닥" 을 입도 · 관례 · 하중 상태와 무관한 상수로 쓰지 말 것
- [d] lyu2025_3d_dem_drying_calendering_lib | 단단한 AM (E 142 GPa) + 무른 CBD (E 0.65 GPa = AM 의 1/220 · 6 wt%): 압연 끝 평균 응력 σ_zz ≈ −165 MPa > σ_xx = σ_yy ≈ −130 MPa (접촉력이 주로 두께 방향) · 판 힘은 0 에서 지수적으로 증가 (판 ≈ −4.9 N · 집전체 ≈ −5.7 N) | §3 (L33–36) · §5 Fig 9 (L94) | digitized | 상별 하중 몫 · 재밍 판정은 카드에 없음 ("CBD 가 부드러워 압밀을 흡수" 는 카드 서술 · L137) · LIB 전극
- [d] lyu2025_3d_dem_drying_calendering_lib | 압연 초기의 재배열: 배위수 3.6 → ≈ 2.3 으로 떨어졌다가 (건조 구조의 안정성이 깨지고 접촉이 분리) 8.3 까지 오름 · 같은 때 기공은 무차원 시간 0–0.25 동안 57 % 로 평탄 (거친 윗면이라 판이 높은 점만 닿음) 뒤 선형으로 급강하 | §3 (L28 · L31) · §5 Fig 7 (L92) | stated / digitized | 시간 축 (압력 축 아님) · 시드 미기재
- [d] ngandjong2021_dem_calendering_digital_twin | 실험 기공 바닥 26.2 %: 86 → 156 MPa (1.8 배) 에서 Δε 0.1 %p (0–156 MPa 총 치밀화의 63 % 가 5.92 MPa 에서 · 99 % 가 86 MPa 에서 끝남). 카드 풀이 = "소성이 끝나서가 아니라 강체 NMC 골격이 잼 (jam) 됐기 때문이라고 읽는 것이 자기일관적" (어느 Heckel 창이든 1/K ≫ 156 MPa) | §3 (L79 · L82) · §3-A-5 (L185) · §3-A-6 판정 2 (L204–206) | digitized · 진행률 · 풀이 = derived(ours) | 단단한 입자의 하중 몫을 잰 수는 카드에 없음 · NMC111 96 wt% (E 200 GPa) + 무른 CBD 4 wt% (E 2 GPa) · 뺀 뒤 값
- [d] ngandjong2021_dem_calendering_digital_twin | 카드 가설: 곡선의 꺾임 (knee) 은 "하중을 지탱하는 가장 무른 상의 강성 × 부피분율" 이 정함 — 이 논문은 무른 상이 4 wt% 뿐이라 knee (< 5.92 MPa · 그 아래 실측점이 없어 상한만) 가 강체 재배열 단계에 있음. 모의 바닥 27.0 % (155.7 MPa) 는 실험보다 +0.8 %p 높음 | §3-B T3 (L243) · §3-A-5 (L182–184) · §3 (L80–81) | 카드 표기 "가설이고 측정된 전이가 아니다" · derived(ours) | 측정 아님 · 모의 시드 1 개
- [d] ngandjong2021_dem_calendering_digital_twin | 구조 통계 (g(r)): 압밀이 커지면 CBD 가 각 AM 을 덮으며 AM–AM 간극을 채우고 AM–CBD 피크 위치는 더 줄지 않음 (접근 한계) · AM–AM 피크는 두 반지름 합보다 약간 큼 (사이에 CBD) | §5 Fig 4B · 4C (L467–468) | 피크 = digitized · Table S3 = stated | 힘 몫이 아니라 배열 (Fig 4B 검산은 카드 문제 절 참조)
- [d] xu2023_realistic_am_shape_cgmd_calendering | AM 을 변형 가능하게 풀어 둔 모델에서도 AM 은 거의 안 변함: 두께를 36–42 % 줄이는 동안 2차입자 Krumbein 구형도의 맞춤 모드가 0.782 → 0.736–0.750 (96 % AM) · 0.804–0.822 → 0.760 (94 % AM) = −0.04 ~ −0.06. 논문 문장: *"the secondary particles have suffered from modest deformations at high pressure due to the mechanical properties of NMC111"* · 배향은 *"quite random"* (음성 결과) | §3 (L102) · §5 Fig 5 · S6 (L515 · L521) · §7 핵심 대비 2 (L657–663) | 모드 = digitized · 인용문 = stated (본문 stated 는 "peak is always around 0.7–0.8" 뿐) | 단단한 입자의 하중 몫 · 재밍 판정은 카드에 없음 · AM 94–96 wt% (무른 상 4–6 wt%) 라 하중을 AM 골격이 지는 침대 — 카드: "정성 지지, 정량 전이 불가" · 폭 변화는 두 조성에서 부호가 반대
- [d] xu2023_realistic_am_shape_cgmd_calendering | 포화 (재밍) 여부는 판정 불가: 모의 곡선이 가파른 채 끝남 — 마지막 구간 dε/dCD ≈ −0.90 %p/% (96 % AM · CD 35.18 → 36.11) · −0.96 (94 % AM · 38.72 → 42.17) → 최저 20.39 % · 24.95 % 는 바닥이 아니라 마지막 점. 무른 상이 많은 94 % AM 쪽에서 모의가 실험보다 +1.5 ~ +3.1 %p 더 성김 (세 점 같은 부호) | §3-A-3 (L157–169) · §3-B-3 (L227–241) | derived(ours) (digitized 값에서) | 압력 축이 없어 "어느 압력에서" 를 말할 수 없음
- [d] miss2026_insitu_conductivity_porosity_pressure_compaction | 섞은 자료 없음 (*"The application of this method to composite cathodes will be the subject of future work."* p.32835) — 단단한 상과 무른 상의 **단독** 양 끝만: 300 MPa 누른 채 기공 SE 0.0755 ↔ pc-NMC622 0.1803 (놓은 뒤 0.0861 ↔ 0.2389) · 400 MPa 0.0426 ↔ 0.1420 (놓은 뒤 0.0626 ↔ 0.1969). NMC 단독 누른 채 50 → 400 MPa = 0.3376 · 0.3035 · 0.2716 · 0.2334 · 0.2052 · 0.1803 · 0.1558 · 0.1420 | §0 (L20–24) · §3-3 (L129–136) | [재계산] · 인용문 = [인쇄] | 하중 몫 · 재밍 자료 없음 · 카드: "복합체 회복이 두 상 사이에 온다는 근거 없음" · NMC 기공 절대값은 ρ₀ 4.48 (성격 미기재) 에 민감 (우리 4.8 이면 +4–6 %p)
- [d] miss2026_insitu_conductivity_porosity_pressure_compaction | 두 상의 변형 양식 (SEM · 저자 해석): 고압 기공이 *"much lower than the porosity of a dense packing of spheres, even if these spheres are polydispersive"* → SE 는 강한 비가역 입자 변형 (50 MPa 조각 사이 공극 → 100 MPa 계면 맞물림 → 400 MPa 치밀) · NMC 는 1차입자 접촉 파괴 · 재배열로 2차입자 형상이 변함 (50 MPa 거의 구형 → 200 MPa 계면 평평 → 200–400 MPa 는 주로 공극 감소) · NMC 50 MPa 단면에 2차입자 중심 공동 + 방사형 균열 | §3-3 (L137) · §3-6 (L159–165) · 논문 Fig 5 · 6 · S5 · p.32833–32834 | [인쇄] · 균열 · 공동 = [판독] (본문 무언급) | 단일상 · FIB-SEM 은 무가압 상태에서 촬영 · 한 시야
- [d] miss2026_pressure_tortuosity_composite_cathode_coating | 하중 몫 · 재밍의 기계 자료는 없음 (기공 · 두께 미보고). 수송으로 본 간접 추론 둘: ① 전자 — CAM 부피분율 0.5 에서 압력이 오르면 CAM – CAM 접촉이 좋아져 전자 tortuosity 가 내림 (다결정 무코팅 ≈ 1000 → 51 · 단결정 무코팅 98 → 9.0 · 코팅 시료는 측정 구간이 좁아 2.4–2.5 배) ② 이온 — 압력 의존이 약해 저자가 *"the compaction of the solid electrolyte in the composite pellets with increasing pressure is similar to the compaction in the pure solid electrolyte pellets"* 로 풀이 | §3-6 (L108–123) · 논문 Fig 8 · p.8–9 | τ = [판독] · 인용문 = [인쇄] | SE 는 Li₃PS₄–LiI 유리 · 도전재 없음 · ② 는 분모 (같은 압력의 순수 SE 펠릿 σ) 가 같이 오르는 정규화의 산물일 수 있음 (카드 §8-2 · §10-9) — 기계적으로 확인된 것 아님
- [d] miss2026_pressure_tortuosity_composite_cathode_coating | 단단한 입자 쪽의 손상 · 배열 (SEM / EDX): 단결정 NMC622 는 응집해 사전 AM – AM 접촉을 가짐 · 다결정 NMC622 는 막자사발 혼합 15 분 동안 갈라지고 SE 로 거의 균일하게 덮임 · 663 MPa 뒤 단면에서 다결정 2차입자 내부에 방사 · 그물 균열 | §3-7 (L127–133) · 논문 Fig 9–12 · p.8–10 | [인쇄] · 단면 균열 = [판독] | 정성 · 입경 수치 [미확인] · 원인 (표면 화학 · 결정성) 은 저자 가설 (측정 없음)


### [batch_14] d. 단단한 입자와 무른 입자를 섞어 누를 때 단단한 입자의 하중 몫 · 재밍

단단한 입자가 지는 하중 분율을 수로 준 카드는 **없다**. 닿는 것 = AM 손상과 그 위치 (so2022) · 혼합의 압밀 추세 (lee2024 · 수치 없음) · 리뷰의 원인 서술 (kang2026).

- [d] so2022_dem_compaction_coated_particles_assb | 하중 몫 수치는 없음. 관련 결과: (i) AM 손상 f^AM = AM–AM 융착 결합의 상대 감소율 (식 9) ≈ 12 % @500 MPa (혼합 ≈ 코팅) (ii) 위치별: 위 · 아래 벽 (집전체 · SE 층 경계) 근처 ≈ 25 % ↔ 가운데 ≈ 5 % @360 MPa (iii) AM–AM 융착 결합 4.2 × 10⁴ → 3.7 × 10⁴ (0 → 500 MPa) (iv) 코팅 쉘이 AM–AM 접촉을 가림: AM 퍼콜 부피 ≈ 0.3 @25 MPa → ≈ 1.0 @100 MPa | §3.2 L63 · L66–67 · L70 · §4.4 L112–113 · Fig 4c · 6 | 12 % · 0.3 → 1.0 = stated · 나머지 digitized | LPS + NCM · 손상 정의가 융착 결합 감소율 (깨진 입자 수 아님) · 시드 1 개로 보임
- [d] lee2024_multiphysics_dem_fem_initial_pressure_assb | (i) SE 혼합에서 LGPS 가 LLZO 보다 훨씬 압축됨 · 고압축성 상 (LGPS 66 wt%) 이 압밀 개선 (Fig 2) (ii) 양극 혼합이 NMC 단독보다 압밀이 잘 됨 — 작은 입자가 큰 공극을 채움 (Fig 3b) (iii) graphite 를 과하게 넣으면 응력이 분산돼 불완전 압밀 (Fig 3e) (iv) 위 punch · 아래 punch 응력을 따로 그림 | §5 L205–206 | 표지 없음 (그림 설명) | LGPS · LLZO · graphite (E 1 GPa) · 하중 몫 · 기공 수치는 카드에 없음 · 재밍 판정 없음
- [d] kang2026_intertwined_electrochemo_mechanical_sulfide_assb_review | 리뷰 서술: 냉간 가압 뒤 공동이 남는 원인 ③ = 변형 거동 불일치 — 단단한 산화물 CAM (E 150–200 GPa) ↔ 무른 황화물 SE (E 20–30 GPa) → "SE 는 소성변형하나 CAM 강성 수용 못 함 → 구조 불균일 잔존" (카드의 한국어 옮김) · 원인 ② = 불균일 가압 → 국소 force concentration + 가압 방향에 수직으로 남는 공동 · NCM 비 ↑ → 응력 국소화 · 인장 / 압축 기울기 (Fig 11a · ref 37) | §5.1 L124–128 · §6.1 L166 | 2 차 인용 | 하중 몫 수치 없음 · Fig 11a 는 80 % 방전 상태의 응력 (가압 아님)
- [d] kakar1967_deformation_theory_hot_pressing | 단분산 한 재료라 혼합 없음. 재배열 실측만: 납 상온 a/R = 0.15 에서 밀도 곡선 급변 = 미끄러짐 (Z 곡선 단절과 같은 자리) · Z ≈ 7.6 → 9–10 · 결론 (a) 하중 즉시 입자 미끄러짐 (b) 재배향 · 재적층이 변형 내내 계속 | §3-A L68 · L71 · §3-B L78 · 논문 p.3228–3230 | stated · Z 는 판독 | 납 · 단분산
- [d] sakuda2013_sulfide_mechanical_property | 이 카드에 없음 (Fig 6a 는 SE 코팅이 부피 변화의 버퍼라는 모식뿐 · L99) | — | — | —
- [d] doux2020_stack_pressure_assb | 이 카드에 없음 | — | — | —
- [d] nisar2024_dem_effective_electrical_conductivity_sps | 이 카드에 없음 (단상) | — | — | —
- [d] deysher2022_transport_mechanical_aspects_assb_review | 이 카드에 없음 | — | — | —


### [batch_15] d. 단단한 입자와 무른 입자를 섞어 누를 때 단단한 입자의 하중 몫 · 재밍

하중 몫을 수로 준 카드는 **없다** (가압 역학을 계산하거나 잰 카드가 없다). 닿는 것만 적는다.

- [d] cronk2026_lis_positive_electrode_geometry_fem | 하중 몫 없음 (압밀 모델 없음). 닿는 결과: 팽창하는 개재물 (S) 둘레의 기지 (LPSCl) 응력이 입자 표면 껍질에 몰림 — *"most of the SSE matrix does not experience stress since only 30 wt% of sulfur is used"* · 히스토그램 이봉 (0 근처 + ≈ 4.1–4.3 GPa) | §5.1 L324–333 | stated (인용문) · 봉 위치는 그림 읽기 | 가압이 아니라 리튬화 팽창 · 선형탄성 · Li–S
- [d] beutl2024_round_robin_coin_cell_sulfide_assb | 수치 없음. 논문 서술 (카드의 한국어 옮김): "복합 양극 치밀화에는 보통 300–800 MPa 를 쓰고 그 응력이 활물질을 깬다 · 단결정이 더 견딘다 · 가압 순서가 계면 품질에 중요" | §4-1 L197 · 논문 p.5–6 | 카드 옮김 (서술) | 정성 · 하중 몫 아님
- [d] bielefeld2019_microstructural_modeling_composite_cathode | 역학 없음. 재밍과 닿는 기하 한계만: 겹침 없는 단일 크기 구 AM 은 ≈ 65 vol% 에서 겹침 ≈ 1 vol% 가 남음 (등구 조밀 충전 ≈ 74 vol% 근접) | §3 L57–58 · §5.2 L99 · 논문 p.1628 | stated | 기하 배치 (힘 없음)
- 나머지 (asano2017 · bielefeld2020 · chen2011 · cooper2017): 이 카드들에 없음.


### [batch_16] d. 단단한 입자와 무른 입자를 섞어 누를 때 단단한 입자의 하중 몫 · 재밍

하중 몫을 수로 준 카드는 **없다**. 닿는 것은 (1) 단단한 구 + 무른 기지를 한 압력으로 눌렀을 때 남는 기공 (froboese2019 — 실측), (2) 형상이 안 변하는 DEM 의 기공 바닥 (galvezaranda2024), (3) 힘 없는 배치 알고리즘의 막힘 (duquesnoy2020).

- [d] froboese2019_microstructure_ionic_conductivity_assb_electrode | 단단한 유리구 + 무른 고분자 SE 를 732 MPa 로 누른 뒤 남는 기공 (하중 몫 아님 · 결과만): 순수 SE 4.36 % → 유리구 60 vol% 에서 14.15 % (70–110 µm) · ≈ 16.3 % (40–70 µm) · 19.72 % (0–50 µm) · 굵은 두 입경은 30 vol% 까지 거의 일정한 뒤 지수적 증가 · 47.5 vol% 에서 ε ≈ 14.2 · 12.6 · 9.1 · 5.7 % (x50 2.96 · 35.65 · 60.68 · 92.5 µm) | §3-2 L90–110 · L115 · §3-3 L127 · 논문 A322–A323 · Fig 8 | stated (4.36 · 5.42 · 19.72) · 판독 ≈ (나머지 · TREND 전용) | 고분자 SE · 유리구 수십 µm · 단일 압력 · 하중을 누가 지는지는 재지 않음 · 60 % 굵은 두 입경의 본문 표기가 그림과 뒤바뀜 (카드 §3-6 c — 여기 값은 그림 배정)
- [d] froboese2019_microstructure_ionic_conductivity_assb_electrode | 한계 조성: 0–20 µm 유리구는 50 vol% 초과에서 기계적으로 불안정 (60 % 전극을 못 만듦) · 40–70 µm 는 > 60 vol% 불안정 · 측정 밀도는 50 vol% 까지 늘다가 줄어듦 · 원문 설명 = "기공 크기는 입경의 1/2–1/4" (ref 41) 이라 작은 틈을 SE 가 못 채움 | §3-1 L72 · §3-2 L113 · §3-3 L128 · §6-bis L288 | stated | 정성 · 하중 몫 아님
- [d] galvezaranda2024_time_dependent_dl_calendering_microstructure | DEM (AM 96 wt% · 형상 불변) 압연의 기공 바닥: CD 40 % 에서 ≈ 19–20 % 에 닿고 그 위에서는 ± 2 % 로 진동 (단조성 깨짐 · 미세구조 IV: 20.02 → 19.04 → 19.87 %) — 저자 해석 "전극이 기계적 압축 한계에 도달" (카드의 한국어 옮김) · 실험의 ≈ 20 % 하한 (2 차 NMC 입자 파쇄 · refs [15, 48, 49]) 과 정성 일치라고 적음 | §3-C L125–131 · L137–141 · §5-3 L294–295 | stated (표 값) · 저자 해석은 카드 옮김 | LIB · CD 축 (압력 없음) · 하중 몫 수치 없음 · 카드: "다른 기전이 우연히 같은 숫자. 그들의 20 % 는 AM 파쇄 한계, 우리 20 % 는 형상 소성 부재" (L421)
- [d] duquesnoy2020_calendering_ml_mesostructure_generator | 힘 없는 기하 한계: 강체 구 무작위 순차 배치가 낮은 기공률 · 높은 AM 분율에서 막힘 — SI: *"at low porosities and high AM content, stochastic algorithms can be stuck"* → 대책이 겹침 허용 (중심 거리 ≥ 0.7·(r_i + r_j)) | §4.1 L149–153 | stated (SI 인용문) · 코드 판독 (카드) | 역학 없음 (재밍이 아니라 배치 알고리즘의 막힘) · LIB
- [d] hamann2026 · hlushkou2018 · holzer2013 · islam2026 | 이 카드들에 없음 | — | — | —


### [batch_17] d. 단단한 입자와 무른 입자를 섞어 누를 때 단단한 입자의 하중 몫 · 재밍

하중 몫을 수로 준 카드는 **없다**. 닿는 것은 (1) 같은 조건으로 눌렀을 때 조성에 따라 남는 기공 (ketter2025 — 실측), (2) AM 등급에 따른 균열 (jung2023 · kim2026_pregranulation — 정성), (3) LIB 전극에서의 정성 해석 (landesfeind2016 · kato2018).

- [d] ketter2025_resistor_network_models_predict_transport_properties | 단단한 NCM83 + 무른 LPSCl 을 같은 조건 (370 MPa 선압 → 등방 500 MPa 60 min) 으로 누른 뒤 남는 기공 (하중 몫 아님 · 결과만): φ_NCM 0 / 20 / 40 / 60 / 80 / 100 vol% → 12.13 / 15.62 / 21.16 / 22.42 / 25.33 / 29.24 % | §3-3 L102–107 · SD `FigS18a` | SD (측정) | 한 압력 · 뺀 뒤 · LPSCl ≈ 20 µm ≫ NCM ≈ 2 µm (우리와 크기 계층 반대 — 카드 L291) · ρ_theo 1.86 / 4.78 기준 · 누가 하중을 지는지는 재지 않음
- [d] ketter2025_resistor_network_models_predict_transport_properties | 저자 문장: 조성과 밀도 사이에 선형 관계가 있다 — "a linear relationship between composition and density exists" | §4-1 L162 · SI §S7 | stated (인용문) | 밀도에 대한 문장 · 하중 몫 아님
- [d] ketter2025_resistor_network_models_predict_transport_properties | VGCF 를 넣은 복합 (φ_NCM 40 %) 의 기하 밀도: 2.387 (0 wt%) → 2.567 → 2.529 → 2.514 → 2.409 → 1.991 g/cm³ (5 wt% 에서 급락) | §3-4 L120–125 · SD `FigS18b` | SD · 단일 측정 | 섬유 첨가제가 많으면 덜 눌린다는 방향의 자료 한 줄 · 기공률 환산은 카드에 없음
- [d] jung2023_single_crystal_ncm_morphology | 크기가 같은 (D50 4.9 / 5.0 µm) AM 두 등급: 다결정 PC (1차 입자 ~600 nm 응집 · 입계 + 내부 공극) 는 제조 · 사이클 중 입계 따라 균열 · 단결정 SC 는 억제 — 입자 경도 ~113.3 ↔ 972.7 MPa · ASSB 제조 압력 437 MPa | §1 L27–32 · §3 L60 · L74 · §7-B L145–147 | stated · stated(정성) | 하중 몫 · 균열 분율 수치 없음 · 균열 사진은 100–150 사이클 뒤 (제조 직후 균열의 정량 없음)
- [d] kim2026_pregranulation_ptfe_dry_nca_cathode_crack_delithiation | 캘린더링 직후 균열은 큰 (≈ 10 µm) NCA 2차 입자에서 보이고 작은 각진 입자 (1–3 µm) 에는 안 보임 (정성). 저자 주장 = 섬유로 묶인 과립이 점진 변형 · 조절된 파괴로 응력을 흡수 · 재분배 ("not from the fibril network confining individual secondary particles like a physical corset" p.7) — 힘 · 응력 측정 0 인 가설이고 과립화 전극의 기공률이 더 높음 (0.333 ↔ 0.305) | §3-3 L100–101 · §3-2 L93 · §7-2 L310–312 | [인쇄] (균열 유무 · 인용문) · [판독] (크기 의존) · 카드 서술 (가설 판정) | LIB 건식 전극 · 압력 값 [미확인] · 균열 분율 없음 · 카드의 "접촉력 ∝ R² · 임계력 ∝ R" 은 [추정]
- [d] landesfeind2016_tortuosity_eis_electrodes_separators | 저자의 기전 해석 (정성): 도전재는 단단해 비압축 지지체로 LFP 응집체 사이를 벌림 · 높은 압축에서 LFP 응집체가 깨져 판상화 (도전재가 적을수록 넓은 판) · 흑연은 무른 입자 자체가 눌려 기공이 줄어듦 | §5-6 L283–284 · A1384–A1385 · Fig 18 | stated (원문 해석 — 카드의 한국어 옮김) | LIB 전극 · 하중 몫 수치 없음
- [d] kato2018_thick_electrode_assb_cycle_tortuosity | 원문: 황화물 SE 는 냉간 압분으로 쉽게 변형되어 SE 부피분율이 높을 때 전극 형태가 비슷해진다 (두 SE 의 τ 가 같다는 가정의 근거 ③) · SEM 은 SE 영역의 void · crack 을 보임 (정성) | §4-2 L220 · SI p.8 · §0 L44 · p.610 | stated | 가정의 근거로 쓴 문장 — 측정 아님
- [d] kim2024 · kim2026_a3d | 이 카드들에 없음 | — | — | —


### [batch_18] d. 단단한 입자와 무른 입자를 섞어 누를 때 단단한 입자의 하중 몫 · 재밍

하중 몫을 수로 준 카드 = **0**. 닿는 것은 (1) 눌렀을 때 단단한 AM 이 깨지는지와 무른 SE 껍질이 그것을 막는지 (nakamura2020 — 실측 구조), (2) 층 두께에 따른 응력 전달 (nakamura2020 — 저자 추정), (3) 섬유 바인더 함량에 따른 치밀화 (lee2026), (4) 압연에 따른 판상 입자 정렬 (malifarge2017) 이다.

- [d] nakamura2020_dry_coating_ncm_li3ps4_core_shell | 막자 혼합 복합 (NCM111 + Li₃PS₄ 13.1 wt%) 을 360 MPa 로 누르면 NCM 2차 입자가 1차 입자 사이로 깨짐 (Fig 7a) → NCM 총 표면 1.51 µm²/µm³-전극 ↔ 코팅 (SE 껍질 0.1–0.2 µm) 은 1.26 (균열 없이 거의 구형). 원문: "the compressive stress acting on the NCM particles was damped by the soft and ductile LPS shell layer" | §3-6 L141–146 · §7-1 L249 · p.7–8 · Table 1b · Fig 7 | [인쇄] (면적 · 인용문) | 하중 몫 수치 없음 · FIB-SEM 은 50 회 사이클 뒤 시료 (L320) · 20 µm 정육면체 1 개 · NCM111 단봉 4.7 µm · Li₃PS₄ 유리 · 카드의 "+20 %" 는 1.51 ÷ 1.26
- [d] nakamura2020_dry_coating_ncm_li3ps4_core_shell | 압축 뒤에도 남는 계면 미세공극 (IMV): NCM 표면 중 "NCM 사이 공극" 과 닿은 몫 = 혼합 36.7 % ↔ 코팅 16.4 % (NCM–LPS 접촉 몫 54.1 ↔ 67.8 %) | §3-6 L142–147 · p.8 · Table 1b | [인쇄] | 세 몫 합 = 100 % — NCM–NCM 맞닿은 면은 분모 밖 ([우리 산술] L31)
- [d] nakamura2020_dry_coating_ncm_li3ps4_core_shell | 껍질이 있어도 누르면 AM–AM 접촉이 생김: "the continuous shell layer of LPS was partially pushed away when the cathode powder bed was compressed" → 이미지 기준 전자 σ_eff/σ_B 0.233 (혼합) → 0.208 (코팅) = −11 % | §3-6 L155 · L160 · p.8 · Table 1c | [인쇄] | 도전재 없는 전극 · 한 압력
- [d] nakamura2020_dry_coating_ncm_li3ps4_core_shell | 층 두께와 응력 전달 (저자 추정): DC 분극 셀의 양극이 반쪽셀보다 ≈ 8 배 두꺼워 (카드 산술 ≈ 300 ↔ ≈ 38 µm) 압축 응력이 덜 전달되고 NCM–NCM 접촉이 줄었을 것 → DC σ_e 가 코팅에서 −94 % (5.9 × 10⁻⁶ → 3.6 × 10⁻⁷ S/cm) 인데 이미지는 −11 % | §0 L33 · §3-4 L98 · §3-7 L167–169 · p.8–9 · Table 2 | [인쇄] (값) · 원문 "speculated" · [우리 산술] (두께) | 시험하지 않은 설명 (§10-11 L324) · 두 측정의 시료 상태도 다름
- [d] lee2026_unveiling_ptfe_dry_electrode_digital_twin | 같은 370 MPa 에서 PTFE 함량에 따른 치밀화: 상대밀도 84.6 (PTFE 0) → 87.4 (0.2) → 86.8 (0.5) → 82.5 % (1.0 wt%). 저자: "excessive PTFE increased electrode porosity and impeded mass transport" | §3-7 L163–168 · Table S2 · p.9 | [인쇄] | 하중 몫 아님 — 결과 밀도만 · LPSCl 1.86 g/cm³ 기준 (랩 표준과 다른 문헌 값)
- [d] lee2026_unveiling_ptfe_dry_electrode_digital_twin | 누른 뒤가 아니라 사이클 뒤의 AM 균열: 200 회 뒤 PTFE 0 전극은 NCM 균열 · 0.2 wt% 는 "no noticeable cracks" · OEP 에서 0.2 wt% 가 압력 감소가 작음 (저자 해석 = 고른 분포가 응력을 고르게 나눔) | §3-9 L192–194 · p.9–11 · Fig S19 · S20 | [인쇄] (정성) · [판독] (ΔP) | 압밀 직후의 균열 정량 없음
- [d] malifarge2017_tortuosity_symmetric_cell_impedance_tlm | (하중 몫 아님 — 누르면 입자가 돌아눕는다는 근거) 판상 흑연 가운데 집전체와 평행에 가까운 입자가 압연압에 따라 같은 배치에서 30–60 % ([21] 의 XRD 정량). "The tortuosity values increase as the amount of graphite particles parallel to the current collector increases" | §0 L43 · §8-1 L343 · E3332 | stated | 방향 분율과 τ₂ 를 전극별로 짝지은 자료는 이 논문에 없음 (문장뿐) · 액체 LIB
- [d] matthews2024_ptfe_nanofibril_network | (하중 몫 아님 — 혼합 전단) 10–20 µm NMC 가 100–200 µm PTFE 원료 입자에 눌려 표면 거칠기가 PTFE 결정자와 맞물리고, 이어지는 전단에서 실이 뽑힘. 압축 중 피브릴이 끊어지는지는 문헌이 갈림 (Hippauf 2019: NMC–Li₆PS₅Cl 복합양극 압축 중 끊어질 것 ↔ Lee 2023: 과도한 캘린더링 뒤에도 조밀한 망) | §4.3 L205–215 · §5.4 L311–315 · §12-6 L662–663 | stated (정성 · 문헌 대비) | LIB · 관찰 기반 — 측정 아님
- [d] landesfeind2018 · morasch2018 · nguyen2020 | 이 카드들에 없음 | — | — | —


### [batch_19] d. 단단한 + 무른 입자 혼합 압축의 하중 몫 · 재밍

이 배치에 없음. (sangros2020 은 단단한 LFP (E 123.9 GPa) 와 무른 CB (E 5 GPa) 를 함께 누르지만 하중 몫 · 재밍 값은 카드에 없다 — §3 L41.)


### [batch_20] d. 단단한 + 무른 입자 혼합 압축의 하중 몫 · 재밍

하중 몫 · 재밍을 직접 잰 카드 없음. 관련만.
- [d] wang2027_ncm811_effective_bulk_modulus_mapper_dfs_gnn | 선형 탄성 FE 에서 무른 상 (CBD 1.8 GPa · 봉우리 ≈9 vol%) 을 넣으면 K +10.6 % (13.531 → 14.965 GPa · 같은 20 개) — 무른 상의 강성 몫이 작다 | 표 1 p.6 · L93 · L210 | [인쇄] · [우리 산술] | 압축 과정 아님 · 작은 변형 −1.25 % · 액체 LIB CB/PVDF (SE 아님)
- [d] wang2027_ncm811_effective_bulk_modulus_mapper_dfs_gnn | AM 망 (≈70 vol% · 결합 목) K ≈15–16 GPa 로 우리 DFT LPSCl B₀ 26.23 GPa 보다 낮다 → 카드 해석: "얼린 AM" 근사가 정당한 것은 위치 고정 때문이지 골격이 단단해서가 아니다 | §8-5 L363–364 | [추정] | 액체 LIB · 완전 결합 복셀 · 둘째 상 강성 0 (카드가 "값 이전 금지" 명시) · ⚠ 카드 문제 3 (프로젝트 기록과 어긋남)
- [d] wang2027_ncm811_effective_bulk_modulus_mapper_dfs_gnn | 국소 응력 집중: σ₁₁ 범례 최솟값 −1.804 × 10¹⁰ Pa ≈ 부피 평균 (≈−0.57 GPa) 의 ≈30 배 → "목이 하중을 진다" | §3-3 L92 · 그림 6b · L260 | [인쇄] + [우리 산술] | 범례 극값은 한 절점일 수 있다 (카드) · 선형 탄성
- [d] yoo2026_porosity_gradient_dry_electrode | 단단한 흑연 필름 아래 무른 primer layer 가 라미네이션 · 캘린더 때 소성변형 → 집전체 쪽이 더 치밀 → 두께 방향 기공 구배 (가장 무른 PVDF-PL 이 가장 가파름) | §3 L111–116 (p.9) | 표지 없음 (저자 해석) | 응력 · 하중 몫 측정 없음 · 입자 혼합이 아니라 층 구조 · 흑연 LIB


### [batch_21] d. 단단한 + 무른 입자 혼합 압축의 하중 몫 · 재밍

이 배치에 없음 (하중 몫 · 재밍을 잰 카드 없음). 관련만:
- [d] asylbekov2023_cb_fragmentation_pbe_dem_dry_mixing | 가정 — 크고 단단한 AM 이 날 · 내벽에서 눌리며 그 사이에 낀 CB 응집체의 분쇄 매체가 된다: "The much larger and tougher active material particles are compressed at the blades and the inner wall of the mixer and serve as a grinding media for the CB agglomerates which are caught in between." | §4.7 L374–377 | 원문 따옴표 (카드 옮김) | 혼합 · 저응력 · CB 가 DEM 에 없어 하중 몫 계산 아님
- [d] frankenberg2024_dem_high_intensity_mixer_assb | coarse-grain 입자를 너무 크게 (> 0.5 mm) 하면 gap (1.532–1.895 mm) 에 jam → 비현실적 고응력 · 0.5 mm = gap 의 ~1/3 절충 | §4.4 L103 · §10 L279 | stated (저자) | 입자–틈 기하 재밍 = 수치 인공물 · 단단 / 무른 혼합의 하중 몫 아님
- [d] cho2024_conflicting_roles_conductive_additive | AM 88 wt% 전극이 72 wt% 보다 기공이 큼 (0.18–0.19 ↔ 0.14–0.15) · 카드 해석 "SE 적어 충전율↓" | §3 L121–122 · Table S2 | stated (해석 = 카드 풀이) | 하중 몫 측정 아님 · 433 MPa 한 점


### [batch_22] d. 단단한 입자와 무른 입자를 섞어 누를 때 단단한 입자의 하중 몫 · 재밍

이 배치에 없음 (단단한 + 무른 입자 혼합 압축의 하중 몫 · 재밍을 다룬 카드 없음).


### [batch_23] d. 단단한 입자와 무른 입자를 섞어 누를 때 단단한 입자의 하중 몫 · 재밍

하중 몫 · 재밍의 수치는 이 배치에 없음. 관련만 (정성 — 무른 상이 단단한 입자의 파쇄를 줄인다):
- [d] kawaguchi2023_doe_electrode_fabrication_dry_coated_ncm_lps | 단순 혼합 Xs 0.1 에서 NCM 안 균열 · Xs 0.3 에서 억제 — 저자 해석 "높은 Xs 가 NCM 에 걸리는 압축 응력을 완화" · 코어–셸도 압축 응력 완화 (180 / 360 MPa 압축) | §3-7 L147–148 · p.12–13 | [인쇄] (저자 해석 · SEM 정성) | 하중 몫 계산 없음 · 셀 1 개
- [d] kawaguchi2023_doe_electrode_fabrication_dry_coated_ncm_lps | 단순 혼합은 Xs 0.3 에서도 NCM–NCM 접촉이 남음 (Fig 5d) · 코팅은 Xs 가 오르면 NCM–NCM 접촉이 줄어 NCM 이 LPS 기지 안 섬이 됨 (Fig 6c,d) | §3-7 L145 · §5 L181–182 | [인쇄] · SEM 정성 | 접촉 수 정량 없음
- [d] kawaguchi2017_dry_coating_parametric_na2so4_model_se | 충격 코팅 중 게스트 20–30 wt% 는 300 s 까지 NCM 파쇄 없음 (완충) · 10 wt% 이하 (100 m/s) · 1800 s 는 파쇄 — 원인 후보 = 막이 얇아져 충격 전달 · 피로 (둘 다 "may be") | §3-4 L96 · §3-5 L103 · §0 ④ L29 | [인쇄] · '이하' 읽기는 [추정] | 압축이 아니라 충격 공정 · 모델 물질
- [d] kang2026_multiscale_inverse_design_ptfe_fibrillation_dry_electrode | 미시 FEM 의 AM 원 = PTFE 에 압력을 거는 단단한 몸 (재질 무감 — SiO₂ ↔ LFP 곡선 겹침, SI Fig 6) · 하중 몫 계산 없음 | §4-3 L216 · §10-26 L367 | [판독] · [추정] | 2–4 원 정적 모형 (충전 · 힘 사슬 없음)


### [batch_24] d. 단단한 입자와 무른 입자를 섞어 누를 때 단단한 입자의 하중 몫 · 재밍

하중 몫 · 재밍을 잰 카드 없음. 단단한 입자 (AM) 의 압축 중 파괴만:
- [d] lee2025_corolling_dryprocess_lpscl_ptfe | 가압 뒤 큰 다결정 PC-NCM (5–15 µm) 균열 · debris / 작은 단결정 SC-NCM (3–5 µm) 무손상 · 300 vs 500 MPa: PC 는 500 에서 균열 ↑ · SC 는 균열 없음 · 접촉 ↑ · 저자 서술: PC 는 거친 표면 + 큰 CAM / 작은 SE 사이 큰 void → 가압 시 심한 균열, SC 는 압밀 전부터 조밀 · 친밀 접촉 | §3 L46 · §4 L63–64 · §5 L73 · L87–89 · Fig 2b,c · SI Fig 6–8 | stated (SEM) | 정성 (균열 분율 수치 없음) · 하중 몫 값 없음
- [d] koo2025_cnt_wrapped_sc_nca_dry_cathode | 전극 압밀 뒤 단면 미세균열 면적 분율 PC-NCA 7.8 % @3.6 g/cc vs SC-NCA 0 % @4.0 g/cc · 카드: "단결정은 견고 → 고밀도 압축 (4.0 g/cc) 가능, 다결정은 입계균열로 못 감" | §5(a) L247–250 · SI Fig S23d,e | 카드가 '본문 명시값' 으로 분류 | NCA · 액체 LIB · 캘린더 압력값 없음 (밀도로만) · 하중 몫 없음
- [d] lee2024_shear_force_dry_process_cathode_coverage | 단면에서 NMC 균열 (펠릿 · 건식 큰 입자 일부) · 펠릿 단면 수평 균열 | §4-2 L232 · §3-2 L97 · S2 · S8 | [판독] (정성) | 수치 없음
- [d] lee2025_corolling_dryprocess_lpscl_ptfe | co-rolled 막 인장강도 ≈ 두 막의 합 (0.510 ≈ 0.049 + 0.441 N/cm) → 카드: "둘 다 하중분담" | §3 L43 · §5 L77 · Fig 3b | stated (값) · 카드 풀이 (해석) | 막 수준 인장 (입자 하중 몫 아님)


### [batch_25] d. 단단한 입자와 무른 입자를 섞어 누를 때 단단한 입자의 하중 몫 · 재밍

하중 몫 · 재밍의 수치는 이 배치에 없음. 관련만 (정성):
- [d] mun2025_dry_electrode_technology_assb_review | 후막 건식 양극 + LiPO₂F₂ / NaCl: "Effective densification by bimodal structure → suppression of particle crack → interfacial reinforcement by decomposition of additive" ↔ "Not effective densification by void (particle crack)" | §5 L130 · Fig 5e · §B ③ L182 | 리뷰 인용 (정성) | 하중 몫 계산 없음 · 첨가제 분해 효과와 묶임
- [d] mun2025_dry_electrode_technology_assb_review | 모식: 습식 = 바인더 코팅 · 응집 · 점접촉 · 낮은 이용률 ↔ 건식 = "deformed SE · high coverage · high utilization" | §5 L108 · Fig 3a · §4 L91 | 리뷰 모식 (정성) | 수치 없음
- [d] lippke2023_dem_drying_structure_formation_lib | 저자 정성 관측: CB 응집체가 AM 입자 사이에 자리잡아 AM–AM 직접 접촉을 대부분 막는다 (마찰을 쌍별로 나누지 않은 근거) | §3-B L118 · §A-2 L519 | stated (본문 §9 한 줄) | 습식 건조 · 하중 몫 아님 · 숫자 없음


### [batch_26] d. 단단한 + 무른 입자를 섞어 누를 때 단단한 입자의 하중 몫 · 재밍

- [d] qin2026_bilayer_cathode_cgmd_dem_graded_thick_electrode | c40 (제하 뒤) 층 영역 AM 부피분율이 조성과 무관하게 0.556–0.565 (인쇄 공극률 역산) · Fig 5 판독 0.564–0.580 → 카드 가설: AM 골격이 하중을 지고 직렬 층은 같은 응력 → 같은 φ_AM, 무른 상 (CBD) 이 많은 층이 더 치밀; 층별 두께감소 94:6 ≈41–43 % vs 96:4 ≈23 % (적층 위치와 무관) | §3.3 줄 185–194 · §9 I-1 줄 455 · I-2 줄 457 · D1 줄 551–563 · D2 줄 565–566 | derived(ours) · figure-read ≈ · 가설 | 응력 · 반력 미보고라 같은 응력 검증 불가 (L-1) · AM 하중 몫 직접 측정 없음 · 무른 상 = CBD (SE 아님) · 액체계


### [batch_27] d. 단단한 입자 + 무른 입자 압축의 하중 몫 · 재밍

이 배치에 없음 — 외부 가압에서 단단한 입자의 하중 몫 · 재밍을 잰 카드가 없다.  인접 근거:
- [d] bucci2017_chemomech_failure_assb_cycling_czm | 외부 가압이 아니라 AM 팽창을 구속할 때의 응력 나눔: AM 입자 압력 > 1 GPa (50 % 용량 입자) · SE 압축 0–200 MPa (대부분) · 인장은 정사각 입자 모서리 근처만 | §3.4 줄 139–140 · Fig 2c | stated | 2D · 선형 탄성 · E_AM/E_SE 100/15 · Li 삽입 하중
- [d] wet_processing_resolved_am_ssb_cathode_manufacturing | AM–AM · AM–SE · SE–SE 쌍 E 가 모두 135 GPa 로 같아 단단함/무름 대비가 없음 · 무른 상은 CBD (쌍 E 1–20 kPa · ~10 vol%) · 하중 몫 미보고 | §①-B 줄 354–362 · §③-B 줄 474 | stated (SI) · 카드 환산 | 습식 · 강체 AM
- [d] sun2026_dem_extrusion_recirculation_dry_electrode | AM/BC 강성 대비 1,105–1,712×; 2500 rpm 에서 노즐 막힘 (기공 0.20 대 평탄 · 동시 투입은 49 M Δt 에 해소되며 0.395 로 반등) — 유로 막힘이지 압축 재밍 아님 | §3 다 줄 96 · §3 사 줄 141 | DERIVED(ours) · digitized | 압출 · 폴리머 · SE 없음


### [batch_28] d. 단단한 + 무른 입자를 섞어 누를 때 단단한 입자의 하중 몫 · 재밍

- [d] dem_mechanical_stresses_ssb_electrode_cycling | 일축 375 MPa: 평균 AM 응력 ≈ 2 × SE (*"stress on SE reduced by factor of two w.r.t. AM, due to deformability + lower mechanical stiffness of SE"*) · AM z 응력 ~500–700 MPa 로 경계압 375 MPa 를 넘음 (카드: bulk 가 위 · 아래 판 압력을 같이 받음) · 바닥 · 윗면 층 응력 낮음 · 작은 AM 일수록 응력 큼 (2 µm ~390 → 6 µm ~250 MPa, x/y) | §3.2 줄 76–80 · §5.3 줄 198 (Fig 4) | stated (2×) · digitized | NMC532 26.7 wt% · SE 가 AM 보다 큼 · 강체 Hertz (카드: 소성 캡이 없어 응력 과대 가능 · 줄 322)
- [d] dem_mechanical_stresses_ssb_electrode_cycling | 등방 5 MPa · 사이클: 방전 (AM 팽창) 때 AM–SE 응력 차 벌어짐 → 충전 (AM 수축) 때 응력이 SE 로 이전 · 더 고르게 | §3.4 줄 98–104 (Fig 5a) | stated | 응력 수치 = 6–16 MPa 범위만
- [d] interfacial_impedance_formulation_assb_cathode | 일축 (UP-C · SUS 판) 은 단단한 CAM 에 응력이 몰려 SE 변형이 등방 (IP-P) 보다 적음 (대신 CAM 전자 접촉 ↑ · r_e UP-C/IP-C < IP-P) · SE 분율 ↓ → 공극 ↑ (단단한 NCM 이 SE 치밀화 방해) | §4.5 줄 187 · §5.3 줄 217 · §5.2 줄 205 | 카드 해석 · stated | Cl-rich LPSC · 하중 몫 수치 없음
- [d] gandla2026_layered_cathode_degradation_diagnostics_review | [104]: NCM 비율 ↑ → NCM–NCM 배위수 ↑ → 부피 변화 때 이웃이 입자를 붙잡아 전달 하중 ↑ · 단층촬영 형상 메조 모델 고응력 영역 비선형 증가 | §3-5 줄 121 (p.14 · 그림 5g–h) | [인쇄] · [판독] | 사이클 부피 변화 하중 (가압 아님) · 2 차 인용 · 원 논문 카드 없음
- (가까운 것) [d] kang2025_toughened_bimodal_nca_lzo · kim2023_chemomech_failure_highstrain_anode | 제조압 400 MPa (kang2025 Fig S9) · 433 MPa (kim2023 Fig S15) 직후 단면 SEM 에 NCA 균열 없음 · 사이클 균열에서 stack pressure (수백 MPa) ≪ 확산 유발 응력 (GPa) | kang2025 §5 줄 221 · §4 줄 182–183 · kim2023 §5 줄 233 · §3 줄 92 | stated | NCA (≠ NMC811) · 하중 몫 수치 없음


### [batch_29] d. 단단한 입자와 무른 입자를 섞어 누를 때 단단한 입자의 하중 몫 · 재밍

- [d] sedlatschek2026_nmc811_grain_boundary_strength_micro_tensile | 우리 AM 하중분담 모델 (`am_load_balance_jam.py`) 의 H_AM 기본 4.0 GPa ("NCM811 압입 경도 문헌대 ≈ 3~6") · 역산 3.83–3.85 ↔ 논문이 인용한 NMC 경도 7.8 / 8.9 / 8.6 / 14.2 GPa **네 값 모두 3–6 밖** (인용 최저 7.8 = 상한 6 의 1.30 배 · 역산 3.85 의 2.03 배) · 카드 풀이: H_AM 은 물리적으로 "AM 크라운이 버티는 접촉 평균압" 이고 다결정 2 차입자는 압입 경도보다 낮은 압력에서 입계로 부서질 수 있음 (Fig 4) · 그 모델 자신의 등록 규칙 *"역산값이 그 밴드 밖이면 모델이 틀린 것"* 이 걸림 | §7.1 L266 · §7.5 L306–322 · §8 ② L369–374 · D19 L493 | 카드 판정 · derived(ours) | 인용 경도 원문 미확인 · 두께 예측 수치에는 영향 작음 (VACUOUS 기록 L317) · 흔들리는 것은 "문헌대 안" 교차검증 문장
- [d] sedlatschek2026_nmc811_grain_boundary_strength_micro_tensile | AM–SE 접촉 E* 는 E_SE,eff (1.35 GPa) 가 지배 — AM 영률을 (138, 0.32) 로 바꿔도 AM–SE E* 차 −0.03 % · AM–AM 만 −2.9 % (힘사슬 강성 · Auerbach P_c) | §7.1 L262–263 · §7.2 L278 · D12 L486 | derived(ours) | 우리 DEM 입력 기준 산술
- [d] so2021_dem_fabrication_degradation_ductile_particles | Si (E 70 GPa) + LPS (E 24 · H 1.9 GPa) 복합 음극 제조: "LPS 무름 → SE만 소성" · 단단한 입자의 하중 몫 값은 카드에 없음 | Table I L56–57 · §5.5 L197 | stated | 2D · Si 음극
- 나머지: 없음 (li2026 의 Park 2025 · Farzanian 은 사이클 응력 L65–66 이지 압축 하중 몫 아님).


### [batch_30] d — 단단한 + 무른 입자 혼합 압축의 하중 몫 · 재밍

- [d] 이 배치에 논문 근거 없음 (하중 몫 · 재밍을 잰 · 계산한 카드 없음).
- [d] wheatcroft2023_nmc811_secondary_particle_fracture_insitu_sem | 우리 코퍼스 산술 (논문 값 아님): AM_P–AM_P 자료가 있는 120 케이스의 케이스별 중앙 접촉 F/D² = 최소 25.7 · 25 % 75.4 · 중앙 109.1 · 75 % 134.2 · 최대 265.3 MPa · F/P_c 중앙 10.6 | §7.4 (줄 362–367) · D16 (줄 527) | derived(ours) | 하중 몫 아님 · 중앙 접촉 하나 ≠ 입자 분할 하중 · 압밀 종료 시점 · R_min 5 · 6 µm 두 값


### [batch_31] d — 단단한 + 무른 입자 혼합 압축의 하중 몫 · 재밍

- [d] 이 배치에 없음.


### [batch_32] d — 단단한 + 무른 입자 혼합 압축의 하중 몫 · 재밍

- [d] hong2026_cbd_viscoelasticity_springback | 저자 가설 · 결론 (정성): 단결정 CAM 은 입계가 없어 균열로 압축 에너지를 소산하지 못함 → calendering 압축응력의 상당 부분을 무른 CBD 가 수용 · 다결정은 입계 균열로 소산 (보관 중 두께 변화 없음); HT CBD 가 더 compliant → 같은 3.5 g/cm³ 를 roll gap 70 µm (RT 는 60 µm) 에서 도달 · 3.7 g/cm³ 에서 입자 균열 뚜렷 (Fig S1) | §1 (줄 79–82) · §3 (줄 139–154) · §4.1 (줄 170–171) · §4.3 (줄 224–227) · Fig 4e | 표지 없음 (저자 가설) | 하중 몫 수치 없음 · 무른 상 = CBD · 액체 LIB
- [d] 나머지 — 하중 몫 · 재밍 값 없음 (huang2025 는 압력 · 하중 분담을 내지 않음 · 카드 §3 줄 38 · §10 줄 137).


### [batch_33] d — 단단한 입자 하중 몫 · 재밍

이 배치에 없음.


### [batch_34] d — 단단한 · 무른 입자 혼합의 하중 몫 · 재밍

- 이 배치에 없음. (minnmann2022 는 "hard CAM + soft SE 또는 그 반대" 설계 원칙만 · 하중 몫 수치 없음 — §1 L116 · §6 L235.)


### [batch_35] d — 단단한 입자의 하중 몫 · 재밍

이 배치에 하중 몫 값 없음.  참고:

- [d] otani2023 | SE 21 vol% 복합의 저공극 영역에서 실측 < 모형 → 저자 해석 "AM 이 가압 충돌로 변형돼 거시 β > 1.5" (재맞춤 없음) · 카드 비판: 모형은 AM 이 하중을 지는 차폐를 반영하지 않음 | §3-4 표 (줄 94) · §4-2 (줄 119) · §10-5 (줄 248) · p.4 | [인쇄] (저자 해석) · 카드 비판 | 하중 몫 정량 없음
- [d] song2025 | 압밀 아님 — 충전 말기 집전체 근처 활물질 최대 von Mises 314 MPa 가 CBM 으로 전달돼 CBM 소성 (Fig 5) | §4.4 (줄 320–323) | 표지 없음 | 사이클 Li 변형 하중 · 액체 LIB


### [batch_36] d — 단단한 입자의 하중 몫 · 재밍

이 배치에 없음.  (wang2018 §8-3 줄 402–405 는 다른 카드 bazzoun2026 의 복합 양극 σ_eff,ion 이 f_CAM 70 → 80 wt% 에서 줄어든다는 것을 AM 이온 전도 반증으로 인용 — 하중 몫이 아니다.)


### [batch_37] d — 단단한 입자의 하중 몫 · 재밍

하중 몫 · 재밍 값 = 0.  참고:

- [d] famprikis2019 | 리뷰가 복합체 미세역학을 요구한 문장: *"It is crucial to consider the solid-state battery as a solid composite and treat its micromechanics (ref 105), including its resilience to form cracks and the delamination of interfaces"* | §5.4-1 줄 252 | stated (인용문) | 정량 없음
- [d] calpa2019 | 큰 SE (>10 µm) 복합체 단면: NCM 덩어리와 >20 µm SE 응집체가 따로 논다 (SEM-EDX 정성) — 분포 관찰이지 하중 몫 아님 | §5.2 줄 151 · Fig. 4 | stated (정성) | Li₇P₃S₁₁ · NCM111 · 그림 한 장씩


### [batch_38] d — 단단한 입자의 하중 몫 · 재밍

- [d] tron2023 | 저자의 기계적 해석 (측정 없음): *"For low AM:SE ratios … enough electrolyte particles are surrounding each active material particle to buffer mechanical stress … When less electrolyte is added, the NMC811 particles come in contact with each other, and densification is inhibited"* (ref [13]).  짝 관측: sp-LPSCl · 단결정 NMC811 · C65 2.5 wt% · 300 MPa 성형 · 10 MPa 측정 · C/20 첫 방전 — AM:SE 70:30 / 75:25 / 80:20 / 85:15 / 90:10 wt% → ≈160 / ≈149 / ≈135 / ≈102 / ≈13 mAh/g_NMC → 85:15 wt% (논문 표기 70:30 vol) 에서 −36 % · 90:10 에서 붕괴.  하중 몫 · 기공 · 밀도 정량 없음 | §3e 줄 117–129 · §3g 줄 143 · p.8–9 · Fig. 6 · Fig. 8 | stated (인용문) · 판독 ≈ (용량) · 우리 산수 (−36 %) | 카드 §10-7: "측정 없는 주장" · 셀 1 개 · 첫 사이클 · LiNbO₃ 코팅 NMC811 + Li₆PS₅Cl · 3D 실물
- 나머지 카드: 없음.


### [batch_39] d. 단단한 입자와 무른 입자를 섞어 누를 때 단단한 입자의 하중 몫 · 재밍

이 배치에 없음.


### [batch_40] d — 단단한 입자의 하중 몫 · 재밍

이 배치에 없음 (입자 혼합이 없음).  관련만:
- [d] gritton2017_mpm_chemomechanical_coupling_silicon_anode | 변형하는 기판은 기둥 팽창의 변형을 *"shared between both the pillar and the substrate"* — 단단한 (변형 않는) 기판에서는 바닥 모서리에 변형이 몰린다 | 카드 §5-6 · 논문 §4.6 p.18–19 · Fig. 9 | 인쇄 (정성) | 하중 몫의 값 없음 · 입자 층이 아니라 기둥 + 기판 · 계면 붙음


### [layer3] d. 단단한 입자와 무른 입자를 섞어 누를 때 단단한 입자의 하중 몫 · 재밍

- [d] ngandjong2021_dem_calendering_digital_twin | NMC111 96 wt% + CBD 4 wt% 압연: 86 → 156 MPa 로 1.8 배 올려도 Δε = 0.1 %p (26.33 → 26.23 %) · densification 의 63 % 가 5.92 MPa · 99 % 가 86 MPa 안 — 비교 문서 해석: 26 % floor 는 소성 종료가 아니라 강체 NMC 골격의 잼 · "floor 를 깨는 것은 압력이 아니라 기전 (소성 형상흐름)" | §A L181–189 · L195–197 · L210–212 | 0 / 5.92 / 86 MPa 값 = stated · 나머지 digitized (추세용) | 액체 LIB (E 200 GPa 강체 96 wt% + 무른 CBD) · 조성 교란 (우리 AM 62–88 wt%) → "수치 동일성 주장 금지 · 밴드 근거로만"
- [d] ngandjong2021_dem_calendering_digital_twin | knee 는 "하중을 지탱하는 가장 무른 상의 강성 × 부피분율" 이 정한다 — 무른 상 (CBD E 2 GPa) 이 4 wt% 뿐이라 knee 가 강체 재배열 단계 (< 5.92 MPa · 그 사이 실측점 없음) · SE 가 18–50 wt% 면 SE 자체가 하중경로 | §A L218–222 | "가설" | 육안 꺾임 ≠ Heckel 1/K (같은 양 아님)
- [d] bouvard2000_hard_soft_powder_densification + martinbouvard2003_dem_composite_cold_compaction | (묶음) 경상↑ → 고압 porosity↑ (Astroloy 상대밀도 0.995 → 0.86 @ alumina 0 → 35 vol%) · 거시응력이 E₂/E₁ = 10 → 100 에서 < 3 % 변화 → 비교 문서: "rigid-AM 가정 외부 면허" | §A L383–385 | 표지 없음 | Astroloy + alumina 분말 (황화물 아님) · 차원 이 줄에 없음
- [d] qin2026_bilayer_cathode_cgmd_dem_graded_thick_electrode | 직렬 두 층을 누를 때 영모형은 같은 변형률이 아니라 같은 응력 — 층별 두께감소 94:6 ≈ 41–43 % · 96:4 ≈ 23 % (두 적층 순서 동일) = 조성이 분배를 정함 · c40 에서 네 층 영역 φ_AM = 0.556–0.565 (Fig 5 판독 0.564–0.580) | §A L159–161 | derived(ours) · 판독 | 액체 LIB · ChemRxiv 비심사 · 1 실현 · 측면 31 µm ≈ 최대 입자의 2.2 배 · 압력축 없음
- [d] qin2026_bilayer_cathode_cgmd_dem_graded_thick_electrode | "같은 φ_AM" 규칙은 우리 DEM 으로 안 옮겨짐 — LHS 130 대조에서 AM-rich (SE/고체 < 0.35 · n = 68) 도 φ_AM 이 SE 비율을 따라 떨어짐 (기울기 −0.35 ± 0.03) ⇒ SE 가 AM 골격 틈을 채우기만 하지 않고 AM 을 벌림 · 옮겨 오는 것은 "층별 공극률 ≈ 같은 조성 단일 침대의 같은 응력 값" 하나 | §A L163–168 | "빠른 점검 · 스크립트 비커밋" | 모델 대 모델 (어느 쪽이 실물에 맞는지 말하지 않음)
- [d] kang2025_toughened_bimodal_nca_lzo | FEM: 가압 응력 (stack 200 / fab 400 MPa) ≪ Li 탈리 확산-유발 응력 (최대 GPa) → 사이클 균열에 가압 기여 미미 | §A L447–451 | 표지 없음 | 사이클 균열 맥락 한정 (압밀 결론으로 전이 금지) · NCA + LPSCl
- [d] varkey2026_multicontact_elastoplastic_dem | halide (E = 10.58 GPa) separator floor 21 % / cathode 37 % @ 350 MPa — separator (SE 만) ↔ cathode (NMC 섞임) | §A L332 · L206 | 표지 없음 | halide Li₃YBrCl₆ (LPSCl 아님 · §D L2730) · 강체 구 DEM · < 20 % "추구 안 함"
- [d] cardenasbarrantes2020_rigid_deformable_mixture_compaction_nscd + cardenasbarrantes2021_soft_rigid_mix_compaction_proceedings + cardenasbarrantes2022_soft_hard_grains_compaction_experiment_dic | (묶음) 강체 + 무른 입자 혼합 압밀: 최대 충전률 φmax 는 재료 상수가 아니라 혼합 구조의 출력 — 무른 고체 부피분율 κ 0.2 → 1 에서 φmax 0.877 → 0.994 (μ 0) · 0.862 → 0.982 (μ 0.2) · κ = 0.2 는 P/E 0.4 에서도 φ ≈ 0.86–0.88 에 멈춤 · 본문 설명 = 기하 (강체 상이 자기 jammed 충전률에 묶임) · 2022 실험 φmax κ = 1 → 0.97 · κ = 0.2 → 0.88 | §A L941–947 | Eq.(12) 적합값 = "PRE 2020 그림 5, PDF 벡터 경로 판독" · 0.86–0.88 = 판독 · 2022 값 = stated | 2D 원판 · 무른 입자 = 초탄성 (가역 · neo-Hookean ν 0.495) · 등방 (2022 실험만 일축 · ≤ ≈ 60 kPa) · P/E 무차원 · 같은 크기 범위 → "절대값 전이 0 건"
- [d] cardenasbarrantes2020_rigid_deformable_mixture_compaction_nscd + martinbouvard2003_dem_composite_cold_compaction | (묶음) 비교 문서 해석: jammed 강체 골격이 압력을 받는다 (Martin–Bouvard 경–경 하중 분담) → AM 을 얼린 장애물로 두는 MPM 은 이 기전을 지움 (f = 0 과대 압밀 ε_sphere 1.13 % 의 반대 극단) · "AM 이 움직이고 AM–AM 접촉이 하중을 받는 것이 φmax(κ) 의 최소 조건" | §A L945 | "우리 해석" | 2D 유비
- [d] cardenasbarrantes2020_rigid_deformable_mixture_compaction_nscd | 상분리 식 (15) φmax(κ) = φ0·φ1,max/[φ1,max + (φ0 − φ1,max)κ] (φ0 0.8167 · φ1,max 0.9936 / 0.9816) 는 섞인 침대 적합값보다 0.012–0.035 낮음 — 같은 크기에서도 섞임이 공극 채움을 도움 | §A L943 | 판독 | 2D · 같은 크기 (SE ≪ AM 인 계에는 그대로 못 씀 · 보정 목표로도 안 씀)
- [d] cardenasbarrantes2022_soft_hard_grains_compaction_experiment_dic + cardenasbarrantes2020_rigid_deformable_mixture_compaction_nscd | 배위수 Z − Z_J = 4.9 (φ − φ_J)^0.5 (실험 · κ 무관 · 실리콘 0.45 MPa + PVC 1.2 GPa · ~100 원기둥) ↔ 2020 시뮬 ξ = 5.1 | §A L947 | 표지 없음 | 2D · 같은 그룹 (φ_J 선택이 SM 이라 완전 독립 아님)
- [d] he2026_dem_calendering_inhomogeneity_areal_density | 하중분담을 정의할 수 없음 — 상이 하나 (NCM622 97.77 wt% + CBD) 라 f_AM ≡ 1 | §A L868–869 | 표지 없음 | 액체 LIB
- [d] zhang2026_xct_dem_cathode_calendering_peel_calibration | 하중 중 0.152 @ 200 MPa 는 "강체구 floor ~20 %" 아래 — 넓은 실측 PSD (반지름 ≈ 0.5–16 µm) + CBD 소구 + 탄성 겹침 + 미기재 공극률 관례 → "~20 % floor 는 PSD · 관례 · 하중상태에 조건부" 라는 반례 (제하 후 0.319 는 floor 위) | §A L894–895 | figure-read | 액체 LIB
- [d] martinbouvard2003_dem_composite_cold_compaction | 2-기전 분해: 경상 force-network (K_h ≈ 1.3 @ 20 → 1.8 @ 40 vol% · N₂₂/N₁₁ → 3.5) + 연상 excluded-volume 과변형 (+20–40 %) → 비교 문서: "복합 porosity 관계식 두 항" | §C L2160–2161 | 표지 없음 | 재료 · 차원 이 줄에 없음 (카드 소관)
- [d] so2021_dem_mold_pressure_assb_coldpress | Fig 5–6: Si AM–AM 응력집중 (2.5 → 5.9 GPa · overlap 0.007) · SE–SE 는 H_SE 캡 — AM 이 하중을 지고 SE 를 가림 | §C L2162–2163 | 표지 없음 | LPS + Si
- [d] cardenasbarrantes2020_rigid_deformable_mixture_compaction_nscd + cardenasbarrantes2022_soft_hard_grains_compaction_experiment_dic | (묶음) 배위수 Z · 입자간 응력 σℓ · 접촉 길이 · 마찰 μ 의존은 입자 경계가 있어야 정의됨 — 닿으면 융합하는 단일 속도장 MPM 에서는 정의조차 안 됨 → 움직이는 강체 AM 만으로는 (후보 A) 이 관측량을 못 얻고 다중 속도장 (A′) · 입자별 FE (B) 가 필요 · 2022 실험: 입자 내부 평균 변형이 C_c ≈ 0.991 을 경계로 밀도 지배 → 압력 지배 ("이산 → 연속체 같은 계") | §C L2685 | 표지 없음 | 2D · 초탄성 · 1500 입자 · 계산 비용 미기재
- [d] xu2023_realistic_am_shape_cgmd_calendering | AM 을 변형 가능하게 풀어 놓은 모델의 결론 "the secondary particles have suffered from modest deformations at high pressure due to the mechanical properties of NMC111" · 구형도 모드 −0.04 ~ −0.06 (두께 36–42 % 감소 동안) | §C L2094–2103 | 원문 인용 · digitized (폭은 "인용 금지 · 모드만") | AM E 135 GPa · 96 wt% (무른 상 4–6 wt%) → 하중 경로가 다름 · "정성 지지 · 정량 전이 불가"
- [d] zhang2026_xct_dem_cathode_calendering_peel_calibration | 큰 입자가 더 많은 접촉과 더 큰 힘을 짐 (Fig 9) — 그러나 파괴 판정량은 원시 힘이 아니라 크기 정규화량이어야 함 | §C L2345–2350 | figure-read | 액체 LIB
- [d] bardenhagen2000_mpm_granular_multibody_frictional_contact | 원판 369 개 75 % 전단 (Fig 6): no-slip (단일 속도장) = 큰 소성 변형 + 큰 공극 ↔ 마찰 미끄럼 (μ 0.3) = 구름 · 미끄럼 · 소성 적음 — 접촉 조건이 하중 경로를 바꿈 | §C L2716 | 표지 없음 | 2D · 전단 (압밀 아님) · HMX 근사
- [d] mcgeary1961_bimodal_sphere_packing | 강체 구 패킹 실험 원전 ("소성변형 없음" 명시): 1 size 62.5 % → binary 86 % (임계 크기비 d_c/d_f ≥ 7 · 삼각공극 0.154·d_c) → ternary 90 % → quaternary 95.1 % — 비교 문서: AM : SE 12 : 1 (≫ 7 · dip 깊음) · 4 : 1 (< 7 · 부분충전) 을 이 무릎으로 설명 → (조성 × 크기비) 기하항 | §D L2737–2739 | 표지 없음 | 구 충전 실험 (전극 아님 · 재료는 이 줄에 없음) · 압밀 아님 (충전)
- [d] bouvard2000_hard_soft_powder_densification + so2021_dem_mold_pressure_assb_coldpress | (묶음) 단단한 상의 percolation 임계가 크기비의 함수: Bouvard 0.32 (r = 1) → 0.18 (r = 2) · alumina inclusion 균열 = 하중분담의 증거 · So 2021 φ_SE^crit = 0.13 (ball-milled aggregate) | §D L2740–2742 | 표지 없음 | Bouvard = alumina inclusion 계 (모재는 이 줄에 없음) · So = LPS + Si
- [d] varkey2026_multicontact_elastoplastic_dem + mcgeary1961_bimodal_sphere_packing + bielefeld2019_microstructural_modeling_composite_cathode + bielefeld2020_effective_ionic_conductivity_binder + minnmann2022_designing_cathodes_solidstate + luan2025_graded_cathode_400whkg_pouch | (묶음 · 조성–기공 최소 "dip") 문헌: Varkey RCP / rigid → dip @ AM 70–80 wt% (de Larrard 기하) · Bielefeld 2019 는 단봉 PSD 만 (bi / tri-modal 은 향후 과제) · Bielefeld 2020 은 trimodal 1 : 1 : 2 한 케이스를 porosity 15 % 고정으로 (dip 미측정) · Minnmann 2022 는 정성 · Luan 은 측정 없음 → dip 의 정량 실험 자료는 McGeary (강체 구) 뿐 · 비교 문서: "dip 은 초기 강체 구 패킹 (기하) 에 산다 · 소성 연속체 MPM 은 재현 못 함" | §D L2734–2760 · L2770 | 표지 없음 | 복합 양극 (AM + SE) 의 조성별 기공 실측은 이 절에 없음
- [d] kang2026_multiscale_inverse_design_ptfe_fibrillation_dry_electrode | 미세 분획 응집이 틈 채움 이득을 뒤집은 실측: SiO₂ 쌍봉 10 + 1.5 µm (크기비 0.15) 탭 밀도 1.38 → 1.18 g/cc · 건식 막 MIP 공극 32.2 → 36.1 % (10 + 5: 1.40 · 29.9 %) — 점착 없는 압밀 DEM 은 이 역전을 못 냄 | §D L2788 | 표지 없음 | SiO₂ 대리 입자 · 섞는 비율 미기재
- [d] gandla2026_layered_cathode_degradation_diagnostics_review | XCT 로 센 NCM–NCM 배위수 최빈 ≈ 4.5 · ≈ 5.5 · ≈ 5–6.5 (NCM : SE 70 : 30 · 80 : 20 · 85 : 15) — 리뷰 그림 5h (Park 2025 ACS Nano 재수록) | §E L2870 | 판독 ± 0.5 | 접촉 판정 · CT 분해능 · 질량 / 부피 기준 미기재 → "모양 · 방향만" · 하중 몫 값은 아님
- [d] shi2019_high_am_loading_particle_size_assb | (하중 몫 아님 · 연결성) 활성 CAM 분율 θ 98 % 에 필요한 크기비 λ_min 이 65–75 wt% 에서 1.6–2.1 로 평평하다가 ≈ 78 wt% 에서 수직 (≈ 79.6 wt% 에서 λ 8 초과) | §D L2778–2786 | digitized (Fig 3d) | LPS 유리 · NMC532-LZO · E_SE 18.5 무연화 강체구 · DEM porosity 미보고 · dip ↔ λ_min 직접 등치 금지
- [d] vanlew2015_modifying_youngs_modulus_distribution | 7 침대 실측: 거시 응력–변형은 E 가 지배 ("the largest contributor to stress–strain response is the Young's modulus. The coefficient of friction and radius distribution had comparatively insignificant influence.") · 접촉력 분포의 본체는 전부 겹치고 ("the majority of the contacts in all the beds are equally small") 꼬리만 갈리며 꼬리는 μ 가 지배 ("higher coefficients of friction generally have higher peak contact forces") | §F L3322–3331 | 원문 인용 | 세라믹 pebble · 6 MPa
- [d] coetzee2017_dem_calibration_review | 강성을 낮추면 배위수가 올라감: Ng & Asce [193] (p.130) "Decreasing the particle stiffness resulted in a higher coordination number and these two effects balanced each other" — 역학은 상쇄돼도 접촉망은 바뀜 | §F L3380–3387 | 원문 인용 | 
- [d] giannis2021_stress_based_multicontact_dem | 배위수 의존 접촉강성 ΔF/F ∝ C — 같은 겹침이라도 잘 구속된 입자의 접촉이 더 뻣뻣 · 예측 (미시험): 다접촉을 켜면 SE-rich (고 C) 침대가 AM-rich 보다 더 뻣뻣해짐 | §F L3533–3537 | 미시험 예측 | 
- [d] cardenasbarrantes2020_rigid_deformable_mixture_compaction_nscd + cardenasbarrantes2021_soft_rigid_mix_compaction_proceedings + cardenasbarrantes2022_soft_hard_grains_compaction_experiment_dic | (묶음 · 공통 관측량) φ(P) (느슨한 출발 → φmax 포화) · φmax(κ) · K(φ) 발산 위치 · Z − Z0 = ξ(φ − φ0)^α · 접촉 길이 / 피복 vs (φ − φJ) (2022 실험: 선형 · κ 무관) · 비구형도 vs P · 입자 내부 변형 평균 · 폭 · 출발 패킹 2D φ0 0.805–0.815 · Z0 3.3–3.7 (2021 학회판 Table 1) | §F L3972 | 표지 없음 | 2D
- [d] zunker2025_dem_large_deformation_compaction | 강한 다분산에서 홈에 낀 작은 입자가 정당한 큰 입자끼리 접촉을 소거할 위험 (거리 기반 중심판정이 크기를 모름) · 검증은 반경비 0.25 까지 (거기서 이미 최악) · 2 상 불가 | §F L3769–3773 · L3752–3758 | DERIVED | MCC



# Rint ② 개발 탐침 사전 원장 — ⑥ SBE 값 봉인 숫자 탐침 · ⑦ SBE 물리 확인 탐침 (11-03 밤 · §5)

- 근거 = Codex 회차 ① 판정 §10 (`docs/reviews/codex_review_rint2_rr_round1_20261026.md` — "⑥ 을 별도 개발 탐침 사전 원장에 넣거나 명시적 예외로 등록") · 수정 계획 `docs/reviews/rint2_rr1_fix_plan_20261026.md` Q5 (가) · 1저자 10-26 *"권고대로해"*.
- 지위 = **결과 0 건** · 첫 시도 전에 이 원장을 커밋한다 (결과 전 커밋).  아래 ⬜ 칸은 첫 시도 전에 채워 다시 커밋한다.
- Q9 설계 §3-5 의 "원장 밖 킷 풀이 금지" (개정 4 · 1저자 10-24 Q1 · Q7) 와의 관계 = 이 원장에 등록된 ⑥ 만 그 금지의 예외다 (Q9 개정 5 · §10).  다른 SBE · DBE 킷 풀이는 그대로 금지.  → (11-03 밤 · 1저자 Q7 *"권고대로"*) 이 원장 §5 에 등록된 ⑦ 시도도 같은 예외 (SBE 만 · DBE 입력 · 결과 금지 · Codex 회차 ② 가 "열어도 된다" 일 때만) — 그 밖은 그대로 금지.

## 1. ⑥ 이 무엇인가 (등록 R §11 ⑥ · §2-1)

- 실침대 SBE 에서 전처리 · maxiter · 시간 상한을 정하기 위한 **반복 · 메모리 · 비용 탐색**.  등록 R §11: "숫자 탐침 (σ 봉인 · 반복 수 · 잔차 · 판 전류 불균형 · 시간만)".
- 순서 (등록 R :536 · 1저자 10-22 Q2) = S0 단계 1 (SBE 기하) → s_min 개발 단계 → **⑥** → Codex 요청 (기하 + ⑥ 의 실침대 반복 수) → 세 숫자 → 계획 하나 봉인 → S0 단계 2 (DBE) → R 런.

## 2. 규칙 (Codex §10 의 일곱 칸)

| 칸 | 규칙 |
|---|---|
| 허용 입력 | SBE 새 침대 (VGCF E 100 GPa 재압밀 · 10-23 · `docs/data/rint2_recompaction_vgcf100_20261023/README.md`) 만.  **DBE 입력 금지** (DBE 결과 사용 금지). |
| 핀 | 시도마다 코드 커밋 sha 를 원장에 적는다 · 최종 핀과 다르면 그 시도는 개발 자료 (반복 수 · 시간만 참고) · R 용 숫자는 최종 핀에서 다시 잰다. |
| 기계 / 환경 | 시도마다 기계 이름과 전체 환경 지문 (Python · numpy · scipy 판 · GPU · CUDA · BLAS) 을 적는다 · 첫 기계 = kgy (Python 3.8.10 · numpy 1.24.4 · scipy 1.10.1) ✅ 확정 (11-10 · 1저자 현장 사실 확인에서 같은 판 · §3 시도 1). |
| 시도 | 시도 하나 = 원장 한 줄 (번호 · 시작 시각 · 명령 줄 전체 · 핀 · 기계 · 환경 · 결과 칸) · 번호는 이 원장에서 온다 · 시작 전에 줄을 커밋 · "가장 좋은 시도" 를 고르지 않는다 (모든 시도를 보고). |
| 실패 보존 | 멈춘 시도 · 실패한 시도의 폴더를 바이트 그대로 두고 폴더 요약 sha256 을 적는다 · 지우거나 덮어쓰지 않는다. |
| σ 비열람 | σ 값은 봉인 파일에만 쓰고 화면 · 로그 · 보고에 내지 않는다 · 읽는 것 = 반복 수 · 잔차 · 판 전류 불균형 · 시간 · 메모리뿐 (등록 R §11). |
| 채택 불가 | ⑥ 의 어떤 값도 R 판정 · 보정 · 예측 값으로 쓰지 않는다 · 쓰는 곳 = 계획의 전처리 · maxiter · 시간 상한 숫자 (등록 R §10) 뿐. |

## 3. 시도 원장

| 번호 | 시작 (KST) | 명령 줄 | 핀 | 기계 · 환경 | 결과 (반복 · 잔차 · 판 전류 불균형 · 시간 · 메모리) | 폴더 sha256 |
|---|---|---|---|---|---|---|
| 1 | 2026-11-11 08:52:19 (러너 시작 · 묶음 meta start_kst) → 11:00:06 끝 (DONE) | 아래 "시도 1 · 2 의 명령 줄" 의 시도 1 (감시 셸 한 줄 + 감시 셸이 내는 러너 명령 한 줄 · 한도 30000 · 짧은 확인) · 실제로 돈 러너 줄 = 묶음 command.txt = 아래 러너 줄에 출력 폴더 · 작업 트리 자리만 채운 글과 글자 같음 (본 세션 대조) | `5bca50c8829b3845529bae4fb7bfe5952208b216` (발사 직전의 stoic 끝 = 이 원장 §3 의 고침 커밋 자리를 채운 커밋 · 발사 블록의 PIN = 묶음 meta 의 pin) · 이 줄을 넣은 커밋 = `b0f118e17` · 발사 전 고침 커밋 = 2 회차 반박 리뷰 고침 = `420da6bb33890965717510d1a4167d597718b2d1` (11-10 push) | kgy · Python 3.8.10 · numpy 1.24.4 · scipy 1.10.1 · cupy 12.3.0 (CUDA 런타임 12060) · RTX 3090 24 GB · GPU 드라이버 560.35.03 · CUDA 12.6 · OpenBLAS SkylakeX · Ubuntu 20.04.6 · 커널 5.15.0-139 · i9-11900K 16 스레드 · 메모리 65,709,496 kB · 발사 전 GPU 사용 5,727 MiB (다른 프로세스) · 상한 41 GB | 판독 rc 3 (미수렴 = 시도 1 의 정상 끝 · 문제 = 미수렴 하나뿐 · 침대 · tol_ff · 핀 · R_j 등록값 대조 참 · 영수증 arms 1) · 미지수 26,529,223 · 반복 주 30,000 (한도) · 이어 풀기 30,000 (한도) · 잔차 4.81885e-07 · 판 전류 불균형 1.02382 · 증서 POSITIVE_SOLVED · ⓐ–ⓓ 거짓 · 시간 전체 7,667 s (러너 rc 1) = 런 전 101 s + 래스터 준비 4,487 s (탄소 접합 준비 4,038 s 포함) + CG · 증서 3,049 s · 반복당 0.0508 s (위 한계) · 메모리 러너 그룹 RSS 최대 33,433,904 kB · `time -v` 34,978,676 kB · GPU 전체 최대 14,044 MiB (다른 프로세스 포함 · 우리 몫 표본 없음) · 기록 `docs/data/rint2_probe6_a1_20261111/README.md` | 묶음 eadc906823823e2047690830aa00c0ecc37786d9567181b0410b71e8cd4b6792 · 출력 폴더 (이름 크기 sha256 목록) 722e625bb9d92bce0162456456e2d91e7fe6ce337c5adcf0f23b2f651fe3aff6 · (sha256sum 꼴) d9ba443f525573ccc2a8326426938446f4ba1a3169ce4a641dbec706dfea2fe8 · 미수렴 팔 (킷 런 폴더 · 129,561,005 B) e2a7014c9e5bfa46b684281e17f7e236161d272af45e71055c4002e8821a75c3 |
| 2 | 2026-11-11 13:32:48 (러너 시작 · 묶음 meta start_kst) → 19:45:13 끝 (DONE) · 앞 조건 = 풀이를 시작한 시도 1 (`solve_started=1`) 의 DONE (11:00:06) 뒤 = 블록 · 감시 셸 확인 | 아래 "시도 1 · 2 의 명령 줄" 의 시도 2 (한도 1500000) · 실제로 돈 러너 줄 = 묶음 command.txt = 아래 러너 줄에 출력 폴더 · 작업 트리 자리만 채운 글과 글자 같음 (본 세션 대조) | `5bca50c8829b3845529bae4fb7bfe5952208b216` (발사 때 stoic 끝 = 시도 1 의 핀과 같음 · 묶음 meta 의 pin = attempt1_pin · code_same_as_attempt1 = 1 = 두 핀 사이 풀이 코드 차이 0) | 시도 1 과 같은 기계 (kgy) · 같은 작업 트리 다시 씀 · 환경 = 시도 1 과 같음 (묶음 env.txt 가 시도 1 의 것과 바이트 같음) · 발사 전 GPU 사용 6,325 MiB (다른 프로세스) · 상한 41 GB | 판독 rc 0 (PROBE_OK · 문제 0 건 · 침대 · tol_ff · 핀 · R_j 등록값 대조 참 · 영수증 arms 1) · 미지수 26,529,223 · 반복 주 277,885 (수렴 · 한도의 18.5 %) · 이어 풀기 84,485 (수렴) · 잔차 1.0519e-12 · 판 전류 불균형 9.63612e-07 · 증서 POSITIVE_SOLVED · ⓐ–ⓓ 참 · 시간 전체 22,345 s (러너 rc 0) = 런 전 100 s + 래스터 준비 4,467 s (탄소 접합 준비 4,040 s 포함) + CG · 증서 17,748 s + 저장 · 끝 30 s · 반복당 0.0490 s (위 한계 · 주 + 이어 풀기 362,370 반복) · 메모리 러너 그룹 RSS 최대 34,457,020 kB (저장 구간 · 풀이 구간 26,093,944–31,722,772 kB) · `time -v` 34,491,680 kB · GPU 전체 최대 14,648 MiB (다른 프로세스 포함 · 우리 몫 표본 없음) · 기록 `docs/data/rint2_probe6_a2_20261111/README.md` | 묶음 d685af169f65a7aba890951d271429f04bc7560755c8bf56a62a12f7c90e7f44 · 출력 폴더 (이름 크기 sha256 목록) c20ffa2f6e780bdee2a21bfc98d1a2f27e2dba18849d7343a75e93a35deeccde · (sha256sum 꼴) 7bface00253dac50b7cac064524e234480f46fc6cacf17fbda98c99b991ffc5f · 팔 JSON (출력 폴더 · 129,560,974 B) a55d46aaa132fd5a4e5e937edbe54737c78eb6f176eb82d2320c7d02c7d5888d |
| 3 | (빈칸 — 발사 때 적는다 · 러너 시작 = 묶음 meta start_kst) | 아래 "시도 3 · 4 의 명령 줄" 의 시도 3 (한도 1500000 · 탄소 접합 원장 저장본 켬 · `~/p6_cjstore` 가 없거나 빈 폴더 → payload 가 원장을 짓고 씀 · audit 상태 `built_written`) · 앞 조건 = 풀이를 시작한 시도 2 (`solve_started=1`) 의 DONE 하나 (감시 셸이 본다) | 11-13 Codex 반박 1/2 고침 묶음을 넣은 커밋 또는 그 뒤 발사 직전 가지 끝 (빈칸 — 발사 때 적는다) | kgy (빈칸 — 묶음 env.txt) | 결과 0 건 (발사 전 · 11-13 등록) | (빈칸) |
| 4 | (빈칸 — 발사 때 적는다) | 아래 "시도 3 · 4 의 명령 줄" 의 시도 4 (한도 1500000 · 시도 3 이 남긴 저장본 그대로 → payload 가 읽음 · audit 상태 `hit`) · 앞 조건 = 풀이를 시작한 시도 3 의 DONE 하나 · 두 핀의 풀이 코드 같음 (`code_same_as_attempt3=1`) · 저장본 = 시도 3 meta `store_listing_after` 와 이름 · sha256 같음 | 시도 3 의 핀 또는 풀이 코드가 같은 뒤 커밋 (빈칸) | kgy (빈칸) | 결과 0 건 (발사 전 · 11-13 등록) | (빈칸) |

### 시도 1 · 2 의 명령 줄 (11-10 등록 · 결과 0 건 · 시작 전 커밋)

시도 1 (블록 `ATTEMPT=1` · 한도 30000 · 한도에 닿아 끝나는 것이 정상):

    bash <W>/docs/reviews/rint2_probe6_prep_20261110/tools/run_probe6.sh <W> <O> <L> <PIN> 30000

    env -u BASH_ENV -u SHELLOPTS VOX=0.15 SDCP_SPHERE_D=0.30 PTFE_STAMP=face_alpha BRIDGE_UM=0.48 SIGMA_AM_S_OVERRIDE=0.0041 SIGMA_SDCP_OVERRIDE=256.6 SIGMA_FIBRE_BULK=1e4 CJUNC=1 CJUNC_RJ=1e6 CJUNC_LEN_LAW=len_scaled_v0 CJUNC_UNREG_LAW=cut CJUNC_S_MIN_UM=0.0 CJUNC_TOL_FF_UM=0.07381254285530132 CJUNC_PTFE_JLAW=P0 SDCP_MOD_C=0 STEP3_RTOL=1e-12 EXPECT_BACKEND=gpu KITS=kit_SBE_vgcf100 ARMS=1 LEAN=2 P2_EXTRA="--step3-maxiter 30000" OUTDIR=<O> PYTHONUNBUFFERED=1 bash <W>/scripts/sdcp_gain_vox015_8arm.sh

시도 2 (블록 `ATTEMPT=2` · 한도 1500000 · 풀이를 시작한 시도 1 (`solve_started=1`) 의 DONE 뒤):

    bash <W>/docs/reviews/rint2_probe6_prep_20261110/tools/run_probe6.sh <W> <O> <L> <PIN> 1500000

    env -u BASH_ENV -u SHELLOPTS VOX=0.15 SDCP_SPHERE_D=0.30 PTFE_STAMP=face_alpha BRIDGE_UM=0.48 SIGMA_AM_S_OVERRIDE=0.0041 SIGMA_SDCP_OVERRIDE=256.6 SIGMA_FIBRE_BULK=1e4 CJUNC=1 CJUNC_RJ=1e6 CJUNC_LEN_LAW=len_scaled_v0 CJUNC_UNREG_LAW=cut CJUNC_S_MIN_UM=0.0 CJUNC_TOL_FF_UM=0.07381254285530132 CJUNC_PTFE_JLAW=P0 SDCP_MOD_C=0 STEP3_RTOL=1e-12 EXPECT_BACKEND=gpu KITS=kit_SBE_vgcf100 ARMS=1 LEAN=2 P2_EXTRA="--step3-maxiter 1500000" OUTDIR=<O> PYTHONUNBUFFERED=1 bash <W>/scripts/sdcp_gain_vox015_8arm.sh

- 러너 env 에 `SIGMA_VGCF_OVERRIDE` 는 없다.  `--show-results` 없음 (값 봉인).  `PYTHONUNBUFFERED=1` 은 물리 축이 아니다 (감시 셸이 러너에 준다 · 일찍 멈출 때 payload 의 한도 줄이 버퍼에 갇히지 않게).  `-u BASH_ENV -u SHELLOPTS` 도 물리 축이 아니다 (러너 bash 가 시작 파일 BASH_ENV 와 셸 선택 SHELLOPTS (작업 제어 monitor 등) 를 물려받지 않게 · 2 회차 P6R2-06 · 감시 셸은 러너의 런 전 관문을 미리 돌릴 때도 같은 env 로).  감시 셸은 PYTHONPATH 를 걷어낸 뒤 python 을 부른다 (P6R2-05 · meta `pythonpath_removed` · 판독기는 러너 시작 때 PYTHONPATH 가 남았다는 meta `pythonpath_set=1` 을 PROBE_OK · 미수렴 어느 쪽에서도 받지 않는다).  자리표 값의 근거와 두 한도의 까닭 = `docs/reviews/rint2_probe6_prep_20261110/LEDGER_LINE.md` 끝 표 · `docs/reviews/rint2_probe6_prep_20261110/README.md` §6.
- 시도 2 의 한도 1500000 은 시도 1 의 결과를 보기 전에 정한 값이다.  시도 1 을 본 뒤 바꾸지 않는다 (바꾸려면 새 줄을 먼저 커밋한다).  **시도 번호 ↔ 한도 짝** (1 → 30000 · 2 → 1500000) 은 감시 셸이 본다 (다른 짝 = 띄우기 전 STOP) · 판독기도 본다 (meta 의 짝이 다르면 rc 4 · P6R2-04).
- **핀 칸**: 줄이 자기가 든 커밋의 번호를 미리 담을 수 없어 1 번 줄은 "이 줄을 넣은 커밋" 으로 적는다.  발사 전에 줄이나 준비물을 고치는 커밋이 더 생기면 핀 = 발사 직전의 stoic 끝이고 (블록이 fetch 뒤 PIN = 가지 끝인지 본다), 그 사실을 줄에 적은 뒤 발사한다.  2 번 줄의 핀 = 시도 2 발사 직전의 stoic 끝이다.  어느 쪽이든 발사 블록의 PIN (40 자리) 과 묶음 meta 의 pin 이 같아야 하고, 발사 뒤 그 칸에 40 자리를 옮긴다.  (11-10) 2 회차 반박 리뷰 고침 커밋 (`420da6bb33890965717510d1a4167d597718b2d1` · 11-10 push) 이 1 번 줄을 넣은 커밋 뒤에 들어간다 → 1 번 줄의 핀 칸에 그 sha 를 적고 핀 = 발사 직전의 stoic 끝.
- **띄우기 전 STOP · 풀이 0**: 풀이가 시작되기 전에 끝난 경우 (블록의 멈춤 · 감시 셸의 발사 전 확인 실패 · 러너 시작 전 신호 · 러너가 자기 런 전 관문에서 멈춤 · payload 가 풀이 시작 줄 전에 멈춤 · 풀이 0) 는 새 시도로 세지 않고 그 줄의 결과 칸에 사유를 적는다 (다음 발사도 같은 번호).  판별 = 로그 폴더의 `STOPPED` 표지 (감시 셸이 러너를 띄우지 않았다 · `runner_started=0` · 화면 · status.log 에 `STOP: … (runner not started)`) 또는 `DONE` 이어도 meta 의 `solve_started=0` (러너는 돌았지만 풀이 시작 줄이 없다).  블록 자신의 멈춤 (`[p6] STOP:` · 로그 폴더를 만들기 전) 은 폴더가 없다.  meta `solve_started=1` 이면 그 시도는 끝난 것이고 (일찍 멈춤 · 실패 · 한도 포함 · 폴더 그대로) 다음은 다음 번호 줄이다.  `WATCHER_FAILED` 표지 (러너 시작 뒤 감시 셸 자신의 실패 · 러너가 자기 세션의 우두머리가 아님 · meta 가 없을 수 있다) 는 본 세션이 그 폴더의 status.log 를 보고 정한다.
  → 본 세션 정함 (11-10 · README §9 의 정할 것 6 · 7): 시도 2 의 핀 = 시도 1 의 핀이거나 그 뒤 커밋 (블록의 merge-base 조건 그대로 · 두 시도 사이에 시도 1 결과 줄을 커밋하므로) · `WATCHER_FAILED` 는 status.log 에 러너 시작 줄이 있으면 끝난 시도로 센다 (다음 = 다음 번호 · 폴더 그대로) · 러너 시작 줄이 없으면 위 STOP 과 같다 (새 시도로 세지 않음) · 남은 잠금 (`~/.probe6.lock`) 은 1저자가 같은 계정에 감시 셸 · 러너 · payload 프로세스가 없음을 본 뒤에만 지운다 · 붙잡아 둔 상대 칸 넷은 그대로 닫아 둔다 · 메모리 상한 규칙 · BASE 그대로.
- **시도 2 의 앞 조건** (2 회차 P6R2-01): 풀이를 시작한 시도 1 (`solve_started=1`) 의 DONE 뒤: `~/p6log_a1_*` 가운데 `DONE` 이 있고 meta 에 `solve_started=1` 인 폴더가 정확히 하나 (블록 · 감시 셸 둘 다 본다).  풀이 0 인 시도 1 (`STOPPED` · `DONE` + `solve_started=0`) 뒤에는 시도 2 블록이 멈추고, 시도 1 블록을 다시 붙인다 (같은 번호).
- **끝난 시도 번호** (2 회차 P6R2-02): `~/p6log_a<N>_*` 에 `DONE` + `solve_started=1` 이나 `WATCHER_FAILED` + status.log 의 러너 시작 줄 (`runner started - maxiter …`) 이 하나라도 있으면 그 번호는 다시 띄우지 않는다 (블록 · 감시 셸 둘 다 · 원장의 감시 셸 줄은 손으로도 부를 수 있다).  시도 1 은 끝난 시도 2 폴더가 있어도 멈춘다.  `STOPPED` · `DONE` + `solve_started=0` 은 세지 않는다 (같은 번호 다시).  감시 셸은 로그 폴더가 홈 바로 밑 (`~/p6log_a<N>_…`) 일 때만 받고, 앞 로그 폴더에 끝 표지가 없으면 멈춘다 (블록과 같다).
- **풀이 코드** (2 회차 P6R2-03 · 1저자 11-10 Q2 (가)): 두 시도의 핀 사이에 다음 경로가 바뀌면 시도 2 는 띄우지 않는다: `scripts/` · `docs/reviews/rint2_probe6_prep_20261110/tools/` · `docs/data/rint2_s0_sbe_20261108/` · `docs/data/rint_eis_anchors.csv` · `docs/reviews/sdcp_gain_prereg_v2_20260816.md` (러너 · payload 가 읽거나 import 하는 리포 파일 = 실물 러너 + payload 를 픽스처 침대에서 strace 로 돌려 셌다 · scripts/ 밖 = 러너가 있는지 보는 사전등록 · payload 가 읽는 EIS 앵커 표 · 그 밖에 탐침 도구 폴더 · S0 단계 1 자료 · 규율 검사의 입력 (`docs/reviews/claims.json` 등) 은 통과 / 멈춤만 정하고 감시 셸이 미리 돌리므로 목록 밖 · 이 원장 · 진행 기록 같은 문서도 목록 밖 · 두 시도 사이에 본 세션이 시도 1 결과 줄을 커밋한다).  두 겹: 블록이 `git diff --quiet <시도 1 의 핀> <PIN> -- <목록>` 이 아니면 멈추고 바뀐 파일 앞 다섯 개를 찍는다 · 감시 셸 (시도 2) 이 시도 1 폴더에서 그 핀을 스스로 찾아 다시 보고 meta 에 `attempt1_pin` · `code_same_as_attempt1=1` 을 적는다 · 판독기는 시도 2 에 그 둘이 없거나 다르면 rc 4.
- 검토 = 내부 반박 리뷰 (독립 조수 · Codex 아님) 를 발사 전에 거친다 (1저자 11-10 · Codex 회차는 봉인 전 묶음 한 번).  → 1 회차 (11-10 · 보고 = 본 세션 scratch · 원장 P6R-01–12) = P1 0 · P2 5 · P3 7 (σ 새는 길 없음 · 킷 원 입력 해시 대조를 깨지 않음) → 고침 = 이 줄을 넣은 커밋 (두 시도 · 시험 먼저) → 고친 곳만 짧은 재리뷰 (독립 조수) 뒤 시도 1 발사 GO 요청.
  → 2 회차 (11-10 · 내부 반박 · Codex 아님) = P1 0 · P2 3 · P3 5 (P6R2-01–08) → 고침 = 이 고침을 넣은 커밋 → 고친 곳만 3 회차 짧은 재리뷰 → 시도 1 GO 요청.
  → 3 회차 (11-10 · 고친 곳만 · 내부 반박 · Codex 아님) = P1 0 · P2 0 · P3 5 (`P6R3-01`–`05` · P6R2-01–07 닫힘) → 1저자 11-10 *"다 권고야"* = 시도 1 GO (BASE 그대로) → 시도 1 (11-11 08:52 → 11:00 KST · 위 1 번 줄) → 1저자 11-11 시도 2 GO → 시도 2 (11-11 13:32 KST · 위 2 번 줄) · P3 처분 = 01 · 02 · 05 코드 고침은 시도 2 끝 (DONE) 뒤 (그 전에 탐침 도구를 커밋하면 풀이 0 재발사가 막힌다) · 03 = 한정 (블록 겹만 약함 · 감시 셸이 막음) · 04 = 아래 글.
- **두 시도 사이 커밋** (3 회차 `P6R3-04`): 위 풀이 코드 목록의 경로 (scripts/ 통째 · 탐침 도구 폴더 = 시험 파일 포함 · S0 단계 1 자료) 를 바꾸는 커밋은 두 시도 사이에, 그리고 시도 2 가 끝날 때 (DONE) 까지 가지에 올리지 않는다 — 블록이 PIN = 가지 끝을 요구하므로 피해 갈 수 없고, 풀이 0 으로 끝난 시도는 같은 번호를 다시 띄우므로 그때도 코드가 같아야 한다 (README §9 의 "따라 나오는 것" 과 같은 글 · 이 원장 · 진행 기록 같은 문서는 목록 밖).
  → (11-11) 시도 2 = DONE · `solve_started=1` (19:45:13 KST · 묶음 meta · 본 세션 판독 · 위 2 번 줄) → 두 시도가 다 끝났으므로 이 금지는 여기서 끝난다. 뒤의 `scripts/` · 탐침 도구 커밋은 평소 절차 (시험 먼저 · 게이트) 대로다. 미뤄 둔 `P6R3-01` · `02` · `05` 코드 고침이 이제 열린다.

### 시도 3 · 4 의 명령 줄 (11-13 등록 · 결과 0 건 · 시작 전 커밋 · Codex 반박 1/2 고침 묶음 · 1저자 Q4)

시도 3 · 4 (감시 셸 로그 폴더 `~/p6log_a3_<시각>` · `~/p6log_a4_<시각>` · 출력 `ca1_probe6_a3_…_arm1` · `ca1_probe6_a4_…_arm1` · 한도 1500000 = 시도 2 와 같음 · 저장본 `~/p6_cjstore` 고정):

    bash <W>/docs/reviews/rint2_probe6_prep_20261110/tools/run_probe6.sh <W> <O> <L> <PIN> 1500000

    env -u BASH_ENV -u SHELLOPTS VOX=0.15 SDCP_SPHERE_D=0.30 PTFE_STAMP=face_alpha BRIDGE_UM=0.48 SIGMA_AM_S_OVERRIDE=0.0041 SIGMA_SDCP_OVERRIDE=256.6 SIGMA_FIBRE_BULK=1e4 CJUNC=1 CJUNC_RJ=1e6 CJUNC_LEN_LAW=len_scaled_v0 CJUNC_UNREG_LAW=cut CJUNC_S_MIN_UM=0.0 CJUNC_TOL_FF_UM=0.07381254285530132 CJUNC_PTFE_JLAW=P0 SDCP_MOD_C=0 STEP3_RTOL=1e-12 EXPECT_BACKEND=gpu KITS=kit_SBE_vgcf100 ARMS=1 LEAN=2 P2_EXTRA="--step3-maxiter 1500000" CJUNC_STORE=~/p6_cjstore OUTDIR=<O> PYTHONUNBUFFERED=1 bash <W>/scripts/sdcp_gain_vox015_8arm.sh

- **무엇** — 탄소 접합 원장 저장본 (Q2 코드 묶음 · `scripts/cjunc_store.py`) 의 실침대 첫 측정: 시도 3 = 빗나감 (짓고 씀) · 시도 4 = 적중 (읽음).  팔 audit 곁 파일 `cjstore_audit_<팔>.json` (과학 payload 밖 · 러너가 팔과 함께 출력 폴더로 옮김) 의 상태 · 열쇠 · 파일 · sha 를 판독기가 본다 (시도 3 = `built_written` · 시도 4 = `hit` · 파일 sha = 끝 목록 · 시도 3 시작 목록 빔 · 시도 4 앞 목록 = 끝 목록 — 다르면 rc 4).
- **결과 전 기대 (적어 둠 · 결과를 보고 바꾸지 않는다)** — 시도 3 ↔ 4 = 같은 코드 · 같은 기계 · 같은 침대 → 판독기가 내는 반복 수 · 잔차 · 판 전류 불균형 · n_dof · 증서 칸이 같다 (저장본 적중이 원장을 바꾸지 않는다) · 시도 4 의 탄소 접합 준비 초 < 시도 3 (읽기 ≪ 짓기 · 크기는 결과).  다르면 그대로 보고하고 원인을 저장본으로 단정하지 않는다 (GPU 합산 차례 등) — 출력된 잔차 자리 · 반복 수 같음은 해 벡터 바이트 같음이 아니다.
- **시도 2 ↔ 시도 3 · 4** = 코드 묶음이 다르다 (시도 2 = 바탕 · A 꼴 전처리 · 저장본 없음 / 시도 3 · 4 = C 꼴 · 저장본) — 반복 수 · 잔차 · 불균형 비교는 보고만 · 차이의 원인을 C 꼴 하나로 귀속하지 않는다 (Codex 반박 1/2 Q11).  GPU C 꼴의 채택은 Q11 확인 블록 v8 의 소비 규칙 (`docs/reviews/rint2_codepkg_20261113/q11_gpu_check_block_v8.txt` · `consume.adopt`) 이 정한다 — 이 두 시도가 아니다.
- **앞 조건 · 멈춤 (감시 셸 · 11-13)** — 시도 3: 풀이를 시작한 시도 2 의 DONE 정확히 하나 · 그 핀 = 이 핀 또는 앞 커밋 · 저장본 폴더 없음 또는 빔 (모든 확인 뒤 감시 셸이 umask 022 로 만든다 · 링크 = 멈춤).  시도 4: 풀이를 시작한 시도 3 의 DONE 정확히 하나 · 풀이 코드 목록 같음 · 저장본 = 시도 3 meta `store_listing_after` (이름 · sha256).  끝난 뒤 번호의 시도가 있으면 앞 번호는 띄우지 않는다 (예: 끝난 시도 3 뒤 시도 2 = 멈춤).  graft · shallow 이력 (`GIT_GRAFT_FILE` · `GIT_SHALLOW_FILE` · `info/grafts` · 얕은 복제) = 조상 대조를 믿을 수 없어 멈춤 → kgy · gabia 현장에서 `git rev-parse --is-shallow-repository` 가 false 인지 먼저 본다 (true 면 `git fetch --unshallow`).  감시 셸의 git 읽기는 저장소 고르는 `GIT_*` 를 지우고 `GIT_NO_REPLACE_OBJECTS=1` 로 한다 (러너도 물려받는다).
- **핀 칸** — 줄을 넣은 커밋 (이 묶음) 이후 발사 직전 가지 끝이 핀이다 (블록이 PIN = 가지 끝을 본다).  시도 4 의 핀 = 시도 3 의 핀이거나 풀이 코드가 같은 뒤 커밋.  **두 시도 사이 커밋** — 시도 4 가 끝날 때 (DONE) 까지 풀이 코드 목록의 경로 (scripts/ 통째 · 탐침 도구 폴더 · S0 단계 1 자료) 를 바꾸는 커밋을 가지에 올리지 않는다 (시도 1 · 2 와 같은 규칙).
- **블록** — `docs/reviews/rint2_probe6_prep_20261110/KGY_BLOCK.md` 는 시도 1 · 2 꼴 그대로다.  시도 3 · 4 의 붙여 넣을 블록은 발사 전에 이 줄의 핀으로 새로 만든다 (본 세션 · 1저자 · 이 묶음 밖).
- **한정** — 시도 3 · 4 가 한도에 닿아 팔이 거부되면 audit 곁 파일은 킷 런 폴더에 남고 (러너는 받아들인 팔의 것만 옮긴다) 판독기는 출력 폴더만 보므로 rc 4 (저장본 기록 없음) 로 끝난다 — 미수렴과 저장본 결함을 판독기 rc 로 가르지 못한다 (러너 로그 · 킷 런 폴더를 본다).

## 4. 한정

- 이 원장은 원장 안 시도끼리만 막는다 (Q9 §3-5 한정과 같다) — 원장 밖에서 돈 그림자 런을 기계적으로 막지는 못한다 (규칙이지 기계적 보장이 아니다).
- S0 단계 1 의 "새 SV 계약이 모두 닫혔다" 는 결론을 이 탐침에서 뽑지 않는다 (Codex §10).

## 5. ⑦ SBE 물리 확인 탐침 (개발 자료 · 값 열람) — 1저자 11-03 밤 Q7 *"권고대로"* · 결과 0 건 · 결과 전 등록

- 지위 = **결과 0 건** · 첫 ⑦ 시도 전에 이 절을 커밋했다 (결과 전 등록 = 사후 선택 아님).  아래 ⬜ 칸은 첫 시도 전에 채워 다시 커밋한다.
- 무엇 — 실침대 SBE 에서 v0 모형의 물리 크기 (σ_e · 개발용 R_j,0 · 접합 소산 몫 · 전달 길이 ↔ 접촉 길이 · 문헌 상식 띠) 를 **열어 보는** 개발 탐침.  ⑥ 은 σ 를 봉인하지만 ⑦ 은 SBE 값을 연다 — 그래서 판정 · 보정 · 예측에 쓰지 않고, 결과를 보고 모형을 바꾸지 않는다 (§5-2 금지).
- 순서 = S0 단계 1 → s_min 개발 → ⑥ (σ 봉인) → **⑦**.  ⑦ 은 **Codex 회차 ② 답이 "열어도 된다" 일 때만** 실행한다 (요청서 `docs/reviews/codex_rint2_rr_round2_request_20261103.md` §11 Q10) — 답 전 · "안 된다" 이면 0 건 그대로.
- (11-05 · Codex 회차 ② 판정문 `docs/reviews/codex_review_rint2_rr_round2_20261105.md` §10 · 수정 계획 `docs/reviews/rint2_rr2_fix_plan_20261105.md` Q7 (가) · 1저자 11-05 *"권고대로"*) **⑦ = 숫자 봉인 뒤에만** — S0 단계 1 → s_min → ⑥ → 기하 · 반복 수 → 숫자 · 실행 정책 봉인 → ⑦ (결과 민감 빈칸 — 점 수 상한 · 역상 폭 상한 · SV 문턱 · 등급 관련 값 · 실행 정책 — 을 ⑦ 을 본 뒤 처음 고르는 길을 처음부터 없앤다 · 이 절의 나머지 규칙 그대로).

### 5-1. 규칙 (⑥ 의 일곱 칸 꼴)

| 칸 | 규칙 |
|---|---|
| 허용 입력 | SBE 새 침대 (VGCF E 100 GPa 재압밀 · 10-23 · `docs/data/rint2_recompaction_vgcf100_20261023/README.md`) 만.  **DBE 입력 · DBE 결과 금지** (맹검 유지 · DBE 4.68 비교 = 등록 캠페인 판정에서 한 번 · 등록 R §1). |
| 열어 보는 것 | ① R_j,0 사다리 점마다 SBE σ_e ② SBE 1.63 mS/cm 에 맞춘 개발용 R_j,0 (법칙 P0 · P1 마다 · 개발값 표지) ③ 접합 소산 몫 (`scripts/carbon_junction.py` `dissipation_share` 의 `vv_junction`) ④ 모델 전달 길이 λ_model = √(R_j,0·L_par/(r′_i + r′_j)) ↔ S0 L_c 분포 (L_c > λ_model · > 2λ_model 인 instance 수 · 원장 `RINT2-L01` 의 닫는 조건과 같은 양 — 단 ⑦ 값은 개발 자료라 그 항목을 닫지 않는다) ⑤ R_j,0 ↔ 문헌 상식 띠 (등록 R §8 11-03 표 · `litdb-canon:fuhrer2000_crossed_nanotube_junctions` · `litdb-canon:nirmalraj2009_swcnt_network_junction_resistance` · `litdb-canon:hamasaki2022_single_parallel_contact_mwcnt_conductivity` · 비동치 문장 *"R_j,0 = 모형 내부 보정값 · CNT 계 접합 값과 같은 양이 아니다"* 를 함께 · 등록 R §7-2 11-03 금지 문장 그대로). |
| 핀 | 시도마다 코드 커밋 sha 를 원장에 적는다 · 봉인 핀과 다르면 개발 자료 · **등록 캠페인의 보정은 봉인 핀에서 다시 한다** (⑦ 의 개발 R_j,0 를 가져다 쓰지 않는다). |
| 기계 / 환경 | ⑥ 과 같다 (기계 이름 · 전체 환경 지문 — Python · numpy · scipy · GPU · CUDA · BLAS). |
| 시도 | ⑥ 과 같다 (시도 하나 = 원장 한 줄 · 번호 = 이 원장 · 시작 전에 줄을 커밋 · "가장 좋은 시도" 를 고르지 않는다 · 모든 시도를 보고). |
| 실패 보존 | ⑥ 과 같다 (폴더 바이트 그대로 · 폴더 요약 sha256). |
| 금지 | ⑦ 결과를 보고 v0 모형 · 법칙 · 값 (길이 법칙 · 분산판 · 시나리오 끝 P · c · R_j,0 사다리 · 문턱 · 등급 · 금지 문장) 을 바꾸지 않는다.  **예외 = 독립 근거가 있는 버그 고침뿐** — 원장 `docs/reviews/findings.json` 에 따로 항목을 열고 §5-3 표에 적는다 (근거 = ⑦ 값이 아닌 독립 시험 · 코드 읽기).  ⑦ 값은 판정에 쓰지 않는다. |

### 5-2. 시도 원장 (⑦)

| 번호 | 시작 (KST) | 명령 줄 | 핀 | 기계 · 환경 | 결과 (① σ_e 사다리 · ② 개발 R_j,0 · ③ 소산 몫 · ④ λ_model ↔ L_c · ⑤ 띠) | 폴더 sha256 |
|---|---|---|---|---|---|---|
| — | ⬜ | ⬜ (Codex 회차 ② 답 뒤 · 명령 꼴 = 등록 R §10-1 의 사다리 명령 · 값 열람 출력) | ⬜ | ⬜ | — (결과 0 건) | — |

### 5-3. 버그 고침 예외 기록 (⑦ 뒤 · 독립 근거가 있을 때만)

| 날짜 | 원장 항목 | 독립 근거 | 고친 커밋 |
|---|---|---|---|
| — | — | — | — (0 건) |

### 5-4. 한정

- 개발 자료 · **n = 1 침대 (SBE)** · 사후 선택 아님 (이 절 = 결과 전 등록 · 11-03 밤).
- ⑦ 의 SBE 맞춤 R_j,0 = 개발값 — 등록 R §3 의 보정 사다리 · 확인 · 식별 규칙을 그 판 그대로 거치지 않았으면 그 사실을 함께 적는다 · 등록 캠페인 판정 · 보정 · 예측에 쓰지 않는다.
- ⑦ 은 DBE 를 보지 않으므로 SV (SDCP–VGCF) 우회 · DBE 예측에 대해 아무것도 말하지 않는다 · 원장 안 시도끼리만 막는다 (§4 와 같다).

# V_S3.md 문제 1–15 → S3_mpm_contact_2d3d_handoff_limits.md
V = 'V_S3'
D = 'S3'
PYC = 'pycompact2025_dem_mpfem_workflow'

ROW30_END = '[b01 · bardenhagen2000 ↔ bardenhagen2001 (두 카드) · 2000 §3-1 (L92–93) · 2001 §4-1 (L106–107) · §7 Fig 1 행 (L268)] |\n\n## 빈 곳'
ROW31 = ('| ㉛ | Lee 2024 식 38 (τ = −11.7·ε_SE + 8.54) 의 출처 | otani2025 카드: 출처 = Otani 2023 (ref46) '
         '| lee2024 카드 (정정 2026-10-13): Otani 2023 원문에 이 선형식 없음 · 귀속 [미확인] '
         '| [b11 · otani2025_dem_se_dispersion_aggregation_compression · §0 (L25–32)] '
         '[b14 · lee2024_multiphysics_dem_fem_initial_pressure_assb · §1 L22–23 · §4.1 L98–113 · §4.3 L158 · L163–166 · Fig 1] |')

EDITS = [
    # ── 문제 1 · H-1 · 어긋남 ④
    dict(doc=D, v=V, num=1, item='H-1 (넘긴 시점)', kind='값 다름 · 표지 다름 (카드 기준)', line=r'^\| H-1 \|',
         old='· 압축 (기공 41 → 4 %) 은 100 % MPFEM (stated · b02)',
         new='· 압축 (기공 ≈42–43 → ≈3–4 %) 은 100 % MPFEM (digitized 2026-11-11 · 카드 §4.2 L170–172 · 묶음 b02 의 \'41 → 4 % (stated)\' 는 카드가 옛 표기로 돌린 값)',
         note='카드 대조: pycompact2025 §4.2 L170–172 "≈42–43 % 에서 ≈3–4 % (digitized 2026-11-11 · 옛 표기 41 → 4 %)" 맞음'),
    dict(doc=D, v=V, num=1, item='어긋남 ④ (한쪽)', kind='값 다름 · 표지 다름 (카드 기준)', line=r'^\| ④ \|',
         old='| b02: 압축 (기공 41 → 4 %) 은 100 % MPFEM (stated) |',
         new='| b02: 압축 (기공 41 → 4 %) 은 100 % MPFEM (stated) — 정본 카드 §4.2 L170–172 는 이를 \'옛 표기\' 로 돌리고 ≈42–43 → ≈3–4 % (digitized 2026-11-11) 로 고침 |',
         note='같은 카드 줄'),
    # ── 문제 2 · H-7 + 어긋남 ㉛ + 셈
    dict(doc=D, v=V, num=2, item='H-7 (한계)', kind='철회 출처 · 어긋남 누락', line=r'^\| H-7 \|',
         old='· τ 식 계보 = Otani 2023 (다른 카드 기록)',
         new='· τ 식 (식 38) 귀속 = [미확인] — otani2025 카드 (§0 L25–32) 는 \'Otani 2023 ref46\' 으로 적으나 lee2024 카드가 2026-10-13 에 그 귀속을 정정 (Otani 2023 원문에 이 식 없음) · 어긋남 ㉛',
         note='카드 대조: lee2024 L165–166 (정정 2026-10-13) · otani2025 L25–27 맞음'),
    dict(doc=D, v=V, num=2, item='어긋남 ㉛ (새 행)', kind='철회 출처 · 어긋남 누락', multiline=True, cells_change=True,
         old=ROW30_END,
         new=ROW30_END.replace('\n\n## 빈 곳', '\n' + ROW31 + '\n\n## 빈 곳'),
         note='검증이 준 새 행 그대로 (칸 구분 "∣" → "|") · 꼬리 둘은 H-7 의 꼬리에 이미 있는 위치'),
    dict(doc=D, v=V, num=2, item='읽은 범위와 셈 (어긋남 개수)', kind='철회 출처 · 어긋남 누락',
         old='- 어긋남 30 · 빈 곳 19.',
         new='- 어긋남 31 (㉛ = 검증 뒤 더한 행) · 빈 곳 19.',
         note='어긋남 행을 더해 개수를 맞춤'),
    # ── 문제 3 · J-3
    dict(doc=D, v=V, num=3, item='J-3', kind='카드에 없음 (따옴표 앞 절반)', line=r'^\| J-3 \|',
         old='Bardenhagen 2005: "Effects due to including more realistic models, such as viscoelasticity for polymeric foams, plasticity for metallic foams, and frictional sliding contact, will be studied later."',
         new='Bardenhagen 2005: "viscoelasticity for polymeric foams, plasticity for metallic foams, and frictional sliding contact, will be studied later" (p.601 · 카드 L6 — 묶음 b41 의 앞 절 \'Effects due to including more realistic models, such as\' 는 정본 카드에 없음 [미확인])',
         note='카드 대조: bardenhagen2005 L6 의 따옴표와 글자 같음 · "Effects" · "realistic models" 는 카드에 0 회'),
    # ── 문제 4 · 요지 1
    dict(doc=D, v=V, num=4, item='요지 1', kind='표지 빠짐 ([미확인])',
         old='검증은 경사면 · 전단 · 응력파 원판 (2D) 과 구 1 개 (3D) · 압밀 없음 (F-5 · F-6 · J-1).',
         new='검증은 경사면 · 전단 (2D) · 광탄성 응력파 원판 (실험 = 평면응력 원판 · 시뮬 차원 [미확인]) 과 구 1 개 (3D) · 압밀 없음 (F-5 · F-6 · G-1 · J-1).',
         note='카드 대조: bardenhagen2001 L139 "광탄성 시뮬의 차원 (2D/3D) [미확인]" 맞음'),
    # ── 문제 5 · G-16
    dict(doc=D, v=V, num=5, item='G-16', kind='따옴표 다름 (낱말 더함)', line=r'^\| G-16 \|',
         old="'the 2D model expected to correctly capture trends in stress and fracture'",
         new="'2D model expected to correctly capture trends in stress and fracture'",
         note='카드 대조: bucci2017 L214 — "the" 없음'),
    # ── 문제 6 · F-41
    dict(doc=D, v=V, num=6, item='F-41 (어떻게 정했나)', kind='표지 빠짐', line=r'^\| F-41 \|',
         old='| 해석해 · 기지값 · 다른 방법 교차 · Huang 해상도 확인은 한 경우뿐 · 열만 |',
         new='| 해석해 · 기지값 · 다른 방법 교차 · Huang 해상도 확인은 한 경우뿐 · 열만 (표지: Cooper = stated (규칙) · 우리 재계산 (해석해 값) / Ketter = SD · derived(ours) · stated / Malifarge = 우리 재계산 / Morasch = 파생 (카드 검산) / Hlushkou = stated · 판독 (Fig S1) / Nguyen 2020 = stated(그림) · stated · 내 검산 / Huang · Song = stated / Wiedenmann = stated · 우리 산술 (대표 부피 비)) |',
         note='묶음 대조: synth2/q_f L143 · L168 · L159 · L178 · L296 · L195 · L330 의 표지 칸과 같음'),
    # ── 문제 7 · F-45
    dict(doc=D, v=V, num=7, item='F-45 (어떻게 정했나)', kind='표지 빠짐', line=r'^\| F-45 \|',
         old='| 두 해상도 대조 · 특징 크기 대비 판정 · 카드 판정 |',
         new='| 두 해상도 대조 · 특징 크기 대비 판정 · 카드 판정 (표지: Tjaden = stated / Yoo = 표지 없음 / Xu = stated · digitized / Zhang 2026 = stated / 카드 풀이 / Lee 2025 = 표지 없음 (카드 판정) / Kang 2025 = stated) |',
         note='묶음 대조: synth2/q_f L193 · L204 · L128 · L203 · L238 · L230 의 표지 칸과 같음'),
    # ── 문제 8 · 요지 8
    dict(doc=D, v=V, num=8, item='요지 8', kind='넓게 말함',
         old='넘긴 직후 겹침 · 평형 처리는 둘 다 적지 않음 (H-1 · H-3 · H-4 · 빈 곳 ㅌ).',
         new='넘긴 직후 겹침 · 평형 처리 = PyCompact 원문에 문장 없음 ([미확인]) · Demirtas 는 이 묶음 · 카드에 근거 없음 (H-1 · H-3 · H-4 · 빈 곳 ㅌ).',
         note=''),
    # ── 문제 9 · 빈 곳 ㅎ
    dict(doc=D, v=V, num=9, item='빈 곳 ㅎ', kind='값 다름 (카드 기준)', line=r'^\| ㅎ \|',
         old='(Demirtas < 2000 · PyCompact 569)',
         new='(Demirtas < 2000 · PyCompact 403–1033 입자 (카드 Table 1 · §15.6 — 비교 문서 표기는 569))',
         note='카드 대조: pycompact2025 L356 (Table 1 · 569 / 874 / 1033) · L968 (§15.6 "403–1033 입자") 맞음'),
    # ── 문제 10 · 요지 10
    dict(doc=D, v=V, num=10, item='요지 10', kind='넓게 말함',
         old='· 실험은 in-die 위주 ·',
         new='· 실험은 감압 쪽 자료가 적음 (Faka · Lee 2025 = in-die 만 · Heck = 되튐은 재나 같은 시료 in-die ↔ out-of-die 대조 없음) ·',
         note='카드 대조: heck2026 L19 · L24 (무구속 펀치 springback 6.7 → 10.4 % · in-die 감압) 과 맞음'),
    # ── 문제 11 · H-12
    dict(doc=D, v=V, num=11, item='H-12', kind='표지 빠짐 (가벼움)', line=r'^\| H-12 \|',
         old='· 저자 귀속 "예측 위치가 서로 너무 가까워 겹침 → 입자간 힘 불균형 → 내부 충돌"',
         new='· 저자 귀속 (카드의 한국어 옮김) "예측 위치가 서로 너무 가까워 겹침 → 입자간 힘 불균형 → 내부 충돌"',
         note='묶음 대조: synth2/q_h L187 "카드가 옮긴 저자 귀속" · 표지 "stated (한국어 옮김)"'),
    # ── 문제 12 · G-21
    dict(doc=D, v=V, num=12, item='G-21', kind='재료 빠짐 (가벼움)', line=r'^\| G-21 \|',
         old='Bouvard 2000: Delie & Bouvard [14] 변형 계산은 2D 정사각 배열 ("2D 주기배열, 진짜 morphology 아님") · 실험은 3D 라 percolation 임계 수치 (0.32 등) 는 "직접 참조 가능"',
         new='Bouvard 2000 (금속 + 세라믹): Delie & Bouvard [14] 변형 계산은 2D 정사각 배열 ("2D 주기배열, 진짜 morphology 아님") · 실험은 3D 라 percolation 임계 수치 (0.32 등 · 단분산 구 패킹 수치모사) 는 "직접 참조 가능"',
         note='카드 대조: bouvard2000 L32 "percolation 임계분율 (mono, r=1) f_hard = 0.32 … 수치모사" · 묶음 q_g L30 한계 "금속 + 세라믹" 맞음'),
    # ── 문제 13 · J-71
    dict(doc=D, v=V, num=13, item='J-71', kind='표지 빠짐 (인용 금지 표지 · 가벼움)', line=r'^\| J-71 \|',
         old='70 MPa 에선 PVDF 142 > PPMA 131 mAh/g 역전 · 조성 교란 (90:10 vs 97:3)',
         new='70 MPa 에선 PVDF 142 > PPMA 131 mAh/g 역전 · "PPMA가 항상 우월" 은 카드 \'인용 금지\' · 조성 교란 (90:10 vs 97:3)',
         note='묶음 대조: synth2/q_j L300 과 같음'),
    # ── 문제 14 · F-17
    dict(doc=D, v=V, num=14, item='F-17', kind='표지 빠짐 (가벼움)', line=r'^\| F-17 \|',
         old='(Bardenhagen 2005 · 3D · GIMP · 탄성)',
         new='(Bardenhagen 2005 · 3D ([카드 판독]) · GIMP · 탄성)',
         note='묶음 대조: synth2/q_g L307 표지 [카드 판독]'),
    # ── 문제 15 · H-1 꼬리
    dict(doc=D, v=V, num=15, item='H-1 (출처 칸 끝)', kind='꼴 (꼬리 위치 · 가벼움)', line=r'^\| H-1 \|',
         old='[layer3 · ' + PYC + ' · §F L3732–3737] |',
         new='[layer3 · ' + PYC + ' · §F L3732–3737] [b42 · ' + PYC + ' · 카드 §4.7 (마)(바)] |',
         note='카드 대조: pycompact2025 §4.7 (마) L302 · (바) L317 있음'),
    # ── 머리 한정 줄
    dict(doc=D, v=V, num='머리', item='한정 줄', kind='한정 (지시서)', multiline=True,
         old='(정독 종합 · 질문 f · g · h · j)\n\n',
         new='(정독 종합 · 질문 f · g · h · j)\n\n'
             '한정 (2026-11-12): 검증 = 표본 (넷에 하나 + 따옴표 · 서지 전부) · 문제 비율 = 문제 15 / 본 항목 65 (전체 항목 193 · 표본 65 = F 12 · G 6 · J 25 (넷에 하나) + H 22 (전부) · 숫자 = V_S3.md 셈) · 표본 밖 항목은 대조하지 않았다 · 이 판은 검증 표의 "고칠 글" 을 적용한 뒤다 (기록 = APPLIED.md).\n\n',
         note='숫자는 V_S3.md 셈 절에서만'),
]

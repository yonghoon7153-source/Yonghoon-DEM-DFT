#!/bin/bash
# G″ = G″a 나무 + README v2.1 + G″a 결과 증거 → 64e4d213e 위 한 커밋 · 그 위 다시 잼 · 묶음 (scratch 사본 안 git 만)
set -euo pipefail
SCR=/tmp/claude-0/-home-user-Yonghoon-DEM-DFT/81c0ad95-542f-503b-9cf7-2f6a678a4b5b/scratchpad; V21=/tmp/claude-0/-home-user-Yonghoon-DEM-DFT/81c0ad95-542f-503b-9cf7-2f6a678a4b5b/scratchpad/rint/seal_candidate_v2_1; W=/tmp/claude-0/-home-user-Yonghoon-DEM-DFT/81c0ad95-542f-503b-9cf7-2f6a678a4b5b/scratchpad/rint/seal_candidate_v2_1/work; C=$SCR/rint/v21_clone; O=$W/evG2a; D=$C/docs/reviews/rint2_seal_20261120; E=$V21/evidence; ET=$SCR/rint/v21_exist
PIN=64e4d213e8267bafaf3ae5af00a42996cefd3f33; CL=2da71fe5abbaa856beb87c39c2a49424e4c87bc7; GA=$(cat $W/G2a.sha); GP=bea3cb33a4bdfbe1009866b53ef5f3aacb466802
SR=docs/reviews/rint2_seal_20261120/registration_R_sealed.md; PL=docs/data/rint2_r_plan_20261120/ca1_plan.json
test "$(git -C $C rev-parse HEAD)" = "$GA"
bash $W/stage_raw.sh
rm -rf $W/evidence_commit; python3 -I $E/tools/make_committed_evidence.py $W/raw_commit $W/evidence_commit $C/docs/reviews/claims.json > $W/make_committed_evidence.txt
python3 -I $W/fill_readme_v21.py $V21/README.md $O > $W/fill_readme.txt
! grep -n "@@" $V21/README.md
cp $V21/README.md $D/README.md
find $D/evidence -maxdepth 1 -type f -delete
cp $W/evidence_commit/* $D/evidence/
find $E -maxdepth 1 -type f -delete; cp $W/evidence_commit/* $E/
cd $C
git add -A
git -c user.name=scratch -c user.email=scratch@invalid -c commit.gpgsign=false commit -q -m "scratch G2 prep"
T=$(git rev-parse 'HEAD^{tree}')
G2=$(git -c user.name=scratch -c user.email=scratch@invalid commit-tree "$T" -p $PIN -m "scratch seal-form commit G2 (seal candidate v2.1 · internal rebuttal review fixes · README/evidence with G2a results · NOT for push)")
git update-ref refs/heads/seal-form-scratch "$G2"
echo "$G2" > $W/G2.sha
H=$G2
{ echo "# G″a $GA → G″ $G2 (부모 $(git rev-parse "$G2^"))"; git diff --name-status "$GA" "$G2"; echo "## 봉인 기록 폴더 README · evidence 결과 파일 밖 차이: $(git diff --name-only "$GA" "$G2" | grep -vc '^docs/reviews/rint2_seal_20261120/\(README.md\|evidence/[^/]*\)$' || true)";
  echo "## G′ $GP → G″ (name-status 셈)"; git diff --name-status "$GP" "$G2" | awk '{print $1}' | sort | uniq -c; echo "## G′ ↔ G″ 파일 목록 같음: $(test "$(git ls-tree -r --name-only $GP | sort | sha256sum)" = "$(git ls-tree -r --name-only $G2 | sort | sha256sum)" && echo 예 || echo 아니오)";
  echo "## git diff --stat G′ G″"; git diff --stat "$GP" "$G2" | cat; } > $E/raw/G2b_diff.txt
rm -rf $ET; python3 -I $SCR/rint/seal_candidate_v2_review/repro/h_docrefs/make_exist_tree.py $C HEAD $ET > /dev/null
{ echo "# HEAD $H (G″ · 존재 나무 · 원격 추적 ref $(git for-each-ref refs/remotes | wc -l))"; ( cd $ET && python3 -I $C/scripts/check_doc_refs.py --root $ET ); echo "rc=$?"; } > $E/raw/G2b_check_doc_refs.txt 2>&1 || true
rm -rf $ET
{ echo "# HEAD $H (G″ · claims.json = 원격 stoic 2da71fe5a 판) · $(python3 -V)"; python3 -I $E/tools/check_ban_new_text.py $C $PIN HEAD $CL; echo "rc=$?"; } > $E/raw/G2b_ban_new_text.txt 2>&1 || true
{ echo "# HEAD $H (G″)"; python3 -I $E/tools/check_seal_files.py $C $PIN HEAD; echo "rc=$?"; } > $E/raw/G2b_seal_files.txt 2>&1 || true
rm -rf $W/fh_G2b; { echo "# HEAD $H (G″)"; python3 -I $E/tools/check_sh_commands.py $C $SR $W/fh_G2b --expect sealed=13+1,kgy=14+1; echo "rc=$?"; } 2>&1 | sed "s#$SCR#<scratch>#g" > $E/raw/G2b_sh_commands.txt || true; rm -rf $W/fh_G2b
{ echo "# HEAD $H (G″)"; python3 -I scripts/rint_r_chain.py --stage plan-doc --plan $PL --check-doc --registration $SR; echo "rc=$?"; python3 -I scripts/rint_r_chain.py --stage plan-doc --plan $PL --check-doc; echo "rc=$? (기본 = 원본 자리)"; } > $E/raw/G2b_plan_doc.txt 2>&1 || true
{ echo "# HEAD $H (G″) · check_chain_functions.py <사본> 20261120"; python3 -I $E/tools/check_chain_functions.py $C 20261120 | tail -2; } > $E/raw/G2b_chain_functions.txt 2>&1 || true
echo "status 줄 $(git status --porcelain --untracked-files=all | wc -l)" > $E/raw/G2b_status_lines.txt
rm -f $V21/seal_form_G2_20261117.bundle
git bundle create $V21/seal_form_G2_20261117.bundle seal-form-scratch ^$PIN 2> $W/bundle_create.txt
{ echo "# git bundle verify (사본 안 · 필요한 커밋 = 64e4d213e)"; git bundle verify $V21/seal_form_G2_20261117.bundle 2>&1; echo "rc=$?"; git bundle list-heads $V21/seal_form_G2_20261117.bundle; sha256sum $V21/seal_form_G2_20261117.bundle | sed "s#$SCR#<scratch>#"; } > $E/raw/G2b_bundle.txt 2>&1 || true
echo "G2=$G2"

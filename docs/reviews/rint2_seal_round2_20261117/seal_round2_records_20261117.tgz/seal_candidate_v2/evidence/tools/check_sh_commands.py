#!/usr/bin/env python3
"""봉인 꼴 트리의 두 문서 (봉인본 · kgy 명령 문서) ```sh 블록 명령을 사슬 · S0 argparse 로 대조 — 리포 무변경 · 결과 0 건 · σ 없음 · 단계 함수 = 받기만.

argv: <봉인 꼴 트리 (scripts · docs)> <봉인본 리포 상대 자리> <가짜 홈 (없어야)>
방법 = 봉인 후보 v1 `evidence/tools/apply_and_check.py` (시험 K01 과 같은 꼴: 자리표 <…> → '1' · `\\` 이음 · 주석 줄 뺌 · && | ; 로 가름 ·
단계 함수 · S0 `verify_plan_commit` 를 바꿔 끼워 argparse 만) + `~/` → 가짜 홈 (저장본 폴더 = 실제 0755 폴더) + 값 대조:
  · 사슬 명령마다 `--registration` = <가짜 홈>/dem-ca1/<봉인본> · S0 단계 2 마다 `--r-doc` = <봉인본> (리포 상대 그대로)
  · 사다리 · 단위 · 점 = 원장 시도 꼴 + 저장본 · 합치기 = --attempt · --cjunc-store 없음 · 사다리 · 예측 (dry 뺌) --max-hours 168 · --machine ∈ 허용 목록
  · 종류마다 두 문서의 인자 이름 집합이 같다 (한 문서에만 있는 종류 = 보고)
"""
import contextlib
import io
import json
import os
import re
import shlex
import sys
from pathlib import Path

TREE, SEALED_REL, FAKEHOME = sys.argv[1:4]
assert not os.path.exists(FAKEHOME), FAKEHOME
sys.path.insert(0, str(Path(TREE) / 'scripts'))
import rint_r_chain as RR  # noqa: E402
import ca_s0_census as S0m  # noqa: E402

DOCS = (('sealed', Path(TREE) / SEALED_REL), ('kgy', Path(TREE) / 'docs/reviews/rint2_kgy_commands_20261020.md'))
fh = Path(FAKEHOME)
(fh / 'ca1_cjstore').mkdir(parents=True)
os.chmod(fh / 'ca1_cjstore', 0o755)
REG_ABS = str(fh / 'dem-ca1' / SEALED_REL)
_SPLIT = re.compile(r'\s(?:&&|\|\||\||;)\s')
ALLOWED = ('kgy', 'gabia', 'v100')


def sh_commands(path, tool):
    out, inb, buf, start = [], False, '', 0
    for i, ln in enumerate(Path(path).read_text(encoding='utf-8').splitlines(), 1):
        s = ln.strip()
        if s.startswith('```'):
            inb, buf = (not inb) and s == '```sh', ''
            continue
        if not inb:
            continue
        if not buf:
            if not s or s.startswith('#'):
                continue
            start = i
        cont = s.endswith('\\')
        buf += ' ' + (s[:-1] if cont else s)
        if cont:
            continue
        line, buf = re.sub(r'<[^<>]*>', '1', buf), ''
        for seg in _SPLIT.split(line):
            if tool not in seg:
                continue
            toks = shlex.split(seg, comments=True)
            at = [k for k, t in enumerate(toks) if t.endswith('/' + tool) and k > 0 and re.search(r'(^|/)python3?$', toks[k - 1])]
            if not at:
                continue
            args, skip = [], False
            for t in toks[at[0] + 1:]:
                if skip:
                    skip = False
                    continue
                if t == '>':
                    skip = True
                    continue
                if re.match(r'^\d*>', t) or t == '&':
                    continue
                args.append(t.replace('~/', str(fh) + '/') if t.startswith('~/') else t)
            out.append((start, args))
    return out


class _Took(Exception):
    pass


got = {}


def _stub(a, contract=None):
    got['a'] = a
    return 0


def _vpc(*_a, **_k):
    raise _Took()


saved = {k: getattr(RR, k) for k in ('stage_ladder', 'stage_predict', 'stage_verdict', 'stage_ledger', 'stage_recover', 'stage_plan_doc')}
saved_vpc = S0m.verify_plan_commit
for k in saved:
    setattr(RR, k, _stub)
S0m.verify_plan_commit = _vpc
kinds, bad, counts, regvals = {}, [], {}, {}
try:
    for dn, path in DOCS:
        cmds = sh_commands(path, 'rint_r_chain.py')
        counts[dn] = {'rint_r_chain': len(cmds)}
        for ln, args in cmds:
            got.clear()
            err = io.StringIO()
            try:
                with contextlib.redirect_stderr(err), contextlib.redirect_stdout(io.StringIO()):
                    rc = RR.main(args, contract=object())
            except SystemExit as e:
                rc = f'argparse rc {e.code} · {(err.getvalue().strip().splitlines() or [""])[-1][:160]}'
            if rc != 0 or 'a' not in got:
                bad.append(f'{dn}:{ln} {args[:2]} → {rc}')
                continue
            a = got['a']
            if a.stage == 'predict':
                k = 'unit' if a.unit else 'point' if a.point else ('merge_x' if a.expand else 'merge') if a.merge else 'predict'
            elif a.stage == 'ledger':
                k = 'ledger_init' if a.init else 'ledger_add'
            elif a.stage == 'verdict':
                k = 'reverify' if a.reverify else 'verdict'
            elif a.stage == 'ladder':
                k = 'ladder_dry' if a.dry_run else 'ladder'
            else:
                k = a.stage
            opts = frozenset(t for t in args if t.startswith('--') and t != '--machine')
            kinds.setdefault((dn, k), set()).add(opts)
            regvals.setdefault(dn, set()).add(a.registration)
            if '--registration' not in args or a.registration != REG_ABS:
                bad.append(f'{dn}:{ln} {k} --registration = {a.registration!r} (≠ 봉인본 {REG_ABS!r})')
            if k in ('ladder', 'unit', 'point') and not (a.ledger and a.attempt is not None and a.cjunc_store):
                bad.append(f'{dn}:{ln} {k} = 원장 시도 꼴 + 저장본이 아니다')
            if k in ('merge', 'merge_x') and (a.attempt is not None or a.cjunc_store):
                bad.append(f'{dn}:{ln} {k} 에 --attempt · --cjunc-store')
            if a.stage in ('ladder', 'predict') and a.max_hours != 168.0:
                bad.append(f'{dn}:{ln} --max-hours {a.max_hours}')
            if a.machine is not None and a.machine not in ALLOWED:
                bad.append(f'{dn}:{ln} --machine {a.machine}')
        s0 = sh_commands(path, 'ca_s0_census.py')
        counts[dn]['ca_s0_census'] = len(s0)
        for ln, args in s0:
            stage = args[args.index('--stage') + 1] if '--stage' in args[:-1] else None
            if stage != '2':
                bad.append(f'{dn}:{ln} S0 명령 --stage {stage}')
                continue
            err = io.StringIO()
            try:
                with contextlib.redirect_stderr(err), contextlib.redirect_stdout(io.StringIO()):
                    rc = S0m.main(args)
                bad.append(f'{dn}:{ln} S0 단계 2 → rc {rc} (관문 앞 인자 검사) · {(err.getvalue().strip().splitlines() or [""])[-1][:160]}')
                continue
            except _Took:
                pass
            except SystemExit as e:
                bad.append(f'{dn}:{ln} S0 단계 2 → argparse rc {e.code}')
                continue
            rdoc = args[args.index('--r-doc') + 1] if '--r-doc' in args[:-1] else None
            if rdoc != SEALED_REL:
                bad.append(f'{dn}:{ln} S0 단계 2 --r-doc = {rdoc!r} (≠ {SEALED_REL!r})')
            kinds.setdefault((dn, 's0-2'), set()).add(frozenset(t for t in args if t.startswith('--')))
finally:
    for k, v in saved.items():
        setattr(RR, k, v)
    S0m.verify_plan_commit = saved_vpc
print('# 봉인본', SEALED_REL, '· 가짜 홈 =', '<가짜 홈>')
for dn, c in counts.items():
    print(f'{dn}: sh 블록 사슬 명령 {c["rint_r_chain"]} · S0 명령 {c["ca_s0_census"]} · --registration 값 {sorted(v.replace(str(fh), "<가짜 홈>") for v in regvals.get(dn, set()))}')
allk = sorted({k for _d, k in kinds})
for k in allk:
    r, g = kinds.get(('sealed', k), set()), kinds.get(('kgy', k), set())
    same = (r == g) if r and g else None
    print(f'  {k:12s} 봉인본 {len(r)} 집합 · kgy {len(g)} 집합 · 두 문서 같음 {same}' + (f' · 인자 {sorted(next(iter(r or g)))}' if (r or g) else ''))
    if r and g and r != g:
        bad.append(f'{k}: 두 문서 인자 이름 다름 — 봉인본 {sorted(sorted(x) for x in r)} ↔ kgy {sorted(sorted(x) for x in g)}')
only = [k for k in allk if bool(kinds.get(('sealed', k))) != bool(kinds.get(('kgy', k)))]
print('한 문서에만 있는 종류', only)
print('문제', json.dumps(bad, ensure_ascii=False) if bad else '없음')
sys.exit(1 if bad else 0)

#!/usr/bin/env python3
"""종합 문서의 줄을 찾아 칸 단위로 보여 준다 (읽기 전용).

  show.py <문서 접두 (S1 · S6_2 …)> <정규식> [--max N] [--raw] [--width W]
"""
import glob
import os
import re
import sys

OUT = '/tmp/claude-0/-home-user-Yonghoon-DEM-DFT/d26d1e75-209f-540f-83a8-c0e1957edc2f/scratchpad/handoff_litread_20261112/litread/synth/out'


def path_of(prefix):
    c = sorted(glob.glob(os.path.join(OUT, prefix + '_*.md')))
    if len(c) != 1:
        raise SystemExit('문서 못 찾음: %s %s' % (prefix, c))
    return c[0]


def split_cells(line):
    # '\|' 는 칸 구분이 아니다
    parts = re.split(r'(?<!\\)\|', line)
    return parts


def main():
    a = sys.argv[1:]
    prefix, pat = a[0], a[1]
    mx = 5
    raw = False
    width = 0
    i = 2
    while i < len(a):
        if a[i] == '--max':
            mx = int(a[i + 1]); i += 2
        elif a[i] == '--raw':
            raw = True; i += 1
        elif a[i] == '--width':
            width = int(a[i + 1]); i += 2
        else:
            raise SystemExit('모르는 인자 ' + a[i])
    rx = re.compile(pat)
    n = 0
    for ln, line in enumerate(open(path_of(prefix), encoding='utf-8').read().split('\n'), 1):
        if not rx.search(line):
            continue
        n += 1
        if n > mx:
            print('… (더 있음)')
            break
        if raw or not line.startswith('|'):
            s = line if not width else line[:width]
            print('L%d: %s' % (ln, s))
        else:
            cells = split_cells(line)
            print('L%d: (칸 %d)' % (ln, len(cells) - 2))
            for k, c in enumerate(cells[1:-1], 1):
                s = c.strip()
                if width:
                    s = s[:width]
                print('   [%d] %s' % (k, s))
    if n == 0:
        print('(맞는 줄 없음)')


if __name__ == '__main__':
    main()

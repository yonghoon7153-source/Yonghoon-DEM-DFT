# mixer_e0_query.sh — 믹서 E0 자격 pilot 한 팔 · 등록 초안 13 절 조회 q1–q9 (ibb 읽기 전용 · 초안 2026-11-12 · 형식 mixer_e0_query/1)
#   승인 범위: 1저자 11-12 "다 권고대로" = 등록 초안 18 절 Q6 (13 절의 읽기 전용 조회 아홉 줄 · sacct · 로그 꼴 포함).
#   q6 (sacct) 와 q9 (로그 안 줄 꼴) 는 11-10 메타 블록의 승인 범위 (sinfo · sacctmgr show · 내 squeue · 로그는 크기와 첫 배너 줄만) 밖이었다
#   → 이번 Q6 승인 범위로 돈다.  q9 는 숫자 값 · 본문을 옮기지 않는다: thermo 머리 ~ Loop 사이에서 숫자 줄이 아닌 줄의
#   첫 낱말 (숫자 → # · 경로 꼴 → <PATHLIKE> · 24 자) 과 줄 수 · 칸 수만 센다.
#   붙여넣기 블록 (query_block.txt) 이 md5 를 대조한 뒤에만 bash -c 로 돈다.  쓰는 곳 = 새 폴더 ~/mixer_e0_query_<UTC>/ 하나뿐.
#   하지 않는 것: 제출 · 취소 · 잡 제어 · 예약 · git · 지우기 · 옮기기 · conda / module 바꾸기 · 계산 · lmp_mpi 실행
#   (ldd = 로더 목록 모드 · 11-10 메타와 같음) · 덤프 · 체크포인트 · exact 파일 · 로그 내용 복사 (크기 · 이름 · 시각 · 센 수만).
#   외부 명령은 전부 timeout 안 · 없으면 MISSING · 실패면 FAIL · 시간 초과면 TIMEOUT 으로 적고 다음으로 간다.
#   조회 전체 상한 MIX_BUDGET 초 (기본 600) — 넘으면 남은 조회 SKIPPED_BUDGET · 묶음 만들기는 늘 한다 (묶음 상한 +300 초).
#   Ctrl-C = 지금 도는 명령 하나가 끝난 뒤 (그 명령의 timeout 안) 남은 조회를 SKIPPED_INTERRUPT 로 건너뛰고 묶음을 만든다.
#   켜고 끄기 (붙여넣기 전에 export): MIX_Q='q1 q2 q3 q4 q5 q6 q7 q8 q9' (돌릴 조회 · 기본 아홉 다) · MIX_BUDGET=<초>
#   결과: out/ (가린 사본) 을 묶은 tgz 하나 + sha256 (화면).  raw/ (가리지 않은 원문) · work/ (중간 파일) 은 ibb 에 남긴다.
export LC_ALL=C PAGER=cat
umask 077
FORMAT='mixer_e0_query/1'
BLOCK_ID='mixer_e0_query_block draft 2026-11-12'
REF_LMP='ee2d77261bac9e7fa4e9311c8709e74bf7583a13225a5bc35a791bef9be60a3f'
JOBS='249080,249081,249082,249083,249084'
RUNS='E0_ref_s32452843:249080 E0_ref_s49979687:249081 E0_ref_s67867967:249082 E0_ref2_s32452843:249083 E0_ref_dthalf_s32452843:249084'
ONE_RUN='E0_ref_s32452843'
CAP=2097152
BUDGET=${MIX_BUDGET:-600}
case "$BUDGET" in ''|*[^0-9]*) BUDGET=600;; esac
HARD=$((BUDGET + 300))
QSEL=${MIX_Q:-'q1 q2 q3 q4 q5 q6 q7 q8 q9'}
QSEL=${QSEL//,/ }
SELF_TEXT=${1-}
say() { printf '%s\n' "$*"; }

# ── 가림 (awk) — 메타 블록과 같은 규칙 + 'CANCELLED by <uid>'.  토큰은 환경 MIX_T<k> (값) · MIX_R<k> (대체) · MIX_W<k> (1 = 낱말 경계)
AWK_RED='
function isw(c) { return (c ~ /[A-Za-z0-9_]/) }
function rlit(s, a, b,   i, o) { o = ""; while ((i = index(s, a)) > 0) { o = o substr(s, 1, i - 1) b; s = substr(s, i + length(a)) } return o s }
function rword(s, a, b,   i, o, pr, po) {
  o = ""
  while ((i = index(s, a)) > 0) {
    if (i > 1) pr = substr(s, i - 1, 1); else if (length(o) > 0) pr = substr(o, length(o), 1); else pr = ""
    po = substr(s, i + length(a), 1)
    if ((pr == "" || isw(pr) == 0) && (po == "" || isw(po) == 0)) o = o substr(s, 1, i - 1) b
    else o = o substr(s, 1, i - 1 + length(a))
    s = substr(s, i + length(a))
  }
  return o s
}
function buser(s,   i, j, r, k) {
  i = index(s, "compiled "); if (i == 0) return s
  j = index(substr(s, i), " by "); if (j == 0) return s
  j = i + j + 3; r = substr(s, j); k = match(r, /[ ,)]/)
  if (k == 0) return substr(s, 1, j - 1) "<BUILD_USER>"
  return substr(s, 1, j - 1) "<BUILD_USER>" substr(r, k)
}
BEGIN { n = 0; for (k = 1; k <= 9; k++) { v = ENVIRON["MIX_T" k]; if (length(v) > 0) { n++; T[n] = v; R[n] = ENVIRON["MIX_R" k]; W[n] = ENVIRON["MIX_W" k] } } rem = ENVIRON["MIX_REMOTE"] }
{ s = $0
  if (rem == "1") gsub(/[^ ]+:\//, "<REMOTE>:/", s)
  for (k = 1; k <= n; k++) { if (W[k] == "1") s = rword(s, T[k], R[k]); else s = rlit(s, T[k], R[k]) }
  gsub(/\/home\/[A-Za-z0-9._-]+/, "/home/<OTHER_USER>", s)
  gsub(/[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+/, "<IPV4>", s)
  gsub(/uid[ =]?[0-9]+/, "uid <UID>", s); gsub(/gid[ =]?[0-9]+/, "gid <GID>", s)
  gsub(/CANCELLED by [0-9]+/, "CANCELLED by <UID>", s)
  print buser(s) }'

# ── q1 · q3 요약: find -printf 'F|%y|%s[|%f]' 줄만 센다 (이름 · 내용은 옮기지 않는다)
AWK_SUM='
$1 == "F" { n++; if ($2 == "f") { nf++; v = $3 + 0; s += v; if (nf == 1 || v < mn) mn = v; if (v > mx) mx = v } else no++; next }
{ noise++ }
END { printf "%s|entries=%d|files=%d|bytes=%.0f|min=%.0f|max=%.0f|other=%d|noise=%d\n", tag, n, nf, s, mn, mx, no, noise }'
# ── q2: 덤프 이름 mix_<step>.liggghts 에서 step 만 꺼낸다 → step|바이트|수정 시각
AWK_Q2X='$1 == "F" && $4 ~ /^mix_[0-9]+[.]liggghts$/ { s = $4; sub(/^mix_/, "", s); sub(/[.]liggghts$/, "", s); print s "|" $3 "|" $2 }'
# ── q2: 정렬된 목록에서 처음 3 · 가운데 1 · 끝 3 줄 (같은 줄은 한 번)
AWK_Q2P='
FILENAME == f1 { n++; a[n] = $0; next }
$1 == "F" { tot++; if ($4 ~ /^mix_[0-9]+[.]liggghts$/) mt++; else oth++; next }
{ noise++ }
END {
  printf "q2|run=%s|files=%d|matched=%d|sorted=%d|other_names=%d|noise=%d\n", run, tot, mt, n, oth, noise
  m = int((n + 1) / 2); ix[1] = 1; ix[2] = 2; ix[3] = 3; ix[4] = m; ix[5] = n - 2; ix[6] = n - 1; ix[7] = n
  for (j = 1; j <= 7; j++) { x = ix[j]; if (x >= 1 && x <= n && done[x] == "") { done[x] = 1; printf "frame|%d|%s\n", x, a[x] } }
}'
# ── q3: exact 폴더의 hp_ · g6_ 파일 크기 (6 열 · %.17g ↔ 기본 %g) — 내용은 열지 않는다
AWK_Q3='
$1 == "F" && $2 == "f" && $4 ~ /^(hp|g6)_[0-9]+[.]liggghts$/ { printf "exact|%s|%s|%s\n", d, $4, $3; next }
$1 == "F" { oth++; next }
{ noise++ }
END { printf "exact_other|%s|other=%d|noise=%d\n", d, oth, noise }'
# ── q7: 동적 구간에서 RPATH / RUNPATH 줄만
AWK_RPATH='/RPATH|RUNPATH/ { n++; print } END { printf "rpath_lines=%d\n", n }'
# ── q7: ldd 줄 → 종류|soname|경로
AWK_LDD='
{ sub(/\r$/, "") }
/=> not found/ { print "notfound|" $1 "|-"; next }
/=> \// { p = $0; sub(/^.*=> /, "", p); sub(/ \(0x[0-9a-fA-F]+\)$/, "", p); print "path|" $1 "|" p; next }
/^[ \t]*\// { p = $1; s = p; sub(/^.*\//, "", s); print "path|" s "|" p; next }
/linux-vdso|linux-gate/ { print "vdso|" $1 "|-"; next }
NF > 0 { print "other|" $1 "|-" }'
# ── q9: thermo 머리 (첫 낱말 Step) ~ "Loop time of" 사이를 센다.  숫자 · 본문은 내보내지 않는다 (센 수 · 칸 수 · 가린 첫 낱말만)
AWK_Q9='
function isnum(t) { return (t ~ /^[-+]?([0-9]+[.]?[0-9]*|[.][0-9]+)([eE][-+]?[0-9]+)?$/) }
function isnf(t,   u) { u = tolower(t); return (u ~ /^[-+]?(nan|inf|infinity)$/) }
function fw(t,   u) {
  if (index(t, "/") > 0) return "<PATHLIKE>"
  u = t; gsub(/[0-9]/, "#", u); gsub(/[^A-Za-z#:._-]/, "?", u)
  if (length(u) > 24) u = substr(u, 1, 24) "~"
  if (u == "") u = "<EMPTY>"
  return u
}
{ nl++; sub(/\r$/, "") }
$1 == "Step" { b++; inb = 1; hc[b] = NF; rows[b] = 0; nfr[b] = 0; nr[b] = 0; bl[b] = 0; cl[b] = "no"; next }
inb == 1 && index($0, "Loop time of") == 1 { cl[b] = "yes"; inb = 0; next }
inb == 1 {
  if (NF == 0) { bl[b]++; next }
  num = 1; nonf = 0
  for (i = 1; i <= NF; i++) { if (isnum($i)) continue; if (isnf($i)) { nonf = 1; continue } num = 0; break }
  if (num == 1) { rows[b]++; rc[b "|" NF]++; if (NF > mc) mc = NF; if (nonf == 1) nfr[b]++; next }
  nr[b]++; fwc[b "|" fw($1)]++; next
}
END {
  printf "q9|lines=%d|blocks=%d\n", nl, b
  for (k = 1; k <= b; k++) {
    s = ""
    for (c = 1; c <= mc; c++) { key = k "|" c; if (key in rc) s = s (s == "" ? "" : ",") c ":" rc[key] }
    printf "block|%d|header_cols=%d|rows=%d|rows_nonfinite=%d|row_cols=%s|nonrow=%d|blank=%d|closed=%s\n", k, hc[k], rows[k], nfr[k], (s == "" ? "-" : s), nr[k], bl[k], cl[k]
    for (key in fwc) { split(key, p, "|"); if (p[1] + 0 == k) printf "nonrow|%d|%s|%d\n", k, p[2], fwc[key] }
  }
}'

# ── 시작 관문 (하나라도 안 되면 폴더도 만들지 않고 끝)
command -v timeout >/dev/null 2>&1 || { say "timeout 이 없음 — 아무것도 안 함 (폴더도 안 만듦)"; exit 3; }
TK=''
timeout -k 2 5 true </dev/null >/dev/null 2>&1 && TK='-k 5'
case "${HOME-}" in /?*) ;; *) say "HOME 이 절대경로가 아님 — 아무것도 안 함"; exit 3;; esac
[ "${#HOME}" -ge 4 ] || { say "HOME 이 너무 짧음 — 아무것도 안 함"; exit 3; }
STAMP=$(timeout 5 date -u +%Y%m%dT%H%M%SZ </dev/null 2>/dev/null)
case "$STAMP" in [0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9]T[0-9][0-9][0-9][0-9][0-9][0-9]Z) ;; *) say "UTC 시각을 못 읽음 — 아무것도 안 함"; exit 3;; esac
D=''; NAME=''
for sfx in '' _2 _3 _4 _5; do
  if timeout 10 mkdir -- "$HOME/mixer_e0_query_$STAMP$sfx" </dev/null 2>/dev/null; then NAME="mixer_e0_query_$STAMP$sfx"; D="$HOME/$NAME"; break; fi
done
[ -n "$D" ] || { say "새 폴더를 못 만듦 (이미 있음 · 권한 · 디스크) — 아무것도 안 함"; exit 3; }
timeout 10 mkdir -- "$D/raw" "$D/out" "$D/work" "$D/work/tmp" </dev/null 2>/dev/null || { say "하위 폴더를 못 만듦 — 멈춤 (만든 폴더 ~/$NAME)"; exit 3; }
cd -- "$D/work" 2>/dev/null || { say "작업 폴더로 못 들어감 — 멈춤 (만든 폴더 ~/$NAME)"; exit 3; }
export TMPDIR="$D/work/tmp"
FR="$D/raw/fields.txt"; PR="$D/raw/probes.txt"
: > "$FR"; : > "$PR"
printf '%s' "$SELF_TEXT" > "$D/raw/query_script.sh"
say "── 믹서 E0 조회 q1–q9 시작 · 폴더 ~/$NAME · 조회 상한 $BUDGET 초 · 읽기 전용 (제출 · 취소 · 지우기 없음)"

# ── 도우미
put() { local v=${2-}; v=${v//$'\n'/ }; v=${v//$'\r'/ }; printf '%s=%s\n' "$1" "$v" >> "$FR"; }
INTR=0
trap 'INTR=1' INT
over() { [ "$INTR" = 1 ] || [ "$SECONDS" -ge "$BUDGET" ]; }
why() { if [ "$INTR" = 1 ]; then printf SKIPPED_INTERRUPT; else printf SKIPPED_BUDGET; fi; }
want() { case " $QSEL " in *" $1 "*) return 0;; esac; return 1; }
probe() {  # probe <이름> <초> <출력 파일> <명령...> → 출력 파일 (stdout+stderr · 상한 CAP) · raw/probes.txt 한 줄 · 반환 = 명령 rc
  local name=$1 secs=$2 f=$3 t0 rc st by
  shift 3
  if over; then printf '%s|%s|-|0|0|%s\n' "$name" "$(why)" "${1##*/}" >> "$PR"; : > "$f"; return 200; fi
  command -v -- "$1" >/dev/null 2>&1 || { printf '%s|MISSING|-|0|0|%s\n' "$name" "${1##*/}" >> "$PR"; : > "$f"; return 127; }
  t0=$SECONDS
  timeout $TK "$secs" "$@" </dev/null 2>&1 | timeout 900 head -c "$CAP" > "$f"
  rc=${PIPESTATUS[0]}
  by=$(timeout 10 wc -c < "$f" 2>/dev/null); by=${by//[^0-9]/}
  case "$rc" in 0) st=OK;; 124|137) st=TIMEOUT;; 126|127) st=MISSING;; 141) st=TRUNC;; *) st=FAIL;; esac
  [ "$st" = OK ] && [ "${by:-0}" -ge "$CAP" ] && st=TRUNC
  printf '%s|%s|%s|%s|%s|%s\n' "$name" "$st" "$rc" "$((SECONDS - t0))" "${by:-0}" "${1##*/}" >> "$PR"
  return "$rc"
}
hashline() {  # hashline <경로> <최대 바이트> → "sha256|바이트|mtime" 또는 "사유|바이트|mtime" (해시 전후 stat 이 같아야 sha256)
  local p=$1 max=$2 s t sz mt h a rc
  s=$(timeout 10 stat -c '%F|%s|%Y' -- "$p" </dev/null 2>/dev/null) || { printf 'ABSENT||'; return 1; }
  t=${s%%|*}; s=${s#*|}; sz=${s%%|*}; mt=${s#*|}
  case "$t" in 'regular file'|'regular empty file') ;; *) printf 'NOT_REGULAR|%s|%s' "$sz" "$mt"; return 1;; esac
  [ "$sz" -le "$max" ] 2>/dev/null || { printf 'TOO_BIG|%s|%s' "$sz" "$mt"; return 1; }
  h=$(timeout $TK 120 sha256sum -- "$p" </dev/null 2>/dev/null); rc=$?; h=${h%% *}
  [ "$rc" = 124 ] && { printf 'HASH_TIMEOUT|%s|%s' "$sz" "$mt"; return 1; }
  case "$h" in ''|*[^0-9a-f]*) printf 'HASH_FAIL|%s|%s' "$sz" "$mt"; return 1;; esac
  [ "${#h}" -eq 64 ] || { printf 'HASH_FAIL|%s|%s' "$sz" "$mt"; return 1; }
  a=$(timeout 10 stat -c '%F|%s|%Y' -- "$p" </dev/null 2>/dev/null)
  [ "$a" = "$t|$sz|$mt" ] || { printf 'CHANGED_DURING_HASH|%s|%s' "$sz" "$mt"; return 1; }
  printf '%s|%s|%s' "$h" "$sz" "$mt"
}
red_file() { MIX_REMOTE=${3:-0} timeout 30 awk "$AWK_RED" "$1" > "$2" 2>/dev/null; }

# ── 신원 (원문은 raw/private_identity.txt 에만 — out/ 로 복사하지 않는다) · 가림 토큰 (메타 블록과 같다)
MYUID=$(timeout 5 id -u </dev/null 2>/dev/null); MYGID=$(timeout 5 id -g </dev/null 2>/dev/null)
IDN=$(timeout 5 id -un </dev/null 2>/dev/null)
ME=${USER-}; [ -n "$ME" ] || ME=$IDN
HOST_F=$(timeout 10 hostname -f </dev/null 2>/dev/null); HOST_S=$(timeout 10 hostname -s </dev/null 2>/dev/null)
[ -n "$HOST_S" ] || HOST_S=$(timeout 5 uname -n </dev/null 2>/dev/null)
HOME_REAL=$(cd -P -- "$HOME" 2>/dev/null && pwd -P)
printf 'user=%s\nid_un=%s\nuid=%s\ngid=%s\nhost_f=%s\nhost_s=%s\nhome=%s\nhome_real=%s\n' "$ME" "$IDN" "$MYUID" "$MYGID" "$HOST_F" "$HOST_S" "$HOME" "$HOME_REAL" > "$D/raw/private_identity.txt"
TOKV=(); ti=0
addtok() { [ "${#1}" -ge 2 ] || return 0; ti=$((ti + 1)); export "MIX_T$ti=$1" "MIX_R$ti=$2" "MIX_W$ti=$3"; TOKV+=("$1"); }
if [ "${#HOME_REAL}" -gt "${#HOME}" ]; then addtok "$HOME_REAL" '<HOME_REAL>' 0; addtok "$HOME" '<HOME>' 0
else addtok "$HOME" '<HOME>' 0; [ "$HOME_REAL" = "$HOME" ] || addtok "$HOME_REAL" '<HOME_REAL>' 0; fi
[ "$HOST_F" = "$HOST_S" ] || addtok "$HOST_F" '<HOST>' 1
addtok "$HOST_S" '<HOST>' 1
addtok "$ME" '<USER>' 1
[ "$IDN" = "$ME" ] || addtok "$IDN" '<USER>' 1

# ── 실행 메타
T_START=$(timeout 5 date -u +%Y-%m-%dT%H:%M:%SZ </dev/null 2>/dev/null)
put format "$FORMAT"; put block_id "$BLOCK_ID"; put target_alias ibb; put folder "~/$NAME"
put captured_start_utc "$T_START"; put bash_version "$BASH_VERSION"
put timeout_kill_after "${TK:-unsupported}"; put budget_seconds "$BUDGET"; put pack_deadline_seconds "$HARD"
put switch.MIX_Q "$QSEL"; put redaction_tokens "$ti"
for q in $QSEL; do case "$q" in q[1-9]) ;; *) put qsel.unknown_token "$q";; esac; done
x=$(timeout 10 md5sum -- "$D/raw/query_script.sh" </dev/null 2>/dev/null); put script_md5 "${x%% *}"
x=$(timeout 10 sha256sum -- "$D/raw/query_script.sh" </dev/null 2>/dev/null); put script_sha256 "${x%% *}"
put script_bytes "${#SELF_TEXT}"
for t in stat readlink find du sort awk head wc sha256sum md5sum tar gzip df lfs sacct sinfo readelf objdump ldd hostname id date; do
  command -v "$t" >/dev/null 2>&1 && put "tool.$t" present || put "tool.$t" MISSING
done
ALLOC=no; [ -n "${SLURM_JOB_ID-}" ] && ALLOC=yes; put inside_slurm_allocation "$ALLOC"
x=$(timeout 5 awk -W version </dev/null 2>/dev/null | timeout 5 head -n 1); [ -n "$x" ] || x=$(timeout 5 awk --version </dev/null 2>/dev/null | timeout 5 head -n 1)
put awk_version "$x"
BASE="$HOME/mixer_dev7_20260930_v26"
put base "$BASE"; put base.stat "$(timeout 10 stat -c '%F' -- "$BASE" </dev/null 2>/dev/null || printf ABSENT)"
DMNT=$(timeout 10 df -P -- "$HOME" </dev/null 2>/dev/null | timeout 5 awk 'NR == 2 { print $NF }')
DFST=$(timeout 10 stat -f -c %T -- "$HOME" </dev/null 2>/dev/null)
put disk.home.mount "$DMNT"; put disk.home.fstype "$DFST"

# ── q1 DEV E0 다섯 런의 post · restart 크기 (du 할당 + 파일 크기 합 · 파일 수 · 최소 · 최대)
q1() {
  local i=0 ent run job R
  for ent in $RUNS; do
    i=$((i + 1)); run=${ent%%:*}; job=${ent#*:}; R="$BASE/$run"
    put "q1.r$i.run" "$run"; put "q1.r$i.job" "$job"
    probe "q1_r${i}_du" 120 "$D/raw/q1_r${i}_du.txt" du -sk -- "$R/post" "$R/restart"
    probe "q1_r${i}_post_ls" 120 "$D/work/q1_r${i}_post_ls.txt" find "$R/post" -mindepth 1 -maxdepth 1 -printf 'F|%y|%s\n'
    probe "q1_r${i}_post_sum" 30 "$D/raw/q1_r${i}_post_sum.txt" awk -F'|' -v tag="r$i|$run|post" "$AWK_SUM" "$D/work/q1_r${i}_post_ls.txt"
    probe "q1_r${i}_restart_ls" 60 "$D/raw/q1_r${i}_restart_ls.txt" find "$R/restart" -mindepth 1 -maxdepth 1 -printf 'F|%y|%s|%f\n'
    probe "q1_r${i}_restart_sum" 30 "$D/raw/q1_r${i}_restart_sum.txt" awk -F'|' -v tag="r$i|$run|restart" "$AWK_SUM" "$D/raw/q1_r${i}_restart_ls.txt"
  done
}
# ── q2 한 런의 프레임 크기 · 수정 시각 (처음 3 · 가운데 1 · 끝 3)
q2() {
  local R="$BASE/$ONE_RUN"
  put q2.run "$ONE_RUN"
  probe q2_post_ls 120 "$D/work/q2_post_ls.txt" find "$R/post" -mindepth 1 -maxdepth 1 -type f -printf 'F|%T@|%s|%f\n'
  probe q2_extract 30 "$D/work/q2_extract.txt" awk -F'|' "$AWK_Q2X" "$D/work/q2_post_ls.txt"
  probe q2_sort 60 "$D/work/q2_sorted.txt" sort -t'|' -k1,1n -- "$D/work/q2_extract.txt"
  probe q2_pick 30 "$D/raw/q2_frames.txt" awk -F'|' -v run="$ONE_RUN" -v f1="$D/work/q2_sorted.txt" "$AWK_Q2P" "$D/work/q2_sorted.txt" "$D/work/q2_post_ls.txt"
}
# ── q3 exact 보충 폴더의 hp (%.17g) · g6 (기본 %g) 파일 크기 (6 열)
q3() {
  local k=0 tg dn
  probe q3_dirs 60 "$D/work/q3_dirs.txt" find "$BASE" -mindepth 1 -maxdepth 1 -type d -name 'exact_*' -printf 'D|%f\n'
  while IFS='|' read -r tg dn; do
    [ "$tg" = D ] || continue
    case "$dn" in exact_*) ;; *) continue;; esac
    case "$dn" in *[^A-Za-z0-9_.-]*) put q3.skipped_odd_name yes; continue;; esac
    k=$((k + 1)); [ "$k" -le 20 ] || break
    probe "q3_d${k}_ls" 60 "$D/work/q3_d${k}_ls.txt" find "$BASE/$dn/exact" -mindepth 1 -maxdepth 1 -printf 'F|%y|%s|%f\n'
    probe "q3_d${k}_sizes" 30 "$D/raw/q3_d${k}_sizes.txt" awk -F'|' -v d="$dn" "$AWK_Q3" "$D/work/q3_d${k}_ls.txt"
  done < "$D/work/q3_dirs.txt"
  put q3.n_dirs "$k"
}
# ── q4 기본 할당 한도 · q5 OST 별 여유 (Lustre 일 때만)
q4() {
  case "$DFST" in lustre*) ;; *) printf 'q4_lfs_quota_default|SKIPPED_NOT_LUSTRE|-|0|0|lfs\nq4_lfs_quota_user|SKIPPED_NOT_LUSTRE|-|0|0|lfs\n' >> "$PR"; return 0;; esac
  [ -n "$DMNT" ] || { printf 'q4_lfs_quota_default|FAIL|-|0|0|df\nq4_lfs_quota_user|FAIL|-|0|0|df\n' >> "$PR"; return 0; }
  probe q4_lfs_quota_default 60 "$D/raw/q4_lfs_quota_default.txt" lfs quota -U "$DMNT"
  probe q4_lfs_quota_user 60 "$D/raw/q4_lfs_quota_user.txt" lfs quota -u "$ME" "$DMNT"
}
q5() {
  case "$DFST" in lustre*) ;; *) printf 'q5_lfs_df|SKIPPED_NOT_LUSTRE|-|0|0|lfs\n' >> "$PR"; return 0;; esac
  [ -n "$DMNT" ] || { printf 'q5_lfs_df|FAIL|-|0|0|df\n' >> "$PR"; return 0; }
  probe q5_lfs_df 60 "$D/raw/q5_lfs_df.txt" lfs df "$DMNT"
}
# ── q6 DEV E0 잡 다섯의 sacct 기록 (State · ExitCode · Elapsed · AllocCPUS · MaxRSS · ReqMem — 노드 · 계정 칸은 안 부른다)
q6() {
  probe q6_sacct 60 "$D/raw/q6_sacct.txt" sacct -j "$JOBS" -P -o JobID,State,ExitCode,Elapsed,AllocCPUS,MaxRSS,ReqMem
}
# ── q7 lmp_mpi 의 RPATH / RUNPATH 줄 + ldd 대상의 실제 파일 sha256
q7() {
  local B="$HOME/LIGGGHTS-PUBLIC/src/lmp_mpi" BR h t0 kind so lp lr lt n=0 nok=0 nbad=0 st
  BR=$(timeout 10 readlink -e -- "$B" </dev/null 2>/dev/null) || BR=''
  if [ -z "$BR" ]; then printf 'q7_bin|FAIL|-|0|0|readlink\n' >> "$PR"; put q7.bin ABSENT; return 0; fi
  if over; then printf 'q7_bin|%s|-|0|0|sha256sum\n' "$(why)" >> "$PR"; return 0; fi
  t0=$SECONDS
  h=$(hashline "$BR" 4294967296); put q7.bin.realpath "$BR"; put q7.bin.hash "$h"
  case "${h%%|*}" in "$REF_LMP") put q7.bin.vs_ref same; st=OK;; [0-9a-f]*) put q7.bin.vs_ref different; st=OK;; *) put q7.bin.vs_ref unknown; st=FAIL;; esac
  printf 'q7_bin|%s|-|%s|0|sha256sum\n' "$st" "$((SECONDS - t0))" >> "$PR"
  probe q7_readelf 30 "$D/work/q7_dynamic.txt" readelf -d -- "$BR"
  [ "$?" = 127 ] && probe q7_objdump 30 "$D/work/q7_dynamic.txt" objdump -p -- "$BR"
  probe q7_rpath 10 "$D/raw/q7_rpath.txt" awk "$AWK_RPATH" "$D/work/q7_dynamic.txt"
  probe q7_ldd 30 "$D/raw/q7_ldd.txt" ldd -- "$BR"
  probe q7_ldd_parse 10 "$D/work/q7_ldd_items.txt" awk "$AWK_LDD" "$D/raw/q7_ldd.txt"
  : > "$D/raw/q7_libs.txt"
  t0=$SECONDS
  while IFS='|' read -r kind so lp; do
    case "$kind" in
      path) n=$((n + 1)); [ "$n" -le 150 ] || break
            if over; then printf 'lib|%s|%s|-|-|%s||\n' "$so" "$lp" "$(why)" >> "$D/raw/q7_libs.txt"; nbad=$((nbad + 1)); continue; fi
            lt=$(timeout 10 stat -c '%F' -- "$lp" </dev/null 2>/dev/null) || lt=ABSENT
            lr=$(timeout 10 readlink -e -- "$lp" </dev/null 2>/dev/null) || lr=''
            if [ -z "$lr" ]; then printf 'lib|%s|%s|%s|-|UNRESOLVED||\n' "$so" "$lp" "$lt" >> "$D/raw/q7_libs.txt"; nbad=$((nbad + 1)); continue; fi
            h=$(hashline "$lr" 1073741824) && nok=$((nok + 1)) || nbad=$((nbad + 1))
            printf 'lib|%s|%s|%s|%s|%s\n' "$so" "$lp" "$lt" "$lr" "$h" >> "$D/raw/q7_libs.txt";;
      notfound) printf 'lib|%s|-|NOT_FOUND|-|-||\n' "$so" >> "$D/raw/q7_libs.txt";;
      vdso) printf 'lib|%s|-|VDSO|-|-||\n' "$so" >> "$D/raw/q7_libs.txt";;
    esac
  done < "$D/work/q7_ldd_items.txt"
  put q7.n_lib_paths "$n"; put q7.n_lib_hashed "$nok"; put q7.n_lib_not_hashed "$nbad"
  if [ "$n" -gt 0 ] && [ "$nbad" = 0 ]; then st=OK; else st=FAIL; fi
  printf 'q7_libs|%s|-|%s|%s|sha256sum\n' "$st" "$((SECONDS - t0))" "$nok" >> "$PR"
}
# ── q8 빈 코어 (시점 값 · 판정 아님) — 파티션 CPU 할당/유휴/기타/전체 · cpu 파티션 노드별 같은 칸 (노드 이름 칸은 안 부른다)
q8() {
  probe q8_sinfo_partitions 30 "$D/raw/q8_sinfo_partitions.txt" sinfo -h -o '%P|%a|%C'
  probe q8_sinfo_nodes_cpu 30 "$D/raw/q8_sinfo_nodes_cpu.txt" sinfo -h -N -p cpu -o '%C|%t'
}
# ── q9 DEV E0 한 런 log.liggghts 의 thermo 표 안 비-행 줄 꼴 (첫 낱말 · 줄 수 · 칸 수만)
q9() {
  local L="$BASE/$ONE_RUN/log.liggghts" s
  s=$(timeout 10 stat -c '%F|%s' -- "$L" </dev/null 2>/dev/null) || s=ABSENT
  put q9.run "$ONE_RUN"; put q9.log_stat "$s"
  case "$s" in 'regular file|'*) probe q9_thermo_shape 30 "$D/raw/q9_thermo_shape.txt" awk "$AWK_Q9" "$L";; *) printf 'q9_thermo_shape|FAIL|-|0|0|stat\n' >> "$PR";; esac
}

for q in q1 q2 q3 q4 q5 q6 q7 q8 q9; do
  if want "$q"; then "$q"; else printf '%s|SKIPPED_SWITCH|-|0|0|-\n' "$q" >> "$PR"; fi
done

# ── 끝: 기록 → 가린 사본 out/ → 남은 문자열 확인 → SHA256SUMS → tgz
T_END=$(timeout 5 date -u +%Y-%m-%dT%H:%M:%SZ </dev/null 2>/dev/null)
put captured_end_utc "$T_END"; put elapsed_seconds "$SECONDS"; put interrupted "$INTR"
put probe_status_counts "$(timeout 10 awk -F'|' '{ c[$2]++ } END { for (s in c) printf "%s=%d ", s, c[s] }' "$PR")"
RED_OK=0; command -v awk >/dev/null 2>&1 && RED_OK=1
RAWL=()
for f in "$D"/raw/*; do
  b=${f##*/}
  case "$b" in private_*) continue;; esac
  RAWL+=("$b")
  [ "$b" = query_script.sh ] && continue
  case "$b" in q4_*|q5_*) rem=1;; *) rem=0;; esac
  if [ "$SECONDS" -ge "$HARD" ]; then printf 'redact_skipped_deadline=%s\n' "$b" >> "$D/out/fields_post.txt"; continue; fi
  if [ "$RED_OK" = 1 ]; then red_file "$f" "$D/out/$b" "$rem" || printf 'redact_fail=%s\n' "$b" >> "$D/out/fields_post.txt"; fi
done
printf '%s' "$SELF_TEXT" > "$D/out/query_script.sh"
RES=0
for tv in "${TOKV[@]}"; do
  c=$(timeout 30 grep -r -F -c --exclude=query_script.sh -- "$tv" "$D/out" 2>/dev/null | timeout 10 awk -F: '{ s += $NF } END { print s + 0 }')
  RES=$((RES + ${c:-0}))
done
printf 'redaction.available=%s\nredaction.residual_token_hits=%s\n' "$RED_OK" "$RES" >> "$D/out/fields_post.txt"
( cd "$D/raw" && timeout 60 sha256sum -- "${RAWL[@]}" ) > "$D/out/RAW_SHA256SUMS" 2>/dev/null
OUTL=(); for f in "$D"/out/*; do b=${f##*/}; [ "$b" = SHA256SUMS ] || OUTL+=("$b"); done
( cd "$D/out" && timeout 60 sha256sum -- "${OUTL[@]}" ) > "$D/out/SHA256SUMS" 2>/dev/null
TGZ="$D/$NAME.tgz"; TGZ_SHA=''; TGZ_BYTES=''
if timeout 120 tar --owner=0 --group=0 --numeric-owner -czf "$TGZ" -C "$D" out </dev/null 2>"$D/work/tar_err.txt"; then
  x=$(timeout 60 sha256sum -- "$TGZ" </dev/null 2>/dev/null); TGZ_SHA=${x%% *}
  TGZ_BYTES=$(timeout 10 stat -c %s -- "$TGZ" </dev/null 2>/dev/null)
  printf '%s  %s\n' "$TGZ_SHA" "$NAME.tgz" > "$D/$NAME.tgz.sha256"
fi

# ── 화면 (조회별 상태 · 묶음 · 경로는 ~/ 로만)
[ "$INTR" = 1 ] && say "⚠ Ctrl-C 로 멈춤 — 남은 조회는 SKIPPED_INTERRUPT · 묶음은 만들었다 (넘길지는 1저자)"
say "── 끝 · $SECONDS 초 · 조회 $(timeout 10 awk -F'|' '{ c[$2]++ } END { for (s in c) printf "%s %d  ", s, c[s] }' "$PR")"
for q in q1 q2 q3 q4 q5 q6 q7 q8 q9; do
  say "$q  $(timeout 10 awk -F'|' -v q="$q" '$1 == q || index($1, q "_") == 1 { c[$2]++ } END { for (s in c) printf "%s %d  ", s, c[s] }' "$PR")"
done
if [ "$RES" = 0 ]; then say "가림 확인  out/ 에 남은 계정 · 호스트 · 경로 문자열 0 곳"
else say "가림 확인  ⚠ out/ 에 남은 계정 · 호스트 · 경로 문자열 $RES 곳 — tgz 를 넘기기 전에 out/ 을 확인 (가림 실패면 넘기지 말 것)"; fi
if [ -n "$TGZ_SHA" ]; then
  say "가져올 파일 ~/$NAME/$NAME.tgz  ($TGZ_BYTES 바이트 · out/ 만 · 가린 사본)"
  say "sha256     $TGZ_SHA"
else say "⚠ tgz 를 못 만듦 (tar) — ~/$NAME/out/ 폴더를 그대로 가져올 것"; fi
say "raw/ (가리지 않은 원문) · work/ 는 ~/$NAME/ 에 남김 — 가져오지 않는다"

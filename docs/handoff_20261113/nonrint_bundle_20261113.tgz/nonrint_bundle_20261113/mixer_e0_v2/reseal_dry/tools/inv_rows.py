"""Rewrite bytes / sha256 / git_blob of named rows of an IN source_inventory.json from a tree's
files (other keys of the row, e.g. original_* / accepted_* / receipt_*, are kept).
Writes in place as json.dumps(indent=2)+newline (the committed file round-trips that way).
Usage: python3 -I -B inv_rows.py <inventory.json> <tree_root> <dep|launch>:<path> [...]"""
import hashlib, json, sys
from pathlib import Path
inv, tree = Path(sys.argv[1]), Path(sys.argv[2])
v = json.loads(inv.read_bytes())
before = hashlib.sha256(inv.read_bytes()).hexdigest()
sect = {'dep': v['source_dependencies'], 'launch': v['launch_snapshot']}
for item in sys.argv[3:]:
    kind, path = item.split(':', 1)
    row = [r for r in sect[kind] if r['path'] == path]
    assert len(row) == 1, item
    raw = (tree / path).read_bytes()
    old = (row[0]['bytes'], row[0]['sha256'][:12], row[0]['git_blob'][:12])
    row[0].update(bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest(),
                  git_blob=hashlib.sha1(b'blob ' + str(len(raw)).encode() + b'\0' + raw).hexdigest())
    print('row', kind, path, 'old', old, 'new', (row[0]['bytes'], row[0]['sha256'][:12], row[0]['git_blob'][:12]))
inv.write_bytes((json.dumps(v, indent=2, ensure_ascii=False) + '\n').encode('utf-8'))
print('inventory sha256', before[:12], '->', hashlib.sha256(inv.read_bytes()).hexdigest()[:12])

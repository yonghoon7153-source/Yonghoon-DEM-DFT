"""Byte-only NOTE01 recheck. No science arithmetic or repository code execution."""
from pathlib import Path,PurePosixPath
import zipfile,hashlib,json,io
ROOT=Path(__file__).resolve().parent
NEW='0f284e7db65278acb52dd4666b1b22151604e9ba'
OLD='d0107959955f284df56cb546ee008595d26dac61'
NAME='codex_mixer_precal_note01_20261104_0f284e7db652.zip'
SHA='149884c16a1024cd9fa7e377fc8d52d12ad4851bc065d1ee8fa57bafe2b6bdbc'
hash256=lambda b:hashlib.sha256(b).hexdigest()
def require(ok,msg):
 if not ok:raise ValueError(msg)
def main():
 data=(ROOT/'input'/NAME).read_bytes();require(hash256(data)==SHA,'ZIP differs')
 remote=json.loads((ROOT/'remote_pin.json').read_text(encoding='utf-8'))
 require(remote['pin']==NEW,'remote pin differs');rm={r['path']:r for r in remote['entries']}
 with zipfile.ZipFile(io.BytesIO(data)) as z:
  names=z.namelist();require(len(names)==len(set(n.casefold() for n in names)),'duplicate members')
  for e in z.infolist():
   n=e.filename;p=PurePosixPath(n)
   require(not p.is_absolute() and '..' not in p.parts and ':' not in n and '\\' not in n,'unsafe path')
   require((e.external_attr>>16)&0o170000!=0o120000,'symlink')
  require(z.read('PIN.txt').decode().strip()==NEW,'new pin differs')
  require(z.read('EXTERNALLY_ACCEPTED_PIN.txt').decode().strip()==OLD,'accepted pin differs')
  manifest=json.loads(z.read('SNAPSHOT_MANIFEST.json'));require(manifest['pin']==NEW,'manifest pin differs')
  for e in manifest['entries']:
   b=z.read(e['path']);blob=hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
   require((len(b),hash256(b),blob)==(e['bytes'],e['sha256'],e['git_blob']),'snapshot differs '+e['path'])
   r=rm[e['path']];require((len(b),blob)==(r['bytes'],r['git_blob']),'remote differs '+e['path'])
  require({e['path'] for e in manifest['entries']}==set(rm),'remote path set differs')
  package=[]
  for line in z.read('PACKAGE_SHA256SUMS').decode().splitlines():
   h,n=line.split('  ',1);n=n[2:] if n.startswith('./') else n
   require(hash256(z.read(n))==h,'package checksum differs');package.append(n)
  require(len(package)==len(set(package)) and set(names)-set(package)=={'PACKAGE_SHA256SUMS'},'package coverage differs')
  pre='docs/reviews/mixer_precal_map_acceptance_20261104/'
  evidence=z.read(pre+'codex_mixer_precal_map_review_evidence_20261104.zip')
  require(hash256(evidence)=='44c464e241458c8b3a7a1510e8aa93cca9a96eeef8e7d46aa97f940e40f13608','original evidence ZIP differs')
  with zipfile.ZipFile(io.BytesIO(evidence)) as previous:
   report=previous.read('codex_review_mixer_precal_map_20261104.md')
   require(z.read(pre+'external_review.txt')==report,'external report differs')
   for n in ('scope_verdict.json','independent_results.json'):
    require(z.read(pre+n)==previous.read(n),'external '+n+' differs')
   oldarchive=previous.read('input/codex_mixer_precal_map_draft_20261104_d0107959955f.zip')
   require(hash256(oldarchive)=='e64340eb1391f19cbf27f482d36bae0b19de0ab07c98b2bfdb67e13e6fc0a477','original input differs')
   with zipfile.ZipFile(io.BytesIO(oldarchive)) as accepted:
    require(accepted.read('PIN.txt').decode().strip()==OLD,'embedded old pin differs')
    draft='docs/reviews/mixer_precal_exploration_registration_draft_20261104.md'
    before=accepted.read(draft);after=z.read(draft)
    quotes=[l[2:] for l in report.decode().splitlines() if l.startswith('> ')]
    require(len(quotes)==1,'proposal quote not unique')
    sentence=quotes[0].encode('utf-8');block=sentence+b'\n\n'
    require(after.count(sentence)==1 and after.count(block)==1,'proposal not exact and unique')
    require(len(block)==301 and after.replace(block,b'',1)==before,'delta not exactly301bytes')
    same=[]
    for e in json.loads(accepted.read('SNAPSHOT_MANIFEST.json'))['entries']:
     if e['path']!=draft:
      require(z.read(e['path'])==accepted.read(e['path']),'previous file changed '+e['path'])
      same.append(e['path'])
  require(z.read('REQUEST.md')==z.read('docs/reviews/codex_mixer_precal_note01_confirmation_request_20261104.md'),'request copy differs')
  line=after[:after.index(sentence)].count(b'\n')+1
 return {'new_pin':NEW,'previous_accepted_pin':OLD,'zip_sha256':SHA,'zip_bytes':len(data),'snapshot_remote_entries_checked':len(manifest['entries']),'package_entries_checked':len(package),'proposal_verbatim':True,'proposal_start_line':line,'addition_bytes':len(block),'before_bytes':len(before),'after_bytes':len(after),'removal_restores_exact_previous_draft':True,'before_sha256':hash256(before),'after_sha256':hash256(after),'other_previous_snapshot_files_unchanged':same,'original_review_and_evidence_preserved':True,'request_copy_identical':True,'scope':'NOTE01 transcription, byte preservation and receipt boundaries only; not a repeated full review','science_arithmetic_rerun':False,'repository_code_imported_or_executed':False,'overall_gate':'HOLD','execution_authorized':False}
if __name__=='__main__':print(json.dumps(main(),ensure_ascii=False,indent=2))


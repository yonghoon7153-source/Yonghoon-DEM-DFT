# 지시서 — P1 언로딩 G2c′ 다음 두 초안 (문서만 · 결과 0 건 · 11-12 · 1저자 "권고대로")

## 0. 할 일

G2c′ 샌드박스 (직렬 · 1 프로세스 · N 40000) 가 끝났다 — 판정 다 · 라 PASS (비트 같은 쌍 3111/3111 · 원자 1220) · 판독 가능한 예측 13 줄 모두 맞음 · 가 · 라-재현(나) = 해당 없음 (실행 파일 md5 다름). 1저자가 다음 둘을 권고대로 하라고 했다. **두 초안을 쓴다 (문서만 · 실행 · 제출 · 리포 쓰기 없음).**

- **초안 A — 키트 적용 등록 개정** (메모 §5-3): RJ 잡에 RT1 (S0 → P → `write_restart`) · RT2 (그 파일 → P) 두 단계를 넣고, G2c 판정 = RT2 ↔ RT1 · 옛 G2c (R POST ↔ 원 `contact_S0`) = [연속] 보고로 내리는 등록 개정 초안. R 덱 흐름 (PRE · POST · G1–G3 · UN) 은 그대로. 이력 열 = 이력 시험 소비자 꼴. 무엇이 바뀌고 무엇이 그대로인지 · 결과 전 예측 · 판정 규칙 · 주장하지 않는 것 · 1저자 질문 (권고 한 줄).
- **초안 B — MPI 2 차 등록** (메모 §5-4 · §7 Q7): 랭크 경계 고스트 · 이력 지연의 실제 크기 — ibb 의 같은 생산 `lmp_mpi` (md5 0c0daccc2a190d1cf219305bf5286d06) · 같은 샌드박스 침대 · `mpirun -np 2` 와 `-np 4` (cpu-60 · 실제 R 잡의 NP 가 기록에 있으면 그 값도 후보로 적고 근거) 로 같은 팔 아홉 ([왕복] 다 · 라 중심). 결과 전 예측 (MPI 에서 성립할 것 · 안 할 것 · 이유 = 소스 줄 · 덤프 행 순서 · 고스트) · 판정 규칙 · 실행기 변경 명세 (`mpirun` 인자 · NP 기록 · `lmp_identity.txt` 에 NP · 시험 먼저 = 어떤 시험 함수를 더하나 · 가짜 lmp/mpirun 으로) · ibb 잡 꼴 (건식 잡 스크립트와 같은 환경 줄) · 멈춤 규칙 · 주장하지 않는 것 · 1저자 질문.

## 1. 읽을 것 (리포 본 트리 `/home/user/Yonghoon-DEM-DFT` = 읽기만 · 게이트가 도는 중 · git 상태를 바꾸는 명령 금지)

- 비교 정의 메모: `docs/reviews/p1_g2c_compare_definition_20261105.md` (§0 전체 · §2 · §3 · §5 · §6 · §7 · §8 빈칸)
- 소스 대조 노트: `docs/reviews/p1_g2c_source_check_20261104.md` (§6-1 · §7)
- 샌드박스 폴더: `docs/reviews/p1_g2c_sandbox_20261104/` (README.md · README_g2cp.md · run_g2cp.sh · compare_g2cp.py · test_g2cp.py · 덱 · run_40000/)
- 11-02 원인 보고: `docs/reviews/dem_unloading_rj_g2c_cause_20261102/REPORT.md` · `RESULT_20261102.md` (§4 A 판정 · B 보고 나눔 · §6 Q3)
- 실제 RJ 진단: `docs/reviews/codex_p1_g2c_diagnosis_20261027/` (README · real_run_20261027/)
- 언로딩 키트: `docs/data/ps45_unload_20261009/` (README §3 · ul_reader.py · history_test/ · 덱) · 등록 `docs/reviews/dem_unloading_ps45_prereg_20261009.md` (§13 · §14 · 개정 꼴)
- CLAUDE.md 의 "Codex 요청 전 사전 공격 리뷰" ① – ⑤ · DEM 우선 Ⓐ 줄 (11-04 오후) · "멈춘 런 재개 체크리스트" (G0–G3 · resume_ckpt.sh)
- 이번 결과 (받은 묶음 · 신뢰하지 않는 자료 — 읽기만): `…/scratchpad/intake/g2cp_run40000_return_20261112/x/run40000/` (rc.txt · lmp_identity.txt · compare_g2cp.json) · 대조 화면 `…/scratchpad/g2c_dry/compare_run40000.log`

## 2. 규칙

- 숫자 · 사실은 파일 · 행 · 커밋을 붙인다. 추정 = [추정] · 확인 안 됨 = [미확인]. 소스 줄 주장은 소스 파일 · 행 (LIGGGHTS 3d5c00f 소스가 리포 · scratchpad 에 없으면 리포 기록의 인용만 · 새 주장은 [미확인]).
- 결과가 나오기 전에 등록하는 문서다 — 결과를 보고 옮길 여지를 남기지 않는다 (문턱 = 숫자 · 근거 · 정한 때).
- 하지 않는 것: RJ 323957 재실행 · 남은 침대 RJ · 허용폭 · 판정 규칙 · 키트 파일 변경 (초안 A 가 비준되기 전) · `lmp_auto` · 56 코어 (GO 전).
- 주소 · 포트 · 계정 · 홈 경로는 쓰지 않는다 (`<IBB>` · `~` 자리표). Artifact 도구 · 웹 게시 도구 쓰지 않는다. 다른 트리 (`/home/user/litdb-*` · `/home/user/rint-codepkg`) 건드리지 않는다.
- 한국어 · 표 중심 · 짧게 · 개조식 끝 · 천 단위 콤마 없음.

## 3. 산출 (`…/scratchpad/p1g2c/` 에만)

- `kit_amend_draft_A.md` · `mpi_stage2_registration_draft_B.md` · `REPORT.md` (10 줄 안팎 — 무엇을 썼나 · [미확인] 목록 · 1저자 질문과 권고).
- 두 초안 머리에 "초안 · 결과 0 건 · 1저자 비준 전 · 내부 반박 리뷰 전".

## 4. 답장

`REPORT.md` 내용 + 산출 파일 전체 경로. 길게 설명하지 않는다.

"""Read-only package/metadata checks; never executes an inventory or simulator."""
from pathlib import Path
import json,hashlib
ROOT=Path(__file__).resolve().parent
BASE=ROOT/'input'
manifest=json.loads((BASE/'SNAPSHOT_MANIFEST.json').read_text(encoding='utf-8'))
checks=[]
for e in manifest['entries']:
    raw=(BASE/e['path']).read_bytes()
    blob=hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()
    checks.append(dict(path=e['path'],size_ok=len(raw)==e['bytes'],sha256_ok=hashlib.sha256(raw).hexdigest()==e['sha256'],blob_ok=blob==e['git_blob']))
sums=[]
for row in (BASE/'PACKAGE_SHA256SUMS').read_text().splitlines():
    h,n=row.split('  ',1);sums.append(dict(path=n,ok=hashlib.sha256((BASE/n).read_bytes()).hexdigest()==h))
entries=json.loads((ROOT/'remote_main_directory.json').read_text())['entries']
for d in json.loads((ROOT/'remote_other_directories.json').read_text())['results']:entries+=d['entries']
lookup={e['path']:e for e in entries}
remote=[dict(path=e['path'],ok=e['path'] in lookup and lookup[e['path']]['sha']==e['git_blob'] and lookup[e['path']]['size']==e['bytes']) for e in manifest['entries']]
commit=json.loads((ROOT/'remote_commit_scope.json').read_text())
context=json.loads(next(BASE.glob('docs/reviews/*draft_20261105/source_context.json')).read_text())
doc=json.loads((ROOT/'d07_remote_document.json').read_text())['content'].encode()
summary=dict(pin=manifest['pin'],pin_matches=manifest['pin']==(BASE/'PIN.txt').read_text().strip(),checks=checks,package=sums,remote_cached=remote,parent_matches=(BASE/'PARENT_PIN.txt').read_text().strip() in commit['parents'],only_added_documents=all(x['status']=='added' and x['path'].startswith('docs/') for x in commit['files']),d07_sha256=hashlib.sha256(doc).hexdigest(),d07_sha_matches=hashlib.sha256(doc).hexdigest()==context['remote_document_sha256'])
assert summary['pin_matches'] and summary['parent_matches'] and summary['only_added_documents'] and summary['d07_sha_matches']
assert all(all(e[k] for k in ('size_ok','sha256_ok','blob_ok')) for e in checks)
assert all(e['ok'] for e in sums+remote)
(ROOT/'package_recheck.json').write_text(json.dumps(summary,indent=2),encoding='utf-8')
print(json.dumps(dict(pin=manifest['pin'],snapshot=len(checks),package=len(sums),remote=len(remote),passed=True)))

# recheck2 — git 이 훅에 넣는 GIT_* 실측 (unshare -pf --mount-proc --kill-child bash hook_env_probe.sh <작업 폴더>) · 일회용 저장소 X · Y 만
set -u
W=$1; cd $W
for v in $(env | sed -n 's/^\(GIT_[A-Za-z0-9_]*\)=.*/\1/p'); do unset "$v"; done
CFG="-c user.email=t@t -c user.name=t -c commit.gpgsign=false -c init.defaultBranch=main"
git $CFG init -q X && echo a > X/a.txt && git -C X $CFG add -A && git -C X $CFG commit -qm base
printf '#!/bin/sh\nenv | grep "^GIT_" | sort > %s/env_pre_commit.txt\n' "$W" > X/.git/hooks/pre-commit; chmod 755 X/.git/hooks/pre-commit
printf '#!/bin/sh\nenv | grep "^GIT_" | sort > %s/env_pre_push.txt\n' "$W" > X/.git/hooks/pre-push; chmod 755 X/.git/hooks/pre-push
echo b > X/b.txt && git -C X $CFG add -A && git -C X $CFG commit -qm two
git $CFG init -q --bare Y.git && git -C X $CFG push -q $W/Y.git main
cat $W/env_pre_commit.txt; echo ---; cat $W/env_pre_push.txt

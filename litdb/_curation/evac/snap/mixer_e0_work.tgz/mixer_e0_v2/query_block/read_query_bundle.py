#!/usr/bin/env python3
"""read_query_bundle.py — ibb 에서 가져온 믹서 E0 조회 묶음 (mixer_e0_query_<UTC>.tgz · q1–q9) 을 빈 새 폴더에 안전하게 풀고 대조 · 요약한다.

사용 (리포 밖 · 빈 새 폴더 · 격리 모드 · 이 파일은 풀 폴더와 다른 곳에 둔다):
  python3 -I read_query_bundle.py <묶음.tgz> <빈 새 폴더> --expect-md5 <블록 md5> --expect-sha256 <화면 sha256>
         [--json <요약.json (없는 새 파일)>] [--forbid-file <찾을 문자열 목록 파일 (한 줄에 하나 · 계정 · 주소 · 포트 등)>]
하는 일: 묶음 sha256 대조 → 멤버 검사 (out/ 바로 아래 정규 파일만 · 절대경로 · '..' · 링크 · 장치 · 하위 폴더 · 크기 상한 · 소유자 이름 = 거부)
  → 정규 파일만 직접 써서 풂 (extractall 안 씀) → out/SHA256SUMS 전수 대조 → query_script.sh md5 = 블록 md5 → 형식 · 상태 어휘
  → 가림 남은 토큰 0 → (선택) 금지 문자열 0 → q1–q9 요약 (등록 초안 4-1 · 5 절 · 7-4 ③ · 기준 표 2 · 4 · 5 절에 옮길 값).
rc 0 = 묶음 구조 정상.  ⚠ 자격 판정 · 실행 승인이 아니다 (관측일 뿐).  원자료를 리포에 쓰지 않는다 (반입은 본 세션이 따로).
"""
import argparse
import hashlib
import json
import os
import re
import sys
import tarfile

FORMAT = 'mixer_e0_query/1'
MAX_MEMBERS = 500
MAX_MEMBER = 20 * 1024 * 1024
MAX_TOTAL = 100 * 1024 * 1024
STATUSES = {'OK', 'FAIL', 'MISSING', 'TIMEOUT', 'TRUNC', 'SKIPPED_BUDGET', 'SKIPPED_SWITCH', 'SKIPPED_NOT_LUSTRE'}
QS = ['q%d' % i for i in range(1, 10)]
# 비교 기준 (출처 = 등록 초안 · 기준 표 · out/ 의 11-10 메타)
RUNS = [('r1', 'E0_ref_s32452843', '249080'), ('r2', 'E0_ref_s49979687', '249081'), ('r3', 'E0_ref_s67867967', '249082'),
        ('r4', 'E0_ref2_s32452843', '249083'), ('r5', 'E0_ref_dthalf_s32452843', '249084')]
META_POST_ENTRIES = {'r1': 1037, 'r2': 1037, 'r3': 1037, 'r4': 1467, 'r5': 1037}   # 메타 out/fields.txt L348 · L343 · L252 · L201 · L291
META_RESTART_ENTRIES = 3                                                           # 같은 파일 L347 · L337 · L251 · L195 · L290
REG_RUN_SECONDS = {'249080': 13997, '249081': 13956, '249082': 11271, '249083': 17415, '249084': 24521}  # 등록 초안 4-1 (job 시작 → 로그 마지막 수정)
JOB_START_EPOCH = {'E0_ref_s32452843': 1790755936}   # 2026-09-30T08:12:16Z (메타 seal_extract.txt L957) — q2 첫 프레임까지 시간
EST_FRAME_BYTES_52 = 11658 * 1024                    # 등록 초안 5-2 폴더 평균 [추정] 11658 KB / 항목
G_RULE_FRAME_BOUND = 14000512                        # 등록 초안 5-3 교차 확인: %g 규칙 상한 / 장 (100000 원자 · 12 열)
PILOT_FRAME_BOUND = 26000512                         # 등록 초안 5-3 (%.17g · 12 열)
FLOOR_BYTES = 32193231348                            # 등록 초안 5-4 여유 바닥
NOMINAL_ATOMS = 100000                               # q3 exact 프레임의 원자 수는 모른다 — 계획값으로 나눈 값 (근사)
W6 = {'hp': 6 + 2 + 4 * 24 + 6, 'g6': 6 + 2 + 4 * 12 + 6}   # 6 열 한 줄 최악 폭 (등록 초안 5-3 의 규칙을 6 열에 그대로) = 110 · 62 B


def sha256_bytes(b):
    return hashlib.sha256(b).hexdigest()


def kv(text):
    out = {}
    for line in text.splitlines():
        if '=' in line:
            k, v = line.split('=', 1)
            out.setdefault(k, []).append(v)
    return out


def f1(d, k, default=None):
    v = d.get(k)
    return v[0] if v else default


def to_int(s):
    try:
        return int(str(s).strip())
    except (TypeError, ValueError):
        return None


def to_float(s):
    try:
        return float(str(s).strip())
    except (TypeError, ValueError):
        return None


def elapsed_s(s):
    """sacct Elapsed: [D-]HH:MM:SS 또는 MM:SS.mmm → 초"""
    if not s:
        return None
    m = re.fullmatch(r'(?:(\d+)-)?(?:(\d+):)?(\d+):(\d+(?:\.\d+)?)', s.strip())
    if not m:
        return None
    d, h, mi, se = m.groups()
    return int(d or 0) * 86400 + int(h or 0) * 3600 + int(mi) * 60 + float(se)


def mem_bytes(s):
    """sacct MaxRSS / ReqMem: 123K · 1.5G · 4000Mn · 0n → 바이트 (빈칸 = None)"""
    if s is None:
        return None
    m = re.fullmatch(r'\s*(\d+(?:\.\d+)?)([KMGTP]?)([nc]?)\s*', s)
    if not m:
        return None
    mult = {'': 1, 'K': 1024, 'M': 1024 ** 2, 'G': 1024 ** 3, 'T': 1024 ** 4, 'P': 1024 ** 5}[m.group(2)]
    if m.group(2) == '' and s.strip()[-1:] in 'nc':     # ReqMem '0n' 처럼 단위 없는 수 = MB (sacct 관례)
        mult = 1024 ** 2
    return int(float(m.group(1)) * mult)


def extract(a, bad):
    with open(a.tgz, 'rb') as f:
        blob = f.read()
    tsha = sha256_bytes(blob)
    print(f'묶음 sha256 {tsha} · {len(blob)} 바이트')
    if a.expect_sha256 is not None and a.expect_sha256.strip().lower() != tsha:
        bad.append('묶음 sha256 이 화면 값과 다름')
    files = {}
    with tarfile.open(a.tgz, 'r:gz') as tf:
        members = tf.getmembers()
        if len(members) > MAX_MEMBERS:
            bad.append(f'멤버 {len(members)} 개 > {MAX_MEMBERS}')
            return tsha, files
        total = 0
        for m in members:
            n = m.name
            parts = n.split('/')
            if m.uname or m.gname or m.uid or m.gid:
                bad.append(f'소유자 정보가 남음: {n!r}')
            if n == 'out' and m.isdir():
                continue
            if n.startswith('/') or '..' in parts or len(parts) != 2 or parts[0] != 'out' or not parts[1]:
                bad.append(f'멤버 이름 거부 (out/ 바로 아래 파일만): {n!r}')
                continue
            if not m.isfile():
                bad.append(f'정규 파일 아님 (링크 · 장치 · 폴더): {n!r}')
                continue
            if m.size > MAX_MEMBER:
                bad.append(f'멤버 크기 상한 초과: {n!r}')
                continue
            total += m.size
            if total > MAX_TOTAL:
                bad.append('전체 크기 상한 초과')
                break
            files[parts[1]] = tf.extractfile(m).read()
    return tsha, files


def write_out(dest, files):
    od = os.path.join(dest, 'out')
    os.makedirs(od)
    for name, data in files.items():
        with open(os.path.join(od, name), 'xb') as f:
            f.write(data)


def text(files, name):
    b = files.get(name)
    return None if b is None else b.decode('utf-8', 'replace')


def parse_sum(t):
    """r1|run|post|entries=..|files=..|bytes=..|min=..|max=..|other=..|noise=.."""
    if not t:
        return None
    line = t.strip().splitlines()[-1] if t.strip() else ''
    c = line.split('|')
    if len(c) < 4:
        return None
    d = {}
    for x in c[3:]:
        if '=' in x:
            k, v = x.split('=', 1)
            d[k] = to_int(v)
    return d


def summarize(files):
    S = {'q': {}}
    probes = []
    for line in (text(files, 'probes.txt') or '').splitlines():
        c = line.split('|')
        if len(c) >= 6:
            probes.append(c)
    for q in QS:
        rows = [c for c in probes if c[0] == q or c[0].startswith(q + '_')]
        cnt = {}
        for c in rows:
            cnt[c[1]] = cnt.get(c[1], 0) + 1
        S['q'][q] = {'status_counts': cnt, 'not_ok': [c[0] + ':' + c[1] for c in rows if c[1] != 'OK']}
    st = {c[0]: c[1] for c in probes}
    fields = kv(text(files, 'fields.txt') or '')

    # q1
    q1 = []
    for tag, run, job in RUNS:
        r = {'tag': tag, 'run': run, 'job': job}
        du = text(files, f'q1_{tag}_du.txt') or ''
        for line in du.splitlines():
            c = line.split('\t')
            if len(c) == 2 and c[0].isdigit():
                if c[1].endswith('/post'):
                    r['post_du_kb'] = int(c[0])
                elif c[1].endswith('/restart'):
                    r['restart_du_kb'] = int(c[0])
        r['post'] = parse_sum(text(files, f'q1_{tag}_post_sum.txt'))
        r['restart'] = parse_sum(text(files, f'q1_{tag}_restart_sum.txt'))
        r['restart_files'] = []
        for line in (text(files, f'q1_{tag}_restart_ls.txt') or '').splitlines():
            c = line.split('|')
            if len(c) == 4 and c[0] == 'F':
                r['restart_files'].append({'type': c[1], 'bytes': to_int(c[2]), 'name': c[3]})
        r['status'] = {k: st.get(f'q1_{tag}_{k}', 'ABSENT') for k in ('du', 'post_ls', 'post_sum', 'restart_ls', 'restart_sum')}
        ok = all(v == 'OK' for v in r['status'].values()) and r['post'] and r['restart']
        r['ok'] = bool(ok)
        if ok:
            pb, rb, nf = r['post']['bytes'], r['restart']['bytes'], r['post']['files']
            r['post_plus_restart_bytes'] = pb + rb
            r['mean_frame_bytes'] = pb / nf if nf else None
            r['mean_vs_est52'] = r['mean_frame_bytes'] / EST_FRAME_BYTES_52 if nf else None
            r['max_vs_g_rule_bound'] = r['post']['max'] / G_RULE_FRAME_BOUND
            r['post_entries_vs_meta'] = 'same' if r['post']['entries'] == META_POST_ENTRIES[tag] else 'different'
            r['restart_entries_vs_meta'] = 'same' if r['restart']['entries'] == META_RESTART_ENTRIES else 'different'
        q1.append(r)
    S['q1'] = q1

    # q2
    q2 = {'header': {}, 'frames': []}
    for line in (text(files, 'q2_frames.txt') or '').splitlines():
        c = line.split('|')
        if c[0] == 'q2':
            for x in c[1:]:
                if '=' in x:
                    k, v = x.split('=', 1)
                    q2['header'][k] = v if k == 'run' else to_int(v)
        elif c[0] == 'frame' and len(c) == 5:
            q2['frames'].append({'idx': to_int(c[1]), 'step': to_int(c[2]), 'bytes': to_int(c[3]), 'mtime': to_float(c[4])})
    fr = q2['frames']
    if len(fr) >= 2 and fr[-1]['mtime'] is not None and fr[0]['mtime'] is not None and fr[-1]['step'] > fr[0]['step']:
        dt = fr[-1]['mtime'] - fr[0]['mtime']
        ds = fr[-1]['step'] - fr[0]['step']
        q2['steps_per_s_first_to_last'] = ds / dt if dt > 0 else None
        q2['s_per_1000_steps'] = dt / ds * 1000 if ds else None
    run = q2['header'].get('run')
    if fr and run in JOB_START_EPOCH and fr[0]['mtime'] is not None:
        q2['first_frame_after_job_start_s'] = fr[0]['mtime'] - JOB_START_EPOCH[run]
    S['q2'] = q2

    # q3
    q3 = {}
    for name in sorted(files):
        if re.fullmatch(r'q3_d\d+_sizes\.txt', name):
            for line in text(files, name).splitlines():
                c = line.split('|')
                if c[0] == 'exact' and len(c) == 4:
                    m = re.fullmatch(r'(hp|g6)_(\d+)\.liggghts', c[2])
                    if m:
                        q3.setdefault(c[1], {}).setdefault(m.group(2), {})[m.group(1)] = to_int(c[3])
                elif c[0] == 'exact_other' and len(c) >= 3:
                    q3.setdefault(c[1], {})['_other'] = c[2]
    q3s = []
    for d, steps in sorted(q3.items()):
        for step, v in sorted(steps.items()):
            if step == '_other' or not isinstance(v, dict):
                continue
            hp, g6 = v.get('hp'), v.get('g6')
            row = {'dir': d, 'step': step, 'hp_bytes': hp, 'g6_bytes': g6}
            if hp and g6:
                row['ratio_hp_over_g6'] = hp / g6
                row['hp_bytes_per_atom_nominal'] = hp / NOMINAL_ATOMS
                row['g6_bytes_per_atom_nominal'] = g6 / NOMINAL_ATOMS
            q3s.append(row)
    S['q3'] = {'rows': q3s, 'model_line_bytes_6col': W6, 'model_ratio_6col': W6['hp'] / W6['g6'],
               'n_dirs': to_int(f1(fields, 'q3.n_dirs')), 'odd_name_skipped': f1(fields, 'q3.skipped_odd_name')}

    # q4 · q5
    S['q4'] = {'default': (text(files, 'q4_lfs_quota_default.txt') or '').splitlines(),
               'user': (text(files, 'q4_lfs_quota_user.txt') or '').splitlines()}
    osts = []
    for line in (text(files, 'q5_lfs_df.txt') or '').splitlines():
        c = line.split()
        if len(c) >= 6 and c[0].endswith('_UUID') and '[OST:' in c[-1]:
            osts.append({'uuid': c[0], 'kb': to_int(c[1]), 'used_kb': to_int(c[2]), 'avail_kb': to_int(c[3]), 'use': c[4]})
    q5 = {'n_ost': len(osts), 'osts': osts}
    av = [o['avail_kb'] for o in osts if o['avail_kb'] is not None]
    if av:
        q5.update(min_avail_bytes=min(av) * 1024, max_avail_bytes=max(av) * 1024, sum_avail_bytes=sum(av) * 1024,
                  min_avail_vs_floor=min(av) * 1024 / FLOOR_BYTES)
    S['q5'] = q5

    # q6
    q6 = {'header': None, 'jobs': {}}
    for line in (text(files, 'q6_sacct.txt') or '').splitlines():
        c = line.split('|')
        if c[0] == 'JobID':
            q6['header'] = c
            continue
        if q6['header'] is None or len(c) != len(q6['header']):
            continue
        r = dict(zip(q6['header'], c))
        jid = r.get('JobID', '')
        base = jid.split('.')[0]
        j = q6['jobs'].setdefault(base, {'steps': {}})
        if '.' in jid:
            j['steps'][jid.split('.', 1)[1]] = {'State': r.get('State'), 'ExitCode': r.get('ExitCode'), 'MaxRSS': r.get('MaxRSS'),
                                                'MaxRSS_bytes': mem_bytes(r.get('MaxRSS'))}
        else:
            j.update(State=r.get('State'), ExitCode=r.get('ExitCode'), Elapsed=r.get('Elapsed'), AllocCPUS=r.get('AllocCPUS'),
                     ReqMem=r.get('ReqMem'), elapsed_s=elapsed_s(r.get('Elapsed')))
    for jid, j in q6['jobs'].items():
        rss = [s['MaxRSS_bytes'] for s in j['steps'].values() if s['MaxRSS_bytes'] is not None]
        j['max_step_maxrss_bytes'] = max(rss) if rss else None
        if jid in REG_RUN_SECONDS and j.get('elapsed_s') is not None:
            j['elapsed_minus_reg41_s'] = j['elapsed_s'] - REG_RUN_SECONDS[jid]
    S['q6'] = q6

    # q7
    libs = []
    for line in (text(files, 'q7_libs.txt') or '').splitlines():
        c = line.split('|')
        if len(c) == 8 and c[0] == 'lib':
            libs.append({'soname': c[1], 'ldd_path': c[2], 'ldd_path_type': c[3], 'real_path': c[4], 'sha256_or_reason': c[5],
                         'bytes': to_int(c[6]), 'mtime': to_int(c[7])})
    hashed = [x for x in libs if re.fullmatch(r'[0-9a-f]{64}', x['sha256_or_reason'] or '')]
    rp = [l for l in (text(files, 'q7_rpath.txt') or '').splitlines() if 'RPATH' in l or 'RUNPATH' in l]
    bh = (f1(fields, 'q7.bin.hash') or '||').split('|')
    S['q7'] = {'bin_sha256_or_reason': bh[0], 'bin_bytes': to_int(bh[1]) if len(bh) > 1 else None,
               'bin_vs_ref': f1(fields, 'q7.bin.vs_ref'), 'rpath_lines': rp,
               'libs': libs, 'n_paths': sum(1 for x in libs if x['ldd_path_type'] not in ('NOT_FOUND', 'VDSO')),
               'n_hashed': len(hashed), 'n_not_found': sum(1 for x in libs if x['ldd_path_type'] == 'NOT_FOUND'),
               'n_symlink': sum(1 for x in libs if x['ldd_path_type'] == 'symbolic link'),
               'not_hashed': [x['soname'] + ':' + x['sha256_or_reason'] for x in libs
                              if x['ldd_path_type'] not in ('NOT_FOUND', 'VDSO') and x not in hashed]}

    # q8
    parts = []
    for line in (text(files, 'q8_sinfo_partitions.txt') or '').splitlines():
        c = line.split('|')
        if len(c) == 3 and re.fullmatch(r'\d+/\d+/\d+/\d+', c[2]):
            a_, i_, o_, t_ = (int(x) for x in c[2].split('/'))
            parts.append({'partition': c[0], 'avail': c[1], 'alloc': a_, 'idle': i_, 'other': o_, 'total': t_})
    nodes = []
    for line in (text(files, 'q8_sinfo_nodes_cpu.txt') or '').splitlines():
        c = line.split('|')
        if len(c) == 2 and re.fullmatch(r'\d+/\d+/\d+/\d+', c[0]):
            a_, i_, o_, t_ = (int(x) for x in c[0].split('/'))
            nodes.append({'alloc': a_, 'idle': i_, 'other': o_, 'total': t_, 'state': c[1]})
    S['q8'] = {'partitions': parts, 'cpu_nodes': nodes, 'cpu_nodes_with_idle_ge_20': sum(1 for n in nodes if n['idle'] >= 20),
               'note': '시점 값 · 판정 아님 (발사 직전 값은 다시 재야 한다)'}

    # q9
    q9 = {'head': {}, 'blocks': {}}
    for line in (text(files, 'q9_thermo_shape.txt') or '').splitlines():
        c = line.split('|')
        if c[0] == 'q9':
            for x in c[1:]:
                k, _, v = x.partition('=')
                q9['head'][k] = to_int(v)
        elif c[0] == 'block' and len(c) >= 3:
            b = q9['blocks'].setdefault(c[1], {'words': {}})
            for x in c[2:]:
                k, _, v = x.partition('=')
                b[k] = v if k in ('row_cols', 'closed') else to_int(v)
        elif c[0] == 'nonrow' and len(c) == 4:
            q9['blocks'].setdefault(c[1], {'words': {}})['words'][c[2]] = to_int(c[3])
    q9['blocks_with_INFO'] = sorted((k for k, b in q9['blocks'].items() if b['words'].get('INFO:')), key=int)
    S['q9'] = q9
    return S


def show(S):
    print('── 요약 (관측 · 자격 판정 아님)')
    for q in QS:
        sc = S['q'][q]['status_counts']
        print(f"  {q}  " + ' · '.join(f'{k} {v}' for k, v in sorted(sc.items())) + ('' if not S['q'][q]['not_ok'] else '  ← ' + ', '.join(S['q'][q]['not_ok'][:8])))
    print('q1 런별 post · restart (파일 크기 합 = 바이트 · du = KB)')
    for r in S['q1']:
        if r.get('ok'):
            p, rs = r['post'], r['restart']
            print(f"  {r['tag']} {r['run']} job {r['job']}: post 파일 {p['files']} (항목 {p['entries']} · 메타와 {r['post_entries_vs_meta']}) · "
                  f"합 {p['bytes']} B · 평균 {r['mean_frame_bytes']:.0f} B (5-2 어림의 {r['mean_vs_est52']:.3f} 배) · 최대 {p['max']} B "
                  f"(%g 규칙 상한의 {r['max_vs_g_rule_bound']:.3f} 배) · restart {rs['files']} 파일 {rs['bytes']} B · "
                  f"post+restart {r['post_plus_restart_bytes']} B · du {r.get('post_du_kb')} KB + {r.get('restart_du_kb')} KB")
        else:
            print(f"  {r['tag']} {r['run']}: 미완 {r['status']}")
    q2 = S['q2']
    print(f"q2 {q2['header']} · 첫 프레임까지 {q2.get('first_frame_after_job_start_s')} s · 1000 step 당 {q2.get('s_per_1000_steps')} s · "
          f"{q2.get('steps_per_s_first_to_last')} step/s (처음 → 끝 프레임)")
    for f in q2['frames']:
        print(f"    프레임 {f['idx']}: step {f['step']} · {f['bytes']} B · mtime {f['mtime']}")
    print(f"q3 exact (6 열 · 원자 수는 계획값 {NOMINAL_ATOMS} 으로 나눔) · 모델 한 줄 최악 폭 hp {W6['hp']} · g6 {W6['g6']} B · 비 {S['q3']['model_ratio_6col']:.3f}")
    for row in S['q3']['rows']:
        if row.get('ratio_hp_over_g6'):
            print(f"    {row['dir']} step {row['step']}: hp {row['hp_bytes']} · g6 {row['g6_bytes']} · 비 {row['ratio_hp_over_g6']:.3f} · "
                  f"원자당 hp {row['hp_bytes_per_atom_nominal']:.1f} · g6 {row['g6_bytes_per_atom_nominal']:.1f} B")
        else:
            print(f"    {row['dir']} step {row['step']}: 짝 없음 hp {row['hp_bytes']} · g6 {row['g6_bytes']}")
    print('q4 기본 할당 (lfs quota -U):')
    for l in S['q4']['default'][:8]:
        print('    ' + l)
    print('q4 내 할당 (lfs quota -u):')
    for l in S['q4']['user'][:8]:
        print('    ' + l)
    q5 = S['q5']
    print(f"q5 OST {q5['n_ost']} 개" + (f" · 최소 여유 {q5['min_avail_bytes']} B (바닥 {FLOOR_BYTES} B 의 {q5['min_avail_vs_floor']:.1f} 배) · 합 {q5['sum_avail_bytes']} B" if q5.get('n_ost') else ''))
    print('q6 sacct (Elapsed − 등록 4-1 런 시간 · MaxRSS = step 최댓값)')
    for jid, j in sorted(S['q6']['jobs'].items()):
        print(f"    {jid}: {j.get('State')} · {j.get('ExitCode')} · {j.get('Elapsed')} ({j.get('elapsed_minus_reg41_s')} s) · CPU {j.get('AllocCPUS')} · "
              f"ReqMem {j.get('ReqMem')} · MaxRSS 최대 {j.get('max_step_maxrss_bytes')} B")
    q7 = S['q7']
    print(f"q7 바이너리 sha256 {q7['bin_sha256_or_reason']} · {q7['bin_bytes']} B · 09-28 기준과 {q7['bin_vs_ref']} · RPATH/RUNPATH {len(q7['rpath_lines'])} 줄 · 라이브러리 경로 {q7['n_paths']} · "
          f"해시 {q7['n_hashed']} · 링크 {q7['n_symlink']} · not found {q7['n_not_found']} · 해시 못 함 {q7['not_hashed']}")
    for l in q7['rpath_lines']:
        print('    ' + l.strip())
    q8 = S['q8']
    print(f"q8 파티션 {[(p['partition'], p['idle'], p['total']) for p in q8['partitions']]} · cpu 노드 유휴 {[n['idle'] for n in q8['cpu_nodes']]} · "
          f"유휴 ≥ 20 노드 {q8['cpu_nodes_with_idle_ge_20']} (시점 값)")
    q9 = S['q9']
    print(f"q9 {q9['head']} · INFO 줄이 있는 thermo 표 = {q9['blocks_with_INFO']}")
    for k in sorted(q9['blocks'], key=int):
        b = q9['blocks'][k]
        print(f"    표 {k}: 머리 {b.get('header_cols')} 칸 · 숫자 줄 {b.get('rows')} ({b.get('row_cols')}) · 비유한 {b.get('rows_nonfinite')} · "
              f"비-행 {b.get('nonrow')} {b['words']} · 빈 줄 {b.get('blank')} · Loop 로 닫힘 {b.get('closed')}")


def main():
    ap = argparse.ArgumentParser(description='믹서 E0 조회 묶음 (q1–q9) 안전 해제 · 대조 · 요약 (읽기만)')
    ap.add_argument('tgz')
    ap.add_argument('dest', help='없거나 빈 새 폴더')
    ap.add_argument('--expect-md5', default=None, help='블록 머리 · 마지막 줄의 스크립트 md5')
    ap.add_argument('--expect-sha256', default=None, help='ibb 화면에 찍힌 tgz sha256')
    ap.add_argument('--json', default=None, help='요약 JSON 을 쓸 새 파일 (이미 있으면 거부)')
    ap.add_argument('--forbid-file', default=None, help='찾을 문자열 목록 (한 줄에 하나) — 하나라도 나오면 rc 1')
    a = ap.parse_args()
    bad = []
    if os.path.exists(a.dest) and (not os.path.isdir(a.dest) or os.listdir(a.dest)):
        print('거부: 풀 폴더가 비어 있지 않다 (빈 새 폴더만)')
        return 2
    if a.json and os.path.exists(a.json):
        print('거부: --json 파일이 이미 있다 (새 파일만)')
        return 2
    tsha, files = extract(a, bad)
    os.makedirs(a.dest, exist_ok=True)
    write_out(a.dest, files)

    sums = text(files, 'SHA256SUMS')
    if sums is None:
        bad.append('out/SHA256SUMS 없음')
    else:
        listed = set()
        for line in sums.splitlines():
            if not line.strip():
                continue
            h, _, name = line.partition('  ')
            listed.add(name)
            if name not in files:
                bad.append(f'SHA256SUMS 의 파일이 묶음에 없음: {name}')
            elif sha256_bytes(files[name]) != h:
                bad.append(f'sha256 불일치: {name}')
        extra = sorted(n for n in files if n not in listed and n != 'SHA256SUMS')
        if extra:
            bad.append(f'SHA256SUMS 에 없는 파일: {extra[:5]}')
    script = files.get('query_script.sh')
    smd5 = hashlib.md5(script).hexdigest() if script is not None else None
    print(f'query_script.sh md5 {smd5}')
    if a.expect_md5 is not None and smd5 != a.expect_md5.strip().lower():
        bad.append('query_script.sh md5 이 블록 md5 와 다름 (다른 판의 스크립트가 돌았다)')
    fields = kv(text(files, 'fields.txt') or '')
    post = kv(text(files, 'fields_post.txt') or '')
    if f1(fields, 'format') != FORMAT:
        bad.append(f"형식 칸이 {FORMAT} 가 아님: {fields.get('format')}")
    for line in (text(files, 'probes.txt') or '').splitlines():
        c = line.split('|')
        if len(c) >= 6 and c[1] not in STATUSES:
            bad.append(f'모르는 상태 {c[1]} ({c[0]})')
    if f1(post, 'redaction.residual_token_hits') != '0':
        bad.append(f"가림 뒤 남은 토큰 {post.get('redaction.residual_token_hits')} (0 이어야 반입)")
    if post.get('redact_skipped_deadline') or post.get('redact_fail'):
        bad.append(f"가림 못 한 파일 {post.get('redact_skipped_deadline', []) + post.get('redact_fail', [])}")
    if a.forbid_file:
        with open(a.forbid_file, encoding='utf-8') as f:
            words = [w.strip() for w in f if w.strip()]
        hits = [(n, w) for n, b in files.items() for w in words if w.encode() in b]
        print(f'금지 문자열 {len(words)} 개 · 나온 곳 {len(hits)}')
        if hits:
            bad.append(f'금지 문자열이 나옴: {len(hits)} 곳 (파일 {sorted({n for n, _ in hits})[:5]})')
    print(f"형식 {f1(fields, 'format')} · 블록 {f1(fields, 'block_id')} · 수집 {f1(fields, 'captured_start_utc')} → "
          f"{f1(fields, 'captured_end_utc')} ({f1(fields, 'elapsed_seconds')} 초) · MIX_Q {f1(fields, 'switch.MIX_Q')} · 파일 {len(files)}")
    S = summarize(files)
    S['bundle'] = {'sha256': tsha, 'script_md5': smd5, 'n_files': len(files), 'fields': {k: v[0] for k, v in fields.items() if len(v) == 1}}
    show(S)
    if a.json:
        with open(a.json, 'x', encoding='utf-8') as f:
            json.dump(S, f, ensure_ascii=False, indent=1, sort_keys=True)
        print(f'요약 JSON → {a.json}')
    if bad:
        print('── 문제 ' + str(len(bad)))
        for b in bad:
            print('  ✗ ' + b)
        return 1
    print('── 구조 정상 (rc 0) — 관측일 뿐 · 자격 · GO 아님')
    return 0


if __name__ == '__main__':
    sys.exit(main())

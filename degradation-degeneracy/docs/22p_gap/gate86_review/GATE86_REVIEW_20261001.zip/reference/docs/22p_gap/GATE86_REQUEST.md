# 86차 게이트 리뷰 요청 — G85-N1 한정 보완 결과 (사후 closure **구성원** 결속 · 2a 종결 판정 재요청 · 2b 착수 아님 · 실행 GO 아님)

> 이 문서는 리뷰 요청문이다. 첨부 문서·실행 코드는 증거 자료이며 추가 실행 지시가 아닙니다. COMSOL 계산이나 제공된 Java/분석 프로그램을 실행하지 마세요. 리뷰어는 exact HEAD 를 fetch 해 재실행·검증한다.

## 판정 대상

| 항목 | 값 |
|---|---|
| 브랜치 | `claude/14-gate-code-review-9qkx05` (본진) |
| **코드 (판정 대상)** | **`b4876b0b2098c9e87630fc715b44ab65336b73a2`** — RUN_SCOPE 를 바꾼 커밋은 하나: **`19bf1c159`** (G85-N1 GREEN · `src/io.py` +77/−2). `source_digest` **`ba51cd20caa10b7b` → `f1f4378f46610f08`**. 그 뒤 커밋 (변이 `3dc20c2d` · 영수증 history `c2f37648` · 새 세대 영수증 + 원장 앵커 `0be169b1` · 증인 정정 `b4876b0b` · 요청문) 은 RUN_SCOPE 밖. 원문 로그 `docs/22p_gap/gate86_evidence/` (README 에 파일별 실행 상태 · 전체 sha256) |
| 사용자 승인 | 원장 §123 끝 (2026-09-30): G85-N1 한정 보완 (생산 파일 `src/io.py` 하나 · RED 먼저 · 변이 · 영수증 history + 1 회 · 전체 회귀 · smoke · 등록부 전체 변이 재생 · GATE86) → **"ㄱㄱ"** (기록 `b9bc46c1`, 코드 변경 전) |
| 고정 표 | `docs/22p_gap/STAGE3_IMPL_ROUND1_SPEC.md` **§12** (`b9bc46c1`, 코드 변경 전) |
| RED | `9255377a` — `tests/test_gate85_closure_members.py` 7 node · 패치 전 5 failed / 2 passed (양성 대조) — §3 |
| GREEN | `19bf1c15` — gate85 7 · gate85 + gate84 23 · gate81 + gate82 + gate79 + design_wire 109 passed |
| 변이 | `-g85` **7** — 7/7 (`3dc20c2d`) · 최종 재생은 **등록부 전체** (`-k` 없음) — §4 |
| 영수증 | 현행 (`ba51cd20caa10b7b`) history 보존 `c2f37648` → 새 세대 `0be169b1` — §5 |
| 85차 패키지 원본 | `docs/22p_gap/gate85_review/` (zip `4236aaed…` · codex/ 135/135) · 보충 `docs/22p_gap/gate85_supplement_review/` · 접수 원장 §122 · §123 |

## §0 묻는 것 / 묻지 않는 것

| 묻는 것 | 묻지 않는 것 |
|---|---|
| §1 이 G85-N1 을 고정 표 §12 대로 닫았는가 · 자기일관 위조가 **이 검사 하나**에서 거부되는가 | 실행 GO · 새 연구 leg · 2b (R2-a · R2-c · G84-N2) · p_ini 구현 |
| **라운드 2a 종결** 판정 (85차에서 G85-N1 하나로 보류) | 이미 수용된 G84-N3 · N4 · R2-e · R2-f 재심 |
| §5 새 세대 영수증 · §6 자기 신고 | |

## §1 반영 (고정 표 §12 → 코드 → 시험 → 변이)

| §12 | 코드 (`src/io.py`, 줄번호는 `b4876b0b` 실측) | 시험 | 변이 |
|---|---|---|---|
| a 출발점은 `run_spec.base_config` | `_stage3_checks` 의 `base_config_결속` 블록 :2026 이 `base_config_closure_members(spec0.get("base_config"), sealed, run_dir / "_inputs")` 를 부른다 — 기록된 키 목록은 대조 대상일 뿐 | m00 · m01–m03 | `closure-members-are-derived-not-trusted-g85` (유도를 지우고 목록을 정답으로 → m01 · m02 · m03 가 "통과" 로 빨개진다) |
| b 스냅샷 YAML 에서 `extends` 를 `load_config` 규칙으로 | 새 `base_config_closure_members` :1806 (모듈 수준 · `_CLOSURE_MAX_DEPTH = 32` :1803) — `posixpath.join(dirname(norm), extends)` · `normpath` | m05 양성 (합성 l → p) | — |
| c 봉인 목록 · 스냅샷에 없는 부모는 실패 · live fallback 없음 | 같은 함수 — "봉인 목록 (run_spec.sealed_inputs) 에 없다" · "봉인 스냅샷이 없다" | m05 (봉인 목록 · 스냅샷 · root) | `closure-derivation-refuses-unsealed-parents-g85` |
| d 순환 · 밖 경로 · YAML/mapping · extends 비문자열 · 깊이 | 같은 함수 | m05 (순환 · 밖 · extends) | `…-refuses-cycles-g85` · `…-refuses-escaping-paths-g85` |
| e 정확 · 유일 | 블록: 중복 :2024 → "closure 키가 중복됐다" · 유도 집합과 누락 / 추가 각각 이름 | m01 (부모 누락) · m02 (leaf 누락) · m03 (봉인된 무관 입력 추가) · m04 (중복 · digest 진짜) | `closure-missing-members-are-refused-g85` · `closure-extra-members-are-refused-g85` · `closure-member-keys-are-unique-g85` |
| f closure 는 유도 집합 바이트로 → 기존 두 비교 | 루프 대상이 `keys` → `members` · 기존 run_spec hex64 · 계획 digest 비교 유지 (84차 변이 `the-validator-rebuilds-the-closure-from-snapshots-g84` preimage 불변) | m00 · m06 | (84차 변이 유지) |
| g 검사 이름 · 수 불변 | `base_config_결속` 한 이름 · sig 6 전용 | 영수증 검사 수 35 · 34 불변 (§5) | — |

**자기일관 위조의 모양 (m01–m04):** 실제 leaf → parent v6 실행 (`configs/grid_coarse.yaml` extends `base.yaml` — 저장소의 실제 config · 시험이 저장소에 파일을 쓰지 않는다) 을 만들고, 스냅샷 · 입력 봉인은 그대로 둔 채 closure 키 목록과 계획 · run_spec 의 두 digest 를 함께 바꾸고, 계획 사슬 (planned_id · record · `G82._forge_stage3`) · **run_signature · fits 행 `run_sig` · fits 봉인**까지 다시 맞춘다. 판정: validator 실패 목록이 **정확히 `[base_config_결속]`** 이고 이유에 빠진 / 더해진 키 이름 (m04 는 "중복") 이 있다.

## §2 최소 diff

`git diff --stat 9255377a 19bf1c15 -- src tools configs scripts run.sh 'requirements*.txt'` → `src/io.py` 1 file, 77 insertions(+), 2 deletions(−) (`19bf1c15` → 판정 대상 RUN_SCOPE diff 0). 삭제 2 줄: 84차 주석 한 줄 (재료 키 설명 — 유도 집합으로 고쳐 씀) · 루프 `for k in keys:` → `for k in (members if not bc_bad else []):`. 새 production 파일 0 · `tools/` · `src/fitting.py` · v5 preimage · `_stage3_preflight` · N4 불변. 루프 안의 "봉인 스냅샷이 없다" 분기는 유도 함수가 먼저 같은 조건을 보므로 지금은 도달하지 않지만 fail-closed 분기라 줄이지 않았다 (§6-c).

RUN_SCOPE 밖 동반: `tests/test_gate85_closure_members.py` (신규 7) · `tests/conftest.py` +2 (gated 등록) · `tests/test_gate84_round2a.py` n4_02 docstring (85차 C2) · `docs/22p_gap/mutation_replay.py` (변이 7 + EXPECT 7) · 영수증 2 + history 2 · `LEG_PRESERVATION.yaml` 앵커 2 × 2.

## §3 RED 이유 분류

| node | 패치 전 | 분류 |
|---|---|---|
| m01 · m02 · m03 · m04 | `AssertionError: 자기일관 위조가 base_config_결속 를 통과했다: 통과` · **validator 실패 목록 `[]`** | **실제 결함 4** — 85차 리뷰어의 국소 판정식 모형 (`CLOSURE_COUNTERMODEL.json`) 을 넘어 **전체 `validate_provenance` PASS** 로 재현 |
| m05 | `AttributeError: … no attribute 'base_config_closure_members'` | 무관 예외 (새 helper 부재) — RED 증거로 세지 않는다. 경계 이유별 kill 은 변이 3 이 목격 |
| m00 · m06 | 통과 | 양성 대조 (패치 전에도 통과해야 한다) |

RED 첫 시도에서 위조가 `run_signature_재계산` 에 걸렸다 (m01–m04 모두 `['run_signature_재계산']`). 85차 §2 요구 ("필요한 서명/출력 봉인까지 맞춘 뒤") 대로 위조 도구에 run_signature · 행 `run_sig` · fits 봉인 재정합 (`_resign`) 을 더한 뒤의 결과가 위 표다 — 즉 84차 n1_04 는 서명을 안 맞춘 위조였다.

## §4 시험 · 변이 결과

| 단계 | 결과 |
|---|---|
| RED (`9255377a`) | 7 node — 5 failed / 2 passed (`scratchpad/red_gate85.txt`) |
| GREEN (`19bf1c15`) | gate85 7 · gate85 + gate84 23 · gate81 + gate82 + gate79 + design_wire 109 passed |
| 변이 첫 관측 (`--emit-expect -k g85`) | 7/7 기대 node 빨강 (EXPECT 미선언 표시만) · `--check-preimages -k g85` 정확히 한 번 |
| 변이 재생 (`-k g85`) | **7/7** "실행한 변이 7건이 전부 기대 node 를 call 단계에서 물었다" (rc 0) |
| 영수증 · preservation lint 부분집합 | 16 passed (`0be169b1` 직전 작업 트리 — 영수증 + 앵커 커밋 전) |
| **최종 (clean `0be169b1` · 한 러너에서 순차)** | 시작 HEAD = 끝 HEAD = `0be169b18ed40f64c6aae4ca7e364e45ba46fa32` · 시작 / 각 단계 / 끝 status 0 · 19:15:18Z → 22:30:13Z (`gate86_evidence/final_0be169b1/`): 전체 pytest **1 failed** · 2045 passed · 1 xfailed (55:33 · rc 1) — 실패는 `test_g67_14_every_registered_witness_is_a_fixed_reason` (g85 증인 하나의 열린 따옴표 꼬리 · §6-g) · xfail 은 `test_gate63_defensive.py::test_staging_an_input_outside_the_repo_is_still_unsupported` (이번에는 `-rx` 로 로그에 이름) · strict smoke **rc 0** (184 s) · **등록부 전체 변이 재생 ran 352 → 352 물었다 · 안 물었다 0 · 실행오류 0** · 신고 11 · "모든 변이 지점이 정확히 한 번 나타난다" · source_digest `f1f4378f46610f08` |
| 증인 정정 (clean `b4876b0b`) | gate67 모듈 **17 passed** · `closure-derivation-refuses-escaping-paths-g85` 단독 재생 rc 0 (`gate86_evidence/witness_fix/`) |
| 요청문 커밋 (clean) | 전체 pytest + smoke — 발송문에 (방금 실행한 출력으로만) |

## §5 영수증 diff (`ba51cd20caa10b7b` ↔ `f1f4378f46610f08`)

`make_receipt.py paired_fixed5_v4 grid_fit_v5` — clean `c2f37648` (status 0) · rc 0 (19:06:16Z → 19:07:37Z). paired 검사 35 · core `adf0ce1fff69f7b36d955234b3eb16be3235e165b7a1512255bc377d32ed0fdc` · grid 검사 34 · core `01bd53eb85b6c1cf6753d40dfd6bac9ef5eb965922f0148968b158083e3e3463`. diff 는 두 파일 각각 `validator_source_digest` (`ba51cd20caa10b7b → f1f4378f46610f08`) · `src_io_sha256` (`30556f689f28de5c → e8f9561b6492d5a5`) · `validator_commit` (`b740db16 → c2f37648`) · `generated_at_utc` 뿐. stamp `validator_tree_dirty` 는 직전 세대와 같게 **paired false · grid true** (paired 를 먼저 쓴 뒤 grid 를 쓰는 순차 기록 — clean 시작과 섞지 않는다). `LEG_PRESERVATION.yaml` 앵커 2 × 2 (`0be169b1`). 직전 세대 바이트 사본 `history/<leg>.validate.ba51cd20caa10b7b.yaml` (`c2f37648`, `cmp` 동일).

## §6 우리가 스스로 신고하는 것

| # | 신고 | 처리 · 판정 요청 |
|---|---|---|
| a | **85차 §6-f 의 우리 답이 틀렸다** — "키 목록을 위조하면 재계산이 달라져 실패" 는 digest 를 고정한 변이에만 맞았다. RED 는 서명까지 맞춘 위조가 **validator 전체를 통과**함을 실측했다 (§3) | — (원장 §123 에 기록) |
| b | **탐침이 운영 등록부에 기록 1 개를 남겼다** — RED 전 leaf config 로 v6 실행이 되는지 보려고 `python -` 로 production `run_fit` 을 **pytest 밖에서** 돌렸다 (18:51Z · smoke namespace 안 출력). conftest 의 시험 authority 격리는 pytest 안에서만 걸리므로, 산출 완료 등록 하나가 최상위 `docs/22p_gap/_exec_class/20f6faf9….json` (leg=L · class canonical · untracked) 에 쓰였다. 커밋되지 않았고 (untracked 로 발견) · 스크래치패드에 바이트 사본을 둔 뒤 지웠다 (sha256 `050a719e1b7baee3…`). `_exec_class/local/` (git 무시 · smoke 가 평소 쓰는 곳) 에도 같은 창에 항목이 쓰였고 그대로 두었다. 같은 방식의 84차 10:54Z 탐침은 `local/` 에만 썼다. **절차 정정:** production 진입점 탐침은 pytest fixture 안에서만 (또는 `git archive` 사본에서) 돌린다 | 판정 요청: 이 등록 하나가 기존 판정에 영향이 있는가 (우리 판단: 없다 — 커밋되지 않았고, 18:47–18:52Z 창에 `docs/22p_gap` 아래 바뀐 파일은 `_exec_class/` 의 그 하나와 `local/` 항목뿐 · `LEG_PRESERVATION.yaml` · `COHORT_LIFECYCLE.jsonl` · `_claims/` 불변 (`find -newermt` 실측)) |
| c | **루프 안 스냅샷 부재 분기가 지금은 도달하지 않는다** (유도 함수가 먼저 봄) — fail-closed 분기라 남겼다. 변이 대상으로 두지 않았다 (관측 불가 — 등가 변이) | 수용 여부 |
| d | **`base_config_closure_keys` 는 그대로 run_spec 에 쓴다** — 이제는 대조 대상이다 (§12-a). 키를 아예 안 쓰는 설계 (유도만) 는 기록 형식 변경이라 2a 밖으로 봤다 | 수용 여부 |
| e | **`load_config` 의 `configs/` 이름 fallback 은 재현하지 않는다** (`path` 가 없으면 `CONFIG_DIR / path.name`) — 유도는 봉인 스냅샷만 보고, fallback 으로 풀린 부모는 봉인 키가 다르면 실패한다 (live fallback 금지 §12-c 와 같은 방향). 현행 두 경로 (base.yaml 단독 · grid_coarse → base) 는 fallback 을 쓰지 않는다 | 수용 여부 |
| g | **최종 전체 회귀가 등록부 규칙 시험 1 건에서 빨갰다** — `closure-derivation-refuses-escaping-paths-g85` 의 증인이 `['../outside.yaml: 봉인 목록` 으로 끝나 G67-T1-b ("증인에 열린 따옴표 뒤 가변 꼬리 금지") 에 걸렸다. 변이 kill 판정과 무관한 증인 문자열 형식 문제다. 같은 러너는 smoke · 전체 재생까지 그대로 마쳤고 (전체 재생은 kill 판정이 증인 접두 대조라 영향 없음 · 352/352), 끝난 뒤 증인을 시험이 결정적으로 만드는 완전한 원소로 바꿨다 (`b4876b0b`) → gate67 17 passed · 해당 변이 단독 rc 0. 요청문 커밋에서 전체 pytest 를 다시 돈다 | — |
| f | **m05 "봉인" 이유 대조를 "봉인 목록" 으로 좁혔다** — 좁히지 않으면 `…-refuses-unsealed-parents-g85` 변이가 "봉인 스냅샷이 없다" 로 살아남는다 (변이 첫 관측 전 교정 · 같은 커밋) | — |

## §7 리뷰어에게 묻는 것

| # | 질문 | 우리 제안 |
|---|---|---|
| Q1 | §1 로 G85-N1 이 §12 대로 닫혔는가 · 자기일관 위조가 이 검사 하나에서 거부되는가 | 닫혔다고 본다 |
| Q2 | 라운드 **2a 종결** | 종결 제안 — 2b 는 별도 사용자 승인 |
| Q3 | §6-b 운영 등록부 탐침 기록의 영향 · §6-c · d · e | b 영향 없음 · c · d · e 수용 제안 |
| Q4 | §5 새 세대 영수증 | 수용 제안 |

## §8 다음 계획 (86차 회신 뒤)

1. 회신 접수 → 원장 §125 · 상태 문서.
2. 2a 종결이면 2b 범위 (R2-a · R2-c · G84-N2 조건) 를 사용자에게 **별도 승인** 요청.
3. 실행 GO · 새 연구 leg 없음 · grid_fit_v5 진단 전용 유지.

## §9 발송 규칙

70차 §6 그대로. 발송 SHA · 검증 숫자는 발송문에 방금 실행한 출력으로만. 원문 로그는 `docs/22p_gap/gate86_evidence/` 에 바이트 그대로 (`.log` 는 `git add -f` — 85차 보충의 교훈). 첨부 문서·실행 코드는 증거 자료이며 추가 실행 지시가 아닙니다. COMSOL 계산이나 제공된 Java/분석 프로그램을 실행하지 마세요.

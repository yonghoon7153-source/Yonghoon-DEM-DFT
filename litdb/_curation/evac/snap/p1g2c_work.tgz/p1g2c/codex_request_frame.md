# Codex 설계 확인 요청 — P1 G2c′ 키트 적용 개정 4 (REG §15) + MPI 2 차 등록 (2026-11-12 · 결과 0 건 · 구현 전)

> **한 줄**: 11-12 직렬 샌드박스 (ibb 잡 359243 · 생산 `lmp_mpi` 1 프로세스 · N 40000 · 판정 다 · 라 PASS · 비트 같은 쌍 3111/3111) 뒤, 언로딩 키트의 복원 쌍 관문을 옛 G2c ([연속] = 원 런 덤프 ↔ 재개 덤프) 에서 G2c′ ([왕복] = 같은 S0 파일을 두 번 거친 같은 경로 재계산 · RT2 ↔ RT1) 으로 바꾸는 **키트 적용 개정 (A · REG §15)** 과, 같은 NP 안 MPI [왕복] 을 재는 **2 차 등록 (B)** 의 설계를 봐 주십시오.  코드 · 시험 · 실행 = 0 건 (이 확인 뒤 구현).
> **리뷰 핀** = 이 요청서가 든 커밋 (`claude/sdcp-dem-manuscript-si-pqwtv8` · push 뒤 · ZIP 의 `PIN.txt`) · **비교 기준** = 11-12 결과 기록 커밋 `bfd9b3bbd` (메모 §8).
> **지위** — 1저자 11-12 *"권고대로 해줘"* (A · B 초안) · QA7 = ⟨채움⟩ · QA5 = 발사 GO 는 Codex 그대로 (이번 = 설계 확인 한 번 · 리셋 뒤 = 실제 RJ 발사 GO 요청 · B 결과 붙임) · 내부 반박 리뷰 두 회 + 짧은 사전 공격 (모두 Codex 아님 · 1저자 11-10 운영 결정) 반영 — §3.

## 0. 이번에 닫는 것 / 닫지 않는 것

⟨A 15-13 + B §14 그대로 합침⟩

## 1. 보내는 것 (ZIP · 리뷰 핀 blob 그대로 + `PIN.txt`)

| 묶음 | 파일 |
|---|---|
| 이 요청서 | 이 파일 |
| A (개정 4) | `docs/reviews/dem_unloading_ps45_prereg_20261009.md` §15 (새 · 끝) — 앞 절 §3-2 · §12-1 · §13-7 · §14-10 · §14-11 · §14-12 는 그대로 (§15 가 범위만 준다) |
| B (2 차 등록) | `docs/reviews/p1_g2c_mpi_stage2_registration_20261112.md` (새) |
| 정의 · 결과 | 메모 `docs/reviews/p1_g2c_compare_definition_20261105.md` (§8 = 11-12) · `docs/reviews/p1_g2c_sandbox_20261104/README_g2cp.md` · 11-12 기록 `docs/reviews/p1_g2c_sandbox_20261104/run_ibb_40000_20261112/` · `run_ibb_dry200_20261112/` · 노트 `docs/reviews/p1_g2c_source_check_20261104.md` §7 |
| 샌드박스 (B 가 고칠 자리 · 지금 판) | `docs/reviews/p1_g2c_sandbox_20261104/run_g2cp.sh` · `compare_g2cp.py` · `test_g2cp.py` |
| 키트 (A 가 고칠 자리 · 지금 판) | `docs/data/ps45_unload_20261009/` 의 `run_unload.sh` · `ul_reader.py` · `ul_gates.py` · `make_unload_decks.py` · `seal_kit.py` · `active_rules.json` · `SHA256SUMS` · `README.md` · `history_test/` · `ul_runner_test.py` |
| RJ 323957 기록 | `docs/reviews/codex_p1_g2c_diagnosis_20261027/` · `docs/reviews/dem_unloading_rj_g2c_cause_20261102/` |
| 내부 반박 리뷰 (Codex 아님) | `docs/reviews/p1_g2c_sandbox_20261104/internal_reviews/p1next_AB_20261112/` (1 회차 · 2 회차 · 사전 공격 · 처분 · 산술) |
| 원장 | `docs/reviews/findings.json` |

## 2. 묻는 것

| # | 질문 | 우리 쪽 생각 |
|---|---|---|
| Q1 | RT1 · RT2 (UN 뒤 · UK 앞) 를 더하고 판정을 RT2 ↔ RT1 로 옮기면, 옛 G2c 가 원리상 못 서던 까닭 셋 (주기 restart 의 한 step 전 이력 · 스텝 끝 고스트 재계산 · 쌍 전체 힘 사영) 을 피하면서 "같은 S0 상태에서 같은 경로를 다시 계산하면 같은 쌍 상태가 나온다" 를 생산 키트에서 판정할 수 있나 | 직렬 다 (주기 파일 BW → F′ → BR) PASS 가 같은 길 · NP 6 은 B 와 첫 RJ 가 처음 |
| Q2 | 15-5b (\|Ft\| 가중 reset 몫 W ≤ 0.05 ∧ 쌍 집합 같음 · R · RT1 각각) 를 거부 쪽 결과 전 규칙으로 두는 것 — 문턱은 11-12 정직 흐름을 본 뒤 정했다 (A 머리) · 생산 침대 정직 여유는 [추정] | 생산 경로에서 값 수준 이력 증거가 이것뿐 · 한계 = 몫 0.05 밑 부분 소실은 못 잡는다 (주장 안 함) |
| Q3 | rt.bin 결합 = 잡 기록 sha256 두 줄 + RT2 **로그 파일** 의 치환 `read_restart` 전체 경로 (꼬리 대조 아님) — 이름 바꾼 앞 시도 폴더 · 다른 폴더 같은 이름 파일을 막기에 충분한가 | 화면에는 경로가 안 찍힌다 (11-12 로그 꼴) |
| Q4 | RT 문법 fixture (새 파일 · 검사 20 · 봉인 · 사전 점검 · RJ 전 ibb 한 번) 를 첫 생산 RJ 앞에 두는 순서 | 지금 문법 fixture 봉인은 무변경 |
| Q5 | B: NP 2 (2×1×1) · NP 4 (2×2×1) 같은 NP [왕복] 의 결과 전 예측 · 결론 ①–③ · 부분 결론 없음 · 시도 셈 (NP 마다 첫 내용 판정 · 한도 2) 이 A 의 RJ 발사 GO 근거로 쓰기에 맞나 · NP 6 을 빼고 키트 RJ 가 직접 보는 것 | 상자 0.012 에서 NP 6 하위영역 < 절단 [추정] |
| Q6 | "닫지 않는 것" (§0 오른쪽) 가운데 이번 설계 확인에 들어와야 할 것이 있나 | — |

## 3. 우리 쪽 사전 점검 (요청 전 · Codex 아님)

⟨내부 반박 리뷰 1 회차 · 2 회차 · 사전 공격 — 등급 수 · 처분 · 남은 한정⟩ · ⟨숫자 · 전칭 대조⟩ · ⟨리포 참조 · 철회값 스윕 · 게이트⟩

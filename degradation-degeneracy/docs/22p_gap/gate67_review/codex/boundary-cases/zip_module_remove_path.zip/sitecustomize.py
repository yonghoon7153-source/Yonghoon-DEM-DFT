import os, sys
_arc=os.path.dirname(__file__)
sys.path[:]=[p for p in sys.path if os.path.normcase(os.path.normpath(p)) != os.path.normcase(os.path.normpath(_arc))]

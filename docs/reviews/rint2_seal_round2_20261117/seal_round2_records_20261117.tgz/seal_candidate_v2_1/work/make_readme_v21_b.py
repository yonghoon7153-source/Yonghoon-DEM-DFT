"""README v2.1 뒤 반 — 글자 자리 대조 뒤 바꿈 + 절 "v2 → v2.1" 넣기.  argv: <파일 (그 자리에서 고침)>"""
import sys

p = sys.argv[1]
s = open(p, encoding='utf-8').read()
SCRV = '/tmp/claude-0/-home-user-Yonghoon-DEM-DFT/81c0ad95-542f-503b-9cf7-2f6a678a4b5b/scratchpad'


def rep(old, new, n=1):
    global s
    assert s.count(old) == n, (s.count(old), old[:80])
    s = s.replace(old, new)


V21 = '''## v2 → v2.1 (내부 반박 리뷰 · **Codex 아님** · 11-17 · 리뷰 = `<scratch>/rint/seal_candidate_v2_review/REVIEW.md`)

- 처분 규칙 = 1저자 11-16 Q2 (P1 = 보류 · P2 · P3 = 알려진 한계로 적고 진행) · 이 판 = P2 둘 **고침 (자기 시험 먼저 · 고치기 전 판에서 실패 확인 뒤)** · P3 = 글 · 도구로 고칠 것 7 · README 한정 5 (메인 지시 11-17).  "시험 고치기 전 → 뒤" = 같은 자기 시험을 v2 판 판정 코드 (`work/check_sh_commands_v2_plus_selftest.py` · `work/make_sealed_copy_v2_plus_tests.py` = v2 바이트 + 새 시험만) 와 v2.1 판에 돌린 수 [실측].

| # | 지적 (리뷰) | 처분 | 시험 고치기 전 → 뒤 · 근거 |
|---|---|---|---|
| P2-1 | 증거 ③ 도구가 꼴이 다른 명령 줄 (`python3 -I` · `-u` · sh 울타리 아님) 을 조용히 빼고 rc 0 (변이 D2 · D3 · D4 · D8b · D10) | **고침** — 모든 울타리 읽기 · 도구 이름이 든 조각이 `python3? <…>/<도구>` 꼴이 아니면 문제 (첫 낱말 `git` · `ls` … = 인자로만 나온 줄 · 따로 셈) · sh · bash 밖 울타리의 도구 줄 = 문제 · 기대 셈 (`--expect`) ≠ 읽은 수 = 문제 · sh 명령 0 개 = 문제 · 원본 자리에 sh 실행 줄 = 문제 · `ladder_dry` 밖 "한 문서에만" = 문제 · bash (인자 계약 꼴) = `--registration` 없음이 설계라 오류로 만들지 않고 "계약 꼴" 로 따로 센다 | 자기 시험 19 경우 (리뷰 D0 – D10 + 새 D11 – D16 · D2b): 고치기 전 **6/19** (D2 · D3 · D4 · D8b · D10 = rc 0 그대로 · D9 = rc 1 이지만 다른 까닭 · 새 반례 8 = rc 0) → 뒤 **19/19** [실측 `evidence/e3_sh_argparse.txt`] |
| P2-2 | `make_sealed_copy.py` 가 계획이 실제로 돌 수 있는지 (두 계획 대조 · 결과 전 넷 · Q3 꼴) 를 안 본다 (A22 – A25) | **고침** — 계획 바이트 = Q3 꼴 (`json.dumps(…, indent=1, sort_keys=True)` · ASCII · 끝 줄바꿈 없음) · 핀 사슬 `plans_cross_problems(계획, S0 계획) == []` · `--final` (봉인 때 필수) = 핀 사슬 `require_plan_numbers` 와 같은 판정 · `--final` 없이 = 후보 (넷 null 도 만든다 · `_manifest.json` `seal_status` = "후보 · 봉인 값 아님") · 새 확인 셋 = `_manifest.json` `plan_checks` (v2 의 사슬 대조 11 개 `checks` 그대로) | 자기 시험 35 (v2 17 그대로 + 새 18): 고치기 전 **17/35** → 뒤 **35/35** · 리뷰 변이 34 = 거부 19 → **30** · 리뷰 `e_s0gate` 틀린 계획 다섯 = v2.1 도구가 봉인본을 만들기 전에 거부 [실측 `evidence/e11_make_sealed_copy.txt` · `evidence/e5_fixture_build.txt`] |
| P3-1 | 측정 뒤 바뀐 상태 (본 리포 HEAD · stoic-next · 5a04acd15 원격 밖 · 원격 ref 153) | **고침** — 때에 따라 바뀌는 문장 = "11-17 06:56 UTC 측정 값" 으로 · 지금 값 (본 리포 HEAD = 원격 stoic `b3481336c` · stoic-next `5645b86c8` · 5a04acd15 · b3481336c · b80f10d08 · c0c3b1ff5 = 원격 stoic 안 · 원격 ref @@REFN@@ 개) · e12 다시 잼 | `evidence/e12_stoic_refs.txt` (G″) · 조각 머리 줄 · §마-4 · §바 |
| P3-2 | ⑤ "후보 = 넷 때문에만 거부" = 관문의 첫 실패만 | **한정** (아래 한정 표 ①) · v2.1 도구가 tol_ff · len_law · env_unit 틀린 계획을 만들기 전에 거부하므로 그 뒤 대조는 고정물 값 커밋 통과 + 도구 거부가 함께 덮는다 | `evidence/e5_fixture_build.txt` |
| P3-3 | `--check-doc` rc 0 은 계획 바이트를 묶지 않는다 · `--init` 은 등록을 읽지 않는다 | **한정** (②) · 도구 쪽은 이제 계획 바이트 Q3 꼴을 본다 (P2-2) | 리뷰 `repro/b_plan_bytes/` |
| P3-4 | 도구 조각 꼴 허점 (A02 · A10 · A11 · A15 · A17 · A30 · A34 조용히 통과) | **고침** — 빈 블록 · last · mid+last 블록에 줄바꿈 · `|` · 조각 이름 집합 고정 (R-MARK · R-00 – R-15 · K-01 – K-05) · 남은 자리표 = 허용 목록 (35) · 날짜 = `datetime.strptime` · 가지 = git 가지 이름 규칙 (`.lock` 끝 · `//` · `.` 시작 성분 · `@{`) | 위 P2-2 의 자기 시험 · 리뷰 변이 (일곱 다 거부) |
| P3-5 | 명령 문서 (2b) venv 켬 · 판 출력 없음 · same-version 줄과 S0 줄이 안 묶임 · `\\| tee` 가 rc 를 가림 | **고침** — (2b) 첫 줄 = venv 켬 + 판 출력 (기대 `3.8.10 1.24.4 1.10.1`) · `git diff --quiet … && echo SAME_VERSION_OK && python3 …/ca_s0_census.py …` · 끝 `; echo "rc=${PIPESTATUS[0]}"` (bash) | 증거 ③ (S0 줄 그대로 읽힘 · 13 + 1 · 14 + 1) |
| P3-6 | 원장 받는 쪽 — 되살림 (`mv`) 과 `pull` 사이 창 · 블록 rc 0 | **고침** — 받는 쪽 = 세워 둔 자리에서 먼저 `git -C ca1_ledger.parked -c pull.rebase=false pull -q --ff-only … && mv …` (그동안 그 기계 사슬은 원장 자리를 못 연다 = 창 없음) · 끝 = `test "$(git -C ca1_ledger rev-parse HEAD)" = <넘김 기록의 원장 끝 커밋> && echo RECV_OK` · 봉인본 §10-7 ① 글도 같은 차례 · `-c pull.rebase=false` 는 [추정] (옛 git 의 rebase 설정) | 넘김 흉내 ① ② ③ 결과 OK [실측 scratch `work/check_relay_block.py` · 증거 표 '넘김'] |
| P3-7 | 넘김 기록 표가 실행 트리 안 명령 문서에 있다 | **한정** (③) | — |
| P3-8 | `--registration` 을 빼면 "멈출 뿐" 의 비용 | **한정** (④) | — |
| P3-9 | 증거 도구 날짜 고정 (`20261120`) | **고침** — `check_chain_functions.py <트리> <날짜>` · `check_s0_stage2_gate.py … <날짜>` | §아 |
| P3-10 | 원본 자리 머리 표지로 줄 +1 · 판 없이 줄 번호를 적은 문서 | **한정** (⑤ · 수 = 리뷰 실측) | — |
| P3-11 | ③ 도구가 값 일부만 본다 | **고침** (P2-1 과 함께) — `--cjunc-store` 값 = `~/ca1_cjstore` 글자 대조 (Q4 · 사다리 · dry-run · 단위 · 점) · 사다리 `--law` P0 = kgy · P1 = gabia (Q6 · `ledger --add ladder:<법칙>` 도) · 보지 않는 것 = `--out` 값 · 단위 이름 ↔ 첫 배정 (도구 머리 글에 적음) | 자기 시험 D9 (Q4 표지) · D16 (Q6 표지) |
| P3-12 | 작은 글 · 줄 번호 | **고침** — 러너 "통과 = 734 줄" → **733 줄** (핀 판 `scripts/sdcp_gain_vox015_8arm.sh` 733 줄 `echo "[p2] 규율 검사 통과"` [실측]) · 명령 문서 T_hit "(중앙값)" 지움 (3 판 = 한 런 실측 4,932 s · 봉인본 R-13 ⑩ 과 같은 글) · `command -v python3` 기대 = `~/dem-venv/bin/python3` · 도구 머리 글 = 쓰는 곳 (`--out` · 옆 `.msc_out_*` · 시스템 임시 `msc_*`) · `_manifest.json` = 입력 파일 이름 안 넣음 · 이 README 의 scratch 절대 경로 3 곳 = `<scratch>` | 이 README · 조각 · 도구 |

### v2.1 한정 (알려진 한계 · 고치지 않음 · 리뷰 문장을 다듬음 · 근거 줄 그대로)

| # | 한정 | 근거 |
|---|---|---|
| ① (P3-2) | ⑤ 의 "후보 = 넷 때문에만 거부" 는 관문 `verify_plan_commit` 의 **첫 실패**만 보인다 — 그 차례 = … `require_plan_numbers` → tol_ff 대조 → len_law 대조 라 넷이 null 이면 뒤 대조는 돌지 않는다 · 뒤 대조의 증거 = 고정물 값 커밋 (넷 밖 칸 = 후보와 같은 값) 의 통과 + v2.1 도구가 틀린 tol_ff · len_law 계획을 만들기 전에 거부 | [코드] `scripts/ca_s0_census.py` @64e4d213e `verify_plan_commit` (require_plan_numbers 993 줄 · tol_ff 996 · len_law 999) |
| ② (P3-3) | 사슬 `--stage plan-doc --check-doc` rc 0 = **블록 같음 (바이트 아님)** — 끝 줄바꿈 · indent 2 · `1.0e-12` 꼴 계획도 `PLAN_DOC_SAME` · 계획 바이트를 묶는 것 = 단계마다 `check_plan_registered` (해시 줄) · `--stage ledger --init` 은 등록을 읽지 않는다 → 계획 사본 바이트가 틀리면 원장 머리가 틀린 sha 로 생기고 첫 `--add` · 사다리에서 멈춘다 (새 원장) · 봉인 때 넣을 수 있는 기계 대조 한 줄 (이 판 문서에 넣지 않음 · 권고): `python3 -c 'import sys,hashlib; sys.path.insert(0,sys.argv[1]); import rint_r_chain as R; print(R.check_plan_registered(hashlib.sha256(open(sys.argv[2],"rb").read()).hexdigest(), sys.argv[3])["plan_hash"][:12], "PLAN_REGISTERED_OK")' ~/dem-ca1/scripts ~/sdcp/ca1_plan.json ~/dem-ca1/<봉인본>` | 리뷰 `repro/b_plan_bytes/` [실측] · [코드] 사슬 8539–8540 줄 |
| ③ (P3-7) | 넘김 기록 표 (명령 문서 §3-1b (5)) 는 **실행 트리 밖 사본** (1저자 · 본 세션 리포) 에 적는다 — `~/dem-ca1` 안 그 문서를 고치면 `git status` dirty → 다음 `--add` · 단계 입구 · 판정 = `CODE_PIN_MISMATCH` 로 멈춘다 (틀린 결과 없음 · 되돌리면 풀림 · 돌고 있는 단계는 다시 보지 않는다) | [코드] 사슬 948 · 1949 · 1985 줄 |
| ④ (P3-8) | `--registration` 을 빼면 "멈출 뿐" 이지만 공짜가 아니다 — 시도 꼴은 시도 폴더 · 시작 기록 · 결과 줄 (결과 전) 을 쓰고 멈춘다 = 그 대상 최대 시도 8 중 하나 · 판정은 멈춘 `verdict.json` 을 `--out` 에 남겨 같은 폴더를 다시 못 쓴다 → 원장 항목 하나 · 판정 폴더 하나가 쓰인다 | [코드] 사슬 3667–3765 · 6627–6660 · 8185–8205 줄 |
| ⑤ (P3-10) | 원본 자리 머리 표지 한 줄로 원본 자리 줄 번호가 핀 판보다 1 밀린다 — 판 없이 "등록 R … N 줄" · "[R] N 줄" 을 적은 문서 **6 개 · 55 줄** (봉인 기록 밖 · 리뷰 실측 · 이 판이 다시 세지 않음) 은 봉인 커밋 판에서 N+1 · 꼴 (머리 표지 자리) = 1저자 Q1 결정 그대로 · 시험은 다 지남 | 리뷰 P3-10 |
'''

rep('## 1저자 결정 (11-17 · 봉인 후보 Q1 – Q8', V21 + '\n## 1저자 결정 (11-17 · 봉인 후보 Q1 – Q8')
# §나 R-13 row · 도구가 본 것
rep('| R-13 | 660 줄 뒤 | **§10-6 저장본**', '| R-13 | 660 줄 뒤 | (v2.1 = §10-7 ① 받는 쪽 차례 = 세워 둔 자리에서 먼저 `pull --ff-only` 뒤 되살림 · `RECV_OK`) **§10-6 저장본**')
# §다 K-03 row
rep('| K-03 | 564 줄 앞 | **§3-1b** — 머리', '| K-03 | 564 줄 앞 | (v2.1 = (2) `python3` 기대 자리 · (2b) venv 켬 + 판 출력 · `&&` 묶음 · rc 줄 · (5) 받는 쪽 차례 + `RECV_OK` · (6) T_hit "(중앙값)" 지움) **§3-1b** — 머리')
rep('보낸 쪽 `flock` + `bundle create --all` + 세워 두기 → 받는 쪽 `clone -b` → 다시 보낸 쪽 → 세워 둔 사본 되살려 `pull --ff-only` · 끝 커밋 같음',
    '보낸 쪽 `flock` + `bundle create --all` + 세워 두기 → 받는 쪽 `clone -b` → 다시 보낸 쪽 → (v2.1) 세워 둔 사본 **자리에서 먼저** `pull --ff-only` 뒤 되살림 · 끝 = `RECV_OK` 기계 대조 [실측 scratch `work/check_relay_block.py` ① ② ③] · 끝 커밋 같음')
# §라
rep('- **꼴** = `json.dump(plan, f, indent=1, sort_keys=True)` · 끝 줄바꿈 없음 · `s_min_um` = `0.0` · `max_hours` = `168` (Q3).',
    '- **꼴** = `json.dump(plan, f, indent=1, sort_keys=True)` · 끝 줄바꿈 없음 · `s_min_um` = `0.0` · `max_hours` = `168` (Q3) — v2.1 도구가 바이트로 본다 (다르면 rc 2 · 리뷰 P2-2).')
rep('→ `make_sealed_copy.py --plan <봉인 계획> --seal-date <날짜>` → 봉인본 해시 칸 · 블록이 바뀐다 (사람이 옮기지 않는다).',
    '→ `make_sealed_copy.py --plan <봉인 계획> --seal-date <날짜> --final` (v2.1 · 넷이 다 채워져야 · 두 계획 대조 · Q3 꼴) → 봉인본 해시 칸 · 블록이 바뀐다 (사람이 옮기지 않는다).')
# §마-1 표 머리 글
rep('(표 = 증거 e10 그대로 (G) · 경로 `20261120` = 보기 날짜 · G′ = 같은 표에서 봉인 기록 폴더만 36 (증거에 G 결과 · `e12` · `e13` · `e1` F · G 판을 더함) [실측 · scratch evidence/raw/G2_seal_files.txt (scratch 후보 폴더 · 리포 밖)])',
    '(표 = 증거 e10 그대로 (G″ · v2.1) · 경로 `20261120` = 보기 날짜 · G′ ↔ G″ 파일 구성 같음 (바뀐 바이트만) [실측 · `evidence/e10_seal_files.txt`])')
rep('| A | `docs/reviews/rint2_seal_20261120` | 31 | 밖 | 밖 | 밖 |', '| A | `docs/reviews/rint2_seal_20261120` | 36 | 밖 | 밖 | 밖 |')
# §마-2
rep('`scripts/sdcp_gain_vox015_8arm.sh` 724–731 줄 · 통과 = 734 줄]', '`scripts/sdcp_gain_vox015_8arm.sh` 724–731 줄 · 통과 = 733 줄 (v2 "734" = 다음 줄 · 리뷰 P3-12)]')
rep('→ **봉인 꼴 커밋 (최종 등록부) 에서 핀 판 규율 검사 = 0 오류 · rc 0 (경고 17)** [실측 · ⑦].', '→ **봉인 꼴 커밋 (최종 등록부) 에서 핀 판 규율 검사 = 0 오류 · rc 0 (경고 17)** [실측 · ⑦ · v2.1 = G″a 다시].')
# §마-3
rep('봉인 꼴 커밋에서 **사슬 시험 전체 506/506 · E17 1/1** [실측 ① ②]', '봉인 꼴 커밋에서 **사슬 시험 전체 @@E1@@ · E17 1/1** [실측 ① ② · v2.1 = G″a]')
rep('— 봉인 꼴 커밋 G 에서 셋 다 돌림: `test_probe6_read.py` 357/357 · `test_ca_ext_z3.py` 84/84 · `test_ca_s0_census.py` 186/186 · 셋 다 rc 0',
    '— 봉인 꼴 커밋 G″a (v2.1) 에서 셋 다 돌림: `test_probe6_read.py` @@E14P@@ · `test_ca_ext_z3.py` @@E14Z@@ · `test_ca_s0_census.py` @@E14C@@')
rep('→ G′ 도 같은 입력]', '→ G″ 도 같은 입력]', n=1)
# §마-4
rep('(본 리포 `refs/remotes/origin/*` 153 개와 이름 · 객체 같음 [실측])', '(본 리포 `refs/remotes/origin/*` 와 이름 · 객체 같음 — v2 때 153 개 · v2.1 G″ 검사 직전 다시 받음 = @@REFN@@ 개 [실측])')
rep('| 3 판 v3/review3_internal_20261117/REVIEW.md (stoic 판) → 커밋 5a04acd15 | 본 리포 로컬 HEAD (원격 밖 · 지금 게이트 중) |',
    '| 3 판 v3/review3_internal_20261117/REVIEW.md (stoic 판) → 커밋 5a04acd15 | v2 측정 때 = 본 리포 로컬 HEAD (원격 밖) · 11-17 06:56 UTC = 원격 stoic 안 (리뷰 P3-1 · 처분은 그대로) |')
rep('- 처분 뒤 = **rc 0 · 없는 경로 0 · 없는 커밋 0** (최종 봉인 꼴 커밋 G′ · 이 README 와 `evidence/` 포함) [실측 · G′ = scratch evidence/raw/G2_check_doc_refs.txt (scratch 후보 폴더 · 리포 밖) (그 커밋 자신의 출력이라 리포 사본에 못 넣음) · F = `evidence/e9_check_doc_refs.txt` 4b 절 (rc 0) · G (중간) = 같은 파일 4c 절 (없는 경로 2 = 이 README 가 가리키는 새 증거 둘이 G 의 증거 폴더에 아직 없던 판 → G′ 에서 넣음)].',
    '- 처분 뒤 = **rc 0 · 없는 경로 0 · 없는 커밋 0** (v2 = G′ · v2.1 = G″ @@E9@@ · 이 README 와 `evidence/` 포함 · G″ 자신의 출력 = scratch `evidence/raw/G2b_check_doc_refs.txt` · 리포 사본 = `evidence/e9_check_doc_refs.txt` 끝 절 (G″a 위 같은 검사 · README · `evidence/` 결과 파일만 다르다) · v2 절 그대로 (F 4b · G 4c))].')
# §마-5
rep('→ `make_sealed_copy.py` (봉인 날짜 · 가지 이름 · 봉인 계획 · 핀 판 원본 · 사슬 · S0 계획) → 출력 넷',
    '→ `make_sealed_copy.py --final` (봉인 날짜 · 가지 이름 · 봉인 계획 · 핀 판 원본 · 사슬 · S0 계획) → 출력 넷')
# §바
rep('- 봉인 꼴 트리에서 리포 게이트 전체 (`scripts/check_all.sh`) 는 돌리지 않았다 — 원본 자리 · 원장을 읽는 게이트 시험 셋은 G 에서 돌렸고',
    '- 봉인 꼴 트리에서 리포 게이트 전체 (`scripts/check_all.sh`) 는 돌리지 않았다 — 원본 자리 · 원장을 읽는 게이트 시험 셋은 G″a (v2 = G) 에서 돌렸고')
rep('- stoic 가리킴의 커밋 (b3481336c · b80f10d08 · c0c3b1ff5) = 지금 본 리포 로컬 가지 tmp-stoic-next 에만 (원격 밖 · push 전) [실측] → 봉인 때 원격 stoic 의 커밋으로 다시 확인 (`git branch -r --contains` · blob 이 같으면 그대로) [미확인].',
    '- (v2.1 · 닫힘) stoic 가리킴의 커밋 (b3481336c · b80f10d08 · c0c3b1ff5) = v2 측정 때 원격 밖 → **11-17 06:56 UTC = 원격 stoic 안** (`git branch -r --contains` · `evidence/e12_stoic_refs.txt`) · 봉인 때 한 번 더 본다 (stoic 끝이 움직이면 blob 만 같으면 된다).')
rep('- 원본 자리 머리 표지 한 줄 때문에 원본 자리의 줄 번호가 핀 판보다 1 밀린다 → 다른 문서의 "등록 R N 줄" (판 없이 적은 것) 은 봉인 커밋 판에서 N+1 — 판 (`64e4d213e`) 을 같이 적는 것이 안전 [실측 · 한정].',
    '- 원본 자리 머리 표지 한 줄 때문에 원본 자리의 줄 번호가 핀 판보다 1 밀린다 → 다른 문서의 "등록 R N 줄" (판 없이 적은 것 · 6 문서 · 55 줄 · 리뷰 실측) 은 봉인 커밋 판에서 N+1 — 판 (`64e4d213e`) 을 같이 적는 것이 안전 [실측 · 한정 · v2.1 한정 표 ⑤].')
rep('- 봉인본 sh 블록은 리포 시험이 읽지 않는다 (K01 = 원본 자리 · 명령 문서 bash 만) — 인자 대조 = 이 후보의 도구 (증거 ③) · 봉인 때 다시 [한정].',
    '- 봉인본 sh 블록은 리포 시험이 읽지 않는다 (K01 = 원본 자리 · 명령 문서 bash 만) — 인자 대조 = 이 후보의 도구 (증거 ③ · v2.1 = 꼴 · 셈 · 값 (Q4 · Q6) 을 지킨다 · `--out` 값 · 단위 ↔ 첫 배정 은 보지 않는다) · 봉인 때 다시 (`--expect` = 그때 독립 셈) [한정].')
# §사
rep('## (사) stoic 기록 가리킴 (봉인 가지에 넣지 않은 것 · 커밋 · 경로 · blob · 이 후보가 `git cat-file -e` 로 확인 [실측 · `evidence/e12_stoic_refs.txt` = 8/8 있음 · stoic-next 세 커밋 = 원격 가지 0 개 · 2da71fe5a = 원격 가지 4 개])',
    '## (사) stoic 기록 가리킴 (봉인 가지에 넣지 않은 것 · 커밋 · 경로 · blob · 이 후보가 `git cat-file -e` 로 확인 [실측 · `evidence/e12_stoic_refs.txt` (v2.1 · G″) = @@E12@@])')
# §아
rep('''    --plan <봉인 계획> --s0-plan <11-16 cjunc_plan.json> --chain <핀 트리>/scripts/rint_r_chain.py --seal-date <봉인 날짜> [--seal-branch <가지>] --out <빈 폴더>
python3 -I make_sealed_copy.py --selftest --chain <핀 트리>/scripts/rint_r_chain.py      # 17/17''',
    '''    --plan <봉인 계획> --s0-plan <11-16 cjunc_plan.json> --chain <핀 트리>/scripts/rint_r_chain.py --seal-date <봉인 날짜> [--seal-branch <가지>] [--final] --out <빈 폴더>
#   (--final = 봉인 때 필수 · 없으면 후보 = 결과 전 넷 null 도 만든다 · _manifest.json seal_status 로 가른다)
python3 -I make_sealed_copy.py --selftest --chain <핀 트리>/scripts/rint_r_chain.py      # 35/35 (v2.1)''')
rep('python3 -I evidence/tools/check_sh_commands.py <사본> docs/reviews/rint2_seal_<날짜>/registration_R_sealed.md <새 가짜 홈>',
    'python3 -I evidence/tools/check_sh_commands.py <사본> docs/reviews/rint2_seal_<날짜>/registration_R_sealed.md <새 가짜 홈> --expect sealed=13+1,kgy=14+1   # 기대 셈 = 독립 셈\npython3 -I evidence/tools/check_sh_commands.py --selftest <사본> docs/reviews/rint2_seal_<날짜>/registration_R_sealed.md --expect sealed=13+1,kgy=14+1   # 19/19')
rep('python3 -I evidence/tools/check_s0_stage2_gate.py <사본> <고정물 값 도구 출력> <새 둘째 사본>',
    'python3 -I evidence/tools/check_s0_stage2_gate.py <사본> <고정물 값 도구 출력 (--final)> <새 둘째 사본> <날짜>')
rep('python3 -I evidence/tools/check_chain_functions.py <사본>', 'python3 -I evidence/tools/check_chain_functions.py <사본> <날짜>')
rep('```\n', '```\n', n=s.count('```\n'))
s = s.rstrip('\n') + '\n# 넘김 흉내 (scratch · 봉인 커밋 밖 · v2.1)\npython3 -I work/check_relay_block.py <사본> <원장 --init 고정물 계획> <없는 일 자리>\n```\n' if s.rstrip('\n').endswith('```') else s
s = s.replace('python3 -I evidence/tools/make_committed_evidence.py evidence/raw evidence <사본>/docs/reviews/claims.json   # 리포 사본 증거 (요약 · 가림)\n```\n# 넘김',
              'python3 -I evidence/tools/make_committed_evidence.py evidence/raw evidence <사본>/docs/reviews/claims.json   # 리포 사본 증거 (요약 · 가림)\n# 넘김')
s = s.replace(SCRV, '<scratch>')
assert SCRV not in s, '남은 scratch 절대 경로'
open(p, 'w', encoding='utf-8').write(s)
print('ok')

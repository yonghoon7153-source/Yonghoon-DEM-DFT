import importlib.util, sys, unittest, collections
from pathlib import Path
tree = Path(sys.argv[1])
spec = importlib.util.spec_from_file_location('test_mixer_precal_observe', tree/'scripts'/'test_mixer_precal_observe.py')
T = importlib.util.module_from_spec(spec); sys.modules['test_mixer_precal_observe'] = T; spec.loader.exec_module(T)
class R(unittest.TestResult):
    def __init__(s, *a, **k):
        super().__init__(*a, **k); s.sub = collections.Counter(); s.subfail = 0; s.ok = 0
    def addSubTest(s, test, subtest, err):
        super().addSubTest(test, subtest, err); s.sub[test.__class__.__name__] += 1; s.subfail += err is not None
    def addSuccess(s, test):
        super().addSuccess(test); s.ok += 1
suite = unittest.defaultTestLoader.loadTestsFromModule(T)
r = R(); suite.run(r)
print('tests run', r.testsRun, 'methods ok', r.ok, 'failures', len(r.failures), 'errors', len(r.errors))
print('subtests by class', dict(r.sub), 'subtest failures', r.subfail)

#!/bin/bash
# run_tests.sh — 조회 블록 (query_block.txt) 컨테이너 시험 · 가짜 HOME · 가짜 명령 · PID 이름공간 안에서만
#   unshare -pf --mount-proc --kill-child bash test/run_tests.sh
#   신호: 이 시험은 직접 kill 하지 않는다.  멈춘 가짜 명령 (t4) 은 블록 안의 timeout 이 자기 프로세스 묶음에만 TERM → KILL 을 보낸다.
#   ibb · 원격 접속 없음.  쓰는 곳 = test/run_<UTC>/ 하나 (가짜 홈 · 결과 · 기록).
set -u
[ "$$" = 1 ] || { echo "거부: PID 1 이 아님 — 'unshare -pf --mount-proc --kill-child bash $0' 로만 돈다"; exit 2; }
HERE=$(cd "$(dirname "$0")" && pwd); QB=$(dirname "$HERE")
BLOCK="$QB/query_block.txt"
MD5=$(tail -n 1 "$BLOCK" | grep -o '= [0-9a-f]\{32\} \]' | grep -o '[0-9a-f]\{32\}')
[ -n "$MD5" ] || { echo "블록 md5 를 못 읽음"; exit 2; }
T="$HERE/run_$(date -u +%Y%m%dT%H%M%SZ)"; mkdir -p "$T"
echo "test root $T · block md5 $MD5 · bash $BASH_VERSION"
SENT="sbatch scancel scontrol srun salloc squeue sacctmgr rm mv cp ln chmod chown truncate git conda sudo kill pkill mpirun mpiexec python3 python touch dd shred"

mkbin() {  # mkbin <사례> <가짜 목록…> → $T/<사례>/bin (가짜 명령 + 금지 명령 감시)
  local b="$T/$1/bin" f; shift
  mkdir -p "$b"
  for f in "$@"; do
    case "$f" in readelf=127) ln -s "$HERE/fakes/readelf127" "$b/readelf";; *) ln -s "$HERE/fakes/$f" "$b/$f";; esac
  done
  for f in $SENT; do ln -s "$HERE/fakes/sentinel" "$b/$f"; done
}
run_case() {  # run_case <사례> <세계 꼴> <가짜 목록 (쉼표)> <셸 꼴: plain | inter> [VAR=값 …]
  #   블록은 따로 만든 마운트 이름공간에서 돈다: / 와 /dev/shm 을 읽기 전용으로 다시 붙이고 가짜 세계 (W) 와 기록 폴더 (IO) 만 쓰기 가능
  #   → 블록이 새 폴더 밖 (W 밖) 에 쓰려 하면 EROFS 로 실패한다.  W 안은 전후 스냅숏으로 새 폴더 하나만 바뀌었는지 본다.
  local n=$1 variant=$2 fakes=$3 mode=$4 W IO t0 t1 rc sh
  shift 4
  W="$T/$n/w"; IO="$T/$n.io"
  python3 "$HERE/mkworld.py" "$W" "$variant" || { echo "mkworld 실패 $n"; return 1; }
  mkbin "$n" ${fakes//,/ }
  mkdir -p "$IO"
  python3 "$HERE/check_run.py" snap "$W" > "$T/$n.snap_before.json"
  if [ "$mode" = inter ]; then sh='bash --norc --noprofile -i'; else sh='bash'; fi
  t0=$(date +%s.%N)
  unshare -m env RO_W="$W" RO_IO="$IO" RO_BLK="${BLK:-$BLOCK}" RO_SH="$sh" RO_PATH="${XPATH:-}$T/$n/bin:/usr/local/bin:/usr/bin:/bin" bash -c '
    mount --make-rprivate / && mount --bind "$RO_W" "$RO_W" && mount --bind "$RO_IO" "$RO_IO" \
      && mount -o remount,bind,ro / && mount -o remount,bind,ro /dev/shm || { echo "읽기 전용 마운트 실패" > "$RO_IO/stderr"; exit 97; }
    cd "$RO_W/cwd" || exit 98
    exec env -i HOME="$RO_W/hroot/home/fakeuser" USER=fakeuser LOGNAME=fakeuser PATH="$RO_PATH" TMPDIR="$RO_W/tmp_outer" LANG=C.UTF-8 TERM=dumb \
      HISTFILE="$RO_IO/history" FAKE_CALLS="$RO_IO/calls" FAKE_SENTINEL="$RO_IO/sentinel" "$@" \
      timeout 900 $RO_SH < "$RO_BLK" > "$RO_IO/stdout" 2> "$RO_IO/stderr"' run_case "$@"
  rc=$?
  t1=$(date +%s.%N)
  echo "$rc" > "$T/$n.rc"
  awk -v a="$t0" -v b="$t1" 'BEGIN { printf "%.2f\n", b - a }' > "$T/$n.secs"
  for x in stdout stderr calls sentinel history; do [ -e "$IO/$x" ] && cp "$IO/$x" "$T/$n.$x"; done
  [ -e "$T/$n.stdout" ] || : > "$T/$n.stdout"
  python3 "$HERE/check_run.py" snap "$W" > "$T/$n.snap_after.json"
  echo "── $n rc=$rc $(cat "$T/$n.secs") 초"
}
ALL=sacct,sinfo,lfs,df,stat,hostname,id,du

# t1 전부 (mawk) · t2 전부 (gawk — ibb 와 같은 awk 종류)
run_case t1 full "$ALL" plain FAKE_LUSTRE=1
mkdir -p "$T/gawk"; ln -s /usr/bin/gawk "$T/gawk/awk"
XPATH="$T/gawk:" run_case t2 full "$ALL" plain FAKE_LUSTRE=1
# t3 실패 섞기: E0_ref2 런 폴더 없음 · sacct 없음 · sinfo 실패 · lfs quota -U 실패 · readelf 127 (→ objdump)
run_case t3 fail "sinfo,lfs,df,stat,hostname,id,du,readelf=127" plain FAKE_LUSTRE=1 FAKE_SINFO_MODE=fail FAKE_LFS_U_MODE=fail
# t4 멈춘 명령: sacct 가 TERM 을 무시하고 600 초 잔다 → timeout 60 + kill 5
run_case t4 full "$ALL" plain FAKE_LUSTRE=1 FAKE_SACCT_MODE=hang
ps -eo args | grep -c -E '(^/bin/bash .*/bin/sacct )|(^sleep 600$)' | tr -d ' ' > "$T/t4.leftover"
# t5 예산 1 초 (첫 du 가 2 초 걸림)
run_case t5 full "$ALL" plain FAKE_LUSTRE=1 MIX_BUDGET=1 FAKE_DU_DELAY=2
# t6 MIX_Q=q8 만
run_case t6 full "$ALL" plain FAKE_LUSTRE=1 MIX_Q=q8
# t7 Lustre 아님 · MIX_Q='q4 q5'
run_case t7 full "$ALL" plain FAKE_LUSTRE=0 'MIX_Q=q4 q5'
# t8 게이트: (a) 본문 한 글자 (b) CRLF (c) 대화형 bash -i (d) CRLF 를 DEM1 sed 로 고친 사본 = 원본
sed '0,/q1–q9 시작/s//q1–q9 시직/' "$BLOCK" > "$T/block_onechar.txt"
cmp -s "$T/block_onechar.txt" "$BLOCK" && echo "경고: 한 글자 바꾸기가 안 됨"
BLK="$T/block_onechar.txt" run_case t8a full "$ALL" plain FAKE_LUSTRE=1
sed 's/$/\r/' "$BLOCK" > "$T/block_crlf.txt"
BLK="$T/block_crlf.txt" run_case t8b full "$ALL" plain FAKE_LUSTRE=1
run_case t8c full "$ALL" inter FAKE_LUSTRE=1
sed 's/\r$//' "$T/block_crlf.txt" > "$T/block_crlf_fixed.txt"
if cmp -s "$T/block_crlf_fixed.txt" "$BLOCK"; then echo same > "$T/t8d.cmp"; else echo different > "$T/t8d.cmp"; fi

python3 "$HERE/check_run.py" check "$T" "$MD5" | tee "$T/check.txt" | tail -n 3
cp "$T/check.txt" "$HERE/last_run.txt"
grep -q '^== PASS [0-9]* · FAIL 0$' "$T/check.txt"

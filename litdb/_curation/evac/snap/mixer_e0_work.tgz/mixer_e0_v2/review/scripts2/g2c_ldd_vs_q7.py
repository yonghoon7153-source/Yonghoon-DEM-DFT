"""재리뷰 (Codex 아님) — G2c' 잡 359243 의 job 안 ldd 기록 ↔ QY q7 (로그인 셸) 대조.
값 (경로 문자열) 은 출력하지 않는다. 셈 · 참거짓만.
쓰는 법: python3 -I -B g2c_ldd_vs_q7.py <REPO> <QY summary.json>
job ldd 꼴: 1 vdso · 29 'soname => path (addr)' · 1 로더 'path (addr)' (9 번째) · 끝 'ldd_rc N'.
q7 꼴: 31 항목 (vdso · 로더 포함). 위치 2–31 (30 개) 을 맞춘다.
"""
import json, re, sys
repo, summ = sys.argv[1], sys.argv[2]
ldd = open(repo + '/docs/reviews/p1_g2c_sandbox_20261104/run_ibb_40000_20261112/lmp_ldd.txt', encoding='utf-8').read().splitlines()
q7 = json.load(open(summ, encoding='utf-8'))['q7']['libs']
job = []
rc = None
for l in ldd:
    t = l.split()
    if len(t) == 2 and t[0] == 'ldd_rc':
        rc = t[1]; continue
    if '=>' in t:
        job.append((t[0], t[2]))
    elif len(t) == 2 and t[1].startswith('(0x'):
        job.append(('<bare>', t[0]))
print('job ldd entries', len(job), '| ldd_rc', rc)
print('q7 entries', len(q7))
j = job[1:]                      # 1 = vdso 빼고
q = q7[1:]
print('compared positions', len(j), len(q))
son_eq = sum(1 for (s, _), d in zip(j, q) if s == d['soname'] or (s == '<bare>' and 'ld-linux' in d['soname']))
path_eq = sum(1 for (_, p), d in zip(j, q) if p == d['ldd_path'])
dot = sum(1 for _, p in j if '/./' in p)
print('soname same (order, loader bare line counted by name)', son_eq, '/', len(q))
print('ldd path string same', path_eq, '/', len(q))
print('"./" form paths in job ldd', dot)
print('libs NOT dlopen-listed by ldd (q7 is ldd too) -> no MCA / PRTE components in either list')

import json, sys, os
summ, d1110, qy = sys.argv[1], sys.argv[2], sys.argv[3]
S = json.load(open(summ)); F = S['bundle']['fields']
runmap = {'1': 23, '2': 22, '3': 9, '4': 1, '5': 14, '6': 11, '7': 16, '8': 12, '9': 21}
fl = open(os.path.join(d1110, 'fields.txt')).read().splitlines()
same = 0
for i, n in runmap.items():
    run = F['q9b.l%s.run' % i]
    path = [l for l in fl if l.startswith('mix3_run%d.path=' % n)][0]
    assert path.endswith('/' + run), (i, n)
    st = F['q9b.l%s.stat' % i].split('|')
    ls = [l for l in open(os.path.join(d1110, 'mix3_run%d_ls.txt' % n)) if l.rstrip('\n').endswith('|log.liggghts')][0].split('|')
    ok = (st[1] == ls[1] and st[2] == ls[2].split('.')[0])
    same += ok
    print(i, run, 'size', st[1], ls[1], 'mtime', st[2], ls[2].split('.')[0], 'SAME' if ok else 'DIFF')
print('logs same as 11-10:', same, '/ 9')
Q = json.load(open(qy))
q9 = Q['q9']; l1 = S['q9b']['logs']['1']
rows_qy = [q9['blocks'][k]['rows'] for k in sorted(q9['blocks'])]
rows_qb = [l1['table_summary'][k]['rows'] for k in sorted(l1['table_summary'])]
print('r1 lines', q9['head']['lines'], l1['lines_total'], 'tables', q9['head']['blocks'], l1['tables'], 'rows', rows_qy, rows_qb)
fr = {f['step']: f['bytes'] for f in Q['q2']['frames']}
for pos, f in S['q2b']['frames'].items():
    print('q2b', pos, f['step'], f['bytes'], 'QY q2', fr.get(int(f['step'])), 'SAME' if fr.get(int(f['step'])) == int(f['bytes']) else 'DIFF')
print('QY q2 header', Q['q2']['header'], 'QB pick', S['q2b']['pick'])
pe = [l for l in fl if l.startswith('mix3_run23.dir.post.entries=')]
print('11-10', pe)
c1110 = open(os.path.join(d1110, 'conda1_meta.txt')).read().split()
for k, p in S['q7b']['pkgs'].items():
    print('q7b', k, p['name'], p['json'], 'in 11-10 conda1_meta:', p['json'] in c1110, 'line', (c1110.index(p['json']) + 1) if p['json'] in c1110 else None)

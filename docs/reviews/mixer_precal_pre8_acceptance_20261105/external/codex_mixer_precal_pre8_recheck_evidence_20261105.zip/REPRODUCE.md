# PRE8-01/02 외부 재확인 증거

대상 `ec484c2719d6a444214ddc9c48fe683a7735688b`, 이전 `189930cc68b6e58beb6b4546d80353dc03852195`.

판정은 `codex_review_mixer_precal_pre8_recheck_20261105.md`를 읽는다. input/은 사용자 ZIP을 바이트 그대로 푼 자료이고, task/는 독립 소형 탐침과 실제 JSON 결과다. remote_directories.json은 원격 고정 핀 API 응답에서 추출한 파일 신원 목록이고 remote_verification.json은 89파일 대조다. 원 외부 ZIP 안에 과거 입력 ZIP도 보존되어 있어 `replay_external.py old`는 다운로드 폴더 없이 재현한다.

NumPy/SciPy가 있는 Python으로 이 디렉터리에서 실행:

```text
python -I -B -X utf8 verify_intake.py
python -I -B -X utf8 run_resident.py
python -I -B -X utf8 replay_external.py old
python -I -B -X utf8 replay_external.py fixed
python -I -B -X utf8 task/pre8_absence/probe_pre8_absence.py
python -I -B -X utf8 task/pre8_loader/probe_loader.py
python -I -B -X utf8 task/pre8_boundary/probe_boundary.py
```

실제 사용: Windows 11, Python 3.12.14, NumPy 2.5.3, SciPy 1.16.3. 실제 ibb/WSL/DEM·연구 자료는 사용하지 않았다. 모든 소스 변경 주입은 작업 내 임시 복사본에 한다. resident 임시 위치를 작업 디렉터리로 지정했으며 대상 코드나 테스트는 고치지 않았다.

상주 관측 시험 원본은 27 OK / 1 ERROR / rc 1이다. ERROR는 symlink 생성의 WinError 1314이며 환경을 바꾸어 강제로 통과시키지 않았다. 일부 callback 내부 symlink 생성 실패는 관측기의 TECH 예외 처리로 메서드가 통과할 수 있으므로, 실제 symlink 분기 성공으로 세지 않는다. 독립 absence 탐침은 실제 링크 capability를 먼저 점검하여 21 예정 조합을 미실행으로 기록했다.

원 반례 9관측 전후, 추가 absence71관측, loader12관측, boundary7그룹은 다른 단위이며 합계 시험 수를 만들지 않는다. 독립 소형 관측은 validate_case 단위 경계만 mock한다. 생성기 자체 읽기와 lazy import의 별도 검사는 메모리 정적 자료이며 실제 연구 덱을 발사하지 않는다.

loader 최초 임시폴더 실패와 boundary 래퍼 실패 기록은 각각 task의 initial_environment_failure.json, review.json에 보존한다. 외부 원반례의 portable 경로 수정 후 옛 코드 재생 로그도 별도로 남겼다. 시행 수를 새 증거 수로 더하지 않는다.

기존 준비14/전체 게이트/실제100000입자 양성/실제로그 호환성/현장 파일시스템은 이번 독립 실행 범위가 아니다. 문서 전달 정정을 실제 P1 수치 검증으로 전용하지 않는다. 전체 HOLD, 실제 실행·등록·배포·통합·원장 종결 미승인.

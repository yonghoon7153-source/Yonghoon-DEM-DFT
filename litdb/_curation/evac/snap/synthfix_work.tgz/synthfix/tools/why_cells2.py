#!/usr/bin/env python3
"""S6_2 '왜' 칸 분류 (읽기 전용): 묶음 줄의 넷째 칸 (왜 / 근거 위치) 과 견준다."""
import re, sys, json
from collections import Counter
LR = '/tmp/claude-0/-home-user-Yonghoon-DEM-DFT/d26d1e75-209f-540f-83a8-c0e1957edc2f/scratchpad/handoff_litread_20261112/litread'
doc = open(LR + '/synth/out/S6_2_insights.md', encoding='utf-8').read().split('\n')
bund = open(LR + '/synth2/q_m2.md', encoding='utf-8').read().split('\n')
cur = None; by_batch = {}
for l in bund:
    m = re.match(r'^### \[batch_(\d+)\]', l)
    if m:
        cur = int(m.group(1)); by_batch[cur] = []; continue
    if cur is not None and l.startswith('- '):
        by_batch[cur].append(l)
for b in sorted(by_batch):
    ncell = Counter(len(re.split(r' [|│] ', l)) for l in by_batch[b])
    print('b%02d 줄 %d · 칸 수 분포 %s' % (b, len(by_batch[b]), dict(ncell)))
    print('    예:', by_batch[b][0][:230])
LOC = re.compile(r'§|L\d|Fig|Table|표 |p\.?\s?\d|eq|식 |줄 \d|SI |Eq|T\d')
rows = []
for ln, l in enumerate(doc, 1):
    if not re.match(r'^\| MB-\d+ \|', l):
        continue
    cells = [c.strip() for c in re.split(r'(?<!\\)\|', l)[1:-1]]
    if len(cells) != 7:
        continue
    bs = sorted(set(int(x) for x in re.findall(r'\[b(\d+) ·', cells[6])))
    rows.append((cells[0], bs, cells[3], bool(LOC.search(cells[3]))))
noloc = [r for r in rows if not r[3]]
print('왜 칸에 위치 낱말이 없는 줄', len(noloc), sorted(Counter(tuple(r[1]) for r in noloc).items()))

# new_papakyriakou2021_mechanical_behavior_inorganic_li_solid_electrolytes_nanoindentation 정독 근거 (새 카드 · 원문 PDF 10 쪽 전문 (SI 없음) + 카드 451 줄 · 2026-11-10)

카드: `papakyriakou2021_mechanical_behavior_inorganic_li_solid_electrolytes_nanoindentation` — M. Papakyriakou, M. Lu, Y. Liu, Z. Liu, H. Chen, M. T. McDowell & S. Xia,
"Mechanical behavior of inorganic lithium-conducting solid electrolytes", Journal of Power Sources 516 (2021) 230672,
DOI 10.1016/j.jpowsour.2021.230672 (© 2021 Elsevier B.V. · SI 없음).  정본 커밋 `716143621`.

적는 법: 위치의 `L숫자` = 카드 줄 번호 (451 줄 판) · `p.n` = 논문 쪽.  표지는 카드에 적힌 그대로
(`[인쇄]` = 본문 · 표 · 그림 안 숫자 · `[판독]` = 그림에서 읽음 (digitized.csv 990 행 · 그림이 전부 벡터 경로) · `[카드 산술]` · `[카드 해석]` · `[정본 카드]` = 다른 정본 카드 값 · `[미확인]`).
재료 = **Li₆PS₅Cl 순수 SE — 열간 가압 (240 °C · 360 MPa · 2 h) 펠릿의 건식 연마면 · 3D 실물** — 같은 재료다.  단 입자 · 분말 침대 · 냉간 펠릿이 아니고, 상대밀도 91 % 의 분모 (진밀도) 와 측정법이 없어 랩 표준 (1.64 g/cm³ · 순수 SE 기공 10–13 %) 과 견줄 수 없다.
**Li₆PS₅Cl 의 상온 (25 °C) 경도 · 탄성률 · 응력 지수는 본문에 숫자로 인쇄돼 있지 않다 — 전부 그림 판독이다** (인쇄는 −40 · 300 °C 의 환산 탄성률 · 감소율 · 활성화 부피뿐).
대조 재료 (Li₁₀SnP₂S₁₂ · LAGP · LLZTO 2 종 · 석영 유리) 값은 우리 재료 값이 아니다.  계산 모델 (DEM · FEM · MPM) 은 이 논문에 없다.

형식: `- [글자] slug | 내용 (값 · 단위) | 위치 | 표지 | 한계`

## a. 순수 SE (LPSCl · 황화물) 의 압력별 기공 곡선 · 진밀도 · 질량 기준 · 누른 채 / 뺀 뒤

- [a] papakyriakou2021_mechanical_behavior_inorganic_li_solid_electrolytes_nanoindentation | **압력별 기공 곡선 없음** — 황화물 펠릿은 열간 가압 240 °C · 360 MPa · 2 h 한 조건뿐.  상대밀도 Li₆PS₅Cl 91 % (기공 9 %) · Li₁₀SnP₂S₁₂ 92 % (기공 8 %) | §3-1 L66–67 · §3-2 L79–85 · 논문 p.2–3 · Table 1 | 상대밀도 = [인쇄] · 기공 = [카드 산술] | 한 점 · 열간 (랩 기준은 냉간 순수 SE 10–13 %) · Table 1 의 "LSPCl" 은 LPSCl 의 인쇄 오기 (L82)
- [a] papakyriakou2021_mechanical_behavior_inorganic_li_solid_electrolytes_nanoindentation | **진밀도 (분모) · 밀도 측정법 · 벌크 밀도 (g/cm³) · 질량이 원문에 없다** — 원문은 "Table 1 lists the obtained ionic conductivity of each material, together with their mass density measurement results." 한 문장뿐 → 랩 표준 1.64 g/cm³ 과 견줄 수 없는 "열간 가압 · 분모 미기재" 의 문헌 값 | §3-2 L87–88 · §12 L423 · 논문 p.3 | 문장 = [인쇄] · 나머지 = [미확인] | 참고만: 91 % 가 뜻하는 벌크 밀도는 분모에 따라 1.49 (분모 1.64) – 1.70 g/cm³ (분모 1.87) [카드 산술 — 원문 값 아님]
- [a] papakyriakou2021_mechanical_behavior_inorganic_li_solid_electrolytes_nanoindentation | 상태 = 열간 가압으로 만든 원판 (⌀19 mm 다이 → 두께 0.75 mm) — 가압 중 값이 아니다.  가열 / 냉각 속도 · 하중 제거 순서 · 분말 질량 · 분말 입경 · 결정립 크기 [미확인] | §3-1 L66 · L73 · §10 L393 · §12 L422 · 논문 p.2 | [인쇄] + [미확인] | 360 MPa = 102 kN (⌀19 mm) [카드 산술 L74]
- [a] papakyriakou2021_mechanical_behavior_inorganic_li_solid_electrolytes_nanoindentation | (다른 재료 · 유일한 밀도 대조) 같은 조성 LLZTO: 열간 97 % ↔ 냉간 가압 뒤 소결 85 % — 25 °C 경도 9.18 ↔ 3.79 GPa (0.41 배) · 환산 탄성률 124.1 ↔ 94.6 GPa (0.76 배) | §3-10 L250 · Table 1 · Fig. 4b · 4c | 밀도 = [인쇄] · 경도 · 탄성률 = [판독] · 비 = [카드 산술] | LLZTO (우리 재료 아님) · 합성 경로가 함께 달라 기공만의 효과로 읽을 수 없다 [카드 해석] · 황화물에는 밀도를 바꾼 대조가 없다

## b. 압력을 뺄 때 되돌아오는 양과 잰 방법

- [b] papakyriakou2021_mechanical_behavior_inorganic_li_solid_electrolytes_nanoindentation | 분말 · 펠릿의 탈압 회복은 **재지 않았다** (열간 가압 뒤의 치수 회복 · 하중 제거 조건 [미확인]) | §0 L36 · §4-3 (4) L270 | 카드 판정 (원문에 없음) | —
- [b] papakyriakou2021_mechanical_behavior_inorganic_li_solid_electrolytes_nanoindentation | 간접: 압입 제하의 깊이 회복 (25 °C · 2000 µN 대표 곡선) — Li₆PS₅Cl 최대 깊이 198.9 nm → 잔류 127.7 nm (잔류 ÷ 최대 0.642 · 회복 35.8 %) · 제하 기울기 41.0 µN/nm · 제하 일 ÷ 부하 일 0.33.  Li₁₀SnP₂S₁₂ 0.625 (회복 37.5 %) · 산화물 셋 0.374–0.431 (회복 56.9–62.6 %) · 석영 유리 0.292 (70.8 %) | §3-6 L151–160 · Fig. 4a · 논문 p.4–5 | [판독 · 벡터 꼭짓점] · 기울기 · 일의 비 = [카드 산술] | Berkovich 한 점의 탄성 회복 — 침대 치수 회복이 아니다 · 재료당 대표 곡선 1 개 (12 점 평균 아님 L160 · L401)
- [b] papakyriakou2021_mechanical_behavior_inorganic_li_solid_electrolytes_nanoindentation | 0.25 P_max 에서 0.2 s 유지하는 동안 깊이가 여섯 재료 모두 2–3 nm 줄어든다 (LPSCl 157.6 → 155.1 nm · 석영 유리 56.1 → 53.5 nm) — 크리프하는 황화물과 석영 유리가 같은 크기라 재료의 시간 의존 회복으로 읽을 수 없다 | §3-6 L163 · Fig. 4a | [판독] + [카드 해석] | 판독 창에 앞뒤 제하 끝이 1–2 nm 섞인다

## c. 항복 · 경도 · 크리프 값과 정의 · 일축 항복 세기 환산

- [c] papakyriakou2021_mechanical_behavior_inorganic_li_solid_electrolytes_nanoindentation | 경도 H (Oliver–Pharr · 3 면 Berkovich · 2000 µN · 부하 0.5 s · 최대 하중 유지 없음 · 12 점 평균 ± 막대 반폭) Li₆PS₅Cl: 2.39 ± 0.26 (−40 °C) · 2.48 ± 0.31 (0) · **1.87 ± 0.37 (25 °C)** · 2.15 ± 0.65 (60) · 2.01 ± 0.39 (100) · 1.92 ± 0.21 (200) · 1.21 ± 0.14 GPa (300 °C) | §3-5 L133–139 · Fig. 4c · 논문 p.5 | [판독] (본문 인쇄는 −40 → 300 °C 감소율 49 % 뿐 L118) | 열간 가압 펠릿 연마면 · 깊이 ≈0.2 µm · 오차 막대의 뜻은 캡션에 없음 (표준편차로 읽음 = [카드 해석] L144) · 80 °C 위는 저자가 표면 산화를 인정한 구간 (L146 · L240) · 하중 · 깊이 · 속도 사다리 없음 (L394)
- [c] papakyriakou2021_mechanical_behavior_inorganic_li_solid_electrolytes_nanoindentation | 환산 탄성률 E_r Li₆PS₅Cl: 인쇄 42.1 GPa (−40 °C) → 29.4 GPa (300 °C) (−30.2 %).  판독 25 °C 33.8 ± 5.7 GPa (판독 −40 °C 42.4 · 300 °C 29.6 = 인쇄값과 ≤ 0.3 GPa) · H/E_r 0.055 (25 °C) | §3-5 L116 · L122–128 · L147 · 논문 p.5 · Fig. 4b | [인쇄] / [판독] / [카드 산술] | 환산 탄성률이다 — 시편 ν · 영률 환산은 원문에 없음 (L106) · 카드 산술 E ≈ 30.1–30.3 GPa (ν 0.36–0.37 가정 L148)
- [c] papakyriakou2021_mechanical_behavior_inorganic_li_solid_electrolytes_nanoindentation | 크리프의 정의: ε̇_eff = B(σ_eff/σ₀)ⁿ · σ_eff = P/A_p (투영 접촉 면적) · ε̇_eff = ḣ/h · σ₀ = 유지 시작 때의 압입 응력 (식 1–3) · n = 응력 지수 · B = 크리프 계수.  변위 이력은 210 Hz 진동의 접촉 강성에서 환산 | §3-8 L198–202 · §3-3 L103 · 논문 p.3–4 · p.6 | [인쇄] | 이 논문 자신은 일축 크리프와 대조하지 않았다 (L201) · σ₀ 값은 어디에도 인쇄돼 있지 않다 (L236)
- [c] papakyriakou2021_mechanical_behavior_inorganic_li_solid_electrolytes_nanoindentation | 크리프 값 (Li₆PS₅Cl · 25 °C · 2000 µN 유지 ≈150 s · 대표 곡선): 크리프 변위 4.8 · 8.0 · 10.5 · 12.4 · 13.9 nm @ 10 · 30 · 60 · 100 · 150 s (준정적 최대 깊이의 7.0 %) · ε̇_eff 1.29 × 10⁻³ → 1.18 × 10⁻⁴ s⁻¹ · 끝의 σ_eff/σ₀ 0.888 (접촉 응력 −11 %) | §3-8 L204–216 · Fig. 6a · 6b · 논문 p.6 | [판독] + [카드 산술] | 대표 곡선 1 개 · 150 s 에도 멈추지 않았다 (끝 30 s 기울기 ≈0.020 nm/s)
- [c] papakyriakou2021_mechanical_behavior_inorganic_li_solid_electrolytes_nanoindentation | 응력 지수 n (12 점 평균 ± 반폭) Li₆PS₅Cl: 18.1 ± 3.8 (−40 °C) · 27.0 ± 4.2 (0) · **21.3 ± 3.7 (25 °C)** · 20.4 ± 4.4 (60) · 24.9 ± 7.5 (100) · 32.6 ± 6.0 (200) · 30.6 ± 12.0 (300 °C) · 크리프 계수 B 7.2–15.7 × 10⁻⁴ s⁻¹ · 활성화 부피 V 3.6 × 10⁻²⁸ m³ (0–80 °C) → 저자 결론 = 전위 지배 (확산 크리프 n = 1–2 가 아님) | §3-8 L218–223 · L237–239 · Fig. 7 · 8b · 논문 p.6–8 | n · B = [판독] · V · 결론 = [인쇄] | B 는 자기 초기 응력으로 정규화한 값 (절대 크리프 속도 비교 아님 L236) · V 는 0 · 25 · 60 °C 세 점 맞춤 (L398) · 식 (4) + 25 °C 경도로 재계산하면 LPSCl 은 7 % 안 (L242)
- [c] papakyriakou2021_mechanical_behavior_inorganic_li_solid_electrolytes_nanoindentation | 변형률 속도 민감도 지수: 원문에 m 은 없다 (n 만 쓴다).  1/n = 0.047 (25 °C) · 0.055 (−40 °C) · 0.037 (0 °C) → 변형률 속도 10 배당 접촉 응력 10^(1/n) = 1.11 배 (25 °C) | §3-8 L241 · §0 L31 · §4-4 L277 | [카드 산술] | 잰 구간은 ε̇_eff ≈ 1.2 × 10⁻⁴–1.3 × 10⁻³ s⁻¹ 한 자릿수뿐 — 그 밖으로의 연장은 외삽
- [c] papakyriakou2021_mechanical_behavior_inorganic_li_solid_electrolytes_nanoindentation | 점탄성 손실 (NanoDMA 1–100 Hz · 평균 하중 2000 µN): Li₆PS₅Cl tan δ 0.026 → 0.007 (1 → 100 Hz · 25 °C) · 저장 탄성률 33.7 GPa (25 °C) · 0.05 를 넘는 점은 −40 °C 의 1 Hz (0.075) · 1.67 Hz (0.056) 둘뿐 | §3-7 L174 · L185 · L190–191 · Fig. 5 · 논문 p.6 | [판독] (원문 문장 "almost uniformly below 0.05 for all materials" = [인쇄]) | 원문의 "tan δ = E′/E″" 는 뒤집힌 표기 (L102) · −40 °C 에서 준정적 E_r 과 저장 탄성률의 LPSCl ↔ LSPS 대소가 반대 (L193)
- [c] papakyriakou2021_mechanical_behavior_inorganic_li_solid_electrolytes_nanoindentation | **일축 항복 세기 환산: 원문에 없다** — yield strength · σ_y · Tabor · constraint factor · H/3 0 회 ("yield" 는 "evaporated to yield a gel-like mixture" · "yielded flat areas" 두 곳뿐).  경도는 재료 순위 · 온도 의존 · 식 (4) 의 H 로만 쓰인다 → 카드도 환산하지 않았다 | §3-9 L245–246 · §0 L33 | 카드 확인 (글자 층 전문 검색) | —
- [c] papakyriakou2021_mechanical_behavior_inorganic_li_solid_electrolytes_nanoindentation | 파괴 인성: 재지 않았다 (K_IC · fracture toughness · 균열 길이 측정 0 회) | §0 L30 · §12 L431 | 카드 확인 | —
- [c] papakyriakou2021_mechanical_behavior_inorganic_li_solid_electrolytes_nanoindentation | Li₆PS₅Cl 경도가 정본 카드에 따라 0.55–1.87 GPa (3.4 배): var2026 0.545–0.665 (1 mN · 부하 0.5 s · 냉간 펠릿 꼭대기 군집) · larson2025 0.72 ± 0.16 / 0.78 ± 0.25 (최대 100 mN · 냉간 300 MPa / 150 °C 열간) · jung2026 1.34 · lee2025 1.41 ± 0.24 (8 mN · 부하 4 s + 유지 2 s · 치밀 펠릿) · 이 논문 1.87 ± 0.37 (2 mN · 부하 0.5 s · 열간 펠릿 연마면) · lee2026 은 σ_ys 92 MPa (다른 정의) | §7-2 L326–339 | [정본 카드] + [판독] | 하중 (압입 크기) · 열간 조건 · 표면 처리가 함께 달라 원인을 가를 수 없다 · 속도만으로는 설명 안 됨 (1.41 ↔ 1.87 의 1.33 배에 2.6 자릿수 필요 [카드 산술] L339) · 카드는 어느 값이 맞다고 판정하지 않았다

## d. 단단한 입자와 무른 입자를 섞어 누를 때 단단한 입자의 하중 몫 · 재밍

- [d] papakyriakou2021_mechanical_behavior_inorganic_li_solid_electrolytes_nanoindentation | 해당 없음 — 단일상 SE 펠릿만 (CAM · 복합체 없음) | §2 L52 | 카드 판정 | —

## e. 점접촉 법칙이 큰 변형에서 깨지는 범위와 대안 · 대안마다 맞춘 값 개수

- [e] papakyriakou2021_mechanical_behavior_inorganic_li_solid_electrolytes_nanoindentation | 접촉 법칙 · 대안 (multi-contact · MDR · EEPA · Thornton–Ning · Storåkers) 은 이 논문에 없다 (수치 모사 없음) | §4-1 L259 · §4-3 (1) L267 | 카드 판정 | —
- [e] papakyriakou2021_mechanical_behavior_inorganic_li_solid_electrolytes_nanoindentation | 접촉 법칙 입력에 닿는 재료 사실 둘: 황화물은 경도가 환산 탄성률의 ≈1/18 (H/E_r 0.055 · 25 °C) 인 무른 고체 · 일정 하중 150 s 에 접촉 응력이 11 % 풀린다 | §4-3 (1) L267 · §3-5 L147 · §3-8 L216 | [판독] + [카드 산술] | 열간 펠릿 · Berkovich 2 mN · 대표 곡선
- [e] papakyriakou2021_mechanical_behavior_inorganic_li_solid_electrolytes_nanoindentation | 문헌 DEM 의 EEPA 접촉 소성비 (yano2026 카드: LPSCl–LPSCl λp 0.642 · 출처 = 이 논문) 는 이 논문 Fig. 4a 대표 곡선의 잔류 깊이 ÷ 최대 깊이 = 127.7 / 198.9 = 0.642 와 같은 수 — 이 논문에 "소성비" 라는 양은 없다.  선형 이력 스프링이면 제하 일 ÷ 부하 일 = 1 − λp = 0.358 인데 곡선 적분은 0.33 | §3-6 L162 · §7-2 L348 · §7-3 L358 | [판독 + 카드 산술] · 출처 연결 = [카드 해석] | 구–구 접촉 실험이 아니라 뾰족한 압자의 압입 한 곡선 (2 mN · 25 °C) · 맞춘 값 개수 = 해당 없음

## f. MPM 의 접촉 · 다물체 · 강체 결합 방법 · 해상도 규칙 (지름당 셀 수) · 수치 오차 추정

- [f] papakyriakou2021_mechanical_behavior_inorganic_li_solid_electrolytes_nanoindentation | 해당 없음 — 측정 논문 (MPM · FEM · DEM 없음) | 머리 주석 L8 · §0 L24 | 카드 판정 | —

## g. 2D 결과를 3D 로 옮길 때의 경고 · 증거

- [g] papakyriakou2021_mechanical_behavior_inorganic_li_solid_electrolytes_nanoindentation | 말 없음 — 실험 (3D 실물 · Berkovich 압입) · 2D 계산도 2D → 3D 전이에 대한 문장도 없다 | §0 L36 · §4-3 (3) L269 | 카드 판정 (원문에 없음) | —

## h. DEM 에서 FE · MPM 으로 넘긴 선례와 넘긴 시점

- [h] papakyriakou2021_mechanical_behavior_inorganic_li_solid_electrolytes_nanoindentation | 해당 없음 — 수치 모델을 쓰지 않는다.  원문이 모델 쪽으로 든 인용은 화학-기계 모델 [12] (Bucci 외 2017 · 정본 카드 `bucci2017_chemomech_failure_assb_cycling_czm`) 과 멱법칙 크리프 고체의 압입 해석 [45] (Bower · Fleck · Needleman · Ogbonna 1993) 뿐 | §4-3 (1) L267 · §11 L408 · L418 | [인쇄] (참고문헌 목록) | —

## i. 복합 양극 (AM + SE) 의 압력별 기공

- [i] papakyriakou2021_mechanical_behavior_inorganic_li_solid_electrolytes_nanoindentation | 없음 (단일상 SE 펠릿만) | §2 L52 | 카드 판정 | —

## j. 카드가 스스로 "아직 못 한다 · 한계" 라고 적은 것 가운데 가압 · 탈압 계산과 닿는 것

- [j] papakyriakou2021_mechanical_behavior_inorganic_li_solid_electrolytes_nanoindentation | 저자: 탄성 · 소성 물성을 온도 무관으로 둘 수 없다 — "cannot be effectively designed and modeled with the assumption of temperature independent elastic and plastic properties" | §0 L35 · §4-3 (1) L267 · 논문 p.5 | [인쇄] | 구성식 · 접촉 법칙 · 수치 방법에 대한 안내는 없다 (이 한 문장뿐)
- [j] papakyriakou2021_mechanical_behavior_inorganic_li_solid_electrolytes_nanoindentation | 저자: 하중 상한 — "the peak indentation load was limited to 2000 μN to avoid capacitor shorting in argon, in contrast to the designed ~10,000 μN load capacity for indentation testing in air" → 대표 곡선의 깊이 78–253 nm | §3-3 L96 · §10 L384 · 논문 p.3 | 문장 = [인쇄] · 깊이 = [판독] | 하중 · 깊이 · 부하 속도 의존은 재지 않았다 (L394)
- [j] papakyriakou2021_mechanical_behavior_inorganic_li_solid_electrolytes_nanoindentation | 저자: 80 °C 위 황화물은 < 0.1 ppm 에서도 표면이 산화한다 — "excessive side reactions did occur in the sulfide SEs at the temperatures of >80 °C, as evidenced by a change in their surface appearance from glossy grey to dull light yellow during prolonged creep testing." · "High-temperature mechanical testing of such air sensitive battery materials indeed poses a great challenge and requires more stringent environmental control than is currently available." · −40 °C 의 상 변화는 가설 ("Further work such as variable-temperature XRD analysis is needed to fully validate this hypothesis.") | §3-8 L240 · §10 L386–387 · 논문 p.8 | [인쇄] | 준정적 값 (경도 · 탄성률) 에 산화가 얼마나 섞였는지는 원문이 다루지 않는다 (L146) → 황화물 값은 0–80 °C 만 "intrinsic"
- [j] papakyriakou2021_mechanical_behavior_inorganic_li_solid_electrolytes_nanoindentation | 저자: 압입 크리프의 유효 응력 · 유효 변형률 속도는 대리 척도 — "the material under the indenter tip experiences a highly inhomogeneous stress state and the above effective stress and strain terms are chosen as a metric of measurement to construct the constitutive relationship" | §3-8 L201 · §10 L389 · 논문 p.4 | [인쇄] | —
- [j] papakyriakou2021_mechanical_behavior_inorganic_li_solid_electrolytes_nanoindentation | 카드: 영률 환산 (ν) · 경도의 항복 환산 · 파괴 인성 · 하중 / 깊이 사다리 · 부하 속도 사다리 · 기공 보정 · 밀도를 바꾼 황화물 시편 · 냉간 가압 황화물 · 분말 / 입자 압입 · 펠릿 압밀 곡선 · 탈압 · 모든 수치 모사 = 하지 않음 | §4-1 L259 · §12 L422–433 | 카드 판정 | —
- [j] papakyriakou2021_mechanical_behavior_inorganic_li_solid_electrolytes_nanoindentation | 카드: 보고값은 보정된 면적 함수에 기대는데 보정 절차가 적혀 있지 않다 — 석영 유리 대표 곡선을 이상 Berkovich (A = 24.5 h_c²) 로 풀면 E_r 108 · H 22.7 GPa (그림 값 70.4 · 9.37) → 접촉 면적이 이상 삼각뿔의 2.4 배여야 한다 · "tip radius of 50 nm" 는 공칭값으로 읽힌다 | §3-6 L165 · §10 L395 | [카드 산술 · 지적] | 대표 곡선 1 개 기준 (흩어짐이 큰 황화물 · CPSS-LLZTO 는 평균과 다른 몫이 섞임 · 석영 유리가 가장 깨끗한 검산)

## k. DEM 의 한계

- [k] papakyriakou2021_mechanical_behavior_inorganic_li_solid_electrolytes_nanoindentation (Papakyriakou, Lu, Liu, Liu, Chen, McDowell & Xia, J. Power Sources 516, 230672, 2021) | **말 없음** — 본문 10 쪽 (참고문헌 포함) 에 'DEM' · 'discrete element' · 'particle' · 'sphere' · 'simulation' 0 회.  DEM 을 쓰지도 말하지도 않는 측정 논문 ("model" 은 일곱 곳 — 화학-기계 모델 [12] · "modeling and designing solid-state batteries" · "validated by computational modeling [45]" · "designed and modeled" · "the power-law creep model" · 장치 이름 · 참고문헌 제목) | §0 L36 · §4-3 (1) L267 | 카드 확인 (글자 층 전문 검색) | —
- [k] papakyriakou2021_mechanical_behavior_inorganic_li_solid_electrolytes_nanoindentation (같은 서지 · DEM 이 아니라 **속도 · 온도 무관으로 둔 접촉 / 구성 가정** 에 닿는 인용처 — 우리 hooke/hysteresis 접촉 (후보 D0) · J2 연속체 둘 다 속도 무관) | "cannot be effectively designed and modeled with the assumption of temperature independent elastic and plastic properties" (p.5) · "creep deformation occurs over time in all tests" (p.6) · Highlights "Solid electrolytes exhibited minimal viscoelastic damping." (p.1) | §4-3 (1) L267 · §3-8 L215 · §2 L56 | [인쇄] | DEM 에 대한 문장이 아니다 — 재료가 시간 · 온도 의존이라는 측정 사실 (열간 펠릿 · 압입)
- [k] papakyriakou2021_mechanical_behavior_inorganic_li_solid_electrolytes_nanoindentation (같은 서지 · 숫자) | 속도 무관 가정이 놓치는 크기: Li₆PS₅Cl 응력 지수 n 21.3 ± 3.7 (25 °C · 12 점) → 변형률 속도 10 배당 접촉 응력 ≈11 % · 2000 µN 을 150 s 유지하면 접촉 응력 −11 % · 깊이 +7 % | §3-8 L216 · L223 · L241 · §7-3 L353–354 | [판독] + [카드 산술] | 열간 치밀 펠릿 · 2 mN 압입 · 변형률 속도 한 자릿수 구간 (≈10⁻⁴–10⁻³ s⁻¹) 의 값 — 냉간 펠릿 꼭대기 (var2026: 2 mN · 120 s 에 +38 %) 와는 ≈5 배 차 (L354)

## l. 소성변형이 왜 어려운가

- [l] papakyriakou2021_mechanical_behavior_inorganic_li_solid_electrolytes_nanoindentation (Papakyriakou, Lu, Liu, Liu, Chen, McDowell & Xia, J. Power Sources 516, 230672, 2021) | 계산이 없어 "입자 계산에 소성을 넣기 어려운 이유" 를 말한 문장은 **없다** (말 없음).  우회 · 맞춘 값 · 계산 비용 (입자 수 · 시간) = 해당 없음 | §4-3 (2) L268 | 카드 판정 | —
- [l] papakyriakou2021_mechanical_behavior_inorganic_li_solid_electrolytes_nanoindentation (같은 서지 · 구성식 쪽에 주는 사실 ①) | 압입 밑의 응력 상태가 불균일해 유효 응력 · 유효 변형률 속도라는 대리 척도로 구성 관계를 세운다: "During nanoindentation, the material under the indenter tip experiences a highly inhomogeneous stress state and the above effective stress and strain terms are chosen as a metric of measurement to construct the constitutive relationship. This creep analysis method has been validated by computational modeling [45] and indentation experiments [46–49], and it has been proven to produce results consistent with those from conventional uniaxial creep testing." | §3-8 L201 · 논문 p.4 | [인쇄] | 이 논문 자신은 일축 시험 · 다른 하중 · 다른 압자와 교차 확인하지 않았다 (L258)
- [l] papakyriakou2021_mechanical_behavior_inorganic_li_solid_electrolytes_nanoindentation (같은 서지 · 사실 ②) | 소성이 시간 의존이다 — 여섯 재료 모두 일정 하중에서 크리프: "The ε̇_eff − σ_eff relationship is found to be fairly linear on the log-log scale, thus validating the power-law creep model given by Eq. (1)." · 응력 지수가 확산 크리프 값 (n = 1 · 입계 미끄럼 ≈2) 보다 훨씬 커서 "diffusion-controlled creep is inactive despite the high Li diffusivity (D = 10⁻¹⁰ to 10⁻¹³ m² s⁻¹) of the SEs studied" → 전위 지배 (Li₆PS₅Cl 활성화 부피 3.6 × 10⁻²⁸ m³) | §3-8 L215 · L237–239 · 논문 p.6–8 | [인쇄] | 2000 µN 유지 한 조건 · 황화물은 0–80 °C 구간만
- [l] papakyriakou2021_mechanical_behavior_inorganic_li_solid_electrolytes_nanoindentation (같은 서지 · 사실 ③) | 재료 값 자체가 온도 · 표면 상태에 따라 흔들린다: 탄성 · 소성 물성을 온도 무관으로 두면 안 된다 (p.5) · 80 °C 위에서는 황화물 표면이 산화해 값이 변한다 (p.8) | §4-3 (2) L268 · §3-8 L240 | [인쇄] | —
- [l] papakyriakou2021_mechanical_behavior_inorganic_li_solid_electrolytes_nanoindentation (같은 서지 · 숫자 — 원문의 말이 아니라 카드 대조) | 같은 Li₆PS₅Cl 의 경도 (= 항복의 대리) 가 정본 카드에 따라 0.55–1.87 GPa (3.4 배) → 항복 캡 · Tabor 면적 (A = F/H) 을 문헌 한 값으로 못 박으면 면적이 3.4 배까지 달라질 수 있다 | §7-2 L338 · §7-3 L355–356 | [정본 카드] + [카드 산술] | 우리 덱이 쓰는 H 값은 그 카드에서 확인하지 않았다 (L355)

## m. 받아들일 통찰

- [m] papakyriakou2021_mechanical_behavior_inorganic_li_solid_electrolytes_nanoindentation | **속도 무관 모델의 한정어에 크기를 붙인다** — "점소성 미포함: 문헌 응력 지수 n ≈ 21 (25 °C) 이면 변형률 속도 10 배당 접촉 응력 ≈11 % · 2000 µN 유지 150 s 에 접촉 응력 −11 % · 깊이 +7 %".  실험 밀도 · 접촉 면적은 유지 시간과 함께 적는다 | 후보 D0 · 후보 C′ · 단계 4 · 단계 5 (결과 보고의 한정어) · 결과 전 대조 항목 | §7-3 L353–354 · §8 L369 · §3-8 L241 | [판독] + [카드 산술] | 한 자릿수 구간 (≈10⁻⁴–10⁻³ s⁻¹) · 열간 치밀 펠릿 · 2 mN 압입이라는 꼬리표와 함께
- [m] papakyriakou2021_mechanical_behavior_inorganic_li_solid_electrolytes_nanoindentation | **경도 ↔ 항복 세기 환산 규칙을 등록할 때 경도 값마다 하중 · 깊이 · 부하 / 유지 시간 · 시편 상태 (열간 / 냉간 · 밀도와 그 분모 · 연마) · 면적 함수 보정 여부를 같이 적는다** — 같은 Li₆PS₅Cl 이 0.55–1.87 GPa 이고, 이 논문은 분모와 면적 함수 보정을 적지 않아 다른 자료와 곧바로 겹치지 못한다 (석영 유리 검산에서 접촉 면적이 이상 Berkovich 의 2.4 배).  같은 시료 원측정을 요청할 때의 틀 = 글러브박스 안 압입 · 조건당 12 점 · 간격 ≥ 압흔의 10 배 · 일정 하중 유지 크리프 (변위는 접촉 강성에서 환산) | 단계 0 · 단계 4 · 조건 R5 · 결과 전 대조 항목 · 흐름 밖: 우리 시료 원측정 요청 | §8 L367–368 · L370 · L374 · §7-2 L338 · §3-6 L165 | [정본 카드] + [카드 산술] | 이 논문은 환산식을 주지 않는다 · 캡을 문헌 경도 한 값으로 못 박을 수 없다는 쪽의 실험 근거 (L356)
- [m] papakyriakou2021_mechanical_behavior_inorganic_li_solid_electrolytes_nanoindentation | **문헌 DEM 의 접촉 소성 입력은 출처 그림까지 내려가 본다** — yano2026 의 EEPA λp 0.642 (LPSCl) 는 구–구 접촉 실험값이 아니라 이 논문 Fig. 4a 의 Berkovich 2 mN 대표 곡선 한 개의 잔류 깊이비다.  같은 곡선의 깊이 회복 36 % · 일의 비 0.33 은 "눌렀다 떼기" 의 실험 쪽 모양 | 후보 C′ · 후보 D0 · U3 | §3-6 L162 · §7-3 L357–358 · §8 L372 | [판독 + 카드 산술] · [카드 해석] | U3 의 수치 표적으로는 쓰지 않는다 (무딘 팁 · 대표 곡선 한 개 · Berkovich)
- [m] papakyriakou2021_mechanical_behavior_inorganic_li_solid_electrolytes_nanoindentation | **온간 가압 (60–100 °C) 의 이득을 "경도 저하" 로 설명하지 않는다 · 하중–제하 이력을 재료 감쇠로 설명하지 않는다** — Li₆PS₅Cl 경도는 25 · 60 · 100 °C 에서 1.87 · 2.15 · 2.01 GPa 로 오차 안에서 같고 (환산 탄성률만 60 → 100 °C 에 36.0 → 29.1 GPa), tan δ 는 25 °C 에서 0.03 아래라 이력은 탄성 손실이 아니라 소성 · 크리프의 몫이다 | 흐름 밖: 온간 가압 해석 · 접촉 감쇠 설정의 근거 · 다른 정본 카드가 이 논문 값으로 옮긴 숫자 (var2026 의 28.5 ± 3.5 GPa · larson2025 의 30 GPa) 를 인용할 때 온도와 "환산 탄성률" 임을 같이 적기 | §8 L371 · L373 · §3-5 L146 · §3-7 L191 · §7-2 L345–346 | [판독] | 80 °C 위는 표면 산화가 섞인 구간 (저자 진술)

## 카드 문제

없음 (카드 안 값끼리의 모순은 못 찾음).  원문 안의 어긋남은 카드 §10 L392–402 에 모아 둠: Li₆PS₅Cl 상온 값이 본문에 숫자로 없음 · 손실 계수 표기 "tan δ = E′/E″" (뒤집힘) · "LSPCl" 오기 (Fig. 1 · 4 · 6b · Table 1) · Li₁₀SnP₂S₁₂ 경도 감소율 39.1 % 의 기준이 −40 °C 가 아니라 0 °C 최대값 · −40 °C 에서 준정적 E_r ↔ 저장 탄성률의 두 황화물 대소 반대 · 활성화 부피 인쇄값 여섯 중 식 (4) + 25 °C 경도로 재현되는 것은 둘 (나머지 17–40 % 차) · 식 (4) 는 절편 0 인데 맞춤 직선은 그렇지 않음 · "No significant frequency dependence" ↔ HP-LLZTO 25 °C 126 → 142 GPa · 참고문헌 [23] 의 자리 · [43] 서지 깨짐 · 이상 Berkovich ↔ 보고값 (접촉 면적 2.4 배).
다른 정본 카드가 이 논문 값으로 옮긴 숫자 가운데 원문에 그 숫자로 인쇄돼 있지 않은 것 = var2026 의 "28.5 ± 3.5 GPa" · larson2025 의 "30 GPa" (카드 §7-2 L345–346 — 기존 카드는 고치지 않았다).
인덱스: SE 축 `INDEX.md` 의 "Digest 완료" 표는 중간의 빈 줄 뒤로 표 머리와 끊겨 있어 (기존 상태) 이 카드 줄도 var2026 · lee2025 줄과 같이 "떠 있는 행" 으로 세어진다 (build_index.py --check 110 → 111 건 · 어느 머리에 붙일지는 사람이 정하는 자리라 손대지 않았다).

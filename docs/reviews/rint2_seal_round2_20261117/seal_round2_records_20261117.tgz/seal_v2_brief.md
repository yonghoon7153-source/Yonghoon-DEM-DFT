너는 Rint ② "봉인 후보 v2" 를 만드는 조수다 (문서 · scratch 만 · 결과 0 건 · 실행 0 · σ 열람 0).  답은 한국어.  1저자 결정은 아래에 다 있다 — 새 숫자 · 새 기준을 만들지 않는다.

## 배경 (먼저 읽을 것)
- v1 (앞 조수 · 다 됨): /tmp/claude-0/-home-user-Yonghoon-DEM-DFT/81c0ad95-542f-503b-9cf7-2f6a678a4b5b/scratchpad/rint/seal_candidate/ — README.md (194 줄 · (가)–(바)) · registration_R_insert.md (R-01–R-15) · commands_doc_insert.md (K-01–K-04) · plan_candidate.json · plan_doc_block.txt · plan_make_commands.txt · evidence/ (도구 넷 포함).  작업 사본 = 같은 scratch 의 rint/seal_work/ (pin_tree = `git archive 64e4d213e` 사본 · apply_tree_2 = 붙일 글을 넣은 사본 · s0_1116 · 고정물 계획 plan_fixture_values_SCRATCH_ONLY.json).
- 넷째 길 확인 (메인 · scratch): rint/seal_opt4/opt4_check.py · 그 출력 = rint/seal_opt4/run1/ (tree · repo).  결과: 원본 등록 R (핀 판 + 머리 표지 한 줄) 을 그대로 두고 붙인 판을 새 파일 `docs/reviews/rint2_seal_20261120/registration_R_sealed.md` 로 두면 → 시험 K01 · PC18 · PC20 · EP06 4/4 · E17 1/1 · `--stage plan-doc --check-doc --registration <봉인본>` rc 0 PLAN_DOC_SAME · 기본 (원본) rc 3 · 원본의 `registration_plan_hash` = 멈춤 PLAN_HASH_UNREGISTERED · S0 단계 2 관문 (`ca_s0_census.verify_plan_commit(..., r_doc=봉인본)`) = 넷 null 때문에만 거부 · 고정물 값 PASS · 시험 `scripts/test_rint_r_chain_e2e12.py` (64e4d213e) 는 사다리 · 예측 · 판정에 `--registration` 을 CLI 로 넘긴다.
- 리포 /home/user/Yonghoon-DEM-DFT (읽기만 · git show · diff · grep · log · ls-tree · archive 만 · 출력은 scratch 로) · 코드 핀 = 64e4d213e (원격 codex/rint-rtr01-receipt-1113 끝 · stoic 조상 아님).  stoic 쪽 새 기록은 /home/user/stoic-next (가지 tmp-stoic-next · 읽기만): 3 판 `docs/reviews/rint2_time_reestimate_20261111/README.md` 끝 절 + `v3/` · 원장 `docs/reviews/rint2_dev_probe_ledger_20261026.md` (§2 · §3 시도 3 · 4) · `docs/data/rint2_q11_gpu_check_kgy_20261116/` · `docs/data/rint2_s0_sbe_20261116/` (ADOPTION_CHECK.md 새로 있음) · `docs/data/rint2_probe6_a3_20261116/` · `…a4…` · `docs/data/rint2_s0_sbe_20261113/`.

## 1저자 결정 (11-17 · *"권고대로해 · 이런걸로 병목 만들지마"*) — 그대로 쓴다
- Q1 봉인 꼴 = **봉인본 새 파일** `docs/reviews/rint2_seal_<봉인 날짜>/registration_R_sealed.md` (원본 등록 R = 핀 판 그대로 + 머리 표지 한 줄 · `scripts/` 무변경 · ⑥ 다시 없음) · 모든 사슬 단계 명령에 `--registration <봉인본>` · S0 단계 2 명령에 `--r-doc <봉인본>`.
- Q2 12 단위 · 저장본 실행 줄 = `sh` 블록 (K01 은 `bash` 만 읽는다) + 사슬 argparse 대조 기록을 봉인 기록에.
- Q3 계획 자리 = `docs/data/rint2_r_plan_<봉인 날짜>/ca1_plan.json` · 꼴 = indent 1 · sort_keys · 끝 줄바꿈 없음 · schema `rint-r-plan-v3` (문서의 "v2 · 칸 11" = 낡은 글 → 표지).
- Q4 R 저장본 = 기계마다 새 빈 폴더 `~/ca1_cjstore` (⑥ · S0 시험 저장본 안 씀).
- Q5 원장 넘김 = 사슬과 같은 잠금 파일에 `flock` (gabia 에 없으면 "그 기계 사슬이 시작 확인 뒤 도는 중일 때만 넘긴다").
- Q6 사다리 P0 = kgy · P1 = gabia · 12 단위 첫 배정 kgy 7 · gabia 5 · 합치는 기계 = kgy · 합친 폴더 `ca1_predict` · `ca1_predict_x` (봉인 밖).
- Q7 넘침 점 안전 규칙 어림 = 3 판 §3-3 (4) "팔 전체" 꼴.
- Q8 감도 (FIBRE · UNREG · GRID · SVORDER) 경로 = R 시작 전 따로 (이 후보 밖 · 그대로 ⬜ 로 적음).
- 그대로 ⬜: 결과 전 등록 넷 (Codex 2/2 회신 뒤 · S0 단계 2 전 1저자 · `sv_cf_scope` = 10-23 결정 all3 기록) · 봉인 날짜 · 가지 이름 · 현장 확인 · 두 기계 조립 같음.
- 앞의 결정 (v1 지시서와 같음): maxiter 5,000,000 (`p2_extra` = `--step3-maxiter 5000000`) · `max_hours` 168 · `max_attempts` 8 · 허용 기계 kgy · gabia · v100 · env_unit (3.8 · 1.24.4 · 1.10.1) · 원장 공유 (가-2) · 넘침 점 112 h 규칙 · 마감 12-05 24:00 KST.

## 낼 것 (새 폴더 = /tmp/claude-0/-home-user-Yonghoon-DEM-DFT/81c0ad95-542f-503b-9cf7-2f6a678a4b5b/scratchpad/rint/seal_candidate_v2/ · v1 은 고치지 않는다)
1. `make_sealed_copy.py` — 핀 판 원본 등록 R (git show 64e4d213e:…) + 붙일 글 (R 조각) + 계획 파일 → 봉인본 바이트를 기계로 만드는 도구 (같은 입력 = 같은 바이트 · python3 -I · scratch 만).  원본 등록 R 머리 표지 한 줄 (정확한 글 · `| 계획 해시 |` · `| S0 계획 해시 |` 로 시작하지 않고 계획 블록 표지 글자를 담지 않음 · 봉인본 자리 · 봉인 커밋을 가리킴) 도 이 도구가 넣는다.
2. `registration_R_insert.md` v2 — R 조각들을 "봉인본에 넣는 글" 로 고쳐 쓴다 (자리 = 핀 판 원본 줄 기준 그대로 · 봉인본 머리에 "이 문서 = 등록 R 봉인본 · 원본 = … @64e4d213e · 바뀐 곳 = 이 조각들뿐" 절 하나) · R-10 (§10-1b) 의 사슬 명령 전부 `--registration <봉인본>` · S0 단계 2 줄 `--r-doc <봉인본>` · 원장 공유 · 저장본 (§10-6 · §10-7 · §10-8) 은 결정 Q4 · Q5 · Q6 · Q7 반영.
3. `commands_doc_insert.md` v2 — K-03 (§3-1b) 명령 전부 `--registration` / `--r-doc` · 결정 반영 · K-01 · K-02 주석에 "실제 실행 = 봉인본 · `--registration`" 한 줄.
4. `README.md` v2 — 맨 위 "이번에 닫는 것 / 닫지 않는 것" · (가) 값 표 (v1 그대로 + 봉인본 자리) · (나) (다) 요지 · (라) 계획 (v1 그대로 · 넷 null 후보 · 봉인 때 다시) · (마) 봉인 커밋 구성 = 봉인본 새 파일 · 원본 등록 R 표지 한 줄 · 명령 문서 · 원장 · 계획 · 자료 폴더 + 각 파일이 풀이 코드 목록 다섯 경로 · CODE_FILES 20 · S0 일곱 · 규율 검사 입력 밖인지 · (마-3) 은 넷째 길로 닫힘 (증거) · (바) [미확인] 만 (1저자 질문 없음 — 작은 것은 권고로 정하고 적는다).
5. 봉인 가지 문서 참조 — scratch 에 `git clone --shared --no-checkout` 사본 (본 리포에서 · `git -C <사본>` 만) 을 만들고 원격 추적 ref 를 본 리포의 refs/remotes/origin/* 와 같게 (fetch refspec) 한 뒤, 64e4d213e 위에 봉인 꼴 커밋 (위 (마) 파일 · 봉인본 · 계획 = 후보 · 자료 폴더는 stoic-next 의 바이트 그대로) 을 scratch 가지로 만들고 그 커밋의 `scripts/check_doc_refs.py` 를 사본에서 돌린다 → 깨진 참조가 있으면 (예: 3 판 README 가 stoic 에만 있는 `docs/handoff_return_to_stoic_knuth_20261117.md` 를 가리킴) 처분을 정한다: 봉인 가지에 꼭 필요한 파일만 넣고, 나머지는 봉인 기록에서 `<stoic 커밋 sha>:<경로>` 꼴로 가리키거나 사본 문서의 줄을 고친다 (어느 쪽인지 · 까닭 적기) · 최종 rc 0 를 증거로.
6. 다시 잰 증거 (`evidence/`): 봉인 꼴 사본 (위 5 의 트리) 에서 ① `scripts/test_rint_r_chain.py` 전체 (기대 = 503/506 · 실패 = git 신원 탓 Y13 · RR4A · RR4B 뿐 — git 저장소 사본이면 그것도 통과할 수 있다 · 실제 결과 그대로) ② `scripts/test_rint_r_chain_e2e.py --only E17` ③ 두 문서 `sh` 블록 사슬 명령 전부 argparse 대조 (v1 `evidence/tools/apply_and_check.py` 방법 · `--registration` 붙은 판) ④ `--stage plan-doc --check-doc --registration <봉인본>` rc 0 · 기본 = 멈춤 ⑤ S0 단계 2 관문 (r_doc = 봉인본 · 후보 = 넷 때문에만 거부 · 고정물 = PASS) ⑥ 철회값 등록부 (`claims.json` `quotation_ban` @64e4d213e) = 새 글 0 건 ⑦ 봉인 커밋 꼴에서 `scripts/check_method_discipline.py` (핀 판) rc 0.

## 규칙 (반드시)
- 리포 · 다른 작업 트리 (/home/user/stoic-next · /home/user/litdb-canon-a · /home/user/litdb-canon-b · /home/user/litdb-curation) 는 읽기만 — git 은 show · diff · grep · log · ls-tree · archive · `clone --shared` (scratch 로) 만.  본 리포 · 그 작업 트리에서 commit · checkout · reset · stash · worktree · push · fetch 금지 (scratch 사본 안의 git 은 됨).  GIT_DIR · GIT_WORK_TREE · GIT_INDEX_FILE 을 export 하거나 명령 앞에 붙이지 않는다.  본 리포에서는 게이트가 돈다 — 그 트리에서 아무것도 실행하지 않는다.
- 코드는 scratch 사본에서 `python3 -I` 로.  신호 · kill 실험 금지 · 시스템 패키지 설치 금지 · 바깥 호스트 접속 금지.  σ 값은 열지도 쓰지도 않는다.  디스크 여유 약 3.7 GB — scratch 사본은 끝나면 큰 것부터 지운다 (증거 파일은 남김).
- 숫자 · 줄 번호 · 명령은 파일에서 직접 확인한 것만 (기억 금지) · 확인 못 한 것 = [미확인].  전칭 (전부 · 같다 · 0) 은 범위 · 근거와 같이.

## 마지막 답 (30 줄 안)
만든 파일 · 봉인 꼴 사본에서 시험 · 관문 · check_doc_refs · 규율 검사 결과 (수 그대로) · 봉인 가지에 넣을 파일 목록 (최종) · 처분한 깨진 참조 · 남은 [미확인].

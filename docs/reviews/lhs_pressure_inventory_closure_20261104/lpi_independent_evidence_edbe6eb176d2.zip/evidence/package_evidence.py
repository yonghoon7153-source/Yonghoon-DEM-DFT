import pathlib,hashlib,json,zipfile,shutil
B=pathlib.Path(__file__).resolve().parent.parent;E=B/'evidence';S=B/'source';A=pathlib.Path('/workspace/artifacts/lpi-independent-20261104');A.mkdir(exist_ok=False)
sha=lambda b:hashlib.sha256(b).hexdigest()
scope=json.loads((E/'scope_verified.json').read_text());suites=json.loads((E/'suites.json').read_text())
summary={'pin':'edbe6eb176d22db574953d3e47d11969b353421b','priorPin':'c8a55c8ae1021ec80634ee8c6533deeebc67ce61','commandSHA256':'2305bd2194b29ac5439008906a17b1c673968a59fd52dcdde35b03ff4da20634','suites':suites,'independent':[{'version':v,'checks':18,'passed':18,'failed':0,'rc':0,'timing_observations':1,'timing_timeout_seconds':5,'timing_target_rc':None} for v in ['3.11.17','3.8.20']],'independentProbeList':[x['name'] for x in json.loads((E/'independent_311.json').read_text())['checks']],'mutations':scope['mutations'],'mutationRunnerRC':0,'newFinding':{'id':'OBS-AUDIT-01','priority':'P3 follow-up','mechanism':'synthetic sibling create/remove between ancestor stat and open yields CHANGED/rc2','historicalCauseProven':False,'newLPIRegression':False},'LPIclosurelimits':{'LPI-01':'output and CLI failure handling only; eligible for closure','LPI-02':'documentation and counterexample preservation only; timing risk unresolved'},'initialAuditFailure':'preserved 19 pass/1 fail rc1; historical cause unresolved','wholeGateHOLD':True,'actualExecutionDeploymentApproved':False,'sourceFilesUnchanged':68,'originalRepositoryUnchanged':True,'windowsAttachmentDirectlyInspected':False,'historical7179Rerun':False}
(E/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n')
files={}
for p in sorted(E.rglob('*')):
 if p.is_file():files['evidence/'+str(p.relative_to(E))]=p.read_bytes()
for p in json.loads((E/'source_before.json').read_text()):files['source/'+p]=(S/p).read_bytes()
files['source/AGENTS.md']=(S/'AGENTS.md').read_bytes()
for p in sorted((B/'mutations').rglob('*')):
 if p.is_file():files['mutations/'+str(p.relative_to(B/'mutations'))]=p.read_bytes()
files['PIN.txt']=(summary['pin']+'\n').encode();files['PRIOR_REVIEW_PIN.txt']=(summary['priorPin']+'\n').encode()
manifest=''.join(sha(data)+'  '+name+'\n' for name,data in sorted(files.items()));files['SHA256SUMS']=manifest.encode()
zp=A/'lpi_independent_evidence_edbe6eb176d2.zip'
with zipfile.ZipFile(zp,'w',zipfile.ZIP_DEFLATED) as z:
 for name,data in sorted(files.items()):z.writestr(name,data)
with zipfile.ZipFile(zp) as z:
 assert z.testzip() is None
 for name,data in files.items():assert z.read(name)==data
 assert len(z.namelist())==len(set(z.namelist()))
report=A/'판정문.md';shutil.copyfile(E/'판정문.md',report)
artifacts={'zip':{'path':str(zp),'bytes':zp.stat().st_size,'sha256':sha(zp.read_bytes()),'files':len(files),'manifestEntries':len(files)-1},'verdict':{'path':str(report),'sha256':sha(report.read_bytes())}}
summary['artifacts']=artifacts
(A/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n');(A/'SHA256SUMS').write_text(''.join(sha(p.read_bytes())+'  '+p.name+'\n' for p in [zp,report,A/'summary.json']))
print(json.dumps(artifacts,ensure_ascii=False,indent=2))

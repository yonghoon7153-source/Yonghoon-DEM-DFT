#!/bin/bash
#SBATCH --job-name=ps_7_3_r45
#SBATCH --output=logs/output_ps_7_3_r45_%j.out
#SBATCH --qos=cpu-60
#SBATCH --partition=cpu
#SBATCH -n 10
#SBATCH --time=5-00:00:00

source ~/.bashrc
conda activate myenv
cd ~/dem_test/ps45/ps_7_3_r45
mpirun --oversubscribe -np 10 lmp_mpi -in input_ps_7_3_r45.liggghts

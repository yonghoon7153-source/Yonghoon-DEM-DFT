| case | expected | old observer (df22dcf0…) | new observer |
|---|---|---|---|
| (normal) planned PRECAL_E0 actual-form log | MATCH | TECH error/resume log is not fresh completion evidence | MATCH |
| test_true_error_lines_stay_tech[error_in_table] | TECH: error/resume log is not fresh completion evidence | TECH error/resume log is not fresh completion evidence | TECH error/resume log is not fresh completion evidence |
| test_true_error_lines_stay_tech[error_on_proc] | TECH: error/resume log is not fresh completion evidence | TECH error/resume log is not fresh completion evidence | TECH error/resume log is not fresh completion evidence |
| test_true_error_lines_stay_tech[error_at_end] | TECH: error/resume log is not fresh completion evidence | TECH error/resume log is not fresh completion evidence | TECH error/resume log is not fresh completion evidence |
| test_true_error_lines_stay_tech[word_mid_line] | TECH: error/resume log is not fresh completion evidence | TECH error/resume log is not fresh completion evidence | TECH error/resume log is not fresh completion evidence |
| test_true_error_lines_stay_tech[line_start_prefix] | TECH: error/resume log is not fresh completion evidence | TECH error/resume log is not fresh completion evidence | TECH error/resume log is not fresh completion evidence |
| test_true_error_lines_stay_tech[altered_comment] | TECH: error/resume log is not fresh completion evidence | TECH error/resume log is not fresh completion evidence | TECH error/resume log is not fresh completion evidence |
| test_true_error_lines_stay_tech[comment_echoed_twice] | TECH: error/resume log is not fresh completion evidence | TECH error/resume log is not fresh completion evidence | TECH error/resume log is not fresh completion evidence |
| test_true_error_lines_stay_tech[comment_reindented] | TECH: error/resume log is not fresh completion evidence | TECH error/resume log is not fresh completion evidence | TECH error/resume log is not fresh completion evidence |
| test_true_error_lines_stay_tech[no_deck_facts] | TECH: error/resume log is not fresh completion evidence | TECH error/resume log is not fresh completion evidence | TECH error/resume log is not fresh completion evidence |
| test_truncated_logs_stay_tech[inside_run2] | TECH: log fresh four-run completion mismatch | TECH error/resume log is not fresh completion evidence | TECH log fresh four-run completion mismatch |
| test_truncated_logs_stay_tech[before_run0] | TECH: log fresh four-run completion mismatch | TECH error/resume log is not fresh completion evidence | TECH log fresh four-run completion mismatch |
| test_truncated_logs_stay_tech[loop_stamp_cut] | TECH: malformed Loop line | TECH error/resume log is not fresh completion evidence | TECH malformed Loop line |
| test_truncated_logs_stay_tech[loop_mid_stamp] | TECH: malformed Loop line | TECH error/resume log is not fresh completion evidence | TECH malformed Loop line |
| test_truncated_logs_stay_tech[row_cut] | TECH: invalid five-column thermo row | TECH error/resume log is not fresh completion evidence | TECH invalid five-column thermo row |
| test_truncated_logs_stay_tech[empty] | TECH: log fresh four-run completion mismatch | TECH log fresh four-run completion mismatch | TECH log fresh four-run completion mismatch |
| test_corrupted_rows_stay_tech[nan] | TECH: nonfinite thermo row | TECH error/resume log is not fresh completion evidence | TECH nonfinite thermo row |
| test_corrupted_rows_stay_tech[-nan] | TECH: nonfinite thermo row | TECH error/resume log is not fresh completion evidence | TECH nonfinite thermo row |
| test_corrupted_rows_stay_tech[inf] | TECH: nonfinite thermo row | TECH error/resume log is not fresh completion evidence | TECH nonfinite thermo row |
| test_corrupted_rows_stay_tech[overflow] | TECH: nonfinite thermo row | TECH error/resume log is not fresh completion evidence | TECH nonfinite thermo row |
| test_corrupted_rows_stay_tech[unicode_digit] | TECH: non-ASCII line inside thermo table | TECH error/resume log is not fresh completion evidence | TECH non-ASCII line inside thermo table |
| test_corrupted_rows_stay_tech[nbsp] | TECH: non-ASCII line inside thermo table | TECH error/resume log is not fresh completion evidence | TECH non-ASCII line inside thermo table |
| test_corrupted_rows_stay_tech[unicode_blank_line] | TECH: non-ASCII line inside thermo table | TECH error/resume log is not fresh completion evidence | TECH non-ASCII line inside thermo table |
| test_corrupted_rows_stay_tech[unit_separator] | TECH: invalid five-column thermo row | TECH error/resume log is not fresh completion evidence | TECH invalid five-column thermo row |
| test_corrupted_rows_stay_tech[four_columns] | TECH: invalid five-column thermo row | TECH error/resume log is not fresh completion evidence | TECH invalid five-column thermo row |
| test_corrupted_rows_stay_tech[six_columns] | TECH: invalid five-column thermo row | TECH error/resume log is not fresh completion evidence | TECH invalid five-column thermo row |
| test_corrupted_rows_stay_tech[float_step] | TECH: invalid five-column thermo row | TECH error/resume log is not fresh completion evidence | TECH invalid five-column thermo row |
| test_corrupted_rows_stay_tech[negative_atoms] | TECH: invalid five-column thermo row | TECH error/resume log is not fresh completion evidence | TECH invalid five-column thermo row |
| test_corrupted_rows_stay_tech[text_value] | TECH: invalid five-column thermo row | TECH error/resume log is not fresh completion evidence | TECH invalid five-column thermo row |
| test_corrupted_rows_stay_tech[underscore_value] | TECH: invalid five-column thermo row | TECH error/resume log is not fresh completion evidence | TECH invalid five-column thermo row |
| test_corrupted_rows_stay_tech[unknown_warning] | TECH: invalid five-column thermo row | TECH error/resume log is not fresh completion evidence | TECH invalid five-column thermo row |
| test_lost_particles_stay_tech[run2_row] | TECH: thermo atom count decreased | TECH error/resume log is not fresh completion evidence | TECH thermo atom count decreased (lost particles) |
| test_lost_particles_stay_tech[run3_setup_row] | TECH: thermo atom count decreased | TECH error/resume log is not fresh completion evidence | TECH thermo atom count decreased (lost particles) |
| test_lost_particles_stay_tech[run0_row] | TECH: thermo atom count decreased | TECH error/resume log is not fresh completion evidence | TECH thermo atom count decreased (lost particles) |
| test_lost_particles_stay_tech[step1_after_report] | TECH: differs from the report | TECH error/resume log is not fresh completion evidence | TECH thermo atom count after insertion report differs from the report |
| test_insertion_report_contract[total_count] | TECH: inconsistent insertion report | TECH error/resume log is not fresh completion evidence | TECH incomplete or inconsistent insertion report |
| test_insertion_report_contract[total_mass] | TECH: inconsistent insertion report | TECH error/resume log is not fresh completion evidence | TECH incomplete or inconsistent insertion report |
| test_insertion_report_contract[total_period] | TECH: inconsistent insertion report | TECH error/resume log is not fresh completion evidence | TECH incomplete or inconsistent insertion report |
| test_insertion_report_contract[total_missing] | TECH: inconsistent insertion report | TECH error/resume log is not fresh completion evidence | TECH incomplete or inconsistent insertion report |
| test_insertion_report_contract[wrong_step] | TECH: not at the first step of its run | TECH error/resume log is not fresh completion evidence | TECH insertion report is not at the first step of its run |
| test_insertion_report_contract[zero_inserted] | TECH: invalid insertion report values | TECH error/resume log is not fresh completion evidence | TECH invalid insertion report values |
| test_insertion_report_contract[nan_mass] | TECH: invalid insertion report values | TECH error/resume log is not fresh completion evidence | TECH invalid insertion report values |
| test_insertion_report_contract[repeated] | TECH: undeclared, repeated or misplaced | TECH error/resume log is not fresh completion evidence | TECH insertion report of an undeclared, repeated or misplaced insert/pack fix |
| test_insertion_report_contract[undeclared_fix] | TECH: undeclared, repeated or misplaced | TECH error/resume log is not fresh completion evidence | TECH insertion report of an undeclared, repeated or misplaced insert/pack fix |
| test_insertion_report_contract[moved_to_run2] | TECH: undeclared, repeated or misplaced | TECH error/resume log is not fresh completion evidence | TECH insertion report of an undeclared, repeated or misplaced insert/pack fix |
| test_insertion_report_contract[before_setup_row] | TECH: not at the first step of its run | TECH error/resume log is not fresh completion evidence | TECH insertion report is not at the first step of its run |
| test_insertion_report_contract[after_two_rows] | TECH: not at the first step of its run | TECH error/resume log is not fresh completion evidence | TECH insertion report is not at the first step of its run |
| test_insertion_report_contract[less_insertions_warning] | TECH: invalid five-column thermo row | TECH error/resume log is not fresh completion evidence | TECH invalid five-column thermo row |
| test_insertion_report_contract[start_info_inside_table] | TECH: invalid five-column thermo row | TECH error/resume log is not fresh completion evidence | TECH invalid five-column thermo row |
| test_insertion_report_contract[report_then_loop] | TECH: insertion report without its thermo row | TECH error/resume log is not fresh completion evidence | TECH insertion report without its thermo row |
| test_insertion_report_contract[report_missing] | TECH: declared insert/pack fix without its insertion report | TECH error/resume log is not fresh completion evidence | TECH declared insert/pack fix without its insertion report |
| test_insertion_report_contract[report_outside_table] | TECH: declared insert/pack fix without its insertion report | TECH error/resume log is not fresh completion evidence | TECH declared insert/pack fix without its insertion report |
| test_table_structure_stays_tech[header_inside_table] | TECH: thermo header inside an unfinished table | TECH error/resume log is not fresh completion evidence | TECH thermo header inside an unfinished table |
| test_table_structure_stays_tech[fifth_run] | TECH: cumulative run endpoint mismatch | TECH error/resume log is not fresh completion evidence | TECH Loop/thermo cumulative run endpoint mismatch |
| test_table_structure_stays_tech[loop_steps] | TECH: cumulative run endpoint mismatch | TECH error/resume log is not fresh completion evidence | TECH Loop/thermo cumulative run endpoint mismatch |
| test_table_structure_stays_tech[loop_atoms] | TECH: Loop atom count differs | TECH error/resume log is not fresh completion evidence | TECH Loop atom count differs from the last thermo row |
| test_table_structure_stays_tech[fullwidth_procs] | TECH: malformed Loop line | TECH error/resume log is not fresh completion evidence | TECH malformed Loop line |
| test_table_structure_stays_tech[prefixed_loop] | TECH: invalid five-column thermo row | TECH error/resume log is not fresh completion evidence | TECH invalid five-column thermo row |
| test_table_structure_stays_tech[legacy_header] | TECH: Loop lacks a qualified thermo table | TECH error/resume log is not fresh completion evidence | TECH Loop lacks a qualified thermo table |
| test_table_structure_stays_tech[resume_marker] | TECH: error/resume log is not fresh completion evidence | TECH error/resume log is not fresh completion evidence | TECH error/resume log is not fresh completion evidence |
| test_table_structure_stays_tech[read_restart_echo] | TECH: error/resume log is not fresh completion evidence | TECH error/resume log is not fresh completion evidence | TECH error/resume log is not fresh completion evidence |
| test_table_structure_stays_tech[legacy_loop] | TECH: malformed Loop line | TECH error/resume log is not fresh completion evidence | TECH malformed Loop line |
| test_table_structure_stays_tech[concatenated] | TECH: error/resume log is not fresh completion evidence | TECH error/resume log is not fresh completion evidence | TECH error/resume log is not fresh completion evidence |

"""Read-only verification of delivered package bytes, not an inventory CLI."""
import hashlib
import json
from pathlib import Path

base = Path(__file__).resolve().parent.parent
package = base / 'package'
manifest = json.loads((package / 'SNAPSHOT_MANIFEST.json').read_text(encoding='utf8'))
pin = '14773e25b32eec187366b58168e2cf98fd4730c7'
assert (package / 'PIN.txt').read_text().strip() == manifest['pin'] == pin
for row in manifest['entries']:
    data = (package / row['path']).read_bytes()
    assert len(data) == row['bytes'], row['path']
    assert hashlib.sha256(data).hexdigest() == row['sha256'], row['path']
    assert hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest() == row['git_blob'], row['path']
checked = 0
for line in (package / 'SHA256SUMS').read_text().splitlines():
    digest, rel = line.split(None, 1)
    rel = rel.strip().lstrip('*')
    assert hashlib.sha256((package / rel).read_bytes()).hexdigest() == digest, rel
    checked += 1
old = package / 'docs/reviews/lhs_pressure_inventory_20261104/pressure_inventory.sh'
new = package / 'docs/reviews/lhs_inventory_execution_preparation_20261106/pressure_inventory.sh'
assert old.read_bytes() == new.read_bytes()
print(json.dumps({'pin': pin, 'snapshot_entries': len(manifest['entries']), 'packaging_entries': checked,
                  'command_bytes_identical': True, 'scope': 'local package bytes only; no runtime or remote qualification'}, indent=2))

import hashlib, json, subprocess, sys
V21, C = sys.argv[1:3]
p = f'{V21}/CHANGES_v2_to_v2_1.md'; s = open(p, encoding='utf-8').read()
sh = lambda f: hashlib.sha256(open(f, 'rb').read()).hexdigest()
man = json.load(open(f'{V21}/build_20261120/_manifest.json', encoding='utf-8'))
g2 = open(f'{V21}/work/G2.sha').read().strip()
env = {k: v for k, v in __import__('os').environ.items() if not k.startswith('GIT_')}
stat = subprocess.run(['git', '-C', C, 'diff', '--stat', 'bea3cb33a4bdfbe1009866b53ef5f3aacb466802', g2], capture_output=True, text=True, env=env).stdout.rstrip()
vals = {'@@G2@@': g2[:12], '@@MSC@@': sh(f'{V21}/make_sealed_copy.py')[:16] + '…', '@@CSC@@': sh(f'{V21}/evidence/tools/check_sh_commands.py')[:16] + '…',
        '@@CMDSHA@@': man['outputs']['docs/reviews/rint2_kgy_commands_20261020.md']['sha256'][:16] + '…', '@@G2STAT@@': stat}
for k, v in vals.items():
    assert k in s, k; s = s.replace(k, v)
assert '@@' not in s
open(p, 'w', encoding='utf-8').write(s); print({k: v[:60] for k, v in vals.items()})

# litdb 끝 묶음 보고용 메모 (1저자 11-12 '다 진행하고 한번에') — 편마다 한 줄 · 끝에 이것으로 보고

| 편 | slug · 커밋 | 줄 · 크롭 | 핵심 | 서지 · 카드 문제 | 시트 |
|---|---|---|---|---|---|
| N-15 | sadeghirad2011 CPDI · `52c378da0` | 699 · 87 | extension instability 정의 (p.1440) · CPDI 식 21–26 · MMS 오차 표준 9.9e-6 ↔ CPDI 1.72e-8 [판독] · 우리 B-spline 늘어남 숫자 기준 원문에 없음 | gritton2017 · homel2017 · devaucorbeil2020 카드 과장 기록 | litcards/sadeghirad2011_…_sheet_1.png · _2 |
| N-16 | bardenhagen2004 GIMP · `f3d6d0b14` | 628 · 78 | W 12000 MPM 편차 14 % ↔ GIMP 1.7 % · 폭 고정 GIMP -5.2 % ↔ Finite GIMP -0.01 % [판독] · 식 40 + l_p = L/2 = 2차 B-spline [카드 산술] | 서지 = cmes 5(6) 477–495 (후보 표 끝 쪽 · 호 다름) · bardenhagen2005 L564 정의 · gritton2017 [37] 줄 없음 | litcards/bardenhagen2004_…_sheet_1.png · _2 |
| N-17 | benhadjali2026 완전결합 화학-역학 · `da4ed9c99` | 435 · 55 | 집전체 σzz -78 → +35 → -110 MPa [인쇄] · 다섯 사이클 같은 꼴 · 두께 -0.68 → -3.29 → +0.04 % · 완전결합 ↔ 한 방향 과전압 차 약 2.3 mV [판독] · 소성 · 탈압 없음 · 역학 검증 0 | ⚠ 받은 PDF = ChemRxiv v1 프리프린트 (SI 없음) — 후보 표의 ESM 90 105304 는 확인 안 됨 → **출판본 + SI 필요** · benhadjali2026_wip L443 · zhang2026 L64 | litcards/benhadjali2026_…_sheet_1.png · _2 |
| N-19 | ai2011 구름저항 모델 · `81d79396d` | 367 · 67 | 네 부류 (A 방향 일정 토크 = Zhou 1999 원전 · LIGGGHTS cdt 꼴) · A 는 정지 때 토크 뒤집힘으로 잔류 KE (줄지만 안 사라짐) · 안식각 실험 27° ↔ C 27.9–29.4° / A 18.5–21.0° [판독] · 표 1 E 40 MPa 오식 가능 [추정] | 호 (3) 원문에 없음 · ⚠ jadidi2023 L101 '우리 덱 구름마찰 안 씀' ↔ 다섯 카드의 rolling_friction cdt 표기 어긋남 (리포 덱 대조 필요) · chibwe2020 L273–274 · L790 · morrissey2013 | litcards/ai2011_…_sheet_1.png · _2 |

# 지시서 — 메모 3.2 4 회차 고침의 짧은 독립 확인 (11-12 밤 · 문서만 · 내부 반박 리뷰 · Codex 아님 · 결과 0 건)

## 0. 배경

방향 메모 3.2 (`docs/reviews/dem_redesign_direction_20261109/memo_v3_2.md` · 리포 커밋 `ed62b45c2` 에 반입 · push 됨) 는 내부 반박 리뷰 네 회를 거쳤다. 4 회차 재확인 (`review/review4_recheck_memo32.md`) 의 지적을 고친 판 (4 회차 고침) 에는 **독립 확인이 아직 없다**. 다음 단계 = Codex 재리뷰 (리셋 뒤). 그 전에 4 회차 고침만 짧게 본다.

## 1. 볼 것 (읽기만 · 리포 경로 = `/home/user/Yonghoon-DEM-DFT/docs/reviews/dem_redesign_direction_20261109/`)

- 고친 판 `memo_v3_2.md` · 고치기 전 `memo_v3_2_before_review4.md` · 차이 `review/_diff_r4.txt`
- 4 회차 지적 `review/review4_recheck_memo32.md` · 처분 `review/disposition4.md` · 산술 `review/calc_r4_recheck.py` · `review/_calc_r4_out.txt`
- 필요하면 앞 회차 처분 `review/disposition.md` · `disposition2.md` · `disposition3.md` (그 회차에 닫은 것이 4 회차 고침으로 다시 열리지 않았는지만)

## 2. 할 일

1. 4 회차 지적마다: 처분대로 고쳐졌는가 (닫힘 · 부분 · 안 됨) · 근거 = 메모 행 번호.
2. 4 회차 고침이 바꾼 줄만 반박: 새 모순 (같은 메모 안 다른 절 · 표와 본문) · 숫자 · 전칭 (*"전부"* · *"N/N"* · *"같음"*) · 바뀐 권고 (Q6 · Q10 · Q13) 의 문장이 처분과 같은지 · 산술은 다시 셈 (작은 python 스크립트 · 출력 같이 남김).
3. 보장 문장 (결정 규칙 · 갈래 · 문턱) 이 4 회차 고침으로 바뀐 곳은 손으로 풀리는 작은 반례를 하나씩 대 본다.
4. 등급: P1 (결론 · 결정이 틀림) · P2 (규칙 · 숫자 결함) · P3 (문구 · 표지). 4 회차 고침 밖의 옛 문장은 보지 않는다 (범위 밖 = 한 줄 메모만).

## 3. 규칙

- 리포 `/home/user/Yonghoon-DEM-DFT` 는 읽기만 (git 명령 금지 · 파일 수정 금지). `GIT_DIR` · `GIT_WORK_TREE` · `GIT_INDEX_FILE` 을 export 하거나 명령 앞에 붙이지 않는다.
- 산출 = 스크래치 `/tmp/claude-0/-home-user-Yonghoon-DEM-DFT/d26d1e75-209f-540f-83a8-c0e1957edc2f/scratchpad/dem_redesign/review5/` (새 폴더) 의 `recheck5_fix4_memo32.md` + 산술 스크립트 · 출력.
- 주소 · 포트 · 계정 · 홈 경로 값을 쓰지 않는다. Artifact 도구 · 웹 게시 · 시스템 패키지 설치 · 시스템 설정 변경 금지. 실행 · 원격 접속 없음.

## 4. 답장

8 줄 안팎: 4 회차 지적 닫힘 · 부분 · 안 됨 수 · 새 지적 (P1 · P2 · P3 수와 한 줄씩) · 산술 대조 결과 · 산출 파일 전체 경로.

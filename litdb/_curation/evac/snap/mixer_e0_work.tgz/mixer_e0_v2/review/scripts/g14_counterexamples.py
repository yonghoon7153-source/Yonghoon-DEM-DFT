"""G14 — hand-made small logs against the FIXED observer log contract (bb2f3229, HEAD copy).
Read-only: AST-extracts _need, _positive_value, _log_contract and the module-level regex
constants from a copy of the observer file (argv[1]); no repo import, no science module.
Run: python3 -I -B g14_counterexamples.py <observer_HEAD_copy.py.txt>
Each case prints MATCH / TECH:<reason>.  The question per case is written next to it.
"""
import ast, hashlib, math, re, sys

src = open(sys.argv[1], 'rb').read()
print('observer sha256', hashlib.sha256(src).hexdigest())
tree = ast.parse(src.decode('utf-8'))
keep_fn = {'_need', '_positive_value', '_log_contract'}
keep_const = {'_THERMO_HEADER', '_THERMO_ROW', '_THERMO_VALUE', '_LOOP_LINE',
              '_INSERT_REPORT', '_INSERT_TOTAL', '_ERROR_LINE'}
body = []
for n in tree.body:
    if isinstance(n, ast.FunctionDef) and n.name in keep_fn:
        body.append(n)
    elif isinstance(n, ast.Assign) and any(isinstance(t, ast.Name) and t.id in keep_const for t in n.targets):
        body.append(n)
class Tech(ValueError):
    pass
ns = {'re': re, 'math': math, 'Tech': Tech}
exec(compile(ast.Module(body=body, type_ignores=[]), 'observer_copy', 'exec'), ns)
LC = ns['_log_contract']

RUNS = [1, 560606, 560606, 0]
HDR = '    Step    Atoms         KinEng            rke         Volume '
DECK_ERR = '#   (`ERROR: youngsModulus <= 1e9 required for SI units`, global_properties.cpp:371).'
FACTS = dict(comment_lines={DECK_ERR: 1}, insert_fix_run={'ins': 0})

def row(step, atoms=100000, ke='3.2685651e-12'):
    return '%8d %8d  %s  1.0960987e-10  2.7589053e-05 ' % (step, atoms, ke)

def loop(n, atoms=100000, procs=20):
    return ('Loop time of 5.19e-07 on %d procs for %d steps with %d atoms, '
            'finish time Tue Oct  6 19:30:09 2026') % (procs, n, atoms)

def build(procs=20, inserted=100000, warn=False, lose_at=None, extra_out=None, ke_neg=False,
          echo_count=1, rows_every=5000):
    out = ['LIGGGHTS (Version LIGGGHTS-PUBLIC 3.8.0, compiled <DATE> by <BUILD_USER>, git commit <GIT>)']
    out += [DECK_ERR] * echo_count
    cum, atoms = 0, 0
    for k, n in enumerate(RUNS):
        out += ['Setting up run at <DATE>', '', 'Memory usage per processor = 102.09 Mbytes', HDR]
        start = cum
        out.append(row(start, atoms))
        if k == 0:
            if warn:
                out.append('WARNING: Particle insertion: Less insertions than requested (../fix_insert.cpp:700)')
            out.append('INFO: Particle insertion ins: inserted %d particle templates (mass 1.000000e-01) at step 1' % inserted)
            out.append(' - a total of %d particle templates (mass 1.000000e-01) inserted so far.' % inserted)
            atoms = inserted
        cum += n
        for s in range((start // rows_every + 1) * rows_every, cum, rows_every):
            if lose_at is not None and s >= lose_at:
                atoms = min(atoms, 99999)
            out.append(row(s, atoms, '-3.2e-12' if ke_neg else '3.2685651e-12'))
        if n > 0:
            out.append(row(cum, atoms, '-3.2e-12' if ke_neg else '3.2685651e-12'))
        out.append(loop(n, atoms, procs))
        out += ['', '', 'Pair  time (%) = 0 (0)']
        if extra_out and k == 1:
            out.append(extra_out)
    out.append('Total wall time: 4:12:00')
    return ('\n'.join(out) + '\n').encode('utf-8')

def run(name, raw, facts=FACTS):
    try:
        r = LC(raw, RUNS, facts)
        print('%-62s -> %s procs=%s inserted=%s' % (name, r['status'], r['loop_procs'],
              [x['inserted'] for x in r['insertion_reports']]))
    except Tech as e:
        print('%-62s -> TECH: %s' % (name, e))

run('N0 normal full-length (positive control)', build())
run('N1 "on 1 procs" x4 (rank 20 not checked?)', build(procs=1))
run('N2 inserted 99991, no WARNING line (shortfall, D13 allows <=10)', build(inserted=99991))
run('N3 inserted 99991 + WARNING inside table (Q-A)', build(inserted=99991, warn=True))
run('N4 particle loss after step 600000', build(lose_at=600000))
run('N5 WARNING line OUTSIDE tables (between run 2 and 3)', build(extra_out='WARNING: Mesh element Drum lost contact (../fix_mesh.cpp:1)'))
run('N6 negative KinEng in every row', build(ke_neg=True))
run('N7 deck ERROR comment echoed twice (deck has it once)', build(echo_count=2))
run('N8 deck ERROR comment echo absent', build(echo_count=0))
run('N9 facts=None (deck facts not passed)', build(), facts=None)

"""Independent pure-function and stdout probes; never opens ibb/WSL paths.

The received embedded Python is compiled unchanged. Windows lacks pwd, so a
stub is registered for import only; identity and inventory calls are replaced
for main() output tests. This does not reproduce the real Linux runtime.
"""
import ast
import contextlib
import hashlib
import io
import json
from pathlib import Path
import random
import re
import sys
import types

BASE = Path(__file__).resolve().parent.parent / 'received'
COMMAND = BASE / 'docs/reviews/lhs_pressure_inventory_20261104/pressure_inventory.sh'
B7 = BASE / 'scripts/lhs_pressure_record.py'
raw = COMMAND.read_bytes()
shell = raw.decode('utf-8')
code = shell.split("-c '\n", 1)[1].split("\n' \"$@\"", 1)[0]
tree = ast.parse(code, feature_version=(3, 8))
sys.modules['pwd'] = types.ModuleType('pwd')
m = types.ModuleType('independent_contract_probe')
exec(compile(code, str(COMMAND), 'exec'), m.__dict__)

result = {
    'scope': 'Windows pure-function/stdout probes only; pwd import stub, no inventory filesystem execution',
    'command_sha256': hashlib.sha256(raw).hexdigest(),
    'ast_python38_parse': True,
}

want_ibb = [('base', 'lhs00_%03d' % n) for n in range(100)] + [('base', 'lhsx_%03d' % n) for n in range(1, 65)] + [('supp', 'lhss_%03d' % n) for n in range(1, 21)]
want_wsl = [('local', 'lhs00_%03d' % n) for n in range(100, 130)]
assert m.plan('ibb') == want_ibb and m.plan('wsl') == want_wsl
assert len(set(want_ibb + want_wsl)) == 214
result['fixed_plan'] = {'ibb': len(want_ibb), 'wsl': len(want_wsl), 'unique': 214}

b7_tree = ast.parse(B7.read_text(encoding='utf-8'))
b7_regex = next(ast.literal_eval(n.value.args[0]) for n in b7_tree.body if isinstance(n, ast.Assign) and any(isinstance(t, ast.Name) and t.id == 'PRESS_LINE' for t in n.targets))
assert m.PRESS_LINE.pattern == b7_regex
random.seed(4)
tokens = ['Current Pressure: 1 MPa (Target: 2)', 'Current Pressure: NaN MPa (Target: inf)', 'Current Pressure: invalid', 'not a match', '', ' read_restart state', 'Reading restart file state']
separators = ['\n', '\r', '\r\n', '\v', '\f', '\x1c', '\x1d', '\x1e', '\x85', '\u2028', '\u2029']
for _ in range(300):
    text = ''.join(random.choice(tokens) + random.choice(separators) for _ in range(20))
    expected = sum(re.compile(b7_regex).match(line) is not None for line in text.splitlines())
    actual = m.count_text(io.StringIO(text))['b7_matches']
    assert actual == expected, (actual, expected)
result['b7_regex_and_splitlines'] = {'exact_regex': True, 'synthetic_corpora': 300, 'passed': 300}

identities = [
    ('ibb', ('Linux', 'ibb-master', 'generic', 'yonghoon', 1000, 1000), True),
    ('ibb', ('Linux', 'ibb-master', 'microsoft-custom', 'yonghoon', 1000, 1000), False),
    ('ibb', ('Linux', 'different', 'generic', 'yonghoon', 1000, 1000), False),
    ('ibb', ('Linux', 'ibb-master', 'generic', 'yonghoon', 1001, 1000), False),
    ('wsl', ('Linux', 'any-host-name', 'microsoft-custom', 'yonghoon71', 1000, 1000), True),
    ('wsl', ('Linux', 'any-host-name', 'generic', 'yonghoon71', 1000, 1000), False),
    ('wsl', ('Windows', 'any-host-name', 'microsoft-custom', 'yonghoon71', 1000, 1000), False),
]
assert all(m.identity_allowed(mode, identity) == expected for mode, identity, expected in identities)
result['identity_predicate_cases'] = len(identities)

m.runtime_identity = lambda: ('Linux', 'ibb-master', 'generic', 'yonghoon', 1000, 1000)
m.inventory = lambda mode, roots: {'schema': 'lhs_pressure_inventory/v1', 'status': 'INVENTORY_COMPLETE', 'rc': 0}
class TransientOutputFailure:
    def __init__(self):
        self.parts = []
        self.calls = 0
    def write(self, value):
        self.calls += 1
        if self.calls == 2:
            raise OSError('synthetic output failure')
        self.parts.append(value)
        return len(value)
sink = TransientOutputFailure()
with contextlib.redirect_stdout(sink):
    rc = m.main(['ibb'])
text = ''.join(sink.parts)
try:
    json.loads(text)
    single_json = True
except json.JSONDecodeError:
    single_json = False
result['stdout_failure_after_json_before_newline'] = {
    'rc': rc,
    'single_json': single_json,
    'success_status_present': 'INVENTORY_COMPLETE' in text,
    'failure_status_present': 'NOT_ESTABLISHED' in text,
    'output': text,
}
assert rc == 2 and not single_json

class PersistentOutputFailure:
    def write(self, value):
        raise BrokenPipeError('synthetic closed consumer')
try:
    with contextlib.redirect_stdout(PersistentOutputFailure()):
        m.main(['ibb'])
except BrokenPipeError:
    result['persistent_stdout_failure_escapes_main'] = True

result['os_open_flags_source'] = [ast.unparse(n) for n in ast.walk(tree) if isinstance(n, ast.Call) and isinstance(n.func, ast.Attribute) and isinstance(n.func.value, ast.Name) and n.func.value.id == 'os' and n.func.attr == 'open']
destination = Path(__file__).with_name('probe_result.json')
destination.write_text(json.dumps(result, indent=2, ensure_ascii=False) + '\n', encoding='utf-8')
print(json.dumps(result, indent=2, ensure_ascii=False))

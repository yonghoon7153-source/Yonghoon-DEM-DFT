#!/usr/bin/env python3
"""recheck2 — 스크래치 사본 (git 아님) 에 기반 판 커밋 (Q11 · G4 · G5 의 `git show 11a794674:scripts/step3_sigma.py`) 이 읽는 객체 넷만 심는다.
읽기 = 작업 트리 `git -C <작업 트리> rev-parse · cat-file` (읽기 전용) · 쓰기 = 스크래치 저장소의 .git/objects 에 느슨한 객체 (zlib) 를 파이썬으로 직접.
git 의 hash-object 를 쓰지 않는다 (객체가 다른 저장소에도 있으면 그 파일 시각을 건드리는 freshen 길을 피한다).
사용: python3 -I seed_base_objects.py <작업 트리> <스크래치 뿌리> <커밋 약칭> <경로>"""
import hashlib
import os
import subprocess
import sys
import zlib

WT, ROOT, C, PATH = sys.argv[1:5]
ENV = {k: v for k, v in os.environ.items() if not k.startswith('GIT_')}


def g(*a, text=True):
    r = subprocess.run(['git', '-C', WT, *a], capture_output=True, env=ENV)
    if r.returncode != 0:
        raise SystemExit(f'git {a} rc {r.returncode}: {r.stderr[:200]!r}')
    return r.stdout.decode().strip() if text else r.stdout


def put(kind, sha, raw):
    body = f'{kind} {len(raw)}\0'.encode() + raw
    got = hashlib.sha1(body).hexdigest()
    assert got == sha, (kind, sha, got)
    d = os.path.join(ROOT, '.git', 'objects', sha[:2])
    os.makedirs(d, exist_ok=True)
    p = os.path.join(d, sha[2:])
    if not os.path.exists(p):
        with open(p, 'wb') as f:
            f.write(zlib.compress(body))
    return sha


if not os.path.isdir(os.path.join(ROOT, '.git')):
    r = subprocess.run(['git', 'init', '-q', ROOT], capture_output=True, env=ENV)
    assert r.returncode == 0, r.stderr
full = g('rev-parse', '--verify', f'{C}^{{commit}}')
objs = [('commit', full)]
parts = PATH.split('/')
for i in range(len(parts) + 1):
    spec = f'{full}:' + '/'.join(parts[:i])
    sha = g('rev-parse', spec)
    objs.append(('tree' if i < len(parts) else 'blob', sha))
for kind, sha in objs:
    put(kind, sha, g('cat-file', kind, sha, text=False))
print('심음:', ' '.join(f'{k}:{s[:12]}' for k, s in objs))

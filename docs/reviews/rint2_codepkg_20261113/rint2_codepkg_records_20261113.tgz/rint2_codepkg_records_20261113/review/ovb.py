import sys, os, json, shutil, contextlib, io
tree, wd, tag, mode = sys.argv[1], sys.argv[2], sys.argv[3], sys.argv[4]
sys.path.insert(0, os.path.join(tree, 'scripts'))
with contextlib.redirect_stdout(io.StringIO()):
    import test_ca_ext_b6 as B6
shutil.rmtree(wd, ignore_errors=True); os.makedirs(wd)
B6.make_fixture(wd, sdcp=True)
args = B6.OFF + B6.LEAN2 + (B6.CJ if mode == 'cj' else [])
rc, log, d = B6.run_payload(wd, args, out='p.json')
shutil.copy(os.path.join(wd, 'p.json'), os.path.join(os.path.dirname(wd), f'ovb_{tag}_{mode}.json'))
print(tag, mode, 'rc', rc)

# 지시서 — 믹서 E0 자격 pilot 등록 초안 (문서만 · 11-12 · 1저자 "권고대로")

## 0. 할 일 한 줄

믹서 first8 (보정 전 탐색 지도의 첫 8 팔) 를 띄우기 전에 **E0 한 팔을 ibb 에서 자격 확인용으로 돌리는 계획**을, 결과가 나오기 전에 고정해 둘 **등록 초안**으로 쓴다. 발사 · 제출 · ibb 명령 실행은 하지 않는다. 산출은 이 폴더 (`…/scratchpad/mixer_e0_v2/`) 에만 쓴다.

배경: 본 세션 (11-10 ~ 11-12) 이 같은 초안과 리뷰 지시서를 자기 scratch 에 썼지만 인계 묶음에 넘어오지 않았다. 1저자가 그 폴더를 zip 으로 줄 수도 있다 — 오면 본 세션이 이 폴더의 `from_main/` 에 풀어 둔다. **있으면 그것을 이어 쓰고 리포 기록과 대조한다 · 없으면 리포 기록에서 새로 쓴다.** 시작할 때와 끝내기 전에 `from_main/` 이 생겼는지 본다.

## 1. 정해진 것 (바꾸지 않는다)

- 1저자 11-10 운영 결정: Codex 토큰 소진 → **믹서 E0 자격 pilot 한 팔만 내부 반박 리뷰로 Codex GO 를 대신한다 (그 한 팔뿐 · 발사 GO 는 1저자).** (CLAUDE.md 11-10 줄)
- 1저자가 채택한 first8 정책: 팔당 NP20 · 처음 E0 1 팔 · 자격 확인과 별도 wave 승인 뒤 동시 최대 2 팔 · 순서 E0 → 검토 → N0 → 검토 → B1 U/C → B2 U/C → B3 U/C. (`docs/reviews/mixer_inactive_preparation_20261109/README.md` 5 행 · 같은 폴더 `author_policy_record.json`)
- E0 메타 (11-10 ibb 읽기 전용 수집 · `docs/data/mixer_e0_meta_ibb_20261110/`): 바이너리 = 09-28 영수증과 같음 (LIGGGHTS-PUBLIC 3.8.0 · git 3d5c00f) · mpirun 1 · QOS cpu-60 = 사용자당 CPU 60 · GPU 0 · association MaxWall 7 일 · cpu 파티션 14 일 · Lustre 여유 있음.
- 1저자 11-10 Q1–Q8 "권고대로" (진행 기록 `docs/session_20260923_progress.md` 1428 · 1430 행): Q4 기준 바이너리 = 09-28 영수증과 같은 것 · Q5 런 폴더 = 발사 때 새로 · walltime · 디스크 문턱 · **STOP 문턱 = DEV E0 다섯 런 실측으로 결과 전에 등록** · 내부 반박 리뷰 범위 · 반입 = 가린 사본만 · 다음 = "기준 고정 표 + E0 pilot 등록 초안".
- 비활성 준비물 (운영 전환 · 재봉인 0): `docs/reviews/mixer_first8_launch_preparation_20261106/` (submit_one.py.txt · job_start.py.txt · run_one.sbatch.txt · source_seal.json · ledger_proposal.json · campaign_policy.json.example · blockers.json · 시험) · `docs/reviews/mixer_inactive_preparation_20261109/` (현재 소스의 비활성 사본) · `docs/reviews/mixer_path_limited_acceptance_20261109/` · `docs/reviews/nonrint_next_decisions_20261109.md` 3 절 (믹서 M0–M5 · 문서로만 준비할 셋: 비활성→운영 전환 차이표 · 링크 · 제어된 변경 시험 계획 · **E0 pilot 결과 전 기준 · 수동 감시 · STOP · 회수 · 예약 대조 · 다음 wave 판단 양식**).
- 탐색 지도 등록 초안 · 리뷰: `docs/reviews/mixer_precal_exploration_registration_draft_20261104.md` · `docs/reviews/mixer_precal_first8_preparation_20261104/` · `docs/reviews/mixer_precal_first8_recheck_20261105/` · `docs/reviews/mixer_precal_map_acceptance_20261104/` · Codex 요청서 `docs/reviews/codex_mixer_precal_*_2026110*.md`.
- 고-Bo 등록 · DEV 실측 (STOP 문턱의 근거): `docs/reviews/mixer_highbo_prereg_20260927.md` (§8 · §9 · §11–§12) · `docs/reviews/mixer_highbo_stiffness_prereg_20260929.md` (§8 · DEV7 · E0 진단) · `docs/mixer_devlog/` · `docs/data/mixer_highbo_dev_decks_20260930_v26/` · 진행 기록의 09-30 ~ 10-06 믹서 줄 (DEV E0 다섯 런 = ibb job 249077–249084 · 09-30 17:12 KST 발사 · 10-01 04:27 KST 완주 · `dev_e0_diag*.json`). **E0 한 런의 실측 시간 · step/s · 메모리 · 디스크가 리포에 있으면 그 값을, 없으면 [미확인] 으로 적고 어디를 봐야 하는지 적는다.** first8 README 의 "63–70 step/s · E0 ≈ 4.4–4.9 h" 는 옛 가정 (역사 값) 이다 — 등록 문턱은 실측에서만.
- 믹서 정본 규칙: CLAUDE.md 의 믹서 행 · `docs/hetero_thesis.md` (비준 블록) · 1저자 11-09 "DEM 우선, 믹서는 착실하게 진행해야돼".

## 2. 산출 (이 폴더에)

1. `baseline_table.md` — **기준 고정 표**: 바이너리 (경로는 쓰지 않고 판 · git · sha 만) · MPI · STL 셋 · 케이스 덱 (E0 덱의 sha 는 리포 파일에서 계산) · 소스 핀 (first8 비활성 사본의 핀) · NP · 동시 실행 수 · walltime · 디스크 · 런 폴더 규칙 · 감시 주기. 칸마다 근거 (파일 · 행 · 커밋) · 모르는 값 = [미확인] + 어떻게 채우나.
2. `e0_pilot_registration_draft.md` — **등록 초안** (결과 0 건): 목적 (자격 = 무엇을 확인하나 — 시작 · 완주 · 시간 · 자원 · 산출물 무결성 · 판독기 경로), 결과 전 기준 (통과 · 실패 · 기술 실패를 가르는 문턱과 그 근거), STOP · 회수 규칙 (언제 1저자에게 멈춤을 권하나 · 누가 · 어떻게 · 무엇을 남기나), 수동 감시 양식, 예약 대조, 다음 wave 판단 양식 (N0 로 가도 되나를 무엇으로 정하나), 가린 사본 반입 규칙, 하지 않는 것 (판정 · M 열람 · 확인 블록 · 문턱 개정), 1저자 질문 (Q 번호 · 질문마다 권고 한 줄).
3. `review_brief.md` — 다음 단계 **내부 반박 리뷰 지시서** (독립 조수 · Codex 아님 · 고친 쪽 설명 없이 문서만 · 보장마다 작은 반례 · P1/P2/P3 · 기록 꼴).
4. `REPORT.md` — 10 줄 안팎 요약 (무엇을 썼나 · [미확인] 목록 · 1저자 질문).

## 3. 규칙

- 리포 본 트리 `/home/user/Yonghoon-DEM-DFT` 는 게이트가 도는 중 — **읽기만** (git 으로 상태를 바꾸는 명령 금지 · 파일 쓰기 금지). 다른 트리 (`/home/user/litdb-canon` · `/home/user/litdb-canon2` · `/home/user/rint-codepkg` · `/home/user/litdb-ctl`) 는 건드리지 않는다.
- ibb · kgy · gabia 에 접속하지 않는다. 주소 · 포트 · 계정 · 홈 경로는 파일에 쓰지 않는다 (`<IBB>` 같은 자리표만).
- 숫자는 리포 기록에서만 (파일 · 행 · 커밋을 붙인다). 추정은 [추정] · 확인 안 된 것은 [미확인].
- 결과가 나오기 전에 등록하는 문서다 — 결과를 보고 문턱을 옮기는 여지를 남기지 않는다 (문턱 = 숫자 · 근거 · 언제 정했나).
- 문체: 한국어 · 표 중심 · 짧게 · 개조식 끝. 천 단위 콤마 쓰지 않는다.

## 4. 답장

`REPORT.md` 의 내용 (10 줄 안팎) + 산출 파일 전체 경로. 길게 설명하지 않는다.

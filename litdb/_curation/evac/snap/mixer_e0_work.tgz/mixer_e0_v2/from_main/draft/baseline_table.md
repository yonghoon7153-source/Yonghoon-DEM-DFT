# 믹서 E0 자격 pilot 한 팔 — 기준 고정 표 (초안 · 2026-11-11)

**지위: 초안 · 문서만 · 실행 0 · 제출 0 · 결과 0 건 · 자격 판정 아님 · 전체 HOLD 그대로.**
받은 메타 (관측) 를 "발사 때 대조할 기준" 으로 적어 둔 표다. 값이 맞는다고 실행 승인이 되지 않는다.

## 읽는 법

- 원천 = `docs/data/mixer_e0_meta_ibb_20261110/out/` (가린 사본 132 파일). "근거" 칸의 파일 이름은 그 폴더 안이고, `L` 뒤 숫자는 그 파일의 줄 번호다.
- 리포 경로 줄임: `F8` = `docs/reviews/mixer_first8_launch_preparation_20261106` (first8 준비 묶음). out/ 밖 근거에는 "리포" 라고 적었다.
- 수집 창 = 2026-11-10T14:49:56Z ~ 14:53:02Z · 186 초 (`fields.txt` L5 · L577 · L578). **모든 값은 그 3 분의 관측이다.**
- 가린 꼴 그대로 쓴다: `<HOME>` (로그인 경로) · `<HOME_REAL>` (풀린 실제 경로) · `<USER>` · `<UID>` · `<REMOTE>` · `<BUILD_USER>` · `<HOST>`. 주소 · 호스트 이름 · 계정 이름 · 포트는 이 문서에 없다.
- "다시 확인" = 발사 직전에 다시 재는가. 발사 직전 = 제출 전 5 분 안 + job 시작 때. 근거 = first8 준비 문서의 preflight 1–6 (리포 `F8/inventory.md` L43–48) · 제출 가드의 300 초 규칙 (리포 `F8/submit_one.py.txt` L125–126).
- out/ 에 없는 값은 **미확인** 이다 (계획 문서 말로는 UNKNOWN / PROBE_NEEDED). 지어 채우지 않았다.
- [산술] = 인용한 숫자로 본 세션이 계산한 값. [추정] = 가정이 들어간 값.

## 0. 영수증 칸 (R0–R6) 과 이 표의 자리

영수증 칸의 정의 = `docs/reviews/nonrint_approved_preparation_20261109/mixer_ibb_qualification_receipt_plan.md` L53–59.

| 칸 | 이 표의 절 | 지금 상태 |
|---|---|---|
| R0 대상 · 범위 | 1 | 수집 메타 있음. 설치 실체 인증 · 운영자 · 승인 참조는 out/ 밖 (1저자) |
| R1 링크 · 경로 | 6 | 조상 경로의 종류 · 모드 관측 있음. 링크 거부 자격 시험은 안 했다 |
| R2 권한 · 변경 통제 | 2 · 6 | 모드 · 소유 · ACL 수 관측 있음. 변경 통제 (불변 창) 는 out/ 에 없다 (미확인) |
| R3 binary / MPI | 2 · 3 | sha256 · 판 · ldd 관측 있음. 라이브러리 해시 · job 안 런타임 = 미확인 |
| R4 SLURM · 자원 | 4 | QOS · association · 파티션 · 내 잡 수 관측 있음 (시점 값) |
| R5 시간 · 저장 · 회수 | 5 | df · inode · 사용량 관측 있음. 기본 한도 값 · 런별 크기 = 미확인. walltime · 문턱은 등록 초안 (`registration_draft.md`) |
| R6 최종 결속 | 7 | first8 묶음이 ibb 에 아직 없다 → 전부 미확인 (봉인 단계의 몫) |

## 1. 수집 · 대상 (R0)

| 칸 | 값 | 근거 | 다시 확인 |
|---|---|---|---|
| 대상 별칭 | ibb | `fields.txt` L3 | 예 — preflight 1 (날짜 · 호스트 · 운영자). 원문은 ibb 의 raw/ 에만 둔다 |
| 수집 스크립트 | md5 4e01c25f8f3a1cebc9daee51e2999cc4 · sha256 4d9e11f4ea216e71d506e9225160e92e5bd89bd52461c929ce72e8f4691a0553 | `fields.txt` L13 · L14 | 아니오 — 수집 도구의 신원일 뿐이다 |
| OS | Rocky Linux 8.7 · 커널 4.18.0-553.40.1.el8_10.x86_64 · glibc 2.28 · bash 4.4.20 | `os_release.txt` L7 · `os_uname.txt` L1 · `os_glibc.txt` L1 · `fields.txt` L7 | 아니오 — 발사 판정에 쓰지 않는 기록 칸 |
| SLURM 할당 안에서 수집했나 | 아니오 (로그인 셸) | `fields.txt` L47 | 예 — job 안 환경 (PATH · 라이브러리 · TMPDIR) 은 잰 적이 없다 |
| 조회 결과 | OK 127 · FAIL 13 | `fields.txt` L579 | 해당 없음 |
| FAIL 13 의 내용 | 가지 이름 10 (체크아웃 10 곳) · 정적 배너 1 · `lmp_mpi -h` 종료 코드 1 · `quota -s` 1 | `probes.txt` L9 (repo1) · L95 · L97 · L115 | 해당 없음 |
| 가림 뒤 남은 토큰 | 0 | `fields_post.txt` L2 | 해당 없음 |

## 2. 바이너리 (R3)

| 칸 | 값 | 근거 | 다시 확인 |
|---|---|---|---|
| 실행 파일 경로 (가린 꼴) | `<HOME>/LIGGGHTS-PUBLIC/src/lmp_mpi` → 실제 `<HOME_REAL>/LIGGGHTS-PUBLIC/src/lmp_mpi` | `fields.txt` L484 · L483 | 예 — job 시작 때 실제 경로를 다시 푼다 (preflight 2) |
| 후보 | 후보 123 개 중 실제 파일 1 개. conda env 쪽 `lmp_mpi` 후보는 없음 (UNRESOLVED) | `fields.txt` L481 · L482 · L378 | 아니오 |
| sha256 | ee2d77261bac9e7fa4e9311c8709e74bf7583a13225a5bc35a791bef9be60a3f | `fields.txt` L486 · `hashes.txt` L474 | 예 — 준비 · staging · job 시작 세 번 (preflight 2–3). 파일이 그룹 쓰기 가능이라 바뀔 수 있다 |
| 09-28 영수증 바이너리와 같은가 | 같음 (`same`) → Q4 = 이 바이너리 | `fields.txt` L487 (대조 값 = `meta_script.sh` L11 · 리포 `docs/data/mixer_phase_receipt_20260928/receipt_v2_ibb.json` L1474) | 예 — sha256 대조 한 번으로 같이 본다 |
| 크기 · 수정 시각 | 9,180,024 B · mtime 1774503499 (= 2026-03-26T05:38:19Z [산술]) | `fields.txt` L485 · `hashes.txt` L474 | 예 (sha256 과 같이) |
| 판 | LIGGGHTS-PUBLIC 3.8.0 | `lmp1_help.txt` L1 | 아니오 — sha256 이 같으면 같은 바이트다. job 로그 첫 줄 배너는 기록한다 |
| 빌드 날짜 | compiled 2026-03-26-14:37:06 by `<BUILD_USER>` | `lmp1_help.txt` L1 | 아니오 (위와 같음) |
| git | 3d5c00f20519e6bb6eb6756f51f1ad36564e649d | `lmp1_help.txt` L1 | 아니오 (위와 같음) |
| 배너를 얻은 방법 | `lmp_mpi -h` 실행 (종료 코드 1 · 출력 9,033 B). 파일에서 찾는 정적 배너는 실패 (0 B) | `probes.txt` L97 · L95 | 해당 없음 |
| 파일 종류 | ELF 64-bit · x86-64 · 동적 링크 · not stripped | `lmp1_file.txt` L1 | 아니오 |
| 권한 | 일반 파일 · 모드 775 · 소유 = 나 · 그룹 = 나 · 그룹 쓰기 가능 · 이름 붙은 ACL 0 | `fields.txt` L485 · `walk.txt` L75 · `fields.txt` L549–550 | 예 — 변경 통제는 정해진 것이 없다 (R2 · 미확인). 조상 `<HOME_REAL>` 은 700 (`walk.txt` L72) |
| 덱이 쓰는 스타일 | 있음: pair gran 의 hertz · history · sjkr · cdt / fix mesh/surface · wall/gran · particletemplate/sphere · particledistribution/discrete · insert/pack · nve/sphere · move/mesh · property/global · gravity / compute erotate/sphere / dump custom | `lmp1_help.txt` L36 · L41 · L45 · L49 · L64–78 · L85 · L100 | 아니오 — 기능 목록일 뿐이다. 물리 · 로그 호환 자격이 아니다 |
| 링크 라이브러리 (ldd) | 31 줄 = conda env (`<HOME>/.conda/envs/myenv/lib/`) 23 · 시스템 `/lib64` 7 · vdso 1. MPI = `libmpi.so.40` (conda env) | `lmp1_ldd.txt` L1–31 (L3) | 예 — 로그인 셸 값이다. job 안에서 다시 |
| 링크 라이브러리 sha256 | **미확인** — 30 행 중 29 행이 심볼릭 링크라 해시가 없다. 잡힌 것은 libgcc_s.so.1 하나 (0907d66b5a5f028480cf78adad58180e1c1183a3a085877e8f4fd471af60d50c) | `hashes.txt` L475–504 (L478). `fields.txt` L488 의 "30" 은 행 수다 | 예 — 봉인 전에 링크 대상 파일의 sha256 을 받는다 |
| 라이브러리를 찾는 길 (RPATH 등) | **미확인** — LD_LIBRARY_PATH 는 UNSET 인데 conda env 로 풀린다. 까닭은 out/ 에 없다 | `fields.txt` L50 · `lmp1_ldd.txt` L3 | 예 |

## 3. MPI · 실행 환경 (R3)

| 칸 | 값 | 근거 | 다시 확인 |
|---|---|---|---|
| mpirun 경로 (가린 꼴) | `<HOME>/.conda/envs/myenv/bin/mpirun` → 실제 `<HOME_REAL>/.conda/envs/myenv/bin/mpirun` | `fields.txt` L519 · L518 | 예 — job 시작 때 |
| 후보 | 후보 26 개 중 실제 파일 1 개 (mpiexec 도 같은 파일) | `fields.txt` L516 · L517 · L511 | 아니오 |
| mpirun sha256 | 407990f94f9d3863be273b44e6e8fc96b9a015a3b14763ae0aab60857d1ee72d · 190,592 B · mtime 1774502927 (= 2026-03-26T05:28:47Z [산술]) · 모드 755 | `fields.txt` L521 · L520 · `hashes.txt` L505 | 예 |
| MPI 판 | mpirun (Open MPI) 5.0.10 | `mpi1_version.txt` L24 | 아니오 (sha256 이 같으면) |
| conda 꾸러미 (myenv · 79 개 중) | openmpi-5.0.10-h67ed482_1 · mpi-1.0.1-openmpi · ucx-1.20.0 · libfabric-2.5.0 · libpmix-5.0.8 · libhwloc-2.13.0 · libstdcxx-15.2.0 · libgcc-15.2.0 | `conda1_meta.txt` L64 · L38 · L56 · L63 · L65 · L46 · L12 · L55 | 예 — conda env 는 고칠 수 있는 자리다 (디렉터리 모드 2775 · `walk.txt` L79–82) |
| 다른 MPI 의 흔적 | 시스템 anaconda 꾸러미 목록에 mpich 이름이 있다 (mpi-1.0-mpich · mpich-3.3.2-external_0). 그쪽 `mpirun` 파일은 없다 (UNRESOLVED) → 실제 mpirun 은 위 하나뿐 | `conda2_meta.txt` L9 · L15 · `fields.txt` L515 | 예 — job 안에서 실제로 풀린 mpirun 경로를 적는다 |
| 로그인 셸 환경 | PATH 앞쪽 = `<HOME>/LIGGGHTS-PUBLIC/src` · `<HOME>/qe-7.4.1/bin` · `<HOME>/.conda/envs/myenv/bin` · 시스템 anaconda. CONDA_DEFAULT_ENV=base · LD_LIBRARY_PATH UNSET · OMP_NUM_THREADS UNSET · 모듈 0 | `fields.txt` L49 · L51 · L50 · L54 · L57 · `module_list.txt` L1 | 예 — job 안 환경은 잰 적이 없다 |
| 수집 때 MPI 경고 | "세션 폴더가 공유 파일시스템 (lustre) 위" 라는 PRTE 경고. 수집 블록이 TMPDIR 을 자기 폴더로 잡아서 났다 | `mpi1_version.txt` L2–7 | 아니오 — 단 job 안 TMPDIR 자리는 **미확인** |
| DEV 런이 쓴 MPI 호출 | 플래그 `--oversubscribe --bind-to none` · NP 20 · conda env myenv · PATH 덧붙임 없음 | `seal_extract.txt` L985 · L984 · L989 · L990 (E0_ref_s32452843) | 아니오 (기록) |
| MPI 런타임 (rank 수 · 바인딩 · 노드 배치) | **미확인** — 로그인 셸에서 `--version` 만 돌렸다 | `probes.txt` L98 | 예 — job 안에서만 볼 수 있다 (pilot 자신의 몫) |
| Python (가드 · job 시작 · 관측기용) | 후보 둘. myenv = 3.10.20 · numpy 2.2.6 · scipy 1.15.3 · sha256 561c350efec08f1712162c4d649f4b668bacceb68388e973efec964f0073cd92 / 시스템 anaconda = 3.9.13 · numpy 1.21.5 · scipy 1.9.1 · sha256 e8cd6aea4793c192bb74ffcfc1c670afa4629eca2a3ea998c5e15c1c876a3917. 어느 쪽을 쓸지 **미정** | `py1_version.txt` L1 · `py1_modules.txt` L1–2 · `fields.txt` L529 / `py2_version.txt` L1 · `py2_modules.txt` L1–2 · `fields.txt` L532 | 예 — 러너에 절대 경로로 박는 칸이다 (리포 `F8/run_one.sbatch.txt` L14 = UNRESOLVED) |

## 4. SLURM (R4)

| 칸 | 값 | 근거 | 다시 확인 |
|---|---|---|---|
| SLURM 판 | slurm 22.05.2 | `slurm_sinfo_version.txt` L1 | 아니오 |
| 파티션 | cpu (기본) · up · 노드 4 · 노드당 CPU 152 · 노드당 메모리 515,000 MB · 상태 mix | `slurm_sinfo_partitions.txt` L1 (열 뜻 = `meta_script.sh` L440) | 예 — 상태는 시점 값 |
| 파티션 시간 상한 | 14-00:00:00 | `slurm_sinfo_partitions.txt` L1 | 예 — 관리자가 바꿀 수 있는 값 |
| 노드 사용 | 할당 / 유휴 / 기타 / 전체 = 4 / 0 / 0 / 4 (유휴 노드 0) | `slurm_sinfo_summary.txt` L2 | 예 — 시점 값. 빈 코어 수는 **미확인** (out/ 에 없다) |
| QOS cpu-60 | 사용자당 한도 = cpu 60 (GPU a100 0 · rtx3090 0). 우선순위 0. MaxWall · 사용자당 잡 수 · 제출 수 칸은 빈칸 | `slurm_qos.txt` L23 (열 뜻 = `meta_script.sh` L442) | 예 |
| 내 association | QOS = cpu-60 하나 · **MaxWall = 7-00:00:00**. Partition · DefaultQOS · MaxJobs · MaxSubmit · MaxTRES · GrpTRES 칸은 빈칸. 줄 1 개 | `slurm_assoc_me.txt` L1 (열 뜻 = `meta_script.sh` L443 · Account 열은 일부러 안 모았다) | 예 |
| 걸리는 시간 상한 | 7-00:00:00 [추정 — association 7 일과 파티션 14 일 중 작은 쪽이 걸린다고 읽음] | 위 두 줄 | 예 |
| 내 잡 수 | 0 (squeue 종료 코드 0 · 출력 0 줄) | `slurm_squeue_me.txt` (0 줄) · `probes.txt` L110 · `fields.txt` L537–538 | 예 — 제출 전 5 분 안. 가드 규칙 = 내 잡 CPU + 20 ≤ 60 (리포 `F8/submit_one.py.txt` L132–133) |
| 다른 사용자 큐 · 빈 코어 | **미확인** (타인 자료라 안 모았다) | — | 예 — 대기 시간 가늠용. 판정에는 안 쓴다 |
| 메모리 요청 · 한도 | **미확인** — DEV 러너와 first8 러너 초안 둘 다 메모리 지정이 없다 (리포 `dem_scripts/mixer_20260921/launch_highbo.sh` L293–298 · `F8/run_one.sbatch.txt` L2–7) | — | 예 — DEV E0 잡의 sacct (MaxRSS · ReqMem) 를 받으면 채운다 |

## 5. 디스크 (R5)

| 칸 | 값 | 근거 | 다시 확인 |
|---|---|---|---|
| HOME 파일시스템 | lustre · 마운트 `/lustre` · 원격 `<REMOTE>:/lustre` · 옵션 rw, checksum, flock, nouser_xattr, lruresize, lazystatfs, nouser_fid2path, verbose, encrypt | `fields.txt` L539–540 · `findmnt_home.txt` L1 | 아니오 (정적). 단 런 폴더 경로가 정해지면 그 경로로 df 를 한 번 잰다 |
| 전체 · 사용 · 여유 (바이트) | 745,348,133,519,360 · 565,160,840,167,424 · **142,604,135,108,608 B** · 80 % | `df_home_bytes.txt` L2 | 예 — 공유 파일시스템 · 시점 값 |
| 같은 값 (df -h) | 678T · 515T · 130T · 80 % | `df_home_human.txt` L2 | (위와 같음) |
| inode | 전체 755,667,898 · 사용 196,186,622 · **여유 559,481,276** · 26 % | `df_home_inodes.txt` L2 | 예 |
| 믹서 폴더가 있는 파일시스템 | 세 폴더 모두 같은 `/lustre` | `fields.txt` L541–546 | 아니오 |
| 내 사용량 | 2,228,675,672 KB · 파일 543,500 개 | `lfs_quota_home.txt` L3 | 예 |
| 내 할당 (한도) | 개인 칸은 quota 0 · limit 0 (블록 · 파일 둘 다). "기본 할당 설정을 쓴다" 는 줄이 2 개 있다 → **기본 한도의 실제 값 = 미확인** | `lfs_quota_home.txt` L3 · L4 · L5 | 예 — 기본 한도를 보는 읽기 조회가 필요하다 (등록 초안 9 절) |
| `quota -s` | 실패 (종료 코드 1 · 출력 0 B). Lustre 라 `lfs quota` 로 따로 받았다 | `probes.txt` L115 · L116 | 아니오 |
| OST 별 여유 | **미확인** (df 는 집계 값이다) | — | 예 (권고) |
| 믹서 폴더 크기 (du -sk) | 09-21 층상 runs 524,888 KB · dev7 63,444,400 KB · dev7_v26 90,504,844 KB | `mix1_du.txt` L1 · `mix2_du.txt` L1 · `mix3_du.txt` L1 | 아니오 — Q6 산술의 입력이다 |
| DEV E0 런별 덤프 크기 · 프레임 한 장 크기 | **미확인** — out/ 에는 폴더 합계와 런별 항목 수만 있다 (post 는 디렉터리 항목 크기뿐) | `mix3_run23_ls.txt` L10 · `fields.txt` L348 | 예 — 등록 초안 9 절의 조회로 채운다 |
| first8 제안 root | 없음 (`<HOME>/mixer_precal_first8_20261106` 이 없다). 홈 아래 믹서 폴더는 dev7 · dev7_v26 · 수집 폴더뿐 | `fields.txt` L353 · `home_mixer_dirs.txt` L1–3 | 예 — Q5: 발사 때 새로 만든다 |

## 6. 경로 · 권한 (R1 · R2 · 보조)

| 칸 | 값 | 근거 | 다시 확인 |
|---|---|---|---|
| HOME 의 실제 자리 | `<HOME>` 은 `/home` 아래. `/home` 은 `/lustre/home/` 으로 가는 심볼릭 링크 (모드 777 · 소유 root). 실제 경로는 `/lustre` 아래 | `fields.txt` L6 · `walk.txt` L77 · L85 | 아니오 — 단 봉인 묶음의 경로 문자열은 한 가지 꼴로 통일해야 한다 (8 절 관찰 1) |
| HOME | 디렉터리 700 · 소유 = 나 · 이름 붙은 ACL 0 | `walk.txt` L86 · L72 · `fields.txt` L547–548 | 아니오 |
| 바이너리 조상 | `/` 555 root · `/lustre` 755 root · `/lustre/home` 755 root · `<HOME_REAL>` 700 나 · `LIGGGHTS-PUBLIC` 775 · `src` 775 (그룹 쓰기) | `walk.txt` L69–74 | 예 (R2) |
| dev7_v26 폴더 | 775 · 그룹 쓰기 가능 · 이름 붙은 ACL 0 | `fields.txt` L193 · L555–556 · `walk.txt` L68 | 아니오 — pilot 은 이 폴더를 쓰지 않는다 (Q5) |
| conda env 경로 | `.conda` · `envs` · `myenv` · `bin` = 2775 (그룹 쓰기) · mpirun = 755 | `walk.txt` L79–83 | 예 (R2) |
| 새 폴더의 기본 권한 (umask) | **미확인** | — | 예 — 런 폴더를 만든 뒤 모드를 본다 |

## 7. 덱 · 템플릿 신원 (R6 · out/ 에 있는 것만)

| 칸 | 값 | 근거 | 다시 확인 |
|---|---|---|---|
| ibb 위 first8 E0 덱 | **없음** (ABSENT). first8 root 가 없다 — Q5 대로 아직 안 만들었으니 정상 | `hashes.txt` L473 · `fields.txt` L355 | 예 — 발사 때 새로 놓고 sha256 을 계획 바이트와 대조 (preflight 3) |
| ibb 위 first8 메타 · STL · 러너 · 가드 · 정책 · 승인 파일 | **미확인 = 없음** (같은 까닭) | `fields.txt` L353 | 예 — 봉인 단계에서 처음 생긴다 |
| ibb 체크아웃 (repo1) | HEAD 063309e5e821e6fd898f23eb7d9a9861ef5b1dbd · 가지 이름 조회 실패 (떨어진 HEAD 로 읽음 [추정]) · status 출력 0 B · 마지막 커밋 1791277818 (= 2026-10-06T09:10:18Z [산술]) | `repo1_head.txt` L1 · `probes.txt` L9 · L11 · `repo1_log1.txt` L1 | 예 — 단 이 체크아웃은 pilot 소스가 아니다 (아래 줄) |
| 체크아웃에 first8 스크립트가 있나 | **없음** — `scripts/mixer_precal_prepare.py` · `scripts/mixer_precal_observe.py` 가 ABSENT (체크아웃 10 곳 모두) | `hashes.txt` L16–17 (다른 9 곳 = L33 · L50 · L67 · L84 · L101 · L118 · L135 · L152 · L169 부터 두 줄씩) | 예 — pilot 소스 묶음은 새로 놓아야 한다 |
| 체크아웃의 STL 셋 | Drum fe821a8ab6db0d94151e9d84bf19cc1fad77abb417cd640bf4577c2f87279730 (14,310 B) · Front 443f9c3c859b2562dc041cde2af712fdfc4ab0225032ebb9420267c781843c81 (5,990 B) · Back 2e7b962d14ced968d8178456feaf2f6a4856edd4b151070c23a8ac1588a461e5 (10,790 B) | `hashes.txt` L6 · L7 · L8 | 예 — staging 뒤 pilot 폴더의 STL 로 다시 |
| 체크아웃의 생성기 · 되읽기 · 비교기 · M 판독기 | make_mixer_deck.py f3cd4d9f… · mixer_deck_readback.py 1bab4ba1… · mixer_deck_diff.py 8cc033ce… · measure_mixing_index.py 4375ec56… | `hashes.txt` L13 · L12 · L11 · L14 | 아니오 — pilot 에 안 쓰는 옛 판이다 (8 절 관찰 2) |
| 체크아웃의 런처 · 정책 · 시작 대조기 | launch_highbo.sh ed469ffa… · launch_policy.json 08bdcb4f… (DEV 런 봉인의 STIFF-DEV-U-2026-10-05 와 같은 해시) · start_check.py 93fa907e… | `hashes.txt` L1 · L2 · L3 · `seal_extract.txt` L673–674 | 아니오 — first8 은 이 런처 · 정책을 쓰지 않는다 (리포 `F8/inventory.md` L30) |
| DEV E0 다섯 런 (dev7_v26) 의 덱 sha256 | E0_ref_s32452843 78ad92356373e00a… · E0_ref_s49979687 0544fffbf5c7ae26… · E0_ref_s67867967 b79e0d73c8a36c78… · E0_ref2_s32452843 cc470941768ae5dd… · E0_ref_dthalf_s32452843 819c8a7f2310d2b5… | `hashes.txt` L461 · L453 · L341 · L304 · L386 (`seal_extract.txt` L961 · L921 · L561 · L441 · L721 과 같다) | 아니오 — Q6 산술의 출처 신원이다 (pilot 덱이 아니다) |
| DEV E0 런의 STL 셋 | 체크아웃 STL 과 같은 세 해시 | `hashes.txt` L462 · L470 · L464 (E0_ref_s32452843) | 아니오 |
| DEV E0 런의 실행 기록 | 다섯 다 시작 대조 ok=true · NP 20 · QOS cpu-60 · 파티션 cpu · 시간 한도 2-00:00:00 · 바이너리 sha256 = 2 절과 같음 · 정책 STIFF-DEV7-2026-09-30-v26-dev-e0-rot | `seal_extract.txt` L965 · L984 · L986–988 · L960 · L993 (E0_ref_s32452843. 나머지 넷도 같은 칸) | 아니오 |
| DEV E0 진단 기록 | dev7_v26 = schema mixer_dev_e0_diag/1 · verdict PASS (기록 5 개). dev7 (옛 덱) = FAIL | `diag_extract.txt` L3–12 · L1–2 | 아니오 — pilot 판정과 무관 |

## 8. out/ 를 읽다가 본 것 (관찰 · 판정 아님)

1. **경로 꼴이 두 가지다.** 로그인 경로 `<HOME>` 은 심볼릭 링크 (`/home`) 를 지난다 (`walk.txt` L77). DEV 봉인에도 두 꼴이 섞여 있다 — 발사 기록의 `lmp_path` 칸이 09-28 런은 `<HOME>` 꼴, 09-30 런은 `<HOME_REAL>` 꼴이다 (`seal_extract.txt` L22 · L976). first8 가드는 자기 파일의 풀린 경로와 문자열로 대조한다 (리포 `F8/submit_one.py.txt` L43–44 · L52). 봉인 묶음에 `<HOME>` 꼴을 적으면 제출이 막힌다 [관찰 — 코드 판독 · 시험 안 함].
2. **ibb 체크아웃은 first8 소스가 아니다.** first8 스크립트 둘이 없고 (`hashes.txt` L16–17), 생성기 해시 f3cd4d9f… 는 first8 봉인의 생성기 661936b7… (리포 `F8/source_seal.json` L27) 와 다르다.
3. **라이브러리 신원이 비어 있다.** 30 행 중 29 행이 심볼릭 링크라 해시가 없다 (`hashes.txt` L475–504). 지금 고정된 것은 실행 파일 둘 (lmp_mpi · mpirun) 의 바이트뿐이다.
4. **Python 판이 first8 시험 판과 다르다.** ibb = 3.10.20 (myenv) · 3.9.13 (시스템). first8 문서의 시험 판 = 3.8.20 · 3.12.14 · 3.11.17 (리포 `F8/README.md` L36 · `docs/reviews/mixer_precal_first8_preparation_20261104/README.md` L51). ibb 판에서 가드 · 관측기를 돌린 기록은 없다.
5. **유휴 노드가 0 이었다** (`slurm_sinfo_summary.txt` L2). 내 잡은 0 이지만 바로 시작된다는 보장은 out/ 에 없다.
6. 관측기 로그 계약과 실제 ibb 로그 형식의 어긋남은 out/ 밖 증거 (리포의 10-06 로그) 라서 등록 초안 7-3 절에 적었다.

## 9. "미확인" 칸 모음

| # | 칸 | 채우는 길 |
|---|---|---|
| 1 | 링크 라이브러리 29 개의 sha256 | 링크 대상 파일의 sha256 (읽기 조회) |
| 2 | 라이브러리를 찾는 길 (RPATH 등) | `readelf -d` 읽기 조회 |
| 3 | job 안 환경 · MPI 런타임 (rank · 바인딩 · TMPDIR) | pilot job 의 시작 영수증 |
| 4 | Python 경로 · 판 고정 | 봉인 단계에서 정함 |
| 5 | 메모리 요청 · 한도 · DEV E0 의 MaxRSS | DEV E0 잡 다섯의 sacct |
| 6 | 빈 코어 수 · 다른 사용자 큐 | 발사 직전 조회 (판정 아님) |
| 7 | 기본 할당 한도의 실제 값 | `lfs quota -U` 류 읽기 조회 |
| 8 | OST 별 여유 | `lfs df` 읽기 조회 |
| 9 | DEV E0 런별 덤프 크기 · 프레임 한 장 크기 · 첫 프레임까지 시간 | du · 파일 목록 읽기 조회 |
| 10 | 새 폴더 기본 권한 (umask) | 런 폴더를 만든 뒤 |
| 11 | first8 덱 · 메타 · STL · 러너 · 가드 · 정책 · 승인 파일 (ibb 위) | 봉인 단계 (지금은 없음) |

## 10. 발사 직전 다시 확인할 것 (요약)

| 순서 | 무엇 | 기준 값 (이 표) | 규칙 |
|---|---|---|---|
| 1 | 날짜 · 호스트 · 운영자 · 내 association · QOS | 4 절 | preflight 1 |
| 2 | 바이너리 · mpirun 의 실제 경로 · sha256 (+ 라이브러리) | 2 · 3 절 | preflight 2 — job 안에서 한 번 더 |
| 3 | 덱 · 메타 · STL · 소스 · 러너 · 정책의 sha256 | 등록 초안 1 절 (계획 바이트) | preflight 3 — 준비 · staging · job 시작 세 번 |
| 4 | 내 잡의 CPU 합 + 20 ≤ 60 · 파티션 cpu · QOS cpu-60 | 4 절 | preflight 4 · 가드 300 초 규칙 |
| 5 | 여유 바이트 · inode · 사용량 · 한도 | 5 절 | preflight 5 — 바닥 값은 등록 초안 5 · 6 절 |
| 6 | walltime | 등록 초안 4 절 | preflight 6 |

## 11. 한정

- sha256 은 내용 신원이다. 작동 · 호환 · 승인의 증명이 아니다.
- `lmp_mpi -h` 의 목록은 기능 목록이다. 물리 · 로그 호환 자격이 아니다.
- "미확인" · FAIL 은 0 · 빈 큐 · 무제한 할당을 뜻하지 않는다.
- 이 표의 값은 로그인 셸에서 3 분 동안 본 것이다. job 안 값과 같다는 보장이 없다.
- 이 표는 자격 수행 · 운영 승인 · 발사 GO 가 아니다.

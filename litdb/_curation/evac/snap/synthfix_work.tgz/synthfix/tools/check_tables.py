#!/usr/bin/env python3
"""표 칸 수 점검 (읽기만).

    python3 -I check_tables.py <파일 또는 폴더> [...]

표 무리 = '|' 로 시작하는 줄이 이어진 것. 머리 줄 (첫 줄) 의 칸 수와 다른 줄을 센다.
'\\|' (역슬래시 막대) 는 칸 구분으로 세지 않는다. 구분 줄 (|---|) 이 둘째 줄이 아닌 무리도 적는다.
"""
import os
import re
import sys


def cells(line):
    s = line.rstrip('\n')
    s = s.replace('\\|', '\x00')
    s = s.strip()
    if s.startswith('|'):
        s = s[1:]
    if s.endswith('|'):
        s = s[:-1]
    return [c.replace('\x00', '\\|') for c in s.split('|')]


def check(path):
    L = open(path, encoding='utf-8').read().split('\n')
    bad = []
    blocks = 0
    rows = 0
    i = 0
    while i < len(L):
        if L[i].startswith('|'):
            j = i
            while j < len(L) and L[j].startswith('|'):
                j += 1
            blocks += 1
            head = len(cells(L[i]))
            if j - i < 2 or not re.match(r'^\|\s*:?-{3,}', L[i + 1] if i + 1 < j else ''):
                bad.append((i + 1, 'sep', head, L[i][:70]))
            for k in range(i, j):
                rows += 1
                n = len(cells(L[k]))
                if n != head:
                    bad.append((k + 1, 'cells %d≠%d' % (n, head), head, L[k][:70]))
                if not L[k].rstrip().endswith('|'):
                    bad.append((k + 1, 'no-end-bar', head, L[k][:70]))
            i = j
        else:
            i += 1
    return blocks, rows, bad


def main():
    targets = []
    for a in sys.argv[1:]:
        if os.path.isdir(a):
            for root, _, files in os.walk(a):
                for f in sorted(files):
                    if f.endswith('.md'):
                        targets.append(os.path.join(root, f))
        else:
            targets.append(a)
    tot = 0
    for p in sorted(targets):
        b, r, bad = check(p)
        tot += len(bad)
        print('%-70s 표 %3d · 줄 %5d · 어긋난 줄 %d' % (p[-70:], b, r, len(bad)))
        for x in bad[:12]:
            print('     L%d %s :: %s' % (x[0], x[1], x[3]))
    print('합계 어긋난 줄', tot)
    return 0


if __name__ == '__main__':
    sys.exit(main())

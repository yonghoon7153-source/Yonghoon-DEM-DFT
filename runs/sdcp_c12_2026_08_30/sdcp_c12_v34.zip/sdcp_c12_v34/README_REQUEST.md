# VASP 계산 요청 — LiNiO₂(104) 위 분자 조각 단일점

바쁘신 중에 부탁드려 죄송합니다. **VASP 실행 16회**입니다
(static 16).
슬랩·분자 **전 잡이 단일점**입니다 — 구조 최적화는 저희가 MLIP 으로
끝냈고, 이 묶음에는 `relax/` 폴더가 하나도 없습니다 (기체 기준계 포함).

## 하실 일

⛔ **`run_staged.sh` 로만 실행해 주세요. 16잡을 한꺼번에 던지지 마십시오.**
1단계(10잡)가 진공 두께 수렴 시험을 통과해야 2단계를 돌립니다 — 통과 못 하면
2단계는 **돌리지 않는 것이 맞습니다**(추가 계산으로 메우지 않습니다).

```
cd <이 묶음을 푼 디렉터리>            # 묶음 **루트**에서 실행합니다 (잡 폴더 아님)
# ⛔⛔ 0단계 — **ZIP 을 풀기 전에**, ZIP 밖에서 SHA 를 대조하십시오 (회신 BA P0-1).
#    아래 값은 메일 본문에 있습니다. 이 대조는 번들 안의 어떤 스크립트도 쓰지 않습니다
#    — ZIP 안의 해시는 자기 자신을 증명하지 못하기 때문입니다.
#      sha256sum /경로/받은번들.zip     # ← 메일 본문의 값과 눈으로 대조
#    다르면 **풀지 마시고** 저희에게 알려 주십시오.
#
# ⚠ 러너는 배포 스크립트를 실행하기 **전에** 추출 파일 전수검사(census + files_sha256
#    + EXPECT)를 끝냅니다. v21 까지는 POTCAR 조립(SEAL)이 그 검사보다 **먼저** 돌아,
#    변조된 assembler 가 무결성 검사 전에 실행될 수 있었습니다 (회신 BA P0-1).
cd <이 묶음을 푼 디렉터리>              # 묶음 **루트**

# ── POTCAR 원본 트리와 allowlist (조립기가 쓴다) ──
export PP=/path/to/potpaw_PBE.54
# allowlist 는 그 트리의 변형별 POTCAR 해시 목록입니다. 없으면 이렇게 만드십시오:
#   for v in $(ls "$PP"); do sha256sum "$PP/$v/POTCAR"; done > /abs/site_allow.txt
#   (형식: `<sha256>  <PP>/<variant>/POTCAR` — sha256sum 기본 출력 그대로)
export POTCAR_ALLOWLIST=/abs/site_allow.txt

# ── 배포본 결박 (ZIP 밖의 값이 유일한 앵커입니다) ──
export BUNDLE_ZIP_SHA256=$(sha256sum /경로/받은번들.zip | cut -d" " -f1)
export EXPECT_MANIFEST_SHA256=<메일 본문의 MANIFEST SHA256>
export EXPECT_ZIP_SHA256=<메일 본문의 ZIP SHA256>

# ── 실행 방식 ──
# ⛔ 자유형 launcher 문자열(VASP_CMD·VASP_LAUNCHER)은 **폐지됐습니다** (회신 AV P0-2) —
#    문자열 검사는 우회가 가능해, 종류와 수만 받고 실행 명령은 러너가 조립합니다.
export VASP_LAUNCHER_KIND=mpirun            # mpirun|mpiexec|srun|none|wrapper
export LAUNCHER_BIN=/abs/path/to/mpirun     # **필수** — PATH 에서 찾지 않습니다. 없으면 exit 2
export VASP_NPROC=48                        # 랭크 수 (잡 하나당)
export VASP_EXE=/abs/path/to/vasp_std       # 실행파일 절대경로 (봉인 대상)

# ⚠ 러너는 기본으로 잡 8개를 **동시에** 띄웁니다 (= 8 × VASP_NPROC 랭크).
#    할당이 그보다 적으면:  export JOBS_PARALLEL=<할당코어 ÷ VASP_NPROC>

bash run_staged.sh 1     # census → POTCAR 조립+봉인 → 봉인 census → 1단계 → 판정
bash run_staged.sh 2     # 1단계 통과(STAGE1_PASS.json) 뒤에만
```

⚠ `BUNDLE_ZIP_SHA256` 이 없으면 봉인 스크립트가 **거부합니다** — 번들 안에는 자기
해시를 넣을 수 없어서, 받으신 파일에서 직접 구해 주셔야 결박이 성립합니다.
`EXPECT_MANIFEST_SHA256` 과 `EXPECT_ZIP_SHA256` 은 메일 본문에 적어 보내드립니다 —
**둘 다 필수**입니다. 없으면 러너가 시작하지 않습니다 (번들 안의 해시는 자기 자신을
증명하지 못하므로, ZIP 밖의 값이 유일한 앵커입니다).

**POTCAR 를 따로 조립하지 마십시오** — `run_staged.sh` 가 첫 VASP 실행 전에
`SEAL_POTCAR_ROOT.sh` 로 전 잡 조립 + 원본 fingerprint 봉인까지 합니다.

### 🙏 부탁 — 첫 잡 전에 한 줄만 더 (POTCAR 신원)

```bash
bash MAKE_POTCAR_ATTESTATION.sh     # ← 첫 VASP 실행 **전에만** 가능합니다
```

**막지는 않습니다. 없어도 러너는 돕니다.** 다만 이것 하나로 결과의 쓰임새가 달라져
말씀드립니다.

저희 봉인(`SEAL_POTCAR_ROOT.sh`)이 보증하는 것은 *"16잡이 전부 같은 하나의 트리에서
나왔고 그 트리가 첫 계산 전에 고정됐다"* 까지입니다. **그 트리가 승인된 PAW dataset
인지는 보증하지 못합니다** — VASP 는 같은 원소에도 여러 PAW 세트와 suffix variant
(`Li` vs `Li_sv`, release 5.2 vs 5.4 …)를 배포하고, 어느 것을 썼는지에 따라 에너지가
달라지므로 dataset 신원은 범함수 선택과 같은 급의 **계산 조건**입니다.
해시는 "바뀌지 않았다"만 말하고 "이것이 무엇이다"는 말해 주지 않습니다.

- **돌려 주시면**: dataset 신원 기록이 남습니다. (⚠ 그것만으로 원고 인용 자격이
  서지는 않습니다 — 아래 참조.)
- **안 돌리셔도**: 계산은 그대로 진행되고 결과도 유효합니다.

⛔ **이 묶음의 결과는 원고 인용용이 아닙니다.** MANIFEST 의
`potcar_identity_policy.manuscript_citable = false` 이고, 분석기가 그것을 결과 최상위
(`citation_status`)에서 기계로 집행합니다. attestation 을 **사후에** 받아도 원고용으로
승격되지 않습니다 — 그러려면 계산 **전에** 외부 앵커(사전 승인 해시 `--potcar_pin`
또는 서명)가 있어야 합니다 (회신 BA P0-3·Q5).
따라서 "조건부로 원고 인용" 이라는 표현은 이 묶음에 **쓰지 않습니다**.

시간은 몇 초입니다. 첫 VASP 실행 뒤에는 만들 수 없습니다(생산 전이라는 사실 자체가
근거이기 때문입니다 — 회신 AR P0-6).
`run_all.sh` 는 이 묶음에 **넣지 않았습니다** (전체 제출 경로가 있으면 1단계
정지 규칙이 무력화됩니다).

⛔ **단일 잡을 손으로 돌리는 경로는 이 묶음에서 삭제했습니다** (회신 AT P0-5).
`run_job.sh` 를 직접 부르면 봉인된 실행파일 검사와 번들 전역 lock 을 **둘 다 우회**해,
봉인이 무의미해지고 같은 번들에 두 실행이 들어올 수 있습니다.
⛔ **`ALLOW_RESUME` 은 폐지됐습니다** (회신 BA 해제조건 7). 러너는 그 변수를 보면
**거부합니다** — 이 문서가 그것을 지시하고 있었던 것은 잘못이고, 그대로 따르면
실행이 막혀 이유를 알 수 없었습니다 (회신 BB P1 지적).

한 잡을 다시 돌리셔야 하면 **폴더를 새로 풀고 처음부터** 돌리십시오. 부분 재개는
남이 다른 설정으로 돌려 둔 결과를 우리 것으로 반송하는 사고를 막지 못합니다
(회신 AA P0-5). 실패 잡이 남아 다시 돌려야 하는 경우는 저희에게 알려 주시면
**그 잡만 담은 별도 rescue 묶음**을 만들어 보내 드립니다 — 그 묶음은 부모 번들을
`parent`/`supersedes` 로 명시해 계보가 끊기지 않습니다 (회신 BB Q3).

```
mkdir -p <이 묶음 전용 빈 디렉터리> && cd <그 디렉터리>
unzip <이 묶음>.zip
```
⛔ 이 묶음은 `run_staged.sh` **하나로만** 돌립니다. 위 블록의
명령을 그대로 쓰십시오. `run_job.sh` 를 직접 부르지 마세요 — 봉인된 실행파일 검사와
번들 전역 lock 을 우회합니다 (회신 AT P0-5).


⚠ **묶음이 둘 이상이면 반드시 서로 다른 빈 디렉터리에 풀고 따로 반송해 주세요.**
같은 자리에 겹쳐 풀면 어느 결과가 어느 묶음 것인지 저희가 되살릴 수 없습니다.

### POTCAR 신원 — 별도로 보내주실 것은 없습니다

`POTCAR_ASSEMBLE.sh` 가 조립하면서 **`POTCAR_PROVENANCE.json`** 을 만듭니다.
그 안에 변형별 원본 SHA256 · TITEL 줄 · 조립본 SHA256 이 들어갑니다.
`run_job.sh` 는 그 파일이 없으면 **실행을 거부**하므로 (POTCAR 를 손으로 놓으면 멈춥니다),
반송물에 자동으로 포함됩니다. 저희가 그 값으로 대조합니다.

- **따로 메일로 해시를 보내실 필요 없습니다.**
- ⚠ 이 묶음은 **이전 wave 와의 PP 동등성을 주장하지 않습니다** — 어느 트리를
  쓰셨는지는 봉인이 기록하고, 저희는 "이 묶음 안에서 하나의 트리였는가" 만
  확인합니다 (회신 AO P1 · AR P1-11).
- POTCAR 파일 자체는 주고받지 않습니다 — 해시와 TITEL 줄만 기록됩니다.

잡 폴더 16개가 `prospective` · `refs` · `vacconv` 에 있습니다.
⛔ **서로 독립이 아닙니다.** canary(`*__nzmag`)는 부모 기체 기준의 최종
기하를 받으므로 부모가 **먼저** 끝나야 하고, 2단계는 1단계 게이트를
통과해야 열립니다. 순서는 `run_staged.sh` 가 강제합니다 — 전부 동시에
던지지 마십시오.

## 잡 census (산출물에서 센 값)

| | 끝점 | D3-off 쌍둥이 | 계 |
|---|---:|---:|---:|
| references | 6 | 0 | **6** |
| calibration complexes | 8 | 0 | **8** |
| | | | **16** |

audit pose **0개**. pose 당: pm1/D3-on · net4/D3-on — **D3-off 쌍둥이를 만들지 않는다** (C3 는 D3-on OUTCAR 의 Edisp 로 낸다)


## 실행 단계와 결과 범위 (읽어 주세요)

이 요청은 **이것으로 끝나는 계산**입니다 — 뒤에 이어지는 단계가 없습니다.
조각당 primary 1자세 + 대안 1자세를 자기 시드 2종으로 잽니다. primary 는 셀 두 높이에서 한 번 더 잽니다(진공 두께 수렴 시험, 2잡). 보고하는 것은 **두 조각의 흡착에너지 차 하나**이고,
개별 절대값은 보고하지 않습니다(깨끗한 슬랩을 계산하지 않으므로 대비에서 소거됩니다).

대안 자세는 최저값 후보가 **아닙니다** — "다른 접촉 방식에서도 방향이 유지되는가" 만
봅니다. 최저·평균·순위에 섞지 않습니다.

각 calibration pose 는 `pm1/D3-on` · `net4/D3-on` **두 계산**입니다.
**D3-off 쌍둥이는 만들지 않습니다** — 고정기하 static(NSW=0)에서 D3(zero)는
SCF 밖의 additive 항이라 `E_on − E_off` 가 항등적으로 OUTCAR 의 `Edisp` 와
같습니다. 그래서 그 항을 D3-on 결과에서 직접 읽습니다.
같은 POSCAR 가 자기 seed 둘로 두 번 보이는 것은 **정상이고 설계**입니다.
중복으로 보고 하나만 돌리시면 그 짝이 통째로 무의미해집니다.

`pm1` 과 `net4` 는 **초기 MAGMOM seed 이름**입니다. 최종 자기상태가 아닙니다.
저희 분석기가 최종 Ni 국소모멘트 부호벡터 · moment collapse · 유기종 상대스핀으로
realized magnetic basin 을 판정하고, **같은 realized basin 으로 매칭되지 않은**
에너지끼리는 빼지 않습니다. 그래서 `LORBIT` 를 켜 두었습니다 — OUTCAR 의
국소모멘트 표가 판정 근거입니다.

⚠ 이 묶음에는 **깨끗한 슬랩(clean slab) 잡이 없습니다.** 보고하는 양이 두 조각의
**차**라 공통 슬랩 항이 소거되기 때문입니다 — `refs/clean_slab__*` 을 찾지 마십시오.
자기 basin 판정은 두 complex 의 Ni 국소모멘트 배열을 **서로** 비교해서 합니다
(그래서 `LORBIT` 를 켜 두었습니다).


모든 결과는 MLIP 이 고른 **고정기하에서의 PBE+U+D3 단일점 전자에너지**입니다.
DFT-relaxed adsorption energy · 평형 결합에너지 · 자유에너지로 표현하지 않습니다.

## 미리 아셔야 할 것

- **전 잡이 단일점입니다.** `relax/` 폴더가 아예 없습니다. 확인하실 수 있습니다:
  `find . -maxdepth 3 -type d -name relax | wc -l` → **0**
  잡 수는 `find . -name run_job.sh | wc -l` 이 정답입니다.
- **가장 긴 잡이 약 111 시간**입니다 (48코어 기준 추정, ±2배).
  walltime 상한이 이보다 짧으면 그 잡만 알려 주세요 — 나눠서 다시 만들어 드립니다.
- **POTCAR 는 잡마다 종 순서가 다릅니다.** `POTCAR_ASSEMBLE.sh` 가 그 잡에 맞게
  조립하고 순서·variant·PAW_PBE 까지 확인합니다. 하나를 만들어 전체에 복사하시면
  **에러 없이 다른 계를 계산합니다.**

## 보내 주실 것

**정본은 `MANIFEST.json` 의 `return_contract`** 이며 이 목록은 그 렌더입니다
(README 와 SUBMIT_CONTRACT 어디를 보셔도 같습니다 — 회신 AV P0-4).

각 잡 폴더에서:
- static/OUTCAR (또는 .gz)
- static/OSZICAR
- static/POSCAR — **실행된 기하** (부모↔canary 기하 대조·기하 감사. 없으면 CANARY_GEOM_UNCHECKED 로 막힙니다)
- POTCAR_PROVENANCE.json (조립기가 자동 생성)
- EXECUTABLE_RECEIPT.tsv — 상별 실행파일 해시 (run_staged 경로가 자동 생성 · 분석기가 root seal 과 대조합니다)

묶음 루트에서:
- POTCAR_ROOT_SEAL.json (첫 실행 전 봉인)
- ZIP_SHA256.txt
- STAGE1_PASS.json (1단계 통과 receipt)
- POTCAR_ATTESTATION.json — **선택** (탐색용 정책). 없어도 러너는 돕니다. ⚠ 다만 그 결과는 **원고 인용 자격이 없습니다** — 사후 provenance 는 무엇을 썼는지만 기록하고 그것이 승인된 PAW dataset 인지 판정하지 못합니다 (회신 AZ P0-7·Q4). 만들려면 `MAKE_POTCAR_ATTESTATION.sh` 를 **첫 VASP 실행 전에만** 돌릴 수 있습니다 (회신 AR P0-6)

보내지 않으셔도 되는 것: CHGCAR·WAVECAR (용량) · vasprun.xml (선택)
⚠ 발산·미수렴 잡도 지우지 말고 그대로 — 실패가 판정의 일부다

## 부탁 — 입력을 고치지 말아 주세요

`INCAR` · `KPOINTS` · `POSCAR` 를 **한 글자도 고치지 말아 주세요.**
분석기가 `MANIFEST.json` 의 sha256 으로 대조하며, **예외 태그 목록을 두지 않았습니다.**
`NCORE` 를 포함해 무엇이든 한 줄이 바뀌면 그 잡은 거부됩니다
(`NCORE` 는 4 로 넣어 두었습니다).

- 병렬 조정이 꼭 필요하시면 **알려 주세요** — 저희가 다시 만들어 드리는 게 빠릅니다.
- **SCF 가 안 붙는 잡은 그대로 두고 알려만 주세요.** 설정을 바꿔 다시 돌리신 값은
  저희 검증을 통과하지 못해 버려집니다.
- 그래도 직접 재시도해 보셔야 한다면, **원본을 덮지 마시고**
  `<잡폴더>/_retry_1/` 처럼 별도 디렉터리에 남겨 주세요. 원본 실패 상태와 재시도를
  둘 다 받아야 저희가 원인을 압니다.
  ⚠ 이 `_retry_1` 은 **진단 자료**이지 반송물이 아닙니다 — 저희 검증은 그 값을
    쓰지 않습니다. 다시 돌려야 하는 잡은 저희가 **별도 rescue 묶음**으로 만들어
    보내 드립니다 (부모 번들·잡·입력 SHA 와 attempt ID 가 박히고, 원본은 그대로
    보존되며 자동 대체는 하지 않습니다 — 회신 BC P1).

## 확인용

```
python3 analyze_results.py .       # 판정 실패 exit 2 · 완주했으나 원고 인용 불가(탐색용) exit 3
```

---
계산 조건·근거·범위는 `MANIFEST.json` 에, 제출 관련 수치는 `SUBMIT_CONTRACT.md` 에
적어 두었습니다. 궁금한 점 있으시면 편하게 물어봐 주세요.

<details><summary>프로토콜 요약 (참고)</summary>

PBE+U(Ni d 6.2 Dudarev) · D3 zero damping(IVDW=11) · ENCUT 520 · ISMEAR 0/0.05 ·
ISYM=0 · LASPH · ADDGRID · LDIPOL/IDIPOL=3 · static k 3 4 1 · dense k 4 6 1 ·
고정 평면 z ≤ 17.396 Å · 자기 seed 2종(각 끝점마다 둘 다 필요합니다) ·
Ni 는 **Ni_pv**. ⚠ 이전 wave 와의 PP 동등성은 **주장하지 않습니다**, 배포판(release)도
여기서 단정하지 않습니다 — variant 는 `POTCAR_SPEC.txt` 그대로 쓰시고, 원본
fingerprint 는 첫 실행 전에 `SEAL_POTCAR_ROOT.sh` 가 봉인합니다 (회신 AO P1 · AR P1-11).
dense 는 k 검증용이라 0개 잡에만 있습니다: (없음).
</details>

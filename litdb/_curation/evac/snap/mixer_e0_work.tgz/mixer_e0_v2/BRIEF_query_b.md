# 지시서 — 믹서 E0 봉인 전 보충 조회 블록 (q2b · q7b · q9b) 만들기 · 컨테이너 시험 먼저 (11-12 밤 · 실행 = 아침 1저자 ibb)

## 0. 할 일

등록 초안 `…/scratchpad/mixer_e0_v2/e0_pilot_registration_draft.md` 13-1 절 (q2b · q7b · q9b · 2 회차 고침 판 · 1저자 11-12 밤 오버나잇 = Q-F′ · Q-G′ · Q-K 권고대로 = 셋 다 함) 을, 지난 조회 블록 `…/mixer_e0_v2/query_block/` (query_block.txt · src/build_block.sh · src/query_script.sh · read_query_bundle.py · test/) 과 **같은 꼴**로 새 블록 `…/mixer_e0_v2/query_block_b/` 에 만든다.

1. **시험 먼저**: `query_block_b/test/` 에 가짜 ibb 세계 (지난 `test/mkworld.py` · `fakes/` 꼴) 로 세 조회의 기대 출력과 실패 꼴 (파일 없음 · 권한 없음 · 시간 초과 · 가림 실패 · 줄 수 넘침) 을 먼저 쓰고, 블록 없이 실패하는 것을 기록.
2. 블록: 읽기 전용 (ibb 에서 쓰는 곳 = 새 빈 폴더 하나 · 결과 묶음 tgz + sha256) · 숫자 값 · 본문을 옮기지 않는 조회는 13-1 정의 그대로 (q9b = 첫 낱말 · 표 번호 · 앞 숫자 행 수 · 앞 공백 수만 · q2b = 끝 개행 · 개행 수 · TIMESTEP 줄 꼴 · q7b = conda 꾸러미 파일 목록 해시) · 가림 (홈 · 계정 · 노드 이름 · 주소) = 지난 블록 규칙 + 노드 이름 (sinfo 자리표) · 실패 처리 · 시간 상한 · 출력 크기 상한.
3. 판독기: `read_query_bundle.py` 를 넓히거나 `read_query_bundle_b.py` — 묶음 sha256 대조 · 가림 검사 · 요약 JSON.
4. 컨테이너 시험 전부 통과 · 블록 텍스트 sha256 · 1저자가 붙여 넣을 명령 (한 덩어리 · 주소 · 포트 · 계정은 자리표 `<IBB>` 로).

## 1. 규칙

- 리포 `/home/user/Yonghoon-DEM-DFT` 는 읽기만 (git 상태 변경 금지). GIT_DIR · GIT_WORK_TREE · GIT_INDEX_FILE export 금지.
- ibb 나 다른 원격 기계에 접속하지 않는다 (블록은 아침에 1저자가 돌린다). 시스템 패키지 설치 · 시스템 설정 변경 금지 (gawk 등 설치 금지 · 필요하면 PATH 앞자리 가짜만). 신호 실험은 `unshare -pf --mount-proc --kill-child` 안에서만.
- 주소 · 포트 · 계정 · 홈 경로 · 노드 이름 값을 파일에 쓰지 않는다. Artifact 도구 · 웹 게시 금지. 디스크가 빠듯하다 — 큰 가짜 세계는 시험 뒤 지운다.

## 2. 답장

8 줄 안팎: 시험 수 (고치기 전 → 뒤) · 블록 sha256 · 조회 셋의 출력 꼴 · 가림 규칙 · 산출 파일 전체 경로.

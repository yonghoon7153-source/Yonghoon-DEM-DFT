# PRE8-01·02 보완 한정 재확인

리뷰 핀 `ec484c2719d6a444214ddc9c48fe683a7735688b`, 가지 `codex/mixer-1104`입니다. PIN.txt가 새 대상이며 PREVIOUSLY_REVIEWED_PIN.txt는 이전 `189930cc68b6e58beb6b4546d80353dc03852195`입니다. 이전 첫8 정적 준비의 범위 수용을 관측 연결 전체 수용과 구분해 주세요.

REQUEST.md에 따라 두 P2만 재확인해 주세요.

- PRE8-01: run/E0의 n_expected 부재를 봉인하고 판독 중 파일/dangling symlink 출현 또는 기존 파일 변경 시 TECH·값 제거인가? 생성 시점을 _load 뒤와 계산 중으로 나눠 확인합니다.
- PRE8-02: 해시한8의존 소스 bytes를 실제 compile/exec하는 private 모듈 집합, 자기 observer code 동등성 검사, 내부/lazy import와 생성기 자기 소스 읽기가 결속되는가? 오래된 sys.modules/동일 mtime-size pyc가 우회하지 않는가? import 후 sentinel 변경/새 프로세스 대조와 bootstrap 오류를 확인해 주세요. 기록 SHA는 실제 고정본이어야 합니다.

직접 회귀는 `python scripts/test_mixer_precal_observe.py`입니다(numpy/scipy 필요). 작성 측 Python3.8.20/3.11.17에서 각28 메서드 통과. 원 외부 반례 전후, 기대 판정만 바꾼 외부 탐침9관측, 별도 내부3그룹과 모의 없는8조건 음성 입력 경계는 새 수령 폴더 evidence에 분리했습니다. 준비14개는 이전 외부 수용 기록이며 이번에 반복 실행했다고 세지 않습니다. fixture의 prepare binding mock/일부 cell_stats mock과 실제100000입자 양성 경로 미검증을 유지합니다.

부가 문서 확인: 첫8 준비 README §4의 Claude 정정은 write_restart도 원 런 덤프와 비트 동일성을 보장하지 않음, 같은 방식 재계산끼리 비교 정의 선행, force_normal의 전체 쌍 힘 사영이라는 전달 범위입니다. P1 자체 검토·실행은 요청하지 않습니다.

새 문제가 있으면 ID·최소 반례·대상 핀을 남기고, 없으면 두 결속 보완 범위만 판정해 주세요. 작성 측은 종결하지 않습니다. 전체 HOLD·실제 연구/ibb/WSL 실행·활성 등록·실험·배포·통합·원장 종결 미승인입니다. D0.7 종료 후·1저자 승인 후 조건과 MXD2R 별도 재확인 대기는 유지합니다. 발송은1저자, Rint② 우선입니다.

import faulthandler, os, runpy, signal, sys
f = open(sys.argv[1], 'w')
faulthandler.register(signal.SIGUSR1, file=f, all_threads=True)
script = os.path.abspath(sys.argv[2])
sys.argv = sys.argv[2:]
sys.path.insert(0, os.path.dirname(script))
runpy.run_path(script, run_name='__main__')

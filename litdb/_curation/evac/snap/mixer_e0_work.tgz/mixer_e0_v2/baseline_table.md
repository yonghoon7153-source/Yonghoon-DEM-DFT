# 믹서 E0 자격 pilot 한 팔 — 기준 고정 표 (초안 · 2026-11-12)

**지위: 초안 · 문서만 · 실행 0 · 제출 0 · 결과 0 건 · 자격 판정 아님 · 전체 HOLD 그대로.**
받은 메타 (관측) 와 리포 기록을 "발사 때 대조할 기준" 으로 적어 둔 표다. 값이 맞는다고 실행 승인이 되지 않는다.
11-11 본 세션 초안 (`from_main/draft/baseline_table.md`) 을 이어 썼다. 옛 칸은 리포와 한 칸씩 대조해 맞는 것은 그대로 두었다. 바뀐 곳 = 같은 폴더 `changes.md`.

## 읽는 법

- 원천 = `docs/data/mixer_e0_meta_ibb_20261110/out/` (가린 사본 132 파일). "근거" 칸의 파일 이름은 그 폴더 안이고 `L` 뒤 숫자는 그 파일의 줄 번호다.
- 리포 경로 줄임: `F8` = `docs/reviews/mixer_first8_launch_preparation_20261106` · `P8` = `docs/reviews/mixer_precal_first8_preparation_20261104` · `IN` = `docs/reviews/mixer_inactive_preparation_20261109`. out/ 밖 근거에는 "리포" 라고 적었다.
- 리포 HEAD = `21bb09d82` (2026-11-12). 본 세션 sha256 대조는 이 HEAD 의 파일로 했다.
- 수집 창 = 2026-11-10T14:49:56Z ~ 14:53:02Z · 186 초 (`fields.txt` L5 · L577 · L578). **out/ 의 값은 그 3 분의 관측이다.**
- **경로 문자열은 적지 않는다** (지시서 2 · 3 절). 바이너리 · MPI · conda 환경 · 런 폴더는 판 · git · sha256 · 크기 · 이름만 적고, 가린 경로는 out/ 줄 번호로만 가리킨다. 주소 · 호스트 이름 · 노드 이름 · 계정 이름 · 포트는 이 문서에 없다.
- "다시 확인" = 발사 직전에 다시 재는가. 발사 직전 = 제출 전 5 분 안 + job 시작 때 (리포 `F8/inventory.md` L43–48 preflight 1–6 · `F8/submit_one.py.txt` L125–126 의 300 초).
- out/ 에 없는 값은 **[미확인]** 이다 (계획 문서 말로는 UNKNOWN / PROBE_NEEDED). 지어 채우지 않았다.
- [산술] = 인용한 숫자로 계산한 값. [추정] = 가정이 든 값. [관찰] = 코드 · 다른 런 기록으로 본 것 (이 pilot 으로 확인 전).

## 0-A. 기준 고정 요약 (지시서 2 절의 칸)

| 칸 | 기준 값 | 근거 | 상태 | 비었거나 미정이면 채우는 법 |
|---|---|---|---|---|
| 바이너리 | LIGGGHTS-PUBLIC 3.8.0 · 빌드 2026-03-26-14:37:06 · git 3d5c00f20519e6bb6eb6756f51f1ad36564e649d · sha256 ee2d77261bac9e7fa4e9311c8709e74bf7583a13225a5bc35a791bef9be60a3f · 9180024 B · 09-28 영수증 바이너리와 같음 | `lmp1_help.txt` L1 · `fields.txt` L485–487 · 리포 `docs/data/mixer_phase_receipt_20260928/receipt_v2_ibb.json` L1474 | 관측 · Q4 확정 (1저자 11-10 · 리포 `docs/data/mixer_e0_meta_ibb_20261110/README.md` L15 · L30) | 준비 · staging · job 시작에 sha256 다시 (preflight 2–3) |
| 링크 라이브러리 | 30 행 중 해시 1 (libgcc_s.so.1 0907d66b5a5f028480cf78adad58180e1c1183a3a085877e8f4fd471af60d50c) · 29 행 = 심볼릭 링크 | `hashes.txt` L475–504 (L478) | [미확인] | 등록 초안 13 절 q7 |
| MPI | Open MPI 5.0.10 · mpirun sha256 407990f94f9d3863be273b44e6e8fc96b9a015a3b14763ae0aab60857d1ee72d · 190592 B · 사용자 conda 환경 안 · 호출 꼴 `--oversubscribe --bind-to none -np 20` | `mpi1_version.txt` L24 · `fields.txt` L520–521 · 리포 `F8/job_start.py.txt` L44 | 파일 신원 관측 · 런타임 (rank · 배치 · TMPDIR) [미확인] | pilot job 시작 영수증 (pilot 자신의 몫) |
| STL 셋 | Drum fe821a8ab6db0d94151e9d84bf19cc1fad77abb417cd640bf4577c2f87279730 (14310 B) · Front 443f9c3c859b2562dc041cde2af712fdfc4ab0225032ebb9420267c781843c81 (5990 B) · Back 2e7b962d14ced968d8178456feaf2f6a4856edd4b151070c23a8ac1588a461e5 (10790 B) | 리포 `F8/planned_assets/SHA256SUMS` L38–40 · `hashes.txt` L6–8 (ibb 체크아웃) · L462 · L470 · L464 (DEV E0 런) · 본 세션 sha256 (HEAD 의 `dem_scripts/mixer_20260919/*.stl` 셋 같음) | 바이트 확정 · 기하 자격 아님 (`F8/inventory.md` L26) | staging · job 시작 대조 |
| 케이스 덱 (E0) | `in.mixer` 11347 B · sha256 8b588b24117ab77bf72d93662237268b401f714df8515d62ef7b964d01c6e718 (계획 자산 = 비활성 후보 사본 · 바이트 같음) | 본 세션 sha256 (`F8/planned_assets/PRECAL_E0/in.mixer` · `IN/candidate/candidate_assets/PRECAL_E0/in.mixer`) · `F8/planned_assets/SHA256SUMS` L36 · `F8/blockers.json` L72 | 확정 | — |
| 메타 (E0) | 후보 둘: 원 계획 c6543f3800d0d76d0d75ca04f4aebc5d9dd557de0702d94c0355910121efe218 (생성기 해시 661936b7…) / 비활성 후보 498b941c898ea963ae50d931dc1fb71e164f6b5082436f661d1a474ea8ae80d3 (생성기 해시 dc253bc8…) · 다른 곳 = `generator_sha256` 한 칸 | `F8/planned_assets/SHA256SUMS` L37 · `IN/candidate/candidate_asset_manifest.json` L36 · `IN/README.md` L25 · 본 세션 sha256 | **미정** (등록 초안 18 절 Q7) | 1저자 Q7 |
| 소스 핀 | 운영 봉인 = 527e244e4ebd6f0cb04c6cfb2ff5f3a52fb01996 (원 자산 생성 핀 · `F8/source_seal.json` L2) / 비활성 사본 검증 · 메타 생성 핀 = e48e5fa0498ab7ee8fd84163d9af024d07cbb135 (`IN/candidate/inactive_candidate.json`) · HEAD `21bb09d82` 의 12 의존 sha256 = 비활성 사본 12/12 · 원 봉인과는 2 개 다름 (`make_mixer_deck.py` · `mixer_deck_readback.py`) | 본 세션 sha256 · `IN/README.md` L11–17 | **미정** (Q7 · 운영 봉인 교체 = 1저자 별도 승인) | 1저자 Q7 |
| 관측기 | `scripts/mixer_precal_observe.py` df22dcf03fcd628901ffb6ac7362579faee6e94285404a3163bed44d3666f013 (두 핀 · HEAD 같음) · 같은 빌드 실제 로그 꼴과 네 가지 어긋남 [관찰] · E0 에서 t0 프레임 한 장만 본다 [관찰 — 코드 판독] | `F8/source_seal.json` L11 · 등록 초안 7-4 · 리포 `scripts/mixer_precal_observe.py` L297–302 | 고침 필요 (Q5) | 시험 먼저 → 고침 → 재봉인 |
| 가드 · job 시작 · 러너 | submit_one.py.txt sha256 d1232bff3576016e0235d0764dfdb029e582da400a2b4abbe53bf571039e16a8 · job_start.py.txt 5e140635336be247ee3a776be58b2b3eb8679562c02bfc9cb593e27c24276b91 (= 가드의 `REVIEWED_JOB_START_SHA256`) · run_one.sbatch.txt 5360aa212f2bba98c49bebf8ab5288a1d3069ba087f595b521f2b274972a8f15 (Python 경로 UNRESOLVED) | 본 세션 sha256 · `F8/submit_one.py.txt` L15 · `F8/run_one.sbatch.txt` L14 | 비활성 초안 · 가짜 sbatch · 모의 프로세스로만 시험 (`F8/README.md` L30 · L34) | 봉인 단계 |
| NP | 20 | 리포 `IN/author_policy_record.json` L13 | 확정 (1저자 11-09) | — |
| 동시 실행 수 | 1 팔 (E0 pilot) · 가드 규칙 = first8 돌고 있는 팔 < `max_concurrency` · 내 잡 CPU 합 + 20 ≤ 60 | `IN/author_policy_record.json` L14 · `F8/submit_one.py.txt` L83–84 · L132–134 | 정책 확정 · 지금 내 잡 수는 아래 4 절 (11-12 부터 G2c′ 잡) | 제출 전 5 분 안 `squeue` |
| walltime | `1-00:00:00` [초안] | 등록 초안 4-4 | 1저자 Q1 | — |
| 디스크 | post + restart 파일 크기 합 상한 29,266,573,952 B · 여유 바닥 32,193,231,348 B · inode 바닥 1,261 [초안] | 등록 초안 5-3 · 5-4 | 1저자 Q2 · 봉인 전 q1–q3 로 한 번 확인 | — |
| 런 폴더 규칙 | 발사 때 새로 만든다 (dev7 · dev7_v26 안 씀) · 제안 이름 `mixer_precal_first8_20261106` · 아래 `campaign_policy.json` · `cases/PRECAL_E0/` · `admission/` · 경로 꼴 = 풀린 꼴 [초안] | 리포 `docs/data/mixer_e0_meta_ibb_20261110/README.md` L16 · `F8/commands.txt` L68–71 · 등록 초안 3 절 | 새로 만들기 = 1저자 11-10 Q5 · 경로 꼴 = Q4 | — |
| 감시 주기 | 읽기 전용 watch 기록 10 분 · 사람 판단 = 첫 프레임 · +1 h · 그 뒤 1 h 마다 · 끝 [초안] | 등록 초안 9 절 | 1저자 Q3 | — |
| SLURM | partition cpu · QOS cpu-60 (사용자당 cpu 60) · association MaxWall 7-00:00:00 · 파티션 14-00:00:00 | 4 절 | 관측 (11-10) | 발사 직전 |
| D0.7 (가드의 `d07_finished` 칸) | 완주 — ibb job 338349 · 끝 step 2,135,002 (`Simulation Finished`) · 11-05 수령 | 리포 `docs/session_20260923_progress.md` L1322 · `docs/data/kg50_d07_end_20261105/README.md` | 기록 있음 | live_preflight 에 참으로 · 근거 참조를 붙인다 |
| 덤프 형식 줄 (`dump_modify … format` 한 줄 꼴) | 같은 바이너리에서 6 열 `%.17g` 꼴 실측 통과 (10-06 정확 좌표 런) · pilot 의 12 열 꼴은 미실측 | 리포 `docs/data/mixer_highbo_devu_prelim_20261006/README.md` L80 · `…/exact_runs/exact_LU212_settled/exact_receipt.json` L77 · 덱 `F8/planned_assets/PRECAL_E0/in.mixer` L138 | 부분 | pilot 자신의 몫 |
| Python (ibb) | 3.10.20 (사용자 conda · numpy 2.2.6) · 3.9.13 (시스템 · numpy 1.21.5) · 가드 · job 시작은 표준 라이브러리만 쓴다 · 관측기는 회수 뒤 로컬에서 돈다 | 3 절 · 리포 `F8/commands.txt` L53–58 | 어느 쪽 = 미정 | 봉인 단계 (러너에 절대 경로로) |

## 0-B. 영수증 칸 (R0–R6) 과 이 표의 자리

영수증 칸의 정의 = 리포 `docs/reviews/nonrint_approved_preparation_20261109/mixer_ibb_qualification_receipt_plan.md` L53–59.

| 칸 | 이 표의 절 | 지금 상태 |
|---|---|---|
| R0 대상 · 범위 | 1 | 수집 메타 있음. 설치 실체 인증 · 운영자 · 승인 참조는 out/ 밖 (1저자) |
| R1 링크 · 경로 | 6 | 조상 경로의 종류 · 모드 관측 있음. 링크 거부 자격 시험은 안 했다 |
| R2 권한 · 변경 통제 | 2 · 6 | 모드 · 소유 · ACL 수 관측 있음. 변경 통제 (불변 창) 는 out/ 에 없다 [미확인] |
| R3 binary / MPI | 2 · 3 | sha256 · 판 · ldd 관측 있음. 라이브러리 해시 · job 안 런타임 = [미확인] |
| R4 SLURM · 자원 | 4 | QOS · association · 파티션 · 내 잡 수 관측 있음 (시점 값 · 11-12 부터 같은 QOS 의 G2c′ 잡) |
| R5 시간 · 저장 · 회수 | 5 | df · inode · 사용량 관측 있음. 기본 한도 값 · 런별 크기 = [미확인]. walltime · 문턱은 등록 초안 |
| R6 최종 결속 | 7 | first8 묶음이 ibb 에 아직 없다 → 전부 [미확인] (봉인 단계의 몫) |

## 1. 수집 · 대상 (R0)

| 칸 | 값 | 근거 | 다시 확인 |
|---|---|---|---|
| 대상 별칭 | ibb | `fields.txt` L3 | 예 — preflight 1 (날짜 · 호스트 · 운영자). 원문은 ibb 의 raw/ 에만 둔다 |
| 수집 스크립트 | md5 4e01c25f8f3a1cebc9daee51e2999cc4 · sha256 4d9e11f4ea216e71d506e9225160e92e5bd89bd52461c929ce72e8f4691a0553 | `fields.txt` L13 · L14 | 아니오 — 수집 도구의 신원일 뿐이다 |
| OS | Rocky Linux 8.7 · 커널 4.18.0-553.40.1.el8_10.x86_64 · glibc 2.28 · bash 4.4.20 | `os_release.txt` L7 · `os_uname.txt` L1 · `os_glibc.txt` L1 · `fields.txt` L7 | 아니오 — 발사 판정에 쓰지 않는 기록 칸 |
| SLURM 할당 안에서 수집했나 | 아니오 (로그인 셸) | `fields.txt` L47 | 예 — job 안 환경 (PATH · 라이브러리 · TMPDIR) 은 잰 적이 없다 |
| 조회 결과 | OK 127 · FAIL 13 | `fields.txt` L579 | 해당 없음 |
| FAIL 13 의 내용 | 가지 이름 10 (체크아웃 10 곳) · 정적 배너 1 · `lmp_mpi -h` 종료 코드 1 · `quota -s` 1 | `probes.txt` L9 (repo1 · 나머지 9 곳 같은 꼴) · L95 · L97 · L115 | 해당 없음 |
| 가림 뒤 남은 토큰 | 0 | `fields_post.txt` | 해당 없음 |

## 2. 바이너리 (R3)

| 칸 | 값 | 근거 | 다시 확인 |
|---|---|---|---|
| 자리 | 로그인 경로 → 실제 경로가 Lustre 위로 풀린다 (가린 꼴 = 근거 줄) | `fields.txt` L483–484 | 예 — job 시작 때 실제 경로를 다시 푼다 (preflight 2) |
| 후보 | 후보 123 개 중 실제 파일 1 개. conda 환경 쪽 `lmp_mpi` 후보는 없음 (UNRESOLVED) | `fields.txt` L481 · L482 · L378 | 아니오 |
| sha256 | ee2d77261bac9e7fa4e9311c8709e74bf7583a13225a5bc35a791bef9be60a3f | `fields.txt` L486 · `hashes.txt` L474 | 예 — 준비 · staging · job 시작 세 번 (preflight 2–3). 파일이 그룹 쓰기 가능이라 바뀔 수 있다 |
| 09-28 영수증 바이너리와 같은가 | 같음 (`same`) → Q4 = 이 바이너리 | `fields.txt` L487 (대조 값 = `meta_script.sh` L11 · 리포 `docs/data/mixer_phase_receipt_20260928/receipt_v2_ibb.json` L1474) | 예 — sha256 대조 한 번으로 같이 본다 |
| 크기 · 수정 시각 | 9180024 B · mtime 1774503499 (= 2026-03-26T05:38:19Z [산술]) | `fields.txt` L485 · `hashes.txt` L474 | 예 (sha256 과 같이) |
| 판 · 빌드 · git | LIGGGHTS-PUBLIC 3.8.0 · compiled 2026-03-26-14:37:06 by `<BUILD_USER>` · git 3d5c00f20519e6bb6eb6756f51f1ad36564e649d | `lmp1_help.txt` L1 | 아니오 — sha256 이 같으면 같은 바이트다. job 로그 첫 줄 배너는 기록한다 |
| 배너를 얻은 방법 | `lmp_mpi -h` 실행 (종료 코드 1 · 출력 9033 B). 파일에서 찾는 정적 배너는 실패 (0 B) | `probes.txt` L97 · L95 | 해당 없음 |
| 파일 종류 | ELF 64-bit · x86-64 · 동적 링크 · not stripped | `lmp1_file.txt` L1 | 아니오 |
| 권한 | 일반 파일 · 모드 775 · 소유 = 나 · 그룹 = 나 · 그룹 쓰기 가능 · 이름 붙은 ACL 0 · 홈 디렉터리는 700 | `fields.txt` L485 · `walk.txt` L75 · `fields.txt` L549–550 · `walk.txt` L72 | 예 — 변경 통제는 정해진 것이 없다 (R2 · [미확인]) |
| 덱이 쓰는 스타일 | 있음: pair gran 의 hertz · history · sjkr · cdt / fix mesh/surface · wall/gran · particletemplate/sphere · particledistribution/discrete · insert/pack · nve/sphere · move/mesh · property/global · gravity / compute erotate/sphere / dump custom | `lmp1_help.txt` L36 · L41 · L45 · L49 · L64–78 · L85 · L100 | 아니오 — 기능 목록일 뿐이다. 물리 · 로그 호환 자격이 아니다 |
| 링크 라이브러리 (ldd) | 31 줄 = 사용자 conda 환경 23 · 시스템 7 · vdso 1. MPI = `libmpi.so.40` (conda 환경) | `lmp1_ldd.txt` L1–31 (L3) | 예 — 로그인 셸 값이다. job 안에서 다시 |
| 링크 라이브러리 sha256 | **[미확인]** — 30 행 중 29 행이 심볼릭 링크라 해시가 없다. 잡힌 것은 libgcc_s.so.1 하나 | `hashes.txt` L475–504 (L478) · `fields.txt` L488 (30 = 행 수) | 예 — 봉인 전에 링크 대상 파일의 sha256 을 받는다 (q7) |
| 라이브러리를 찾는 길 (RPATH 등) | **[미확인]** — LD_LIBRARY_PATH 는 UNSET 인데 conda 환경으로 풀린다. 까닭은 out/ 에 없다 | `fields.txt` L50 · `lmp1_ldd.txt` L3 | 예 (q7) |

## 3. MPI · 실행 환경 (R3)

| 칸 | 값 | 근거 | 다시 확인 |
|---|---|---|---|
| mpirun 자리 | 사용자 conda 환경의 bin (가린 꼴 = 근거 줄) | `fields.txt` L518–519 | 예 — job 시작 때 |
| 후보 | 후보 26 개 중 실제 파일 1 개 (mpiexec 도 같은 파일) | `fields.txt` L516 · L517 · L511 | 아니오 |
| mpirun sha256 | 407990f94f9d3863be273b44e6e8fc96b9a015a3b14763ae0aab60857d1ee72d · 190592 B · mtime 1774502927 (= 2026-03-26T05:28:47Z [산술]) · 모드 755 | `fields.txt` L521 · L520 · `hashes.txt` L505 | 예 |
| MPI 판 | mpirun (Open MPI) 5.0.10 | `mpi1_version.txt` L24 | 아니오 (sha256 이 같으면) |
| conda 꾸러미 (사용자 환경 · 79 개 중) | openmpi-5.0.10-h67ed482_1 · mpi-1.0.1-openmpi · ucx-1.20.0 · libfabric-2.5.0 · libpmix-5.0.8 · libhwloc-2.13.0 · libstdcxx-15.2.0 · libgcc-15.2.0 | `conda1_meta.txt` L64 · L38 · L56 · L63 · L65 · L46 · L12 · L55 | 예 — conda 환경은 고칠 수 있는 자리다 (디렉터리 모드 2775 · `walk.txt` L79–82) |
| 다른 MPI 의 흔적 | 시스템 anaconda 꾸러미 목록에 mpich 이름이 있다 (mpi-1.0-mpich · mpich-3.3.2-external_0). 그쪽 `mpirun` 파일은 없다 (UNRESOLVED) → 실제 mpirun 은 위 하나뿐 | `conda2_meta.txt` L9 · L15 · `fields.txt` L515 | 예 — job 안에서 실제로 풀린 mpirun 을 적는다 |
| 로그인 셸 환경 | PATH 앞쪽 = LIGGGHTS 빌드 폴더 · 다른 프로그램 하나 · 사용자 conda 환경 · 시스템 anaconda. CONDA_DEFAULT_ENV=base · LD_LIBRARY_PATH UNSET · OMP_NUM_THREADS UNSET · 모듈 0 | `fields.txt` L49 · L51 · L50 · L54 · L57 · `module_list.txt` L1 | 예 — job 안 환경은 잰 적이 없다 |
| 수집 때 MPI 경고 | "세션 폴더가 공유 파일시스템 (lustre) 위" 라는 PRTE 경고. 수집 블록이 TMPDIR 을 자기 폴더로 잡아서 났다 | `mpi1_version.txt` L2–7 | 아니오 — 단 job 안 TMPDIR 자리는 **[미확인]** |
| DEV 런이 쓴 MPI 호출 | 플래그 `--oversubscribe --bind-to none` · NP 20 · conda 환경 활성 · PATH 덧붙임 없음 (DEV E0 다섯 다 같음) | `seal_extract.txt` L984–990 (E0_ref_s32452843) · L944–950 (s49979687) · L584–590 (s67867967) · L464–470 (ref2) · L744–750 (dthalf) | 아니오 (기록) |
| pilot 러너가 쓸 호출 | job 시작 대조기가 `<mpirun 절대 경로> --oversubscribe --bind-to none -np 20 <바이너리 절대 경로> -in in.mixer` 한 번 · OMP · OPENBLAS · MKL 스레드 1 · conda 환경 활성 없음 | 리포 `F8/job_start.py.txt` L44 · L47 | 예 — DEV 와 다른 조합이다 (등록 초안 17 절 11) |
| MPI 런타임 (rank 수 · 바인딩 · 노드 배치) | **[미확인]** — 로그인 셸에서 `--version` 만 돌렸다 | `probes.txt` L98 | 예 — job 안에서만 볼 수 있다 (pilot 자신의 몫) |
| Python (가드 · job 시작용) | 후보 둘. 사용자 conda = 3.10.20 · numpy 2.2.6 · scipy 1.15.3 · sha256 561c350efec08f1712162c4d649f4b668bacceb68388e973efec964f0073cd92 / 시스템 anaconda = 3.9.13 · numpy 1.21.5 · scipy 1.9.1 · sha256 e8cd6aea4793c192bb74ffcfc1c670afa4629eca2a3ea998c5e15c1c876a3917. 어느 쪽을 쓸지 **미정**. 가드 · job 시작은 표준 라이브러리만 쓴다 | `py1_version.txt` L1 · `py1_modules.txt` L1–2 · `fields.txt` L529 / `py2_version.txt` L1 · `py2_modules.txt` L1–2 · `fields.txt` L532 · 리포 `F8/job_start.py.txt` L3 · `F8/submit_one.py.txt` L6–13 | 예 — 러너에 절대 경로로 박는 칸이다 (리포 `F8/run_one.sbatch.txt` L14 = UNRESOLVED) |
| 관측기가 도는 자리 | 회수 뒤 로컬 스냅숏에서 (`--case PRECAL_E0 --run <스냅숏>`) — ibb 에서 돌리지 않는다 | 리포 `F8/commands.txt` L53–58 · `F8/inventory.md` L60 | 해당 없음 — 로컬 Python · numpy 판은 회수 때 기록 |

## 4. SLURM (R4)

| 칸 | 값 | 근거 | 다시 확인 |
|---|---|---|---|
| SLURM 판 | slurm 22.05.2 | `slurm_sinfo_version.txt` L1 | 아니오 |
| 파티션 | cpu (기본) · up · 노드 4 · 노드당 CPU 152 · 노드당 메모리 515000 MB · 상태 mix | `slurm_sinfo_partitions.txt` L1 (열 뜻 = `meta_script.sh` L440) | 예 — 상태는 시점 값 |
| 파티션 시간 상한 | 14-00:00:00 | `slurm_sinfo_partitions.txt` L1 | 예 — 관리자가 바꿀 수 있는 값 |
| 노드 사용 | 할당 / 유휴 / 기타 / 전체 = 4 / 0 / 0 / 4 (유휴 노드 0) | `slurm_sinfo_summary.txt` L2 | 예 — 시점 값. 빈 코어 수는 **[미확인]** (out/ 에 없다) |
| QOS cpu-60 | 사용자당 한도 = cpu 60 (GPU a100 0 · rtx3090 0). 우선순위 0. MaxWall · 사용자당 잡 수 · 제출 수 칸은 빈칸 | `slurm_qos.txt` L23 (열 뜻 = `meta_script.sh` L442) | 예 |
| 내 association | QOS = cpu-60 하나 · **MaxWall = 7-00:00:00**. Partition · DefaultQOS · MaxJobs · MaxSubmit · MaxTRES · GrpTRES 칸은 빈칸. 줄 1 개 | `slurm_assoc_me.txt` L1 (열 뜻 = `meta_script.sh` L443 · Account 열은 일부러 안 모았다) | 예 |
| 걸리는 시간 상한 | 7-00:00:00 [추정 — association 7 일과 파티션 14 일 중 작은 쪽이 걸린다고 읽음] | 위 두 줄 | 예 |
| 내 잡 수 (11-10 관측) | 0 (squeue 종료 코드 0 · 출력 0 줄) | `slurm_squeue_me.txt` (0 줄) · `probes.txt` L110 · `fields.txt` L537–538 | 예 — 제출 전 5 분 안. 가드 규칙 = 내 잡 CPU + 20 ≤ 60 (리포 `F8/submit_one.py.txt` L132–133) |
| 내 잡 (11-12 기록) | **바뀜** — 11-12 부터 같은 계정 · ibb 에서 언로딩 G2c′ 잡 (빌드 358638 · 358659 · 건식 358639 · 358660 · 358667) · 1저자 *"ibb 로 가서 cpu 60 활용해서 진행"* · 다음 = 건식 다시 → 샌드박스 (N 40000) = 1저자 GO | 리포 `docs/reviews/p1_g2c_sandbox_20261104/README_g2cp.md` L71–80 · `docs/session_20260923_progress.md` L1445 | 예 — pilot 제출 전 내 잡 CPU 합을 다시 본다 · 순서 = 1저자 (등록 초안 Q11) |
| 다른 사용자 큐 · 빈 코어 | **[미확인]** (타인 자료라 안 모았다) | — | 예 — 대기 시간 가늠용. 판정에는 안 쓴다 |
| 메모리 요청 · 한도 | **[미확인]** — DEV 러너와 first8 러너 초안 둘 다 메모리 지정이 없다. DEV E0 다섯 런은 그 꼴로 완주했다. MaxRSS 는 안 쟀다 | 리포 `dem_scripts/mixer_20260921/launch_highbo.sh` L293–298 · `F8/run_one.sbatch.txt` L2–7 · `docs/session_20260923_progress.md` L822 · `docs/reviews/mixer_highbo_stiffness_prereg_20260929.md` L346 ("메모리 미측정") | 예 — DEV E0 잡의 sacct (MaxRSS · ReqMem) 를 받으면 채운다 (q6) |

## 5. 디스크 (R5)

| 칸 | 값 | 근거 | 다시 확인 |
|---|---|---|---|
| 홈 파일시스템 | lustre · 마운트 옵션 rw, checksum, flock, nouser_xattr, lruresize, lazystatfs, nouser_fid2path, verbose, encrypt (원격 이름은 가림) | `fields.txt` L539–540 · `findmnt_home.txt` L1 | 아니오 (정적). 단 런 폴더 경로가 정해지면 그 경로로 df 를 한 번 잰다 |
| 전체 · 사용 · 여유 (바이트) | 745348133519360 · 565160840167424 · **142604135108608 B** · 80 % | `df_home_bytes.txt` L2 | 예 — 공유 파일시스템 · 시점 값 |
| 같은 값 (df -h) | 678T · 515T · 130T · 80 % | `df_home_human.txt` L2 | (위와 같음) |
| inode | 전체 755667898 · 사용 196186622 · **여유 559481276** · 26 % | `df_home_inodes.txt` L2 | 예 |
| 믹서 폴더가 있는 파일시스템 | 세 폴더 모두 같은 Lustre | `fields.txt` L541–546 | 아니오 |
| 내 사용량 | 2228675672 KB · 파일 543500 개 | `lfs_quota_home.txt` L3 | 예 |
| 내 할당 (한도) | 개인 칸은 quota 0 · limit 0 (블록 · 파일 둘 다). "기본 할당 설정을 쓴다" 는 줄이 2 개 있다 → **기본 한도의 실제 값 = [미확인]** | `lfs_quota_home.txt` L3 · L4 · L5 | 예 — 기본 한도를 보는 읽기 조회가 필요하다 (q4) |
| `quota -s` | 실패 (종료 코드 1 · 출력 0 B). Lustre 라 `lfs quota` 로 따로 받았다 | `probes.txt` L115 · L116 | 아니오 |
| OST 별 여유 | **[미확인]** (df 는 집계 값이다) | — | 예 (권고 · q5) |
| 믹서 폴더 크기 (du -sk) | 09-21 층상 runs 524888 KB · dev7 63444400 KB · dev7_v26 90504844 KB | `mix1_du.txt` L1 · `mix2_du.txt` L1 · `mix3_du.txt` L1 | 아니오 — Q6 산술의 입력이다 |
| DEV E0 런별 덤프 크기 · 프레임 한 장 크기 | **[미확인]** — out/ 에는 폴더 합계와 런별 항목 수만 있다 (post 는 디렉터리 항목 크기뿐). DEV 덤프는 전부 기본 `%g` 꼴이다 (DEV · dev-bo · dev-u 덱에 `dump_modify` 줄 0) | `mix3_run23_ls.txt` L10 · `fields.txt` L348 · 리포 `docs/data/mixer_highbo_dev_decks_20260930_v26/decks/*/in.mixer` · `…_20261002_bo` · `…_20261005_u` (본 세션 grep) | 예 — q1–q3 로 채운다 |
| first8 제안 root | 없음 (홈 아래 믹서 폴더는 dev7 · dev7_v26 · 수집 폴더뿐) | `fields.txt` L353 · `home_mixer_dirs.txt` L1–3 | 예 — Q5: 발사 때 새로 만든다 |
| 회수 목적지 여유 | **[미확인]** (로컬). 이 컨테이너는 디스크 여유 8.4 GB 라 목적지가 될 수 없다 | 리포 `docs/session_20260923_progress.md` L1437 | 예 — 1저자 WSL 여유를 회수 전에 (등록 초안 Q8) |

## 6. 경로 · 권한 (R1 · R2 · 보조)

| 칸 | 값 | 근거 | 다시 확인 |
|---|---|---|---|
| 홈의 실제 자리 | 로그인 홈 경로는 루트 아래 심볼릭 링크 (모드 777 · 소유 root) 를 지나 Lustre 위 실제 경로로 풀린다 | `fields.txt` L6 · `walk.txt` L77 · L85 | 아니오 — 단 봉인 묶음의 경로 문자열은 한 가지 꼴로 통일해야 한다 (8 절 관찰 1) |
| 홈 | 디렉터리 700 · 소유 = 나 · 이름 붙은 ACL 0 | `walk.txt` L86 · L72 · `fields.txt` L547–548 | 아니오 |
| 바이너리 조상 | 루트 555 root · Lustre 마운트 755 root · 홈 상위 755 root · 홈 700 나 · LIGGGHTS 폴더 775 · src 775 (그룹 쓰기) | `walk.txt` L69–74 | 예 (R2) |
| dev7_v26 폴더 | 775 · 그룹 쓰기 가능 · 이름 붙은 ACL 0 | `fields.txt` L193 · L555–556 · `walk.txt` L68 | 아니오 — pilot 은 이 폴더를 쓰지 않는다 (Q5) |
| conda 환경 경로 | 환경 폴더 넷 = 2775 (그룹 쓰기) · mpirun = 755 | `walk.txt` L79–83 | 예 (R2) |
| 새 폴더의 기본 권한 (umask) | **[미확인]** | — | 예 — 런 폴더를 만든 뒤 모드를 본다 |

## 7. 덱 · 템플릿 신원 (R6 · out/ 에 있는 것만)

| 칸 | 값 | 근거 | 다시 확인 |
|---|---|---|---|
| ibb 위 first8 E0 덱 | **없음** (ABSENT). first8 root 가 없다 — Q5 대로 아직 안 만들었으니 정상 | `hashes.txt` L473 · `fields.txt` L355 | 예 — 발사 때 새로 놓고 sha256 을 계획 바이트와 대조 (preflight 3) |
| ibb 위 first8 메타 · STL · 러너 · 가드 · 정책 · 승인 파일 | **없음** (같은 까닭) | `fields.txt` L353 | 예 — 봉인 단계에서 처음 생긴다 |
| ibb 체크아웃 (repo1) | HEAD 063309e5e821e6fd898f23eb7d9a9861ef5b1dbd (리포에 있는 커밋 · 10-06) · 가지 이름 조회 실패 (떨어진 HEAD 로 읽음 [추정]) · status 출력 0 B · 마지막 커밋 1791277818 (= 2026-10-06T09:10:18Z [산술]) | `repo1_head.txt` L1 · `probes.txt` L9 · L11 · `repo1_log1.txt` L1 · 리포 `git log -1 063309e5e` | 예 — 단 이 체크아웃은 pilot 소스가 아니다 (아래 줄) |
| 체크아웃에 first8 스크립트가 있나 | **없음** — `scripts/mixer_precal_prepare.py` · `scripts/mixer_precal_observe.py` 가 ABSENT (체크아웃 10 곳 모두) | `hashes.txt` L16–17 (다른 9 곳도 같은 두 줄) | 예 — pilot 소스 묶음은 새로 놓아야 한다 |
| 체크아웃의 STL 셋 | 0-A 의 세 해시와 같음 | `hashes.txt` L6 · L7 · L8 | 예 — staging 뒤 pilot 폴더의 STL 로 다시 |
| 체크아웃의 생성기 · 되읽기 · 비교기 · M 판독기 | make_mixer_deck.py f3cd4d9f… · mixer_deck_readback.py 1bab4ba1… · mixer_deck_diff.py 8cc033ce… · measure_mixing_index.py 4375ec56… | `hashes.txt` L13 · L12 · L11 · L14 | 아니오 — pilot 에 안 쓰는 옛 판이다 (8 절 관찰 2) |
| 체크아웃의 런처 · 정책 · 시작 대조기 | launch_highbo.sh ed469ffa… · launch_policy.json 08bdcb4f… (DEV-U 런 봉인의 정책 해시와 같음) · start_check.py 93fa907e… | `hashes.txt` L1 · L2 · L3 · `seal_extract.txt` L673–674 | 아니오 — first8 은 이 런처 · 정책을 쓰지 않는다 (리포 `F8/inventory.md` L30) |
| DEV E0 다섯 런 (dev7_v26) 의 덱 sha256 | E0_ref_s32452843 78ad92356373e00a… · E0_ref_s49979687 0544fffbf5c7ae26… · E0_ref_s67867967 b79e0d73c8a36c78… · E0_ref2_s32452843 cc470941768ae5dd… · E0_ref_dthalf_s32452843 819c8a7f2310d2b5… = 리포 `docs/data/mixer_highbo_dev_decks_20260930_v26/decks/` 의 덱과 같음 (본 세션 sha256) | `hashes.txt` L461 · L453 · L341 · L304 · L386 (`seal_extract.txt` L961 · L921 · L561 · L441 · L721 과 같다) | 아니오 — Q6 산술의 출처 신원이다 (pilot 덱이 아니다) |
| DEV E0 런의 STL 셋 | 체크아웃 STL 과 같은 세 해시 | `hashes.txt` L462 · L470 · L464 (E0_ref_s32452843) | 아니오 |
| DEV E0 런의 실행 기록 | 다섯 다 시작 대조 ok=true · NP 20 · QOS cpu-60 · 파티션 cpu · 시간 한도 2-00:00:00 · 바이너리 sha256 = 2 절과 같음 · 정책 STIFF-DEV7-2026-09-30-v26-dev-e0-rot | `seal_extract.txt` L965 · L984 · L986–988 · L960 · L993 (E0_ref_s32452843 · 나머지 넷 같은 칸) | 아니오 |
| DEV E0 진단 기록 | dev7_v26 = schema mixer_dev_e0_diag/1 · verdict PASS (기록 5 개). dev7 (옛 덱) = FAIL | `diag_extract.txt` L3–12 · L1–2 | 아니오 — pilot 판정과 무관 |

## 8. 읽다가 본 것 (관찰 · 판정 아님)

1. **경로 꼴이 두 가지다.** 로그인 홈 경로는 심볼릭 링크를 지난다 (`walk.txt` L77). DEV 봉인에도 두 꼴이 섞여 있다 — 발사 기록의 `lmp_path` 칸이 09-28 런은 로그인 꼴, 09-30 런은 풀린 꼴이다 (`seal_extract.txt` L22 · L976). first8 가드는 자기 파일의 풀린 경로와 문자열로 대조한다 (리포 `F8/submit_one.py.txt` L43–46 · L52). 봉인 묶음 · 정책의 경로를 로그인 꼴로 적으면 제출이 막힌다 [관찰 — 코드 판독 · 시험 안 함]. 계획 문서의 정본 root 문자열 (`F8/commands.txt` L25 · L69 · `F8/campaign_policy.json.example` 의 install_root) 은 로그인 꼴이다.
2. **ibb 체크아웃은 first8 소스가 아니다.** first8 스크립트 둘이 없고 (`hashes.txt` L16–17), 생성기 해시 f3cd4d9f… 는 first8 봉인의 생성기 661936b7… (리포 `F8/source_seal.json` L27) 와도 HEAD 의 dc253bc8… 와도 다르다.
3. **라이브러리 신원이 비어 있다.** 30 행 중 29 행이 심볼릭 링크라 해시가 없다 (`hashes.txt` L475–504). 지금 고정된 것은 실행 파일 둘 (lmp_mpi · mpirun) 의 바이트뿐이다.
4. **Python 판이 first8 시험 판과 다르다.** ibb = 3.10.20 (사용자 conda) · 3.9.13 (시스템). first8 문서의 시험 판 = 3.8.20 · 3.12.14 · 3.11.17 (리포 `F8/README.md` L36 · `P8/README.md` L51). ibb 판에서 가드 · job 시작을 돌린 기록은 없다.
5. **유휴 노드가 0 이었다** (`slurm_sinfo_summary.txt` L2). 11-10 에는 내 잡이 0 이었지만 11-12 부터 G2c′ 잡이 같은 QOS 를 쓴다 (4 절). 바로 시작된다는 보장은 없다.
6. **관측기 로그 계약과 실제 ibb 로그 형식이 네 군데에서 어긋난다** [관찰 — 리포의 같은 빌드 로그 줄 · 덱 주석 · 본 세션 재현 `work/check_log_contract_output.txt`] — 등록 초안 7-4.
7. **관측기는 E0 에서 t0 프레임 한 장만 본다** — 나머지 1120 장의 결손 · 겹침을 잡지 않는다 [관찰 — `scripts/mixer_precal_observe.py` L297–302 판독]. 등록 초안 7-3 점검표 C3 이 그 자리를 채운다.
8. **메타 · 생성기 · 관측기는 짝으로 움직인다** — HEAD 소스 (생성기 dc253bc8…) 로는 원 메타 (c6543f38…) 가 "metadata differs from the fixed case recipe" 로 거부되고 (리포 `IN/README.md` L23), 원 가드는 원 메타만 받는다 (`F8/submit_one.py.txt` L147–150 · `F8/static_asset_manifest.json`). 등록 초안 Q7.
9. **덤프 형식 줄은 6 열 꼴만 실측됐다** (리포 `docs/data/mixer_highbo_devu_prelim_20261006/README.md` L80). 덱 주석 "ibb 바이너리 실측 전" (`F8/planned_assets/PRECAL_E0/in.mixer` L138) 은 6 열 꼴에 대해서는 낡았고, 12 열 꼴에 대해서는 아직 맞다.

## 9. "[미확인]" 칸 모음

| # | 칸 | 채우는 길 |
|---|---|---|
| 1 | 링크 라이브러리 29 개의 sha256 | 링크 대상 파일의 sha256 (q7) |
| 2 | 라이브러리를 찾는 길 (RPATH 등) | `readelf -d` 읽기 조회 (q7) |
| 3 | job 안 환경 · MPI 런타임 (rank · 바인딩 · TMPDIR) | pilot job 의 시작 영수증 |
| 4 | Python 경로 · 판 고정 | 봉인 단계에서 정함 |
| 5 | 메모리 요청 · 한도 · DEV E0 의 MaxRSS | DEV E0 잡 다섯의 sacct (q6) |
| 6 | 빈 코어 수 · 다른 사용자 큐 | 발사 직전 조회 (판정 아님 · q8) |
| 7 | 기본 할당 한도의 실제 값 | `lfs quota` 기본 한도 읽기 조회 (q4) |
| 8 | OST 별 여유 | `lfs df` 읽기 조회 (q5) |
| 9 | DEV E0 런별 덤프 크기 · 프레임 한 장 크기 · 첫 프레임까지 시간 | du · 파일 목록 읽기 조회 (q1 · q2) |
| 10 | 전 정밀도 12 열 프레임의 실제 크기 · 쓰기 시간 | pilot 자신 (q3 은 6 열 꼴 비만) |
| 11 | 새 폴더 기본 권한 (umask) | 런 폴더를 만든 뒤 |
| 12 | first8 덱 · 메타 · STL · 러너 · 가드 · 정책 · 승인 파일 (ibb 위) | 봉인 단계 (지금은 없음) |
| 13 | 실제 DEV E0 로그의 thermo 표 안 비-행 줄 꼴 | q9 (값 없이 첫 낱말 · 줄 수만) |
| 14 | 회수 목적지 (1저자 WSL) 여유 | 회수 전 1저자 |
| 15 | 지금 내 잡 CPU 합 (G2c′ 포함) | 제출 전 5 분 안 squeue |

## 10. 발사 직전 다시 확인할 것 (요약)

| 순서 | 무엇 | 기준 값 (이 표) | 규칙 |
|---|---|---|---|
| 1 | 날짜 · 호스트 · 운영자 · 내 association · QOS | 4 절 | preflight 1 |
| 2 | 바이너리 · mpirun 의 실제 경로 · sha256 (+ 라이브러리) | 0-A · 2 · 3 절 | preflight 2 — job 안에서 한 번 더 |
| 3 | 덱 · 메타 · STL · 소스 · 러너 · 정책의 sha256 | 0-A (계획 바이트) | preflight 3 — 준비 · staging · job 시작 세 번 |
| 4 | 내 잡의 CPU 합 + 20 ≤ 60 · first8 돌고 있는 팔 0 · 파티션 cpu · QOS cpu-60 | 4 절 | preflight 4 · 가드 300 초 규칙 |
| 5 | 여유 바이트 · inode · 사용량 · 한도 | 5 절 | preflight 5 — 바닥 값은 등록 초안 5 · 6 절 |
| 6 | walltime | 등록 초안 4 절 | preflight 6 |
| 7 | D0.7 완주 근거 · MXD2R 처분 · 승인 묶음 아홉 영수증 | 0-A · 등록 초안 17 절 14 | 가드 L113 · L127–128 |

## 11. 한정

- sha256 은 내용 신원이다. 작동 · 호환 · 승인의 증명이 아니다.
- `lmp_mpi -h` 의 목록은 기능 목록이다. 물리 · 로그 호환 자격이 아니다.
- "[미확인]" · FAIL 은 0 · 빈 큐 · 무제한 할당을 뜻하지 않는다.
- out/ 의 값은 로그인 셸에서 3 분 동안 본 것이다. job 안 값과 같다는 보장이 없다. 4 절 "11-12 기록" 줄만 out/ 밖 (리포 기록) 이다.
- 이 표는 자격 수행 · 운영 승인 · 발사 GO 가 아니다.

#!/usr/bin/env python3
"""recheck2 RCP2-01 한정 (가) 대조 — 실제 payload (`mpm_webapp_payload.py` 를 runpy 로 __main__) 를 러너 꼴 인자로 띄워, 입구에서 멈춘 뒤 이 프로세스의
`cjunc_store._START['preloaded']` · 열쇠 모듈 넷의 불린 차례 (sys.modules 넣은 차례 = import 시작 차례) 를 적는다.
  갈래 A (P6 꼴) = `--step3-cjunc --step3-cjunc-store <폴더>` 만
  갈래 B (러너 꼴) = 위 + `--expect-physics <러너가 붙이는 ca_ext.cjunc.* 칸 하나>` (러너 NG_DECL · payload 1781–1782 행 `_RC.ca_ext_protocol_fields()`)
GPU · 솔브 없음 (입구 계약에서 SystemExit).  사용: python3 ce01_payload_order.py <트리 scripts> <저장본 폴더> <A|B> [ca_ext 칸]"""
import json
import runpy
import sys

scripts, store, which = sys.argv[1:4]
key = sys.argv[4] if len(sys.argv) > 4 else None
sys.path.insert(0, scripts)
argv = ['mpm_webapp_payload.py', '--step3-cjunc', '--step3-cjunc-store', store]
if which == 'B':
    argv += ['--expect-physics', f'{key}=1']
sys.argv = argv
exit_msg = None
try:
    runpy.run_path(scripts + '/mpm_webapp_payload.py', run_name='__main__')
except SystemExit as e:
    exit_msg = str(e)[:160]
KEYM = ('carbon_junction', 'step3_sigma', 'fibre_segment_raster', 'cjunc_store')
cs = sys.modules.get('cjunc_store')
print('ORDER ' + json.dumps({'which': which, 'exit': exit_msg, 'start_order': [m for m in sys.modules if m in KEYM],
                             'preloaded': (cs._START.get('preloaded') if cs is not None else None)}, ensure_ascii=False))

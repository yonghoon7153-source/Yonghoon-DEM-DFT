#!/usr/bin/env python3
"""applied_log.jsonl → APPLIED.md (적용 기록).

    python3 -I make_applied.py [<묶음 뒤 손질 글 파일>]

표의 '바꾸기 전 글' · '바꾼 글' 은 앞 80 자 (세로 막대는 ∣ 로 · 줄바꿈은 ⏎ 로 바꿔 적는다).
"""
import collections
import json
import os
import sys

FIX = '/tmp/claude-0/-home-user-Yonghoon-DEM-DFT/d26d1e75-209f-540f-83a8-c0e1957edc2f/scratchpad/synthfix'
LOG = os.path.join(FIX, 'applied_log.jsonl')
DOCS = [('S1', 'S1_compaction_unloading_values.md', 'V_S1.md', 18),
        ('S2', 'S2_material_loadshare_contactlaw.md', 'V_S2.md', 9),
        ('S3', 'S3_mpm_contact_2d3d_handoff_limits.md', 'V_S3.md', 15),
        ('S4', 'S4_dem_limits.md', 'V_S4.md', 10),
        ('S5', 'S5_why_plasticity_is_hard.md', 'V_S5.md', 18),
        ('S6_1', 'S6_1_insights.md', 'V_S6_12.md 대상 1', 9),
        ('S6_2', 'S6_2_insights.md', 'V_S6_12.md 대상 2', 10),
        ('S6_3', 'S6_3_insights.md', 'V_S6_3.md', 12)]
# 고칠 글의 일부만 넣었거나 꼴을 바꿔 넣은 문제 (문서 → 문제 번호 → 한 줄 까닭)
PARTIAL = {
    'S1': {'7': '4 절 표에 새 칸을 더하지 않고 값이 주어진 여섯 줄의 한계 칸 끝에 붙임'},
    'S5': {'1': 'L-14 · L-77 은 고칠 글이 없음', '8': '요지 6 째 줄은 고칠 글이 없음',
           '9': '표지를 댄 일곱 줄만 (2 절 나머지 91 줄 보류)'},
    'S6_2': {'5': '검증이 이름을 댄 여덟 칸만 (나머지 63 칸 보류)'},
}


def cut(s, n=80):
    s = (s or '').replace('\n', ' ⏎ ').replace('|', '∣').strip()
    if not s:
        return '—'
    return s if len(s) <= n else s[:n] + '…'


def cell(s):
    return (s or '').replace('\n', ' ⏎ ').replace('|', '∣').strip() or '—'


def main():
    recs = [json.loads(l) for l in open(LOG, encoding='utf-8') if l.strip()]
    post = open(sys.argv[1], encoding='utf-8').read().rstrip('\n') if len(sys.argv) > 1 else '(묶음을 만들기 전 판 — 이 절은 묶음 뒤에 채운다)'
    o = []
    o.append('# 적용 기록 — 검증 표의 "고칠 글" 을 종합 문서 S1–S6_3 에 넣은 것 (2026-11-12)')
    o.append('')
    o.append('## 0. 범위와 방법')
    o.append('')
    o.append('- 대상 = 정독 종합 문서 여덟 개 (synth/out 의 S1 · S2 · S3 · S4 · S5 · S6_1 · S6_2 · S6_3). S8 (S8_paper_agent_candidates.md) 은 건드리지 않았다 (sha256 고치기 전과 같음).')
    o.append('- 적용한 것 = 검증 보고 일곱 개 (synth/verify 의 V_S1 · V_S2 · V_S3 · V_S4 · V_S5 · V_S6_12 · V_S6_3) 의 "문제 (무거운 순)" 표, "고칠 글" 칸. 같은 보고의 "가벼운 것" · "빠진 무게 있는 줄" · "확인 못 함" 절은 적용 대상이 아니다 (넣지 않았다).')
    o.append('- 고치기 전 문서 = synthfix/out_before/ (아홉 파일 + SHA256SUMS.txt).')
    o.append('- 카드 대조 = litdb 정본 가지 origin/claude/friendly-meitner-lldvar (커밋 c5f78c6682673e6e3d62c0a6ecaafc2e3dbff6a4 · 카드 532 장 + comparison_vs_ours_DEM.md) 를 git archive 로 synthfix/cards_cache/ 에 풀어 읽었다 (정본 저장소에는 쓰지 않음 · c5f78c6 = 작업을 시작할 때 그 가지의 끝). 고칠 글이 카드 줄을 댄 곳은 그 줄을 직접 열어 값 · 문구가 맞을 때만 넣었다. 검증 글의 줄 번호가 정본과 한두 줄 다른 곳은 정본에서 본 줄 번호로 적고 "까닭" 칸에 남겼다.')
    o.append('- 정본 가지의 이동: 작업 중에 그 가지가 아홉 커밋 나아가 ee0c13789 가 되었다 (11-12 · 바뀐 md = 비교 문서 + 카드 8 장 · 새 카드 2 장 · zunker2025_dem_large_deformation_compaction 은 555 → 1,051 줄). 바뀐 파일에 기대는 적용 (S6_2 MB-1 · MB-55 · S6_3 어-17 · S4 K-156) 을 새 끝에서 다시 보았다 — 글 · 값은 그대로이고 줄 번호만 밀렸다 (zunker2025 의 MB-55 문장 L266 → L572 · 비교 문서 겹침 규약 줄 L701–704 → L714–717 · "reasonable enough" 줄 L799 → L812 · zunker2024_mdr_contact_model_partI L209–210 은 그대로). 문서에 적힌 줄 번호 (예: MB-55 의 "(L266)") 는 고치지 않았다 — 종합 문서의 줄 번호는 묶음 · 검증이 읽은 때의 것이다.')
    o.append('- 넣는 법 = 명세 파일 (synthfix/tools/spec_*.py) 의 "바꾸기 전 글 → 바꾼 글" 을 문서에서 정확히 한 번 (또는 적어 둔 횟수만큼) 찾아 바꿈 (synthfix/tools/apply.py · 하나라도 어긋나면 그 문서에는 아무것도 쓰지 않음 · 표 줄은 칸 수가 바뀌지 않는지 확인). 기록 원본 = synthfix/applied_log.jsonl.')
    o.append('- 한정 줄 = 여덟 문서의 제목 바로 아래에 한 줄씩. 숫자는 그 문서 V 파일의 셈 절에서만 옮겼다. 표본 꼴은 V 파일이 적은 대로다 (S1 · S2 · S3 넷에 하나 · S4 · S5 다섯에 하나 · S6_1 · S6_2 일곱에 하나 · S6_3 여섯에 하나).')
    o.append('')
    o.append('## 1. 문서별 셈')
    o.append('')
    o.append('"검증 문제" = V 파일 문제 표의 줄 수. "고침 기록" = 문서에 실제로 넣은 바꿈 하나하나 (문제 하나가 여러 자리를 고치면 여러 줄 · 한정 줄 1 포함).')
    o.append('')
    o.append('| 문서 | V 파일 | 검증 문제 | 전부 적용 | 일부만 적용 | 통째 보류 | 고침 기록 (적용) | 보류 기록 |')
    o.append('|---|---|---|---|---|---|---|---|')
    tot = collections.Counter()
    for d, fn, vf, n in DOCS:
        rs = [r for r in recs if r['doc'] == d]
        nums = collections.defaultdict(list)
        for r in rs:
            for k in [x.strip() for x in r['num'].split('·')]:
                nums[k].append(r['status'])
        part = set(PARTIAL.get(d, {}).keys())
        miss = [str(i) for i in range(1, n + 1) if str(i) not in nums]
        assert not miss, (d, miss)
        whole_held = [k for k in nums if k.isdigit() and all(s == 'held' for s in nums[k])]
        full = n - len(part) - len(whole_held)
        na = sum(1 for r in rs if r['status'] == 'applied')
        nh = sum(1 for r in rs if r['status'] == 'held')
        o.append('| %s | %s | %d | %d | %d | %d | %d | %d |' % (fn, vf, n, full, len(part), len(whole_held), na, nh))
        tot.update(n=n, full=full, part=len(part), wh=len(whole_held), na=na, nh=nh)
    o.append('| 합 | | %d | %d | %d | %d | %d | %d |' % (tot['n'], tot['full'], tot['part'], tot['wh'], tot['na'], tot['nh']))
    o.append('')
    o.append('일부만 적용한 문제:')
    o.append('')
    for d, fn, vf, n in DOCS:
        for k, why in sorted(PARTIAL.get(d, {}).items(), key=lambda x: int(x[0])):
            o.append('- %s 문제 %s — %s' % (vf, k, why))
    o.append('')
    o.append('## 2. 보류한 것 (까닭)')
    o.append('')
    for r in recs:
        if r['status'] == 'held':
            o.append('- %s #%s · %s — %s' % (r['v'], r['num'], r['item'], r['note']))
    o.append('')
    o.append('## 3. 검증의 글과 다르게 넣은 곳 (값은 같고 위치 표기나 꼴만 다름)')
    o.append('')
    o.append('- V_S1 #4 · #15 (A-48 꼬리): 검증의 글은 "§3.3 L108" — 정본 카드에서 L108 은 §3.2 표라 절 번호만 "§3.2 L108" 로 적었다.')
    o.append('- V_S1 #7 (4 절 표): 표에 "진밀도 (분모)" 칸을 새로 더하지 않았다 (나머지 60 줄에 넣을 내용을 검증이 주지 않음). 값이 주어진 여섯 줄 (I-4 · I-5 · I-9 · I-10 · I-14 · I-15) 의 한계 칸 끝에 "· 진밀도 (분모): …" 로 붙였다.')
    o.append('- V_S1 #11 (어긋남 15): 행을 지우고 남은 번호 16–40 은 다시 매기지 않았다 (셈 줄에 "어긋남 39 줄 (번호 1–40 가운데 15 번은 검증 뒤 지움 …)").')
    o.append('- V_S4 #5 (K-156): 2-2 로 옮긴 줄의 원문 위치는 검증 글 "비교 문서 §A L798" 대신 그 줄 꼬리의 범위 "(L797–801)" 로 적었다 (c5f78c6 에서는 L799 · 새 끝 ee0c137 에서는 L812).')
    o.append('- V_S4 #7 (2-2 의 K-6 · K-8 · K-54 · K-165 · K-209): 따옴표만 떼고 "(묶음 줄의 풀이 · 카드 글자 아님)" 표지를 붙였다 (카드 글자로 바꿔 쓰지는 않음).')
    o.append('- V_S5 #2 (L-363): 갈라 낸 문장의 새 행 번호 = L-599 (끝 번호 다음 · 기존 번호는 그대로).')
    o.append('- V_S5 #9 (2 절 표지): 새 칸을 더하지 않고 검증이 표지를 댄 일곱 줄의 "검증" 칸 끝에 "· 표지 = …" 로 붙였다.')
    o.append('- V_S6_12 대상 2 #5 (왜 칸): 표지 "(종합 · 조수 판단)" 은 이름이 주어진 여덟 칸에만 · 셈 절에 더한 줄에 그 한정을 같이 적었다.')
    o.append('- V_S6_12 대상 2 #10 (MB-70 왜 칸): 검증 글의 바깥 따옴표 한 겹을 빼고 카드 글자대로 "앵커" · "후보 (기준 미확인)" 두 따옴표만 두었다.')
    o.append('- V_S6_3 #1 (MC-67): 고친 뒤 MC-516 과 같은 판독이 되므로 어긋남 행은 더하지 않았다 (검증의 고칠 글에도 없음).')
    o.append('- V_S6_3 #7 (17 절 MC-64 행): "(문턱은 2D 원판 MPM 의 것)" 을 줄 맨 끝이 아니라 까닭 칸의 표지 "(종합 · 조수 판단)" 바로 앞에 넣었다.')
    o.append('- 검증 글의 카드 줄 번호가 정본 (c5f78c6) 과 달랐던 곳 (문서에는 줄 번호를 새로 적지 않음): doux2020_stack_pressure_assb 상대밀도 줄 = L204–205 (검증 L202–203) · 같은 카드 §8 문장 = L237–238 (검증 L235–236) · 비교 문서 겹침 규약 줄 = L701–704 (검증 L700–703 · 새 끝 ee0c137 에서는 L714–717).')
    o.append('')
    o.append('## 4. 구조가 바뀐 곳 (행 · 번호 · 개수)')
    o.append('')
    o.append('- S1: 어긋남 15 행 지움 (표 줄 347 → 346) · 셈 줄의 어긋남 개수 40 → 39.')
    o.append('- S2: 어긋남 36 새 행 (표 줄 349 → 350) · 셈 줄의 어긋남 35 → 36 · 어긋남 꼬리 수 97 → 100.')
    o.append('- S3: 어긋남 ㉛ 새 행 (표 줄 307 → 308) · 셈 줄의 어긋남 30 → 31.')
    o.append('- S4: K-156 한 줄을 2-1 에서 2-2 로 옮김 (표 줄 수 그대로 887) · 2-1 머리 · 2-2 머리 · 요지 · 셈 줄의 개수 226 → 225 · 80 → 81.')
    o.append('- S5: 3-B 에 L-599 새 행 (표 줄 688 → 689) · 요지 · 빈 곳 10 · 셈 줄의 3 절 항목 171 → 172 · 3-B 32 → 33 · 끝 번호 L-598 → L-599.')
    o.append('- S6_2: 읽은 범위와 셈 절에 "왜 칸" 줄 하나 더함.')
    o.append('- 여덟 문서 모두: 제목 아래 한정 줄 하나 (+ 빈 줄 하나).')
    o.append('- 항목 번호 (표 첫 칸) 집합은 위에 적은 것 말고 고치기 전과 같다 (기계 대조).')
    o.append('')
    o.append('## 5. 검증이 말하지 않아 그대로 둔 것 (눈에 띈 것만)')
    o.append('')
    o.append('- S5 L-183 "µ 0.1 → 0.3 이 RD 84.2 → 86.0 %" · S6_1 요지 7 과 MA-98 (본 표 · 17 절 두 줄) 의 "≈ 84.2 → (85.4 →) 86.0 %": 정본 카드 pycompact2025 의 11-11 재판독은 μ 0.3 ≈ 85.9 % 이고 86.0 은 옛 판독이다 (카드 L140 · L564). V_S1 #12 는 S1 B-28 에서 같은 값을 85.9 로 고치게 했으나 V_S5 · V_S6_12 는 이 줄들을 문제로 적지 않았다 → 그대로 두었다 (S1 B-28 과 0.1 %p 다름).')
    o.append('- S1 빈 곳 6 의 oh2026 꼬리 (A-73 에서 고친 것과 같은 꼬리) · S1 A-80 의 표지 칸 — 검증이 글을 주지 않음.')
    o.append('- S2 E-100 행 자체 (V_S2 #2 의 항목 칸에 있으나 고칠 글은 요지 9 줄과 어긋남 새 행뿐).')
    o.append('- S6_3 MC-67 의 왜 칸 "§C" · 표지 칸 "표지 없음 (비교 문서)" — 무엇을 칸과 출처 칸만 고치게 되어 있다.')
    o.append('- layer3 꼬리의 줄 번호 (11-10 읽기 사본 기준) — 정본 비교 문서 (11-11) 에서는 L934 뒤가 밀려 있다 (V_S6_3 "가벼운 것").')
    o.append('- 표본 밖 항목 전부 — 검증이 보지 않았고 이 작업도 보지 않았다.')
    o.append('')
    o.append('## 6. 자기 점검')
    o.append('')
    o.append('- 표 칸 수 (synthfix/tools/check_tables.py): 고치기 전 아홉 문서 어긋난 줄 0 · 고친 뒤 아홉 문서 어긋난 줄 0 (표 줄 수 변화 = 4 절에 적은 것과 같음).')
    o.append('- 줄 단위 차이 (difflib): 바뀐 줄 · 더한 줄 · 지운 줄의 첫 칸이 모두 기록의 항목과 맞는다 (기록에 없는 줄 변화 0).')
    o.append('- 카드 다시 대조 (synthfix/tools/selfcheck.py): 점검 55 개 (적용 기록 52 줄에 해당 · 그 가운데 따옴표 글자 대조 18) 를 정본 카드의 그 줄 범위와 다시 대조 — 통과 55 · 실패 0. 점검 도구 자체의 확인: 고치기 전 문서에 돌리면 50 개가 실패하고 (문서 쪽) 토큰 둘을 일부러 틀리게 하면 그 둘만 실패한다 (카드 쪽).')
    o.append('- 같은 점검을 새 정본 끝 (ee0c137 · 바뀐 md 아홉 개를 덮어쓴 사본 synthfix/cards_merged_ee0c/) 으로 다시 돌리면 통과 53 · 실패 2 — 둘 (MB-55 · 어-17) 은 줄 범위만 밀린 것이고 문장은 밀린 자리 (L572 · L714–717) 에 글자 그대로 있다.')
    o.append('- 한 것은 표본 대조다 — 적용 기록 212 줄 가운데 카드 (또는 정본 비교 문서) 줄을 직접 댄 것이 80 줄이고 그 가운데 52 줄을 기계로 다시 보았다. 나머지 적용은 문서 안 다른 줄 · 묶음 줄 · 검증의 글에 기대어 넣었다.')
    o.append('')
    o.append('## 7. 묶음 (build_package) 과 그 뒤 손질')
    o.append('')
    o.append(post)
    o.append('')
    o.append('## 8. 적용 표 (한 줄 = 바꿈 하나)')
    o.append('')
    o.append('| V 파일 | # | 항목 번호 | 종류 | 바꾸기 전 글 (앞 80 자) | 바꾼 글 (앞 80 자) | 적용 / 보류 | 까닭 |')
    o.append('|---|---|---|---|---|---|---|---|')
    for r in recs:
        st = '적용' if r['status'] == 'applied' else '보류'
        old = cut(r.get('old'))
        new = cut(r.get('new'))
        if r['status'] == 'applied' and not (r.get('new') or '').strip():
            new = '(지움)'
        o.append('| %s | %s | %s | %s | %s | %s | %s | %s |' % (
            cell(r['v']), cell(r['num']), cell(r['item']), cell(r['kind']), old, new, st, cell(r.get('note'))))
    o.append('')
    open(os.path.join(FIX, 'APPLIED.md'), 'w', encoding='utf-8').write('\n'.join(o))
    print('APPLIED.md 줄', len(o), '· 기록', len(recs), '· 적용', tot['na'], '· 보류', tot['nh'],
          '· 문제', tot['n'], '전부', tot['full'], '일부', tot['part'], '통째 보류', tot['wh'])


if __name__ == '__main__':
    main()

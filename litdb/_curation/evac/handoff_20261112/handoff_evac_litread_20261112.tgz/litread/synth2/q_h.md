# 질문 h — 배치별 근거 묶음 (원문 줄 그대로 · 파일 43 개)

### [batch_01] h. DEM 에서 FE · MPM 으로 넘긴 선례와 넘긴 시점

DEM 상태를 FE · MPM 으로 넘긴 **계산 선례는 이 배치에 없음**. 가까운 것만.

- [h] devaucorbeil2020_mpm_after_25_years_review | 영상 · 구조 → MPM 입자 (voxel → particle · 다중 contact) 치밀화 선례 = Bardenhagen 2005 "foam densification via numerical simulation". MPM ↔ DEM: "적절한 구성식이면 MPM 이 DEM 정확도 재현 가능 · DEM 에서 유도한 구성식으로 MPM 대규모" (Coetzee / Gracia) | §6 (L56–60 · L63–66) | intro stated | DEM 상태를 넘긴 시점은 카드에 없음 · PDF 미열람
- [h] bardenhagen2000 · bardenhagen2001 (두 카드) | 선례 값 없음 — 카드 추론: 접촉에 반발 계수 자리가 없으므로 성긴 초기 패킹은 DEM (P ≈ 0 · 정착) 이 만들고 압축 (· 제하) 만 다물체 MPM 이 하는 인계가 자연스럽다 ("PyCompact · Demirtas 꼴") | 2000 §9-⑦ (L339) · 2001 §10-⑨ (L331) | [우리 추론] | 논문 밖 · 지목한 카드 (`pycompact2025_dem_mpfem_workflow` · `demirtas2021_mpfem_hollow_sphere_die_compaction`) 는 이 배치 밖
- [h] bardenhagen2000_mpm_granular_multibody_frictional_contact | 카드의 우리 현황: 우리 MPM 은 "DEM 끝에서 짧은 재압축" (SE = DEM 중심 구의 합집합 · AM = 얼린 장애물) | §8-1 (L297 · L303) | 표지 없음 (우리 쪽 기록) | 넘긴 시점 = DEM 압축 끝 (카드 표현) · 값 없음
- [h] lim2025_virtual_calendering_framework | DEM 이 아니라 측정 구조에서 넘김: 압축 전 (2.3 g/cm³) 전극을 FIB-SEM 으로 재구성 → 복셀 FVM 선형 탄성 압축 (넘긴 시점 = 압축 전). 선행 도구로 LAMMPS · LIGGGHTS · MATBOX · GeoDict · EDEM · MPSP-DEM 을 거명 | §3.1–3.2 (L121–145) · §1 (L79–83) | 표지 없음 | DEM → FE 인계 아님 · Li-ion 액체계
- [h] choi2024_digital_twin_review_echem | 압연 DEM 자료 → 학습 공정 모델 (ref 112) · DEM · FVM 을 상향식 구조 형성 도구로 명시 | §8.1 (L338–340) · §5.2 (L232–234) | 표지 없음 | FE · MPM 인계 아님


### [batch_02] h. DEM 에서 FE · MPM 으로 넘긴 선례와 넘긴 시점

- [h] pycompact2025_dem_mpfem_workflow | DEM (LIGGGHTS-PUBLIC 3.8 · Hertz–Mindlin · raindrop 삽입 + 중력 침강) → 입자별 FE (OpenRadioss): 넘긴 시점 = 중력 침강 직후 · 압축 전 (P ≈ 0) — 압축 (기공 41 → 4 %) 은 100 % MPFEM | §4.2 (L144–151) · Fig 1 · 2a | stated | 금속 · 3D
- [h] pycompact2025_dem_mpfem_workflow | 넘긴 것 = (x, y, z, r) CSV 하나 ("This file forms the interface between DEM and MPFEM" · "Initial powder configuration (size, center)") — 접촉 목록 · 겹침 · 접촉력 · 응력 이력 · 속도 · DEM 강성은 안 넘김 (상태변수 0) · 단위 cm → ×10 → mm · 그 자리에 완전한 구를 다시 만들어 생기는 초기 상호침투는 논문이 언급 안 함 | §4.1 (L135 · L141–142) · §4.3 (L153–167) · §4.5 (L186) | stated (인계물) + 카드 지적 | "초기 상호침투" 는 카드의 지적 (논문 무언급)
- [h] pycompact2025_dem_mpfem_workflow | 저자 문장: "Since DEM effectively manages the kinematics, the resulting configuration serves as a realistic initial configuration for MPFEM." · "achieving accurate data transfer between DEM and MPFEM stages can be challenging, and large-scale simulations remain computationally demanding." | §4.2 (L145–147) · §5-(d) (L247–248) | 표지 없음 (원문 따옴표 인용 · 카드 표기 "원문 그대로") | —
- [h] nezamabadi2022_mpm_cd_plastic_particle_compaction | 초기 배치를 DEM 으로 준비 (코드 · 접촉식 미기재) → Φ0 = 0.78 (2D 재밍 바로 아래) 부터 압축 전부를 MPM + CD 로 | §3.1 (L95) · §4.5 (L190) · §7.1 (L348) | stated (DEM 준비 · Φ0) | 2D · 넘긴 정보의 형식은 카드에 없음
- [h] alabdali2023_cgmd_wet_manufacturing_ssb_cathode | 기계 계산의 인계는 없음 (슬러리 → 건조 → 압연 모두 CGMD 안) — 압연 뒤 구조를 GeoDict 복셀 연속체 (ConductoDict · DiffuDict) 로 넘겨 수송만 계산 · voxel 크기 미보고 | §1 (L54) · §4-7 (L276–282) | 표지 없음 (voxel 은 n/a) | 수송용 인계
- [h] 우리 쪽 기록 (카드 안) | 우리 인계 시점 = DEM 300 MPa 압축 완료 뒤 (`atom_2060000`) — pycompact 와 정반대 (pycompact2025 §4.6 L212) · 11-09 1저자 결정 "MPM 은 느슨한 충전에서 시작 · SE 질량 보존 씨앗" (nezamabadi2022 §9 행동 3 L440–442) | 두 카드 | 표지 없음 | 논문 값 아님 · 두 서술의 날짜가 다름 (08-25 · 11-09)
- nguyen2017: 초기 배치 생성법은 카드에 없음 (시작 Φ′0 = 0.7 만 · L119).


### [batch_03] h. DEM 에서 FE · MPM 으로 넘긴 선례와 넘긴 시점

DEM → FE · MPM 인계 논문은 **이 배치에 없음**. 가까운 것:

- [h] cardenasbarrantes2020_rigid_deformable_mixture_compaction_nscd | DEM 인계 아님 — 강체 원판 1500 개를 기하 규칙으로 조밀 (jammed · 겹침 0) 하게 놓은 뒤, 부피 κVp 만큼을 같은 크기 · 같은 자리의 FE 원판 (92 삼각형) 으로 교체 → 고체 면적 (2D 질량) 보존. 시점 = 압축 전 (P/E → 0) | §4-2 (L198–201) · §9-3 (L495–497) | stated (절차) · 질량 보존 해석은 카드 | 2D · 강체 패킹 (DEM 접촉 계산 아님)
- [h] cardenasbarrantes2021_soft_rigid_mix_compaction_proceedings | 같은 준비를 "gently compressed to reach the jammed state" 뒤 교체로 서술 (모체는 "simple geometrical rules … to build a dense system") — 교체 뒤 다시 jam 시켰는지는 [미확인] | §3-2 (L84) · §4 (L114–115) · §3-1 (L74–75) | stated · [미확인] | 2D
- [h] cardenasbarrantes2020_rigid_deformable_mixture_compaction_nscd | 다른 카드를 가리키는 줄: `pycompact2025_dem_mpfem_workflow` = "DEM 패킹 → P ≈ 0 인계 → MPFEM, 비용 추정" · 명시적 MPFEM 환산 "≈ 연 단위" · `demirtas2021_mpfem_hollow_sphere_die_compaction` | §14 (L625–626) · §10-1 (L518) | 표지 없음 (다른 카드 요약) | 이 배치 밖 — 원 카드 확인
- [h] cardenasbarrantes2020_rigid_deformable_mixture_compaction_nscd | 카드가 적은 우리 쪽 사슬: 강체 구 DEM → DEM 끝 상태 (300 MPa) 를 받아 AM 을 얼리고 SE 만 다시 누르는 단일 속도장 MPM (한 방향 순차 연계) · 겹친 구를 합집합으로 심어 1.251 %p 를 잃음 · 1저자 11-09 결정 = "느슨한 패킹에서 출발 · 질량 보존 씨앗" | §0 (L23–27) · §8-0 (L416) · §9-3 (L495–497) | 표지 없음 (우리 쪽 기록) | 논문 내용 아님
- [h] cardenasbarrantes2022_soft_hard_grains_compaction_experiment_dic | 실험의 출발 조건 (인계 아님): "the systems were prepared loosely enough to observe the jamming transition" → φJ · ZJ 를 실험에서 뽑음 (선택법은 SM) | §4-3 (L166–170) · §11 (L381–382 · p. L022901-2) | stated | 2D 실험


### [batch_04] h. DEM 에서 FE · MPM 으로 넘긴 선례와 넘긴 시점

넘긴 선례 · 시점은 **이 배치에 없음**.

- [h] giannis2021_stress_based_multicontact_dem | 반대 방향 한 줄 (FE 로 DEM 접촉 계수를 정하자는 향후 과제): "For calibration, it would be interesting to provide these parameters by detailed finite element simulations" | §7-6 (L434–435) · §10 (L518) | 원문 인용 (outlook) | 실행 안 됨 · 이 논문에 FEM 검증 없음 (L428)
- [h] giannis2021_stress_based_multicontact_dem | 카드의 교차 기록: Varkey SI Fig S1 = 단일 접촉 FEM 을 기준으로 Thornton–Ning 을 견줌 · 공저자 Celigueta = CIMNE (DEM-FEM 계열) | §7-3 (L377–378) · §2 (L45) | 표지 없음 | 넘긴 시점 없음
- [h] coetzee2017_dem_calibration_review | DEM → FE 인계 없음. 가장 가까운 것 = Cleary [30] 멀티스케일 (거시 밀 + 국소 전단 셀 · 1-way) · Servin & Wang [148] 강체 집합체 치환 (5–50×) | 카드 §6 의 "§3.2" 요약 (L577–579) | 리뷰 stated (소환) | DEM 안의 축약
- [h] electromechanical_contact_model_particulate_systems · dmt1975_adhesion_contact_deformation · deng2021_mechanical_surface_energy_tester_bond_number | 이 배치에 없음 | — | — | —


### [batch_05] h. DEM 에서 FE · MPM 으로 넘긴 선례와 넘긴 시점

넘긴 선례 · 시점은 **이 배치에 없음**. 지목만.

- [h] gonzalez2012_nonlocal_contact_confined_granular | 논문 §1 이 정리한 대안 (카드 옮김): 전 입자를 FEM 으로 (Gethin 2003 · Procopio & Zavaliangos 2005 — 정확하나 입자 수 제한) · FEM 에서 접촉 법칙을 뽑아 DEM 에 (Harthong 2009 — 쌍 상호작용을 경우마다 특성화) · 연속체 구성모델 (Drucker–Prager 1952 · Borja & Lee 1990 — 경우별 실험 보정 뒤에만 예측적); 같은 그룹의 이산–연속 혼합 (Zheng & Cuitiño 2002 KONA 20, 168 · Koynov, Akseli, Cuitiño 2011 Int. J. Pharma. 418, 273) | §16 (L986–997) | stated (논문 §1 · 카드 요약) | 방향이 FE → DEM 인 것뿐 · 원문은 이 카드 밖
- [h] he2026_dem_calendering_inhomogeneity_areal_density | 지목만: 참고문헌 [41] Du 2025 (J. Energy Storage 138, 118688) "Force chain-induced collector damage in calendering: a DEM-FEM study" — 미digest; 계보표의 Ngandjong 2021 (GH + SJKR, FEM · 멀티스케일 디지털 트윈) | §13 N5 (L689) · §7 표 (L368) · §2 (L60) | 표지 없음 | 넘긴 시점 · 방법은 카드에 없음
- [h] jacksongreen2005_fem_elastoplastic_hemispherical_contact | DEM → FE 가 아님 — FE 단접촉 식을 거친 표면 통계 모델 (GW asperity) 에 꽂아 쓰는 것이 명시 목적 | 메타 (L22) | stated | —


### [batch_06] h. DEM 에서 FE · MPM 으로 넘긴 선례와 넘긴 시점

이 배치에 **DEM 결과를 FE · MPM 으로 넘긴 카드 없음**. 닿는 것만.

- [h] mesarovicfleck2000_dissimilar_elastoplastic_indentation | 반대 방향 (단접촉 FE → 분말 압밀용 반경험 접촉 법칙). 시점의 근거가 될 수 있는 한계: 접촉 독립 D < 0.82 · stage I 종료 D ≈ 0.8 | L28 · L123–130 | stated | 넘김 선례 아님
- [h] martinbouvard2003_dem_composite_cold_compaction | DEM ↔ 해석 모델 (Arzt / Helle eq 17–18 · Storåkers) 대조만 · DEM 유효 D ≤ 0.85–0.90 (엄밀) / 0.95 (계산) | §4 (L46 · L51) | stated | 넘김 없음
- [h] oh2026_bimodal_composite_cathode | DEM 없이 "측정 (loading · 두께 · 부피분율 · 입자 크기 · 형상) → 구조 생성 알고리즘 → GeoDict FVM · COMSOL FEM" | §2.3 (L144–158) | 표지 없음 | 압밀 계산이 아니라 측정값 재구성
- [h] kissel2026_mechanofusion_derived_cathode_composite_microstructures_scalable | DEM 은 공정 응력 (SI · SN · E_m) 만 내고 구조 계산으로 넘기지 않는다 | §4-2 (L272–279) | [인쇄 p.6] | —


### [batch_07] h. DEM 에서 FE · MPM 으로 넘긴 선례와 넘긴 시점

이 배치에 없음. 넘긴 계산을 실은 카드는 없고, 닿는 것은 아래 두 줄 (선례 아님).

- [h] so2022_dem_contact_model_assb_compaction_sintering | 저자가 DEM 안에서 고른 것: over-compaction 을 막는 문헌의 Voronoi 방법 (다면체 부피로 국소 면적 추정) 은 "계산비용 큼" → 겹침 상한으로 대체 | §4.6 (L163) | stated (카드의 우리말 옮김) | FE · MPM 아님
- [h] paulick2015_elastic_particle_properties_dem_review | 우리 쪽 기록: "300 MPa 에서는 실물 모듈러스를 그대로 써도 이 가드레일을 못 지킨다 → 탈출구는 (i) 항복캡 접촉법칙 (ii) 진짜 형상 소성 = MPM" | §10-(b) ③ (L848–856) | DERIVED-BY-US 에 근거한 카드 판단 | 논문 문장 아님


### [batch_08] h. DEM 에서 FE · MPM 으로 넘긴 선례와 넘긴 시점

**넘긴 선례는 이 배치에 없음.** 닿는 것:

- [h] varkey2026_multicontact_elastoplastic_dem | DEM 접촉 법칙을 FE (Ansys Mechanical · 변형체 구 3 개) 로 검증 — 넘긴 것이 아니라 같은 조건의 대조 | Supplementary (L88–99) | 표지 없음 | 일반 재료 · 3 입자
- [h] thorntonning1998_adhesive_elastoplastic_contact | 균일 p_y 압분포 가정을 다른 논문의 FE (Hardy et al. [8] · Sinclair et al. [9]) 로 정당화 | §6 (L186–188) | stated (인용) | 단일 접촉
- [h] storakers1997_similarity_inelastic_contact | 방향이 반대인 계보: 연속체 단접촉 해 (자기상사 + FE) → Storåkers 1996 → Martin–Bouvard 2003 DEM 의 접촉 법칙 (eq7–8) | §2 (L22) · §8.2 (L174–182) | 카드 계보 서술 | 넘긴 시점 개념 없음
- [h] tovar2026_cold_spray_cathode_composite_dem_plastic_elastic_bond | (우리 쪽 기록) SE 1 µm 입자를 하위 구 10²–10³ 개로 풀면 침대 SE 32,832 개 → 3 × 10⁶–3 × 10⁷ 구 = 비용 장벽 → "MPM scaffold 커플링 선택의 근거가 하나 더" | §7 ④ (L277) | 우리 산수 | 논문 주장 아님


### [batch_09] h. DEM 에서 FE · MPM 으로 넘긴 선례와 넘긴 시점

DEM → FE · MPM 으로 넘겨 이어 계산한 선례는 **이 배치에 없음**.

- [h] zunker2025_dem_large_deformation_compaction | 반대 방향 — FE 배치를 DEM 으로 복제: MPFEM 셋업의 입자 좌표 · 반경을 정확히 복제해 LAMMPS 에 넣고 (압축 전 초기 배치) 같은 벽 운동으로 세 방향 응력을 대조 · XCT 수입은 세 논문 어디에도 없음 | §3-3 (L103–104) · §10 (L358–360) | stated | 14 / 12 입자 · 넘겨서 이어 계산한 것이 아니라 같은 출발 상태의 대조
- [h] zunker2025_dem_large_deformation_compaction | 형상 대조: DEM 상태 변수 (R · δ_max) 로 변형 형상을 재구성해 FEM 형상과 비교 — 삼축 단일 입자 (δ_o/R_o 0.15 · 하중 제거 뒤) · MPFEM 침대 안 한 입자 (최대 압축 시점 · 접촉 패치 5 개 모두 나타남) | §6 (L227–233) · Fig 7 | stated (정성 · "good agreement") | 비교일 뿐
- [h] xu2017_nmc532_nanoindentation_modulus_hardness_toughness | 실험 값 → DEM 입력 선례: Sangrós 2020 이 이 논문을 [32] 로 인용해 E_NMC 142.5 → 111.6 을 DEM 입력으로 씀 | §7-1 (L335–337) · §13 (L502) | 표지 없음 (다른 카드 기록) | 이 카드에서 확인 불가


### [batch_10] h. DEM 에서 FE · MPM 으로 넘긴 선례와 넘긴 시점

**역학** 을 FE · MPM 으로 넘긴 선례는 없음. DEM 으로 만든 눌린 구조 위에서 **수송 · 전기화학** 을 연속체로 푼 선례 3 (모두 압축이 끝난 뒤 넘김).

- [h] bazzoun2026_dem_fem_rnm_ionic | DEM (LIGGGHTS) 압밀 구조 → SE 상 추출 · 메싱 → COMSOL FEM 정상상태 전도 (∇·J = 0 · Dirichlet 1 V / 0 V · 절연 Neumann · GMRES) 와 같은 구조 위 저항망 RNM 을 나란히. 넘긴 시점 = 압밀이 끝난 뒤. 비용 FEM 2551–3352 s ↔ RNM 26–105 s (32–98 배) | §4 (L27 · L34–38) · §6 (L66 · Table 5) | 표지 없음 | 수송만 · 조성당 실현 10 개
- [h] kim2024_optimal_cathode_composite_mechanical_mixing_se_coverage | DEM (200 MPa 압축) → A* 최단 경로로 이온 퍼콜레이션 이용률 (CUE) → 같은 3D 구조 위 FEA (Fick + 전하 보존 + Butler–Volmer + 확산 변형 선형 탄성 · 1 C · 롤러 경계 x · y = 0 · 16 µm). 넘긴 시점 = 압축 뒤 | §0 표 ⑤ (L30) · §3-4 (L118–128) · 논문 SI p.2–6 | [인쇄] | FEA 는 SE 소성 없음 · 코드 [미확인] · 압밀 역학을 넘긴 것은 아님
- [h] faka2026_particle_size_consolidation_strain_lpscl | DEM (11 µm · 0.1–1.0 GPa 의 구조) → GeoDict 복셀 확산: σ_sim = σ_bulk (2.0 mS/cm) × D_ion/D_bulk = 0.1 GPa 1.30 → 0.3 GPa 1.78 → ≥ 0.6 GPa 1.94–1.95 ↔ 실험 0.96 → 1.68 → 2.04 → 1.85 mS/cm | §3-6 (L115) · 논문 p.12 · Fig 1c | 식 = [인쇄] · 값 = [판독] | 접촉 저항 없음 · 대조는 11 µm 하나
- [h] minnmann2024_microstructure_porosity_visualization | (DEM 아님) 실제 토모 재구성 구조 → GeoDict ConductoDict flux · Pytrax random-walk tortuosity. 저자: "we use geometric reconstructions of *actual* cathodes and do not generate digital twins by any statistical or stochastic methods." | §4 (L86–88) | 카드가 "본문 명시" 로 옮긴 인용 | 구조를 만드는 모델이 아니라 잰 구조의 후처리
- [h] frankenberg2025_milling_dry_processed_sulfide_cathode_microstructure | (넘김 아님) 볼 DEM 은 충돌 에너지 지표 (E_col · f_col → E_m) 만 주고 미세구조를 푸는 모델은 없음 | §4-2 (L224) · §7-4 (L303) | 표지 없음 | —


### [batch_11] h. DEM 에서 FE · MPM 으로 넘긴 선례와 넘긴 시점

역학을 DEM 에서 FE · MPM 으로 넘긴 선례는 이 배치에 없다. 수송 계산만 연속체로 넘긴 선례 = 1.

- [h] schneider2023_particle_size_pressure_transport | DEM (BACI) 으로 압밀한 입자 위치 · 반지름 → 복셀 구조 → 유한체적 (BEST) 정상 전류 (∇·J = 0 · J = −σ∇φ) → 정규화 σ_eff. 넘긴 시점 = 압력 점마다의 압밀 구조 (Scenario I = 일정 stack 압 · II = 성형압 변화) · 역학은 끝까지 DEM | §4 (L68–70 · L78–86) · §6 (L123) · §A-3 (L185–188) | 표지 없음 (카드 서술) | 수송 전용 · 접촉 협착 항 없음 · t-Li₇SiPS₈
- [h] park2020_dimension_controlled_se_percolation_contact_area · schlautmann2023_se_particle_size_composite_transport | DEM 없이 기하 생성 (GeoDict 무작위 배치) → 복셀 전도 해 → (park 는 COMSOL P2D 에 σ_eff · a_s · ε · 두께 입력) — DEM 선례 아님 | park §4.1 (L231) · schlautmann §4g (L193–194) | stated | 압밀 역학 없음
- [h] otani2025_dem_se_dispersion_aggregation_compression | 다른 카드 `lee2024_multiphysics_dem_fem_initial_pressure_assb` 의 이름만 나옴 (굴곡도 식 τ = −11.7·ε_SE + 8.54 의 출처가 Otani 2023 이라는 계보) — 넘긴 방법은 이 카드에 없음 | §0 (L25–32) | 표지 없음 | 해당 카드 참조


### [batch_12] h. DEM 에서 FE · MPM 으로 넘긴 선례와 넘긴 시점

DEM → FE 선례 둘 — 넘긴 시점이 정반대다 (느슨한 충전 직후 ↔ 압축 · 제하가 끝난 뒤). DEM → MPM 선례는 이 배치에 없음.

- [h] demirtas2021_mpfem_hollow_sphere_die_compaction | DEM (중력 랜덤 다이 충전 · Abaqus) → 입자 중심 좌표를 Python 으로 옮김 → 입자별 FE 가 압밀 전 과정 (+ 제하) 을 계산. 넘긴 시점 = **느슨한 다이 충전 상태** (초기 RD 23.5–45.3 %) — 압밀은 DEM 이 전혀 하지 않음. 원문: *"The model was generated in a three-step process by coupling DEM and traditional FEM. In the first step, a gravity forced random die filling simulation was carried out using the DEM approach. In the second step, the coordinate of each particle center was extracted from the DEM simulations and used as the initial particle configuration for the MPFEM. Finally, the powder compaction simulation was run by using MPFEM."* | §4-1 (L243–256) · §4-2 (L262–270) · 논문 p.36 | stated | 중공 고분자 구 · 단일 크기 · DEM 정지 판정 = *"first 2000 particles were settled"* (평균 변위 plateau) · 같은 외경 모델들에 같은 DEM 배치를 재사용
- [h] benhadjali2026_wip_vs_cup_pressing_assb_cathode_dem | DEM (슬러리 → 건조 → 변위 제어 가압 → 유지 → 제하 → 이완) → 0.2 µm 복셀 → 메시 → COMSOL FEM (선형 탄성 + 고유변형). 넘긴 시점 = **가압 · 제하 · 이완이 끝난 최종 기하**. 넘긴 것 = 기하만 — *"No additional particle displacement, artificial densification, isotropic rescaling, or phase redistribution"* · 제조 잔류 응력은 안 넘김 (FEM 출발 응력 0) | §3-8 (L165) · §4-3 (L246) · §8-0 EM-07 (L355) · 논문 p.21 | [인쇄] | FEM 은 압밀을 풀지 않음 (사이클 응력용) · 물성 [미확인] · 프리프린트
- [h] yano2026_se_psd_width_ionic_tortuosity_dem · so2021_dem_mold_pressure_assb_coldpress · sangros2019_dem_calendering_lib_electrode · sangros2020_lib_electrode_dem_mech_elec_ionic | DEM 만 (FE · MPM 없음) | — | — | —


### [batch_13] h. DEM 에서 FE · MPM 으로 넘긴 선례와 넘긴 시점

DEM 의 가압 역학을 FE · MPM 으로 넘긴 선례는 이 배치에 없다. 있는 넘김은 CGMD → DEM → (복셀화) → FEM 전기화학 · X-CT → DEM · 건조 DEM → 압연 DEM (같은 코드) · DEM → 복셀 솔버.

- [h] ngandjong2021_dem_calendering_digital_twin | CGMD (건조 구조 · 압입 · 크기 수렴 시험 때만 x · y 각 4 배 복제) → DEM (압연) → 자체 복셀화 (INNOV) → COMSOL FEM (4D 전기화학 · EIS). 넘긴 시점 = 압연 뒤 (복귀 · 완화 뒤) 구조 세 개 (ε 41.6 / 31.5 / 27.2 %) · 메시 25.8 × 25.8 × {165.0 · 141.6 · 133.8} µm³ · 각 > 800,000 요소 · τ 는 0.25 µm 복셀 (GeoDict) | §4 (L276–278 · L303) · §5 Fig 7A (L472) | stated | FE 로 넘긴 것은 전기화학이지 가압 역학이 아님 · 넘길 때 생긴 인공물 = 건조 모델은 z 주기 · 압연은 z 비주기 → 압연 전 구조의 집전체 접촉 면적이 오히려 큼 (저자 인정 · L332–334)
- [h] zhang2026_xct_dem_cathode_calendering_peel_calibration | FE · MPM 으로 넘긴 것 없음. 넘김은 실험 → DEM 한 번: Ebner 2013 싱크로트론 X-CT (분할이 끝난 미압연 전극 · 입자별 좌표 · 부피) → 같은 부피의 구 → 100 × 100 × 75 µm³ 부분 체적을 DEM 초기 구조로 (CBD 는 2.2 µm 구를 따로 채움 · 간격 3.3 µm 까지 bond 로 묶음). 논문이 인용한 선례 = Ge 2022 (ref 18) | §2.5 (L96–100 · L104) · §4.4 (L298–301) | stated · 선례는 "이 논문이 인용한 내용" | 구조 (Ebner 전극) 와 실험 전극 (자체 NMC111) 이 다른 전극 (L465) · 가압 전 (미압연) 시점에 넘김
- [h] xu2023_realistic_am_shape_cgmd_calendering | FE · MPM 으로 넘긴 것 없음 (전기화학 FEM 도 없음). 넘김은 두 번: ① 실험 → 모의 = µ-XCT 분할 → watershed 로 2차입자 낱개화 → 형상 DB → 무작위 추출 · 회전 · 배치 ② 모의 → 복셀 솔버 = 압연 해제 · 완화 뒤 구조를 0.25 µm 로 복셀화 → AM 상을 N 복셀 팽창 뒤 원래 부피까지 침식 (N = 2) → TauFactor · PNM · 타원체 피팅 | §4-B-1 (L414–422) · §6 (L541–556) | stated | ② 에서 N 을 τ 표적에 맞춰 골랐다고 SI 가 적음 (§6-B) — 넘길 때의 표현 규약이 결과를 바꿈
- [h] lyu2025_3d_dem_drying_calendering_lib | FE · MPM 으로 넘긴 것 없음. 같은 DEM 코드 (PFC3D) 안에서 건조가 끝난 구조 (구조 · 접촉 · bond) 를 그대로 압연의 초기 조건으로 넘김 — 논문 동기 (카드의 한국어 옮김): 선행 DEM 압연 모의는 건조 구조를 초기 상태로 거의 안 쓰고 랜덤 생성 구조를 써서 압연 분석에 부적절 | §2 (L22) · §4 (L74 · L78) | 표지 없음 (카드의 한국어 옮김) | 역학 → 전기화학 넘김도 없음 (전도도 솔버 없음)
- [h] miss2026_insitu_conductivity_porosity_pressure_compaction · miss2026_pressure_tortuosity_composite_cathode_coating | 이 카드들에 없음 (시뮬레이션 없음) | — | — | —


### [batch_14] h. DEM 에서 FE · MPM 으로 넘긴 선례와 넘긴 시점

선례 = **1** (lee2024: DEM → FEM · 균질화 스칼라 · 압밀이 끝난 압축률 상태에서 한 방향). so2022 는 압밀 끝 구조를 격자 수송 계산으로만 넘긴다.

- [h] lee2024_multiphysics_dem_fem_initial_pressure_assb | DEM (Ansys Rocky 4.5) → FEM (COMSOL 6.0 · 전기화학 – 역학 결합) 한 방향. **넘긴 것** = 균질화 스칼라: 압축률 · 압축률에 따른 유효 영률 · 부피분율 · 표면적 S_a = 3ε_AM/R_p (식 34) · 굴곡도 τ = −11.7·ε_SE + 8.54 (식 38). **넘긴 시점** = DEM 압밀이 정한 압축률 (0.7 · 0.5) 상태 — 그 뒤의 외부압 (0 / 10 / 50 / 100 MPa) · 충방전 · 인터칼레이션 부피 변형 응력은 FEM 이 품 · 되먹임 없음. 저자 주장 "DEM+FEM 동시 예측은 처음" | §1 L22–23 · §4.1 L98–113 · §4.3 L158 · L163–166 · Fig 1 | stated · 식 38 의 출처 귀속 [미확인] (카드 정정 2026-10-13) | 입자 위치가 아니라 유효 물성만 넘김 (카드: 입자 정보 소실) · LGPS + LLZO · 실험 검증 없음 · DEM (graphite 14 · NMC 12 µm) 과 FEM (10 · 5 µm) 의 입경이 다름
- [h] so2022_dem_compaction_coated_particles_assb | DEM 입자 → 3D 격자 매핑 [30] → TauFactor (라플라스 확산) 로 SE 상 · AM 상의 τ — 압밀 끝 구조를 격자 수송 계산으로 넘긴 선례 (역학을 FE · MPM 으로 넘긴 것은 아님) · 주기 (PBC) · 비주기 두 판을 계산했고 비주기가 FIB-SEM 실험 (Nakamura) 과 더 잘 맞음 | §4.3 L108 · Fig 7 | 표지 없음 | 격자 해상도는 카드에 없음 · σ 값은 내지 않음 (τ 와 퍼콜 부피만)
- [h] nisar2024_dem_effective_electrical_conductivity_sps | FE · MPM 으로 넘기지 않음. 소결 DEM (열 – 점탄성 모델 [43]) 을 중간중간 멈춰 여러 기공률의 기하를 뽑아 같은 DEM 틀의 저항망에 넣음 · 연속체 비교는 [20] FEM 열전도 인용으로 대체 | §4 L59–62 · L66 | 표지 없음 | —
- [h] kang2026_intertwined_electrochemo_mechanical_sulfide_assb_review | 인용만: phase-field (ref 39) · FEM 으로 균열 · 응력 — DEM 에서 넘긴 선례는 아님 | §6.1 L166 · §12 L333 | 2 차 인용 | —
- [h] doux2020 · sakuda2013 · kakar1967 · deysher2022 | 이 카드에 없음 | — | — | —


### [batch_15] h. DEM 에서 FE · MPM 으로 넘긴 선례와 넘긴 시점

DEM 에서 넘긴 선례는 **이 배치에 없다** (DEM 을 쓴 카드 0). 닿는 것:

- [h] cronk2026_lis_positive_electrode_geometry_fem | 생성 기하 (DEM 아님) → FE 로 넘긴 사슬: MATLAB 확률적 voxel 기하 (S = 구 · 탄소 = aggregate · 기공 10 vol% 입력) → Iso2Mesh 로 사면체 메시 → COMSOL 6.1 Solid Mechanics. 넘기면서 기공을 지움 (*"the electrode was assumed to be **fully compact (no porosity)**"*) · 박스도 25 / 10 µm 로 그려져 생성 상자 (50 / 15 µm) 와 다름 (본문 언급 없음) | §3.2 L97 · §4.1 L207 · §4.4 L241–245 · §9 L618–622 | stated (인용문) · 박스 불일치는 카드 관찰 | 넘긴 시점 = 생성 직후 (압밀 없음) · 넘길 때 기하가 바뀌었는데 어느 상이 기공을 흡수했는지 미기록
- [h] bielefeld2019 → bielefeld2020 | 같은 무작위 배치 기하 위에서 percolation 세기 (2019) → 복셀 연속체 flux 풀이 (2020) 로 넘어감 — *"We use the AM microstructures generated in our **previous work**"* | bielefeld2020 §2.1 L105 | stated (인용문) | DEM · 역학 아님 (수송 솔버만 더함)


### [batch_16] h. DEM 에서 FE · MPM 으로 넘긴 선례와 넘긴 시점

**역학 계산을 DEM 에서 FE · MPM 으로 넘긴 선례는 이 배치에 없다.** 가까운 것:

- [h] galvezaranda2024_time_dependent_dl_calendering_microstructure | DEM 입자 좌표 → 복셀 격자 (0.4 µm · 라벨 pore / CBD / AM / void) → GeoDict DiffuDict 유한체적 확산 (x · y 주기 · z 양끝 농도 고정) — **수송 계산용 넘김** (역학은 끝까지 DEM) · 넘기는 시점 = 프레임 (75 µs) 마다 복셀화 · 상류는 CGPD (슬러리 + 건조) → DEM 압연의 초기 구조 | §4-1 L176 · §4-2 L198–203 · §4-4 L250–253 | stated | LIB · 넘김의 함정: 복셀 라벨 기공률이 표의 기공률과 어긋나고 (프레임 0 에서 22.6 ↔ 31.09 % · 완화 뒤 2.7 ↔ 19.07 %) AM 복셀 수가 −22.3 % 까지 줄었다 되돌아옴 (L525–541 · digitized — TREND only)
- [h] duquesnoy2020_calendering_ml_mesostructure_generator | 선례 아님 (참고): 같은 그룹이 2020 확률 생성기 → 2023 에 CGMD 슬러리 → 건조 → DEM 압연 사슬 + GeoDict 로 교체 | §14 L478–489 | 카드 서술 (다른 카드 요약) | 역학 넘김 아님
- [h] hamann2026 · hlushkou2018 · islam2026 | DEM 없음 — 영상 (FIB-SEM) 또는 phase-field 미세구조 → 복셀 / FEM 수송 계산 | hamann §4.1 L178–182 · hlushkou §3-C L103–111 · islam §4 L41–60 | stated | 역학 계산 없음


### [batch_17] h. DEM 에서 FE · MPM 으로 넘긴 선례와 넘긴 시점

DEM 에서 넘긴 선례 = **0**. 닿는 것은 "3D 구조 → 유효 물성 → 1D 전기화학" 으로 넘긴 한 건이다.

- [h] kim2026_a3d_air_electrode_microstructure_transport | DEM 아님 — CAD 단위셀 (STL) → 복셀 (GeoDict) → 유효 물성 (기공 · 비표면적 · σ_e · σ_ion · D_O₂) → 1D FEM (COMSOL) 로 넘긴 선례. 넘긴 시점 = 고정된 구조에서 유효 물성을 뽑은 뒤 · 구조에서 못 얻는 동역학 값은 문헌 + 실험 방전 곡선에 맞춰 고정 | §2.1 L134–165 · §2.2 L226–231 · Table S2 L233–257 | 표지 없음 | Li–O₂ · 압력 · 입자 없음
- [h] ketter2025_resistor_network_models_predict_transport_properties | DEM 아님 — 계산용 미세구조는 합성 (복셀 클러스터 무작위 삽입) 이고 FIB-SEM 도 DEM 도 아님 | §4-3 L171–176 | stated | —
- [h] 그 밖의 카드 | 이 배치에 없음 | — | — | —


### [batch_18] h. DEM 에서 FE · MPM 으로 넘긴 선례와 넘긴 시점

**이 배치에 없음** — DEM 을 쓴 카드가 없다. 닿는 것은 "눌린 구조를 계산하지 않고 재서 (FIB-SEM) 복셀 수송으로 넘긴" 두 건이다 (우회의 성격은 l 에).

- [h] lee2026_unveiling_ptfe_dry_electrode_digital_twin | DEM 아님 — 370 MPa 로 누른 전극 → FIB-SEM 500 장 → U-Net 분할 → 복셀 FVM (σ_e · σ_ion) → 반쪽셀 2 C 시뮬 (25 µm). 카드 분류: 측정 재구성 = 하향식 ↔ 우리 DEM + MPM = 상향식 | §4-1–4-5 L237–257 · §4-8 L267 | [인쇄] · 카드 서술 | 구조를 만드는 단계의 계산 없음
- [h] nakamura2020_dry_coating_ncm_li3ps4_core_shell | DEM 아님 — 360 MPa 반쪽셀 (50 회 뒤) → FIB-SEM 100 장 → 네 상 분할 → 복셀 Poisson (σ_eff/σ_B · τ) | §3-6 L124–125 · §4-1 L192 | [인쇄] | —
- [h] 그 밖의 카드 | 이 배치에 없음 | — | — | —


### [batch_19] h. DEM 에서 FE · MPM 으로 넘긴 선례 · 시점

- [h] sangros2020_dem_electrical_conductive_paths_assb | DEM → (FE · MPM 아님) 그래프 후처리: 목표 부피분율에 닿아 멈춘 **마지막 구조 하나**를 입자 파일 (ID · 반경 · 위치) + 접촉 파일 (쌍 · 접촉면적) 로 내보내 Python A* · 등가회로 (σ_e) · MATLAB skeleton (τ) 로 넘김 | §4.1 L61–63 · §4.6 L103 | stated | FE/MPM 선례 아님 · 압밀 중간 상태는 넘기지 않음
- 나머지: 해당 없음.


### [batch_20] h. DEM 에서 FE · MPM 으로 넘긴 선례 · 시점

DEM → FE · MPM 넘김 선례 없음. 관련 음성 사례만.
- [h] vijay2025_hybrid_cgmd_dl_slurry_microstructure | 사슬 = 슬러리 CGMD → 건조 CGMD → 압연 DEM; DL 예측 좌표를 바로 NEMD 에 넣으면 입자 손실 → CGMD 평형화 1 스텝 필수 · 카드가 옮긴 저자 귀속 *"예측 위치가 서로 너무 가까워 겹침 → 입자간 힘 불균형 → 내부 충돌"* · 평형화는 겹침만 풀고 중거리 구조는 못 고침 (Fig 7a) | §3-3 L133 · §5-5 L380–382 · §5-4 L360–361 | stated (한국어 옮김) / figure-read ≈ | 입자 → 입자 (FE · MPM 아님)
- [h] zhang2026_dryprocess_electrode_architecture_cell_level | CGMD 출력이 COMSOL 입력이 되지 않는다 — CGMD 상자 (AM 없음 · 압밀 없음) 와 COMSOL 대상 (PFIB 실물) 이 달라 "공정 → 구조" 와 "구조 → 성능" 이 다른 대상 위에서 따로 성립 | §4-0 L531–535 | 카드 풀이 | 넘김 없음
- [h] wang2027_ncm811_effective_bulk_modulus_mapper_dfs_gnn | 영상 → 복셀 FE (DEM 을 거치지 않음 · 압축 물리 없음) | §4-1 L217 · §4-2 L222 | 카드 풀이 | —


### [batch_21] h. DEM 에서 FE · MPM 으로 넘긴 선례 · 넘긴 시점

- [h] duquesnoy2023_ml_multiobjective_manufacturing_optimization | DEM 압연이 끝난 구조 → MATLAB 메싱 → GeoDict (σ_e · 복셀 연속체) · TauFactor (τ · Laplace FV) · Python (active surface · density · porosity) — 넘긴 시점 = 압연 DEM 끝 (과정 결합 없음) | §4.6 L183–188 · §4.1 L120 | stated | 넘긴 곳 = 복셀 연속체 수송 (역학 FE · MPM 아님) · 액체 LIB
- [h] asylbekov2023_cb_fragmentation_pbe_dem_dry_mixing | DEM → PBE 단방향 · 1 회 — DEM 은 최적화 루프 밖에서 한 번만 돌아 응력 분포 σ̄ 와 비빈도 ṅ(σ̄) 두 통계만 넘김 · CB 분쇄가 분체 거동을 바꾸는 되먹임 없음 (저자도 결론에서 문제로 지적) | §4.0 L231–233 · §4.1 L237–253 | stated | FE · MPM 아님 · 크기 공간 0D
- [h] bak2024_binder_distribution_multilayer | (DEM 아님) GeoDict GrainGeo 로 설계한 구형 NCM 골격 + stochastic CBD → ConductoDict | §2.6 L151–157 | 표지 없음 | 넘김 선례 아님 (설계 구조 입력)


### [batch_22] h. DEM 에서 FE · MPM 으로 넘긴 선례 · 넘긴 시점

이 배치에 DEM → FE · MPM 선례 없음. 관련만:
- [h] galvezaranda2025_paml_vgg16_dem_slurry_drying | DEM (+DL) 구조 → 복셀 (76 × 76 × 124 · 0.4 µm · 라벨 0 pore / 1 CBD / 2 AM) → GeoDict DiffuDict FV 로 D_eff · τ (z 방향 0↔1 mM Dirichlet · x·y 주기 · 프레임마다 후처리) | §3-A L93–96 · §4-5 L308–319 | stated | FE · MPM 아님 · 공극상 Fick (액체) · τ 규약 = ε / D_eff (카드: 규약 확인 필수 · L728–729)
- [h] hong2026_sulfide_cathode_binder_digitaltwin | 측정 (조성 · BET · porosity) → GeoDict GrainGeo 확률 재구성 → ConductoDict FV (상 · 하면 전위차 1 V) 로 current density · coverage | §2.4 L114–124 | 표지 없음 | DEM 에서 넘긴 것 아님 (재구성 · 고정 형상)


### [batch_23] h. DEM 에서 FE · MPM 으로 넘긴 선례 · 넘긴 시점

이 배치에 DEM → FE · MPM 선례 없음. 관련만:
- [h] kang2026_multiscale_inverse_design_ptfe_fibrillation_dry_electrode | 거시 유동 FEM (반죽기 · 압출기 · 멱법칙 유체 K · n 미기재) 의 전단 응력 → 미시 FEM 의 경계 하중 PLP 로 넘김 — "Shear rates obtained from macroscale simulations were subsequently converted into PLP values" (환산식 미기재) · 실물 PLP 측정 없음 | §3-5 L144 · §10-15 L356 · §4-1 L206 | [인쇄] · [미확인] | 거시 → 미시 하중 넘김 (DEM 아님) · 넘김 규칙 없음
- [h] kim2026_charge_engineered_cnf_binder | 실측 매개변수 (τ · OCV · 저항) → 다공전극 PDE (GA 100 회 매개변수 추정 → 확률밀도) | §4.5 L264–266 | 표지 없음 | 측정 → 연속체 전기화학 (DEM 아님)


### [batch_24] h. DEM 에서 FE · MPM 으로 넘긴 선례와 넘긴 시점

이 배치에 없음 (DEM → FE · MPM 을 한 카드 없음). 관련만 (DEM 없이 FE · 복셀 기하를 만든 선례):
- [h] lee2026_li_underlayer_primer_free_dry_prelithiated_thick_anode | FEM 기하 = Blender 4.3 으로 Si · C 입자를 "sequentially stacking … within a 50 μm thick domain" → COMSOL 메시 · 압밀 없음 · 접촉은 메시로 붙어 접촉 저항 항 없음 | §3-7 L173 · §4-3 L190 · SI p.4–5 | [인쇄] (방법) · [추정] (CONTACT_FREE 범주) | 영역 50 µm ↔ 실제 63–65 µm · 물성 · 입자 수 미기재
- [h] koo2025_cnt_wrapped_sc_nca_dry_cathode · koo2026_swcnt_sheath_thick_electrode | 측정 구조 (FIB-SEM 토모) → 분할 → 복셀 균질화 · PNM · 1D 전기화학 — 카드: "토모는 이미 압축된 전극" · 압력 → 구조 예측 없음 | koo2025 §4 L199–212 · koo2026 §5 L238–252 · §9(e) L531 | 표지 없음 | 출력단 재구성 · 압축 경로 없음


### [batch_25] h. DEM 에서 FE · MPM 으로 넘긴 선례 · 넘긴 시점

DEM → FE · MPM 으로 넘긴 선례는 이 배치에 없음. 관련만:
- [h] lippke2023_dem_drying_structure_formation_lib | DEM ↔ 1D 건조기 열 · 물질 모델 반복 커플링 — 넘기는 스칼라 = 구간별 막 수축률 (선형 피팅) ↔ DEM 최종 두께 · DEM 이 넘기는 시점 = 층–액면 간격이 최대 입자 직경 이상이 된 순간의 두께 · 초기 추정치로 반복 · 수렴 기준 · 반복 횟수 미제시 | §4.7 L378–388 · §4.8 L401–403 · §B-1 L559–566 | stated · 카드 판정 | 공정 모델 커플링 (FE · MPM 아님)
- [h] lippke2023_dem_drying_structure_formation_lib | 설계 목표 = Sangrós 압연 DEM 과의 커플링 (iPAT 건조 → 압연 사슬) · Outlook ④ 압연 DEM 커플링 · 카드 §C 가 본문 §1 이 선행으로 인용한 Ngandjong 2021 을 "CGMD + DEM + FEM" 사슬로 소개 (넘긴 시점 이 카드에 없음) | §2 L80 · §D-9 L704–706 · §C L661 | stated · 카드 표 | 다른 카드 정보 · 시점 없음


### [batch_26] h. DEM 에서 FE · MPM 으로 넘긴 선례와 시점

- [h] qin2026_bilayer_cathode_cgmd_dem_graded_thick_electrode | 인용만: ref [45] Lyu · Dong · Guo 2026, IJMS 322, 111716 "Calendering behavior of two-layer electrodes: A coupled DEM–FEM framework" (정본 카드 없음 · 원문 미확인); 자체 = DEM 구조를 자체 Python 으로 복셀화 → GeoDict (τ_z · 상분율 · 정규화 σ_z — 수송, 기계 아님) · 시점 = 캘린더링 · 제하 뒤 (c40 제하 후 ≈68 µm) | §0 줄 40 · §6 줄 353 · §4.1 줄 270 | stated · [미확인] | 기계 넘김 없음
- [h] sankar2026_fiber_scale_dem_carbon_felt_manufacturing | 단계마다 DEM 구조 → 섬유 중심선 재구성 → GeoDict `.gad` (GeneralCurvedCircularFiber) → PSD · 최대지름 경로 · 확산 (기계 넘김 아님) · 시점 = 각 단계 뒤 (캘린더링은 되튐 뒤 평형 구조) | §4.8 줄 346–351 · §3.7 줄 240 (p.16 · p.18–19) | stated | 수송만
- [h] nam2026_primer_layer_dry_electrode_collector | AFM 실측 지형 정적 import + 입자 적층 · 패킹 (실제 밀도 맞춤) → Ohm 전도 해석 · 압축 (라미네이션 · 캘린더링) 시뮬 없음 · 패킹 방법이 DEM 인지 카드에 없음 | §5.1 줄 283–292 | stated · 카드 해석 | 기계 해석 없음


### [batch_27] h. DEM → FE · MPM 넘김 선례 · 시점

이 배치에 없음 (DEM → FE · MPM 역학 넘김 선례 없음).  인접 근거 (DEM → 복셀 수송 넘김):
- [h] sun2026_dem_extrusion_recirculation_dry_electrode | DEM 구조 → GeoDict 복셀 (기공 · τ · D_eff · σ_e): 출구 Sample 1 을 1 M Δt 마다 잘라 계산 · 미세구조 분석은 10 M Δt 부터 · 비교는 30–70 M Δt 산술평균 | §3 라 줄 114 · §6 줄 288 · 297 | stated | 역학 넘김 아님 · 복셀 해상도 미보고 · D_eff 숫자는 카드 '인용 금지'
- [h] wet_processing_resolved_am_ssb_cathode_manufacturing | DEM 구조 → GeoDict (DiffuDict 이온 · ConductoDict 전자) 를 압연도마다 다시 계산 (case-by-case) · 그 상태가 roll 후퇴 (springback) 뒤인지 카드에 명시 없음 | (7) 줄 251 · §6 줄 115 · 119 | stated | 역학 넘김 아님 · 접촉 · 계면 저항 항 없음


### [batch_28] h. DEM 에서 FE · MPM 으로 넘긴 선례와 넘긴 시점

이 배치에 DEM → FE · MPM 기계 넘김 선례 없음.
- (가까운 것) [h] dem_mechanical_stresses_ssb_electrode_cycling | 단계마다 (일축 · relax · 등방 · D1–C5) DEM 입자 → 복셀 (0.5 µm) → GeoDict 수송 (σ_el · τ) | §4.7 줄 168–169 · §7 줄 243 | stated | 수송만
- (가까운 것) [h] intergranular_cracking_nmc811_jmca2023 | X-ray CT 실입자 형상 → Rhino Voronoi 400 1 차입자 (+ 20 µm CBD 껍질) → COMSOL phase-field (영상 → FE) | §4-B 줄 136–138 | stated | DEM 아님
- (가까운 것) [h] gandla2026_layered_cathode_degradation_diagnostics_review | 단층촬영 미세구조 → 메조 화학-기계 모델 [104] · 전망 3 단계 (MLIP → FIB-SEM/XCT 또는 GAN 형상 위 메조 모델 → 셀 트윈) · 카드 [추정]: 공정 모의 (DEM 압축) 가 형상을 만드는 길은 목록에 없음 | §3-5 줄 121 · §3-11 줄 209 · §7-1 줄 315 | [인쇄] · [추정] | DEM 아님


### [batch_29] h. DEM 에서 FE · MPM 으로 넘긴 선례 · 넘긴 시점

이 배치에 없음. (so2021 은 DEM 안에서 냉간 제조 → 사이클 두 단계를 잇고 FE · MPM 으로 넘기지 않는다 L150–159 · 저자 미래 과제 = 다구 (multisphere) 비구형 · DEM + 반응 / 물질전달 결합 (위상장 반응) · 취성 재료 확장 L219.)


### [batch_30] h — DEM 에서 FE · MPM 으로 넘긴 선례 · 시점

- [h] kim2024_digital_twin_acsenergyletters | "To effectively simulate the internal distribution and morphology, computational techniques like the discrete element method (DEM) and finite volume method (FVM) are employed to model particle interactions and the morphological changes under compression." (p.5230) · "Dynamic modeling techniques, such as DEM and coarse-grained molecular dynamics (CGMD), were used to create 3D electrode structures and perform microstructure-resolved performance predictions, thereby unveiling the influence of drying conditions and calendering degree" (ref 50, 104 · p.5230) | §4.2 (줄 229–233) · §5 (줄 301–304) | 원문 인용 (카드) | 넘긴 시점 · 넘긴 방법 카드에 없음 · ref 50 · 104 원문 미확인
- [h] park2020_digitaltwin_assb_foundational · lee2023_sicspe_digitaltwin_assb | DEM 아님 — GeoDict GrainGeo 로 놓은 구조를 그대로 voxel 유효 σ (EJ / ConductoDict) 와 BESTmicro 전기화학에 넘김 | park2020 §2 · §4 · §7 · lee2023 §2.3–2.4 | stated | DEM → FE 선례 아님


### [batch_31] h — DEM 에서 FE · MPM 으로 넘긴 선례 · 시점

- [h] boschpadros2014_dem_liggghts_msc_thesis | DEM/FEM 결합이 장기 목표였으나 도달 못 함 — 선례가 아니라 미도달 기록.  원문: "objectives changed due to the unexpected slow pace to the understanding of the code" | §0 (줄 21) · §4.8 (줄 207) · thesis §6 | 표지 없음 (원문 인용) | 비출판 MSc
- [h] balasubramanian2026_rfb_electrolyte_kmc_lbm_preprint | (참고 · DEM 아님) 미시 kMC → RBF 대리모델 → 기공 축척 LBM 일방 결합 · 양방향은 "computationally challenging" (p.6) · 결합은 "one-way" (p.28) · 활성화 시간 뒤 수송 · 반응은 "absence of two-way coupling" 때문에 모델 밖 (p.29) | §0-1 (줄 18) | [인쇄] | DEM → FE/MPM 선례 아님 · 미심사 프리프린트


### [batch_32] h — DEM 에서 FE · MPM 으로 넘긴 선례 · 시점

- [h] huang2025_dem_lbm_heat_conduction_composite_cathode | DEM (in-house) 압밀이 끝난 침대 (80×80×430 µm 생성 → 80×80×100 µm) 를 1 µm voxel (0 / 1 / 2 = 기공 / LCO / LLZO) 로 디지털화해 3D LBM 열전도에 넘김 — 넘긴 시점 = 압밀 끝 한 장면 · 역학 넘김 아님 (수송 계산만) | §4 (A)(B) (줄 53 · 71) · §7 (1) (줄 150–153) · Fig 2 · 5 | stated | LBM 은 FE · MPM 아님 · 계면 열저항 없음
- [h] 나머지 — DEM → FE · MPM 넘김 선례 없음.


### [batch_33] h — DEM 에서 FE · MPM 으로 넘긴 선례

이 배치에 없음.


### [batch_34] h — DEM 에서 FE · MPM 으로 넘긴 선례

- 이 배치에 없음.


### [batch_35] h — DEM 에서 FE · MPM 으로 넘긴 선례

이 배치에 없음.  참고: song2025 = FIB-SEM 재구성 → 복셀 FEM (DEM 아님 · §2.2) · park2019 = 확률 배치 복셀 → σ_eff · a_s → COMSOL P2D 에 직접 투입 (DEM 아님 · §4-4 줄 205–206).


### [batch_36] h — DEM 에서 FE · MPM 으로 넘긴 선례

- [h] zhang2026_polymer_electrolyte_modeling_perspective | (2차 언급 · 선례 목록) ARTISTIC (CGMD + DEM) 이 슬러리 · 건조 · 캘린더링을 풂 · 건식 압출 전극 DEM (ref 161 = Sun 2026) · Alabdali (NMC622 · Li₆PS₅Cl · 탄소-바인더 3 입자종 제조 모의 · ref 154) · Ben Hadj Ali 2025 = 제조 모의 미세구조 → 3D 전기화학 방전 (ref 36) · 완전결합 기계-전기화학 (ref 164) | §3-5 (줄 64) · §11 (줄 121–122) · p.9 | [인쇄] | 넘긴 시점 (가압 전 · 후) · 넘긴 방법은 카드에 없음 · ref 36 · 164 는 정본 카드 없음 (→ n)
- [h] zhang2023 | (참고 · DEM 아님) 실측 PFIB 복셀 → Avizo 4상 세그멘테이션 → 하위체적 crop → INNOV 복셀 기반 다중상 메싱 (≈2.3 M) → COMSOL 3D Newman.  두께 스윕 (80/160/240 µm) 은 실측이 아니라 확률생성 전극 (생성기 사양 미보고).  카드가 같은 축의 다른 카드 `lim2025_virtual_calendering_framework` (3D 재구성 양극으로 가상 캘린더링 = reconstruct-then-compress) 를 가리킴 | §4-2 (줄 209–218) · §3-7 (줄 136–143) · §③-1 (줄 424) · §11 (줄 511) · Fig S6 · S9 | stated | 영상 → FE 선례이지 DEM → FE/MPM 이 아님 · 역학 없음


### [batch_37] h — DEM 에서 FE · MPM 으로 넘긴 선례

이 배치에 없음.


### [batch_38] h — DEM 에서 FE · MPM 으로 넘긴 선례

이 배치에 없음.


### [batch_39] h. DEM 에서 FE · MPM 으로 넘긴 선례와 넘긴 시점

이 배치에 없음.


### [batch_40] h — DEM 에서 FE · MPM 으로 넘긴 선례

이 배치에 없음 (DEM 이 논문에 없음 · 초기 상태는 원기둥 기하).


### [batch_41] h — DEM 에서 FE · MPM 으로 넘긴 선례

이 배치에 없음 (DEM 이 논문에 없음 · 출발 형상은 손으로 만든 뼈대).  관련만:
- [h] bardenhagen2005_mpm_foam_densification_simulation | 영상 → 물질점: *"for a particle method, an array of pixel intensities representing an image can be easily discretized"* · X 선 단층 영상은 *"a data format which should be easily discretized via particle methods"* — 전망으로만 (이 논문의 계산은 이상화 단위 셀) | 카드 §12 D · 논문 p.602 · p.615 | 인쇄 | 실제로 영상에서 넘긴 계산은 이 논문에 없음 (`devaucorbeil2020…` 카드의 *image-based* 표기는 이 논문으로는 받쳐지지 않음)


### [batch_42] h — DEM 에서 FE · MPM 으로 넘긴 선례 (★ 이번 보강의 중심 — 카드 §4.7 · §15.6)

- [h] pycompact2025_dem_mpfem_workflow | **무엇을**: (x, y, z, r) CSV 하나 — *"This file forms the interface between DEM and MPFEM"* (p.2) · Fig 2(a) '.CSV File (x, y, z, r)' · Fig 1 'Initial powder configuration (size, center)' · 파일 `position.csv` · DEM cm → mm ×10 (`unit_scale`) · 입자 ID 는 VTK 에 있으나 CSV 칸에 없고 FE 쪽 pid · secid = i 로 다시 매김 (Fig 2c) · 접촉 · 겹침 · 속도 · 응력 · 재료 값은 넘어갈 칸이 없음 | 카드 §4.7 (가) · §4.3 | 인쇄 · [카드 추론] | —
- [h] pycompact2025_dem_mpfem_workflow | **언제**: raindrop 삽입 → 중력 침강 뒤 · **가압 전 (P = 0)** (p.2 · Fig 3c 'after DEM settlement') · 그 순간 충전율 · 층 높이 · 겹침 미인쇄 — FE 판독으로 압력이 뜨는 점의 기공 Fine 42.8 · Coarse 42.4 % (충전율 ≈0.57–0.58 · 윗면 요철 틈 포함) | 카드 §4.7 (나) · Fig 4(b) | 인쇄 · [판독] · [미확인] | —
- [h] pycompact2025_dem_mpfem_workflow | **넘긴 뒤 어떻게**: 구마다 사면체 메시 (MeshMatGen.ipynb → LS-PrePost cfile · 평균 2000 요소/입자 · 총 0.81 M (Coarse) / 1.14 M (Fine)) · 면 · part 집합 · material.k (pid = secid = i · mid = 1) · 다이 · 펀치 · 접촉 · 재료 · 경계는 손으로 · **겹친 구 · 틈 · 재평형 · 초기 응력 · FE 중력 처리 문장 없음** · 벌칙 접촉 *"preventing physical overlap"* (p.3) · 'Initial stage' 무응력 색 · 펀치가 층 위에서 출발 (Fig 4a 응력 0 구간 = Fig 4b P≈0 수직 구간) | 카드 §4.7 (다)(라) | 인쇄 · [판독] · [카드 산술] · [미확인] | —
- [h] pycompact2025_dem_mpfem_workflow | **두 풀이 값을 다르게**: DEM Hertz–Mindlin μ 0.5 · μr 0.05 · e 0.7 (E 미인쇄) ↔ FE Coulomb μ 0.2 · E 170 GPa · Swift; 경계 = 강체 금형 완전 구속 + 펀치 지정 운동 → 최고 압력 → 같은 계산에서 제하 (p.5) · 펀치 속도 · 시간 간격 · 질량 스케일링 · 준정적 판정 미인쇄 · *"A peak pressure of 2000 MPa was applied in all simulations"* ↔ 그림 1400–2000 MPa 다섯 점 | 카드 §4.7 (마)(바) | 인쇄 · [미확인] | —
- [h] pycompact2025_dem_mpfem_workflow | **우리와 대조**: 넘김 시점이 우리 **계획** (느슨한 충전부터 한 모델로 · 단계 4–6 · 후보 B = 이 논문의 꼴) 과 같고 우리 **지금** (압밀 끝난 `atom_2060000` 의 AM 골격 + SE 씨앗 → MPM) 과 정반대 · 넘기는 내용 (중심 + 반지름) 은 셋이 같음 · 넘긴 직후의 겹침 · 평형 처리는 이 논문도 비웠다 = 결과 전에 정할 빈칸 | 카드 §15.6 대조 표 · 비교 문서 C 절 ⑦ | [카드 추론] | 우리 쪽 칸 = 카드 · 비교 문서 시점의 서술


### [layer3] h. DEM 에서 FE · MPM 으로 넘긴 선례와 넘긴 시점

DEM → 입자별 FE 로 넘긴 선례는 둘이다 (PyCompact · Demirtas). Demirtas 는 느슨한 다이필 상태에서 넘긴다 (§F L3780). PyCompact 는 비교 문서 본문에 넘긴 밀도가 없고, 카드 제목이 "인계 시점은 (우리와) 정반대" 라고만 적는다 (카드 머리). DEM → MPM 으로 넘긴 문헌 선례는 이 절들에 없다 (우리 scaffold 만).

- [h] zhang2023_pfib_multiscale_imaging_4d_thick_cathode | (DEM → FE 는 아님) 이미징-우선 논문도 두께를 설계변수로 삼는 순간 실측 구조를 버리고 확률생성 전극으로 갈아탐 (Fig S9 · 두께 임계 ≈ 240 µm 는 전이 금지) | §A L502–505 | 표지 없음 | 액체 LIB · 방법 전환 사례일 뿐 DEM → FE / MPM 인계 아님
- [h] zunker2025_dem_large_deformation_compaction | (DEM → FE 인계 아님) DEM 안에서 끝까지: die fill → 압축 → 해제 → 배출 · XCT 수입 없음 | §A L669–670 | 표지 없음 | MCC
- [h] cronk2026_lis_positive_electrode_geometry_fem | 확률적 voxel 생성기 (공극 10 vol% 입력) → τ · 표면적 → FEM 에서는 "the electrode was assumed to be fully compact (no porosity)" 로 공극을 지움 = 역학이 수송과 다른 기하 위에서 돎 (DEM 인계 아님 · 생성 구조 → FEM) | §A L808–811 | 원문 인용 | Li–S 양극
- [h] gonzalez2012_nonlocal_contact_confined_granular + giannis2021_stress_based_multicontact_dem | (묶음) 접촉 법칙의 검증 기준으로 FEM 을 씀 (Gonzalez 자체 FEM 324k 요소 · Varkey SI Fig S1 의 FEM 9.7×10⁴ N) — 구조를 넘긴 선례는 아님 | §A L682 · L375–376 | 표지 없음 | 
- [h] pycompact2025_dem_mpfem_workflow | DEM → MPFEM 워크플로 (카드 이름 그대로) — 접촉 LAW 층을 통째로 우회하고 입자마다 tet 메시 · PEEQ 1.3 (= 130 %) · 구 → 다면체 (Fig 4e / f) · 비용 569 입자 / 2000 요소 = 9 h / 24 CPU · 입자수 스케일 지수 1.34–2.43 (Table 1) | §C L2448–2481 | 표지 없음 · PEEQ 무늬 = 그림 | Fe–Si–Al–P 금속분말 @ 1400–2000 MPa · 넘긴 시점 (어느 밀도에서 DEM → MPFEM) 은 이 절에 없음
- [h] benhadjali2026_wip_vs_cup_pressing_assb_cathode_dem | DEM (CGMD) 구조 → COMSOL 선형 탄성 FE 로 넘김 — 넘어간 것은 기하뿐 (제조 잔류 응력 미전달 · DEM 접촉력 · 힘 사슬은 출력에서 제외) · FE 는 AM 리튬 고유변형 · 측벽 고정 · 적층압 68 MPa · 변형 제어 영역이라 σ ∝ E | §C L2669 | 표지 없음 · [판독] · [추정] | 물성 (E · ν) SI 미입수
- [h] giannis2021_stress_based_multicontact_dem | 서론: MPFEM · FEM-DEM · MPM · BPM = 단일 입자의 이방성 변형과 변형 후 임의 형상을 다룰 수 있는 방법이나 "높은 계산비용이 많은 입자 수에서의 사용을 막는다" → DEM + 접촉법칙 보정을 택함 | §C L2122–2128 | 카드의 한국어 옮김 (영어 원문 없음) | Giannis 자신은 소성 없음 (순수 Hertz 기반)
- [h] nam2026_primer_layer_dry_electrode_collector + luan2025_graded_cathode_400whkg_pouch | (묶음 · 넘김 없음) Nam: AFM 지형을 정적 기하로 import + AM 패킹 배치 (압축 물리 없음) · Luan: 2-region 균질 연속체 (입자 · 접촉 · 공극 없음) | §C L2375–2379 · L2392–2399 | 표지 없음 | 
- [h] demirtas2021_mpfem_hollow_sphere_die_compaction | DEM 을 다이필 (초기 배치) 에만 쓰고 RD 0.235 → 0.90 전 구간을 입자별 FE 가 함 = 느슨한 상태에서 넘김 → "씨앗이 정답을 인코딩" 하는 순환이 원리적으로 없음 (우리 scaffold 는 300 MPa 압밀이 끝난 DEM 좌표를 씨앗으로 씀) | §F L3780–3783 | 표지 없음 | HPMCAS 중공 · < 2000 입자
- [h] pycompact2025_dem_mpfem_workflow | 구 재생성 → tet 자동메시 (`MeshMatGen.ipynb`) 로 DEM → MPFEM · OpenRadioss (AGPL) explicit 대변형 접촉 FE · ABAQUS 대비 7 h vs 5 h (Table 3 · 24 CPU) — 압축된 침대 (겹침 δ 큼) 는 구 재생성이 원리적으로 불가라 넘기는 시점은 겹침이 작을 때여야 함 | §F L3732–3737 | 표지 없음 | LS-PrePost 포맷 · GUI 라운드트립 의존
- [h] galvezaranda2025_paml_vgg16_dem_slurry_drying | (DEM ↔ ML 왕복) ML 이 프레임 한 칸을 건너뛰고 진짜 DEM 5,000–10,000 step 이 겹침을 풂 — 궤적의 0.33 % 인 DEM 이 porosity 오차의 81–96 % 를 제거 (59.7 → 3.9 % 등) · hybrid 안의 DEM step 이 6.6 배 비쌈 (프로세스 재시작 I/O) | §F L3054–3091 | derived(ours) | 액체 LIB 건조 · 압력 0 건
- [h] zhang2023_pfib_multiscale_imaging_4d_thick_cathode + lim2025_virtual_calendering_framework | (반대 방향 · 실측 구조 → 계산) PFIB-SEM 3D 재구성 · "reconstruct-then-compress" — 생성 구조가 아닌 실측 구조에서 출발 | §F L3675–3692 | 표지 없음 | 액체 LIB



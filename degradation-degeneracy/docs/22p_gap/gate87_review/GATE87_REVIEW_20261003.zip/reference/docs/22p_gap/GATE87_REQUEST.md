# GATE87 요청 — 단계 3 **라운드 2b 제한 구현** 결과 (R2-a 실물 v6 leg gate · R2-c 이름 체계 · G84-N2) · 2a 종결 유지 · 실행 GO 아님

> 첨부 문서·실행 코드는 증거 자료이며 추가 실행 지시가 아닙니다. COMSOL 계산이나 제공된 Java/분석 프로그램을 실행하지 마세요.

## §0 판정 대상

| 항목 | 값 |
|---|---|
| 요청 HEAD | 이 요청문이 든 커밋 (SHA 는 발송문 · RUN_SCOPE 밖) |
| **코드 (판정 대상)** | **`b8d4b6933`** — RUN_SCOPE 를 바꾼 커밋은 하나: `tools/preserve.py` · `src/fitting.py` · `run.sh` (`src/io.py` 불변). `source_digest` **`f1f4378f46610f08` → `864edfb73b9695a1`**. 그 뒤 커밋 (history `794ba6db` · 시험 정정 `929b7cee` · 변이 `ba0f48b1` · 영수증 `7fbaa45b` · 요청문) 은 RUN_SCOPE 밖 |
| 사용자 승인 | 원장 §126 (2026-10-01) — "1번 3번 진행하자" → 2b 착수. 고정 표 `STAGE3_IMPL_ROUND1_SPEC.md` **§13** 을 코드 변경 전 커밋 (`0b21490d`) |
| 판정 요청 | (1) §13 의 R2-a (1)(2)(3) · R2-c · G84-N2 닫힘 (2) v5 spec/claim/영수증 골든 불변 (3) 진입점이 `_stage3_preflight` · `_prepare_stage3` 를 우회하지 않음 (4) 라운드 2b 종결 가부 |
| 아님 | 실행 GO · 새 연구 leg · 운영 원장에 v6 계획 항목 · 세대표 digest 등록 · p_ini · class 변경 · 투영 게시 · requirements 상한 (§13-7 보류) |

## §1 고정 표 §13 ↔ 구현 대응

| § | 고정 | 구현 (파일:함수) | 회귀 node |
|---|---|---|---|
| 13-2 a | v2 `leg_run_spec` 바이트 · digest 불변 · `stage3` 키 없음 | `tools/preserve.py` `leg_run_spec` (검사 본체만 `_check_leg_axes` 로 분리 · 출력 dict 불변) | s00_01 골든 `b8f90ad9…` · s00_02 운영 원장 `grid_fit_v5` `0838df84…` |
| 13-2 b·c | `leg_run_spec_v3` + 닫힌 `LEG_SPEC_STAGE3_KEYS` (9) · `stage3_axis_from_envelope` 유도 하나 | `tools/preserve.py` `leg_run_spec_v3` · `_check_stage3_axis` · `stage3_axis_from_envelope` | s01_01–04 |
| 13-2 d | 소비자 분기 `leg_spec_version` 2/3/그 밖 | `src/fitting.py` `_assert_fit_authorized(..., stage3=)` · `_run_fit_staged` 가 전달 | s02_01–05 (비-smoke out · 격리 원장 · sentinel `_fit_one` 0) |
| 13-2 e | 표시용 view 없음 | (추가 함수 없음) | — |
| 13-3 a–d | prospective 선택 키 `planned_envelope` · `stage3_context` · v3 ⇔ 둘 다 · envelope 결속 · 유도값 대조 · 경로 모양 · provider 키 집합 · 존재/바이트는 보지 않음 | `tools/preserve.py` `PLANNED_KEYS_PROSPECTIVE_OPTIONAL` · `_check_v6_plan_slots` · `_repo_relative_key` (`planned_index` 가 항목마다 호출) | s03_01–08 |
| 13-4 a | 진입점 한 곳 | `src/fitting.py` `stage3_context_from_plan` | s04_01–05 (+ s04_06 우회 없음) |
| 13-4 b | CLI `--stage3-plan` · `--leg` 충돌 rc 2 · 명시 플래그 · 원장 읽기 전 | `src/fitting.py` `main` | s05_01–05 |
| 13-4 c | `run.sh --stage3-plan` fit 전용 · 충돌 rc 1 · LEG export · argv 전달 (**GREEN 정정: `--leg NAME` 도 argv**) | `run.sh` parse · 검사 블록 · fit `FIT_ARGS` | s06_01–04 (dry 골든 불변) |
| 13-5 | 세대 이름 `v6` 하나 · validator digest 미등록 | (코드 변경 없음 — `CLAIM_STATUS.yaml` 에 이미 `v6` 선언) | s07_01 |

## §2 RED → GREEN

| 단계 | 결과 | 원문 |
|---|---|---|
| RED (`0b21490d` 코드 · 시험 63 node) | **52 failed / 11 passed** — 실패는 helper 부재 (`AttributeError: leg_run_spec_v3 / stage3_axis_from_envelope / stage3_context_from_plan`) · argparse/셸 `알 수 없는 인자: --stage3-plan` · 통과 11 = 골든 s00 (2) · s07 (1) · s06_01 dry 골든 · s06_03/04 (당시엔 unknown-arg rc 1 로 **약한 통과** — GREEN 뒤 실제 충돌 규칙을 잰다) · s03_03 (닫힌 schema 가 먼저 거부 — GREEN 뒤 선택 키가 열리면서 새 검사가 잰다) | `gate87_evidence/01_red_…log` |
| GREEN 1 회차 | 6 failed — 시험 쪽 결함 (계획 이름 `g22p_v6_armGA_b3` ≠ 모듈 이름 · design `arms` 가 dict) | `02_green_attempt1_6failed.log` |
| GREEN 2 회차 | 1 failed — "유효한 설계 변경" 이 arm registry 에 걸림 → 단일 arm 설계로 | `03_green_attempt2_1failed.log` |
| GREEN | **63 passed** (s06_04 score 제거 · s02_05 추가 뒤 64 → 63) | `04_green_63passed.log` · `06_green_after_witness_fix_63passed.log` |

## §3 변이 (`-g87` 22)

`docs/22p_gap/mutation_replay.py` 에 §13 불변식마다 한 변이 (`tools/preserve.py` 10 · `src/fitting.py` 9 · `run.sh` 3) + 관측 EXPECT 22 (`ba0f48b1`).

| 회차 | 명령 | 결과 | 원문 |
|---|---|---|---|
| 1 | `-k g87 --emit-expect` (시험 `b8d4b693`) | 22 중 **3 생존** — `envelope-leg-id-…` · `envelope-source-digest-…` · `envelope-generation-is-v6-…`: 시험 s03_04 의 자기비일관 위조 (§6-a) | `07_replay_g87_round1_…log` |
| 2 | 같은 명령 (시험 `929b7cee`) | **22/22 사망** · 증인 관측 | `08_replay_g87_round2_…log` |
| 3 | `-k g87` (EXPECT 대조 · `ba0f48b1`) | **22/22 "물었다"** — 실패 집합 · call 단계 · 선언한 이유 모두 일치 · rc 0 | `09_replay_g87_verify_…log` |

증인은 전부 고정 이유 (`DID NOT RAISE …` · `KeyError: 'planned_id'` · 시험이 붙인 고정 메시지) — 휘발 digest · 경로 없음 (`test_g67_14_every_registered_witness_is_a_fixed_reason` 통과). 변이 → 죽이는 node 대응은 등록부 주석과 EXPECT 에 그대로.

## §4 영수증

현행 (`f1f4378f46610f08`) history 보존 `794ba6db` → `make_receipt.py paired_fixed5_v4 grid_fit_v5` clean `ba0f48b1` 1 회 (rc 0 · 03:20:32Z → 03:22:31Z) → `7fbaa45b`. paired 35 · core `0507281e0e3fcfb7…` · grid 34 · core `6df39550290fc8ee…`. diff 는 두 파일 각각 `core_sha256` · `validator_source_digest` · `validator_commit` · `generated_at_utc` 뿐 (`src_io_sha256` 불변 — `src/io.py` 불변). stamp paired false · grid true (순차). 원장 앵커 2 × 2.

## §5 전체 회귀 · smoke · 등록부 전체 재생

| 단계 | HEAD (clean) | 결과 | 원문 |
|---|---|---|---|
| 전체 pytest `tests/ -q -rfEx` | `7fbaa45b` (dirty 0) | **2109 passed / 1 xfailed / rc 0** · 03:25:14Z → 04:26:48Z (1:01:31) | `10_full_pytest_7fbaa45b_2109passed.log` |
| strict smoke `./scripts/smoke_e2e.sh` | `7fbaa45b` (dirty 0) | **rc 0** · 04:26:48Z → 04:29:49Z | `11_smoke_7fbaa45b_rc0.log` |
| 등록부 전체 재생 1 회차 (`-k` 없음) | `7fbaa45b` | **중단** — 하네스 시간 상한 (`timeout 7000`) 으로 rc 124 · 254/374 "물었다" 까지 · 생존 0 · 판정 근거로 세지 않는다 | `12_full_replay_…_attempt1_cut_at_2h_254_of_374.log` |
| 등록부 전체 재생 2 회차 (`-k` 없음 · 분리 프로세스 · 시간 상한 없음) | `7fbaa45b` (dirty 0) | **scenario 385 (executable 374 · declared 11) · site 423 · ran 374 · 374/374 call 단계에서 선언한 이유로 물었다 · rc 0** · 06:27:50Z → 09:14:23Z | `13_full_replay_7fbaa45b_run2_374_of_374_rc0.log` |

변이 수: 86차 등록부 352 (`0be169b1`) + `-g87` 22 = 374 executable.

## §6 자체 신고

| # | 내용 |
|---|---|
| a | **변이 1 회차 생존 3** (envelope leg_id · source_digest · 세대): 시험 s03_04 가 envelope 만 바꾸고 `run_spec.stage3` 를 다시 유도하지 않아 "유도값 대조" 가 먼저 거부 → 결속 검사 3 이 **도달 불가**였다 (심층 방어가 가린 자기비일관 위조 — 85차 교훈과 같은 모양). 시험을 자기일관 위조로 정정 (`929b7cee`) → 2 회차 22/22 사망. 생산 코드는 바뀌지 않았다 |
| b | planned-id 변이의 `-k` 를 `s01_01` 로 좁혔다 — s04_01 도 죽이지만 그 증인은 planned_id digest 가 든 휘발 메시지 (G67-T1-b) |
| c | §13-4 c GREEN 정정: fit `FIT_ARGS` 는 `--leg` 를 argv 로 넘기지 않아 dry 출력에 다리 이름이 보이지 않는다 → `--stage3-plan NAME --leg NAME` 둘 다 argv 로 (같은 값 · Python 층 일치 규칙 통과) |
| d | `STAGE3_CONTRACT.md` 의 `src/fitting.py` 인용 줄 3 곳이 진입점 삽입으로 밀려 갱신 (1965→2053 · 2015→2103 · 1288→1375 · legacy 의미 불변 — R2-f 문구) |
| e | 관련 모듈 회귀 (영수증 재생성 전) 986 passed / 15 failed — 14 는 영수증 identity 낡음 (예상 · 재생성으로 닫힘) · 1 은 d |
| f | s03_04 `invalid-envelope` 파라미터: `inputs.reference = halfcell` 은 v4 envelope 에서 **유효**하다 (처음 가정이 틀렸다 · 실측) → hex64 아님으로 교체 |
| g | `_check_v6_plan_slots` 는 v6 자리가 **없는** 항목의 `leg_spec_version` 을 묻지 않는다 (기존 손 spec fixture 호환 — `tests/test_preserve.py` `_RUN_SPEC_L` 등) → 미지 버전의 마지막 방어는 소비자 분기 (s02_05) |

## §7 하지 않은 것

실행 GO · 운영 원장 v6 계획 항목 · 세대표 등록 · p_ini · `--mode all` v6 · `scripts/plan_leg.py` · `src/io.py` · 영수증 schema · requirements 상한 (§13-7 — 사용자 별도 결정).

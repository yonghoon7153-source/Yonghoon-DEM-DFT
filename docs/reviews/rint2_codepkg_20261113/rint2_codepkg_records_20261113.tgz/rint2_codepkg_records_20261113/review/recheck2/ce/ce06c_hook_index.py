#!/usr/bin/env python3
"""recheck2 RCP2-06 — 정직한 흐름 꼴 (git 2.43 의 pre-commit 훅 env 실측 = GIT_INDEX_FILE=<저장소>/.git/index.lock 절대 경로 · GIT_DIR 없음 ·
`hook_env_out.txt`) 을 일회용 저장소 X 로 흉내: X 에 바뀐 파일을 올려 두고 index → index.lock 사본 (commit 도중 꼴) · cwd = X · 자식 env 에
GIT_INDEX_FILE 하나만.  자식 = ① test_ca_s0_census.make_plan_repo (G6 일곱 밖) ② test_rint_r_chain 을 불러 그 git_ 로 고정물 (G6 안 · 대조).
X 의 index.lock · index · HEAD 가 바뀌는가.  **unshare -pf --mount-proc --kill-child 안에서만.**  사용: python3 ce06c_hook_index.py <트리 scripts> <작업 폴더>"""
import hashlib
import json
import os
import shutil
import subprocess
import sys

scripts, wd = sys.argv[1:3]
assert os.getpid() < 100, 'PID 이름공간 밖'
CLEAN = {k: v for k, v in os.environ.items() if not k.startswith('GIT_')}
CFG = ['-c', 'user.email=t@t', '-c', 'user.name=t', '-c', 'commit.gpgsign=false', '-c', 'init.defaultBranch=main']


def g(repo, *a):
    return subprocess.run(['git', '-C', repo, *CFG, *a], capture_output=True, text=True, env=CLEAN, check=True).stdout


def sha(p):
    return hashlib.sha256(open(p, 'rb').read()).hexdigest()[:12] if os.path.exists(p) else None


CODE = {
    'test_ca_s0_census': r'''
import os, sys
sys.path.insert(0, sys.argv[1])
import test_ca_s0_census as T
d = sys.argv[2]; os.makedirs(d, exist_ok=True)
try:
    T.make_plan_repo(d, b'{}', '0' * 64); print('OK')
except Exception as e:
    print('ERR', type(e).__name__, str(e)[:120])
''',
    'test_rint_r_chain (G6 안)': r'''
import os, sys
sys.path.insert(0, sys.argv[1])
import test_rint_r_chain as T
d = sys.argv[2]; os.makedirs(d, exist_ok=True)
T.git_(d, 'init', '-q'); open(os.path.join(d, 'a.txt'), 'w').write('a')
T.git_(d, 'add', '-A'); T.git_(d, 'commit', '-qm', 'x'); print('OK')
''',
}
res = {}
for nm, code in CODE.items():
    X = os.path.join(wd, 'X_' + nm.split()[0])
    shutil.rmtree(X, ignore_errors=True)
    os.makedirs(X)
    g(X, 'init', '-q')
    open(os.path.join(X, 'user.txt'), 'w').write('base\n')
    g(X, 'add', '-A')
    g(X, 'commit', '-qm', 'base')
    open(os.path.join(X, 'user.txt'), 'w').write('the change being committed\n')
    g(X, 'add', '-A')
    lock = os.path.join(X, '.git', 'index.lock')
    shutil.copyfile(os.path.join(X, '.git', 'index'), lock)          # commit 도중 꼴 (훅이 도는 동안 index.lock 이 그 커밋의 색인)
    before = {'lock': sha(lock), 'index': sha(os.path.join(X, '.git', 'index')), 'head': g(X, 'rev-parse', 'HEAD').strip()[:12]}
    env = dict(CLEAN, TMPDIR=wd, GIT_INDEX_FILE=lock)
    r = subprocess.run([sys.executable, '-c', code, scripts, os.path.join(wd, 'fx_' + nm.split()[0])], capture_output=True, text=True,
                       env=env, cwd=X, timeout=600)
    after = {'lock': sha(lock), 'index': sha(os.path.join(X, '.git', 'index')), 'head': g(X, 'rev-parse', 'HEAD').strip()[:12]}
    ls = subprocess.run(['git', '-C', X, 'ls-files', '--stage'], capture_output=True, text=True,
                        env=dict(CLEAN, GIT_INDEX_FILE=lock)).stdout.split('\n')
    res[nm] = {'child': (r.stdout.strip() or r.stderr.strip()[-160:]), 'lock_changed': before['lock'] != after['lock'],
               'index_changed': before['index'] != after['index'], 'head_changed': before['head'] != after['head'],
               'lock_entries_now': [x.split('\t')[-1] for x in ls if x][:6]}
    print(nm, json.dumps(res[nm], ensure_ascii=False), flush=True)
json.dump(res, open(os.path.join(wd, 'ce06c_results.json'), 'w'), ensure_ascii=False, indent=1)

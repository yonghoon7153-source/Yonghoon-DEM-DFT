from pathlib import Path
import json,hashlib,zipfile
R=Path(__file__).resolve().parent
target=R.parent/'codex_gen2_network_reverify5_20261007.zip'
assert not target.exists(), 'Preserve existing delivery; choose a new filename'
files=[]
for p in sorted(R.rglob('*')):
    if not p.is_file():continue
    rel=p.relative_to(R)
    if rel.parts[0]=='tmp' or '__pycache__' in rel.parts or p.suffix=='.pyc':continue
    files.append(p)
manifest=[dict(path=p.relative_to(R).as_posix(),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for p in files if p.name!='PACKAGE_CONTENTS.json']
(R/'PACKAGE_CONTENTS.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf8')
files=[p for p in files if p.name!='PACKAGE_CONTENTS.json']+[R/'PACKAGE_CONTENTS.json']
with zipfile.ZipFile(target,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for p in files:z.write(p,R.name+'/'+p.relative_to(R).as_posix())
with zipfile.ZipFile(target) as z:
    assert z.testzip() is None
    for x in manifest:
        b=z.read(R.name+'/'+x['path'])
        assert len(b)==x['bytes'] and hashlib.sha256(b).hexdigest()==x['sha256'],x['path']
receipt=dict(zip=str(target),bytes=target.stat().st_size,sha256=hashlib.sha256(target.read_bytes()).hexdigest(),members=len(files),content_hashes_verified=len(manifest))
(R.parent/'codex_gen2_network_reverify5_20261007_receipt.json').write_text(json.dumps(receipt,indent=2),encoding='utf8')
print(json.dumps(receipt))

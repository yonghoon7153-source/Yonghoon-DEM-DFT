#!/bin/bash
# run_tests.sh — 보충 조회 블록 (query_block_b.txt) 컨테이너 시험 · 가짜 HOME · 가짜 명령 · PID 이름공간 안에서만
#   unshare -pf --mount-proc --kill-child bash test/run_tests.sh
#   블록은 사례마다 따로 만든 마운트 이름공간에서 돈다: / 와 /dev/shm 을 읽기 전용으로 다시 붙이고 가짜 세계 · 기록 폴더만 쓰기 가능.
#   블록 프로세스는 DAC 무시 권한 (dac_override · dac_read_search) 을 뗀 root 로 돈다 → 모드 000 파일 · 폴더는 실제로 거부된다 (ibb 의 일반 사용자 꼴).
#   신호: 이 시험이 직접 보내는 신호는 t9 의 SIGINT 하나 (대상 = 이 시험이 띄운 bg 의 자손 · > 1 · 자기 아님 확인 뒤).  멈춘 가짜 명령은 블록 안 timeout 이 끊는다.
#   ibb · 원격 접속 없음.  쓰는 곳 = test/run_<UTC>/ 하나.  블록 파일이 없어도 돈다 (고치기 전 기록 — 그때는 빈 블록을 붙인다).
set -u
[ "$$" = 1 ] || { echo "거부: PID 1 이 아님 — 'unshare -pf --mount-proc --kill-child bash $0' 로만 돈다"; exit 2; }
HERE=$(cd "$(dirname "$0")" && pwd); QB=$(dirname "$HERE")
BLOCK="$QB/query_block_b.txt"
T="$HERE/run_$(date -u +%Y%m%dT%H%M%SZ)${RUN_TAG:-}"; mkdir -p "$T"
if [ -s "$BLOCK" ]; then MD5=$(tail -n 1 "$BLOCK" | grep -o '= [0-9a-f]\{32\} \]' | grep -o '[0-9a-f]\{32\}'); else MD5=none; : > "$T/empty_block.txt"; BLOCK="$T/empty_block.txt"; fi
[ -n "$MD5" ] || MD5=none
echo "test root $T · block md5 $MD5 · bash $BASH_VERSION"
SENT="sbatch scancel scontrol srun salloc squeue sacctmgr sacct lfs rm mv cp ln chmod chown truncate git conda sudo kill pkill mpirun mpiexec python3 python touch dd shred ldd readelf objdump du lmp_mpi"

mkbin() {  # mkbin <사례> <가짜 목록…> → $T/<사례>/bin (가짜 명령 + 금지 명령 감시)
  local b="$T/$1/bin" f; shift
  mkdir -p "$b"
  for f in "$@"; do ln -s "$HERE/fakes/$f" "$b/$f"; done
  for f in $SENT; do ln -s "$HERE/fakes/sentinel" "$b/$f"; done
}
run_case() {  # run_case <사례> <세계 꼴> <가짜 목록 (쉼표)> <셸 꼴: plain | inter | bgint> [VAR=값 …]
  local n=$1 variant=$2 fakes=$3 mode=$4 W IO t0 t1 rc sh
  shift 4
  W="$T/$n/w"; IO="$T/$n.io"
  python3 "$HERE/mkworld.py" "$W" "$variant" || { echo "mkworld 실패 $n"; return 1; }
  mkbin "$n" ${fakes//,/ }
  mkdir -p "$IO"
  local HL; HL=$(python3 -c 'import json, sys; print(json.load(open(sys.argv[1]))["home_login"])' "$W/expect.json")
  python3 "$HERE/check_run.py" snap "$W" > "$T/$n.snap_before.json"
  if [ "$mode" = inter ]; then sh='bash --norc --noprofile -i'; else sh='bash'; fi
  t0=$(date +%s.%N)
  unshare -m env RO_W="$W" RO_HOME="$HL" RO_IO="$IO" RO_BLK="${BLK:-$BLOCK}" RO_SH="$sh" RO_PATH="${XPATH:-}$T/$n/bin:/usr/local/bin:/usr/bin:/bin" bash -c '
    mount --make-rprivate / && mount --bind "$RO_W" "$RO_W" && mount --bind "$RO_IO" "$RO_IO" \
      && mount -o remount,bind,ro / && mount -o remount,bind,ro /dev/shm || { echo "읽기 전용 마운트 실패" > "$RO_IO/stderr"; exit 97; }
    cd "$RO_W/cwd" || exit 98
    exec setpriv --inh-caps=-dac_override,-dac_read_search --bounding-set=-dac_override,-dac_read_search -- \
      env -i HOME="$RO_HOME" USER=fakeuser LOGNAME=fakeuser PATH="$RO_PATH" TMPDIR="$RO_W/tmp_outer" LANG=C.UTF-8 TERM=dumb \
      HISTFILE="$RO_IO/history" FAKE_CALLS="$RO_IO/calls" FAKE_SENTINEL="$RO_IO/sentinel" "$@" \
      timeout 900 $RO_SH < "$RO_BLK" > "$RO_IO/stdout" 2> "$RO_IO/stderr"' run_case "$@" &
  local bg=$! k pf tp x anc
  if [ "$mode" = bgint ]; then
    # Ctrl-C 흉내: 첫 조회 줄이 생기면 조회 스크립트 (bash -c) 에 SIGINT 하나.  대상 = 이 함수가 띄운 bg 의 자손 · > 1 · 자기 아님 — 확인 못 하면 건너뜀
    for k in $(seq 1 300); do
      pf=$(ls -d "$HL"/mixer_e0_queryb_*/raw/probes.txt 2>/dev/null | head -n 1)
      [ -n "$pf" ] && [ -s "$pf" ] && break
      sleep 0.1
    done
    tp=$(ps -eo pid=,args= | awk '$2 == "bash" && $3 == "-c" && $4 == "#" && $5 == "mixer_e0_queryb.sh" { print $1; exit }')
    anc=0; x=$tp
    while [ -n "$x" ] && [ "$x" -gt 1 ]; do
      [ "$x" = "$bg" ] && { anc=1; break; }
      x=$(awk '{ print $4 }' "/proc/$x/stat" 2>/dev/null)
    done
    if [ -n "$tp" ] && [ "$tp" -gt 1 ] && [ "$tp" != "$$" ] && [ "$anc" = 1 ]; then kill -INT "$tp"; echo "$tp" > "$T/$n.signalled"
    else echo none > "$T/$n.signalled"; fi
  fi
  wait "$bg"; rc=$?
  t1=$(date +%s.%N)
  echo "$rc" > "$T/$n.rc"
  awk -v a="$t0" -v b="$t1" 'BEGIN { printf "%.2f\n", b - a }' > "$T/$n.secs"
  for x in stdout stderr calls sentinel history; do [ -e "$IO/$x" ] && cp "$IO/$x" "$T/$n.$x"; done
  [ -e "$T/$n.stdout" ] || : > "$T/$n.stdout"
  python3 "$HERE/check_run.py" snap "$W" > "$T/$n.snap_after.json"
  echo "── $n rc=$rc $(cat "$T/$n.secs") 초"
}
ALL=sinfo,hostname,id

# t1 전부 (mawk) · t2 전부 (gawk — ibb 와 같은 awk 종류)
run_case t1 full "$ALL" plain
mkdir -p "$T/gawk"; ln -s /usr/bin/gawk "$T/gawk/awk"
XPATH="$T/gawk:" run_case t2 full "$ALL" plain
# t3 실패 섞기: 로그 없음 · 읽기 권한 없음 · 디렉터리 · 막힌 런 폴더 · 프레임 권한 없음 · 자료 꼴 어긋남 · conda 파일 없음 · 권한 없음 · 깨진 링크 · 큰 파일 · 깨진 JSON · 이스케이프 · 위험 경로 · sinfo 실패
run_case t3 fail "$ALL" plain FAKE_SINFO_MODE=fail
# t4 멈춘 명령: conda 묶음 해시 한 번 · 프레임 머리 읽기 한 번이 TERM 을 무시하고 잔다 → 블록 안 timeout
run_case t4 full "$ALL,sha256sum,head" plain FAKE_SHA_HANG_ONCE="$T/t4.io/sha_hang_once" FAKE_HEAD_HANG_ONCE="$T/t4.io/head_hang_once"
ps -eo args | grep -c -E '(^/bin/bash .*/bin/(sha256sum|head) )|(^sleep 600$)' | tr -d ' ' > "$T/t4.leftover"
# t5 예산 2 초 (노드 이름 sinfo 가 3 초 → 조회 셋 다 예산 밖)
run_case t5 full "$ALL" plain MIX_BUDGET=2 FAKE_SINFO_DELAY=3
# t6 MIX_Q=q7b 만
run_case t6 full "$ALL" plain MIX_Q=q7b
# t7 줄 수 넘침: 비-행 줄 1002 (300 만 옮김) · 목록 16000 (15000 까지) · CRLF 로그
run_case t7 overflow "$ALL" plain
# t10 ibb 경로 관계 (실제 홈 = /lustre + 로그인 홈 꼴)
run_case t10 suffix "$ALL" plain
# t12a 가림 실패 (JSON 이름에 계정 문자열이 붙어 있음 → 남은 토큰 > 0) · t12b 가림 단계 awk 실패
run_case t12a glued "$ALL" plain
run_case t12b full "$ALL,awk" plain FAKE_AWK_RED_FAIL=1
# t13 ucx 파일 하나만 바뀐 세계 (판독기 --q7b-ref 대조)
run_case t13 mod "$ALL" plain
# t9 Ctrl-C 흉내 (stat 하나에 1 초 · 첫 조회 줄이 생기면 SIGINT)
run_case t9 full "$ALL,stat" bgint FAKE_STAT_DELAY=1
# t8 게이트: (a) 본문 한 글자 (b) CRLF (c) 대화형 bash -i (d) CRLF 를 DEM1 sed 로 고친 사본 = 원본
sed '0,/q9b · q2b · q7b 시작/s//q9b · q2b · q7b 시직/' "$BLOCK" > "$T/block_onechar.txt"
cmp -s "$T/block_onechar.txt" "$BLOCK" && echo "경고: 한 글자 바꾸기가 안 됨"
BLK="$T/block_onechar.txt" run_case t8a full "$ALL" plain
sed 's/$/\r/' "$BLOCK" > "$T/block_crlf.txt"
BLK="$T/block_crlf.txt" run_case t8b full "$ALL" plain
run_case t8c full "$ALL" inter
sed 's/\r$//' "$T/block_crlf.txt" > "$T/block_crlf_fixed.txt"
if cmp -s "$T/block_crlf_fixed.txt" "$BLOCK"; then echo same > "$T/t8d.cmp"; else echo different > "$T/t8d.cmp"; fi

python3 "$HERE/check_run.py" check "$T" "$MD5" | tee "$T/check.txt" | tail -n 3
cp "$T/check.txt" "$HERE/last_run${RUN_TAG:-}.txt"
grep -q '^== PASS [0-9]* · FAIL 0$' "$T/check.txt"

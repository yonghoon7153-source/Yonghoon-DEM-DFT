# new_homel2017_mpm_field_gradient_partitioning_fracture_self_contact 정독 근거 (카드 1 장 · 2026-11-10)

읽은 카드: `homel2017_mpm_field_gradient_partitioning_fracture_self_contact` (674 줄 · 원문 = 출판사 웹 전문 페이지 캡처 두 장 (글자 층 없음) 을 조각 25 장 + 2–5 배 확대로 직접 읽고 쓴 카드 · 정본 가지 커밋 `b5fe371ca`).
서지: Michael A. Homel · Eric B. Herbold, “Field-gradient partitioning for fracture and frictional contact in the material point method”, International Journal for Numerical Methods in Engineering, Volume 109, Issue 7 (17 February 2017), Pages 1013–1044 (first published 11 June 2016); DOI 10.1002/nme.5317.

적는 법: 위치의 `L숫자` = 카드 줄 번호 · 표지는 카드에 적힌 그대로 (`인쇄` · `[카드 산술]` · `[판독]` · `[미확인]` · `[카드 판독]` · `[우리 코드 판독]` · `[우리 기록]` · `[카드 추론]`).  논문 위치는 쪽 번호가 없어 절 · 식 · 그림 · 표 · Algorithm 번호로 적는다.  "우리 쪽 기록" = 논문 값이 아니라 카드가 적은 우리 코드 · 계산.

형식: `- [글자] slug | 내용 (값 · 단위) | 위치 | 표지 | 한계`

## a. 순수 SE (LPSCl · 황화물) 의 압력별 기공 곡선 · 진밀도 · 질량 기준 · 누른 채 / 뺀 뒤

이 카드에 없음 (압밀 곡선 · 기공 · 밀도 계산이 없는 논문 — 카드 §3-7 L218 · 재료도 황화물이 아니다).

## b. 압력을 뺄 때 되돌아오는 양과 잰 방법

되돌아온 양의 수치는 없음.  닿는 것만 적는다.

- [b] homel2017_mpm_field_gradient_partitioning_fracture_self_contact | 값 없음 — 탈압을 다루지 않는다 ('unload' · 'rebound' · 'springback' 을 보지 못함).  닿는 것 둘: 접촉력을 다가올 때만 걸어 “naturally allows separation of contact surfaces” (속도 판정) · 한 속도장에서는 실패한 층을 사이에 둔 부재가 인장을 계속 전달한다는 문장 | §0-2 (iv) L51 · §4-2 L250 · 논문 §1.1.1 · §1.1.2 | 인쇄 · [카드 정독] | 동적 문제 · 수치 없음
- [b] homel2017_mpm_field_gradient_partitioning_fracture_self_contact | 분리 판정이 속도뿐 — Bardenhagen 2001 의 수직 견인력 판정 (압축이 남아 있으면 접촉 유지) 은 언급 없음 · 점착 없음 · 표면 표지는 지워지지 않는다 (냉간 접합을 나타내려면 표지를 지우는 규칙이 따로 필요) | §4-2 L257 · §9-⑨ L558 | [카드 판독] · [카드 추론] | 탈압 시험 없음
- [b] homel2017_mpm_field_gradient_partitioning_fracture_self_contact (우리 쪽 기록) | 우리 MPM 이 판을 물릴 때 SE–SE · SE–AM 계면이 열리지 않고 당겨지는 것이 원리적으로 “a tensile member containing a single layer of failed (or even deleted) particles can still support a tensile load” 의 경우 | §9-③ L546 | [카드 추론] | 논문 값 아님 · 크기 미측정

## c. 항복 · 경도 · 크리프 값과 정의 · 일축 항복 세기 환산

LPSCl 값 없음.  항복 · 경도 · 크리프 없음 (소성 없는 초탄성 재료).  일축 항복 환산식 없음.  있는 것은 취성 파괴 값뿐이다.

- [c] homel2017_mpm_field_gradient_partitioning_fracture_self_contact | 인장 강도 σ_f 570 MPa (Kalthoff–Winkler) · 1.0 GPa (Charpy) · 파괴 에너지 G_f 22.13 N/mm (본문 — 표는 22.3 mJ mm⁻²; 354.1 mJ = 22.13 × 16 mm² 가 본문 값을 지지) · Weibull 기준 강도 140 MPa @ 8 cm³ · 계수 6.0 · 균열 속도 2 km/s (Brazilian) | §3-3 L117 · §3-4 L134 · L137 · §3-5 L171–172 · 논문 Table 2–4 · §3.2–3.4 | 인쇄 · [카드 산술] · [카드 판독] | 가상 재료 (E 190 GPa) · 최대 인장 주응력 판정 (Rankine) — 항복이 아니다 · 우리 재료 값으로 쓰지 않는다

## d. 단단한 입자와 무른 입자를 섞어 누를 때 단단한 입자의 하중 몫 · 재밍

이 카드에 없음 (입자 혼합 압밀이 없다).  닿는 것 하나만:

- [d] homel2017_mpm_field_gradient_partitioning_fracture_self_contact | 값 없음.  Brazilian 문제에서 파쇄된 조각이 옆 대칭면 (벽) 에 부딪혀 “the debris starts to fill the volume and become compressed” — 절 제목은 Fragmentation and compaction response 지만 다짐 단계의 수치 (밀도 · 기공 · 응력 곡선) 는 없다 | §3-5 L183 · 논문 §3.4 · Fig. 15 | 인쇄 | 서술 한 문장 · 동적 · 2D

## e. 점접촉 법칙이 큰 변형에서 깨지는 범위와 대안

이 카드에 없음 (DEM · 점접촉 법칙 언급 없음 — 카드 §0-2 (i) L48).

## f. MPM 의 접촉 · 다물체 · 강체 결합 방법과 해상도 규칙 · 수치 오차 추정

- [f] homel2017_mpm_field_gradient_partitioning_fracture_self_contact | 다물체 접촉을 물체별 속도장 없이: 입자의 손상 (또는 표면 표지) 을 3차 핵 (반경 r_p = 셀 대각선) 으로 합쳐 정규화한 D̄ = D/S 의 기울기를 입자에서 구하고 → 노드 대표 기울기 = 그 노드에 얹히는 입자 중 기울기가 가장 큰 것 (Algorithm 1) → 내적 ∇D̄_p · ∇D̄_i ≥ 0 이면 장 0, 아니면 장 1 (Algorithm 2) — 장 번호는 노드마다 따로 | §4-4–§4-5 L269–291 · 논문 §2.1–2.2 식 17–20 | 인쇄 | 기울기 계산식 · r_g 값 미인쇄 [미확인]
- [f] homel2017_mpm_field_gradient_partitioning_fracture_self_contact | 접촉 법칙 = Bardenhagen 식: 질량중심 속도 v^cm · 보정 법선 n* = ½(n_1 − n_2) (정규화 — 두 법선을 정확히 반대로 → 선운동량 보존) · 법선력 f^nor = (m/Δt)(v^cm − v̄)·n · Coulomb 접선력 = min(μ·‖f^nor‖, ‖f^tan‖) · 다가올 때만 접촉 (KKT) · 분리 조건 (완전 손상 입자 ≥ 1 ∧ min(D̄_1i, D̄_2i) > D̄^min = 0.25) 이 안 서면 두 장을 v^cm 에 묶음 (한 장) | §4-2 L243–257 · §4-6 L293–305 · 논문 §1.1.1 식 11–16 · §2.3 식 21 · Algorithm 3 | 인쇄 · [카드 산술] (속도 꼴로 바꾸면 Bardenhagen 2001 식 10 과 같음) | 분리는 속도 판정뿐 (견인력 판정 없음) · ε_m 값 미인쇄
- [f] homel2017_mpm_field_gradient_partitioning_fracture_self_contact | ⚠ 인쇄 부호 어긋남: 식 (11) 은 바깥 법선을 주는데 (1D 확인) 접촉 조건 “Σ n·v ≤ 0” · KKT f^nor ≥ 0 · Algorithm 3 16 행 (v^cm − v̄)·n > 0 은 안쪽 법선일 때 '다가옴' · Algorithm 3 22 행은 식 (16) 과 다르다 (크기를 한 번 더 곱한 꼴) → 구현은 두 블록 접근 / 이탈 단위 시험으로 규약 고정 | §4-2 L259 · §4-6 L302 · §12 L622–623 | [카드 판독] · [카드 산술] | 어느 쪽이 구현인지 논문만으로 알 수 없음
- [f] homel2017_mpm_field_gradient_partitioning_fracture_self_contact | 물체별 속도장 방식의 한계 (원문): 장 N 개면 접촉 쌍 N(N − 1) · “they do not strictly prevent interpentrability for N > 2 fields” · 2D 는 4 색 정리로 4 장, “In 3-D, there is no analogous theorem limiting the number of required fields” | §4-3 L263–265 · §0 L27 · 논문 §1.1.1 | 인쇄 | —
- [f] homel2017_mpm_field_gradient_partitioning_fracture_self_contact | 셋 이상이 한 노드에 만날 때: 분할은 노드마다 접촉 평면 하나를 가정 · 균열 교차는 '완전 손상 셀' 로 나타난다는 정성 설명뿐 · 정량 시험 없음 | §4-8 L319–328 · 논문 §2.2 끝 | 인쇄 · [카드 추론] (세 알갱이 중 둘이 그 노드에서 붙는다) | 오차 크기 미인쇄
- [f] homel2017_mpm_field_gradient_partitioning_fracture_self_contact | 강체 결합: 없음 (판도 변형체 · 경계는 대칭면) | §4-12 L392 | 카드 서술 | —
- [f] homel2017_mpm_field_gradient_partitioning_fracture_self_contact | 해상도 규칙: 지름당 셀 수 규칙 없음.  있는 것 — 핵 반경 = 셀 대각선 · 셀당 입자 방향당 2 개 · 표면 표지 띠 두께는 “consistent with the kernel radius” (수 없음) · 접촉면은 “resolved to within a single grid cell spacing” · 쓴 격자: Kalthoff–Winkler 100 × 100 셀 · Charpy Δx 1.00 / 0.50 / 0.25 mm (남은 단면 8 mm 에 8 / 16 / 32 셀) · Brazilian 지름당 55 / 106 / 159 셀 | §4-4 L274 · §4-10 L356 · §4-7 L315 · §11 L600 · §3-3 L118 · §3-4 L140 · §3-5 L176 | 인쇄 · [카드 산술] | 빌릿 · 쐐기 문제의 격자 · 입자 수 [미확인]
- [f] homel2017_mpm_field_gradient_partitioning_fracture_self_contact | 수치 오차 추정 ①: 미리 나눈 다중 장 해를 '정답' 으로 두고 속도 등고선을 눈으로 대조 (빌릿 · 쐐기–원판–블록) — “nearly identical” · 오차 노름 · 접촉 해석해 · 판 반력 없음 | §5-1 L401–402 · §3-7 L219 · 논문 §3.1 Fig. 8–9 | 인쇄 | 쌍 접촉뿐 · 소성 없음
- [f] homel2017_mpm_field_gradient_partitioning_fracture_self_contact | 수치 오차 추정 ②: 계 전체 에너지 수지 — 탄성 충돌로 기준 소산 2.5 % (Δx 1 mm) 를 먼저 재고 기대 파괴 에너지 G_f A_f = 354.1 mJ 와 대조: 소산 분할 387 / 373 / 368 ↔ 한 속도장 437 / 407 / 378 mJ (Δx 1 / 0.5 / 0.25 mm) | §3-4 L137–149 · 논문 §3.3 Fig. 13 | 인쇄 (354.1 mJ · 2.5 %) · [판독 ±5 mJ] · [카드 산술] | 가상 재료 · 2D
- [f] homel2017_mpm_field_gradient_partitioning_fracture_self_contact | 수치 손잡이 민감도: 특성 길이 l^ch 를 셀 대각선의 ½ 배로 하면 소산 ≈ 482 mJ (1 배일 때 372 의 1.30 배) · 3/2 배면 343 mJ · D̄^min 0.01–0.25 는 겹침 | §3-4 L153–160 · 논문 Fig. 14 | [판독 ±5 mJ] · [카드 산술] · 인쇄 (겹침은 캡션) | —
- [f] homel2017_mpm_field_gradient_partitioning_fracture_self_contact | 비용 (2D · CPU 16 스레드 · 셀당 2 × 2 × 1): 입자 32,000–150,000 에서 한 속도장 대비 +30–50 % · 이웃 정렬 < 0.1 % · DFG 계산은 가장 큰 문제에서 전체의 30 % · 맞춤 기울기 DFP 1.23 (1 스레드) · 1.27 (16) ↔ SF 1.01 · 0.89 | §3-6 L187–197 · 논문 §3.5 Fig. 19 | 인쇄 | 3D 값 없음 · 판독한 점의 비 (5.7 만–7.3 만 입자에서 ≈ 1.8–1.9 배) 는 본문 범위보다 큼 (L211 [카드 판독])
- [f] homel2017_mpm_field_gradient_partitioning_fracture_self_contact | 이웃 수: 반경 = 셀 대각선 · 입자 간격 Δx/2 → 2D ≈ 25 · 3D ≈ 174 (6.9 배) | §3-6 L213 | [카드 산술 — 논문에 없는 수] | —
- [f] homel2017_mpm_field_gradient_partitioning_fracture_self_contact | 시간 간격 · CFL: 미인쇄 (걸음 수 3,000–18,000 만) | §3-7 L221 | [미확인] | —

## g. 2D 결과를 3D 로 옮길 때의 경고나 증거

- [g] homel2017_mpm_field_gradient_partitioning_fracture_self_contact | 미리 나누는 속도장의 수: “The four-color theorem states that any 2-D domain can be partitioned to avoid edge-to-edge contact of matching fields with no more than four fields 45.  In 3-D, there is no analogous theorem limiting the number of required fields to ensure frictional contact between all entities, and even if the geometry can be initialized such that neighboring particles are in separate velocity fields, subsequent deformation and granular flow can change the contact points.” | §0 L27 · §0-2 (iii) L50 · 논문 §1.1.1 | 인쇄 | 방법의 장 수에 대한 말 — 물리량의 2D → 3D 전이에 대한 말은 없다
- [g] homel2017_mpm_field_gradient_partitioning_fracture_self_contact | 정량 검증은 전부 2D 평면변형 (“The 2-D computational examples in this work are all plane strain”) · 3D 는 Fig. 20 한 장 — “included simply to demonstrate that the method is not limited to two dimensions” · 값 없음 | §0-2 (iii) L50 · §11 L612 · 논문 §2.7 · §4 | 인쇄 | 3D 정량 검증 0 건
- [g] homel2017_mpm_field_gradient_partitioning_fracture_self_contact | 차원에 따라 달라지는 정의: 핵 반경 · 특성 길이 = 셀 대각선 (2D √(Δx² + Δy²) · 3D √(Δx² + Δy² + Δz²)) · 평면변형에서도 입자 부피 (Weibull) 를 위해 두께를 정해야 함 · “Computational expense becomes an important factor when solving complex 3-D problems.” | §0-2 (iii) L50 · 논문 §2.1 · §2.7 · §4 | 인쇄 | —
- [g] homel2017_mpm_field_gradient_partitioning_fracture_self_contact | 비용의 전이: 2D 의 +30–50 % 는 이웃 ≈ 25 개일 때의 값 — 3D 는 ≈ 174 개 | §3-6 L213 · §8-3 L527 | [카드 산술] | 3D 실측 없음

## h. DEM 에서 FE · MPM 으로 넘긴 선례와 넘긴 시점

이 카드에 없음 (DEM 언급 없음).  참고로 CT 복셀 자료에서 MPM 모형을 바로 만든다는 서술은 있다 (카드 §4-1 L240 · §4-7 L316) — DEM 인계가 아니다.

## i. 복합 양극 (AM + SE) 의 압력별 기공

이 카드에 없음.

## j. 카드가 스스로 "아직 못 한다 · 한계" 라고 적은 것 가운데 가압 · 탈압 계산과 닿는 것

- [j] homel2017_mpm_field_gradient_partitioning_fracture_self_contact | 접촉 틈: “Contact surfaces in the MPM are resolved to within a single grid cell spacing, which … can also result in a nonphysical gap at the contact surface between two approaching bodies. … for compaction of granular materials (or porous materials with a high internal surface area), this could lead to a value of the continuum density that is inconsistent with the particle density.  This error decreases with mesh refinement but should be accounted for when interpreting mesoscale results.” | §11 L600 · §9-④ L548 · 논문 §4.2 | 인쇄 | 크기 미인쇄 — 카드 어림: 지름 7 셀 알갱이에서 틈 1 셀 = 지름의 ≈ 14 % 규모 [카드 산술 · 틈 = 1 셀 가정]
- [j] homel2017_mpm_field_gradient_partitioning_fracture_self_contact | 장이 셋 이상이면 쌍별 접촉력이 침투를 엄밀히 막지 못한다 (“We are currently developing other approaches to address this limitation”) · 분할은 노드마다 접촉 평면 하나를 가정 | §11 L598–599 · 논문 §1.1.1 · §2.2 | 인쇄 | 조밀 충전의 세 알갱이 선에서의 오차 미측정
- [j] homel2017_mpm_field_gradient_partitioning_fracture_self_contact | 처음부터 닿아 있는 알갱이는 표면 탐지로 못 찾는다 — “it would be necessary to 'paint in' the surface flag at initialization” | §11 L607 · §4-7 L314 · 논문 §2.4 | 인쇄 | 우리 DEM 씨앗 침대가 이 경우 (카드 §8-2 L518 [우리 코드 판독 · 카드 추론])
- [j] homel2017_mpm_field_gradient_partitioning_fracture_self_contact | 소성 · 연성 재료: 시험 없음 — 연성 파괴 · 전단띠에는 비국소 구성 모델이 필요 (“a constitutive modeling issue, independent of the methods presented herein”) · 자기 접촉이 비탄성 변형에서도 선다는 것은 주장뿐 | §11 L603 · §5-1 L404 · 논문 §4.2 · §3.1 | 인쇄 | —
- [j] homel2017_mpm_field_gradient_partitioning_fracture_self_contact | MPM 은 에너지를 근사적으로만 보존 (탄성 충돌에서 2.5 % 손실 · Δx 1 mm) | §11 L608 · 논문 §3.3 | 인쇄 | 동적 문제
- [j] homel2017_mpm_field_gradient_partitioning_fracture_self_contact | 이 방법이 소성 재료의 준정적 조밀 압밀 · 탈압에서 어떻게 행동하는지는 이 논문으로 알 수 없다 | §12 L634 | 카드 서술 (표지 없음) | —

## k. DEM 의 한계

- [k] homel2017_mpm_field_gradient_partitioning_fracture_self_contact (Homel & Herbold, Int. J. Numer. Meth. Engng 109(7), 1013–1044, 2017) | **말 없음** — 본문에서 'DEM' · 'discrete element' 를 보지 못했다 (글자 층이 없어 전문 검색은 못 함 · 참고문헌 목록은 캡처에 없음).  DEM 을 쓰지도 말하지도 않는 논문 | §0-2 (i) L48 | [카드 정독] | —
- [k] homel2017_mpm_field_gradient_partitioning_fracture_self_contact (Homel & Herbold, Int. J. Numer. Meth. Engng 109(7), 1013–1044, 2017) · DEM 이 아니라 **MPM 한 속도장**의 한계 (후보 A′ 가 필요한 이유의 인용처) | “The MPM algorithm outlined in Equations 1–10 computes the response for material in a single velocity field.  Within this velocity field, the method naturally produces a no-slip contact condition that prevents interpenetration between materials.” (§1.1.1) · “A single velocity-field MPM solution can produce artificial 'welding' of material interfaces or nonphysical localization when the constitutive response includes softening or damage 32.” (§1) · “a tensile member containing a single layer of failed (or even deleted) particles can still support a tensile load, when the particle width is less than the grid cell spacing” (§1.1.2) | §0 L21–23 · §9-③ L546 | 인쇄 (카드가 따옴표로 옮김) | 가상 재료 · 동적 문제
- [k] homel2017_mpm_field_gradient_partitioning_fracture_self_contact (Homel & Herbold, Int. J. Numer. Meth. Engng 109(7), 1013–1044, 2017) · **물체마다 속도장을 두는 MPM 접촉**의 한계 | 4 색 정리 문장 (위 g) · “For N velocity fields, there are N(N − 1) possible contact pairs, so the computational cost and memory requirements for the contact algorithm become more significant as N becomes large.” · “while pairwise force calculations ensure conservation of linear momentum, they do not strictly prevent interpentrability for N > 2 fields.” (§1.1.1) | §4-3 L263–265 | 인쇄 (카드가 따옴표로 옮김) | —
- [k] homel2017_mpm_field_gradient_partitioning_fracture_self_contact (Homel & Herbold, Int. J. Numer. Meth. Engng 109(7), 1013–1044, 2017) · 다른 방법 일반 | “A variety of computational methods to simulate fracture and large deformation have been developed for applications in solid mechanics, but each has its limitations with respect to either accuracy or robustness when simulating large-deformation fracture with subsequent frictional contact in complex 3-D geometries.” (§1) · “This 'granular flow' phase occurs in fragmentation and comminution processes and can be exceedingly difficult to model with other numerical methods.” (§3.1) | §0-2 (i) L48 | 인쇄 | 어느 방법인지 이름을 들지 않는다

## l. 소성변형이 왜 어려운가

- [l] homel2017_mpm_field_gradient_partitioning_fracture_self_contact (Homel & Herbold, Int. J. Numer. Meth. Engng 109(7), 1013–1044, 2017) | 어렵다는 설명 **없음** — 이 논문에 소성 계산이 없다 (초탄성 neo-Hookean + 스칼라 인장 손상).  큰 변형은 MPM 이 견딘다는 쪽의 말만: “The material state history is stored at the particles, so that advection errors are eliminated.” · “The background grid is reset at each time step, so the method tolerates large deformation.” (§1.1) · “by avoiding advection errors, it becomes possible to accurately use more sophisticated constitutive models for large-deformation solid mechanics.  However, for the examples presented herein, we use a relatively simplistic phenomenological model” (§2.7) | §0-2 (ii) L49 | 인쇄 (카드가 따옴표로 옮김) | 가공 경화 · 이웃 접촉의 상호 영향 · 하중 이력 · 탈압 언급 없음
- [l] homel2017_mpm_field_gradient_partitioning_fracture_self_contact (Homel & Herbold, Int. J. Numer. Meth. Engng 109(7), 1013–1044, 2017) | 비탄성에 닿는 두 마디: 자기 접촉이 “even if the solid material is undergoing large (potentially inelastic) deformation” 에서도 선다는 주장 (§3.1 · 시험 없음) · 연성 파괴 · 전단띠에는 “a non-local constitutive model 74 formulation” 이 필요 (§4.2) | §0-2 (ii) L49 · §11 L603 | 인쇄 | —
- [l] homel2017_mpm_field_gradient_partitioning_fracture_self_contact (Homel & Herbold, Int. J. Numer. Meth. Engng 109(7), 1013–1044, 2017) | 우회의 값: 실험에 맞춘 값 0 개 (“without requiring any parameter tuning”, §3.2 — 파괴값은 다른 XFEM 해석 것을 그대로) · 다만 수치 손잡이 D̄^min · l^ch 는 저자 표현으로 “can be tuned” · 검증 = 2D 예제 5 건 (눈 대조 2 · Kalthoff–Winkler 각 / 속도 · Charpy 에너지 · Brazilian 격자 민감도) · 비용 = 2D 입자 ≤ ≈ 2.3 × 10⁵ · 걸음 3,000–18,000 · 걸음당 0.1–3.8 s (16 스레드) · 한 속도장 대비 +30–50 % | §0-2 (ii) L49 · §3-6 L187–211 · §3-4 L162 | 인쇄 · [판독] (걸음당 시간) | 소성 · 압밀과 무관한 검증

## m. 받아들일 통찰

- [m] homel2017_mpm_field_gradient_partitioning_fracture_self_contact | **접촉 틈의 몫을 먼저 뺀다**: 접촉을 넣은 MPM 으로 잰 압밀 기공률은 dx 사다리로 접촉 틈 (≈ 1 셀 · 새로 만나는 면에 생김) 의 몫을 뺀 뒤에만 실험과 견준다 → 단계 0 (기공률 연산자) · U6 · 결과 전 대조 항목 | 근거: 저자 경고 논문 §4.2 (카드 L600) · Fig. 6 의 흰 틈 (L453 [판독]) · 카드 §9-④ L548 · §10 행동 5 L587 | 인쇄 + [카드 추론] | 틈의 크기는 논문에 수치 없음 — 우리가 재야 한다
- [m] homel2017_mpm_field_gradient_partitioning_fracture_self_contact | **세 해 겹치기 시험**: 판 사이 빌릿 압축을 (i) 한 속도장 (ii) 판 · 빌릿 두 장 (iii) 표면 표지 분할로 풀어 겹친다 — 다중 장 해가 기준.  우리는 판 반력 · 옆면 변위 · 미끄럼량을 숫자로 (논문은 눈 대조).  앞서 두 블록 접근 / 이탈 시험으로 부호 규약을 고정 (식 11 ↔ Algorithm 3 16 행이 인쇄에서 엇갈림) → 단계 3 · U0 · U2 | 근거: 논문 §3.1 Fig. 7–8 (카드 L401–402) · 카드 L259 · §10 행동 2–3 L584–585 | 인쇄 + [카드 판독] | Table 1 의 재료값은 본문과 안 맞아 쓰지 않는다 (L102)
- [m] homel2017_mpm_field_gradient_partitioning_fracture_self_contact | **장 2 개 + 셋 이상 노드 통계**: 후보 A′ 의 장 수를 알갱이 수에서 떼어 내는 길 (노드마다 2 장 ≈ 1.81 GB ↔ 알갱이별 장 ≈ 30 TB) — 대신 근사가 걸리는 자리는 '노드당 알갱이 수 ≥ 3' 인 노드이므로, real_14 씨앗으로 그 비율을 결과 전에 잰다 (GPU 불요 · Bardenhagen 2001 의 N ≤ 2 가정 점검과 같은 계산) → 단계 1 · 후보 A′ | 근거: 논문 §1.1.1 (N > 2 침투 · 4 색 정리) · §2.2 끝 (접촉 평면 하나) · 카드 §8-2 L514 · §9-② L544 · §10 행동 1 L583 | 인쇄 + [카드 산술] + [카드 추론] | 3D 비용 (이웃 ≈ 174 개) 은 따로 재야 한다 (L588)
- [m] homel2017_mpm_field_gradient_partitioning_fracture_self_contact | **에너지 수지 + 수치 소산 띠**: 탄성 충돌로 기준 소산 (2.5 %) 을 먼저 재고, 해석 기대값 선과 그 띠를 그린 뒤 접촉 표현들을 겹친다 → U3 · U4 (눌렀다 떼기 · 판 분리) 의 보고 틀 · 단계 6 | 근거: 논문 §3.3 Fig. 13 (카드 L139 · L143–149) · 카드 §7 L483 · §9-⑥ L552 | 인쇄 + [카드 추론] | 우리 쪽 기대값 (소성 일 + 되돌아온 탄성 에너지) 은 따로 세워야 한다

## 카드 문제

없음 (카드 안의 모순은 찾지 못함).  참고 — 카드가 스스로 표지해 둔 원문 인쇄 / 판독의 어긋남: 법선 부호 규약 (L259) · Algorithm 3 22 행 (L302) · τ = c_f/ℓ (L338) · Table 1 빌릿 탄성값 (L102) · Table 2 w_t 10 mm · G_f 22.3 ↔ 22.13 (L114 · L117) · n_p 129553 ↔ 129,533 (L175) · “50µs” (L180) · Fig. 19 판독 비 ↔ 본문 +30–50 % (L211).  이 값들을 인용할 때는 카드 §12 (L621–632) 를 같이 볼 것.

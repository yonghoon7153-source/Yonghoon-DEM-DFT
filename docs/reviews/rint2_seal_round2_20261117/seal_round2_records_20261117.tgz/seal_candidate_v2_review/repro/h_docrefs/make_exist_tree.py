"""git ls-tree 의 모든 경로를 만든다 — .md · 참조 검사기가 읽는 tsv 는 실제 바이트, 나머지는 빈 파일 (존재만).  .git = 사본 gitdir 을 가리키는 gitfile."""
import os, sys, subprocess
clone, rev, out = sys.argv[1:4]
os.makedirs(out)
ls = subprocess.run(['git', '-C', clone, 'ls-tree', '-r', '-z', rev], capture_output=True, check=True).stdout.split(b'\0')
want, n_all = [], 0
for ent in ls:
    if not ent:
        continue
    meta, path = ent.split(b'\t', 1)
    mode, typ, obj = meta.split()
    path = path.decode('utf-8')
    n_all += 1
    p = os.path.join(out, path)
    os.makedirs(os.path.dirname(p), exist_ok=True)
    if typ != b'blob':
        os.makedirs(p, exist_ok=True); continue
    if path.endswith('.md') or path.endswith('.tsv'):
        want.append((obj.decode(), p))
    else:
        open(p, 'wb').close()
proc = subprocess.Popen(['git', '-C', clone, 'cat-file', '--batch'], stdin=subprocess.PIPE, stdout=subprocess.PIPE)
for obj, p in want:
    proc.stdin.write((obj + '\n').encode()); proc.stdin.flush()
    hdr = proc.stdout.readline().split()
    size = int(hdr[2]); data = proc.stdout.read(size); proc.stdout.read(1)
    open(p, 'wb').write(data)
proc.stdin.close(); proc.wait()
gd = subprocess.run(['git', '-C', clone, 'rev-parse', '--absolute-git-dir'], capture_output=True, text=True).stdout.strip()
open(os.path.join(out, '.git'), 'w').write(f'gitdir: {gd}\n')
print(f'entries {n_all} · real (.md/.tsv) {len(want)}')

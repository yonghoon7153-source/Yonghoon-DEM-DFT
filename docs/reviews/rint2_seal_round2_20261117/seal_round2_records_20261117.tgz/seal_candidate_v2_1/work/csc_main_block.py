TOOLS = ('rint_r_chain.py', 'ca_s0_census.py')
ALLOWED = ('kgy', 'gabia', 'v100')
STORE_RAW = '~/ca1_cjstore'                 # 1저자 11-17 봉인 후보 Q4 — R 저장본 = 기계마다 새 빈 폴더 (글자 그대로 · ~ 는 실행 셸이 편다)
LAW_MACHINE = {'P0': 'kgy', 'P1': 'gabia'}  # 1저자 11-17 봉인 후보 Q6 — 사다리 P0 = kgy · P1 = gabia
ONLY_ONE_OK = {'ladder_dry'}                # 한 문서에만 있어도 되는 종류 (사다리 dry-run = 명령 문서 §3-1b (4) 에만 · 설계)
#: 도구 이름이 인자 (파일 경로) 로만 나오는 줄의 첫 낱말 — 부르는 줄이 아니다 (예: same-version 손 확인 `git diff --quiet … scripts/ca_s0_census.py`)
NONINV_OK = ('git', 'ls', 'cp', 'cat', 'grep', 'sha256sum', 'test', 'echo', 'printf')
_SPLIT = re.compile(r'\s(?:&&|\|\||\||;)\s')
_PY = re.compile(r'(^|/)python3?$')


def scan(path):
    """문서 하나의 모든 울타리 (```sh · ```bash · 그 밖) 를 읽는다 — 논리 줄 (`\\` 이음 · 주석 줄 뺌 · 자리표 <…> → '1') 을 && · || · | · ; 로 갈라
    도구 (사슬 · S0) 를 부르는 조각 = `python3? <…>/<도구>` 꼴만 읽는다.  도구 이름이 든 조각인데 그 꼴이 아니면 = 못 읽은 줄 (첫 낱말이 NONINV_OK 면
    인자로만 나온 줄 · 따로 센다).  → {'cmds': [(울타리, 줄, 도구, 인자 (raw))], 'unread': [(울타리, 줄, 조각)], 'argonly': [(울타리, 줄, 첫 낱말)]}"""
    out = {'cmds': [], 'unread': [], 'argonly': []}
    fence, buf, start = None, '', 0
    for i, ln in enumerate(Path(path).read_text(encoding='utf-8').splitlines(), 1):
        s = ln.strip()
        if s.startswith('```'):
            fence = (s[3:].strip() or '(없음)') if fence is None else None
            buf = ''
            continue
        if fence is None:
            continue
        if not buf:
            if not s or s.startswith('#'):
                continue
            start = i
        cont = s.endswith('\\')
        buf += ' ' + (s[:-1] if cont else s)
        if cont:
            continue
        line, buf = re.sub(r'<[^<>]*>', '1', buf), ''
        for seg in _SPLIT.split(line):
            if not any(t in seg for t in TOOLS):
                continue
            try:
                toks = shlex.split(seg, comments=True)
            except ValueError:
                out['unread'].append((fence, start, seg.strip()[:120]))
                continue
            for tool in TOOLS:
                named = [k for k, t in enumerate(toks) if t == tool or t.endswith('/' + tool)]
                if not named:
                    continue
                at = [k for k in named if k > 0 and _PY.search(toks[k - 1])]
                if not at:
                    w = [t for t in toks if t not in ('nohup', 'exec', 'time')]
                    if w and w[0] in NONINV_OK:
                        out['argonly'].append((fence, start, w[0]))
                    else:
                        out['unread'].append((fence, start, seg.strip()[:120]))
                    continue
                args, skip = [], False
                for t in toks[at[0] + 1:]:
                    if skip:
                        skip = False
                        continue
                    if t == '>':
                        skip = True
                        continue
                    if re.match(r'^\d*>', t) or t == '&':
                        continue
                    args.append(t)
                out['cmds'].append((fence, start, tool, args))
    return out


class _Took(Exception):
    pass


def check(tree, sealed_rel, fakehome, expect):
    """→ (화면 줄, 문제 목록).  사슬 · S0 argparse = 그 트리의 scripts (단계 함수 · S0 관문 = 받기만 · 리포 무변경 · 결과 0 건 · σ 없음)."""
    sys.path.insert(0, str(Path(tree) / 'scripts'))
    import rint_r_chain as RR  # noqa: E402
    import ca_s0_census as S0m  # noqa: E402
    fh = Path(fakehome)
    assert not fh.exists(), fakehome
    (fh / STORE_RAW[2:]).mkdir(parents=True)
    os.chmod(fh / STORE_RAW[2:], 0o755)
    reg_abs = str(fh / 'dem-ca1' / sealed_rel)
    docs = (('sealed', Path(tree) / sealed_rel), ('kgy', Path(tree) / KGY_REL), ('orig', Path(tree) / ORIG_REL))
    got = {}

    def _stub(a, contract=None):
        got['a'] = a
        return 0

    def _vpc(*_a, **_k):
        raise _Took()
    saved = {k: getattr(RR, k) for k in ('stage_ladder', 'stage_predict', 'stage_verdict', 'stage_ledger', 'stage_recover', 'stage_plan_doc')}
    saved_vpc = S0m.verify_plan_commit
    for k in saved:
        setattr(RR, k, _stub)
    S0m.verify_plan_commit = _vpc
    kinds, bad, counts, regvals, rdocs = {}, [], {}, {}, {}

    def home(t):
        return t.replace('~/', str(fh) + '/', 1) if t.startswith('~/') else t
    try:
        for dn, path in docs:
            sc = scan(path)
            c = counts[dn] = {'sh_chain': 0, 'sh_s0': 0, 'bash_chain': 0, 'bash_s0': 0, 'unread': len(sc['unread']), 'argonly': len(sc['argonly']),
                              'other': 0}
            for fence, ln, seg in sc['unread']:
                bad.append(f'{dn}:{ln} 못 읽은 줄 (```{fence} · 도구 이름이 있는데 `python3? <…>/<도구>` 꼴이 아니다) — {seg[:90]!r}')
            for fence, ln, tool, raw in sc['cmds']:
                short = 'chain' if tool == 'rint_r_chain.py' else 's0'
                if fence == 'bash':
                    c['bash_' + short] += 1            # 인자 계약 꼴 (리포 시험 K01 이 원본 자리 · 명령 문서의 이 꼴을 argparse 와 대조 · --registration 없음 = 설계)
                    continue
                if fence != 'sh':
                    c['other'] += 1
                    bad.append(f'{dn}:{ln} sh · bash 밖 울타리 (```{fence}) 의 도구 줄')
                    continue
                c['sh_' + short] += 1
                if dn == 'orig':
                    bad.append(f'{dn}:{ln} 원본 자리 (봉인 전 판 + 표지 한 줄) 에 sh 실행 줄')
                    continue
                args = [home(t) for t in raw]
                if short == 's0':
                    stage = raw[raw.index('--stage') + 1] if '--stage' in raw[:-1] else None
                    if stage != '2':
                        bad.append(f'{dn}:{ln} S0 명령 --stage {stage}')
                        continue
                    err = io.StringIO()
                    try:
                        with contextlib.redirect_stderr(err), contextlib.redirect_stdout(io.StringIO()):
                            rc = S0m.main(args)
                        bad.append(f'{dn}:{ln} S0 단계 2 → rc {rc} (관문 앞 인자 검사) · {(err.getvalue().strip().splitlines() or [""])[-1][:160]}')
                        continue
                    except _Took:
                        pass
                    except SystemExit as e:
                        bad.append(f'{dn}:{ln} S0 단계 2 → argparse rc {e.code}')
                        continue
                    rdoc = raw[raw.index('--r-doc') + 1] if '--r-doc' in raw[:-1] else None
                    rdocs.setdefault(dn, set()).add(rdoc)
                    if rdoc != sealed_rel:
                        bad.append(f'{dn}:{ln} S0 단계 2 --r-doc = {rdoc!r} (≠ {sealed_rel!r})')
                    kinds.setdefault((dn, 's0-2'), set()).add(frozenset(t for t in raw if t.startswith('--')))
                    continue
                if '--cjunc-store' in raw:
                    v = raw[raw.index('--cjunc-store') + 1] if '--cjunc-store' in raw[:-1] else None
                    if v != STORE_RAW:
                        bad.append(f'{dn}:{ln} --cjunc-store {v!r} ≠ {STORE_RAW} (Q4 · 기계마다 새 빈 폴더)')
                got.clear()
                err = io.StringIO()
                try:
                    with contextlib.redirect_stderr(err), contextlib.redirect_stdout(io.StringIO()):
                        rc = RR.main(args, contract=object())
                except SystemExit as e:
                    rc = f'argparse rc {e.code} · {(err.getvalue().strip().splitlines() or [""])[-1][:160]}'
                if rc != 0 or 'a' not in got:
                    bad.append(f'{dn}:{ln} {raw[:2]} → {rc}')
                    continue
                a = got['a']
                if a.stage == 'predict':
                    k = 'unit' if a.unit else 'point' if a.point else ('merge_x' if a.expand else 'merge') if a.merge else 'predict'
                elif a.stage == 'ledger':
                    k = 'ledger_init' if a.init else 'ledger_add'
                elif a.stage == 'verdict':
                    k = 'reverify' if a.reverify else 'verdict'
                elif a.stage == 'ladder':
                    k = 'ladder_dry' if a.dry_run else 'ladder'
                else:
                    k = a.stage
                kinds.setdefault((dn, k), set()).add(frozenset(t for t in raw if t.startswith('--') and t != '--machine'))
                regvals.setdefault(dn, set()).add(a.registration)
                if '--registration' not in raw or a.registration != reg_abs:
                    bad.append(f'{dn}:{ln} {k} --registration = {a.registration!r} (≠ 봉인본 {reg_abs!r})')
                if k in ('ladder', 'unit', 'point') and not (a.ledger and a.attempt is not None and a.cjunc_store):
                    bad.append(f'{dn}:{ln} {k} = 원장 시도 꼴 + 저장본이 아니다')
                if k in ('ladder', 'ladder_dry', 'unit', 'point') and '--cjunc-store' not in raw:
                    bad.append(f'{dn}:{ln} {k} 에 --cjunc-store {STORE_RAW} 가 없다 (Q4)')
                if k in ('merge', 'merge_x') and (a.attempt is not None or a.cjunc_store):
                    bad.append(f'{dn}:{ln} {k} 에 --attempt · --cjunc-store')
                if a.stage in ('ladder', 'predict') and a.max_hours != 168.0:
                    bad.append(f'{dn}:{ln} --max-hours {a.max_hours}')
                if a.machine is not None and a.machine not in ALLOWED:
                    bad.append(f'{dn}:{ln} --machine {a.machine}')
                if k in ('ladder', 'ladder_dry') and LAW_MACHINE.get(a.law) != a.machine:
                    bad.append(f'{dn}:{ln} {k} --law {a.law} --machine {a.machine} (Q6 · P0 = kgy · P1 = gabia)')
                if k == 'ledger_add' and (a.ledger_target or '').startswith('ladder:'):
                    law = a.ledger_target.split(':')[1] if a.ledger_target.count(':') == 1 else None
                    if law in LAW_MACHINE and LAW_MACHINE[law] != a.machine:
                        bad.append(f'{dn}:{ln} ledger --add {a.ledger_target} --machine {a.machine} (Q6)')
    finally:
        for k, v in saved.items():
            setattr(RR, k, v)
        S0m.verify_plan_commit = saved_vpc
    for dn in ('sealed', 'kgy'):
        want, c = expect[dn], counts[dn]
        if (c['sh_chain'], c['sh_s0']) != want:
            bad.append(f'{dn}: 기대 셈 사슬 {want[0]} + S0 {want[1]} ≠ 읽은 sh 명령 {c["sh_chain"]} + {c["sh_s0"]}')
        if c['sh_chain'] + c['sh_s0'] == 0:
            bad.append(f'{dn}: sh 명령 0 개 (실행 줄 울타리가 없다)')
    rows = [f'# 봉인본 {sealed_rel} · 가짜 홈 = <가짜 홈> · 기대 셈 {_fmt_expect(expect)} · 저장본 {STORE_RAW} (Q4) · 사다리 기계 {LAW_MACHINE} (Q6)']
    for dn, c in counts.items():
        rows.append(f'{dn}: sh 블록 사슬 명령 {c["sh_chain"]} · S0 명령 {c["sh_s0"]} · 계약 꼴 (bash) 사슬 {c["bash_chain"]} · S0 {c["bash_s0"]} · '
                    f'그 밖 울타리 {c["other"]} · 도구 이름이 인자로만 나온 줄 {c["argonly"]} · 못 읽은 줄 {c["unread"]} · '
                    f'--registration 값 {sorted(v.replace(str(fh), "<가짜 홈>") for v in regvals.get(dn, set()))} · S0 --r-doc 값 {sorted(map(str, rdocs.get(dn, set())))}')
    allk = sorted({k for _d, k in kinds})
    for k in allk:
        r, g = kinds.get(('sealed', k), set()), kinds.get(('kgy', k), set())
        same = (r == g) if r and g else None
        rows.append(f'  {k:12s} 봉인본 {len(r)} 집합 · kgy {len(g)} 집합 · 두 문서 같음 {same}' + (f' · 인자 {sorted(next(iter(r or g)))}' if (r or g) else ''))
        if r and g and r != g:
            bad.append(f'{k}: 두 문서 인자 이름 다름 — 봉인본 {sorted(sorted(x) for x in r)} ↔ kgy {sorted(sorted(x) for x in g)}')
    only = [k for k in allk if bool(kinds.get(('sealed', k))) != bool(kinds.get(('kgy', k)))]
    rows.append(f'한 문서에만 있는 종류 {only} (허용 = {sorted(ONLY_ONE_OK)})')
    for k in only:
        if k not in ONLY_ONE_OK:
            bad.append(f'{k}: 한 문서에만 있는 종류 (허용 = {sorted(ONLY_ONE_OK)})')
    return rows, [b.replace(str(fh), '<가짜 홈>').replace(str(tree), '<트리>') for b in bad]


def main(argv):
    import argparse
    p = argparse.ArgumentParser(description=__doc__.split('\n')[0])
    p.add_argument('tree')
    p.add_argument('sealed_rel')
    p.add_argument('fakehome')
    p.add_argument('--expect', required=True, help='sealed=<사슬>+<S0>,kgy=<사슬>+<S0> — 두 문서 sh 블록의 기대 명령 수 (독립 셈과 맞춘 값)')
    a = p.parse_args(argv)
    rows, bad = check(os.path.abspath(a.tree), a.sealed_rel, os.path.abspath(a.fakehome), _parse_expect(a.expect))
    for r in rows:
        print(r)
    print('문제', json.dumps(bad, ensure_ascii=False) if bad else '없음')
    return 1 if bad else 0


if __name__ == '__main__':
    sys.exit(main(sys.argv[1:]))

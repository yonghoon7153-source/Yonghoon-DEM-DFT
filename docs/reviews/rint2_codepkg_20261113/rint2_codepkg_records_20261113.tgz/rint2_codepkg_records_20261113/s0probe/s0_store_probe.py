#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""S0 단계 1 감싸개 — 실침대 원장으로 탄소 접합 원장 저장본 (scripts/cjunc_store.py) 의 쓰기 · 읽기를 잰다 (내부 반박 리뷰 RCP-04 · 11-12 · 초안).

  python3 s0_store_probe.py <기록 폴더> <저장본 폴더 (빈 · 0755 · 이 사용자)> <작업 트리>/scripts/ca_s0_census.py --stage 1 --kit <킷> --out <새 폴더>

하는 일: `carbon_junction.cjunc_registry` 를 감싸 (단계 1 = 한 번 · junction_census) 원장을 지은 직후 같은 프로세스에서
  ① encode_strict (받는 꼴인가 · 시간) ② Store.get_or_build (짓기 = 방금 지은 원장을 돌려주는 함수 → 싣기 · 쓰기 · 발행 전 다시 읽기 대조 · 상태 ·
  시간 · 바이트) ③ 새 Store 로 다시 get_or_build (짓기 함수 = 부르면 실패 → 적중이어야 · 읽기 시간) ④ 읽은 원장 ↔ 지은 원장 엄격 지문 · registry_fp
  ⑤ RSS (/proc/self/status VmRSS · VmHWM — ② 앞에서 /proc/self/clear_refs 5 로 최고값을 되돌려 ②–④ 의 최고값만 잰다)
  → <기록 폴더>/store_probe.json · 화면 한 줄 (stderr).  S0 에는 **지은 그 원장 객체**를 그대로 돌려준다 (읽은 사본은 놓고 gc) — S0 보고 ·
  계획 · 배열은 감싸개 없이 돈 것과 같다 (시간 칸 elapsed_s 만 다르다 · 시험 = 스크래치 픽스처 킷).
재기가 실패해도 (예외 · 메모리 부족) S0 는 계속한다 — 기록에 사유를 남긴다.  σ · 솔브 없음 (원장 = 기하).
⚠ 단계 1 원장 = s_min 미등록 (None · 자기 후보 전부) — R 팔의 원장 (봉인 s_min) 보다 instance 가 같거나 많다 = 크기 · 시간의 보수 쪽 어림.
"""
import gc
import json
import os
import runpy
import sys
import time


def _status():
    out = {}
    try:
        with open('/proc/self/status', encoding='ascii', errors='replace') as f:
            for ln in f:
                k, _, v = ln.partition(':')
                if k in ('VmRSS', 'VmHWM'):
                    out[k] = int(v.split()[0])                   # kB
    except OSError:
        pass
    return out


def _reset_hwm():
    try:
        with open('/proc/self/clear_refs', 'w') as f:
            f.write('5')
        return True
    except OSError:
        return False


def main():
    if len(sys.argv) < 4:
        print(__doc__, file=sys.stderr)
        return 2
    log_dir, store_dir, script = os.path.abspath(sys.argv[1]), os.path.abspath(sys.argv[2]), os.path.abspath(sys.argv[3])
    os.makedirs(log_dir, exist_ok=True)
    rec_path = os.path.join(log_dir, 'store_probe.json')
    sys.path.insert(0, os.path.dirname(script))
    import carbon_junction as CJ
    import cjunc_store as CS
    orig = CJ.cjunc_registry
    calls = []

    def wrapped(sid, box_lo, vox, add_pts, add_phase, add_fid, add_kind, **thr):
        t0 = time.time()
        reg = orig(sid, box_lo, vox, add_pts, add_phase, add_fid, add_kind, **thr)
        rec = {'call': len(calls) + 1, 'seconds_build': round(time.time() - t0, 3), 'thresholds': {k: thr[k] for k in sorted(thr)},
               'n_instances': None, 'encode': None, 'write': None, 'read': None, 'same': None, 'rss_kb': {}, 'error': None}
        calls.append(rec)
        try:
            rec['n_instances'] = int(len(reg['instances']['fi']))
            rec['rss_kb']['before'] = _status()
            rec['hwm_reset'] = _reset_hwm()
            t1 = time.time()
            try:
                strict, skel, arrays = CS.encode_strict(reg)
                rec['encode'] = {'ok': True, 'seconds': round(time.time() - t1, 3), 'n_arrays': len(arrays), 'skeleton_bytes': len(skel),
                                 'array_bytes': int(sum(int(a.nbytes) for a in arrays))}
            except CS.Unsupported as e:
                strict, skel, arrays = None, None, ()
                rec['encode'] = {'ok': False, 'why': f'Unsupported: {e}'[:300], 'seconds': round(time.time() - t1, 3)}
            del skel, arrays
            kw = dict(sid=sid, lo=box_lo, vox=vox, pts=add_pts, phase=add_phase, fid=add_fid, kind=add_kind, thresholds=thr)
            _r1, o1 = CS.Store(store_dir).get_or_build(lambda: reg, **kw)
            rec['write'] = {k: o1.get(k) for k in ('status', 'why', 'key', 'file', 'seconds_write', 'bytes')}
            rec['rss_kb']['after_write'] = _status()
            del _r1

            def must_not_build():
                raise RuntimeError('저장본 적중이어야 하는데 짓기를 불렀다 (재기 감싸개)')
            got = None
            try:
                got, o2 = CS.Store(store_dir).get_or_build(must_not_build, **kw)
                rec['read'] = {k: o2.get(k) for k in ('status', 'why', 'seconds_read', 'bytes')}
            except Exception as e:                         # noqa: BLE001 — 기록만 (S0 는 계속)
                rec['read'] = {'status': 'error', 'why': f'{type(e).__name__}: {e}'[:300]}
            rec['rss_kb']['after_read'] = _status()
            if got is not None and strict is not None:
                rec['same'] = {'strict': CS.strict_digest(got) == strict, 'registry_fp': CJ.registry_fp(got) == reg['fp']['registry'],
                               'object_is_new': got is not reg}
            del got
        except BaseException as e:                         # noqa: BLE001 — MemoryError 포함 · S0 는 계속 (KeyboardInterrupt 는 다시 올린다)
            if isinstance(e, KeyboardInterrupt):
                raise
            rec['error'] = f'{type(e).__name__}: {e}'[:400]
        finally:
            gc.collect()
            rec['rss_kb']['after_gc'] = _status()
            with open(rec_path, 'w', encoding='utf-8') as f:
                json.dump({'tool': 's0_store_probe v1 (11-12 RCP-04 초안)', 'store_dir': store_dir, 'calls': calls}, f, ensure_ascii=False, indent=1)
            w, r = rec.get('write') or {}, rec.get('read') or {}
            print(f'[store-probe] 원장 instance {rec.get("n_instances")} · 짓기 {rec["seconds_build"]} s · 싣기 '
                  f'{(rec.get("encode") or {}).get("seconds")} s ({(rec.get("encode") or {}).get("ok")}) · 쓰기 {w.get("status")} '
                  f'{w.get("seconds_write")} s {w.get("bytes")} B · 읽기 {r.get("status")} {r.get("seconds_read")} s · 같음 {rec.get("same")} · '
                  f'VmHWM(②–④) {(rec["rss_kb"].get("after_read") or {}).get("VmHWM")} kB · 오류 {rec.get("error")}', file=sys.stderr, flush=True)
        return reg
    CJ.cjunc_registry = wrapped
    sys.argv = sys.argv[3:]
    runpy.run_path(script, run_name='__main__')
    return 0


if __name__ == '__main__':
    sys.exit(main())

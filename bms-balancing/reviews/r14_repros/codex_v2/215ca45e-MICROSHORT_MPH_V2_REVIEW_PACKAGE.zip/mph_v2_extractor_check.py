"""Read-only independent parsing checks of the supplied COMSOL artifact."""
from __future__ import annotations

import contextlib
import hashlib
import importlib.util
import io
import json
from pathlib import Path
import re
import sys
import zipfile

from lxml import etree as LET
import xml.etree.ElementTree as ET

sys.stdout.reconfigure(encoding="utf-8")

WORKSPACE = Path(__file__).resolve().parents[1]
TARGET = WORKSPACE / "work/microshort-v2-d72e735f/bms-balancing"
ARCHIVE = Path("C:/Users/Administrator/Documents/카카오톡 받은 파일/ICA_degradation mode.zip")


def load():
    with zipfile.ZipFile(ARCHIVE) as outer:
        names = [n for n in outer.namelist() if n.lower().endswith(".mph")]
        assert len(names) == 1, names
        mph = outer.read(names[0])
    with zipfile.ZipFile(io.BytesIO(mph)) as inner:
        data = inner.read("dmodel.xml")
        members = [{"name": n.filename, "size": n.file_size} for n in inner.infolist()]
    tree = LET.fromstring(data).getroottree()
    spec = importlib.util.spec_from_file_location("submitted_dump", TARGET / "reviews/r14_repros/mph_dump.py")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return mph, data, tree, members, module


def describe(tree, node):
    return {"xpath": tree.getpath(node), "line": node.sourceline,
            "tag": node.tag, "attributes": dict(node.attrib),
            "text": (node.text or "").strip()[:250],
            "own_flags": [c.text for c in node if c.tag == "entityFlags"]}


def main():
    mph, data, tree, members, module = load()
    root = tree.getroot()
    if len(sys.argv) > 1 and sys.argv[1] == "inspect":
        print(json.dumps({"root": describe(tree, root), "members": members}, ensure_ascii=False, indent=2))
        return
    if len(sys.argv) > 2 and sys.argv[1] == "xpath":
        for el in tree.xpath(sys.argv[2]):
            if isinstance(el, LET._Element):
                print(json.dumps(describe(tree, el), ensure_ascii=False))
            else:
                print(el)
        return

    et_root = ET.fromstring(data)
    rows = module.walk_features(et_root)
    names = ("dPE", "dNE", "cs_NCM_init", "cs_Gr_init", "E_end", "x_NCM_max", "x_NCM_min", "i_app", "CurrentDirection")
    exprs = module.live_expressions(et_root)
    evidence = {
        "source": {"outer_archive": str(ARCHIVE), "mph_sha256": hashlib.sha256(mph).hexdigest(),
                   "dmodel_sha256": hashlib.sha256(data).hexdigest(), "dmodel_bytes": len(data)},
        "submitted_feature_rows": rows,
        "submitted_reference_hits": {n: module.count_refs(exprs, n) for n in names},
        "raw_selected_nodes": [], "synthetic_tests": [],
    }
    test_capture = io.StringIO()
    with contextlib.redirect_stdout(test_capture):
        module.test_extractor_ownership()
    evidence["submitted_self_test"] = test_capture.getvalue().strip()
    dump_capture = io.StringIO()
    with contextlib.redirect_stdout(dump_capture):
        module.main(["mph_dump.py", io.BytesIO(data), "--refs", ",".join(names[:-1])])
    stored_dump = (TARGET / "reviews/r14_repros/mph_dump_output.txt").read_text(encoding="utf-8")
    evidence["stored_dump_matches_regeneration"] = stored_dump.strip() == dump_capture.getvalue().strip()
    evidence["strict_direct_ownership_disagreements"] = []
    for el in et_root.iter():
        if el.tag not in ("Physics", "PhysicsFeature"):
            continue
        direct = {c.get("param"): c.get("value") for c in el if c.tag == "param" and c.get("param")}
        if direct != module._own_params(el):
            evidence["strict_direct_ownership_disagreements"].append({"tag": el.get("tag"), "direct": direct, "submitted": module._own_params(el)})
    evidence["raw_identifier_inventory"] = {n: [] for n in names}
    evidence["source_and_study_selector_nodes"] = [
        describe(tree, el) for el in tree.xpath(
            '//*[not(ancestor::actions) and (@param="cEeqref" or @param="cEeqref_mat" or '
            '@param="ParticleMaterial" or @name="p:activate" or @name="p:disabledphysics" or '
            '@name="p:disablesolving" or @name="p:active" or @name="p:solvefor")]'
        )
    ]
    for el in root.iter():
        if any(a.tag == "actions" for a in el.iterancestors()):
            continue
        if el.tag == "actions":
            continue
        for field, value in [*el.attrib.items(), ("#text", el.text or "")]:
            for n in names:
                # Deliberately broad identifier inventory: no suppression of qualified names,
                # identity RHS expressions, declarations, or disabled fields.
                if not re.search(r"(?<![A-Za-z0-9_])" + re.escape(n) + r"(?![A-Za-z0-9_])", value):
                    continue
                item = describe(tree, el)
                item.update({"field": field, "field_value": value,
                             "disabled_physics_ancestors": [a.get("tag") for a in el.iterancestors()
                                if a.tag in ("Physics", "PhysicsFeature") and any(c.tag == "entityFlags" and "DISABLED" in (c.text or "") for c in a)]})
                evidence["raw_identifier_inventory"][n].append(item)
        if el.tag in ("Physics", "PhysicsFeature", "Study", "StudyFeature", "Solver", "SolverFeature"):
            evidence["raw_selected_nodes"].append(describe(tree, el))
        elif any(any(n in v for n in names) for v in el.attrib.values()):
            evidence["raw_selected_nodes"].append(describe(tree, el))

    fixtures = {
        "identity_rhs_only": '<root><expressions name="alias" expr="dPE"/></root>',
        "qualified_reference_only": '<root><expressions name="alias" expr="comp1.dPE+1"/></root>',
        "ordinary_reference_control": '<root><expressions name="alias" expr="dPE+1"/></root>',
        "physics_disabled_inheritance": '<root><Physics tag="ev"><entityFlags>DISABLED</entityFlags><feature><PhysicsFeature tag="ds1"><param param="init" value="1"/></PhysicsFeature></feature></Physics></root>',
        "history_feature_exclusion": '<root><Physics tag="live"/><actions><Physics tag="historical"/></actions></root>',
        "non_physics_owner_container": '<root><Physics tag="liion"><VariableCollection tag="var1"><param param="expr" value="CHILD_VARIABLE"/></VariableCollection></Physics></root>',
        "live_refs_identity_qualified_disabled": '<root><expressions name="alias" expr="dPE"/><param param="equation" value="comp1.dPE+1"/><Physics tag="off"><entityFlags>DISABLED</entityFlags><param param="expr" value="dPE+1"/></Physics><actions><param value="dPE+1"/></actions></root>',
        "name_metadata_is_not_expression": '<root><param param="dPE" value="0.1"/><expressions name="other" expr="0" descr="dPE"/></root>',
    }
    for name, xml in fixtures.items():
        r = ET.fromstring(xml)
        evidence["synthetic_tests"].append({"name": name, "xml": xml,
                                            "feature_rows": module.walk_features(r),
                                            "dPE_refs": module.count_refs(module.live_expressions(r), "dPE")})
    by_name = {f['name']: f for f in evidence['synthetic_tests']}
    assert len(by_name['identity_rhs_only']['dPE_refs']) == 0
    assert len(by_name['qualified_reference_only']['dPE_refs']) == 0
    assert len(by_name['ordinary_reference_control']['dPE_refs']) == 1
    output = WORKSPACE / "outputs/mph_v2_extractor_evidence.json"
    output.write_text(json.dumps(evidence, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"output": str(output), "feature_count": len(rows),
                      "refs": {n: len(evidence["submitted_reference_hits"][n]) for n in names},
                      "regenerated_dump_matches": evidence["stored_dump_matches_regeneration"],
                      "ownership_disagreements": len(evidence["strict_direct_ownership_disagreements"]),
                      "raw_inventory": {n: [(r["line"], r["field"]) for r in evidence["raw_identifier_inventory"][n]] for n in names},
                      "sha256": evidence["source"]}, ensure_ascii=False))


if __name__ == "__main__":
    main()

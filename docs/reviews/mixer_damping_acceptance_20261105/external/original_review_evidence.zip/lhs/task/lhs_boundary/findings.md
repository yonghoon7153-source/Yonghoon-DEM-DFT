# LHS companion 경계 독립 정적 검토

판정: **bounded acceptance — 지정 문서 경계에서 새 필수 수정 0건.**

검토 대상 핀은 `bb6e86ac44f70a27b154db62fc14a624cab944df`다. 이 하위 검토는 전달 snapshot의 문서·JSON과 봉인 명령의 정적 해시만 다뤘다. 원격 핀 인증과 공통 감쇠식의 물리 정의 검토는 부모 검토/다른 하위 검토의 별도 범위다.

## 확인된 경계

| 항목 | 근거 | 판단 |
|---|---|---|
| 새 관측 0건 | companion README:3; companion_draft.json:3–9,21–48 | `measured_rows=0`, `rows=[]`, `NOT_COLLECTED`; status를 제외한 template 26개 필드는 모두 null이다. null을 관측 0으로 대체하지 않는다. |
| 실행·열람·활성 등록 미승인 | REQUEST.md:3,11; companion_draft.json:6–9,64; source_context.json:48–51 | 문서 초안의 준비가 실행·값 열람·등록·통합 권한으로 전환되지 않는다. 원문 context의 더 넓은 과거 허용 범위를 이번 작업의 실행 요청으로 읽지 않는다. |
| inventory schema·키·명령 보존 | companion README:21; companion_draft.json:10–15; inventory README:21–35; closure README:8 | 로컬 명령 SHA256이 `2305bd2194b29ac5439008906a17b1c673968a59fd52dcdde35b03ff4da20634`로 companion·closure·snapshot manifest와 일치한다. 한정 종결 문서에 명시된 기존 명령과 같은 해시이므로 schema 및 출력 키를 바꾸는 명령 변경은 없다. 실행 출력의 새 관측을 주장하지 않는다. |
| 재고와 값·동일 실행 증명의 구분 | companion README:11,21; inventory README:24–31; canonical §11-8:463,468 | B7 일치 줄 수·재개 흔적·파일 수를 압력 적격성, 감쇠 관측 또는 동일 실행 증명으로 확대하지 않는다. |
| 선행 결정 순서 | companion README:23,35; companion_draft.json:59–62; inventory README:47; canonical §11-8:466–470 | 기존 재고 준비/저자 승인 결과 → A/C 선택 및 값 열람 규칙 비준 → 별도 자료 수집 승인이다. 기존 Q1의 재고 우선 결정을 대체하지 않는다. |
| 타 트랙 전용 방지 | companion README:29–31; companion_draft.json:16–19; source_context.json:3–27 | 다른 D0.7 자료는 출처 기록으로 남고 LHS 관측은 모두 null이다. 서로 다른 표본/정지 시점을 같은 정지 사건의 비율로 승격하지 않는다. 원격 §4 미게시와 전달 정보의 검증 한계를 유지한다. |
| 자원·우선순위·허가 범위 | companion README:31; source_context.json:28–41,48–59 | 자원 점유는 전달 관찰이며 현재 스케줄러 조회로 서술하지 않는다. Rint ② 우선, 신규 제출 없음, 통합 미승인 및 연구 결과 0건을 유지한다. |
| 외부 수용과 열린 조건 | companion README:25; ledger_proposal.json:3–7; closure README:4,14–20,28–34 | LPI-01/02 수용은 출력/종료·시간위험 문구의 한정 결론이다. 느린 regex·디렉터리·파일시스템 위험, OBS-AUDIT-01 최초 원인 미확정, 전체 HOLD·P1 경계를 유지한다. 원장 적용·종결·활성 등록 제안은 없다. |

## 수행 범위와 한계

- `pressure_inventory.sh`는 해시와 schema 문자열의 정적 대조에만 사용했다. 실행·import하지 않았으며 기존 LPI 재감사를 열지 않았다.
- 원덤프, 연구 호스트, 실측 압력/감쇠 원자료에 접근하지 않았다. 물리 수치 계산, 기존 회귀·합성 suite, full gate를 실행하지 않았다.
- 전달 문서의 과거 시험 결과는 서술 경계만 읽었으며 이번 시험 수로 합산하지 않았다.
- source_context의 현재 bytes와 companion의 명시 해시는 일치한다. 별도의 최초 scratch 원본은 이 하위 검토에 없으므로 최초 원본과의 바이트 동일성 자체는 독립 인증하지 않는다.
- 이 판정은 실행·값 열람·등록·원장 종결·단계 A·통합·배포 GO 또는 외부 독립 수용의 대체물이 아니다.

신규 지적 ID·최소 반례·최소 수정: 해당 없음. 기계 판독 가능한 정적 대조는 `static_comparison.json`에 기록한다.

# 내부 반박 리뷰 2 회차 재확인 (Codex 아님) · 대상 0ac6edf3c..ea3b13b89 · 11-12 밤

- 대상 = 작업 트리 (rint-codepkg) 커밋 7 (`f8077a51d` 시험 먼저 → `4e1e5b6c6` 고침 → `ac7e1c58d` 게이트 · 결과 전 등록 → `8cc3fe462` · `609d78ca4` 변이 보강 →
  `c0ff22431` 시험 먼저 → `ea3b13b89` 고침).  판단 근거 = diff + 재리뷰 `review/rereview_codepkg.md` 뿐 (고친 쪽 설명 안 읽음 · 커밋 메시지의 숫자 · 전칭만 대조).
  판정 아님 · 지적 목록 (Codex verified 로 올리지 않는다).
- 실험 자리 = `recheck2/tree` (`git archive ea3b13b89` 일부 = scripts · webapp · 필요한 docs 일곱) + 기반 판 `11a794674` 의 객체 넷 (commit · tree 둘 · blob ·
  `ce/seed_base_objects.py` 가 파이썬으로 느슨한 객체를 씀 — git hash-object 안 씀 · Q11 · G4 · G5 의 `git show` 용).  반례 = `recheck2/ce/` (스크립트 · `*_out.txt` ·
  `*_results.json`) · 다시 돈 시험 기록 = `recheck2/logs/`.  env 반례는 전부 `unshare -pf --mount-proc --kill-child` 안 · 스크립트가 만든 일회용 저장소만 가리킨다.
- 킷 풀이 · GPU · σ 열람 없음.  무거운 시험 (사슬 · e2e · e2e12 · conv_cert · store_e2e) 은 돌리지 않고 `logs/r3` · `r4` 의 rc · 줄 수만 대조.

## 1. 지적별 — 닫힘 6 · 부분 3 · 안 됨 0

| 지적 | 판정 | 근거 (행 = ea3b13b89) |
|---|---|---|
| RCP2-01 런 도중 코드 바뀜 | **부분** | `cjunc_store.py:455–497` (`_START` · `code_drift`) · `:679–684` (발행 직전) · `:740–746` (get_or_build 시작) · T15a–f · P6.  재리뷰 CE-A 꼴 닫힘 (T15a · 내 `ce01` samesize · symlink 갈래 = disabled).  남은 구멍 = **RCP3-02** (시작 + 1 s 창 · Store 코드 칸 미대조 · 반대쪽 거짓 꺼짐) · **RCP3-03** (러너 꼴 payload 는 carbon_junction 을 먼저 부른다 — 한정 (가) 의 "payload 는 없다" 거짓) |
| RCP2-02 경로 정규화 | **닫힘** | `run_contract.py:1480` `normal_path_problem` · `cjunc_store.py:542–546` · `rint_r_chain.py:5619–5623` · 러너 `:606–613`.  내 차등 24,142 글 = 파이썬 ↔ 러너 셸 (러너 줄을 그대로 떼어 냄) ↔ 독립 기준 (normpath) 다름 0 · 실제 폴더 링크 꼴 14 전부 거부 · 중간 성분 링크 (`L/sub`) 받음 = 한정대로 (`ce02_out.txt`) |
| RCP2-03 그룹 · 남 쓰기 갈래 | **닫힘** | T7 `test_cjunc_store.py:1045–1046` (0664 · 0464 · 0646 · 0446) · T11 0757.  내 변이 M1 (0o002 = 재리뷰 N9) · M2 (0o020) → T7 실패 · M3 (뿌리 0o020) → T11 실패 · 사유 '남만 쓸 수 있음 (0757 · RCP2-03): 받았다' (`mut_out.txt`) |
| RCP2-04 결과 전 등록 · 쓰는 자리 | **닫힘** | `docs/reviews/rint2_s0_store_probe_20261112/README.md` (E1–E4 · T1–T3 · 결과 0 건 · FETCH_HEAD · 원격 추적 ref · worktree 관리 항목) · 블록 머리 6–24 행 같은 E · T.  다시 셈: 블록 md5 `692b34ff…` · 273 줄 · ASCII · 탭 · CR · 느낌표 0 · heredoc md5 감싸개 `86e9bf4b…` · 감시 셸 `ff385531…` = README 값 |
| RCP2-05 T14 부분집합 필터 | **닫힘** | `test_cjunc_store.py` `file_kind` · `mod_kind` · `import_violations` (T14a · b).  내 변이 M4 (원장 함수 첫 줄 `import pandas`) → T14a · T14b 실패 |
| RCP2-06 git 환경 | **부분** | `run_contract.py:1459–1477` (`git_env` · `drop_git_env`) · RCPT-sha `:2415–2430` (`_own` 확인) · payload `:639–642` · `:719–741` · 사슬 `:960–978` · `:1779–1783` · `:3071` · `:3085` · 시험 모듈 일곱 = 불러올 때 지움.  G1–G6 10/10 (3.11 · 3.8.20 · unshare 안 다시 돔).  남은 = **RCP3-01** (같은 부류 시험 모듈 하나 빠짐 · P2) · **RCP3-04** (지우는 폭) · **RCP3-05** (게이트 수준 · 묶음 밖) |
| RCP-03 남은 몫 (독립 대조) | **부분** | 머리 docstring `:33–38` "그 대조는 여전히 없다" = 한정 명시 (S0 단계 2 지문 ↔ DBE arm 0 = 1저자 결정 대기).  같은 문단의 "RCP2-01 꼴은 '런 시작 코드 칸' 이 막는다" 는 RCP3-02 · 03 만큼 넘친다 |
| RCP-04 남은 몫 (실침대 재기) | **닫힘** | RCP2-04 로 (블록 · 등록 · md5) · 실기계 결과 = [미확인] (블록 미실행) |
| RCP-06 남은 몫 (링크 · TOCTOU) | **닫힘** (한정 명시) | docstring `:48–50` (마지막 성분만 · 중간 링크 따름 · 경로 기준) · RCP2-02 · 03 닫힘 |

## 2. 새 지적 — P1 0 · P2 1 · P3 4

| 번호 | 등급 | 어디 | 반례 · 근거 | 고칠 방향 |
|---|---|---|---|---|
| RCP3-01 | **P2** | `scripts/test_ca_s0_census.py:308` `_git` (env 없음) · `:340–376` `make_plan_repo` (init · add -A · commit) · `:417` `checkout -q -b side` · 모듈이 GIT_* 를 안 지움 · 게이트 `check_all.sh` 의 'ca_s0_census' · kgy R 묶음 `check_kgy_py38.sh:61` | RCP2-06 과 같은 부류인데 G6 일곱에 없다.  실측 (`ce06_out.txt` A): GIT_DIR=V 꼴 → V 의 head · index · refs · reflog · 객체 3 → 15 바뀜 (고정물 커밋이 V 가지로) · 정직한 훅 꼴 (git 2.43 pre-commit 실측 env = `GIT_INDEX_FILE=<저장소>/.git/index.lock` 절대 경로 하나 · GIT_DIR 없음 · `hook_env_out.txt`) → 그 저장소의 commit 도중 색인 (index.lock) 항목이 `user.txt` 에서 시험 고정물 넷 (README · docs/data/s0/… · docs/reviews/R.md) 으로 바뀜 · 고친 모듈 (test_rint_r_chain) 은 그대로 (`ce06c_out.txt`) | 같은 두 줄 (`import run_contract as _RCG` · `_RCG.drop_git_env()`) + G6 에 넣기 · G 적대 꼴에 훅 꼴 (GIT_INDEX_FILE 하나) 더하기 · 손 목록 대신 게이트 · kgy 묶음 시험 모듈 중 git 쓰기 (init · add · commit · checkout) 를 부르는 것 전수를 G6 가 세게 (규율 ⑤) |
| RCP3-02 | P3 | `cjunc_store.py:441` `MTIME_SLACK_NS` · `:495` (시작 시각 + 1 s 와 비교) · `:562–565` Store 코드 칸 (런 시작과 대조 안 함) | `ce01_out.txt` — **samesec**: 런 시작 뒤 318 ms 안에 fsr 변이판 → 불러옴 → 원판 내용 되돌려 씀 (시각 되돌리기 없음) → built_written (변이판 원장 202eb91e965d 를 원판 열쇠로) → 원판 정직한 새 프로세스 = **hit** · 받은 202eb91e965d ≠ 제 원장 f24cbd6245dc · **samesec_store**: 변이판일 때 Store (열쇠 코드 칸 = 변이판 0ac15cfa…) → 253 ms 안에 원판으로 → 짓기 = 원판 → 변이판 정직한 런 = hit · 받은 f24cbd ≠ 제 202eb9 — 한정 (가)–(라) 어디에도 없음.  반대쪽: 사본 수정 시각이 미래 (+1 h · 다른 기계에서 `rsync -t` 꼴 = 정직한 '폴더 옮김') 면 내용 그대로인데 정직한 런마다 disabled (2/2 · `ce01_future_mtime_out.txt` · 틀린 결과 아님 · E3 에 걸림) | 시작 때 파일마다 stat 신원 (dev · ino · size · mtime_ns · ctime_ns) 을 적고 두 재기에서 정확히 같음 (여유 없음 · 벽시계 비교 없음) — 같은 초 뒤집기 · 시각 되돌린 뒤집기 (ctime 은 utime 으로 못 되돌림 · `stat_identity_demo.txt`) · 미래 mtime 거짓 꺼짐 셋을 함께 닫는다 · Store 코드 칸 = `_START['code']` 와 같아야 (아니면 꺼짐) |
| RCP3-03 | P3 | `ca_ext_cjunc.py:30` (carbon_junction) → `:33` (cjunc_store) · payload `:1781–1782` (`--expect-physics` 의 `ca_ext.*` 칸 → `_RC.ca_ext_protocol_fields()` → ca_ext_cjunc import · 입구 계약 `:1882` 보다 먼저) · 러너 `:879` (`XP="$XP$NG_DECL"` · CJUNC_STORE 는 CJUNC=1 에서만 = 늘 붙음) | 실제 payload (runpy · 입구에서 멈춤 · `ce01_payload_order_out.txt`): P6 꼴 (`--expect-physics` 없음) = 시작 차례 [cjunc_store] · preloaded [] / 러너 꼴 (`ca_ext.cjunc.*` 하나) = [carbon_junction, cjunc_store] · **preloaded ['carbon_junction']**.  docstring `:44–45` "payload 는 그런 모듈이 없다 = P6" · README "payload 와 같은 차례" 거짓 · `_START['preloaded']` 는 적기만 하고 아무도 안 읽음 · 창 ≈ 0.14 s (carbon_junction 본문) 라 실제 위험은 작다.  같은 기전의 효과 = `ce01` preloaded 갈래 (독 지속 — 한정 (가) 문서대로) | ca_ext_cjunc 에서 cjunc_store 를 carbon_junction 보다 먼저 (또는 payload 가 인자 해석 전에) · P6 를 러너 argv (`--expect-physics` + ca_ext 칸) 로 · 저장본 켬 런은 `preloaded` 비지 않으면 꺼짐 (fail-closed) |
| RCP3-04 | P3 | `run_contract.py:1462` `git_env` (접두 `GIT_` 전부) | 부르는 쪽 격리 설정까지 지운다 (`ce06_out.txt` C · `ce06b_out.txt`): ① `GIT_CEILING_DIRECTORIES=O` 로 둔 git 아닌 사본 (O/kit/scripts) — 옛 `_code_sha` = None (출처 없음) → 새 = 바깥 O 의 HEAD `3f800c4+dirty` (다른 저장소 귀속 · +dirty 라 하류 피해 작음) ② `GIT_CONFIG_GLOBAL=/dev/null` 로 격리한 부르는 쪽 — 옛 selftest 훅 0 회 → 새 selftest = 전역 pre-commit · post-commit 1 회씩 ③ HOME · XDG 전역 설정은 안 지운다 — 전역 core.hooksPath 가 RCPT-sha 임시 commit 에서 돈다 (pre 1 · post 1 · 125/125 그대로) · 전역 core.worktree = V 는 git 이 무시 (V 그대로 · 남의 저장소로 쓰기 넘어감 없음).  `GIT_CONFIG_*` · `-c` (GIT_CONFIG_PARAMETERS) 는 접두에 들어 지워짐 (확인) | 지울 목록 = 저장소 고르는 이름 (GIT_DIR · WORK_TREE · INDEX_FILE · OBJECT_DIRECTORY · ALTERNATE_OBJECT_DIRECTORIES · COMMON_DIR · NAMESPACE · CONFIG_PARAMETERS · CONFIG_COUNT/KEY/VALUE) · CEILING · DISCOVERY · CONFIG_GLOBAL · NOSYSTEM 은 남김 · 임시 저장소 쓰기에 `-c core.hooksPath=/dev/null` · `_code_sha` 는 찾은 저장소가 script_dir 파일을 추적하는지 (`ls-files --error-unmatch`) 확인 |
| RCP3-05 | P3 | 게이트 수준 (묶음 밖 포함) — `check_review_findings.py:881–896` (`--selftest` commit-tree · env 없음 · 게이트 단계) · 러너 `sdcp_gain_vox015_8arm.sh:1080` (기각 영수증 code_sha · 한정은 커밋 메시지에만 · 코드 주석 없음) · S0 블록 `:46–59` (fetch · worktree add) · `ca_s0_census.py:901–903` `_git` (S0 보고 git_head · git_dirty `:1385–1387` · 계획 커밋 읽기) | GIT_DIR=V 꼴에서 check_review_findings --selftest → V 객체 3 → 4 (매달린 커밋이 V 로 · `ce06_out.txt` B) · 나머지는 읽기 (잘못된 저장소의 HEAD · dirty 를 적을 수 있음 · 코드 읽기) | `check_all.sh` · `check_kgy_py38.sh` 머리에서 한 번 저장소 고르는 GIT_* 를 지우거나 있으면 경고 (규율 ① 한 곳 — RCP3-01 도 함께 막힌다) · 러너 1080 행에 한정 주석 |

## 3. 보장별 작은 해석 반례 — 시도한 꼴

- **RCP2-01 "런 시작 뒤 코드가 바뀌면 저장 안 함"** (`ce/ce01_*` · 새 프로세스 · 코드 사본 · 원장 = T15 와 같은 조밀 침대):
  깨짐 = samesec (318 ms · 시각 안 건드림) · samesec_store (253 ms) — RCP3-02 · 한정대로 못 가림 = mtime 되돌림 (1.3 s 뒤 · `os.utime` · 한정 (나)) · preloaded
  (한정 (가) · 러너 꼴 실제 해당 = RCP3-03) · 잡힘 = 같은 크기 바꿔치기 (주석 한 글자) · 심볼릭 링크 대상 바꿈 (자리 바뀜) · T15e 의 +5 s 다시 씀 · 거짓 꺼짐 = 미래 mtime ·
  안 해 봄 = 낡은 .pyc (한정 (다)) · 같은 프로세스 함수 바꿔 끼우기 (한정 (라)) · 시계 되돌림.
- **RCP2-06 "GIT_* 전부 지움"** (`ce/ce06*` · `hook_env_out.txt`): 고친 길 = 적대 셋 (GIT_DIR · +WORK_TREE+INDEX · OBJECT+COMMON) · 훅 꼴 (GIT_INDEX_FILE 하나 ·
  git 2.43 실측) 모두 그대로 · `GIT_CONFIG_*` · `-c` = 지워짐 · HOME · XDG = 안 지움 (core.worktree 무시 · hooksPath 돈다) · CEILING · CONFIG_GLOBAL = 지워서
  격리가 풀림 (RCP3-04) · env 안 넘기는 자리 = test_ca_s0_census (쓰기 · RCP3-01) · check_review_findings (쓰기 · RCP3-05) · 러너 1080 · S0 블록 · ca_s0_census (읽기).
  G 시험의 적대 꼴 셋은 모두 GIT_DIR 또는 GIT_COMMON_DIR 를 품는다 — 실제 훅 꼴 (GIT_INDEX_FILE 하나) 은 없다 (고친 코드는 접두 규칙이라 막지만 시험 판별력은 비어 있음).
- **RCP2-02 경로 정규화** (`ce/ce02_*`): `a/./b` · `a//b` · 끝 `/` · 앞 `//` · `.` · `..` · `...` · `.a` · `a.` 1–4 성분 조합 24,142 = 다름 0 · 실제 폴더 L · L/ · L// ·
  L/. · L/./ · L/.// · L//. · L/../L · B/./L · B//L · B/E/../L · LL (링크 → 링크) 꼴 = 전부 거부 · L/sub (중간 링크) = 받음 (한정) · 전각 점 · 한 점 리더 · 폭 없는
  빈칸 · NFC/NFD · 대소문자 = 파이썬은 보통 이름으로 받음 (OS 도 글자 그대로 = 마지막 성분 lstat 이 그 항목을 본다 · 우회 아님) · 사슬 · 러너는 글자 규칙으로 거부 ·
  대소문자 무시 파일 체계 = 이 기계에 없음 [미확인].

## 4. 숫자 · 전칭 대조

| 주장 | 대조 | 결과 |
|---|---|---|
| store 62 | 다시 돔 3.11 · 3.8.20 (numpy 1.24.4 · scipy 1.10.1) | **같음** 62/62 둘 다 (`logs/store_311_full.log` · `store_38.log`) — 첫 3.11 실행 61/1 = 내 사본에 `docs/reviews/sdcp_gain_prereg_v2_20260816.md` 빠짐 (R2 러너 ABORT · 내 환경 탓) → 넣고 R 묶음 2/2 → 전체 다시 62/62 |
| git_env 10 · run_contract 125 · Q11 19 | 다시 돔 (git_env = unshare 안) | **같음** 둘 다 (`logs/`) |
| e2e 51 · e2e12 33 | `logs/r4` (HEAD ea3b13b89 · 바뀐 파일 0) | 같음 (3.11 · 3.8 rc 0) |
| conv_cert 30 | `logs/r4` | 3.11 = 30/30 · **3.8 = 29/29** (K4b 건너뜀 · "scipy 1.10.1 < 1.12 · 세지 않음" = 설계) — "30" 은 3.11 판 수 |
| 사슬 506 | `logs/r3` (HEAD ac7e1c58d) | 같음 (3.11 · 3.8) · 그 뒤 커밋 넷은 시험 파일만 (test_rint_r_chain · 생산 코드 무변경) |
| 고치기 전 51 · 11 / 4 · 6 / 9 · 1 | `logs/r3` before 셋 · `r4/before_kgy` | 같음 (실패 이름도 같음) |
| 게이트 186 → 187 · 새 121 · kgy 16 → 17 | `CHECK_ALL_LIST=1` · 파일 | 같음 (121 = git_env_isolation) |
| 변이 W14 → T11 · H21 → G5 | 다시 돔 (내 사본 변이) | 같음 (둘 다 잡힘 · 옳은 사유) |
| "같은 부류 셋 … 이번 묶음에서 닫는다" (c0ff22431) | git 쓰는 시험 모듈 전수 (`scan_git_calls.json`) | **넘침** — test_ca_s0_census 빠짐 (RCP3-01) |
| "payload 는 그런 모듈이 없다 = P6" (cjunc_store `:44–45`) | 러너 꼴 payload | **거짓** (RCP3-03) |

## 5. 봉인 대조 (손댄 18 파일)

194 `CODE_FILES` 32 (`run_network_194_parallel.py:198`) 겹침 0 · 언로딩 키트 `docs/data/ps45_unload_20261009/SHA256SUMS` 76 + `history_test/SHA256SUMS` 15 겹침 0 ·
믹서 `dem_scripts/mixer_20260921/launch_policy.json` (경로 3) · `mixer_first8_launch_preparation_20261106/source_seal.json` (9) · `mixer_first8_reseal_candidate_20261108/candidate_seal.json` (12)
겹침 0 → **주장 맞음**.  참고: 사슬 `CODE_FILES` 20 에는 손댄 다섯 (cjunc_store · payload · rint_r_chain · run_contract · 러너) = 커밋 메시지의 '봉인 전' 그대로.

## 6. 확인 못 한 것 · 자기 점검

- 무거운 시험 (사슬 · e2e · e2e12 · conv_cert · store_e2e) 다시 안 돔 · kgy 실기계 · GPU · S0 블록 실침대 · 대소문자 무시 파일 체계 · 낡은 .pyc · 함수 바꿔 끼우기 · 시계 되돌림.
- 자기 점검: GIT_* export · 명령 앞 덧붙임 없음 (env 반례 = unshare 안 · 스크립트가 만든 일회용 저장소 · 자식 env 에만) · 본 리포 git 0 회 · 작업 트리 = log · diff · show · archive ·
  ls-tree · grep · cat-file · rev-parse (읽기) + 맨 처음 한 번 `status --short` (출력 없음 — 색인 stat 캐시를 다시 쓸 수 있는 명령이라 적어 둔다 · 그 뒤 안 씀) ·
  내 사본 저장소 = 객체 넷 + 시험이 만든 것만 · 큰 사본 (`tree` · 변이 · 작업 폴더) 은 끝에 지움.

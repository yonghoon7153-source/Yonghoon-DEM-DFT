"""Package already completed review evidence. No target code or host calls."""
from pathlib import Path, PurePosixPath
import hashlib
import json
import zipfile

ROOT = Path(__file__).resolve().parent
PIN = 'b57fe91503ba68cec6f41aec247851262788e48f'
SOURCE = Path('C:/Users/Administrator/Downloads/codex_mixer_launch_20261106_b57fe91503ba.zip')
ZIP_NAME = 'codex_review_mixer_launch_b57fe91503ba_evidence_20261106.zip'

def sha(b):
    return hashlib.sha256(b).hexdigest()

raw = SOURCE.read_bytes()
assert len(raw) == 645817
assert sha(raw) == 'f55bd750d601f50acbf360e39f3fb780de9132d801cc7076cd99fe63caf08803'
with zipfile.ZipFile(SOURCE) as z:
    names = z.namelist()
    assert len(names) == len(set(names)) == 115
    for name in names:
        assert not name.startswith('/') and '..' not in PurePosixPath(name).parts
        assert z.read(name) == (ROOT / 'package' / name).read_bytes(), name
    assert z.testzip() is None
input_identity = {
    'pin': PIN,
    'input_zip': SOURCE.name,
    'bytes': len(raw),
    'sha256': sha(raw),
    'original_entries': len(names),
    'all_original_entries_still_byte_identical_after_review': True,
    'transport_hash_independently_supplied': False,
    'scope': 'received-byte identity, not execution qualification',
}
(ROOT / 'input_identity.json').write_text(json.dumps(input_identity, indent=2)+'\n', encoding='utf8')
summary = {
    'pin': PIN,
    'branch': 'codex/mixer-1104',
    'scope': 'new mixer-launch static preparation and local mock boundaries only',
    'verdict': 'HOLD_SUBMISSION_JOB_START_BOUNDARIES',
    'static_assets': 'ACCEPTED_WITHIN_STATIC_SCOPE',
    'document_authorization_boundaries': 'ACCEPTED_WITHIN_DOCUMENT_SCOPE',
    'findings': [
        {'id':'MLA-01','severity':'P1','summary':'Ambient scheduler input variables can override sealed runner directives'},
        {'id':'MLA-02','severity':'P2','summary':'Per-case claim lacks shared concurrency and uncertain-submission admission state'},
        {'id':'MLA-03','severity':'P2','summary':'Existing job_end.json is omitted from freshness and overwritten'},
    ],
    'independent_checks': {
        'snapshot_files':89,'packaging_checksum_entries':114,
        'remote_blob_matches':89,'patch_reconstructed_files':72,
        'static_case_bindings':8,'static_pair_checks':3,
        'submission_scenarios':7,'job_start_observations':29,
        'ambient_environment_variables_in_one_probe':6,
        'counts_are_distinct_units_not_summed':True,
    },
    'whole_gate':'HOLD', 'physical_execution_authorized':False,
    'actual_scheduler_calls':0, 'actual_mpi_calls':0,
    'actual_ibb_wsl_access':False, 'integration_performed':False,
    'ledger_closure_performed':False,
    'runtime':'Windows Python 3.12.14, locally mocked processes and capacities',
}
(ROOT / 'review_summary.json').write_text(json.dumps(summary, indent=2)+'\n', encoding='utf8')
selected = [ROOT/'codex_review_mixer_launch_20261106.md', ROOT/'review_summary.json',
            ROOT/'input_identity.json',ROOT/'package_verification.json',ROOT/'remote_verification.json',
            ROOT/'build_evidence_bundle.py']
for directory in ('evidence','package'):
    selected.extend(p for p in (ROOT/directory).rglob('*') if p.is_file())
assert all('__pycache__' not in p.parts for p in selected)
selected = sorted(set(selected), key=lambda p:p.relative_to(ROOT).as_posix())
manifest = ''.join(sha(p.read_bytes())+'  '+p.relative_to(ROOT).as_posix()+'\n' for p in selected)
(ROOT/'EVIDENCE_SHA256SUMS').write_text(manifest,encoding='utf8',newline='\n')
archive = ROOT/ZIP_NAME
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for p in selected+[ROOT/'EVIDENCE_SHA256SUMS']:
        z.write(p,p.relative_to(ROOT).as_posix())
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    names=z.namelist()
    assert len(names)==len(set(names))
    for line in z.read('EVIDENCE_SHA256SUMS').decode().splitlines():
        digest,name=line.split('  ',1)
        assert sha(z.read(name))==digest,name
    assert len(names)==len(selected)+1
result={'review_pin':PIN,'verdict_file':'codex_review_mixer_launch_20261106.md',
        'evidence_zip':ZIP_NAME,'bytes':archive.stat().st_size,
        'sha256':sha(archive.read_bytes()),'zip_entries':len(names),
        'payload_checksums_verified':len(selected),'crc_ok':True,
        'input_package_bytes_preserved':True,'whole_gate':'HOLD'}
(ROOT/'delivery_receipt.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf8')
print(json.dumps(result,indent=2))

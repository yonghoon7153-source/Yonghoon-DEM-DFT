"""R01: synthetic deck/consumer probes only. No simulator or real data access."""
from pathlib import Path
import contextlib, copy, hashlib, importlib.util, io, json, math, os, re, shutil, subprocess, sys

ROOT = Path(__file__).resolve().parent
PKG = ROOT / 'package'
OUT = ROOT / 'evidence'
OUT.mkdir(exist_ok=True)
sys.path.insert(0, str(PKG / 'scripts'))
import make_mixer_deck as gen
import mixer_deck_readback as rb
import mixer_deck_diff as dd
import mixer_smoke_blind as smoke

def sha(b): return hashlib.sha256(b).hexdigest()
def prime(n):
    return n >= 2 and all(n % d for d in range(2, math.isqrt(n) + 1))

def pair(seed=49979687, layered=True, phases=('AM_P','AM_S','SE')):
    """Call real generator directly; do not import author's test fixture."""
    prior = gen.TYPES
    made = []
    try:
        gen.set_phases(phases)
        for coated in (False, True):
            gam = {p: 1.0 if coated or p == 'SE' else .35 for p in phases}
            arm = gen.gm_arm(gam, gamma_wall=gen.gm_wall_from_ncm(.35),
                             bo_se=.89, rho_uncoated_ncm=.35)
            arm['layered'] = layered
            gen.ARMS['R01INDEPENDENT'] = arm
            plan = gen.plan(90017, cgf=137., stiffen_se=20., dens_gen='lab20261014')
            rpm = gen.resolve_rpm(plan['R'])
            deck = gen.deck(plan, rpm, 2, seed=seed, arm='R01INDEPENDENT', hold_bo_pairwise=True)
            meta = gen.deck_meta(plan, rpm, 2, seed, 'R01INDEPENDENT', deck, hold_bo_pairwise=True)
            made.append([deck.encode('utf-8'), meta])
    finally:
        gen.ARMS.pop('R01INDEPENDENT', None)
        gen.set_phases(prior)
    return made

def alter(data, fix, token, sides=(0,1)):
    data = copy.deepcopy(data)
    for i in sides:
        b, m = data[i]
        s, count = re.subn(r'(fix '+fix+r' all insert/pack seed )\S+',
                          lambda match: match[1] + token, b.decode('utf-8'))
        assert count == 1
        b=s.encode('utf-8');m.update(deck_sha256=sha(b), deck_bytes=len(b))
        # Bind first metadata to actual numeric mutation too, where representable.
        if fix == 'insA' and re.fullmatch(r'-?[0-9]+',token): m['seed']=int(token)
        data[i]=[b,m]
    return data

def save_case(name, data):
    dest=OUT/'cases'/name;dest.mkdir(parents=True,exist_ok=True)
    for name2,(b,m) in zip(('u','c'),data):
        assert sha(b)==m['deck_sha256'] and len(b)==m['deck_bytes']
        (dest/(name2+'.in')).write_bytes(b)
        (dest/(name2+'.json')).write_text(json.dumps(m,indent=2),encoding='utf-8')
    return dest

def cli(scripts, folder, tag, side='u'):
    base=[sys.executable,'-I','-B','-X','utf8']
    commands={
      'readback':['mixer_deck_readback.py','--d2',str(folder/(side+'.in')),str(folder/(side+'.json'))],
      'pair':['mixer_deck_diff.py',str(folder/'u.in'),str(folder/'c.in'),'--allow','D2',
              '--meta-ref',str(folder/'u.json'),'--meta-new',str(folder/'c.json')],
      'plan':['mixer_smoke_blind.py','--d2-plan',str(folder/(side+'.in')),'--d2-meta',str(folder/(side+'.json'))]}
    results={}
    for name,args in commands.items():
        cmd=base+[str(scripts/args[0])]+args[1:]
        p=subprocess.run(cmd,capture_output=True,timeout=20)
        (folder/(tag+'_'+name+'.stdout')).write_bytes(p.stdout)
        (folder/(tag+'_'+name+'.stderr')).write_bytes(p.stderr)
        results[name]={'rc':p.returncode,'stdout':p.stdout.decode('utf-8'),'stderr':p.stderr.decode('utf-8')}
    return results

def apis(data,side=0):
    (a,am),(b,bm)=data
    return {'readback':rb.read_d2(data[side][0],data[side][1]),
            'pair':dd.diff_d2_decks(a,b,am,bm),
            'plan':smoke.d2_plan_check(data[side][0],data[side][1])}

cases=[]
for phases in [('AM_P','AM_S','SE'),('AM_P','SE')]:
    for seed,layered in [(2147483647,False),(2147483629,True),(2,True),(49979687,True)]:
        name=f'p{len(phases)}_{seed}_{"layered" if layered else "uniform"}'
        cases.append((name,pair(seed,layered,phases),True,None,0))
    cases.append((f'p{len(phases)}_overflow',pair(2147483647,True,phases),False,
                 'D2 insert/pack insB seed 2147483659: outside 1..2147483647',0))

tokens=['0','-7','1','9','2147483646','2147483648','2147483659','+49979687',
        '049979687','49979687.0','4.9979687e7','４９９７９６８７','0x2faa0a7']
base=pair()
for fix in ['insA','insB']:
    for idx,token in enumerate(tokens):
        if token in ['1','9','2147483646']:reason='not prime'
        elif token in ['2147483648','2147483659']:reason='outside 1..2147483647'
        else:reason='ASCII positive integer'
        cases.append((fix+'_'+str(idx),alter(base,fix,token),False,
                      f'D2 insert/pack {fix} seed {token}: '+reason,0))
cases.append(('coated_only_overflow',alter(base,'insB','2147483659',sides=(1,)),False,
              'D2 insert/pack insB seed 2147483659: outside 1..2147483647',1))
cases.append(('wrong_valid_second_prime',alter(pair(2147483629),'insB','49979687'),False,
              '`49979687` (generator `2147483647`)',0))

records=[]
for name,data,expected,reason,side in cases:
    folder=save_case(name,data)
    results=apis(data,side)
    cl=cli(PKG/'scripts',folder,'candidate',side='u' if side==0 else 'c')
    row={'case':name,'expected_pass':expected,'expected_reason':reason,'api':results,'cli':cl}
    row['ok']=all((r['verdict']=='PASS')==expected and not r['execution_authorized'] and
                  (reason is None or any(reason in f for f in r['failures'])) for r in results.values()) and all(
                 x['rc']==(0 if expected else 1) and 'Traceback' not in x['stderr'] and
                 (reason is None or reason in x['stdout']) for x in cl.values())
    records.append(row)

# Old and mutant code lives in review-owned copies; package files never change.
scratch=ROOT/'scratch';scratch.mkdir(exist_ok=True)
original_source=(PKG/'scripts/mixer_deck_readback.py').read_text(encoding='utf-8')
old_sources=PKG/'docs/reviews/mxd2r_r01_recheck_20261106/evidence/red_sources'
variants={}
for label in ['before','no_range','no_prime']:
    dest=scratch/label/'scripts';dest.mkdir(parents=True,exist_ok=True)
    for p in (PKG/'scripts').glob('*.py'): shutil.copyfile(p,dest/p.name)
    src=original_source
    if label=='before':
        src=(old_sources/'mixer_deck_readback.py').read_text(encoding='utf-8')
    elif label=='no_range':
        line="    _d2_need(seed <= D2_SEED_MAX, label + f': outside 1..{D2_SEED_MAX}' + rule)\n"
        assert src.count(line)==1;src=src.replace(line,'',1)
    else:
        line="    _d2_need(_d2_next_prime(seed) == seed, label + ': not prime' + rule)\n"
        assert src.count(line)==1;src=src.replace(line,'',1)
    (dest/'mixer_deck_readback.py').write_bytes(src.encode('utf-8'))
    variants[label]={'source_sha256':sha(src.encode()),'cli':{}}
    names=['p3_overflow','p3_2147483647_uniform','p3_2147483629_layered'] if label=='before' else (
          ['p3_overflow'] if label=='no_range' else ['insB_3'])
    for name in names:
        variants[label]['cli'][name]=cli(dest,OUT/'cases'/name,label)

# Independent prime oracle and ordering sentinel, not generator's next-prime copy.
tokens_checked=list(range(1,501))+[2147483587,2147483629,2147483646,2147483647]
oracle=[]
for n in tokens_checked:
    try: out=rb._d2_insert_seed(str(n),'probe');accepted=True
    except ValueError:accepted=False
    oracle.append({'n':n,'prime':prime(n),'accepted':accepted,'ok':accepted==prime(n)})
orig=rb._d2_next_prime
called=[]
def forbidden(n):called.append(n);raise AssertionError('prime called before range/lexical check')
rb._d2_next_prime=forbidden
ordering=[]
try:
    for token in ['0','-7','+2','02','2147483648','2147483659','9'*100]:
        try:rb._d2_insert_seed(token,'probe');msg='UNEXPECTED PASS'
        except ValueError as ex:msg=str(ex)
        ordering.append({'token':token,'message':msg,'prime_calls':len(called)})
finally:rb._d2_next_prime=orig

summary={'pin':(PKG/'PIN.txt').read_text().strip(),'python':sys.version,
 'synthetic_only':True,'case_count':len(records),'cli_calls_candidate':3*len(records),
 'all_cases_ok':all(r['ok'] for r in records),'cases':records,'variants':variants,
 'prime_oracle':oracle,'prime_oracle_all_ok':all(x['ok'] for x in oracle),
 'order_probes':ordering,'prime_order_calls':called,
 'full_gate_run':False,'simulator_run':False,'execution_authorized':False}
(OUT/'results.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({'cases':len(records),'all_cases_ok':summary['all_cases_ok'],
 'bad_cases':[r['case'] for r in records if not r['ok']], 'prime_oracle_count':len(oracle),
 'prime_oracle_all_ok':summary['prime_oracle_all_ok'],'prime_order_calls':called,
 'variant_rcs':{k:{n:{c:v['rc'] for c,v in cs.items()} for n,cs in vv['cli'].items()} for k,vv in variants.items()}},indent=2))
assert summary['all_cases_ok'] and summary['prime_oracle_all_ok'] and not called
assert all(x['rc']==0 for vv in variants['before']['cli'].values() for x in vv.values())
assert all(x['rc']==0 for vv in variants['no_range']['cli'].values() for x in vv.values())
assert all(x['rc']==1 and 'not prime' not in x['stdout'] for vv in variants['no_prime']['cli'].values() for x in vv.values())

from pathlib import Path, PurePosixPath
import zipfile,hashlib,json,io
ROOT=Path(__file__).resolve().parent
NEW='67d23a4fdeab0f09c8a8c2602cfc59daecd07f20'
OLD='df9a4623e2f9e6302e6bc8922bd0612ab48e120c'
ZNAME='codex_d3_sop_note01_20261104_67d23a4fdeab.zip'
sha=lambda b:hashlib.sha256(b).hexdigest()
def verify():
 zbytes=(ROOT/'input'/ZNAME).read_bytes()
 assert sha(zbytes)=='e6529061e6723037233761b19f6e1069f8a4d00d8db187dabfb5c7a835673ab5'
 remote=json.loads((ROOT/'remote_pin.json').read_text(encoding='utf-8'))
 assert remote['pin']==NEW
 ri={r['path']:r for r in remote['entries']}
 with zipfile.ZipFile(io.BytesIO(zbytes)) as z:
  names=z.namelist();assert len(names)==len(set(n.casefold() for n in names))
  for e in z.infolist():
   n=e.filename;p=PurePosixPath(n)
   assert not p.is_absolute() and '..' not in p.parts and ':' not in n and '\\' not in n
   assert ((e.external_attr>>16)&0o170000)!=0o120000
  assert z.read('PIN.txt').decode().strip()==NEW
  assert z.read('EXTERNALLY_ACCEPTED_PIN.txt').decode().strip()==OLD
  m=json.loads(z.read('SNAPSHOT_MANIFEST.json'));assert m['pin']==NEW
  checked=[]
  for e in m['entries']:
   b=z.read(e['path']);blob=hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
   assert (len(b),sha(b),blob)==(e['bytes'],e['sha256'],e['git_blob'])
   r=ri[e['path']];assert (len(b),blob)==(r['bytes'],r['git_blob'])
   checked.append(e['path'])
  assert set(checked)==set(ri)
  package=[]
  for line in z.read('PACKAGE_SHA256SUMS').decode().splitlines():
   h,n=line.split('  ',1)
   if n.startswith('./'):n=n[2:]
   assert sha(z.read(n))==h,n
   package.append(n)
  assert len(package)==len(set(package))
  assert set(names)-set(package)=={'PACKAGE_SHA256SUMS'}
  prefix='docs/reviews/mixer_d3_sop_acceptance_20261104/'
  original_evidence=z.read(prefix+'codex_d3_sop_review_evidence_20261104.zip')
  assert sha(original_evidence)=='71706a409469fde4cdb0d2ed349ff0fbad6e30a4bd83510de304f920a5fab3a3'
  with zipfile.ZipFile(io.BytesIO(original_evidence)) as previous:
   original_report=previous.read('codex_review_mixer_d3_sop_20261104.md')
   assert z.read(prefix+'external_verdict.txt')==original_report
   assert z.read(prefix+'scope_verdict.json')==previous.read('scope_verdict.json')
   assert z.read(prefix+'external_verification_results.json')==previous.read('verification_results.json')
   oldzip=previous.read('input/codex_d3_sop_review_20261104_df9a4623e2f9.zip')
   assert sha(oldzip)=='7ad7020be45b8de645a01783c1009163853b7beb6447014f947422e40eabf501'
   with zipfile.ZipFile(io.BytesIO(oldzip)) as accepted:
    sop='docs/reviews/mixer_d3_measurement_sop_draft_20261104.md'
    old=accepted.read(sop);new=z.read(sop)
    for n in ['docs/reviews/mixer_d3_candidate_reader_contract_20261024.md','docs/reviews/mixer_d3_se_flowability_anchor_design_v2_20261023.md']:
     assert accepted.read(n)==z.read(n)
  proposal=[line[2:] for line in original_report.decode().splitlines() if line.startswith('> ')]
  assert len(proposal)==1
  sentence=proposal[0].encode('utf-8')
  block=sentence+b'\n\n'
  assert new.count(sentence)==1 and new.count(block)==1
  assert new.replace(block,b'',1)==old
  assert len(new)-len(old)==len(block)
  assert z.read('REQUEST.md')==z.read(prefix+'review_request.md')
  line_no=new[:new.index(sentence)].count(b'\n')+1
 return {'new_pin':NEW,'externally_accepted_pin':OLD,'package_sha256':sha(zbytes),'snapshot_remote_files':len(checked),'package_entries':len(package),'proposal_exact_transcription':True,'added_sentence_line':line_no,'sop_old_bytes':len(old),'sop_new_bytes':len(new),'added_bytes_including_newlines':len(block),'restored_sop_sha256':sha(old),'new_sop_sha256':sha(new),'remove_sentence_and_blank_line_restores_exact_bytes':True,'prior_review_evidence_zip_preserved':True,'original_verdict_scope_and_verification_preserved':True,'v2_and_reader_contract_unchanged':True,'request_copy_identical':True,'review_scope':'NOTE01 sentence transcription and receipt boundaries only','source_code_tests_full_gate_reexecuted':False,'overall_gate':'HOLD','execution_authorized':False}
if __name__=='__main__':
 print(json.dumps(verify(),ensure_ascii=False,indent=2))


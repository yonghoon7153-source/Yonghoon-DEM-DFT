#!/usr/bin/env bash
# 2단계 러너 — 정지 규칙을 **실제로 적용**하려면 순서가 있어야 한다 (회신 AJ·AO·AP).
#
#   0단계(자동): POTCAR 조립 + provenance + **묶음 root 봉인** (AO P0-2·Q1)
#   1단계: primary 두 조각 x 셀 두 높이 + 기체 기준 + 기체 canary
#          -> **1단계 선결조건 8축** 전부 통과해야 2단계가 열린다:
#             진공 수렴 · 분자 스핀 · canary 기하 · POTCAR 신원 ·
#             δ_gas(기체 상자) · pm1 자기 topology · 잔여 차단 0 · 봉인 포괄
#   2단계: primary 다른 seed + 대안 자세 두 seed
#          -> 시작 **직전에** 1단계 게이트를 다시 돌린다 (AP #6)
#          -> 끝나면 최종 분석기를 돌린다 (AP #9)
#
# ⛔ 이 스크립트가 **유일한 실행 경로**다. run_job.sh 를 손으로 부르지 않는다.
set -u
usage() { echo "사용법: bash run_staged.sh {1|2}"; exit 2; }
[ $# -ge 1 ] || usage
stage=$1
case "$stage" in 1|2) ;; *) echo "모르는 단계: $stage"; usage;; esac
# 🔴🔴 회신 AV P0-2 (2026-08-31) — **자유형 launcher 문자열을 폐지한다.**
#   회신 AT 해제 뒤에도 세 형태가 뚫렸다:
#     `mpirun -np 48 other_vasp`  — PATH 이름은 파일이 아니라 -x 검사에 안 걸린다
#     `/tmp/evil/mpirun -np 48`   — basename 만 봐서 아무 경로나 mpirun 행세를 했다
#     `env --split-string=...`    — env 는 인자 문법 자체가 실행이다
#   교훈: 문자열을 **검사**하는 한 진다. ⇒ 사용자는 종류와 수만 주고,
#   **argv 는 러너가 조립한다** (회신 AV Q5 — 이름 목록은 좁게, env 는 제거):
#     VASP_LAUNCHER_KIND : mpirun | mpiexec | srun | none | wrapper
#     VASP_NPROC         : 랭크 수 (양의 정수 · none 이면 생략 가능)
#     VASP_EXE           : 실행파일 절대경로 (봉인 대상)
#     VASP_WRAPPER       : KIND=wrapper 일 때 현장 wrapper 절대경로 —
#                          SEAL 이 해시를 봉인하고 실행 직전 재대조한다
if [ -n "${VASP_CMD:-}" ] || [ -n "${VASP_LAUNCHER:-}" ]; then
  echo "⛔ VASP_CMD / VASP_LAUNCHER 는 폐지됐습니다 (회신 AV P0-2)."
  echo "   자유형 문자열은 봉인된 실행파일을 우회할 수 있어 종류+수만 받습니다:"
  echo "     export VASP_LAUNCHER_KIND=mpirun   # mpirun|mpiexec|srun|none|wrapper"
  echo "     export VASP_NPROC=48"
  echo "     export VASP_EXE=/abs/path/to/vasp_std"
  exit 2
fi
VASP_LAUNCHER_KIND=${VASP_LAUNCHER_KIND:?VASP_LAUNCHER_KIND 를 지정하세요 (mpirun|mpiexec|srun|none|wrapper)}
VASP_EXE=${VASP_EXE:?VASP_EXE 를 지정하세요 (실행파일 절대경로 — 이것이 봉인 대상입니다)}
# ⛔⛔ 2026-09-01 (회신 AZ P0-2) — **PATH 조회를 여기서도 폐기한다.**
#   AY P0-1 에서 run_job.sh 의 PATH 조회만 걷고 "폐기했다" 고 적었는데, **봉인을
#   만드는 이 자리가 그대로였다.** PATH 앞에 가짜 mpirun/vasp_std 를 두면 그 파일이
#   **정상적으로 봉인된다** — 봉인 뒤 교체만 막고 '가짜를 처음부터 봉인하는' 경로는
#   열려 있었다. 우회를 닫은 게 아니라 한 겹 더 미룬 것이었다 (같은 실수 두 번째).
#   ⇒ 절대경로만 받는다. PATH 에서 찾아 주지 않는다.
case "$VASP_EXE" in
  /*) ;;
  *) echo "⛔ VASP_EXE 는 **절대경로**여야 합니다 (회신 AZ P0-2): $VASP_EXE"
     echo "   PATH 에서 찾아 주지 않습니다 — PATH 앞의 가짜가 봉인될 수 있습니다."
     echo "   예: export VASP_EXE=\\$(command -v vasp_std)   # 값을 **직접 확인한 뒤** 주세요"
     exit 2 ;;
esac
[ -f "$VASP_EXE" ] && [ -x "$VASP_EXE" ] || { echo "⛔ VASP_EXE 가 실행파일이 아닙니다: $VASP_EXE"; exit 2; }
LAUNCHER_BIN=${LAUNCHER_BIN:-}
VASP_WRAPPER=${VASP_WRAPPER:-}
case "$VASP_LAUNCHER_KIND" in
  mpirun|mpiexec|srun)
    case "${VASP_NPROC:-}" in
      ''|*[!0-9]*|0) echo "⛔ VASP_NPROC 가 양의 정수가 아닙니다: '${VASP_NPROC:-}'"; exit 2 ;;
    esac
    # ⛔ 회신 AZ P0-2 — launcher 도 **절대경로로 직접** 받는다 (PATH 조회 없음).
    [ -n "$LAUNCHER_BIN" ] || {
      echo "⛔ LAUNCHER_BIN=/abs/path/to/$VASP_LAUNCHER_KIND 를 주세요 (회신 AZ P0-2)."
      echo "   PATH 에서 찾아 주지 않습니다 — 그 경로로 가짜가 봉인될 수 있었습니다."
      exit 2; }
    case "$LAUNCHER_BIN" in /*) ;; *) echo "⛔ LAUNCHER_BIN 은 절대경로여야 합니다: $LAUNCHER_BIN"; exit 2 ;; esac
    [ -f "$LAUNCHER_BIN" ] && [ -x "$LAUNCHER_BIN" ] || { echo "⛔ LAUNCHER_BIN 이 실행파일이 아닙니다: $LAUNCHER_BIN"; exit 2; }
    ;;
  none)
    VASP_NPROC=${VASP_NPROC:-1} ;;
  wrapper)
    # 목록 밖 launcher 는 **해시로 봉인한 wrapper** 로만 (회신 AV Q5).
    #   wrapper 계약: $1=VASP_EXE $2=VASP_NPROC 을 받아 현장 방식으로 돌린다.
    [ -n "$VASP_WRAPPER" ] || { echo "⛔ KIND=wrapper 면 VASP_WRAPPER=/abs/wrapper.sh 를 주세요"; exit 2; }
    case "$VASP_WRAPPER" in /*) ;; *) echo "⛔ VASP_WRAPPER 는 절대경로여야 합니다"; exit 2 ;; esac
    [ -f "$VASP_WRAPPER" ] && [ -x "$VASP_WRAPPER" ] || { echo "⛔ VASP_WRAPPER 가 실행파일이 아닙니다"; exit 2; }
    case "${VASP_NPROC:-}" in
      ''|*[!0-9]*|0) echo "⛔ VASP_NPROC 가 양의 정수가 아닙니다: '${VASP_NPROC:-}'"; exit 2 ;;
    esac
    ;;
  *) echo "⛔ 모르는 VASP_LAUNCHER_KIND: $VASP_LAUNCHER_KIND (mpirun|mpiexec|srun|none|wrapper)"; exit 2 ;;
esac
# ⛔⛔ 2026-09-04 — **랭크 수가 KPAR 의 배수여야 한다.** INCAR 이 `KPAR` 을 명시하는데
#   `VASP_NPROC` 이 그 배수가 아니면 VASP 는 k-그룹을 고르게 못 나눈다 (배치를 거부하거나
#   남는 랭크를 놀린다). INCAR 은 해시로 동결돼 현장에서 못 고치므로, **비용이 나가기 전에**
#   여기서 멈추고 쓸 수 있는 랭크 수를 알려 준다. KPAR 은 잡의 INCAR 에서 직접 읽는다
#   (MANIFEST 사본을 믿지 않는다 — 사본은 언젠가 정본과 갈린다).
#   ⚠ KPAR 은 **잡마다 다르다** (슬랩 4 · 기체 Γ-only 1). 하나만 보면 기체 잡을 집어
#     검사를 건너뛴다 — 전 INCAR 을 훑어 **최댓값**으로 조건을 건다 (그 배수면 1·2·4 전부 나눈다).
#   🔴 렌즈 K2 P1-3 (2026-09-04) — 실제 조건은 `% KPAR` 이 **아니다.** VASP 는 k-그룹당 랭크를
#     다시 NCORE 로 나누므로 `NPROC % (KPAR × NCORE)` 여야 INCAR 대로 돈다. `% KPAR` 만 보면
#     랭크 20(=4×5)이 통과하는데 5 는 NCORE=4 로 안 나뉘어 **VASP 가 NCORE 를 말없이 재설정**한다 —
#     동결한 INCAR 과 실제 병렬화가 갈리고 비용모형(NCORE=4 전제)도 다시 어긋난다.
#   🔴 렌즈 K2 P1-1 — 산술은 `10#` 을 붙인다. `VASP_NPROC=09` 는 위 정수검사를 통과하는데
#     bash 가 8진수로 읽어 죽고, `set -e` 가 없어 **가드를 조용히 새어 나간다** (실측).
_KPAR=$(find . -mindepth 3 -maxdepth 4 -name INCAR -exec \
          sed -n 's/^[[:space:]]*KPAR[[:space:]]*=[[:space:]]*\([0-9][0-9]*\).*/\1/p' {} + 2>/dev/null \
        | sort -n | tail -1)
_NCORE=$(find . -mindepth 3 -maxdepth 4 -name INCAR -exec \
          sed -n 's/^[[:space:]]*NCORE[[:space:]]*=[[:space:]]*\([0-9][0-9]*\).*/\1/p' {} + 2>/dev/null \
        | sort -n | tail -1)
if [ -z "$_KPAR" ]; then
  # 🔴 렌즈 K2 P2-1 — "구판이라 없음" 과 "find 가 헛돌았음"(잘못된 cwd 등)을 구분해야 한다.
  #   이 생성기는 전 INCAR 에 KPAR 을 쓰므로, 못 읽었으면 **말한다** (조용한 건너뜀 금지).
  echo "  ⚠ INCAR 에서 KPAR 을 읽지 못했습니다 — 랭크 배치 검사를 건너뜁니다."
  echo "     묶음 루트에서 실행 중인지 확인해 주십시오 (구판 묶음이면 정상입니다)."
else
  _NCORE=${_NCORE:-1}
  _NEED=$(( 10#$_KPAR * 10#$_NCORE ))
  if [ "$_NEED" -gt 1 ] 2>/dev/null; then
    if [ $(( 10#${VASP_NPROC:-1} % _NEED )) -ne 0 ]; then
      echo "⛔ VASP_NPROC=${VASP_NPROC:-1} 이 이 묶음의 랭크 배치와 맞지 않습니다."
      echo "   INCAR 이 KPAR=$_KPAR · NCORE=$_NCORE 로 고정돼 있어 랭크 수는 **$_NEED 의 배수**여야 합니다"
      echo "   (k-그룹당 랭크 = NPROC/KPAR 이 다시 NCORE 로 나눠져야 합니다)."
      echo "   INCAR 은 해시로 동결돼 있어 고칠 수 없습니다 — 고치면 그 잡이 거부됩니다."
      echo "   쓸 수 있는 랭크 수: $_NEED · $(( _NEED * 2 )) · 48 · 64 · 96 · 128 · 256"
      echo "   (스모크 테스트만 하실 거면 $_NEED 랭크로도 돕니다.)"
      echo "   ⚠ KPAR 은 k-그룹마다 배열 사본을 들어 **노드당 메모리가 늘어납니다**."
      echo "     메모리가 모자라도 **랭크를 줄이지 마시고**(배수 조건이 깨집니다) 노드를 늘려 주십시오."
      exit 2
    fi
    echo "  ✔ 랭크 ${VASP_NPROC:-1} = KPAR $_KPAR × NCORE $_NCORE × $(( 10#${VASP_NPROC:-1} / _NEED ))"
  fi
fi
export VASP_EXE VASP_LAUNCHER_KIND VASP_NPROC LAUNCHER_BIN VASP_WRAPPER

# ⛔⛔ 2026-09-08 (Codex v38 P1-1) — **잠금을 공유 상태보다 먼저 잡는다.**
#   종전엔 lock 이 PP 검사 뒤(메모리 가드·호스트 풀·프로브 **뒤**)에 있었다. 계산 중 같은
#   번들을 실수로 다시 부르면, 두 번째 호출이 lock 에서 거부되기 **전에** 기존 _hostpool 을
#   지우고 다시 만들어 — 점유 중인 조각이 free 로 돌아가고 다음 잡이 계산 중인 잡과 겹칠 수
#   있었다. ⇒ lock 을 여기(가드·풀·프로브 앞)로 올린다. 가드가 PP 검사보다 앞이어야 한다는
#   종전 요구는 그대로 지켜진다 (순서: lock → 가드 → 풀 → 프로브 → PP).
# ⛔⛔ 회신 AR P0-8 · 해제조건 8 — **경쟁조건 없는 host/run-id 잠금**.
#   종전 구현: `mkdir $LOCK` 뒤에 pid 를 썼다. 그 사이(디렉터리는 있고 pid 는
#   아직 없는 창)에 다른 프로세스가 이를 stale 로 보고 `rm -rf` 했다.
#   게다가 다른 HPC 노드의 pid 에는 `kill -0` 이 유효한 생존검사가 아니다.
#   ⇒ ① 내용을 **먼저** 쓴 임시 파일을 `ln` 으로 원자적으로 링크한다
#       (하드링크 생성은 대상이 있으면 실패한다 — 내용이 없는 창이 존재하지 않는다)
#     ② **모르는 lock 은 절대 지우지 않는다.** 같은 호스트의 죽은 pid 일 때만
#       안내하고, 그래도 자동 삭제하지 않는다 (사람이 지운다).
# ⛔⛔ 회신 AS 해제조건 6 (2026-08-31) — lock 을 **단계별이 아니라 번들 전역**으로
#   바꾼다. 종전엔 `.lock_bundle` 과 `.lock_stage2` 가 따로라 1단계와 2단계를
#   동시에 던지면 둘 다 lock 을 잡았다. 같은 번들 디렉터리에서 동시에 도는 것은
#   단계가 달라도 안 된다 — POTCAR·봉인·산출물을 공유하기 때문이다.
LOCK=".lock_bundle"
RUNID="$(hostname)|$$|stage$stage|$(date -u +%Y-%m-%dT%H:%M:%SZ)"
LOCKTMP="$LOCK.tmp.$$"
printf '%s\n' "$RUNID" > "$LOCKTMP" || exit 3
if ! ln "$LOCKTMP" "$LOCK" 2>/dev/null; then
  rm -f "$LOCKTMP"
  own=$(cat "$LOCK" 2>/dev/null || echo "?")
  own_host=${own%%|*}
  rest=${own#*|}; own_pid=${rest%%|*}
  echo "⛔ 단계 $stage 의 lock 이 이미 있습니다: $own"
  if [ "$own_host" = "$(hostname)" ] && ! kill -0 "$own_pid" 2>/dev/null; then
    echo "   같은 호스트의 pid $own_pid 는 살아 있지 않습니다."
    echo "   그래도 **자동으로 지우지 않습니다** — 다른 노드의 실행일 수 있습니다."
    echo "   확실하면 손으로: rm -f $LOCK"
  else
    echo "   다른 호스트/살아 있는 프로세스입니다. 끝날 때까지 기다리세요."
  fi
  exit 3
fi
rm -f "$LOCKTMP"
# 우리 것일 때만 지운다 (남의 lock 을 치우지 않는다)
# ⛔ 2026-09-08 (Codex v38 P1-1) — 잠금 **소유자만** 이 실행의 공유 상태를 만들고 정리한다.
#   증거(PLACEMENT_PROBE.json)와 규칙 파일(_place_flags.sh)은 남기고, 실행 중에만 뜻이 있는
#   호스트 풀·프로브 출력·가드 env 는 소유자가 나갈 때 치운다. 남의 lock 이면 손대지 않는다.
_unlock() {
  if [ "$(cat "$LOCK" 2>/dev/null)" = "$RUNID" ]; then
    rm -rf _hostpool; rm -f ._memguard.env _hosts_all.txt _probe_*.out
    rm -f "$LOCK"
  fi
  return 0
}
# 🔴🔴 회신 AT P0-5 — 종전 trap 은 INT/TERM 에서 **lock 만 지우고 러너는 계속
#   돌았다.** bash 는 핸들러를 돌린 뒤 하던 일을 이어간다. 그 사이 lock 이 비므로
#   다른 실행이 같은 번들에 들어올 수 있었다 — 잠금이 있으나 마나였다.
#   ⇒ 신호를 받으면 **자식을 죽이고 정말로 나간다.**
_bail() {
  echo ""
  echo "⛔ 신호를 받았습니다 ($1) — 자식 프로세스를 정리하고 중단합니다."
  trap - EXIT INT TERM
  # ⛔ 회신 BA P1 — **unlock 을 먼저** 한다. 종전엔 `kill -TERM 0` 이 앞서서
  #   호출자 process group 까지 종료시키고 lock 을 남길 수 있었다 (stale lock).
  _unlock
  kill -TERM 0 2>/dev/null || true      # 이 프로세스 그룹 전체
  exit "$2"
}
trap '_unlock' EXIT
trap '_bail INT 130' INT
trap '_bail TERM 143' TERM
# 🔴 회신 AV P0-2 — run_job.sh 는 이 토큰 없이는 거부한다 (직접 호출 차단).
#   토큰 = lock 파일 내용. lock 을 쥔 실행만이 값을 알고, 값이 곧 소유 증명이다.
export RUNNER_TOKEN="$RUNID"

# ── 동시 실행 잡 수. **메모리 사전검사가 먼저 써야 해서 여기서 정합니다.** ──────
#   (아래 물결 실행이 같은 $NPAR 을 씁니다 — 두 곳에 복사하지 않습니다.)
NPAR=${JOBS_PARALLEL:-$(python3 -c '
import json
print((json.load(open("MANIFEST.json")).get("submission") or {}).get("max_concurrency") or 1)'
)}
case "$NPAR" in ''|*[!0-9]*) NPAR=1 ;; esac
[ "$NPAR" -ge 1 ] || NPAR=1

# ══ 메모리 사전검사 ════════════════════════════════════════════════════════
#   왜 생겼나 (2026-09-04 실패) — 인수처에서 **슬랩 잡이 전부 OOM** 났습니다.
#   원인은 INCAR 도 물리도 아니고 **랭크 배치**였습니다. 잡 하나를 노드 하나에
#   몰아넣으면(48 랭크 / 1 노드) 최악 잡이 162.6 GB 를 요구하는데 노드 가용은
#   159.8 GB 였습니다. 2.8 GB 차이로 슬랩은 죽고 분자(56.1 GB)는 살아남아
#   로그만 봐서는 원인이 안 보였습니다.
#   ⇒ 벽시계는 몇 시간 뒤에나 알지만 메모리는 **시작 전에** 계산됩니다. 여기서 막습니다.
#   ⛔ 이 검사가 **못 하는 것**: 실제 사용량을 재지 않습니다. 모형이고 ±2배가
#     예상 범위입니다. ⛔ 2026-09-07 (Codex v37 P1-1) — 종전에 "실패에서 역산한
#     범위 0.98~2.85배" 라고 적었으나 **철회합니다**: 159.8 GB 는 관측된 OOM 임계가
#     아니라 우리 계획값이고, 슬랩과 분자에 같은 계수를 쓸 근거도 없습니다.
#     통과가 안전 보증이 아니라, **명백한 불가를 시작 전에 거르는** 것입니다.
if [ "${MEM_GUARD:-on}" = "off" ]; then
  echo "  ⚠ 메모리·배치 사전검사를 껐습니다 (MEM_GUARD=off)."
  echo "     2026-09-04 의 OOM 은 정확히 이 검사가 막는 종류였습니다."
else
  MEMG_NPAR="$NPAR" MEMG_NPROC="${VASP_NPROC:-1}" python3 <<'PYMEM' > ._memguard.env || exit 2
import json, math, os, sys

def out(*a):                       # 판정 출력은 stderr (stdout 은 export 용)
    print(*a, file=sys.stderr)

man = json.load(open("MANIFEST.json"))
mm = (man.get("submission") or {}).get("memory_model") or man.get("memory_model")
if not mm:
    out("  ⚠ MANIFEST 에 memory_model 이 없습니다 — 메모리 사전검사를 건너뜁니다.")
    out("     (2026-09-07 이전 묶음이면 정상입니다.)")
    sys.exit(0)

floor = float(mm["floor_GB"]); repl = float(mm["repl_GB_per_rank"])
frac = float(mm.get("usable_frac", 0.85)); worst = mm.get("worst_job", "(이름 없음)")
npar = max(1, int(os.environ.get("MEMG_NPAR", "1")))
nproc = max(1, int(os.environ.get("MEMG_NPROC", "1")))

# ══ ① 노드 메모리는 **관측을 먼저** 한다 ═══════════════════════════════════
#   ⛔ 2026-09-07 Codex v37 P0-1 — 종전엔 NODE_MEM_GB 를 그대로 믿었다. 노드에
#   64 GB 만 배정된 상태에서 NODE_MEM_GB=188 을 주면 **그대로 통과**했다.
#   ⇒ 관측 가능한 상한을 모두 모아 **가장 작은 것**을 쓰고, 선언이 그보다 크면 거부한다.
obs = []
# ⚠ 2026-09-08 (Codex v38 P2) — Slurm 의 `--mem=0` 은 "노드 전체 메모리" 다. 0 을 0 GiB 로
#   읽으면 정상 할당을 거부하거나 0 으로 나눈다. 0 은 **미관측**으로 취급한다.
try:
    v = os.environ.get("SLURM_MEM_PER_NODE")
    if v and float(v) > 0:
        obs.append((float(v) / 1024.0, "SLURM_MEM_PER_NODE"))
    vc = os.environ.get("SLURM_MEM_PER_CPU"); nc = os.environ.get("SLURM_CPUS_ON_NODE")
    if vc and nc and float(vc) > 0 and int(nc) > 0:
        obs.append((float(vc) * int(nc) / 1024.0, f"SLURM_MEM_PER_CPU×SLURM_CPUS_ON_NODE ({vc}×{nc})"))
except ValueError:
    pass
# ⛔ 2026-09-08 (Codex 재검토 P0-1 c) — 종전엔 cgroup **루트 파일만** 읽었다. 작업이 하위
#   cgroup 에 있으면(스케줄러가 보통 그렇게 만든다) 적용되는 제한을 놓친다. 현재 프로세스의
#   cgroup 경로를 /proc/self/cgroup 에서 읽어 **리프에서 루트까지 올라가며** 제한을 모두 모은다.
def _cgroup_mem_limits():
    got = []
    try:
        lines = open("/proc/self/cgroup").read().splitlines()
    except OSError:
        return got
    walks = []
    for ln in lines:
        parts = ln.split(":", 2)
        if len(parts) != 3:
            continue
        hid, ctrls, path = parts
        if hid == "0" and ctrls == "":                       # cgroup v2 (unified)
            walks.append(("/sys/fs/cgroup", path, "memory.max", "cgroup v2"))
        elif "memory" in ctrls.split(","):                   # cgroup v1 memory controller
            walks.append(("/sys/fs/cgroup/memory", path, "memory.limit_in_bytes", "cgroup v1"))
    for root, path, fname, tag in walks:
        segs = [x for x in path.split("/") if x]
        for k in range(len(segs), -1, -1):                   # 리프 → 루트
            d = os.path.join(root, *segs[:k]) if k else root
            try:
                t = open(os.path.join(d, fname)).read().strip()
                if t not in ("max", "") and int(t) < (1 << 62):
                    got.append((int(t) / 1024.0 ** 3, f"{tag} {d}/{fname}"))
            except (OSError, ValueError):
                pass
    return got
obs.extend(_cgroup_mem_limits())
try:
    for ln in open("/proc/meminfo"):
        if ln.startswith("MemTotal:"):
            obs.append((float(ln.split()[1]) / 1024.0 ** 2, "/proc/meminfo MemTotal")); break
except OSError:
    pass

decl = os.environ.get("NODE_MEM_GB")
decl = float(decl) if decl else None
if obs:
    mem, src = min(obs)
    if decl is not None and decl > mem * 1.001:
        out("⛔ NODE_MEM_GB 선언이 이 노드의 **실제 상한보다 큽니다.**")
        out(f"   선언 {decl:.0f} GB  vs  관측 {mem:.1f} GB ({src})")
        for g, n in sorted(obs):
            out(f"     · {n}: {g:.1f} GB")
        out("   더 큰 값을 선언해도 커널이 그만큼 주지 않습니다 — 그대로 돌리면 OOM 입니다.")
        out("   실제 배정을 늘리시거나 NODE_MEM_GB 를 관측값 이하로 낮춰 주십시오.")
        sys.exit(2)
    if decl is not None and decl < mem:
        mem, src = decl, f"NODE_MEM_GB (관측 {mem:.1f} GB 보다 보수적)"
elif decl is not None:
    mem, src = decl, "NODE_MEM_GB (⚠ 관측 불가 — 선언을 검증하지 못했습니다)"
else:
    mem, src = None, None

# ══ ② 노드 수도 **할당과 대조** 한다 — 관측이 선언보다 우선 ══════════════════
#   ⛔ 2026-09-07 P0-1: 총 4노드 할당에 "잡당 4노드 × 동시 4잡"(=16 필요) 이 통과했다.
#   ⛔ 2026-09-08 재검토 (b): 종전엔 VASP_TOTAL_NODES 를 **먼저** 읽고 끝내서, 그게 있으면
#     더 작은 SLURM_JOB_NUM_NODES 를 대조하지 않았다 — 선언이 관측을 덮는 경로였다.
#     ⇒ 관측(SLURM · VASP_HOSTFILE 의 고유 호스트 수)을 모으고, 선언은 **관측 이하일 때만**
#       받아들인다. 선언 > 관측이면 거부. 관측이 하나도 없으면 아래 배치 프로브가 관측을 대신한다.
obs_n = []
for k in ("SLURM_JOB_NUM_NODES", "SLURM_NNODES"):
    if os.environ.get(k):
        try:
            obs_n.append((int(os.environ[k]), k)); break
        except ValueError:
            pass
hf = os.environ.get("VASP_HOSTFILE")
if hf and os.path.isfile(hf):
    try:
        hosts = []
        for ln in open(hf):
            t = ln.split()
            if t and not t[0].startswith("#") and t[0] not in hosts:
                hosts.append(t[0])
        if hosts:
            obs_n.append((len(hosts), f"VASP_HOSTFILE 고유 호스트 ({hf})"))
    except OSError:
        pass
decl_n = os.environ.get("VASP_TOTAL_NODES")
decl_n = int(decl_n) if decl_n and decl_n.isdigit() else None
tot = None
if obs_n:
    tot = min(obs_n)
    if decl_n is not None and decl_n > tot[0]:
        out("⛔ VASP_TOTAL_NODES 선언이 **관측된 할당보다 큽니다.**")
        out(f"   선언 {decl_n} 노드  vs  관측 {tot[0]} 노드 ({tot[1]})")
        for n_, k_ in sorted(obs_n):
            out(f"     · {k_}: {n_}")
        out("   선언으로 할당을 늘릴 수 없습니다 — 관측값 이하로 낮추거나 실제 할당을 늘려 주십시오.")
        sys.exit(2)
    if decl_n is not None and decl_n < tot[0]:
        tot = (decl_n, f"VASP_TOTAL_NODES (관측 {tot[0]} 보다 보수적)")
elif decl_n is not None:
    tot = (decl_n, "VASP_TOTAL_NODES (⚠ 관측 없음 — 아래 배치 프로브가 실제 호스트로 검증합니다)")

nd = os.environ.get("VASP_NODES")
if nd:
    nodes, nsrc = max(1, int(nd)), "VASP_NODES"
elif tot:
    nodes, nsrc = max(1, tot[0] // npar), f"할당 {tot[0]} 노드 ÷ 동시 {npar} 잡"
else:
    nodes, nsrc = None, None

if tot and nodes is not None:
    need = nodes * npar
    if need > tot[0]:
        out("⛔ 요청한 배치가 **이 할당에 들어가지 않습니다.**")
        out(f"   잡당 {nodes} 노드 × 동시 {npar} 잡 = {need} 노드 필요"
            f"  vs  할당 {tot[0]} 노드 ({tot[1]})")
        out(f"   → 노드를 {need} 개로 늘리시거나, export JOBS_PARALLEL={max(1, tot[0] // nodes)}"
            f" 로 동시 실행을 줄여 주십시오.")
        sys.exit(2)

if mem is None or nodes is None:
    miss = []
    if mem is None:   miss.append("노드 메모리 (NODE_MEM_GB, 단위 GB)")
    if nodes is None: miss.append("잡 하나가 걸치는 노드 수 (VASP_NODES)")
    out("⛔ 메모리·배치 사전검사에 필요한 값을 알아내지 못했습니다:")
    for m in miss:
        out("   · " + m)
    out("   예:  export NODE_MEM_GB=188   export VASP_NODES=4")
    out("   ⚠ 모르는 채로 지나가지 않습니다 — 2026-09-04 OOM 이 정확히 그 경로였습니다.")
    out("   정말 검사 없이 돌리시려면  export MEM_GUARD=off  (권장하지 않습니다).")
    sys.exit(2)

# ══ ③ 랭크를 노드에 **정수로** 나눌 수 있어야 한다 ═════════════════════════
if nproc % nodes != 0:
    out(f"⛔ 랭크 {nproc} 을 노드 {nodes} 개에 고르게 못 나눕니다 ({nproc} % {nodes} != 0).")
    out("   불균등 분산은 한 노드에 랭크가 몰려 그 노드만 OOM 납니다.")
    out(f"   → VASP_NODES 를 {nproc} 의 약수로 주십시오.")
    sys.exit(2)
ppn = nproc // nodes

need_gb = (floor + nproc * repl) / nodes
usable = mem * frac
out("  ── 메모리·배치 사전검사 (모형) ──")
out(f"     최악 잡 {worst}")
out(f"     바닥 {floor:.1f} GB + 랭크 {nproc} x {repl:.2f} GB = {floor + nproc * repl:.1f} GB")
out(f"     노드 {nodes} 개 x 랭크 {ppn} 개/노드 ({nsrc})  ->  노드당 {need_gb:.1f} GB")
out(f"     노드 메모리 {mem:.1f} GB ({src}) x {frac:.2f} = 가용 {usable:.1f} GB")

if need_gb > usable:
    want = math.ceil((floor + nproc * repl) / usable)
    out(f"     ⛔ {need_gb / usable * 100:.0f} % — **이대로 돌리면 OOM 입니다.**")
    out("")
    out("   고치는 법 (INCAR 은 해시로 동결돼 있어 건드리지 마십시오):")
    out(f"     · 랭크 {nproc} 을 **노드 {want} 개 이상에 펼쳐** 주십시오 (현재 {nodes}).")
    out(f"     · 또는 동시 실행을 줄이십시오: export JOBS_PARALLEL=<값>")
    out(f"     · 필요한 총 노드 = {want} x 동시 {npar} = {want * npar} 개")
    out("   ⚠ 랭크 수를 **줄이지 마십시오** — KPAR x NCORE 배수 조건이 깨집니다.")
    sys.exit(2)

out(f"     ✔ {need_gb / usable * 100:.0f} % 사용 — 통과 (모형 기준 {usable / need_gb:.2f}배 여유)")
if not obs:
    out("     ⚠ 노드 메모리를 **관측하지 못했습니다** — 위 판정은 선언값에만 근거합니다.")
    print("MEMG_MEM_UNOBSERVED=1")
if not obs_n:
    out("     ⚠ 할당 노드 수를 관측하지 못했습니다 — **아래 배치 프로브가 실제 호스트로 검증합니다** (프로브도 못 하면 멈춥니다).")
    print("MEMG_NODES_UNOBSERVED=1")

# 검사한 배치를 **실행에 결박**한다 (P0-1 의 핵심 — 산술만 하고 끝내지 않는다)
print(f"VASP_NODES={nodes}")
print(f"VASP_RANKS_PER_NODE={ppn}")
print(f"MEMG_NEED_GB={need_gb:.3f}")       # 노드당 필요량 — 프로브가 실행 노드마다 다시 판정한다
print(f"MEMG_FRAC={frac}")
print(f"MEMG_LOCAL_GB={mem:.3f}")
# 스케줄러 할당(SLURM_* 관측)만 따로 넘긴다 — 프로브가 'cgroup 무제한(검증)' 노드의 상한을 min(할당, MemTotal) 로 잡는 데 쓴다 (Codex v39 P1).
_sched = [g for g, n in obs if n.startswith("SLURM_")]
print(f"MEMG_SCHED_GB={min(_sched):.3f}" if _sched else "MEMG_SCHED_GB=")
PYMEM
  # shellcheck disable=SC1091
  . ./._memguard.env && rm -f ._memguard.env
  export VASP_NODES VASP_RANKS_PER_NODE MEMG_NEED_GB MEMG_FRAC MEMG_LOCAL_GB MEMG_SCHED_GB
  echo "     → 배치 결박: VASP_NODES=$VASP_NODES · VASP_RANKS_PER_NODE=$VASP_RANKS_PER_NODE"
fi

# ══ 배치 **실측** — 호스트 풀 + 동시 프로브 (2026-09-08 Codex 재검토 P0-1 a·b) ══════
#   플래그가 launcher 에 **도착**하는 것과 랭크가 **실제로 그 노드들에 놓이는** 것은 다르다.
#   · -N/-ppn 은 노드당 랭크만 정하고, 동시에 뜨는 launcher 호출들이 **서로 다른 호스트
#     집합**을 쓰게 하지 않는다 ⇒ 할당 호스트를 JOBS_PARALLEL 조각으로 나눠 잡별 hostfile 로 준다.
#   · Intel MPI 는 스케줄러 배치를 존중하는 기본값에서 -ppn 을 무시할 수 있다
#     ⇒ I_MPI_JOB_RESPECT_PROCESS_PLACEMENT=0.
#   · 그리고 **첫 VASP 실행 전에** 같은 launcher·같은 플래그로 `hostname` 을 NPAR 개
#     **동시에** 띄워 rank→host 를 읽는다: 프로브마다 (고유 호스트 = VASP_NODES) ∧
#     (호스트당 랭크 = VASP_RANKS_PER_NODE) ∧ (호스트 ⊆ 자기 조각) ∧ **프로브 간 호스트 집합
#     서로소**. 하나라도 어긋나면 멈춘다. 결과는 PLACEMENT_PROBE.json 에 남는다 (배치 증거).
#   ⛔ 이 검사가 못 하는 것: 메모리 대역·통신망·NUMA 는 보지 않는다. VASP 를 돌리지 않는다.
if [ "${MEM_GUARD:-on}" != "off" ] && [ "$VASP_LAUNCHER_KIND" != none ]; then
  _NPROBE=$NPAR
  _np_flag_p="-np"; [ "$VASP_LAUNCHER_KIND" = srun ] && _np_flag_p="-n"
  # ── 호스트 목록 (관측) ──────────────────────────────────────────────────
  : > _hosts_all.txt; _HOSTS_SRC=""
  if [ -n "${SLURM_JOB_NODELIST:-}" ] && command -v scontrol >/dev/null 2>&1; then
    if scontrol show hostnames "$SLURM_JOB_NODELIST" > _hosts_all.txt 2>/dev/null && [ -s _hosts_all.txt ]; then
      _HOSTS_SRC="scontrol show hostnames \$SLURM_JOB_NODELIST"
    fi
  fi
  if [ -z "$_HOSTS_SRC" ] && [ -n "${VASP_HOSTFILE:-}" ] && [ -f "$VASP_HOSTFILE" ]; then
    awk 'NF && $1 !~ /^#/ {print $1}' "$VASP_HOSTFILE" | awk '!seen[$0]++' > _hosts_all.txt
    [ -s _hosts_all.txt ] && _HOSTS_SRC="VASP_HOSTFILE=$VASP_HOSTFILE"
  fi
  # ── 배치 플래그 규칙: 러너와 프로브가 **같은 파일**을 읽는다 (두 곳에 복사하지 않는다) ──
  cat > _place_flags.sh <<'PF'
# 생성: run_staged.sh (2026-09-08). run_job.sh 와 배치 프로브가 이 함수 하나로 플래그를 만든다.
place_args() {   # $1 mode(srun|ompi|hydra)  $2 slotfile(절대경로)  $3 nodes  $4 ranks/node
  case "$1" in
    srun)  printf -- '--nodelist=%s --nodes=%s --ntasks-per-node=%s' "$(paste -sd, "$2")" "$3" "$4" ;;
    ompi)  printf -- '--hostfile %s -N %s' "$2" "$4" ;;
    hydra) printf -- '-f %s -ppn %s' "$2" "$4" ;;
    *)     return 1 ;;
  esac
}
PF
  # ── 모드 판별 (한 곳에서만) ───────────────────────────────────────────────
  VASP_PLACE_MODE=""
  case "$VASP_LAUNCHER_KIND" in
    srun) VASP_PLACE_MODE=srun ;;
    mpirun|mpiexec)
      _mpiver=$("$LAUNCHER_BIN" --version 2>&1 | head -5 || true)
      case "$_mpiver" in
        *"Open MPI"*|*OpenRTE*|*open-mpi*) VASP_PLACE_MODE=ompi ;;
        *HYDRA*|*Hydra*|*MPICH*|*"Intel(R) MPI"*)
          VASP_PLACE_MODE=hydra
          case "$_mpiver" in *"Intel(R) MPI"*)
            export I_MPI_JOB_RESPECT_PROCESS_PLACEMENT=0   # 없으면 -ppn 이 무시될 수 있다 (Intel 문서)
            echo "  · Intel MPI: I_MPI_JOB_RESPECT_PROCESS_PLACEMENT=0 (스케줄러 배치 존중 시 -ppn 무시 방지)" ;;
          esac ;;
        *)
          echo "⛔ MPI 구현을 판별하지 못해 **랭크 배치를 강제할 수 없습니다.** ($LAUNCHER_BIN --version)"
          printf '     %s\n' "$_mpiver"
          echo "   → srun 을 쓰시거나, 배치를 고정한 현장 래퍼를 VASP_LAUNCHER_KIND=wrapper 로 주십시오."
          exit 2 ;;
      esac ;;
    wrapper)
      echo "⛔ VASP_LAUNCHER_KIND=wrapper 는 **이 제출 경로에서 지원하지 않습니다** (2026-09-08 Codex v38 P1-2)."
      echo "   래퍼는 잡별 호스트 조각을 점유·반납하지 않아 동시 잡의 자원이 실행 내내 서로소라는"
      echo "   보장을 이 러너가 확인할 수 없습니다. srun · Open MPI · MPICH/Intel MPI 중 하나로 주십시오."
      exit 2 ;;
  esac
  export VASP_PLACE_MODE
  # ── 호스트 풀 (잡별 서로소 조각) ─────────────────────────────────────────
  rm -rf _hostpool; mkdir -p _hostpool/free _hostpool/busy
  if [ "$VASP_PLACE_MODE" != wrapper ]; then
    if [ -z "$_HOSTS_SRC" ]; then
      echo "⛔ 할당 호스트 목록을 얻지 못해 **잡별 호스트 분리를 할 수 없습니다.**"
      echo "   SLURM 할당 안에서 돌리시거나(SLURM_JOB_NODELIST + scontrol), 할당 호스트를 한 줄에"
      echo "   하나씩 적은 파일을 VASP_HOSTFILE 로 주십시오. 분리 없이 동시 $NPAR 잡을 띄우면"
      echo "   launcher 들이 같은 노드에 겹쳐 OOM 납니다 — 2026-09-04 의 그 경로입니다."
      exit 2
    fi
    python3 - "$VASP_NODES" "$NPAR" <<'PYPOOL' || exit 2
import sys
nodes, npar = int(sys.argv[1]), int(sys.argv[2])
hosts = [l.strip() for l in open("_hosts_all.txt") if l.strip()]
need = nodes * npar
if len(hosts) < need:
    print(f"⛔ 호스트 {len(hosts)} 개로는 잡당 {nodes} × 동시 {npar} = {need} 개를 채울 수 없습니다.", file=sys.stderr)
    print(f"   → 할당을 늘리시거나 export JOBS_PARALLEL={max(1, len(hosts)//nodes)}", file=sys.stderr)
    sys.exit(2)
for k in range(npar):
    with open(f"_hostpool/free/slot_{k+1}", "w") as f:
        f.write("\n".join(hosts[k*nodes:(k+1)*nodes]) + "\n")
print(f"  ✔ 호스트 풀: {npar} 조각 × {nodes} 호스트 (출처 {len(hosts)} 호스트)", file=sys.stderr)
PYPOOL
  fi
  # ── 노드 프로브 페이로드 — 호스트 이름만이 아니라 **그 노드에 적용된 메모리 제한**을 읽는다 ──
  #   ⛔ 2026-09-08 (Codex v38 P1-2) — 종전 프로브는 hostname 만 찍어, 러너 호스트(188 GiB)와
  #   실행 노드(64 GiB)가 다른 hostfile 구성에서 **실행 노드의 제한을 보지 못했다.** 각 랭크가
  #   자기 노드에서 cgroup 계층(리프→루트)의 최소와 MemTotal 을 읽어 보낸다. POSIX sh 만 쓴다.
  cat > _probe_node.sh <<'PN'
#!/bin/sh
# 출력: <hostname>\t<제한: bytes | max | none>\t<MemTotal bytes>\t<상태>\t<근거>
#   상태 finite     — cgroup 계층(리프→루트) 어딘가에서 **유한 제한을 읽었다** (최소값 · 근거 = 그 파일)
#        unlimited  — 제한 파일을 **실제로 읽었고** 전부 max(v2)/무제한 센티널(v1) 이었다, 또는
#                     memory 컨트롤러가 보이는 루트 cgroup 이다 (v2 루트에는 memory.max 가 없다)
#        unobserved — /proc/self/cgroup 이 없다 · memory 계층 줄이 없다 · cgroup 경로가 이 마운트에 없다 ·
#                     루트인데 memory 컨트롤러가 안 보인다 (namespace 밖의 제한을 못 본다)
#   ⛔ Codex v39 P1 — 'none' 은 **못 읽었다**는 뜻이다. 커널이 정의하는 memory.max 의 'max'(무제한)와
#      읽기 실패는 다른 상태다. 둘을 합쳐 'none' 으로 내던 종전 출력을 폐기한다.
h=$(hostname 2>/dev/null || cat /etc/hostname 2>/dev/null || echo unknown)
# MemTotal: awk 로는 **필드만** 뽑고 곱셈은 셸 산술(64비트)로 한다 — awk 구현에 따라 큰 수를 6.87e+10 처럼
# 지수표기로 내어 판정기의 int() 가 줄을 버릴 수 있다 (Codex v39 §4 호환성 지적).
mt=$(awk '/^MemTotal:/{print $2; exit}' /proc/meminfo 2>/dev/null); mt=$(( ${mt:-0} * 1024 ))
lim=""; limsrc=""; nread=0; nhier=0; nroot=0; miss=""; state=""; why=""
if [ ! -r /proc/self/cgroup ]; then
  state=unobserved; why="no-proc-self-cgroup"
else
  while IFS=: read -r id ctrl path; do
    root=""; f=""
    if [ "$id" = "0" ] && [ -z "$ctrl" ]; then root=/sys/fs/cgroup; f=memory.max; fi
    case ",$ctrl," in *,memory,*) root=/sys/fs/cgroup/memory; f=memory.limit_in_bytes ;; esac
    [ -n "$root" ] || continue
    nhier=$((nhier+1))
    p="$path"
    if [ ! -d "$root$p" ]; then miss="cgroup-path-not-mounted:$root$p"; continue; fi
    while :; do
      if [ -r "$root$p/$f" ]; then
        v=$(cat "$root$p/$f" 2>/dev/null)
        case "$v" in
          '') ;;
          max) nread=$((nread+1)) ;;
          *) if [ "$v" -lt 4611686018427387904 ] 2>/dev/null; then
               nread=$((nread+1))
               if [ -z "$lim" ] || [ "$v" -lt "$lim" ]; then lim=$v; limsrc="$root$p/$f"; fi
             elif [ "$v" -ge 4611686018427387904 ] 2>/dev/null; then nread=$((nread+1)); fi ;;
        esac
      else
        case "$p" in ""|"/")
          # v2 루트에는 memory.max 가 없다. memory 컨트롤러가 여기서 **보이면** 루트=무제한으로 인정하고,
          # 안 보이면(namespace 루트인데 부모가 memory 를 위임하지 않음) 제한을 못 본 것이다.
          if [ "$f" = "memory.max" ]; then
            if grep -qw memory "$root/cgroup.controllers" 2>/dev/null; then nroot=$((nroot+1))
            else miss="memory-controller-not-visible-at-root:$root"; fi
          fi ;;
        esac
      fi
      case "$p" in ""|"/") break ;; esac
      p="${p%/*}"
    done
  done < /proc/self/cgroup
  # 우선순위: 유한 > 실제로 읽은 계층이 전부 max > 경로 미마운트 > memory 계층 없음 > 루트(컨트롤러 보임) > 그 외 미관측
  #   hybrid(v1 memory + `0::/`) 에서는 v2 루트 검사가 헛돌 수 있지만, v1 을 읽었으면 그것이 memory 계층이다.
  if [ -n "$lim" ]; then state=finite; why="$limsrc"
  elif [ "$nread" -gt 0 ]; then state=unlimited; why="all-readable-levels-max:$nread"
  elif [ -n "$miss" ]; then state=unobserved; why="$miss"
  elif [ "$nhier" -eq 0 ]; then state=unobserved; why="no-memory-hierarchy-in-proc-self-cgroup"
  elif [ "$nroot" -gt 0 ]; then state=unlimited; why="root-cgroup-v2(memory-controller-visible,no-memory.max-on-root)"
  else state=unobserved; why="no-limit-file-readable"; fi
fi
case "$state" in finite) l="$lim" ;; unlimited) l=max ;; *) l=none ;; esac
printf '%s\t%s\t%s\t%s\t%s\n' "$h" "$l" "$mt" "$state" "$why"
PN
  chmod +x _probe_node.sh
  # ── 동시 프로브 ────────────────────────────────────────────────────────
  . ./_place_flags.sh
  rm -f _probe_*.out
  for _k in $(seq 1 "$_NPROBE"); do
    _sf="$PWD/_hostpool/free/slot_$_k"
    _pa=$(place_args "$VASP_PLACE_MODE" "$_sf" "$VASP_NODES" "$VASP_RANKS_PER_NODE")
    # shellcheck disable=SC2086
    ( "$LAUNCHER_BIN" $_pa "$_np_flag_p" "$VASP_NPROC" /bin/sh "$PWD/_probe_node.sh" > "_probe_$_k.out" 2>/dev/null ) &
  done
  wait
  python3 - "$_NPROBE" "$VASP_NODES" "$VASP_RANKS_PER_NODE" "$VASP_PLACE_MODE" "$_HOSTS_SRC" <<'PYPROBE' || exit 2
import sys, json, collections, os, time
npr, nodes, ppn, mode, src = int(sys.argv[1]), int(sys.argv[2]), int(sys.argv[3]), sys.argv[4], sys.argv[5]
need_gb = float(os.environ.get("MEMG_NEED_GB") or 0); frac = float(os.environ.get("MEMG_FRAC") or 0.85)
# 러너 호스트에서 관측한 **스케줄러 할당**(SLURM_MEM_PER_NODE · MEM_PER_CPU×CPUS) — 할당 전 노드에 같이 적용된다.
_sg = os.environ.get("MEMG_SCHED_GB") or ""
sched_gb = float(_sg) if _sg.strip() else None
GiB = 1024.0 ** 3
_RANK = {"unobserved": 0, "finite": 1, "unlimited": 2}      # 같은 호스트에 여러 줄이면 **더 나쁜 상태**를 남긴다
res, bad, seen_all, node_mem, node_info = [], [], {}, {}, {}
for k in range(1, npr + 1):
    try:
        raw = [l.rstrip("\n") for l in open(f"_probe_{k}.out") if l.strip()]
    except OSError:
        raw = []
    # 각 줄: host \t limit(bytes|max|none) \t memtotal \t state(finite|unlimited|unobserved) \t why
    #   (구판 hostname 전용 출력도 첫 필드로 받는다. 구판 3필드 'none' 은 **미관측**으로 읽는다 —
    #    Codex v39 P1: 못 읽은 것을 무제한으로 간주하지 않는다.)
    lines = []
    for l in raw:
        f = [x.strip() for x in l.split("\t")]
        h = f[0]; lines.append(h)
        if len(f) < 3:
            continue
        try:
            mt = int(f[2]) / GiB if int(f[2]) > 0 else None
        except ValueError:
            mt = None
        lim, st, why = None, (f[3] if len(f) >= 4 else None), (f[4] if len(f) >= 5 else "")
        if st is None:                                   # 구판 3필드
            if f[1].isdigit(): st, lim = "finite", int(f[1]) / GiB
            else: st, why = "unobserved", "legacy-probe-format(none)"
        elif st == "finite":
            if f[1].isdigit(): lim = int(f[1]) / GiB
            else: st, why = "unobserved", "finite-without-value"
        elif st == "unlimited":
            if f[1] != "max": st, why = "unobserved", f"unlimited-with-value({f[1]})"
        else:
            st = "unobserved"; why = why or "probe-said-unobserved"
        ni = {"state": st, "limit_GiB": lim, "memtotal_GiB": mt, "why": why}
        old = node_info.get(h)
        if old is None or _RANK[st] < _RANK[old["state"]]:
            node_info[h] = ni
        elif _RANK[st] == _RANK[old["state"]]:
            for key in ("limit_GiB", "memtotal_GiB"):
                if ni[key] is not None and (old[key] is None or ni[key] < old[key]): old[key] = ni[key]
    cnt = collections.Counter(lines)
    want = None
    if mode != "wrapper":
        try:
            want = [l.strip() for l in open(f"_hostpool/free/slot_{k}") if l.strip()]
        except OSError:
            want = None
    rec = {"probe": k, "ranks_seen": len(lines), "hosts": dict(cnt), "slot_hosts": want}
    why = []
    if not lines:
        why.append("출력 없음 — launcher 가 hostname 을 실행하지 못했다")
    if len(cnt) != nodes:
        why.append(f"고유 호스트 {len(cnt)} ≠ VASP_NODES {nodes}")
    if any(v != ppn for v in cnt.values()):
        why.append(f"호스트당 랭크 {sorted(set(cnt.values()))} ≠ {ppn}")
    if want is not None and not set(cnt) <= set(want):
        why.append(f"자기 조각 밖 호스트 {sorted(set(cnt) - set(want))}")
    for h in cnt:
        if h in seen_all:
            why.append(f"프로브 {seen_all[h]} 와 호스트 {h} 겹침 — 동시 잡이 같은 노드를 쓴다")
        seen_all.setdefault(h, k)
    # ── 노드별 메모리 판정 (Codex v38 P1-2 · v39 P1) — 러너 호스트가 아니라 **실행 노드**의 제한으로 본다
    #   세 상태를 가른다: finite → 그 값 · unlimited(검증) → min(스케줄러 할당, 물리 RAM) · unobserved → **정지**.
    #   ⛔ 못 읽은 노드를 물리 RAM 으로 통과시키지 않는다 (v39 P1 — 종전 코드가 그렇게 했다).
    rec_nm = {}
    if need_gb > 0:
        # 같은 사유는 접는다 — 96 노드가 전부 같은 이유면 96 줄이 아니라 한 줄이어야 읽힌다
        _unobs, _short = {}, {}
        for h in sorted(cnt):
            ni = node_info.get(h)
            if ni is None:
                _unobs.setdefault("no-probe-line", []).append(h); rec_nm[h] = {"state": "unobserved", "why": "no-probe-line"}; continue
            st, lim, mt = ni["state"], ni["limit_GiB"], ni["memtotal_GiB"]
            if st == "unobserved":
                _unobs.setdefault(ni["why"], []).append(h)
                rec_nm[h] = {"state": st, "limit_GiB": None, "memtotal_GiB": (round(mt, 2) if mt else None), "bound_GiB": None,
                             "basis": f"미관측 ({ni['why']}) — 물리 RAM 으로 대체하지 않는다"}
                continue
            if st == "finite":
                cands = [x for x in (lim, mt) if x is not None]
                basis = f"cgroup 유한 제한 {lim:.1f} GiB ({ni['why']})" + (f" · MemTotal {mt:.1f}" if mt else "")
            else:                                                       # unlimited (검증됨)
                if mt is None:
                    _unobs.setdefault("unlimited-but-no-MemTotal", []).append(h)
                    rec_nm[h] = {"state": "unobserved", "why": "unlimited-but-no-MemTotal"}; continue
                cands = [mt] + ([sched_gb] if sched_gb else [])
                basis = (f"cgroup 무제한 (검증: {ni['why']}) · 상한 = "
                         + (f"min(스케줄러 할당 {sched_gb:.1f}, MemTotal {mt:.1f})" if sched_gb
                            else f"MemTotal {mt:.1f} (러너 호스트에서 스케줄러 할당 미관측)"))
            g = min(cands)
            node_mem[h] = g
            rec_nm[h] = {"state": st, "limit_GiB": (round(lim, 2) if lim else None), "memtotal_GiB": (round(mt, 2) if mt else None),
                         "bound_GiB": round(g, 2), "basis": basis}
            if need_gb > g * frac:
                _short.setdefault(round(g, 1), []).append(h)
        for r_, hs in sorted(_unobs.items()):
            why.append(f"{len(hs)} 노드 메모리 제한 **미관측** ({r_} · 예 {hs[:3]}) — 물리 RAM 으로 대체하지 않고 멈춘다")
        for g, hs in sorted(_short.items()):
            why.append(f"{len(hs)} 노드(예 {hs[0]}…{hs[-1]}): 노드당 필요 {need_gb:.1f} GiB > 가용 {g:.1f}×{frac:.2f}={g*frac:.1f} GiB")
    rec["node_mem_GiB"] = {h: round(node_mem[h], 2) for h in cnt if h in node_mem}
    rec["node_mem"] = rec_nm
    rec["limit_states"] = dict(collections.Counter(v["state"] for v in rec_nm.values()))
    rec["ok"] = not why; rec["why"] = why
    res.append(rec)
    if why: bad.append((k, why, dict(cnt)))
json.dump({"schema": "placement_probe/v1", "at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
           "mode": mode, "hosts_source": src, "concurrent_probes": npr,
           "expected": {"nodes_per_job": nodes, "ranks_per_node": ppn,
                        "need_GiB_per_node": round(need_gb, 3), "usable_frac": frac},
           "node_mem_GiB_min": (round(min(node_mem.values()), 2) if node_mem else None),
           "scheduler_alloc_GiB_runner": sched_gb,
           "limit_state_rule": {"finite": "cgroup 계층에서 읽은 유한 제한 (min(제한, MemTotal))",
                                "unlimited": "제한 파일을 실제로 읽었고 전부 max — 상한 = min(스케줄러 할당(관측 시), MemTotal)",
                                "unobserved": "제한을 못 읽음 — **정지** (물리 RAM 으로 대체하지 않는다 · Codex v39 P1)"},
           "probes": res, "all_ok": not bad,
           "⛔_이_기록이_보증하지_않는_것": "메모리 대역·통신망·NUMA. VASP 자체의 배치도 아니다 — 같은 launcher·같은 플래그로 프로브를 놓아 본 결과다. 'unlimited' 는 cgroup 이 안 막는다는 뜻이지 스케줄러가 코어·메모리를 예약했다는 증거가 아니다."},
          open("PLACEMENT_PROBE.json", "w"), ensure_ascii=False, indent=1)
if bad:
    print("⛔ 배치 프로브 실패 — **launcher 가 요청한 대로 랭크를 놓지 않았습니다.** 첫 VASP 전에 멈춥니다.", file=sys.stderr)
    for k, why, cnt in bad:
        print(f"   프로브 {k}: " + " · ".join(why), file=sys.stderr)
        print(f"      관측 rank→host: {cnt}", file=sys.stderr)
    print("   PLACEMENT_PROBE.json 에 전부 기록했습니다. 이 상태로 VASP 를 띄우면 노드가 겹쳐 OOM 납니다.", file=sys.stderr)
    sys.exit(2)
_states = collections.Counter(v["state"] for r in res for v in r.get("node_mem", {}).values())
print(f"  ✔ 배치 프로브 {npr} 개 동시 통과: 각 {nodes} 호스트 × {ppn} 랭크 · 프로브 간 호스트 서로소"
      + (f" · 실행 노드 메모리 최소 {min(node_mem.values()):.1f} GiB ≥ 필요 {need_gb:.1f}/{frac:.2f}" if node_mem and need_gb > 0 else "")
      + (f" · 제한 상태 {dict(_states)}" if _states else "")
      + " · PLACEMENT_PROBE.json", file=sys.stderr)
PYPROBE
  rm -f _probe_*.out       # 관측은 PLACEMENT_PROBE.json 에 있다 (실패 시엔 exit 2 로 위에서 끝나 _unlock 이 치운다)
fi

PP=${PP:?PP 를 지정하세요 (POTCAR 원본 트리)}
POTCAR_ALLOWLIST=${POTCAR_ALLOWLIST:?POTCAR_ALLOWLIST 를 지정하세요 (절대경로)}


# ⛔⛔ 회신 AR P0-7 · 해제조건 8 — **실행 전 census.** 종전엔 존재하는 job.json
#   만 분류하고 디렉터리 수만 비교해서, job.json 하나를 지워도 통과했다.
#   ⇒ ① MANIFEST 해시(봉인/EXPECT 와 결박) ② 계획 잡 **집합** 완전일치
#     ③ 단계 분류가 manifest 선언과 **정확히** 같은지 — 셋 다 확인한다.
python3 census.py "$stage" || { echo "⛔ 실행 전 census 실패 — 중단"; exit 2; }

# ⛔⛔ 회신 BA P0-1 (2026-09-02) — **SEAL 을 preflight 뒤로 옮긴다.**
#   종전엔 러너가 SEAL 을 **먼저** 불렀고, SEAL 은 16개 `POTCAR_ASSEMBLE.sh` 를
#   실행한다. `EXPECT_*`·`files_sha256` 검사는 그 **뒤**였다. 즉 변조된 assembler 가
#   무결성 검사 **전에** 실행됐다 — 리뷰어가 흔적을 만든 뒤 자기 바이트를 원본으로
#   복구하는 재현으로 잡았다.
#   ⇒ 추출 파일 전수검사(census + files_sha256 + EXPECT)를 **먼저** 끝내고,
#     그것이 통과한 뒤에만 배포 스크립트를 실행한다.
#   ⚠ ZIP SHA 자체는 ZIP 밖에서 대조해야 한다 — README 의 첫 단계가 그것이다.

# ⛔ 회신 AT P0-6 — SEAL 은 러너가 **이미 lock 을 쥔 채** 부른다. 중복 획득으로
#   교착하지 않도록 알려 준다 (단독 실행이면 SEAL 이 스스로 잡는다).
# ⛔ 회신 BD P0-4 · GO 해제조건 5 — 거버넌스를 **SEAL 보다 먼저** 본다.
#   비준이 안 섰으면 조립·봉인도 하지 않는다 (그것도 되돌리기 어려운 상태다).
# 🔴🔴 회신 BE P0-3 (2026-09-03) — 루트 마커 **파일만으로** 거버넌스를 건너뛰었다.
#   production 번들에 `.SELFTEST_FIXTURE` 하나 두면 비준 실패 fixture 가 SEAL 직전까지
#   갔다 (리뷰어 재현). run_job.sh 와 같은 규칙으로 맞춘다: **MANIFEST 가 스스로
#   selftest_fixture=true 를 선언한 번들에서만, 그리고 마커도 있을 때만** 픽스처다.
#   production MANIFEST 에 그 필드를 심으면 해시가 바뀌어 EXPECT·봉인 대조가 깨지고,
#   선언 없는 마커는 census 가 거부한다.
_GFIX=0
if [ -f .SELFTEST_FIXTURE ] && python3 -c 'import json,sys;sys.exit(0 if json.load(open("MANIFEST.json")).get("selftest_fixture") is True else 1)' 2>/dev/null; then
  _GFIX=1
fi
if [ "$_GFIX" = 1 ]; then
  echo "  ⚠ selftest 픽스처(MANIFEST 선언 + 마커) — 거버넌스 사전검사를 건너뜁니다"
  echo "     (**실물 번들에는 선언도 마커도 없습니다**. 하나만 있으면 fail-closed 입니다)."
else
  python3 analyze_results.py . --check_governance \
    || { echo "거버넌스 검사 실패 — 중단 (회신 BD P0-4: 비용 발생 전에 닫는다)"; exit 2; }
fi
BUNDLE_LOCK_HELD=1 bash SEAL_POTCAR_ROOT.sh || { echo "POTCAR 조립·봉인 실패 — 중단"; exit 1; }

# ⛔ 회신 BA P0-1 — SEAL 이 만든 봉인을 **여기서** 검사한다 (앞 census 는 파일
#   무결성만 봤다). 같은 코드를 두 번 돌리므로 검사 로직이 갈라지지 않는다.
RECHECK_SEAL=1 python3 census.py "$stage" || { echo "⛔ 봉인 census 실패 — 중단"; exit 2; }

# ⛔⛔ 회신 AZ P0-7 (2026-09-01) — **attestation 을 생산 전에 강제**한다.
#   봉인은 "이 계산들이 하나의 트리에서 나왔고 그 트리가 생산 전에 고정됐다" 까지만
#   보증한다. **그 트리가 승인된 PAW dataset 인지**는 보증하지 않는다. VASP 는 여러
#   PAW 세트와 suffix variant 를 배포하므로 dataset 신원은 계산 조건의 일부다.
#   ⇒ 사후 provenance 만으로는 원고 인용 자격이 안 선다 (회신 AZ Q4).
#   이 게이트는 MANIFEST 의 `potcar_identity_policy` 가 정한다:
#     require_attestation  → attestation 이 없으면 **한 잡도 안 돈다** (원고용)
#     post_hoc             → 경고만 하고 진행 (탐색용 — 원고 인용 불가)
_AP=$(python3 -c 'import json;print((json.load(open("MANIFEST.json")).get("potcar_identity_policy") or {}).get("mode") or "post_hoc")' 2>/dev/null || echo post_hoc)
if [ "$_AP" = "require_attestation" ]; then
  if [ ! -s POTCAR_ATTESTATION.json ]; then
    echo "⛔ POTCAR_ATTESTATION.json 이 없습니다 — 이 묶음은 **원고용 정책**"
    echo "   (potcar_identity_policy.mode=require_attestation)이라 attestation 없이는"
    echo "   한 잡도 돌리지 않습니다 (회신 AZ P0-7)."
    echo "   첫 VASP 실행 **전에** 만드십시오:  bash MAKE_POTCAR_ATTESTATION.sh"
    exit 2
  fi
  # ⛔⛔ 회신 BB P0-6 (2026-09-02) — **검사 사본을 두지 않는다.**
  #   종전엔 여기에 짧은 파이썬 사본이 있어 `made_before_production` 과 SHA map
  #   두 가지만 봤다. schema·ZIP·manifest·allowlist·VASP·시각은 **분석 단계에
  #   가서야** 봤으므로, 잘못된 증서로 16잡(약 300 h)을 다 돌린 뒤 거부될 수
  #   있었다. 그리고 사본은 언젠가 정본과 갈린다 (BA 해제조건 8 이 그 사고였다:
  #   사본이 `sealed_before_production`/`source_sha256` 이라는 **없는 키**를
  #   요구해 정상 증서를 거부했다).
  #   ⇒ 정본 하나(`potcar_identity_gates`)를 부른다. 그 파일 SHA 는 MANIFEST 에 있다.
  python3 analyze_results.py . --check_attestation || exit 2
else
  echo "  ⚠ POTCAR 신원 정책 = post_hoc — attestation 없이 진행합니다."
  echo "     이 묶음의 결과는 **탐색용**이고 원고 인용 자격이 서지 않습니다"
  echo "     (승인된 PAW dataset 인지 확인 못 함 · 회신 AZ P0-7·Q4)."
  # 🔴🔴 렌즈4 P0-1 (2026-09-03) — post_hoc 이라도 **선택 증서가 있으면 지금 검증한다.**
  #   종전엔 이 분기에서 증서를 보지 않아, 결함 있는 증서(예: 버전 문자열 형식 불일치)가
  #   1단계를 다 돌린 **뒤에야** 최종 분석의 potcar_identity 에서 처음 막혔다. "선택" 은 없어도 된다는
  #   뜻이지 틀린 것이 있어도 된다는 뜻이 아니다. 결함이면 여기서 멈춘다 (지우면 돌아간다).
  if [ -s POTCAR_ATTESTATION.json ]; then
    echo "  ⚠ 선택 attestation 이 있습니다 — 생산 전에 봉인·MANIFEST·ZIP 과 대조합니다."
    python3 analyze_results.py . --check_attestation \
      || { echo "⛔ 선택 attestation 에 결함 — 지우고 돌리거나 다시 만드십시오 (렌즈4 P0-1)"; exit 2; }
  fi
fi

# ⛔ 회신 AP #6 — receipt 존재만으로 2단계를 열지 않는다. **지금 결과로 재판정**한다.
#    (해시 결박보다 단순하고, 위조 receipt 로 우회할 수 없다)
if [ "$stage" = 2 ]; then
  echo "== 2단계 시작 전 1단계 재판정 =="
  python3 analyze_results.py . --gate vacconv || {
    echo "1단계 게이트가 지금 결과로 통과하지 않는다 — 2단계를 열지 않는다."; exit 2; }
fi

# 잡 분류는 job.json 의 **구조화 필드**로 한다 — 이름 파싱 금지
python3 -c '
import json, sys, glob, os
want = sys.argv[1]
for jp in sorted(glob.glob("*/*/job.json")):
    m = json.load(open(jp)); d = os.path.dirname(jp)
    kind, role, vac = m.get("kind"), m.get("role"), m.get("vacconv")
    if kind is None:
        sys.exit("job.json 에 kind 가 없다: " + jp)
    if kind == "mol_ref":
        s = "1"
    elif kind == "clean_ref":
        # 2026-09-04 — clean slab 은 기준계다. E_S 가 1단계에 있어야 절대 E_ads 를
        # 1단계 게이트에서 확인할 수 있다. 부 seed 는 민감도라 2단계.
        s = "1" if (vac or m.get("seed") == "afm2424_pm1") else "2"
    elif kind == "prospective_pose" and role == "primary":
        s = "1" if (vac or m.get("seed") == "afm2424_pm1") else "2"
    else:
        s = "2"
    if s == want:
        print(d)
' "$stage" > _stage_jobs.txt || { echo "잡 분류 실패 — 중단"; exit 2; }

# ⛔ 회신 AP #9 — 분류가 조용히 0개/일부만 내고 성공하는 것을 막는다.
n_stage=$(grep -c . _stage_jobs.txt || true)
# ⛔ 2026-09-11 — census 와 같은 버그가 여기에도 있었다: `ls -d */*/` 가 `_hostpool/{free,busy}` 를
#   세어 "잡 폴더 18 ≠ 계획 16" 으로 죽는다. census 를 고쳐도 **이 줄에서 다시 죽는다.**
#   `_` 최상위 폴더는 러너 작업공간이다 — census.py 의 규칙과 **같은 규칙**을 쓴다.
n_total=$(ls -d */*/ 2>/dev/null | grep -v "^_" | wc -l)
n_expect=$(python3 -c '
import json,sys
m=json.load(open("MANIFEST.json"))
print(sum(1 for k,v in (m.get("planned") or {}).items()))' 2>/dev/null || echo 0)
echo "== 단계 $stage · $n_stage 잡 (묶음 전체 $n_total · 계획 $n_expect) =="
if [ "$n_stage" -eq 0 ]; then
  echo "이 단계의 잡이 0개다 — 분류 규칙과 job.json 을 확인하세요. 중단."; exit 2; fi
if [ "$n_total" != "$n_expect" ]; then
  echo "잡 폴더 $n_total ≠ 계획 $n_expect — 묶음이 온전하지 않다. 중단."; exit 2; fi
cat _stage_jobs.txt

# ⛔⛔ 회신 AS 해제조건 5 — **실행 직전에** 봉인한 절대경로를 다시 해시한다.
#   봉인 시점과 실행 시점 사이에 바이너리가 바뀌었을 수 있다.
python3 - "$VASP_EXE" "$VASP_LAUNCHER_KIND" "$VASP_WRAPPER" <<'PYEXE' || { echo "⛔ 실행파일이 봉인과 다릅니다 — 중단"; exit 2; }
import hashlib, json, os, sys
exe, kind, wrap = sys.argv[1], sys.argv[2], sys.argv[3]
h = hashlib.sha256(open(exe, "rb").read()).hexdigest()
try:
    seal = json.load(open("POTCAR_ROOT_SEAL.json", encoding="utf-8"))
except Exception as e:
    sys.exit("⛔ 봉인을 읽을 수 없다: %r" % e)
bad = []
if seal.get("vasp_executable") and os.path.realpath(seal["vasp_executable"]) != os.path.realpath(exe):
    bad.append("봉인 경로 %s ≠ 실행 경로 %s" % (seal["vasp_executable"], exe))
if seal.get("vasp_executable_sha256") != h:
    bad.append("봉인 해시 %s ≠ 지금 %s" % (str(seal.get("vasp_executable_sha256"))[:12], h[:12]))
# 🔴 회신 AV P0-2/Q5 — wrapper 도 봉인과 같은 파일이어야 한다. 봉인에 wrapper 가
#   없는데 KIND=wrapper 로 돌리는 것도 거부한다 (봉인 밖 실행 경로).
if kind == "wrapper":
    if not wrap:
        bad.append("KIND=wrapper 인데 VASP_WRAPPER 가 비었다")
    elif not seal.get("launcher_wrapper_sha256"):
        bad.append("봉인에 launcher_wrapper_sha256 가 없다 — wrapper 는 SEAL 때 "
                   "봉인된 것만 쓸 수 있다 (VASP_WRAPPER 를 주고 다시 봉인)")
    else:
        wh = hashlib.sha256(open(wrap, "rb").read()).hexdigest()
        if wh != seal["launcher_wrapper_sha256"]:
            bad.append("wrapper 해시 %s ≠ 봉인 %s"
                       % (wh[:12], seal["launcher_wrapper_sha256"][:12]))
if bad:
    print("⛔ 실행 직전 대조 실패:")
    for b in bad:
        print("   · " + b)
    sys.exit(1)
print("✓ 실행파일 = 봉인한 그 파일 (%s · %s)" % (exe, h[:12]))
PYEXE

# ⛔⛔ 회신 AS 해제조건 10 (2026-08-31) — 러너는 **직렬**인데 MANIFEST 는
#   `max_concurrency: 8` 이라고 적고 있었다. 비용 추정이 그 병렬도 가정 위에
#   서 있으므로 둘이 어긋나면 외주가 일정을 잘못 잡는다.
#   ⇒ 러너가 실제로 병렬로 돈다. 단 **의존성이 있는 잡은 나중 물결**로 민다:
#     canary(`*__nzmag`)는 `PARENT_GEOM` 이 가리키는 부모의 최종 기하를 받으므로
#     부모가 먼저 끝나야 한다.
#   `JOBS_PARALLEL` 로 조절한다 (기본 = MANIFEST 의 max_concurrency).
#   ⚠ $NPAR 은 **위 메모리 사전검사 앞에서 이미 정했다** — 가드가 그 값을 써야 하기
#     때문이다. 여기서 다시 계산하면 두 곳이 갈린다 (실제로 갈린 전례가 있다).
[ -n "${NPAR:-}" ] || { echo "⛔ 내부 오류: NPAR 이 안 정해졌다"; exit 3; }

# ══ 2026-09-21 — 다른 extraction 의 **완주 잡 승계** (CONTINUE_FROM) ══════════════════
#   mirae 실측 (v41): 같은 extraction 에서 1단계를 세 번 불러 7잡 완주 · 12잡 미실행. 새 판은
#   스크립트만 다르고 잡 입력은 바이트 동일한데, 완주 7잡(≈97 h)을 이어 쓸 길이 없었다:
#     (a) 옛 extraction 에 새 스크립트를 덮으면 census 의 files_sha256·봉인의 manifest_sha256 에 막힌다
#         (봉인은 바꾸지 않는다 — 그게 봉인이다).
#     (b) 새 extraction 에 완주 폴더를 **먼저** 복사하면 SEAL 이 "생산 산출물이 이미 있습니다" 로
#         최초 봉인을 거부한다 (AP #7 — 계산 뒤에 만든 봉인은 사전 승인이 아니다).
#   ⇒ 러너가 **봉인·census·실행파일 대조가 끝난 뒤** 승계한다. 그래서 봉인은 여전히 이 extraction 의
#     생산 전이고, 승계는 "같은 입력·같은 PP 트리·같은 실행파일로 이미 완주한 결과를 옮겨 온 것" 으로
#     CONTINUATION.json 에 기록된다 (반송 목록).
#   자격 — 전부 fail-closed (하나라도 어긋나면 **아무 잡도 옮기지 않고** 멈춘다):
#     ① CONTINUE_FROM = 이전 extraction 의 묶음 루트 **절대경로** (MANIFEST.json · POTCAR_ROOT_SEAL.json 존재)
#     ② SKIP_COMPLETE=1 이 같이 켜져 있다 (옮겨 온 잡은 아래 물결에서 "완주 증명" 으로 건너뛴다)
#     ③ 이전 봉인 == 지금 봉인: PP 원본 SHA(variant 전부) · VASP 실행파일 SHA · launcher 종류/SHA
#        (다르면 옮겨 온 receipt 가 판정에서 막힌다 — 그것을 90 h 뒤가 아니라 지금 잡는다)
#     ④ 잡마다: 이 번들이 실은 입력 전부(MANIFEST files_sha256 의 <잡>/… 항목)가 이전 extraction 에서
#        **바이트 동일** · 이전 MANIFEST 의 planned[잡] 동일 · 조립본 해시(POTCAR_PROVENANCE) 동일 ·
#        이전 static/POSCAR == 이 잡이 돌아야 할 기하(PARENT_GEOM 이면 부모 루트 POSCAR)
#     ⑤ 잡마다 완주 증명: 존재하는 모든 상이 General timing · receipt 의 _runner_start 정확히 하나
#   ⑤ 미달(0스텝 찌꺼기 · qdel 잔재)은 옮기지 않고 **여기서 새로 돈다**. ④ 위반은 전체 중단 —
#   입력이 다른 것은 다른 계산이다. 옮기는 것: receipt · _placement.tsv · 상 폴더의 파일 전부
#   (이미 있는 파일은 같은 내용이면 손대지 않고, 다르면 중단). POTCAR_PROVENANCE.json 은 **지금 것**을
#   둔다 (조립본 해시가 같음을 ④ 에서 확인했다 · allowlist 경로만 다를 수 있다).
#   ⛔ 이 승계가 못 하는 것: 이전 extraction 이 정직했는지는 증명하지 못한다 — 옮겨 온 receipt·
#     OUTCAR 는 남의 기계가 쓴 파일이고, 그 대조는 분석기(receipt 게이트·봉인 대조)가 반송 뒤에 한다.
if [ -n "${CONTINUE_FROM:-}" ]; then
  echo "== 완주 잡 승계: CONTINUE_FROM=$CONTINUE_FROM =="
  if [ "${SKIP_COMPLETE:-0}" != "1" ]; then
    echo "⛔ CONTINUE_FROM 은 SKIP_COMPLETE=1 과 **같이** 써야 합니다 — 옮겨 온 잡을 건너뛰는 자격 검사가"
    echo "   거기 있습니다. 둘 다 export 하고 다시 부르십시오. (아무 잡도 시작하지 않았습니다)"
    exit 2
  fi
  python3 - "$CONTINUE_FROM" _stage_jobs.txt "$stage" <<'PYCONT' || { echo "⛔ 승계 실패 — 중단 (아무 잡도 시작하지 않았습니다 · 자격 검사에서 막혔으면 아무 파일도 옮기지 않았고, 옮기는 중 막혔으면 위에 어디까지인지 적혀 있습니다)"; exit 2; }
import gzip, hashlib, json, os, shutil, sys, time
prev, stage_list, stage = sys.argv[1], sys.argv[2], sys.argv[3]
def sha(p):
    return hashlib.sha256(open(p, "rb").read()).hexdigest()
def die(m):
    print("⛔ " + m)
    sys.exit(1)
if not os.path.isabs(prev):
    die("CONTINUE_FROM 은 절대경로여야 합니다: %r" % prev)
prev = os.path.normpath(prev)
if not os.path.isdir(prev):
    die("CONTINUE_FROM 디렉터리가 없습니다: %s" % prev)
if os.path.realpath(prev) == os.path.realpath("."):
    die("CONTINUE_FROM 이 이 extraction 자신입니다 — 이전 extraction 의 루트를 주십시오")
for f in ("MANIFEST.json", "POTCAR_ROOT_SEAL.json"):
    if not os.path.isfile(os.path.join(prev, f)):
        die("이전 extraction 에 %s 가 없습니다 (묶음 **루트**를 가리켜야 합니다): %s" % (f, prev))
man = json.load(open("MANIFEST.json", encoding="utf-8"))
pman = json.load(open(os.path.join(prev, "MANIFEST.json"), encoding="utf-8"))
seal = json.load(open("POTCAR_ROOT_SEAL.json", encoding="utf-8"))
pseal = json.load(open(os.path.join(prev, "POTCAR_ROOT_SEAL.json"), encoding="utf-8"))
# ③ 같은 트리 · 같은 실행파일 · 같은 launcher
if not seal.get("source_sha256") or (pseal.get("source_sha256") or {}) != seal["source_sha256"]:
    die("이전 봉인의 PP 원본 SHA 가 지금 봉인과 다릅니다 — 다른 트리의 결과는 승계하지 않습니다")
for k in ("vasp_executable_sha256", "launcher_kind", "launcher_sha256", "launcher_wrapper_sha256"):
    if (pseal.get(k) or "") != (seal.get(k) or ""):
        die("이전 봉인의 %s 가 지금과 다릅니다 (이전 %s / 지금 %s) — 옮겨 온 receipt 가 판정에서 막히므로 승계하지 않습니다"
            % (k, str(pseal.get(k))[:12], str(seal.get(k))[:12]))
fh = man.get("files_sha256") or {}
pfh = pman.get("files_sha256") or {}
planned = man.get("planned") or {}
pplanned = pman.get("planned") or {}
pasm = pseal.get("assembled_sha256_by_job") or {}
stage_jobs = [l.strip() for l in open(stage_list, encoding="utf-8") if l.strip()]
plan, not_imported = [], []
for j in stage_jobs:
    pj = os.path.join(prev, j)
    if not os.path.isdir(pj):
        not_imported.append({"job": j, "why": "이전 extraction 에 폴더가 없다"}); continue
    phases = [ph for ph in ("pre", "relax", "static", "dense") if os.path.isdir(os.path.join(pj, ph))]
    # ⑤ 완주 증명 — 미달은 승계하지 않는다 (여기서 새로 돈다)
    why = None
    if "static" not in phases:
        why = "static 상 폴더가 없다"
    for ph in phases:
        if why:
            break
        oc, ocg = os.path.join(pj, ph, "OUTCAR"), os.path.join(pj, ph, "OUTCAR.gz")
        if os.path.isfile(oc) and os.path.isfile(ocg):
            die("%s/%s: OUTCAR 와 OUTCAR.gz 가 둘 다 있다 — 어느 쪽이 정본인지 판정 불가 (분석기도 막는다). 하나만 남기십시오" % (j, ph))
        if os.path.isfile(oc):
            txt = open(oc, "rb").read()
        elif os.path.isfile(ocg):
            txt = gzip.open(ocg).read()
        else:
            why = "%s/OUTCAR 가 없다 (0스텝 찌꺼기 · qdel 잔재)" % ph; break
        if b"General timing" not in txt:
            why = "%s/OUTCAR 가 General timing 으로 안 끝났다" % ph
    rp = os.path.join(pj, "EXECUTABLE_RECEIPT.tsv")
    if not why:
        if not os.path.isfile(rp):
            why = "EXECUTABLE_RECEIPT.tsv 가 없다"
        else:
            _ns = sum(1 for l in open(rp, encoding="utf-8", errors="replace") if "_runner_start" in l)
            if _ns != 1:
                why = "receipt 의 _runner_start 가 %d 개 (정확히 1 이어야 한다)" % _ns
    if why:
        not_imported.append({"job": j, "why": why}); continue
    # ④ 입력 동일성 — 위반은 **전체 중단**
    ins = sorted(k for k in fh if k.startswith(j + "/"))
    if not ins:
        die("%s: MANIFEST files_sha256 에 이 잡의 입력이 없다 — 대조 불가" % j)
    for rel in ins:
        pf = os.path.join(prev, rel)
        if not os.path.isfile(pf):
            die("%s: 이전 extraction 에 입력 %s 가 없다 — 승계하지 않고 중단" % (j, rel))
        if sha(pf) != fh[rel]:
            die("%s: 이전 extraction 의 %s 가 이 번들의 입력과 **다릅니다** — 다른 계산입니다. 승계하지 않고 중단" % (j, rel))
        if pfh.get(rel) != fh[rel]:
            die("%s: 이전 MANIFEST 의 files_sha256[%s] 가 이 번들과 다릅니다 — 다른 설계의 잡입니다" % (j, rel))
    if (pplanned.get(j) or {}) != (planned.get(j) or {}):
        die("%s: 이전 MANIFEST 의 planned 항목(phases·meta)이 이 번들과 다릅니다 — 승계하지 않고 중단" % j)
    pv, cv = os.path.join(pj, "POTCAR_PROVENANCE.json"), os.path.join(j, "POTCAR_PROVENANCE.json")
    for q in (pv, cv):
        if not os.path.isfile(q):
            die("%s: %s 가 없습니다 (조립본 대조 불가)" % (j, q))
    pa = str(json.load(open(pv, encoding="utf-8")).get("assembled_sha256") or "")
    ca = str(json.load(open(cv, encoding="utf-8")).get("assembled_sha256") or "")
    if not pa or pa != ca:
        die("%s: 조립본(POTCAR) 해시가 다릅니다 (이전 %s / 지금 %s) — 다른 POTCAR 로 돈 결과는 승계하지 않습니다" % (j, pa[:12], ca[:12]))
    if str(pasm.get(j) or "") != pa:
        die("%s: 이전 봉인의 assembled_sha256_by_job 이 이전 provenance 와 다릅니다 (%s / %s)" % (j, str(pasm.get(j))[:12], pa[:12]))
    # 실제로 돈 기하 == 이 잡이 돌아야 할 기하 (run_job.sh 와 같은 규칙: PARENT_GEOM 이면 부모 루트 POSCAR)
    pg = os.path.join(j, "PARENT_GEOM")
    if os.path.isfile(pg):
        tgt = os.path.normpath(os.path.join(j, open(pg, encoding="utf-8").read().strip()))
        want = os.path.join(tgt, "relax", "CONTCAR") if os.path.isdir(os.path.join(tgt, "relax")) else os.path.join(tgt, "POSCAR")
    else:
        want = os.path.join(j, "relax", "CONTCAR") if "relax" in phases else os.path.join(j, "POSCAR")
    sp = os.path.join(pj, "static", "POSCAR")
    if not os.path.isfile(sp):
        die("%s: 이전 static/POSCAR 가 없다 — 실제로 돈 기하를 확인할 수 없어 승계하지 않습니다" % j)
    if not os.path.isfile(want) or sha(sp) != sha(want):
        die("%s: 이전 static/POSCAR 가 이 잡의 기하(%s)와 다릅니다 — 다른 기하의 결과는 승계하지 않습니다" % (j, want))
    files = []
    for f in ("EXECUTABLE_RECEIPT.tsv", "_placement.tsv"):
        if os.path.isfile(os.path.join(pj, f)):
            files.append((os.path.join(pj, f), os.path.join(j, f)))
    for ph in phases:
        for fn in sorted(os.listdir(os.path.join(pj, ph))):
            src = os.path.join(pj, ph, fn)
            if os.path.isfile(src):
                files.append((src, os.path.join(j, ph, fn)))
    for src, dst in files:
        if os.path.exists(dst) and sha(src) != sha(dst):
            die("%s: 여기 이미 있는 %s 가 이전 산출물과 다릅니다 — 덮지 않고 중단 (폴더를 새로 푸십시오)" % (j, dst))
    plan.append((j, phases, ins, files, pa))
if not plan:
    if stage != "1":
        # 2단계에는 승계할 것이 없는 게 정상이다 (1단계 산출물은 이미 이 extraction 에 있다).
        # 셸에 CONTINUE_FROM 이 남아 있다고 2단계를 막으면 그게 새 헛돌이다 — 경고만 하고 진행한다.
        print("  ⚠ 단계 %s 에는 승계할 완주 잡이 없습니다 — 승계 없이 진행합니다 (CONTINUE_FROM 은 1단계용)" % stage)
        sys.exit(0)
    die("승계할 완주 잡이 하나도 없습니다 — CONTINUE_FROM 이 이전 extraction 의 **묶음 루트**인지, 그 안에 완주 잡이 있는지 확인하십시오. 미승계 사유: %s"
        % [(x["job"], x["why"]) for x in not_imported[:6]])
# ── 여기까지 한 건도 옮기지 않았다. 전부 통과했으므로 이제 옮긴다 ──
imported = []
for j, phases, ins, files, pa in plan:
    rec = {}
    for src, dst in files:
        if os.path.exists(dst):
            rec[dst] = {"sha256": sha(dst), "action": "already_identical"}; continue
        os.makedirs(os.path.dirname(dst), exist_ok=True)
        try:
            try:
                os.link(src, dst); act = "hardlink"      # 같은 파일시스템이면 즉시 (WAVECAR·CHGCAR 가 GB 급이다)
            except OSError:
                shutil.copy2(src, dst); act = "copy"
        except Exception as e:                             # noqa: BLE001
            # ⚠ 여기부터는 "아무것도 안 옮겼다" 가 아니다 — 어디까지 옮겼는지 적고 멈춘다
            die("%s: 옮기는 중 실패 (%s → %s: %r) — **이 잡까지 일부 파일이 이미 옮겨졌습니다.** 폴더를 새로 풀고 다시 하십시오" % (j, src, dst, e))
        rec[dst] = {"sha256": sha(dst), "action": act}
    imported.append({"job": j, "phases": phases, "inputs_verified_identical": ins,
                     "assembled_potcar_sha256": pa, "files": rec})
    print("  ✓ 승계 %s (상 %s · 파일 %d · 입력 %d 동일 확인)" % (j, "/".join(phases), len(rec), len(ins)))
for x in not_imported:
    print("  · 승계 안 함 %s — %s" % (x["job"], x["why"]))
def _rd(p):
    try:
        return open(p, encoding="utf-8").read().split()[0]
    except Exception:
        return None
out = {
    "schema": "continuation/v1",
    "at_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
    "stage": stage,
    "from": {"path": prev, "bundle_label": pman.get("bundle_label"),
             "manifest_sha256": sha(os.path.join(prev, "MANIFEST.json")),
             "zip_sha256_txt": _rd(os.path.join(prev, "ZIP_SHA256.txt")),
             "seal_sha256": sha(os.path.join(prev, "POTCAR_ROOT_SEAL.json")),
             "seal_sealed_at_utc": pseal.get("sealed_at_utc")},
    "this": {"bundle_label": man.get("bundle_label"), "manifest_sha256": sha("MANIFEST.json"),
             "zip_sha256_txt": _rd("ZIP_SHA256.txt"), "seal_sealed_at_utc": seal.get("sealed_at_utc")},
    "seal_fields_equal": ["source_sha256", "vasp_executable_sha256", "launcher_kind", "launcher_sha256"],
    "imported": imported,
    "not_imported": not_imported,
    "⛔_이_기록이_보증하지_않는_것": [
        "이전 extraction 의 정직성 (옮겨 온 receipt·OUTCAR 는 남의 기계가 쓴 파일 — 분석기가 반송 뒤 봉인과 대조한다)",
        "옮겨 온 결과의 물리적 타당성 (SCF 수렴·자기상태는 분석기 게이트의 몫)"],
}
if os.path.isfile("CONTINUATION.json"):
    try:
        out["previous_record"] = json.load(open("CONTINUATION.json", encoding="utf-8"))
    except Exception:
        out["previous_record"] = "unreadable"
json.dump(out, open("CONTINUATION.json", "w", encoding="utf-8"), indent=1, ensure_ascii=False)
print("  → CONTINUATION.json (승계 %d 잡 · 미승계 %d 잡 · 이전 MANIFEST %s)" % (len(imported), len(not_imported), out["from"]["manifest_sha256"][:12]))
PYCONT
fi

: > _wave1.txt; : > _wave2.txt
while read -r j; do
  [ -n "$j" ] || continue
  if [ -f "$j/PARENT_GEOM" ]; then echo "$j" >> _wave2.txt; else echo "$j" >> _wave1.txt; fi
done < _stage_jobs.txt
n1=$(grep -c . _wave1.txt || true); n2=$(grep -c . _wave2.txt || true)
echo "== 병렬도 $NPAR · 1물결 $n1 잡 · 2물결(부모 의존) $n2 잡 =="

# ⛔⛔ 2026-09-21 (mirae 실측) — **완주한 잡의 거부가 실패로 집계돼 2물결이 영영 안 열렸다.**
#   거부도 `exit 1`, 진짜 실패도 `exit 1` 이라 xargs 가 둘을 못 갈랐다. 같은 extraction 에서
#   1단계를 다시 부르면 이미 끝난 1물결 잡이 전부 "실패" 가 되고, `PARENT_GEOM` 을 가진
#   2물결(nzmag canary 2잡)이 **구조적으로** 시작될 수 없었다 — 우회로도 없었다
#   (ALLOW_RESUME 폐지 · PLANNED_CONTINUATION 은 DENSE_PLAN.json 요구 · 잡 부분선택 없음).
#   ⇒ 자식이 `ok|skip|fail` 을 **파일 표지**로 남기고, 부모가 **fail 만** 센다.
#   ⚠ 표지를 못 남긴 잡은 **실패로 센다** (fail-closed — 자식이 죽은 경우).
WAVE_STAT="$PWD/_wave_status"
rm -rf "$WAVE_STAT"; mkdir -p "$WAVE_STAT"
export WAVE_STAT
if [ "${SKIP_COMPLETE:-0}" = "1" ]; then
  echo "⚠ SKIP_COMPLETE=1 — **완주가 증명된** 잡만 건너뜁니다 (1회용 계약의 명시적 예외)."
  echo "   자격 둘을 다 채워야 합니다: ① 존재하는 모든 상이 'General timing' 으로 끝났다"
  echo "                              ② receipt 에 '_runner_start' 가 정확히 하나"
  echo "   ⛔ '산출물이 있다' 는 자격이 아닙니다 — 0스텝 찌꺼기도 파일을 남깁니다."
  echo "   ⛔ 자격 미달이면 건너뛰지 않고 **실패로 셉니다**."
  : > _SKIP_COMPLETE_USED
fi

run_wave() {   # $1 = 목록 파일
  [ -s "$1" ] || return 0
  WAVE_DIR="$WAVE_STAT/$(basename "$1" .txt)"
  rm -rf "$WAVE_DIR"; mkdir -p "$WAVE_DIR"; export WAVE_DIR
  xargs -a "$1" -I{} -P "$NPAR" sh -c '
    j="$1"
    _mk="$WAVE_DIR/$(echo "$j" | tr "/" "_")"
    [ -f "$j/run_job.sh" ] || { echo "없음: $j"; echo fail > "$_mk"; exit 1; }
    # 🔴 회신 AT P0-5 · AV P0-2 — receipt 는 **헤더행(러너) + 상별 행(run_job.sh)**.
    #   종전엔 러너가 잡당 한 행만 썼고 분석기가 읽지 않았다. 이제 run_job.sh 가
    #   상 직전마다 해시를 재서 append 하고, 분석기가 **필수 반송물**로 읽는다.
    #   열 9개: ts phase exe_sha256 exe kind nproc launcher launcher_sha potcar_sha
    #   (AY P0-1 · BE P1 — 헤더행의 potcar_sha 는 "-", 상별 행은 run_job.sh 가 채운다)
    case "$VASP_LAUNCHER_KIND" in
      mpirun|mpiexec|srun) _hl="$LAUNCHER_BIN" ;;
      wrapper)             _hl="$VASP_WRAPPER" ;;
      *)                   _hl="" ;;
    esac
    if [ -n "$_hl" ]; then _hlh=$(sha256sum "$_hl" | cut -d" " -f1); else _hl="-"; _hlh="-"; fi
    # ⛔⛔ 회신 AZ P1 (2026-09-01) — **재개가 영수증을 파괴했다.**
    #   종전엔 언제나 `> receipt` 로 **덮어썼다**. `ALLOW_RESUME=1` 이면 새 헤더만
    #   남고 run_job.sh 는 완료된 상을 건너뛰므로, 이미 돈 상의 행이 통째로 사라져
    #   분석기가 `RECEIPT_PHASE_MISSING` 을 냈다 — 정직하게 이어 돌린 사람이
    #   "러너 밖에서 돌렸다" 는 판정을 받았다.
    #   ⇒ 재개는 **이어 쓰고** 표지를 `_runner_resume` 으로 구분한다.
    #     `_runner_start` 는 여전히 정확히 하나다 (첫 실행에만 찍힌다).
    # ⛔⛔ 회신 BA 해제조건 7 (2026-09-02) — **재개를 폐지한다.**
    #   AZ P1 에서 재개를 “이어 쓰기” 로 고쳤는데, 그 계약이 실제로는 **항상 막혔다**:
    #   `_runner_resume` 자체가 `RECEIPT_RESUMED` 게이트가 되고, 중단된 상을 다시
    #   돌리면 같은 phase 행이 둘이라 `RECEIPT_PHASE_DUPLICATE` 도 난다.
    #   제대로 지원하려면 attempt ID·성공상태·supersedes 가 필요한데, 이 묶음의
    #   질문에 비해 과하다. ⇒ **한 번에 완주하거나, 새 번들로 다시 시작한다.**
    if [ "${ALLOW_RESUME:-0}" = "1" ]; then
      echo "⛔ ALLOW_RESUME 은 폐지됐습니다 (회신 BA 해제조건 7)."
      echo "   종전 재개 계약은 영수증 게이트(RECEIPT_RESUMED · PHASE_DUPLICATE)에"
      echo "   **언제나 걸려** 통과할 수 없었습니다 — 있으나 마나가 아니라 함정이었습니다."
      echo "   중단된 실행은 폴더를 새로 풀고 처음부터 돌려 주십시오."
      exit 2
    fi
    # ⛔⛔ 회신 BD P1 (2026-09-02) — **receipt 를 먼저 자르고 나서 거부했다.**
    #   Stage 1 을 실수로 다시 부르면 run_job.sh 가 "이미 산출물이 있다" 로 거부하는데,
    #   그 **전에** 러너가 정상 receipt 를 헤더 한 줄로 덮어써 증거를 망가뜨렸다.
    #   ⇒ 기존 산출물 검사를 **쓰기보다 앞에** 둔다. 거부하면 아무것도 손대지 않는다.
    if [ "${PLANNED_CONTINUATION:-0}" != "1" ]; then
      _stale_pre=""
      for _ph in pre relax static dense; do
        [ -d "$j/$_ph" ] || continue
        for _f in OUTCAR vasprun.xml OSZICAR CONTCAR WAVECAR CHGCAR; do
          [ -e "$j/$_ph/$_f" ] && _stale_pre="$_stale_pre $_ph/$_f"
        done
      done
      if [ -n "$_stale_pre" ]; then
        # ⭐ 2026-09-21 — **완주가 증명되면** 거부가 아니라 건너뛰기다. 증명은 둘 다 필요하다:
        #   ① 존재하는 모든 상이 `General timing` 으로 끝났다  ② receipt `_runner_start` 정확히 하나
        #   ⛔ "파일이 있다" 는 증명이 아니다 — 0스텝 찌꺼기도 OSZICAR·CONTCAR 를 남긴다
        #      (실측: mirae 3잡이 qdel 직후 그런 찌꺼기를 남겼다).
        if [ "${SKIP_COMPLETE:-0}" = "1" ]; then
          _cpl=1
          [ -d "$j/static" ] || _cpl=0
          for _ph in pre relax static dense; do
            [ -d "$j/$_ph" ] || continue
            if [ -f "$j/$_ph/OUTCAR" ]; then
              grep -aq "General timing" "$j/$_ph/OUTCAR" || _cpl=0
            elif [ -f "$j/$_ph/OUTCAR.gz" ]; then
              gzip -cd "$j/$_ph/OUTCAR.gz" 2>/dev/null | grep -aq "General timing" || _cpl=0
            else
              _cpl=0
            fi
          done
          _ns=$(grep -c "_runner_start" "$j/EXECUTABLE_RECEIPT.tsv" 2>/dev/null || true)
          [ "$_ns" = "1" ] || _cpl=0
          if [ "$_cpl" = 1 ]; then
            echo "  ✓ $j 이미 완주 — 건너뜁니다 (SKIP_COMPLETE · receipt 손대지 않음)"
            echo skip > "$_mk"; exit 0
          fi
          echo "⛔ $j 에 산출물이 있는데 **완주가 증명되지 않습니다**:$_stale_pre"
          echo "   (상이 General timing 으로 안 끝났거나 receipt 의 _runner_start 가 $_ns 개)"
          echo "   → 건너뛰지 않고 **실패로 셉니다.** 폴더를 새로 풀고 처음부터 돌려 주십시오."
          echo fail > "$_mk"; exit 1
        fi
        echo "⛔ $j 에 이미 산출물이 있습니다:$_stale_pre"
        echo "   이 잡은 **1회용**입니다 — 폴더를 새로 풀고 처음부터 돌려 주십시오."
        echo "   ⚠ receipt 는 **손대지 않았습니다** (회신 BD P1: 종전엔 먼저 덮어쓴 뒤"
        echo "      거부해 증거가 망가졌습니다)."
        echo "   ⚠ 완주한 잡을 건너뛰려면 SKIP_COMPLETE=1 로 부르십시오 (자격 검사 있음)."
        echo fail > "$_mk"; exit 1
      fi
    fi
    # 계획된 이어달리기(dense 승격)는 **새 상**을 여는 것이라 성격이 다르다.
    if [ "${PLANNED_CONTINUATION:-0}" = "1" ] && [ -s "$j/EXECUTABLE_RECEIPT.tsv" ]; then
      _rtag=_runner_continue; _rop=append
    else
      _rtag=_runner_start;  _rop=truncate
    fi
    if [ "$_rop" = append ]; then
      printf "%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\n" \
        "$(date -u +%Y-%m-%dT%H:%M:%SZ)" "$_rtag" \
        "$(sha256sum "$VASP_EXE" | cut -d" " -f1)" \
        "$VASP_EXE" "$VASP_LAUNCHER_KIND" "$VASP_NPROC" \
        "$_hl" "$_hlh" "-" >> "$j/EXECUTABLE_RECEIPT.tsv"
    else
      printf "%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\n" \
        "$(date -u +%Y-%m-%dT%H:%M:%SZ)" "$_rtag" \
        "$(sha256sum "$VASP_EXE" | cut -d" " -f1)" \
        "$VASP_EXE" "$VASP_LAUNCHER_KIND" "$VASP_NPROC" \
        "$_hl" "$_hlh" "-" > "$j/EXECUTABLE_RECEIPT.tsv"
    fi
    echo "=== $j 시작 ==="
    ( cd "$j" && bash run_job.sh ) || { echo "⛔ $j 실패"; echo fail > "$_mk"; exit 1; }
    echo ok > "$_mk"
    echo "=== $j 완료 ==="
  ' _ {}
  #: 부모 집계는 **표지로** 한다 — xargs 종료코드는 "거부" 와 "실패" 를 못 가른다.
  _njob=$(grep -c . "$1" || true)
  _nmk=$(ls -1 "$WAVE_DIR" 2>/dev/null | wc -l | tr -d " ")
  _nfail=$(grep -lx fail "$WAVE_DIR"/* 2>/dev/null | wc -l | tr -d " ")
  _nskip=$(grep -lx skip "$WAVE_DIR"/* 2>/dev/null | wc -l | tr -d " ")
  echo "   [$1] 잡 $_njob · 표지 $_nmk · 건너뜀 $_nskip · 실패 $_nfail"
  if [ "$_nmk" != "$_njob" ]; then
    echo "⛔ 상태 표지가 $_nmk/$_njob 뿐입니다 — 표지를 못 남긴 잡은 **실패로 셉니다** (fail-closed)"
    return 1
  fi
  [ "$_nfail" = 0 ] || return 1
  return 0
}
fail=0
run_wave _wave1.txt || fail=1
if [ "$fail" = 0 ]; then
  run_wave _wave2.txt || fail=1
else
  echo "⛔ 1물결에 **실패**가 있어 2물결(부모 의존 잡)을 시작하지 않습니다"
  echo "   ⚠ 이미 완주한 잡은 실패가 아닙니다 — SKIP_COMPLETE=1 로 다시 부르면 건너뜁니다"
  echo "      (자격: 모든 상이 General timing · receipt _runner_start 정확히 하나)"
fi

if [ "$stage" = 1 ]; then
  [ "$fail" = 0 ] || { echo "1단계에 실패한 잡이 있다 — 판정하지 않는다."; exit 2; }
  echo "== 1단계 판정 =="
  python3 analyze_results.py . --gate vacconv || {
    echo "1단계 판정이 막혔다 — 2단계를 돌리지 않는다."; exit 2; }
  echo "1단계 통과 — 2단계는 'bash run_staged.sh 2'"
else
  # ⛔ 회신 AP #9 — 2단계 뒤 **최종 분석**까지가 러너의 일이다.
  # 🔴 회신 BF P1 (2026-09-03) — 2단계에 실패한 잡이 있으면 **분석하지 않는다.** 종전엔 fail=1
  #   이어도 그대로 분석해 rc 3 을 "계산은 완주했으나…" 로 출력할 수 있었다. 완주가 아니다.
  [ "$fail" = 0 ] || { echo "⛔ 2단계에 실패한 잡이 있다 — 완주가 아니므로 판정하지 않는다 (rc 2)."; exit 2; }
  # 완주 census — 이 단계의 모든 잡이 반송 receipt(_runner_start) 를 남겼는가
  _miss_rc=0
  while read -r j; do
    [ -n "$j" ] || continue
    grep -q "_runner_start" "$j/EXECUTABLE_RECEIPT.tsv" 2>/dev/null || { echo "⛔ $j: 실행 receipt 가 없다 — 이 잡은 러너로 완주하지 않았다"; _miss_rc=1; }
  done < _stage_jobs.txt
  [ "$_miss_rc" = 0 ] || { echo "⛔ 완주하지 않은 잡이 있다 — 판정하지 않는다 (rc 2)."; exit 2; }
  echo "== 최종 판정 (2단계 전 잡 완주 확인됨) =="
  # 🔴 회신 BE P1 — 분석기 rc 3 (완주했으나 원고 인용 불가·탐색용) 을 계산 실패 2 와 가른다.
  python3 analyze_results.py .; _frc=$?
  case "$_frc" in
    0) ;;
    3) echo "⚠ 계산은 완주했으나 **원고 인용 자격 없음** (탐색용 · manuscript_citable=false)"
       echo "   — 종료코드 3 (rc 2 = 판정 실패와 구분 · 회신 BE P1). RESULTS.json 은 그대로 보내십시오."
       exit 3 ;;
    *) echo "최종 판정 미통과 (rc=$_frc)"; exit 2 ;;
  esac
fi
exit $fail

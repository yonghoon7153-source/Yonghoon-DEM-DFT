#!/usr/bin/env python3
"""원장 넘김 흉내 (v2.1 · 내부 반박 리뷰 P3-6 고침의 확인) — 명령 문서 §3-1b (5) 의 sh 블록 줄을 **그대로** 읽어 가짜 홈 둘 (같은 컨테이너) 에서 돌린다.
리뷰 repro/k_relay/relay_sim.py (11-17) 와 같은 꼴 · σ · 킷 · 러너 없음 · 사슬 = 그 트리의 scripts (원장 --init · ledger_append · ledger_history_problem).

argv: <봉인 꼴 트리 (scripts · docs)> <원장 --init 계획 (결과 전 넷 채운 고정물 · 시험 값 · 등록 숫자 아님)> <일할 빈 자리 (없어야)>
  ① 정상 A→B (clone) → B 항목 → B→A (세워 둔 자리에서 먼저 pull --ff-only 뒤 되살림) — 받는 쪽마다 RECV_OK · HEAD = 넘김 기록 · 원장 역사 문제 None
  ② 받는 동안 그 기계의 사슬이 덧붙이려 하면 (pull 전) = 원장 자리 ca1_ledger 가 없다 → 못 쓴다 · 그 뒤 RECV_OK (v2 꼴의 창 = mv 뒤 pull 전 덧붙임 → ff 실패 → 블록 rc 0 이 없다)
  ③ 세워 둔 자리가 받은 묶음과 갈라졌으면 (손 커밋 흉내) = pull --ff-only 실패 → 되살림 없음 → RECV_OK 없음 (멈춤 · 사람)
GIT_DIR · GIT_WORK_TREE · GIT_INDEX_FILE 은 쓰지 않는다 (환경의 GIT_* 를 지운 셸 · git -C 만)."""
import os
import re
import shutil
import subprocess
import sys

TREE, PLAN, W = sys.argv[1:4]
assert not os.path.exists(W), W
sys.path.insert(0, os.path.join(TREE, 'scripts'))
import rint_r_chain as R  # noqa: E402

doc = open(os.path.join(TREE, 'docs/reviews/rint2_kgy_commands_20261020.md'), encoding='utf-8').read().split('\n')
a = next(i for i, ln in enumerate(doc) if ln.startswith('### (5) 원장 넘김'))
o = next(i for i in range(a, len(doc)) if doc[i].strip() == '```sh')
c = next(i for i in range(o + 1, len(doc)) if doc[i].strip() == '```')
blk = doc[o + 1:c]
r0 = next(i for i, ln in enumerate(blk) if ln.startswith('# 받는 쪽'))
SEND = '\n'.join(ln for ln in blk[1:r0] if not ln.startswith('#'))
RECV = '\n'.join(ln for ln in blk[r0 + 1:] if not ln.startswith('#'))
print(f'# (5) 블록 = 명령 문서 {o + 2}–{c} 줄 · 보낸 쪽 {len(SEND.splitlines())} 줄 · 받는 쪽 {len(RECV.splitlines())} 줄 (주석 뺌 · 글 그대로)')
ENV = {k: v for k, v in os.environ.items() if not k.startswith('GIT_')}
H = {m: os.path.join(W, m) for m in ('A', 'B')}
for h in H.values():
    os.makedirs(os.path.join(h, 'sdcp', 'ca1_relay'))


def sh(m, script):
    r = subprocess.run(['bash', '-c', script], env=dict(ENV, HOME=H[m]), capture_output=True, text=True)
    return r.returncode, r.stdout.strip(), r.stderr.strip()


def led(m):
    return os.path.join(H[m], 'sdcp', 'ca1_ledger')


def entry(m, n, target, machine):
    st = R.ledger_parse(R.ledger_now(led(m))[1])
    e = {'kind': 'entry', 'n': n, 'target': target, 'machine': machine, 'resume_of': None, 'plan_sha256': st['header']['plan_sha256'],
         'code_key_sha256': '0' * 64, 'env': {}, 'bed': {}, 'utc': '2026-11-17T00:00:00Z'}
    return R.ledger_append(led(m), e, f'sim entry {n}')


def send(frm, to, x, y):
    rc, out, err = sh(frm, SEND.replace('FROM=kgy; TO=gabia', f'FROM={x}; TO={y}'))
    lines = out.split('\n')
    head, T = lines[0], lines[2]
    shutil.copy2(os.path.join(H[frm], 'sdcp', 'ca1_relay', f'{T}_{x}_to_{y}.bundle'), os.path.join(H[to], 'sdcp', 'ca1_relay'))
    return rc, head, T, out.endswith('PARKED_OK')


def recv(to, x, y, T, br, head, pre=None):
    s = (RECV.replace('<넘김 기록 시각>', T).replace('<원장 가지>', br).replace('<넘김 기록의 원장 끝 커밋>', head)
         .replace('FROM=kgy; TO=gabia', f'FROM={x}; TO={y}'))
    if pre:     # 받는 블록의 되살림 줄 바로 앞에 그 기계 사슬의 덧붙임 흉내를 끼운다 (실패해도 블록은 이어간다 = 다른 프로세스)
        s = s.replace('if [ -d ca1_ledger.parked ]', f'( {pre} ) >/dev/null 2>&1 && echo HOOK_WROTE || echo HOOK_COULD_NOT_WRITE\nif [ -d ca1_ledger.parked ]', 1)
    return sh(to, s)


out = []
os.makedirs(led('A'))
subprocess.run(['git', '-C', led('A'), 'init', '-q'], env=ENV, check=True)
r = subprocess.run([sys.executable, '-I', os.path.join(TREE, 'scripts', 'rint_r_chain.py'), '--stage', 'ledger', '--ledger', led('A'), '--init',
                    '--plan', PLAN], env=dict(ENV, HOME=H['A']), capture_output=True, text=True)
out.append(f'init rc {r.returncode} · {r.stdout.strip()[:60]}')
br = subprocess.run(['git', '-C', led('A'), 'symbolic-ref', '--short', 'HEAD'], env=ENV, capture_output=True, text=True).stdout.strip()
ok = r.returncode == 0
rc, h1, T1, pk = send('A', 'B', 'kgy', 'gabia')
rc2, o2, e2 = recv('B', 'kgy', 'gabia', T1, br, h1)
out.append(f'① A→B: 보냄 rc {rc} PARKED_OK {pk} · 받음 rc {rc2} RECV_OK {o2.endswith("RECV_OK")}')
ok &= pk and o2.endswith('RECV_OK')
h2 = entry('B', 1, 'ladder:P1', 'gabia')
rc, h2s, T2, pk = send('B', 'A', 'gabia', 'kgy')
rc3, o3, e3 = recv('A', 'gabia', 'kgy', T2, br, h2s)
prob = R.ledger_history_problem(led('A'), h2s) if hasattr(R, 'ledger_history_problem') else '?'
out.append(f'① B→A (세워 둔 자리에서 pull 뒤 되살림): 보냄 PARKED_OK {pk} · 받음 rc {rc3} RECV_OK {o3.endswith("RECV_OK")} · HEAD = B 항목 {h2s == h2} · 원장 역사 문제 {prob}')
ok &= pk and o3.endswith('RECV_OK') and h2s == h2 and prob is None
# ② 받는 동안 사슬 덧붙임 시도
rc, h3, T3, pk = send('A', 'B', 'kgy', 'gabia')
rc4, o4, e4 = recv('B', 'kgy', 'gabia', T3, br, h3)
h4 = entry('B', 2, 'ladder:P0', 'gabia')
rc, h4s, T4, pk = send('B', 'A', 'gabia', 'kgy')
hook = (f"{sys.executable} -I -c 'import sys; sys.path.insert(0, \"{os.path.join(TREE, 'scripts')}\"); import rint_r_chain as R; "
        f"st = R.ledger_parse(R.ledger_now(\"{led('A')}\")[1]); R.ledger_append(\"{led('A')}\", dict(kind=\"entry\", n=len(st[\"entries\"]) + 1, "
        f"target=\"unit:P0_c0_R_j0\", machine=\"kgy\", resume_of=None, plan_sha256=st[\"header\"][\"plan_sha256\"], code_key_sha256=\"0\"*64, env={{}}, bed={{}}, "
        f"utc=\"2026-11-17T00:00:01Z\"), \"sim chain write while receiving\")'")
rc5, o5, e5 = recv('A', 'gabia', 'kgy', T4, br, h4s, pre=hook)
out.append(f'② B→A 받는 동안 사슬 덧붙임: {"HOOK_COULD_NOT_WRITE" if "HOOK_COULD_NOT_WRITE" in o5 else "HOOK_WROTE"} (원장 자리 없음) · 받음 rc {rc5} '
           f'RECV_OK {o5.endswith("RECV_OK")} · HEAD = 넘김 기록 {subprocess.run(["git", "-C", led("A"), "rev-parse", "HEAD"], env=ENV, capture_output=True, text=True).stdout.strip() == h4s}')
ok &= 'HOOK_COULD_NOT_WRITE' in o5 and o5.endswith('RECV_OK')
# ③ 갈라진 세워 둔 자리 (손 커밋 흉내) → ff 실패 → RECV_OK 없음
rc, h5, T5, pk = send('A', 'B', 'kgy', 'gabia')
recv('B', 'kgy', 'gabia', T5, br, h5)
pa = os.path.join(H['A'], 'sdcp', 'ca1_ledger.parked')
subprocess.run(['git', '-C', pa, '-c', 'user.name=sim', '-c', 'user.email=sim@invalid', 'commit', '-q', '--allow-empty', '-m', 'hand commit (diverge)'], env=ENV, check=True)
entry('B', 3, 'unit:P1_c0_R_j_lo', 'gabia')
rc, h6, T6, pk = send('B', 'A', 'gabia', 'kgy')
rc7, o7, e7 = recv('A', 'gabia', 'kgy', T6, br, h6)
out.append(f'③ 갈라진 세워 둔 자리 → 받음 rc {rc7} · RECV_OK {o7.endswith("RECV_OK")} · ca1_ledger 있음 {os.path.isdir(led("A"))} · .parked 남음 {os.path.isdir(pa)} · '
           f'git {(e7.splitlines() or [""])[0][:70]!r}')
ok &= (not o7.endswith('RECV_OK')) and os.path.isdir(pa) and not os.path.isdir(led('A'))
for ln in out:
    print(ln.replace(W, '<일 자리>'))
print('결과', 'OK' if ok else 'NOT OK')
shutil.rmtree(W, ignore_errors=True)
sys.exit(0 if ok else 1)

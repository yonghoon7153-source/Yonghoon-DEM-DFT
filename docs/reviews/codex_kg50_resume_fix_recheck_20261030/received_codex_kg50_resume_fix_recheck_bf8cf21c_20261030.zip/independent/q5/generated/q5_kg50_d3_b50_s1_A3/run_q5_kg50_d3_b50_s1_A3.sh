#!/bin/bash
# 50kg Q5 가지 A3 (hit · SLURM 없음 · make_se_size_decks.hit_command 꼴) · NP 1 (Q5) · scripts/kg50_q5_branches.py 생성
# 체크포인트 복사 · sha256 (ckpt_sha256.txt) 뒤에만 실행
cd $HOME/simulation/q5_kg50_d3_b50_s1_A3 && setsid nohup mpirun --oversubscribe --bind-to none -np 1 $HOME/LIGGGHTS-PUBLIC/src/lmp_auto -in input_q5_kg50_d3_b50_s1_A3.liggghts > log_q5_kg50_d3_b50_s1_A3_v1.out 2>&1 < /dev/null &

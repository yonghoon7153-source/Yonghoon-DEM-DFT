#!/usr/bin/env python3
"""항목마다 '같은 논문일 수 있는' 정본 카드 후보를 뽑는다 (확정은 사람이 카드 머리를 보고).

python3 -I card_candidates.py <items.tsv> <cards_dir> <out.tsv>
후보 근거 셋:
  doi   = 항목 서지의 DOI 가 카드 앞 60 줄에 있음
  num   = 항목 서지의 4 자리 이상 숫자 (해 제외 · 권쪽 · 논문 번호) 가 카드 앞 60 줄에 있음 (같은 줄에 2 개 이상이면 강함)
  name  = 카드 파일 이름이 제1 저자 성 + 해 로 시작
"""
import os
import re
import sys
import unicodedata

items_p, cdir, out = sys.argv[1:4]


def fold(s):
    return "".join(c for c in unicodedata.normalize("NFKD", s) if not unicodedata.combining(c)).lower()


cards = {}
for f in sorted(os.listdir(cdir)):
    if not f.endswith(".md") or f.startswith("_"):
        continue
    with open(os.path.join(cdir, f), encoding="utf-8", errors="replace") as fh:
        head = [next(fh, "") for _ in range(60)]
    cards[f[:-3]] = fold("".join(head))

rows = [l.rstrip("\n").split("\t") for l in open(items_p, encoding="utf-8")][1:]
YEAR = re.compile(r"^(19[0-9]\d|20[0-3]\d)$")
with open(out, "w", encoding="utf-8") as fo:
    fo.write("idx\tline\tbatch\tkind\tcard\tevidence\n")
    for idx, line, batch, bib, why, check in rows:
        fb = fold(bib)
        dois = re.findall(r"10\.\d{4,9}/[^\s,;)]+", fb)
        dois = [d.rstrip(".") for d in dois]
        nums = [n for n in re.findall(r"\d{4,}", fb) if not YEAR.match(n)]
        # 이름 + 해
        b = re.sub(r"^\s*(\[[^\]]*\]|\(\d+\)|\d+\.)\s*", "", bib).strip()
        tok = re.split(r"[,;:]", b)[0].strip()
        words = [w for w in re.split(r"\s+", tok) if w]
        sur = ""
        if words:
            if len(words) > 1 and all(re.fullmatch(r"[A-Z]\.(-?[A-Z]\.)?|[A-Z]\.-[A-Z]\.", w) for w in words[:-1]):
                sur = words[-1]
            else:
                sur = words[0]
        sur = re.sub(r"[^a-z]", "", fold(sur))
        yrs = re.findall(r"\b(19[0-9]\d|20[0-3]\d)\b", bib)
        found = {}
        for slug, txt in cards.items():
            ev = []
            for d in dois:
                if d and d in txt:
                    ev.append("doi:" + d)
            hit = [n for n in nums if n in txt]
            if hit:
                ev.append("num:" + "+".join(hit))
            if sur and any(slug.startswith(sur + y) for y in yrs):
                ev.append("name")
            if ev:
                # 숫자 하나만 맞은 것은 약함 — 두 개 이상이거나 doi · name 이 있을 때만 적는다
                strong = any(e.startswith("doi") for e in ev) or ("name" in ev) or (hit and len(hit) >= 2)
                if strong or (hit and len(hit[0]) >= 5):
                    found[slug] = ";".join(ev)
        for slug, ev in found.items():
            fo.write(f"{idx}\t{line}\t{batch}\tcand\t{slug}\t{ev}\n")
print("done")

# VASP 계산 요청 — LiNiO₂(104) 위 분자 조각 단일점

바쁘신 중에 부탁드려 죄송합니다. **VASP 실행 19회**입니다
(static 19). 이 밖에 봉인 프로브(단계마다 1회)와 선택 attestation(1회)이 VASP 를 인자 없이
잠깐 기동합니다 — 생산 계산이 아니라 버전 확인입니다.
슬랩·분자 **전 잡이 단일점**입니다 — 구조 최적화는 저희가 MLIP 으로
끝냈고, 이 묶음에는 `relax/` 폴더가 하나도 없습니다 (기체 기준계 포함).

## ⛔ 시작 전에 확인·회신해 주실 것 — 이 답을 저희가 받은 뒤에 시작해 주십시오

이 묶음은 ZIP 을 함께 드리지만, **아래 다섯 가지 답을 저희가 받기 전에는 `run_staged.sh` 를 시작하지 말아 주십시오.**
답에 따라 코어 수 · 동시 잡 수 · walltime 계획을 다시 계산해 드려야 할 수 있고, 그때는 지금 숫자
(단계당 할당 156 h · 약 4.46일)를 그대로 옮기지 않고 새 번들을 드립니다.

1. **노드 확보** — 잡 하나를 노드 **4 개**에 펼쳐 동시 **4잡**, 한 할당에서 총 **16 노드**를 동시에
   잡을 수 있습니까? 안 되면 몇 노드까지 가능합니까?
   (한 노드에 몰면 최악 잡이 노드당 292.2 GB 를 요구하는 것으로 저희 모형에서 나옵니다 — 292/73 GB 는
   실측이 아니라 **모형값**이며, 예약 요구량이나 안전 보장이 아닙니다.)
2. **노드별 자원 (단위까지)** — 잡당 192 랭크를 노드 4 개에 나눠 **노드당 48 랭크**로 돌릴 계획입니다.
   그에 맞는 노드별 **CPU 예약량(물리코어/SMT 구분)** · **실제 할당 메모리** · **작업에 적용되는 cgroup 메모리 제한**을
   단위까지 알려 주십시오. 현재 메모리 계획은 노드당 188 GB 입니다. 노드별 제한 확인이 필요해서 실제 값이 필요합니다.
3. **단계당 할당 시간** — 러너는 한 할당 안에서 그 단계의 잡 전부를 돌리므로 잡당이 아니라 **단계당** 할당이 필요합니다.
   중앙 추정 1단계 55.6 h · 2단계 51.5 h, NELM=200 시나리오 148.2 h · 137.4 h —
   스텝당 시간 모형이 ±2배라 **보장된 상한이 아니고**, 156 h 는 계획 요청값입니다.
   **156 h 연속 할당**이 가능한 큐/파티션이 있습니까? (알려 주신 잡당 큐 상한 91 h 로는 충족되지 않습니다.)
4. **없다면 이어가기** — 완료된 잡 사이에서 다음 할당으로 단계를 이어갈 수 있는 운영 방식이 있습니까?
   잡을 중간에 끊거나 쪼개는 방식은 안 됩니다 — static 단일점은 나눌 수 없고 재개도 없습니다.
5. **실행 환경** — 러너는 첫 VASP 전에 실행 노드마다 cgroup 메모리 제한을 읽어 유한/무제한/미관측으로 가르고,
   미관측이면 멈춥니다. Slurm 이 통상 경로(`/sys/fs/cgroup` 또는 `/sys/fs/cgroup/memory`)에 cgroup 을 마운트한
   환경인지, 컨테이너·namespace 안에서 돌리는지 알려 주십시오.

답을 받으면 그에 맞춘 최종 실행 조건(필요하면 새 번들)을 드립니다. 이 절의 숫자는 아래 walltime 문장과 같은
출처(MANIFEST `cost_frozen` · `memory_model`)입니다.

## 하실 일

```
mkdir -p <이 묶음 전용 빈 디렉터리> && cd <그 디렉터리>
unzip <이 묶음>.zip                      # ← 풀기 **전에** ZIP 의 sha256 을 메일 본문 값과 대조
```

⛔ **`run_staged.sh` 로만 실행해 주세요. 19잡을 한꺼번에 던지지 마십시오.**
1단계(10잡)가 게이트 **8축**(진공 수렴 · 분자 스핀 · canary 기하 · POTCAR 신원 · 기체 상자 δ_gas ·
pm1 자기 topology · 잔여 차단 0 · 봉인 포괄)을 전부 통과해야 2단계를 돌립니다 — 통과 못 하면
2단계는 **돌리지 않는 것이 맞습니다**(추가 계산으로 메우지 않습니다).

```
cd <이 묶음을 푼 디렉터리>            # 묶음 **루트**에서 실행합니다 (잡 폴더 아님)
# ⛔⛔ 0단계 — **ZIP 을 풀기 전에**, ZIP 밖에서 SHA 를 대조하십시오 (회신 BA P0-1).
#    아래 값은 메일 본문에 있습니다. 이 대조는 번들 안의 어떤 스크립트도 쓰지 않습니다
#    — ZIP 안의 해시는 자기 자신을 증명하지 못하기 때문입니다.
#      sha256sum /경로/받은번들.zip     # ← 메일 본문의 값과 눈으로 대조
#    다르면 **풀지 마시고** 저희에게 알려 주십시오.
#
# ⚠ 러너는 배포 스크립트를 실행하기 **전에** 추출 파일 전수검사(census + files_sha256
#    + EXPECT)를 끝냅니다. v21 까지는 POTCAR 조립(SEAL)이 그 검사보다 **먼저** 돌아,
#    변조된 assembler 가 무결성 검사 전에 실행될 수 있었습니다 (회신 BA P0-1).
cd <이 묶음을 푼 디렉터리>              # 묶음 **루트**

# ── POTCAR 원본 트리와 allowlist (조립기가 쓴다) ──
export PP=/path/to/potpaw_PBE.54
# allowlist 는 그 트리의 변형별 POTCAR 해시 목록입니다. 없으면 이렇게 만드십시오:
#   for v in $(ls "$PP"); do sha256sum "$PP/$v/POTCAR"; done > /abs/site_allow.txt
#   (형식: `<sha256>  <PP>/<variant>/POTCAR` — sha256sum 기본 출력 그대로)
export POTCAR_ALLOWLIST=/abs/site_allow.txt

# ── 배포본 결박 (ZIP 밖의 값이 유일한 앵커입니다) ──
export BUNDLE_ZIP_SHA256=$(sha256sum /경로/받은번들.zip | cut -d" " -f1)
export EXPECT_MANIFEST_SHA256=<메일 본문의 MANIFEST SHA256>
export EXPECT_ZIP_SHA256=<메일 본문의 ZIP SHA256>

# ── 실행 방식 ──
# ⛔ 자유형 launcher 문자열(VASP_CMD·VASP_LAUNCHER)은 **폐지됐습니다** (회신 AV P0-2) —
#    문자열 검사는 우회가 가능해, 종류와 수만 받고 실행 명령은 러너가 조립합니다.
export VASP_LAUNCHER_KIND=mpirun            # mpirun|mpiexec|srun  (⛔ wrapper 는 이 제출 경로에서 제외 · none 은 스모크용)
export LAUNCHER_BIN=/abs/path/to/mpirun     # **필수** — PATH 에서 찾지 않습니다. 없으면 exit 2
export VASP_NPROC=192                        # 랭크 수 (잡 하나당) — **KPAR × NCORE = 16 의 배수**여야 합니다
#    이 묶음의 INCAR 은 KPAR=4 · NCORE=4 로 고정했습니다. 쓸 수 있는 랭크: 48·64·96·128·192·256·384·512.
#    ⛔ KPAR 배수만으로는 부족합니다 — k-그룹당 랭크가 NCORE 로 안 나뉘면 VASP 가 조용히
#      NCORE 를 되돌립니다 (예: 랭크 20 은 KPAR 4 로 나뉘지만 그룹당 5 가 NCORE 4 로 안 나뉩니다).
#    배수가 아니면 러너가 **첫 VASP 실행 전에** 멈춥니다. INCAR 은 해시로 동결돼 고칠 수 없습니다.
#    ⚠ KPAR 은 k-그룹마다 배열 사본을 들어 **노드당 메모리가 늘어납니다.** 모자라면 랭크를
#      줄이지 마시고(배수 조건이 깨집니다) 노드를 늘려 주십시오.
export VASP_EXE=/abs/path/to/vasp_std       # 실행파일 절대경로 (봉인 대상)

# ── 메모리 배치 (**2026-09-04 OOM 재발 방지 · 필수**) ──
export NODE_MEM_GB=188          # 노드 하나의 메모리 [GB]
export VASP_NODES=4                        # 잡 하나를 **이만큼의 노드에 펼쳐** 주십시오
#    잡 하나가 노드 하나에 몰리면 최악 잡이 노드당 292.2 GB 를 요구해 OOM 납니다 (**모형값** · 실측 아님).
#    노드 4 개에 펼치면 노드당 73.1 GB (가용 159.8 GB 의 46 퍼센트) 로 내려갑니다 — 이것도 모형값이라
#    예약 요구량이나 안전 보장이 아닙니다. 실제 판정은 아래 관측·프로브가 합니다.
#    필요한 총 노드 = 4 (노드/잡) x 4 (동시잡) = **16 노드**.
#    러너가 **첫 VASP 실행 전에** 이 값으로 계산해 보고, 넘치면 멈춥니다.
#    ⚠ 위 두 값은 **선언**입니다. 러너는 선언을 믿지 않고 관측과 대조합니다:
#      · 노드 메모리 — 러너 호스트에서 SLURM_MEM_PER_NODE(·MEM_PER_CPU×CPUS) · 이 작업의 cgroup 제한(계층 전부)
#        · /proc/meminfo 중 **가장 작은 값**을 먼저 보고, 배치 프로브가 **실행 노드 전부**에서 같은 값을
#        읽어 노드마다 다시 판정합니다. 어느 노드든 부족하면 멈춥니다. 선언이 관측보다 크면 멈춥니다.
#        프로브는 노드마다 제한을 **유한 / 무제한(검증) / 미관측** 세 상태로 가릅니다 — 유한이면 그 값,
#        무제한(제한 파일을 실제로 읽었고 전부 max)이면 스케줄러 할당·물리 RAM 의 최소, **미관측(못 읽음)이면
#        멈춥니다.** 못 읽은 것을 무제한으로 보지 않습니다. 상태·근거는 PLACEMENT_PROBE.json 에 남습니다.
#      · 노드 수 — SLURM_JOB_NUM_NODES 또는 아래 VASP_HOSTFILE 의 고유 호스트 수와 대조.
#        잡당 노드 × 동시 잡이 할당을 넘으면 멈춥니다.
# export VASP_HOSTFILE=/abs/hosts.txt   # SLURM 밖에서 돌리실 때만: 할당 호스트를 한 줄에 하나씩
#    (SLURM 안에서는 SLURM_JOB_NODELIST 를 scontrol 로 풀어 자동으로 얻습니다.)
#    러너는 그 호스트들을 **동시 잡 수만큼 서로소 조각**으로 나눠 잡마다 hostfile 로 넘기고,
#    **첫 VASP 실행 전에** 같은 launcher·같은 플래그로 `hostname` 을 동시에 띄워 랭크가 실제로
#    어느 노드에 놓이는지 읽습니다 (노드 수 · 노드당 랭크 · 조각 안 · 잡 사이 겹침 없음).
#    어긋나면 멈추고, 결과는 PLACEMENT_PROBE.json 에 남습니다 — 반송 목록에 포함해 주십시오.
#    ⚠ MPI 구현은 `<launcher> --version` 으로 판별합니다 (Open MPI → -N · MPICH/Intel → -ppn).
#      판별이 안 되면 멈춥니다. Intel MPI 는 I_MPI_JOB_RESPECT_PROCESS_PLACEMENT=0 을 러너가 켭니다.

# ⚠ 러너는 기본으로 잡 4개를 **동시에** 띄웁니다 (= 4 × VASP_NPROC 랭크).
#    할당이 그보다 적으면:  export JOBS_PARALLEL=<동시에 돌릴 잡 수>

# (선택) PAW release 기록 — 첫 VASP 실행 **전에만** 가능 · 안 하셔도 러너·판정에 영향 없음.
#   위 export 들이 같은 셸에 있어야 합니다. 결함이면 러너가 생산 **전에** 멈춥니다 (지우면 다시 돌아갑니다).
#   RELEASE_LABEL="potpaw_PBE.54" SITE="기관/담당자" bash MAKE_POTCAR_ATTESTATION.sh

bash run_staged.sh 1     # census → POTCAR 조립+봉인 → 봉인 census → 1단계 → 판정
bash run_staged.sh 2     # 1단계 통과(STAGE1_PASS.json) 뒤에만
```

⚠ `BUNDLE_ZIP_SHA256` 이 없으면 봉인 스크립트가 **거부합니다** — 번들 안에는 자기
해시를 넣을 수 없어서, 받으신 파일에서 직접 구해 주셔야 결박이 성립합니다.
`EXPECT_MANIFEST_SHA256` 과 `EXPECT_ZIP_SHA256` 은 메일 본문에 적어 보내드립니다 —
**둘 다 필수**입니다. 없으면 러너가 시작하지 않습니다 (번들 안의 해시는 자기 자신을
증명하지 못하므로, ZIP 밖의 값이 유일한 앵커입니다).

**POTCAR 를 따로 조립하지 마십시오** — `run_staged.sh` 가 첫 VASP 실행 전에
`SEAL_POTCAR_ROOT.sh` 로 전 잡 조립 + 원본 fingerprint 봉인까지 합니다.

### 🙏 부탁 — 첫 잡 전에 한 줄만 더 (POTCAR 신원 · 선택)

```bash
# 위 실행 블록의 export 들(PP · POTCAR_ALLOWLIST · BUNDLE_ZIP_SHA256 · VASP_EXE)이 같은 셸에
# 있어야 합니다. 러너 1단계를 시작하기 **전에** 한 번만 — 첫 VASP 실행 뒤에는 만들 수 없습니다.
RELEASE_LABEL="potpaw_PBE.54" SITE="기관/담당자" bash MAKE_POTCAR_ATTESTATION.sh
```

**막지는 않습니다. 없어도 러너는 돌아갑니다.** 있으면 러너가 생산 **전에** 봉인과 대조하고,
결함이면 그 자리에서 멈춥니다 (파일을 지우면 다시 돌아갑니다). 이것으로 결과의 인용 자격이
달라지지는 않지만, PAW dataset 신원 **기록**이 남아 말씀드립니다.

저희 봉인(`SEAL_POTCAR_ROOT.sh`)이 보증하는 것은 *"16잡이 전부 같은 하나의 트리에서
나왔고 그 트리가 첫 계산 전에 고정됐다"* 까지입니다. **그 트리가 승인된 PAW dataset
인지는 보증하지 못합니다** — VASP 는 같은 원소에도 여러 PAW 세트와 suffix variant
(`Li` vs `Li_sv`, release 5.2 vs 5.4 …)를 배포하고, 어느 것을 썼는지에 따라 에너지가
달라지므로 dataset 신원은 범함수 선택과 같은 급의 **계산 조건**입니다.
해시는 "바뀌지 않았다"만 말하고 "이것이 무엇이다"는 말해 주지 않습니다.

- **돌려 주시면**: dataset 신원 기록이 남습니다. (⚠ 그것만으로 원고 인용 자격이
  서지는 않습니다 — 아래 참조.)
- **안 돌리셔도**: 계산은 그대로 진행되고 결과도 유효합니다.

⛔ **이 묶음의 결과는 원고 인용용이 아닙니다.** MANIFEST 의
`potcar_identity_policy.manuscript_citable = false` 이고, 분석기가 그것을 결과 최상위
(`citation_status`)에서 기계로 집행합니다. attestation 을 **사후에** 받아도 원고용으로
승격되지 않습니다 — 그러려면 계산 **전에** 외부 앵커(사전 승인 해시 `--potcar_pin`
또는 서명)가 있어야 합니다 (회신 BA P0-3·Q5).
따라서 "조건부로 원고 인용" 이라는 표현은 이 묶음에 **쓰지 않습니다**.

시간은 몇 초입니다. 첫 VASP 실행 뒤에는 만들 수 없습니다(생산 전이라는 사실 자체가
근거이기 때문입니다 — 회신 AR P0-6).
`run_all.sh` 는 이 묶음에 **넣지 않았습니다** (전체 제출 경로가 있으면 1단계
정지 규칙이 무력화됩니다).

⛔ **단일 잡을 손으로 돌리는 경로는 이 묶음에서 삭제했습니다** (회신 AT P0-5).
`run_job.sh` 를 직접 부르면 봉인된 실행파일 검사와 번들 전역 lock 을 **둘 다 우회**해,
봉인이 무의미해지고 같은 번들에 두 실행이 들어올 수 있습니다.
⛔ **`ALLOW_RESUME` 은 폐지됐습니다** (회신 BA 해제조건 7). 러너는 그 변수를 보면
**거부합니다** — 이 문서가 그것을 지시하고 있었던 것은 잘못이고, 그대로 따르면
실행이 막혀 이유를 알 수 없었습니다 (회신 BB P1 지적).

한 잡을 다시 돌리셔야 하면 **폴더를 새로 풀고 처음부터** 돌리십시오. 부분 재개는
남이 다른 설정으로 돌려 둔 결과를 우리 것으로 반송하는 사고를 막지 못합니다
(회신 AA P0-5). 실패 잡이 남아 다시 돌려야 하는 경우는 저희에게 알려 주시면
**그 잡만 담은 별도 rescue 묶음**을 만들어 보내 드립니다 — 그 묶음은 부모 번들을
`parent`/`supersedes` 로 명시해 계보가 끊기지 않습니다 (회신 BB Q3).

### 이전 extraction 에서 완주한 잡을 이어 쓰기 (승계 · `SKIP_COMPLETE=1` + `CONTINUE_FROM`)

같은 계산(잡 입력이 바이트 동일한 이전 판)에서 이미 **완주한** 잡이 있으면 다시 돌리지 않습니다.
⛔ 다만 **손으로 옮기지 마십시오** — 완주 폴더를 새 extraction 에 먼저 복사하면 봉인 스크립트가
"생산 산출물이 이미 있습니다" 로 거부하고, 이전 extraction 에 새 스크립트를 덮어쓰면 census 가
`files_sha256` 불일치로 거부합니다 (봉인은 MANIFEST·ZIP 해시에 묶여 있고 바꾸지 않습니다).
러너가 봉인 **뒤에** 스스로 옮깁니다. 절차는 위 실행 블록에 두 줄이 더 붙은 것이고, 아래 블록을
그대로 쓰시면 됩니다 (`<…>` 두 곳 — 이 묶음 디렉터리 · 이전 extraction 루트 — 만 채우십시오).

```
cd <이 묶음을 푼 디렉터리>              # 묶음 **루트**

# ── POTCAR 원본 트리와 allowlist (조립기가 쓴다) ──
export PP=/path/to/potpaw_PBE.54
# allowlist 는 그 트리의 변형별 POTCAR 해시 목록입니다. 없으면 이렇게 만드십시오:
#   for v in $(ls "$PP"); do sha256sum "$PP/$v/POTCAR"; done > /abs/site_allow.txt
#   (형식: `<sha256>  <PP>/<variant>/POTCAR` — sha256sum 기본 출력 그대로)
export POTCAR_ALLOWLIST=/abs/site_allow.txt

# ── 배포본 결박 (ZIP 밖의 값이 유일한 앵커입니다) ──
export BUNDLE_ZIP_SHA256=$(sha256sum /경로/받은번들.zip | cut -d" " -f1)
export EXPECT_MANIFEST_SHA256=<메일 본문의 MANIFEST SHA256>
export EXPECT_ZIP_SHA256=<메일 본문의 ZIP SHA256>

# ── 실행 방식 ──
# ⛔ 자유형 launcher 문자열(VASP_CMD·VASP_LAUNCHER)은 **폐지됐습니다** (회신 AV P0-2) —
#    문자열 검사는 우회가 가능해, 종류와 수만 받고 실행 명령은 러너가 조립합니다.
export VASP_LAUNCHER_KIND=mpirun            # mpirun|mpiexec|srun  (⛔ wrapper 는 이 제출 경로에서 제외 · none 은 스모크용)
export LAUNCHER_BIN=/abs/path/to/mpirun     # **필수** — PATH 에서 찾지 않습니다. 없으면 exit 2
export VASP_NPROC=192                        # 랭크 수 (잡 하나당) — **KPAR × NCORE = 16 의 배수**여야 합니다
#    이 묶음의 INCAR 은 KPAR=4 · NCORE=4 로 고정했습니다. 쓸 수 있는 랭크: 48·64·96·128·192·256·384·512.
#    ⛔ KPAR 배수만으로는 부족합니다 — k-그룹당 랭크가 NCORE 로 안 나뉘면 VASP 가 조용히
#      NCORE 를 되돌립니다 (예: 랭크 20 은 KPAR 4 로 나뉘지만 그룹당 5 가 NCORE 4 로 안 나뉩니다).
#    배수가 아니면 러너가 **첫 VASP 실행 전에** 멈춥니다. INCAR 은 해시로 동결돼 고칠 수 없습니다.
#    ⚠ KPAR 은 k-그룹마다 배열 사본을 들어 **노드당 메모리가 늘어납니다.** 모자라면 랭크를
#      줄이지 마시고(배수 조건이 깨집니다) 노드를 늘려 주십시오.
export VASP_EXE=/abs/path/to/vasp_std       # 실행파일 절대경로 (봉인 대상)

# ── 메모리 배치 (**2026-09-04 OOM 재발 방지 · 필수**) ──
export NODE_MEM_GB=188          # 노드 하나의 메모리 [GB]
export VASP_NODES=4                        # 잡 하나를 **이만큼의 노드에 펼쳐** 주십시오
#    잡 하나가 노드 하나에 몰리면 최악 잡이 노드당 292.2 GB 를 요구해 OOM 납니다 (**모형값** · 실측 아님).
#    노드 4 개에 펼치면 노드당 73.1 GB (가용 159.8 GB 의 46 퍼센트) 로 내려갑니다 — 이것도 모형값이라
#    예약 요구량이나 안전 보장이 아닙니다. 실제 판정은 아래 관측·프로브가 합니다.
#    필요한 총 노드 = 4 (노드/잡) x 4 (동시잡) = **16 노드**.
#    러너가 **첫 VASP 실행 전에** 이 값으로 계산해 보고, 넘치면 멈춥니다.
#    ⚠ 위 두 값은 **선언**입니다. 러너는 선언을 믿지 않고 관측과 대조합니다:
#      · 노드 메모리 — 러너 호스트에서 SLURM_MEM_PER_NODE(·MEM_PER_CPU×CPUS) · 이 작업의 cgroup 제한(계층 전부)
#        · /proc/meminfo 중 **가장 작은 값**을 먼저 보고, 배치 프로브가 **실행 노드 전부**에서 같은 값을
#        읽어 노드마다 다시 판정합니다. 어느 노드든 부족하면 멈춥니다. 선언이 관측보다 크면 멈춥니다.
#        프로브는 노드마다 제한을 **유한 / 무제한(검증) / 미관측** 세 상태로 가릅니다 — 유한이면 그 값,
#        무제한(제한 파일을 실제로 읽었고 전부 max)이면 스케줄러 할당·물리 RAM 의 최소, **미관측(못 읽음)이면
#        멈춥니다.** 못 읽은 것을 무제한으로 보지 않습니다. 상태·근거는 PLACEMENT_PROBE.json 에 남습니다.
#      · 노드 수 — SLURM_JOB_NUM_NODES 또는 아래 VASP_HOSTFILE 의 고유 호스트 수와 대조.
#        잡당 노드 × 동시 잡이 할당을 넘으면 멈춥니다.
# export VASP_HOSTFILE=/abs/hosts.txt   # SLURM 밖에서 돌리실 때만: 할당 호스트를 한 줄에 하나씩
#    (SLURM 안에서는 SLURM_JOB_NODELIST 를 scontrol 로 풀어 자동으로 얻습니다.)
#    러너는 그 호스트들을 **동시 잡 수만큼 서로소 조각**으로 나눠 잡마다 hostfile 로 넘기고,
#    **첫 VASP 실행 전에** 같은 launcher·같은 플래그로 `hostname` 을 동시에 띄워 랭크가 실제로
#    어느 노드에 놓이는지 읽습니다 (노드 수 · 노드당 랭크 · 조각 안 · 잡 사이 겹침 없음).
#    어긋나면 멈추고, 결과는 PLACEMENT_PROBE.json 에 남습니다 — 반송 목록에 포함해 주십시오.
#    ⚠ MPI 구현은 `<launcher> --version` 으로 판별합니다 (Open MPI → -N · MPICH/Intel → -ppn).
#      판별이 안 되면 멈춥니다. Intel MPI 는 I_MPI_JOB_RESPECT_PROCESS_PLACEMENT=0 을 러너가 켭니다.

# ⚠ 러너는 기본으로 잡 4개를 **동시에** 띄웁니다 (= 4 × VASP_NPROC 랭크).
#    할당이 그보다 적으면:  export JOBS_PARALLEL=<동시에 돌릴 잡 수>

# (선택) PAW release 기록 — 첫 VASP 실행 **전에만** 가능 · 안 하셔도 러너·판정에 영향 없음.
#   위 export 들이 같은 셸에 있어야 합니다. 결함이면 러너가 생산 **전에** 멈춥니다 (지우면 다시 돌아갑니다).
#   RELEASE_LABEL="potpaw_PBE.54" SITE="기관/담당자" bash MAKE_POTCAR_ATTESTATION.sh

# ── 승계: 이전 extraction 에서 **완주한** 잡을 옮겨 오고 건너뜁니다 (1단계에만) ──
export SKIP_COMPLETE=1      # 완주가 증명된 잡(모든 상 'General timing' · receipt _runner_start 정확히 1개)만 건너뜁니다
export CONTINUE_FROM=/abs/path/to/<이전 extraction 의 묶음 루트>   # MANIFEST.json · POTCAR_ROOT_SEAL.json 이 있는 폴더 · **절대경로**
#    러너가 봉인·census·실행파일 대조를 끝낸 **뒤에** 이전 extraction 의 완주 잡 산출물(receipt·상 폴더)을 옮겨 옵니다.
#    옮기기 전에 잡마다 입력(job.json·POSCAR·INCAR·KPOINTS·run_job.sh·조립기) 바이트 동일 · 같은 PP 트리 ·
#    같은 VASP/launcher · 같은 조립본 해시 · 실제로 돈 기하 동일을 확인하고, 하나라도 어긋나면 **아무것도 옮기지 않고**
#    멈춥니다. 완주가 증명되지 않은 잡(qdel 찌꺼기 등)은 옮기지 않고 여기서 새로 실행됩니다. 기록: CONTINUATION.json (반송 목록).
GO=1
[ -f "$CONTINUE_FROM/MANIFEST.json" ] && [ -f "$CONTINUE_FROM/POTCAR_ROOT_SEAL.json" ] \
  || { echo "CONTINUE_FROM 이 이전 extraction 의 묶음 루트가 아닙니다: $CONTINUE_FROM"; GO=0; }
[ "$GO" = 1 ] && bash run_staged.sh 1     # 봉인 → 승계(CONTINUATION.json) → 완주 잡 건너뜀 → 나머지 실행 → 1단계 판정
# 2단계는 승계 없이 그대로 (CONTINUE_FROM 이 남아 있어도 러너가 '승계할 것 없음' 으로 지나갑니다):
#   bash run_staged.sh 2
```

- 러너 출력에 `✓ 승계 <잡>` 가 완주 잡 수만큼 찍히고, 물결 집계에 `건너뜀 N` 으로 잡힙니다.
  완주가 증명되지 않은 잡(중단 잔재)은 `승계 안 함 … — <사유>` 로 찍히고 여기서 새로 실행됩니다.
- 옮겨 온 잡의 `EXECUTABLE_RECEIPT.tsv` 는 손대지 않습니다 (분석기가 그 receipt 를 봉인과 대조합니다).
- 이전 extraction 은 지우지 마시고 그대로 두십시오 (승계 기록 `CONTINUATION.json` 이 그 경로·MANIFEST·봉인 해시를 가리킵니다).
- ⚠ 잡 입력이 하나라도 다르면(다른 판·다른 설계) 러너가 승계를 **통째로 거부**합니다 — 그때는 저희에게 알려 주십시오.

⛔ 이 묶음은 `run_staged.sh` **하나로만** 돌립니다. 위 블록의
명령을 그대로 쓰십시오. `run_job.sh` 를 직접 부르지 마세요 — 봉인된 실행파일 검사와
번들 전역 lock 을 우회합니다 (회신 AT P0-5).


⚠ **묶음이 둘 이상이면 반드시 서로 다른 빈 디렉터리에 풀고 따로 반송해 주세요.**
같은 자리에 겹쳐 풀면 어느 결과가 어느 묶음 것인지 저희가 되살릴 수 없습니다.

### POTCAR 신원 — 별도로 보내주실 것은 없습니다

`POTCAR_ASSEMBLE.sh` 가 조립하면서 **`POTCAR_PROVENANCE.json`** 을 만듭니다.
그 안에 변형별 원본 SHA256 · TITEL 줄 · 조립본 SHA256 이 들어갑니다.
`run_job.sh` 는 그 파일이 없으면 **실행을 거부**하므로 (POTCAR 를 손으로 놓으면 멈춥니다),
반송물에 자동으로 포함됩니다. 저희가 그 값으로 대조합니다.

- **따로 메일로 해시를 보내실 필요 없습니다.**
- ⚠ 이 묶음은 **이전 wave 와의 PP 동등성을 주장하지 않습니다** — 어느 트리를
  쓰셨는지는 봉인이 기록하고, 저희는 "이 묶음 안에서 하나의 트리였는가" 만
  확인합니다 (회신 AO P1 · AR P1-11).
- POTCAR 파일 자체는 주고받지 않습니다 — 해시와 TITEL 줄만 기록됩니다.

잡 폴더 19개가 `prospective` · `refs` · `vacconv` 에 있습니다.
⛔ **서로 독립이 아닙니다.** canary(`*__nzmag`)는 부모 기체 기준의 최종
기하를 받으므로 부모가 **먼저** 끝나야 하고, 2단계는 1단계 게이트를
통과해야 열립니다. 순서는 `run_staged.sh` 가 강제합니다 — 전부 동시에
던지지 마십시오.

## 잡 census (산출물에서 센 값)

| | 끝점 | D3-off 쌍둥이 | 계 |
|---|---:|---:|---:|
| references | 8 | 0 | **8** |
| calibration complexes | 8 | 0 | **8** |
| | | | **19** |

audit pose **0개**. pose 당: pm1/D3-on · net4/D3-on — **D3-off 쌍둥이를 만들지 않는다** (C3 는 D3-on OUTCAR 의 Edisp 로 낸다)


## 실행 단계와 결과 범위 (읽어 주세요)

이 요청은 **이것으로 끝나는 계산**입니다 — 뒤에 이어지는 단계가 없습니다.
조각당 primary 1자세 + 대안 1자세를 자기 시드 2종으로 잽니다. primary 는 셀 두 높이에서 한 번 더 잽니다(진공 두께 수렴 시험, 3잡). 보고하는 것은 **두 조각의 흡착에너지 절대값 2건과 그 차 ΔE_ads — 셋 다**입니다.
(⛔ 2026-09-07 정정: 종전 README 는 *"차 하나만 보고하고 개별 절대값은 보고하지 않습니다
— 깨끗한 슬랩을 계산하지 않으므로"* 라고 적었는데, **둘 다 사실이 아니었습니다.**
이 묶음에는 `refs/clean_slab__afm2424_pm1` · `refs/clean_slab__afm2424_net4` ·
`vacconv/clean_slab__afm2424_pm1__c2` 3잡이 들어 있고, 비준된 사전등록도 절대값 2건과
차를 함께 보고하도록 개정돼 있습니다. MANIFEST 의 `reported_quantity` 가 정본입니다.)
⚠ 두 값의 신뢰도는 다릅니다 — ΔE_ads 는 슬랩 항이 소거돼 clean slab 오차에 둔감하고,
절대값은 그 항을 직접 빼므로 민감합니다. 귀측 실행에 달라지는 것은 없습니다.

대안 자세는 최저값 후보가 **아닙니다** — "다른 접촉 방식에서도 방향이 유지되는가" 만
봅니다. 최저·평균·순위에 섞지 않습니다.

각 calibration pose 는 `pm1/D3-on` · `net4/D3-on` **두 계산**입니다.
**D3-off 쌍둥이는 만들지 않습니다** — 고정기하 static(NSW=0)에서 D3(zero)는
SCF 밖의 additive 항이라 `E_on − E_off` 가 항등적으로 OUTCAR 의 `Edisp` 와
같습니다. 그래서 그 항을 D3-on 결과에서 직접 읽습니다.
같은 POSCAR 가 자기 seed 둘로 두 번 보이는 것은 **정상이고 설계**입니다.
중복으로 보고 하나만 돌리시면 그 짝이 통째로 무의미해집니다.

`pm1` 과 `net4` 는 **초기 MAGMOM seed 이름**입니다. 최종 자기상태가 아닙니다.
저희 분석기가 최종 Ni 국소모멘트 부호벡터 · moment collapse · 유기종 상대스핀으로
realized magnetic basin 을 판정하고, **같은 realized basin 으로 매칭되지 않은**
에너지끼리는 빼지 않습니다. 그래서 `LORBIT` 를 켜 두었습니다 — OUTCAR 의
국소모멘트 표가 판정 근거입니다.

가능하시면 **`refs/clean_slab__*` 잡을 먼저** 돌려 보내 주세요. 그것으로 자기
topology gate 를 통과시킨 뒤 complex 결과를 씁니다. raw `net4` 가 pose 마다 다른
basin 으로 수렴하면 저희가 계산을 중단하고 별도 절차를 요청드립니다.


모든 결과는 MLIP 이 고른 **고정기하에서의 PBE+U+D3 단일점 전자에너지**입니다.
DFT-relaxed adsorption energy · 평형 결합에너지 · 자유에너지로 표현하지 않습니다.

## 미리 아셔야 할 것

- **전 잡이 단일점입니다.** `relax/` 폴더가 아예 없습니다. 확인하실 수 있습니다:
  `find . -maxdepth 3 -type d -name relax | wc -l` → **0**
  잡 수는 `find . -name run_job.sh | wc -l` 이 정답입니다.
- ⚠ **walltime — 요청은 단계 기준 하나입니다.** `run_staged.sh` 는 계산노드 할당 **안에서**(로그인 노드 아님) 그 단계의 잡 전부를 동시 4잡 × VASP_NPROC 랭크로 돌리므로, 할당은 **그 단계가 끝날 때까지** 유지돼야 합니다. 잡 하나하나가 짧아도 단계 합이 넘으면 **할당이 먼저 잘립니다.**
   · 단계 할당 (러너의 실제 순서로 계산 — 경로 사전순 FIFO + 물결 장벽): 중앙 추정 1단계 55.6 h · 2단계 51.5 h / NELM 시나리오 1단계 148.2 h · 2단계 137.4 h
   ⇒ **단계당 156 h** 를 요청해 주십시오 (NELM 시나리오 최대를 12 h 단위로 올림). ⚠ 이 수도 보장이 아닌 **계획값**입니다 — 여유를 더 둘지는 귀측 큐 정책의 선택이고, NELM 으로 입증되는 것이 아닙니다.
   ⛔ 알려 주신 잡당 큐 상한 **91 h 로는 충족되지 않습니다.** 더 긴 할당이 가능한지, 아니면 완료된 잡 사이에서 단계를 이어갈 운영 방식이 있는지 **제출 전에** 알려 주십시오. VASP 를 중간에 끊거나 잡을 쪼개는 방식은 안 됩니다 — static 단일점은 나눌 수 없고 재개도 없습니다.
   참고 (요청값 아님): 가장 긴 잡의 중앙 추정 **29 h** (192코어/잡 · 모형 ±2배 → 외피 58 h). 가정한 스텝수 대신 `NELM=200` 번을 다 돌면 가장 긴 잡이 **77 h** 입니다 (잡당 큐 상한 91 h 아래입니다 (여유 14 h)). ⛔ 다만 NELM 이 묶는 것은 **횟수**이지 시간이 아닙니다 — 스텝당 시간이 바로 ±2배인 그 양이라 이 수도 같은 폭을 안고 있고, **보장이 아닙니다**. 종전 문서의 *'결정론적 상한'* 표현은 **철회합니다**. 봉인 프로브도 같은 노드에서 VASP 를 인자 없이 한 번 잠깐 기동합니다.
⚠ **전체 일정** — 동시 4잡 기준 약 **4.46일**입니다 (1단계 최장 28.9 h → 게이트 → 2단계 최장 26.0 h · 두 단계는 **직렬**이라 동시 실행을 늘려도 이 아래로는 내려가지 않습니다). 여기에 1단계 반송 뒤 저희 판정 왕복 시간은 포함돼 있지 않습니다.
💡 **먼저 한 잡만 재 보시길 권합니다.** 위 추정은 모형이라 ±2배입니다. 큐 상한이 빠듯하시면 `refs/` 의 기체 잡 하나(가장 짧습니다)나 복합체 한 잡을 먼저 돌려 실제 벽시계를 알려 주시면, 나머지 walltime 을 그 값으로 다시 잡아 드립니다. 1단계 전체를 던진 뒤 큐에서 잘리는 것보다 쌉니다 — 잘린 잡은 재개할 수 없어 통째로 다시 돌려야 합니다.
- **POTCAR 는 잡마다 종 순서가 다릅니다.** 러너(`SEAL_POTCAR_ROOT.sh`)가 첫 실행 전에 잡마다
  조립하고 순서·variant·PAW_PBE 까지 확인합니다 — 직접 조립하지 마십시오. 하나를 만들어
  전체에 복사하시면 **에러 없이 다른 계를 계산합니다.**

## 보내 주실 것

**정본은 `MANIFEST.json` 의 `return_contract`** 이며 이 목록은 그 렌더입니다
(README 와 SUBMIT_CONTRACT 어디를 보셔도 같습니다 — 회신 AV P0-4).

**보내는 방법**: 가장 쉬운 방법 — 푼 디렉터리를 **통째로** 다시 압축해 보내 주십시오 (배포 입력·MANIFEST 포함 · 위 목록이 자동으로 충족됩니다). 예: `tar --exclude=CHGCAR --exclude=WAVECAR --exclude=POTCAR -czf 반송.tgz <푼 디렉터리>`  ⛔ **POTCAR 는 반드시 빼 주십시오** (라이선스 — 2026-09-07 Codex v37 P1-2). 종전 명령은 CHGCAR·WAVECAR 만 빼서 조립된 POTCAR 가 딸려 왔습니다. 증빙인 `POTCAR_PROVENANCE.json` · `POTCAR_ROOT_SEAL.json` · `EXECUTABLE_RECEIPT.tsv` 는 **그대로 두십시오** — 그게 판정에 쓰이는 것이고, POTCAR 원문은 저희가 받으면 안 되는 것입니다.

각 잡 폴더에서:
- static/OUTCAR (또는 .gz)
- static/OSZICAR
- static/POSCAR — **실행된 기하** (부모↔canary 기하 대조·기하 감사. 없으면 CANARY_GEOM_UNCHECKED 로 막힙니다)
- POTCAR_PROVENANCE.json (조립기가 자동 생성)
- job.json (받으신 그대로 — 분석기가 잡의 정체·상 목록을 이것으로 읽습니다 · 없으면 그 잡은 차단)
- EXECUTABLE_RECEIPT.tsv — 상별 실행파일 해시 (run_staged 경로가 자동 생성 · 분석기가 root seal 과 대조합니다)

묶음 루트에서:
- MANIFEST.json (받으신 그대로 — 분석기가 가장 먼저 읽습니다)
- POTCAR_ROOT_SEAL.json (첫 실행 전 봉인)
- ZIP_SHA256.txt
- RESULTS.json (run_staged 가 판정 때 만듦 — 있으면 그대로)
- PLACEMENT_PROBE.json — 첫 VASP 전 배치 프로브 기록 (2026-09-08 · 랭크가 실제로 어느 노드에 놓였는지 · 잡 사이 겹침 없음의 증거)
- STAGE1_PASS.json (1단계 통과 receipt)
- CONTINUATION.json — 이전 extraction 의 완주 잡을 승계(SKIP_COMPLETE=1 + CONTINUE_FROM)했을 때 러너가 만듭니다. 승계했으면 **필수**, 승계하지 않았으면 이 파일은 없습니다
- POTCAR_ATTESTATION.json — **선택** (탐색용 정책). 없어도 러너는 돌아갑니다. ⚠ 다만 그 결과는 **원고 인용 자격이 없습니다** — 사후 provenance 는 무엇을 썼는지만 기록하고 그것이 승인된 PAW dataset 인지 판정하지 못합니다 (회신 AZ P0-7·Q4). 만들려면 `MAKE_POTCAR_ATTESTATION.sh` 를 **첫 VASP 실행 전에만** 돌릴 수 있습니다 (회신 AR P0-6)

보내지 않으셔도 되는 것: CHGCAR·WAVECAR (용량 — 압축에서 빼셔도 됩니다 · ⚠ 서버에서는 지우지 말고 두십시오) · vasprun.xml (선택)
⚠ 발산·미수렴 잡도 지우지 말고 그대로 보내 주십시오 — 실패도 판정의 일부입니다

## 부탁 — 입력을 고치지 말아 주세요

`INCAR` · `KPOINTS` · `POSCAR` 를 **한 글자도 고치지 말아 주세요.**
분석기가 `MANIFEST.json` 의 sha256 으로 대조하며, **예외 태그 목록을 두지 않았습니다.**
`NCORE` 를 포함해 무엇이든 한 줄이 바뀌면 그 잡은 거부됩니다
(`NCORE` 는 4 로 넣어 두었습니다).

- 병렬 조정이 꼭 필요하시면 **알려 주세요** — 저희가 다시 만들어 드리는 게 빠릅니다.
- **SCF 가 안 붙는 잡은 그대로 두고 알려만 주세요.** 설정을 바꿔 다시 돌리신 값은
  저희 검증을 통과하지 못해 버려집니다.
- 그래도 직접 재시도해 보셔야 한다면, **원본을 덮지 마시고**
  `<잡폴더>/_retry_1/` 처럼 별도 디렉터리에 남겨 주세요. 원본 실패 상태와 재시도를
  둘 다 받아야 저희가 원인을 압니다.
  ⚠ 이 `_retry_1` 은 **진단 자료**이지 반송물이 아닙니다 — 저희 검증은 그 값을
    쓰지 않습니다. 다시 돌려야 하는 잡은 저희가 **별도 rescue 묶음**으로 만들어
    보내 드립니다 (부모 번들·잡·입력 SHA 와 attempt ID 가 박히고, 원본은 그대로
    보존되며 자동 대체는 하지 않습니다 — 회신 BC P1).

## 확인용

```
python3 analyze_results.py .       # 판정 실패 exit 2 · 완주했으나 원고 인용 불가(탐색용) exit 3
```

---
계산 조건·근거·범위는 `MANIFEST.json` 에, 제출 관련 수치는 `SUBMIT_CONTRACT.md` 에
적어 두었습니다. 궁금한 점 있으시면 편하게 물어봐 주세요.

<details><summary>프로토콜 요약 (참고)</summary>

PBE+U(Ni d 6.2 Dudarev) · D3 zero damping(IVDW=11) · ENCUT 520 · ISMEAR 0/0.05 ·
ISYM=0 · LASPH · ADDGRID · LDIPOL/IDIPOL=3 · static k 3 4 1 · dense 없음 (δ_k 축 설계 제외 — 비준 사전등록 3_오차예산) ·
고정 평면 z ≤ 17.396 Å · 자기 seed 2종(각 끝점마다 둘 다 필요합니다) ·
Ni 는 **Ni_pv**. ⚠ 이전 wave 와의 PP 동등성은 **주장하지 않습니다**, 배포판(release)도
여기서 단정하지 않습니다 — variant 는 `POTCAR_SPEC.txt` 그대로 쓰시고, 원본
fingerprint 는 첫 실행 전에 `SEAL_POTCAR_ROOT.sh` 가 봉인합니다 (회신 AO P1 · AR P1-11).
dense(k 수렴) 상은 이 묶음 설계에 없습니다 — δ_k 는 재지 않으며, 0.01 eV 전체 안정성은 주장하지 않습니다 (시험한 축 조건부로만 보고).
</details>

#!/usr/bin/env python3
"""
DEM Contact Analysis - Standard mode (AM + SE, 2 types)
Full pipeline: porosity, interface area, coverage, percolation, tortuosity, ionic active AM

Usage:
    python analyze_contacts.py results/atoms.csv results/contacts.csv -o ./results -t "1:AM,2:SE" -s 1000
"""
import argparse
import hashlib
import os
import sys
import json
import numpy as np
import pandas as pd
from collections import defaultdict

sys.path.insert(0, os.path.dirname(__file__))
from dem_analysis_core import run_full_analysis
import type_map_resolve as _tmr
from metrics_json import json_default as _json_default   # numpy → 파이썬 숫자 (옛 default=str 은 '412' 문자열 — LHS-24 (a))
from metrics_json import STRESS_CV_COMPUTED, STRESS_CV_STATUS_ROW   # LHS-33 옛 σ_VM 열 상태 계약 (표 상태 줄 철자 한 곳)


def _file_digest(path, chunk=1 << 20):
    """입력 파일 sha256 앞 16 자 — webapp/pipeline_service.file_digest 와 같은 꼴 (scripts 는 webapp 을 import 하지 않는다)."""
    h = hashlib.sha256()
    try:
        with open(path, 'rb') as f:
            for b in iter(lambda: f.read(chunk), b''):
                h.update(b)
        return h.hexdigest()[:16]
    except OSError:
        return ''


_CSTR_COLS = ('c_strs[1]', 'c_strs[2]', 'c_strs[3]')
_SIGMA_KEYS = ('sigma_xx', 'sigma_yy', 'sigma_zz')


def _cstr_issues(raw, num, present):
    """RGLR-03 — c_strs 원 열 (강제 변환 **전** raw · 뒤 num) 에서 행마다 손상 사유 목록 (빈 목록 = 세 성분이 다 있고 유한).
    열 일부만 있으면 모든 행에 그 사유 · 칸이 비었거나 NaN · 숫자로 못 읽음 (문자열) · 비유한 (±inf · 넘침) 을 칸마다 가른다."""
    why = [[] for _ in range(len(num))]
    absent = [c for c in _CSTR_COLS if c not in present]
    if absent:
        msg = 'c_strs 열 일부만 (' + ' · '.join(absent) + ' 없음)'
        for w in why:
            w.append(msg)
    for c in present:
        r = raw[c]
        v = num[c].to_numpy(dtype=float)
        blank = r.isna().to_numpy()
        bad = (~blank) & np.isnan(v)                       # 칸은 있는데 숫자로 못 읽음 (pd.to_numeric coerce → NaN)
        inf = (~blank) & (~bad) & ~np.isfinite(v)
        for k in np.flatnonzero(blank):
            why[k].append(f'{c} 빈칸 · NaN')
        for k in np.flatnonzero(bad):
            why[k].append(f'{c} 숫자 아님 ({str(r.iloc[k])[:24]!r})')
        for k in np.flatnonzero(inf):
            why[k].append(f'{c} 비유한 ({float(v[k])!r})')
    return why


def load_atoms_raw(csv_path):
    """atoms.csv → ({id: 입자 dict}, df).  df 는 옛 판 그대로 (모든 열 pd.to_numeric(coerce)).

    c_strs (LIGGGHTS compute stress/atom) → sigma_xx·yy·zz = c_strs ÷ (4/3 π r³) (sim 단위 · 정상 행은 옛 판과 비트 동일).
    ★ RGLR-03 (Codex 10-05 재검증 · P2 · 1저자 비준) — 옛 판은 강제 변환 뒤 첫 성분이 NaN (문자열 → NaN 포함) 이면 세 sigma 키를 모두
      안 써서 "손상" 을 "c_strs 없음" 으로 바꿨다 → Love–Weber 전역 virial 검사가 꺼졌다 (틀린 virial −2.7 도 OK).  이제:
        · 세 원천 열이 **전부** 헤더에 없을 때만 미제공 (sigma 키 없음 — 옛 입력 호환)
        · 열 일부만 · 칸 비유한 · 파싱 실패 · 반경 (부피) 무효 = 그 입자의 sigma 키를 **NaN 으로** 남기고 (못 쓰는 성분만 NaN ·
          쓸 수 있는 성분은 c_strs ÷ 부피) 사유를 `c_strs_invalid` 에 적는다 → 소비자 (calc_love_weber_stress · calc_von_mises_stress)
          가 "있는데 무효" 로 거부한다 (invalid_input).  정상 행 dict 에는 새 키가 없다.
    """
    df = pd.read_csv(csv_path)
    present = [c for c in _CSTR_COLS if c in df.columns]
    raw = {c: df[c].copy() for c in present}                  # 강제 변환 전 원 칸 (빈칸 ↔ 파싱 실패를 가른다)
    for col in df.columns:
        df[col] = pd.to_numeric(df[col], errors='coerce')
    df['id'] = df['id'].astype(int)
    df['type'] = df['type'].astype(int)
    issues = _cstr_issues(raw, df, present) if present else None
    atoms = {}
    for i, (_, row) in enumerate(df.iterrows()):
        atom = {
            'type': int(row['type']),
            'x': row['x'], 'y': row['y'], 'z': row['z'],
            'radius': row['radius'],
        }
        # Add stress if available (sim units)
        if present:
            vol = (4.0 / 3.0) * np.pi * row['radius']**3
            ok_vol = bool(np.isfinite(vol) and vol > 0)
            if ok_vol and not issues[i]:
                atom['sigma_xx'] = row['c_strs[1]'] / vol
                atom['sigma_yy'] = row['c_strs[2]'] / vol
                atom['sigma_zz'] = row['c_strs[3]'] / vol
            else:                                             # 있는데 무효 — 키는 남기고 NaN (0 으로 채우지 않는다) + 사유
                for k, c in zip(_SIGMA_KEYS, _CSTR_COLS):
                    v = row[c] if c in present else np.nan
                    atom[k] = (v / vol) if (ok_vol and np.isfinite(v)) else np.nan
                why = list(issues[i])
                if not ok_vol:
                    why.append(f'반경 {row["radius"]!r} → 부피 무효 (σ = c_strs ÷ 부피 불가)')
                atom['c_strs_invalid'] = ' · '.join(why)
        atoms[int(row['id'])] = atom
    return atoms, df


def load_contacts_raw(csv_path):
    df = pd.read_csv(csv_path, low_memory=False)
    for col in df.columns:
        df[col] = pd.to_numeric(df[col], errors='coerce')
    df['id1'] = df['id1'].astype(int)
    df['id2'] = df['id2'].astype(int)
    # Vectorized contact list construction (much faster than iterrows for large files)
    fn = np.sqrt(df['fn_x'].values**2 + df['fn_y'].values**2 + df['fn_z'].values**2)
    ft = np.sqrt(df['ft_x'].values**2 + df['ft_y'].values**2 + df['ft_z'].values**2)
    #  ④b (J20-s · 10-04) — Love–Weber 입자 응력용: 전체 힘 (fx·fy·fz = id1 이 받는 힘 · c_cpl[10–12]) · 접선 성분 · 접촉점
    #  (cp_* = c_cpl[24–26]).  열이 있는 덤프만 (옛 덤프 · 손 픽스처는 없다 → 소비자가 NOT_COMPUTED).  값은 열 배열에서 한 번에 뽑는다
    #  (옛 판의 행마다 .iloc 과 같은 값 — 키 · 값 불변).
    opt = []
    for grp in (('fx', 'fy', 'fz'), ('cp_x', 'cp_y', 'cp_z')):
        if all(g in df.columns for g in grp):
            opt += list(grp)
    keep = ['id1', 'id2', 'fn_x', 'fn_y', 'fn_z', 'ft_x', 'ft_y', 'ft_z', 'contact_area', 'delta'] + opt
    arr = {k: df[k].values for k in keep}
    contacts = []
    for i in range(len(df)):
        c = {
            'id1': int(arr['id1'][i]), 'id2': int(arr['id2'][i]),
            'fn': float(fn[i]),
            'fn_x': float(arr['fn_x'][i]), 'fn_y': float(arr['fn_y'][i]), 'fn_z': float(arr['fn_z'][i]),
            'ft': float(ft[i]),
            'contact_area': float(arr['contact_area'][i]),
            'delta': float(arr['delta'][i]),
            'ft_x': float(arr['ft_x'][i]), 'ft_y': float(arr['ft_y'][i]), 'ft_z': float(arr['ft_z'][i]),
        }
        for k in opt:
            c[k] = float(arr[k][i])
        contacts.append(c)
    print(f"  Loaded {len(contacts)} contacts from {os.path.basename(csv_path)}")
    return contacts, df


def save_results(results, atoms_raw, contacts_raw, df_atom, df_contact,
                 type_map, scale, output_dir):
    area_conv = 1.0 / (scale ** 2) * 1e12

    # Read box dimensions from input_params.json (default 0.05)
    _box_x, _box_y = 0.05, 0.05
    _ip_path = os.path.join(output_dir, 'input_params.json')
    if os.path.exists(_ip_path):
        with open(_ip_path) as _f:
            _ip = json.load(_f)
        _box_x = _ip.get('box_x', 0.05)
        _box_y = _ip.get('box_y', 0.05)

    # Contact Summary
    rows = []
    total_n = 0
    total_area = 0
    am_types_count = sum(1 for v in type_map.values() if 'AM' in v)
    is_bimodal = am_types_count > 1

    for ct, v in results['interface'].items():
        # Standard 모드에서 AM전체-SE는 AM-SE와 동일하므로 생략
        if ct == 'AM전체-SE' and not is_bimodal:
            continue
        rows.append({
            '접촉유형': ct, '접촉수': v['n_contacts'],
            # 접촉 0 인 쌍 (두 상 다 있음 — 측정된 0) 의 평균 면적은 정의되지 않는다 → '—' (LHS-24 (b))
            '접촉면적_mean(μm²)': round(v['mean_area'], 4) if v['mean_area'] is not None else '—',
            '접촉면적_total(μm²)': round(v['total_area'], 2),
        })
        if ct != 'AM전체-SE':
            total_n += v['n_contacts']
            total_area += v['total_area']
    rows.append({
        '접촉유형': 'All',
        '접촉수': total_n,
        '접촉면적_mean(μm²)': round(total_area / total_n, 4) if total_n > 0 else 0,
        '접촉면적_total(μm²)': round(total_area, 2),
    })
    pd.DataFrame(rows).to_csv(os.path.join(output_dir, 'contact_summary.csv'), index=False)

    # Atom Statistics (입자수, 반지름, 영률)
    # Load Young's modulus from input_params.json if available
    input_params = {}
    params_path = os.path.join(output_dir, 'input_params.json')
    if os.path.exists(params_path):
        with open(params_path) as f:
            input_params = json.load(f)

    e_sim_list = input_params.get('youngs_modulus_sim', [])
    # SE: 유효영률 ↔ 실제영률 비례 스케일링
    # 기준: E_eff=1.35 GPa (sim 1.35e6) → E_real=24 GPa
    SE_BASELINE_EFF_SIM = 1.35e6   # baseline E_eff in sim units (Pa)
    SE_BASELINE_REAL_GPA = 24.0    # baseline E_real (GPa)
    AM_REAL_GPA = 140.0            # AM E_real (GPa, 고정)

    rows = []
    type_keys = sorted(type_map.keys())
    for t in type_keys:
        name = type_map[t]
        sub = {aid: a for aid, a in atoms_raw.items() if a['type'] == t}
        if not sub: continue
        rs = [a['radius'] for a in sub.values()]
        r_real = round(np.mean(rs) * scale, 2)

        # Young's modulus: sim value × scale → real value
        e_idx = t - 1  # type 1 → index 0
        if e_idx < len(e_sim_list):
            e_sim = e_sim_list[e_idx]
            e_real = e_sim * scale  # × 1000 → effective real (Pa)
            if e_real >= 1e9:
                e_str = f"{e_real/1e9:.2f} GPa"
            else:
                e_str = f"{e_real/1e6:.1f} MPa"
            # SE: 유효영률(실제영률) — E_real을 E_eff 비율로 스케일링
            if name == 'SE':
                factor = e_sim / SE_BASELINE_EFF_SIM  # 0.5x→0.5, 1.0x→1.0, 1.5x→1.5
                se_real_gpa = SE_BASELINE_REAL_GPA * factor
                e_str = f"{e_str} ({se_real_gpa:.0f} GPa)"
            elif name == 'AM':
                e_str = f"{e_str} ({AM_REAL_GPA:.0f} GPa)"
        else:
            e_str = '-'

        rows.append({
            '입자유형': name,
            '입자수': len(sub),
            '반지름(μm)': r_real,
            '영률': e_str,
        })
    pd.DataFrame(rows).to_csv(os.path.join(output_dir, 'atom_statistics.csv'), index=False)

    # Coordination Summary
    coord = defaultdict(int)
    for c in contacts_raw:
        coord[c['id1']] += 1
        coord[c['id2']] += 1
    rows = []
    for t, name in type_map.items():
        ids = [aid for aid, a in atoms_raw.items() if a['type'] == t]
        if not ids:
            # ★ 덤프에 0개인 타입 = P:S 10:0 의 AM_S 처럼 **설계상** 비는 상이다.
            #   옛 판은 여기서 `np.min(빈 배열)` 로 죽었다 (2026-09-22 실사고,
            #   케이스 260922_092001_0853b1).  퇴화 케이스는 죽는 것이 아니라
            #   `—` 다 — 위 124행 particle_info 루프가 이미 `if not sub: continue`
            #   로 같은 규약을 쓰고 있었고 이 루프만 빠져 있었다.
            #   ⚠ 이 관용이 안전한 **유일한** 이유는 main() 이 계산 **전에**
            #     type_map ↔ 덤프를 대조해 *틀린* map 을 거부하기 때문이다.
            #     그 게이트 없이 관용만 넣으면 틀린 map 이 조용히 통과한다
            #     (실제로 그 크래시가 false-green 을 우연히 막고 있었다).
            rows.append({
                '입자유형': name, '입자수': 0,
                '배위수_mean': '—', '배위수_std': '—',
                '배위수_min': '—', '배위수_max': '—',
            })
            continue
        vals = np.array([coord.get(aid, 0) for aid in ids])
        rows.append({
            '입자유형': name, '입자수': len(ids),
            '배위수_mean': round(float(np.mean(vals)), 1),
            '배위수_std': round(float(np.std(vals)), 1),
            '배위수_min': int(np.min(vals)),
            '배위수_max': int(np.max(vals)),
        })
    pd.DataFrame(rows).to_csv(os.path.join(output_dir, 'coordination_summary.csv'), index=False)

    # Network Summary (comprehensive)
    # 구조 → 계면 → 이온경로(연결성→경로효율→경로품질) → 활성도 → 응력
    perc = results['percolation']
    cn = results['se_se_cn']
    tau = results['tortuosity']
    tau_all = results.get('tortuosity_all') or {}       # 기하 τ 전체판 (10-02) — 옛 results 에는 없다
    ionic = results['ionic_active']
    eff_cond = results.get('effective_conductivity')
    rows = [
        # ── 구조 ──
        {'지표': '── 구조 ──', '값': ''},
        {'지표': 'Porosity(%)', '값': round(results['porosity'], 2)},
        {'지표': '전극두께(μm)', '값': round(results['thickness_um'], 2)},
        # ── 계면 ──
        {'지표': '── 계면 ──', '값': ''},
        {'지표': 'AM-SE Total(μm²)', '값': round(results['interface'].get('AM전체-SE', {}).get('total_area', 0), 2)},
        {'지표': 'SE-SE Total(μm²)', '값': round(results['interface'].get('SE-SE', {}).get('total_area', 0), 2)},
    ]
    # Per-contact 5-case binding-distribution rows. Populated by webapp
    # from full_metrics keys A_binding_share_AM_SE_pct and
    # A_binding_share_total_pct (see coverage_physics_vs_hertzian.py).
    # Each row reports the share of contacts where each of the five
    # candidate areas was selected:
    #   H = Hertzian  (lower bound, π R*δ)
    #   L = LIGGGHTS  (lower bound, DEM-internal)
    #   T = Tabor     (upper cap, F/H)
    #   V = volume    (upper cap, V_overlap/h_min)
    #   G = geom      (upper cap, 2π R_min²)
    rows += [
        {'지표': 'Binding % — AM-SE (H/L/T/V/G)', '값': '-'},
        {'지표': 'Binding % — Total (H/L/T/V/G)', '값': '-'},
    ]
    for lbl, v in results['coverage'].items():
        rows.append({'지표': f'Coverage {lbl}(%)', '값': round(v['mean'], 1)})
    rows += [
        # ── 이온경로: 연결성 ──
        {'지표': '── 이온경로: 연결성 ──', '값': ''},
        {'지표': 'SE-SE CN mean', '값': round(cn['mean'], 2)},
        {'지표': 'SE-SE CN std', '값': round(cn['std'], 2)},
        {'지표': 'SE Cluster 수', '값': f"{perc.get('n_large_components', '-')}(≥10) / {perc['n_components']}"},
        {'지표': 'SE Percolation(%)', '값': round(perc['percolation_pct'], 1)},
        {'지표': 'Top Reachable(%)', '값': round(perc['top_reachable_pct'], 1)},
        # ── 이온경로: 경로 효율 ──
        {'지표': '── 이온경로: 경로 효율 ──', '값': ''},
        {'지표': 'Tortuosity mean', '값': round(tau['mean'], 2) if tau['mean'] else 'N/A'},
        {'지표': 'Tortuosity median', '값': round(tau.get('median', 0), 2) if tau.get('median') else 'N/A'},
        {'지표': 'Tortuosity std', '값': round(tau['std'], 2) if tau['std'] else 'N/A'},
        {'지표': 'GB Density(hops/μm)', '값': '-'},  # placeholder, updated after cluster calc
        # ── 이온경로: 경로 품질 ──
        {'지표': '── 이온경로: 경로 품질 ──', '값': ''},
        {'지표': 'Path Hop Area mean(μm²)', '값': '-'},
        {'지표': 'Path Bottleneck(μm²)', '값': '-'},
        {'지표': 'Path Conductance(μm²)', '값': '-'},
        # ── 활성도 ──
        {'지표': '── 활성도 ──', '값': ''},
    ]
    am_risk = results.get('am_isolation_risk')
    if am_risk:
        rows.append({'지표': 'AM-SE CN mean', '값': round(am_risk['am_se_cn_mean'], 2)})
        # Per-AM-type breakdown (bimodal only: expose AM_P-SE and AM_S-SE separately)
        if 'AM_P_se_cn_mean' in am_risk and 'AM_S_se_cn_mean' in am_risk:
            rows.append({'지표': '  ├ AM_P-SE CN mean', '값': round(am_risk['AM_P_se_cn_mean'], 2)})
            rows.append({'지표': '  ├ AM_S-SE CN mean', '값': round(am_risk['AM_S_se_cn_mean'], 2)})
            rows.append({'지표': '  └ AM-SE CN (surface-weighted)', '값': round(am_risk['am_se_cn_surface_weighted'], 2)})
    rows.append({'지표': 'Ionic Active AM(%)', '값': round(ionic['active_pct'], 1)})
    #  v1.1 ①② — 경로 기준 고립 = 100 − 활성 · 그 분해 (단절 = SE 는 닿았지만 위 띠로 안 이어짐 · 무접촉 = SE 접촉 0)
    rows.append({'지표': 'Ionic Isolated AM(%)', '값': round(100.0 - ionic['active_pct'], 1)})
    rows.append({'지표': '  ├ Isolated: SE not linked(%)', '값': round(ionic['dead_pct'], 1)})
    rows.append({'지표': '  └ Isolated: no SE contact(%)', '값': round(ionic['no_se_pct'], 1)})
    if am_risk:
        rows.append({'지표': 'AM Vulnerable(%)', '값': round(am_risk['vulnerable_pct'], 1)})
        if 'AM_P_vulnerable_pct' in am_risk and 'AM_S_vulnerable_pct' in am_risk:
            rows.append({'지표': '  ├ AM_P Vulnerable(%)', '값': round(am_risk['AM_P_vulnerable_pct'], 1)})
            rows.append({'지표': '  └ AM_S Vulnerable(%)', '값': round(am_risk['AM_S_vulnerable_pct'], 1)})
    # ── 이온전도 ──
    if eff_cond:
        rows.append({'지표': '── 이온전도 ──', '값': ''})
        rows.append({'지표': 'SE Volume Fraction', '값': round(eff_cond['phi_se'], 3)})
        # τ 가 없으면 (관통 SE 없음) σ 비는 정의되지 않는다 — φ 행만 남긴다 (DESC-01 · LHS-24 (c))
        if eff_cond.get('sigma_ratio') is not None:
            sigma_brug_mScm = round(3.0 * eff_cond['sigma_ratio'], 4)
            rows.append({'지표': 'σ_Bruggeman (mS/cm)', '값': sigma_brug_mScm})
            rows.append({'지표': 'σ_brug/σ_grain (Bruggeman)', '값': round(eff_cond['sigma_ratio'], 4)})
    # ── Network Solver (자동 추가) ──
    # These values come from network_conductivity.py merge → full_metrics.json
    # Read from full_metrics if already computed
    met_path = os.path.join(output_dir, 'full_metrics.json')
    if os.path.exists(met_path):
        with open(met_path) as _mf:
            _met = json.load(_mf)
        if _met.get('sigma_full_mScm'):
            rows.append({'지표': '── Network Solver (Hertzian DEM-native) ──', '값': ''})
            rows.append({'지표': 'σ_ionic (mS/cm)', '값': round(_met['sigma_full_mScm'], 4)})
            if _met.get('R_brug_over_full'):
                rows.append({'지표': 'R_brug (과대추정 배수)', '값': f"{_met['R_brug_over_full']:.1f}×"})
            if _met.get('bulk_resistance_fraction'):
                rows.append({'지표': 'Constriction 비율(%)', '값': round((1-_met['bulk_resistance_fraction'])*100, 1)})
            if _met.get('electronic_sigma_full_mScm'):
                rows.append({'지표': 'σ_electronic (mS/cm)', '값': round(_met['electronic_sigma_full_mScm'], 2)})
            if _met.get('thermal_sigma_full_mScm'):
                rows.append({'지표': 'σ_thermal (mS/cm equiv)', '값': round(_met['thermal_sigma_full_mScm'], 3)})

            # ── Physics-mode (Tabor+volume, literature-anchored, 0 free params) ──
            if _met.get('sigma_full_mScm_physics') is not None:
                rows.append({'지표': '── Physics (Plastic film, Tabor+volume) ──', '값': ''})
                sfP = _met['sigma_full_mScm_physics']
                rows.append({'지표': 'σ_ionic [physics] (mS/cm)', '값': round(sfP, 4)})
                sfH = _met.get('sigma_full_mScm') or 0
                if sfH > 0:
                    rows.append({'지표': 'σ_ionic ratio (physics/Hertzian)',
                                 '값': f"{sfP / sfH:.2f}×"})
                if _met.get('electronic_sigma_full_mScm_physics') is not None:
                    rows.append({'지표': 'σ_electronic [physics] (mS/cm)',
                                 '값': round(_met['electronic_sigma_full_mScm_physics'], 2)})
                if _met.get('thermal_sigma_full_mScm_physics') is not None:
                    rows.append({'지표': 'σ_thermal [physics] (mS/cm equiv)',
                                 '값': round(_met['thermal_sigma_full_mScm_physics'], 3)})
    # ── 응력 ──
    #  옛 줄 (Stress CV(%) · σ_<상>/σ_mean) = LIGGGHTS stress/atom (접촉 virial 50/50 분할) · 대각 성분 — 이름표는 웹앱이 정정한다 (LHS-29).
    #  ④b (J20-s · 10-04) Love–Weber 줄은 그 뒤에 — 상태가 OK 일 때만 (실패 · 열 없음 = 줄 없음 · 웹앱이 '—' + 상태로 채운다).
    #  ★ LHS-33 (좁은 개정 · 10-05) — 옛 네 줄이 무효 · 미정의 (status ≠ computed) 면 값 '—' + 상태 줄 (상태 — 사유) · 0 으로 안 채움.
    stress = results.get('stress')
    stress_lw = results.get('stress_lw') or {}
    if stress or stress_lw.get('status') == 'OK':
        rows.append({'지표': '── 응력 ──', '값': ''})
    if stress:
        _scv = stress.get('vm_cv')
        rows.append({'지표': 'Stress CV(%)', '값': round(_scv, 1) if _scv is not None else '—'})
        for tn in ['AM_P', 'AM_S', 'SE']:
            if tn in stress['type_stress']:
                _sr = stress['type_stress'][tn]['ratio']
                rows.append({'지표': f'σ_{tn}/σ_mean', '값': round(_sr, 3) if _sr is not None else '—'})
        if stress.get('status') not in (None, STRESS_CV_COMPUTED):
            rows.append({'지표': STRESS_CV_STATUS_ROW,
                         '값': f"{stress['status']} — {stress.get('reason')}" if stress.get('reason') else stress['status']})
    if stress_lw.get('status') == 'OK':
        rows.append({'지표': 'Stress CV — Love–Weber (%)', '값': round(stress_lw['vm_cv'], 1)})
        for tn in ['AM_P', 'AM_S', 'SE']:
            if tn in stress_lw['type_stress']:
                rows.append({'지표': f'σ_{tn}/σ_mean — Love–Weber', '값': round(stress_lw['type_stress'][tn]['ratio'], 3)})
        if stress_lw.get('vm_cv_nowall') is not None:
            rows.append({'지표': 'Stress CV — Love–Weber · 벽 접촉 제외 (%)', '값': round(stress_lw['vm_cv_nowall'], 1)})
            for tn in ['AM_P', 'AM_S', 'SE']:
                if tn in (stress_lw.get('type_stress_nowall') or {}):
                    rows.append({'지표': f'σ_{tn}/σ_mean — Love–Weber · 벽 접촉 제외',
                                 '값': round(stress_lw['type_stress_nowall'][tn]['ratio'], 3)})
        _bt = stress_lw['wall'].get('by_type', {})
        _fr = [f"{tn} {100 * _bt[tn]['frac_wall']:.1f}" for tn in ['AM_P', 'AM_S', 'SE']
               if tn in _bt and _bt[tn].get('frac_wall') is not None]
        if _fr:
            rows.append({'지표': '벽 접촉 입자 (%) — 바닥 · 판', '값': ' · '.join(_fr)})
    pd.DataFrame(rows).to_csv(os.path.join(output_dir, 'network_summary.csv'), index=False)

    # Auto-detect P:S ratio from mass (count × volume × density)
    # NCM811 density = 4800 kg/m³ for both AM_P and AM_S
    am_density = 4800  # kg/m³ (NCM811)
    am_p_atoms = [a for a in atoms_raw.values() if type_map.get(a['type']) == 'AM_P']
    am_s_atoms = [a for a in atoms_raw.values() if type_map.get(a['type']) == 'AM_S']

    # Standard mode: type_map has 'AM' (not AM_P/AM_S)
    # Determine if it's P or S from radius (AM_P ≈ 6μm, AM_S ≈ 2μm in sim units)
    am_generic = [a for a in atoms_raw.values() if type_map.get(a['type']) == 'AM']
    if am_generic and not am_p_atoms and not am_s_atoms:
        avg_r = np.mean([a['radius'] for a in am_generic])
        # In sim units: AM_P radius ≈ 0.006, AM_S radius ≈ 0.002
        if avg_r > 0.004:  # large AM → P only
            am_p_atoms = am_generic
        else:  # small AM → S only
            am_s_atoms = am_generic

    am_p_mass = sum(am_density * 4/3 * np.pi * a['radius']**3 for a in am_p_atoms)
    am_s_mass = sum(am_density * 4/3 * np.pi * a['radius']**3 for a in am_s_atoms)

    if am_p_mass > 0 and am_s_mass > 0:
        total_am_mass = am_p_mass + am_s_mass
        p_frac = am_p_mass / total_am_mass
        # Round to nearest 10% step: 0.3 → 3:7, 0.5 → 5:5, 0.7 → 7:3
        p_pct = round(p_frac * 10)
        s_pct = 10 - p_pct
        ps_ratio = f"{p_pct}:{s_pct}"
    elif am_p_mass > 0 and am_s_mass == 0:
        ps_ratio = "10:0"
    elif am_s_mass > 0 and am_p_mass == 0:
        ps_ratio = "0:10"
    else:
        ps_ratio = ""

    # Auto-detect AM:SE mass ratio
    se_density = 2000  # kg/m³ (DEM 시뮬레이션에서 사용한 SE 밀도)
    se_atoms = [a for a in atoms_raw.values() if type_map.get(a['type']) == 'SE']
    total_am_mass_all = am_p_mass + am_s_mass
    se_mass = sum(se_density * 4/3 * np.pi * a['radius']**3 for a in se_atoms)
    if total_am_mass_all > 0 and se_mass > 0:
        total_mass = total_am_mass_all + se_mass
        am_pct = round(total_am_mass_all / total_mass * 100)  # nearest 1%
        se_pct = 100 - am_pct
        am_se_ratio = f"{am_pct}:{se_pct}"
    else:
        am_se_ratio = ""

    # Particle counts and radii per type
    particle_info = {}
    for t, name in type_map.items():
        sub = [a for a in atoms_raw.values() if a['type'] == t]
        if sub:
            particle_info[f'n_{name}'] = len(sub)
            particle_info[f'r_{name}'] = round(np.mean([a['radius'] for a in sub]) * scale, 2)

    # Full metrics JSON
    metrics = {
        'porosity': results['porosity'],
        # 쌍 렌즈 union · 겹침 비율 — ε_sphere 와 **같은 판 · 같은 상자** 로 이미 계산돼 있던 값 (dem_analysis_core.calc_porosity_dual).
        #   옛 판은 저장하지 않아 파이프라인 2e (recompute_porosity_dual) 만 채웠고, 2e 가 없는 재분석 경로
        #   (batch_rerun_physics · archive_reanalyze · stop_after contact/coverage) 에서는 사라졌다 (LHS-24 (d)).
        #   ⚠ 이 union 은 벽 밖 부피를 빼지 않아 정확 union 보다 **낮다** — 상한이 아니다 (SELF-72).
        'porosity_spheresum': results.get('porosity_spheresum', results['porosity']),
        'porosity_union': results.get('porosity_union'),
        'overlap_fraction_pct': results.get('overlap_fraction_pct'),
        # 정확 union (몬테카를로 · 같은 판 · 상자 · 벽 밖 제외) · 질량 보존 두께 · φ — 인계표와 같은 규약 (웹앱 ③ · J20-l · J20-e (라))
        **{k: (results.get('union_exact') or {}).get(k) for k in (
            'porosity_union_exact_pct', 'porosity_union_exact_se_pct', 'union_exact_mc_n', 'union_exact_mc_seed',
            'union_exact_status', 'wall_overhang_over_Vbox_pct', 'porosity_union_pair_clipped_pct', 'union_pair_upper_bound_ok',
            'se_of_solid_vol', 'thickness_mass_conserving_um', 'phi_se_mass_conserving', 'phi_am_mass_conserving')},
        'thickness_um': results['thickness_um'],
        'plate_z_source': results['plate_z_source'],
        'ps_ratio': ps_ratio,
        'am_se_ratio': am_se_ratio,
        'se_se_cn': cn['mean'],
        'se_se_cn_std': cn['std'],
        # F2: percolating-only and area-weighted CN (NEW)
        'se_se_cn_perc': cn.get('mean_perc'),
        'se_se_cn_eff_area': cn.get('cn_eff_area'),
        'se_se_cn_eff_area_perc': cn.get('cn_eff_area_perc'),
        'se_se_cn_n_perc': cn.get('n_perc'),
        # F1: plastic-augmented CN (NEW — counts pairs within h_spread)
        'se_se_cn_aug': cn.get('mean_aug'),
        'se_se_cn_aug_std': cn.get('std_aug'),
        'se_se_cn_aug_n_extra': cn.get('n_extra_aug'),
        'se_se_cn_aug_h_spread_sim': cn.get('h_spread_sim'),
        'percolation_pct': perc['percolation_pct'],
        'top_reachable_pct': perc['top_reachable_pct'],
        'n_components': perc['n_components'],
        'n_large_components': perc.get('n_large_components', 0),
        'tortuosity_mean': tau['mean'],
        'tortuosity_median': tau.get('median'),
        'tortuosity_std': tau['std'],
        'tortuosity_use_median': tau.get('use_median', False),
        'tortuosity_recommended': tau.get('recommended', tau['mean']),
        #  기하 τ 전체판 (1저자 10-02) — 바닥 띠 관통 SE 전부 → 위쪽 띠 SE 최단 경로 (`calc_tortuosity_all` · 표본 200 쌍 아님 · 길이만)
        'tortuosity_all_mean': tau_all.get('mean'),
        'tortuosity_all_median': tau_all.get('median'),
        'tortuosity_all_std': tau_all.get('std'),
        'tortuosity_all_n': tau_all.get('n'),
        'tortuosity_all_n_sources': tau_all.get('n_sources'),
        'tortuosity_all_recommended': tau_all.get('recommended'),
        'ionic_active_pct': ionic['active_pct'],
        #  v1.1 ② (1저자 비준 10-01 · LHS 인계) — 경로 기준 고립 (= 100 − 활성) 의 분해.  calc_ionic_active_am 이 계산만 하고 버리던 값:
        #   단절 = SE 는 닿았지만 그 SE 가 위 띠 (분리막 쪽) 로 안 이어짐 · 무접촉 = SE 접촉 0.  활성 + 단절 + 무접촉 = 100 (전체 · 상별).
        'ionic_dead_pct': ionic['dead_pct'],
        'ionic_no_se_pct': ionic['no_se_pct'],
        #  v1.1 ① — 경로 기준 고립 (이온이 분리막 쪽에서 닿을 수 없는 AM) = 100 − 활성 = 단절 + 무접촉.  인계표 열과 같은 이름.
        #   ≠ am_vulnerable_pct (고립 **위험** = SE 접촉 0–1 개 · calc_am_isolation_risk) — 접촉 둘 이상인데 고립일 수도, 하나뿐인데 활성일 수도 있다.
        'am_ionic_isolated_pct': 100.0 - ionic['active_pct'],
        **{f'{lbl}_ionic_{s}_pct': ionic[f'{lbl}_{s}_pct']
           for lbl in sorted({v for v in type_map.values() if 'AM' in v})
           for s in ('active', 'dead', 'no_se') if f'{lbl}_{s}_pct' in ionic},
    }

    # GB density and path conductance from cluster paths (exact per-hop contact area)
    perc_clusters_path = os.path.join(output_dir, 'se_clusters.json')
    # Will be computed later, add placeholder; actual values filled after cluster computation

    metrics.update(particle_info)
    for ct, v in results['interface'].items():
        safe = ct.replace('-', '_')
        metrics[f'area_{safe}_total'] = v['total_area']
        metrics[f'area_{safe}_n'] = v['n_contacts']
        if v['mean_area'] is not None:                  # 접촉 0 쌍은 평균이 없다 — 키를 쓰지 않는다 (LHS-24 (b))
            metrics[f'area_{safe}_mean'] = v['mean_area']
    for lbl, v in results['coverage'].items():
        metrics[f'coverage_{lbl}_mean'] = v['mean']
        metrics[f'coverage_{lbl}_std'] = v['std']
    # Stress (relative) — 옛 키 = LIGGGHTS stress/atom (접촉 virial 50/50 분할) · 대각 성분 (값 · 키 불변 · LHS-29)
    #   ★ LHS-33 (좁은 개정 · 1저자 비준 10-05 · Codex Q7) — 정상 입력은 정의 · 수치 · 키 그대로.  무효 · 미정의 (c_strs 없음 · 입력 무효 ·
    #   평균 VM 0) 는 같은 키에 None (null) — 옛 판은 0 (거짓 최고 등급) 이거나 키를 빼 소비자의 `get(…, 0)` 이 0 으로 읽었다.
    #   stress_cv_status · stress_cv_contract (metrics_json.STRESS_CV_CONTRACT · 옛 세대와 가른다) · stress_cv_reason 은 상태와 무관하게 남긴다.
    #   RGLR2-03 (10-05) — stress_cv_vm_stable_n = 거의 정수압이라 안정식 ½Σ(σ_ii − σ_jj)² 로 다시 센 입자 수 (계산 전 무효면 키 없음).
    stress = results.get('stress')
    if stress:
        metrics['stress_cv'] = stress['vm_cv']
        for tn, sv in stress['type_stress'].items():
            metrics[f'stress_ratio_{tn}'] = sv['ratio']
        metrics['stress_z_layer_cv'] = stress['z_layer_cv']
        if stress.get('status') is not None:
            metrics['stress_cv_status'] = stress['status']
            metrics['stress_cv_contract'] = stress.get('contract')
            if stress.get('reason'):
                metrics['stress_cv_reason'] = stress['reason']
            if stress.get('vm_stable_recomputed_n') is not None:   # RGLR2-03 — 거의 정수압이라 안정식으로 다시 센 입자 수 (출처 · 0 = 전부 옛 식)
                metrics['stress_cv_vm_stable_n'] = stress['vm_stable_recomputed_n']
    # ④b Love–Weber (J20-s · 1저자 비준 10-04) — 새 키만 더한다.  상태가 OK 가 아니면 값 키를 쓰지 않는다 (0 으로 안 채움).
    #   RGL-06 (10-05): 상태는 OK · NOT_COMPUTED · FAILED · UNDEFINED (평균 VM 0 = 무하중 — CV · 비 미정의) — OK 일 때만 값 키.
    #   메타 (계약 · 양의 이름 한정 · 덱 가정 미검증 · 입력 출처) 는 상태와 무관하게 남긴다 — 소비자가 계약 v2 로 옛 결과와 가른다.
    stress_lw = results.get('stress_lw')
    if stress_lw:
        metrics['stress_lw_status'] = stress_lw['status']
        metrics['stress_lw_definition'] = stress_lw['definition']
        for mk in ('contract', 'quantity', 'assumptions_unverified'):
            if stress_lw.get(mk) is not None:
                metrics[f'stress_lw_{mk}'] = stress_lw[mk]
        for ck, cv_ in (stress_lw.get('checks') or {}).items():
            metrics[f'stress_lw_check_{ck}'] = cv_
        _pv = stress_lw.get('provenance') or {}
        if _pv:
            metrics['stress_lw_input_digest_atoms'] = _pv.get('atoms_csv_digest')
            metrics['stress_lw_input_digest_contacts'] = _pv.get('contacts_csv_digest')
            metrics['stress_lw_timestep'] = _pv.get('timestep')
        if stress_lw['status'] == 'OK':
            metrics['stress_cv_lw'] = stress_lw['vm_cv']
            for tn, sv in stress_lw['type_stress'].items():
                metrics[f'stress_ratio_{tn}_lw'] = sv['ratio']
            if stress_lw.get('vm_cv_nowall') is not None:
                metrics['stress_cv_lw_nowall'] = stress_lw['vm_cv_nowall']
                for tn, sv in (stress_lw.get('type_stress_nowall') or {}).items():
                    metrics[f'stress_ratio_{tn}_lw_nowall'] = sv['ratio']
            if stress_lw.get('nowall_status') is not None:
                metrics['stress_lw_nowall_status'] = stress_lw['nowall_status']
            _w = stress_lw['wall']
            metrics['stress_lw_wall_scope'] = _w['scope']
            if _w.get('nowall_scope') is not None:
                metrics['stress_lw_nowall_scope'] = _w['nowall_scope']
            metrics['stress_lw_plate_flag'] = _w['plate_flag']
            metrics['stress_lw_n_wall_floor'] = _w['n_floor']
            if _w['n_plate'] is not None:
                metrics['stress_lw_n_wall_plate'] = _w['n_plate']
            for tn, bt in _w['by_type'].items():
                metrics[f'stress_lw_floor_frac_{tn}'] = bt['frac_floor']
                if bt['frac_wall'] is not None:
                    metrics[f'stress_lw_wall_frac_{tn}'] = bt['frac_wall']
            metrics['stress_lw_n_no_contact'] = stress_lw['n_no_contact']
            metrics['stress_lw_asym_frob_median'] = stress_lw['asym_frob_median']
    # New metrics
    force_dist = results.get('force_dist', {})
    for ct, v in force_dist.items():
        safe = ct.replace('-', '_')
        metrics[f'fn_{safe}_mean'] = v['mean']
        metrics[f'fn_{safe}_max'] = v['max']
    cp = results.get('contact_pressure', {})
    if cp.get('overall'):
        metrics['contact_pressure_mean'] = cp['overall']['mean']
        metrics['contact_pressure_max'] = cp['overall']['max']
    overlap = results.get('overlap_ratio')
    if overlap:
        metrics['overlap_mean'] = overlap['mean']
        metrics['overlap_max'] = overlap['max']
        metrics['overlap_pct_above_5'] = overlap['pct_above_5']
    am_risk = results.get('am_isolation_risk')
    if am_risk:
        metrics['am_vulnerable_pct'] = am_risk['vulnerable_pct']
        metrics['am_se_cn_mean'] = am_risk['am_se_cn_mean']
        # 2026-09-30 (LHS 인계 7a · J20-k (C)) — AM 전 입자의 AM–SE 분포 (std · median · max).  옛 코드는 std 를
        # 계산만 하고 버렸고 median · max 는 상별로만 내보냈다 (`--selftest` ④–⑥ · ⑪).  추가만 — 옛 키는 그대로.
        for key in ('am_se_cn_std', 'am_se_cn_median', 'am_se_cn_max'):
            if key in am_risk:
                metrics[key] = am_risk[key]
        # Per-AM-type AM-SE CN (bimodal): for COMSOL Butler-Volmer per-phase
        for key in ['AM_P_se_cn_mean', 'AM_P_se_cn_std', 'AM_P_se_cn_median', 'AM_P_se_cn_max',
                    'AM_P_n_particles', 'AM_P_vulnerable_pct',
                    'AM_S_se_cn_mean', 'AM_S_se_cn_std', 'AM_S_se_cn_median', 'AM_S_se_cn_max',
                    'AM_S_n_particles', 'AM_S_vulnerable_pct',
                    'am_se_cn_surface_weighted']:
            if key in am_risk:
                metrics[key] = am_risk[key]
    eff_cond = results.get('effective_conductivity')
    if eff_cond:
        # φ 는 τ 와 무관한 기하량 — τ 가 없어도 싣는다 (DESC-01 · LHS-24 (c)) · σ 비는 τ 가 있을 때만
        if eff_cond.get('sigma_ratio') is not None:
            metrics['sigma_ratio'] = eff_cond['sigma_ratio']
        metrics['phi_se'] = eff_cond['phi_se']
        metrics['phi_am'] = 1.0 - eff_cond['phi_se'] - results['porosity'] / 100.0
    am_am_cn = results.get('am_am_cn')
    if am_am_cn and am_am_cn.get('n_am', 0) > 0:
        metrics['am_am_cn'] = am_am_cn['mean']
        metrics['am_am_cn_std'] = am_am_cn['std']
        metrics['am_am_n_contacts'] = am_am_cn['n_contacts']
        metrics['am_am_mean_area'] = am_am_cn['mean_area']
        metrics['am_am_total_area'] = am_am_cn['total_area']
    # Target pressure from input_params (sim → real MPa)
    if input_params.get('target_press_sim'):
        metrics['target_pressure_mpa'] = round(input_params['target_press_sim'] * scale, 1)

    # E_SE effective GPa (for scaling law / predictor)
    e_sim_list_met = input_params.get('youngs_modulus_sim', [])
    if len(e_sim_list_met) >= 2:
        e_se_eff_gpa = e_sim_list_met[-1] * scale / 1e9  # sim Pa × scale → GPa
        metrics['e_se_eff_gpa'] = round(e_se_eff_gpa, 4)

    # ── Data quality warnings ──
    warnings = []
    tau = results['tortuosity']
    perc_data = results['percolation']
    overlap = results.get('overlap_ratio')

    # 1. Tortuosity anomaly: mean > 5 or std/mean > 0.5
    if tau.get('mean') and tau['mean'] > 5:
        med_info = f" (median={tau.get('median', 0):.2f}, using median)" if tau.get('use_median') else ""
        warnings.append({'type': 'tortuosity_extreme', 'severity': 'critical',
                        'msg': f"Tortuosity mean={tau['mean']:.1f} (>5): RVE artifact{med_info}"})
    elif tau.get('use_median'):
        warnings.append({'type': 'tortuosity_unstable', 'severity': 'warning',
                        'msg': f"Tortuosity mean={tau['mean']:.2f} vs median={tau['median']:.2f}: high dispersion, using median"})
    elif tau.get('mean') and tau['mean'] > 3:
        warnings.append({'type': 'tortuosity_high', 'severity': 'warning',
                        'msg': f"Tortuosity mean={tau['mean']:.1f} (>3): unusually tortuous paths"})

    # 2. Low percolation
    #  ⛔ **전거 없는 문턱이다** (원장 `GAP3-40`, 2026-09-18).  `85` · `95` · `3.5` 는 주석뿐이고
    #    문헌·코퍼스 어느 쪽에도 근거가 없다.  그런데 `critical` 은 사용자 화면에 뜬다.
    #  ★ 실측 (n=157, `docs/data/case_master.csv`): σ_ion 이 두 양에 **단조**로 붙긴 하지만
    #    **이 자리에 무릎이 없다** — percolation 90–95 구간의 σ_ion 중앙(0.0581)이
    #    95–98 구간(0.0497)보다 **오히려 높다**.  se_se_cn 도 3.0–3.5(0.0570)가
    #    3.5–4.0(0.0507)보다 높다.  진짜 붕괴는 각각 **85 아래 · 3.0 아래**에서 일어난다.
    #  ⚠⚠ 그 측정조차 **순환적**이다 — `percolation_pct` · `se_se_cn` · `sigma_full_mScm` 이
    #    **같은 Kirchhoff 망**에서 나온다.  망이 끊기면 σ 가 낮은 것은 정의상 그렇다
    #    (corr = +0.62 · +0.79).  ⇒ 우리 코퍼스는 이 문턱을 **세워 줄 수 없다**.
    #  ⇒ 최소 조치: 값은 **그대로 두고** `critical` → `warning` 으로 낮추고, 전거가 없다는
    #    사실을 **메시지에 적는다**.  값을 바꾸면 그것도 전거 없는 수가 된다.
    if perc_data.get('percolation_pct', 100) < 85:
        warnings.append({'type': 'percolation_low', 'severity': 'warning',
                        'msg': f"Percolation={perc_data['percolation_pct']:.1f}% (<85%): "
                               f"SE network likely fragmented.  ⚠ 이 문턱은 **관례이며 전거가 없다** (원장 `GAP3-40`) — 실측상 이 자리에 무릎이 없다.  진단 참고용."})
    elif perc_data.get('percolation_pct', 100) < 95:
        warnings.append({'type': 'percolation_marginal', 'severity': 'warning',
                        'msg': f"Percolation={perc_data['percolation_pct']:.1f}% (<95%): "
                               f"SE network connectivity marginal.  ⚠ 이 문턱은 **관례이며 전거가 없다** (원장 `GAP3-40`) — 실측상 이 자리에 무릎이 없다.  진단 참고용."})

    # 3. High porosity (poor compaction)
    if results.get('porosity', 0) > 25:
        warnings.append({'type': 'porosity_high', 'severity': 'warning',
                        'msg': f"Porosity={results['porosity']:.1f}% (>25%): insufficient compaction"})

    # 5. Too few particles (RVE representativeness)
    total_particles = sum(particle_info.get(f'n_{name}', 0) for name in type_map.values())
    if total_particles < 500:
        warnings.append({'type': 'rve_small', 'severity': 'warning',
                        'msg': f"Total particles={total_particles} (<500): RVE may not be representative"})

    # 6. SE-SE CN near percolation threshold
    #  ⛔ 위 `GAP3-40` 주석과 같은 사유 — `critical` → `warning`, 전거 없음을 메시지에 적는다.
    if cn.get('mean', 10) < 3.5:
        warnings.append({'type': 'cn_critical', 'severity': 'warning',
                        'msg': f"SE-SE CN={cn['mean']:.1f} (<3.5): may be near percolation threshold.  ⚠ 이 문턱은 **관례이며 전거가 없다** (원장 `GAP3-40`) — 실측상 이 자리에 무릎이 없다.  진단 참고용."})

    # (Electronic-Active-AM warnings are network-solver dependent and are
    # emitted by webapp._refresh_post_network_warnings AFTER the solver runs.
    # The previous code here read full_metrics.json before it was written on
    # cold runs, so it never actually fired.)

    # ── Auto-DB: flatten fracture-stage data into top-level metrics keys ──
    # results['fracture'] is produced by run_full_analysis (Auerbach + Lawn
    # 1998 classifier). Each key (n_intact_AM_AM, fracture_index_force, etc.)
    # is written as a flat scalar so build_metrics_db absorbs it without
    # nested-dict flattening logic.
    fracture = (results.get('fracture') or {})
    if fracture:
        metrics.update(fracture)

    if warnings:
        metrics['warnings'] = warnings
        metrics['warning_count'] = len(warnings)
        for w in warnings:
            print(f"  ⚠ [{w['severity']}] {w['msg']}")

    with open(os.path.join(output_dir, 'full_metrics.json'), 'w') as f:
        json.dump(metrics, f, indent=2, default=_json_default)

    # Save percolation sets for 3D viewer
    perc = results['percolation']
    perc_sets = {
        'top_reachable': list(perc.get('top_reachable_se', set())),
        'bottom_se': list(perc.get('bottom_se', set())),
        'top_se': list(perc.get('top_se', set())),
    }
    with open(os.path.join(output_dir, 'percolation_sets.json'), 'w') as f:
        json.dump(perc_sets, f)

    # Save SE cluster data for 3D viewer (cluster membership + paths)
    if 'graph' in perc:
        import networkx as nx
        G = perc['graph']
        components = list(nx.connected_components(G))
        bottom_se = perc.get('bottom_se', set())
        top_se = perc.get('top_se', set())

        clusters = []
        for comp in components:
            if len(comp) < 2:
                continue
            comp_list = list(comp)
            has_bottom = len(comp & bottom_se) > 0
            has_top = len(comp & top_se) > 0
            percolating = has_bottom and has_top

            cluster_info = {
                'ids': comp_list,
                'size': len(comp),
                'percolating': percolating,
                'path': None,
            }

            # Find multiple shortest paths, sorted by closeness to τ mean
            if percolating:
                src_candidates = list(comp & bottom_se)
                tgt_candidates = list(comp & top_se)
                import random
                random.seed(42)
                random.shuffle(src_candidates)
                random.shuffle(tgt_candidates)

                # Build contact area lookup: (id1,id2) → area (sim units)
                contact_area_map = {}
                for c in contacts_raw:
                    i1, i2 = c['id1'], c['id2']
                    contact_area_map[(min(i1,i2), max(i1,i2))] = c['contact_area']

                area_conv = 1.0 / (scale ** 2) * 1e12  # sim m² → real μm²

                all_paths = []
                seen_pairs = set()
                for si in range(min(15, len(src_candidates))):
                    for ti in range(min(15, len(tgt_candidates))):
                        if len(all_paths) >= 30:
                            break
                        src = src_candidates[si]
                        tgt = tgt_candidates[ti]
                        pair = (src, tgt)
                        if pair in seen_pairs:
                            continue
                        seen_pairs.add(pair)
                        try:
                            path = nx.shortest_path(G, src, tgt, weight='distance')
                            path_len = 0
                            # Exact per-hop contact area and resistance
                            hop_areas = []  # real μm²
                            sum_inv_a = 0  # Σ(1/A_i) for resistance
                            for ki in range(len(path)-1):
                                a1, a2 = atoms_raw[path[ki]], atoms_raw[path[ki+1]]
                                dx = abs(a1['x'] - a2['x'])
                                dy = abs(a1['y'] - a2['y'])
                                dz = a1['z'] - a2['z']
                                dx = min(dx, _box_x - dx)
                                dy = min(dy, _box_y - dy)
                                path_len += np.sqrt(dx**2 + dy**2 + dz**2)
                                # Lookup actual contact area
                                pair_key = (min(path[ki], path[ki+1]), max(path[ki], path[ki+1]))
                                ca = contact_area_map.get(pair_key, 0)
                                ca_real = ca * area_conv  # → μm²
                                hop_areas.append(ca_real)
                                if ca_real > 0:
                                    sum_inv_a += 1.0 / ca_real
                            z_dist = abs(atoms_raw[tgt]['z'] - atoms_raw[src]['z'])
                            n_hop = len(path) - 1
                            if z_dist > 0:
                                gb_density = round(n_hop / (z_dist * scale), 3)  # hops/μm
                                path_conductance = round(1.0 / sum_inv_a, 6) if sum_inv_a > 0 else 0  # μm² (effective)
                                all_paths.append({
                                    'ids': path,
                                    'tortuosity': round(path_len / z_dist, 2),
                                    'path_length': round(path_len * scale, 1),
                                    'z_distance': round(z_dist * scale, 1),
                                    'n_hop': n_hop,
                                    'gb_density': gb_density,
                                    'path_conductance': path_conductance,
                                    'hop_area_mean': round(np.mean(hop_areas), 4) if hop_areas else 0,
                                    'hop_area_min': round(min(hop_areas), 4) if hop_areas else 0,
                                })
                        except nx.NetworkXNoPath:
                            pass
                    if len(all_paths) >= 30:
                        break
                if all_paths:
                    # Sort: best τ (1~10), mean τ (11~20), worst τ (21~30)
                    tau_mean = results['tortuosity'].get('mean', 0) or 0
                    all_paths.sort(key=lambda p: p['tortuosity'])  # ascending
                    best = all_paths[:10]  # lowest τ
                    worst = all_paths[-10:] if len(all_paths) > 20 else all_paths[10:]
                    # mean-close: sort middle by closeness to mean
                    middle = [p for p in all_paths[10:] if p not in worst] if len(all_paths) > 10 else []
                    middle.sort(key=lambda p: abs(p['tortuosity'] - tau_mean))
                    middle = middle[:10]
                    paths_list = best + middle + worst
                    # Tag each path
                    for i, p in enumerate(paths_list):
                        if i < 10:
                            p['category'] = 'best'
                        elif i < 20:
                            p['category'] = 'mean'
                        else:
                            p['category'] = 'worst'
                    cluster_info['path'] = paths_list[0]
                    cluster_info['paths'] = paths_list

            clusters.append(cluster_info)

        # Sort by size (largest first)
        clusters.sort(key=lambda c: c['size'], reverse=True)

        # Build SE id → cluster index map
        se_cluster_map = {}
        for i, cl in enumerate(clusters):
            for sid in cl['ids']:
                se_cluster_map[sid] = i

        with open(os.path.join(output_dir, 'se_clusters.json'), 'w') as f:
            json.dump({'clusters': clusters, 'se_cluster_map': se_cluster_map}, f)

        # Update metrics with GB density and path conductance from percolating cluster paths
        all_perc_paths = []
        for cl in clusters:
            if cl.get('paths'):
                all_perc_paths.extend(cl['paths'])
        if all_perc_paths:
            gb_densities = [p['gb_density'] for p in all_perc_paths if 'gb_density' in p]
            conductances = [p['path_conductance'] for p in all_perc_paths if p.get('path_conductance', 0) > 0]
            hop_areas = [p['hop_area_mean'] for p in all_perc_paths if 'hop_area_mean' in p]
            hop_area_mins = [p['hop_area_min'] for p in all_perc_paths if 'hop_area_min' in p]

            metrics_update = {}
            if gb_densities:
                metrics_update['gb_density_mean'] = round(float(np.mean(gb_densities)), 3)
            if conductances:
                metrics_update['path_conductance_mean'] = round(float(np.mean(conductances)), 6)
            if hop_areas:
                metrics_update['path_hop_area_mean'] = round(float(np.mean(hop_areas)), 4)
            if hop_area_mins:
                metrics_update['path_hop_area_min_mean'] = round(float(np.mean(hop_area_mins)), 4)

            # Re-read and update full_metrics.json
            metrics_path = os.path.join(output_dir, 'full_metrics.json')
            if os.path.exists(metrics_path):
                with open(metrics_path) as f:
                    existing = json.load(f)
                existing.update(metrics_update)
                with open(metrics_path, 'w') as f:
                    json.dump(existing, f, indent=2, default=_json_default)

            # Update network_summary.csv placeholders with actual values
            ns_path = os.path.join(output_dir, 'network_summary.csv')
            if os.path.exists(ns_path):
                ns_df = pd.read_csv(ns_path)
                update_map = {}
                if gb_densities:
                    update_map['GB Density(hops/μm)'] = round(float(np.mean(gb_densities)), 3)
                if hop_areas:
                    update_map['Path Hop Area mean(μm²)'] = round(float(np.mean(hop_areas)), 4)
                if hop_area_mins:
                    update_map['Path Bottleneck(μm²)'] = round(float(np.mean(hop_area_mins)), 4)
                if conductances:
                    update_map['Path Conductance(μm²)'] = round(float(np.mean(conductances)), 6)
                for label, val in update_map.items():
                    mask = ns_df['지표'] == label
                    if mask.any():
                        ns_df.loc[mask, '값'] = str(val)
                ns_df.to_csv(ns_path, index=False)

    # Force chain data for 3D viewer
    force_chains = []
    fn_values = []
    for c in contacts_raw:
        fn = c.get('fn', 0) or np.sqrt(c.get('fn_x', 0)**2 + c.get('fn_y', 0)**2 + c.get('fn_z', 0)**2)
        fn_values.append(fn)
    fn_threshold = np.percentile(fn_values, 90) if fn_values else 0  # top 10%
    print(f"  Force chains: {len(fn_values)} contacts, threshold={fn_threshold:.6f}, max fn={max(fn_values) if fn_values else 0:.6f}")
    for c in contacts_raw:
        if c['id1'] in atoms_raw and c['id2'] in atoms_raw:
            fn = c.get('fn', 0) or np.sqrt(c.get('fn_x', 0)**2 + c.get('fn_y', 0)**2 + c.get('fn_z', 0)**2)
            if fn >= fn_threshold:
                a1, a2 = atoms_raw[c['id1']], atoms_raw[c['id2']]
                t1 = type_map.get(a1['type'], '?')
                t2 = type_map.get(a2['type'], '?')
                force_chains.append({
                    'p1': [a1['x'] * scale, a1['z'] * scale, a1['y'] * scale],
                    'p2': [a2['x'] * scale, a2['z'] * scale, a2['y'] * scale],
                    'fn': round(fn * 1e6 / scale**2, 3),  # μN
                    'type': '-'.join(sorted([t1, t2])),
                })
    print(f"  Force chains saved: {len(force_chains)} chains")
    with open(os.path.join(output_dir, 'force_chains.json'), 'w') as f:
        json.dump(force_chains, f)

    # Save tortuosity sample paths for 3D viewer (legacy)
    tau = results['tortuosity']
    if tau.get('mean') and 'graph' in perc:
        import networkx as nx
        G = perc['graph']
        reach_bottom = list(perc.get('bottom_se', set()) & perc.get('top_reachable_se', set()))
        reach_top = list(perc.get('top_se', set()) & perc.get('top_reachable_se', set()))
        paths_data = []
        for i in range(min(5, len(reach_bottom), len(reach_top))):
            src = reach_bottom[i % len(reach_bottom)]
            tgt = reach_top[i % len(reach_top)]
            try:
                path = nx.shortest_path(G, src, tgt, weight='distance')
                path_len = 0
                for ki in range(len(path)-1):
                    a1, a2 = atoms_raw[path[ki]], atoms_raw[path[ki+1]]
                    dx = abs(a1['x'] - a2['x'])
                    dy = abs(a1['y'] - a2['y'])
                    dz = a1['z'] - a2['z']
                    dx = min(dx, _box_x - dx)
                    dy = min(dy, _box_y - dy)
                    path_len += np.sqrt(dx**2 + dy**2 + dz**2)
                z_dist = abs(atoms_raw[tgt]['z'] - atoms_raw[src]['z'])
                if z_dist > 0:
                    paths_data.append({
                        'ids': path,
                        'tortuosity': round(path_len / z_dist, 2),
                        'path_length': round(path_len * scale, 1),
                        'z_distance': round(z_dist * scale, 1),
                    })
            except nx.NetworkXNoPath:
                pass
        with open(os.path.join(output_dir, 'tortuosity_paths.json'), 'w') as f:
            json.dump(paths_data, f)

    # Analyzed CSVs
    df_atom['type_name'] = df_atom['type'].map(type_map)
    coord_s = pd.Series(coord, name='coordination')
    df_atom = df_atom.merge(coord_s, left_on='id', right_index=True, how='left')
    df_atom['coordination'] = df_atom['coordination'].fillna(0).astype(int)
    df_atom.to_csv(os.path.join(output_dir, 'atoms_analyzed.csv'), index=False)

    id_to_type = {aid: type_map.get(a['type'], '?') for aid, a in atoms_raw.items()}
    df_contact['type1'] = df_contact['id1'].map(id_to_type)
    df_contact['type2'] = df_contact['id2'].map(id_to_type)
    df_contact['contact_type'] = df_contact.apply(
        lambda r: '-'.join(sorted([str(r['type1']), str(r['type2'])])), axis=1)
    df_contact.to_csv(os.path.join(output_dir, 'contacts_analyzed.csv'), index=False)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('atoms_csv')
    parser.add_argument('contacts_csv')
    parser.add_argument('-o', '--output', default='./results')
    parser.add_argument('-t', '--type-map', default='1:AM,2:SE')
    parser.add_argument('-s', '--scale', type=float, default=1000)
    args = parser.parse_args()

    os.makedirs(args.output, exist_ok=True)
    type_map = {}
    for item in args.type_map.split(','):
        k, v = item.split(':')
        type_map[int(k)] = v.strip()

    print(f"Type map: {type_map}, Scale: {args.scale}")

    atoms_raw, df_atom = load_atoms_raw(args.atoms_csv)
    print(f"  {len(atoms_raw)} atoms")

    # ★★ fail-closed 게이트 (2026-09-22).  **계산 전에** type_map 을 덤프와 대조한다.
    #   실사고: ps_sweep 덱은 3:SE 인데 map 이 `1:AM_P,2:SE` 로 들어와 원자의
    #   99.75 % 가 상(phase) 없이 `?` 가 됐다.  그런데도 파이프라인은 40분을 돌며
    #   porosity·CN·파괴지수를 **그럴듯하게** 다 뽑았고, 마지막 CSV 쓰기에서
    #   빈 배열에 걸려 **우연히** 터졌다.  ⇒ 그 크래시가 false-green 을 막고
    #   있었을 뿐이다 (CLAUDE.md 규율 ⑤).  이제 몇 초 만에 거부한다.
    _dump = _tmr.types_from_pairs(
        (a['type'], a.get('radius')) for a in atoms_raw.values())
    _errs, _notes = _tmr.validate(type_map, _dump)
    for _n in _notes:
        print('  ' + _n)
    if _errs:
        print()
        for _e in _errs:
            print(_e, file=sys.stderr)
        print('   ⇒ 덱의 `particletemplate/sphere … atom_type N … radius constant '
              '${r_XXX}` 줄이 정답을 말한다.  확인:', file=sys.stderr)
        print('     python3 scripts/type_map_resolve.py --deck <in.*.liggghts> '
              '--atoms <atom_*.liggghts>', file=sys.stderr)
        return 2
    contacts_raw, df_contact = load_contacts_raw(args.contacts_csv)
    print(f"  {len(contacts_raw)} contacts")

    print("\n=== Full Analysis ===")
    results = run_full_analysis(atoms_raw, contacts_raw, type_map, args.scale, args.output)
    #  RGL-06 ⑤ — Love–Weber 입력 출처: 이 단계가 실제로 읽은 CSV 의 sha256 앞 16 자 (망 단계 network_provenance.json 의
    #  input_digests 와 같은 꼴 → 두 단계가 같은 입력을 읽었는지 맞댈 수 있다).  원 덤프의 TIMESTEP 은 parse_liggghts 가 CSV 로
    #  옮기며 버린다 → 기록할 수 없다 (원자 · 접촉 덤프가 같은 프레임인지는 여전히 확인되지 않는다 · 전역 virial 은 부호 · 척도만 본다).
    if isinstance(results.get('stress_lw'), dict):
        results['stress_lw']['provenance'] = {
            'atoms_csv_digest': _file_digest(args.atoms_csv), 'contacts_csv_digest': _file_digest(args.contacts_csv),
            'timestep': 'unavailable (원 덤프 TIMESTEP 은 parse_liggghts 가 CSV 로 옮기며 버린다 — 두 덤프의 같은 프레임 미확인)'}

    print("\nSaving...")
    save_results(results, atoms_raw, contacts_raw, df_atom, df_contact,
                 type_map, args.scale, args.output)
    print("Done!")
    return 0


def _selftest():
    """AM 고립 (AM–SE 배위수) 키 계약 — 작은 침대를 **웹앱과 같은 CLI** 로 돌려 full_metrics.json 을 본다.

    2026-09-30 · LHS 인계 7a (판정 J20-k (C)) — AM **전 입자** 의 AM–SE 분포 (`am_se_cn_std` · `am_se_cn_median` ·
    `am_se_cn_max`) 를 내보낸다.  옛 코드는 std 를 계산만 하고 버렸고, median · max 는 상별 (AM_P_ · AM_S_) 로만 있었다.
    mono 침대는 AM 이 한 상이라 전체 분포 = 그 상의 분포다 (7b — J20-k (B) 의 근거).
    3 상 침대는 `analyze_contacts_bimodal.py`, mono 는 이 파일 — 웹앱 `run_pipeline` 이 부르는 그대로 (app.py 의 두 cmd).
    기대값은 설계한 접촉 수에서 **손으로** 셈한다 (numpy 를 다시 부르지 않는다).
    """
    import math
    import re
    import shutil
    import subprocess
    import tempfile

    fails, n_chk = [], [0]

    def chk(name, ok, extra=''):
        n_chk[0] += 1
        print(('  ✓ ' if ok else '  ✗ ') + name + ('' if ok or not extra else f'  — {extra}'))
        if not ok:
            fails.append(name)

    def same(a, b, tol=1e-12):
        try:
            return abs(float(a) - float(b)) <= tol * max(1.0, abs(float(b)))
        except (TypeError, ValueError):
            return False

    def pop_std(xs):
        m = sum(xs) / len(xs)
        return math.sqrt(sum((x - m) ** 2 for x in xs) / len(xs))

    def median(xs):
        s = sorted(xs)
        k = len(s) // 2
        return float(s[k]) if len(s) % 2 else (s[k - 1] + s[k]) / 2.0

    def is_int(v):
        return isinstance(v, int) and not isinstance(v, bool)

    here = os.path.dirname(os.path.abspath(__file__))
    R_SE, PLATE_Z = 0.0005, 0.02                        # sim 단위 (scale 1000 → 0.5 µm · 20 µm)
    ISO_KEY = re.compile(r'am_vulnerable_pct|am_se_cn_\w+|AM_[PS]_(se_cn_\w+|n_particles|vulnerable_pct)')
    PHASE_KEYS = ('se_cn_mean', 'se_cn_std', 'se_cn_median', 'se_cn_max', 'n_particles', 'vulnerable_pct')
    AGG_KEYS = {'am_vulnerable_pct', 'am_se_cn_mean', 'am_se_cn_std', 'am_se_cn_median', 'am_se_cn_max',
                'am_se_cn_surface_weighted'}

    def run_bed(tmp, name, script, type_map, se_type, am, links, extra=()):
        """am = [(id, type, r, x, y, z)] · links = [(am_id, k, 뒤집기)] — AM 마다 짝 SE k 개와 닿는 행 (뒤집기 = SE 가 id1).
        SE 사슬 (바닥 → 플래튼 · id 101–120) 을 깔아 퍼콜레이션 · 굴곡도 단계가 빈 집합에서 돌지 않게 한다 (AM 고립과 무관)."""
        d = os.path.join(tmp, name)
        out = os.path.join(d, 'out')
        os.makedirs(out)
        rows_a = [(aid, t, x, y, z, r) for aid, t, r, x, y, z in am]
        rows_c = []
        for k in range(20):
            rows_a.append((101 + k, se_type, 0.025, 0.025, R_SE + 2 * R_SE * k, R_SE))
            if k:
                rows_c.append((100 + k, 101 + k))
        pos = {aid: (x, y, z, r) for aid, _t, r, x, y, z in am}
        sid = 201
        for aid, k, flip in links:
            x, y, z, r = pos[aid]
            for j in range(k):
                th, g = 2 * math.pi * j / k, r + R_SE - 1e-5
                rows_a.append((sid, se_type, x + g * math.cos(th), y + g * math.sin(th), z, R_SE))
                rows_c.append((sid, aid) if flip else (aid, sid))
                sid += 1
        rows_c += list(extra)
        with open(os.path.join(d, 'atoms.csv'), 'w') as fh:
            fh.write('id,type,x,y,z,radius\n')
            fh.writelines(f'{a},{t},{x!r},{y!r},{z!r},{r!r}\n' for a, t, x, y, z, r in rows_a)
        with open(os.path.join(d, 'contacts.csv'), 'w') as fh:
            fh.write('id1,id2,fn_x,fn_y,fn_z,ft_x,ft_y,ft_z,contact_area,delta\n')
            fh.writelines(f'{i},{j},0,0,0.001,0,0,0,1e-08,1e-05\n' for i, j in rows_c)
        with open(os.path.join(out, 'mesh_info.json'), 'w') as fh:
            json.dump({'plate_z': PLATE_Z}, fh)
        pr = subprocess.run([sys.executable, os.path.join(here, script), os.path.join(d, 'atoms.csv'),
                             os.path.join(d, 'contacts.csv'), '-o', out, '-t', type_map, '-s', '1000'],
                            capture_output=True, text=True, timeout=300)
        met = {}
        if os.path.exists(os.path.join(out, 'full_metrics.json')):
            with open(os.path.join(out, 'full_metrics.json')) as fh:
                met = json.load(fh)
        return pr, met

    tmp = tempfile.mkdtemp(prefix='ac_selftest_')
    try:
        # ── 3 상 침대: AM_P 3 · AM_S 4 · AM 마다 SE 접촉 수를 정해 둔다 (0 인 AM 둘 · 1 인 AM 하나) ──
        am3 = [(1, 1, 0.006, 0.010, 0.010, 0.006), (2, 1, 0.006, 0.040, 0.010, 0.006), (3, 1, 0.006, 0.010, 0.040, 0.006),
               (4, 2, 0.002, 0.040, 0.040, 0.002), (5, 2, 0.002, 0.018, 0.030, 0.012), (6, 2, 0.002, 0.034, 0.024, 0.012),
               (7, 2, 0.002, 0.030, 0.040, 0.016)]
        k3 = {1: 3, 2: 0, 3: 1, 4: 2, 5: 2, 6: 5, 7: 0}
        pr3, m3 = run_bed(tmp, 'bimodal', 'analyze_contacts_bimodal.py', '1:AM_P,2:AM_S,3:SE', 3, am3,
                          [(a, k, a in (5, 6)) for a, k in k3.items()],     # 5 · 6 은 SE 가 id1 인 행
                          extra=[(1, 4)])                                    # AM_P–AM_S 접촉 한 행 — AM–SE 로 세지 않는다
        allc = [k3[a] for a in sorted(k3)]
        pc, sc = [k3[a] for a in (1, 2, 3)], [k3[a] for a in (4, 5, 6, 7)]
        r2 = {a: r * r for a, _t, r, _x, _y, _z in am3}
        sw = sum(r2[a] * k3[a] for a in k3) / sum(r2.values())
        chk('① 3 상 침대 — analyze_contacts_bimodal.py (웹앱 cmd 그대로) rc 0 · full_metrics.json',
            pr3.returncode == 0 and bool(m3), (pr3.stderr or '')[-400:])
        chk('② 옛 전체 키 그대로 — am_se_cn_mean 13/7 · am_vulnerable_pct 3/7 (접촉 0 · 1 인 AM) · surface_weighted = Σr²·CN/Σr²',
            same(m3.get('am_se_cn_mean'), 13 / 7) and same(m3.get('am_vulnerable_pct'), 300 / 7)
            and same(m3.get('am_se_cn_surface_weighted'), sw),
            f"{m3.get('am_se_cn_mean')} · {m3.get('am_vulnerable_pct')} · {m3.get('am_se_cn_surface_weighted')}")
        want_p = dict(se_cn_mean=4 / 3, se_cn_std=pop_std(pc), se_cn_median=median(pc), se_cn_max=3, n_particles=3,
                      vulnerable_pct=200 / 3)
        want_s = dict(se_cn_mean=9 / 4, se_cn_std=pop_std(sc), se_cn_median=median(sc), se_cn_max=5, n_particles=4,
                      vulnerable_pct=25.0)
        chk('③ 옛 상별 키 그대로 — AM_P (3,0,1) · AM_S (2,2,5,0) 의 평균 · 표준편차 · 중앙값 · 최댓값 · 입자 수 · 취약 비율',
            all(same(m3.get(f'AM_P_{k}'), v) for k, v in want_p.items())
            and all(same(m3.get(f'AM_S_{k}'), v) for k, v in want_s.items())
            and all(is_int(m3.get(f'{ph}_se_cn_max')) for ph in ('AM_P', 'AM_S')),
            str({k: m3.get(k) for k in sorted(m3) if k.startswith(('AM_P_', 'AM_S_'))}))
        chk('④ ★ 7a am_se_cn_std = AM 전 입자 7 개 (접촉 0 인 AM 포함) 의 모집단 표준편차',
            same(m3.get('am_se_cn_std'), pop_std(allc)), f"{m3.get('am_se_cn_std')} vs {pop_std(allc)}")
        chk('⑤ ★ 7a am_se_cn_median = 2 (7 개 · 가운데 값) · float',
            same(m3.get('am_se_cn_median'), median(allc)) and isinstance(m3.get('am_se_cn_median'), float),
            repr(m3.get('am_se_cn_median')))
        chk('⑥ ★ 7a am_se_cn_max = 5 · int (JSON 문자열 아님) · = max(AM_P_se_cn_max, AM_S_se_cn_max)',
            m3.get('am_se_cn_max') == 5 and is_int(m3.get('am_se_cn_max'))
            and m3.get('am_se_cn_max') == max(m3.get('AM_P_se_cn_max', -1), m3.get('AM_S_se_cn_max', -1)),
            repr(m3.get('am_se_cn_max')))
        chk('⑦ 항등식 — am_se_cn_mean × N_AM = area_AM전체_SE_n (13) · 상별 평균 × 입자 수 = area_AM_P_SE_n (4) · area_AM_S_SE_n (9)',
            same(m3.get('am_se_cn_mean', 0) * 7, m3.get('area_AM전체_SE_n')) and m3.get('area_AM전체_SE_n') == 13
            and same(m3.get('AM_P_se_cn_mean', 0) * m3.get('AM_P_n_particles', 0), m3.get('area_AM_P_SE_n'))
            and same(m3.get('AM_S_se_cn_mean', 0) * m3.get('AM_S_n_particles', 0), m3.get('area_AM_S_SE_n'))
            and m3.get('area_AM_P_SE_n') == 4 and m3.get('area_AM_S_SE_n') == 9,
            f"{m3.get('area_AM전체_SE_n')} · {m3.get('area_AM_P_SE_n')} · {m3.get('area_AM_S_SE_n')}")
        chk('⑧ AM–AM 행 (1–4) · SE 사슬 19 행은 AM–SE 로 세지 않는다 — area_AM_P_AM_S_n 1 · area_SE_SE_n 19 · AM_P 1 의 SE 수 3',
            m3.get('area_AM_P_AM_S_n') == 1 and m3.get('area_SE_SE_n') == 19 and m3.get('AM_P_se_cn_max') == 3,
            f"{m3.get('area_AM_P_AM_S_n')} · {m3.get('area_SE_SE_n')} · {m3.get('AM_P_se_cn_max')}")
        want3 = AGG_KEYS | {f'{ph}_{k}' for ph in ('AM_P', 'AM_S') for k in PHASE_KEYS}
        got3 = {k for k in m3 if ISO_KEY.fullmatch(k)}
        chk(f'⑨ AM 고립 키 집합 = 계약 {len(want3)} (전체 6 · 상별 6 × 2) — 빠지거나 더 붙으면 실패',
            got3 == want3, f'빠짐 {sorted(want3 - got3)} · 더 {sorted(got3 - want3)}')

        # ── mono 침대: 웹앱은 AM 한 종류를 반지름으로 부른다 (r 2 µm → AM_S) · AM 4 개 (짝수 — 중앙값 규약) ──
        am1 = [(1, 1, 0.002, 0.010, 0.010, 0.002), (2, 1, 0.002, 0.040, 0.010, 0.002),
               (3, 1, 0.002, 0.010, 0.040, 0.002), (4, 1, 0.002, 0.040, 0.040, 0.002)]
        k1 = {1: 0, 2: 1, 3: 4, 4: 2}
        pr1, m1 = run_bed(tmp, 'mono', 'analyze_contacts.py', '1:AM_S,2:SE', 2, am1,
                          [(a, k, False) for a, k in k1.items()])
        c1 = [k1[a] for a in sorted(k1)]
        chk('⑩ mono (1:AM_S,2:SE) — analyze_contacts.py rc 0 · 옛 키 그대로 (평균 1.75 · 취약 50 % · AM_S 중앙값 1.5 · 최댓값 4) · AM_P 키 없음',
            pr1.returncode == 0 and same(m1.get('am_se_cn_mean'), 1.75) and same(m1.get('am_vulnerable_pct'), 50.0)
            and same(m1.get('AM_S_se_cn_median'), 1.5) and m1.get('AM_S_se_cn_max') == 4
            and m1.get('AM_S_n_particles') == 4 and not any(k.startswith('AM_P_') for k in m1),
            (pr1.stderr or '')[-400:] if pr1.returncode else str({k: m1.get(k) for k in sorted(m1) if ISO_KEY.fullmatch(k)}))
        chk('⑪ ★ 7a mono 전체 분포 = 그 상 — std · 중앙값 (짝수 개 = 가운데 둘의 평균 1.5) · 최댓값 4 가 AM_S_* 와 같다 (7b 근거)',
            same(m1.get('am_se_cn_std'), pop_std(c1)) and same(m1.get('am_se_cn_median'), median(c1))
            and m1.get('am_se_cn_max') == 4 and is_int(m1.get('am_se_cn_max'))
            and all(same(m1.get(f'am_se_cn_{s}'), m1.get(f'AM_S_se_cn_{s}')) for s in ('mean', 'std', 'median', 'max')),
            str({k: m1.get(k) for k in sorted(m1) if k.startswith(('am_se_cn_', 'AM_S_se_cn_'))}))
        want1 = AGG_KEYS | {f'AM_S_{k}' for k in PHASE_KEYS}
        got1 = {k for k in m1 if ISO_KEY.fullmatch(k)}
        chk(f'⑫ mono AM 고립 키 집합 = 계약 {len(want1)} (전체 6 · AM_S 6)',
            got1 == want1, f'빠짐 {sorted(want1 - got1)} · 더 {sorted(got1 - want1)}')

        # ── v1.1 ② (1저자 비준 10-01) — 경로 기준 고립의 분해: 이온 활성 · 단절 (SE 는 닿았지만 위 띠로 안 이어짐) · SE 무접촉 ──
        #   calc_ionic_active_am 은 셋을 다 세고 active 만 내보냈다 (단절 · 무접촉은 계산 뒤 버림 · 상별은 active 만 계산).
        #   AM 을 SE 사슬 (위 띠까지 이어진 SE 101–120) 에 직접 잇는 행 (extra) 으로 활성을 만든다 — 사슬에 안 닿은 SE 는 외톨이 (단절).
        IONIC_KEY = re.compile(r'ionic_(active|dead|no_se)_pct|AM_[PS]_ionic_(active|dead|no_se)_pct')
        k3i = {1: 0, 2: 2, 3: 0, 4: 0, 5: 0, 6: 1, 7: 0}            # 외톨이 SE 수 (사슬 SE 와 닿는 수는 extra 로 따로)
        pr3i, m3i = run_bed(tmp, 'ionic3', 'analyze_contacts_bimodal.py', '1:AM_P,2:AM_S,3:SE', 3, am3,
                            [(a, k, False) for a, k in k3i.items()],
                            extra=[(1, 110), (4, 115), (7, 105), (106, 7)])   # 활성 = AM 1 (AM_P) · 4 · 7 (AM_S) · 7 은 뒤집힌 행 하나 포함
        #   손 계산: 활성 {1, 4, 7} · 단절 {2 (외톨이 2), 6 (외톨이 1)} · 무접촉 {3, 5} → 전체 3/7 · 2/7 · 2/7 ·
        #   AM_P {1 활성 · 2 단절 · 3 무접촉} = 1/3 씩 · AM_S {4 · 7 활성 · 6 단절 · 5 무접촉} = 2/4 · 1/4 · 1/4 ·
        #   고립 위험 (SE 접촉 0–1 개) = {1 (사슬 하나 — 활성인데 위험) · 3 · 4 · 5 · 6} = 5/7 ≠ 경로 고립 {2 · 3 · 5 · 6} = 4/7 (2 는 접촉 2 개인데 고립)
        chk('⑬ ★ v1.1 ② 3 상 — ionic_dead_pct 200/7 · ionic_no_se_pct 200/7 를 내보낸다 · 옛 ionic_active_pct 300/7 그대로 · 셋의 합 = 100',
            pr3i.returncode == 0 and same(m3i.get('ionic_active_pct'), 300 / 7) and same(m3i.get('ionic_dead_pct'), 200 / 7)
            and same(m3i.get('ionic_no_se_pct'), 200 / 7)
            and same(sum(m3i.get(f'ionic_{s}_pct', float('nan')) for s in ('active', 'dead', 'no_se')), 100.0),
            (pr3i.stderr or '')[-400:] if pr3i.returncode else str({k: m3i.get(k) for k in sorted(m3i) if IONIC_KEY.fullmatch(k)}))
        want_ip = dict(active=100 / 3, dead=100 / 3, no_se=100 / 3)
        want_is = dict(active=50.0, dead=25.0, no_se=25.0)
        chk('⑭ ★ v1.1 ② 상별 — AM_P (활성 · 단절 · 무접촉 = 1/3 씩) · AM_S (2/4 · 1/4 · 1/4) · 상마다 합 = 100',
            all(same(m3i.get(f'AM_P_ionic_{s}_pct'), v) for s, v in want_ip.items())
            and all(same(m3i.get(f'AM_S_ionic_{s}_pct'), v) for s, v in want_is.items()),
            str({k: m3i.get(k) for k in sorted(m3i) if k.startswith(('AM_P_ionic', 'AM_S_ionic'))}))
        k1i = {1: 0, 2: 1, 3: 0, 4: 0}
        pr1i, m1i = run_bed(tmp, 'ionic1', 'analyze_contacts.py', '1:AM_S,2:SE', 2, am1,
                            [(a, k, False) for a, k in k1i.items()], extra=[(1, 112)])   # 활성 1 · 단절 2 · 무접촉 3 · 4
        chk('⑮ ★ v1.1 ② mono (1:AM_S,2:SE) — 전체 = AM_S = 25 · 25 · 50 · AM_P 분해 키 없음',
            pr1i.returncode == 0 and all(same(m1i.get(f'ionic_{s}_pct'), v) and same(m1i.get(f'AM_S_ionic_{s}_pct'), v)
                                         for s, v in (('active', 25.0), ('dead', 25.0), ('no_se', 50.0)))
            and not any(k.startswith('AM_P_ionic') for k in m1i),
            (pr1i.stderr or '')[-400:] if pr1i.returncode else str({k: m1i.get(k) for k in sorted(m1i) if IONIC_KEY.fullmatch(k)}))
        want_i3 = {f'ionic_{s}_pct' for s in ('active', 'dead', 'no_se')} | \
            {f'{ph}_ionic_{s}_pct' for ph in ('AM_P', 'AM_S') for s in ('active', 'dead', 'no_se')}
        want_i1 = {f'ionic_{s}_pct' for s in ('active', 'dead', 'no_se')} | {f'AM_S_ionic_{s}_pct' for s in ('active', 'dead', 'no_se')}
        got_i3 = {k for k in m3i if IONIC_KEY.fullmatch(k)}
        got_i1 = {k for k in m1i if IONIC_KEY.fullmatch(k)}
        chk(f'⑯ ★ v1.1 ② 분해 키 집합 = 계약 (3 상 {len(want_i3)} · mono {len(want_i1)}) — 빠지거나 더 붙으면 실패 · 값은 숫자 (문자열 아님)',
            got_i3 == want_i3 and got_i1 == want_i1
            and all(isinstance(m3i[k], (int, float)) and not isinstance(m3i[k], bool) for k in got_i3),
            f'3 상 빠짐 {sorted(want_i3 - got_i3)} · 더 {sorted(got_i3 - want_i3)} · mono 빠짐 {sorted(want_i1 - got_i1)}')
        chk('⑰ ★ v1.1 ① 경로 기준 고립 am_ionic_isolated_pct = 100 − ionic_active_pct = 단절 + 무접촉 (3 상 400/7 · mono 75) — '
            '인계표와 같은 이름 · 고립 위험 (am_vulnerable_pct · SE 접촉 0–1 개 = 3 상 500/7 · mono 100) 과 다른 양',
            same(m3i.get('am_ionic_isolated_pct'), 400 / 7) and same(m1i.get('am_ionic_isolated_pct'), 75.0)
            and same(m3i.get('am_ionic_isolated_pct', 0), m3i.get('ionic_dead_pct', 0) + m3i.get('ionic_no_se_pct', 0))
            and same(m3i.get('am_vulnerable_pct'), 500 / 7) and same(m1i.get('am_vulnerable_pct'), 100.0),
            f"{m3i.get('am_ionic_isolated_pct')} · {m1i.get('am_ionic_isolated_pct')} · 취약 {m3i.get('am_vulnerable_pct')}")
        rows3 = {}
        try:
            with open(os.path.join(tmp, 'ionic3', 'out', 'network_summary.csv'), encoding='utf-8-sig') as fh:
                import csv as _csv
                rows3 = {r['지표']: r['값'] for r in _csv.DictReader(fh)}
        except (OSError, KeyError):
            rows3 = {}
        chk('⑱ ★ v1.1 ①② 케이스 표 (network_summary.csv) — 활성 바로 뒤에 "Ionic Isolated AM(%)" · 그 아래 단절 · 무접촉 두 줄 (값 = 57.1 · 28.6 · 28.6)',
            rows3.get('Ionic Isolated AM(%)') in ('57.1', 57.1) and rows3.get('  ├ Isolated: SE not linked(%)') in ('28.6', 28.6)
            and rows3.get('  └ Isolated: no SE contact(%)') in ('28.6', 28.6),
            str({k: v for k, v in rows3.items() if 'Ionic' in k or 'Isolated' in k}))

        # ⑲ F1 근접쌍 CN (se_se_cn_aug) — x · y 주기 경계 너머의 근접쌍 (원장 LHS-22 · 10-01 · 반례 먼저).
        #   상자 0.05 (sim) · SE 반지름 0.0005 · 틈 h = 1e-5 (10 nm × 1000).  탄성 접촉 (덤프) 은 없다고 두고 근접쌍만 본다.
        import dem_analysis_core as _DAC
        L, r, h = 0.05, 0.0005, 1e-5

        def _f1(pos, **kw):
            at = {k + 1: dict(type=3, x=p[0], y=p[1], z=p[2], radius=r) for k, p in enumerate(pos)}
            return _DAC.calc_se_se_cn(at, [], [3], h_spread_sim=h, **kw)

        gap = 0.5 * h                                           # 틈 5 nm 상당 — 근접쌍이어야 한다
        across_x = [(r, 0.02, 0.01), (L - r - gap, 0.02, 0.01)]  # 최소영상 거리 = 2r + gap
        across_y = [(0.02, r, 0.01), (0.02, L - r - gap, 0.01)]
        inner = [(0.02, 0.02, 0.01), (0.02 + 2 * r + gap, 0.02, 0.01)]
        chk('⑲a ★ x 주기 경계 너머 근접쌍 (틈 < h) 을 센다 — 상자를 주면 n_extra_aug 1 (옛 코드 0 = LHS-22)',
            _f1(across_x, box_x=L, box_y=L).get('n_extra_aug') == 1, str(_f1(across_x, box_x=L, box_y=L)))
        chk('⑲b ★ y 주기 경계 너머도 같다 — n_extra_aug 1', _f1(across_y, box_x=L, box_y=L).get('n_extra_aug') == 1)
        chk('⑲c 상자를 안 주면 옛 동작 그대로 (경계 너머 0 · 비주기 호출부 호환)', _f1(across_x).get('n_extra_aug') == 0)
        chk('⑲d 내부 근접쌍은 상자 유무와 무관하게 1', _f1(inner).get('n_extra_aug') == 1 and _f1(inner, box_x=L, box_y=L).get('n_extra_aug') == 1)
        over = [(r, 0.02, 0.01), (L - r + 0.2 * r, 0.02, 0.01)]   # 최소영상으로 겹친다 = 탄성 접촉 몫 → 근접쌍이 아니다
        far = [(r, 0.02, 0.01), (L - r - 3 * h, 0.02, 0.01)]      # 틈 3h → 아니다
        chk('⑲e 경계 너머로 겹친 쌍 · 틈이 h 보다 큰 쌍은 근접쌍이 아니다 (0 · 0)',
            _f1(over, box_x=L, box_y=L).get('n_extra_aug') == 0 and _f1(far, box_x=L, box_y=L).get('n_extra_aug') == 0)
        crowd = [(x0, 0.02, 0.01) for x0 in (r, L - r - gap)] + [(0.02, y0, 0.012) for y0 in (r, L - r - gap)]
        res_c = _f1(crowd, box_x=L, box_y=L)
        chk('⑲f 여러 쌍 — 쌍마다 한 번만 (x 1 + y 1 = 2) · mean_aug = 2·2/4 = 1.0',
            res_c.get('n_extra_aug') == 2 and same(res_c.get('mean_aug'), 1.0), str(res_c))
        src_core = open(os.path.join(os.path.dirname(os.path.abspath(__file__)), 'dem_analysis_core.py'), encoding='utf-8').read()
        call = src_core[src_core.find('cn = calc_se_se_cn(atoms_raw'):][:260]
        chk('⑲g 생산 경로 (run_full_analysis) 가 상자 크기를 넘긴다 — box_x=box_x · box_y=box_y', 'box_x=box_x' in call and 'box_y=box_y' in call, call)
    finally:
        shutil.rmtree(tmp, ignore_errors=True)
    print(f'\n{n_chk[0] - len(fails)}/{n_chk[0]}  ' + ('✓ 전부 통과' if not fails else f'✗ {len(fails)} 건 실패'))
    return 0 if not fails else 1


if __name__ == '__main__':
    if '--selftest' in sys.argv:
        sys.exit(_selftest())
    sys.exit(main())

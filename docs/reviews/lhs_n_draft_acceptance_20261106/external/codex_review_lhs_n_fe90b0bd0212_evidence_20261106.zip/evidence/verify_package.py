"""Read supplied static package and saved remote metadata; no research execution."""
from pathlib import Path
import hashlib
import json

ROOT = Path(__file__).resolve().parent.parent
P = ROOT / 'package'
def h(b):
    return hashlib.sha256(b).hexdigest()
def blob(b):
    return hashlib.sha1(b'blob ' + str(len(b)).encode() + b'\0' + b).hexdigest()
manifest = json.loads((P/'SNAPSHOT_MANIFEST.json').read_text(encoding='utf8'))
pin = (P/'PIN.txt').read_text().strip()
assert pin == manifest['pin'] == 'fe90b0bd0212da6fba8dffd56991a0b2bbea9615'
rows = []
for e in manifest['entries']:
    b = (P/e['path']).read_bytes()
    row = {'path':e['path'], 'bytes_match':len(b)==e['bytes'], 'sha256_match':h(b)==e['sha256'], 'blob_match':blob(b)==e['git_blob']}
    assert all(row[k] for k in ('bytes_match','sha256_match','blob_match')), row
    rows.append(row)
sums = []
for line in (P/'SHA256SUMS').read_text().splitlines():
    digest, name = line.split(None,1)
    name = name.strip().lstrip('*')
    match = h((P/name).read_bytes()) == digest
    assert match, name
    sums.append({'path':name,'match':match})
commit = json.loads((ROOT/'evidence/github_commit_metadata.json').read_text(encoding='utf8'))
assert commit['sha']==pin
assert len(commit['parents'])==1 and commit['parents'][0]['sha']==(P/'PARENT_PIN.txt').read_text().strip()
changes = []
for f in commit['files']:
    assert f['status']=='added'
    b = (P/f['filename']).read_bytes()
    assert blob(b)==f['sha'], f['filename']
    changes.append({'path':f['filename'],'remote_blob_match':True,'status':'added'})
patch = (P/'CHANGE.patch').read_bytes().splitlines(keepends=True)
reconstructed = {}
name = None
data = []
for line in patch:
    if line.startswith(b'diff --git '):
        if name is not None:
            reconstructed[name] = b''.join(data)
        name = None
        data = []
    elif line.startswith(b'+++ b/'):
        name = line[len(b'+++ b/'):].rstrip(b'\r\n').decode()
    elif name is not None and line.startswith(b'+'):
        data.append(line[1:])
    elif name is not None and line.startswith(b'-'):
        raise AssertionError('Expected only new-file patch')
if name is not None:
    reconstructed[name] = b''.join(data)
assert set(reconstructed)=={f['filename'] for f in commit['files']}
for path, b in reconstructed.items():
    assert b == (P/path).read_bytes(), path
definition=json.loads((P/'docs/reviews/lhs_pressure_n_dependence_draft_20261106/prospective_definition.json').read_text(encoding='utf8'))
assert definition['status']=='DRAFT_NOT_REGISTERED' and definition['measured_rows']==0 and definition['rows']==[]
null_fields=[k for k,v in definition['template'].items() if k!='status']
assert all(definition['template'][k] is None for k in null_fields)
assert definition['template']['status']=='NOT_COLLECTED'
result={'pin':pin,'snapshot':rows,'packaging':sums,'remote_new_files':changes,
        'new_patch_files':len(reconstructed),'patch_reconstructed_bytes_match':True,
        'template_null_fields':len(null_fields),'scope':'byte and static-invariant checks only'}
print(json.dumps(result,ensure_ascii=False,indent=2))

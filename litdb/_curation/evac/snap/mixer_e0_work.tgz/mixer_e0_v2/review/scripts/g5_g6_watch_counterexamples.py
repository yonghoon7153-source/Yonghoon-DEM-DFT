"""G5 / G6 — small hand counterexamples for the registered watch rules (S5 stall · S6 log rules).
No ibb, no real data: frame names follow the planned deck (post/mix_<step>.liggghts, every 1000,
last 1121000); speeds = registration 4-1 range.  Run: python3 -I -B g5_g6_watch_counterexamples.py
"""
FRAMES = [s for s in range(1000, 1121001, 1000)]
assert len(FRAMES) == 1121 and FRAMES[-1] == 1121000
names = ['mix_%d.liggghts' % s for s in FRAMES]

# (1) "post 의 가장 큰 step 파일" read lexicographically (ls | sort | tail -1) instead of numerically
def lex_max_at(step_now):
    have = [n for n, s in zip(names, FRAMES) if s <= step_now]
    return max(have)                     # lexicographic
def num_max_at(step_now):
    return max(s for s in FRAMES if s <= step_now)
frozen = []
prev = None
for s in FRAMES:
    m = lex_max_at(s)
    if m != prev:
        frozen.append((s, m)); prev = m
spans = []
for (s0, m0), (s1, m1) in zip(frozen, frozen[1:] + [(1121213, None)]):
    spans.append((m0, s0, s1, s1 - s0))
worst = max(spans, key=lambda x: x[3])
print('(1) lexicographic "largest" frame frozen longest:', worst[0], 'from step', worst[1], 'to', worst[2],
      '=', worst[3], 'steps')
for rate in (92.04, 74.12, 63.49):
    print('    at %.2f step/s that is %.1f min (S5 limit 30 min)' % (rate, worst[3] / rate / 60))

# (2) S5 after a normal completion: last frame 1121000, run ends 1121213 + write_restart + run 0.
for rate in (92.04, 63.49):
    tail_s = 213 / rate
    print('(2) normal end: last frame mtime then job ends %.1f s later; a watch row 31 min after the end'
          ' still sees "largest frame unchanged > 30 min" -> S5 unless the rule is limited to RUNNING' % tail_s)

# (3) S6 (2) "thermo 줄에 비유한 값 (nan · inf)" implemented as a case-insensitive grep over the log
normal_log_lines = [
    'INFO: Particle insertion ins: inserting every 0 steps',
    '    Step    Atoms         KinEng            rke         Volume ',
    '       0        0              0              0  2.7589053e-05 ',
    'INFO: Particle insertion ins: inserted 100000 particle templates (mass 1.000000e-01) at step 1',
    ' - a total of 100000 particle templates (mass 1.000000e-01) inserted so far.',
    '       1   100000  3.2685651e-12  1.0960987e-10  2.7589053e-05 ',
]
import re
naive = [l for l in normal_log_lines if re.search(r'nan|inf', l, re.I)]
rowwise = [l for l in normal_log_lines
           if re.fullmatch(r'\s*\d+\s+\d+(\s+\S+){3}\s*', l) and re.search(r'nan|inf', l, re.I)]
print('(3) naive case-insensitive grep nan|inf hits %d normal lines (INFO:) ; thermo-row-only hits %d'
      % (len(naive), len(rowwise)))

# (4) "가장 큰 step" numerically: no false stall in a normal run with the slowest observed segment
print('(4) numeric max: slowest observed 1000-step segment 14.17 s -> S5 margin %.0fx' % (1800 / 14.17))

from pathlib import Path
import hashlib,json,zipfile
r=Path(__file__).resolve().parent
names=['README.md','codex_review_mxd2r_r01_recheck_20261106.md','integrity.json',
       'remote_verification.json','final_integrity.json','focused.log',
       'independent_probe.py','replay_delivered.py','seed_static_probe.py','seed_static_probe.json',
       'evidence_docs.md','evidence_seed_static.md','package_delivery.py']
files=[r/n for n in names]
for n in ['package','evidence']:
    files += sorted(q for q in (r/n).rglob('*') if q.is_file())
assert len(files)==len(set(files))
manifest=''.join(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+p.relative_to(r).as_posix()+'\n' for p in files)
(r/'EVIDENCE_SHA256SUMS').write_bytes(manifest.encode('utf-8'))
files.append(r/'EVIDENCE_SHA256SUMS')
dest=r/'codex_mxd2r_r01_independent_recheck_69b6bec7ac20_20261106.zip'
with zipfile.ZipFile(dest,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for p in files:z.write(p,p.relative_to(r).as_posix())
with zipfile.ZipFile(dest) as z:
    assert z.testzip() is None
    assert len(z.namelist())==len(set(z.namelist()))==len(files)
    for line in z.read('EVIDENCE_SHA256SUMS').decode().splitlines():
        h,n=line.split('  ',1);assert hashlib.sha256(z.read(n)).hexdigest()==h
receipt={'zip':dest.name,'bytes':dest.stat().st_size,'sha256':hashlib.sha256(dest.read_bytes()).hexdigest(),
         'entries':len(files),'verified_payload_hashes':len(files)-1,'crc_ok':True,
         'pin':'69b6bec7ac20343dd884f8d5fa63e8bf45e7df97',
         'verdict':'MXD2R-R01 closed in actual insert/pack seed consumer scope only',
         'overall_gate':'HOLD','execution_authorized':False,'ledger_changed':False}
(r/'delivery_receipt.json').write_text(json.dumps(receipt,indent=2),encoding='utf-8')
print(json.dumps(receipt,indent=2))

# 제출 계약 (SUBMIT_CONTRACT)

## 상 의존성
```
static  (독립 — 잡끼리 완전 병렬)
   └─ dense   (같은 잡의 static/CHGCAR 필요 → **그 잡 안에서는 직렬**)
```
잡 사이에는 의존성이 없습니다. 한 잡의 `run_job.sh` 가 그 잡의 상 순서를 강제합니다.

## 규모
| | |
|---|---:|
| 잡 | 18 |
| static 실행 | 18 |
| dense 실행 | 0 |
| 총 VASP 실행 | **18** |
| 상별 | static 18 |

⚠ **잡 수의 정본은 `find . -name run_job.sh | wc -l`** 입니다 —
`MANIFEST.planned` 에는 D3-off 쌍둥이가 들어 있지 않으므로 그것으로 세면 적게 나옵니다.

### census

- references 2 (끝점 2 + 쌍둥이 0)
- calibration complexes 16 (pose×seed 16 + 쌍둥이 0)
- audit pose 0
- pose 당: pm1/D3-on · net4/D3-on — **D3-off 쌍둥이를 만들지 않는다** (C3 는 D3-on OUTCAR 의 Edisp 로 낸다)


## 병렬 제출 (권장)
`run_all.sh` 는 **직렬 디버그용**입니다. 실제로는 잡 목록을 배열로 던지세요:
```bash
# ⚠ 폴더 이름을 손으로 적지 않는다 — refs/ 냐 controls/ 냐가 모드에 따라 다르다.
#   2026-08-12: controls/ 로 적어 두는 바람에 기준계 10잡이 통째로 빠질 뻔했다.
find . -mindepth 2 -maxdepth 2 -type d -name '*__*' -o      -mindepth 2 -maxdepth 2 -type d -path './refs/*' | sed 's|^\./||' | sort > JOBS.txt
n=$(wc -l < JOBS.txt)
[ "$n" = 18 ] || { echo "⛔ 잡 18개여야 하는데 $n 개"; exit 1; }
# Slurm 예시 — 동시 8개
sbatch --array=1-$(wc -l < JOBS.txt)%8   --ntasks=256 --time=120:00:00 --wrap='
  j=$(sed -n "${SLURM_ARRAY_TASK_ID}p" JOBS.txt)
  cd "$j"
  PP=/path/to/potpaw_PBE.54 bash POTCAR_ASSEMBLE.sh    # ★ 잡마다 종 순서가 다르다
  VASP_CMD="srun -n 256 vasp_std" bash run_job.sh'
```
⚠ **공통 POTCAR 를 전 잡에 복사하면 안 됩니다.** 조각마다 POSCAR 종 순서가 달라
(`Li Ni O` · `Li Ni O C F` · `Li Ni O C F H` · `Li Ni O S C H`) 하나를 돌려 쓰면
그 잡은 조용히 **다른 계**를 계산합니다. `POTCAR_ASSEMBLE.sh` 가 잡마다 조립하고
TITEL 수까지 검증합니다.
⚠ walltime — 가장 긴 잡이 중앙 추정 56 h 이고 모형 불확실성이 ±2배입니다.
   ±2배 외피가 112 h 이므로 **120 h** 를 권합니다 (24–48 h 면 그 잡이 잘립니다).

## 비용 추정의 출처
- 모델: `tools/sdcp/vasp_cost_estimate.py` — 2026-08-08 납품 `slab/OUTCAR.gz`
  (192원자 · NKPTS 4 · 48코어 · 30,438 s / 58 전자스텝 = **525 s/스텝**)
- **±2배 불확실성**을 인정하는 모델입니다. 계약값이 아니라 계획용 수치입니다.
- `python3 tools/sdcp/vasp_cost_estimate.py --manifest MANIFEST.json --concurrent 8`
  로 이 번들의 실제 계획에서 다시 계산하세요.
- ⚠ **aggregate 시간 ÷ 동시 실행 수**는 산술 하한입니다. 한 잡의
  static→dense 임계경로가 그 하한보다 길면 하한에 도달할 수 없습니다.

## 코어 수
이 번들은 **256 코어/잡 · 동시 8잡**으로 계획했습니다
(MANIFEST.json 의 `submission`). 실제와 다르면 추정이 그만큼 어긋납니다 —
알려 주시면 `--manifest` 로 다시 계산합니다.

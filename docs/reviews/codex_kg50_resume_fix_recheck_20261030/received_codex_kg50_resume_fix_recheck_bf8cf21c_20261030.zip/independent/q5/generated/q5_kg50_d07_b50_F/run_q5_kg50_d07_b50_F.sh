#!/bin/bash
#SBATCH --job-name=q5_kg50_d07_b50_F
#SBATCH --output=logs/output_q5_kg50_d07_b50_F_%j.out
#SBATCH --qos=cpu-60
#SBATCH --partition=cpu
#SBATCH -n 28
#SBATCH --time=5-00:00:00

source ~/.bashrc
conda activate myenv

export OMP_NUM_THREADS=1
export MKL_NUM_THREADS=1
export OPENBLAS_NUM_THREADS=1
export NUMEXPR_NUM_THREADS=1

cd $HOME/dem_test/q5_kg50_d07_b50_F
mpirun --oversubscribe --bind-to none -np 28 lmp_mpi -in input_q5_kg50_d07_b50_F.liggghts

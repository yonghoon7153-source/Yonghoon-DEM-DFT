import os, sys, subprocess, json, shutil, hashlib
D = os.path.dirname(os.path.abspath(__file__))
IN = os.path.join(D, 'in')
M = os.path.join(D, 'mut')
def rd(n): return open(os.path.join(IN, n), encoding='utf-8', newline='').read()
def wr(name, text, enc='utf-8'):
    p = os.path.join(M, name)
    with open(p, 'w', encoding=enc, newline='') as f: f.write(text)
    return p
ri, ci, plan = rd('reg_ins.md'), rd('cmd_ins.md'), rd('plan.json')
cases = []
def case(name, **kw): cases.append((name, kw))
# (a) insert-file weird inputs
case('A01 empty after-block (R-08 block empty)', ri=wr('a01.md', ri.replace("====\n  - (봉인 · <봉인 날짜> · 3 판 Q7", "====\n====\n\n====\n  - (봉인 · <봉인 날짜> · 3 판 Q7", 1)))
t = ri.split('\n## R-08 ·')[0] + '\n## R-08 · x\n\n@op after 334 - 기계 = kgy (RTX 3090 24 GB\n\n====\n====\n\n## R-09 ·' + ri.split('\n## R-09 ·')[1]
case('A02 R-08 block = empty (==== ====)', ri=wr('a02.md', t))
case('A03 duplicate fragment R-01', ri=wr('a03.md', ri + '\n## R-01 · dup\n\n@op last 72 | u (위치 불확도) |\n\n====\n~~⬜~~ x\n====\n'))
case('A04 @op prefix not in original', ri=wr('a04.md', ri.replace('@op after 334 - 기계 = kgy (RTX 3090 24 GB', '@op after 334 - 기계 = kgy (RTX 3090 99 GB')))
case('A05 @op fullwidth digits', ri=wr('a05.md', ri.replace('@op last 72 |', '@op last ７２ |')))
case('A06 @op arabic-indic digits', ri=wr('a06.md', ri.replace('@op last 72 |', '@op last ٧٢ |')))
case('A07 @op double space', ri=wr('a07.md', ri.replace('@op last 72 |', '@op last 72  |')))
case('A08 CRLF insert file', ri=wr('a08.md', ri.replace('\n', '\r\n')))
case('A09 ==== with trailing space on one closer', ri=wr('a09.md', ri.replace('\n====\n\n## R-02', '\n==== \n\n## R-02', 1)))
case('A10 last-cell block with newline (R-01)', ri=wr('a10.md', ri.replace('~~⬜~~ → **0.07381254285530132 µm** (봉인 · S0 단계 1 SBE', '~~⬜~~ → **0.07381254285530132 µm**\n| 계획 해시X | injected | row |\n(봉인 · S0 단계 1 SBE', 1)))
case('A11 last-cell block with extra pipe (R-02)', ri=wr('a11.md', ri.replace('~~⬜~~ → **0.07381254285530132 µm** (= min(u', '~~⬜~~ → **0.0738 µm** | extra col (= min(u', 1)))
case('A12 R-MARK mentions hash row text mid-line', ri=wr('a12.md', ri.replace('이 글의 §2-1 해시 칸은', '이 글의 | 계획 해시 | 칸은', 1)))
case('A13 R-MARK starts with " | 계획 해시 |"', ri=wr('a13.md', ri.replace('> **봉인 표지 (<봉인 날짜>)**', ' | 계획 해시 | **봉인 표지 (<봉인 날짜>)**', 1)))
case('A14 fragment adds line starting "| S0 계획 해시 |" via R-08', ri=wr('a14.md', ri.replace('  - (봉인 · <봉인 날짜> · 3 판 Q7', '| S0 계획 해시 | x | `' + '1'*64 + '` |\n  - (봉인 · <봉인 날짜> · 3 판 Q7', 1)))
case('A15 R-10 removed entirely', ri=wr('a15.md', ri.split('\n## R-10 ·')[0] + '\n## R-11 ·' + ri.split('\n## R-11 ·')[1]))
case('A16 R-10 sh line --registration removed (tool scope)', ri=wr('a16.md', ri.replace('--init --plan ~/sdcp/ca1_plan.json --registration ~/dem-ca1/<봉인본>', '--init --plan ~/sdcp/ca1_plan.json', 1)))
case('A17 unknown placeholder left <봉인본X>', ri=wr('a17.md', ri.replace('--r-doc <봉인본> \\', '--r-doc <봉인본X> \\', 1)))
case('A18 extra fragment R-16 inserted after 1', ri=wr('a18.md', ri + '\n## R-16 · extra\n\n@op after 2 \n\n====\n- extra line\n====\n'))
case('A19 header typo ### R-10', ri=wr('a19.md', ri.replace('\n## R-10 ·', '\n### R-10 ·', 1)))
# (a) pin / plan / date
pin = rd('pin_reg.md')
case('A20 pin reg CRLF', reg=wr('a20_pin.md', pin.replace('\n', '\r\n')))
case('A21 pin reg one byte changed', reg=wr('a21_pin.md', pin.replace('탄소 접합', '탄소 접함', 1)))
case('A22 plan trailing newline', plan=wr('a22.json', plan + '\n', 'ascii'))
case('A23 plan indent 2', plan=wr('a23.json', json.dumps(json.loads(plan), indent=2, sort_keys=True), 'ascii'))
p = json.loads(plan); p['tol_ff_um'] = 0.0738
case('A24 plan tol_ff != S0 (cross)', plan=wr('a24.json', json.dumps(p, indent=1, sort_keys=True), 'ascii'))
p = json.loads(plan); p['len_law'] = 'len_scaled_v9'
case('A25 plan len_law wrong (cross)', plan=wr('a25.json', json.dumps(p, indent=1, sort_keys=True), 'ascii'))
case('A26 plan NaN', plan=wr('a26.json', plan.replace('"calib_rj_ratio_max": null', '"calib_rj_ratio_max": NaN'), 'ascii'))
case('A27 plan duplicate key', plan=wr('a27.json', plan.replace('"len_law": "len_scaled_v0",', '"len_law": "len_scaled_v0",\n "len_law": "len_scaled_v0",'), 'ascii'))
p = json.loads(plan); p['exec_policy']['max_hours'] = 167
case('A28 plan max_hours 167 (policy change, not cross)', plan=wr('a28.json', json.dumps(p, indent=1, sort_keys=True), 'ascii'))
case('A29 s0 plan = other file (R-06 hash mismatch)', s0=wr('a29.json', open(os.path.join(IN,'s0.json')).read() + ' ', 'ascii'))
case('A30 date month 13', date='20261320')
case('A31 date fullwidth', date='２０２６１１２０')
case('A32 date with newline', date='20261120\n')
case('A33 branch with ..', branch='a..b')
case('A34 branch endswith .lock', branch='seal.lock')
res = []
for name, kw in cases:
    out = os.path.join(M, 'out_' + name.split()[0])
    shutil.rmtree(out, ignore_errors=True)
    args = [os.path.join(D, 'run.sh'), out] + [f'{k}={v}' for k, v in kw.items()]
    r = subprocess.run(args, capture_output=True, text=True)
    msg = (r.stderr.strip().splitlines() or [''])[-1] if r.returncode else (r.stdout.strip().splitlines() or [''])[-1]
    res.append((name, r.returncode, msg[:230]))
    print(f'{name} | rc {r.returncode} | {msg[:230]}')

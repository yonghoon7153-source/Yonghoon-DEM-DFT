import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from keys import K, EXTRA
slugs = sorted(f[:-3] for f in os.listdir(sys.argv[1]) if f.endswith('.md') and not f.startswith('_'))
import re
seen = {}
for idx,(key,names) in sorted(K.items()):
    if key in seen: continue
    seen[key]=idx
    hits = sorted({s for s in slugs for n in names if re.match(n+r'\d{4}', s)})
    if hits:
        print(f"{idx}\t{key}\t" + " ".join(hits))
print("unique keys:", len(seen), "+ extra", sum(len(v) for v in EXTRA.values()))

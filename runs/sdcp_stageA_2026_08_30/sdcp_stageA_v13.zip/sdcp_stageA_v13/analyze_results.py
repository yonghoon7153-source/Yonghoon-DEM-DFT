#!/usr/bin/env python3
"""analyze_results.py v3 — VASP 완주 후 이거 **하나**로 회수 (stdlib only).

  python3 analyze_results.py <bundle_dir> [--delta 0.030]

판정 에너지 = **static/OUTCAR 만**. 전 검사는 fail-closed 다 — 확인 못 한 것은
통과가 아니라 게이트다 (2026-08-11 Codex 재검토 P0-C/D/E/G/H).

  잡: MANIFEST 해시(입력 무결성) / 상별 정상종료 / 전자수렴 / relax 이온수렴 /
     POTCAR TITEL(반도체준위 변형은 치명) / 힘 블록 존재·원자수 / 등록(표면 양이온만)
     / 결합 그래프 / 탈착 / 고정원자 drift / **Ni 국소 모멘트·부호 패턴**
  쌍: PAIR_MIGRATED · PAIR_COLLAPSED(주기 RMSD + 접촉 지문) ·
     seed-매칭 |ΔE_pm1−ΔE_net4| ≤ 10 meV
  수치(**게이트다 — 실패하면 E_ads/판정을 만들지 않는다**):
     상자 20↔24 Å ≤ 10 meV (정본은 box24) · dense-k ΔE·E_ads ≤ 10 meV
exit 0 = 필수(tier1+refs) 완결 · exit 2 = 필수 산출 누락/무결성 실패 (fail-closed).

이 도구가 **못 하는 것**
  · 자기바닥상태를 찾아 주지 않는다. 두 seed 가 같은 basin 으로 무너졌는지
    모멘트 부호 패턴으로 **알려만** 준다.
  · POTCAR 파일 자체를 검증하지 못한다 (라이선스로 미포함) — OUTCAR 의 TITEL 만 본다.
  · 유한셀 보정(전하·쌍극자 상호작용)을 하지 않는다. 상 사이 비교용이다.
"""
import gzip, hashlib, json, math, os, pathlib, re, sys
from glob import glob

DELTA = 0.030
SEED_TOL = 0.010          # eV — seed-매칭 ΔE 게이트
BOX_TOL = 0.010           # eV — 기체상 상자 수렴
K_TOL = 0.010             # eV — dense-k 민감도
GUARD_EV = 0.010          # ±10 meV — k 전이 불확실성. **30 meV 판정바닥과 별개다**
                          #   (Codex 5차: 두 숫자를 하나로 합치면 경계 결과를 오판한다)
RMSD_TOL = 0.75           # Å — 두 끝점이 같은 basin 인가 (0.50/1.00 민감도도 같이 뽑는다)
CONTACT_A = 3.0           # Å — 접촉 지문 반경
FP_JACCARD = 0.80         # 접촉 지문 겹침 — 경계 원자 하나로 뒤집히지 않게 완전일치 대신
#: 실행 INCAR echo 로 대조할 키. 생성부의 AUDIT_KEYS 와 **같은 목록이어야 한다** —
#:  둘이 따로 적혀 있어 한쪽만 늘리면 조용히 갈린다 (Codex 5차 P1-3).
#:  물리 규약 키(LASPH/ADDGRID/ISYM/NUPDOWN/LDAUU)도 넣어 외주처의 우발적 수정을 잡는다.
AUDIT_KEYS_RUNTIME = ("ENCUT", "ISMEAR", "IVDW", "LREAL", "ISTART", "ICHARG", "LDIPOL",
                      "LASPH", "ADDGRID", "ISYM", "NUPDOWN", "LDAUU", "LDAUTYPE", "IDIPOL",
                      "ISPIN", "LDAUL", "LDAUJ", "MAGMOM", "LDAU", "LMAXMIX",
                      # 🔴 회신 AB P0-5 — `_spin_setup_ok()` 가 이 넷을 검사하는데
                      #   여기 없어서 `read_outcar()` 가 **아예 안 읽었다**. 손으로 만든
                      #   dict 를 넣는 단위시험은 통과하고 실제 OUTCAR 경로에서는
                      #   검사가 통째로 꺼져 있었다 (전형적인 가짜 초록).
                      #   ⚠ 넷 다 **미출력이 기본값**이다: VASP 는 기본값이면 안 찍는
                      #     경우가 있어 None 이 곧 "안전한 기본" 이다. 그래서
                      #     _spin_setup_ok 은 None 을 통과로 본다 — 그 해석을 여기 적어
                      #     둔다(안 적으면 다음 사람이 fail-closed 로 바꿔 전 잡을 막는다).
                      "LNONCOLLINEAR", "LSORBIT", "I_CONSTRAINED_M", "BEXT")

# ── 되울림 형식 3종 (2026-08-25 실측, wave1 43개 OUTCAR) ─────────────────────
#   ① 행두형: `   ENCUT  =  520.0 eV …` · `   NUPDOWN=      -1.0000` (= 앞 공백 0개 허용)
#   ② 산문형: LDA+U 계열은 행 **중간**에 있다 —
#        ` LDA+U is selected, type is set to LDAUTYPE =  2`
#        `   U (eV)           for each species LDAUU =   0.0  6.2  0.0  0.0  0.0`
#      행두 앵커로는 한 줄도 안 잡힌다. 고정 산문을 앵커로 쓴다.
#   ③ 미되울림: MAGMOM · ADDGRID 는 OUTCAR 어디에도 없다(grep 0건) —
#      **원리적으로 검증 불가**이므로 영원히 unverified 로 보고한다 (조용한 통과 금지).
_ECHO_PROSE = {
    "LDAUTYPE": r"type is set to LDAUTYPE\s*=\s*(\S+)",
    "LDAUL": r"for each species LDAUL\s*=\s*([^\n]+)",
    "LDAUU": r"for each species LDAUU\s*=\s*([^\n]+)",
    "LDAUJ": r"for each species LDAUJ\s*=\s*([^\n]+)",
}
_ECHO_ABSENT = ("MAGMOM", "ADDGRID")

# ── OUTCAR 되울림 ↔ INCAR 선언 대조 (2026-08-25) ─────────────────────────────
#   VASP 는 INCAR 표기를 그대로 되울리지 않는다: 520 → `520.0`, `.TRUE.` → `T`,
#   `Auto` → `T`. 문자열 비교로는 전부 불일치로 잡혀 게이트가 30/30 오탐을 냈다.
_TRUE = {"T", "TRUE", ".TRUE."}
_FALSE = {"F", "FALSE", ".FALSE."}
#   LREAL 은 Auto·On·A·O 가 전부 "실공간" 이고 되울림은 `T` 하나뿐이다.
_LREAL_REAL = {"AUTO", "A", "ON", "O"} | _TRUE
_LREAL_RECIP = set(_FALSE)


def _echo_val(text, key):
    """OUTCAR 의 **파라미터 줄**에서 key 의 값을 읽는다 (산문·경고문 제외).

    행두형은 행두 공백 앵커로(권고 상자는 `|` 시작이라 걸러진다), LDA+U 계열은
    고정 산문 앵커로 읽는다(행 중간이라 행두 앵커가 못 잡는다 — 2026-08-25 실측).
    목록 키는 **줄 끝까지** 캡처해 공백 정규화한다 — 한 토큰만 읽으면
    `LDAUU = 0.0 6.2 0.0` 이 `0.0` 으로 잘려 실제 U 차이를 못 잡는다 (codex E-1).

    이 함수가 못 하는 것: MAGMOM·ADDGRID 는 OUTCAR 가 되울리지 않아 **원리적으로
    None** 이다 — 호출부가 unverified 로 보고한다 (통과도 실패도 아니다).
    """
    if key in _ECHO_ABSENT:
        return None
    if key == "LDAU":
        # 직접 되울림 줄이 없다 — "LDA+U is selected" 산문의 존재가 곧 T 다 (실측).
        # ⚠ 켜져 있을 때만 판별 가능: .FALSE. 는 산문이 없어 None(unverified)로 남는다.
        return "T" if "LDA+U is selected" in text else None
    pat = _ECHO_PROSE.get(key)
    if pat:
        m = re.search(pat, text)
        return " ".join(m.group(1).split()) if m else None
    m = re.search(r"^[ \t]{0,8}" + key + r"\s*=\s*([-\w.]+)", text, re.M)
    return m.group(1) if m else None


def _incar_match(key, got, want):
    """되울림 got 과 선언 want 대조 → (일치 여부, 종류).

    종류 (codex E-2 분류):
      "exact"             — 같은 값 (표기 차이만: 520.0↔520, T↔.TRUE., 목록 원소별)
      "equivalence_class" — **같은 값임을 보증 못 하고 같은 계열임만 보증**.
                            LREAL 의 Auto/On/.TRUE. 는 알고리즘이 서로 다른데
                            VASP 가 전부 `T` 로만 되울려 계열까지만 갈라진다.
      "mismatch"          — 다르다.

    수치는 **Decimal** 로 비교한다 (codex E-1) — float 는 `1e309` 가 inf 로 붙어
    서로 다른 두 값이 같아질 수 있고, 큰 정수에서 정밀도를 잃는다.
    비유한값(inf/nan 표기)은 일치로 치지 않는다.
    """
    from decimal import Decimal, InvalidOperation

    def _nonfinite(s):
        for tok in s.split():
            try:
                if not Decimal(tok).is_finite():
                    return True
            except (InvalidOperation, ValueError):
                pass
        return False

    g, w = str(got).strip(), str(want).strip()
    # ⚠ 비유한값 검사가 문자열 지름길보다 **먼저**다 — "inf"=="inf" 가 문자열로
    #   같아서 통과해 버리면 이 가드는 죽은 코드가 된다 (selftest 가 실제로 잡았다).
    if _nonfinite(g) or _nonfinite(w):
        return False, "mismatch"
    gu, wu = g.upper(), w.upper()
    if gu.strip(".") == wu.strip("."):          # .TRUE. ↔ TRUE 도 여기서 걸린다
        return True, "exact"
    if key == "LREAL":
        known = _LREAL_REAL | _LREAL_RECIP
        if gu in known and wu in known:
            same = (gu in _LREAL_REAL) == (wu in _LREAL_REAL)
            return (True, "equivalence_class") if same else (False, "mismatch")
        return False, "mismatch"
    if gu in _TRUE | _FALSE and wu in _TRUE | _FALSE:
        return ((gu in _TRUE) == (wu in _TRUE)), "exact"
    try:                                         # 520.0 ↔ 520 · LDAUU 목록도 원소별
        gd = [Decimal(x) for x in g.split()]
        wd = [Decimal(x) for x in w.split()]
    except (InvalidOperation, ValueError):
        return False, "mismatch"
    if any(not x.is_finite() for x in gd + wd):
        return False, "mismatch"
    ok = len(gd) == len(wd) and all(a == b for a, b in zip(gd, wd))
    return ok, ("exact" if ok else "mismatch")


def _incar_equal(key, got, want):
    """(하위호환 래퍼) — 일치 여부만. 종류가 필요하면 _incar_match 를 쓸 것."""
    return _incar_match(key, got, want)[0]

RCOV = {"H": 0.31, "B": 0.84, "C": 0.76, "N": 0.71, "O": 0.66, "F": 0.57,
        "Na": 1.66, "P": 1.07, "S": 1.05, "Cl": 1.02, "Li": 1.28, "Ni": 1.24}
BOND_F = 1.25             # 결합 = d < BOND_F × (r_i + r_j)
DETACH_A = 4.0            # 분자-슬랩 최소거리가 이보다 크면 탈착
FIX_DRIFT_A = 0.10        # 고정(F F F) 원자가 이보다 움직이면 파일 불일치
FORCE_TOL = 0.05          # eV/Å — 자유원자 잔여 힘 경고
RECON_A = 0.60            # Å — 자유 상부 양이온이 이만큼 움직이면 재구성
LI_OUT_A = 0.80           # Å — Li 가 바깥(+z)으로 이만큼 나오면 추출 의심
LI_O_A = 2.60             # Å — Li–O 배위 반경
LI_COORD_LOSS = 2         # O 배위가 이만큼 줄면 추출로 본다
MOM_MIN = 0.30            # μB — **개별 검토 trigger** (판정 문턱 아님, Codex Q7)
Q_RATIO_MIN = 0.50        # clean 대비 Q 가 이 아래면 집단 붕괴 (초기 민감도)
F_SMALL_MAX = 0.25        # |m|<MOM_MIN 비율이 이 위면 집단 붕괴 (초기 민감도)
#: 준중심(semicore) 변형이 다르면 원자가 전자 수가 달라진다 — 일관돼도 치명이다.
SEMICORE = ("_pv", "_sv", "_h", "_s", "_d")


def _read_text(path):
    try:
        if os.path.isfile(path):
            # ⛔ 2026-08-25 — `.gz` 경로를 그대로 주면 gzip 바이너리를 errors="ignore"
            #   로 읽어 **깨진 문자열을 조용히 돌려줬다**. 그러면 모든 정규식이 안
            #   맞아 E0·NIONS·되울림이 전부 None 이 되는데, None 은 "없음" 으로만
            #   보여 원인이 안 드러난다. 매직바이트로 판별한다 (확장자 말고).
            with open(path, "rb") as fh:
                if fh.read(2) == b"\x1f\x8b":
                    return gzip.open(path, "rt", errors="ignore").read()
            return open(path, errors="ignore").read()
        if os.path.isfile(path + ".gz"):
            return gzip.open(path + ".gz", "rt", errors="ignore").read()
    except OSError:
        pass
    return None


def global_sign(moments, want):
    """시드 부호 want 에 대해 관측 모멘트의 **전역 부호**를 정한다.

    ⚠ 전역 반전은 시간반전이라 **같은 상태**다. 그래서 부호를 정규화한 뒤
      *부분* 반전만 문제 삼아야 한다. static 과 dense 가 이 규칙을 따로 구현하면
      갈린다 — 실제로 dense 가 static 의 부호를 재사용해, dense 가 완전한
      시간반전으로 수렴했을 때 전부 불일치로 잡는 **거짓 차단**이 났다
      (Codex 5차 P1-2). 한 함수로 둔다.

    반환 (sg, 불일치 인덱스). want/moments 는 {인덱스: 값} 이다.
    """
    ag = {s: sum(1 for i, v in want.items() if moments.get(i, 0.0) * s * v > 0)
          for s in (1.0, -1.0)}
    sg = 1.0 if ag[1.0] >= ag[-1.0] else -1.0
    bad = [i for i, v in want.items() if moments.get(i, 0.0) * sg * v <= 0]
    return sg, bad


#: 회신 AA Q5 — **단일 문턱 금지.** 확실한 붕괴 / 회색 / 확실한 자성으로 나누고
#: 회색은 unresolved 로 뺀다. 값은 wave1 clean slab 분포(|m| ~1.2 μB)와 반복
#: 산포에서 잡았다: 0.25 아래는 어떤 basin 에서도 안 나오고, 0.55 위는 정상
#: Ni 모멘트다. 그 사이는 **우리가 못 가르는 구간**이다.
MOM_COLLAPSE = 0.25      # 이 아래 = 확실한 붕괴
MOM_MAGNETIC = 0.55      # 이 위   = 확실한 자성
#: 같은 부호벡터라도 크기가 이보다 더 벌어지면 자동 동일 판정하지 않는다 (Q5)
MOM_RMS_TOL = 0.30       # μB


def _spin_setup_ok(incar_echo):
    """전역 시간반전을 접어도 되는 계인가 (회신 AA Q5).

    collinear · SOC 없음 · 외부장 없음 · signed spin constraint 없음일 때만
    `+++−` 와 `−−−+` 가 같은 상태다. **INCAR 되울림에서 기계적으로 확인한다** —
    전제를 사람이 기억하는 것에 맡기지 않는다.
    """
    # 🔴 회신 AB P0-5 — `str(None)` 이 **"NONE"** 이 된다. 종전 정규화는 None 을
    #   그 문자열로 만들었고, 그러면 `not in (None, "", "0")` 이 참이라 **미출력이
    #   곧 "스핀 제약 있음"** 이 됐다. 이 키들이 AUDIT_KEYS_RUNTIME 에 없어서
    #   실제 OUTCAR 경로로는 한 번도 안 들어왔기 때문에 드러나지 않았다 —
    #   손으로 만든 dict 를 넣는 단위시험만 통과하던 자리다.
    #   ⚠ VASP 는 이 넷이 기본값이면 **되울리지 않는다**. 그러므로 미출력(None)은
    #     "확인 불가" 가 아니라 **기본값(꺼짐)** 으로 읽는 것이 맞다. 반대로
    #     fail-closed 로 두면 전 잡이 BASIN_UNRESOLVED 가 된다(실측).
    e = {str(k).upper(): (None if v is None else str(v).strip().upper().strip("."))
         for k, v in (incar_echo or {}).items()}
    bad = []
    if e.get("LNONCOLLINEAR") in ("T", "TRUE"):
        bad.append("LNONCOLLINEAR=T (비공선)")
    if e.get("LSORBIT") in ("T", "TRUE"):
        bad.append("LSORBIT=T (SOC)")
    if e.get("I_CONSTRAINED_M") not in (None, "", "0"):
        bad.append(f"I_CONSTRAINED_M={e.get('I_CONSTRAINED_M')} (스핀 제약)")
    if e.get("BEXT") not in (None, "", "0", "0.0", "0.00"):
        bad.append(f"BEXT={e.get('BEXT')} (외부장)")
    return (not bad), bad


def realized_basin_id(mom, ni_sign, mol_sign, mom_min=None, incar_echo=None):
    """OUTCAR 국소모멘트 표 → **실제로 수렴한** 자기 basin 의 지문 (회신 Z P0-4).

    `pm1` · `net4` 는 **초기 MAGMOM seed 이름**이지 최종 상태가 아니다. wave1.5 에서
    raw `net4` 가 의도한 topology 가 아니라 Ni 하나 뒤집힌 basin 으로 반복 수렴한
    전례가 있다. seed 이름으로 짝지어 빼면 상태를 가로질러 뺀 것이 된다.

    v2 (회신 AA Q5 반영):
      · 전역 시간반전을 접기 전에 **collinear·무SOC·무외부장·무제약**을 INCAR
        되울림에서 확인한다. 아니면 접지 않고 unresolved 를 낸다.
      · 붕괴 판정을 **두 문턱**으로 (확실한 붕괴 / 회색 / 확실한 자성).
        회색이 하나라도 있으면 지문을 만들지 않는다 — 그 자리가 basin 을 가른다.
      · 지문 해시는 **정규화 canonical JSON 의 full SHA256**. 12자는 표시용이다.
      · raw 모멘트 벡터와 Ni 인덱스 매핑을 그대로 보존한다 (사후 재판독용).

    반환 (id, detail) — id 가 None 이면 사유가 detail["why"] 에 있다.

    ⛔ 이 함수가 **못 하는 것**
      · 어느 basin 이 **바닥**인지 말하지 못한다. 같은가 다른가만 가른다.
      · OUTCAR 의 site moment 는 PAW 구 안으로 투영한 **관측량**이지 basin 그
        자체가 아니다. 같은 설정 안에서만 쓰는 지문이다.
      · 모멘트 표가 없거나 불완전하면 **추측하지 않는다** — None 을 낸다.
      · Ni 인덱스 집합이 다른 두 계(다른 슬랩)를 비교할 수 없다.
    """
    if not mom:
        return None, {"why": "모멘트 표 없음 (LORBIT)"}
    ni = {int(k): float(v) for k, v in (ni_sign or {}).items()}
    if not ni:
        return None, {"why": "ni_sign_poscar_idx 없음"}
    if max(ni) >= len(mom):
        return None, {"why": f"Ni 인덱스가 모멘트 표 {len(mom)}행 밖"}
    if incar_echo is not None:
        ok_setup, why = _spin_setup_ok(incar_echo)
        if not ok_setup:
            return None, {"why": "전역 시간반전을 접을 수 없는 설정: " + " · ".join(why)}
    got = {i: mom[i] for i in ni}
    sg, _flip = global_sign(got, ni)
    idx = sorted(ni)
    gray = [k for k, i in enumerate(idx) if MOM_COLLAPSE <= abs(got[i]) < MOM_MAGNETIC]
    if gray:
        return None, {"why": (f"회색구간 모멘트 {len(gray)}자리 "
                              f"({MOM_COLLAPSE}–{MOM_MAGNETIC} μB) — 붕괴인지 자성인지 "
                              f"못 가른다. 이 잡으로는 뺄셈하지 않는다"),
                      "gray_positions": gray,
                      "gray_moments_muB": [round(got[idx[k]], 3) for k in gray]}
    vec = "".join("+" if got[i] * sg > 0 else "-" for i in idx)
    collapsed = [k for k, i in enumerate(idx) if abs(got[i]) < MOM_COLLAPSE]
    ms = {int(k): float(v) for k, v in (mol_sign or {}).items() if int(k) < len(mom)}
    org = "".join("+" if mom[i] * sg > 0 else "-" for i in sorted(ms)) if ms else ""
    # 정규화 canonical JSON → full SHA256 (12자는 표시용)
    canon = json.dumps({"ni_sign_vector": vec, "collapsed": collapsed,
                        "organic_relative_spin": org},
                       sort_keys=True, separators=(",", ":"), ensure_ascii=False)
    full = hashlib.sha256(canon.encode()).hexdigest()
    return full, {
        "id_short": full[:12], "canonical": canon,
        "ni_sign_vector": vec, "n_ni": len(idx), "global_sign": sg,
        "collapsed_ni_positions": collapsed, "organic_relative_spin": org or None,
        "ni_index_poscar": idx,
        "ni_moments_muB": [round(got[i], 4) for i in idx],
        "abs_mean_muB": round(sum(abs(got[i]) for i in idx) / len(idx), 4),
        "thresholds": {"collapse": MOM_COLLAPSE, "magnetic": MOM_MAGNETIC},
        "⚠": "seed 이름이 아니라 **수렴 결과**의 지문이다. site moment 는 PAW 투영 관측량이다"}


def basin_distance(da, db):
    """두 realized basin 사이의 **거리** (회신 AA Q5-c).

    지문이 다르다는 것만으로는 "얼마나 다른가" 를 못 말한다. Ni 하나가 뒤집힌
    것과 20개가 뒤집힌 것은 다른 사건이다.

    반환: {hamming, collapse_symdiff, moment_rms_muB, moment_max_muB,
           flipped_index_poscar, same}
    `same` 은 부호·붕괴가 같고 **크기 RMS 도 MOM_RMS_TOL 안**일 때만 참이다 —
    같은 부호라도 크기가 크게 다르면 자동 동일 판정하지 않는다.
    """
    if not da or not db:
        return None
    va, vb = da.get("ni_sign_vector"), db.get("ni_sign_vector")
    ia, ib = da.get("ni_index_poscar"), db.get("ni_index_poscar")
    if not (va and vb) or len(va) != len(vb) or ia != ib:
        return {"same": False, "why": "Ni 인덱스 집합이 다르다 — 비교 불가"}
    ham = [k for k in range(len(va)) if va[k] != vb[k]]
    ca, cb = set(da.get("collapsed_ni_positions") or []), set(db.get("collapsed_ni_positions") or [])
    ma = da.get("ni_moments_muB") or []
    mb = db.get("ni_moments_muB") or []
    sa, sb = da.get("global_sign", 1.0), db.get("global_sign", 1.0)
    diff = [abs(ma[k] * sa - mb[k] * sb) for k in range(min(len(ma), len(mb)))]
    rms = (sum(x * x for x in diff) / len(diff)) ** 0.5 if diff else float("inf")
    mx = max(diff) if diff else float("inf")
    return {"hamming": len(ham), "flipped_index_poscar": [ia[k] for k in ham],
            "collapse_symdiff": sorted(ca ^ cb),
            "moment_rms_muB": round(rms, 4), "moment_max_muB": round(mx, 4),
            "same": (not ham and not (ca ^ cb) and rms <= MOM_RMS_TOL),
            "rms_tol_muB": MOM_RMS_TOL}


def read_moments(t):
    """LORBIT=11 의 마지막 'magnetization (x)' 표 → 이온별 tot 모멘트 [μB]."""
    k = t.rfind("magnetization (x)")
    if k < 0:
        return None
    out = []
    for ln in t[k:].splitlines()[1:]:
        v = ln.split()
        if len(v) == 5 and v[0].isdigit():
            try:
                out.append(float(v[4]))
            except ValueError:
                break
        elif out:
            break
    return out or None


def read_ldau(t):
    """LDAUPRINT=2 의 onsite density matrix → {원자: [n_up, n_dn]}. 없으면 None.

    ⚠ 모멘트 projector 하나에 자기상태 판정을 맡기지 않으려고 둔다 (Codex P0-2).
      **판정용이 아니라 기록용**이다 — 절대값은 PAW sphere 규약에 의존한다.
    """
    out = {}
    for m in re.finditer(r"atom\s*=\s*(\d+)\s+type\s*=\s*\d+\s+l\s*=\s*(\d+)", t):
        a, l = int(m.group(1)), int(m.group(2))
        n = 2 * l + 1
        seg = t[m.end():m.end() + 6000]
        traces = []
        for sm in re.finditer(r"spin component\s+\d+", seg):
            rows = []
            for ln in seg[sm.end():].splitlines()[1:]:
                v = ln.split()
                if len(v) == n:
                    try:
                        rows.append([float(x) for x in v])
                    except ValueError:
                        break
                elif rows:
                    break
                if len(rows) == n:
                    break
            if len(rows) == n:
                traces.append(round(sum(rows[i][i] for i in range(n)), 4))
            if len(traces) == 2:
                break
        if len(traces) == 2:
            out[a] = traces          # 뒤에 나온 이온스텝이 앞을 덮는다 = 최종값
    return out or None


def _pk(path, root):
    """잡 키를 **POSIX 구분자**로 정규화한다.

    ⚠ os.path.relpath 는 Windows 에서 `tier1\\job` 을 낸다. MANIFEST 의 prefix 는
      `tier1/job` 이라, 개별 잡이 멀쩡해도 pair 조회가 전부 실패해 "필수 산출 누락"
      으로 보였다 (2026-08-12 Codex 재감사 P0-6). 키는 한 표기법이어야 한다.
    """
    return os.path.relpath(path, root).replace(os.sep, "/").replace("\\", "/").strip("/")


# ══ OUTCAR 엄격 판독 (2026-08-25 codex E-3) ══════════════════════════════════
#   errors="ignore" 금지 — 깨진 바이트가 낀 `ENC\xffUT` 이 `ENCUT` 으로 붙어
#   **거짓 정상**을 만들고, 잘린 gzip 은 예외로 분석기 전체를 죽이며, UTF-16 은
#   NUL 이 낀 채 조용히 오독된다. 전부 판독 실패(OUTCAR_READ_ERROR)로 승격한다.
def _read_outcar_raw(p):
    """→ (text|None, meta). meta = {read_error, format, suffix_magic_mismatch}.

    이 함수가 못 하는 것: 내용의 물리적 타당성. **읽기 신뢰성**까지만 책임진다.
    """
    meta = {"read_error": None, "format": None, "suffix_magic_mismatch": False}
    base = p[:-3] if p.endswith(".gz") else p
    plain, gz = os.path.isfile(base), os.path.isfile(base + ".gz")
    if plain and gz:
        meta["read_error"] = "OUTCAR 와 OUTCAR.gz 가 둘 다 있다 — 어느 쪽이 정본인지 판정 불가"
        return None, meta
    path = base if plain else (base + ".gz" if gz else None)
    if path is None:
        return None, meta                      # 파일 없음 = NOT_RUN (read_error 아님)
    try:
        raw = open(path, "rb").read()
    except OSError as e:
        meta["read_error"] = f"open 실패: {e}"
        return None, meta
    is_gz_magic = raw[:2] == b"\x1f\x8b"
    meta["suffix_magic_mismatch"] = (path.endswith(".gz") != is_gz_magic)
    if is_gz_magic:
        try:
            raw = gzip.decompress(raw)         # CRC·절단이 여기서 예외로 드러난다
        # ⚠ py3.6 호환 — gzip.BadGzipFile 은 3.8+ 이고 OSError 의 하위클래스다.
        #   wave1.5 회신(2026-08-28)이 실측으로 알려줬다: 클러스터 파이썬이 3.6.8 이라
        #   손상 .gz 를 만나면 깔끔한 오류 대신 AttributeError 로 죽는다.
        except (OSError, EOFError) as e:
            meta["read_error"] = f"gzip 손상/절단: {type(e).__name__} {e}"
            return None, meta
    if b"\x00" in raw[:4096]:
        meta["read_error"] = "NUL 바이트 검출 — UTF-16/바이너리 오염 의심"
        return None, meta
    try:
        text = raw.decode("utf-8", errors="strict")
    except UnicodeDecodeError as e:
        meta["read_error"] = f"디코드 실패(비ASCII 오염): offset {e.start}"
        return None, meta
    meta["format"] = "gzip" if is_gz_magic else "plain"
    return text, meta


def _last_run_segment(text):
    """이어붙은 OUTCAR 를 실행 단위로 갈라 **마지막 완결 실행**을 고른다.

    (2026-08-25 codex E) 여러 실행이 한 파일에 이어지면 옛 코드는 파라미터를 첫
    실행에서, 에너지를 마지막에서, 정상종료를 아무 데서나 읽어 **서로 다른 실행을
    섞었다.** 실행 경계는 버전 배너(행두 ` vasp.`)다.

    → (segment_text, {"n": 배너수, "used": "only|last_complete|last_incomplete",
                       "used_index": i})
    """
    starts = [m.start() for m in re.finditer(r"(?m)^ vasp\.[\w.]+", text)]
    if len(starts) <= 1:
        return text, {"n": max(len(starts), 1) if text.strip() else 0,
                      "used": "only", "used_index": 0}
    segs = [text[s:e] for s, e in zip(starts, starts[1:] + [len(text)])]
    for i in range(len(segs) - 1, -1, -1):
        if "General timing and accounting" in segs[i]:
            return segs[i], {"n": len(segs), "used": "last_complete", "used_index": i}
    return segs[-1], {"n": len(segs), "used": "last_incomplete",
                      "used_index": len(segs) - 1}


def read_outcar(p):
    t, rmeta = _read_outcar_raw(p)
    if rmeta["read_error"]:
        return {"read_error": rmeta["read_error"], "normal_end": False, "E0": None,
                "edisp_eV": None, "edisp_n": 0,
                "nelm_hit": False, "ionic_conv": False, "nions": None, "nkpts": None,
                "titels": [], "incar_echo": {}, "moments": None, "mag_total": None,
                "run_segments": None}
    if t is None:
        return None
    t, seg = _last_run_segment(t)
    e = re.findall(r"energy\(sigma->0\)\s*=\s*(-?[\d.]+)", t)
    # ── D3 분산항. **VASP 가 IVDW=11 에서 직접 찍는다** (repo 실물 확인:
    #   runs/sdcp_phaseB_vasp_v1_2026_08_08/{slab,mol_neutral,complex_neutral}/OUTCAR.gz
    #   → " Edisp (eV)  -27.49493 / -0.71798 / -28.58614").
    #   D3 는 SCF 에 안 들어가고 핵좌표만 보고 총에너지에 **더해지는** 항이라
    #   고정기하 static 에서 `E_on − E_off = Edisp` 가 **항등식**이다 ⇒ C3 의 세 괄호가
    #   각각 Edisp 로 접힌다. 그래서 D3-off 쌍둥이 잡이 **필요 없다**.
    #   ⚠ NSW>0 이면 이온스텝마다 갱신될 수 있으므로 **마지막 것**을 쓴다. 이 캠페인은
    #     전 잡 NSW=0 이라 하나뿐이고, 개수도 같이 돌려준다(검사용).
    _ed = re.findall(r"Edisp\s*\(eV\)\s*:?\s*(-?[\d.]+)", t)
    nions = re.search(r"NIONS\s*=\s*(\d+)", t)
    nk = re.search(r"NKPTS\s*=\s*(\d+)", t)
    nelm = re.search(r"NELM\s*=\s*(\d+)", t)
    iters = re.findall(r"Iteration\s+\d+\(\s*(\d+)\)", t)
    ver = re.search(r"vasp\.([\w.]+)", t)
    # 파일 존재가 아니라 **읽었다는 로그**로 승계를 증명한다 (Codex Q4)
    read_wav = bool(re.search(r"reading WAVECAR|WAVECAR.*read|initial charge.*wavefunc", t, re.I))
    fell_back = bool(re.search(r"ISTART.*=.*0.*job.*fresh|WAVECAR not read|"
                               r"wave function.*not.*found|reading from scratch", t, re.I))
    titels = re.findall(r"TITEL\s*=\s*(.+)", t)
    mag = re.findall(r"number of electron\s+[\d.]+\s+magnetization\s+(-?[\d.]+)", t)
    forces = None
    # ★ 실행 기하 감사용 — OUTCAR 안의 **실제 좌표**. phase POSCAR 를 반송받지 않아도
    #   VASP 가 무엇을 읽었는지 여기서 확인할 수 있다 (Codex zip 감사 P0-6).
    positions = None
    k0 = t.rfind("POSITION")
    if k0 > 0:
        positions = []
        for ln in t[k0:].splitlines()[2:]:
            v = ln.split()
            if len(v) >= 6:
                try:
                    positions.append([float(v[0]), float(v[1]), float(v[2])])
                except ValueError:
                    break
            elif positions:
                break
    k = t.rfind("TOTAL-FORCE")
    if k > 0:
        forces = []
        for ln in t[k:].splitlines()[2:]:
            v = ln.split()
            if len(v) >= 6:
                try:
                    forces.append([float(v[3]), float(v[4]), float(v[5])])
                except ValueError:
                    break
            else:
                break
    # CHGCAR 를 **실제로 읽었는가** — vasp.log 가 아니라 OUTCAR 자체의 마커 (실측):
    #   ICHARG=1: `initial charge density was supplied:` 만 있고
    #   ICHARG=2: 그 밑에 `charge density of overlapping atoms calculated`
    #             (원자에서 새로 만듦) 가 따라온다. 후자가 있으면 파일을 안 읽은 것.
    _sup = "initial charge density was supplied" in t
    _atoms = "charge density of overlapping atoms calculated" in t
    chg_from_file = (True if (_sup and not _atoms) else
                     False if _atoms else None)
    return {"E0": float(e[-1]) if e else None,
            "edisp_eV": float(_ed[-1]) if _ed else None,
            "edisp_n": len(_ed),
            "chgcar_from_file": chg_from_file,
            "ionic_conv": "reached required accuracy" in t,
            # ⚠ 정상종료를 안 보면 **잘린 OUTCAR 도 에너지만 있으면 통과**한다
            "normal_end": "General timing and accounting" in t,
            "nelm_hit": bool(nelm and iters
                             and any(int(x) >= int(nelm.group(1)) for x in iters)),
            "nions": int(nions.group(1)) if nions else None,
            "nkpts": int(nk.group(1)) if nk else None,
            "read_wavecar": read_wav, "restart_fell_back": fell_back,
            "titels": [x.strip() for x in titels],
            "vasp_version": ver.group(1) if ver else None,
            "mag_total": float(mag[-1]) if mag else None,
            "moments": read_moments(t), "forces": forces,
            "positions": positions,
            "ldau": read_ldau(t),
            "run_segments": seg, "read_format": rmeta["format"],
            "suffix_magic_mismatch": rmeta["suffix_magic_mismatch"],
            # ⛔ 2026-08-25 (sdcp_wave1 회신) — 이 검색은 **앵커가 없어서 산문도 물었다.**
            #   분자 박스 OUTCAR 129행의 VASP 권고문
            #     `|      So try LREAL= Auto  in the INCAR   file.  |`
            #   이 첫 매치라, 실제 파라미터 줄이 `LREAL = F` 인데도 got="Auto" 가 나와
            #   `LREAL: Auto!=.FALSE.` 오탐이 났다. 파라미터 줄만 보도록 행두 고정.
            "incar_echo": {k2: _echo_val(t, k2) for k2 in AUDIT_KEYS_RUNTIME}}


def read_poscar(p):
    """POSCAR/CONTCAR (Direct/Cartesian · Selective 지원). 실패 시 None."""
    t = _read_text(p)
    if t is None:
        return None
    try:
        L = t.splitlines()
        scale = float(L[1].split()[0])
        cell = [[float(x) * scale for x in L[i].split()[:3]] for i in (2, 3, 4)]
        i = 5
        species = None
        if not L[i].split()[0].isdigit():
            species = L[i].split(); i += 1
        counts = [int(x) for x in L[i].split()]; i += 1
        seldyn = False
        if L[i].strip() and L[i].strip()[0] in "Ss":
            seldyn = True; i += 1
        direct = bool(L[i].strip()) and L[i].strip()[0] in "Dd"
        i += 1
        n = sum(counts)
        pos, fixed = [], []
        for k in range(n):
            v = L[i + k].split()
            xyz = [float(x) for x in v[:3]]
            if direct:
                xyz = [sum(xyz[j] * cell[j][ax] for j in range(3)) for ax in range(3)]
            else:
                xyz = [x * scale for x in xyz]
            pos.append(xyz)
            fixed.append(seldyn and len(v) >= 6 and
                         all(f.upper().startswith("F") for f in v[3:6]))
        syms = []
        if species:
            for s, c in zip(species, counts):
                syms += [s] * c
        return {"cell": cell, "pos": pos, "fixed": fixed, "syms": syms,
                "species": species, "counts": counts}
    except Exception:
        return None


def mic_dist(a, b, cell):
    best = None
    for u in (-1, 0, 1):
        for v in (-1, 0, 1):
            for w in (-1, 0, 1):
                d = [a[x] - b[x] - u * cell[0][x] - v * cell[1][x] - w * cell[2][x]
                     for x in range(3)]
                r = math.sqrt(sum(x * x for x in d))
                best = r if best is None or r < best else best
    return best


def mol_bond_graph(struct, mol_idx):
    """분자 내부 결합 집합 {(i,j)} — 공유반경 기준."""
    bonds = set()
    syms = struct["syms"]
    for a in range(len(mol_idx)):
        for b in range(a + 1, len(mol_idx)):
            i, j = mol_idx[a], mol_idx[b]
            cut = BOND_F * (RCOV.get(syms[i], 1.0) + RCOV.get(syms[j], 1.0))
            if mic_dist(struct["pos"][i], struct["pos"][j], struct["cell"]) < cut:
                bonds.add((i, j))
    return bonds


def contact_fp(struct, mol_idx, slab_idx):
    """접촉 지문 — 분자에서 CONTACT_A 안에 있는 슬랩 원자 인덱스 집합."""
    fp = set()
    for i in slab_idx:
        for m in mol_idx:
            if mic_dist(struct["pos"][i], struct["pos"][m], struct["cell"]) < CONTACT_A:
                fp.add(i)
                break
    return fp


def geometry_audit(jd, meta):
    """relax/CONTCAR vs POSCAR — 등록·결합그래프·탈착·고정 drift. (게이트, 정보) 반환."""
    gates, info = [], {}
    init = read_poscar(os.path.join(jd, "POSCAR"))
    sp_only = "relax" not in (meta.get("phases") or ["relax"])
    # ⚠ 단일점 모드는 CONTCAR 가 없다 — 기하가 안 변하므로 POSCAR 가 곧 최종이다.
    #   그렇다고 검사를 끄지 않는다: 등록·결합 감사는 그대로 돌아 자세가 의도대로인지 본다.
    fin = init if sp_only else read_poscar(os.path.join(jd, "relax", "CONTCAR"))
    info["single_point"] = sp_only
    if init is None or fin is None or len(fin["pos"]) != len(init["pos"]):
        gates.append("REGISTRY_UNVERIFIED(CONTCAR 없음/파싱 실패/원자수 불일치)")
        return gates, info
    # ⚠ 원자수만 같고 종/셀이 다르면 다른 계다 (Codex P0-G)
    if fin.get("species") and init.get("species") and fin["species"] != init["species"]:
        gates.append(f"SPECIES_MISMATCH({fin['species']}!={init['species']})")
    if fin.get("counts") and init.get("counts") and fin["counts"] != init["counts"]:
        gates.append("COUNTS_MISMATCH(POSCAR vs CONTCAR)")
    dcell = max(abs(fin["cell"][i][j] - init["cell"][i][j])
                for i in range(3) for j in range(3))
    info["cell_drift_A"] = round(dcell, 4)
    if dcell > 1e-3:
        gates.append(f"CELL_CHANGED({dcell:.3f} Å — ISIF=2 인데 셀이 바뀌었다)")
    if not fin["syms"]:
        fin["syms"] = init["syms"]
    mol = meta.get("mol_poscar_idx") or []
    # ★ 등록은 **표면 양이온**으로만 판정한다 — 먼 H/C 나 표면 아래 양이온이
    #   라벨을 정하면 안 된다 (Codex P0-G). 표면 목록이 없으면 전체로 후퇴하되 표시한다.
    top_li = meta.get("top_li_poscar_idx") or meta.get("slab_li_poscar_idx") or []
    top_ni = meta.get("top_ni_poscar_idx") or meta.get("slab_ni_poscar_idx") or []
    if mol and (top_li or top_ni):
        def dmin(idxs):
            return min((mic_dist(fin["pos"][m], fin["pos"][i], fin["cell"])
                        for m in mol for i in idxs), default=1e9)
        dli, dni = dmin(top_li), dmin(top_ni)
        info["registry"] = {"d_Li": round(dli, 3), "d_Ni": round(dni, 3),
                            "nearest": "Li" if dli < dni else "Ni",
                            "top_only": bool(meta.get("top_li_poscar_idx"))}
        # 🔴 회신 AB P0-1 — `role` 이 **두 가지 뜻**으로 쓰이고 있었다.
        #   champion/cross 경로는 `role = "Li"|"Ni"`(등록 역할)를 쓰는데,
        #   from_basins 경로는 `role = "calibration"|"holdout"`(분석 역할)을 쓴다.
        #   그래서 동결본 번들의 복합체 전 잡이 `calibration -> Ni` 로 **항상**
        #   불일치했다 — OUTCAR 가 와도 그대로 막힌다.
        #   ⇒ 등록 기대는 `registry_role` 에서만 읽고, 옛 번들 호환으로
        #     `role` 은 그 값이 실제 Li/Ni 일 때만 받는다.
        want = meta.get("registry_role")
        if want is None and meta.get("role") in ("Li", "Ni"):
            want = meta["role"]
        info["registry"]["expected"] = want
        if want is None:
            # ⚠ **조용한 통과가 아니다.** 기대가 없다는 사실을 기록한다 —
            #   안 적으면 나중에 "검사했는데 통과" 로 읽힌다.
            info["registry"]["checked"] = False
        if want and info["registry"]["nearest"] != want:
            # ⚠ 단일점에서 이건 "이완 중 옮겨갔다" 가 아니라 **애초에 그 자리가 아니다**
            #   이다 (Codex 6차 §4). 이름이 원인을 오도하면 진단이 엉뚱한 데로 간다.
            gates.append(("SOURCE_ROLE_MISMATCH" if sp_only else "PAIR_MIGRATED")
                         + f":{want}->{info['registry']['nearest']}")
        slab_idx = (meta.get("slab_li_poscar_idx") or []) + \
                   (meta.get("slab_ni_poscar_idx") or [])
        dsl = min((mic_dist(fin["pos"][m], fin["pos"][i], fin["cell"])
                   for m in mol for i in slab_idx), default=1e9)
        info["mol_slab_min_A"] = round(dsl, 3)
        if dsl > DETACH_A:
            gates.append(f"DETACHED(분자-슬랩 {dsl:.2f} Å > {DETACH_A})")
        # ⚠ 지문에 **O 도 넣는다** — Li/Ni 만 보면 O 쪽 접촉 재구성을 못 본다 (Codex Q3)
        o_idx = [i for i, sy in enumerate(fin["syms"]) if sy == "O" and i not in mol]
        info["_contact_fp"] = sorted(contact_fp(fin, mol, slab_idx + o_idx))
    if mol:
        b1 = mol_bond_graph(fin, mol)
        if sp_only:
            # ⚠⚠ 단일점에서는 fin 이 곧 init 이다 — init↔fin 을 비교하면 변화가
            #   **구조적으로 항상 0** 이라 절대 발화하지 못하는 검사가 된다
            #   (통과해도 아무것도 보증하지 못한다 · Codex 6차 §4).
            #   정본은 빌드 때 저장한 **조각 정본 그래프**다. 없으면 통과시키지 않는다.
            b0 = {tuple(e) for e in (meta.get("mol_graph_canonical") or [])}
            if not meta.get("mol_graph_canonical"):
                gates.append("SOURCE_TOPOLOGY_UNVERIFIED(정본 분자 그래프가 job.json 에 "
                             "없다 — 옛 번들이다. 재생성할 것)")
                info["bonds"] = {"final": len(b1), "canonical": None}
            else:
                broke, formed = b0 - b1, b1 - b0
                info["bonds"] = {"canonical": len(b0), "broken": len(broke),
                                 "formed": len(formed),
                                 "compared_against": "빌드 시 조각 정본 그래프"}
                if broke or formed:
                    gates.append(f"SOURCE_TOPOLOGY_CHANGED(정본 대비 끊김 {len(broke)} · "
                                 f"생성 {len(formed)} — 계산에 넣은 분자가 조각이 아니다)")
        else:
            # 기체 기준계도 여기 온다 (슬랩이 없어 위 블록은 건너뛴다)
            b0 = mol_bond_graph(init, mol)
            broke, formed = b0 - b1, b1 - b0
            info["bonds"] = {"initial": len(b0), "broken": len(broke),
                             "formed": len(formed)}
            if broke or formed:
                gates.append(f"BOND_CHANGE(끊김 {len(broke)} · 생성 {len(formed)})")
    # ── 계면 정체성 (Codex P0-7) — 자리 선호를 묻던 계가 다른 계가 됐는가 ──
    #   ⚠ 이 검사들은 "버리라" 가 아니라 **격리하라** 는 뜻이다. 재구성·전이가 일어난
    #     끝점은 흡착 에너지의 질문 자체가 달라져 같은 표에 못 올린다.
    if mol and (top_li or top_ni) and not sp_only:
        top_all = sorted(set(top_li) | set(top_ni))
        # ① 자유 상부 양이온의 재구성 변위
        rec_d = max((mic_dist(init["pos"][i], fin["pos"][i], fin["cell"])
                     for i in top_all if not init["fixed"][i]), default=0.0)
        info["top_reconstruction_A"] = round(rec_d, 3)
        if rec_d > RECON_A:
            gates.append(f"SURFACE_RECONSTRUCTION(상부 양이온 {rec_d:.2f} Å > {RECON_A})")
        # ② Li 바깥쪽 이탈 + O 배위 손실 (표면에서 뽑혀 나왔나)
        o_slab = [i for i, sy in enumerate(fin["syms"]) if sy == "O" and i not in mol]
        worst_li = (0.0, 0, 0)
        for i in top_li:
            dz = fin["pos"][i][2] - init["pos"][i][2]
            n0 = sum(1 for j in o_slab
                     if mic_dist(init["pos"][i], init["pos"][j], init["cell"]) < LI_O_A)
            n1 = sum(1 for j in o_slab
                     if mic_dist(fin["pos"][i], fin["pos"][j], fin["cell"]) < LI_O_A)
            if dz - 0.0 > worst_li[0] or (n0 - n1) > worst_li[1]:
                worst_li = (max(dz, worst_li[0]), max(n0 - n1, worst_li[1]), i)
        info["li_outward_A"] = round(worst_li[0], 3)
        info["li_O_coord_loss"] = worst_li[1]
        if worst_li[0] > LI_OUT_A or worst_li[1] >= LI_COORD_LOSS:
            gates.append(f"LI_EXTRACTION(바깥 이동 {worst_li[0]:.2f} Å · "
                         f"O 배위 −{worst_li[1]})")
        # ③ 새 계면 결합 (분자 원자 ↔ 슬랩 원자가 공유반경 안으로)
        newb = []
        for m in mol:
            for i in slab_idx + o_slab:
                cut = BOND_F * (RCOV.get(fin["syms"][m], 1.0) + RCOV.get(fin["syms"][i], 1.0))
                d0 = mic_dist(init["pos"][m], init["pos"][i], init["cell"])
                d1 = mic_dist(fin["pos"][m], fin["pos"][i], fin["cell"])
                if d1 < cut <= d0:
                    newb.append((fin["syms"][m], fin["syms"][i], round(d1, 2)))
        info["new_interface_bonds"] = newb[:8]
        if newb:
            gates.append(f"INTERFACE_REACTION_OR_RECONSTRUCTION(새 계면 결합 {len(newb)}: "
                         + ", ".join(f"{a}–{b} {d}Å" for a, b, d in newb[:3]) + ")")

    # ⚠ 이완이 없으면 drift·재구성·Li 추출·새 계면결합은 **정의되지 않는다**.
    #   여기에 0 을 적으면 "검사했고 통과" 로 읽힌다 (Codex 6차 §4). 이름을 붙인다.
    if sp_only:
        info["fixed_drift_A"] = "NOT_APPLICABLE_SINGLE_POINT"
        info["relaxation_gates"] = "NOT_APPLICABLE_SINGLE_POINT"
        info["relaxation_gates_list"] = [
            "ionic convergence", "fixed-atom drift", "surface reconstruction",
            "Li extraction", "new interface bonds", "DFT CONTCAR migration"]
    else:
        dmax = 0.0
        for i, fx in enumerate(init["fixed"]):
            if fx:
                dmax = max(dmax, mic_dist(init["pos"][i], fin["pos"][i], fin["cell"]))
        info["fixed_drift_A"] = round(dmax, 4)
        if dmax > FIX_DRIFT_A:
            gates.append(f"FIXED_DRIFT({dmax:.3f} Å — 파일 불일치 의심)")
    info["_init_fixed"] = init["fixed"]
    info["_fin"] = fin
    return gates, info


BRANCH_TIE_EV = 0.020     # 두 branch 차가 이 아래면 k 보정(각 ±10)으로 순서가 뒤집힌다
MAX_OPTIONAL_DENSE = 2    # 예산 상한 — 넘으면 전이를 주장하지 않는다


def plan_dense(root, man, jobs, E, E_dense):
    """coarse static 을 보고 **어느 branch 에 dense 를 걸어야 하는지** 정한다.

    설계 (Codex 6차 §3 을 예산에 맞게 조정)
      · 기본 dense 는 pm1 에 **이미 사슬로 붙어 있다** — 아무것도 발동 안 하면 추가 0
      · 발동 조건은 두 가지뿐이다
          ① pm1 이 무효 (게이트/미완)          → net4 후보를 승격
          ② net4 가 pm1 보다 {BRANCH_TIE_EV*1000:.0f} meV 넘게 낮다 → net4 승격
        (둘 다 아니면 우리가 보고하는 branch 를 이미 dense 한 것이다)
      · 승격은 최대 {MAX_OPTIONAL_DENSE} 건. 넘으면 **한 조각만 완결**하고 나머지는
        MAX_OPTIONAL_DENSE 를 넘겼다고 적는다 — 임의의 둘로 전체를 주장하지 않는다.

    이 함수가 **못 하는 것**: 어느 branch 가 진짜 바닥인지 보장하지 못한다.
      두 seed 는 시도한 초기값 두 개일 뿐이고, 더 낮은 자기배치가 있을 수 있다.
    """
    seeds = man.get("seeds_full") or ["afm2424_pm1", "afm2424_net4"]
    main, alt = seeds[0], (seeds[1] if len(seeds) > 1 else seeds[0])
    cal = list(man.get("dense_calibrators") or [])
    plan = {"parent_manifest_sha256": hashlib.sha256(
                open(os.path.join(root, "MANIFEST.json"), "rb").read()).hexdigest(),
            "rule": {"branch_tie_eV": BRANCH_TIE_EV,
                     "max_optional": MAX_OPTIONAL_DENSE,
                     "why": (f"두 branch 의 k 보정이 각각 최대 ±10 meV 면 차가 "
                             f"{BRANCH_TIE_EV * 1000:.0f} meV 안일 때 순서가 뒤집힐 수 "
                             f"있다. 30 meV 판정바닥과는 다른 축이다.")},
            "calibrators": cal, "endpoints": {}, "promote": [], "notes": []}
    if not cal:
        plan["notes"].append("dense 보정자가 지정되지 않았다 — 계획할 대상이 없다")
    cand = []
    for pid, pm in man.get("pairs", {}).items():
        if pm["fragment"] not in cal:
            continue
        for role in ("li", "ni"):
            pre = pm[f"{role}_prefix"]
            ent = {"fragment": pm["fragment"], "role": role.capitalize(),
                   "E_by_seed": {}, "valid": {}, "static_sha256": {}}
            for sd in seeds:
                j = f"{pre}__{sd}"
                r = jobs.get(j)
                ent["valid"][sd] = bool(r and r.get("ok"))
                ent["E_by_seed"][sd] = E(j)
                for ext in ("", ".gz"):
                    p = os.path.join(root, j, "static", "OUTCAR" + ext)
                    if os.path.isfile(p):
                        ent["static_sha256"][sd] = hashlib.sha256(
                            open(p, "rb").read()).hexdigest()
                        break
                if r and not r.get("ok"):
                    ent.setdefault("gates", {})[sd] = r.get("gates", [])[:3]
            em, ea = ent["E_by_seed"].get(main), ent["E_by_seed"].get(alt)
            have_dense = E_dense(f"{pre}__{main}") is not None
            ent["dense_done_on"] = main if have_dense else None
            if em is None and ea is None:
                ent["decision"] = "NO_VALID_BRANCH — 이 끝점은 k 검증 불가"
            elif em is None:
                ent["decision"] = f"PROMOTE_{alt}(주 branch 무효)"
                cand.append((0, pid, role, alt, ent))          # 우선순위 0 = 최상
            elif ea is not None and ea < em - BRANCH_TIE_EV:
                ent["decision"] = (f"PROMOTE_{alt}(coarse 에서 "
                                   f"{(em - ea) * 1000:.0f} meV 더 낮다)")
                cand.append((1, pid, role, alt, ent))
            elif ea is not None and abs(em - ea) <= BRANCH_TIE_EV:
                # ⚠ tie 는 "괜찮다" 가 아니라 **재순위 위험 구간**이다. adaptive 가
                #   꺼져 있으면 추가 계산이 불가능하므로 그 사실을 판정으로 남긴다.
                ent["decision"] = (f"MAGNETIC_K_UNRESOLVED(두 branch 차 "
                                   f"{abs(em - ea) * 1000:.0f} meV ≤ "
                                   f"{BRANCH_TIE_EV * 1000:.0f} — k 보정 ±10 으로 순서가 "
                                   f"뒤집힐 수 있는데 adaptive dense 가 꺼져 있다)")
            else:
                ent["decision"] = (f"OK({main} 이 {(ea - em) * 1000:.0f} meV 낮다 — "
                                   f"보고 branch = dense 한 branch)")
            if not have_dense:
                ent["decision"] += " ⚠ 주 branch dense 산출이 없다(미완/게이트)"
            plan["endpoints"][f"{pid}/{role}"] = ent
    cand.sort(key=lambda t: (t[0], t[1], t[2]))
    for pr, pid, role, sd, ent in cand[:MAX_OPTIONAL_DENSE]:
        rel = f"{man['pairs'][pid][role + '_prefix']}__{sd}"
        plan["promote"].append({"job": rel, "seed": sd, "priority": pr,
                                "reason": ent["decision"],
                                "candidate_dir": "dense_cand"})
    if len(cand) > MAX_OPTIONAL_DENSE:
        drop = [f"{p}/{r}" for _x, p, r, _s, _e in cand[MAX_OPTIONAL_DENSE:]]
        plan["notes"].append(
            f"⛔ 승격 후보 {len(cand)}건 > 상한 {MAX_OPTIONAL_DENSE} — "
            f"{drop} 는 MAGNETIC_K_UNRESOLVED 다. 임의의 둘로 전체 전이를 "
            f"주장하지 않는다 (예산을 늘리든지 주장 범위를 줄이든지 골라야 한다)")
    plan["estimated_extra_dense_runs"] = len(plan["promote"])
    op = os.path.join(root, "DENSE_PLAN.json")
    with open(op, "w") as fh:
        json.dump(plan, fh, indent=1, ensure_ascii=False)
    print(f"=== dense 계획 ===  보정자 {cal} · 끝점 {len(plan['endpoints'])}")
    for k, v in plan["endpoints"].items():
        print(f"  {k:44s} {v['decision']}")
    print(f"\n승격 {len(plan['promote'])}건"
          + ("  (추가 계산 없음 — 보고 branch 를 이미 dense 했다)"
             if not plan["promote"] else ""))
    for p in plan["promote"]:
        print(f"   ▶ {p['job']}  ({p['reason']})")
    for n in plan["notes"]:
        print(f"  ⚠ {n}")
    print(f"\n→ {op}")
    print("   ⚠ 이 모드는 --adaptive_dense 로 만든 번들에서만 의미가 있다. "
          "기본 번들에는 dense_cand/ 도 run_dense_selected.sh 도 없다.")
    return 0


def k_transfer_gate(cal, kap_all, frags):
    """k 전이 게이트 — (판정, 조각별 라벨, 통과한 보정자) 를 낸다.

    ★ κ 는 **부호 있는** 양이다. 크기만 보면 +9 와 −9 를 둘 다 통과시켜 실제
      18 meV 의 계 의존성을 놓친다. 그래서 max|κ| 와 range 를 **둘 다** 본다.
    ★ n=2 다 — 평균·표준편차·CI 를 쓰지 않는다. deterministic max/range 규칙이다.

    이 함수가 **못 하는 것**: 보정자가 대표성이 있는지는 판단하지 못한다.
      큰 계 하나 + open-shell 하나로 고른 것은 **공학적 선택**이지 통계가 아니다.
    """
    # ★ 라벨은 **선언이 아니라 데이터**를 따른다 (2026-08-12). κ 를 실제로 잰 조각은
    #   dense_calibrators 에 안 적혀 있어도 직접 검증된 것이다 — 선언만 보면 dense 를
    #   돌리고도 K_UNVERIFIED 가 되어 headline 이 막힌다.
    have = {f: kap_all[f] for f in (cal or list(kap_all)) if f in kap_all}
    if not cal and not have:
        kt = {"pass": False, "why": "dense 를 돌린 조각이 없다 — 전이 불가"}
    elif cal and len(have) < len(cal):
        kt = {"pass": False, "kappa_eV": have,
              "why": f"보정자 {len(have)}/{len(cal)} 만 회수 — 전이 근거 부족"}
    else:
        vals = list(have.values())
        mx = max(abs(v) for v in vals)
        rng = max(vals) - min(vals)
        kt = {"pass": bool(mx <= GUARD_EV and rng <= GUARD_EV), "kappa_eV": have,
              "max_abs_meV": round(mx * 1000, 1), "range_meV": round(rng * 1000, 1),
              "rule": (f"|κ_f| ≤ {GUARD_EV * 1000:.0f} meV **및** "
                       f"|κ_i−κ_j| ≤ {GUARD_EV * 1000:.0f} meV. n=2 라 max/range 로 "
                       f"본다 (평균·표준편차·CI 금지)")}
    labels = {f: ("K_DIRECTLY_CHECKED" if f in have else
                  "K_TRANSFER_SCREENED" if kt["pass"] else "K_UNVERIFIED")
              for f in frags}
    return kt, labels, have


def apply_k_guard(cls, med, lbl, delta):
    """guard band 를 **실제 release gate 로** 적용한다 (Codex 6차 §6).

    옛 판은 k_guard 에 문자열만 붙이고 최종 class 를 막지 않았다 — 직접 dense 하지
    않은 조각의 25 meV 대비가 그대로 판정으로 나갔다.
    ±10 meV(k 불확실성)는 30 meV(판정바닥)와 **별개 축**이다:
      · |ΔE| ≤ 10 meV      → 부호 자체가 안 정해진다 (라벨 무관)
      · 20 ≤ |ΔE| ≤ 40 meV → k 오차 하나로 바닥을 넘나든다. 직접 dense 아니면 보류
      · 그 밖                → 원래 판정 유지
    """
    a = abs(med)
    if a <= GUARD_EV:
        return f"UNRESOLVED_SIGN(|ΔE|={a * 1000:.0f} ≤ {GUARD_EV * 1000:.0f} meV)"
    # ★★ K_UNVERIFIED 는 **유한한 k 오차 경계가 없다** (Codex zip 감사).
    #   전이 게이트가 실패했다는 건 "10 meV 안" 이라고 말할 근거가 사라졌다는 뜻이다.
    #   그런데 옛 판은 |ΔE| 가 크면 그냥 통과시켰다 — 경계 없는 값에 판정을 붙인 셈이다.
    if lbl == "K_UNVERIFIED":
        return (f"UNRESOLVED_K(|ΔE|={a * 1000:.0f} meV 이지만 k 오차에 **유한한 경계가 "
                f"없다** — 전이 게이트 실패. 직접 dense 없이는 판정 불가)")
    if lbl != "K_DIRECTLY_CHECKED" and delta - GUARD_EV <= a <= delta + GUARD_EV:
        return (f"UNRESOLVED_K_GUARD(|ΔE|={a * 1000:.0f} meV 가 "
                f"{(delta - GUARD_EV) * 1000:.0f}–{(delta + GUARD_EV) * 1000:.0f} meV "
                f"띠 안 · {lbl} — 직접 dense 없이는 판정 불가)")
    return cls


def selftest_k() -> int:
    """k 라벨·guard band 의 **순수 산술**을 시험한다 (음성 포함).

    이 시험이 못 하는 것: OUTCAR 회수·게이트 연동. 그건 번들 selftest 몫이다.
    """
    ok = True

    def chk(c, m):
        nonlocal ok
        print(("  ✓ " if c else "  ✗ ") + m)
        ok = ok and bool(c)

    F = ["c10", "doped", "neutral", "dimer"]
    C = ["c10", "doped"]
    # 양성: 보정자 둘이 작고 서로 가까우면 나머지는 전이 심사 통과
    kt, lb, _ = k_transfer_gate(C, {"c10": 0.003, "doped": 0.005}, F)
    chk(kt["pass"] and lb["c10"] == "K_DIRECTLY_CHECKED"
        and lb["neutral"] == "K_TRANSFER_SCREENED",
        f"κ +3/+5 meV → 전이 통과 · 라벨 {lb['neutral']}")
    # ★★ 음성 (이 함수를 만든 이유): 부호가 반대면 크기만으로는 통과해 버린다
    kt2, lb2, _ = k_transfer_gate(C, {"c10": 0.009, "doped": -0.009}, F)
    chk(not kt2["pass"] and lb2["neutral"] == "K_UNVERIFIED",
        f"κ +9/−9 meV → **탈락** (각각은 10 이하지만 range {kt2['range_meV']} meV)")
    chk(max(abs(v) for v in kt2["kappa_eV"].values()) <= GUARD_EV,
        "  ↑ 전제 확인: 절대값만 봤다면 통과했을 사례다")
    # 음성: 크기가 크면 탈락
    kt3, lb3, _ = k_transfer_gate(C, {"c10": 0.025, "doped": 0.026}, F)
    chk(not kt3["pass"] and lb3["dimer"] == "K_UNVERIFIED",
        f"κ +25/+26 meV → 탈락 (range 는 작아도 max {kt3['max_abs_meV']} meV)")
    # 음성: 보정자 하나가 결측이면 전이 불가
    kt4, lb4, _ = k_transfer_gate(C, {"c10": 0.002}, F)
    chk(not kt4["pass"] and lb4["c10"] == "K_DIRECTLY_CHECKED"
        and lb4["doped"] == "K_UNVERIFIED",
        "보정자 1/2 회수 → 전이 불가 (회수된 쪽은 여전히 직접 검증)")
    # 음성: 보정자 미지정이면 조용히 통과시키지 않는다
    kt5, lb5, _ = k_transfer_gate([], {}, F)
    chk(not kt5["pass"] and set(lb5.values()) == {"K_UNVERIFIED"},
        "보정자 미지정 + κ 도 없음 → 전 조각 K_UNVERIFIED")
    # ★ 라벨은 **선언이 아니라 데이터**를 따른다 — dense 를 돌렸으면 직접 검증이다
    kt6, lb6, _ = k_transfer_gate([], {"c10": 0.004, "doped": 0.006}, F)
    chk(lb6["c10"] == "K_DIRECTLY_CHECKED" and lb6["neutral"] == "K_TRANSFER_SCREENED",
        "보정자 미선언이어도 κ 를 잰 조각은 직접 검증 (선언만 보면 headline 이 막힌다)")

    # ── 전역 부호 정규화 (Codex 5차 P1-2) ────────────────────────────────
    #   static 과 dense 가 이 규칙을 따로 구현해서, dense 가 **완전한 시간반전**으로
    #   수렴하면 전부 불일치로 잡는 거짓 차단이 났다. 한 함수로 두고 여기서 시험한다.
    _w = {0: 1.0, 1: -1.0, 2: 1.0, 3: -1.0}
    _same = {0: 1.2, 1: -1.2, 2: 1.2, 3: -1.2}
    chk(global_sign(_same, _w) == (1.0, []), "시드와 같은 배치 → sg=+1, 불일치 0")
    _rev = {k: -v for k, v in _same.items()}
    chk(global_sign(_rev, _w) == (-1.0, []),
        "**완전한 시간반전** → sg=−1, 불일치 0 (같은 상태다)")
    _part = dict(_same); _part[1] = +1.2          # 하나만 뒤집힘
    _sg, _bad = global_sign(_part, _w)
    chk(_bad == [1], f"부분 반전 하나 → 그것만 잡는다 ({_bad})")
    _half = {0: 1.2, 1: 1.2, 2: -1.2, 3: -1.2}    # 절반 반전 (모호)
    _sg2, _bad2 = global_sign(_half, _w)
    chk(len(_bad2) == 2, f"절반 반전 → 어느 부호로 봐도 2개 불일치 ({_bad2})")
    _zero = {k: 0.0 for k in _w}
    chk(len(global_sign(_zero, _w)[1]) == len(_w),
        "모멘트 전부 0 → 전부 불일치 (붕괴를 통과시키지 않는다)")

    # ── realized_basin_id (회신 Z P0-4) ──────────────────────────────────
    #   pm1/net4 는 초기 seed 이름이지 최종 basin 이 아니다. 지문이 **수렴 결과**를
    #   따라가는지, 그리고 안 따라가야 할 것(시간반전)에 안 따라가는지 본다.
    _NS = {str(i): v for i, v in _w.items()}
    _b_same, _d_same = realized_basin_id([1.2, -1.2, 1.2, -1.2], _NS, {})
    _b_rev, _d_rev = realized_basin_id([-1.2, 1.2, -1.2, 1.2], _NS, {})
    chk(_b_same is not None and _b_same == _b_rev,
        "완전한 시간반전은 **같은 basin** (전역 부호 정규화 후 지문)")
    chk(len(_b_same) == 64 and _d_same["id_short"] == _b_same[:12],
        "지문은 canonical JSON 의 **full SHA256** — 12자는 표시용 (회신 AA Q5-b)")
    _b_flip, _d_flip = realized_basin_id([1.2, 1.2, 1.2, -1.2], _NS, {})
    chk(_b_flip is not None and _b_flip != _b_same,
        "⛔음성: Ni 하나가 뒤집히면 **다른 basin** (wave1.5 의 실제 사고 모양)")
    _b_col, _ = realized_basin_id([1.2, -1.2, 0.1, -1.2], _NS, {})
    chk(_b_col != _b_same and _b_col is not None,
        "⛔음성: 모멘트 붕괴도 다른 basin (부호는 살아 있어도 상태가 다르다)")
    # ★ 회신 AA Q5-c — 두 문턱. 회색은 판정하지 않는다
    _b_gray, _dg = realized_basin_id([1.2, -1.2, 0.40, -1.2], _NS, {})
    chk(_b_gray is None and "회색구간" in _dg["why"],
        f"⛔음성: 회색구간(0.25–0.55 μB) 모멘트는 **unresolved** — 단일 문턱이면 "
        f"0.4 를 자성으로 오판했다")
    _MS = {"4": 1.0}
    _b_o1, _ = realized_basin_id([1.2, -1.2, 1.2, -1.2, 0.9], _NS, _MS)
    _b_o2, _ = realized_basin_id([1.2, -1.2, 1.2, -1.2, -0.9], _NS, _MS)
    chk(_b_o1 != _b_o2,
        "⛔음성: Ni 는 같은데 **유기종 상대스핀**만 갈려도 다른 basin")
    chk(realized_basin_id(None, _NS, {})[0] is None
        and realized_basin_id([1.2], _NS, {})[0] is None,
        "⛔음성: 표가 없거나 짧으면 **추측하지 않고** None (뺄셈을 막는다)")
    _b_o1b, _ = realized_basin_id([-1.2, 1.2, -1.2, 1.2, -0.9], _NS, _MS)
    chk(_b_o1b == _b_o1,
        "유기종까지 통째로 반전해도 같은 basin (시간반전은 상대부호를 안 바꾼다)")
    # ★ 회신 AA Q5 — 시간반전을 접을 수 있는 계인지 INCAR 로 확인
    chk(realized_basin_id([1.2, -1.2, 1.2, -1.2], _NS, {},
                          incar_echo={"LSORBIT": ".TRUE."})[0] is None,
        "⛔음성: SOC 가 켜져 있으면 시간반전을 접지 않는다 (전제가 깨진다)")
    chk(realized_basin_id([1.2, -1.2, 1.2, -1.2], _NS, {},
                          incar_echo={"I_CONSTRAINED_M": "1"})[0] is None,
        "⛔음성: signed spin constraint 가 걸려 있으면 접지 않는다")
    chk(realized_basin_id([1.2, -1.2, 1.2, -1.2], _NS, {},
                          incar_echo={"LSORBIT": ".FALSE.", "ISPIN": "2"})[0] is not None,
        "양성: collinear·무SOC·무제약이면 접는다")
    # ★ basin_distance (회신 AA Q5-c) — "얼마나 다른가"
    _dd = basin_distance(_d_same, _d_flip)
    chk(_dd["hamming"] == 1 and _dd["flipped_index_poscar"] == [1] and not _dd["same"],
        f"거리: Ni 하나 뒤집힘 → hamming 1, 인덱스 {_dd['flipped_index_poscar']}")
    _dd2 = basin_distance(_d_same, _d_rev)
    chk(_dd2["same"] and _dd2["hamming"] == 0 and _dd2["moment_rms_muB"] < 1e-9,
        "거리: 시간반전끼리는 hamming 0 · RMS 0 (전역부호로 정규화해 비교한다)")
    _b_big, _d_big = realized_basin_id([2.0, -2.0, 2.0, -2.0], _NS, {})
    _dd3 = basin_distance(_d_same, _d_big)
    chk(_dd3["hamming"] == 0 and not _dd3["same"] and _dd3["moment_rms_muB"] > 0.3,
        f"⛔음성: 부호가 같아도 **크기**가 벌어지면 동일 판정 안 한다 "
        f"(RMS {_dd3['moment_rms_muB']} > {MOM_RMS_TOL})")

    # ── 닫힘 조건 C1 · C3 (회신 AA P0-4 — 코드로 낸다) ────────────────────
    def _J(kind, _edisp=None, _mom=(1.2, -1.2, 1.2, -1.2), **kw):
        m = {"kind": kind, "d3": "on"}; m.update(kw)
        return {"ok": True, "gates": [], "meta": m,
                # C3 v2 는 OUTCAR 의 Edisp 를 읽는다 — 픽스처도 실물과 같은 자리에 둔다
                "static": {"edisp_eV": _edisp, "edisp_n": 0 if _edisp is None else 1,
                           "incar_echo": {"NSW": "0"}},
                # ★ P0-4 — 해시만이 아니라 **상세 지문**도 실물과 같은 자리에 둔다.
                #   없으면 same_basin() 이 (옳게) 통과시키지 않는다.
                "geom": {"magnetic": {
                    "realized_basin_id": "B",
                    "realized_basin": {
                        "ni_sign_vector": [1 if x > 0 else -1 for x in _mom],
                        "ni_index_poscar": [0, 1, 2, 3],
                        "collapsed_ni_positions": [],
                        "ni_moments_muB": list(_mom), "global_sign": 1.0}}}}

    _en3, _jb3 = {}, {}
    _CS = "refs/clean_slab__" + SEED_MAIN
    _jb3[_CS] = _J("clean_ref", seed=SEED_MAIN, _edisp=-1.0); _en3[_CS] = -900.0
    _jb3[_CS + "__d3off"] = _J("clean_ref", seed=SEED_MAIN, d3="off", d3_twin_of=_CS)
    _en3[_CS + "__d3off"] = -899.0                    # d_slab = -1.0 = Edisp_slab
    for _f, _em, _dm in (("sdcp_neutral", -200.0, -0.5), ("ptfe_c10", -100.0, -0.2)):
        _mk = "refs/mol__%s__box24" % _f
        _jb3[_mk] = _J("mol_ref", fragment=_f, _edisp=_dm); _en3[_mk] = _em
        _jb3[_mk + "__d3off"] = _J("mol_ref", fragment=_f, d3="off", d3_twin_of=_mk)
        _en3[_mk + "__d3off"] = _em - _dm             # d_mol = _dm = Edisp_mol
        for _i in range(4):
            _k = "prospective/%s__b%02d__%s" % (_f, _i, SEED_MAIN)
            _dcx = -2.0 if _f == "sdcp_neutral" else -1.0
            _jb3[_k] = _J("prospective_pose", fragment=_f, seed=SEED_MAIN,
                          basin_id="b%02d" % _i, role="calibration",
                          uma_E_pose_eV=0.10 + 0.01 * _i, _edisp=_dcx)
            _en3[_k] = -900.0 + _em + (-1.20 - 0.01 * _i)   # 잔차 range = 0.06
            _jb3[_k + "__d3off"] = _J("prospective_pose", fragment=_f, seed=SEED_MAIN,
                                      basin_id="b%02d" % _i, d3="off", d3_twin_of=_k)
            _en3[_k + "__d3off"] = _en3[_k] - _dcx
    _E3 = lambda j: _en3.get(j)                       # noqa: E731
    _emol3 = {"sdcp_neutral": -200.0, "ptfe_c10": -100.0}
    _F3 = ["sdcp_neutral", "ptfe_c10"]

    #   ★ manifest 를 준다 — 기대 자세 수의 정본이다 (회수분에서 세지 않는다)
    _man3 = {"planned": {k: {} for k in _jb3
                         if k.startswith("prospective/") and k.endswith(SEED_MAIN)}}
    _c1 = closure_C1(_man3, _jb3, _E3, _emol3, _F3)
    chk(all(abs(_c1["by_frag"][f]["S_f_eV"] - 0.06) < 1e-6 for f in _F3),
        "C1: S_f 가 **range** 로 계산된다 (0.06) — 실제 %s"
        % [round(_c1["by_frag"][f]["S_f_eV"], 4) for f in _F3])
    _jb_p = dict(_jb3); _jb_p.pop("prospective/sdcp_neutral__b03__" + SEED_MAIN)
    chk(closure_C1(_man3, _jb_p, _E3, _emol3, _F3)["by_frag"]["sdcp_neutral"]["verdict"]
        == "unresolved",
        "⛔음성 C1: 자세 하나가 빠지면 **unresolved** — 남은 것으로 range 를 내면 "
        "표본이 줄어 통과 쪽으로 편향된다")
    _kb = "prospective/ptfe_c10__b01__" + SEED_MAIN
    _jb_b = dict(_jb3)
    _jb_b[_kb] = dict(_jb3[_kb], geom={"magnetic": {"realized_basin_id": "OTHER"}})
    chk(closure_C1(_man3, _jb_b, _E3, _emol3, _F3)["by_frag"]["ptfe_c10"]["verdict"]
        == "unresolved",
        "⛔음성 C1: 네 자세 중 basin 이 다른 것이 있으면 unresolved")
    # ⛔ 음성 P0-4 — **해시는 같은데 크기가 벌어진** 경우. 종전엔 해시만 봐서
    #   1.2 μB 와 2.0 μB 가 같은 basin 으로 통과했다. basin_distance 의 RMS 규칙은
    #   selftest 밖에서 한 번도 안 불렸다 (살아 있는 척하는 죽은 코드).
    _jb_m = dict(_jb3)
    _jb_m[_kb] = _J("prospective_pose", fragment="ptfe_c10", seed=SEED_MAIN,
                    basin_id="b01", role="calibration", uma_E_pose_eV=0.11,
                    _edisp=-1.0, _mom=(2.0, -2.0, 2.0, -2.0))    # 부호 같음, 크기 다름
    _r_m = closure_C1(_man3, _jb_m, _E3, _emol3, _F3)["by_frag"]["ptfe_c10"]
    chk(_r_m["verdict"] == "unresolved"
        and any("RMS" in str(x) for x in (_r_m.get("missing") or [])),
        "⛔음성 P0-4: 부호가 같아도 **모멘트 크기**가 벌어지면 unresolved — "
        "해시만 보면 통과했다 (%s)" % (_r_m.get("missing") or [])[:1])
    # ⛔ 음성 P0-4b — 상세 지문이 아예 없으면 **통과가 아니다**
    _jb_n4 = dict(_jb3)
    _jb_n4[_kb] = dict(_jb3[_kb],
                       geom={"magnetic": {"realized_basin_id": "B"}})   # 상세 없음
    _r_n4 = closure_C1(_man3, _jb_n4, _E3, _emol3, _F3)["by_frag"]["ptfe_c10"]
    chk(_r_n4["verdict"] == "unresolved",
        "⛔음성 P0-4b: 상세 지문이 없으면 해시가 같아도 통과시키지 않는다")

    # ── P0-5 회귀: **production 이 실제로 쓰는 경로**로 친다 ─────────────────
    #   read_outcar 는 `{k: _echo_val(t, k) for k in AUDIT_KEYS_RUNTIME}` 로
    #   되울림을 만든다. 손으로 만든 dict 를 넣으면 그 키가 목록에 없어도 통과한다 —
    #   회신 AB P0-5 가 잡은 것이 정확히 그 상태였다. 그래서 **같은 식으로** 만든다.
    for _k5 in ("LNONCOLLINEAR", "LSORBIT", "I_CONSTRAINED_M", "BEXT"):
        chk(_k5 in AUDIT_KEYS_RUNTIME,
            "⛔음성 P0-5: %s 가 AUDIT_KEYS_RUNTIME 에 있다 — 없으면 read_outcar 가 "
            "안 읽어서 _spin_setup_ok 이 **실제로는 안 돈다**" % _k5)
    _echo = lambda t: {k: _echo_val(t, k) for k in AUDIT_KEYS_RUNTIME}   # noqa: E731
    _e5 = _echo("  ENCUT  =  520.0 eV\n  ISMEAR =      0\n")
    chk(_spin_setup_ok(_e5)[0] is True,
        "⛔음성 P0-5: 그 넷이 **미출력이면 통과**다 (VASP 기본값은 안 찍는다). "
        "종전엔 str(None)='NONE' 이 되어 전 잡을 '스핀 제약 있음' 으로 막았다: %s"
        % (_spin_setup_ok(_e5)[1],))
    chk(_spin_setup_ok(_echo("  LSORBIT =      T\n"))[0] is False,
        "⛔음성 P0-5: SOC 가 켜져 있으면 같은 경로에서 잡힌다")
    chk(_spin_setup_ok(_echo("  I_CONSTRAINED_M =      1\n"))[0] is False,
        "⛔음성 P0-5: 스핀 제약이 켜져 있으면 같은 경로에서 잡힌다")

    # ══ C5 — ΔΔE_obs (12자세 · 홀드아웃 게이트) ═══════════════════════════
    #   이것이 Figure 2e 의 숫자를 내는 조건이다. 게이트가 하나라도 새면 값을
    #   만들면 안 되므로 음성을 촘촘히 친다.
    def _mk12(a_by_role):
        """조각별 12자세 픽스처 — cal 4 + holdout 8, A 값을 지정한다."""
        jb, en = {}, {}
        for f, (cal, hld) in a_by_role.items():
            mk = "refs/mol__%s__box24" % f
            jb[mk] = _J("mol_ref", fragment=f); en[mk] = -100.0
            for i, (role, a) in enumerate([("calibration", x) for x in cal]
                                          + [("holdout", x) for x in hld]):
                k = "prospective/%s__b%02d__%s" % (f, i, SEED_MAIN)
                jb[k] = _J("prospective_pose", fragment=f, seed=SEED_MAIN,
                           basin_id="b%02d" % i, role=role, _edisp=-1.0)
                en[k] = -100.0 + a                       # A = E_cx − E_mol = a
        return jb, en

    _F5 = ["sdcp_neutral", "ptfe_c10"]
    _em5 = {"sdcp_neutral": -100.0, "ptfe_c10": -100.0}
    _A5 = {"sdcp_neutral": ([-1.20, -1.10, -1.05, -1.00], [-1.15] + [-0.9] * 7),
           "ptfe_c10":     ([-0.80, -0.75, -0.70, -0.65], [-0.78] + [-0.6] * 7)}
    _jb5, _en5 = _mk12(_A5)
    _man5 = {"planned": {k: {} for k in _jb5 if k.startswith("prospective/")}}
    _E5 = lambda j: _en5.get(j)                          # noqa: E731
    _c5 = closure_C5(_man5, _jb5, _E5, _em5, _F5)
    chk(abs(_c5.get("ddE_obs_eV", 0) - (-0.40)) < 1e-6,
        "C5 양성: ΔΔE_obs = min(SDCP) − min(c10) = −1.20 − (−0.80) = −0.40 (실제 %s)"
        % _c5.get("ddE_obs_eV"))
    chk(all(_c5["by_frag"][f]["H1_pass"] for f in _F5),
        "C5: 홀드아웃이 calibration 최저를 안 밑돌면 H1 통과")
    chk("전역 최소" in str(_c5.get("⛔_금지_서술")),
        "C5 가 금지 서술을 결과에 함께 싣는다")
    # ⛔ 음성 C5-a — 홀드아웃이 더 낮으면 **SELECTOR_FAIL**, 값을 안 만든다
    _A5b = dict(_A5, sdcp_neutral=([-1.20, -1.10, -1.05, -1.00],
                                   [-1.40] + [-0.9] * 7))   # 홀드아웃이 200 meV 더 낮다
    _jb5b, _en5b = _mk12(_A5b)
    _c5b = closure_C5(_man5, _jb5b, lambda j: _en5b.get(j), _em5, _F5)
    chk("ddE_obs_eV" not in _c5b
        and "SELECTOR_FAIL" in _c5b["by_frag"]["sdcp_neutral"]["verdict"],
        "⛔음성 C5: 홀드아웃이 calibration 최저를 30 meV 이상 밑돌면 **값을 안 만든다** "
        "— '더 낮은 자세를 찾았다' 로 흡수하면 선택기 실패가 사라진다")
    # ⛔ 음성 C5-b — 자세가 하나라도 빠지면 unresolved
    _jb5c = dict(_jb5); _jb5c.pop("prospective/sdcp_neutral__b11__" + SEED_MAIN)
    chk(closure_C5(_man5, _jb5c, _E5, _em5, _F5)["by_frag"]["sdcp_neutral"]["verdict"]
        == "unresolved",
        "⛔음성 C5: 12자세 중 하나라도 빠지면 unresolved (표본이 줄면 min 이 올라간다)")
    # ⛔ 음성 C5-c — 홀드아웃 역할이 아예 없으면(= calibration 전용 tranche) 값 없음
    _jb5d = {k: (dict(v, meta=dict(v["meta"], role="calibration"))
                 if k.startswith("prospective/") else v) for k, v in _jb5.items()}
    _c5d = closure_C5(_man5, _jb5d, _E5, _em5, _F5)
    chk("ddE_obs_eV" not in _c5d,
        "⛔음성 C5: 홀드아웃이 없으면 값을 만들지 않는다 — 그 시험이 이 양의 **전제**다")
    # ⛔ 음성 C5-d — basin 이 갈리면 unresolved
    _kx5 = "prospective/ptfe_c10__b03__" + SEED_MAIN
    _jb5e = dict(_jb5)
    _jb5e[_kx5] = dict(_jb5[_kx5], geom={"magnetic": {"realized_basin_id": "Z"}})
    chk(closure_C5(_man5, _jb5e, _E5, _em5, _F5)["by_frag"]["ptfe_c10"]["verdict"]
        == "unresolved",
        "⛔음성 C5: 12자세가 서로 다른 basin 이면 unresolved")

    _c3 = closure_C3(_man3, _jb3, _E3, _F3)
    chk(abs(_c3["D_eV"] - (-0.7)) < 1e-6,
        "C3: D = mean(δ_SDCP) − mean(δ_c10) = −0.7 (실제 %s)" % _c3.get("D_eV"))
    # ★★ 부호 규약 (회신 AB P0-3). 봉인된 0.90 eV 는 **(UMA − DFT)** 규약이고
    #   D3 는 additive 라 offset ≈ −δ 다 ⇒ 예측 오프셋 차등 = −D.
    #   ⚠ 2026-08-30 이전 이 두 시험은 **틀린 규약을 그대로 인코딩**하고 있었다 —
    #     코드와 시험이 서로 동의하면서 둘 다 틀렸다. 정확히 설명적인 D=−0.7 을
    #     "반대 부호" 로 기각했다. 그래서 여기 규약을 글로 박아 둔다.
    chk(abs(_c3["predicted_offset_gap_eV"] - 0.7) < 1e-6,
        "C3: 예측 오프셋 차등 = −D = +0.7 (offset 규약, 실제 %s)"
        % _c3.get("predicted_offset_gap_eV"))
    chk(_c3["ratio"] > 0 and _c3["ratio"] >= C3_HI and "수치상" in _c3["verdict"],
        "C3 양성: −D 가 +0.90 과 같은 부호이고 비율 %s ≥ 0.70 → '수치상 설명'"
        % _c3.get("ratio"))
    _en3p, _jb3p = dict(_en3), dict(_jb3)
    for _i in range(4):
        for _f, _d in (("sdcp_neutral", 2.0), ("ptfe_c10", 1.0)):
            _k = "prospective/%s__b%02d__%s" % (_f, _i, SEED_MAIN)
            _en3p[_k + "__d3off"] = _en3p[_k] - _d      # d_cx = E_on − E_off = +_d
            # 항등식이 성립하도록 Edisp 도 같이 뒤집는다 — 안 그러면 교차검증에 걸린다
            _jb3p[_k] = dict(_jb3[_k],
                             static=dict(_jb3[_k]["static"], edisp_eV=_d))
    _c3b = closure_C3(_man3, _jb3p, lambda j: _en3p.get(j), _F3)
    chk(_c3b["D_eV"] > 0 and "미해결" in _c3b["verdict"] and "부호" in _c3b["verdict"],
        "⛔음성 C3: D 가 양수면 예측 오프셋 차등(−D)이 관측 +0.90 과 **반대 부호** → "
        "미해결 (절댓값이면 %s 로 '설명' 오판했다)" % abs(_c3b.get("ratio", 0)))
    # ⛔ 음성 C3-e — **평균이 맞아도 조각내 일관성이 깨지면 미해결.**
    #   D3 는 기하 의존 항이라 자세마다 달라야 하는데 관측 오프셋은 조각 안에서
    #   상수(SDCP 6 meV)였다. δ 가 그보다 훨씬 흔들리면 D3 귀속이 성립 안 한다.
    _jb_w = dict(_jb3)
    for _i, _d in enumerate((-2.0, -2.3, -1.7, -2.0)):
        _kw = "prospective/sdcp_neutral__b%02d__%s" % (_i, SEED_MAIN)
        _jb_w[_kw] = dict(_jb3[_kw],
                          static=dict(_jb3[_kw]["static"], edisp_eV=_d))
        # 이 픽스처는 **조각내 range** 를 시험한다. 쌍둥이를 남겨 두면 항등식
        # 교차검증이 먼저 걸려서(그 자체는 정상 동작) 시험하려던 경로에 못 간다.
        _jb_w.pop(_kw + "__d3off", None)
    _c3w = closure_C3(_man3, _jb_w, _E3, _F3)
    chk("조각내 일관성" in _c3w["verdict"]
        and _c3w["within_fragment"]["sdcp_neutral"]["ok"] is False,
        "⛔음성 C3: δ 의 조각내 range 0.6 eV 가 관측 오프셋 상수성(6 meV)의 5배를 "
        "넘으면 **평균이 맞아도** 미해결 (%s)" % _c3w["verdict"][:40])
    chk(_c3["within_fragment"]["sdcp_neutral"]["ok"] is True,
        "양성 대조: δ 가 조각내 상수면 일관성 통과 (range %s)"
        % _c3["within_fragment"]["sdcp_neutral"]["delta_range_eV"])
    _kx = "prospective/sdcp_neutral__b00__%s__d3off" % SEED_MAIN
    _jb_x = dict(_jb3)
    _jb_x[_kx] = dict(_jb3[_kx], geom={"magnetic": {"realized_basin_id": "Z"}})
    chk(closure_C3(_man3, _jb_x, _E3, _F3)["by_frag"]["sdcp_neutral"]["verdict"]
        == "unresolved",
        "⛔음성 C3: on/off 가 다른 realized basin 이면 unresolved "
        "(그 차이는 D3 기여가 아니다)")
    # ⛔ 음성 C3-c — **Edisp 가 없으면 unresolved.** IVDW 가 실제로 안 걸린 잡을
    #   "D3 기여 0" 으로 조용히 읽으면 D 가 통째로 틀린다.
    _kn = "prospective/sdcp_neutral__b02__" + SEED_MAIN
    _jb_n = dict(_jb3)
    _jb_n[_kn] = dict(_jb3[_kn], static=dict(_jb3[_kn]["static"], edisp_eV=None))
    _r_n = closure_C3(_man3, _jb_n, _E3, _F3)["by_frag"]["sdcp_neutral"]
    chk(_r_n["verdict"] == "unresolved" and any("Edisp" in str(x) for x in
                                                (_r_n.get("missing") or [])),
        "⛔음성 C3: OUTCAR 에 Edisp 가 없으면 unresolved (0 으로 읽지 않는다)")
    # ⛔ 음성 C3-d — **항등식이 깨지면 unresolved.** 쌍둥이가 남아 있는데
    #   (E_on−E_off) 와 Edisp 가 다르면 IVDW 말고 다른 축이 갈린 것이다.
    _jb_i = dict(_jb3)
    _jb_i[_kn] = dict(_jb3[_kn],
                      static=dict(_jb3[_kn]["static"], edisp_eV=-2.5))  # 참값은 -2.0
    _r_i = closure_C3(_man3, _jb_i, _E3, _F3)["by_frag"]["sdcp_neutral"]
    chk(_r_i["verdict"] == "unresolved" and any("항등식" in str(x) for x in
                                                (_r_i.get("missing") or [])),
        "⛔음성 C3: (E_on−E_off) ≠ Edisp 면 unresolved — 쌍둥이가 IVDW 밖에서 갈렸다")

    # guard band
    D = 0.030
    chk(apply_k_guard("ROBUST", 0.005, "K_DIRECTLY_CHECKED", D).startswith("UNRESOLVED_SIGN"),
        "|ΔE| 5 meV → 부호 미정 (직접 dense 여도)")
    chk(apply_k_guard("ROBUST", 0.025, "K_TRANSFER_SCREENED", D)
        .startswith("UNRESOLVED_K_GUARD"),
        "25 meV + 전이심사 → **판정 보류** (옛 판은 그대로 통과시켰다)")
    chk(apply_k_guard("ROBUST", 0.025, "K_DIRECTLY_CHECKED", D) == "ROBUST",
        "25 meV + 직접 dense → 판정 유지 (직접 쟀으면 띠가 적용되지 않는다)")
    # ★ K_UNVERIFIED 는 **크기와 무관하게** 막는다 (Codex zip 감사) — 전이 게이트가
    #   실패했으면 k 오차에 유한한 경계가 없다. 크니까 괜찮다는 논리는 성립 안 한다.
    chk(apply_k_guard("ROBUST", 0.080, "K_UNVERIFIED", D).startswith("UNRESOLVED_K"),
        "80 meV 라도 K_UNVERIFIED 면 막는다 (경계 없는 값에 판정을 붙이지 않는다)")
    chk(apply_k_guard("ROBUST", 0.015, "K_UNVERIFIED", D).startswith("UNRESOLVED_K"),
        "15 meV 도 마찬가지")
    # ★ 대조: 전이 심사를 **통과한** 라벨은 띠 밖이면 판정이 유지돼야 한다
    chk(apply_k_guard("ROBUST", 0.080, "K_TRANSFER_SCREENED", D) == "ROBUST",
        "80 meV + 전이 통과 → 판정 유지 (막는 건 UNVERIFIED 뿐)")
    chk(apply_k_guard("ROBUST", 0.015, "K_TRANSFER_SCREENED", D) == "ROBUST",
        "15 meV + 전이 통과 → 바닥 아래 결론 유지")
    chk(apply_k_guard("X", -0.025, "K_TRANSFER_SCREENED", D)
        .startswith("UNRESOLVED_K_GUARD"), "음수 ΔE 도 절대값으로 본다")

    # ── e2e: OUTCAR **파일** → read_outcar → phase_gates (codex E-2차 필수4) ──
    #   1차 리뷰가 지적한 그대로 — 광고한 e2e 가 배포본 selftest 에 없으면
    #   "자체검증된다" 는 README 주장이 거짓이 된다. 배포본 자신이 돈다.
    import tempfile
    _BODY = (" vasp.5.4.4.18Apr17-6-g9f103f2a35 (build test) complex\n"
             "|      So try LREAL= Auto  in the INCAR   file.        |\n"
             "   ENCUT  =  520.0 eV  38.22 Ry\n"
             "   LREAL  =      T    real-space projection\n"
             "   NUPDOWN=      4.0000    fix difference up-down\n"
             "   LMAXMIX     =    4 max onsite mixed and CHGCAR\n"
             " LDA+U is selected, type is set to LDAUTYPE =  2\n"
             "   U (eV)           for each species LDAUU =   0.0  6.2  0.0\n"
             "  energy(sigma->0) =     -100.000000\n"
             " General timing and accounting\n")
    _EXP = {"ENCUT": "520", "LREAL": "Auto", "NUPDOWN": "4", "LDAUTYPE": "2",
            "LDAUU": "0.0 6.2 0.0", "LDAU": ".TRUE.", "LMAXMIX": "4"}

    def _e2e(body, want=None, gz_trunc=False, both=False):
        with tempfile.TemporaryDirectory() as _d:
            _o = os.path.join(_d, "OUTCAR")
            if gz_trunc:
                full = gzip.compress(body)
                open(_o + ".gz", "wb").write(full[:len(full) // 2])
            elif both:
                open(_o, "wb").write(body)
                open(_o + ".gz", "wb").write(gzip.compress(body))
            else:
                open(_o, "wb").write(body)
            _oc = read_outcar(_o)
            return _oc, phase_gates(_oc, "static",
                                    {"incar_expected": {"static": want or _EXP}}, {})
    _oc, _g = _e2e(_BODY.encode())
    chk(not any("INCAR" in x for x in _g), f"e2e 정상: INCAR 게이트 0건 ({_g})")
    _au = _oc["incar_audit"]
    chk("LDAUU" in _au["verified_exact"] and "NUPDOWN" in _au["verified_exact"]
        and "LMAXMIX" in _au["verified_exact"] and "LDAU" in _au["verified_exact"],
        f"e2e: 목록·NUPDOWN·LDAU·LMAXMIX 가 exact ({_au['verified_exact']})")
    chk("LREAL" in _au["verified_equivalence_class"], "e2e: LREAL 은 등가류")
    chk(any(x.startswith("MAGMOM") for x in _au["unverified"]),
        "e2e: MAGMOM 명시적 unverified")
    _oc, _g = _e2e(_BODY.encode(), want=dict(_EXP, LDAUU="0.0 5.0 0.0"))
    chk(any("INCAR_MISMATCH(static.LDAUU" in x for x in _g),
        "⛔e2e음성: LDAUU 실제 차이(6.2vs5.0)가 전 경로에서 잡힌다")
    _oc, _g = _e2e(_BODY.encode(), want=dict(_EXP, NUPDOWN="-1"))
    chk(any("INCAR_MISMATCH(static.NUPDOWN" in x for x in _g),
        "⛔e2e음성: release 상에 NUPDOWN=4 잔류 → 하드게이트 (기대 -1)")
    _oc, _g = _e2e(_BODY.encode().replace(b"ENCUT", b"ENC\xffUT"))
    chk(any("OUTCAR_READ_ERROR" in x for x in _g), "⛔e2e음성: 깨진 바이트 → 판독 실패")
    _oc, _g = _e2e(_BODY.encode(), gz_trunc=True)
    chk(any("OUTCAR_READ_ERROR" in x and "gzip" in x for x in _g),
        "⛔e2e음성: 잘린 gzip → 게이트 (예외 아님)")
    _oc, _g = _e2e(_BODY.encode(), both=True)
    chk(any("둘 다" in x for x in _g), "⛔e2e음성: plain/.gz 공존 → 정본 판정 불가")
    _two = (_BODY.replace("-100.000000", "-1.000000")
            + _BODY.replace("-100.000000", "-2.000000")).encode()
    _oc, _g = _e2e(_two)
    chk(any("MULTI_RUN_OUTCAR" in x for x in _g) and _oc["E0"] == -2.0,
        f"⛔e2e음성: 2실행 이어붙음 → MULTI_RUN + 마지막 완결만 (E0={_oc['E0']})")

    # ── check_pin 스위트 (배포본 상주 — E-5차: 번들에만 있던 검사를 이사) ────
    def _pin_job(dirp, flip_one=False, nup_echo="4.0000", ldauu_echo="0.0 6.2 0.0",
                 double_run=False, kmesh=True, incar_tamper=False):
        jd = pathlib.Path(dirp); (jd / "static_pin").mkdir(parents=True)
        sign = {"0": 1.0, "1": -1.0, "2": 1.0, "3": 1.0}
        _meta = {"ni_sign_poscar_idx": sign, "counts": [4], "species_order": ["Ni"],
                 "potcar_spec": {"Ni": "Ni_pv"},
                 "incar_expected": {"static_pin": {"NUPDOWN": "4",
                                                   "LDAUU": "0.0 6.2 0.0"}}}
        if kmesh:
            _meta["kmesh"] = {"static_pin": "1 1 1"}
        (jd / "job.json").write_text(json.dumps(_meta))
        (jd / "static_pin" / "INCAR").write_text("NUPDOWN = 4\n")
        _isha = hashlib.sha256((jd / "static_pin" / "INCAR").read_bytes()).hexdigest()
        (jd / "MANIFEST_RESCUE.json").write_text(json.dumps(
            {"sha256": {"static_pin/INCAR": _isha}}))
        if incar_tamper:
            (jd / "static_pin" / "INCAR").write_text("NUPDOWN = 4\nENCUT = 400\n")
        mom = [1.2, -1.2, 1.2, 1.2]
        if flip_one:
            mom[1] = 1.2
        rows = "\n".join(f"{i + 1:5d}   0 0 {m:7.3f} {m:7.3f}"
                          for i, m in enumerate(mom))
        body = (" vasp.5.4.4 test\n TITEL  = PAW_PBE Ni_pv 01Jan2000\n"
                "   NIONS =      4\n   NKPTS =      1\n"
                f"   NUPDOWN=      {nup_echo}    fix difference up-down\n"
                f"   U (eV)           for each species LDAUU =   {ldauu_echo}\n"
                "  energy(sigma->0) =  -1.0\n"
                "\n magnetization (x)\n\n# of ion  s p d tot\n----\n" + rows +
                "\n----\n General timing and accounting\n")
        if double_run:
            body = body + body
        (jd / "static_pin" / "OUTCAR").write_text(body)
        (jd / "static_pin" / "CHGCAR").write_text("density " * 10)
        return jd
    with tempfile.TemporaryDirectory() as _d:
        _D = pathlib.Path(_d)
        chk(check_pin(_pin_job(_D / "ok")) == 0, "check_pin 양성: 정상 pin 수용")
        for nm, kw, why in (
            ("f", {"flip_one": True}, "⛔check_pin 음성: topology 위반 → 거부"),
            ("n", {"nup_echo": "-1.0000"}, "⛔check_pin 음성: NUPDOWN 미적용 → 거부"),
            ("u", {"ldauu_echo": "0.0 5.0 0.0"},
             "⛔check_pin 음성: LDAUU=5.0 → 거부 (E-3차 재현 구멍)"),
            ("m", {"double_run": True}, "⛔check_pin 음성: 2실행 이어붙음 → 거부"),
            ("k", {"kmesh": False}, "⛔check_pin 음성(P0-1): kmesh 결측 → 거부"),
            ("i", {"incar_tamper": True}, "⛔check_pin 음성: pin INCAR 변조 → 거부"),
        ):
            chk(check_pin(_pin_job(_D / nm, **kw)) == 1, why)

    # ── provenance 스위트 (배포본 상주 · E-6차 계약) ─────────────────────────
    _OC_FILE = (" vasp.5.4.4 test\n initial charge density was supplied:\n"
                " keeping initial charge density in first step\n"
                "  energy(sigma->0) =  -1.0\n General timing and accounting\n")
    _OC_ATOMS = (" vasp.5.4.4 test\n initial charge density was supplied:\n"
                 " charge density of overlapping atoms calculated\n"
                 " keeping initial charge density in first step\n"
                 "  energy(sigma->0) =  -1.0\n General timing and accounting\n")

    def _prov_job(dirp, pv_patch=None, pc_patch=None, skip_disk=(), man_drop=(),
                  tamper_incar=False, static_outcar=_OC_FILE, parent_break=False):
        jd = pathlib.Path(dirp)
        (jd / "static_pin").mkdir(parents=True); (jd / "static").mkdir()
        base = {"POSCAR": "p", "KPOINTS": "k", "static_pin/INCAR": "i1",
                "static/INCAR": "i2", "static_pin/KPOINTS": "k",
                "static/KPOINTS": "k", "run_job.sh": "r"}
        man = {}
        for f, body in base.items():
            if f not in skip_disk:
                (jd / f).write_text(body)
            man[f] = hashlib.sha256(body.encode()).hexdigest()
        # job.json 은 부모 해시를 담아야 하므로 마지막에 (자기 해시는 그 뒤 계산)
        par = {"POSCAR": ("deadbeef" if parent_break else man["POSCAR"]),
               "KPOINTS": man["KPOINTS"]}
        jj = json.dumps({"rescue": {"parent_sha256": par}})
        if "job.json" not in skip_disk:
            (jd / "job.json").write_text(jj)
        man["job.json"] = hashlib.sha256(jj.encode()).hexdigest()
        for f in man_drop:
            man.pop(f, None)
        (jd / "MANIFEST_RESCUE.json").write_text(json.dumps({"sha256": man}))
        if static_outcar is not None:
            (jd / "static" / "OUTCAR").write_text(static_outcar)
        rec = {f: man.get(f, "x") for f in ("POSCAR", "KPOINTS",
                                            "static_pin/INCAR", "static/INCAR")}
        rec["POTCAR"] = "pt"
        for ph in ("static_pin", "static"):
            rec[ph + "/POSCAR"] = rec["POSCAR"]
            rec[ph + "/KPOINTS"] = rec["KPOINTS"]
            rec[ph + "/POTCAR"] = "pt"
        pv = {"run_id": "20260825T000000Z_host", "utc": "2026-08-25T00:00:00Z",
              "preflight_problems": [], "inputs_sha256": rec,
              "parent_match": {"POSCAR": True, "KPOINTS": True},
              "chgcar_sha256": {"pin": "aa", "static_copy": "aa", "identical": True},
              "chgcar_read_evidence": ["grid : charge from CHGCAR file"]}
        pv.update(pv_patch or {})
        (jd / "RUN_PROVENANCE.json").write_text(json.dumps(pv))
        pc = {"pass": True, "chgcar": {"sha256": "aa"}}
        pc.update(pc_patch or {})
        (jd / "static_pin" / "PIN_CHECK.json").write_text(json.dumps(pc))
        if tamper_incar:
            (jd / "static_pin" / "INCAR").write_text("i1-modified")
        return jd
    with tempfile.TemporaryDirectory() as _d:
        _D = pathlib.Path(_d)
        chk(rescue_provenance_ok(_prov_job(_D / "g"))[0] is True,
            "provenance 양성: 완비(OUTCAR 승계 마커 포함) → supersede 허용")
        for nm, kw, why in (
            ("q1", {"pv_patch": {"parent_match": {}}},
             "⛔provenance P0-4: parent_match={} → 거부"),
            ("q2", {"pv_patch": {"chgcar_sha256": {"pin": "aa", "static_copy": "bb",
                                                    "identical": True}}},
             "⛔provenance P0-4: identical 거짓 플래그 → sha 직접 비교 거부"),
            ("q3", {"pc_patch": {"chgcar": None}},
             "⛔provenance P0-4: PIN_CHECK 에 CHGCAR sha 없음 → 거부"),
            ("q4", {"static_outcar": _OC_ATOMS},
             "⛔provenance E-6차: OUTCAR 가 'overlapping atoms 새로 만듦' → 승계 안 됨 거부"),
            ("q5", {"static_outcar": " vasp.5\n General timing and accounting\n"},
             "⛔provenance E-6차: 승계 마커 부재(판별 불가) → 거부"),
            ("q6", {"static_outcar": None},
             "⛔provenance E-6차: static OUTCAR 자체가 없으면 거부"),
            ("q7", {"pv_patch": {"chgcar_read_evidence": "NOT_FOUND"}},
             "⛔provenance P0-5: 문자열 타입(문자 순회 함정) → 형식 거부"),
            ("q8", {"pv_patch": {"preflight_problems": ["bad"]}},
             "⛔provenance E-5차: preflight_problems 비어있지 않음 → 거부"),
            ("q9", {"pv_patch": {"preflight_problems": None}},
             "⛔provenance E-5차: preflight 필드 위조/부재 → 거부"),
            ("qa", {"skip_disk": ("static/INCAR",)},
             "⛔provenance P0-3: 배포 파일 디스크 부재 → 거부"),
            ("qb", {"skip_disk": ("static/KPOINTS",)},
             "⛔provenance P0-2: phase KPOINTS 디스크 부재 → 거부"),
            ("qc", {"man_drop": ("static_pin/KPOINTS",)},
             "⛔provenance: MANIFEST 에 phase KPOINTS 해시 없음 → 거부"),
            ("qd", {"tamper_incar": True},
             "⛔provenance: 디스크 INCAR 사후 변조 → 거부"),
            ("qe", {"pv_patch": {"inputs_sha256": None}},
             "⛔provenance P0-3: 실행 기록 해시 없음 → 거부"),
            ("qf", {"parent_break": True},
             "⛔provenance E-6차: 배포≠부모 (재계산 사슬) → 기록 불리언과 무관하게 거부"),
        ):
            _r = rescue_provenance_ok(_prov_job(_D / nm, **kw))
            chk(_r[0] is False, f"{why} ({_r[1][:38]})")

    print("k-selftest PASS" if ok else "k-selftest FAIL")
    return 0 if ok else 1


def phase_gates(oc, ph, meta, spec, want_ionic=False):
    """상 하나의 fail-closed 검사. oc 가 None 이면 NOT_RUN.

    ⚠ **게이트 통과가 보증하는 것** (codex E-2, 과대해석 금지):
      "제공된 단일 완결 실행 세그먼트에서, incar_expected 에 등록된 유한한 키
       집합이 되울림과 일치했다" — 딱 여기까지다.
    보증하지 못하는 것: 등록되지 않은 키 전부 · 정확한 k-grid shift · POTCAR 원문
    해시 · WAVECAR/CHGCAR 실제 내용과 승계 계보 · 기본값/명시값 구분 · LREAL 의
    정확한 모드(등가류까지만). ISTART/ICHARG 되울림은 재시작 파일이 **실제로
    쓰였다는 증거가 아니다.** 각 상의 incar_audit(4분류)가 이 경계의 기계 기록이다.
    """
    g = []
    if oc is None:
        return [f"NOT_RUN({ph})"]
    if oc.get("read_error"):
        # 판독 실패는 NOT_RUN 이 아니다 — 파일은 있는데 믿고 읽을 수 없는 상태
        return [f"OUTCAR_READ_ERROR({ph}: {oc['read_error']})"]
    seg = oc.get("run_segments") or {}
    if seg.get("n", 1) > 1:
        g.append(f"MULTI_RUN_OUTCAR({ph}: 실행 {seg['n']}개 이어붙음 — "
                 f"{seg['used']}(#{seg['used_index']}) 세그먼트만 읽음. "
                 "단일 실행 계약과 어긋난다 — 출처 확인 전 인용 금지)")
    if oc.get("suffix_magic_mismatch"):
        g.append(f"OUTCAR_FORMAT_MISMATCH({ph}: 확장자와 실제 형식({oc.get('read_format')})이 다름)")
    if not oc["normal_end"]:
        g.append(f"NOT_TERMINATED({ph} — General timing 없음, 잘린 OUTCAR)")
    if oc["E0"] is None:
        g.append(f"NO_ENERGY({ph})")
    if oc["nelm_hit"]:
        g.append(f"ELECTRONIC_NELM_HIT({ph})")
    if want_ionic and not oc["ionic_conv"]:
        g.append(f"IONIC_NOT_CONVERGED({ph})")
    expect = [spec.get(e, e) for e in meta.get("species_order", [])]
    got = [x.split()[1] if len(x.split()) > 1 else x for x in oc["titels"]]
    # ⚠ TITEL 이 아예 없으면 "검사 못 함" 이지 "통과" 가 아니다
    if expect and not got:
        g.append(f"POTCAR_UNVERIFIED({ph} — TITEL 없음)")
    elif expect and got and len(got) != len(expect):
        g.append(f"POTCAR_COUNT({ph}: {len(got)}!={len(expect)})")
    elif expect and got and got != expect:
        # ⛔ 2026-08-12 — 옛 판은 여기서 변형 문자열을 **비교하지 않았고**, 뒤의 전역
        #   검사도 "준중심 접미사가 있는가" 라는 boolean 만 봐서 Ni_pv→Ni_sv 가 경고로
        #   통과했다. 고정 protocol 에서는 한 글자만 달라도 다른 Hamiltonian 이다.
        g.append(f"POTCAR_VARIANT({ph}: {got}!={expect})")
    nat = sum(meta.get("counts", []) or [])
    if nat and oc["nions"] and oc["nions"] != nat:
        g.append(f"NIONS_MISMATCH({ph}: {oc['nions']}!={nat})")
    # ── 이 상이 **선언한 대로** 돌았는지: k 점 수 + INCAR 되울림 (Codex P0-5) ──
    #   dense 폴더에 static OUTCAR 를 복사해도 에너지만 맞으면 통과하던 구멍을 막는다.
    #   ⚠ NKPTS 절대값은 대칭 축약(ISYM·시간반전) 때문에 예측이 불안정하다 —
    #   상한(전체 격자 곱)만 여기서 보고, **상 사이 단조성**은 main() 에서 본다.
    want_k = (meta.get("kmesh") or {}).get(ph)
    if want_k:
        prod = 1
        for x in str(want_k).split():
            prod *= int(x)
        if not oc.get("nkpts"):
            g.append(f"KMESH_UNVERIFIED({ph} — OUTCAR 에 NKPTS 없음)")
        elif oc["nkpts"] > prod:
            g.append(f"KMESH_MISMATCH({ph}: NKPTS {oc['nkpts']} > 격자 {want_k} 의 {prod})")
    audit = {"verified_exact": [], "verified_equivalence_class": [],
             "unverified": [], "mismatch": []}
    expected = (meta.get("incar_expected") or {}).get(ph, {})
    for k2 in AUDIT_KEYS_RUNTIME:
        got2 = (oc.get("incar_echo") or {}).get(k2)
        want = expected.get(k2)
        if k2 in _ECHO_ABSENT:
            # 원리적 검증불가 — 게이트 없이 **명시적으로** unverified (조용한 통과 금지)
            audit["unverified"].append(f"{k2}(OUTCAR 미되울림 — 원리적 검증불가, "
                                       "선언은 INCAR sha256 무결성으로만 보증)")
            continue
        if want is None:
            if got2 is not None:
                audit["unverified"].append(f"{k2}(기대값 미등록 — 되울림 {got2} 은 비교 안 됨)")
            continue
        if got2 is None:
            audit["unverified"].append(k2)
            g.append(f"INCAR_UNVERIFIED({ph}.{k2})")
            continue
        ok, kind = _incar_match(k2, got2, want)
        if not ok:
            audit["mismatch"].append(k2)
            g.append(f"INCAR_MISMATCH({ph}.{k2}: {got2}!={want})")
        elif kind == "equivalence_class":
            audit["verified_equivalence_class"].append(k2)
        else:
            audit["verified_exact"].append(k2)
    oc["incar_audit"] = audit                  # RESULTS.json 에 그대로 실린다
    return g


def check_pin(jobdir):
    """rescue 1상(static_pin)의 수용 검사 — 통과 전에는 release 를 돌리면 안 된다.

    ⛔ v1 은 자기만의 축소판 검사(NUPDOWN·topology)였다 — codex E-3차가
      **LDAUU 를 5.0 으로 바꾼 pin 도 통과**함을 재현했다. v2 는 상 게이트
      전체(phase_gates: 등록된 INCAR 기대키 전부 · MULTI_RUN · 판독오류 ·
      형식 불일치 · E0 · NIONS · POTCAR TITEL · KPOINTS 상한)를 그대로 태우고,
      그 위에 topology·모멘트 붕괴·CHGCAR 해시만 얹는다.

    이 검사가 못 하는 것: pin 이 '어느' basin 인지의 절대 판정 — 시드 topology
    와의 일치까지만 본다.
    """
    jd = pathlib.Path(jobdir)
    meta = json.load(open(jd / "job.json"))
    spec = meta.get("potcar_spec") or {}
    bad = []
    if not spec:
        bad.append("job.json 에 potcar_spec 이 없다 — POTCAR TITEL 검증 불가 (fail-closed)")
    # ⛔ codex E-4차 P0-1 — phase_gates 는 kmesh 결측을 **조용히 건너뛴다** (wave1
    #   호환 때문). release 사슬에서는 그 관용이 fail-open 이다 — 여기서 막는다.
    if not (meta.get("kmesh") or {}).get("static_pin"):
        bad.append("job.json 에 kmesh.static_pin 이 없다 — KPOINTS 검증 불가 (fail-closed)")
    # 배포 기준과 pin INCAR 대조 (MANIFEST_RESCUE — 있으면 강제, 없으면 거부)
    _mr = jd / "MANIFEST_RESCUE.json"
    if not _mr.is_file():
        bad.append("MANIFEST_RESCUE.json 없음 — 배포 기준 해시 부재 (fail-closed)")
    else:
        try:
            _man = (json.load(open(_mr)) or {}).get("sha256") or {}
            _inc = jd / "static_pin" / "INCAR"
            if _inc.is_file() and _man.get("static_pin/INCAR"):
                _h = hashlib.sha256(open(_inc, "rb").read()).hexdigest()
                if _h != _man["static_pin/INCAR"]:
                    bad.append("static_pin/INCAR 가 배포본과 다르다 (변조/수정)")
            else:
                bad.append("pin INCAR 또는 그 배포 해시가 없다")
        except ValueError:
            bad.append("MANIFEST_RESCUE 파싱 실패")
    oc = read_outcar(str(jd / "static_pin" / "OUTCAR"))
    # 상 게이트 전체 — release 사슬에서 하나라도 걸리면 여기서 끝난다
    bad += phase_gates(oc, "static_pin", meta, spec)
    if oc and not oc.get("read_error"):
        seg = oc.get("run_segments") or {}
        if seg.get("n", 1) != 1:
            pass                                  # MULTI_RUN 게이트가 이미 bad 에 있다
        want = {int(k): v for k, v in (meta.get("ni_sign_poscar_idx") or {}).items()}
        mom = {i: v for i, v in enumerate(oc.get("moments") or [])}
        if not mom:
            bad.append("모멘트 표 없음 (LORBIT 확인)")
        elif want:
            sg, flip = global_sign(mom, want)
            small = [i for i in want if abs(mom.get(i, 0.0)) < 0.4]
            if flip:
                bad.append(f"⛔ pin 이 시드 topology 가 아님 — flip {len(flip)}개 "
                           f"(0-based {sorted(flip)[:4]}…)")
            if small:
                bad.append(f"모멘트 붕괴 의심 {len(small)}개 (<0.4 μB)")
    chg = jd / "static_pin" / "CHGCAR"
    chg_info = None
    if chg.is_file() and chg.stat().st_size > 0:
        h = hashlib.sha256()
        with open(chg, "rb") as fh:
            for b in iter(lambda: fh.read(1 << 20), b""):
                h.update(b)
        chg_info = {"sha256": h.hexdigest(), "bytes": chg.stat().st_size,
                    "mtime": chg.stat().st_mtime}
    else:
        bad.append("CHGCAR 없음/빈 파일")
    out = {"pass": not bad, "problems": bad, "chgcar": chg_info,
           "nupdown_echo": ((oc or {}).get("incar_echo") or {}).get("NUPDOWN"),
           "incar_audit": (oc or {}).get("incar_audit"),
           "run_segments": (oc or {}).get("run_segments"),
           "checked": "static_pin"}
    (jd / "static_pin").mkdir(exist_ok=True)
    (jd / "static_pin" / "PIN_CHECK.json").write_text(
        json.dumps(out, indent=1, ensure_ascii=False))
    print(("✅ pin 수용 — release 진행 가능" if not bad else
           "⛔ pin 거부 — release 를 돌리지 말 것") + f"  ({jd})")
    for x in bad:
        print("   ·", x)
    if chg_info:
        print(f"   CHGCAR sha256 {chg_info['sha256'][:16]}… ({chg_info['bytes']} B)")
    return 0 if not bad else 1


def rescue_provenance_ok(jd):
    """supersede 의 추가 조건 — **모든 필드가 fail-closed** (codex E-4차 P0 5건).

    v1 의 구멍 (전부 적대 재현됨):
      · parent_match={} → all({})==True 로 우회      → 키별 is True 요구
      · identical 플래그만 믿음 (거짓 기록 가능)      → pin/static sha 직접 비교
      · PIN_CHECK 에 chgcar 없으면 교차검증 생략       → 없으면 거부
      · 'could not be read' 같은 **부정문도 증거로 통과** → 부정 마커 필터
      · 배포 입력(MANIFEST_RESCUE)과 대조 없음         → 기록·디스크 양쪽 대조

    → (ok, why)
    """
    jd = pathlib.Path(jd)
    pc_p = jd / "static_pin" / "PIN_CHECK.json"
    pv_p = jd / "RUN_PROVENANCE.json"
    mr_p = jd / "MANIFEST_RESCUE.json"
    for f, w in ((pc_p, "PIN_CHECK.json 없음 — pin 수용검사 미실행"),
                 (pv_p, "RUN_PROVENANCE.json 없음 — 해시·승계 증거 미기록"),
                 (mr_p, "MANIFEST_RESCUE.json 없음 — 배포 기준 해시 부재")):
        if not f.is_file():
            return False, w
    try:
        pc, pv, mr = (json.load(open(x)) for x in (pc_p, pv_p, mr_p))
    except ValueError as e:
        return False, f"provenance 파싱 실패: {e}"
    if not pc.get("pass"):
        return False, "PIN_CHECK.pass=false"
    if not re.match(r"^\d{8}T\d{6}Z_\S+$", str(pv.get("run_id") or "")):
        return False, f"run_id 형식 오류: {pv.get('run_id')!r}"
    if not re.match(r"^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}Z$", str(pv.get("utc") or "")):
        return False, f"utc 형식 오류: {pv.get('utc')!r}"
    # ⛔ E-5차 — runner 는 preflight_problems 를 **항상** [] 로 기록한다.
    #   필드 부재(위조 pv)도, 비어있지 않음도 전부 거부다.
    if pv.get("preflight_problems") != []:
        return False, f"preflight 미기록/실패: {pv.get('preflight_problems')!r}"
    # 부모 대조 — 빈 dict 는 통과가 아니다: 키별로 is True 를 요구한다
    pm = pv.get("parent_match") or {}
    for k in ("POSCAR", "KPOINTS"):
        if pm.get(k) is not True:
            return False, f"부모 대조 결측/실패: {k}={pm.get(k)!r}"
    # 배포 기준(MANIFEST_RESCUE) ↔ 실행 기록 ↔ 현재 디스크 3중 대조
    man = mr.get("sha256") or {}
    rec = pv.get("inputs_sha256") or {}
    # ⛔ E-5차 — '있으면 대조' 는 fail-open 이다: 파일이 없으면 대조가 조용히
    #   생략됐다. 배포에 포함된 파일은 **존재 자체가 필수**다.
    _DISK_REQUIRED = ("POSCAR", "KPOINTS", "static_pin/INCAR", "static/INCAR",
                      "static_pin/KPOINTS", "static/KPOINTS",
                      "job.json", "run_job.sh")
    for f in _DISK_REQUIRED:
        if not man.get(f):
            return False, f"MANIFEST_RESCUE 에 {f} 해시 없음"
        fp = jd / f
        if not fp.is_file():
            return False, f"배포 파일이 디스크에 없다: {f}"
        h = hashlib.sha256(open(fp, "rb").read()).hexdigest()
        if h != man[f]:
            return False, f"디스크 파일이 배포본과 다름(사후 변조?): {f}"
    for f in ("POSCAR", "KPOINTS", "static_pin/INCAR", "static/INCAR"):
        if rec.get(f) != man[f]:
            return False, f"실행 기록 해시 ≠ 배포 해시: {f}"
    # ⛔ E-6차 — parent_match 는 runner 가 **기록한 불리언**이라 위조 가능하다.
    #   재계산 사슬로 검증한다: 디스크==배포해시(위에서 확인) 이고, 배포해시==부모해시
    #   (job.json 은 자체가 해시 앵커됨) 이면 부모 대조가 독립적으로 선다.
    try:
        _meta = json.load(open(jd / "job.json"))
    except ValueError as e:
        return False, f"job.json 파싱 실패: {e}"
    _par = ((_meta.get("rescue") or {}).get("parent_sha256") or {})
    for f in ("POSCAR", "KPOINTS"):
        if not _par.get(f):
            return False, f"job.json 에 부모 해시 없음: {f}"
        if man[f] != _par[f]:
            return False, f"배포 {f} 가 부모와 다르다 (재계산 대조 실패)"
    # phase 디렉터리 사본 — **VASP 가 실제로 읽는 파일** (P0-2·3)
    for f in ("static_pin/KPOINTS", "static/KPOINTS",
              "static_pin/POSCAR", "static/POSCAR",
              "static_pin/POTCAR", "static/POTCAR"):
        if not rec.get(f):
            return False, f"실행 기록에 phase 사본 해시 없음: {f}"
    if rec["static_pin/KPOINTS"] != man["KPOINTS"] or rec["static/KPOINTS"] != man["KPOINTS"]:
        return False, "phase KPOINTS 사본이 배포본과 다르다"
    if rec["static_pin/POSCAR"] != man["POSCAR"] or rec["static/POSCAR"] != man["POSCAR"]:
        return False, "phase POSCAR 사본이 배포본과 다르다"
    if not (rec.get("POTCAR") and rec["static_pin/POTCAR"] == rec["POTCAR"]
            and rec["static/POTCAR"] == rec["POTCAR"]):
        return False, "POTCAR 조립본과 phase 사본이 서로 다르다"
    # CHGCAR 승계 — 플래그를 믿지 않는다: sha 문자열 직접 비교 + PIN_CHECK 교차
    ch = pv.get("chgcar_sha256") or {}
    if not (ch.get("pin") and ch.get("static_copy")):
        return False, "CHGCAR sha 미기록"
    if ch["pin"] != ch["static_copy"]:
        return False, "CHGCAR pin/사본 sha 불일치"
    pc_sha = (pc.get("chgcar") or {}).get("sha256")
    if not pc_sha:
        return False, "PIN_CHECK 에 CHGCAR sha 없음 — 교차검증 불가"
    if ch["pin"] != pc_sha:
        return False, "PIN_CHECK 의 CHGCAR sha 와 provenance 가 다르다 (다른 실행 혼입?)"
    # ── CHGCAR 승계 증거 (E-6차 전면 교체) ────────────────────────────────
    #   vasp.log 문자열 게이트는 **블랙리스트 두더지잡기**였다 — 'hello'(양성 패턴
    #   부재), "NOT_FOUND" 문자순회, 부정문 변형("can't", "skipped", …)이 계속
    #   나온다. 판별자는 stdout 이 아니라 **회신된 static OUTCAR 자체**에 있다
    #   (wave1 실측: ICHARG=1 은 `initial charge density was supplied:` 만,
    #   ICHARG=2 는 그 밑에 `charge density of overlapping atoms calculated`).
    #   stdout 기록(chgcar_read_evidence)은 정보용으로 강등 — 게이트하지 않되
    #   타입 오염(str 순회 함정)만은 거부한다.
    ev = pv.get("chgcar_read_evidence")
    if ev is not None and (not isinstance(ev, list)
                           or not all(isinstance(x, str) for x in ev)):
        return False, f"chgcar_read_evidence 형식 오류 (list[str] 아님): {type(ev).__name__}"
    st_oc = read_outcar(str(jd / "static" / "OUTCAR"))
    if st_oc is None or st_oc.get("read_error"):
        return False, ("static OUTCAR 판독 불가 — CHGCAR 승계 검증 불가: "
                       + str((st_oc or {}).get("read_error", "파일 없음")))
    cff = st_oc.get("chgcar_from_file")
    if cff is not True:
        return False, ("static OUTCAR 에 CHGCAR 승계 증거 없음 "
                       + ("(overlapping atoms 로 새로 만듦 — ICHARG=1 미작동)"
                          if cff is False else "(마커 부재 — 판별 불가)"))
    return True, "ok"



#: 사전등록 문턱 — `prereg_sdcp_neutral_contrast_2026_08_29.json` 과 **같은 값**이어야 한다.
#:   ⚠ 두 곳에 복사돼 있다. 고치면 그 json 도 같이 고칠 것.
PREREG_GUARD_EV = -0.10           # primary 가 이 값 이하일 때만 방향성 주장
PREREG_ROUND_EV = 0.01            # 보고 반올림
PREREG_SELECTOR_AGREE_EV = 0.05   # 두 selector 차가 이 미만이면 "시험한 selector 간 일치"


#: ⚠ 분석기는 **번들 안에 단독 배포**된다 — 생성기 상수를 못 본다. 판정 branch 를
#:   여기 따로 박는다 (문자열이 갈라지면 C1·C3 가 조용히 빈다).
SEED_MAIN = "afm2424_pm1"

#: 닫힘 조건 문턱 — db/properties/sdcp_stageA_closure_conditions_2026_08_29.json
#: 에 **DFT 0잡 시점**으로 등록된 값. 코드와 문서가 갈라지면 문서가 정본이다.
C1_S_TOL_EV = 0.050          # 조각 내 잔차 range 허용
C3_REF_GAP_EV = 0.90         # 설명 대상 — 관측된 조각 간 UMA 오프셋 차등
C3_HI, C3_LO = 0.70, 0.30    # 채택 / 기각 비율
# D3 항등식 `E_on − E_off == Edisp` 의 허용 오차. 두 SCF 가 독립 수렴하므로
# EDIFF(1e-6 eV) 급 잔차는 정상이고, 그보다 훨씬 크면 쌍둥이가 IVDW 말고 다른
# 데서 갈렸다는 뜻이다. 1 meV 는 EDIFF 의 1000배 — 넉넉하되 실제 결함은 잡는다.
C3_EDISP_TOL_EV = 1.0e-3
#: ★ 0.90 eV 의 **원자료 정의를 봉인한다** (회신 AB P0-3).
#:   정본 db/properties/prereg_sdcp_neutral_contrast_2026_08_29.json
#:   → `🔬_UMA_대_DFT_오프셋_실측_2026_08_29.오프셋_UMA_빼기_DFT_eV`
#:   부호규약은 문자 그대로 **(UMA − DFT)** 다. 흡착에너지 오프셋이지
#:   총에너지 오프셋이 아니므로 원소별 energy-zero 는 소거된다 (AB P0-3 후단 해소).
C3_OFFSET_UMA_MINUS_DFT = {
    "sdcp_neutral": {"Li_top": 1.0728, "Ni_top": 1.0667},
    "ptfe_c10": {"Li_top": 0.1855, "Ni_top": 0.1484},
}
#: 조각 내 오프셋 **상수성** (관측 range). D3 가설이 살아남으려면 δ 의 조각내
#: range 가 이 정도여야 한다 — D3 는 기하 의존이라 자세마다 달라야 하는데
#: 관측 오프셋은 조각 안에서 상수였다 (prereg ⛔_분산_귀속_철회_2026_08_29).
C3_OFFSET_RANGE_EV = {"sdcp_neutral": 0.0061, "ptfe_c10": 0.0371}
#: 조각내 일관성 판정의 여유배수 — δ range 가 관측 range 의 이 배를 넘으면
#: "D3 로 설명" 은 성립하지 않는다 (평균이 맞아도).
C3_WITHIN_SLACK = 5.0


def _pick(jobs, **want):
    """구조화 필드로 잡을 고른다 (이름 파싱 금지)."""
    out = []
    for jn, jr in jobs.items():
        m = jr.get("meta") or {}
        if all(m.get(k) == v for k, v in want.items()):
            out.append(jn)
    return sorted(out)


def _twin_of(jobs, parent_key):
    """그 잡의 D3-off 쌍둥이 키. `d3_twin_of` 로만 찾는다 (접미어 추측 금지)."""
    for jn, jr in jobs.items():
        if (jr.get("meta") or {}).get("d3_twin_of") == parent_key:
            return jn
    return None


def _basin_of(jr):
    """잡 → (id, detail). 없으면 (None, None) — 호출부가 fail-closed 로 처리한다."""
    m = ((jr or {}).get("geom") or {}).get("magnetic") or {}
    return m.get("realized_basin_id"), m.get("realized_basin")


def same_basin(ja, jb):
    """두 잡이 **같은 자기 basin 인가** → (bool, 사유).

    🔴 회신 AB P0-4 — 종전엔 `realized_basin_id` **해시만** 비교했다. 그 해시는
      부호 벡터·붕괴 위치·유기물 상대 스핀만 담고 **크기를 안 담는다**. 그래서
      1.2 μB 와 2.0 μB 처럼 부호는 같고 크기가 크게 다른 상태가 같은 basin 으로
      통과했다. `basin_distance()` 의 RMS ≤ MOM_RMS_TOL 규칙은 selftest 밖에서
      **한 번도 호출되지 않았다** — 살아 있는 척하는 죽은 코드였다.
      ⇒ 해시가 같아도 상세 지문으로 한 번 더 본다. 지문이 없으면 통과가 아니다.
    """
    ia, da = _basin_of(ja)
    ib, db = _basin_of(jb)
    if ia is None or ib is None:
        return False, "realized_basin_id 없음 (미판정) — 통과로 읽지 않는다"
    if ia != ib:
        return False, f"basin 해시 불일치 {str(ia)[:8]} vs {str(ib)[:8]}"
    d = basin_distance(da, db)
    if d is None:
        return False, "상세 지문 없음 — 크기 비교 불가 (해시만으로 통과시키지 않는다)"
    if not d.get("same"):
        return False, ("해시는 같지만 상세가 다르다 (hamming %s · collapse %s · "
                       "RMS %s μB > %s)" % (d.get("hamming"), d.get("collapse_symdiff"),
                                            d.get("moment_rms_muB"), MOM_RMS_TOL))
    return True, "ok"


def closure_C1(man, jobs, E, emol, frags):
    """C1 — **선택된 네 자세에서의 국소 calibration 일관성**.

      e_{f,p} = E_ads^DFT(f,p) − E_ads^UMA(f,p)
      S_f     = max_p e − min_p e          ← **range 다 (SD 아님)**

    branch 는 pm1 · D3-on 만. 조각당 사전 지정 4자세 **전부**가 있어야 하고
    하나라도 빠지면 `unresolved` — 남은 자세로 계산하면 표본이 줄어 range 가
    자동으로 작아져 **통과 쪽으로 편향된다**.

    ⛔ 이 값이 말하지 않는 것: 후보 전체의 selector 검증이 **아니다.** UMA 가
    고른 자세만 DFT 로 봤으므로 통과는 독립 검증이 아니다. 일반 selector 주장은
    sealed audit 이나 UMA 순위를 가로지르는 사전 층화 holdout 이 있어야 한다.
    """
    res = {"schema": "closure_C1/v1", "S_tol_eV": C1_S_TOL_EV,
           "⚠": "선택된 네 자세의 국소 일관성. selector 일반 검증이 아니다",
           "by_frag": {}}
    slabs = _pick(jobs, kind="clean_ref", seed=SEED_MAIN, d3="on")
    if len(slabs) != 1:
        res["verdict"] = f"unresolved — clean slab(pm1·D3-on)이 {len(slabs)}개"
        return res
    e_slab = E(slabs[0])
    # 🔴 회신 AB P0-4 후단 — `S_f = max_p e − min_p e` 에서는 같은 조각의 슬랩·분자
    #   항이 **정확히 소거된다**. 그러므로 필요한 것은 네 complex 자세가 서로 같은
    #   basin 인가이지, 각 자세가 clean slab 과 같은 basin인가가 **아니다**.
    #   clean slab 일치는 **절대 E_ads** 를 주장할 때 따로 요구한다(그 게이트는
    #   BASIN_MISMATCH_SLAB 로 이미 별도로 있다). 종전 구현은 여기서 슬랩 일치를
    #   요구해 과잉차단이었다.
    res["⚠_basin_규칙"] = ("네 자세가 **서로** 같은 basin 이면 된다 — S_f 에서 슬랩·분자가 "
                          "소거되기 때문. clean slab 일치는 절대 E_ads 쪽 요구조건이다")
    for f in frags:
        poses = _pick(jobs, kind="prospective_pose", fragment=f,
                      seed=SEED_MAIN, d3="on")
        rows, miss = [], []
        for jn in poses:
            jr = jobs[jn]
            m = jr.get("meta") or {}
            rb = ((jr.get("geom") or {}).get("magnetic") or {}).get("realized_basin_id")
            ec, um = E(jn), m.get("uma_E_pose_eV")
            if jr.get("gates") or ec is None or um is None or e_slab is None:
                miss.append(f"{jn}(게이트/에너지 결측)"); continue
            if rb is None:
                miss.append(f"{jn}(basin 미판정)"); continue
            rows.append({"job": jn, "basin": m.get("basin_id"),
                         "E_ads_DFT_eV": round(ec - e_slab - emol[f], 6),
                         "E_ads_UMA_eV": round(float(um), 6),
                         "residual_eV": round(ec - e_slab - emol[f] - float(um), 6)})
        # ★ 기대 자세 수는 **동결된 manifest** 에서 온다. 회수된 잡에서 세면
        #   빠진 자세를 영영 못 잡는다 (없으면 기대도 같이 줄어든다).
        n_want = len([k for k in (man.get("planned") or {})
                      if k.startswith("prospective/")
                      and k.rsplit("/", 1)[-1].startswith(f + "__")
                      and k.endswith(SEED_MAIN)])
        if not n_want:
            res["by_frag"][f] = {"verdict": "unresolved",
                                 "why": "MANIFEST.planned 에 이 조각의 pm1 자세가 없다 "
                                        "— 기대 자세 수를 회수분에서 세지 않는다"}
            continue
        # ★ 네 자세가 **서로** 같은 basin 인지 — 해시가 아니라 상세 지문으로 (P0-4)
        _het = []
        if len(rows) > 1:
            _ref = rows[0]["job"]
            for _r in rows[1:]:
                _ok, _why = same_basin(jobs[_ref], jobs[_r["job"]])
                if not _ok:
                    _het.append(f"{_r['job']}: {_why}")
        if _het:
            miss.extend(_het)
        if miss or len(rows) != n_want or not rows:
            res["by_frag"][f] = {"verdict": "unresolved", "missing": miss,
                                 "n_used": len(rows), "n_required": n_want,
                                 "why": "4자세 전부가 있고 **서로 같은 basin** 이어야 한다 "
                                        "— 부분집합은 range 를 작게 만들어 통과 쪽으로 "
                                        "편향되고, 상태를 가로지르면 e 가 다른 양이 된다"}
            continue
        r = [x["residual_eV"] for x in rows]
        S = max(r) - min(r)
        res["by_frag"][f] = {
            "n": len(rows), "S_f_eV": round(S, 6), "rows": rows,
            "verdict": ("국소 calibration 일관 (이 네 자세 안에서 잔차 range 가 작다)"
                        if S <= C1_S_TOL_EV else
                        "⛔ 국소 일관성 실패 — 선택기를 쓴 근거가 약해진다")}
    return res


#: C5 게이트 — 결과 보기 전 고정 (D-2026-08-30-sdcp-neutral-ptfe-ddE-obs)
C5_N_POSE = 12                 # 조각당 선언 자세 = calibration 4 + holdout 8
C5_H1_TOL_EV = 0.030           # 홀드아웃이 calibration 최저를 이만큼 밑돌면 선택기 실패


def closure_C5(man, jobs, E, emol, frags):
    """C5 — ΔΔE_obs. **선언된 12자세에서의 조각 간 대비** (표본 조건부).

      A(f,p)   = E_complex(f,p) − E_mol(f, box24)
      ΔΔE_obs  = min_{p∈12} A(SDCP,p) − min_{q∈12} A(c10,q)      [pm1 · D3-on]

    왜 이 양이 별도로 있나 — 마감조건 §9 는 *"Stage A 결과로 어느 조각이 더 강하게
    붙는다를 종결형으로 쓰기"* 를 금지하고, 그 근거로 **"audit pose 가 없다"** 를 든다.
    즉 반대 이유는 *min 이 UMA 선택기의 산물일 수 있다* 이다. 층화 홀드아웃 8자세가
    UMA 점수 전 구간을 가로질러 **그 반대 이유를 직접 시험**하므로, 그 시험을 통과할
    때에 한해 **표본 조건부** 대비를 낸다.

    게이트 (하나라도 깨지면 값을 만들지 않는다):
      ① 조각당 12자세 전부 회수·게이트 통과   ② 12자세가 서로 같은 realized basin
      ③ H1 — 홀드아웃 최저가 calibration 최저를 30 meV 이상 **밑돌지 않는다**
      ④ 두 조각 기체 기준이 존재            ⑤ (슬랩은 A 에서 소거되므로 여기선 불필요)

    ⛔ 이 함수가 **못 하는 것**
      · 전역 최소를 주장하지 않는다. 후보풀 밖은 안 봤다.
      · `ΔΔE_lowE` / primary 가 아니다 — 그것은 창 W 전수 + audit 개봉을 전제한다.
      · H1 실패를 "더 낮은 자세를 찾았다" 로 흡수하지 않는다. **재개 사유**다.
    """
    res = {"schema": "closure_C5/v1", "name": "ddE_obs",
           "n_pose_required": C5_N_POSE, "h1_tol_eV": C5_H1_TOL_EV,
           "decision": "D-2026-08-30-sdcp-neutral-ptfe-ddE-obs (proposed)",
           "⚠": "표본 조건부 — 전역 최소가 아니다", "by_frag": {}}
    mins = {}
    for f in frags:
        if emol.get(f) is None:
            res["by_frag"][f] = {"verdict": "unresolved", "why": "기체 기준(box24) 없음"}
            continue
        rows, miss = [], []
        for jn in _pick(jobs, kind="prospective_pose", fragment=f,
                        seed=SEED_MAIN, d3="on"):
            jr = jobs[jn]
            ec = E(jn)
            if jr.get("gates") or ec is None:
                miss.append(f"{jn}(게이트/에너지 결측)"); continue
            rows.append({"job": jn, "role": (jr.get("meta") or {}).get("role"),
                         "basin_id": (jr.get("meta") or {}).get("basin_id"),
                         "A_eV": round(ec - emol[f], 6)})
        if len(rows) != C5_N_POSE or miss:
            res["by_frag"][f] = {
                "verdict": "unresolved", "n_used": len(rows),
                "n_required": C5_N_POSE, "missing": miss[:4],
                "why": ("선언된 12자세 전부가 있어야 한다 — 부분집합에서 min 을 뽑으면 "
                        "표본이 줄수록 min 이 올라가 대비가 흔들린다")}
            continue
        # ② 12자세 상호 동질성 (크기 포함) — 상태를 가로질러 min 을 뽑지 않는다
        _het = []
        for r in rows[1:]:
            ok, why = same_basin(jobs[rows[0]["job"]], jobs[r["job"]])
            if not ok:
                _het.append(f"{r['job']}: {why}")
        if _het:
            res["by_frag"][f] = {"verdict": "unresolved", "basin_mismatch": _het[:3],
                                 "why": "12자세가 서로 같은 realized basin 이어야 한다"}
            continue
        cal = [r for r in rows if r["role"] == "calibration"]
        hld = [r for r in rows if r["role"] == "holdout"]
        if not cal or not hld:
            res["by_frag"][f] = {"verdict": "unresolved",
                                 "why": "calibration %d · holdout %d — 두 역할이 다 "
                                        "있어야 H1 을 시험할 수 있다" % (len(cal), len(hld))}
            continue
        a_cal, a_hld = min(r["A_eV"] for r in cal), min(r["A_eV"] for r in hld)
        # ③ H1 — 홀드아웃이 calibration 최저를 30 meV 이상 밑돌면 선택기 실패
        h1_ok = (a_hld - a_cal) > -C5_H1_TOL_EV
        res["by_frag"][f] = {
            "n_pose": len(rows), "n_cal": len(cal), "n_holdout": len(hld),
            "A_min_calibration_eV": round(a_cal, 6),
            "A_min_holdout_eV": round(a_hld, 6),
            "H1_margin_eV": round(a_hld - a_cal, 6), "H1_pass": h1_ok,
            "A_min_eV": round(min(a_cal, a_hld), 6),
            "rows": sorted(rows, key=lambda r: r["A_eV"]),
            "verdict": ("ok" if h1_ok else
                        "⛔ SELECTOR_FAIL — 홀드아웃 최저가 calibration 최저를 "
                        "%.1f meV 밑돈다. 이 값을 min 으로 흡수하지 않는다; "
                        "사전등록 재개조건이 발동한다" % (1000 * (a_cal - a_hld)))}
        if h1_ok:
            mins[f] = min(a_cal, a_hld)
    sd = next((f for f in mins if "sdcp" in f), None)
    ct = next((f for f in mins if f != sd), None)
    if not (sd and ct):
        res["verdict"] = ("unresolved — 두 조각 모두 게이트를 통과해야 한다 "
                          "(통과 %s)" % sorted(mins))
        return res
    res["ddE_obs_eV"] = round(mins[sd] - mins[ct], 6)
    res["verdict"] = (
        "조사한 %d자세(사전등록 %d + 층화 홀드아웃 %d)에서, 고정기하 단일점 규약 아래 "
        "중성 SDCP 반복단위 모델의 최저 흡착 전자에너지가 perfluorodecane 조각보다 "
        "%.4f eV %s았다" % (C5_N_POSE, 4, 8, abs(res["ddE_obs_eV"]),
                            "낮" if res["ddE_obs_eV"] < 0 else "높"))
    res["⛔_금지_서술"] = ["전역 최소", "가장 안정한 자세", "종결형",
                        "ΔΔE_lowE · primary 로 부르기"]
    return res


def closure_C3(man, jobs, E, frags):
    """C3 — D3 분해. **부호를 먼저 본다.**

      δ_{f,p} = [E_C,on − E_C,off] − [E_S,on − E_S,off] − [E_M,on − E_M,off]
              = Edisp_C(f,p) − Edisp_S − Edisp_M(f)          ← **v2: 쌍둥이 없이**
      D       = mean_p(δ_SDCP) − mean_p(δ_c10)      ← 부호 있는 값, 산술평균

    ★ **v2 개정 (2026-08-30, DFT 결과 0잡 시점)** — D3-off 쌍둥이 잡을 쓰지 않는다.
      D3(IVDW=11)는 SCF 에 안 들어간다: 핵좌표만 보고 총에너지·힘에 **더해지는** 항이라
      KS 해밀토니안을 안 건드린다. 그래서 고정기하 static(NSW=0)에서
          E_on − E_off = Edisp
      가 근사가 아니라 **항등식**이고, 위 세 괄호가 각각 Edisp 로 접힌다.
      VASP 는 그 Edisp 를 OUTCAR 에 직접 찍는다 — repo 실물로 확인했다:
      `runs/sdcp_phaseB_vasp_v1_2026_08_08/{slab,mol_neutral,complex_neutral}/OUTCAR.gz`
      → −27.49493 / −0.71798 / −28.58614 ⇒ δ = **−0.373230 eV**.
      ⇒ 쌍둥이 16잡은 절충으로 버린 것이 아니라 **정보가 0이라** 버린 것이고,
        쌍둥이가 IVDW 말고 다른 축에서 갈릴 위험도 함께 사라진다.

    ⚠ 쌍둥이가 **있으면 버리지 않고 교차검증**한다 (v9 이하 번들 호환):
      |(E_on − E_off) − Edisp| > C3_EDISP_TOL_EV 면 그 조각은 unresolved 다.
      항등식이 깨졌다는 뜻이고 그건 D3 문제가 아니라 **번들 문제**다.

    D 와 0.90 eV 의 **부호가 같을 때만** 70/30 % 를 적용한다. 절댓값을 쓰면
    반대 방향 효과도 "설명" 으로 오판한다.

    ⛔ 허용 문구는 "원인의 70 % 를 증명" 이 아니라 **"이 네 자세에서 관측된
    0.90 eV 차등을 수치상 70 % 이상 설명"** — 인과가 아니라 수치 분해다.

    ⛔ 이 함수가 **못 하는 것**: Edisp 값 자체가 맞는지는 검증하지 않는다.
      VASP 가 찍은 수를 그대로 쓴다. 독립 D3 구현과 대조하지 않는다.
    """
    res = {"schema": "closure_C3/v3", "ref_gap_eV": C3_REF_GAP_EV,
           "hi": C3_HI, "lo": C3_LO, "edisp_tol_eV": C3_EDISP_TOL_EV,
           "source": "Edisp (eV) from the D3-on OUTCAR — no D3-off twin required",
           "offset_definition": C3_OFFSET_UMA_MINUS_DFT,
           "offset_within_fragment_range_eV": C3_OFFSET_RANGE_EV,
           "by_frag": {}}

    def pair_delta(jn):
        """δ 의 한 항 = 그 잡의 Edisp. 없으면 (None, 사유).

        쌍둥이가 남아 있으면 (E_on − E_off) 와 대조해 항등식을 확인한다.
        """
        a = jobs.get(jn)
        if a is None:
            return None, f"{jn}: 잡 없음"
        if a.get("gates"):
            return None, f"{jn}: 게이트됨"
        st = a.get("static") or {}
        ed = st.get("edisp_eV")
        if ed is None:
            return None, (f"{jn}: OUTCAR 에 `Edisp (eV)` 가 없다 — IVDW=11 이 실제로 "
                          f"걸렸는지 확인해야 한다 (D3 없이 돈 잡일 수 있다)")
        if (st.get("edisp_n") or 0) > 1 and (st.get("incar_echo") or {}).get("NSW") not in (None, "0", 0):
            return None, (f"{jn}: Edisp 가 {st['edisp_n']}회 찍혔는데 NSW≠0 — 기하가 "
                          f"바뀌었으면 마지막 값이 어느 기하의 것인지 보장 못 한다")
        # ── 쌍둥이가 있으면 항등식을 **검사**한다 (없는 게 정상이다)
        tw = _twin_of(jobs, jn)
        if tw is not None and not (jobs[tw].get("gates")):
            ea, eb = E(jn), E(tw)
            if ea is not None and eb is not None:
                if abs((ea - eb) - ed) > C3_EDISP_TOL_EV:
                    return None, (f"{jn}: (E_on−E_off)={ea - eb:.6f} 인데 Edisp={ed:.6f} "
                                  f"— 차 {abs((ea - eb) - ed):.6f} eV 가 허용 "
                                  f"{C3_EDISP_TOL_EV} 를 넘는다. D3 항등식이 깨졌다 = "
                                  f"쌍둥이가 IVDW 말고 다른 데서 갈렸다는 뜻")
                ra = ((a.get("geom") or {}).get("magnetic") or {}).get("realized_basin_id")
                rb = ((jobs[tw].get("geom") or {}).get("magnetic") or {}).get("realized_basin_id")
                if ra is not None and rb is not None and ra != rb:
                    return None, f"{jn}: on/off 가 다른 realized basin"
        return ed, None

    d_slab, why = pair_delta((_pick(jobs, kind="clean_ref", seed=SEED_MAIN,
                                    d3="on") or [None])[0]) \
        if _pick(jobs, kind="clean_ref", seed=SEED_MAIN, d3="on") else (None, "clean slab 없음")
    if d_slab is None:
        res["verdict"] = f"unresolved — clean slab D3 짝: {why}"
        return res
    means = {}
    for f in frags:
        mol = [j for j in _pick(jobs, kind="mol_ref", fragment=f, d3="on")
               if "box24" in j and "nzmag" not in j]
        if len(mol) != 1:
            res["by_frag"][f] = {"verdict": "unresolved",
                                 "why": f"box24 기체 기준이 {len(mol)}개"}
            continue
        d_mol, why_m = pair_delta(mol[0])
        if d_mol is None:
            res["by_frag"][f] = {"verdict": "unresolved", "why": why_m}
            continue
        rows, miss = [], []
        for jn in _pick(jobs, kind="prospective_pose", fragment=f,
                        seed=SEED_MAIN, d3="on"):
            d_cx, why_c = pair_delta(jn)
            if d_cx is None:
                miss.append(why_c); continue
            rows.append({"job": jn, "delta_eV": round(d_cx - d_slab - d_mol, 6)})
        # ★ 기대 자세 수는 **동결된 manifest** 에서 온다 (C1 과 같은 규율) — 회수분에서
        #   세면 자세가 통째로 빠져도 기대가 같이 줄어 영영 못 잡는다.
        n_want = len([k for k in (man.get("planned") or {})
                      if k.startswith("prospective/")
                      and k.rsplit("/", 1)[-1].startswith(f + "__")
                      and k.endswith(SEED_MAIN)])
        if not n_want:
            res["by_frag"][f] = {"verdict": "unresolved",
                                 "why": "MANIFEST.planned 에 이 조각의 pm1 자세가 없다"}
            continue
        if miss or len(rows) != n_want or not rows:
            res["by_frag"][f] = {"verdict": "unresolved", "missing": miss,
                                 "n_used": len(rows), "n_required": n_want,
                                 "why": "자세 하나라도 Edisp 가 없거나 검사에 걸리면 "
                                        "unresolved — 부분집합 평균을 내지 않는다"}
            continue
        m = sum(x["delta_eV"] for x in rows) / len(rows)
        means[f] = m
        res["by_frag"][f] = {"n": len(rows), "mean_delta_eV": round(m, 6),
                             "rows": rows, "d_slab_eV": round(d_slab, 6),
                             "d_mol_eV": round(d_mol, 6)}
    sd = next((f for f in means if "sdcp" in f), None)
    ct = next((f for f in means if f != sd), None)
    if not (sd and ct):
        res["verdict"] = "unresolved — 두 조각이 다 필요하다"
        return res
    D = means[sd] - means[ct]
    res["D_eV"] = round(D, 6)
    # ★★ 부호 규약 정정 (회신 AB P0-3) — 종전 코드는 **정확히 설명적인 경우를
    #    기각**했다. 봉인된 0.90 eV 는 (UMA − DFT) 규약이고, D3 는 총에너지에
    #    **더해지는** 항이므로
    #        offset_f = E_ads^UMA − E_ads^DFT ≈ −δ_f
    #    ⇒ 예측되는 오프셋 차등 = (−δ_SDCP) − (−δ_c10) = δ_c10 − δ_SDCP = **−D**
    #    이다. 그래서 비교하는 양을 offset 규약으로 **이름부터** 맞춘다 —
    #    부호를 뒤집는 게 아니라 같은 규약에서 재는 것이다.
    res["predicted_offset_gap_eV"] = round(-D, 6)
    res["ratio"] = round(-D / C3_REF_GAP_EV, 4)
    res["sign_convention"] = (
        "0.90 eV = mean(UMA − DFT)_SDCP − mean(UMA − DFT)_c10 = +0.9028 "
        "(prereg 오프셋_UMA_빼기_DFT_eV). D3 는 additive 이므로 offset ≈ −δ ⇒ "
        "예측 오프셋 차등 = −D. **흡착에너지 오프셋이지 총에너지 오프셋이 아니다** "
        "— 원소별 energy-zero 는 소거된다")

    # ★ 조각내 일관성 — **평균만으로 판정하지 않는다.** D3 는 기하 의존 항이라
    #   자세마다 달라야 하는데, 관측 오프셋은 조각 안에서 상수였다
    #   (SDCP 6 meV · c10 37 meV). δ 가 그보다 훨씬 크게 흔들리면 평균이 맞아도
    #   "D3 로 설명" 은 성립하지 않는다 (prereg ⛔_분산_귀속_철회_2026_08_29).
    within = {}
    for f, r in res["by_frag"].items():
        rows = r.get("rows") or []
        if len(rows) < 2:
            continue
        vals = [x["delta_eV"] for x in rows]
        rng = max(vals) - min(vals)
        obs = C3_OFFSET_RANGE_EV.get(f)
        within[f] = {"delta_range_eV": round(rng, 6),
                     "observed_offset_range_eV": obs,
                     "slack": C3_WITHIN_SLACK,
                     "ok": None if obs is None else bool(rng <= obs * C3_WITHIN_SLACK)}
        r["within_fragment_range_eV"] = round(rng, 6)
    res["within_fragment"] = within
    _bad = sorted(f for f, w in within.items() if w["ok"] is False)

    if -D * C3_REF_GAP_EV <= 0:
        res["verdict"] = ("**미해결** — 예측 오프셋 차등(−D)의 부호가 관측 "
                          f"{C3_REF_GAP_EV:+.2f} eV 와 반대다. 절댓값으로 비율을 "
                          "적용하면 반대 방향 효과를 '설명' 으로 오판한다")
    elif _bad:
        res["verdict"] = (
            "**미해결 — 조각내 일관성 실패** (%s). δ 의 조각내 range 가 관측 오프셋 "
            "상수성의 %g배를 넘는다. D3 는 기하 의존 항이라 자세마다 달라야 하는데 "
            "관측 오프셋은 조각 안에서 상수였다 — 평균 비율이 맞아도 D3 귀속은 "
            "성립하지 않는다 (prereg 분산 귀속 철회)." % (", ".join(_bad), C3_WITHIN_SLACK))
    elif res["ratio"] >= C3_HI:
        res["verdict"] = (f"이 네 자세에서 관측된 {C3_REF_GAP_EV} eV 차등을 "
                          f"**수치상 {res['ratio']:.0%} 설명**한다 (인과가 아니라 분해)")
    elif res["ratio"] <= C3_LO:
        res["verdict"] = "분산 기여로는 설명되지 않는다 — 원인은 기체 기준 오차 또는 자기 basin 쪽"
    else:
        res["verdict"] = "**미해결** — 어느 것도 채택하지 않는다"
    return res


def _closure_estimand(man, results, E, emol, jobs):
    """사전등록한 조각 간 대비를 **코드로** 계산한다 (회신 V P0-4).

      A(f,p) = E_complex(f,p) - E_mol(f)      <- 공통 슬랩이 소거되는 양
      primary   ddE_lowE = min_p A(SDCP,p) - min_q A(c10,q)
      secondary G        = min_q A(c10,q) - max_p A(SDCP,p)

    회신 V P0-3 — 기체 자기상태 대조(zero vs nzmag)를 **여기서 실제로 비교**한다.
    대조가 더 낮으면 `MOLECULAR_STATE_UNRESOLVED` 로 막고 **값을 내지 않는다.**

    ⛔ 이 함수가 못 하는 것:
      · 후보집합이 **사전등록된 것인지 검사하지 않는다** (그 manifest 가 아직 없다 —
        회신 V P0-5). `candidate_set` 에 무엇을 썼는지 기록만 한다.
      · 국소 Ni topology 판정을 다시 하지 않는다 — 잡별 `gates` 를 읽어 **버린다**.
      · dense/k 보정을 적용하지 않는다. coarse static 값이다.
      · 게이트된 자세를 다음 순위로 **대체하지 않는다** (회신 U C-2: 조용한 교체 금지).
    """
    frags = [f for f in (man.get("fragments") or []) if f in emol]
    if len(frags) < 2:
        return None

    # ══ cohort 조립은 **구조화 필드**로 한다 (회신 AA P0-3) ══════════════════
    #   경로 문자열 파싱은 임시봉합이다. job.json 이 이미 kind·role·fragment·
    #   seed·basin_id·source_pose·phases·d3 를 갖고 있으므로 그것으로 조립하고,
    #   **경로와 구조화 필드가 어긋나면 hard fail** 한다 (조용히 한쪽을 믿지 않는다).
    def _meta(jr):
        return (jr.get("meta") or {})

    def _cohort(jn, jr):
        """이 잡의 (kind, fragment, seed, basin, d3) — 전부 구조화 필드에서."""
        m = _meta(jr)
        return {"kind": m.get("kind"), "fragment": m.get("fragment"),
                "seed": m.get("seed"), "basin": m.get("basin_id"),
                "d3": m.get("d3"), "role": m.get("role")}

    def _is(jn, f):
        """조각 f 의 **복합체**인가 — 구조화 필드로만 판단한다."""
        c = _cohort(jn, jobs.get(jn) or {})
        return c["kind"] == "prospective_pose" and c["fragment"] == f
    out = {
        "schema": "prereg_closure/v1",
        "prereg_doc": "db/properties/prereg_sdcp_neutral_contrast_2026_08_29.json",
        "candidate_set": man.get("candidate_set") or "legacy_champion/cross (미동결)",
        "blocks": [], "A_by_frag": {},
    }

    # ── 경로 ↔ 필드 정합성. 어긋나면 값을 만들지 않는다 ──────────────────────
    _incoh = []
    for _jn, _jr in jobs.items():
        _m = _meta(_jr)
        if not _m.get("kind"):
            _incoh.append(f"{_jn}: job.json 에 kind 없음")
            continue
        _base = _jn.rsplit("/", 1)[-1]
        _fg, _sd, _d3 = _m.get("fragment"), _m.get("seed"), _m.get("d3")
        if _fg and _m["kind"] == "prospective_pose" and not _base.startswith(_fg + "__"):
            _incoh.append(f"{_jn}: fragment={_fg} 인데 경로가 그렇지 않다")
        if _sd and _sd not in _base:
            _incoh.append(f"{_jn}: seed={_sd} 인데 경로에 없다")
        if _d3 not in ("on", "off"):
            _incoh.append(f"{_jn}: job.json 에 d3 필드가 없다 (필드 없는 잡이 남으면 "
                          f"분류가 다시 이름으로 샌다 — v7 실측)")
        elif (_d3 == "off") != _base.endswith("__d3off"):
            _incoh.append(f"{_jn}: d3={_d3} 인데 경로 접미어와 어긋난다")
    if _incoh:
        out["blocks"].append(
            "COHORT_INCOHERENT(%d건 — 경로와 구조화 필드가 어긋난다: %s). "
            "어느 쪽이 맞는지 우리가 정할 수 없으므로 값을 만들지 않는다"
            % (len(_incoh), _incoh[:3]))
    out["cohort_fields"] = {"checked": len(jobs), "incoherent": len(_incoh)}


    # (0) calibration 전용 tranche 면 **primary 를 내지 않는다** (회신 X P0-2)
    if str(out["candidate_set"]).startswith(("calibration_pilot", "motif_probe")):
        out["blocks"].append(
            "CALIBRATION_ONLY_TRANCHE — 이 잡들은 창 W 를 정하려고 돌린 것이고 "
            "후보집합이 아니다. primary 는 창 확정 → 창 안 전 자세 계산 → audit "
            "봉인해제 → regret 판정 순서를 마친 뒤에만 낸다 (회신 X Q6).")
    # (0b) 층화 홀드아웃도 **primary 를 내지 않는다** (2026-08-30, 옵션 A).
    #   홀드아웃은 선택기 가정을 시험하는 별도 질문이다. 홀드아웃이 더 낮게 나오면
    #   그것은 primary 의 min 후보가 아니라 **재개 조건 발동**이다 — 넣으면
    #   사전등록 집합이 사라지고 min 이 표본크기를 따라 움직인다
    #   (champion pool size bias, kb/results/champion_pool_size_bias_2026_08_18.md).
    if str(out["candidate_set"]).startswith("holdout_stratified"):
        out["blocks"].append(
            "HOLDOUT_TRANCHE — 층화 홀드아웃은 선택기 가정(H1·H2)을 시험하는 집합이지 "
            "primary 후보집합이 아니다. 이 잡들의 값을 ΔΔE_lowE 의 min 에 넣지 않는다. "
            "estimand 카드: kb/questions/sdcp_stageA_holdout_selector_2026_08_30.md")

    # (1) 기체 자기상태 대조 — 값을 내기 **전에** 본다 (회신 V P0-3)
    ctls = man.get("molecular_spin_controls") or {}
    for f in frags:
        rel = ctls.get("mol__%s__box24" % f)
        if not rel:
            out["blocks"].append("MOLECULAR_SPIN_CONTROL_MISSING(%s)" % f)
            continue
        e1 = E(str(rel).split("/")[-1])
        e0 = emol.get(f)
        if e1 is None:
            out["blocks"].append("MOLECULAR_SPIN_CONTROL_PENDING(%s)" % f)
        elif e0 is not None and e1 < e0 - 1e-4:
            out["blocks"].append(
                "MOLECULAR_STATE_UNRESOLVED(%s: 비영 시작이 %.4f eV 더 낮다 — "
                "자동 채택하지 않는다. 전자상태 estimand 와 box 수렴을 다시 심사할 것)"
                % (f, e0 - e1))
        else:
            out.setdefault("spin_control_delta_eV", {})[f] = round(e1 - e0, 5)

    # (2) A(f,p) — 게이트 통과한 복합체만. 게이트된 것은 **버리되 기록한다**
    #   ★ 회신 Z P0-4 — realized basin 을 같이 모은다. seed 이름(pm1/net4)으로
    #     짝지어 빼면 다른 상태를 가로질러 뺀 것이 된다.
    basins = {}
    for f in frags:
        rows = []
        for jn, jr in jobs.items():
            if not _is(jn, f) or not jr.get("ok"):
                continue
            g = [x for x in (jr.get("gates") or [])
                 if x.startswith(("MAGNETIC", "RADICAL", "PAIR_", "SOURCE_", "BASIN_"))]
            e = E(jn)
            if e is None:
                continue
            if g:
                out["blocks"].append("GATED_POSE(%s: %s)" % (jn, g[0]))
                continue
            rb = (((jr.get("geom") or {}).get("magnetic") or {})
                  .get("realized_basin_id"))
            basins.setdefault(f, {}).setdefault(rb, []).append(jn)
            rows.append([round(e - emol[f], 6), jn, rb])
        rows.sort()
        out["A_by_frag"][f] = {"n": len(rows),
                               "min": rows[0] if rows else None,
                               "max": rows[-1] if rows else None}
    out["realized_basins"] = {f: {str(k): v for k, v in (b or {}).items()}
                              for f, b in basins.items()}

    # (2c) 🔴 동종 basin 강제 — 여러 basin 이 섞인 집합에서 min 을 뽑지 않는다
    for f, b in basins.items():
        if None in b:
            out["blocks"].append(
                "BASIN_UNRESOLVED_IN_SET(%s: %d잡이 realized basin 없음 — %s)"
                % (f, len(b[None]), b[None][:3]))
        real = {k: v for k, v in b.items() if k is not None}
        if len(real) > 1:
            out["blocks"].append(
                "BASIN_HETEROGENEOUS(%s: 서로 다른 realized basin %d개가 한 집합에 "
                "있다 %s — 상태를 가로질러 min 을 뽑지 않는다. seed 이름이 아니라 "
                "수렴 결과가 갈렸다는 뜻이다)"
                % (f, len(real), {k: len(v) for k, v in real.items()}))

    # (2d) clean slab 과의 동종성 — E_ads 를 만들 때 필요하다 (회신 Z P0-4)
    _slab_rb = set()
    for jn, jr in jobs.items():
        if _cohort(jn, jr)["kind"] != "clean_ref" or not jr.get("ok"):
            continue
        rb = ((jr.get("geom") or {}).get("magnetic") or {}).get("realized_basin_id")
        if rb:
            _slab_rb.add(rb)
    if _slab_rb:
        out["clean_slab_basins"] = sorted(_slab_rb)
        _cx = {k for b in basins.values() for k in b if k is not None}
        if _cx and not (_cx & _slab_rb):
            out["blocks"].append(
                "BASIN_MISMATCH_SLAB(복합체 basin %s 이 clean slab basin %s 과 "
                "겹치지 않는다 — 이 둘로 흡착에너지를 만들지 않는다)"
                % (sorted(_cx)[:2], sorted(_slab_rb)[:2]))

    # (2b) J_f — pose × magnetic-basin interaction (회신 X Q1)
    #   조각별로 자세 p 의 두 seed 차 d_p = E(p,net4) − E(p,pm1) 를 모아
    #   J_f = max_p d_p − min_p d_p. 자세마다 자기 basin 이 다르게 잡히면 커진다.
    for f in frags:
        d = {}
        for jn, jr in jobs.items():
            c = _cohort(jn, jr)
            if not _is(jn, f) or not jr.get("ok") or c["d3"] == "off":
                continue
            if not c["basin"] or not c["seed"]:
                continue                      # 구조화 필드가 없으면 짝을 못 맞춘다
            d.setdefault(c["basin"], {})[c["seed"]] = E(jn)
        dp = {k: v["afm2424_net4"] - v["afm2424_pm1"] for k, v in d.items()
              if v.get("afm2424_net4") is not None and v.get("afm2424_pm1") is not None}
        # 🔴 회신 AB P0-7 — 종전엔 짝이 **2개만 있어도** J_f 를 냈다. 네 자세 중
        #   한둘이 빠지면 range 가 자동으로 좁아져 **거짓 PASS** 가 된다(C1 과 같은
        #   편향). 기대 자세 수는 동결 manifest 에서 세고, 그 수만큼 두 seed 가
        #   **모두** 유효할 때만 낸다.
        _want = len({k.rsplit("/", 1)[-1].split("__")[1]
                     for k in (man.get("planned") or {})
                     if k.startswith("prospective/")
                     and k.rsplit("/", 1)[-1].startswith(f + "__")
                     and len(k.rsplit("/", 1)[-1].split("__")) > 2})
        if not _want or len(dp) != _want:
            out.setdefault("pose_basin_interaction", {})[f] = {
                "판정": "unresolved", "n_pose_used": len(dp), "n_pose_required": _want,
                "why": ("계획한 자세 전부가 두 seed 다 유효해야 한다 — 부분집합은 "
                        "range 를 좁혀 통과 쪽으로 편향된다 (회신 AB P0-7)")}
            continue
        jf = max(dp.values()) - min(dp.values())
        out.setdefault("pose_basin_interaction", {})[f] = {
            "n_pose": len(dp), "n_pose_required": _want,
            "J_f_meV": round(jf * 1000, 2),
            "delta_by_pose_meV": {k: round(v * 1000, 2) for k, v in sorted(dp.items())},
            # ⚠ 회신 AB P0-7 — "seed-insensitive" 는 **과한 말**이다. 시험한 네 자세
            #   안에서 range 가 작았다는 것뿐이고, seed 에 둔감하다는 일반 진술이
            #   아니다. 허용 문구를 그대로 박는다.
            "판정": ("seed×pose interaction range 가 작았다 (시험한 %d자세 안에서)"
                     % len(dp) if jf <= 0.010 else
                     "magnetic-sensitive" if jf <= 0.040 else
                     "⛔ SELECTOR_FAIL — J_f > 40 meV")}

    # ── 닫힘 조건 C1 · C3 — **코드로** 낸다 (회신 AA P0-4 "실행 가능한 estimand")
    #   primary 가 막혀도 이 둘은 나온다. 손계산으로 넘기면 결과를 보고 식을 고를
    #   여지가 남고, 그것이 이 캠페인을 여덟 번 물린 경로다.
    try:
        out["closure_C1"] = closure_C1(man, jobs, E, emol, frags)
        out["closure_C3"] = closure_C3(man, jobs, E, frags)
        out["closure_C5"] = closure_C5(man, jobs, E, emol, frags)
    except Exception as _e:                                  # noqa: BLE001
        out["blocks"].append(f"CLOSURE_COND_ERROR({_e!r})")

    if out["blocks"]:
        out["verdict"] = "NO_VALUE — blocks 를 해소하기 전에는 단일 X 를 보고하지 않는다"
        return out

    sd = next((f for f in frags if "sdcp" in f), None)
    ct = next((f for f in frags if f != sd), None)
    a_s = out["A_by_frag"].get(sd) or {}
    a_c = out["A_by_frag"].get(ct) or {}
    if not (a_s.get("min") and a_c.get("min")):
        out["verdict"] = "NO_VALUE — 조각 한쪽에 게이트 통과 자세가 없다"
        return out

    primary = a_s["min"][0] - a_c["min"][0]
    secondary = a_c["min"][0] - a_s["max"][0]
    out["primary_ddE_lowE_eV"] = round(primary, 4)
    out["secondary_G_eV"] = round(secondary, 4)
    out["reported_X_eV"] = round(round(primary / PREREG_ROUND_EV) * PREREG_ROUND_EV, 2)
    out["fragments"] = {"sdcp": sd, "control": ct}
    if primary <= PREREG_GUARD_EV:
        out["guard"] = "통과 (primary %.4f <= %.2f)" % (primary, PREREG_GUARD_EV)
        out["verdict"] = "보고 가능"
    else:
        out["guard"] = ("⛔ primary %+.4f > %.2f — guard band 미달"
                        % (primary, PREREG_GUARD_EV))
        out["verdict"] = "NO_DIRECTIONAL_CLAIM"
    out["⚠_후보집합"] = ("candidate_set 이 동결된 prospective_lowE 가 아니면 이 값은 "
                         "primary 가 아니라 **legacy 교정 tranche** 다 (회신 V P0-5). "
                         "'primary'·'low-energy'·'pose-insensitive'·'전역 최소' 로 쓰지 말 것")
    return out


def main():
    if "--selftest" in sys.argv:
        return selftest_k()
    if "--check_pin" in sys.argv:
        i = sys.argv.index("--check_pin")
        return check_pin(sys.argv[i + 1] if len(sys.argv) > i + 1 else ".")
    root = sys.argv[1] if len(sys.argv) > 1 else "."
    delta = DELTA
    if "--delta" in sys.argv:
        delta = float(sys.argv[sys.argv.index("--delta") + 1])
    man = json.load(open(os.path.join(root, "MANIFEST.json")))
    spec = man.get("potcar_spec", {})
    planned = man.get("planned", {})

    # ── 입력 무결성 (Codex P0-H) — INCAR 이 바뀌었는지부터 본다 ──────────────
    integrity = {"checked": 0, "changed": [], "missing": []}
    for rel, want in (man.get("files_sha256") or {}).items():
        p = os.path.join(root, rel)
        if not os.path.isfile(p):
            integrity["missing"].append(rel); continue
        integrity["checked"] += 1
        got = hashlib.sha256(open(p, "rb").read()).hexdigest()
        if got != want:
            integrity["changed"].append(rel)

    # ── 실행시 POSCAR 가 루트 POSCAR 와 같은가 (Codex 6차 §8) ─────────────────
    #   단일점 판의 주장은 "UMA 가 고른 **그 기하** 위의 DFT 에너지" 다. 외주처가
    #   다른 기하를 넣었으면 무결성 해시(배포 파일)는 통과해도 계산은 다른 계다.
    #   상 폴더의 POSCAR 는 배포물이 아니라 **러너가 만든 것**이라 files_sha256 에 없다.
    integrity["runtime_poscar_mismatch"] = []
    for jd in sorted(glob(os.path.join(root, "*", "*", ""))):
        rp = os.path.join(jd, "POSCAR")
        if not os.path.isfile(rp):
            continue
        rh = hashlib.sha256(open(rp, "rb").read()).hexdigest()
        for ph in ("static", "dense"):
            pp = os.path.join(jd, ph, "POSCAR")
            if not os.path.isfile(pp):
                continue
            if os.path.isdir(os.path.join(jd, "relax")):
                continue          # 이완판은 CONTCAR 승계가 정상 — 달라야 맞다
            if hashlib.sha256(open(pp, "rb").read()).hexdigest() != rh:
                integrity["runtime_poscar_mismatch"].append(
                    _pk(pp, root))
    # ★ phase POSCAR 를 반송받지 못하면 위 검사는 **조용히 건너뛴다** = fail-open.
    #   OUTCAR 가 있는데 POSCAR 가 없으면 OUTCAR 좌표로 대조한다 (Codex P0-6).
    integrity["geometry_unverified"] = []
    for jd in sorted(glob(os.path.join(root, "*", "*", ""))):
        rp = os.path.join(jd, "POSCAR")
        if not os.path.isfile(rp) or os.path.isdir(os.path.join(jd, "relax")):
            continue
        want = read_poscar(rp)
        for ph in ("static", "dense"):
            has_oc = any(os.path.isfile(os.path.join(jd, ph, "OUTCAR" + e))
                         for e in ("", ".gz"))
            if not has_oc or os.path.isfile(os.path.join(jd, ph, "POSCAR")):
                continue
            oc = read_outcar(os.path.join(jd, ph, "OUTCAR"))
            pos = (oc or {}).get("positions")
            rel = _pk(os.path.join(jd, ph), root)
            if not pos or not want or len(pos) != len(want["pos"]):
                integrity["geometry_unverified"].append(rel)
                continue
            d = max(mic_dist(a, b, want["cell"]) for a, b in zip(pos, want["pos"]))
            if d > 0.05:
                integrity["runtime_poscar_mismatch"].append(
                    f"{rel} (OUTCAR 좌표가 루트와 최대 {d:.3f} Å 다르다)")

    jobs = {}
    results_ldau_missing = []
    for jd in sorted(glob(os.path.join(root, "*", "*", ""))):
        jp = os.path.join(jd, "job.json")
        if not os.path.isfile(jp):
            continue
        meta = json.load(open(jp))
        rel = _pk(jd, root)
        phases = (planned.get(rel) or {}).get("phases") or meta.get("phases") or \
            ["relax", "static"]
        ocs = {ph: read_outcar(os.path.join(jd, ph, "OUTCAR")) for ph in phases}
        # ⛔ 2026-08-25 (codex E-2차 필수5) — static/dense 만 남기면 static_pin 등
        #   다른 상의 감사·세그먼트가 **RESULTS 에서 유실**된다. 모든 상을 보존한다.
        rec = {"meta": meta, "static": ocs.get("static"), "dense": ocs.get("dense"),
               "gates": []}
        for _ph in phases:
            rec[_ph] = ocs.get(_ph)
        for ph in phases:
            rec["gates"] += phase_gates(ocs[ph], ph, meta, spec,
                                        want_ionic=(ph == "relax"))
        # ★ 격자가 커지는 상 사이로 NKPTS 가 안 늘면 **같은 계산을 복사한 것**이다.
        km = meta.get("kmesh") or {}
        seq = [ph for ph in phases if ocs.get(ph) and ocs[ph].get("nkpts") and km.get(ph)]
        for x, y in zip(seq, seq[1:]):
            px = py = 1
            for v in str(km[x]).split():
                px *= int(v)
            for v in str(km[y]).split():
                py *= int(v)
            if py > px and ocs[y]["nkpts"] <= ocs[x]["nkpts"]:
                rec["gates"].append(
                    f"KMESH_NOT_DENSER({y} NKPTS {ocs[y]['nkpts']} ≤ {x} {ocs[x]['nkpts']} "
                    f"인데 격자는 {km[x]}→{km[y]} — 다른 상의 산출을 복사했나)")
        g2, info = geometry_audit(jd, meta)
        rec["gates"] += g2
        rec["geom"] = {k: v for k, v in info.items() if not k.startswith("_")}
        rec["_contact_fp"] = info.get("_contact_fp")
        rec["_fin"] = info.get("_fin")
        rx = ocs.get("relax")
        # 힘: 블록이 없거나 원자수가 다르면 **검사 생략이 아니라 게이트**
        if rx is not None:
            if not rx.get("forces"):
                rec["gates"].append("FORCE_UNVERIFIED(TOTAL-FORCE 블록 없음)")
            elif info.get("_init_fixed") and len(rx["forces"]) != len(info["_init_fixed"]):
                rec["gates"].append(
                    f"FORCE_COUNT({len(rx['forces'])}!={len(info['_init_fixed'])})")
            elif info.get("_init_fixed"):
                fmax = max((math.sqrt(sum(c * c for c in f))
                            for f, fx in zip(rx["forces"], info["_init_fixed"]) if not fx),
                           default=0.0)
                rec["geom"]["free_fmax_eVA"] = round(fmax, 3)
                if fmax > FORCE_TOL:
                    rec["gates"].append(f"FORCE_HIGH({fmax:.3f} eV/Å)")
        # ── 단일점의 static 힘: **진단값**이지 수렴 판정이 아니다 (Codex 6차 §4) ──
        #   MLIP 기하가 DFT 최소점에서 얼마나 먼지를 보여 준다. 큰 잔류힘은
        #   "그 자세만 DFT 이완으로 넘길까" 를 결정하는 trigger 로 쓴다.
        #   ⚠ 힘 하나로 단일점 에너지 오차의 부호나 상한을 만들 수 없다 — 게이트 아님.
        st0 = ocs.get("static")
        if rx is None and st0 is not None and st0.get("forces") and \
                info.get("_init_fixed") and \
                len(st0["forces"]) == len(info["_init_fixed"]):
            fr = [math.sqrt(sum(c * c for c in f))
                  for f, fx in zip(st0["forces"], info["_init_fixed"]) if not fx]
            if fr:
                rec["geom"]["uma_geometry_residual_force"] = {
                    "fmax_eVA": round(max(fr), 3),
                    "frms_eVA": round(math.sqrt(sum(x * x for x in fr) / len(fr)), 3),
                    "meaning": ("MLIP 기하의 DFT 잔류힘 — **진단값**. 수렴 판정도, "
                                "에너지 오차 상한도 아니다. 크면 그 자세만 DFT 이완 검토."),
                    "trigger_hint_eVA": FORCE_TOL}
        # ── 자기상태 감사 (Codex P0-E · 2026-08-12 재작성) ──
        st = ocs.get("static")
        want_sign = meta.get("ni_sign_poscar_idx") or {}
        mol_sign = meta.get("mol_sign_poscar_idx") or {}
        if st is not None and want_sign:
            mom = st.get("moments")
            nions = st.get("nions")
            # ★ 완결성부터 hard gate — 표가 짧으면 파싱된 것만 검사하고 나머지를
            #   조용히 버리던 구멍이 있었다 (Ni 1개만 남겨도 통과했다).
            if not mom:
                rec["gates"].append("MAGNETIC_UNVERIFIED(LORBIT 모멘트 표 없음)")
            elif nions and len(mom) != nions:
                rec["gates"].append(
                    f"MAGNETIC_INCOMPLETE(모멘트 {len(mom)}행 ≠ NIONS {nions})")
            elif max(int(k) for k in want_sign) >= len(mom):
                rec["gates"].append(
                    f"MAGNETIC_INCOMPLETE(Ni 인덱스가 모멘트 표 {len(mom)}행 밖)")
            else:
                ni = {int(k): float(v) for k, v in want_sign.items()}
                got = {i: mom[i] for i in ni}
                # ★ 전역 반전은 시간반전이라 **같은 상태**다 — 부호를 정규화해 비교하고,
                #   진짜 문제인 **부분 반전**을 잡는다 (옛 판은 정반대였다).
                sg, flip = global_sign(got, ni)
                small = [i for i, m in got.items() if abs(m) < MOM_MIN]
                rec["geom"]["magnetic"] = {
                    "n_ni": len(ni), "global_sign": sg, "n_partial_flip": len(flip),
                    # ⛔ 2026-08-25 (codex E-4) — 개수만 남기면 "항상 같은 자리 #82"
                    #   라는 관측을 **아무도 재검증할 수 없다**. 인덱스를 기계기록.
                    "flip_indices_poscar": sorted(flip), "index_base": 0,
                    "flip_indices_poscar_1based": [i + 1 for i in sorted(flip)],
                    "flip_moments_muB": {str(i): round(got[i], 3) for i in flip},
                    "n_small": len(small), "min_abs_muB": round(min(map(abs, got.values())), 3),
                    "abs_mean_muB": round(sum(map(abs, got.values())) / len(got), 3),
                    "total_muB": st.get("mag_total")}
                # ★ 회신 Z P0-4 — realized basin 지문. seed 이름으로 짝지으면 안 된다.
                _rb, _rbd = realized_basin_id(mom, want_sign, mol_sign,
                                             incar_echo=st.get("incar_echo"))
                rec["geom"]["magnetic"]["realized_basin_id"] = _rb
                rec["geom"]["magnetic"]["realized_basin"] = _rbd
                if _rb is None:
                    rec["gates"].append(
                        f"BASIN_UNRESOLVED({_rbd.get('why')}) — realized basin 을 "
                        f"만들 수 없어 이 잡으로는 뺄셈을 하지 않는다")
                if flip:
                    rec["gates"].append(
                        f"MAGNETIC_PARTIAL_FLIP({len(flip)}/{len(ni)} Ni 가 시드 topology 와 "
                        f"다르다 — 다른 자기 basin 이다)")
                # ★★ 라디칼 상대 스핀은 **항상** 본다 (Codex 재감사 P0-2).
                #   옛 판은 Ni 가 전역 반전(sg<0)일 때만 검사해서, Ni topology 는
                #   그대로인데 라디칼 하나만 뒤집힌 경우가 **게이트 없이 통과**했다.
                #   dense 에는 넣었는데 static 에는 안 넣어서 실질적으로 열려 있었다.
                ms = {int(k): float(v) for k, v in mol_sign.items() if int(k) < len(mom)}
                if ms:
                    # Ni 전역부호 sg 로 정규화한 뒤 라디칼의 **상대** 부호를 본다.
                    bad = [i for i, v in ms.items() if mom[i] * sg * v <= 0]
                    small = [i for i in ms if abs(mom[i]) < MOM_MIN]
                    rec["geom"]["magnetic"]["radical"] = {
                        "n": len(ms), "sign_mismatch": len(bad), "collapsed": len(small),
                        "ni_global_sign": sg, "total_muB": st.get("mag_total")}
                    if bad or small:
                        rec["gates"].append(
                            f"RADICAL_BRANCH_CHANGED(부호 불일치 {len(bad)} · 소실 "
                            f"{len(small)}/{len(ms)} — Ni 부호를 정규화한 뒤에도 라디칼 "
                            f"상대 스핀이 시드와 다르다. 다른 스핀 basin 이다)")
                    elif sg < 0:
                        rec["geom"]["magnetic"]["note"] = (
                            "Ni·라디칼이 **함께** 전역 반전 — 시간반전이라 같은 상태")
                # ── LDAU occupation + total M 기록 (Codex P0-2 ③) ──
                #   판정용이 아니라 **기록용**이다 — 절대값은 PAW sphere 규약 의존.
                ld = st.get("ldau")
                if ld:
                    ups = sorted(ld.items())
                    mm = [round(v[0] - v[1], 3) for _k, v in ups]
                    rec["geom"]["magnetic"]["ldau"] = {
                        "n_atoms": len(ld),
                        "mean_n_up_dn": [round(sum(v[0] for _k, v in ups) / len(ups), 3),
                                         round(sum(v[1] for _k, v in ups) / len(ups), 3)],
                        "moment_from_occ_mean_abs": round(
                            sum(abs(x) for x in mm) / len(mm), 3),
                        "fingerprint": hashlib.sha256(
                            json.dumps(ups, sort_keys=True).encode()).hexdigest()[:12]}
                else:
                    rec["geom"]["magnetic"]["ldau"] = None
                    results_ldau_missing.append(rel)

                # ── dense 자기감사 — static 과 **같은 수준**으로 (Codex 7차 §8) ──
                #   ⚠ 옛 판은 dense 에 모멘트 표가 없으면 그냥 서명에서 빠졌다. 그러면
                #     local moment 가 없는 dense OUTCAR 도 E0 만으로 κ 에 들어간다.
                #     dense 는 **에너지를 내는 상**이므로 static 과 같은 문턱을 건다.
                dn = ocs.get("dense")
                if dn is not None:
                    dm = dn.get("moments")
                    if not dm:
                        rec["gates"].append(
                            "DENSE_MOMENTS_MISSING(dense OUTCAR 에 모멘트 표가 없다 — "
                            "자기상태를 모르고 κ 에 쓸 수 없다)")
                    elif dn.get("nions") and len(dm) != dn["nions"]:
                        rec["gates"].append(
                            f"DENSE_MOMENT_COUNT({len(dm)} != NIONS {dn['nions']})")
                    elif max(ni) >= len(dm):
                        rec["gates"].append(
                            f"DENSE_MOMENT_SHORT(Ni 인덱스 {max(ni)} 가 표 밖 — "
                            f"표 길이 {len(dm)})")
                    else:
                        miss = [i for i in ni if i >= len(dm)]
                        # ★★ dense 는 **자기 전역부호를 스스로** 구한다 (Codex 5차 P1-2).
                        #   옛 판은 static 의 sg 를 재사용해서, dense 가 완전한 시간반전
                        #   상태(Ni·라디칼·총 M 이 **함께** 뒤집힘)로 수렴하면 물리적으로
                        #   같은 상태인데도 전부 부호 불일치로 잡아 거짓 차단했다.
                        #   바로 아래 phase_sign_sig 는 전역반전을 같은 상태로 인정하는데
                        #   여기만 규칙이 달랐다 — 한 기능이 두 규칙을 쓰고 있었다.
                        sg_d, _dflip = global_sign({i: dm[i] for i in ni}, ni)
                        dq = sum(sg_d * ni[i] * dm[i] for i in ni) / len(ni)
                        dsmall = [i for i in ni if abs(dm[i]) < MOM_MIN]
                        rec["geom"]["magnetic"]["dense"] = {
                            "n_ni_found": len(ni) - len(miss),
                            "global_sign": sg_d,
                            "global_flip_vs_static": (sg_d != sg),
                            "Q_muB": round(dq, 3),
                            "f_small": round(len(dsmall) / len(ni), 3),
                            "total_muB": dn.get("mag_total")}
                        # ★ open-shell 조각(doped)의 **라디칼 상대 스핀**을 dense 에서도
                        #   본다 (Codex zip 감사 P0-5). Ni topology 는 그대로인데
                        #   라디칼만 뒤집히거나 사라지면 다른 스핀 상태를 재는 것이다.
                        if mol_sign:
                            _ms = {int(k2): float(v2) for k2, v2 in mol_sign.items()
                                   if int(k2) < len(dm)}
                            # dense 자기 부호로 정규화한 뒤 **상대** 스핀을 본다
                            _bad = [i for i, v2 in _ms.items() if dm[i] * sg_d * v2 <= 0]
                            _gone = [i for i in _ms if abs(dm[i]) < MOM_MIN]
                            rec["geom"]["magnetic"]["dense"]["radical"] = {
                                "n": len(_ms), "sign_mismatch": len(_bad),
                                "collapsed": len(_gone),
                                "total_muB": dn.get("mag_total")}
                            if _bad or _gone:
                                rec["gates"].append(
                                    f"DENSE_RADICAL_BRANCH_CHANGED(부호 불일치 {len(_bad)} · "
                                    f"소실 {len(_gone)}/{len(_ms)} — Ni 는 유지됐지만 "
                                    f"라디칼 상대 스핀이 달라졌다. κ 에 쓸 수 없다)")
                            # ⚠ 총 M 도 **절대값**으로 본다 — 전역 시간반전이면 부호가
                            #   같이 뒤집히는 게 정상이다.
                            _tm, _td = st.get("mag_total"), dn.get("mag_total")
                            if _tm is not None and _td is not None and \
                                    abs(abs(_tm) - abs(_td)) > 0.5:
                                rec["gates"].append(
                                    f"DENSE_TOTAL_M_CHANGED({_tm:+.2f} → {_td:+.2f} μB — "
                                    f"static↔dense 자기 branch 가 넘어갔다)")
                        qs = rec["geom"]["magnetic"].get("Q_muB")
                        if qs is not None and abs(qs) > 1e-9:
                            rat = dq / qs
                            rec["geom"]["magnetic"]["dense"]["Q_ratio_vs_static"] = round(rat, 3)
                            if rat < Q_RATIO_MIN:
                                rec["gates"].append(
                                    f"DENSE_MAGNETIC_COLLAPSE(Q_dense/Q_static={rat:.2f} — "
                                    f"k 를 촘촘히 했더니 자기상태가 무너졌다. κ 는 k 효과가 "
                                    f"아니라 spin-state 차를 재게 된다)")

                # ── 상별 자기 branch — k 를 바꾸며 상태가 넘어가면 'k 오차'가 아니다 ──
                sig = {}
                for ph2 in phases:
                    o2 = ocs.get(ph2)
                    if not o2 or not o2.get("moments"):
                        continue
                    mo = o2["moments"]
                    if max(ni) < len(mo):
                        sig[ph2] = "".join("+" if mo[i] > 0 else "-" for i in sorted(ni))
                rec["geom"]["magnetic"]["phase_sign_sig"] = {
                    k2: hashlib.sha256(v.encode()).hexdigest()[:8] for k2, v in sig.items()}
                uniq = {v for v in sig.values()}
                # 전역 반전끼리는 같은 상태다 — 반전본도 같이 넣어 비교한다
                if len(uniq) > 1:
                    base = sorted(sig)[0]
                    flip = sig[base].translate(str.maketrans("+-", "-+"))
                    if not all(v in (sig[base], flip) for v in sig.values()):
                        rec["gates"].append(
                            f"MAGNETIC_BRANCH_CHANGED(상별 Ni 부호 topology 가 다르다 "
                            f"{ {k2: v[:8] for k2, v in sig.items()} } — k 오차가 아니라 "
                            f"spin-state 차이를 재게 된다)")

                # ⚠ MOM_MIN 단독 문턱은 보편적이지 않다 (Codex Q7). LORBIT local moment 는
                #   PAW sphere/projector 의존 정성 지표라 표면 Ni 가 물리적으로 0.3 아래로
                #   갈 수 있다. 집단 지표 Q(부호 정규화 평균)와 f_small 을 clean 기준으로
                #   보정해 판정한다 — 절대 판정은 main() 에서 clean 분포를 알고 내린다.
                Q = sum(sg * ni[i] * got[i] for i in ni) / len(ni)
                rec["geom"]["magnetic"]["Q_muB"] = round(Q, 3)
                rec["geom"]["magnetic"]["f_small"] = round(len(small) / len(ni), 3)
                if small:
                    rec["geom"]["magnetic"]["review"] = (
                        f"{len(small)}개가 |m|<{MOM_MIN} — clean 분포와 대조 (아래 집단 판정)")
        rec["ok"] = not rec["gates"]
        jobs[rel] = rec

    # ── 자기 붕괴는 **clean seed 분포 기준**으로 판정한다 (Codex Q7) ──────────
    #   숫자(0.5·0.25)는 초기 민감도일 뿐이다. clean 두 seed 의 Q 를 기준으로 보고,
    #   기준이 없으면 판정을 보류한다(임의 문턱으로 죽이지 않는다).
    #   ★ 2026-08-12 (Codex 6차) 세 가지를 고친다:
    #     (a) `... .get("Q_muB")` 진리값 검사 → **Q=0 인 clean 을 결측으로 버린다**.
    #         Q=0 은 "완전 붕괴한 기준" 이라는 중요한 사실이다. is not None 으로 본다.
    #     (b) 두 seed 중 max 하나를 모든 pose 에 공통 적용 → seed 별 branch 차이가 섞인다.
    #         **같은 seed 의 clean** 과 비교한다.
    #     (c) clean 자체가 무자격(게이트 걸림·Q 결측)이면 조용히 통과시키지 말고
    #         MAGNETIC_REFERENCE_INVALID 로 남긴다.
    # ── rescue supersedes (wave1.5 · codex E-2차 필수1) ───────────────────────
    #   job.json 에 rescue.supersedes = "refs/clean_slab__<seed>" 가 있고 그 잡이
    #   **모든 게이트를 통과**하면, 그 seed 의 clean 참조를 rescue 잡으로 바꾼다.
    #   실패하면 원본 유지 + reference_overrides 에 거부 사유를 남긴다 (조용한 무시 금지).
    ref_alias: Dict[str, str] = {}
    ref_overrides: Dict[str, Any] = {}
    for j, r in jobs.items():
        sup = ((r.get("meta") or {}).get("rescue") or {}).get("supersedes")
        if not sup:
            continue
        _pok, _pwhy = rescue_provenance_ok(os.path.join(root, j))
        if r.get("ok") and _pok:
            ref_alias[sup] = j
            ref_overrides[sup] = {"used": j, "status": "superseded",
                                  "why": "rescue 잡이 전 게이트 + provenance 통과"}
        else:
            _reasons = [] if r.get("ok") else list((r.get("gates") or [])[:3])
            if not _pok:
                _reasons.append(f"provenance: {_pwhy}")
            ref_overrides[sup] = {"used": sup, "status": "rescue_rejected",
                                  "rejected_job": j, "why": "; ".join(_reasons)}
    # (results dict 는 아래에서 만들어진다 — 거기서 reference_overrides 로 실림)

    q_by_seed: Dict[str, Optional[float]] = {}
    ref_bad: Dict[str, str] = {}
    for sd in (man.get("seeds_full") or ["afm2424_pm1", "afm2424_net4"]):
        _canon = f"refs/clean_slab__{sd}"
        if _canon in ref_alias:
            cj = [(ref_alias[_canon], jobs[ref_alias[_canon]])]
        else:
            cj = [(j, r) for j, r in jobs.items()
                  if "clean_slab" in j and j.endswith(sd)]
        if not cj:
            ref_bad[sd] = "clean 대조군 없음"
            continue
        j, r = cj[0]
        q = ((r.get("geom") or {}).get("magnetic") or {}).get("Q_muB")
        if q is None:
            ref_bad[sd] = f"{j}: Ni moment 미완 — Q 없음"
        elif r.get("gates"):
            ref_bad[sd] = f"{j}: 기준 자체가 게이트 걸림 ({r['gates'][0][:40]})"
        else:
            q_by_seed[sd] = float(q)
    for j, r in jobs.items():
        mg = (r.get("geom") or {}).get("magnetic")
        if not mg or "Q_muB" not in mg:
            continue
        sd = r["meta"].get("seed")
        q_ref = q_by_seed.get(sd)
        mg["Q_clean_ref"] = q_ref
        mg["Q_clean_ref_seed"] = sd
        if q_ref is None:
            mg["verdict"] = "clean 기준 없음/무효 — 자기 붕괴 판정 보류"
            if "clean_slab" not in j:
                r["gates"].append(
                    f"MAGNETIC_REFERENCE_INVALID({sd}: "
                    f"{ref_bad.get(sd, '기준 없음')} — 자기 붕괴를 판정할 수 없다)")
                r["ok"] = not r["gates"]
            continue
        ratio = (mg["Q_muB"] / q_ref) if abs(q_ref) > 1e-9 else None
        mg["Q_ratio"] = None if ratio is None else round(ratio, 3)
        if ratio is None:
            # ⛔ 완전히 붕괴한 clean 은 **유효한 기준이 아니다** (Codex 7차 §9).
            #   "판정 보류" 로 pose 를 통과시키면 fail-open 이다.
            mg["verdict"] = "⛔ clean 기준 Q≈0 — 기준 자체가 무효"
            if "clean_slab" not in j:
                r["gates"].append(
                    f"MAGNETIC_REFERENCE_INVALID({sd}: clean Q≈0 — 기준이 붕괴했다. "
                    f"이 seed 의 headline 에서 제외)")
                r["ok"] = not r["gates"]
            continue
        if ratio < Q_RATIO_MIN or mg["f_small"] > F_SMALL_MAX:
            r["gates"].append(
                f"MAGNETIC_COLLAPSE(Q/Q_clean[{sd}]={ratio:.2f} · "
                f"f_small={mg['f_small']:.2f} — 같은 seed clean 대비 집단 붕괴)")
            r["ok"] = not r["gates"]

    # ── POTCAR 변형: 준중심 차이는 일관돼도 치명 (Codex P0-C) ────────────────
    subs, mixed = {}, False
    for r in jobs.values():
        st = r.get("static") or {}
        expect = [spec.get(e, e) for e in r["meta"].get("species_order", [])]
        got = [x.split()[1] if len(x.split()) > 1 else x for x in st.get("titels") or []]
        if expect and got and len(expect) == len(got):
            for e, g in zip(expect, got):
                if e != g:
                    if e in subs and subs[e] != g:
                        mixed = True
                    subs[e] = g
    potcar_warn = None
    # ⛔ 2026-08-12 — "일관되게 다르면 경고" 를 폐기한다. 고정 protocol 에서는
    #   Ni_pv → Ni_sv 도 다른 가전자·projector 라 다른 Hamiltonian 이다. 한 글자라도
    #   다르면 headline 에서 제외한다 (감도로 쓰려면 별도 protocol ID 로 분리).
    if subs:
        txt = ", ".join(f"{e}→{g}" for e, g in sorted(subs.items()))
        for r in jobs.values():
            r["gates"].append(f"POTCAR_WRONG({txt}{' · 혼재' if mixed else ''})")
            r["ok"] = False

    def E(job):
        job = ref_alias.get(job, job)          # supersedes 반영 (wave1.5)
        r = jobs.get(job)
        return r["static"]["E0"] if r and r["ok"] and r["static"] and \
            r["static"]["E0"] is not None else None

    def E_dense(job):
        """dense 도 static 과 **같은 기준**으로 건다 (옛 판은 에너지만 읽었다)."""
        r = jobs.get(job)
        if not r or not r["ok"]:
            return None
        oc = r.get("dense")
        if oc is None or not oc["normal_end"] or oc["nelm_hit"] or oc["E0"] is None:
            return None
        return oc["E0"]

    # ── --plan_dense : 조건부 dense 선택 (Codex 6차 §3) ──────────────────────
    #   왜 분석기 안인가: OUTCAR 회수·자기 게이트·유효성 판정을 **그대로 재사용**한다.
    #   별도 스크립트로 빼면 그 로직이 두 벌이 되고, 갈라지면 아무도 모른다.
    if "--plan_dense" in sys.argv:
        return plan_dense(root, man, jobs, E, E_dense)

    results = {"delta_eV": delta, "pairs": {}, "fragments": {}, "e_ads": {},
               "reference_overrides": ref_overrides,
               "numerical_gates": {}, "warnings": [], "integrity": integrity,
               # incar_audit (codex E-2) — 게이트 통과가 **무엇까지 보증하는지**의
               #   기계 기록: verified_exact / verified_equivalence_class /
               #   unverified / mismatch + 실행 세그먼트 정보. 사람용 요약(README)과
               #   어긋나면 이쪽이 정본이다.
               "jobs": {j: {"ok": r["ok"], "gates": r["gates"],
                            "E0_static": (r["static"] or {}).get("E0"),
                            "vasp_version": (r["static"] or {}).get("vasp_version"),
                            "incar_audit": {ph: (r.get(ph) or {}).get("incar_audit")
                                            for ph in (r["meta"].get("phases")
                                                       or ["static", "dense"])
                                            if (r.get(ph) or {}).get("incar_audit")},
                            "run_segments": {ph: (r.get(ph) or {}).get("run_segments")
                                             for ph in (r["meta"].get("phases")
                                                        or ["static", "dense"])
                                             if (r.get(ph) or {}).get("run_segments")},
                            "geom": r.get("geom")} for j, r in jobs.items()}}
    if potcar_warn:
        results["warnings"].append(potcar_warn)
    if results_ldau_missing:
        results["warnings"].append(
            f"LDAU occupation matrix 가 없는 잡 {len(results_ldau_missing)}개 "
            f"(LDAUPRINT=2 인데 OUTCAR 에 onsite density matrix 없음) — "
            f"자기상태를 모멘트 하나로만 보게 된다: "
            + ", ".join(results_ldau_missing[:4]))
    if integrity.get("geometry_unverified"):
        results["warnings"].append(
            f"⚠ 실행 기하를 검증 못 한 상 {len(integrity['geometry_unverified'])}개 — "
            f"phase POSCAR 도 OUTCAR 좌표도 없다: "
            + ", ".join(integrity["geometry_unverified"][:5]))
    if integrity.get("runtime_poscar_mismatch"):
        results["warnings"].append(
            f"⛔ 실행시 POSCAR 가 루트와 다른 상 "
            f"{len(integrity['runtime_poscar_mismatch'])}개 — **다른 기하를 계산했다** "
            f"(단일점 주장 무효): "
            + ", ".join(integrity["runtime_poscar_mismatch"][:6]))
    if integrity["changed"]:
        results["warnings"].append(
            f"⛔ 번들 입력 {len(integrity['changed'])}개가 바뀌었다 (INCAR/POSCAR 변조?): "
            + ", ".join(integrity["changed"][:8]))

    # ── 기체상 — 상자 게이트. **정본은 큰 상자(box24)** ──────────────────────
    #   ⚠ Wave 1(기준계 미포함)은 기준계가 **의도적으로** 없다 — 실패가 아니다.
    #     그걸 "상자 게이트 실패" 로 찍으면 정상 실행을 고장으로 읽게 된다.
    emol, mol_ok = {}, {}
    has_refs = bool(man.get("refs", {}).get("clean_slab"))
    if not has_refs:
        results["e_ads_status"] = ("NOT_APPLICABLE — Wave 1 은 기준계를 안 돌린다. "
                                  "자리 대비 ΔE 는 기준계 없이 성립하지만 절대 E_ads 는 "
                                  "만들 수 없다 (MANIFEST.claim_scope 참조).")
        results["warnings"].append(
            "Wave 1: clean/gas 기준계 없음 — **의도된 범위**다. ΔE 만 인용하고 "
            "흡착 열역학·조각 간 결합 세기·E_ads 절대값은 주장하지 말 것")
    for f in (man.get("fragments", []) if has_refs else []):
        # ⚠ job key 는 _pk() 로 POSIX 정규화돼 있다. 여기서 os.path.join 을 쓰면
        #   Windows 에서 `refs\mol__...` 가 되어 **한 건도 안 맞는다** — 그런데
        #   gas job 자체는 ok 라 required_missing 이 비고 exit 0 이 났다.
        #   "계산 완료, E_ads 만 없음" 으로 조용히 끝나는 최악의 모양이었다.
        e20 = E(f"refs/mol__{f}__box20")
        e24 = E(f"refs/mol__{f}__box24")
        ok = e20 is not None and e24 is not None and abs(e20 - e24) <= BOX_TOL
        mol_ok[f] = ok
        emol[f] = e24 if ok else None          # 실패하면 E_ads 를 만들지 않는다
        if e20 is not None and e24 is not None:
            d = abs(e20 - e24)
            results["numerical_gates"][f"box_{f}"] = {
                "dE_meV": round(d * 1000, 1), "pass": d <= BOX_TOL}
            if not ok:
                results["warnings"].append(
                    f"mol__{f}: 상자 20↔24 Å 차 {d * 1000:.1f} meV > 10 — "
                    f"이 조각의 E_ads 를 만들지 않는다")
        else:
            results["numerical_gates"][f"box_{f}"] = {"dE_meV": None, "pass": False}
            results["warnings"].append(f"mol__{f}: 상자 2종 중 하나가 없다 — E_ads 불가")

    eclean = {s: E(f"refs/clean_slab__{s}")
              for s in man.get("seeds_full", ["afm2424_pm1", "afm2424_net4"])}
    eclean_dense = E_dense("refs/clean_slab__afm2424_pm1")

    for pid, pm in man.get("pairs", {}).items():
        frag = pm["fragment"]
        rec = {"fragment": frag, "dir": pm["dir"], "roll": pm["roll"],
               "uma_dE": pm.get("uma_dE"), "dE_by_seed": {}, "gates": []}
        for s in pm.get("seeds", ["afm2424_pm1"]):
            eli, eni = E(f"{pm['li_prefix']}__{s}"), E(f"{pm['ni_prefix']}__{s}")
            if eli is not None and eni is not None:
                rec["dE_by_seed"][s] = round(eni - eli, 4)
        # ── PAIR_COLLAPSED — 주기 RMSD + 접촉 지문 (Codex P0 Q5 반박 수용) ──
        s0 = pm.get("seeds", ["afm2424_pm1"])[0]
        jli, jni = jobs.get(f"{pm['li_prefix']}__{s0}"), jobs.get(f"{pm['ni_prefix']}__{s0}")
        rli = (jli or {}).get("geom", {}).get("registry")
        rni = (jni or {}).get("geom", {}).get("registry")
        if jli and jni and jli.get("_fin") and jni.get("_fin"):
            mol = jli["meta"].get("mol_poscar_idx") or []
            a, b = jli["_fin"], jni["_fin"]
            if mol and len(a["pos"]) == len(b["pos"]):
                rms = math.sqrt(sum(mic_dist(a["pos"][i], b["pos"][i], a["cell"]) ** 2
                                    for i in mol) / len(mol))
                # ⚠ 최근접 **원소명**은 판정에 넣지 않는다 — 같으면 한쪽은 이미
                #   PAIR_MIGRATED 라 완전 중복이다(Codex Q5). 접촉 지문은 원자 인덱스라
                #   "같은 자리인가" 를 직접 답한다. 경계 원자 하나로 뒤집히지 않도록
                #   완전일치 대신 Jaccard 를 쓴다.
                fa = set(jli.get("_contact_fp") or [])
                fb = set(jni.get("_contact_fp") or [])
                if not fa and not fb:
                    # ⚠ 양쪽 다 접촉이 없으면 지문은 **정보가 없다**. CONTACT_A 3.0 과
                    #   DETACH_A 4.0 사이에 미판정 shell 이 있으므로 "떠 있지 않다" 가
                    #   "지문이 검증됐다" 를 뜻하지 않는다 (Codex Q3). RMSD 는 진단으로만
                    #   남기고 이 쌍은 최종 분류에서 뺀다.
                    jac, fp_ok, why = None, False, "접촉 지문 없음 — 미검증"
                    rec["gates"].append(
                        f"BASIN_UNVERIFIED_EMPTY_CONTACT_FP(분자 RMSD {rms:.2f} Å 는 "
                        f"진단값 — 3.0~4.0 Å 미판정 shell)")
                else:
                    jac = len(fa & fb) / len(fa | fb)
                    fp_ok = jac >= FP_JACCARD
                    why = f"접촉 지문 Jaccard {jac:.2f} ≥ {FP_JACCARD}"
                rec["basin"] = {"mol_rmsd_A": round(rms, 3),
                                "contact_jaccard": None if jac is None else round(jac, 3),
                                "same_nearest_element": bool(
                                    rli and rni and rli["nearest"] == rni["nearest"]),
                                "sensitivity": {str(t): rms <= t
                                                for t in (0.50, 0.75, 1.00)}}
                if rms <= RMSD_TOL and fp_ok:
                    sp_pair = bool((jli.get("geom") or {}).get("single_point"))
                    rec["gates"].append(
                        ("SOURCE_PAIR_COLLAPSED" if sp_pair else "PAIR_COLLAPSED")
                        + f"(분자 RMSD {rms:.2f} Å ≤ {RMSD_TOL} · {why})")
        # ★★ 추정량 이름 (Codex 7차 §1) — 자세키 p=(down_dir, roll) 에 대해
        #   ΔE_match(p) = E_Ni(p) − E_Li(p)          ← 배향 혼입 없는 자리 대비
        #   D_pool      = E_Ni(p_N*) − E_Li(p_L*)    ← 짝 풀 챔피언 **대각선** 대비
        #   p_L* == p_N* 이면 둘이 같지만, 다르면 D_pool 에 자리와 자세가 섞인다.
        #   그러므로 de_main 을 무조건 "matched" 라 부르면 안 된다.
        de_main = rec["dE_by_seed"].get("afm2424_pm1")
        _pose_matched = pm.get("matched") is True
        rec["estimand"] = ("dE_match(p*)  — 같은 자세키에서 잰 자리 대비 (배향 혼입 없음)"
                           if _pose_matched else
                           "D_pool  — 짝 풀 챔피언 **대각선** 대비 (자리+자세 혼합). "
                           "matched 라 부르지 말 것")
        rec["pose_matched"] = _pose_matched
        de_alt = rec["dE_by_seed"].get("afm2424_net4")
        # ★ ΔE 만 비교하면, 두 pose 가 같은 방향으로 함께 움직이고 clean 은 안 움직인
        #   경우 ΔE 는 그대로인데 E_ads 만 달라진다 (Codex P0-2).
        ea_seed = {}
        for sd in pm.get("seeds", []):
            ec_s, em_s = eclean.get(sd), emol.get(frag)
            eli_s = E(f"{pm['li_prefix']}__{sd}")
            if ec_s is not None and em_s is not None and eli_s is not None:
                ea_seed[sd] = eli_s - ec_s - em_s
        if len(ea_seed) > 1:
            spread = max(ea_seed.values()) - min(ea_seed.values())
            rec["eads_seed_spread_meV"] = round(spread * 1000, 1)
            if spread > SEED_TOL:
                rec["gates"].append(
                    f"BLOCKED_MAGNETIC_SENSITIVITY(E_ads seed 산포 {spread * 1000:.0f} meV > 10)")
        # ★ 두 seed 끝점 에너지가 20 meV 안에서 경합하면 **어느 branch 가 바닥인지
        #   k 보정(±10)으로 뒤집힐 수 있다**. adaptive dense 가 꺼져 있으면 확인할
        #   방법이 없으므로 그 사실을 판정에 남긴다 (Codex 3차 감사).
        #   MANIFEST 는 이 규약을 적어 놓고 정작 --plan_dense 에서만 계산하고 있었다.
        for _role, _pre in (("Li", pm["li_prefix"]), ("Ni", pm["ni_prefix"])):
            _e = {s: E(f"{_pre}__{s}") for s in pm.get("seeds", [])}
            _v = [x for x in _e.values() if x is not None]
            if len(_v) > 1 and abs(_v[0] - _v[1]) <= BRANCH_TIE_EV:
                rec.setdefault("branch_tie", {})[_role] = {
                    "gap_meV": round(abs(_v[0] - _v[1]) * 1000, 1),
                    "note": (f"두 seed 가 {BRANCH_TIE_EV*1000:.0f} meV 안에서 경합 — "
                             f"k 보정 ±{GUARD_EV*1000:.0f} 으로 순서가 뒤집힐 수 있다")}
                # ⚠ **게이트로 막지 않는다.** 우리 headline 은 branch-minimum 이 아니라
                #   같은 seed(pm1) 대비다 — 어느 branch 가 바닥인지 주장하지 않으므로
                #   경합 자체는 결함이 아니다. 실제 보호막은 seed 산포 게이트(≤10 meV)다.
                #   (Codex 3차 감사가 준 두 선택지 중 'pm1 조건부로 명시' 쪽.)
                rec["branch_tie"][_role]["claim"] = (
                    "MAGNETIC_K_UNRESOLVED_for_branch_minimum — 이 값은 "
                    "**pm1 branch 조건부**다. '자기 바닥상태에서의' 로 서술 금지")
        if de_main is not None and de_alt is not None \
                and abs(de_main - de_alt) > SEED_TOL:
            rec["gates"].append(
                f"BLOCKED_MAGNETIC_SENSITIVITY(|ΔE_pm1−ΔE_net4|="
                f"{abs(de_main - de_alt) * 1000:.0f} meV > 10)")
        elif de_main is not None and de_alt is None and len(pm.get("seeds", [])) > 1:
            rec["gates"].append("SEED_INCOMPLETE(두 seed 중 하나가 게이트/미완)")

        # ── dense-k 게이트 — **판정에 실제로 연결** (Codex P0-D) ──
        dli, dni = E_dense(f"{pm['li_prefix']}__afm2424_pm1"), \
            E_dense(f"{pm['ni_prefix']}__afm2424_pm1")
        planned_dense = any("dense" in (planned.get(f"{pm[k]}__afm2424_pm1") or {})
                            .get("phases", []) for k in ("li_prefix", "ni_prefix"))
        if planned_dense:
            if dli is None or dni is None or de_main is None:
                rec["gates"].append("NUMERICALLY_UNRESOLVED(dense 계획인데 회수 실패)")
            else:
                # ★ κ 는 **부호 있는** 양이다 (Codex 5차 taxonomy · 6차 §6).
                #   전이 게이트는 크기뿐 아니라 **보정자끼리 같은 방향인지**를 본다 —
                #   절대값만 보면 +9 와 −9 를 "둘 다 통과" 로 읽어 18 meV 를 놓친다.
                kap = (dni - dli) - de_main
                rec["kappa_eV"] = round(kap, 4)
                results.setdefault("kappa", {})
                prev = results["kappa"].get(frag)
                if prev is None or abs(kap) > abs(prev):
                    results["kappa"][frag] = round(kap, 4)   # 조각당 최악값
                dk = abs(kap)
                ok_k = dk <= K_TOL
                gate = {"dE_meV": round(dk * 1000, 1), "kappa_meV": round(kap * 1000, 1),
                        "pass": ok_k}
                # E_ads 자체의 k 수렴도 본다 (ΔE 만 보면 상쇄로 숨는다)
                if eclean_dense is not None and emol.get(frag) is not None:
                    worst = 0.0
                    for tag, pre, ed in (("Li", pm["li_prefix"], dli),
                                         ("Ni", pm["ni_prefix"], dni)):
                        es = E(f"{pre}__afm2424_pm1")
                        if es is None:
                            continue
                        d = abs((ed - eclean_dense - emol[frag])
                                - (es - eclean.get("afm2424_pm1", 0.0) - emol[frag]))
                        gate[f"dEads_{tag}_meV"] = round(d * 1000, 1)
                        worst = max(worst, d)
                    gate["dEads_meV"] = round(worst * 1000, 1)
                    ok_k = ok_k and worst <= K_TOL
                    gate["pass"] = ok_k
                results["numerical_gates"][f"k_{pid}"] = gate
                if not ok_k:
                    rec["gates"].append(f"NUMERICALLY_UNRESOLVED(dense-k {gate})")

        # ── 전역 자리 선호 vs 배향일치 대비 (2026-08-12) ────────────────────
        #   ΔE(matched) = 같은 배향에서 Li 위 vs Ni 위  — 배향 혼입 없음
        #   ΔE(global)  = 각자 최선을 다했을 때        — 문헌의 "site preference"
        #   둘의 차가 **배향 항**이다. 부호가 다르면 어느 질문인지 반드시 밝혀야 한다.
        gb = pm.get("global_best") or {}
        if gb:
            # ★ 두 seed 전부 읽는다 (Codex 7차 §5). 본 ΔE 는 seed 산포 게이트를 통과해야
            #   하는데 global 만 단일시드면 부호가 자기 branch 잡음일 수 있다.
            dg_seed = {}
            for sd in pm.get("seeds", ["afm2424_pm1"]):
                e2 = {}
                for role, pre in (("Li", pm["li_prefix"]), ("Ni", pm["ni_prefix"])):
                    p2 = gb[role]["prefix"] if role in gb else pre
                    e2[role] = E(f"{p2}__{sd}")
                if e2["Li"] is not None and e2["Ni"] is not None:
                    dg_seed[sd] = round(e2["Ni"] - e2["Li"], 4)
            rec["dE_global_by_seed"] = dg_seed
            n_want = len(pm.get("seeds", []))
            if len(dg_seed) < n_want:
                rec["gates"].append(
                    f"GLOBAL_SEED_INCOMPLETE({len(dg_seed)}/{n_want}) — 전역 대비 보류")
            elif len(dg_seed) > 1:
                sp = max(dg_seed.values()) - min(dg_seed.values())
                rec["global_seed_spread_meV"] = round(sp * 1000, 1)
                if sp > SEED_TOL:
                    rec["gates"].append(
                        f"GLOBAL_MAGNETIC_SENSITIVITY(seed 산포 {sp*1000:.0f} meV > 10)")
            eg = {}
            for role, pre in (("Li", pm["li_prefix"]), ("Ni", pm["ni_prefix"])):
                p2 = gb[role]["prefix"] if role in gb else pre
                eg[role] = E(f"{p2}__afm2424_pm1")
            if eg["Li"] is not None and eg["Ni"] is not None:
                dg = eg["Ni"] - eg["Li"]
                # ★ 이름을 정확히 (Codex 7차 §1.4) — 이건 **UMA 가 고른** 전역 챔피언
                #   대비다. DFT 재랭킹도, DFT 이완 최소점도, 흡착 자유에너지도 아니다.
                rec["dE_UMA_selected_global_champ_eV"] = round(dg, 4)
                rec["global_k_status"] = (
                    "K_DIRECTLY_CHECKED_GLOBAL" if E_dense(
                        f"{(gb.get('Ni') or {}).get('prefix', pm['ni_prefix'])}"
                        f"__afm2424_pm1") is not None
                    else "K_UNVERIFIED_GLOBAL — 전역 끝점은 coarse only")
                rec["dE_global_eV"] = round(dg, 4)      # 하위호환(폐기 예정)
                if de_main is not None:
                    rec["orientation_term_eV"] = round(dg - de_main, 4)
                    flip = (dg > 0) != (de_main > 0)
                    _gk = rec.get("global_k_status", "")
                    rec["global_vs_matched"] = (
                        f"K_UNRESOLVED_GLOBAL({_gk}) — 전역 끝점을 dense 로 검증하지 "
                        f"않았다. 부호 비교는 진단용이고 headline 아님"
                        if _gk.startswith("K_UNVERIFIED") else
                        "SIGN_DIFFERS — 배향일치 대비와 전역 자리 선호가 **반대**다. "
                        "어느 질문인지 밝히지 않고 인용 금지."
                        if flip and min(abs(dg), abs(de_main)) > GUARD_EV else
                        "SIGN_AGREES" if not flip else
                        "UNRESOLVED(한쪽이 guard band 안)")
                    if flip and min(abs(dg), abs(de_main)) > GUARD_EV \
                            and not rec.get("global_k_status", "").startswith("K_UNVERIFIED"):
                        # ⚠ 이건 계산 실패가 아니다 — 각 추정량은 유효하다.
                        #   금지되는 건 **하나의 site preference 숫자로 합치는 것**뿐이다.
                        #   그래서 gates(=값 무효화)가 아니라 해석 라벨로 남긴다.
                        rec["ESTIMAND_DEPENDENT_NO_SINGLE_SITE_PREFERENCE"] = (
                            f"D_pool {de_main:+.3f} vs UMA-selected global {dg:+.3f} eV — "
                            f"부호가 다르다. 두 값 **각각은 유효**하다. 하나의 '자리 선호' "
                            f"숫자로 합치지 말고 추정량을 밝혀 따로 보고할 것.")
            else:
                rec["dE_global_eV"] = None
                rec["global_vs_matched"] = "전역 끝점 미완/게이트 — 전역 대비 불가"
        elif pm.get("global_unmeasured"):
            rec["global_unmeasured"] = pm["global_unmeasured"]

        # ── 교차 끝점: 배향이 맞춰진 대비 (Codex 5차 결정 ②) ──────────────
        #   챔피언 ΔE 는 두 배향이 다르면 자리 효과와 배향 효과가 섞인다.
        #   같은 배향에서 잰 Δ 와 **부호가 같은지**가 배향 인공물 여부를 가른다.
        for tag, cx in (pm.get("cross") or {}).items():
            base_role = cx["role"]                      # 추가된 쪽
            other = "Li" if base_role == "Ni" else "Ni"
            opre = pm[("li" if other == "Li" else "ni") + "_prefix"]
            # ★ 두 seed 로 잰다 (Codex 6차 §5) — 옛 판은 pm1 하나만 읽었다.
            #   본 ΔE 는 seed 산포 게이트를 통과해야 하는데 교차만 단일시드면,
            #   "배향 의존" 판정이 실은 자기 branch 잡음일 수 있다.
            dm_by_seed = {}
            for sd in pm.get("seeds", ["afm2424_pm1"]):
                e_new, e_old = E(f"{cx['prefix']}__{sd}"), E(f"{opre}__{sd}")
                if e_new is not None and e_old is not None:
                    dm_by_seed[sd] = round(
                        (e_new - e_old) if base_role == "Ni" else (e_old - e_new), 4)
            if not dm_by_seed:
                rec.setdefault("cross", {})[tag] = {"status": "미완/게이트"}
                continue
            d_m = dm_by_seed.get("afm2424_pm1", list(dm_by_seed.values())[0])
            entry = {"orientation": cx["down_dir"], "roll": cx.get("roll_deg"),
                     "dE_matched_eV": d_m, "dE_by_seed": dm_by_seed,
                     # 교차 끝점은 dense 를 안 돌린다 — k 는 전이 해석뿐이다
                     "k_label": "K_UNVERIFIED_CROSS", "prefix": cx["prefix"]}
            rec.setdefault("cross", {})[tag] = entry
            n_seed_want = len(pm.get("seeds", []))
            if len(dm_by_seed) < n_seed_want:
                entry["verdict"] = (f"SEED_INCOMPLETE({len(dm_by_seed)}/{n_seed_want}) "
                                    f"— 배향 판정 보류")
                rec["gates"].append(
                    f"CROSS_SEED_INCOMPLETE({tag}: {len(dm_by_seed)}/{n_seed_want} seed)")
                continue
            spread = max(dm_by_seed.values()) - min(dm_by_seed.values())
            entry["seed_spread_meV"] = round(spread * 1000, 1)
            if spread > SEED_TOL:
                entry["verdict"] = (f"BLOCKED_MAGNETIC_SENSITIVITY(seed 산포 "
                                    f"{spread * 1000:.0f} meV > 10) — 배향 판정 불가")
                rec["gates"].append(
                    f"CROSS_MAGNETIC_SENSITIVITY({tag}: {spread * 1000:.0f} meV)")
                continue
            entry["quantity"] = f"dE_match({cx['down_dir']}/r{cx.get('roll_deg')})"
            entry["k_note"] = "coarse only — dense 없음"
        # ── 2×2: **두 고정자세 대비끼리** 비교한다 (Codex 7차 §1.3) ────────────
        #   ΔE_match(p_L*) = E_Ni(p_L*) − E_Li(p_L*)
        #   ΔE_match(p_N*) = E_Ni(p_N*) − E_Li(p_N*)
        #   I = ΔE_match(p_N*) − ΔE_match(p_L*) = O_N − O_L
        #   ⚠ 옛 판은 각 교차를 **대각선** de_main 과 비교했다. 그러면 I 가 안 나온다.
        #   ⚠ I 는 모집단 상호작용이 아니라 **이 두 자세에서의 유한설계 대비**다.
        cr = rec.get("cross") or {}
        mc = pm.get("cross") or {}          # ★ prefix 의 권위는 MANIFEST 쪽이다
        if not _pose_matched and len(mc) == 2:
            eL = {}
            for sd in pm.get("seeds", ["afm2424_pm1"]):
                # p_L* 자세: Li 는 본 끝점, Ni 는 교차(Ni_at_Li_pose)
                a1 = E(f"{pm['li_prefix']}__{sd}")
                b1 = E(f"{mc['Ni_at_Li_pose']['prefix']}__{sd}") \
                    if "Ni_at_Li_pose" in mc else None
                # p_N* 자세: Ni 는 본 끝점, Li 는 교차(Li_at_Ni_pose)
                a2 = E(f"{mc['Li_at_Ni_pose']['prefix']}__{sd}") \
                    if "Li_at_Ni_pose" in mc else None
                b2 = E(f"{pm['ni_prefix']}__{sd}")
                if None not in (a1, b1, a2, b2):
                    eL[sd] = {"dE_match_pL": round(b1 - a1, 4),
                              "dE_match_pN": round(b2 - a2, 4),
                              "I": round((b2 - a2) - (b1 - a1), 4),
                              "O_Li": round(a2 - a1, 4), "O_Ni": round(b2 - b1, 4)}
            if eL:
                rec["two_by_two"] = eL
                m = eL.get("afm2424_pm1") or list(eL.values())[0]
                dl, dn = m["dE_match_pL"], m["dE_match_pN"]
                both_big = min(abs(dl), abs(dn)) > GUARD_EV
                same = (dl > 0) == (dn > 0)
                rec["two_by_two_k_status"] = ("K_UNVERIFIED_CROSS — 교차 끝점은 "
                                              "dense 를 안 돌렸다. 아래 부호 결론은 "
                                              "coarse 값 기준이다")
                # ⚠ k 라벨은 이 루프가 끝나야 정해진다(κ 를 여기서 모은다). 잠정 판정만
                #   쓰고, 아래 후처리에서 K 게이트를 씌운다.
                rec["two_by_two_verdict"] = (
                    "UNRESOLVED(한쪽이 guard band 안 — 부호 비교 불가)" if not both_big else
                    "SIGN_AGREES_AT_BOTH_SAMPLED_POSES — **두 표본 자세에서** 부호 일치 "
                    "(모집단 배향 무관성 주장 아님)" if same else
                    "POSE_DEPENDENT_SIGN — 자세에 따라 부호가 다르다. 자세 무관 자리 선호 금지")
                if both_big and not same:
                    rec["gates"].append(
                        f"POSE_DEPENDENT_SIGN(ΔE_match(p_L*)={dl:+.3f} vs "
                        f"ΔE_match(p_N*)={dn:+.3f} eV)")
                if len(eL) > 1:
                    sp = max(x["I"] for x in eL.values()) - min(x["I"] for x in eL.values())
                    rec["two_by_two"]["I_seed_spread_meV"] = round(sp * 1000, 1)
                    if sp > SEED_TOL:
                        rec["gates"].append(
                            f"TWO_BY_TWO_MAGNETIC_SENSITIVITY(I seed 산포 {sp*1000:.0f} meV)")
        if pm.get("cross_missing"):
            rec["cross_missing"] = pm["cross_missing"]

        if de_main is not None and not rec["gates"]:
            # ★★ 직접 dense 를 돌렸으면 **그 값이 headline** 이다 (Codex zip 감사 P0-3).
            #   옛 판은 dense 로 κ 만 재고 최종 수치·판정은 coarse 를 썼다. 그러면서
            #   K_DIRECTLY_CHECKED 라는 이유로 20–40 meV guard 까지 풀어, dense 값이
            #   30 meV 바닥 반대편에 있어도 coarse 로 판정할 수 있었다.
            _dli = E_dense(f"{pm['li_prefix']}__afm2424_pm1")
            _dni = E_dense(f"{pm['ni_prefix']}__afm2424_pm1")
            if _dli is not None and _dni is not None:
                rec["dE_coarse_eV"] = de_main
                de_main = round(_dni - _dli, 4)
                rec["headline_from"] = "dense (직접 k 검증) — coarse 는 dE_coarse_eV 에"
                # ⚠ 0 은 "3×4×1 의 잔여 k 오차가 없다" 가 아니라 **전이 허용치를 안 썼다**
                #   는 뜻이다 (Codex 재감사). 이름을 그렇게 바꾼다.
                rec["k_transfer_allowance_meV"] = 0.0
                rec["k_residual_note"] = "직접 dense — 전이 허용치 미적용. 잔여 k 오차는 미추정"
            else:
                rec["headline_from"] = "coarse (dense 없음/게이트) — k 불확실성 ±10 meV"
                rec["k_transfer_allowance_meV"] = GUARD_EV * 1000
            rec["dE_Ni_minus_Li_eV"] = de_main
            # ±10 meV k guard band — 30 meV 판정바닥과 **합치지 않는다**
            a_de = abs(de_main)
            rec["k_guard"] = ("판정 유지 (>40 meV)" if a_de > delta + GUARD_EV else
                              "바닥 아래 결론 유지 (<20 meV)" if a_de < delta - GUARD_EV else
                              "⚠ 20–40 meV — k 오차로 판정이 뒤집힐 수 있다: "
                              "직접 dense 아니면 UNRESOLVED")
            if abs(de_main) <= GUARD_EV:
                rec["k_guard"] = "⛔ |ΔE| ≤ 10 meV — 부호 자체가 안 정해진다"
            ec = eclean.get("afm2424_pm1")
            if ec is not None and emol.get(frag) is not None:
                eli = E(f"{pm['li_prefix']}__afm2424_pm1")
                eni = E(f"{pm['ni_prefix']}__afm2424_pm1")
                results["e_ads"][pid] = {
                    "Li_top": round(eli - ec - emol[frag], 4),
                    "Ni_top": round(eni - ec - emol[frag], 4),
                    "mol_ref": "box24",
                    # ⚠ headline 은 **static(coarse) 값**이다. dense 는 별도 k 게이트로만
                    #   쓰고 값을 교체하지 않는다 (Codex 3차 감사 P0-4). 명시하지 않으면
                    #   "dense 로 검증된 E_ads" 로 오독된다.
                    "estimand": "E_ads(static target mesh) — dense 는 k 게이트 전용",
                    "k_check": "관측된 dense 보정이 게이트 안이면 통과. 값 교체 아님"}
        results["pairs"][pid] = rec

    # ══ 사전등록 closure estimand (회신 V P0-3 · P0-4) ══════════════════════
    #   `prereg_sdcp_neutral_contrast_2026_08_29.json` 을 코드로 옮긴 것.
    #   ⛔ 종전엔 사전등록이 **문서로만** 있었다 — 잡이 다 끝나도 판정이 재현되지 않았다.
    _pc = _closure_estimand(man, results, E, emol, jobs)
    if _pc:
        results["prereg_closure"] = _pc

    # ── k 전이 게이트 (Codex 5차 taxonomy · 6차 §6) ───────────────────────────
    #   MANIFEST 에 k_label_rule 을 적어 놓고 **계산은 안 하던** 구멍을 막는다.
    #   n=2 이므로 평균·표준편차·CI 를 쓰지 않는다 — deterministic max/range 다.
    cal = list(man.get("dense_calibrators") or [])
    kap_all = results.get("kappa", {})
    k_transfer, k_labels, have = k_transfer_gate(
        cal, kap_all, man.get("fragments", []))
    results["k_transfer"] = k_transfer
    results["k_labels"] = k_labels
    # ── K 미검증 quantity 의 **부호 결론을 막는다** (Codex 재감사 P0-3) ─────────
    #   교차 끝점과 전역 끝점은 dense 를 안 돌린다. 조각의 k 라벨이 UNVERIFIED 면
    #   coarse 값으로 부호를 말할 근거가 없다.
    for _pid, _r in results["pairs"].items():
        _lb = k_labels.get(_r.get("fragment"), "K_UNVERIFIED")
        if _r.get("two_by_two_verdict") and _lb == "K_UNVERIFIED":
            _r["two_by_two_verdict"] = (
                f"K_UNRESOLVED_2x2(교차는 coarse only · 조각 라벨 {_lb} — 부호 결론 "
                f"보류. I 의 전이 오차폭은 두 대비의 차라 최악 "
                f"±{2 * GUARD_EV * 1000:.0f} meV)")
            _r["gates"] = [g for g in _r.get("gates", [])
                           if not g.startswith("POSE_DEPENDENT_SIGN")]
        for _t2, _c in (_r.get("cross") or {}).items():
            _c["k_note"] = (f"coarse only · 조각 라벨 {_lb}"
                            + (" — 부호 결론 보류" if _lb == "K_UNVERIFIED" else
                               f" · 전이 허용 ±{GUARD_EV * 1000:.0f} meV"))

    for frag in man.get("fragments", []):
        dl = [r["dE_Ni_minus_Li_eV"] for r in results["pairs"].values()
              if r["fragment"] == frag and "dE_Ni_minus_Li_eV" in r]
        n_planned = sum(1 for p in man["pairs"].values() if p["fragment"] == frag)
        expect_dirs = (man.get("contract_expected_pairs") or {}).get(frag)
        # ★ 번들 **이전**에 잃은 방향까지 본다. n/n_planned 만 보면 계획 자체가 이미
        #   줄어든 경우를 영원히 못 잡는다 (계획 3/3 = 100% 인데 원래 방향은 5개).
        #   자리 스윕 방향(Li_top/Ni_top 이 애초에 없음)은 정의 밖이라 세지 않고,
        #   Li_top/Ni_top 이 **있는데 부적격**인 방향만 손실로 센다.
        aud = (man.get("pair_audit") or {}).get(frag) or {}
        ex = aud.get("excluded_dirs") or {}
        lost = {d: sorted(c) for d, c in ex.items()
                if any(s.startswith(("Li_top", "Ni_top")) and "부적격" in s for s in c)}
        nd = aud.get("n_down_dirs")
        cov = (n_planned / nd) if nd else None
        if not dl:
            results["fragments"][frag] = {"n": 0, "n_planned": n_planned,
                                          "class": "NO_DATA"}
            continue
        n = len(dl)
        med = sorted(dl)[n // 2] if n % 2 else 0.5 * (sorted(dl)[n // 2 - 1]
                                                      + sorted(dl)[n // 2])
        side = 1 if med > 0 else -1
        fs = sum(1 for x in dl if x * side > 0) / n
        fe = sum(1 for x in dl if x * side > delta) / n
        # ★ 번들 이전에 방향을 잃었으면 **무조건 검열 등급**이다. n=3·계획=3 이라
        #   coverage 100% 로 보여 ROBUST 까지 올라가던 경로를 막는다 (Codex P0-6).
        champ = [p for p in man["pairs"].values()
                 if p["fragment"] == frag and p.get("champion_pose")]
        if champ:
            # 챔피언 비교는 "Li 위 최선 vs Ni 위 최선" 이다 — 방향 통계가 아니라
            # **설계상 1쌍**이므로 n<3 로 거부하지 않는다. 대신 무엇을 비교했는지 적는다.
            # ★ 판정 기준은 방향이 아니라 **자세키**(down_dir, roll) 다 (Codex 6차 P0-4).
            cp = champ[0].get("champion_pose") or {}
            same = champ[0].get("matched") is True
            ncross = len(champ[0].get("cross") or {})
            # ⚠ 옛 판은 교차 **결과 두 개**만 있으면 "2×2 완료" 라 했다. 그런데 2×2 계산
            #   자체(two_by_two)가 실패해도 그 조건은 참이라 **가짜 완료 라벨**이 붙었다.
            #   실제로 prefix 버그로 two_by_two 가 한 번도 안 만들어지고 있었다.
            _pr = results["pairs"].get(
                f"{frag}__{champ[0]['dir']}_r{champ[0]['roll']:03d}", {})
            got = 2 if (_pr.get("two_by_two") or {}).get("afm2424_pm1") else \
                sum(1 for _t, c in (_pr.get("cross") or {}).items()
                    if "dE_matched_eV" in c) and 0
            cls = ("CHAMPION_MATCHED_POSE" if same else
                   "CHAMPION_MIXED_ORIENTATION_2x2" if ncross == 2 and got == 2 else
                   # 교차 0 = 대각선 두 모서리뿐. 자리와 배향을 **분리할 수 없다**.
                   "CHAMPION_ORIENTATION_CONFOUNDED(교차 없음 — 자리·배향 분리 불가)"
                   if ncross == 0 else
                   "THREE_CORNER_PARTIAL(교차 %d/%d 완료 — 배향 미해결)" % (got, ncross))
        elif lost:
            cls = "DIRECTION_CENSORED_%d_OF_%d" % (n_planned, nd or n_planned)
        elif expect_dirs and n_planned != expect_dirs:
            cls = "CONTRACT_SHORT(계약 %d · 계획 %d)" % (expect_dirs, n_planned)
        elif n < 3:
            cls = "NO_VERDICT_n<3"
        elif n < 0.8 * n_planned:
            cls = "CENSORED(계획 %d 중 %d — coverage<80%%)" % (n_planned, n)
        elif fs >= 0.8 and fe >= 0.8:
            cls = "ROBUST_SCREENING"
        elif fs >= 0.8 and abs(med) > delta:
            cls = "MARGINAL_TENDENCY"
        elif fs >= 0.8:
            cls = "SIGN_CONSISTENT_SMALL"
        else:
            cls = "UNRESOLVED_MIXED"
        lbl = k_labels.get(frag, "K_UNVERIFIED")
        cls = apply_k_guard(cls, med, lbl, delta)
        results["fragments"][frag] = {
            "k_label": lbl,
            "kappa_meV": (round(kap_all[frag] * 1000, 1) if frag in kap_all else None),
            "n_directions": n, "n_planned": n_planned, "dE_list": dl,
            "median_eV": round(med, 4), "class": cls,
            "n_down_dirs": nd, "direction_coverage": None if cov is None else round(cov, 2),
            "disqualified_dirs": lost,
            "read_as": ("Li 위 최선이 더 안정" if med > 0 else "Ni 위 최선이 더 안정")
            if champ else ("Li 우세 경향" if med > 0 else "Ni 우세 경향"),
            "champion_dirs": (champ[0].get("champion_dirs") if champ else None),
            "champion_pose": (champ[0].get("champion_pose") if champ else None),
            "exact_matched_pose": (champ[0].get("matched") if champ else None),
            "note": ("PBE+U(6.2)+D3-zero fixed-protocol tendency — UMA 값과 같은 표 금지. "
                     "δ=%.3f eV." % delta)}
        if lost:
            wr = aud.get("excluded_reasons") or {}
            why = "; ".join(f"{d}: {', '.join(sorted(wr.get(d, {})))}" for d in sorted(lost))
            results["fragments"][frag]["disqualified_reasons"] = \
                {d: wr.get(d, {}) for d in lost}
            results["warnings"].append(
                f"{frag}: down_dir {nd}개 중 {len(lost)}개가 **번들 이전에** 탈락했다 "
                f"— 계획 {n_planned}개는 이미 줄어든 수다. 사유: {why}. "
                f"원고에는 '{nd}방향 중 {n_planned}방향 판정'과 그 사유를 함께 쓸 것 "
                f"(CAP_ARTIFACT 는 조각 모델의 한계지 데이터 부족이 아니다)")

    # ── 필수 완결성 — static + **계획된 dense** 까지 (Codex P0-D) ────────────
    missing = []
    for j, pl in planned.items():
        if not pl.get("required"):
            continue
        if E(j) is None:
            missing.append(j + " [static]")
        elif "dense" in (pl.get("phases") or []) and E_dense(j) is None:
            missing.append(j + " [dense]")
    out = os.path.join(root, "RESULTS.json")
    results["required_missing"] = missing
    for r in jobs.values():
        r.pop("_fin", None); r.pop("_contact_fp", None)
    json.dump(results, open(out, "w"), indent=1, ensure_ascii=False)

    bad = {j: r for j, r in jobs.items() if not r["ok"]}
    print(f"=== 무결성 ===  검사 {integrity['checked']}개 · 변경 "
          f"{len(integrity['changed'])} · 없음 {len(integrity['missing'])}")
    print(f"=== 잡 게이트 ===  통과 {len(jobs) - len(bad)}/{len(jobs)}"
          + (f" · 문제 {len(bad)}건:" if bad else ""))
    for j, r in sorted(bad.items()):
        print(f"  ⛔ {j}: {', '.join(r['gates'])}")
    print("\n=== 자리 선호 (ΔE = E(Ni_top) − E(Li_top), 양수 = Li 우세 · seed-매칭) ===")
    for pid, r in sorted(results["pairs"].items()):
        de = r.get("dE_Ni_minus_Li_eV")
        seeds = " ".join(f"{s.split('_')[-1]}:{v:+.3f}" for s, v in r["dE_by_seed"].items())
        print(f"  {pid:34s} " + (f"{de:+.3f} eV" if de is not None else "(게이트/미완)")
              + (f"  [{seeds}]" if seeds else "")
              + (f"  ⛔{';'.join(r['gates'])}" if r["gates"] else ""))
    print("\n=== 조각별 판정 ===")
    for f, r in results["fragments"].items():
        nd = r.get("n_down_dirs")
        print(f"  {f:14s} n={r.get('n_directions', 0)}/{r.get('n_planned', '?')}"
              + (f" (원래 방향 {nd})" if nd and nd != r.get("n_planned") else "")
              + "  중앙값 "
              + (f"{r['median_eV']:+.3f} eV" if "median_eV" in r else "—")
              + f"  → {r['class']}"
              + (f"  ⚠번들이전 탈락 {len(r['disqualified_dirs'])}방향"
                 if r.get("disqualified_dirs") else ""))
    if results["e_ads"]:
        print("\n=== E_ads (pm1 seed · box24 기준계 · 음수 = 흡착 유리) ===")
        for pid, e in sorted(results["e_ads"].items()):
            print(f"  {pid:34s} Li_top {e['Li_top']:+.3f} · Ni_top {e['Ni_top']:+.3f} eV")
    for k, v in results["numerical_gates"].items():
        print(f"  {'✓' if v['pass'] else '⛔'} 수치게이트 {k}: {v['dE_meV']} meV"
              + (f" · E_ads {v['dEads_meV']} meV" if "dEads_meV" in v else ""))
    for w in results["warnings"]:
        print(f"  ⚠ {w}")
    print(f"\n→ {out}")
    # ⚠ 기하를 **검증하지 못한 것**도 실패다 (Codex 재감사 P0-1). 옛 판은 경고만
    #   찍고 exit 0 이라, 실제 VASP 가 무엇을 읽었는지 모르는 채 완주로 보였다.
    if integrity["changed"] or integrity["missing"] or \
            integrity.get("runtime_poscar_mismatch") or \
            integrity.get("geometry_unverified"):
        print(f"\n⛔ **입력 무결성 실패** — 변경 {len(integrity['changed'])} · "
              f"사라짐 {len(integrity['missing'])} · 실행시 기하 불일치 "
              f"{len(integrity.get('runtime_poscar_mismatch') or [])} · 기하 미검증 "
              f"{len(integrity.get('geometry_unverified') or [])} — exit 2 "
              f"(삭제도 변조이고, **검증 못 한 것도 통과가 아니다**)")
        return 2
    # ⚠ 기준계를 선언해 놓고 E_ads 가 하나도 안 나오면 **조용한 실패**다.
    #   경로 키가 안 맞아도 gas job 자체는 ok 라 exit 0 이 났다 (Codex 4차 P0-2).
    if has_refs and not results["e_ads"]:
        print("\n⛔ **기준계를 선언했는데 E_ads 가 0개다** — refs 조회가 안 맞거나 "
              "상자 게이트가 전부 실패했다. exit 2")
        for k2, v2 in results["numerical_gates"].items():
            if k2.startswith("box_"):
                print(f"   {k2}: {v2}")
        return 2
    if missing:
        print(f"\n⛔ **필수 산출 미완 {len(missing)}건** (tier1/refs) — fail-closed, exit 2:")
        for j in missing[:20]:
            print(f"   · {j}")
        return 2
    return 0


if __name__ == "__main__":
    sys.exit(main())

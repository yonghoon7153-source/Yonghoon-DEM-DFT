#!/usr/bin/env python3
"""mkworld.py <W> <variant> — 시험용 가짜 ibb 홈을 만들고 기대값을 <W>/expect.json 에 적는다.

로그인 홈 = <W>/hroot/home/fakeuser (심볼릭 링크) → 실제 홈 = <W>/lroot/lustre/home/fakeuser (ibb 의 /home → /lustre/home 꼴).
variant: full (다 있음) · fail (E0_ref2 런 폴더 없음) · plain (full 과 같음 · 다른 시험용 이름)
덤프 · 체크포인트 · exact · 금고 파일에는 SECRET 문자열을 넣는다 — 블록이 그 내용을 열면 시험이 잡는다.
"""
import hashlib
import json
import os
import subprocess
import sys

W = os.path.abspath(sys.argv[1])
VARIANT = sys.argv[2]
USER = 'fakeuser'
HOMEL = os.path.join(W, 'hroot', 'home', USER)
HOMER = os.path.join(W, 'lroot', 'lustre', 'home', USER)
BASE = os.path.join(HOMER, 'mixer_dev7_20260930_v26')
RUNS = [('E0_ref_s32452843', '249080', 1037), ('E0_ref_s49979687', '249081', 11), ('E0_ref_s67867967', '249082', 5),
        ('E0_ref2_s32452843', '249083', 7), ('E0_ref_dthalf_s32452843', '249084', 3)]
ONE_RUN = 'E0_ref_s32452843'
SECRET_NUMS = ['42424242', '91827364', '86420135', '77777771', '31415926', '47979797']
SECRET_TXT = ['SECRET_DUMP_VALUE', 'SECRET_RESTART', 'SECRET_EXACT', 'SECRET_M_VALUE', 'SECRET_COMMENT_ECHO',
              'SECRET_WARN_TEXT', 'SECRET_LOG_PATHLINE', 'README_SECRET_NAME', 'SECRET_JOBSTART']


def sha(p):
    with open(p, 'rb') as f:
        return hashlib.sha256(f.read()).hexdigest()


def wfile(p, size, head, mtime=None):
    os.makedirs(os.path.dirname(p), exist_ok=True)
    body = head.encode()
    body = body + b'x' * max(0, size - len(body))
    with open(p, 'wb') as f:
        f.write(body[:size])
    if mtime is not None:
        os.utime(p, (mtime, mtime))
    return os.path.getsize(p)


def frame_size(step):
    return 200 + (step // 1000 * 37) % 251


def frame_mtime(step):
    return 1790755929 + (step // 1000) * 13


LOG = """LIGGGHTS (Version LIGGGHTS-PUBLIC 3.8.0, compiled 2026-03-26-14:37:06 by fakebuilder, git commit 3d5c00f20519e6bb6eb6756f51f1ad36564e649d)
# 주석 메아리 — ERROR: youngsModulus <= 1e9 SECRET_COMMENT_ECHO
variable rdir string {HOMEL}/mixer_dev7_20260930_v26/SECRET_LOG_PATHLINE
Setting up run at Wed Sep 30 08:12:20 2026

INFO: Particle insertion ins: inserting every 0 steps
Memory usage per processor = 5.3174 Mbytes
    Step    Atoms         KinEng            rke         Volume
       0        0              0              0  2.7589053e-05
INFO: Particle insertion ins: inserted 42424242 particle templates (mass 9.557437e-01) at step 1
 - a total of 42424242 particle templates (mass 9.557437e-01) inserted so far.
       1 42424242     0.11946796      90.758093  2.7589053e-05
Loop time of 90.7581 on 20 procs for 1 steps with 42424242 atoms, finish time Wed Sep 30 08:13:51 2026

Setting up run at Wed Sep 30 08:13:52 2026
    Step    Atoms         KinEng            rke         Volume
       1 42424242  86420135.5  1.0960987e-10  2.7589053e-05
    5000 42424242  7.7777771e-11  1.0960987e-10  2.7589053e-05

  518715 42424242  3.1415926e-11  1.0960987e-10  2.7589053e-05
Loop time of 6000.1 on 20 procs for 518714 steps with 42424242 atoms, finish time Wed Sep 30 09:53:52 2026

    Step    Atoms         KinEng            rke         Volume
  518715 42424242            nan  1.0960987e-10  2.7589053e-05
WARNING_42: something SECRET_WARN_TEXT 31415926
/fake/SECRET_LOG_PATHLINE/x: warning
a|b c
INFO: Particle insertion insB: inserted 91827364 particle templates (mass 1.0e-01) at step 518716
  523715 47979797  1.1e-10  1.0e-10  2.7e-05  9.9
Loop time of 6000.2 on 20 procs for 518714 steps with 47979797 atoms, finish time Wed Sep 30 11:33:52 2026
    Step    Atoms         KinEng            rke         Volume
 1037429 47979797  3.2685651e-12  1.0960987e-10  2.7589053e-05
Loop time of 5.19e-07 on 20 procs for 0 steps with 47979797 atoms, finish time Wed Sep 30 11:33:53 2026
    Step    Atoms         KinEng            rke         Volume
 1037429 47979797  3.2685651e-12  1.0960987e-10  2.7589053e-05
"""
Q9_EXPECT = {
    'blocks': 5,
    'block': {
        1: dict(header_cols=5, rows=2, rows_nonfinite=0, row_cols={5: 2}, nonrow=2, blank=0, closed='yes', words={'INFO:': 1, '-': 1}),
        2: dict(header_cols=5, rows=3, rows_nonfinite=0, row_cols={5: 3}, nonrow=0, blank=1, closed='yes', words={}),
        3: dict(header_cols=5, rows=2, rows_nonfinite=1, row_cols={5: 1, 6: 1}, nonrow=4, blank=0, closed='yes',
                words={'WARNING_##:': 1, '<PATHLIKE>': 1, 'a?b': 1, 'INFO:': 1}),
        4: dict(header_cols=5, rows=1, rows_nonfinite=0, row_cols={5: 1}, nonrow=0, blank=0, closed='yes', words={}),
        5: dict(header_cols=5, rows=1, rows_nonfinite=0, row_cols={5: 1}, nonrow=0, blank=0, closed='no', words={}),
    },
}


def build_binary(exp):
    lib_real = os.path.join(HOMER, '.conda', 'envs', 'myenv', 'lib')
    lib_login = os.path.join(HOMEL, '.conda', 'envs', 'myenv', 'lib')
    bdir = os.path.join(W, 'build')
    os.makedirs(lib_real, exist_ok=True)
    os.makedirs(bdir, exist_ok=True)
    src = os.path.join(HOMER, 'LIGGGHTS-PUBLIC', 'src')
    os.makedirs(src, exist_ok=True)
    with open(os.path.join(bdir, 'foo.c'), 'w') as f:
        f.write('int foo(void) { return 42; }\n')
    with open(os.path.join(bdir, 'bar.c'), 'w') as f:
        f.write('int bar(void) { return 7; }\n')
    with open(os.path.join(bdir, 'main.c'), 'w') as f:
        f.write('int foo(void); int bar(void);\nint main(void) { return foo() + bar() == 49 ? 0 : 1; }\n')
    run = lambda *a: subprocess.run(list(a), check=True, capture_output=True)
    run('gcc', '-shared', '-fPIC', '-Wl,-soname,libfoo.so.1', '-o', os.path.join(lib_real, 'libfoo.so.1.0.0'), os.path.join(bdir, 'foo.c'))
    os.symlink('libfoo.so.1.0.0', os.path.join(lib_real, 'libfoo.so.1'))
    run('gcc', '-shared', '-fPIC', '-Wl,-soname,libbar.so.2', '-o', os.path.join(bdir, 'libbar.so.2'), os.path.join(bdir, 'bar.c'))
    binp = os.path.join(src, 'lmp_mpi')
    run('gcc', '-o', binp, os.path.join(bdir, 'main.c'), '-L' + lib_real, '-l:libfoo.so.1', '-L' + bdir, '-l:libbar.so.2',
        '-Wl,-rpath,' + lib_login, '-Wl,--enable-new-dtags')
    exp['bin_sha256'] = sha(binp)
    exp['bin_bytes'] = os.path.getsize(binp)
    exp['libfoo_real_sha256'] = sha(os.path.join(lib_real, 'libfoo.so.1.0.0'))
    exp['libfoo_real_bytes'] = os.path.getsize(os.path.join(lib_real, 'libfoo.so.1.0.0'))


def main():
    for d in (HOMER, os.path.dirname(HOMEL), os.path.join(W, 'cwd'), os.path.join(W, 'tmp_outer')):
        os.makedirs(d, exist_ok=True)
    os.symlink(HOMER, HOMEL)
    exp = {'variant': VARIANT, 'home_login': HOMEL, 'home_real': HOMER, 'user': USER, 'secrets': SECRET_NUMS + SECRET_TXT,
           'q1': {}, 'q2': {}, 'q3': {}, 'q9': {}}
    for i, (run, job, nframes) in enumerate(RUNS, 1):
        if VARIANT == 'fail' and run == 'E0_ref2_s32452843':
            exp['q1']['r%d' % i] = {'run': run, 'absent': True}
            continue
        R = os.path.join(BASE, run)
        sizes = []
        for k in range(1, nframes + 1):
            step = k * 1000
            sizes.append(wfile(os.path.join(R, 'post', 'mix_%d.liggghts' % step), frame_size(step), 'SECRET_DUMP_VALUE\n', frame_mtime(step)))
        other = 0
        if run == ONE_RUN:
            sizes.append(wfile(os.path.join(R, 'post', 'README_SECRET_NAME.txt'), 77, 'SECRET_DUMP_VALUE\n'))
            os.makedirs(os.path.join(R, 'post', 'subdir'))
            other = 1
        rs = {}
        for nm, sz in (('a.bin', 1234), ('b.bin', 1300 + i), ('settled.bin', 1400 + 2 * i)):
            rs[nm] = wfile(os.path.join(R, 'restart', nm), sz, 'SECRET_RESTART\n')
        wfile(os.path.join(R, 'in.mixer'), 300, '# deck\n')
        wfile(os.path.join(R, 'job_start.json'), 120, '{"secret": "SECRET_JOBSTART"}\n')
        wfile(os.path.join(R, 'log.lmp'), 500, 'SECRET_LOG_PATHLINE\n')
        exp['q1']['r%d' % i] = {'run': run, 'job': job, 'post_entries': len(sizes) + other, 'post_files': len(sizes),
                                'post_bytes': sum(sizes), 'post_min': min(sizes), 'post_max': max(sizes), 'post_other': other,
                                'restart': rs, 'restart_bytes': sum(rs.values())}
        if run == ONE_RUN:
            with open(os.path.join(R, 'log.liggghts'), 'w') as f:
                f.write(LOG.replace('{HOMEL}', HOMEL))
            n = nframes
            m = (n + 1) // 2
            idx = []
            for x in (1, 2, 3, m, n - 2, n - 1, n):
                if 1 <= x <= n and x not in idx:
                    idx.append(x)
            exp['q2'] = {'run': run, 'files': nframes + 1, 'matched': nframes, 'other_names': 1,
                         'frames': {str(x): [x * 1000, frame_size(x * 1000), frame_mtime(x * 1000)] for x in idx}}
            exp['q9'] = {'lines': LOG.count('\n'), **{'blocks': Q9_EXPECT['blocks']},
                         'block': {str(k): {**v, 'row_cols': {str(a): b for a, b in v['row_cols'].items()}} for k, v in Q9_EXPECT['block'].items()}}
    ex = {'exact_LU212_a': {'hp_6800000.liggghts': 4321, 'g6_6800000.liggghts': 2100},
          'exact_LU637_settled': {'hp_1037429.liggghts': 4400, 'g6_1037429.liggghts': 2150}}
    for d, files in ex.items():
        for nm, sz in files.items():
            wfile(os.path.join(BASE, d, 'exact', nm), sz, 'SECRET_EXACT\n')
    wfile(os.path.join(BASE, 'exact_LU637_settled', 'exact', 'extra.txt'), 10, 'SECRET_EXACT\n')
    wfile(os.path.join(BASE, 'exact_odd name', 'exact', 'hp_1.liggghts'), 50, 'SECRET_EXACT\n')
    wfile(os.path.join(BASE, 'notexact_dir', 'exact', 'hp_2.liggghts'), 60, 'SECRET_EXACT\n')
    exp['q3'] = {'dirs': ex, 'other': {'exact_LU212_a': 0, 'exact_LU637_settled': 1}, 'odd_skipped': True}
    wfile(os.path.join(BASE, '.e0_diag', 'vault.json'), 40, '{"M": "SECRET_M_VALUE"}\n')
    build_binary(exp)
    with open(os.path.join(W, 'expect.json'), 'w') as f:
        json.dump(exp, f, indent=1, sort_keys=True)


if __name__ == '__main__':
    main()

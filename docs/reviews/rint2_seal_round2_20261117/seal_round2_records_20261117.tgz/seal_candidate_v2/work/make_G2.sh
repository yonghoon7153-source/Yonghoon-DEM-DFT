#!/bin/bash
# G′ = G 의 나무 + (README · 증거를 G 결과로 고친 판) 를 64e4d213e 위 한 커밋으로 · 그 위에서 참조 · 철회값 · 경계만 다시 잰다 (scratch 사본 안 git 만)
set -euo pipefail
V=/tmp/claude-0/-home-user-Yonghoon-DEM-DFT/81c0ad95-542f-503b-9cf7-2f6a678a4b5b/scratchpad/rint/seal_candidate_v2
C=$V/work/sealclone; E=$V/evidence; D=$C/docs/reviews/rint2_seal_20261120; O=$V/work/evG2
PIN=64e4d213e8267bafaf3ae5af00a42996cefd3f33; CLAIMS=2da71fe5abbaa856beb87c39c2a49424e4c87bc7
mkdir -p $O
! grep -n "@@" $V/README.md || { echo "README 자리표 남음"; exit 1; }
sed "s#$V/work#<scratch>#g;s#$V#<후보>#g" $V/work/evG/e1_test_rint_r_chain_full_G.txt > $E/raw/e1_test_rint_r_chain_full_G.txt
rm -f $E/*.txt $E/*.json
python3 -I $E/tools/make_committed_evidence.py $E/raw $E $C/docs/reviews/claims.json > $O/make_committed_evidence.txt
G=064e1268badcffc005af92e07e49b4f3d1e22353
cp $V/README.md $D/README.md
rm -rf $D/evidence; mkdir -p $D/evidence/tools
(cd $E && cp ./*.txt ./*.json $D/evidence/ && cp tools/*.py $D/evidence/tools/)
cd $C
git add -A
git -c user.name=scratch -c user.email=scratch@invalid -c commit.gpgsign=false commit -q -m "scratch G prime prep"
T=$(git rev-parse 'HEAD^{tree}')
G2=$(git -c user.name=scratch -c user.email=scratch@invalid commit-tree "$T" -p $PIN -m "scratch seal-form commit G prime (seal candidate v2 · 11-17 field facts · README · evidence with G results · NOT for push)")
git update-ref refs/heads/seal-form-scratch "$G2"
{ echo "# G = $G → G′ = $G2 (부모 $(git rev-parse "$G2^"))"; echo "## git diff --stat G G′ (봉인 기록 폴더 README · evidence 뿐이어야)"; git diff --stat "$G" "$G2" | tail -40;
  echo "## 봉인 기록 폴더 README · evidence 밖 차이 파일 수: $(git diff --name-only "$G" "$G2" | grep -vc '^docs/reviews/rint2_seal_20261120/\(README.md\|evidence/\)' || true)"; } > $O/G2_diff.txt
{ echo "# HEAD $G2 (G′)"; python3 -I scripts/check_doc_refs.py; echo "rc=$?"; } > $O/G2_check_doc_refs.txt 2>&1 || true
{ echo "# HEAD $G2 (G′ · claims.json = 원격 stoic 2da71fe5a 판) · $(python3 -V)"; python3 -I $E/tools/check_ban_new_text.py $C $PIN HEAD $CLAIMS; echo "rc=$?"; } > $O/G2_ban_new_text.txt 2>&1 || true
{ echo "# HEAD $G2 (G′)"; python3 -I $E/tools/check_seal_files.py $C $PIN HEAD; echo "rc=$?"; } > $O/G2_seal_files.txt 2>&1 || true
echo "status 줄 $(git status --porcelain --untracked-files=all | wc -l)" > $O/G2_status_lines.txt
echo "G2=$G2"

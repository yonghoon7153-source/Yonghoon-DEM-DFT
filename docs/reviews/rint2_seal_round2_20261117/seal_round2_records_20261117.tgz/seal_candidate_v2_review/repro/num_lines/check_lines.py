import re, sys, os
P = sys.argv[1]
F = {'chain': 'rint_r_chain.py', 'reg': 'rint_carbon_additive_registration_R_draft_20261020.md', 'cmd': 'rint2_kgy_commands_20261020.md',
     'cj': 'scripts/carbon_junction.py', 'cc': 'scripts/step3_conv_cert.py', 'rc': 'scripts/run_contract.py', 'st': 'scripts/cjunc_store.py',
     'run': 'scripts/sdcp_gain_vox015_8arm.sh', 'disc': 'check_method_discipline.py', 'crf': 'check_review_findings.py', 'cdr': 'check_doc_refs.py',
     'test': 'test_rint_r_chain.py', 'fam': 'docs/reviews/fam_platen_prereg_20260812.md', 'rfp': 'docs/reviews/rint2_rereview_fix_plan_20261022.md',
     'q9': 'docs/reviews/rint2_rr_fix_evidence_20261023/q9_predict_units_design.md', 's0': 'ca_s0_census.py'}
L = {k: open(os.path.join(P, v), encoding='utf-8').read().split('\n') for k, v in F.items()}
claims = [l.strip() for l in open(sys.argv[2], encoding='utf-8') if l.strip() and not l.startswith('#')]
ok = bad = 0
for c in claims:
    label, f, rng, pat = c.split(' | ')
    a, _, b = rng.partition('-'); a = int(a); b = int(b) if b else a
    seg = L[f][a - 1:b]
    hit = any(re.search(pat, x) for x in seg)
    ok += hit; bad += (not hit)
    near = ''
    if not hit:
        idx = [i + 1 for i, x in enumerate(L[f]) if re.search(pat, x)]
        near = f' · 실제 위치 {idx[:6]}'
    print(f'{"OK " if hit else "BAD"} {label} [{f} {rng}] /{pat}/' + near + ('' if hit else ' · 그 줄: ' + (L[f][a - 1][:90] if a - 1 < len(L[f]) else '<없음>')))
print(f'== {ok} OK · {bad} BAD')

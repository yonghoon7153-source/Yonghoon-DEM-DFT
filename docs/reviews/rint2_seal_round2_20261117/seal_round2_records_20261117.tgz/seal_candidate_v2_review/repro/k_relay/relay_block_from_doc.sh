# 보낸 쪽 — (4) 의 시작 확인 뒤 (또는 그 기계에서 도는 사슬이 없을 때) · 원장 잠금 (사슬과 같은 잠금 파일 · 1저자 11-17 봉인 후보 Q5) 아래에서 묶고 세워 둔다
cd ~/sdcp && umask 022
T=$(date -u +%Y%m%dT%H%M%SZ); FROM=kgy; TO=gabia; B=~/sdcp/ca1_relay/${T}_${FROM}_to_${TO}.bundle
flock -x -w 120 ca1_ledger/.git/rint_r_ledger.lock -c "git -C ca1_ledger bundle create \"$B\" --all && mv ca1_ledger ca1_ledger.parked"
git -C ca1_ledger.parked rev-parse HEAD; sha256sum "$B"; echo "$T"      # 넘김 기록 한 줄 (시각 · 원장 끝 커밋 · 묶음 sha256)
test ! -e ca1_ledger && echo PARKED_OK
# 받는 쪽 — 묶음을 ~/sdcp/ca1_relay/ 에 같은 이름으로 둔 뒤 (T · FROM · TO · 가지 = 넘김 기록)
cd ~/sdcp && umask 022
T=<넘김 기록 시각>; FROM=kgy; TO=gabia; BR=<원장 가지>; RB=~/sdcp/ca1_relay/${T}_${FROM}_to_${TO}.bundle
sha256sum "$RB"                                                     # = 넘김 기록
git bundle list-heads "$RB" | grep "refs/heads/$BR"                 # 커밋 = 넘김 기록의 원장 끝 커밋
if [ -d ca1_ledger.parked ]; then mv ca1_ledger.parked ca1_ledger && git -C ca1_ledger pull -q --ff-only "$RB" "$BR"; else git clone -q -b "$BR" "$RB" ca1_ledger; fi
git -C ca1_ledger rev-parse HEAD                                    # = 넘김 기록의 원장 끝 커밋 (다르면 멈추고 1저자 · 사슬을 띄우지 않는다)

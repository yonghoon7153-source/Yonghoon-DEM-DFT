import os
getattr(os, "fork")()

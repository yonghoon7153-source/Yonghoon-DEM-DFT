import re, sys
for fn in sys.argv[1:]:
    L = open(fn, encoding='utf-8').read().splitlines()
    bad = 0; blk = None; incode = False
    for i, l in enumerate(L, 1):
        if l.startswith('```'):
            incode = not incode; continue
        if incode: continue
        if l.startswith('|'):
            n = len(re.findall(r'(?<!\\)\|', l))
            if blk is None: blk = n
            elif n != blk:
                bad += 1; print(f'{fn}:{i}: {n} pipes vs {blk}')
        else:
            blk = None
    print(fn, 'bad rows', bad)

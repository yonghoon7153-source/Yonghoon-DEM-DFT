#!/usr/bin/env python3
"""AI 학습용 DEM 데이터셋 **설계** — 5 노브 LHS (2026-08-18 지시).

설계인자 (사용자 지정 범위)                 디스크립터 (DEM 이 낼 것)
  대립 AM_P 5–15 µm                          porosity
  소립 AM_S 1–5 µm                           coverage (대립 / 소립 / 전체)
  바이모달 비율 0–100 %                      tortuosity
  전해질 SE 0.5–2 µm
  활물질 함량 70–95 wt%

★★ **크기는 직경(diameter)으로 해석했다.**  근거 — 리포는 두 규약을 다 쓴다:
   `r_AM_P/r_AM_S/r_SE` = **반경** (LIGGGHTS 입력, `docs/data/dem_design_points.csv`)
   `d_am/d_se`          = **직경** (ML 설계층, `docs/data/design_performance_corpus.csv`)
   실측 대조로 확인: d_am 4/5/10/12 = 2 × r_AM 2/2.5/5/6 · d_se 0.5/1/2/3 = 2 × r_SE 0.25/0.5/1/1.5.
   지시된 범위(대립 5–15 · 소립 1–5 · SE 0.5–2)는 **직경**으로 읽을 때 실물성과 맞고
   (poly NCM D50 8–15 · single-crystal 2–5 · 밀링 LPSCl 0.5–2), 두 AM 범위가 **겹치지 않아**
   d_AM_P ≥ d_AM_S 가 구성상 보장된다 (반경으로 읽으면 대립이 Ø10–30 µm 로 비현실적).
   ⇒ 반경 컬럼(`r_*_um`)을 **함께** 내보내므로 어느 쪽이든 그대로 쓸 수 있다.
   ⚠ 지시가 반경이었다면 크기 3열을 2배 하면 된다 (`--as-radius`).

★ 왜 세 블록인가 (분기 설계): ps_frac = 0 이면 AM_P 가 **없어서** d_AM_P 가 식별 불가능하고,
  ps_frac = 1 이면 d_AM_S 가 그렇다.  한 LHS 에 섞으면 그 행들이 **없는 인자에 좌표를 배정**해
  설계행렬을 오염시킨다.  ⇒ 내부(양상 존재) 5-인자 LHS + 두 단일모달 끝점 3-인자 LHS 로 가른다.

사용:
  python3 scripts/lhs_design_dataset.py --n 60 --n-end 10 --out docs/data/lhs_design_20260818.csv
  python3 scripts/lhs_design_dataset.py --selftest
"""
from __future__ import annotations

import argparse
import ast
import collections
import csv
import hashlib
import json
import math
import pathlib
import re
import sys

import numpy as np

#  범위 = 사용자 지정 (2026-08-18).  직경 µm / wt% / 무차원.
RANGES = {
    'd_am_p_um': (5.0, 15.0),      # 대립 (poly NCM 2차입자)
    'd_am_s_um': (1.0, 5.0),       # 소립 (single-crystal)
    'ps_frac':   (0.0, 1.0),       # 바이모달 비율 = AM_P 몫 (0 = 소립만, 1 = 대립만)
    #  ★★ 2026-08-18 — 하한을 0.5 → **1.0** 으로 올렸다 (지시: 입자 20만 이하).
    #    이유는 계산이 아니라 **측정**이다.  덱 실측(input_real_1)으로 규약이 확정된 뒤
    #    격자 11,880 조합의 N_total 을 전수 계산해 보니:
    #        d_se 0.5 → N 100,625 – 908,115   20만 이하 **16.7 %**
    #        d_se 1.0 → N  12,671 – 191,918   20만 이하 **100 %**   ← 딱 경계
    #        d_se 1.5 → N   3,829 – 119,919   100 %
    #        d_se 2.0 → N   1,677 – 102,393   100 %
    #    ★ 그리고 제약이 **d_se 에만** 걸린다 — 나머지 네 인자는 수준별 생존률이
    #      79 % 로 **완전히 균일**하다 ⇒ d_se 하한만 올리면 다른 축은 **전혀 안 일그러진다**.
    #    ⚠ rve 50 · 로딩 2 에서 d_se 1.0 이 **하한이다** (0.9 면 ~23만으로 넘는다).
    #    ⚠ 잃는 것: 코퍼스에 2건뿐인 sub-µm SE 축.  살리려면 그 축만 작은 RVE 서브블록으로
    #      (rve 24 · d_am_p ≤ 7 µm 면 20만 아래) — 본 설계를 일그러뜨리지 않는 방법이다.
    'd_se_um':   (1.0, 2.0),       # 전해질
    'am_pct':    (70.0, 95.0),     # 활물질 함량 wt%
}
FACTORS = list(RANGES)
#  끝점 블록에서 **살아 있는** 인자 (죽은 크기 인자는 좌표를 배정하지 않는다)
END_ACTIVE = {0.0: ['d_am_s_um', 'd_se_um', 'am_pct'],
              1.0: ['d_am_p_um', 'd_se_um', 'am_pct']}
#  내부 블록의 ps 범위 — 0/1 은 끝점 블록이 담당하므로 여기서는 열어 둔다
PS_INTERIOR = (0.10, 0.90)      # 정수 설계에서는 1:9 … 9:1 이 내부다 (0:10/10:0 은 끝점 블록)

#  ── ★ 정수 격자 (2026-08-18 지시 "정수로 설계하는게 좋을거 같은데") ─────────────────
#    실물성 근거: 12.93 µm 분말을 주문할 수는 없다.  실제로 고를 수 있는 눈금에 설계를 얹는다.
#    d_SE 만 0.5 눈금인 이유 — 범위가 0.5–2 라 정수로 자르면 {1, 2} 두 수준밖에 안 남는다.
#    ps 눈금 0.1 = 랩이 이미 쓰는 `0:10 · 3:7 · 5:5 · 7:3 · 10:0` 표기와 정확히 일치한다.
#    am_pct 눈금 5 (2026-08-18 지시) — 70/75/80/85/90/95 = 6수준.  1 눈금(26수준)이면
#    60점에 수준당 2–3개라 **수준별 반복이 거의 없어** 조성 효과가 다른 인자와 섞이기 쉽다.
#    5 눈금이면 수준당 10개 = 조성 축을 **블록처럼** 읽을 수 있고, 실제 배합도 5 % 단위다.
STEP = {'d_am_p_um': 1.0, 'd_am_s_um': 1.0, 'ps_frac': 0.1, 'd_se_um': 0.5, 'am_pct': 5.0}


def levels_of(name, ps_range=None):
    """그 인자가 실제로 고를 수 있는 값들 (정수 격자)."""
    lo, hi = RANGES[name]
    if name == 'ps_frac' and ps_range is not None:
        lo, hi = ps_range
    st = STEP[name]
    k = int(round((hi - lo) / st))
    return [round(lo + i * st, 6) for i in range(k + 1)]


def _balanced(n, L, rng):
    """L 수준에 n 점을 **균형** 배정 (각 수준이 floor/ceil(n/L) 번) 후 섞는다.
    ⇒ 연속 LHS 의 '층마다 정확히 하나' 를 이산 격자로 옮긴 것."""
    base, rem = divmod(n, L)
    idx = np.array([i for i in range(L) for _ in range(base + (1 if i < rem else 0))])
    return rng.permutation(idx)


#  설계행렬이 넘으면 안 되는 |비대각 상관| — 이 값을 넘으면 인자 효과가 서로 섞인다.
CORR_MAX = 0.25


def _unit(I, level_lists):
    """수준 인덱스 → 단위공간 [0,1] (수준 수가 인자마다 달라 인덱스로 재면 왜곡된다)."""
    return np.stack([I[:, j] / max(len(level_lists[j]) - 1, 1)
                     for j in range(I.shape[1])], 1)


def _score(U):
    """(최대 |비대각 상관|, 최소 쌍거리)."""
    C = np.corrcoef(U.T)
    mc = float(np.abs(C[~np.eye(U.shape[1], dtype=bool)]).max())
    d2 = ((U[:, None, :] - U[None, :, :]) ** 2).sum(-1)
    d2[np.diag_indices(len(U))] = np.inf
    return mc, float(np.sqrt(d2.min()))


def lhs_grid(n, level_lists, rng, restarts=400, corr_max=CORR_MAX, sweeps=60):
    """정수 격자 위의 LHS → 수준 인덱스 배열 (n, k).

    ★★ 2026-08-18 — 옛 판은 **maximin(최소 쌍거리)만** 최적화했다.  상관은 이긴 배치가
    우연히 갖는 값이었고, 격자가 고울 때는 그럭저럭 낮았지만(0.15) **거칠어지자 튀었다**:
    am_pct 눈금을 1→5 로 바꾸자 재시작을 60→8000 으로 늘려도 max|corr| 이
    0.23 / 0.21 / **0.37** / 0.21 로 **재시작과 무관하게 오르내렸다** (실측).
    ⇒ 최적화 대상이 우리가 신경 쓰는 양이 아니었다.  두 단계로 고친다:
      ① 무작위 재시작을 **벌점 목적함수**로 고른다 — 상관이 문턱을 넘으면 크게 깎는다
      ② 이긴 배치를 **열 내부 스왑**으로 다듬는다 (열 안에서만 바꾸므로 수준 균형은 불변)
    """
    k = len(level_lists)
    best, best_obj, best_sc = None, -1e18, None
    for _ in range(int(restarts)):
        I = np.stack([_balanced(n, len(level_lists[j]), rng) for j in range(k)], 1)
        mc, md = _score(_unit(I, level_lists))
        obj = md - 10.0 * max(0.0, mc - corr_max)        # 상관 초과분에 큰 벌점
        if obj > best_obj:
            best, best_obj, best_sc = I, obj, (mc, md)
    #  ② 스왑 다듬기 — 한 열에서 두 행의 수준을 맞바꾼다.  열 안의 값 집합이 그대로라
    #     **수준 균형(=이산 LHS 성질)이 정의상 보존**된다.
    I = best.copy()
    for _ in range(int(sweeps)):
        improved = False
        for _try in range(n * k):
            j = int(rng.integers(k))
            a, b = rng.integers(n, size=2)
            if a == b or I[a, j] == I[b, j]:
                continue
            I[[a, b], j] = I[[b, a], j]
            mc, md = _score(_unit(I, level_lists))
            obj = md - 10.0 * max(0.0, mc - corr_max)
            if obj > best_obj + 1e-12:
                best_obj, best_sc, improved = obj, (mc, md), True
            else:
                I[[a, b], j] = I[[b, a], j]              # 되돌린다
        if not improved:
            break
    return I


def lhs_grid_feasible(n, level_lists, names, feasible, rng, restarts=60,
                      sweeps=200, corr_max=CORR_MAX, bal_w=3.0):
    """**제약이 있는** 정수 격자 설계 — 후보 풀에서 n 행을 고른다.

    ★ 왜 별도 알고리즘인가 (2026-08-18): 입자수 상한을 10만으로 조이면 제약이 `d_se`
      하나가 아니라 **여러 축에 동시에** 걸린다 (실측 생존률: am_pct 70 → 64 % ·
      d_se 1.0 → 76 % · d_am_s 1 → 78 % · ps 0.1 → 83 %).  그러면 `_balanced()` 로 만든
      배치가 제약을 위반하고, 위반 행만 갈아끼우면 **수준 균형이 깨진다**.
      ⇒ 실현 가능한 조합만 모은 **후보 풀에서 고르고**, 목적함수에 **균형 항을 명시**한다.
      (200k 상한에서는 제약이 d_se 에만 걸려 범위 조정만으로 됐다 — 그때는 이 경로가 불필요.)

    목적: −bal_w·(수준 점유 불균형) − 10·max(0, max|corr| − corr_max) + minDist
    """
    pool = [c for c in feasible]
    if len(pool) < n:
        raise SystemExit(f'실현 가능한 조합이 {len(pool)}개 < 요청 {n}행')
    idx = {f: {v: j for j, v in enumerate(level_lists[i])} for i, f in enumerate(names)}

    def to_I(sel):
        return np.array([[idx[f][c[f]] for f in names] for c in sel])

    def obj(sel):
        I = to_I(sel)
        mc, md = _score(_unit(I, level_lists))
        bal = 0.0
        for j, f in enumerate(names):
            L_ = len(level_lists[j])
            cnt = np.bincount(I[:, j], minlength=L_)
            bal += float(np.abs(cnt - len(sel) / L_).sum()) / len(sel)   # 총 편차 비율
        return md - 10.0 * max(0.0, mc - corr_max) - bal_w * bal, (mc, md, bal)

    best, best_o, best_s = None, -1e18, None
    for _ in range(int(restarts)):
        sel = [pool[i] for i in rng.choice(len(pool), n, replace=False)]
        o_, st = obj(sel)
        if o_ > best_o:
            best, best_o, best_s = sel, o_, st
    sel = list(best)
    inpool = {id(c) for c in sel}
    for _ in range(int(sweeps)):
        improved = False
        for _t in range(n * 3):
            a_ = int(rng.integers(n))
            cand = pool[int(rng.integers(len(pool)))]
            if id(cand) in inpool:
                continue
            old = sel[a_]
            sel[a_] = cand
            o_, st = obj(sel)
            if o_ > best_o + 1e-12:
                best_o, best_s, improved = o_, st, True
                inpool.discard(id(old)); inpool.add(id(cand))
            else:
                sel[a_] = old
        if not improved:
            break
    return to_I(sel)


#  ── 고정 상수 (인자가 아니다 — 2026-08-18 지시) ──────────────────────────────────
#    면용량 2 mAh/cm² = wall effect 가 거의 안 나오는 최소 단위 · RVE 50×50 µm.
#    ★ 인자에서 빼는 것이 이득이다: 기존 ML 설계층은 `rve` 와 `loading` 을 **자유 노브**로
#      두는데(ml_design_structure.FREE_KNOBS), 그 둘을 고정하면 5 인자에 예산을 다 쓴다.
FIXED = {'rve_um': 50.0, 'loading_mAh_cm2': 2.0}
#  두께는 로딩의 함수다 — 코퍼스 291건 원점회귀 (3σ 제거 후) **19.64 µm per mAh/cm²**
#  ⇒ 면용량 2.0 → 두께 ≈ 39 µm.  DEM 이 실제 두께를 낼 것이고 이 값은 **사전 점검용**이다.
THICK_PER_LOADING_UM = 19.64

#  ── ★ 물리 파생 (2026-08-18 적대 리뷰 R0) ────────────────────────────────────────
#    덱 실측값 — 밀도는 스케일되지 않는다 (input_real_*.liggghts).
RHO_AM_KGM3, RHO_SE_KGM3 = 4800.0, 2000.0
EPS_TYPICAL = 0.183             # ★ 실측 보정: 덱 mesh STL(6 mAh, step 2.93e6) plate_z =
#   0.116811 m = 116.8 µm, 고체만 높이 96.2 µm ⇒ ε = 0.176.  코퍼스 회귀(19.64 µm/mAh)가
#   함축하는 0.183 과 0.9 % 안에서 일치한다.  옛 0.16 은 근거 없는 어림이었다.
PRESSURE_MPA = 300.0            # 코퍼스 규약 — 리뷰 HIGH-E: 컬럼에 없으면 범위인지 편향인지 모른다
E_SE_GPA = 1.35                 # DEM 유효 SE 탄성계수 (CLAUDE.md 확정값)
PHI_C_SE = 0.195                # SE 퍼콜 문턱 (CLAUDE.md FROZEN φc_S; φc_P = 0.200)
N_AM_P_MIN = 30                 # 이보다 적으면 coverage_AM_P·ps_frac 이 실현되지 않는다
N_TOTAL_CAP = 100_000           # 지시 2026-08-18 — "10만 내외가 가장 좋다, 그래서 면용량 2"
#   ⚠ 200k 였을 땐 제약이 d_se 에만 걸려 범위 조정으로 끝났다.  100k 는 여러 축에 걸려
#     (am_pct 70 → 64 % · d_se 1.0 → 76 % · d_am_s 1 → 78 % · ps 0.1 → 83 %)
#     제약-인지 샘플러(`lhs_grid_feasible`)가 필요하다.


def phi_of(am_pct, eps=EPS_TYPICAL):
    """중량 % → (φ_AM, φ_SE) 전체 부피 기준."""
    va, vs = am_pct / RHO_AM_KGM3, (100.0 - am_pct) / RHO_SE_KGM3
    f = va / (va + vs)
    return (1.0 - eps) * f, (1.0 - eps) * (1.0 - f)


_PHI_AM_REF = phi_of(81.6)[0]   # 코퍼스 회귀가 잡힌 조성 (AM:SE = 81.6:18.4)


def thickness_of(am_pct, loading):
    """★ 두께는 상수가 아니다 (리뷰 MED-J).  면용량 고정이면 두께 ∝ 1/φ_AM 이므로
    am_pct 70 → 95 에서 **51.7 → 28.7 µm (1.8배)** 로 변한다.  옛 판이 39.28 을 모든 행에
    박아 `thick_over_d_am_max` 와 `finite_size_flag` 를 **틀리게** 만들고 있었다."""
    return THICK_PER_LOADING_UM * loading * (_PHI_AM_REF / phi_of(am_pct)[0])


def n_particles(d_um, phi, rve_um, thick_um):
    """그 상의 입자 개수 추정 (구 부피 기준)."""
    if not d_um or d_um != d_um or d_um <= 0:
        return float('nan')
    return phi * (rve_um * rve_um * thick_um) / ((np.pi / 6.0) * d_um ** 3)


def lhs(n, k, rng, restarts=200):
    """maximin LHS (numpy 전용).  각 인자를 n 등분해 층마다 정확히 한 점 = 1-D 균일 보장,
    그 위에서 최소 쌍거리를 최대화하는 순열을 무작위 재시작으로 고른다."""
    best, best_d = None, -1.0
    for _ in range(int(restarts)):
        u = np.empty((n, k))
        for j in range(k):
            u[:, j] = (rng.permutation(n) + rng.random(n)) / n
        if n < 2:
            return u
        d2 = ((u[:, None, :] - u[None, :, :]) ** 2).sum(-1)
        d2[np.diag_indices(n)] = np.inf
        m = float(np.sqrt(d2.min()))
        if m > best_d:
            best, best_d = u, m
    return best


def _scale(u, names, ps_range=None):
    out = {}
    for j, nm in enumerate(names):
        lo, hi = RANGES[nm]
        if nm == 'ps_frac' and ps_range is not None:
            lo, hi = ps_range
        out[nm] = lo + u[:, j] * (hi - lo)
    return out


def _n_total_of(d):
    """이 조합의 전체 입자수 추정 (덱 실측으로 검증된 규약).  `dem_input_values` 와 같은 계산."""
    fa, fs = phi_of(d['am_pct'])
    th = thickness_of(d['am_pct'], FIXED['loading_mAh_cm2'])
    r = FIXED['rve_um']
    tot = 0.0
    for dd, ph in ((d.get('d_am_p_um'), fa * d['ps_frac']),
                   (d.get('d_am_s_um'), fa * (1.0 - d['ps_frac'])),
                   (d['d_se_um'], fs)):
        v = n_particles(dd, ph, r, th)
        if v == v:
            tot += v
    return tot


def feasible_combos(names, level_lists, extra=None, cap=None):
    """입자수 상한을 만족하는 격자 조합만 (제약-인지 샘플러의 후보 풀).

    `extra` = 그 블록에서 **고정된** 값 (끝점 블록의 ps 와, 없는 상의 NaN).
    """
    import itertools as _it
    cap = N_TOTAL_CAP if cap is None else cap
    base = {'d_am_p_um': float('nan'), 'd_am_s_um': float('nan'), 'ps_frac': 0.0}
    base.update(extra or {})
    out = []
    for c in _it.product(*level_lists):
        d = dict(zip(names, c))
        if _n_total_of(dict(base, **d)) <= cap:
            out.append(d)
    return out


def build(n_interior=60, n_end=10, seed=0, restarts=400, grid=True):
    rng = np.random.default_rng(seed)
    rows = []

    # ── 블록 A: 내부(양상 공존) 5-인자 ────────────────────────────────────────
    if grid:
        LV = [levels_of(f, PS_INTERIOR) for f in FACTORS]
        #  ★ 제약(입자수 상한)이 있으면 후보 풀에서 고른다 — 균형을 목적함수로 지킨다
        _pool = feasible_combos(FACTORS, LV)
        _all = int(np.prod([len(x) for x in LV]))
        if len(_pool) < _all:
            IA = lhs_grid_feasible(n_interior, LV, FACTORS, _pool, rng,
                                   restarts=max(40, restarts // 40))
        else:
            IA = lhs_grid(n_interior, LV, rng, restarts)
        for i in range(n_interior):
            rows.append({'block': 'bimodal',
                         **{f: float(LV[j][IA[i, j]]) for j, f in enumerate(FACTORS)}})
    else:
        uA = lhs(n_interior, len(FACTORS), rng, restarts)
        sA = _scale(uA, FACTORS, ps_range=PS_INTERIOR)
        for i in range(n_interior):
            rows.append({'block': 'bimodal', **{f: float(sA[f][i]) for f in FACTORS}})

    # ── 블록 B/C: 단일모달 끝점 — **죽은 크기 인자에 좌표를 주지 않는다** ─────
    for ps, active in END_ACTIVE.items():
        if grid:
            LVb = [levels_of(f) for f in active]
            _poolb = feasible_combos(active, LVb, extra={'ps_frac': ps})
            _allb = int(np.prod([len(x) for x in LVb]))
            IB = (lhs_grid_feasible(n_end, LVb, active, _poolb, rng,
                                    restarts=max(40, restarts // 40))
                  if len(_poolb) < _allb else lhs_grid(n_end, LVb, rng, restarts))
            get = lambda i, f: float(LVb[active.index(f)][IB[i, active.index(f)]])
        else:
            sB = _scale(lhs(n_end, len(active), rng, restarts), active)
            get = lambda i, f: float(sB[f][i])
        for i in range(n_end):
            r = {'block': 'mono_AM_P' if ps == 1.0 else 'mono_AM_S', 'ps_frac': float(ps)}
            for f in FACTORS:
                if f == 'ps_frac':
                    continue
                r[f] = get(i, f) if f in active else float('nan')
            rows.append(r)

    # ── 파생 (DEM 입력 + 기존 ML 설계층 호환) ────────────────────────────────
    for k, r in enumerate(rows):
        r['case_id'] = f'lhs{seed:02d}_{k:03d}'
        p = r['ps_frac']
        dP, dS = r['d_am_p_um'], r['d_am_s_um']
        #  ⚠ 2026-08-18 리뷰 HIGH-H: 옛 `d_am_um`(ps 가중 **산술평균**)을 **버렸다**.
        #    코퍼스의 `d_am` 은 `max(d_P, d_S)` 라 같은 이름이 다른 물리량이었고
        #    (중앙 1.41배 · 최대 6.09배), 게다가 ps 는 부피분율인데 산술평균 가중치로 써서
        #    차원도 안 맞았다.  ⇒ 아래에서 `d_am_max_um`(코퍼스 규약)과
        #    `sv_inv_um`(Sauter 역수, 패킹 물리)을 **각각** 낸다.
        for src, dst in (('d_am_p_um', 'r_AM_P_um'), ('d_am_s_um', 'r_AM_S_um'),
                         ('d_se_um', 'r_SE_um')):
            r[dst] = r[src] / 2.0                       # ← LIGGGHTS 입력은 **반경**
        r['ps_label'] = (f'{round(p * 10):d}:{10 - round(p * 10):d}')   # 7:3 식 표기
        #  ★ 정수 격자(ps 눈금 0.1)에서는 이 라벨이 **반올림이 아니라 정확**하다
        r['size_ratio_P_over_S'] = (dP / dS) if (dP == dP and dS == dS) else float('nan')
        r['size_ratio_AM_over_SE'] = None            # 아래에서 d_am_max_um 확정 후 채운다
        #  ★ 코퍼스 규약의 `d_am` = max(d_P, d_S) — 신규 행을 코퍼스에 붙일 때 **이 열**을
        #    맞춰야 한다 (리뷰 HIGH-H: 산술평균과 중앙 1.41배 · 최대 6.09배 어긋난다).
        r['d_am_max_um'] = (dS if np.isnan(dP) else (dP if np.isnan(dS) else max(dP, dS)))
        #  ★★ Sauter 역수 — **끝점에서 저절로 잘 정의된다** (리뷰 §2 처방).
        #    S_v ∝ φ_AM·(ps/d_P + (1−ps)/d_S) 이고 ps=0 이면 d_P 가, ps=1 이면 d_S 가
        #    가중치 0 으로 사라진다 ⇒ NaN·센티넬·블록분리 없이 80 행이 한 모델에 들어간다.
        #    (코퍼스는 ps=0 행에 `d_am=0` 센티넬을 박아 40/291 행이 오염돼 있다.)
        r['sv_inv_um'] = ((0.0 if np.isnan(dP) else p / dP)
                          + (0.0 if np.isnan(dS) else (1.0 - p) / dS))
        #  ── 고정 상수와 물리 파생 ────────────────────────────────────────────────
        r.update(FIXED)
        r['pressure_MPa'] = PRESSURE_MPA          # 리뷰 HIGH-E
        r['e_se_gpa'] = E_SE_GPA
        fa, fs = phi_of(r['am_pct'])
        r['phi_am_est'], r['phi_se_est'] = fa, fs
        #  ★ SE 퍼콜 사전판정 (리뷰 BLOCKER-C).  φ_SE = 0.195 는 am_pct ≈ 88.8 wt% 다.
        #  ⚠⚠ **이름에 규약을 박는다** (`LHS-01`, 2026-09-15).  옛 이름은 `se_percolation` 이라
        #    **실측처럼 읽혔는데** 이 값은 `phi_se_est`(런 **전** 추정)를 동결 평균장 문턱에 댄
        #    파생 라벨이다.  같은 파일 아래 HIGH-F 주석이 이미 *"타깃 이름에 규약을 박는다"* 를
        #    규칙으로 세워 뒀는데 **이 열만 예외로 남아 있었다**.
        #    운용 특성은 `LHS_PERC_MEASURED` 에 실측으로 동결돼 있다 — **선별기이지 필터가 아니다.**
        r['se_percolation_est_meanfield'] = ('OK' if fs > 0.20 else
                                             ('marginal' if fs > PHI_C_SE else 'BELOW_phic'))
        th = thickness_of(r['am_pct'], FIXED['loading_mAh_cm2'])
        r['thickness_est_um'] = th
        #  ★ 입자 수 (rve 50 기준) — coverage_AM_P 와 ps 실현 가능성의 직접 지표
        r['n_am_p_est'] = n_particles(dP, fa * p, FIXED['rve_um'], th)
        r['n_am_s_est'] = n_particles(dS, fa * (1.0 - p), FIXED['rve_um'], th)
        r['n_se_est'] = n_particles(r['d_se_um'], fs, FIXED['rve_um'], th)
        r['n_total_est'] = float(np.nansum([r['n_am_p_est'], r['n_am_s_est'], r['n_se_est']]))
        #  ★ N_AM_P ≥ 30 을 만족하려면 상자가 얼마나 커야 하나 (N ∝ rve²)
        _np_ = r['n_am_p_est']
        r['rve_min_um'] = (float('nan') if (_np_ != _np_ or _np_ <= 0)
                           else FIXED['rve_um'] * float(np.sqrt(N_AM_P_MIN / _np_)))
        r['rve_recommended_um'] = (FIXED['rve_um'] if r['rve_min_um'] != r['rve_min_um']
                                   else max(FIXED['rve_um'], r['rve_min_um']))
        dmax = r['d_am_max_um']                              # 가장 큰 입자가 상자를 정한다
        r['rve_over_d_am_max'] = FIXED['rve_um'] / dmax           # 측면 상자 / 최대 입자
        r['thick_over_d_am_max'] = th / dmax                      # 두께 / 최대 입자
        r['size_ratio_AM_over_SE'] = dmax / r['d_se_um']
        #  ⚠ 측면은 **벽이 아니라 주기경계**다 (생산 덱 `boundary p p f`) — 측면 유한크기는
        #    wall effect 가 아니라 **상관길이 효과**이고, 디스크립터 계산 시 x,y 를
        #    최소상거리로 다뤄야 한다.  z(두께)만 진짜 유한크기다.
        #  ⚠ 플래그는 **거부가 아니라 라벨**이다 — 이 코너가 물리적으로 얇다는 사실 자체가
        #    데이터의 일부다 (실제 39 µm 전극에 Ø15 µm 입자면 정말 2.6층이다).
        #    기준: 코퍼스 최빈 구성이 rve50/d12 = 4.17, rve40/d12 = 3.33 이므로 3.3 을
        #    "우리가 이미 돌려 본 하한" 으로 잡는다 (새 기준을 발명하지 않는다).
        f = []
        if r['rve_over_d_am_max'] < 3.3:
            f.append('lateral')
        if r['thick_over_d_am_max'] < 3.0:
            f.append('thin')
        #  ★ 리뷰 BLOCKER-B: 대립이 한 자릿수면 `coverage_AM_P` 도 명목 `ps_frac` 도
        #    실현되지 않는다 (입자 하나가 ps 의 30 % 를 차지하는 행이 실재).
        if _np_ == _np_ and _np_ < N_AM_P_MIN:
            f.append('n_am_p_low' if _np_ >= 10 else 'n_am_p_CRIT')
        r['finite_size_flag'] = '+'.join(f)
        #  ⚠⚠ **SE 퍼콜 추정을 유한크기 플래그에서 뺀다** (`LHS-01`, 2026-09-15).
        #    옛 판은 `se_BELOW_phic` 를 `finite_size_flag` 에 **접합**해서 **기하 플래그가
        #    물리 추정을 날랐다**.  설계 130 행 중 44 행이 그렇게 켜졌고 그 중 **22 행은
        #    유한크기가 깨끗한데도** 플래그가 서 있었다 = 두 가지가 한 열에서 구별 불가.
        #    ⇒ 자기 열로 분리한다.  둘을 **같이** 보고 싶으면 두 열을 읽으면 된다.
        r['se_perc_est_flag'] = ('' if r['se_percolation_est_meanfield'] == 'OK'
                                 else 'se_' + r['se_percolation_est_meanfield'])
    return rows


#  ★★★ **실측 운용 특성** (`LHS-01` 닫음, 2026-09-15).  위 평균장 라벨을 코호트 127 케이스의
#    **생산 솔버 이온 관통 여부**와 대조한 결과다 (원자료 `docs/data/lhs_percolation_measured_20260915.csv`,
#    파생 `docs/lhs_corpus_readout_20260915.md`).  ⚠ 이 상수는 **읽는 법을 박아 두는 것**이지
#    코드 분기에 쓰라는 값이 아니다.
#
#      se_percolation_est_meanfield = OK          n=83   실제 막힘  1  (= 1.2 %)
#      se_percolation_est_meanfield = BELOW_phic  n=44   실제 막힘 24  (= 54.5 %)
#
#    ⇒ **선별기(screen)로는 훌륭하다** — 재현율 96.0 % (막힌 25건 중 24건을 잡는다).
#      놓친 1건은 `lhs00_009` 이고 그것은 물리가 아니라 경계 규칙이다 (`LHS-04`).
#    ⛔ **필터로 쓰면 안 된다** — 정밀도 54.5 % 라 `BELOW_phic` 를 버리면 **실제로 뚫리는
#      20건을 같이 버린다**.  이것이 `LHS-01` 이 P2 로 등재된 이유다.
#    ★ 그리고 이 값이 `thick_over_d_am_max` 보다 **잘 가른다**: 두 군 막힘률 비 **45.3배**
#      vs 유한크기 구간 최대/최소 **5.1배**(게다가 단조도 아니다 — 42.9/13.7/8.3/25.0 %).
#      ⚠ 판독문 ④ 의 옛 문장 *"유한크기가 φ 보다 잘 가른다"* 는 **이 측정으로 반증됐다**.
LHS_PERC_MEASURED = {
    'source': 'docs/data/lhs_percolation_measured_20260915.csv',
    'n_measured': 127, 'channel': 'ionic', 'solver': 'production (legacy arm, 기본값)',
    'OK': {'n': 83, 'blocked': 1}, 'BELOW_phic': {'n': 44, 'blocked': 24},
    'recall_pct': 96.0, 'precision_pct': 54.5, 'use': 'screen_not_filter',
}


#  ★★ 타깃 이름에 **규약을 박는다** (리뷰 HIGH-F).  리포 실측 모호폭:
#    coverage Hertz 22.25 % vs physics/Tabor 60.53 % (**2.7배**) — 섞으면 CLAUDE.md 가 기록한
#    σ_ionic T1 "FALSE-REVERT"(91건 전부 1.4배 과대예측)가 그대로 재발한다.
#    tortuosity Laplace 3.53 vs Dijkstra 1.29 (**2.73배**, 같은 케이스).
#    porosity ε_sphere vs ε_union (**1.251 %p** 오프셋).
#  ★ 그리고 **porosity 는 회귀 타깃에서 뺀다** — CLAUDE.md 정본 처방:
#    "porosity 는 회귀 말고 ε = C − φ_SE − φ_AM 로 계산 (raw DEM 닫힘 1.0000±0.0000 =
#     정확한 항등식 → φ 너머 정보 0)".  φ 둘을 배우고 빼면 된다 (추가 런 0건).
#    ε_sphere 는 **기록**은 하되 타깃 목록에는 안 넣는다.
DESCRIPTORS = ['phi_se', 'phi_am',                       # ← 회귀 타깃 (porosity 는 이 둘에서 유도)
               'coverage_AM_P_hertz_pct', 'coverage_AM_S_hertz_pct',
               'coverage_AM_total_hertz_pct',
               'tortuosity_dijkstra_SE',
               'porosity_sphere_pct_RECORD_ONLY']


#  ═══ `LHS-02` — 빈 측정 열을 **기계가 보게 한다** (2026-09-15) ═════════════════════
#  결함: 설계 CSV 는 `phi_se_est`(추정)와 `phi_se`(측정)를 **나란히** 갖는데 측정 쪽이
#    130/130 전부 비어 있다.  아무것도 그것을 검사하지 않았다.
#  ★ **지금 당장 오염된 판정은 없다** — 설계 CSV 를 여는 코드 전수(`dem_input_values.py` ·
#    `seal_s3_prerun.py` · `lhs_perc_fit.py` · `lhs_ext_design.py`)가 **설계 노브와 `case_id`
#    만** 읽고 측정 열은 **한 곳도 안 읽는다**.  ⇒ 이 결함은 **잠복**이지 활성이 아니다.
#  ⛔ 그래서 더 위험하다: 다음 사람이 학습셋을 만들며 `phi_se` 를 집으면 **빈 문자열**을 받고,
#    `float(x or 0)` 한 줄이면 **0 이 실측처럼** 들어간다 = 원장 `GAP2-05` 와 정확히 같은 자리.
#  ⇒ 처방은 열 삭제가 **아니다** (수확기 `lhs_descriptor_harvest.py` 가 그 이름에 쓴다).
#    **읽기를 fail-closed 로** 만들고, 채움 상태를 **수치로 보고**한다.
#  ★★ **갱신 2026-09-19 — 채웠다.**  옛 등록값(전부 0)과 그 사유 *"아직 수확되지 않았다"* 는
#    **낡았다**.  규율 ④ 가 경고한 자리이므로 채우는 커밋에서 같이 고친다.
#    남은 결측은 **두 종류뿐이고 둘 다 사유가 있다** — 빈 채로 방치된 칸은 없다.
DESCRIPTOR_FILL_EXPECTED = {           # 2026-09-19 실측.  움직이면 ⑭d 가 알려 준다.
    'path': 'docs/data/lhs_design_20260818.csv', 'n_rows': 130,
    'filled': {'phi_se': 130, 'phi_am': 130,
               'coverage_AM_P_hertz_pct': 100, 'coverage_AM_S_hertz_pct': 100,
               'coverage_AM_total_hertz_pct': 130,
               'tortuosity_dijkstra_SE': 14,
               'porosity_sphere_pct_RECORD_ONLY': 130},
    'why_partial': {
        'coverage_AM_P_hertz_pct': '30 = mono 설계(단일 AM 상)의 `N_A_PHASE_ABSENT`. '
                                   '**없는 상**이지 무접촉 0 이 아니다 (DESC-05).  '
                                   '(설계 CSV 의 등록값 — 인계표는 J20-k (B) 로 설계 상 칸에 전체 값을 싣는다)',
        'coverage_AM_S_hertz_pct': '위와 같은 30 건.',
        'tortuosity_dijkstra_SE': '116 = τ 실패.  ⚠ **원장 `LHS-08` 이 열려 있다** — 그 실패가 '
                                  '물리인지 전극 밴드 규약인지 아직 안 갈렸다.  재측정 뒤 '
                                  '이 숫자가 움직일 수 있다 (그때 이 등록값도 같이 고친다).',
    },
    'source': 'docs/data/lhs_descriptors_20260924/ (재수확 130/130, 2026-09-24 — 09-19 판은 LHS-10 · 11 로 폐기)',
    'manifest': 'docs/data/lhs_design_20260818_descriptor_manifest.json',
    'harvester': 'scripts/lhs_descriptor_harvest.py (selftest 전부 통과 2026-09-19)',
    'filler': 'scripts/lhs_design_dataset.py --fill-descriptors',
}


def descriptor_fill(rows):
    """설계 행들의 측정 열 채움 수를 **센다**.  '' · None · NaN 은 전부 결측이다.

    ⚠ `0` 은 결측이 **아니다** — 무접촉 AM 의 coverage 0.0 은 유효한 측정이다
      (`DESC-05`: *"없는 AM_P → N/A, 존재하는데 무접촉 → 0.0"*).  둘을 같이 세면
      바로 그 결함을 검사기가 재생산한다.
    """
    out = {}
    for c in DESCRIPTORS:
        n = 0
        for r in rows:
            v = r.get(c, '')
            if v is None or (isinstance(v, str) and not v.strip()):
                continue
            if isinstance(v, float) and v != v:            # NaN
                continue
            n += 1
        out[c] = n
    return out


def require_descriptors(rows, cols, path='<rows>'):
    """측정 열을 읽기 **전에** 부른다.  결측이 하나라도 있으면 **거부**한다 (`LHS-02`).

    ⛔ 호출자가 이것을 부르지 않고 `float(r[c] or 0)` 를 쓰면 결측이 **0 이라는 측정**이 된다.
    """
    fill = descriptor_fill(rows)
    bad = {c: fill.get(c, 0) for c in cols if fill.get(c, 0) < len(rows)}
    if bad:
        raise ValueError(
            f'{path}: 측정 열이 비어 있다 — ' +
            ' · '.join(f'{c} {n}/{len(rows)}' for c, n in bad.items()) +
            f'.  결측을 0 으로 채우지 말 것 (원장 LHS-02 · GAP2-05).  '
            f'채우려면: {DESCRIPTOR_FILL_EXPECTED["harvester"]}')
    return fill


#  ═══ `LHS-02` 수리 — 수확 산출물을 설계 CSV 에 **합친다** (2026-09-19) ══════════════
#  ⛔ 세 가지를 **동시에** 지킨다.  하나라도 빼면 이 병합이 결함의 새 자리가 된다.
#   `DESC-07` — 일곱 중 **둘은 정의 종속**이다.  병합 시점에 항등식을 **다시 검증**하고
#     열에 `_derived` 표시를 남긴다 (일곱 독립 타깃으로 세는 것을 막는다).
#   `DESC-08` — **291 코퍼스와 합치지 않는다.**  이 병합은 설계 130 ↔ 수확 130 뿐이다.
#   `DESC-09` — 미실행이 **무작위 결측이 아니다**.  ⇒ 부분 채움을 **금지**한다: 조인이
#     양방향 전단사가 아니면 거부한다 (반쪽 채움은 "한 수준이 통째로 빈" 것을 숨긴다).
#  ★ 그리고 `GAP2-05` 의 자리: **status ≠ OK 인 칸에는 숫자를 안 쓴다.**  빈 칸 + 사유
#    열이다.  0 을 쓰면 그 즉시 '측정된 0' 이 된다.
DESCRIPTOR_STATUS_KEY = {
    'phi_se': 'phi', 'phi_am': 'phi',
    'coverage_AM_P_hertz_pct': 'coverage_AM_P',
    'coverage_AM_S_hertz_pct': 'coverage_AM_S',
    'coverage_AM_total_hertz_pct': 'coverage_AM_total',
    'tortuosity_dijkstra_SE': 'tortuosity',
    'porosity_sphere_pct_RECORD_ONLY': 'porosity',
}
#: `DESC-07` — 이 둘은 **나머지로부터 유도**된다.  기록은 하되 독립 타깃이 아니다.
DERIVED_DESCRIPTORS = ('porosity_sphere_pct_RECORD_ONLY', 'coverage_AM_total_hertz_pct')
#: 항등식 허용오차.  ① 은 부동소수(실측 2.8e-14) · ② 는 실측 **정확히 0**.
DESC07_TOL = {'porosity': 1e-9, 'coverage_total': 1e-9}


class FillRefusal(RuntimeError):
    """병합이 조용히 반쪽으로 되는 것을 막는다 (`DESC-09`)."""


def _desc07_check(h):
    """수확 한 건에서 `DESC-07` 두 항등식을 **다시** 잰다 → (err_porosity, err_cov or None)."""
    e1 = abs(float(h['porosity_sphere_pct_RECORD_ONLY'])
             - 100.0 * (1.0 - float(h['phi_se']) - float(h['phi_am'])))
    cp, cs, ct = (h['coverage_AM_P_hertz_pct'], h['coverage_AM_S_hertz_pct'],
                  h['coverage_AM_total_hertz_pct'])
    if cp is None or cs is None:            # mono 침대 — 상이 하나라 가중평균이 정의 안 된다
        return e1, None
    cnt = h['coverage_detail']['counts']
    npp, ns = int(cnt['AM_P']['n_valid']), int(cnt['AM_S']['n_valid'])
    if npp + ns == 0:
        return e1, None
    return e1, abs((npp * float(cp) + ns * float(cs)) / (npp + ns) - float(ct))


def load_harvest(dir_path):
    """수확 JSON 들을 `case → dict` 로.  `_batch_summary.json` 은 케이스가 아니다."""
    d = pathlib.Path(dir_path)
    if not d.is_dir():
        raise FillRefusal(f'수확 디렉터리가 없다: {d}')
    out = {}
    for p in sorted(d.glob('*.json')):
        if p.name.startswith('_'):
            continue
        h = json.loads(p.read_text(encoding='utf-8'))
        case = h.get('case')
        if not case:
            raise FillRefusal(f'{p.name}: `case` 가 없다')
        if case in out:
            raise FillRefusal(f'수확에 같은 case 가 둘: {case}')
        h['_file'], h['_sha256'] = p.name, hashlib.sha256(p.read_bytes()).hexdigest()
        out[case] = h
    if not out:
        raise FillRefusal(f'{d}: 수확 JSON 이 하나도 없다')
    return out


def fill_descriptors(rows, harvest, key='case_id'):
    """설계 행에 측정 열 + `<열>_status` 를 채운다.  **전단사가 아니면 거부**한다.

    반환 = (채워진 행, 보고 dict).  ⚠ 행은 **제자리에서** 바뀐다.
    """
    have = {r[key] for r in rows}
    miss_h = sorted(have - set(harvest))
    miss_d = sorted(set(harvest) - have)
    if miss_h or miss_d:
        raise FillRefusal(
            f'조인이 전단사가 아니다 — 수확에 없는 설계 {len(miss_h)}건 {miss_h[:5]} · '
            f'설계에 없는 수확 {len(miss_d)}건 {miss_d[:5]}.  '
            '부분 채움은 `DESC-09`(결측이 무작위가 아니다)를 숨긴다 ⇒ 전부이거나 아무것도 아니다.')

    rep = {'n_rows': len(rows), 'filled': {c: 0 for c in DESCRIPTORS},
           'status_tally': {c: {} for c in DESCRIPTORS},
           'desc07_max_err': {'porosity': 0.0, 'coverage_total': 0.0,
                              'n_coverage_checked': 0},
           'derived': list(DERIVED_DESCRIPTORS), 'sources': {}}
    for r in rows:
        h = harvest[r[key]]
        e1, e2 = _desc07_check(h)
        rep['desc07_max_err']['porosity'] = max(rep['desc07_max_err']['porosity'], e1)
        if e1 > DESC07_TOL['porosity']:
            raise FillRefusal(f'{r[key]}: DESC-07 ① 항등식 위반 {e1:.3e} > {DESC07_TOL["porosity"]:.0e} '
                              '— porosity 가 φ 둘에서 유도되지 않는다면 프레임이 섞인 것이다')
        if e2 is not None:
            rep['desc07_max_err']['coverage_total'] = max(
                rep['desc07_max_err']['coverage_total'], e2)
            rep['desc07_max_err']['n_coverage_checked'] += 1
            if e2 > DESC07_TOL['coverage_total']:
                raise FillRefusal(f'{r[key]}: DESC-07 ② 가중평균 항등식 위반 {e2:.3e} '
                                  '— C_total 이 (N_P C_P + N_S C_S)/(N_P+N_S) 가 아니다')
        for c in DESCRIPTORS:
            st = h['status'][DESCRIPTOR_STATUS_KEY[c]]
            v = h.get(c)
            #  ★ 여기가 `GAP2-05` 의 자리다 — 상태가 OK 가 아니면 **숫자를 안 쓴다**.
            if st == 'OK':
                if v is None:
                    raise FillRefusal(f'{r[key]}.{c}: status 가 OK 인데 값이 없다')
                r[c] = repr(float(v))
                rep['filled'][c] += 1
            else:
                if v is not None:
                    raise FillRefusal(f'{r[key]}.{c}: status={st} 인데 값이 있다 ({v!r}) '
                                      '— 실패에 값이 붙으면 그 값이 측정으로 읽힌다')
                r[c] = ''
            r[c + '_status'] = st
            rep['status_tally'][c][st] = rep['status_tally'][c].get(st, 0) + 1
        rep['sources'][r[key]] = {
            'harvest_json': h['_file'], 'harvest_sha256': h['_sha256'],
            'atom_sha256': h['raw']['atom']['sha256'],
            'contact_sha256': h['raw']['contact']['sha256'],
            'timestep': h['timestep']}
    return rows, rep


def diagnostics(rows):
    """설계행렬이 실제로 쓸 만한지 — 상관·1D 균일·최소거리."""
    A = np.array([[r[f] for f in FACTORS] for r in rows if r['block'] == 'bimodal'])
    if len(A) < 3:
        return {}
    lo = np.array([RANGES[f][0] for f in FACTORS])
    hi = np.array([RANGES[f][1] for f in FACTORS])
    U = (A - lo) / (hi - lo)
    C = np.corrcoef(U.T)
    off = C[~np.eye(len(FACTORS), dtype=bool)]
    d2 = ((U[:, None, :] - U[None, :, :]) ** 2).sum(-1)
    d2[np.diag_indices(len(U))] = np.inf
    #  1-D 균일: 각 인자를 5 구간으로 나눠 최소 점유 (층화 LHS 면 균등해야 한다)
    occ = [int(np.histogram(U[:, j], bins=5, range=(0, 1))[0].min()) for j in range(len(FACTORS))]
    #  ★ 정수 격자에서는 **중복 설계점**이 생길 수 있다 (연속 LHS 에는 없던 실패 모드).
    #    같은 조성을 두 번 돌리는 것은 예산 낭비이고, 학습기에는 가짜 정밀도로 보인다.
    keys = [tuple(round(r[f], 6) for f in FACTORS) for r in rows if r['block'] == 'bimodal']
    dup = len(keys) - len(set(keys))
    #  수준별 점유 (균형 배정이 실제로 됐는지)
    lv = {}
    for f in FACTORS:
        L = levels_of(f, PS_INTERIOR)
        c = {v: 0 for v in L}
        for r in rows:
            if r['block'] == 'bimodal':
                c[round(r[f], 6)] = c.get(round(r[f], 6), 0) + 1
        lv[f] = f'{len(L)}수준 · 점유 {min(c.values())}–{max(c.values())}'
    #  ⚠ `min_bin_occupancy_of_5` 는 **연속 모드용** 지표다.  정수 격자에서는 수준 위치가
    #    5 등분 경계와 안 맞아 빈 구간이 생긴다 (예: d_se 4수준 → 5구간 중 하나는 구조적으로 0).
    #    ⇒ 정수 모드의 정본은 `levels` 의 **수준 점유**다.
    return {'n_bimodal': int(len(A)),
            'max_abs_offdiag_corr': round(float(np.abs(off).max()), 4),
            'min_pairwise_dist_unit': round(float(np.sqrt(d2.min())), 4),
            'min_bin_occupancy_of_5_CONTINUOUS_ONLY': occ,
            'duplicate_design_points': int(dup),
            'levels': lv}


#  ═══ 인계표 — 설계축을 밖(ML 담당)으로 넘긴다 (`LHS-02` 후속, 2026-09-19) ═════════
#  ⛔ 세 가지가 이 내보내기의 계약이다.  하나라도 빼면 받는 쪽이 조용히 틀린다.
#   ① **τ 값 열을 넣지 않는다** — `LHS-08` 이 열려 있어 `NOT_PERCOLATING` 이 두 원인을
#      접고 있다.  열이 CSV 에 있으면 학습에 들어간다("있으니까 쓴다").  대신 **왜 없는지**
#      를 `tau_*` 진단 열로 넘긴다.
#   ② **status ≠ OK 인 칸은 빈칸**이고 사유는 옆 열에 있다 (`GAP2-05`).  0 이 아니다.
#   ③ **유도열을 표시**한다 (`DESC-07`) — 일곱을 독립 타깃으로 세는 것을 막는다.
HANDOVER_VALUE_COLS = ('phi_se', 'phi_am',
                       'coverage_AM_P_hertz_pct', 'coverage_AM_S_hertz_pct',
                       'coverage_AM_total_hertz_pct', 'porosity_sphere_pct_RECORD_ONLY')
#: ⛔ 인계표에서 **제외**하는 열 (사유를 남긴다 — 조용히 빠지면 안 된다).
HANDOVER_HELD_BACK = {
    'tortuosity_dijkstra_SE': 'LHS-08 열림 — 130 중 14 만 값이 있고 `NOT_PERCOLATING` 이 '
                              '규약 실패와 물리 미관통을 **한 값으로 접는다**.  재수확 뒤 공급.  '
                              '↪ J20 (09-28): 벽 규약 τ 를 **새 열** `tortuosity_SE_wall` 로 공급 — 이 옛 규약 열은 계속 보류.',
}
#: 기본 수확 스냅샷 — ⛔ 옛 판 (20260919) 은 분모 바닥 · 이른 메시 (LHS-10 · 11) 로 폐기됐다.  조용히 옛 판을 가리키지 않는다 (HND-04).
#: 2026-09-28 (J19): 20260924 → **20260925** — 0924 JSON 에는 `handover_qc` (두께 · 벽 QC · 적격성) 가 없어 HND-04 열이 빈칸으로 나갔고
#:   (J18 기록: *"09-24 스냅샷 JSON 에는 handover_qc 가 없다 ⇒ 재수확 v2 뒤 인계표 재생성"*), union 병기의 짝 검사 (두께) 도 설 수 없다.
#:   0925 는 0924 를 대체한다 — 공통 값 Δ = 0 (그 README).
DEFAULT_HARVEST_DIR = 'docs/data/lhs_descriptors_20260925'
#: 수확 JSON 에서 **추가로** 실어 보내는 것 (새 계산 0 — 이미 측정돼 있다).
#: ★ HND-04 (Codex 09-25, 비준): 벽 QC · 적격성 · 규약 ID · sha 를 CSV 로 **실어 나른다** — JSON 에만 두고 CSV 에서 버리면 계약 실패.
HANDOVER_EXTRA = (
    ('n_AM_P_measured',      ('phase_counts', 'AM_P'),                      '실측 입자수 (설계의 n_*_est 는 추정)'),
    ('n_AM_S_measured',      ('phase_counts', 'AM_S'),                      '실측 입자수'),
    ('n_SE_measured',        ('phase_counts', 'SE'),                        '실측 입자수'),
    ('cov_AM_P_n_valid',     ('coverage_detail', 'counts', 'AM_P', 'n_valid'), '피복 평균의 분모'),
    ('cov_AM_S_n_valid',     ('coverage_detail', 'counts', 'AM_S', 'n_valid'), '피복 평균의 분모'),
    ('cov_n_capped',         ('coverage_detail', 'n_capped'),               'c_i 가 100 %% 로 잘린 횟수'),
    ('cov_n_free_surf_invalid', ('coverage_detail', 'n_free_surface_invalid'), 'F_i <= 0 분모붕괴 (DESC-05)'),
    ('closure_residual',     ('closure_residual',),                         'phi 닫힘 잔차 (QC)'),
    ('tau_status',           ('status', 'tortuosity'),                      'tau 가 왜 없는지'),
    ('tau_n_sampled',        ('tau_detail', 'n_sampled'),                   'tau 진단'),
    ('tau_n_valid',          ('tau_detail', 'n_valid'),                     'tau 진단'),
    ('tau_n_truncated',      ('tau_detail', 'n_truncated'),                 'tau 진단'),
    ('tau_convention',       ('tau_detail', 'tau_convention'),              'tau 규약 문자열'),
    ('plate_z_sim',          ('plate_z_sim',),                              '플래튼 z (sim)'),
    ('plate_z_source',       ('plate_z_source',),                           '플래튼 출처'),
    ('V_box_sim',            ('V_box_sim',),                                '상자 부피 (sim)'),
    ('timestep',             ('timestep',),                                 '읽은 덤프 스텝'),
    ('area_channel',         ('area_channel',),                             'L1-04 — 피복 면적이 무엇인가'),
    ('atom_sha256',          ('raw', 'atom', 'sha256'),                     '원자료 추적'),
    #  ── 두께 · 등록 alias 의 정본 의미 (Codex Q1 · Q2) ──
    ('thickness_wall_gap_um', ('handover_qc', 'thickness_wall_gap_um'),     '주 두께 — 같은 프레임의 플래튼 − 바닥 (z = 0) 간격, sim × 1e3'),
    ('phi_se_spheresum_nominal_gap', ('handover_qc', 'phi_se_spheresum_nominal_gap'), 'phi_se 의 정본 이름 — 명목 구 부피 / 틀 간격 부피 (장부값, 틀 안 점유율 아님)'),
    ('phi_am_spheresum_nominal_gap', ('handover_qc', 'phi_am_spheresum_nominal_gap'), 'phi_am 의 정본 이름'),
    ('porosity_spheresum_nominal_gap_pct', ('handover_qc', 'porosity_spheresum_nominal_gap_pct'), 'porosity 등록 열의 정본 이름 (독립 타깃 아님)'),
    #  ── 보조 지표 — (나) 등가 산술값 · (다) ROI clipped (둘 다 합집합 점유율 아님) ──
    ('thickness_pushback_equiv_um', ('handover_qc', 'thickness_pushback_equiv_um'), '(나) 벽 밖 부피를 두께에 더한 등가값 — hard-bottom 예측 아님 (HND-01)'),
    ('porosity_pushback_equiv_pct', ('handover_qc', 'porosity_pushback_equiv_pct'), '(나) 등가 porosity'),
    ('phi_se_clipped_spheresum_gap', ('handover_qc', 'phi_se_clipped_spheresum_gap'), '(다) 벽 밖 cap 을 뺀 ROI 값'),
    ('phi_am_clipped_spheresum_gap', ('handover_qc', 'phi_am_clipped_spheresum_gap'), '(다) ROI 값'),
    ('porosity_clipped_spheresum_gap_pct', ('handover_qc', 'porosity_clipped_spheresum_gap_pct'), '(다) ROI porosity'),
    #  ── 외피 진단 (실험 두께의 자동 대체물 아님) ──
    ('solid_bottom_um',      ('handover_qc', 'solid_bottom_um'),            'min(z − r) × 1e3'),
    ('solid_top_um',         ('handover_qc', 'solid_top_um'),               'max(z + r) × 1e3'),
    ('thickness_envelope_um', ('handover_qc', 'thickness_envelope_um'),     '외피 높이 — 극값 하나에 좌우될 수 있다'),
    ('plate_minus_solid_top_um', ('handover_qc', 'plate_minus_solid_top_um'), '플래튼 − 고체 윗면 (같은 step 메시면 작다, LHS-11)'),
    #  ── 부피 감사 (겹침 중복을 포함하는 구 합, µm³) ──
    ('V_AM_full_um3',        ('handover_qc', 'V_AM_full_um3'),              'AM 명목 구 부피 합'),
    ('V_SE_full_um3',        ('handover_qc', 'V_SE_full_um3'),              'SE 명목 구 부피 합'),
    ('V_AM_out_floor_um3',   ('handover_qc', 'V_AM_out_floor_um3'),         'AM 바닥 밖 cap 부피'),
    ('V_AM_out_plate_um3',   ('handover_qc', 'V_AM_out_plate_um3'),         'AM 플래튼 밖 cap 부피'),
    ('V_SE_out_floor_um3',   ('handover_qc', 'V_SE_out_floor_um3'),         'SE 바닥 밖 cap 부피'),
    ('V_SE_out_plate_um3',   ('handover_qc', 'V_SE_out_plate_um3'),         'SE 플래튼 밖 cap 부피'),
    #  ── 경계 QC (HND-03) ──
    ('n_floor_center_out',   ('handover_qc', 'n_floor_center_out'),         '중심이 바닥 평면 아래인 입자 수'),
    ('n_floor_fully_out',    ('handover_qc', 'n_floor_fully_out'),          '통째로 바닥 아래인 입자 수'),
    ('n_plate_center_out',   ('handover_qc', 'n_plate_center_out'),         '중심이 플래튼 위인 입자 수'),
    ('n_plate_fully_out',    ('handover_qc', 'n_plate_fully_out'),          '통째로 플래튼 위인 입자 수'),
    ('floor_out_pct',        ('handover_qc', 'floor_out_pct'),              '바닥 밖 부피 / ΣV (백분율)'),
    ('plate_out_pct',        ('handover_qc', 'plate_out_pct'),              '플래튼 밖 부피 / ΣV (백분율)'),
    ('floor_outside_cap_depth_over_r_max', ('handover_qc', 'floor_outside_cap_depth_over_r_max'), '가장 깊은 입자의 cap 깊이/r (접촉 겹침 아님)'),
    ('floor_deepest_contact_overlap_over_r', ('handover_qc', 'floor_deepest_contact_overlap_over_r'), '그 입자의 접촉 겹침/r = (r − |dist|)/r'),
    ('floor_deepest_phase',  ('handover_qc', 'floor_deepest_phase'),        '가장 깊은 입자의 상'),
    ('floor_deepest_r_um',   ('handover_qc', 'floor_deepest_r_um'),         '그 입자의 반지름'),
    ('floor_deepest_z_um',   ('handover_qc', 'floor_deepest_z_um'),         '그 입자의 중심 z'),
    ('plate_outside_cap_depth_over_r_max', ('handover_qc', 'plate_outside_cap_depth_over_r_max'), '플래튼 쪽 가장 깊은 입자의 cap 깊이/r'),
    ('boundary_state',       ('handover_qc', 'boundary_state'),             'INSIDE | CENTER_CROSSED | FULLY_OUT — 바닥 (z = 0) · 플래튼 평면 기준 (같은 프레임 · 수확기 wall_record): '
                                                                            '중심이 평면을 넘은 입자가 있으면 CENTER_CROSSED · 통째로 평면 밖인 입자가 있으면 FULLY_OUT · 없으면 INSIDE'),
    #  ── 적격성 (HND-04) — 숫자 산출 성공과 물리/ML 용도 허용을 분리 ──
    ('calculation_status',   ('handover_qc', 'calculation_status'),         '계산 상태 (명목 규약값)'),
    ('physical_target_status', ('handover_qc', 'physical_target_status'),   'OK | HOLD — 물리적 전극 구조 타깃으로 쓸 수 있는가 (HND-04 — 계산 상태와 분리) · HOLD = hold_reason_codes 가 하나라도 있다 · '
                                                                            '값은 그대로 계산됐다 (calculation_status (정본 인계표 열) OK) · 배포 v1.1 부터 함께 싣는다 — 거를지는 쓰는 쪽이 정한다 · '
                                                                            '정합 규칙 = 생성기 eligibility_problems (LREL-02 — 세 열이 다 있고 HOLD ⟺ 코드 ≥ 1 · BOUNDARY_CENTER_OUT ⟺ boundary_state ≠ INSIDE)'),
    ('hold_reason_codes',    ('handover_qc', 'hold_reason_codes'),          'BOUNDARY_CENTER_OUT = 중심이 바닥 · 플래튼 평면 밖인 입자 ≥ 1 (정상 압입과 구분 · HND-03) · '
                                                                            'NEGATIVE_POROSITY = 구 부피 합 porosity < 0 (= 구 부피 합 φ_SE + φ_AM > 1 · 겹침이 큰 침대 · HND-04 · LHS-15) — '
                                                                            '배포 porosity (정확 union) 는 이 경우에도 양수다 · 여러 개면 | 로 잇는다'),
    ('phi_sum_gt_one',       ('handover_qc', 'phi_sum_gt_one'),             'phi_se + phi_am > 1'),
    #  ── τ 밴드 진단 (LHS-08 · Codex §8-3) — 보고 τ 는 여전히 보류 열 ──
    ('tau_n_bot',            ('tau_detail', 'band_detail', 'n_bot'),        'solid_zrange 아래 밴드의 SE 인원'),
    ('tau_n_top',            ('tau_detail', 'band_detail', 'n_top'),        'solid_zrange 위 밴드의 SE 인원'),
    ('tau_wall_n_bot',       ('tau_detail', 'band_detail', 'wall_n_bot'),   '벽 (z = 0) 기준 아래 밴드의 SE 인원 (진단)'),
    ('tau_wall_n_top',       ('tau_detail', 'band_detail', 'wall_n_top'),   '플래튼 기준 위 밴드의 SE 인원 (진단)'),
    ('tau_wall_n_span_components', ('tau_detail', 'band_detail', 'wall_n_span_components'), '벽 밴드 둘을 잇는 SE 성분 수 (진단)'),
    #  ── 프로비넌스 ──
    ('measurement_protocol_id', ('handover_qc', 'measurement_protocol_id'), '측정 규약 ID'),
    ('boundary_model_id',    ('handover_qc', 'boundary_model_id'),          '경계 모델 ID (바닥 primitive 의 물성 type · 플래튼 메시)'),
    ('scale_sim_per_um',     ('handover_qc', 'scale_sim_per_um'),           'sim 단위 / µm'),
    ('deck_floor_z_sim',     ('deck_floor', 'z'),                           '덱에서 읽은 활성 바닥 벽 z'),
    ('deck_wall_type',       ('handover_qc', 'deck_wall_type'),             '바닥 벽의 물성 type (LHS: SE)'),
    ('contact_sha256',       ('handover_qc', 'contact_sha256'),             '원자료 추적'),
    ('deck_sha256',          ('handover_qc', 'deck_sha256'),                '원자료 추적'),
    ('mesh_sha256',          ('handover_qc', 'mesh_sha256'),                '원자료 추적'),
)


#: ★ LREL-02 (Codex 배포 v1.1 최종 리뷰 10-01 §3 · 1저자 비준 10-06) — 적격성 표지 계약 = 수확기 판정 규칙 그대로
#:   (`lhs_descriptor_harvest` boundary: FULLY_OUT = 통째로 평면 밖 ≥ 1 · CENTER_CROSSED = 중심이 평면 밖 ≥ 1 · 그 밖 INSIDE ·
#:   hold_reason_codes ⊆ {BOUNDARY_CENTER_OUT (중심 밖 ≥ 1) · NEGATIVE_POROSITY (구 부피 합 porosity < 0)} ('|' 로 잇기 · 중복 없음) ·
#:   physical_target_status = HOLD ⟺ 코드 ≥ 1).  옛 생성기는 수확의 세 값이 None 이어도 빈칸 행을 정상 생성했다 (Codex drop_eligibility).
#:   생성기 · 배포 프로필 (`lhs_release_build --profile`) 이 같은 함수를 쓴다 (사본 금지 — 규율 ①).  10-06 실측: 130 · 64 전 행 정합.
ELIGIBILITY_COLS = ('physical_target_status', 'hold_reason_codes', 'boundary_state')
ELIGIBILITY_STATUS = ('OK', 'HOLD')
ELIGIBILITY_CODES = ('BOUNDARY_CENTER_OUT', 'NEGATIVE_POROSITY')
ELIGIBILITY_BOUNDARY = ('INSIDE', 'CENTER_CROSSED', 'FULLY_OUT')
ELIGIBILITY_COUNTS = ('n_floor_center_out', 'n_plate_center_out', 'n_floor_fully_out', 'n_plate_fully_out')


def eligibility_problems(rec, porosity_pct=None):
    """적격성 표지 한 행 → 문제 목록 ([] = 정합).  rec = 수확 `handover_qc` (dict) 또는 표의 한 행 (문자열 칸).

    필수 — 세 열 (ELIGIBILITY_COLS) 이 있고 None 이 아니다 · 허용 값 · 코드 중복 없음 · HOLD ⟺ 코드 ≥ 1 · BOUNDARY_CENTER_OUT ⟺ boundary ≠ INSIDE.
    있으면 함께 — calculation_status = OK · 벽 밖 개수 (ELIGIBILITY_COUNTS) ↔ boundary (중심 밖 합 > 0 ⟺ ≠ INSIDE · 통째로 밖 합 > 0 ⟺ FULLY_OUT) ·
    porosity_pct (구 부피 합) < 0 ⟺ NEGATIVE_POROSITY · phi_sum_gt_one ⟺ NEGATIVE_POROSITY."""
    rec = rec if isinstance(rec, dict) else {}
    prob = []
    miss = [c for c in ELIGIBILITY_COLS if rec.get(c) is None]
    if miss:
        return [f'적격성 표지 없음 {miss} (None · 키 없음 — 빈칸 표지 행을 만들지 않는다)']
    st, b, raw = str(rec['physical_target_status']), str(rec['boundary_state']), rec['hold_reason_codes']
    codes = [str(x) for x in raw] if isinstance(raw, (list, tuple)) else [x for x in str(raw).split('|') if x != '']
    if st not in ELIGIBILITY_STATUS:
        prob.append(f'physical_target_status {st!r} ∉ {ELIGIBILITY_STATUS}')
    if b not in ELIGIBILITY_BOUNDARY:
        prob.append(f'boundary_state {b!r} ∉ {ELIGIBILITY_BOUNDARY}')
    bad_c = [c for c in codes if c not in ELIGIBILITY_CODES]
    if bad_c:
        prob.append(f'hold_reason_codes 의 모르는 코드 {bad_c} (허용 {ELIGIBILITY_CODES})')
    if len(codes) != len(set(codes)):
        prob.append(f'hold_reason_codes 중복 {codes}')
    if (st == 'HOLD') != bool(codes):
        prob.append(f'physical_target_status {st} ↔ 보류 코드 {codes} — HOLD ⟺ 코드 ≥ 1')
    if ('BOUNDARY_CENTER_OUT' in codes) != (b != 'INSIDE'):
        prob.append(f'boundary_state {b} ↔ BOUNDARY_CENTER_OUT {"있음" if "BOUNDARY_CENTER_OUT" in codes else "없음"} — 중심이 평면 밖인 입자가 있으면 둘 다')
    cs = rec.get('calculation_status')
    if cs is not None and str(cs) != 'OK':
        prob.append(f'calculation_status {cs!r} ≠ OK')

    def _int(v):
        try:
            f_ = float(v)
        except (TypeError, ValueError):
            return None
        return int(f_) if math.isfinite(f_) and f_ == int(f_) and f_ >= 0 else None
    if any(rec.get(k) not in (None, '') for k in ELIGIBILITY_COUNTS):
        n_ = {k: _int(rec.get(k)) for k in ELIGIBILITY_COUNTS}
        if None in n_.values():
            prob.append(f'벽 밖 개수가 0 이상 정수가 아니다 {[k for k, v in n_.items() if v is None]}')
        else:
            co, fo = n_['n_floor_center_out'] + n_['n_plate_center_out'], n_['n_floor_fully_out'] + n_['n_plate_fully_out']
            if (co > 0) != (b != 'INSIDE') or (fo > 0) != (b == 'FULLY_OUT') or fo > co:
                prob.append(f'boundary_state {b} ↔ 벽 밖 개수 (중심 밖 {co} · 통째로 밖 {fo})')
    if porosity_pct is not None:
        try:
            p_ = float(porosity_pct)
        except (TypeError, ValueError):
            p_ = float('nan')
        if not math.isfinite(p_):
            prob.append(f'구 부피 합 porosity {porosity_pct!r} 가 유한하지 않다 — NEGATIVE_POROSITY 를 확인할 수 없다')
        elif (p_ < 0) != ('NEGATIVE_POROSITY' in codes):
            prob.append(f'구 부피 합 porosity {p_!r} ↔ NEGATIVE_POROSITY {"있음" if "NEGATIVE_POROSITY" in codes else "없음"}')
    g = rec.get('phi_sum_gt_one')
    if g is not None and str(g) in ('True', 'False') and (str(g) == 'True') != ('NEGATIVE_POROSITY' in codes):
        prob.append(f'phi_sum_gt_one {g} ↔ NEGATIVE_POROSITY')
    return prob


#: J19 (1저자 비준 2026-09-28 — docs/reviews/pure_se_union_prereg_20260927.md §6-2 · lhs_handover_judgments_20260924.md J19) —
#:   겹침 보정 porosity 를 **병기**한다.  구 부피 합 열 (`porosity_sphere_pct_RECORD_ONLY`) 은 J1 대로 **그대로** 남는다 — 교체가 아니다
#:   (CLAUDE.md porosity 규약 · 생산 코퍼스가 그 규약을 공유한다).  ⛔ φ_SE · φ_AM 의 union 판은 **넣지 않는다** (AM–SE 겹침 배분 = 별도 저자
#:   결정) · 물리 타깃 적격성 (`physical_target_status`) 도 **안 바꾼다** (§6-2 비준 범위 밖).
#:   ↪ J20-e (1저자 09-29 밤 "φ 는 (라) 만"): 겹침 배분이 필요 없는 **질량 보존 φ** 두 열을 넣는다 (인계 두께 · union porosity 와 같은 장부) —
#:     union 점유 φ ((가)~(다) · 겹침 배분) 는 여전히 넣지 않는다.
DEFAULT_UNION_TSV = 'docs/data/lhs_union_20260927/lhs130_union.tsv'
#: SE-rich 문턱 (SE / 고체, 구 부피) — ⚠ 등록된 정의가 없어 선례를 따른 **도구 선택**이다 (저자 확인 항목):
#:   CLAUDE.md 신뢰성 regime map *"SE-rich (SE/sol ≳ 50 %) → DEM ε_sphere 과압축"* · union README *"음수 ε_sphere 는 SE/고체 0.5–0.6 칸부터"*.
#:   연속값 `se_of_solid_vol` 을 함께 내므로 받는 쪽이 문턱을 바꿀 수 있다.
SE_RICH_MIN = 0.50
#: union 행 ↔ 수확 짝 검사 허용치 — union README 실측 최대 차: 구 부피 합 5.6e-14 %p · 두께 0 µm
UNION_TOL = {'eps_sphere_pct': 1e-9, 'thickness_um': 1e-6}
#: J20-e — 질량 보존 φ 닫힘 (φ_SE + φ_AM + ε_union = 1) 허용치.  식으로는 정확하다 — 넘으면 DESC-07 (φ 둘 ↔ ε_sphere) 이 깨진 것이다.
PHI_MC_CLOSURE_TOL = 1e-9
#: LREL-04 — union se_of_solid_vol ↔ 수확 V_SE/(V_SE + V_AM) · φ_SE/(φ_SE + φ_AM) 허용치 (같은 덤프 · 다른 코드 · 10-06 실측 최대 5.6e-16 — 부동소수 여유)
SE_SHARE_TOL = 1e-9
HANDOVER_UNION = (
    ('porosity_union_exact_pct',        'mc_void_pct',
     '★ 겹침 보정 porosity (정확 union — 상자 [0,Lx)×[0,Ly)×[0,plate_z) 무작위 점 · 세 입자 이상 겹침까지) — 물리 porosity 열 (J19) · '
     '"정확" = 합집합 정의 (쌍 렌즈 근사 아님) 이지 MC 오차 0 이 아니다 — 1σ = porosity_union_exact_se_pct (정본 인계표 열) (10-06 실측 130: '
     '0.012–0.023 %p · 64: 0.011–0.015 %p) · 마지막 자리를 측정 정밀도로 인용하지 않는다 (LREL-06) · ⚠ 규약 한정 (J20-c ⓒ — 기록된 한정어 · '
     '규약 선택은 1저자 결정 대기): union 은 겹친 부피를 한 번만 세어 소성 압축의 고체를 과소계상하는 상한 규약이다 (CLAUDE.md E_SE 절 · '
     '재료 보존 쪽은 구 부피 합 ε_sphere) — 짝 = thickness_mass_conserving_um · phi_*_mass_conserving (같은 장부)'),
    ('porosity_union_exact_se_pct',     'mc_void_se_pct',         '위 값의 통계 오차 (1σ, %p)'),
    ('porosity_union_pair_clipped_pct', 'eps_union_pair_clipped', '검산 — 웹앱 쌍 렌즈 union − 벽 밖 부피 (세 입자 겹침 무시 · 상한)'),
    ('union_pair_upper_bound_ok',       'pair_upper_bound_ok',
     '쌍 렌즈 ≥ 정확 — False 면 접촉 덤프에 겹친 쌍이 빠졌다 (정확 union 은 원자만 써서 그래도 유효)'),
    ('se_of_solid_vol',                 'se_of_solid_vol',        'SE / 고체 (구 부피) — SE-rich 표지의 연속값'),
)
#: 유도 열 (union 행 + 수확에서 계산)
HANDOVER_UNION_DERIVED = (
    ('thickness_mass_conserving_um',
     '질량 보존 두께 = 두께 × (1 − ε_sphere)/(1 − ε_union) — union 을 실제 공극률로 받을 때 **같은 고체**의 두께 (DEM 에서 겹친 부피는 사라지므로 '
     'union 과 DEM 간격 두께를 둘 다 실제 값으로 받을 수 없다)'),
    ('se_rich', f'SE / 고체 ≥ {SE_RICH_MIN} (구 부피 합이 겹침 이중계상으로 퇴화하는 영역 — 문턱은 도구 선택, 연속값 옆 열)'),
    ('phi_se_mass_conserving',
     '★ 인계용 SE 부피분율 (J20-e (라) · 1저자 09-29 밤) — 질량 보존 φ = phi_se (정본 인계표 열) × (1 − ε_union)/(1 − ε_sphere) '
     '= SE 구 부피 / (L² · thickness_mass_conserving_um) = (1 − porosity_union_exact_pct/100) × se_of_solid_vol.  '
     '인계 두께 · union porosity 와 **같은 장부**: φ_SE + φ_AM + ε_union = 1 (정확) · φ × 인계 두께 = 레시피 적재량.  '
     '유도량 (두께 · 레시피로 정해짐 — 독립 측정 아님) · union 과 같은 상한 규약의 짝 (소성으로 밀려난 재료를 빈틈이 아니라 두께로 보낸다)'),
    ('phi_am_mass_conserving',
     '인계용 AM 부피분율 (J20-e (라)) — 같은 규약 = (1 − porosity_union_exact_pct/100) × (1 − se_of_solid_vol)'),
)


#: J20 (1저자 비준 2026-09-28 "벽 기준 τ 새 열") — 수확 v3 의 `tau_wall_detail` 을 **새 열**로 싣는다.  옛 τ (solid_zrange) 는
#:   HANDOVER_HELD_BACK 그대로 (LHS-08).  값 칸은 status OK 일 때만 (계약 ②) — 미관통을 0 이나 큰 수로 채우지 않는다.
#:   규약 문자열은 수확기 `lhs_descriptor_harvest.TAU_WALL_CONVENTION` 과 같아야 한다 (selftest ⑲n 이 둘을 맞댄다).
TAU_WALL_CONVENTION = 'harvest_v3/wall_z0_plate/rSEmax/no_fallback/same_component'
#: ★ 10-06 (v1.2 README §4 정정 → 생성기) — 벽 τ 뜻의 끝 = 수송 tortuosity 가 **어디 있는가**.  옛 문구 "· 이 표에 없음" 은 망 τ 묶음을 실은 v1.2 에서
#:   거짓이었다 (tau2_ion_hertz 가 바로 그 양).  column_dictionary 가 표의 열에 따라 둘 중 하나를 tortuosity_SE_wall 뜻 끝에 붙인다.
TAU_WALL_TRANSPORT_IN = ('수송 tortuosity 는 이 표의 tau2_ion_hertz — 수송 tortuosity factor T = φ_SE,mc/f_ion_hertz (제곱근 아님 · Hertz 기본 지표 · '
                         '√T = tau_ion_hertz) · 다른 모드 = tau2_ion_<모드> (정본 인계표 열) — 이 열 (기하학적) 과 다른 양이고 최소 조성도 다를 수 있다')
TAU_WALL_TRANSPORT_OUT = ('수송 tortuosity (망 단계 tau2 = φ_SE·σ₀/σ_full · 수송 tortuosity factor · 제곱근 아님) 는 망 τ 묶음 (--webapp-groups …,tau · '
                          '--tau-results) 을 실은 인계표의 tau2_ion_<모드> 열 — 이 표에는 없다')
HANDOVER_TAU_WALL = (
    ('tortuosity_SE_wall',        'tau_mean',
     '★ SE τ (벽 규약 · **기하 최단경로**) — 바닥 벽 (z = 0) 밴드와 플래튼 밴드 (밴드 두께 = r_SE,max · 입자 표면 기준) 를 **같은 SE 성분 '
     '안에서** 잇는 쌍의 SE 중심 경로 최단 길이 (Dijkstra · 가중 = 중심 거리 · x·y 주기) / 두 끝 중심의 z 거리 · 무작위 200 쌍 (seed 42 · '
     '쌍 평균이라 쌍이 많은 큰 성분 쪽으로 가중) · [1, 20) 절단 평균.  접촉 = 원자 좌표 기하 (d ≤ r_i + r_j) — 덤프 접촉과 같은 집합 (J20-a '
     '130/130).  status OK 일 때만 값 · 비관통은 빈칸 (N/A · 0 이 아니다).  ⚠ **수송 τ 가 아니다** — 협착 · 단면 병목을 보지 않아 1 근처에 '
     '모인다 (LHS 1.29–4.15 · lhsx 1.26–1.60) · 기하학적 tortuosity — 망 단계의 수송 tortuosity (tau2 = φ_SE·σ₀/σ_full) 와 다른 양 '
     '(τ 명명 규약 10-03 · TAU-01) · 관문 T1–T3 (10-01)'),
    ('tortuosity_SE_wall_median', 'tau_median',     '같은 표본의 중앙값 (status OK 일 때만) · 같은 한정어 (기하 최단경로 · 수송 τ 아님)'),
    ('tortuosity_SE_wall_status', 'status',
     'OK · NOT_PERCOLATING (벽 밴드 둘을 잇는 SE 성분이 없다 = 미관통 — 퍼콜레이션 percolation_pct 0 과 같은 집합 · 관문 T3) · '
     'ELECTRODE_BAND_EMPTY · NO_VALID_SAMPLED_PAIR · N_A_PHASE_ABSENT'),
    ('tau_wall_n_sampled',        'n_sampled',      '표본 쌍 수 (최대 200)'),
    ('tau_wall_n_valid',          'n_valid',        '경로가 난 표본 수'),
    ('tau_wall_n_truncated',      'n_truncated',    '[1, 20) 밖으로 잘린 수'),
    ('tau_wall_convention',       'tau_convention', '규약 문자열 (harvest_v3/wall_z0_plate/…)'),
)
TAU_WALL_VALUE = ('tortuosity_SE_wall', 'tortuosity_SE_wall_median')
#: v1.1 ③ (1저자 비준 10-01 *"비준이야"* · J20-o) — 가장 큰 SE 덩어리 (수확 v3 `tau_detail.band_detail` · 벽 τ 와 같은 SE 그래프 ·
#:   `lhs_descriptor_harvest.tortuosity_se`).  비관통 24 침대의 "관통에 얼마나 가까웠나" 연속 디스크립터 — 관통 침대에도 값이 있다 (≈ 1).
#:   수확기 원값의 분모는 **전 입자 (AM 포함) z 범위** 라 바닥 아래로 샌 입자에 끌린다 (벽 간격보다 3–20 % 큼 · LHS 중앙 7 %) →
#:   기록된 z_lo · z_hi · plate_z 로 벽 간격 기준 값을 **정확히** 환산한다 (수확기 재실행 없음).
HANDOVER_SE_CLUSTER = (
    ('se_largest_comp_frac',
     '★ 가장 큰 SE 덩어리 (SE 수 기준 가장 큰 연결 성분 · 원자 좌표 기하 접촉 d ≤ r_i + r_j · x·y 주기 — 벽 τ 와 같은 그래프) 에 든 SE 의 '
     '비율 (0–1) = 그 성분의 SE 수 / 전 SE (v1.1 ③ · 1저자 비준 10-01) · 관통 침대는 1 근처 (LHS 중앙 0.997) · 비관통 침대 0.002–0.91 · '
     '관문 C1 (× N_SE = 정수 개수 · N_SE = 수확 phase_counts)'),
    ('se_largest_comp_wall_span_frac',
     '★ 그 덩어리의 두께 방향 폭 / 벽 간격 (v1.1 ③) — 폭 = 덩어리 SE 의 max(z + r) − min(z − r) (입자 표면 기준) · 벽 간격 = 플래튼 plate_z − '
     '바닥 z 0 · 수확 기록값으로 정확히 환산 (= 수확 원값 × 전 입자 z 범위 / 벽 간격 · 재실행 없음) · 표면이 벽 · 플래튼과 겹쳐 1 을 넘을 수 '
     '있다 (관통 침대 LHS 1.01–1.05 · lhsx 1.02–1.06) · 비관통 침대 0.11–0.96 · ⚠ SE 수로 **가장 큰** 덩어리의 폭 — 가장 멀리 뻗은 덩어리가 '
     '아닐 수 있다 · 관문 C3 (플래튼 = 수확 plate_z_sim (정본 인계표 열) · 바닥 = z_floor_sim)'),
    ('se_largest_comp_env_span_frac',
     '참고 (내부) — 수확기 원값 largest_comp_z_span_frac: 같은 폭 / **전 입자 (AM 포함) z 범위** max(z + r) − min(z − r) · ⚠ 분모가 바닥 '
     '아래로 샌 입자 · 벽과 겹친 입자에 끌려 벽 간격보다 3–20 % 크다 (LHS 중앙 7 %) → 침대마다 다르게 작아진다 · 인계는 '
     'se_largest_comp_wall_span_frac 을 쓴다 · 관문 C2 (≤ 1 — 덩어리 ⊂ 전 입자)'),
)


def _se_cluster_cols(case, h):
    """v1.1 ③ 값 + 관문 (fail-closed) — 수확 `tau_detail.band_detail` 의 가장 큰 SE 덩어리 기록이 **이 침대의 SE · 이 판**의 것인가.

      C1 SE 수: band n_se = 수확 phase_counts SE (정수 > 0) · 0 < 비율 ≤ 1 · 비율 × n_se = 정수 개수
      C2 z 폭: 0 < 전 입자 z 범위 대비 폭 ≤ 1 (덩어리 ⊂ 전 입자) · z_hi > z_lo
      C3 벽 간격: band 플래튼 = 수확 plate_z_sim · 바닥 = z_floor_sim (있으면) · 플래튼 > 바닥
    반환 {열: 값 문자열}.  어긋나면 `FillRefusal` (메시지에 'v1.1 C<n>')."""
    def _int(x):
        return isinstance(x, int) and not isinstance(x, bool)

    def _num(x):
        return isinstance(x, (int, float)) and not isinstance(x, bool) and math.isfinite(x)
    b = _dig(h, ('tau_detail', 'band_detail')) or {}
    pc = h.get('phase_counts')
    if not isinstance(pc, dict):
        raise FillRefusal(f'{case}: 수확 JSON 에 phase_counts 가 없다 — SE 수를 몰라 가장 큰 SE 덩어리를 확인할 수 없다 (v1.1 C1)')
    n_se, fr, zs = b.get('n_se'), b.get('largest_comp_frac'), b.get('largest_comp_z_span_frac')
    if not (_int(n_se) and n_se > 0 and n_se == _phase_n(pc, 'SE')):
        raise FillRefusal(f'{case}: 덩어리 기록의 SE 수 {n_se!r} ≠ 수확 phase_counts SE {_phase_n(pc, "SE")} — 다른 침대 · 다른 SE 집합이다 (v1.1 C1)')
    if not (_num(fr) and 0.0 < fr <= 1.0):
        raise FillRefusal(f'{case}: largest_comp_frac {fr!r} ∉ (0, 1] (v1.1 C1)')
    x = fr * n_se
    if abs(x - round(x)) > WA_COUNT_INT_TOL:
        raise FillRefusal(f'{case}: largest_comp_frac {fr!r} × SE {n_se} = {x!r} 이 정수 개수가 아니다 (v1.1 C1)')
    zlo, zhi, pz, fl = b.get('z_lo'), b.get('z_hi'), b.get('alt_plate_z'), b.get('wall_z_floor')
    if not (_num(zs) and 0.0 < zs <= 1.0 + 1e-12):
        raise FillRefusal(f'{case}: largest_comp_z_span_frac {zs!r} ∉ (0, 1] — 덩어리는 전 입자의 부분집합이다 (v1.1 C2)')
    if not (_num(zlo) and _num(zhi) and zhi > zlo):
        raise FillRefusal(f'{case}: 전 입자 z 범위 z_lo {zlo!r} · z_hi {zhi!r} 가 없거나 뒤집혔다 (v1.1 C2)')
    zf = h.get('z_floor_sim')
    if not (_num(pz) and pz == h.get('plate_z_sim') and _num(fl) and (zf is None or fl == zf) and pz > fl):
        raise FillRefusal(f'{case}: 덩어리 기록의 벽 간격 (플래튼 {pz!r} · 바닥 {fl!r}) ≠ 수확 plate_z_sim {h.get("plate_z_sim")!r} · '
                          f'z_floor_sim {zf!r} — 다른 판이다 (v1.1 C3)')
    return {'se_largest_comp_frac': repr(float(fr)),
            'se_largest_comp_wall_span_frac': repr(zs * (zhi - zlo) / (pz - fl)),
            'se_largest_comp_env_span_frac': repr(float(zs))}
#: 벽 τ 관문 상수 — 수확기 (`lhs_descriptor_harvest.TAU_LO · TAU_HI · N_TAU_PAIRS`) 와 같아야 한다 (selftest ㉓ 가 강제)
TAU_WALL_LO, TAU_WALL_HI, TAU_WALL_N_PAIRS = 1.0, 20.0, 200


def _tau_wall_gates(case, t, h):
    """벽 τ 관문 (fail-closed · 1저자 10-01 *"dijkstra tortuosity 벽을 확실하게 닫고 값을 추출"*) — 상태 ↔ 값 ↔ 표본 수 ↔ 관통 성분 수가
    **한 표본**에서 나왔는가.  10-01 실측 130/130 · 64/64 성립.

      T1 관통: n_span_components = 0 이상 정수 · OK ⟹ > 0 · NOT_PERCOLATING ⟹ 0 · 수확 `tau_detail.band_detail.wall_n_span_components` 가
         있으면 같아야 (같은 성분 · 같은 벽 밴드)
      T2 값 · 표본: OK ⟹ 평균 · 중앙값 ∈ [1, 20) · 0 < n_valid ≤ n_sampled ≤ 200 · 0 ≤ n_truncated < n_valid
      (T3 — 웹앱 percolation_pct 가 함께 실리면 NOT_PERCOLATING ⟺ percolation_pct = 0 — `build_handover` 가 행 끝에서 본다)
    반환 1.  어긋나면 `FillRefusal` (메시지에 'τ T<n>')."""
    def _int(x):
        return isinstance(x, int) and not isinstance(x, bool)

    def _num(x):
        return isinstance(x, (int, float)) and not isinstance(x, bool)
    st, nsc = t.get('status'), t.get('n_span_components')
    if not (_int(nsc) and nsc >= 0):
        raise FillRefusal(f'{case}: 벽 τ n_span_components {nsc!r} 가 0 이상 정수가 아니다 (τ T1)')
    span = _dig(h, ('tau_detail', 'band_detail', 'wall_n_span_components'))
    if span is not None and int(span) != nsc:
        raise FillRefusal(f'{case}: 벽 τ 관통 성분 {nsc} ≠ 수확 벽 밴드 진단 {span} — 같은 성분 · 같은 밴드가 아니다 (τ T1)')
    if (st == 'OK' and nsc <= 0) or (st == 'NOT_PERCOLATING' and nsc != 0):
        raise FillRefusal(f'{case}: 벽 τ 상태 {st} 인데 관통 성분 {nsc} (τ T1)')
    if st == 'OK':
        v, m = t.get('tau_mean'), t.get('tau_median')
        if not (_num(v) and _num(m) and TAU_WALL_LO <= v < TAU_WALL_HI and TAU_WALL_LO <= m < TAU_WALL_HI):
            raise FillRefusal(f'{case}: 벽 τ 평균 {v!r} · 중앙값 {m!r} 이 [1, 20) 밖 (τ T2)')
        ns_, nv, ntr = t.get('n_sampled'), t.get('n_valid'), t.get('n_truncated')
        if not (_int(ns_) and _int(nv) and _int(ntr) and 0 < nv <= ns_ <= TAU_WALL_N_PAIRS and 0 <= ntr < nv):
            raise FillRefusal(f'{case}: 벽 τ 표본 수 n_sampled {ns_!r} · n_valid {nv!r} · n_truncated {ntr!r} 가 규칙 밖 (τ T2)')
    return 1

#: J20 (1저자 비준 2026-09-28 "✅ 만 이번에" · "채운 뒤 넘김") — 웹앱 파이프라인을 **그대로** 돌린 열 (`scripts/lhs_webapp_batch.py`) 중
#:   09-19 전수 판정 (`docs/param_audit_report_20260919.md` §2) 이 ✅ 로 판정한 열만 싣는다 ('✅ 쓴다' · '✅ 쓴다(이름 주의)').
#:   ⛔ 🔶 (σ · fallback · τ(웹앱 폴백) · MPM · Stage E · 피복 문턱) · 🔧 (Physics) 는 **싣지 않는다**.  이름은 코퍼스 (case_master) 그대로.
DEFAULT_CENSUS_TSV = 'docs/data/case_master_column_census_20260919.tsv'
#: 같은 프레임 관문 (%p) — 웹앱 porosity (`dem_analysis_core.calc_porosity`, ε_sphere) 와 수확 구 부피 합 porosity 의 차.
#:   같은 식 · 같은 step 메시면 ~1e-13 (J15 · J16 교차검사 5.6e-14 %p) · 이른 메시 (다른 프레임) 면 수 %p 이상 (LHS-11).
#:   ⇒ 0.05 %p 는 "같은 프레임인가" 의 판별선이지 물리 허용오차가 아니다.
WA_SAME_FRAME_TOL_PCT = 0.05
WA_OK_STATUS = ('done', 'partial')      # partial = 선택 단계만 실패 (예: Stage E) — 필수 단계는 성공
#: ★ DESC-06 (Codex 배포 v1.1 최종 리뷰 raw_sha_mismatch · 1저자 비준 10-06) — 최종 join 도 원자료 sha 넷을 다시 맞댄다.  배치 (`lhs_webapp_batch.stage_case`)
#:   는 시작 때 수확 raw sha 와 대조하고 status 의 rec['sha'] 에 남기지만, 옛 생성기는 그 기록을 안 읽어 status 의 atom sha 를 바꿔도 통과했다.
#:   키 = `lhs_webapp_batch.RAW_KEYS` 와 같아야 한다 (selftest ㉜i — 사본은 시험이 지킨다).
WA_RAW_KEYS = ('atom', 'contact', 'mesh', 'deck')


def _wa_raw_sha_problem(rec, h):
    """배치 status 케이스 기록 rec['sha'] ↔ 수확 raw.<k>.sha256 (WA_RAW_KEYS 전부) → '' 또는 사유."""
    sha, raw = rec.get('sha'), (h.get('raw') or {})
    if not isinstance(sha, dict) or not sha:
        return '배치 status 에 원자료 sha 기록이 없다 — 같은 원자료로 돈 배치인지 모른다'
    bad = []
    for k in WA_RAW_KEYS:
        want, got = (raw.get(k) or {}).get('sha256'), sha.get(k)
        if not want:
            bad.append(f'수확 raw.{k}.sha256 없음')
        elif not got:
            bad.append(f'배치 sha.{k} 없음')
        elif got != want:
            bad.append(f'{k}: 배치 {str(got)[:12]}… ≠ 수확 {str(want)[:12]}…')
    return ' · '.join(bad)
WA_ROW_COLS = (
    ('wa_status',        '웹앱 배치 상태 — done · partial (선택 단계 실패) · failed · REFUSED (같은 프레임 · type_map 관문 거부) — '
                         'done · partial 이 아니면 웹앱 열은 빈칸'),
    ('wa_failed_stages', '실패한 파이프라인 단계 (| 로 이음)'),
    ('wa_mono_phase_name_webapp', 'mono (2-type) 침대에서 웹앱이 단일 AM 에 붙인 반지름 이름 (AM_P · AM_S — type_map_resolve · r > 4 µm) · '
                                  '설계 block 의 상과 다르면 상별 웹앱 열의 값을 설계 이름 칸으로 옮겨 실었다 (J20-k (B) · 130 의 5 · 64 의 4) · '
                                  'bimodal 은 빈칸'),
)
WA_QC = (
    ('qc_wa_porosity_minus_harvest_pct', 'porosity', 'porosity_sphere_pct_RECORD_ONLY',
     '같은 프레임 관문 — 웹앱 porosity (ε_sphere) − 수확 porosity (%p).  |값| > 0.05 면 인계표 생성 자체를 거부한다'),
    ('qc_wa_cov_AM_P_minus_harvest_pct', 'coverage_AM_P_mean', 'coverage_AM_P_hertz_pct',
     '검산 — 웹앱 coverage_AM_P_mean − 수확 coverage_AM_P_hertz_pct (%p).  같은 c_cpl[22] 채널 (A_dem_geometric)'),
    ('qc_wa_cov_AM_S_minus_harvest_pct', 'coverage_AM_S_mean', 'coverage_AM_S_hertz_pct',
     '검산 — 웹앱 coverage_AM_S_mean − 수확 coverage_AM_S_hertz_pct (%p)'),
)
#: 넘길 때 **이름을 고쳐 설명**해야 하는 열 (L1-04) — 코퍼스 이름은 frozen 이라 열 이름은 안 바꾼다.
CAVEAT_NAME = ('A_dem_geometric — LIGGGHTS 기하 교차 원판 π(rδ − δ²/4) 이지 Hertz 탄성 πR*δ 가 아니다 '
               '(같은 반경 비 = 2 − δ/2r ≈ 1.99배) · L1-04')
#: ★ J20-m 인계 한정어 ②–⑥ (1저자 비준 10-01 · "다음 인계표 재생성 때 열 사전 · 인계 README 에 붙일 것" — 판정 문서 그대로 옮김 · ① 은 CAVEAT_NAME)
CAVEAT_COVERAGE_J20M = ('인계 한정어 (J20-m ②–⑥): ② SE-rich 과압축 영역 (구 부피 합 ε_sphere < 0: lhsx 60/64 · LHS 18/130) 의 절대값 '
                        '③ AM 90–95 wt% 침대의 SE 바닥 몰림 (추정 — 바닥 접촉 AM 피복 / 내부 1.4–6.3 배 · SE 바닥 · 플래튼 접촉 수 비와 ρ +0.81 · '
                        '원자 z 분포는 직접 안 봄) ④ porosity 와 공선 (LHS ρ −0.985) · AM wt% 와 ρ −0.94 ⑤ AM_P 소표본 (n_P ≤ 10: LHS 12 · '
                        'lhsx 9 침대 — n_AM_P_measured · cov_AM_P_n_valid (정본 인계표 열)) ⑥ 옛 코퍼스와 섞을 때 치밀도 보정 필요 (같은 SE/고체 '
                        '0.3–0.5 에서 LHS 가 25–47 % 높음 — 더 치밀 · 생산 조성 근처 21.0 % 는 옛 18–22 % 와 같다)')
CAVEAT_COVERAGE = CAVEAT_NAME + ' · ' + CAVEAT_COVERAGE_J20M
CAVEAT_FRAC_DELTA = 'δ-based 파괴 분류 — force-based 열 (_force_) 과 같은 표에 나란히 인용 금지 (분류 규칙이 다르다) · force-based 권장'
CAVEAT_FRAC_FORCE = 'force-based 파괴 분류 (Auerbach — 권장) · δ-based 열과 같은 표에 나란히 인용 금지'
HANDOVER_VALUE_MEANING = {
    'phi_se': ('SE 부피분율 — 명목 구 부피 합 / (L² · 플래튼−바닥 간격) (장부값, 겹침 이중계상 포함 · 정본 이름 phi_se_spheresum_nominal_gap) · '
               '⚠ 내부 기록 — union porosity 와 닫히지 않는다 (분모가 인계 두께가 아니다) · 인계용은 phi_se_mass_conserving (J20-e)'),
    'phi_am': 'AM 부피분율 — 같은 규약 · ⚠ 내부 기록 · 인계용은 phi_am_mass_conserving (J20-e)',
    'coverage_AM_P_hertz_pct': 'AM_P 표면 피복률 (%) — 접촉 면적 c_cpl[22] 합 / 표면적, 입자 평균 · 이름의 hertz 는 물려받은 오해 (A_dem_geometric · L1-04)',
    'coverage_AM_S_hertz_pct': 'AM_S 표면 피복률 (%) — 같은 채널',
    'coverage_AM_total_hertz_pct': ('AM 전체 피복률 (%) = (N_P·C_P + N_S·C_S)/(N_P + N_S) — N = 피복 유효 입자 수 cov_AM_P_n_valid (정본 인계표 열) · '
                                    'cov_AM_S_n_valid (정본 인계표 열) · mono = 단일 AM 값 · 상별 값의 유도량 (독립 타깃 아님 · 생성기 관문 DESC-07 ② 1e-9) · 설계 → 구조 예측에서 '
                                    '실측 N 을 X 로 몰래 쓰면 누설 (DESC-07)'),
    'porosity_sphere_pct_RECORD_ONLY': 'ε_sphere 공극률 (%) — 1 − phi_se − phi_am (기록 전용 · 물리 공극률은 porosity_union_exact_pct)',
}


#: J20-a ⓒ (1저자 비준 09-28 밤 "권고하는걸로") — 접촉 위상 열의 **정의**.  09-19 판정의 why ("cap 선택과 무관 Δ = 0 %") 는 좁은 검사
#:   결과이지 뜻이 아니다.  공통: 접촉 = LIGGGHTS pair/gran/local 덤프의 **행** (벽 · 플래튼 접촉은 없다 · x·y 주기 경계를 넘는 접촉은
#:   c_cpl[9] 플래그와 함께 들어 있다 — `scripts/lhs_contact_audit.py` 가 원자 좌표 최소영상 재계수와 쌍 단위로 맞댄다) · CN = 그 상
#:   **전 입자**로 나눈 평균 (접촉 0 · 벽 · 플래튼에 닿은 입자 포함) — `scripts/dem_analysis_core.py`.
CAVEAT_WALL = ('벽 효과 (정의상 — 결함 아님): 바닥 벽 · 플래튼에 닿은 입자는 그쪽에 이웃이 없어 CN 이 낮다 · 설계 d/T AM_P 0.10–0.52 '
               '(두께가 AM_P 2–10 개) ⇒ 두께에 따라 체계적 — wall_touch_frac_* 열과 함께 쓸 것')
CAVEAT_DERIVED_NUM = ('파생 — (N_P·CN_P + N_S·CN_S)/(N_P + N_S) 항등식: AM_P_se_cn_mean · AM_S_se_cn_mean · 상별 입자 수로 정해진다 '
                      '(독립 타깃 아님 · DESC-07 과 같은 부류)')
CAVEAT_DERIVED_SW = ('파생 — 상별 반경이 한 값이면 (N_P r_P² CN_P + N_S r_S² CN_S)/(N_P r_P² + N_S r_S²) 항등식 · r² 가중이라 '
                     'AM_P 가 지배 → 벽 효과가 크다')
CAVEAT_PERC = ('경계 = 바닥 벽 z 0 · 플래튼 plate_z 기준 2·r 밴드 (L0) — LHS 130/130 폴백 0 (J20-b 감사) · 폴백 (L1 · L2) 이 나면 같은 이름이 다른 '
               '정의가 되는데 기록이 없다 (LHS-17 · 생산 코드에서 열림) · 두께 < 4r 이면 두 밴드 겹침 인공물 (LHS-18 · LHS 기하상 0) · '
               '수확기 벽 밴드 관통 (tau_wall_n_span_components (정본 인계표 열) > 0) 과 같은 집합 (관문 P1)')
CAVEAT_COUNT = ('총량 (개수) — 두께 · 입자 수에 비례한다 · 특징으로 쓰려면 입자당 · 부피당으로 나눌 것 · 면적이 아니다 '
                '(A_dem_geometric 주의는 해당 없음)')
#: ★ LREL-05 (Codex 배포 v1.1 최종 리뷰 반례 band_not_wall · 판정문 권고 문안 — README v1.1 개정판 §4 와 같은 말) — 이온 활성 · 경로 기준 고립 · 분해 열은
#:   **그래프 구조 지표**다.  위 평면 접촉 SE 0 개인데 위 띠 SE 와 닿은 AM 이 active 100 % 로 나오는 반례가 있다 — "이온이 닿는다 / 못 닿는다" 로 쓰지 않는다.
IONIC_GRAPH_NOTE = ('그래프 지표 (LREL-05): 등록된 상단 2r 경계 띠 (분리막 쪽) 와 SE 접촉 그래프로 연결됐는지만 본다 — 실제 분리막 접촉 · 계면 저항 · '
                    '이온 전류는 계산하지 않는다 (위 띠에 앉았지만 위 평면에 닿지 않은 SE 도 도달로 센다)')
#: ⑤⑥⑦ 한정어 (J20-s · 열 사전 문구 — 정본 = 판정 J20-s 표)
CAVEAT_F1 = ('h = 10 nm (H_SPREAD_REAL_M · 확대 배율 반영) 는 **출처 없는 모델 상수** ("2 × h_film_min") — 감도 기술자로만 · SE–SE 만 · '
             '반올림 쌍 (덤프 %g · 접촉 감사 v2 의 114 쌍 / 130 침대) 이 탄성 CN 과 겹쳐 셀 수 있음 (무시 가능 수준) · ' + CAVEAT_WALL)
CAVEAT_LHS31 = ('LHS-31 한정: ① 마지막 프레임 힘 (압축 중 최대 아님 → 손상 **하한**) ② 벽 · 판 접촉 제외 (판에 닿은 AM_P 의 최대 하중 빠짐) '
                '③ R_min 선택 (R* 이면 P_c 절반) ④ K_IC_P 0.3 = 소결 펠릿값 (정본 카드 xu2017 — 이차입자 0.102 의 3 배) · K_IC_S 1.0 측정 근거 '
                '없음 — P_c ∝ K_IC² ⑤ A 200 · 배수 원전 (Lawn Table 3.4) 카드 없음 [미확인] ⑥ δ 판 열과 나란히 인용 금지')
CAVEAT_FRAC_AUERBACH = CAVEAT_FRAC_FORCE + ' · ' + CAVEAT_LHS31
CAVEAT_AREA_TOTAL = CAVEAT_NAME + ' · 총량 (µm²) — 두께 · 입자 수에 비례한다 · 특징으로 쓰려면 입자당 · 부피당으로 나눌 것'
WA_DEFINE = {
    'se_se_cn': ('z_SE-SE — SE 1 개당 SE 접촉 수, SE 전 입자 평균 (접촉 0 · 벽 · 플래튼에 닿은 입자 포함)', CAVEAT_WALL),
    'se_se_cn_std': ('z_SE-SE 의 입자간 표준편차 (모집단 · SE 전 입자)', CAVEAT_WALL),
    'am_se_cn_mean': ('z_AM-SE — AM 1 개당 SE 접촉 수, AM 전 입자 (AM_P + AM_S) 의 개수 가중 평균',
                      CAVEAT_DERIVED_NUM + ' · ' + CAVEAT_WALL),
    'am_se_cn_surface_weighted': ('Σ r²·CN_AM-SE / Σ r² (AM 전 입자) — 표면적 가중 AM–SE CN', CAVEAT_DERIVED_SW),
    'am_am_cn': ('z_AM-AM — AM 1 개당 AM 접촉 수 (AM_P–AM_S 교차 포함), AM 전 입자 평균', CAVEAT_WALL),
    'am_am_cn_std': ('z_AM-AM 의 입자간 표준편차 (모집단)', CAVEAT_WALL),
    'am_am_n_contacts': ('AM–AM 접촉 개수', CAVEAT_COUNT),
    #  7c (J20-k · 1저자 비준 10-01) — 고립 비율 · 전체 AM–SE 분포 (7a 새 키)
    'am_vulnerable_pct': ('AM 고립 **위험** 비율 (%) (취약 AM) — SE 접촉이 0–1 개인 AM 의 비율, AM 전 입자 (AM_P + AM_S) · 접촉 개수 기준 '
                          '(coverage 문턱이 아니다 — 09-19 census 의 COND_cov 는 오분류 · LHS-23) · ⚠ 경로 기준 고립 (그래프 지표 · LREL-05) 이 아니다 — '
                          '그것은 100 − ionic_active_pct (1저자 10-01 질문)', CAVEAT_WALL),
    'am_se_cn_std': ('z_AM-SE 의 입자간 표준편차 (모집단) — AM 전 입자 (접촉 0 · 벽 입자 포함) · mono = 단일 상 값 (J20-k 7a)', CAVEAT_WALL),
    'am_se_cn_median': ('z_AM-SE 의 중앙값 — AM 전 입자 (짝수 개면 가운데 둘의 평균 · np.median) · mono = 단일 상 값 (J20-k 7a)', CAVEAT_WALL),
    'am_se_cn_max': ('z_AM-SE 의 최댓값 — AM 전 입자 · = 상별 max 의 최댓값 (J20-k 7a)', CAVEAT_WALL),
    #  ② 퍼콜레이션 (J20-b · F3 = LHS-19 · 열 이름과 뜻이 다른 곳을 적는다)
    'percolation_pct': ('SE 관통 비율 (%) — 바닥 밴드 (z ≤ 2r) 와 위 밴드 (z ≥ plate_z − 2r) 에 다 닿는 SE 성분의 SE / 전 SE · 0.0 = 관통 성분 없음 '
                        '(진짜 미퍼콜 · J20-b) · **밴드 규칙의 그래프 관통** — 솔버 (전류) 관통 · σ 와 다른 정의 (LHS-19)', CAVEAT_PERC),
    'top_reachable_pct': ('위 밴드에 닿는 SE 성분의 SE / 전 SE (%) — 위 밴드에 앉은 외톨이 SE 도 센다 (LHS-19) · SE 그래프 양 (coverage 무관 — LHS-20)',
                          CAVEAT_PERC),
    'n_components': ('SE 접촉 그래프의 성분 수 — 외톨이 SE (크기 1) 포함 → 단절 침대에서는 사실상 외톨이 수 (LHS-06 · LHS-19)', CAVEAT_COUNT),
    'n_large_components': ('크기 ≥ 10 인 SE 성분 수 — 문턱 10 은 출처 없는 코드 상수 (LHS-19)', CAVEAT_COUNT),
    'ionic_active_pct': ('이온 활성 AM 비율 (%) — 위 밴드 (분리막 쪽) 에 닿는 SE 성분 (top-reachable) 의 SE 와 접촉한 AM / 전 AM (calc_ionic_active_am) · '
                         '**100 − 이 값 = 경로 기준 고립 AM** (SE 무접촉 + 닿은 SE 가 위로 안 이어짐) · 접촉 유무만 '
                         '본다 (coverage 무관 — LHS-20) · 외톨이 SE 가 위 밴드에 있으면 그것도 센다 (LHS-19) · ' + IONIC_GRAPH_NOTE, CAVEAT_PERC),
    #  v1.1 ② (1저자 비준 10-01) — 경로 기준 고립 (= 100 − ionic_active_pct) 의 분해
    'ionic_dead_pct': ('경로 기준 고립 중 **단절** 비율 (%) (v1.1 ②) — SE 와 닿았지만 닿은 SE 가 전부 위 밴드 (분리막 쪽) 로 안 이어지는 AM / 전 AM '
                       '(calc_ionic_active_am 의 dead) · SE 망이 끊긴 문제 (접촉을 늘려도 안 풀린다) · ' + IONIC_GRAPH_NOTE, CAVEAT_PERC),
    'ionic_no_se_pct': ('경로 기준 고립 중 **무접촉** 비율 (%) (v1.1 ②) — SE 접촉 0 인 AM / 전 AM (calc_ionic_active_am 의 no_se) · 고립 위험 '
                        '(SE 접촉 0–1 개) 의 부분집합 (관문 D5) · 계면 형성 문제 · ' + IONIC_GRAPH_NOTE, CAVEAT_WALL),
    'se_se_cn_perc': ('관통 SE 성분에 속한 SE 만의 평균 SE–SE CN — 관통 성분이 없으면 빈칸 (N/A · 키 자체가 없다 · LHS-19)', CAVEAT_WALL),
    'se_se_cn_n_perc': ('관통 SE 성분에 속한 SE 개수 — = percolation_pct × N_SE / 100 (생성기 관문 P3) · 관통 없으면 빈칸 (N/A)', CAVEAT_COUNT),
    'A_binding_AM_SE_n_contacts': ('Physics 모듈 (coverage_physics_vs_hertzian) 이 센 AM–SE 접촉 개수 — area_AM전체_SE_n 과 같은 '
                                   '집합인지는 한 건 대조 전', CAVEAT_COUNT),
    'A_binding_total_n_contacts': ('Physics 모듈이 센 전체 접촉 개수 — 같은 집합인지는 한 건 대조 전', CAVEAT_COUNT),
    'n_am_am_contacts_total': ('파괴 모듈이 센 AM–AM 접촉 개수', CAVEAT_COUNT),
    'n_am_am_contacts_excluded': ('파괴 모듈이 제외한 AM–AM 접촉 개수', CAVEAT_COUNT),
    #  ⑤⑥⑦ (J20-s · 1저자 비준 10-04)
    'se_se_cn_aug': ('F1 근접쌍 CN — 탄성 접촉 (덤프) 에 표면 틈 ≤ h 인 SE–SE 쌍을 더해 센 SE 1 개당 SE 접촉 수, SE 전 입자 평균 · '
                     '= se_se_cn + 2 × se_se_cn_aug_n_extra / N_SE (관문 ⑤F1 · 10-01 실측 130/130 · 64/64 상대차 ≤ 2.2e-16) · J20-s ⑤', CAVEAT_F1),
    'se_se_cn_aug_std': ('F1 근접쌍 CN 의 입자간 표준편차 (모집단 · SE 전 입자) · J20-s ⑤', CAVEAT_F1),
    'se_se_cn_aug_n_extra': ('F1 이 더한 SE–SE 근접쌍 개수 (탄성 접촉이 아닌 쌍 · 쌍 하나 = 두 입자에 하나씩) · J20-s ⑤',
                             CAVEAT_F1 + ' · ' + CAVEAT_COUNT),
    'se_se_cn_aug_h_spread_sim': ('F1 의 틈 문턱 h (sim 길이 = 10 nm × 확대 배율 · LHS 1e-05 전부) · J20-s ⑤', CAVEAT_F1),
    'fracture_index_force': ('Auerbach 힘 기반 파괴 지수 = (파편화 + 분쇄) 개수 / n_total_AM_AM_force (소수 넷째 자리 반올림) — AM–AM 접촉만 · '
                             '단계 = F/P_c 의 배수 1 · 3 · 11 · 32 (P_c = A K_IC² R_min / E*) · J20-s ⑥', CAVEAT_FRAC_AUERBACH),
    'n_total_AM_AM_force': ('힘 기반 분류에 들어간 AM–AM 접촉 수 (법선력 fn > 0) — ≤ am_am_n_contacts (관문 ⑥R3 · 10-01 실측 194/194 같음) · '
                            'AM–AM 접촉 0 인 침대는 파괴 열 전부 빈칸 (N/A — calc_fracture_stages 가 키를 안 쓴다 · 생성기가 am_am_n_contacts 0 으로 '
                            '확인한 상태 · RGL-05) · J20-s ⑥', CAVEAT_FRAC_AUERBACH + ' · ' + CAVEAT_COUNT),
    'se_se_cn_eff_area': ('SE 표면 중 SE–SE 접촉이 덮은 비율 (무차원) = Σ A_contact (접촉 하나를 두 입자에 하나씩) / Σ 4πr² (SE 전 입자) = '
                          '2 × area_SE_SE_total / (N_SE · 4π r_SE²) (관문 ⑦A4 · SE 단분산 · 10-01 실측 상대차 ≤ 2.2e-12) · J20-s ⑦', CAVEAT_NAME),
    'se_se_cn_eff_area_perc': ('같은 비율 — 관통 SE 성분에 속한 SE 만 · 관통 없으면 빈칸 (N/A · percolation_pct 0 과 같은 집합 — 관문 ⑦A5) · J20-s ⑦',
                               CAVEAT_NAME),
    'am_am_mean_area': ('AM–AM 접촉 하나의 평균 면적 (µm²) = am_am_total_area / am_am_n_contacts (관문 ⑦A3) · AM–AM 접촉 0 이면 빈칸 '
                        '(N/A — 접촉 0 개에서 평균은 정의되지 않는다 · calc_am_am_cn 의 0 대입은 비운다 · 쌍 평균과 같은 규칙 · RGL-05) · J20-s ⑦',
                        CAVEAT_NAME),
    'am_am_total_area': ('AM–AM 접촉 면적 총합 (µm²) = AM_P–AM_P + AM_P–AM_S + AM_S–AM_S 총합 (관문 ⑦A3) · AM–AM 접촉 0 이면 0 (측정된 0 · '
                         'RGL-05) · J20-s ⑦', CAVEAT_AREA_TOTAL),
}
_STAT_KO = {'mean': '평균', 'std': '표준편차 (모집단)', 'median': '중앙값', 'max': '최댓값'}


def wa_define(col):
    """J20-a ⓒ — 접촉 위상 열이면 (뜻, 주의), 아니면 None.  열 이름은 코퍼스 (case_master) 그대로."""
    if col in WA_DEFINE:
        return WA_DEFINE[col]
    m = re.fullmatch(r'(AM_P|AM_S)_se_cn_(mean|std|median|max)', col)
    if m:
        ph, st = m.groups()
        return (f'{ph} 1 개당 SE 접촉 수의 {_STAT_KO[st]} — {ph} 전 입자 (접촉 0 · 벽 입자 포함) · 상이 없으면 빈칸 (N/A)',
                CAVEAT_WALL)
    m = re.fullmatch(r'(AM_P|AM_S)_vulnerable_pct', col)
    if m:
        return (f'{m.group(1)} 고립 **위험** 비율 (%) (취약) — SE 접촉이 0–1 개인 {m.group(1)} 의 비율 · 접촉 개수 기준 (coverage 문턱이 아니다 — '
                'LHS-23 · 경로 기준 고립은 ionic_active_pct 쪽) · 상이 없으면 빈칸 (N/A)', CAVEAT_WALL)
    m = WA_IONIC_PHASE_RE.fullmatch(col)
    if m:
        ph, s_ = m.groups()
        ko = {'active': '이온 활성 (위 밴드에 닿는 SE 와 접촉)', 'dead': '단절 (SE 와 닿았지만 위 밴드로 안 이어짐)', 'no_se': '무접촉 (SE 접촉 0)'}[s_]
        return (f'{ph} 의 {ko} 비율 (%) (v1.1 ②) — {ph} 전 입자 기준 · 활성 + 단절 + 무접촉 = 100 (관문 D2) · 상이 없으면 빈칸 (N/A) · '
                + IONIC_GRAPH_NOTE,
                CAVEAT_PERC if s_ != 'no_se' else CAVEAT_WALL)
    m = re.fullmatch(r'area_(.+)_n', col)
    if m:
        return (f'{m.group(1)} 접촉 개수 (쌍 종류별 덤프 행 수)', CAVEAT_COUNT)
    m = re.fullmatch(r'frac_([a-z]+)_force_pct', col)                       # ⑥ (J20-s)
    if m and m.group(1) in FRAC_STAGES:
        s_ = m.group(1)
        return (f'힘 기반 {FRAC_STAGE_KO[s_]} ({s_}) 단계 비율 (%) = 100 × n_{s_}_force_AM_AM / n_total_AM_AM_force (소수 둘째 자리 반올림 · '
                '다섯 단계 합 ≈ 100 · 관문 ⑥R2) · J20-s ⑥', CAVEAT_FRAC_AUERBACH)
    m = re.fullmatch(r'n_([a-z]+)_force_AM_AM', col)
    if m and m.group(1) in FRAC_STAGES:
        s_ = m.group(1)
        return (f'힘 기반 {FRAC_STAGE_KO[s_]} ({s_}) 단계 AM–AM 접촉 수 — 다섯 단계 합 = n_total_AM_AM_force (관문 ⑥R1) · J20-s ⑥',
                CAVEAT_FRAC_AUERBACH + ' · ' + CAVEAT_COUNT)
    m = WA_AREA_PAIR.fullmatch(col)                                         # ⑦ (J20-s)
    if m:
        a_, b_, st = m.groups()
        pair = f'{a_.replace("AM전체", "AM 전체")}–{b_}'
        if st == 'mean':
            return (f'{pair} 접촉 하나의 평균 면적 (µm²) = 총합 / 개수 (관문 ⑦A1) · 접촉 0 쌍은 빈칸 (N/A — 접촉 0 개에서 평균은 정의되지 '
                    '않는다) · J20-s ⑦', CAVEAT_NAME)
        return (f'{pair} 접촉 면적 총합 (µm²) — 접촉 0 쌍 = 0 (두 상이 다 있으면 측정된 0 · J20-h 와 같은 규칙)'
                + (' · = AM_P–SE + AM_S–SE (관문 ⑦A2)' if a_ == 'AM전체' else '') + ' · J20-s ⑦', CAVEAT_AREA_TOTAL)
    return None


#: 묶음별 채우기 (1저자 09-29 밤 "단독적으로 하나씩 돌려서 표를 채워나갈 거야") — 웹앱 **접촉 분석 단계** (`analyze_contacts.py` ·
#:   bimodal 은 그것을 감싼 `analyze_contacts_bimodal.py`) 가 full_metrics.json 에 쓰는 ① 열.  WA_DEFINE 의 나머지 넷은 뒤 단계 산출이라
#:   접촉 단계만 돈 배치 (`lhs_webapp_batch --stop-after contact`) 에서는 빈칸이 된다 — 이 묶음에 넣지 않는다:
#:   A_binding_AM_SE_n_contacts · A_binding_total_n_contacts (`coverage_physics_vs_hertzian.py`) ·
#:   n_am_am_contacts_total · n_am_am_contacts_excluded (`run_network_fracture_aware.py`).
WA_GROUP_CONTACT_EXACT = ('se_se_cn', 'se_se_cn_std', 'am_se_cn_mean', 'am_se_cn_surface_weighted',
                          'am_am_cn', 'am_am_cn_std', 'am_am_n_contacts',
                          #  7c — calc_am_isolation_risk 의 나머지 출력 (같은 접촉 단계 · analyze_contacts.py:452–468)
                          'am_se_cn_std', 'am_se_cn_median', 'am_se_cn_max', 'am_vulnerable_pct')
#: ② 퍼콜레이션 묶음 (J20-b 감사 · 1저자 비준 10-01 *"퍼콜레이션은 그렇게 가고"*) — **접촉 분석 단계**가 full_metrics 에 쓰는 SE 그래프 열
#:   (`calc_percolation` · `calc_ionic_active_am` · `calc_se_se_cn` 의 관통 부분 · analyze_contacts.py:404–413).  09-29 contact 배치 · 5번 배치 둘 다
#:   130/130 값.  `electronic_active_fraction` 은 **망 단계** (`active_fractions`) 산출이라 접촉 · coverage 배치에 값이 없다 → 이 묶음에 넣지 않는다
#:   (census ✅ 여도 빈칸 = 측정된 N/A 로 읽힌다) · `se_se_cn_eff_area_perc` 는 면적 (⑦ 차례).
WA_GROUP_PERC_EXACT = ('percolation_pct', 'top_reachable_pct', 'n_components', 'n_large_components', 'ionic_active_pct',
                       'se_se_cn_perc', 'se_se_cn_n_perc')
#: v1.1 ② (1저자 비준 10-01) — 경로 기준 고립의 분해: 웹앱 v1.1 이 내보내기 시작한 키 (calc_ionic_active_am 의 dead · no_se · 상별 셋) ·
#:   접촉 분석 단계 산출 · 09-19 census 밖 → 배치 머리에 있을 때만 싣는다 (5번 배치에는 없다 = 열도 없다).
WA_IONIC_DEC_KEYS = (('ionic_dead_pct', 'ionic_no_se_pct')
                     + tuple(f'{ph}_ionic_{s_}_pct' for ph in ('AM_P', 'AM_S') for s_ in ('active', 'dead', 'no_se')))
WA_IONIC_PHASE_RE = re.compile(r'(AM_P|AM_S)_ionic_(active|dead|no_se)_pct')
#: v1.1 ① (1저자 비준 10-01) — 생성기가 **유도**하는 웹앱 열 (재실행 없음).  웹앱 v1.1 도 같은 이름 · 같은 식으로 낸다 — 있으면 같아야 (D1).
WA_DERIVED = (
    ('am_ionic_isolated_pct',
     '★ 경로 기준 고립 AM 비율 (%) (v1.1 ① · 1저자 비준 10-01) = 100 − ionic_active_pct — 등록된 상단 2r 경계 띠 (분리막 쪽) 와 SE 접촉 그래프로 연결되지 않은 AM: '
     'SE 무접촉 + 닿은 SE 가 top-reachable 이 아님 (calc_ionic_active_am · 접촉 그래프 · coverage 무관) · ⚠ 고립 위험 (am_vulnerable_pct · '
     'SE 접촉 0–1 개 · 접촉 개수) 과 다른 양 — 접촉이 둘 이상이어도 그 SE 가 끊긴 덩어리면 고립, 하나뿐이어도 이어져 있으면 활성 (예: lhs00_083 '
     '고립 위험 0.1 % · 경로 고립 89 %) · 분해 = ionic_dead_pct + ionic_no_se_pct (v1.1 ② 배치부터) · 생성기가 ionic_active_pct 에서 유도 · '
     '관문 v1.1 D0–D5 · ' + IONIC_GRAPH_NOTE),
)
#: ★ v1.3 (1저자 비준 10-06 밤 — CLAUDE.md LHS 줄 "새 열 se_isolated_pct = 100 − top_reachable_pct") — 고립 전해질 · 유도 묶음 se_isolation 일 때만
#:   (WA_SE_ISO_GROUP · 명시 opt-in).  AM 경로 고립 (WA_DERIVED) 과 **같은 규칙** (같은 접촉 그래프 · 같은 상단 2r 띠 · calc_percolation 의 위 밴드 성분) ·
#:   재실행 없음 · 관문 S0 (percolation 묶음 필요) · S1 (= 100 − top · 웹앱이 같은 이름을 내면 같아야) · S2 (≤ 100 − percolation_pct).
WA_DERIVED_SE_ISO = (
    ('se_isolated_pct',
     '★ 고립 전해질 비율 (%) (v1.3 · 1저자 비준 10-06) = 100 − top_reachable_pct — 등록된 상단 2r 경계 띠 (분리막 쪽) 와 SE 접촉 그래프로 이어지지 않은 '
     'SE / 전 SE (calc_percolation 의 위 밴드 성분 밖 · 접촉 그래프 · coverage 무관) · AM 경로 고립 (am_ionic_isolated_pct = 100 − ionic_active_pct) 과 '
     '같은 규칙 · 생성기가 top_reachable_pct 에서 유도 (재실행 없음) · ⚠ 한정: 분리막 쪽 띠에 앉은 외톨이 SE (접촉 0 · LHS-19) 를 연결로 세어 고립을 '
     '약간 적게 잡는다 · 값이 큰 행은 비관통 침대 (percolation_pct = 0) 에 몰린다 → 관통 여부를 먼저 분류할 것 (관통 침대에서는 0 근처) · '
     '관문 S1 (= 100 − top_reachable_pct) · S2 (≤ 100 − percolation_pct — 관통 SE 는 위 띠에 닿는다) · ' + IONIC_GRAPH_NOTE),
)
SE_ISO_VERDICT = '✅ 쓴다 (유도 · v1.3 — 1저자 비준 10-06 밤)'
#: 비율 합 = 100 의 부동소수 여유 (%p) — 물리 허용치가 아니다 (개수 / N × 100 의 반올림만)
WA_PCT_SUM_TOL = 1e-7
#: ⑤⑥⑦ (J20-s · 1저자 비준 10-04 *"권고대로"*) — **접촉 분석 단계**가 full_metrics 에 쓰는 열 · 새 계산 없음 (10-01 d1ec42fba 배치 값).
#:   ⑤ F1 근접쌍 CN — calc_se_se_cn 의 F1 출력 (analyze_contacts.py:438–441).
WA_GROUP_F1_EXACT = ('se_se_cn_aug', 'se_se_cn_aug_std', 'se_se_cn_aug_n_extra', 'se_se_cn_aug_h_spread_sim')
#:   ⑥ Auerbach 힘 기반 파괴 — calc_fracture_stages 의 **힘 기반 전체 집계**만 (δ 판 · 상 쌍별은 WA_EXCLUDED).
FRAC_STAGES = ('intact', 'microcrack', 'multicrack', 'fragmentation', 'pulverization')    # fracture_model.ALL_STAGES 와 같은 순서
FRAC_STAGE_KO = {'intact': '무손상', 'microcrack': '미세 균열', 'multicrack': '다중 균열', 'fragmentation': '파편화', 'pulverization': '분쇄'}
WA_GROUP_FRAC_EXACT = (('fracture_index_force', 'n_total_AM_AM_force') + tuple(f'frac_{s}_force_pct' for s in FRAC_STAGES)
                       + tuple(f'n_{s}_force_AM_AM' for s in FRAC_STAGES))
#:   ⑦ 접촉 면적 (A_dem_geometric · c_cpl[22]) — calc_interface_area 의 쌍별 평균 · 총합 + calc_se_se_cn 면적 피복 + calc_am_am_cn 면적.
#:   쌍별 개수 (area_<쌍>_n) 는 ① 접촉 묶음 (J20-g) 그대로.
WA_AREA_PAIR = re.compile(r'area_(AM_P|AM_S|SE|AM전체)_(AM_P|AM_S|SE)_(mean|total)')
WA_GROUP_AREA_EXACT = ('se_se_cn_eff_area', 'se_se_cn_eff_area_perc', 'am_am_mean_area', 'am_am_total_area')
#: ★ Codex 10-05 재검증 Q5 (1저자 비준) — Love–Weber (④b · LHS-29) 열은 194 건 인계에서 **명시 제외**.  지금은 어느 묶음 · 검토 목록 ·
#:   census 에도 없지만, 그것이 바뀌어도 새어 들어오지 않게 제외 목록에 둔다 (selftest ㉘).  사유 첫 낱말 = frame_unverified.
WA_LW_FRAME_UNVERIFIED = (
    'frame_unverified — Love–Weber (④b) 입자 응력: 원자 · 접촉 · mesh 덤프가 같은 프레임인지 인증되지 않았다 '
    '(parse_liggghts 가 원 덤프의 TIMESTEP 을 CSV 로 옮기지 않고 세 파일을 따로 고른다 · 전역 virial 1 % 는 부호 · 척도 검사일 뿐 '
    '프레임 · 입자 · 상 배분 대응 증명이 아니다 — Codex 10-05 재검증 Q5 · RGL-06).  194 건에 실으려면 원 덤프의 TIMESTEP · 고른 파일 · '
    "타입 매핑 · 벽 기하 대응을 먼저 봉인한다 · 그때까지 '검증된 상별 실측 / 학습 타깃' 으로 인계하지 않는다")
#: ⑤⑥⑦ 근처의 census ✅ 열 중 **인계하지 않는 것** (패턴, 사유) — 묶음 · 검토 여부와 무관하게 먼저 뺀다 (selftest ㉕b · ㉕c · ㉘).
WA_EXCLUDED = (
    (r'path_hop_area_.*', 'LHS-32 — 덩어리마다 고른 경로 30 개 (best · mean · worst 10) 의 평균 = 선별 표본 통계'),
    (r'frac_[a-z]+_pct|fracture_index|n_[a-z]+_AM_AM|n_total_AM_AM',
     'δ 판 파괴 분류 — 힘 기반 열과 나란히 인용 금지 (09-19 · LHS-31 ⑥) · 힘 기반 (Auerbach) 만 인계'),
    (r'(frac|n)_[a-z]+(_force)?_(AM_P|AM_S)-(AM_P|AM_S)(_pct)?|n_total(_force)?_(AM_P|AM_S)-(AM_P|AM_S)',
     '상 쌍별 파괴 분해 — 접촉 0 쌍에서도 비율 0 % (분모 max(n, 1)) 라 N/A 와 0 을 못 가르고, mono 상 이름 규약 (J20-k (B)) 을 이 열에 '
     '옮기는 관문이 없다 · 전체 집계만 인계'),
    (r'area_.+_physics', 'physics 면적 — coverage 인계는 기하면적만 (J20-m) · 접촉별 추정 면적 합에 표면 한도가 없다 (LHS-25)'),
    #  ④b Love–Weber 전부 — 값 (stress_cv_lw · stress_ratio_<상>_lw · _nowall) · 메타 · 검사 · 벽 표지 (stress_lw_*) · 옛 σ_VM 열은 안 잡는다
    (r'stress_lw_.+|stress_cv_lw(_nowall)?|stress_ratio_.+_lw(_nowall)?', WA_LW_FRAME_UNVERIFIED),
)
WA_GROUPS = ('contact', 'percolation', 'f1', 'fracture', 'area')
#: 7c — 웹앱 배치 단계 (`lhs_webapp_batch --stop-after`) → 그 배치가 **다 낸** 묶음 (단계 역량).  coverage 단계는 접촉 단계를 포함한다 (접촉 분석 →
#:   피복) — 5번 배치 (`--stop-after coverage`) 를 contact 묶음으로 받는다.  묶음 제한 없이 (전체) 부르면 여전히 거부 (뒤 단계 열이 빈칸).
#:   ② 퍼콜레이션도 접촉 분석 단계 산출이다 (위).  ⑤⑥⑦ 도 접촉 분석 단계 산출 (J20-s).
#:   ★ RGL-03 (Codex 10-05 · P1 · 1저자 비준 "권고대로") — network 단계를 명시한다.  옛 판은 contact · coverage 만 알아 `--stop-after network`
#:   배치를 일률 거부했고, 안내는 유효 묶음 이름도 아닌 'network' 를 요구했다.  network 정지점 (webapp/app.py `PIPELINE_STOP_AFTER` ·
#:   `_network_and_stage_e(stop_before_stage_e=True)`) = 접촉 분석 (required · causal — 실패하면 그 케이스는 failed) → 피복 (optional ·
#:   `*_physics` · `*_physics_v2` · A_binding 키만 쓴다) → network solver → 머지 (`pipeline_service.NET_MERGE_KEYS` — σ · R · 협착 전력 몫 키만) →
#:   망 정지 계약 · **Stage E 앞**.  뒤 단계가 다섯 묶음의 열을 다시 쓰지 않으므로 done · partial 행은 다섯 묶음을 다 낸다.
#:   ★ 망 τ 묶음 'tau' (v1.2 · 아래 WA_TAU_GROUP) = 망 단계 고유 산출 중 **이온 망 인계 열** (tau_flux) 만 — network 정지점에만 있다.
#:   ④a 협착 전력 몫 · electronic_active_fraction 은 아직 인계 묶음이 아니다 (v1.2 범위 밖 · Codex 10-05 3차 §6-5).
#:   생산 쪽 정지점 (배치 `--stop-after` choices · 웹앱 `PIPELINE_STOP_AFTER`) 이 늘면 여기에 역량을 적기 전까지 거부한다 (selftest ㉖i 가 동기를 본다).
#: ★ 망 τ 묶음 (v1.2 · Codex 10-05 3차 재검증 §3 Q5 · §6-5 *"⑤⑥⑦ · 망 τ 만 · LW 제외"*) — network 정지 배치의 케이스 폴더 (`<--work>/results/<case>/`)
#:   에서 **tau_flux 자신** (`case_row`) 이 낸 이온 망 인계 열 (v2 §5-1 · 모드 꼬리 · `tau_flux.column_names()` — 10-06 밤부터 50 열: 모드 셋 × 15 + 공통 5 (σ₀ · T · φ · L 기준 · 세대 칸) ·
#:   ★ 10-16 L214R-02 부터 끝에 FULL 모형 한계 독립 표지 두 칸 (full_model_limit_hertz · full_model_limit_physics — `_TAU_ML_FLAG`) = 52 열) 을 싣는다.  census 열이 아니라
#:   (metrics_flat 에 dual 레코드가 없다) 별도 원천 (`load_tau_results` · CLI `--tau-results`) 이 필요하다 — 묶음만 부르거나 원천만 주면 거부.
WA_TAU_GROUP = 'tau'
#: ★ v1.3 (1저자 비준 10-06 밤 · 10-07 "v1.3 생성기 미리 준비") — **유도 묶음** se_isolation: 고립 전해질 se_isolated_pct = 100 − top_reachable_pct
#:   (② 퍼콜레이션 묶음에서 유도 · 재실행 없음 · `WA_DERIVED_SE_ISO`).  명시 opt-in 이다 — 옛 인계표 (contact,percolation · v1.2) 를 같은 인자로 다시
#:   만들면 바이트가 그대로여야 한다 (selftest ㉙f2).  단계 역량 표 (WA_STAGE_GROUPS) 에는 넣지 않는다: 어느 정지점이든 percolation 과 함께면 낼 수
#:   있고, 그 표의 network 칸은 194 실행기 (`run_network_194_parallel.HANDOVER_GROUPS` · 그 selftest ㉕) 의 짝이다 (실행기가 찍는 v1.2 명령 그대로).
WA_SE_ISO_GROUP = 'se_isolation'
WA_DERIVED_GROUPS = (WA_SE_ISO_GROUP,)
WA_ALL_GROUPS = WA_GROUPS + (WA_TAU_GROUP,) + WA_DERIVED_GROUPS
WA_STAGE_GROUPS = {'contact': WA_GROUPS, 'coverage': WA_GROUPS, 'network': WA_GROUPS + (WA_TAU_GROUP,)}


def wa_group_contact(col):
    """① 접촉 위상 묶음 중 **접촉 분석 단계**가 내는 열인가."""
    return (col in WA_GROUP_CONTACT_EXACT
            or re.fullmatch(r'(AM_P|AM_S)_(se_cn_(mean|std|median|max)|vulnerable_pct)', col) is not None
            or re.fullmatch(r'area_(.+)_n', col) is not None)


def wa_group_perc(col):
    """② 퍼콜레이션 묶음 (접촉 분석 단계의 SE 그래프 열) 인가 — v1.1 ② 분해 키 포함."""
    return col in WA_GROUP_PERC_EXACT or col in WA_IONIC_DEC_KEYS


def wa_group_f1(col):
    """⑤ F1 근접쌍 CN 묶음인가 (J20-s)."""
    return col in WA_GROUP_F1_EXACT


def wa_group_frac(col):
    """⑥ Auerbach 힘 기반 파괴 — 전체 집계 열인가 (J20-s · LHS-31)."""
    return col in WA_GROUP_FRAC_EXACT


def wa_group_area(col):
    """⑦ 접촉 면적 (A_dem_geometric) 묶음인가 — 쌍별 평균 · 총합 · SE 면적 피복 · AM–AM 면적 (J20-s)."""
    return col in WA_GROUP_AREA_EXACT or WA_AREA_PAIR.fullmatch(col) is not None


def wa_excluded(col):
    """⑤⑥⑦ — 인계하지 않는 열이면 사유, 아니면 None (WA_EXCLUDED · J20-s)."""
    for pat, why in WA_EXCLUDED:
        if re.fullmatch(pat, col) is not None:
            return why
    return None


def handover_exclusion_notes():
    """인계표에서 **명시적으로 뺀** 열과 사유 [(패턴 또는 열, 사유)] — 웹앱 열 제외 (WA_EXCLUDED · LW frame_unverified 포함) + 보류 열
    (HANDOVER_HELD_BACK).  열 사전 (_columns.tsv) 은 표의 열만 한 줄씩 적으므로 (selftest ⑲m) 빠진 열의 사유는 이 노트로 넘긴다."""
    return [(p, w) for p, w in WA_EXCLUDED] + [(c, w) for c, w in HANDOVER_HELD_BACK.items()]


def write_exclusion_notes(path):
    """제외 노트 TSV (pattern · reason) — 인계표 CLI 가 열 사전 옆에 `<인계표>_excluded.tsv` 로 쓴다 (받는 쪽이 왜 없는지 읽는다)."""
    with pathlib.Path(path).open('w', encoding='utf-8', newline='') as fh:
        w = csv.writer(fh, delimiter='\t', lineterminator='\n')
        w.writerow(['pattern', 'reason'])
        for p, why in handover_exclusion_notes():
            w.writerow([p, why])


WA_GROUP_FN = {'contact': wa_group_contact, 'percolation': wa_group_perc,
               'f1': wa_group_f1, 'fracture': wa_group_frac, 'area': wa_group_area}


def wa_groups_norm(g):
    """--webapp-groups 값 → 묶음 튜플 ('contact,percolation' · 'contact' · 튜플) · None = 묶음 제한 없음."""
    if g is None:
        return None
    if isinstance(g, str):
        g = [x.strip() for x in g.split(',') if x.strip()]
    return tuple(g)


#: J20-g (1저자 비준 09-30 "권고대로" — *"하나하나씩 쳐내가자"*) — 인계표에는 **1저자와 함수 단위로 같이 확인한 웹앱 열만** 싣는다.
#:   09-19 census ✅ 는 필요조건일 뿐이다.  함수 검토가 하나 끝날 때마다 (열 패턴, 검토 기록) 을 더한다 — 정본 = 체크리스트
#:   `docs/lhs_handover_checklist_20260929.md` §5 함수 검토표 · 판정 J20-g.
WA_REVIEWED = (
    (r'area_(.+)_n', 'calc_interface_area (dem_analysis_core.py:131–168) — 1저자 검토 09-30 · 수정 불요 · J20-g'),
    (r'se_se_cn(_std)?', 'calc_se_se_cn (dem_analysis_core.py:232–344) — 1저자 검토 09-30 · 수정 불요 · 평균 = 2 × area_SE_SE_n / SE '
                         '입자 수 (생성기 관문 · 09-30 실측 130/130 · 64/64 차이 0) · 같은 함수의 _perc · _eff_area · _aug 는 ② · ⑦ · ⑤ 차례 · J20-i'),
    (r'am_am_(cn(_std)?|n_contacts)', 'calc_am_am_cn (dem_analysis_core.py:347–375) — 1저자 검토 09-30 · 수정 불요 · am_am_n_contacts = AM–AM '
                                      '쌍 개수 합 · am_am_cn = 2 × am_am_n_contacts / AM 입자 수 (생성기 관문 · 09-30 실측 130/130 · 64/64 차이 0) · '
                                      'mono 포함 (상별 열 아님) · am_am_mean_area · am_am_total_area 는 ⑦ 차례 · J20-j'),
    (r'am_se_cn_(mean|surface_weighted|std|median|max)|(AM_P|AM_S)_se_cn_(mean|std|median|max)|(am|AM_P|AM_S)_vulnerable_pct',
     'calc_am_isolation_risk (dem_analysis_core.py:781–855) → analyze_contacts.py:452–468 — 1저자 검토 09-30 · 수정 불요 (7a 로 전체 '
     'std · median · max 추가) · 관문 G1–G7 (상별 평균 × 상 입자 수 = area_<상>_SE_n · 전체 평균 × AM 수 = area_AM전체_SE_n · 고립 개수 가중 · '
     'max · median · 합동 std · 표면 가중 = 설계 반경) · 고립 비율 = SE 접촉 0–1 개 (census COND_cov 오분류 → ✅ 승격 · LHS-23) · J20-k 7c'),
    (r'percolation_pct|top_reachable_pct|n_components|n_large_components|ionic_active_pct|se_se_cn_(n_)?perc',
     'calc_percolation (dem_analysis_core.py:451–) · calc_ionic_active_am (:631–) · calc_se_se_cn 관통 부분 (:320–361) → analyze_contacts.py:404–413 — '
     'J20-b 감사 (WSL 130/130 CLEAN · 밴드 L0 130/130 · 폴백 0 · 겹침 0 · 재현 = 정본) · 1저자 비준 10-01 · 관문 P1–P3 (관통 일관 + 수확기 '
     '독립 재현 · 범위 · 관통 SE 개수 = percolation_pct × N_SE) · F3 한정어 (LHS-19) · top_reachable · ionic_active = census 오분류 → ✅ (LHS-20) · J20-b ②'),
    (r'ionic_(dead|no_se)_pct|(AM_P|AM_S)_ionic_(active|dead|no_se)_pct',
     'calc_ionic_active_am (dem_analysis_core.py:631–) → analyze_contacts — v1.1 ② (1저자 비준 10-01): 계산하고 버리던 단절 · 무접촉 내보내기 + '
     '상별 단절 · 무접촉 계산 추가 (시험 먼저 · analyze_contacts --selftest ⑬–⑱) · 관문 v1.1 D1–D5 (합 100 · 상별 합 100 · 정수 개수 · 상별 개수 '
     '합 = 전체 · 무접촉 ≤ 고립 위험)'),
    (r'se_se_cn_aug(_std|_n_extra|_h_spread_sim)?',
     'calc_se_se_cn F1 (dem_analysis_core.py:303–) → analyze_contacts.py:438–441 — J20-s ⑤ 감사 · 1저자 비준 10-04 ("권고대로") · 한정어 (h 10 nm '
     '출처 없는 모델 상수 · SE–SE 만 · 반올림 쌍) · 관문 ⑤F1 (aug = se_se_cn + 2 · n_extra / N_SE · 10-01 실측 130/130 · 64/64 상대차 ≤ 2.2e-16) · '
     'RGL-05 (10-05): 관문 순서 = 원천 근거 (se_se_cn · 수확 N_SE) · F1 네 열 (std 포함) 필수 → 유한 → 형/범위 (CN · std ≥ 0 · n_extra 0 이상 정수 · '
     'h > 0) → 식 · 최종 레코드 재검'),
    (r'fracture_index_force|n_total_AM_AM_force|frac_(intact|microcrack|multicrack|fragmentation|pulverization)_force_pct|'
     r'n_(intact|microcrack|multicrack|fragmentation|pulverization)_force_AM_AM',
     'calc_fracture_stages (dem_analysis_core.py:977–) · fracture_model.fracture_classify_force_sim — J20-s ⑥ 감사 (LHS-31) · 1저자 비준 10-04 · '
     '힘 기반 전체 집계만 (δ 판 · 상 쌍별 = WA_EXCLUDED) · 관문 ⑥R1–R3 (단계 개수 합 = 전체 · 비율 · 지수 = 반올림 폭 안 · 전체 ≤ am_am_n_contacts) · '
     '10-01 실측 130/130 · 64/64 (전체 = am_am_n_contacts 194/194) · RGL-05 (10-05): 관문 순서 = 원천 근거 (am_am_n_contacts) · 단계 개수 · '
     '(N > 0 이면) 비율 · 지수 필수 → 유한 → 형/범위 (개수 0 이상 정수 · 비율 [0, 100] · 지수 [0, 1] — 반올림 반폭은 식 잔차에만) → 식 · '
     'AM–AM 접촉 0 = 파괴 키 없음 (확인한 상태) · 최종 레코드 재검'),
    (r'area_(AM_P|AM_S|SE|AM전체)_(AM_P|AM_S|SE)_(mean|total)|se_se_cn_eff_area(_perc)?|am_am_(mean|total)_area',
     'calc_interface_area (dem_analysis_core.py:191–) · calc_se_se_cn 면적 (:303–) · calc_am_am_cn (:443–) — J20-s ⑦ 감사 · 1저자 비준 10-04 · '
     'c_cpl[22] = 두 구 교차원 넓이의 정확식 (A_dem_geometric · 작은 δ 에서 Hertz πR*δ 의 ≈ 2 배 · L1-04) · 관문 ⑦A1–A5 (평균 × 개수 = 총합 · '
     '접촉 0 쌍 평균 N/A · AM전체 = 상별 합 · AM–AM 총합 = 쌍 합 · eff_area = 2 × SE–SE 총합 / (N_SE · 4π r_SE²) · eff_area_perc 빈칸 ⟺ 비관통) · '
     '10-01 실측 130/130 · 64/64 · path_hop_area 제외 (LHS-32) · RGL-05 (10-05): 관문 순서 = 원천 근거 (쌍 개수 · 상 유무 · am_am_n_contacts · '
     'percolation_pct · 설계 r_SE · 수확 N_SE) → 유한 → 형/범위 (면적 · 면적 비 ≥ 0 · 개수 0 이상 정수) → 식 · 쌍 · AM–AM 의 개수 · 총합 · 평균을 '
     '함께 정규화 (상 부재 = 세 키 빈칸 · 접촉 0 = 0 · 0 · 평균 N/A · 개수 없이 총합 · 평균만 = 거부) · 최종 레코드 재검'),
)
#: 7c (J20-k · 1저자 비준 10-01 *"ㄱㄱ 하자"*) — 09-19 census 판정을 **바꿔 싣는** 열 (열 사전에 옛 판정을 병기한다).  census 에 없는 키
#:   (7a 새 키) 는 웹앱 배치 머리 (metrics_flat) 에 있을 때만 싣는다 — 옛 배치에 없는 키가 빈칸 = '측정된 N/A' 로 읽히지 않게.
_WA_OVR_VUL = ('✅ 쓴다 (승격 · LHS-23)', 'SE 접촉 0–1 개인 AM 의 비율 — 접촉 위상만 센다 (calc_am_isolation_risk · coverage 값을 읽지 않고 '
               '다른 단계가 덮어쓰지도 않는다) · 09-19 census 의 COND_cov ("coverage 문턱 기반") 는 오분류 (LHS-23)')
_WA_OVR_7A = ('✅ 쓴다 (새 키 · J20-k 7a)', 'AM 전 입자 AM–SE CN 분포 — 7a (09-30) 에 웹앱이 내보내기 시작한 키 · 09-19 census 에 없다 · '
              '상별 통계와 같은 counts · 같은 함수 (calc_am_isolation_risk)')
_WA_OVR_PERC = ('✅ 쓴다 (승격 · LHS-20)', 'SE 그래프 양 — calc_percolation 의 위 밴드 성분 · calc_ionic_active_am 의 AM–SE 접촉 유무 × '
                'top-reachable SE (coverage 값을 읽지 않는다) · 09-19 census 의 COND_cov 는 오분류 (LHS-20 · 1저자 비준 10-01)')
_WA_OVR_DEC = ('✅ 쓴다 (새 키 · v1.1 ②)', '경로 기준 고립의 분해 — 웹앱 v1.1 (10-01) 이 내보내기 시작한 키 · calc_ionic_active_am 이 계산하고 '
               '버리던 단절 · 무접촉 (상별 단절 · 무접촉은 이번에 계산 추가) · 활성 · 단절 · 무접촉 세 집합 하나에서 · 09-19 census 에 없다')
WA_VERDICT_OVERRIDE = {'am_vulnerable_pct': _WA_OVR_VUL, 'AM_P_vulnerable_pct': _WA_OVR_VUL, 'AM_S_vulnerable_pct': _WA_OVR_VUL,
                       'am_se_cn_std': _WA_OVR_7A, 'am_se_cn_median': _WA_OVR_7A, 'am_se_cn_max': _WA_OVR_7A,
                       'top_reachable_pct': _WA_OVR_PERC, 'ionic_active_pct': _WA_OVR_PERC,
                       **{k: _WA_OVR_DEC for k in WA_IONIC_DEC_KEYS}}


def wa_verdicts(wv):
    """7c — census 판정 + `WA_VERDICT_OVERRIDE` → (verdict, why).  census 에 있는 키는 판정을 바꾸고 옛 판정을 why 에 병기 ·
    census 밖 키는 웹앱 배치 머리 (행 키) 에 있을 때만 더한다.  `build_handover` 와 `column_dictionary` 가 같은 것을 쓴다."""
    v = dict((wv or {}).get('verdict') or {})
    why = dict((wv or {}).get('why') or {})
    hdr = set()
    for row in ((wv or {}).get('rows') or {}).values():
        hdr.update(row.keys())
    for c, (vd, reason) in WA_VERDICT_OVERRIDE.items():
        if c in v:
            why[c] = f'{reason} (09-19 census: {v[c]} — {why.get(c) or "사유 없음"})'
            v[c] = vd
        elif c in hdr:
            v[c], why[c] = vd, reason
    return v, why


#: J20-i — 표에 함께 실린 se_se_cn 과 area_SE_SE_n 의 항등식 (se_se_cn = 2 × area_SE_SE_n / N_SE) 허용 상대차.  metrics_flat 은 repr
#:   정밀도라 실측 차이는 0 이다 — 부동소수 여유일 뿐 물리 허용치가 아니다.
WA_CN_IDENTITY_TOL = 1e-9
#: J20-j — 웹앱 원 행의 AM–AM 쌍 개수 열 (calc_interface_area 는 두 상 이름을 정렬해 잇는다 · 접촉 0 인 쌍은 키가 없다 = 0 · mono 는 반지름 이름 하나)
WA_AM_AM_PAIR = re.compile(r'area_(AM_P|AM_S)_(AM_P|AM_S)_n')


def wa_review_note(col):
    """J20-g — 같이 확인한 열이면 검토 기록, 아니면 None."""
    for pat, note in WA_REVIEWED:
        if re.fullmatch(pat, col) is not None:
            return note
    return None


def wa_reviewed(col):
    """J20-g — 1저자와 같이 확인한 웹앱 열인가."""
    return wa_review_note(col) is not None


#: J20-k (B) (1저자 09-30 — *"인계할때는 중복되더라도 잘 채워서 보내야될듯"* · J20-f (A) 개정) — mono (2-type) 침대의 **상별** 열은
#:   **설계 상 칸**에 단일 AM 값을 싣는다.  설계 `block` (mono_AM_P → AM_P · mono_AM_S → AM_S) 이 상을 정한다.  웹앱은 AM 이 한 종류인 덱의
#:   AM 을 반지름으로 AM_P/AM_S 라 부르므로 (`type_map_resolve` · r > 4 µm) 이름이 설계와 다른 침대 (09-30 실측 130 의 5 · 64 의 4 — 전부 설계
#:   AM_P 인데 r ≤ 4 µm) 는 그 이름의 값을 설계 이름 칸으로 **옮기고** 웹앱 이름을 `wa_mono_phase_name_webapp` 에 남긴다.  설계에 없는 상의
#:   칸은 빈칸 (N/A · 0 아님).  수확기 열도 같은 규칙 — 수확기는 mono 의 상을 `AM` 하나로 라벨하므로 (`phase_counts.AM` · `coverage_detail.
#:   counts.AM` · `wall_touch.AM` · `coverage_AM_only` = `coverage_AM_total`) 그 값을 설계 상 칸에 싣는다 (coverage 상별 · n_AM_*_measured
#:   (`LHS-21`) · cov_*_n_valid · 벽 접촉 비율).  설계 block 과 수확 모양 (n_types · phase_counts · coverage 상태 · AM_only = 전체) 이 어긋나거나
#:   둘 중 하나를 모르면 **거부** — 조용히 (A) 로 돌아가면 한 표에 두 규약이 섞인다.  (A) 는 09-30 오전 판 (`lhs_handover_20260930.csv` 까지).
WA_PHASE_COL = re.compile(r'(^|_)AM_[PS](_|$)')
WA_PHASE_TOKEN = re.compile(r'(?<![A-Za-z0-9])AM_[PS](?![A-Za-z0-9])')     # 이름 안의 상 토큰 전부 (area_AM_S_AM_S_n 은 둘)
MONO_BLOCKS = {'mono_AM_P': 'AM_P', 'mono_AM_S': 'AM_S'}
MONO_DESIGN_NOTE = ('mono (2-type) 침대: 설계 상 칸 = 단일 AM 값 (전체 열과 중복 · J20-k (B)) — 설계 block 의 상 (mono_AM_P → AM_P · '
                    'mono_AM_S → AM_S) 칸에 싣고 설계에 없는 상의 칸은 빈칸 (N/A · 0 아님) · 웹앱 반지름 이름이 설계와 다르면 설계 이름 칸으로 '
                    '옮겼다 (웹앱 이름 = wa_mono_phase_name_webapp (정본 인계표 열))')
MONO_PHASE_NOTE = MONO_DESIGN_NOTE          # (A) 시절 이름 — 호환


#: J20-h (1저자 비준 09-30 — *"bimodal 에서 빠진 쌍을 0 으로 채우게 · 시험 먼저"*) — `calc_interface_area` 는 접촉이 0 인 쌍의 키를 만들지 않는다
#:   (dem_analysis_core.py:131–168 — 덤프에 나온 쌍만 센다) → metrics_flat 빈칸.  두 상이 다 있는 침대에서 그 뜻은 **측정된 0** 이다.
WA_PAIR_COUNT = re.compile(r'area_(AM_P|AM_S|SE|AM전체)_(AM_P|AM_S|SE)_n')
WA_PAIR_TOTAL = re.compile(r'area_(AM_P|AM_S|SE|AM전체)_(AM_P|AM_S|SE)_total')     # ⑦ — 접촉 0 쌍 총합 = 0 (J20-h 와 같은 규칙 · J20-s)
PAIR_ZERO_NOTE = ('접촉 0 인 쌍 = 0 — 웹앱 `calc_interface_area` 는 접촉이 없는 쌍의 키를 만들지 않아 빈칸이 되므로, 두 상이 다 있는 침대 '
                  '(수확 `phase_counts`) 에서 생성기가 0 으로 채운다 (J20-h) · mono 는 설계 상으로 판단 (J20-k (B)) · 상이 없으면 빈칸 (N/A) · '
                  '0 으로 채우는 것은 그 쌍의 세 키 (개수 · 총합 · 평균) 가 웹앱 행에 모두 빈칸일 때만 — 개수 없이 총합 · 평균이 있으면 거부 '
                  '(누락 → 0 채움 금지 · RGL-05)')


def _phase_n(pc, ph):
    """수확 `phase_counts` 에서 상의 입자 수 — `AM전체` 는 AM (mono) + AM_P + AM_S."""
    if ph == 'AM전체':
        return sum(int(pc.get(k, 0) or 0) for k in ('AM', 'AM_P', 'AM_S'))
    return int(pc.get(ph, 0) or 0)


def _phase_n_mono(pc, ph, dp):
    """J20-k (B) — mono 침대 (설계 상 dp) 에서 상 ph 의 입자 수: 설계 상 = 수확 `AM` · 설계에 없는 상 = 0 · 그 밖은 `_phase_n`."""
    if dp is None:
        return _phase_n(pc, ph)
    if ph == dp:
        return _phase_n(pc, 'AM전체')
    if ph in ('AM_P', 'AM_S'):
        return 0
    return _phase_n(pc, ph)


def _phase_swap(col, a, b):
    """열 이름의 상 토큰 a → b 전부 (mono: 웹앱 반지름 이름 ↔ 설계 상 · area_AM_S_AM_S_n → area_AM_P_AM_P_n)."""
    return WA_PHASE_TOKEN.sub(lambda m: b if m.group(0) == a else m.group(0), col)


def _mono_path(path, dp, op):
    """J20-k (B) — 수확 JSON 경로의 상 키: 설계 상 → `AM` (수확기 mono 라벨) · 설계에 없는 상 → None (빈칸)."""
    if any(k == op for k in path):
        return None
    return tuple('AM' if k == dp else k for k in path)


def _mono_design_phase(r, h, case):
    """J20-k (B) — 설계행 · 수확 한 건 → (설계 상, 설계에 없는 상) 또는 (None, None) (bimodal).

    설계 `block` 과 수확 모양 (n_types · phase_counts · coverage 상별 상태 · AM_only = 전체) 이 어긋나거나 둘 중 하나를 모르면 `FillRefusal`
    — 조용히 (A) 로 돌아가지 않는다 (한 표에 두 규약이 섞인다).
    """
    blk = r.get('block')
    if blk not in (None, '') and str(blk).startswith('mono') and blk not in MONO_BLOCKS:
        raise FillRefusal(f'{case}: 설계 block {blk!r} — 아는 mono 라벨은 {sorted(MONO_BLOCKS)} 뿐이다 (설계 상을 정할 수 없다 · J20-k (B))')
    dp = MONO_BLOCKS.get(blk)
    nt = h.get('n_types')
    if dp is not None and nt is None:
        raise FillRefusal(f'{case}: 설계 block {blk} 인데 수확 JSON 에 n_types 가 없다 — 수확이 mono 인지 확인할 수 없어 설계 상 칸에 싣지 않는다 '
                          '(J20-k (B))')
    h_mono = nt is not None and int(nt) == 2
    if (dp is not None) != h_mono:
        raise FillRefusal(f'{case}: 설계 block {blk!r} ↔ 수확 n_types {nt!r} 가 어긋난다 — 설계 · 수확이 다른 침대거나 설계행에 block 이 없다 '
                          '(J20-k (B) 를 적용할 수 없다)')
    if dp is None:
        return None, None
    pc = h.get('phase_counts')
    if not isinstance(pc, dict):
        raise FillRefusal(f'{case}: mono 인데 수확 JSON 에 phase_counts 가 없다 — 단일 AM 입자 수를 모른다 (J20-k (B))')
    if _phase_n(pc, 'AM') <= 0 or _phase_n(pc, 'AM_P') > 0 or _phase_n(pc, 'AM_S') > 0:
        raise FillRefusal(f'{case}: mono 인데 phase_counts {pc} 가 수확기 mono 모양 (AM 하나 · AM_P/AM_S 없음) 이 아니다 (J20-k (B))')
    st = h.get('status') or {}
    for k in ('coverage_AM_P', 'coverage_AM_S'):
        if k in st and st[k] != 'N_A_PHASE_ABSENT':
            raise FillRefusal(f'{case}: mono 인데 수확 status.{k} = {st[k]!r} ≠ N_A_PHASE_ABSENT — 상별 값이 따로 있는 수확은 mono 모양이 아니다 '
                              '(J20-k (B))')
    only, tot = h.get('coverage_AM_only_hertz_pct'), h.get('coverage_AM_total_hertz_pct')
    if only is not None and tot is not None and float(only) != float(tot):
        raise FillRefusal(f'{case}: mono 인데 coverage_AM_only {only!r} ≠ coverage_AM_total {tot!r} — 단일 AM = 전체 항등식이 깨졌다 (J20-k (B))')
    return dp, ('AM_S' if dp == 'AM_P' else 'AM_P')


def wa_phase_specific(col):
    """AM_P / AM_S 한 상에 딸린 열인가 (상별 CN · 상별 쌍 개수) — AM전체 · 소문자 am_ 열은 아니다."""
    return WA_PHASE_COL.search(col) is not None


#: J20-a ⓓ (1저자 비준 09-28 밤 "권고하는걸로") — 상별 바닥 벽 · 플래튼 **접촉 입자 비율** (수확 v3 `wall_touch`).  CN 이 벽 · 플래튼
#:   접촉을 세지 않아 벽에 닿은 입자의 CN 이 낮은 몫을 가르는 설명 변수.  규칙 = 수확기 `WALL_TOUCH_RULE` (겹침 깊이 > 0 — z − r < 0 ·
#:   z + r > plate_z · 접선 = 0 은 안 셈 · 10-01 문구 정정: 옛 문구 "≤ · ≥" 는 수확기 규칙과 달랐다).
#:   벽 인접 입자를 뺀 CN 은 택하지 않았다 — AM_P 가 두께 2–10 개인 침대에서 남는 입자가 거의 없어 정의가 흔들린다.
WALL_TOUCH_PHASES = ('SE', 'AM_P', 'AM_S', 'AM')
HANDOVER_WALL_TOUCH = tuple(
    (f'wall_touch_frac_{ph}_{side}', ph, side,
     f'{ph} 입자 중 ' + ('바닥 벽 (z − r < 0)' if side == 'floor' else '플래튼 (z + r > plate_z)')
     + ' 에 닿은 비율 (0–1) · 닿음 = 겹침 깊이 > 0 (접선은 안 셈 · 수확기 WALL_TOUCH_RULE) · '
     + ('AM = AM_P + AM_S 합친 모집단 (am_se_cn_mean 과 같은 분모) · ' if ph == 'AM' else '') + '상이 없으면 빈칸 (N/A)')
    for ph in WALL_TOUCH_PHASES for side in ('floor', 'plate'))


def load_webapp(dir_path, census_path=None):
    """`scripts/lhs_webapp_batch.py` 산출 (status.json · metrics_flat.csv) + 전수 판정 census → `build_handover(webapp=…)` 인자."""
    root = pathlib.Path(__file__).resolve().parent.parent
    d = pathlib.Path(dir_path)
    st = json.loads((d / 'status.json').read_text(encoding='utf-8'))
    if st.get('schema') != 'lhs_webapp_batch/v1':
        raise FillRefusal(f'{d}/status.json schema {st.get("schema")!r} ≠ lhs_webapp_batch/v1')
    rows = {}
    with (d / 'metrics_flat.csv').open(encoding='utf-8', newline='') as fh:
        for r in csv.DictReader(fh):
            if r['case'] in rows:
                raise FillRefusal(f'{d}/metrics_flat.csv: case {r["case"]!r} 가 둘 이상이다')
            rows[r['case']] = r
    cp = pathlib.Path(census_path or (root / DEFAULT_CENSUS_TSV))
    verdict, why = {}, {}
    with cp.open(encoding='utf-8') as fh:
        for r in csv.DictReader(fh, delimiter='\t'):
            verdict[r['column']] = r['verdict']
            why[r['column']] = r.get('why') or ''
    return {'verdict': verdict, 'why': why, 'status': st.get('cases') or {}, 'rows': rows,
            'source': str(d), 'runs': st.get('runs') or [], 'stop_after': st.get('stop_after')}


#  ═══ 망 τ 묶음 (v1.2) — 열 사전 · 원천 로더 ═════════════════════════════════════════════════════════════════════════════════════
#  ★ τ 명명 규약 (CLAUDE.md ★★ τ 블록 · 정본 `docs/reviews/tau_conventions_judgment_v2_20261003.md` §5-1 열 · §5-2 게이트 · §5-3 한정어).
#    열 이름 · 순서 · 값 · 직렬화 = **tau_flux 그대로** (`column_names` · `case_row` · `_cell`) — 생성기는 τ 를 계산하지 않는다 (규율 ① —
#    다시 짜면 게이트 G1–G6 · 공용 기술 검사 · 모드 꼬리가 두 벌이 된다).  여기는 열 사전의 **뜻**과 원천의 **출처 관문**만 둔다.
#: v2 (10-05 RGLR3-02) — 출처 관문 P4 (인계 때 망 정지 계약 재검사 · 활성 세대 · 읽기 안정) · 케이스마다 같은 세대 검사 기록.  v1 (P0–P3) 원천은 받지 않는다.
TAU_NET_SCHEMA = 'lhs_tau_net/v2'
TAU_NET_SOURCE = 'tau_flux'
#: ★ 10-05 RGLR3-02 (Codex 4차 재검증 §3 · §8-2) — 인계 때 케이스마다 다시 도는 같은 세대 검사 (이 순서 · 출처 부록 same_generation_checks 에 그대로).
#:   하나라도 실패하면 생성기가 거부한다 (P0–P3 과 같은 규칙 — 그 케이스 τ 를 빈칸 + 사유로 싣지 않는다) ⇒ 출처 부록에 행이 있다 = 이 검사를 다 통과했다.
#:   ★ 10-06 밤 (G2R-01 · 02) — P4_model_generation = 공용 세대 계약 (tau_flux.network_generation_contract — 모드마다 허용 모델 조합 · 닫힌 열거 ·
#:   부분 결손 거부) + ★ 10-06 밤 (G2RR-01) 도장 ↔ 레코드 세대 대조 (pipeline_service.provenance_generation_problem — g2 = 도장 네 세대 값이 전부 있고 =
#:   레코드에서 유도한 기대값 = 세대 2 값 · inferred_legacy = 도장이 확인된 역사 도장 스키마 (194 v1.2) 일 때만) + 배치 manifest 기대 세대 (주면 ·
#:   tau_manifest_expected_generation).  옛 판은 도장의 키 존재 · g2 값 하나만 보았다 (provenance_claims_generation2 · provenance_predates_generation2 — 삭제).
TAU_SAME_GEN_CHECKS = ('P0_records', 'P1_run_id', 'P2_input_digest', 'P3_batch_tie', 'P4_model_generation', 'P4_stop_contract', 'P4_generation',
                       'P4_read_stable')
#: 대조의 기준 — **지금 파일끼리** (배치 기록 status.json · metrics_flat 과 폴더의 모든 사본) · 게시 시점 해시가 없다 ⇒ 모든 사본 (dual · 모드 파일 ·
#:   legacy · full_metrics · 도장) 을 함께 일관되게 바꾼 편집은 못 잡는다 (Codex RGLR3-02 §8-2 마지막 항 — 잡으려면 게시 때 결과 해시를 배치 기록에 묶어야 한다).
TAU_SAME_GEN_BASIS = 'current_files_no_publish_hash'
#: ★ 10-06 밤 (G2RR-01 · Codex 세대 2 재검증 §2 "새 배치 manifest 의 기대 세대와도 교차 대조") — 배치 manifest 가 선언하는 기대 망 세대의 키 · 허용 값
#:   (= tau_flux.NET_GEN_G2 · NET_GEN_LEGACY — test_gen2_stamp_record 가 대조).  선언은 새 194 실행 봉인 (판정문 §7-3) 이 쓴다 — 194 v1.2 런처 manifest
#:   (network_parallel_launcher/v1) 에는 없다 (그 배치는 manifest 대조 없이 확인된 역사 도장 스키마로만 읽는다).
TAU_MANIFEST_GENERATION_KEY = 'expected_network_generation'
TAU_EXPECTED_GENERATIONS = ('g2', 'inferred_legacy')


def tau_manifest_expected_generation(manifest):
    """배치 manifest (dict · JSON 경로) → 기대 망 세대 ('g2' | 'inferred_legacy') — `load_tau_results(expected_generation=)` · CLI `--tau-batch-manifest`.
    못 읽음 · 객체 아님 · 선언 (`TAU_MANIFEST_GENERATION_KEY`) 없음 · 모르는 값 = FillRefusal (교차 대조를 약속했는데 못 하면 통과로 치지 않는다)."""
    m = manifest
    if not isinstance(m, dict):
        try:
            m = json.loads(pathlib.Path(manifest).read_text(encoding='utf-8'))
        except (OSError, ValueError, TypeError) as e:
            raise FillRefusal(f'τ 기대 세대 — 배치 manifest {str(manifest)!r} 를 못 읽었다 ({type(e).__name__}) — 기대 세대 교차 대조를 할 수 없다') from None
    v = m.get(TAU_MANIFEST_GENERATION_KEY) if isinstance(m, dict) else None
    if v not in TAU_EXPECTED_GENERATIONS:
        raise FillRefusal(f'τ 기대 세대 — 배치 manifest 의 {TAU_MANIFEST_GENERATION_KEY}={v!r} ∉ {list(TAU_EXPECTED_GENERATIONS)} — 기대 세대를 선언하지 '
                          '않은 (또는 모르는 값의) manifest 로는 교차 대조를 할 수 없다 (선언 = 새 194 실행 봉인 · 판정문 §7-3)')
    return v
#: ★ 10-06 저녁 세대 2 (1저자 비준) — 모드 셋째 hertz_h12 (Hertz 이온 민감도 · tau_flux.MODES 와 같아야 한다 — selftest ㉙m).
TAU_NET_MODES = ('hertz', 'physics', 'hertz_h12')
TAU_NET_H12 = 'hertz_h12'
TAU_NET_VERDICT = ('✅ 싣는다 (망 τ 묶음 · v1.2 — Codex 10-05 3차 재검증 §3 Q5 · §6-5 · LW 제외) · ⚠ G6 (협착 세대) — 두 모드 모두 물리 타깃 '
                   '(실험 절대 대조) HOLD · 값은 싣는다 (ML 기술자 전용)')
#: H12 열 = 민감도 부록 전용 (기본 학습 열 아님 · 배포는 `lhs_release_build --appendix` 로만 — 주 배포 표에 넣으면 거부).
TAU_NET_VERDICT_H12 = ('⚠ 민감도 부록 전용 (H12 = Hertz ψ 곱 협착 + 구 조각 bulk · 10-06 1저자 비준 C1-3) — **기본 학습 열에 넣지 않는다** · '
                       '행마다 H0 (hertz 열) 와 짝인 **두 규약 (협착 · bulk 를 함께 바꾼) 의 쌍대응 시나리오** — 오차막대 · 상하한 · 신뢰구간이 아니다 '
                       '(구 사슬 z = 2 · s = 0.45 에서 FV 기준 전도도가 H0 · H12 둘 다보다 크다 — Codex G2R-04) · 배포 = 부록 '
                       '(lhs_release_build --appendix) · G6 물리 타깃 HOLD 그대로')
_TAU_AREA = {'hertz': ('hertz = LIGGGHTS c_cpl[22] 기하 교차 원판 π(rδ − δ²/4) (같은 반지름 r · 겹침 δ — 탄성 πR*δ 의 (2 − δ/2r) 배 · '
                       '"Hertz" 는 이름만 · L1-04) · 협착 maxwell_halfspace · bulk 원기둥 반 d (H0 · 세대 1 과 같은 간선)'),
             'physics': ('physics = 행의 ion_net_area_rule_physics — physics_g2 (2026-10-06 저녁 세대 2 · plastic_coverage.film_area_g2: '
                         'A = max(c_cpl[22] 원판, min(Tabor F/H · 정확 lens/h · 원판 상한 π r_min²)) · 쌍별 E* (SE–SE 13.19 · AM–SE 22.41 GPa · '
                         'AM–AM = 원판 그대로) · µm + h 5 nm [미확인] · 원판 floor 라 간선마다 R_c(physics) ≤ R_c(hertz)) · physics_g1 (2026-10-06 '
                         '전 산출물 · v1 Tabor · 부피 · 기하 cap 면적 — 접촉별 **상한값** · 표면 한도 없음 · LHS-25 · sim 단위 혼용 DESC-03) · '
                         '협착 = 그 행의 ion_net_constriction_physics (세대 2 mikic_psi_multiply = ψ 곱셈 · 2026-10-06 기본 · '
                         '세대 1 mikic_psi_divide = ψ 분모 · 절벽 · legacy_divide = 2026-10-06 전 산출물)'),
             'hertz_h12': ('hertz_h12 = Hertz 면적 (c_cpl[22] 기하 원판 — hertz 와 같은 면적 · 같은 망) 위의 H12 민감도: 협착 ψ 곱 '
                           '(mikic_psi_multiply · R_c = ψ/(2σa) · ψ ≤ 1e-4 → 0) + 구 조각 bulk (sphere_segment · h_i²/(σ·V_i)) — 짝으로만 '
                           '(ψ 단독 H1 기각 · 모든 기하 과전도) · z ≤ 10 에서 ±5 % 개선 · z ≈ 12 · s ≳ 0.3 (LHSx 고밀) 에서 +20–28 % 과전도 (설계 측정)')}
#: 한정어 (v2 §5-3) — 'tortuosity factor' 라는 이름은 tau2 열에만 쓴다 (규약) → 일반 한정어에는 그 낱말을 넣지 않는다.
#:   ★ 10-06 (`L2-01` 세대 2 · 1저자 개정) — physics 협착식의 세대가 둘이 됐다.  열 사전은 행 값을 보지 않으므로 (column_dictionary(cols)) 두 세대를
#:   다 적고, 행의 세대는 그 행의 ion_net_psi_physics · ion_net_constriction_physics 칸이 정한다 (세대가 다른 행을 표기 없이 섞지 않는다).
CAVEAT_TAU_NET = ('세대 (행마다 ion_net_constriction · ion_net_psi · ion_net_area_rule · ion_net_electrode · ion_net_bulk <모드> + 세대 칸 ion_net_generation '
                  '(g2 · inferred_legacy) — 세대가 다른 행을 표기 없이 섞지 않는다 · tau_flux · 인계 생성기가 행마다 세대 계약 (모드마다 허용 모델 조합의 닫힌 표 · '
                  '10-06 밤 G2R-01 · 02) 을 먼저 보고 섞임을 거부한다): ★ 2026-10-06 저녁 세대 2 = 전극 정확 Dirichlet (dirichlet_exact — '
                  '바닥 띠 V = 1 · 위 띠 V = 0 고정 · 옛 가상 전원 g_b 제거 · L2-05 · 배포값 변화 ≤ 1.5e-4 = 5–6 째 자리) · physics 면적 physics_g2 · '
                  'ψ 곱셈 · 표기 없는 옛 산출물 = virtual_source_legacy · physics_g1 · 원기둥 bulk (이력 사실).  협착식: hertz = 1세대 반공간 '
                  'Maxwell R_c = 1/(2σa) + 원기둥 bulk (H0) — z ≤ 10 에서 tau2 −12 … −28 % 쪽 편향 · z ≈ 12 에서 ±5 % 상쇄 (설계 측정 · H12 민감도 열이 '
                  '행마다 괄호) · physics = ψ 배치 — 세대 2 (multiply · '
                  '2026-10-06 기본 · 독립 기준해 AREA-09 STEP 4) R_c = ψ/(2σa) (+ 원기둥 bulk = 과전도 쪽) · 세대 1 (legacy_divide · 2026-10-06 전 산출물) '
                  'R_c = 1/(2σaψ) + ψ < 1e-4 절벽 · 두 세대 모두 ψ ≤ 1e-4 → R_c = 0 (floor 동결) — ML 기술자 전용 · **실험 절대 대조 금지** (G6 HOLD — '
                  '순수 SE 게이트 · 결정 4) · CF (CONTACT_FREE · 협착 0) 가지의 T_CF ≈ 4/z (원기둥 bulk · z = SE–SE 배위수 · 구 조각이면 6/z) = 모형 과전도 — '
                  '상한이 아니다 (q > 1.5 면 값 유지 + 상태 model_over_conduction · 진단 열만) · z 한 축 (Tjaden 식 21 τ_C 와 '
                  '직접 비교 금지) · 형상 · CBD 차단 없음 · σ₀ 펠릿값 위 Holm 접촉 저항 = 부분 이중계상 (방향 tau2↑) · 띠 끝 단락 → tau2 하향 ≤ 4r_SE/L '
                  '(상한 · ion_net_band_frac_<모드> (정본 인계표 열) · 보정한 tau2 는 내지 않는다 — TAU-24) · φ = 전 SE (비관통 · 고립 포함 — dead 부피가 tau2 를 키운다) → 1차 수송량은 f · τ_e (Nguyen Eq 2 · '
                  'electrode) 아님 · 출처 관문 (인계 때 케이스마다 다시 돈다 · 출처 부록 <인계표>_tau_provenance.tsv 의 same_generation_checks — P0 기록 · '
                  'P1 run id · P2 입력 digest · P3 배치 metrics_flat 대조 · P4 망 정지 계약 재검사 (전 사본 · 투영 · σ₀ 짝) · 활성 세대 · 읽기 안정) = '
                  '배치 기록과 지금 파일끼리의 대조 — ⚠ 게시 시점 해시가 없어 모든 사본을 함께 일관되게 바꾼 편집은 못 잡는다 '
                  '(same_generation_basis = current_files_no_publish_hash · Codex RGLR3-02 §8-2)')
CAVEAT_TAU_NET_T2 = ('flux 기반 · 관통 (두 평행 띠 Dirichlet) conventional tortuosity factor (Nguyen Eq 1) — electrode tortuosity factor τ_e '
                     '(Nguyen Eq 2) 가 아니다 · 차단 대칭셀 EIS-TLM 의 τ (Landesfeind Eq 13 형) 와 한정어 없이 비교하지 않는다 · 문헌 tau2 와 맞댈 때 '
                     'Minnmann 은 순수 SE 펠릿 τ² ≡ 1 기준 (σ₀ 1.6 mS/cm @25 °C) — 우리 tau2 는 간선 재료 σ₀ 기준 · ' + CAVEAT_TAU_NET)
_TAU_STATUS = ('이온 망 인계 상태 (tau_flux 게이트 G1–G6 · v2 §5-2 · 먼저 걸린 것 하나) — OK (값) · MODEL_BELOW_CONTINUUM_BOUND (G5 — f > φ · '
               'tau2 < 1 · 원기둥 bulk · physics 절벽의 모델 성질 · **값 유지** + 표지 — 빈칸으로 거르면 코퍼스를 tau2 ≥ 1 쪽으로 선별한다) · '
               'NOT_PERCOLATING (G3 — 비관통 (관통 경로 없음) · 생산자 valid_zero + no_through_path · f = 0 · tau2 · tau 빈칸 (= ∞) · 이온적으로 죽은 '
               '전극으로 읽지 말 것 (ionic_active_pct 는 유한) · 문턱 근처 관통 여부는 상자 크기의 실현값) · BAND_FALLBACK (G1 — 솔버 띠 규칙이 L0 아님 · '
               '값 빈칸) · NOT_COMPUTED (빈칸 + 사유 열).  부류 (RGLR-01): NOT_COMPUTED = **기술적 실패** (입력 결손 · 무효 · 솔버 관문 · 온도 짝 · '
               '관통 불일치 — 값 없음) ↔ BAND_FALLBACK · NOT_PERCOLATING · MODEL_BELOW_CONTINUUM_BOUND = 등록된 **과학적 HOLD** (입력 유효 · 규칙대로 '
               '빈칸 또는 표지) · G6 = 두 모드 모두 물리 타깃 HOLD (값은 싣는다) · 이 칸이 빈칸 = 웹앱 배치 행이 done · partial 이 아니다 (wa_status (정본 인계표 열) · '
               'tau_flux 를 부르지 않았다) · ★ 인계표에는 NOT_COMPUTED 가 실리지 않는다 (10-05 RGLR3-02) — done · partial 행의 폴더가 기술적 결손이면 그 배치의 '
               '망 정지 계약이 done 을 줄 수 없는 상태 (배치 뒤 폴더가 바뀌었다) 이므로 생성기가 인계 때 τ P4 (망 정지 계약 재검사) 에서 거부한다 — 기술적 결손을 '
               '"같은 세대 검증 통과" 행으로 싣지 않는다 (NOT_COMPUTED 는 tau_flux CLI · 웹앱 케이스 페이지의 어휘) · 실린 행 = 출처 부록의 같은 세대 검사 '
               '(P0–P4) 를 다 통과한 케이스 · ★ 10-15 L214 예외 하나 (기술적 실패 아님) — NOT_COMPUTED + 사유 정확히 full_over_conduction = FULL 모형 한계 '
               '(수치 풀이 인증을 통과했으나 사전 고정된 FULL 출력 상한 q > 1.5 를 넘은 모드 · 값 f · tau2 · tau 빈칸 = 미제공 (0 · ∞ 아님) · 거부된 q 와 수치 증서 = '
               'canonical 결과 (network_conductivity_dual.json) 의 증서에 별도 진단으로 보존 · 공용 판정 tau_flux.full_model_limit_problem 을 통과한 레코드만 — '
               'τ P4 망 정지 계약 재검사가 같은 함수로 확인 · 사유만 위조 · 증서 결손 · 틀린 q = 거부) — 이 행은 실린다 · 주 타깃 (Hertz) 이 모형 한계인 행은 '
               'v1.3 주 타깃 배포 관문이 HOLD (행 삭제 · 대체 없음) · Physics · H12 만 모형 한계면 부록 공란 (빈칸 뜻 NA_MODEL_LIMIT)')
_TAU_REASON = ('NOT_COMPUTED 의 사유 (사유 코드 = ":" 앞) — missing_input (망 결과 · 장부 L_gap · L_mc · φ_mc · calc_percolation · 띠 규칙 기록 · '
               '온도 기록 없음) · invalid_input: 세부 (공용 기술 검사 tau_flux.ion_record_problem — 생산자 계약 위반: computed 인데 σ 두 표현이 유한 양수가 '
               '아니거나 서로 다름 (RGLR-02) · 관통 분율 (0, 1] 밖 · 증명된 비관통 조합이 아닌 valid_zero · 모르는 상태 · ★ 10-06 밤 세대 계약 위반 '
               '"invalid_input: 세대 계약 (G2R-01 · 02): …" — H12 를 주 Hertz 자리에 · 모르는 ψ · 전극 · 면적 · bulk · 세대 2 표기 부분 결손 · '
               'tau_flux.network_generation_contract · 레코드 있는 모드 전부) · solver_guard (관통인데 σ 없음 — '
               '생산자 not_computed) · percolation_disagree (G2 — 솔버 관통 ≠ calc_percolation) · temperature_mismatch (G4 — σ₀ 와 σ_full 의 온도가 다르다 · '
               '두 모드의 (σ₀, T) 가 다르다) · generation_invalid: 세부 (10-05 RGLR2-02 — 케이스 폴더의 망 활성 세대가 확정되지 않음: '
               'tau_flux.network_generation_problem — full_metrics ↔ 도장 불일치 · 되돌림 실패 · 중단된 게시 흔적 · 도장 손상 · 두 모드 모두) · 다른 상태면 빈칸 · '
               '인계표 (network 배치 done · partial 행) 에서는 늘 빈칸 — NOT_COMPUTED 행은 생성기가 τ P4 에서 거부한다 (10-05 RGLR3-02) · ★ 10-15 L214 예외 — '
               'full_over_conduction (FULL 모형 한계 · 기술적 실패 사유가 아니다 · 세부 꼬리 없음) 은 인계표에도 실린다 (공용 판정 통과 레코드만 · 위 상태 열 참조)')
_TAU_PER_MODE = {
    'f_ion': ('★ 이온 유효 전도도 비 f = σ_eff/σ₀ ({m} 망 · 무차원 · 단위 1) = σ_ratio × L_gap/L_mc — σ_ratio = 솔버 FULL 해의 무차원 sigma_full '
              '(8 자리 · TAU-25) · L_gap = 판 간격 · L_mc = 질량 보존 두께 = **판 간격 해의 질량보존 두께 재척도 (해 아님)** · 문헌 ε/τ² (Tjaden) · '
              'COMSOL f_e (= 1/N_M) · σ₀ 수치에 무관 · COMSOL 에 넣을 때는 Porous Electrode 보정 User defined (fl) 칸 (같은 틀 L_mc · φ_mc — 10-04 D1 · '
              '앱 예제 Homogenizing a Heterogeneous Electrode Model 식 (1) f_eff = ε/τ) · 판 간격 틀 f_ion_{m}_gap (정본 인계표 열) 과 섞지 않는다 · ⚠ 웹앱 COMSOL 2D '
              '내보내기의 같은 이름 f_ion_{m} 은 판 간격 틀 (σ_full/σ₀ · L_cat · phiSE) = f_ion_{m}_gap (정본 인계표 열) 과 같은 양 (반올림 차 ≤ 0.11 % · '
              'TAU-25) · 값 = 상태 OK · MODEL_BELOW_CONTINUUM_BOUND · NOT_PERCOLATING 이면 0.0 (관통 성분 없음 — 물리적 0) · 그 밖 빈칸 (0 이 아니다)'),
    'f_ion_gap': ('(메타) 판 간격 기준으로 풀린 f = σ_ratio 그대로 ({m} 망 · 무차원) — **φ_mc 와 짝짓지 말 것** (tau2 를 L_gap/L_mc 배 낮춘다) · '
                  '짝은 φ_구합 (판 간격 상자 · 구 부피 합) · 값 규칙은 f_ion_{m} 와 같다'),
    'tau2_ion': ('★ 수송 tortuosity (표시 이름 · 1저자 10-05 밤 · v1.3 — 키 tau2 그대로) = 수송 tortuosity factor T = tortuosity factor tau2 = '
                 'φ_SE,mc / f_ion_{m} ({m} 망 · 무차원 · 단위 1 · **제곱근 아님**) = φ_구합·σ₀/σ_full — 짝 = 기하학적 tortuosity (tortuosity_SE_wall · '
                 '최단경로 길이비 · 다른 양) · 현행 웹앱 케이스 페이지 tau2 와 '
                 '정의상 같은 수 (웹앱은 mS/cm σ (6 자리) 로 계산해 최대 0.11 % 다를 수 있다 · TAU-25) · 문헌 tortuosity factor (Tjaden κ = τ² = '
                 'Landesfeind τ = COMSOL τ_F = TauFactor τ) 와 같은 정의식 — 물리 기준 상태는 다르다 (간선 재료 σ₀ 기준) · COMSOL Tortuosity 칸의 꼴 '
                 '= tau2 (√ 아님 · 종 수송 Eq 6-6 · 배터리 인터페이스는 강하게 시사 — GUI Equation 확인 전에는 "COMSOL 입력" 이라 쓰지 않는다) · '
                 '접촉망 모델 tau2 (Holm 협착 포함 · 원기둥 bulk · z 관통) · 값 = 상태 OK · MODEL_BELOW_CONTINUUM_BOUND (tau2 < 1 이어도 값 유지) · '
                 'NOT_PERCOLATING 이면 빈칸 (= ∞ — 관통 경로 없음) · 그 밖 빈칸 (0 이 아니다)'),
    'tau_ion': ('τ = √tau2 = √T ({m} 망 · 무차원 · 유도량 · τ² 관례의 τ = Minnmann √τ² · Tjaden 식 3 flux τ · 웹앱 τ_Lap,eff) — **COMSOL 입력 아님** '
                '(COMSOL 칸에는 tau2 또는 f) · "수송 tortuosity" 는 tau2 의 이름이다 — 이 √ 값에는 쓰지 않는다 (τ 명명 규약 · v1.3) · '
                'Dijkstra 경로 길이비 (tortuosity_SE_wall) 의 뜻도 아니다 · 값 규칙은 tau2_ion_{m} 와 같다'),
    'ion_net_status': '{m} ' + _TAU_STATUS,
    'ion_net_status_reason': '{m} ' + _TAU_REASON,
    'ion_net_area_mode': '면적 모드 (값 = {m}) — {area}',
    'ion_net_constriction': ('협착식 (G6 세대 메타 · {m}) — maxwell_halfspace (hertz: R_c = 1/(2σa) · ψ 없음 · 1세대) · mikic_psi_multiply (physics '
                             '세대 2: R_c = ψ/(2σa) · ψ 곱셈 · 2026-10-06 기본 · L2-01 · 독립 기준해 AREA-09 STEP 4) · mikic_psi_divide (physics 세대 1: '
                             'R_c = 1/(2σaψ) · ψ 분모 · legacy_divide · ψ < 1e-4 → R_c = 0 절벽 — 2026-10-06 전 산출물) · 두 세대 모두 ψ ≤ 1e-4 → R_c = 0 '
                             '(floor 동결) · 세대가 다른 행을 표기 없이 섞지 않는다 · "unknown:<이름>" = 모르는 저항 모델 · "unknown:mikic/<값>" = 모르는 ψ 배치'),
    'ion_net_psi': ('ψ 배치 ({m} · 세대 표기 · L2-01) — physics · hertz_h12 에만 의미: multiply = 세대 2 (ψ 곱셈 · 2026-10-06 기본 · H12 는 늘 곱셈) · '
                    'legacy_divide = 세대 1 (ψ 분모 · 2026-10-06 전 산출물) · 빈칸 = hertz (ψ 없음) 또는 ψ 기록이 없는 옛 산출물 (09-15 깃발 전 = 세대 1)'),
    'ion_net_area_rule': ('면적 규칙 ({m} · 세대 표기 · 10-06 저녁) — hertz_ccpl22 (hertz · hertz_h12: LIGGGHTS c_cpl[22] 기하 원판) · physics_g2 (physics 세대 2 · '
                          'film_area_g2 규칙 B) · physics_g1 (physics 세대 1 · 표기 없는 옛 산출물 = 이력 사실 — ion_net_generation = inferred_legacy 행에만 '
                          '**추론** 값) · 빈칸 = 그 모드 레코드 없음 (또는 세대 2 표지가 남은 레코드의 빈 칸 — 옛 기본값으로 채우지 않는다 · 그 행은 세대 계약 위반)'),
    'ion_net_electrode': ('전극 ({m} · 세대 표기 · L2-05 · 10-06 저녁) — dirichlet_exact (세대 2: 바닥 띠 V = 1 · 위 띠 V = 0 고정 · G = 바닥 띠 전류) · '
                          'virtual_source_legacy (표기 없는 옛 산출물 — 가상 전원 · 싱크 g_b = max(100·Σg/n, 10·g_max) · 막다른 가지가 σ 를 바꿨다 · '
                          'ion_net_generation = inferred_legacy 행에만 **추론** 값) · 세대 계약 (모드마다 닫힌 표 · 10-06 밤 G2R-01 · 02) 을 어기면 (모르는 값 · '
                          '모드끼리 다름 · 부분 결손) 그 행은 NOT_COMPUTED (invalid_input) · 빈칸 = 레코드 없음 (또는 세대 2 표지가 남은 레코드의 빈 칸 — '
                          '옛 기본값으로 채우지 않는다)'),
    'ion_net_bulk': ('간선 bulk 모형 ({m} · 세대 표기 · C1-3) — cylinder_half_d (H0 · hertz · physics 의 주 값: 반 d 원기둥 (d/2)/(σ·π r²) 두 쪽) · '
                     'sphere_segment (hertz_h12 민감도: 중심 ↔ 접촉 평면 구 조각 h_i²/(σ·V_i)) · 빈칸 = 레코드 없음'),
    'ion_net_band_rule': ('솔버 경계 띠 규칙 ({m} · 안 A 10-04) — L0 (입자 자기 반지름 2 배 · 양 끝 ≥ 3) · L1 · L2 (폴백 — G1 → BAND_FALLBACK) · 빈칸 = '
                          '기록 없는 옛 산출물 (NOT_COMPUTED missing_input)'),
    'ion_net_band_frac': ('띠 분율 ({m} · 무차원 · 기술 열) = (바닥 띠 폭 + 위 띠 폭) / 판 간격 L_gap (솔버 boundary_band_frac · '
                          'network_conductivity.boundary_sets) — L0 = 2 × 2·r_max / L_gap = 4r_SE/L (가장 큰 SE 반지름 · 입자 띠 2r) · L1 = 0.30 '
                          '(15/85 %) · L2 = 관측 z 범위 기준 · 띠 노드를 같은 전위로 묶어 tau2 를 이 비만큼까지 낮출 수 있다 (상한 · TAU-24 — '
                          '게이트가 아니라 한정어) · 보정한 T 는 내지 않는다 (L_eff 보정판 = 런 전 등록 · 1저자 결정 대기) · 기준 길이 = 판 간격 '
                          'L_gap (L_mc 아님) · v1.2 실측 (10-06 · 194 행 · 띠 규칙 L0 194/194 · 두 모드 같은 값) LHS 0.050–0.135 (중앙 0.082) · '
                          'LHSx 0.060–0.157 (중앙 0.096) — 옛 사전의 측정 전 상한 추정값은 철회 (이 실측으로 교체)'),
    'ion_net_basis_check': ('(메타 · 게이트 아님 · {m}) 망 φ (phi_se · 4 자리 · 판 간격 상자 · 구 부피 합) ↔ 장부 φ_mc·L_mc/L_gap (= φ_구합) — ok · '
                            'mismatch:<차> (망과 장부가 다른 판 높이 · 상자 · SE 집합) · unchecked (값 없음) · 게이트로 쓰려면 새 규칙으로 등록 (1저자)'),
}
_TAU_SHARED = {
    'ion_sigma0_mScm': ('σ₀ (mS/cm) = 간선 재료 σ = 펠릿값 (Cronau 2021 SI 그림 S2c µC-Li₆PS₅Cl 평탄 하단 · CL-91 · 온도 런이면 se_material '
                        'Arrhenius 값) — f 의 기준 · COMSOL σ₀ 칸의 짝 · 두 모드 공통 (G4 — 두 모드의 (σ₀, T) 가 다르면 빈칸 + 두 모드 NOT_COMPUTED '
                        'temperature_mismatch) · tau2 · f 는 무차원 σ_ratio 로 계산해 σ₀ 수치에 무관'),
    'ion_sigma0_T_C': 'σ₀ 의 온도 (°C) — 망 기록 temperature_provenance 의 T_C (없으면 규약 기준 T_ref_C = 25 · NOT_MODELLED) · σ₀ 와 같은 규칙으로 빈칸',
    'phi_basis': 'φ 기준 = mass_conserving (φ_SE,mc = 장부 phi_se_mass_conserving · 같은 장부 · v2 D3) — tau2 의 분자',
    'L_basis': '길이 기준 = L_mc (장부 thickness_mass_conserving_um · v2 D3) — f 의 재척도 기준',
    #  ★ 10-06 밤 (G2R-01 · 02 · 1저자 비준) — 공용 세대 계약의 판정 (tau_flux.network_generation_contract · 세 모드 공통)
    'ion_net_generation': ('망 세대 (세대 계약 · 세 모드 공통 · G2R-01 · 02) — g2 = 세대 2 계약 통과 (모드마다 허용 모델 조합의 닫힌 표: 주 Hertz = H0 '
                           'Maxwell 협착 + 원기둥 bulk · H12 = ψ 곱 협착 + 구 조각 bulk · physics = ψ 곱 + physics_g2 + 원기둥 · 셋 다 전극 dirichlet_exact · '
                           '표기 전부 필수 · 세대 2 Hertz 는 H12 필수) · inferred_legacy = 세대 2 표지가 **하나도 없는** 역사 레코드를 옛 세대로 **추론** '
                           '(표기 칸의 virtual_source_legacy · physics_g1 · cylinder_half_d · ψ 분모는 이력 사실로 채운 값이지 레코드에 적힌 값이 아니다 · '
                           '추론은 활성 도장이 확인된 역사 도장 스키마 (194 v1.2 실측 8 키) 와 정확히 같을 때만 · g2 행은 도장 네 세대 값 = 레코드에서 유도한 '
                           '기대값 (G2RR-01)) · invalid = 세대 계약 위반 (H12 를 주 Hertz 자리에 · 모르는 값 · 부분 결손 · '
                           '수치 증서 결합 실패 (G2RR-02 — 다른 가지 · 역할 · 채널의 증서 · 기하 인자 · 발행값 ≠ 증서 재구성) — 그 행 '
                           'NOT_COMPUTED invalid_input · 인계표에는 실리지 않는다) · 빈칸 = 망 레코드 없음 · ⚠ 표기 계약 + 증서 결합 — 숫자만 바꿔 끼운 '
                           '레코드는 증서 재구성이 잡는다 · 증서 · 숫자 · 기하를 함께 일관되게 바꾼 전면 위조는 재계산 없이 못 잡는다 · 한 인계표 = 한 세대 '
                           '(행마다 계약 먼저 · 그다음 섞임)'),
}
#: ★ 10-16 L214R-02 (Codex LHS214 재검증 §3 · §6-4 · 7 · 10 · 수정 계획 Q2 · 1저자 10-16 비준 "권고대로") — FULL 모형 한계 **독립 표지** 두 칸
#:   (tau_flux.MODEL_LIMIT_FLAG_COL · tau_flux.full_model_limit_flag — 상태 게이트와 따로 레코드에서 바로).  τ 상태 칸은 앞 게이트 우선 (띠 L1 · L2 = BAND_FALLBACK ·
#:   사유 공란) 이라 FULL 모형 한계 사실이 상태에서 사라진다 — 이 칸이 띠 규칙과 무관하게 보존하고, 배포 build · check (lhs_release_build) 가 주 타깃 표지로 HOLD ·
#:   ML 사용자도 빈칸 이유를 본다.  H12 표지 칸은 없다 (1저자 Q2 = 두 칸).  ⚠ 뜻 · 한정어 글에 주 배포 표에 없는 인계표 열 이름을 표지 없이 쓰지 않는다
#:   (full_model_limit_hertz 는 v1.3 주 표에 실린다 — lhs_release_build 프로필 ml_v1 의 사전 참조 검사).
#:   판정 칸은 다른 τ 열과 같은 TAU_NET_VERDICT (τ 묶음 · selftest ㉙m2) — 진단 표지라는 뜻은 한정어 첫머리에 적는다.
CAVEAT_TAU_ML_FLAG = ('진단 표지 (10-16 L214R-02 · 1저자 비준 Q2) — 특징 · 타깃 아님 (상태 열과 같이 읽는다) · v1.3 배포 관문 (build · check 같은 함수) 이 읽는다 · '
                      '공용 판정 (tau_flux.full_model_limit_problem — 생산자 · 게시 · 정지 계약 · 다시 읽기 · 인계 출처 관문 P4 가 같은 함수) 을 통과한 레코드만 True · '
                      '거부된 q 와 수치 증서는 canonical 결과 (network_conductivity_dual.json) 의 증서에 별도 진단으로 · 값 = tau_flux 직렬화 (True · False) · '
                      '출처 관문 = 다른 τ 칸과 같다 (P0–P4 · 읽기 안정) · 분류 · 게시 계약의 표지이지 물리 타당성 검증이 아니다 · 무작위 결측 표지가 아니다 (q 가 높은 쪽)')
_TAU_ML_FLAG = {
    'full_model_limit_hertz': (
        'FULL 모형 한계 독립 표지 (hertz = 주 타깃 H0 · 10-16 L214R-02) — True = 그 모드 망 레코드의 FULL 해가 수치 풀이 인증을 통과했으나 사전 고정 출력 상한 '
        '(q > 1.5) 을 넘어 값을 내지 않은 레코드 (사유 full_over_conduction · 공용 판정 통과 — 사유만 위조 · 증서 결손 · 틀린 q 는 True 가 아니다) · '
        '**띠 규칙과 무관** (L0 · L1 · L2 — 상태 칸 ion_net_status_hertz 은 앞 게이트 우선이라 띠 L1 · L2 면 BAND_FALLBACK · 사유 공란으로 보이고 '
        'f · tau2 · tau 의 빈칸 뜻도 HOLD_BAND_FALLBACK 이지만 이 칸은 True 로 남는다 · L0 이면 상태도 NOT_COMPUTED full_over_conduction) · False = 그 밖 '
        '(값이 있는 FULL · 증명된 비관통 · 기술적 무효 레코드 포함) · 빈칸 = 그 모드 레코드 없음 · 케이스 폴더의 망 활성 세대 무효 (인계표 done · partial 행에는 '
        '생기지 않는다) · v1.3 주 타깃 배포 관문 (build · check 같은 함수) 이 True 행 · 칸 없음 · 모르는 값 · 상태와 모순인 행을 HOLD (행 삭제 · Physics · '
        'H12 · 0 · 1.5 대체 없음) ⇒ 실제 v1.3 배포 주 표에서는 전부 False'),
    'full_model_limit_physics': (
        'FULL 모형 한계 독립 표지 (physics · 10-16 L214R-02) — True = 그 모드 망 레코드의 FULL 해가 수치 풀이 인증을 통과했으나 사전 고정 출력 상한 (q > 1.5) 을 '
        '넘어 값을 내지 않은 레코드 (사유 full_over_conduction · 공용 판정 통과) · **띠 규칙과 무관** (상태 칸 ion_net_status_physics 은 띠 L1 · L2 면 '
        'BAND_FALLBACK · 사유 공란 · 빈칸 뜻 HOLD_BAND_FALLBACK 으로 보이지만 이 칸은 True 로 남는다 — Physics 모형 한계 집계에서 빠지지 않는다) · False = 그 밖 · '
        '빈칸 = 그 모드 레코드 없음 · 세대 무효 · Physics = opt-in 부록 정책 그대로 (모형 한계 = 부록 공란 · 배포 HOLD 아님)'),
}
_TAU_COL_RE = re.compile(r'(f_ion|tau2_ion|tau_ion|ion_net_status_reason|ion_net_status|ion_net_area_mode|ion_net_constriction|ion_net_psi|'
                         r'ion_net_area_rule|ion_net_electrode|ion_net_bulk|'
                         r'ion_net_band_rule|ion_net_band_frac|ion_net_basis_check)_(hertz_h12|hertz|physics)(_gap)?')


def tau_net_define(col):
    """망 τ 열 (tau_flux.column_names()) → (뜻, 한정어) · 아니면 None.  이름이 정확히 τ 규약 꼴일 때만 (옛 열을 잡지 않는다 — selftest ㉙f1)."""
    if col in _TAU_SHARED:
        return _TAU_SHARED[col], CAVEAT_TAU_NET
    if col in _TAU_ML_FLAG:                          # ★ 10-16 L214R-02 — 모형 한계 독립 표지 (두 이름 정확히 · τ 값 열 꼴 밖이라 따로)
        return _TAU_ML_FLAG[col], CAVEAT_TAU_ML_FLAG
    m_ = _TAU_COL_RE.fullmatch(col)
    if m_ is None or (m_.group(3) and m_.group(1) != 'f_ion'):
        return None
    base = 'f_ion_gap' if m_.group(3) else m_.group(1)
    mode = m_.group(2)
    text = _TAU_PER_MODE[base].format(m=mode, area=_TAU_AREA[mode])
    if mode in TAU_NET_HERTZ_AREA_MODES and base != 'ion_net_area_mode':   # ★ 10-06 — hertz 면적의 정체를 값 열마다 (면적 모드 열에는 이미 전문)
        text += ' · ' + TAU_HERTZ_AREA_NOTE
    if base == 'f_ion' and mode in TAU_F_TARGET_NOTE:                 # ★ v1.3 #2 — ML 타깃 안내 (주 = Hertz f · Physics = opt-in 부록)
        text += ' · ' + TAU_F_TARGET_NOTE[mode]
    if mode == TAU_NET_H12:                          # ★ 10-06 — 민감도 열은 뜻 앞에 표지 (기본 학습 열 아님)
        text = '[H12 민감도 · 부록 전용] ' + text
        if base in ('ion_net_status', 'ion_net_status_reason'):
            text += TAU_H12_GEN1_NOTE
    return text, (CAVEAT_TAU_NET_T2 if base == 'tau2_ion' else CAVEAT_TAU_NET)


#: ★ 10-06 (1저자 비준 "A·B 코드" · L1-04) — hertz 모드 (hertz · hertz_h12) 의 면적 = LIGGGHTS c_cpl[22] 기하 교차 원판 (탄성 Hertz 아님) — 값 열마다 적는다
#:   (옛 사전은 ion_net_area_mode_<모드> 한 열에만 적어 그 열이 없는 배포 표에서는 "Hertz 접촉망" 이 탄성 Hertz 면적으로 읽혔다).
TAU_NET_HERTZ_AREA_MODES = ('hertz', 'hertz_h12')
TAU_HERTZ_AREA_NOTE = ('hertz 면적 = LIGGGHTS c_cpl[22] 기하 교차 원판 π(rδ − δ²/4) — 탄성 Hertz πR*δ 의 ≈ 2 배 (같은 반지름 2 − δ/2r) · '
                       '"Hertz" 는 이름만 (L1-04 · A_dem_geometric)')


#: ★ v1.3 #2 (1저자 10-06 밤 "f 타깃 안내") — f 열의 ML 쓰임 (주 = Hertz · Physics = opt-in 부록 · H12 = 민감도 부록 — 뜻 앞 표지가 이미 있다).
#:   T (tau2) · √T 는 비관통에서 ∞ (빈칸) 라 회귀 타깃으로 바로 쓰면 비관통 행을 버리거나 임의 값으로 채우게 된다 — f 는 유한 (비관통 = 0.0).
TAU_F_TARGET_NOTE = {
    'hertz': ('★ ML 1차 타깃 (v1.3 #2) — 유한 · 비관통 행 = 0.0 (물리적 0 · 결측 아님) · 먼저 관통 분류 (ion_net_status_hertz = NOT_PERCOLATING ↔ 관통) · '
              'tau2 · tau 는 비관통에서 ∞ (빈칸) 라 타깃으로 쓰지 않는다 · T = φ_SE,mc/f 항등식이라 f 를 예측하면서 tau2 · tau 를 특징으로 넣지 않는다'),
    'physics': 'opt-in 부록 (기본 학습 열 아님 · Codex QV3 — 면적과 협착식이 함께 다른 규약의 결합 민감도)',
}


#: H12 상태 · 사유 칸의 세대 1 예외 — 표기 없는 옛 폴더 (2026-10-06 저녁 전 생산자) 에는 H12 레코드가 없다 (망 정지 계약 ⑨ 는 세대 2 Hertz 레코드에만
#:   H12 를 요구한다 — `pipeline_service.network_generation2_problems`).
TAU_H12_GEN1_NOTE = (' · ⚠ 세대 1 배치 (표기 없는 옛 폴더 · ion_net_generation = inferred_legacy · ion_net_electrode = virtual_source_legacy — '
                     '2026-10-06 저녁 전 생산자) 에는 H12 레코드가 '
                     '없다 → 이 모드만 NOT_COMPUTED (missing_input) · 값 빈칸 = 그 세대에 없는 열 (기술적 결손 아님) — "인계표에는 NOT_COMPUTED 가 '
                     '실리지 않는다" 의 유일한 예외 · 세대 2 배치는 망 정지 계약 ⑨ 가 H12 를 요구한다 (없으면 배치 · 인계 거부)')


def tau_net_verdict(col):
    """망 τ 열의 판정 — H12 민감도 열 (`*_hertz_h12`) = 부록 전용 · 그 밖 = TAU_NET_VERDICT."""
    m_ = _TAU_COL_RE.fullmatch(col)
    return TAU_NET_VERDICT_H12 if (m_ is not None and m_.group(2) == TAU_NET_H12) else TAU_NET_VERDICT


#: 출처 관문 (fail-closed) — 배치 기록 ↔ 케이스 폴더.  P0 기록 · P1 run id · P2 입력 digest · P3 같은 세대 (metrics_flat · dual 투영).
#:   P3 이 대조하는 full_metrics 키 = 망 정지 계약의 τ 장부 (`pipeline_service.NETWORK_STOP_LEDGER_KEYS`) + 도장 + 망 σ 투영 (상태 포함).
TAU_TIE_EXTRA = ('network_run_id', 'active_network_run_id', 'network_solver_status',
                 'sigma_full', 'sigma_full_status', 'sigma_full_physics', 'sigma_full_status_physics')
#: dual ↔ full_metrics 투영 (생산자 `_merge_dual_into_metrics` — hertz = legacy (= dual hertzian · 망 정지 계약 ⑥) · physics = `<키>_physics` 미러)
TAU_DUAL_PROJ = (('hertzian', 'sigma_full', 'sigma_full'), ('hertzian', 'sigma_full_status', 'sigma_full_status'),
                 ('physics', 'sigma_full', 'sigma_full_physics'), ('physics', 'sigma_full_status', 'sigma_full_status_physics'))
#: 망 도장의 입력 digest 대상 (`app._network_and_stage_e` — `_ps.file_digest(atoms_csv · contacts_csv)`)
TAU_INPUT_FILES = ('atoms.csv', 'contacts.csv')


def _tau_import():
    """tau_flux (scripts/) · pipeline_service (webapp/) 지연 임포트 — 망 τ 묶음을 부를 때만 (옛 경로의 의존은 늘지 않는다).
    pipeline_service 는 표준 라이브러리만 임포트한다 (`network_projection_preflight` 와 같은 방식 — 정의를 공유한다 · 사본 금지)."""
    here = pathlib.Path(__file__).resolve().parent
    for p in (here, here.parent / 'webapp'):
        if str(p) not in sys.path:
            sys.path.append(str(p))
    import tau_flux as tf                    # noqa: E402
    import pipeline_service as ps            # noqa: E402
    return tf, ps


def _tau_canon(v):
    """대조용 정규 JSON (키 순서 무관 · NaN 도 같은 토큰) — pipeline_service._canon 과 같은 뜻."""
    return json.dumps(v, sort_keys=True, default=str)


def _tau_read_names(ps):
    """P4 읽기 안정이 검사 앞뒤로 해시하는 파일 (`pipeline_service.file_digest` — 없음 · 못 읽음 = '') — 정지 계약 · 세대 검사 · tau_flux.case_row ·
    P2 가 읽는 것 전부.  이름은 웹앱 정의 그대로 (`NETWORK_ARTIFACT_GLOBS` 의 고정 이름 = 네 망 JSON + 도장 · `ATTEMPT_FILE`) + full_metrics + 입력 둘
    (사본 금지 — 규율 ①)."""
    names = [g for g in ps.NETWORK_ARTIFACT_GLOBS if '*' not in g] + ['full_metrics.json', ps.ATTEMPT_FILE, *TAU_INPUT_FILES]
    return tuple(dict.fromkeys(names))



def load_tau_results(results_dir, webapp, expected_generation=None):
    """망 τ 원천 (v1.2) — network 정지 배치 (`lhs_webapp_batch --stop-after network`) 의 케이스 폴더 묶음 (`<--work>/results`) → `build_handover(tau=…)`.

    ★ 왜 케이스 폴더에서 tau_flux 를 직접 부르나 (검증 가능한 쪽):  τ 를 낼 입력 (dual 레코드 두 모드) 은 metrics_flat 에 없고, tau_flux CLI 의
      TSV/JSON 에는 **출처가 없다** (케이스 이름뿐 — 어느 망 세대인지 대조할 수 없다).  폴더에는 도장 (full_metrics · network_provenance.json 의
      network_run_id · 입력 digest) 이 있어 **배치 기록과 맞댈 수 있다**.  그래서 관문을 본 바로 그 바이트로 tau_flux 를 부른다 (`case_row` = 웹앱
      `_ion_handover` 와 같은 입력) — 계산은 한 곳 (tau_flux) · 출처는 배치 status.json 과 대조.

    배치가 done · partial 로 적은 케이스마다 (나머지는 읽지 않는다 — 표에서 τ 칸이 빈칸):
      P0 기록 — 폴더 · dual · full_metrics · 도장 파일이 있고 읽힌다 (없으면 거부 — 조용히 빈칸으로 두지 않는다)
      P1 run id — 배치 기록 network_run_id (비지 않은 문자열) = full_metrics network_run_id = active_network_run_id = 도장 network_run_id ·
         도장 solver_status success · full_metrics network_solver_status success  (다르면 낡은 세대 — 배치 뒤 다시 돌린 폴더 · 다른 배치의 폴더)
      P2 입력 digest — 도장 input_digests (atoms.csv · contacts.csv) = 지금 폴더 파일의 `pipeline_service.file_digest`
      P3 같은 세대 (배치 기록) — full_metrics 의 τ 장부 (NETWORK_STOP_LEDGER_KEYS) · 도장 · 망 σ 투영 (TAU_TIE_EXTRA) = 배치 metrics_flat 칸
         (row_for 직렬화) · dual σ_ratio · 상태 = full_metrics 투영 (TAU_DUAL_PROJ)
      P4 같은 세대 (인계 때 재검사 · 10-05 RGLR3-02 — Codex 4차 재검증 §3 · §8-2 최소 해제 "기존 정지 계약의 전 사본 · 투영 · σ₀ 대조를 인계 때 다시 호출"):
         P4_model_generation — ★ 10-06 밤 (G2R-01 · 02 · 1저자 비준) 공용 세대 계약 `tau_flux.network_generation_contract` (망 정지 계약 ⑨ · τ 인계 소비자 ·
            배포 빌더와 같은 함수): 모드마다 허용 모델 조합 (주 Hertz = H0 · H12 · physics) · 닫힌 열거 · 세대 2 표기 전부 필수 · 옛 세대 추론은 표지가 하나도
            없는 레코드만.  옛 판은 H12 를 주 Hertz 자리에 둔 폴더 · ψ 오타 · 부분 결손을 받았다.
            ★ 10-06 밤 (G2RR-01 · Codex 세대 2 재검증 §2) 도장 ↔ 레코드 세대 대조 (`pipeline_service.provenance_generation_problem` — 웹앱 망 세대 행과 같은
            함수): g2 = 도장의 네 세대 값 (psi_placement_physics · electrode_model · area_rule_physics · hertz_h12) 이 전부 있고 = 레코드에서 유도한 기대값
            (`generation_stamp_values` — 게시자와 같은 함수 · 타입까지) = 세대 2 값 (null · unknown · 명시 legacy · 부분 결손 · 모순 = 거부) · inferred_legacy =
            도장이 확인된 역사 도장 스키마 (194 v1.2 실측 8 키 · 세대 키 없음) 일 때만 — 그때만 정지 계약을 legacy_ok 로 다시 부른다 (194 v1.2 같은 역사 배치) ·
            expected_generation (배치 manifest 의 기대 세대 — `tau_manifest_expected_generation`) 을 주면 케이스마다 레코드 세대 = 그 값 (다르면 거부).
            옛 판은 도장의 키 존재 · g2 값 하나만 보아 unknown · null · legacy 도장을 g2 로 · null 한 키 남긴 역사 모양 도장을 inferred_legacy 로 받았다.
         P4_stop_contract — 배치가 done 을 준 **바로 그 함수** `pipeline_service.network_stop_verdict` (①–⑨ — 전 사본 (dual · 모드 파일 둘 · legacy) ·
            full_metrics 망 투영 (NET_MERGE_KEYS) · σ₀ · 온도 짝 (두 모드 · legacy · full_metrics · 등급 짝 σ₀) · 띠 규칙 필드 · 공용 기술 검사 · τ 소비자 상태
            = OK · 등록된 과학적 HOLD 만) 를 지금 폴더에 다시 부른다 (fm = 관문이 본 바이트 · 사본 아님 — 규율 ①).  ⚠ P3 은 dual 의 두 키만 보아 dual 만
            바꾼 띠 규칙 L0 → L1 (BAND_FALLBACK 로) · σ₀ ×2 (σ₀ 6.0 mS/cm 로) 를 받았다 (Codex 실 CLI 생산본 반례).  기술적 결손 폴더 (tau_flux 라면
            NOT_COMPUTED) 도 여기서 거부된다 — 그 배치의 계약이 done 을 줄 수 없는 상태이므로 "같은 세대 검증 통과" 행으로 싣지 않는다.
         P4_generation — `tau_flux.network_generation_problem` (case_row 가 쓰는 같은 함수 — 도장 손상 · 중단된 게시 흔적 · 되돌림 실패 기록)
         P4_read_stable — 검사 앞뒤로 같은 바이트 (`_tau_read_names` 해시) · `tau_flux.case_row` 가 읽은 값 = 관문을 본 바이트로 낸 `ion_columns`.
            ⚠ 이것은 **같은 실행 안의 읽기 일관성**이다 (같은 파일을 두 번 읽어 비교) — 배치 때 바이트와의 대조가 아니다 (Codex RGLR3-02).
    ⚠ 한계 (`TAU_SAME_GEN_BASIS`): 모든 대조는 배치 기록과 **지금 파일끼리**다 — 게시 시점 해시가 없어 모든 사본 (dual · 모드 파일 · legacy · full_metrics ·
      도장) 을 함께 일관되게 바꾼 편집은 못 잡는다.  출처 부록의 dual · full_metrics sha256 은 **인계 때 읽은** 바이트다 (배치 때 바이트가 같았다는 증명 아님).
    반환 {'schema', 'source', 'batch_source', 'columns', 'tau_flux_sha256', 'same_generation_checks', 'same_generation_basis',
         'expected_generation' (배치 manifest 기대 세대 — 대조했으면 그 값 · 안 했으면 None),
         'cases': {case: {'network_run_id', 'input_digests', 'dual_sha256', 'full_metrics_sha256', 'same_generation_checks' (다 통과한 검사 —
         TAU_SAME_GEN_CHECKS), 'same_generation_basis', 'cells' (tau_flux 직렬화 `_cell`)}}}.
    어긋나면 FillRefusal ('τ 정지점' · 'τ 기대 세대' · 'τ P0'–'τ P4') — 한 케이스라도 실패하면 거부 (그 케이스 τ 를 빈칸 + 사유로 싣지 않는다 · P0–P3 과
    같은 규칙)."""
    if expected_generation is not None and expected_generation not in TAU_EXPECTED_GENERATIONS:
        raise FillRefusal(f'τ 기대 세대 — expected_generation={expected_generation!r} ∉ {list(TAU_EXPECTED_GENERATIONS)} (배치 manifest 선언 · 닫힌 열거 · '
                          '대조를 약속했는데 못 하면 통과로 치지 않는다)')
    wv = webapp if isinstance(webapp, dict) else {}
    if wv.get('stop_after') != 'network':
        raise FillRefusal(f'τ 정지점 — 웹앱 배치 stop_after={wv.get("stop_after")!r} ≠ network — 망 τ 는 `lhs_webapp_batch --stop-after network` 배치의 '
                          '케이스 폴더에서만 싣는다 (그 배치만 케이스 기록에 network_run_id 를 남기고 망 정지 계약을 통과한다 · --webapp 필요)')
    tf, ps = _tau_import()
    root = pathlib.Path(results_dir)
    if not root.is_dir():
        raise FillRefusal(f'τ P0 — 케이스 폴더 묶음 {root} 이 없다 (배치의 --work 아래 results/)')
    cols = list(tf.column_names())
    flat = wv.get('rows') or {}
    tie = tuple(ps.NETWORK_STOP_LEDGER_KEYS) + TAU_TIE_EXTRA
    read_names = _tau_read_names(ps)
    out = {}
    for case, rec in sorted((wv.get('status') or {}).items()):
        rec = rec or {}
        if rec.get('status') not in WA_OK_STATUS:
            continue
        rid = rec.get('network_run_id')
        if not isinstance(rid, str) or not rid:
            raise FillRefusal(f'{case}: τ P1 — 배치 기록 (status.json) 에 network_run_id 가 없다 ({rid!r}) — 폴더의 망 세대를 대조할 수 없다')
        cd = root / case
        snap0 = {n: ps.file_digest(str(cd / n)) for n in read_names}  # P4 읽기 안정 — 검사 **전** 지문 (아래 모든 읽기 · 검사가 이 바이트를 본다)
        raw = {}
        for n in ('network_conductivity_dual.json', 'full_metrics.json'):
            try:
                b_ = (cd / n).read_bytes()
                raw[n] = (b_, json.loads(b_.decode('utf-8')))
            except (OSError, ValueError, UnicodeDecodeError) as e:
                raise FillRefusal(f'{case}: τ P0 — τ 기록 없음 · 못 읽음 {cd / n} ({type(e).__name__}) — 배치 done 케이스의 망 결과가 폴더에 없다')
        dual, fm = raw['network_conductivity_dual.json'][1], raw['full_metrics.json'][1]
        if not isinstance(dual, dict) or not isinstance(fm, dict):
            raise FillRefusal(f'{case}: τ P0 — dual · full_metrics 가 객체가 아니다')
        dual_sha, fm_sha = (hashlib.sha256(raw[n][0]).hexdigest() for n in ('network_conductivity_dual.json', 'full_metrics.json'))
        prov = ps.read_network_provenance(str(cd))
        if prov.get('provenance_state') == 'missing':
            raise FillRefusal(f'{case}: τ P0 — 망 도장 ({ps.PROVENANCE_FILE}) 이 없다 — 어느 세대인지 대조할 수 없다')
        bad = []
        if prov.get('provenance_state') != 'valid' or prov.get('solver_status') != 'success':
            bad.append(f'도장 상태 {prov.get("provenance_state")!r} · solver_status {prov.get("solver_status")!r} (valid · success 여야)')
        for lab, v_ in (('도장 network_run_id', prov.get('network_run_id')), ('full_metrics network_run_id', fm.get('network_run_id')),
                        ('full_metrics active_network_run_id', fm.get('active_network_run_id'))):
            if v_ != rid:
                bad.append(f'{lab} {v_!r} ≠ 배치 기록 {rid!r}')
        if fm.get('network_solver_status') != 'success':
            bad.append(f'full_metrics network_solver_status {fm.get("network_solver_status")!r}')
        if bad:
            raise FillRefusal(f'{case}: τ P1 — 낡은 · 다른 망 세대: ' + ' · '.join(bad) + ' — 배치 뒤 다시 돌린 폴더이거나 다른 배치의 폴더다')
        dig = prov.get('input_digests') if isinstance(prov.get('input_digests'), dict) else {}
        for n in TAU_INPUT_FILES:
            want, got = dig.get(n), ps.file_digest(str(cd / n))
            if not want or not got or want != got:
                raise FillRefusal(f'{case}: τ P2 — 입력 digest {n}: 도장 {want!r} ≠ 지금 파일 {got!r} — 망이 지금 폴더의 입력에서 나오지 않았다')
        wr = flat.get(case)
        if wr is None:
            raise FillRefusal(f'{case}: τ P3 — 배치 metrics_flat 에 행이 없다 — 표의 다른 열과 같은 세대인지 대조할 수 없다')
        for k in tie:
            #  row_for 는 full_metrics 에 **있는** 키만 펴고 metrics_flat 머리는 행 키의 합집합이다 — 생산자 머지는 None σ 를 키째 안 쓴다 (비관통).
            #   ⇒ 열 없음 = 빈칸 (None) 으로 읽는다: 폴더에도 값이 없을 때만 맞고, 폴더에 값이 있으면 그대로 어긋남 (fail-closed 유지 · ㉙k).
            want = '' if fm.get(k) is None else str(fm.get(k))
            got = wr.get(k)
            if (got or '') != want:
                raise FillRefusal(f'{case}: τ P3 — 폴더 full_metrics {k}={want!r} ≠ 배치 metrics_flat {got!r} — τ 와 표의 다른 열이 다른 세대다')
        for dk, rk, fk in TAU_DUAL_PROJ:
            dv = dual.get(dk).get(rk) if isinstance(dual.get(dk), dict) else None
            if _tau_canon(dv) != _tau_canon(fm.get(fk)):
                raise FillRefusal(f'{case}: τ P3 — dual[{dk}].{rk}={dv!r} ≠ full_metrics {fk}={fm.get(fk)!r} — dual 이 도장 세대의 망 결과가 아니다')
        #  P4_model_generation — ★ 10-06 밤 (G2R-01 · 02) 공용 세대 계약 (tau_flux 의 같은 함수 · 사본 없음) + ★ (G2RR-01) 배치 manifest 기대 세대 +
        #   도장 ↔ 레코드 세대 대조 (pipeline_service 의 같은 함수 — 웹앱 망 세대 행도 이것을 부른다)
        con = tf.network_generation_contract(dual)
        if con.get('problems'):
            raise FillRefusal(f'{case}: τ P4 — 세대 계약 위반 (G2R-01 · 02 · tau_flux.network_generation_contract): '
                              f'{tf.generation_contract_text(con)[:600]} — 역할 · 표기가 확정되지 않은 망의 τ 를 싣지 않는다 (주 Hertz = H0 · H12 · physics 표)')
        gen = con.get('generation')
        if expected_generation is not None and gen != expected_generation:
            raise FillRefusal(f'{case}: τ P4 — 배치 기대 세대 (manifest {TAU_MANIFEST_GENERATION_KEY}) {expected_generation!r} ≠ 레코드 세대 {gen!r} '
                              '(G2RR-01 · 배치 manifest 교차 대조) — 이 배치가 선언한 세대의 폴더가 아니다')
        sp = ps.provenance_generation_problem(prov, dual, gen)
        if sp:
            raise FillRefusal(f'{case}: τ P4 — 세대 도장 대조 (G2RR-01 · pipeline_service.provenance_generation_problem): 레코드 세대 {gen!r} · '
                              f'{" · ".join(sp)[:600]} — 도장 ({ps.PROVENANCE_FILE}) ↔ 레코드가 한 세대를 가리키지 않는다 · '
                              + ('세대 2 로 싣지 않는다 (g2 = 도장 네 세대 값 = 레코드에서 유도한 기대값)' if gen == tf.NET_GEN_G2 else
                                 '옛 세대로 추론하지 않는다 (inferred_legacy = 확인된 역사 도장 스키마 · 194 v1.2 만)' if gen == tf.NET_GEN_LEGACY else
                                 '세대를 대조할 수 없다'))
        legacy_ok = gen == tf.NET_GEN_LEGACY
        #  P4_stop_contract — 배치가 done 을 준 같은 계약을 지금 폴더에 다시 (전 사본 · 투영 · σ₀ 짝 · 띠 규칙 필드 · τ 소비자 상태 · 세대 계약 ⑨ — 사본 아님 ·
        #   규율 ①).  옛 세대 추론은 위 자격을 통과한 역사 폴더에만 (legacy_ok — 게시 때는 늘 False)
        try:
            ok4, why4 = ps.network_stop_verdict(str(cd), rid, fm=fm, legacy_ok=legacy_ok)
        except Exception as e:                                       # noqa: BLE001 — 판정을 못 내면 통과로 치지 않는다 (fail-closed)
            ok4, why4 = False, f'정지 계약 판정 중 예외 ({type(e).__name__}: {e})'
        if not ok4:
            raise FillRefusal(f'{case}: τ P4 — 망 정지 계약 재검사 실패 (인계 때 · 배치가 done 을 준 같은 계약 pipeline_service.network_stop_verdict ①–⑨): '
                              f'{str(why4)[:700]} — 그 계약을 통과한 세대의 폴더가 아니다 (배치 뒤 사본 · 투영 · σ₀ · 띠 규칙이 바뀌었거나 기술적 결손) · '
                              '이 케이스 τ 를 싣지 않는다 (NOT_COMPUTED 로도 싣지 않는다 — "같은 세대 검증 통과" 로 보이지 않게)')
        #  P4_generation — case_row 가 쓰는 같은 세대 검사 (옛 판은 이 경우를 아래 읽기 대조의 "읽는 사이 바뀌었다" 로 잘못 불렀다)
        gp = tf.network_generation_problem(str(cd), fm=fm)
        if gp:
            raise FillRefusal(f'{case}: τ P4 — 활성 세대 무효 (tau_flux.network_generation_problem): {gp[:500]} — 값 인용 금지 · 재계산 필요')
        #  P4_read_stable — 같은 실행 안의 읽기 일관성 (같은 파일을 다시 읽어 맞댄다 · 배치 때 바이트와의 대조가 아니다 — 그 한계는 TAU_SAME_GEN_BASIS)
        row = tf.case_row(str(cd))                                   # tau_flux 자신 (웹앱 `_ion_handover` 와 같은 입력)
        chk_ = tf.ion_columns(dual, fm, fm.get('percolation_pct'))
        moved = sorted(n for n in read_names if ps.file_digest(str(cd / n)) != snap0[n])     # 검사 **뒤** 지문 — 앞과 같아야
        if moved or row.get('case') != case or _tau_canon({c: row.get(c) for c in cols}) != _tau_canon({c: chk_.get(c) for c in cols}):
            raise FillRefusal(f'{case}: τ P4 — 읽기 안정 실패: 검사 앞뒤로 바뀐 파일 {moved} · tau_flux.case_row 가 읽은 값 ≠ 관문을 본 바이트로 낸 값 '
                              '(읽는 사이 폴더가 바뀌었다)')
        out[case] = {'network_run_id': rid, 'input_digests': {n: dig.get(n) for n in TAU_INPUT_FILES},
                     'dual_sha256': dual_sha, 'full_metrics_sha256': fm_sha,
                     'same_generation_checks': list(TAU_SAME_GEN_CHECKS), 'same_generation_basis': TAU_SAME_GEN_BASIS,
                     'cells': {c: tf._cell(row.get(c)) for c in cols}}      # tau_flux 자신의 직렬화 (TSV 와 같은 칸)
    #  ★ 10-06 저녁 세대 2 — 케이스끼리 망 세대 (ψ 배치 · physics 면적 규칙 · 전극) 가 섞이면 거부 (tau_flux 의 같은 판정 함수 — 사본 없음)
    #    ★ 10-06 밤 (G2R-02) — 그 함수가 행마다 세대 계약을 먼저 본다 (같은 결함만 모인 코호트도 거부 · 축에 모드별 협착 · bulk · 세대 칸)
    _mix = tf.generation_mixing_problem([dict(r_['cells'], case=c_) for c_, r_ in sorted(out.items())])
    if _mix:
        raise FillRefusal(f'τ 세대 — {_mix} — 한 배치의 폴더들이 같은 망 세대가 아니다 (같은 세대로 다시 계산할 것)')
    return {'schema': TAU_NET_SCHEMA, 'source': str(root), 'batch_source': wv.get('source'), 'columns': cols,
            'tau_flux_sha256': hashlib.sha256(pathlib.Path(tf.__file__).read_bytes()).hexdigest(),
            'same_generation_checks': list(TAU_SAME_GEN_CHECKS), 'same_generation_basis': TAU_SAME_GEN_BASIS,
            'expected_generation': expected_generation, 'cases': out}


#: 출처 부록 열 — ★ 10-05 RGLR3-02: same_generation_checks = 이 케이스에서 **돌았고 통과한** 같은 세대 검사 (TAU_SAME_GEN_CHECKS · ';' 로 잇기 —
#:   하나라도 실패하면 생성기가 거부해 행이 없다) · same_generation_basis = 대조 기준 (current_files_no_publish_hash — 배치 기록과 지금 파일끼리 · 게시 시점
#:   해시 없음 ⇒ 모든 사본을 함께 일관되게 바꾼 편집은 못 잡는다).  dual · full_metrics sha256 = **인계 때 읽은** 바이트 (P4 읽기 안정으로 검사가 본 바이트와
#:   같다 · 배치 때 바이트가 같았다는 증명은 아니다).  옛 열 순서 · 값은 그대로 (끝에 두 열).
TAU_PROVENANCE_COLS = ('case', 'network_run_id', 'atoms_csv_digest', 'contacts_csv_digest', 'dual_sha256', 'full_metrics_sha256',
                       'tau_flux_py_sha256', 'results_dir', 'same_generation_checks', 'same_generation_basis')


def _tau_src_label(path):
    """출처 부록에 적을 폴더 이름 — 리포 안이면 상대 경로 · 홈 아래면 '~/…' (리포에 사용자 홈 경로를 새기지 않는다)."""
    p = pathlib.Path(path).resolve()
    root = pathlib.Path(__file__).resolve().parent.parent
    try:
        return str(p.relative_to(root))
    except ValueError:
        pass
    try:
        return str(pathlib.Path('~') / p.relative_to(pathlib.Path.home().resolve()))
    except (ValueError, RuntimeError):
        return str(p)


def write_tau_provenance(path, tau):
    """망 τ 출처 부록 TSV — 인계표 CLI 가 `<인계표>_tau_provenance.tsv` 로 쓴다 (τ 칸이 어느 망 세대 · 어느 파일에서 왔는가 · 어느 검사를 통과했나).
    ★ 10-05 RGLR3-02 — 같은 세대 검사 (P0–P4) 를 다 통과한 기록만 적는다: 표지가 모자란 기록 (옛 v1 원천 · 손으로 만든 dict) 이 하나라도 있으면 거부한다
    (출처 부록의 행 = "검증 통과" 로 읽힌다 — 검사가 안 돈 케이스를 그렇게 적지 않는다)."""
    src = _tau_src_label(tau['source'])
    bad = sorted(c for c, r in (tau.get('cases') or {}).items() if list((r or {}).get('same_generation_checks') or []) != list(TAU_SAME_GEN_CHECKS))
    if bad:
        raise FillRefusal(f'τ P4 — 같은 세대 검사 (P0–P4) 를 다 통과한 기록이 아니다 {bad[:5]} — 출처 부록에 "검증됨" 으로 적지 않는다 '
                          '(load_tau_results v2 로 다시 읽을 것)')
    with pathlib.Path(path).open('w', encoding='utf-8', newline='') as fh:
        w = csv.writer(fh, delimiter='\t', lineterminator='\n')
        w.writerow(TAU_PROVENANCE_COLS)
        for case, r in sorted(tau['cases'].items()):
            w.writerow([case, r['network_run_id'], r['input_digests'].get('atoms.csv') or '', r['input_digests'].get('contacts.csv') or '',
                        r['dual_sha256'], r['full_metrics_sha256'], tau['tau_flux_sha256'], src,
                        ';'.join(r['same_generation_checks']), r.get('same_generation_basis') or TAU_SAME_GEN_BASIS])


#  ═══ 완료 압력 (DESC-06 잔여 · 1저자 비준 10-06 "A·B 코드") ═══════════════════════════════════════════════════════════════════════════════
#  원천 = `scripts/lhs_pressure_record.py` (LIGGGHTS 로그의 압밀 루프 판정 줄 — 마지막 줄 current ≥ target 일 때만 루프가 빠져나온다).  생성기는 기록을
#  **관문**으로 읽는다: 설계 케이스마다 기록 · 스키마 · 상태 OK · reached True · 목표 = 설계 상수 PRESSURE_MPA · 마지막 판정 줄 ≥ 목표 · 덱 sha = 수확 raw.deck ·
#  로그 sha — 하나라도 어긋나면 그 인계표를 만들지 않는다.  ⚠ 마지막 프레임 응력은 증거가 아니다 (판 고정 뒤 이완 — 목표보다 낮은 것이 정상).
PRESS_SCHEMA = 'lhs_pressure_record/v1'
PRESS_TOL_MPA = 1e-6
HANDOVER_PRESS = (
    ('press_target_mpa', 'target_mpa',
     '압밀 목표압 (MPa) = 덱 target_press × 1000 (press_units) — 생성기 관문: 설계 상수 pressure_MPa (300) 와 같아야 (DESC-06)'),
    ('press_last_loop_mpa', 'last_press_mpa',
     '압밀 루프의 마지막 판정 줄 (LIGGGHTS 로그 "Current Pressure: … (Target: …)") 의 판 압력 (MPa) — 덱의 루프는 이 값 ≥ 목표일 때만 빠져나온다 · '
     '⚠ 최종 프레임의 응력이 아니다 (목표에 닿으면 판을 고정하고 이완 — 마지막 프레임 응력은 목표보다 낮은 것이 정상) · 생성기 관문 ≥ 목표 (DESC-06)'),
    ('press_reached', 'reached', 'True = 압밀 루프가 목표에 닿아 빠져나왔다 (생성기는 True 만 싣는다 — 아니면 인계표를 만들지 않는다 · DESC-06)'),
    ('press_log_sha256', 'log_sha256', '판정 줄을 읽은 LIGGGHTS 로그의 sha256 (출처 추적 · scripts/lhs_pressure_record.py)'),
)


def load_pressure_record(path):
    """압력 기록 TSV (`scripts/lhs_pressure_record.py` 산출) → dict(case → 행).  스키마 · 같은 case 두 행이면 거부 (DESC-06)."""
    p = pathlib.Path(path)
    if not p.is_file():
        raise FillRefusal(f'압력 기록 {p} 이 없다 (DESC-06)')
    out = {}
    with p.open(encoding='utf-8', newline='') as fh:
        for r in csv.DictReader(fh, delimiter='\t'):
            c = r.get('case')
            if not c:
                raise FillRefusal(f'압력 기록 {p.name}: case 가 빈 행이 있다 (DESC-06)')
            if c in out:
                raise FillRefusal(f'압력 기록 {p.name}: 같은 case 가 둘 이상 — {c} (DESC-06)')
            if r.get('schema') != PRESS_SCHEMA:
                raise FillRefusal(f'압력 기록 {p.name}: {c} 의 schema {r.get("schema")!r} ≠ {PRESS_SCHEMA} (DESC-06)')
            out[c] = r
    if not out:
        raise FillRefusal(f'압력 기록 {p} 에 행이 없다 (DESC-06)')
    return out


def _press_problem(case, rec, h):
    """한 침대의 압력 기록 ↔ 수확 → '' (통과) 또는 사유."""
    if not isinstance(rec, dict):
        return '압력 기록에 이 케이스가 없다'
    if rec.get('status') != 'OK':
        return f'상태 {rec.get("status")!r} ({rec.get("why")}) — 목표압 도달이 기록되지 않았다'
    if rec.get('reached') != 'True':
        return f'상태 OK 인데 reached {rec.get("reached")!r} — 기록이 모순이다'
    try:
        tgt, last = float(rec.get('target_mpa')), float(rec.get('last_press_mpa'))
    except (TypeError, ValueError):
        return f'목표 {rec.get("target_mpa")!r} · 마지막 판정 줄 {rec.get("last_press_mpa")!r} 가 숫자가 아니다'
    if not (math.isfinite(tgt) and math.isfinite(last)):
        return f'목표 {tgt!r} · 마지막 {last!r} 가 유한하지 않다'
    if abs(tgt - PRESSURE_MPA) > PRESS_TOL_MPA:
        return f'목표 {tgt!r} MPa ≠ 설계 상수 {PRESSURE_MPA} MPa — 다른 덱 · 다른 코호트의 기록'
    if last < tgt - PRESS_TOL_MPA:
        return f'마지막 판정 줄 {last!r} MPa < 목표 {tgt!r} MPa 인데 reached True — 기록이 모순이다'
    want = ((h.get('raw') or {}).get('deck') or {}).get('sha256')
    if not want or rec.get('deck_sha256') != want:
        return f'덱 sha {str(rec.get("deck_sha256"))[:12]}… ≠ 수확 raw.deck {str(want)[:12]}… — 이 수확의 덱이 아니다'
    if not re.fullmatch(r'[0-9a-f]{64}', str(rec.get('log_sha256') or '')):
        return f'로그 sha256 {rec.get("log_sha256")!r} 가 없다 — 출처를 댈 수 없다'
    return ''


def _frac_caveat(col):
    c = col.lower()
    if not any(k in c for k in ('frac_', 'fracture_index', 'fragmentation', 'pulverization', 'microcrack', 'multicrack', 'intact')):
        return ''
    return CAVEAT_FRAC_FORCE if 'force' in c else CAVEAT_FRAC_DELTA


#: ★ LREL-06 (Codex 배포 v1.1 최종 리뷰 10-01 §3 · 1저자 비준 10-06) — 설계 열의 정의 (분모 · 단위 · 추정 ↔ 측정).  옛 사전은 설계 열 전부에 한 줄
#:   ("LHS 설계 열 (… build() 가 만든 설계인자 · 추정치)") 만 적어 am_pct 의 질량 % 분모 · ps_frac 의 AM 안 몫 · 확장 설계의 원천을 못 읽었고, 확장 (64) 사전도
#:   130 설계 파일을 가리켰다.  정의 원천 = `build()` (130) · `scripts/lhsx_design_adapter.py` (64 — 같은 이름으로 접는다) — README v1.1 개정판 §2 · §4 와 같은 말.
DESIGN_DEFINE = {
    'case_id': '설계 ID (키 · 한 행 = 침대 하나) — 특징으로 쓰지 않는다',
    'block': '설계 블록 — bimodal (AM_P + AM_S) · mono_AM_P · mono_AM_S (AM 한 상 · 없는 상의 지름 칸은 빈칸 · 상별 측정 칸의 mono 규약 = J20-k (B))',
    'd_am_p_um': '대립 AM (AM_P) 지름 (µm · 설계 입력 — 덱은 반지름 r_AM_P_um = d/2) · 그 상이 없는 mono 행은 빈칸',
    'd_am_s_um': '소립 AM (AM_S) 지름 (µm · 설계 입력) · 그 상이 없는 mono 행은 빈칸',
    'd_se_um': 'SE 지름 (µm · 설계 입력 · 단분산)',
    'ps_frac': ('**AM 중 AM_P 질량 몫** (0–1) = w_AM_P / (w_AM_P + w_AM_S) — AM_P · AM_S 밀도가 같아 AM 안 부피 몫과 같다 · **개수 몫 아님** · '
                'mono_AM_P = 1 · mono_AM_S = 0'),
    'ps_label': 'P:S 표기 (ps_frac 의 10 분율 정수 눈금) — ps_frac 의 재표현 (독립 정보 아님)',
    'am_pct': ('**고체 중 AM 질량 %** = 100 · (w_AM_P + w_AM_S) / (w_AM_P + w_AM_S + w_SE) — SE 질량 % = 100 − am_pct · **부피 % 아님** '
               '(부피 몫 = phi_se_mass_conserving · phi_am_mass_conserving · se_of_solid_vol)'),
    'rve_um': '측면 상자 한 변 (µm · x = y · x·y 주기 경계) — 코호트 상수 50',
    'loading_mAh_cm2': ('면용량 (mAh/cm²) — 2 mAh 규칙 행의 **설계 입력 2.0** (130 전부 · 두께 추정의 입력 · 보충 lhss 의 2mAh_fixed 10 행) · '
                        '부피분율 규칙 행은 **빈칸** (보충 lhss 의 volfrac_free 10 행 — 하중이 설계 입력이 아니다 · 역산값은 출처 열 lhss_loading_mAh_cm2 (정본 인계표 열) · '
                        '1저자 10-12 Q6 (가)) · 경계 = 보충 설계 생성기 SE_SPLIT 0.30 (am_pct 70 — 130 은 AM 70–95 wt%) · 확장 (lhsx) 설계에는 이 열이 없다 '
                        '(volfrac 기반)'),
    'pressure_MPa': ('압밀 목표압 (MPa · 설계 상수 300 = 덱 target_press) · ⚠ **도달 여부는 이 열이 말하지 않는다** (DESC-06 — 압밀 루프 기록 열 '
                     'press_* 가 있는 표에서만 생성기가 확인한다)'),
    'e_se_gpa': 'DEM SE 유효 탄성계수 (GPa · 설계 상수 1.35 — 18 배 연화 규약 · 물성 아님)',
    'thickness_est_um': '두께 **추정** (µm · 면용량 · 조성 · EPS_TYPICAL 에서 계산 — 측정 아님 · LHS-09) · 측정 = thickness_wall_gap_um · thickness_mass_conserving_um',
    'phi_am_est': 'AM 부피분율 **추정** (EPS_TYPICAL 가정 — 측정 아님) · 측정 = phi_am_mass_conserving',
    'phi_se_est': 'SE 부피분율 **추정** (같은 가정 — 측정 아님) · 측정 = phi_se_mass_conserving',
    'se_percolation': ('SE 퍼콜 **평균장 추정** (옛 이름 = se_percolation_est_meanfield · phi_se_est 와 φc 0.195 비교) — 측정 아님 · 선별기이지 필터가 '
                       '아니다 (정밀도 54.5 % · LHS-01) · 측정 = percolation_pct'),
    'se_percolation_est_meanfield': ('SE 퍼콜 **평균장 추정** (phi_se_est 와 φc 0.195 비교) — 측정 아님 · 선별기이지 필터가 아니다 (정밀도 54.5 % · LHS-01) · '
                                     '측정 = percolation_pct'),
    'd_am_max_um': '가장 큰 AM 지름 (µm · max(d_am_p_um, d_am_s_um))',
    'sv_inv_um': 'Sauter 류 설계 추정 (µm · 추정 φ 기반) — 측정 아님',
    'r_AM_P_um': 'AM_P 반지름 (µm · = d_am_p_um / 2 · 덱 입력)',
    'r_AM_S_um': 'AM_S 반지름 (µm · = d_am_s_um / 2 · 덱 입력)',
    'r_SE_um': 'SE 반지름 (µm · = d_se_um / 2 · 덱 입력)',
    'size_ratio_P_over_S': 'd_am_p_um / d_am_s_um (설계 크기비 · mono 빈칸) — 지름 열의 재표현',
    'size_ratio_AM_over_SE': 'd_am_max_um (정본 인계표 열) / d_se_um (설계 크기비) — 지름 열의 재표현',
    'n_am_p_est': ('AM_P 입자 수 **설계 추정** — 측정 아님 · 측정 = n_AM_P_measured (설계 → 구조 예측에서 측정 N 을 X 로 쓰면 누설 · DESC-07)'),
    'n_am_s_est': 'AM_S 입자 수 **설계 추정** — 측정 아님 · 측정 = n_AM_S_measured',
    'n_se_est': 'SE 입자 수 **설계 추정** — 측정 아님 · 측정 = n_SE_measured',
    'n_total_est': '전체 입자 수 **설계 추정** (입자 수 상한 100,000 관문의 근거) — 측정 아님',
    'rve_min_um': 'AM_P 30 알을 담는 최소 측면 상자 (µm · 설계 추정)',
    'rve_recommended_um': '권장 측면 상자 (µm · 설계 추정 — 예산 결정은 사람이 한다)',
    'rve_over_d_am_max': 'rve_um / d_am_max_um (정본 인계표 열) (측면 유한크기 지표 · 설계값)',
    'thick_over_d_am_max': '추정 두께 / d_am_max_um (정본 인계표 열) (두께 방향 유한크기 · **추정**)',
    'finite_size_flag': '유한크기 라벨 (거부 아님) — lateral · thin · n_am_p_low · n_am_p_CRIT (기하 · 설계 추정)',
    'se_perc_est_flag': 'SE 퍼콜 **추정** 플래그 (기하 플래그와 분리 — LHS-01)',
    #  ── 확장 (lhsx) 설계 원본 열 — scripts/lhsx_design_adapter.py 가 lhs_ext_design 의 열 이름에 lhsx_ 를 붙여 그대로 옮겼다
    'lhsx_stratum': '확장 설계 층 번호 (lhs_ext_design 층화 — 층마다 LHS 8 점)',
    'lhsx_ntype': '덱 입자 type 수 (3 = bimodal · 2 = mono)',
    'lhsx_kind': '확장 설계 종류 (bimodal · mono_AM_P · mono_AM_S — block 과 같은 뜻)',
    'lhsx_pdd_SE': 'SE 질량분율 (덱 particledistribution/discrete) — am_pct = 100 · (1 − 이 값)',
    #  ★ 10-12 SUP20-02 (Codex 보충 20 지원 검토 §2) — 원천 P · S 슬롯의 mono 규약 (옛 문구 "AM_P 질량분율 — ps_frac = w_AM_P / (w_AM_P + w_AM_S)" 는
    #    mono_AM_S 행에서 1 을 준다 · 실제 ps_frac = 0) · 문구만 (CSV · 계산 변경 없음 · selftest ㉛j · ㉛j2)
    'lhsx_w_AM_P': ('P 슬롯 질량분율 (덱 · 셋의 합 = 1) — bimodal = AM_P · mono (type 2 개) = 단일 AM 자리 (크기 라벨 = lhsx_kind) · '
                    'ps_frac = w_AM_P / (w_AM_P + w_AM_S) 는 bimodal 에만 · mono_AM_P → ps_frac 1 · mono_AM_S → ps_frac 0 (어댑터가 kind 로 정한다)'),
    'lhsx_w_AM_S': 'S 슬롯 질량분율 (덱 · 셋의 합 = 1) — bimodal = AM_S · mono = 0',
    'lhsx_rSE_lo_um': 'SE 반지름 하한 (µm · 입자 수 상한을 지키려고 올린 값 · lhs_ext_design)',
    'lhsx_rSE_truncated': '1 = SE 반지름을 하한으로 눌렀다 (입자 수 상한 · lhs_ext_design) · 0 = 그대로',
    'lhsx_volfrac': '삽입 부피분율 (덱 volfrac — 확장 설계는 면용량 대신 이 값으로 두께가 정해진다)',
    'lhsx_phi_AM_solid': 'AM 의 고체 중 부피 몫 (설계 — 질량분율과 밀도에서 · lhs_ext_design.phi_am_of_pdd_se · 측정 아님)',
    'lhsx_lhs_cell': 'LHS 칸 좌표 (층 안 4 축 [pdd_SE · volfrac · rP 분위 · rSE 분위] 의 칸 번호)',
    'lhsx_seed': '덱 난수 seed',
    #  ── 보충 (lhss) 설계 원본 열 — scripts/lhss_design_adapter.py 가 lhsx 어댑터 adapt_row 그대로 옮기고 이름만 lhss_ 로 바꾼 12 + 보충 전용 5
    #     (1저자 10-12 Q4 = (가) lhss 별도 데이터셋 · 원천 = lhs_supp_design · 이름이 lhsx 와 같아도 뜻이 다른 열은 그 뜻으로 적는다)
    'lhss_stratum': '보충 설계에는 층이 없다 — 빈칸 (보충 20 은 층화 LHS 가 아니라 maximin 선택 · lhs_supp_design.maximin)',
    'lhss_ntype': '덱 입자 type 수 (3 = bimodal · 2 = mono)',
    'lhss_kind': '보충 설계 종류 (bimodal · mono_AM_P · mono_AM_S — block 과 같은 뜻)',
    'lhss_pdd_SE': 'SE 질량분율 (덱 particledistribution/discrete) — am_pct = 100 · (1 − 이 값) · 하중 규칙 경계 SE_SPLIT 0.30 (이하 = 2mAh_fixed)',
    'lhss_w_AM_P': ('P 슬롯 질량분율 (덱 · 셋의 합 = 1) — bimodal = AM_P · mono (type 2 개) = 단일 AM 자리 (크기 라벨 = lhss_kind) · '
                    'ps_frac = w_AM_P / (w_AM_P + w_AM_S) 는 bimodal 에만 · mono_AM_P → ps_frac 1 · mono_AM_S → ps_frac 0 (어댑터가 kind 로 정한다 · '
                    '보충 mono_AM_S 넷 = lhss_001 · 002 · 003 · 020)'),
    'lhss_w_AM_S': 'S 슬롯 질량분율 (덱 · 셋의 합 = 1) — bimodal = AM_S · mono = 0',
    'lhss_rSE_lo_um': ('SE 반지름 하한 (µm · 0.5 = SE 지름 1.0 µm 시뮬 가능 하한 — lhs_supp_design D_SE_MIN) · lhsx 의 "입자 수 상한 때문에 올린 하한" 과 '
                       '뜻이 다르다'),
    'lhss_rSE_truncated': '1 = SE 반지름을 하한으로 눌렀다 · 0 = 그대로 (보충 20 = 전부 0)',
    'lhss_volfrac': ('삽입 부피분율 (덱 volfrac) — 2mAh_fixed 행 = 하중 2.0 에서 계산한 값 (lhs_supp_design.volfrac_for_loading) · volfrac_free 행 = 설계 축 · '
                     'lhss_cap_adjust = volfrac 행은 입자 수 상한 때문에 낮춘 값'),
    'lhss_phi_AM_solid': 'AM 의 고체 중 부피 몫 (설계 — 질량분율과 밀도에서 · lhs_ext_design.phi_am_of_pdd_se · 측정 아님)',
    'lhss_lhs_cell': '보충 설계에는 LHS 칸이 없다 — 빈칸 (maximin 선택)',
    'lhss_seed': '덱 난수 seed',
    'lhss_loading_rule': ('하중 규칙 — 2mAh_fixed (130 의 2 mAh 규칙 · 하중 2.0 이 설계 입력 · AM ≥ 70 wt%) · volfrac_free (64 확장 규칙 · volfrac 가 설계 축 · '
                          'AM < 70 wt%) · 경계 = lhs_supp_design SE_SPLIT 0.30 (pdd_SE 이하 = 2mAh_fixed)'),
    'lhss_loading_mAh_cm2': ('면용량 (mAh/cm²) 출처 — 2mAh_fixed = 설계 입력 2.0 · volfrac_free = volfrac 에서 거꾸로 계산한 값 (설계 입력 아님 · 본 열 '
                             'loading_mAh_cm2 는 그 행에서 빈칸 · 1저자 10-12 Q6 (가))'),
    'lhss_ins_scale': '삽입 높이 배율 (보충 20 = 전부 1.0 — 후막 짝 lhst_* 의 3 · 4 와 구분 · 그 8 은 LHS 밖)',
    'lhss_cap_adjust': ('volfrac = 입자 수 상한 (기존 194 설계의 최대 추정 입자 수) 때문에 volfrac 를 낮춘 행 (보충 20 중 2) · 빈칸 = 조정 없음'),
    'lhss_gap_dist': ('선택 순간의 최근접 거리 (정규화 3 축 — ps · (SE wt% − 5)/65 · (SE 지름 − 1)/1 · 기존 194 점 + 먼저 고른 보충 점 · '
                      'lhs_supp_design.maximin) — 설계 기록 · 특징 아님'),
}


def design_define(col, design_source=None):
    """설계 열의 뜻 — DESIGN_DEFINE (없으면 일반 문구) + 이 표의 설계 원천.  확장 원본 열 (lhsx_*) · 보충 원본 열 (lhss_*) 은 어댑터 경유를 적는다."""
    src = design_source or '설계 CSV'
    base = DESIGN_DEFINE.get(col) or (f'설계 열 (`{col}` — 생성 코드: 130 = build() · 64 = scripts/lhsx_design_adapter.py · '
                                      f'보충 20 = scripts/lhss_design_adapter.py)')
    if col.startswith('lhsx_'):
        tail = f'원천 = {src} (확장 설계 docs/data/lhs_ext_design_v2_20260829.csv 를 scripts/lhsx_design_adapter.py 가 옮긴 열)'
    elif col.startswith('lhss_'):
        tail = f'원천 = {src} (보충 설계 docs/data/lhs_supp_design_20261006.csv 를 scripts/lhss_design_adapter.py 가 옮긴 열)'
    else:
        tail = f'원천 = {src}'
    return f'{base} · {tail}'


def column_dictionary(cols, webapp=None, design_source=None):
    """인계표 열 사전 — 열마다 출처 · 판정 · 뜻 · 주의.  빈 뜻은 없다 (selftest ⑲m).
    design_source = 이 표의 설계 CSV (경로 문자열 · CLI 가 --design 으로 넘긴다 — 확장 64 의 사전이 130 설계 파일을 가리키지 않게 · LREL-06)."""
    extra = {n: w for n, _p, w in HANDOVER_EXTRA}
    union = {n: w for n, _c, w in HANDOVER_UNION}
    union.update({n: w for n, w in HANDOVER_UNION_DERIVED})
    _tref = TAU_WALL_TRANSPORT_IN if any(c.startswith('tau2_ion_') for c in cols) else TAU_WALL_TRANSPORT_OUT
    tauw = {n: (w + ' · ' + _tref if n == 'tortuosity_SE_wall' else w) for n, _k, w in HANDOVER_TAU_WALL}
    tauw.update({n: w for n, _p, _s, w in HANDOVER_WALL_TOUCH})
    tauw.update({n: w for n, w in HANDOVER_SE_CLUSTER})                          # v1.1 ③
    derived = dict(WA_DERIVED)                                                   # v1.1 ①
    derived_se = dict(WA_DERIVED_SE_ISO)                                         # v1.3 고립 전해질
    warow = dict(WA_ROW_COLS)
    qc = {n: w for n, _a, _b, w in WA_QC}
    wverd, wwhy = wa_verdicts(webapp) if webapp is not None else ({}, {})      # 7c — 판정 바꿔 싣기 (LHS-23 · 7a) 를 표와 같게
    _press_mean = {n: w for n, _k, w in HANDOVER_PRESS}
    out = []
    for c in cols:
        d = {'column': c, 'source': '', 'verdict': '', 'meaning': '', 'caveat': ''}
        if c in HANDOVER_VALUE_MEANING:
            d.update(source='harvest', meaning=HANDOVER_VALUE_MEANING[c])
            if c.startswith('coverage_'):
                d['caveat'] = CAVEAT_COVERAGE                                      # ① CAVEAT_NAME + J20-m ②–⑥
        elif c.endswith('_status') and c[:-7] in HANDOVER_VALUE_MEANING:
            d.update(source='harvest', meaning=f'{c[:-7]} 의 상태 — OK 가 아니면 값 칸은 빈칸 (0 이 아니다)')
        elif c in extra:
            d.update(source='harvest', meaning=extra[c])
        elif c in union:
            d.update(source='union', meaning=union[c])
        elif c in tauw:
            d.update(source='harvest_v3', meaning=tauw[c])
        elif c in derived:
            d.update(source='webapp_derived', verdict='✅ 쓴다 (유도 · v1.1 ①)', meaning=derived[c], caveat=CAVEAT_PERC)
        elif c in derived_se:
            d.update(source='webapp_derived', verdict=SE_ISO_VERDICT, meaning=derived_se[c], caveat=CAVEAT_PERC)
        elif c in warow:
            d.update(source='webapp_batch', meaning=warow[c])
        elif c in qc:
            d.update(source='qc', meaning=qc[c])
        elif c in _press_mean:                       # DESC-06 — 완료 압력 기록 (lhs_pressure_record)
            d.update(source='pressure_log', meaning=_press_mean[c])
        elif tau_net_define(c) is not None:          # v1.2 망 τ (tau_flux 열 · τ 명명 규약) — 이름이 정확히 τ 꼴일 때만 (옛 열은 안 잡는다)
            _tm, _tc = tau_net_define(c)
            d.update(source=TAU_NET_SOURCE, verdict=tau_net_verdict(c), meaning=_tm, caveat=_tc)
        elif webapp is not None and c in wverd:
            v = wverd[c]
            why = wwhy.get(c) or '웹앱 파이프라인 산출 (코퍼스 case_master 와 같은 이름 · 같은 계산)'
            dfn = wa_define(c)                       # J20-a ⓒ — 접촉 위상 열은 정의를 먼저 (판정 근거는 괄호로 남긴다)
            _lab = '09-19 판정 근거' if c in (webapp.get('verdict') or {}) else '판정 근거 (09-19 census 밖 키)'   # 7c — 7a 새 키
            meaning = f'{dfn[0]} ({_lab}: {why})' if dfn else why
            note = wa_review_note(c)                 # J20-g — 1저자 검토 기록
            if note:
                meaning += f' · 1저자 검토: {note}'
            if WA_PAIR_COUNT.fullmatch(c):           # J20-h
                meaning += ' · ' + PAIR_ZERO_NOTE
            d.update(source='webapp', verdict=v, meaning=meaning)
            d['caveat'] = dfn[1] if dfn else (CAVEAT_NAME if '이름 주의' in v else _frac_caveat(c))
        else:
            d.update(source='design', meaning=design_define(c, design_source))
        if wa_phase_specific(c) and d['source'] != 'design':      # J20-k (B) — 상별 열 전부 (수확 · 웹앱 · QC) 에 mono 규약 표지
            d['meaning'] += ' · ' + MONO_DESIGN_NOTE
        out.append(d)
    return out


def load_union(path):
    """union TSV (scripts/lhs_union_webapp.py 산출) → dict(case → 행).  같은 case 가 둘이면 거부."""
    with open(path, encoding='utf-8') as fh:
        rows = list(csv.DictReader(fh, delimiter='\t'))
    out = {}
    for r in rows:
        c = r.get('case')
        if not c or c in out:
            raise FillRefusal(f'union TSV {path}: case {c!r} 가 비었거나 둘 이상이다')
        out[c] = r
    return out


def _union_cols(case, h, u):
    """J19 — 수확 한 건 + union 행 → 인계 열.  짝 (같은 수확 · 같은 프레임) 이 아니면 `FillRefusal`."""
    if u.get('status') != 'OK':
        raise FillRefusal(f'{case}: union status {u.get("status")!r} ≠ OK — 그 union 값을 붙이지 않는다')
    eps_s = float(h['porosity_sphere_pct_RECORD_ONLY'])
    if abs(float(u['eps_sphere_web']) - eps_s) > UNION_TOL['eps_sphere_pct']:
        raise FillRefusal(f'{case}: union 의 구 부피 합 {u["eps_sphere_web"]} ≠ 수확 {eps_s!r} — 다른 수확 · 다른 프레임의 union 이다')
    th = (h.get('handover_qc') or {}).get('thickness_wall_gap_um')
    if th is None:
        raise FillRefusal(f'{case}: 수확에 두께 (handover_qc.thickness_wall_gap_um) 가 없다 — 09-24 판 수확이다 (0925 판을 쓸 것 · DEFAULT_HARVEST_DIR)')
    if abs(float(u['thickness_um']) - float(th)) > UNION_TOL['thickness_um']:
        raise FillRefusal(f'{case}: union 두께 {u["thickness_um"]} ≠ 수확 {th!r} µm — 다른 프레임 (플래튼) 의 union 이다')
    pc = h.get('phase_counts') or {}
    n_am = sum(int(v) for k, v in pc.items() if k != 'SE')
    if int(u['n_SE']) != int(pc.get('SE', -1)) or int(u['n_AM']) != n_am:
        raise FillRefusal(f'{case}: union 입자 수 (SE {u["n_SE"]} · AM {u["n_AM"]}) ≠ 수확 (SE {pc.get("SE")} · AM {n_am}) — 다른 침대다')
    eps_u = float(u['mc_void_pct'])
    if not 0.0 < eps_u < 100.0:
        raise FillRefusal(f'{case}: 정확 union {eps_u!r} % 가 (0, 100) 밖이다')
    #  ★ LREL-04 (Codex 배포 v1.1 최종 리뷰 반례 union_SE_fraction_half) — SE/고체 를 수확에서 **다시 재** 교차대조 · [0, 1].  φ 합 닫힘만 보면
    #    union 행의 se_of_solid_vol 한 칸을 0.5 로 바꿔도 통과했다 (ε · φ_SE 는 그대로 · se_rich 만 오염).  원천 = 수확 부피 감사 V_SE/(V_SE + V_AM)
    #    (handover_qc) · φ_SE/(φ_SE + φ_AM) (φ 상태 OK) — 있는 것 전부와 맞아야 하고 하나는 있어야 한다 (10-06 실측 194 행 최대 차 5.6e-16).
    try:
        se_u = float(u.get('se_of_solid_vol'))
    except (TypeError, ValueError):
        se_u = float('nan')
    if not (math.isfinite(se_u) and 0.0 <= se_u <= 1.0):
        raise FillRefusal(f'{case}: union se_of_solid_vol {u.get("se_of_solid_vol")!r} 가 유한 [0, 1] 밖이다 (LREL-04)')
    refs = []
    qc_ = h.get('handover_qc') or {}
    try:
        vs_, va_ = float(qc_.get('V_SE_full_um3')), float(qc_.get('V_AM_full_um3'))
        if math.isfinite(vs_) and math.isfinite(va_) and vs_ >= 0 and va_ >= 0 and vs_ + va_ > 0:
            refs.append(('수확 부피 감사 V_SE/(V_SE + V_AM)', vs_ / (vs_ + va_)))
    except (TypeError, ValueError):
        pass
    if (h.get('status') or {}).get(DESCRIPTOR_STATUS_KEY['phi_se']) == 'OK' and h.get('phi_se') is not None and h.get('phi_am') is not None:
        ps_, pa_ = float(h['phi_se']), float(h['phi_am'])
        if math.isfinite(ps_) and math.isfinite(pa_) and ps_ + pa_ > 0:
            refs.append(('수확 φ_SE/(φ_SE + φ_AM)', ps_ / (ps_ + pa_)))
    if not refs:
        raise FillRefusal(f'{case}: SE/고체 를 다시 잴 원천이 없다 (수확 handover_qc V_SE · V_AM 없음 · φ 상태 OK 아님) — union se_of_solid_vol 을 '
                          '그대로 싣지 않는다 (LREL-04)')
    for lab_, ref_ in refs:
        if abs(se_u - ref_) > SE_SHARE_TOL:
            raise FillRefusal(f'{case}: union se_of_solid_vol {se_u!r} ≠ {lab_} {ref_!r} (차 {abs(se_u - ref_):.3e} > {SE_SHARE_TOL:.0e}) — '
                              'SE 몫이 φ 장부와 따로 바뀌었다 (LREL-04)')
    o = {name: (str(u[col]) if col == 'pair_upper_bound_ok' else repr(float(u[col]))) for name, col, _w in HANDOVER_UNION}
    o['thickness_mass_conserving_um'] = repr(float(th) * (1.0 - eps_s / 100.0) / (1.0 - eps_u / 100.0))
    o['se_rich'] = str(float(u['se_of_solid_vol']) >= SE_RICH_MIN)
    #  J20-e (1저자 09-29 밤 "φ 는 (라) 만") — 질량 보존 φ: 인계 두께 (질량 보존) · porosity (union) 와 **같은 장부**.
    #   φ_i = φ_i(구) × (1 − ε_union)/(1 − ε_sphere) = V_i / (L² · 질량 보존 두께).  겹침 배분 규칙이 필요 없다.
    #   φ status 가 OK 가 아니면 빈칸 (계약 ② — 0 이 아니다).
    o['phi_se_mass_conserving'] = o['phi_am_mass_conserving'] = ''
    if ((h.get('status') or {}).get(DESCRIPTOR_STATUS_KEY['phi_se']) == 'OK'
            and h.get('phi_se') is not None and h.get('phi_am') is not None):
        k = (1.0 - eps_u / 100.0) / (1.0 - eps_s / 100.0)
        pse, pam = float(h['phi_se']) * k, float(h['phi_am']) * k
        e = abs(pse + pam + eps_u / 100.0 - 1.0)
        if e > PHI_MC_CLOSURE_TOL:
            raise FillRefusal(f'{case}: 질량 보존 φ 닫힘 {e:.3e} > {PHI_MC_CLOSURE_TOL:.0e} — DESC-07 (φ 둘 ↔ ε_sphere) 이 깨졌다')
        o['phi_se_mass_conserving'], o['phi_am_mass_conserving'] = repr(pse), repr(pam)
    return o


def _dig(h, path):
    cur = h
    for k in path:
        if not isinstance(cur, dict) or k not in cur:
            return None
        cur = cur[k]
    return cur


#: 7c — AM–SE CN · 고립 열 (calc_am_isolation_risk 산출)
WA_AMSE_COL = re.compile(r'am_se_cn_(mean|surface_weighted|std|median|max)|(AM_P|AM_S)_se_cn_(mean|std|median|max)|'
                         r'(am|AM_P|AM_S)_vulnerable_pct')
WA_AMSE_PHASE_COL = re.compile(r'(AM_P|AM_S)_(se_cn_(mean|std|median|max)|vulnerable_pct)')
WA_COUNT_INT_TOL = 1e-6          # 고립 비율 × 입자 수 / 100 = 정수 개수 (부동소수 여유 — 물리 허용치 아님)


def _wa_amse_gates(case, o, take, h, dp, drow):
    """7c 관문 (fail-closed) — 표에 실린 AM–SE CN · 고립 값 (o, mono 는 설계 상 칸으로 옮긴 뒤) 이 **같은 counts** (AM 입자별 SE 접촉 수 ·
    `calc_am_isolation_risk`) 에서 나왔는가.  09-30 실측 (J20-k) 은 전부 차이 0 · 5번 배치 max · median 194/194.

      상 있음/없음 — 상 (수확 phase_counts · mono 는 설계 상 = 수확 AM) 이 있으면 실린 상별 열은 값이 있어야 · 없으면 빈칸이어야 · 전체 열도 값
      G1 상별 평균 × 상 입자 수 = area_<상>_SE_n · G2 전체 평균 × AM 수 = area_AM전체_SE_n
      G3 고립: 비율 × 입자 수 / 100 = 정수 개수 · 전체 개수 = 상별 개수 합
      G4 전체 max = 상별 max 의 최댓값 · G5 median: mono = 단일 상 값 · bimodal = 상별 median 사이 (합집합의 중앙값 성질)
      G6 std: mono = 단일 상 값 · bimodal = 합동 (Σ N (σ² + μ²) / N − μ²) · G7 표면 가중: mono = 전체 평균 · bimodal = Σ N r² μ / Σ N r² (설계 반경)
    반환 1 (검사함).  어긋나면 `FillRefusal` (메시지에 '7c G<n>')."""
    pc = h.get('phase_counts')
    if not isinstance(pc, dict):
        raise FillRefusal(f'{case}: 수확 JSON 에 phase_counts 가 없다 — 상 입자 수를 몰라 AM–SE CN · 고립 관문을 볼 수 없다 (7c)')
    n = {ph: _phase_n_mono(pc, ph, dp) for ph in ('AM_P', 'AM_S')}
    n_am = _phase_n(pc, 'AM전체')
    present = [ph for ph in ('AM_P', 'AM_S') if n[ph] > 0]

    def num(c):
        v = o.get(c, '')
        return None if v in (None, '') else float(v)

    def close(a, b):
        return a is not None and b is not None and abs(a - b) <= WA_CN_IDENTITY_TOL * max(1.0, abs(b))

    for c in take:                                                   # 상 있음/없음
        m = WA_AMSE_PHASE_COL.fullmatch(c)
        has = o.get(c, '') not in (None, '')
        if m and n[m.group(1)] > 0 and not has:
            raise FillRefusal(f'{case}: {m.group(1)} 입자 {n[m.group(1)]} 개인데 {c} 가 빈칸 — 상이 있는데 값이 없다 (7c 상 있음)')
        if m and n[m.group(1)] == 0 and has:
            raise FillRefusal(f'{case}: {m.group(1)} 가 없는 침대 (수확 phase_counts) 인데 {c} = {o[c]} — 다른 침대의 값이다 (7c 상 없음)')
        if not m and WA_AMSE_COL.fullmatch(c) and n_am > 0 and not has:
            raise FillRefusal(f'{case}: AM {n_am} 개인데 {c} 가 빈칸 (7c 상 있음)')
    for ph in present:                                               # G1
        cm, ca = f'{ph}_se_cn_mean', f'area_{ph}_SE_n'
        if cm in take and ca in take and not close(num(cm) * n[ph], num(ca)):
            raise FillRefusal(f'{case}: {cm} {num(cm)!r} × {ph} {n[ph]} ≠ {ca} {num(ca)!r} — 같은 접촉 집합의 값이 아니다 (7c G1)')
    mu = num('am_se_cn_mean') if 'am_se_cn_mean' in take else None
    if mu is not None and 'area_AM전체_SE_n' in take and not close(mu * n_am, num('area_AM전체_SE_n')):  # G2
        raise FillRefusal(f'{case}: am_se_cn_mean {mu!r} × AM {n_am} ≠ area_AM전체_SE_n {num("area_AM전체_SE_n")!r} (7c G2)')
    if 'am_vulnerable_pct' in take:                                  # G3
        parts = {ph: num(f'{ph}_vulnerable_pct') * n[ph] / 100.0 for ph in present if f'{ph}_vulnerable_pct' in take}
        tot = num('am_vulnerable_pct') * n_am / 100.0
        for lab, x in [('am', tot)] + list(parts.items()):
            if abs(x - round(x)) > WA_COUNT_INT_TOL:
                raise FillRefusal(f'{case}: {lab} 고립 비율 × 입자 수 / 100 = {x!r} 이 정수 개수가 아니다 (7c G3)')
        if len(parts) == len(present) and round(tot) != sum(round(x) for x in parts.values()):
            raise FillRefusal(f'{case}: 고립 개수 전체 {round(tot)} ≠ 상별 합 {sum(round(x) for x in parts.values())} (7c G3)')
    st = {s: {ph: num(f'{ph}_se_cn_{s}') for ph in present if f'{ph}_se_cn_{s}' in take} for s in ('mean', 'std', 'median', 'max')}
    full = {s: len(st[s]) == len(present) and len(present) > 0 for s in st}
    if 'am_se_cn_max' in take and full['max'] and num('am_se_cn_max') != max(st['max'].values()):     # G4 (정수)
        raise FillRefusal(f'{case}: am_se_cn_max {num("am_se_cn_max")!r} ≠ 상별 max 의 최댓값 {max(st["max"].values())!r} (7c G4)')
    if 'am_se_cn_median' in take and full['median']:                 # G5
        md, lo, hi = num('am_se_cn_median'), min(st['median'].values()), max(st['median'].values())
        ok5 = close(md, lo) if len(present) == 1 else (lo - WA_CN_IDENTITY_TOL * max(1.0, lo) <= md <= hi + WA_CN_IDENTITY_TOL * max(1.0, hi))
        if not ok5:
            raise FillRefusal(f'{case}: am_se_cn_median {md!r} — 상별 median {st["median"]} ' + ('과 같아야 (mono)' if len(present) == 1 else '사이여야')
                              + ' (7c G5)')
    if 'am_se_cn_std' in take and mu is not None and full['std'] and full['mean']:    # G6
        sd = num('am_se_cn_std')
        if len(present) == 1:
            ok6 = close(sd, st['std'][present[0]])
        else:
            m2 = sum(n[ph] * (st['std'][ph] ** 2 + st['mean'][ph] ** 2) for ph in present) / n_am
            ok6 = abs(sd * sd - (m2 - mu * mu)) <= WA_CN_IDENTITY_TOL * max(1.0, m2)
        if not ok6:
            raise FillRefusal(f'{case}: am_se_cn_std {sd!r} — 상별 (N · 평균 · std) 의 합동 표준편차와 다르다 (7c G6)')
    if 'am_se_cn_surface_weighted' in take and mu is not None:        # G7
        sw = num('am_se_cn_surface_weighted')
        if len(present) == 1:
            exp7 = mu
        else:
            if not full['mean']:
                raise FillRefusal(f'{case}: 표면 가중을 확인할 상별 평균이 표에 없다 (7c G7)')
            try:
                rr = {ph: float(drow.get(f'r_{ph}_um')) for ph in present}
            except (TypeError, ValueError):
                raise FillRefusal(f'{case}: bimodal 인데 설계 반경 r_AM_P_um · r_AM_S_um 이 없다 — 표면 가중을 확인할 수 없다 (7c G7 반경)')
            exp7 = (sum(n[ph] * rr[ph] ** 2 * st['mean'][ph] for ph in present) / sum(n[ph] * rr[ph] ** 2 for ph in present))
        if not close(sw, exp7):
            raise FillRefusal(f'{case}: am_se_cn_surface_weighted {sw!r} ≠ {exp7!r} (Σ N r² CN / Σ N r² · 설계 반경) (7c G7)')
    return 1


#: ⑤⑥⑦ 관문 여유 — 물리 허용치가 아니다 (웹앱 반올림 · 부동소수 합의 순서만)
WA_FRAC_PCT_TOL = 0.005 + 1e-9          # calc_fracture_stages: round(100 n / N, 2) → 반폭 0.005
WA_FRAC_FI_TOL = 5e-5 + 1e-12           # round((파편화 + 분쇄) / N, 4)
WA_AREA_TOL = 1e-9                      # 같은 접촉 면적 합 (10-01 실측 ≤ 3e-14)
#: ★ RGL-05 (Codex 10-05 · P2 · 1저자 비준 "권고대로") — ⑤⑥⑦ 관문 순서 = **선택 묶음의 원천 근거 열 요구 → 유한성 → 형/범위 → 식**.
#:   옛 판은 식만 봤다: abs(NaN) > 여유 가 거짓이라 NaN 이 식 검사를 통과해 표에 남았고 (비율 · 지수 · 면적 평균 · 총합) · 양수 검사가 유한성을
#:   대신했고 (h = inf) · 근거 열 (se_se_cn · am_am_n_contacts · percolation_pct · 쌍 개수) 이 비면 식을 **건너뛰었고** · 개수가 빠진 쌍을
#:   검사 **뒤** 0 으로 채워 접촉 0 평균 N/A 규칙이 깨졌다 (Codex probe_g4 — 그 변이는 selftest ㉗ 로 옮겼다).
#:   형/범위 = 열 정의 그대로 — 반올림 반폭 (WA_FRAC_*_TOL) 은 **식 잔차**에만 쓰고 범위를 넓히지 않는다 (round(·, 2) · round(·, 4) 는 [0, 100] ·
#:   [0, 1] 밖으로 못 간다).  거부 문구 = '(관문 <그 값을 쓰는 식의 번호> 필수 | 유한 | 범위 · RGL-05)'.
WA_KIND = {'count': (lambda x: x >= 0.0 and x == int(x), '0 이상 정수 (개수)'),
           'pct': (lambda x: 0.0 <= x <= 100.0, '[0, 100] (비율 %)'),
           'index': (lambda x: 0.0 <= x <= 1.0, '[0, 1] (지수)'),
           'nonneg': (lambda x: x >= 0.0, '≥ 0 (면적 · 면적 비 · CN · 표준편차)'),
           'pos': (lambda x: x > 0.0, '> 0 (F1 틈 문턱 h · 설계 반경 — 0 이하 = F1 이 꺼진 값 · 없는 반경)')}
#: ⑤⑥⑦ 열 (+ 그 식의 원천 근거 열) 의 형/범위 — 열 사전 (WA_DEFINE) 의 정의 그대로.  단계별 개수 · 비율 · 쌍 열은 `wa_s567_kind` 가 이름으로 정한다.
WA_S567_KIND = {'se_se_cn': 'nonneg', 'se_se_cn_aug': 'nonneg', 'se_se_cn_aug_std': 'nonneg', 'se_se_cn_aug_n_extra': 'count',
                'se_se_cn_aug_h_spread_sim': 'pos', 'fracture_index_force': 'index', 'n_total_AM_AM_force': 'count',
                'am_am_n_contacts': 'count', 'percolation_pct': 'pct', 'se_se_cn_eff_area': 'nonneg', 'se_se_cn_eff_area_perc': 'nonneg',
                'am_am_mean_area': 'nonneg', 'am_am_total_area': 'nonneg'}
#: ⑦ 쌍 (calc_interface_area — 두 상 이름을 정렬해 잇는다 · AM전체–SE = AM–SE 상별 합).  RGL-05 정규화는 이 일곱을 키가 없어도 **늘** 본다.
WA_PAIR_ANY = re.compile(r'area_(AM_P|AM_S|SE|AM전체)_(AM_P|AM_S|SE)_(n|total|mean)')
WA_PAIR_BASES = ('area_AM_P_AM_P', 'area_AM_P_AM_S', 'area_AM_S_AM_S', 'area_AM_P_SE', 'area_AM_S_SE', 'area_SE_SE', 'area_AM전체_SE')
WA_AM_AM_BASES = ('area_AM_P_AM_P', 'area_AM_P_AM_S', 'area_AM_S_AM_S')


def wa_s567_kind(col):
    """RGL-05 — ⑤⑥⑦ (+ 원천 근거) 열의 형/범위 이름 (WA_KIND 의 키) · 모르는 열이면 None."""
    if col in WA_S567_KIND:
        return WA_S567_KIND[col]
    m = re.fullmatch(r'(frac|n)_([a-z]+)_force_(pct|AM_AM)', col)
    if m and m.group(2) in FRAC_STAGES:
        return 'pct' if m.group(1) == 'frac' else 'count'
    m = WA_PAIR_ANY.fullmatch(col)
    if m:
        return 'count' if m.group(3) == 'n' else 'nonneg'
    return None


def _wa_num(case, label, v, gate, kind=None, need=None):
    """RGL-05 — 값 하나를 **식 앞에서** 읽는다: 빈칸 → None (need 가 있으면 거부 — 원천 근거 · 필수 열 누락) · 수가 아님 · 비유한 → 거부 ·
    형/범위 (kind) 밖 → 거부.  abs(NaN) > 여유 가 거짓이라 식 검사가 NaN 을 통과시키던 길을 여기서 막는다."""
    if v in (None, ''):
        if need:
            raise FillRefusal(f'{case}: {label} 가 빈칸 — {need} (관문 {gate} 필수 · RGL-05)')
        return None
    try:
        x = float(v)
    except (TypeError, ValueError):
        raise FillRefusal(f'{case}: {label} {v!r} 이 수가 아니다 (관문 {gate} 유한 · RGL-05)') from None
    if not math.isfinite(x):
        raise FillRefusal(f'{case}: {label} {v!r} 이 유한한 수가 아니다 — 식 검사 (abs(…) > 여유) 를 우회하는 값 (관문 {gate} 유한 · RGL-05)')
    if kind is not None and not WA_KIND[kind][0](x):
        raise FillRefusal(f'{case}: {label} {v!r} — {WA_KIND[kind][1]} 밖 (관문 {gate} 범위 · RGL-05)')
    return x


def _wa_val(case, row, col, gate, kind=None, need=None):
    """`_wa_num` 의 행 판 — kind 를 안 주면 열 정의 (`wa_s567_kind`) 를 쓴다."""
    return _wa_num(case, col, row.get(col), gate, kind if kind is not None else wa_s567_kind(col), need)


def _wa_need(case, row, cols, gate, why):
    """RGL-05 — 원천 근거 · 필수 열이 값 검사 **전에** 다 있는가.  빈칸이 하나라도 있으면 거부 (식 검사를 건너뛰지 않는다)."""
    miss = [c for c in cols if row.get(c) in (None, '')]
    if miss:
        raise FillRefusal(f'{case}: {", ".join(miss)} 가 빈칸 — {why} (관문 {gate} 필수 · RGL-05)')


def _wa_src_col(c, dp, op, wname):
    """J20-k (B) — 표의 열 c (설계 이름) 를 채울 웹앱 원 행의 열 → (src, absent).  mono: 설계에 없는 상이 낀 열은 absent (빈칸 · N/A) ·
    웹앱 반지름 이름이 설계 상과 다르면 그 이름의 값 (`_phase_swap`).  bimodal 은 (c, False)."""
    src, absent = c, False
    if dp is not None and wa_phase_specific(c):
        absent = any(t == op for t in WA_PHASE_TOKEN.findall(c))
        if not absent and wname is not None and wname != dp:
            src = _phase_swap(c, dp, wname)
    return src, absent


def _wa_f1_gates(case, wr, h):
    """⑤F1 — se_se_cn_aug = se_se_cn + 2 × n_extra / N_SE (calc_se_se_cn: 근접쌍 하나가 두 입자에 하나씩 더해진다 · 같은 SE 집합의 평균).
    RGL-05 순서: 원천 근거 (탄성 se_se_cn · 수확 N_SE) · F1 네 열 (std 포함) 필수 → 유한 → 형/범위 → 식.  옛 판은 se_se_cn 이 비면 식을
    건너뛰었고 (Codex: aug −999 가 표에 남았다) · h 의 양수 검사가 유한성을 대신했고 (inf 통과) · std 는 보지 않았다."""
    pc = h.get('phase_counts')
    if not isinstance(pc, dict):
        raise FillRefusal(f'{case}: 수확 JSON 에 phase_counts 가 없다 — SE 입자 수를 몰라 F1 항등식을 잴 수 없다 (관문 ⑤F1 필수 · J20-s)')
    _wa_need(case, wr, ('se_se_cn',), '⑤F1', 'F1 항등식의 원천 근거 (탄성 SE–SE CN · 같은 calc_se_se_cn 출력) — 근거 없이 식 검사를 건너뛰지 않는다')
    _wa_need(case, wr, WA_GROUP_F1_EXACT, '⑤F1', 'se_se_cn 은 있는데 F1 열이 비었다 — F1 이 꺼진 배치 · 한 열만 빠진 행을 N/A 로 싣지 않는다')
    cn = _wa_val(case, wr, 'se_se_cn', '⑤F1')
    aug, _sd, nx, _hs = (_wa_val(case, wr, k, '⑤F1') for k in WA_GROUP_F1_EXACT)     # std ≥ 0 · n_extra 0 이상 정수 · h > 0 (유한)
    n_se = _phase_n(pc, 'SE')
    exp = cn + 2.0 * nx / n_se if n_se > 0 else float('nan')
    if not (n_se > 0 and abs(aug - exp) <= WA_CN_IDENTITY_TOL * max(1.0, abs(exp))):
        raise FillRefusal(f'{case}: se_se_cn_aug {aug!r} ≠ se_se_cn {cn!r} + 2 × n_extra {nx:g} / SE {n_se} = {exp!r} — 같은 접촉 집합의 '
                          'F1 이 아니다 (관문 ⑤F1 · J20-s)')
    return 1


def _wa_frac_gates(case, wr):
    """⑥R1–R3 — calc_fracture_stages: 단계 개수 합 = 전체 · 비율 = round(100 n / N, 2) · 지수 = round((파편화 + 분쇄) / N, 4) · 전체 ≤ AM–AM 접촉.
    RGL-05 순서: 원천 근거 (am_am_n_contacts — R3 상한 · 접촉 0 인지 가른다) → 필수 (단계 개수 · N > 0 이면 비율 · 지수) → 유한 → 형/범위 → 식.
    AM–AM 접촉 0 (calc_fracture_stages 가 {} 를 낸다) = 파괴 키가 하나도 없어야 하는 **검증된 상태** → 1 (확인함) · 파괴 열은 빈칸 (N/A)."""
    amn = _wa_val(case, wr, 'am_am_n_contacts', '⑥R3',
                  need='힘 기반 파괴의 원천 근거 (AM–AM 접촉 수 — R3 상한 · 접촉 0 인지 가른다) — 근거 없이 R3 를 건너뛰지 않는다')
    if wr.get('n_total_AM_AM_force') in (None, ''):
        has = [k for k in WA_GROUP_FRAC_EXACT if wr.get(k) not in (None, '')]
        if amn > 0:
            raise FillRefusal(f'{case}: AM–AM 접촉 {amn:g} 개인데 힘 기반 파괴 열이 없다 — 파괴 단계가 빠진 행 (관문 ⑥R1 필수 · J20-s)')
        if has:
            raise FillRefusal(f'{case}: AM–AM 접촉 0 인데 파괴 키 {has[:3]} 만 있다 — calc_fracture_stages 는 접촉 0 이면 키를 하나도 안 쓴다 '
                              '(상태 혼합 · 관문 ⑥R1 필수 · RGL-05)')
        return 1                                                          # AM–AM 접촉 0 — 검증된 상태 (파괴 열 = N/A)
    _wa_need(case, wr, tuple(f'n_{s}_force_AM_AM' for s in FRAC_STAGES), '⑥R1', '힘 기반 단계 개수가 비었다 — 단계 합 = 전체를 잴 수 없다')
    n_t = _wa_val(case, wr, 'n_total_AM_AM_force', '⑥R1')
    ns = [_wa_val(case, wr, f'n_{s}_force_AM_AM', '⑥R1') for s in FRAC_STAGES]
    if n_t > 0:
        _wa_need(case, wr, ('fracture_index_force',) + tuple(f'frac_{s}_force_pct' for s in FRAC_STAGES), '⑥R2',
                 f'n_total_AM_AM_force {n_t:g} > 0 인데 비율 · 지수가 비었다')
    fi = _wa_val(case, wr, 'fracture_index_force', '⑥R2')                 # [0, 1] — 반폭 안이어도 음수 · 1 초과는 범위 밖
    fr = [_wa_val(case, wr, f'frac_{s}_force_pct', '⑥R2') for s in FRAC_STAGES]     # [0, 100]
    if sum(ns) != n_t:
        raise FillRefusal(f'{case}: 힘 기반 단계 개수 합 {sum(ns):g} ≠ n_total_AM_AM_force {n_t:g} (관문 ⑥R1 · J20-s)')
    if n_t > 0:
        for s, x, n in zip(FRAC_STAGES, fr, ns):
            if not abs(x - 100.0 * n / n_t) <= WA_FRAC_PCT_TOL:
                raise FillRefusal(f'{case}: frac_{s}_force_pct {x!r} ≠ 100 × {n:g} / {n_t:g} = {100.0 * n / n_t:.4f} — 반올림 폭 0.005 밖 '
                                  '(관문 ⑥R2 · J20-s)')
        e_fi = (ns[3] + ns[4]) / n_t
        if not abs(fi - e_fi) <= WA_FRAC_FI_TOL:
            raise FillRefusal(f'{case}: fracture_index_force {fi!r} ≠ (파편화 + 분쇄) / N = {e_fi:.6f} — 반올림 폭 5e-5 밖 (관문 ⑥R2 · J20-s)')
    elif fi is not None or any(x is not None for x in fr):
        raise FillRefusal(f'{case}: n_total_AM_AM_force 0 인데 비율 · 지수가 있다 (관문 ⑥R2 · J20-s)')
    if n_t > amn:
        raise FillRefusal(f'{case}: n_total_AM_AM_force {n_t:g} > am_am_n_contacts {amn:g} — fn > 0 AM–AM 접촉은 전 AM–AM 접촉의 부분집합 '
                          '(관문 ⑥R3 · J20-s)')
    return 1


def _wa_raw_phase_n(pc, dp, wname):
    """RGL-05 — 웹앱 **원 이름** 의 상 → 입자 수 (쌍 정규화용).  bimodal 은 수확 이름 = 웹앱 이름 · mono (설계 상 dp) 는 웹앱이 단일 AM 에
    붙인 반지름 이름 (wname · 모르면 설계 상) 이 AM 전체이고 다른 이름은 0 (J20-k (B))."""
    n = {'SE': _phase_n(pc, 'SE'), 'AM전체': _phase_n(pc, 'AM전체')}
    if dp is None:
        n.update(AM_P=_phase_n(pc, 'AM_P'), AM_S=_phase_n(pc, 'AM_S'))
    else:
        nm = wname or dp
        n.update({ph: (n['AM전체'] if ph == nm else 0) for ph in ('AM_P', 'AM_S')})
    return n


def _wa_area_norm(case, wr, rn, rep):
    """⑦A1 (+ A3) — RGL-05: 쌍마다 개수 · 총합 · 평균을 **함께** 읽어 한 상태로 정한 웹앱 원 행 **사본** (원 행은 안 바꾼다 · 웹앱 원 이름).
    순서 = 원천 근거 (개수 · 상 유무) → 유한 → 형/범위 → 식.  옛 판 (`_wa_area_prep`) 은 값이 있는 개수만 봤고, 개수가 빠진 쌍은 검사 **뒤**
    출력에서 0 으로 채워 '개수 0 · 평균 0.01' 이 표에 남았다 (Codex missing_pair_count_positive_mean).
      상 부재 (rn 0)       — 세 키 모두 빈칸이어야 (값이 있으면 다른 침대 · 다른 상의 값 → 거부) · 빈칸 그대로 (N/A)
      접촉 0               — 개수 0 · 총합 0 · 평균 빈칸 (calc_interface_area 의 AM전체–SE 평균 0 대입은 비운다 · 0 아닌 평균은 거부) ·
                             세 키 모두 빈칸 (09-30 이전 웹앱 — 접촉 0 쌍의 키를 안 만들었다) 이면 0 · 0.0 · 빈칸 (J20-h)
      접촉 있음 (개수 > 0)  — 총합 · 평균 필수 · 평균 × 개수 = 총합
      기술적 결측           — 개수 없이 총합 · 평균만 있거나 (누락 → 0 채움 금지) · 개수만 있고 총합이 없으면 거부 (웹앱은 둘을 함께 쓴다)
    AM–AM 묶음 (am_am_n_contacts · am_am_total_area · am_am_mean_area — calc_am_am_cn 은 AM 이 있으면 셋을 늘 쓴다) 도 같은 셋:
      개수 = 원천 근거 · 접촉 0 이면 총합 0 · 평균 빈칸 (calc_am_am_cn 의 0 대입은 비운다).
    rn = 웹앱 원 이름 상 → 입자 수 (`_wa_raw_phase_n`)."""
    out = dict(wr)
    bases = set(WA_PAIR_BASES) | {k[:k.rfind('_')] for k in wr if WA_PAIR_ANY.fullmatch(k)}
    for b in sorted(bases):
        p1, p2 = re.fullmatch(r'area_(AM_P|AM_S|SE|AM전체)_(AM_P|AM_S|SE)', b).groups()
        kn, kt, km = b + '_n', b + '_total', b + '_mean'
        has = [k for k in (kn, kt, km) if wr.get(k) not in (None, '')]
        if not (rn.get(p1, 0) > 0 and rn.get(p2, 0) > 0):
            if has:
                raise FillRefusal(f'{case}: {b} — 상 ({p1 if rn.get(p1, 0) <= 0 else p2}) 이 없는 침대인데 {has} 에 값이 있다 — 다른 침대 · 다른 상의 '
                                  '값이다 (관문 ⑦A1 상 없음 · RGL-05)')
            continue                                                      # 상 부재 — N/A (빈칸 그대로)
        if kn not in has:
            if has:
                raise FillRefusal(f'{case}: {kn} 가 빈칸인데 같은 쌍의 {has} 에 값이 있다 — 개수 없이 0 으로 채우지 않는다 (누락 → 0 채움 금지 · '
                                  '관문 ⑦A1 필수 · RGL-05)')
            out[kn], out[kt], out[km] = '0', '0.0', ''                    # 옛 웹앱의 접촉 0 쌍 (세 키 모두 없음) — 측정된 0 · 평균 N/A (J20-h)
            continue
        _wa_need(case, wr, (kt,), '⑦A1', f'{kn} {wr.get(kn)!r} 은 있는데 총합이 없다 — 웹앱은 개수 · 총합을 함께 쓴다 (기술적 결측)')
        n = _wa_val(case, wr, kn, '⑦A1')
        tot = _wa_val(case, wr, kt, '⑦A1')
        mean = _wa_val(case, wr, km, '⑦A1')
        if n > 0:
            if mean is None:
                raise FillRefusal(f'{case}: {b} 개수 {n:g} > 0 인데 평균이 비었다 (관문 ⑦A1 필수 · J20-s · RGL-05)')
            if not abs(mean * n - tot) <= WA_AREA_TOL * max(abs(tot), abs(mean * n), 1e-300):
                raise FillRefusal(f'{case}: {b}_mean {mean!r} × 개수 {n:g} ≠ {b}_total {tot!r} — 같은 접촉의 값이 아니다 (관문 ⑦A1 · J20-s)')
        else:
            if tot != 0.0:
                raise FillRefusal(f'{case}: {b} 개수 0 인데 총합 {tot!r} ≠ 0 (관문 ⑦A1 · J20-s)')
            if mean is not None:
                if mean != 0.0:
                    raise FillRefusal(f'{case}: {b} 개수 0 인데 평균 {mean!r} 이 있다 — 접촉 0 개에서 평균은 정의되지 않는다 (관문 ⑦A1 · J20-s)')
                out[km] = ''
                rep['wa_area_mean_blanked'] += 1
    if rn.get('AM전체', 0) > 0:
        amn = _wa_val(case, wr, 'am_am_n_contacts', '⑦A3', need='AM–AM 면적 (총합 · 평균) 의 원천 근거 (calc_am_am_cn 의 개수)')
        _wa_need(case, wr, ('am_am_total_area',), '⑦A3', 'calc_am_am_cn 은 AM 이 있으면 총합을 늘 쓴다 (평균만 남은 AM–AM = 기술적 결측)')
        aat = _wa_val(case, wr, 'am_am_total_area', '⑦A3')
        aam = _wa_val(case, wr, 'am_am_mean_area', '⑦A3')
        if amn > 0:
            if aam is None:
                raise FillRefusal(f'{case}: AM–AM 접촉 {amn:g} 개인데 am_am_mean_area 가 비었다 (관문 ⑦A3 필수 · RGL-05)')
        else:
            if aat != 0.0:
                raise FillRefusal(f'{case}: AM–AM 접촉 0 인데 am_am_total_area {aat!r} ≠ 0 (관문 ⑦A3 · RGL-05)')
            if aam is not None:
                if aam != 0.0:
                    raise FillRefusal(f'{case}: AM–AM 접촉 0 인데 am_am_mean_area {aam!r} 이 있다 — 접촉 0 개에서 평균은 정의되지 않는다 '
                                      '(관문 ⑦A3 · RGL-05)')
                out['am_am_mean_area'] = ''                               # calc_am_am_cn 의 0 대입 — N/A (쌍 평균과 같은 규칙)
                rep['wa_area_mean_blanked'] += 1
    return out


def _wa_area_gates(case, wn, h, drow, take, rn):
    """⑦A2–A5 — `_wa_area_norm` 으로 정규화한 행에서 (쌍 · AM–AM 셋이 한 상태로 정해진 뒤): AM전체–SE = 상별 합 (총합 · 개수) ·
    AM–AM 개수 = 쌍 개수 합 · 총합 = 쌍 총합 합 · 평균 = 총합 / 개수 · eff_area = 2 × SE–SE 총합 / (N_SE · 4π r_SE²) · eff_area_perc 빈칸 ⟺ 비관통.
    RGL-05: A4 · A5 의 원천 근거 (설계 r_SE · 수확 N_SE · SE–SE 총합 · percolation_pct) 와 그 열을 먼저 요구한다 — 옛 판은 근거가 비면 식을 건너뛰었다."""
    def num(k, g):
        return _wa_val(case, wn, k, g, need='정규화 뒤에도 비었다 — 상이 있는 쌍은 개수 · 총합이 정해져 있어야 한다')
    if rn.get('AM전체', 0) > 0 and rn.get('SE', 0) > 0:                   # A2
        ph = [p for p in ('AM_P', 'AM_S') if rn.get(p, 0) > 0]
        tot, n_all = num('area_AM전체_SE_total', '⑦A2'), num('area_AM전체_SE_n', '⑦A2')
        s_t = sum(num(f'area_{p}_SE_total', '⑦A2') for p in ph)
        s_n = sum(num(f'area_{p}_SE_n', '⑦A2') for p in ph)
        if not abs(tot - s_t) <= WA_AREA_TOL * max(abs(tot), abs(s_t), 1e-300):
            raise FillRefusal(f'{case}: area_AM전체_SE_total {tot!r} ≠ AM_P–SE + AM_S–SE {s_t!r} (관문 ⑦A2 · J20-s)')
        if n_all != s_n:
            raise FillRefusal(f'{case}: area_AM전체_SE_n {n_all:g} ≠ AM_P–SE + AM_S–SE 개수 {s_n:g} (관문 ⑦A2 · J20-s)')
    if rn.get('AM전체', 0) > 0:                                            # A3
        bases = [b for b in WA_AM_AM_BASES if all(rn.get(p, 0) > 0 for p in re.fullmatch(r'area_(AM_P|AM_S)_(AM_P|AM_S)', b).groups())]
        amn, aat = num('am_am_n_contacts', '⑦A3'), num('am_am_total_area', '⑦A3')
        aam = _wa_val(case, wn, 'am_am_mean_area', '⑦A3')
        s_n = sum(num(b + '_n', '⑦A3') for b in bases)
        s_t = sum(num(b + '_total', '⑦A3') for b in bases)
        if amn != s_n:
            raise FillRefusal(f'{case}: am_am_n_contacts {amn:g} ≠ AM–AM 쌍 개수 합 {s_n:g} — 같은 접촉 집합의 값이 아니다 (관문 ⑦A3 · J20-j · RGL-05)')
        if not abs(aat - s_t) <= WA_AREA_TOL * max(abs(aat), abs(s_t), 1e-300):
            raise FillRefusal(f'{case}: am_am_total_area {aat!r} ≠ AM–AM 쌍 총합 {s_t!r} (관문 ⑦A3 · J20-s)')
        if amn > 0:
            e_m = aat / amn
            if aam is None or not abs(aam - e_m) <= WA_AREA_TOL * max(abs(aam), abs(e_m), 1e-300):
                raise FillRefusal(f'{case}: am_am_mean_area {aam!r} ≠ am_am_total_area / am_am_n_contacts = {e_m!r} (관문 ⑦A3 · J20-s)')
    if 'se_se_cn_eff_area' in take:                                       # A4
        ea = _wa_val(case, wn, 'se_se_cn_eff_area', '⑦A4',
                     need='⑦ 면적 묶음의 SE 면적 피복 (calc_se_se_cn 은 늘 쓴다) — 근거 없이 A4 를 건너뛰지 않는다')
        rse = _wa_num(case, '설계 r_SE_um', drow.get('r_SE_um'), '⑦A4', 'pos', need='eff_area 식의 원천 근거 (SE 단분산 반경 · 설계 d_se 하나)')
        pc = h.get('phase_counts')
        if not isinstance(pc, dict):
            raise FillRefusal(f'{case}: 수확 JSON 에 phase_counts 가 없다 — SE 입자 수를 몰라 eff_area 식을 잴 수 없다 (관문 ⑦A4 필수 · RGL-05)')
        n_se = _phase_n(pc, 'SE')
        sst = _wa_val(case, wn, 'area_SE_SE_total', '⑦A4', need='eff_area 식의 원천 근거 (SE–SE 접촉 면적 총합)')
        e_a = 2.0 * sst / (n_se * 4.0 * math.pi * rse * rse) if n_se > 0 else float('nan')
        if not (n_se > 0 and abs(ea - e_a) <= WA_AREA_TOL * max(abs(e_a), 1e-300)):
            raise FillRefusal(f'{case}: se_se_cn_eff_area {ea!r} ≠ 2 × area_SE_SE_total / (N_SE {n_se} · 4π r_SE²) = {e_a!r} '
                              '(관문 ⑦A4 · J20-s · SE 단분산 = 설계 d_se 하나)')
    if 'se_se_cn_eff_area_perc' in take:                                  # A5
        pp = _wa_val(case, wn, 'percolation_pct', '⑦A5',
                     need='eff_area_perc 빈칸 ⟺ 비관통 의 원천 근거 (SE 관통 비율) — 근거 없이 A5 를 건너뛰지 않는다')
        eap = _wa_val(case, wn, 'se_se_cn_eff_area_perc', '⑦A5')
        if pp > 0.0 and eap is None:
            raise FillRefusal(f'{case}: 관통 침대 (percolation_pct {pp!r}) 인데 se_se_cn_eff_area_perc 가 빈칸 — 빈칸 ⟺ 비관통이어야 한다 '
                              '(관문 ⑦A5 필수 · J20-s)')
        if pp == 0.0 and eap is not None:
            raise FillRefusal(f'{case}: 비관통 침대 (percolation_pct 0) 인데 se_se_cn_eff_area_perc {eap!r} 이 있다 — 빈칸 ⟺ 비관통이어야 한다 '
                              '(관문 ⑦A5 · J20-s)')
    return 1


def _wa_s567_final(case, o, take, pair_n, amn=''):
    """RGL-05 — 내보내는 행 (**최종 레코드**) 을 다시 본다: 0 채움 (J20-h) · mono 이름 옮김 · 접촉 0 평균 비움 **뒤** 의 값이 여전히 한 상태인가.
      ⑤⑥⑦ · 원천 근거 열의 값 = 유한 · 형/범위 안 (빈칸 = N/A 는 아래 규칙이 본다)
      쌍 (설계 이름) 마다 — 개수 빈칸 (상 부재 · N/A) 이면 총합 · 평균도 빈칸 · 개수 0 (접촉 0) 이면 총합 0 · 평균 빈칸 ·
      개수 > 0 이면 실린 총합 · 평균에 값 · 평균 × 개수 = 총합.  AM–AM 묶음도 같은 규칙 (개수 = am_am_n_contacts).
    pair_n = {설계 이름 쌍: 그 쌍의 개수 문자열 (표에 실렸으면 표의 값 · 아니면 정규화한 웹앱 원 행의 값)} · amn = am_am_n_contacts (같은 뜻).
    정규화가 맞으면 쏘지 않는 이중 안전장치다 — 반환 1 (검사함) · 어긋나면 FillRefusal ('최종 레코드')."""
    g = '최종 레코드'
    for c in take:
        if wa_s567_kind(c) is not None:
            _wa_val(case, o, c, g)

    def triple(label, n_s, tc, mc):
        t_s = o.get(tc, '') if tc in take else None                      # None = 그 칸은 표에 없다 (볼 것이 없다)
        m_s = o.get(mc, '') if mc in take else None
        n = _wa_num(case, label, n_s, g, 'count')
        t = _wa_num(case, tc, t_s, g, 'nonneg') if t_s is not None else None
        m = _wa_num(case, mc, m_s, g, 'nonneg') if m_s is not None else None
        if n is None:
            if t_s or m_s:
                raise FillRefusal(f'{case}: 최종 레코드 {label} 빈칸 (상 부재 · N/A) 인데 총합 · 평균에 값이 있다 (관문 {g} · RGL-05)')
        elif n == 0:
            if t_s is not None and t != 0.0:
                raise FillRefusal(f'{case}: 최종 레코드 {label} 0 (접촉 0) 인데 {tc} {t_s!r} — 측정된 0 이어야 한다 (관문 {g} · RGL-05)')
            if m_s:
                raise FillRefusal(f'{case}: 최종 레코드 {label} 0 (접촉 0) 인데 {mc} {m_s!r} — 접촉 0 개에서 평균은 정의되지 않는다 (관문 {g} · RGL-05)')
        else:
            if (t_s is not None and t is None) or (m_s is not None and m is None):
                raise FillRefusal(f'{case}: 최종 레코드 {label} {n:g} > 0 인데 실린 총합 · 평균이 비었다 (관문 {g} · RGL-05)')
            if t is not None and m is not None and not abs(m * n - t) <= WA_AREA_TOL * max(abs(t), abs(m * n), 1e-300):
                raise FillRefusal(f'{case}: 최종 레코드 {mc} {m!r} × {label} {n:g} ≠ {tc} {t!r} (관문 {g} · RGL-05)')
    for b, n_s in sorted(pair_n.items()):
        triple(f'{b}_n', n_s, b + '_total', b + '_mean')
    if 'am_am_total_area' in take or 'am_am_mean_area' in take:
        triple('am_am_n_contacts', amn, 'am_am_total_area', 'am_am_mean_area')
    return 1


def _wa_perc_gates(case, o, take, h):
    """② 관문 (fail-closed) — 표에 실린 퍼콜레이션 값이 한 SE 그래프에서 나왔고 수확기가 독립으로 재현하는가.  09-29 J20-b 감사 130/130 CLEAN ·
    10-01 실측 130/130 · 64/64 성립.

      P1 관통 일관: percolation_pct > 0 ⟺ se_se_cn_perc · se_se_cn_n_perc 에 값 ⟺ 수확기 벽 밴드 관통 (`tau_detail.band_detail.wall_n_span_components`
         > 0 · J20-b F8 독립 재현 — SE 단분산이면 두 밴드 규칙이 같은 집합)
      P2 범위 · 순서: 비율 셋 ∈ [0, 100] · 성분 수 정수 ≥ 0 · n_large ≤ n_components · top_reachable ≥ percolation (관통 SE 는 위 밴드에 닿는다)
      P3 관통 SE 개수 = percolation_pct × N_SE / 100 (수확 phase_counts)
    반환 1 (검사함).  어긋나면 `FillRefusal` (메시지에 '② P<n>')."""
    def num(c):
        v = o.get(c, '')
        return None if v in (None, '') else float(v)
    for c in ('percolation_pct', 'top_reachable_pct', 'ionic_active_pct'):             # P2
        if c in take and num(c) is not None and not (0.0 <= num(c) <= 100.0):
            raise FillRefusal(f'{case}: {c} {num(c)!r} ∉ [0, 100] (② P2)')
    for c in ('n_components', 'n_large_components'):
        if c in take and num(c) is not None and (num(c) < 0 or num(c) != int(num(c))):
            raise FillRefusal(f'{case}: {c} {num(c)!r} 이 0 이상 정수가 아니다 (② P2)')
    if 'n_components' in take and 'n_large_components' in take and None not in (num('n_components'), num('n_large_components')) \
            and num('n_large_components') > num('n_components'):
        raise FillRefusal(f'{case}: n_large_components {num("n_large_components")!r} > n_components {num("n_components")!r} (② P2)')
    pp = num('percolation_pct') if 'percolation_pct' in take else None
    if pp is not None and 'top_reachable_pct' in take and num('top_reachable_pct') is not None \
            and num('top_reachable_pct') < pp - WA_CN_IDENTITY_TOL * max(1.0, pp):
        raise FillRefusal(f'{case}: top_reachable_pct {num("top_reachable_pct")!r} < percolation_pct {pp!r} — 관통 SE 는 위 밴드에 닿는다 (② P2)')
    if pp is None:
        return 1
    perc = pp > 0.0
    for c in ('se_se_cn_perc', 'se_se_cn_n_perc'):                                      # P1
        if c in take and (num(c) is not None) != perc:
            raise FillRefusal(f'{case}: percolation_pct {pp!r} 인데 {c} = {o.get(c)!r} — 관통 여부와 값 유무가 어긋난다 (② P1)')
    span = _dig(h, ('tau_detail', 'band_detail', 'wall_n_span_components'))
    if span is None:
        raise FillRefusal(f'{case}: 수확 JSON 에 tau_detail.band_detail.wall_n_span_components 가 없다 — 관통을 독립으로 재현할 수 없다 (② P1)')
    if (int(span) > 0) != perc:
        raise FillRefusal(f'{case}: 웹앱 percolation_pct {pp!r} ↔ 수확기 벽 밴드 관통 성분 {span} — 독립 재현이 어긋난다 (② P1 · J20-b F8)')
    if 'se_se_cn_n_perc' in take and perc:                                               # P3
        pc = h.get('phase_counts')
        if not isinstance(pc, dict):
            raise FillRefusal(f'{case}: 수확 JSON 에 phase_counts 가 없다 — 관통 SE 개수를 확인할 수 없다 (② P3)')
        exp3 = pp * _phase_n(pc, 'SE') / 100.0
        if abs(num('se_se_cn_n_perc') - exp3) > WA_COUNT_INT_TOL:
            raise FillRefusal(f'{case}: se_se_cn_n_perc {num("se_se_cn_n_perc")!r} ≠ percolation_pct × N_SE / 100 = {exp3!r} (② P3)')
    return 1


def _se_iso_gates(case, o):
    """v1.3 고립 전해질 관문 (fail-closed) — 표에 실린 se_isolated_pct 가 같은 행의 top_reachable_pct · percolation_pct 와 한 SE 그래프의 값인가.

      S1 = 100 − top_reachable_pct (부동소수 여유 WA_PCT_SUM_TOL) · 값이 빈칸이면 top_reachable_pct 도 빈칸이어야
      S2 ≤ 100 − percolation_pct (관통 SE 는 위 띠에 닿는다 — ② P2 의 top ≥ percolation 과 같은 사실의 이중 안전장치) · 유한 [0, 100]
    반환 1 (검사함) · 0 (두 칸 다 빈칸 — 배치가 이 행의 웹앱 값을 싣지 않았다).  어긋나면 `FillRefusal` (메시지에 'v1.3 S<n>')."""
    def num(c):
        v = o.get(c, '')
        if v in (None, ''):
            return None
        try:
            x = float(v)
        except (TypeError, ValueError):
            raise FillRefusal(f'{case}: {c} = {v!r} 가 숫자가 아니다 (v1.3 S1)')
        if not math.isfinite(x):
            raise FillRefusal(f'{case}: {c} = {v!r} 가 유한하지 않다 (v1.3 S1)')
        return x
    iso, top, perc = num('se_isolated_pct'), num('top_reachable_pct'), num('percolation_pct')
    if iso is None and top is None:
        return 0
    if iso is None or top is None or abs(iso - (100.0 - top)) > WA_PCT_SUM_TOL:
        raise FillRefusal(f'{case}: se_isolated_pct {o.get("se_isolated_pct")!r} ≠ 100 − top_reachable_pct {o.get("top_reachable_pct")!r} — '
                          '같은 SE 그래프의 값이 아니다 (v1.3 S1)')
    if not 0.0 <= iso <= 100.0:
        raise FillRefusal(f'{case}: se_isolated_pct {iso!r} ∉ [0, 100] (v1.3 S2)')
    if perc is not None and iso > 100.0 - perc + WA_PCT_SUM_TOL:
        raise FillRefusal(f'{case}: se_isolated_pct {iso!r} > 100 − percolation_pct {perc!r} — 관통 SE 가 위 띠에 안 닿는다는 뜻이다 (v1.3 S2)')
    return 1


def _wa_ionic_gates(case, o, take, h, dp):
    """v1.1 ①② 관문 (fail-closed) — 이온 활성 · 경로 기준 고립 · 분해가 calc_ionic_active_am 의 **세 집합 하나**에서 나왔는가.

      상 있음/없음 — 상 (수확 phase_counts · mono 는 설계 상) 이 있으면 실린 상별 분해 열은 값이 있어야 · 없으면 빈칸이어야
      D0 (LREL-01) 각 비율 숫자 · 유한 · [0, 100] · 개수 [0, N] — 합 · 정수 검사는 음수 개수 분할 · NaN 을 통과시켰다
      D1 전체 활성 + 단절 + 무접촉 = 100 · D2 상별 같은 합 = 100
      D3 비율 × 입자 수 / 100 = 정수 개수 (활성은 분해 키가 없는 옛 배치에서도 — ① 의 원천)
      D4 상별 개수 합 = 전체 개수 (활성 · 단절 · 무접촉 각각)
      D5 무접촉 개수 ≤ 고립 위험 개수 (SE 접촉 0 ⊂ 0–1 개 — 7c 와 같은 접촉 집합 · 전체 · 상별)
    반환 1.  어긋나면 `FillRefusal` (메시지에 'v1.1 D<n>' · 'v1.1 상 있음/없음')."""
    pc = h.get('phase_counts')
    if not isinstance(pc, dict):
        raise FillRefusal(f'{case}: 수확 JSON 에 phase_counts 가 없다 — AM 입자 수를 몰라 이온 활성 · 고립 관문을 볼 수 없다 (v1.1 D3)')
    n = {ph: _phase_n_mono(pc, ph, dp) for ph in ('AM_P', 'AM_S')}
    n_am = _phase_n(pc, 'AM전체')
    present = [ph for ph in ('AM_P', 'AM_S') if n[ph] > 0]

    def num(c):
        v = o.get(c, '') if c in take else ''
        if v in (None, ''):
            return None
        try:
            return float(v)
        except (TypeError, ValueError):
            raise FillRefusal(f'{case}: {c} = {v!r} 가 숫자가 아니다 (v1.1 D0)')
    for c in take:                                                    # 상 있음/없음
        m = WA_IONIC_PHASE_RE.fullmatch(c)
        if not m:
            continue
        has = o.get(c, '') not in (None, '')
        if n[m.group(1)] > 0 and not has:
            raise FillRefusal(f'{case}: {m.group(1)} 입자 {n[m.group(1)]} 개인데 {c} 가 빈칸 — 상이 있는데 값이 없다 (v1.1 상 있음)')
        if n[m.group(1)] == 0 and has:
            raise FillRefusal(f'{case}: {m.group(1)} 가 없는 침대인데 {c} = {o[c]} — 다른 침대의 값이다 (v1.1 상 없음)')
    trio = {'전체': [num(f'ionic_{s_}_pct') for s_ in ('active', 'dead', 'no_se')]}
    trio.update({ph: [num(f'{ph}_ionic_{s_}_pct') for s_ in ('active', 'dead', 'no_se')] for ph in present})
    #  ★ D0 (LREL-01 · Codex 배포 v1.1 최종 리뷰 반례 negative_ionic_no_se_counts) — 각 비율이 유한 · [0, 100].  정수 · 합 · 상별 합 (D1–D4) 만으로는
    #    무접촉 −1 개 + 단절 +1 개 분할이 통과했다 (−1 도 정수 · 합은 100) · NaN 은 합 검사를 그대로 지났다 (비교가 거짓).  개수 [0, N] 은 D3 뒤에서.
    for lab, vals in trio.items():
        for s_, v in zip(('active', 'dead', 'no_se'), vals):
            if v is not None and not (math.isfinite(v) and 0.0 <= v <= 100.0):
                raise FillRefusal(f'{case}: {lab} {s_} 비율 {v!r} 이 유한 [0, 100] 밖이다 — 집합 분할의 비율이 아니다 (v1.1 D0 · LREL-01)')
    if None not in trio['전체'] and abs(sum(trio['전체']) - 100.0) > WA_PCT_SUM_TOL:        # D1
        raise FillRefusal(f'{case}: 활성 + 단절 + 무접촉 = {sum(trio["전체"])!r} ≠ 100 — 같은 세 집합이 아니다 (v1.1 D1)')
    for ph in present:                                                # D2
        if None not in trio[ph] and abs(sum(trio[ph]) - 100.0) > WA_PCT_SUM_TOL:
            raise FillRefusal(f'{case}: {ph} 활성 + 단절 + 무접촉 = {sum(trio[ph])!r} ≠ 100 (v1.1 D2)')
    cnt = {}
    for lab, N in [('전체', n_am)] + [(ph, n[ph]) for ph in present]:  # D3
        for s_, v in zip(('active', 'dead', 'no_se'), trio[lab]):
            if v is None:
                continue
            x = v * N / 100.0
            if abs(x - round(x)) > WA_COUNT_INT_TOL:
                raise FillRefusal(f'{case}: {lab} {s_} 비율 {v!r} × 입자 수 {N} / 100 = {x!r} 이 정수 개수가 아니다 (v1.1 D3)')
            cnt[(lab, s_)] = round(x)
            if not 0 <= cnt[(lab, s_)] <= N:                               # D0 (LREL-01) — 개수 [0, N] (비율 범위의 개수 쪽 · 이중 안전장치)
                raise FillRefusal(f'{case}: {lab} {s_} 개수 {cnt[(lab, s_)]} ∉ [0, {N}] (v1.1 D0 · LREL-01)')
    for s_ in ('active', 'dead', 'no_se'):                             # D4
        if present and ('전체', s_) in cnt and all((ph, s_) in cnt for ph in present) \
                and cnt[('전체', s_)] != sum(cnt[(ph, s_)] for ph in present):
            raise FillRefusal(f'{case}: {s_} 개수 전체 {cnt[("전체", s_)]} ≠ 상별 합 {sum(cnt[(ph, s_)] for ph in present)} (v1.1 D4)')
    for lab, vcol, N in [('전체', 'am_vulnerable_pct', n_am)] + [(ph, f'{ph}_vulnerable_pct', n[ph]) for ph in present]:   # D5
        vv = num(vcol)
        if (lab, 'no_se') in cnt and vv is not None and cnt[(lab, 'no_se')] > round(vv * N / 100.0):
            raise FillRefusal(f'{case}: {lab} 무접촉 {cnt[(lab, "no_se")]} 개 > 고립 위험 {round(vv * N / 100.0)} 개 — SE 접촉 0 은 0–1 개의 '
                              '부분집합이다 (v1.1 D5)')
    return 1


def build_handover(rows, harvest, key='case_id', union=None, webapp=None, webapp_groups=None, wa_reviewed_only=True, tau=None, pressure=None):
    """설계행 + 수확 (+ union) (+ 웹앱) (+ 망 τ) → 인계용 행 리스트.  **순수 함수**(파일을 안 쓴다) 라 시험 가능하다.

    union (J19, 선택): `load_union` 산출 dict 또는 행 목록.  주면 설계 케이스 **전부**에 짝이 있어야 하고 (부분 병기 금지),
    짝마다 구 부피 합 porosity · 두께 · 상별 입자 수가 수확과 같아야 한다 (`_union_cols`).  설계에 없는 union 행 (코호트의 perc 등) 은
    인계표에 넣지 않고 report['union_extra'] 에 남긴다.
    벽 τ (J20): 수확 JSON 에 `tau_wall_detail` 이 **전부** 있으면 새 열로 싣는다 (일부만 있으면 수확 세대 혼합 → 거부).
    webapp (J20, 선택): `load_webapp` 산출.  설계행 **전부**를 배치가 시도했어야 하고, done · partial 행은 웹앱 porosity = 수확 porosity
    (WA_SAME_FRAME_TOL_PCT) 여야 한다.  ✅ 열만 · 이름 충돌이면 기존 열이 정본 (report['wa_collisions']).  거부 · 실패 행은 빈칸 + wa_status.
    tau (v1.2 망 τ 묶음, 선택): `load_tau_results` 산출.  webapp_groups 에 'tau' 가 있을 때만 받는다 (둘 중 하나만이면 거부) · network 정지 배치만 ·
    배치 done · partial 케이스 집합 = τ 원천 케이스 집합 · run id 같아야 · 케이스마다 같은 세대 검사 (P0–P4 · 10-05 RGLR3-02) 를 다 통과한 기록.
    τ 열 (tau_flux.column_names()) 은 표 **끝**에 붙는다 — 묶음을 안 부르면
    표 · 열 사전은 옛 그대로 (selftest ㉙f).  done · partial 이 아닌 행은 τ 칸 전부 빈칸 (wa_status 가 사유).
    pressure (DESC-06, 선택): `load_pressure_record` 산출.  주면 설계 케이스마다 기록이 OK · reached True · 목표 300 · 덱 sha = 수확 raw.deck 이어야 하고
    press_* 열 (HANDOVER_PRESS) 이 표 **끝**에 붙는다.  CLI 는 --pressure-record 또는 --pressure-unverified (명시 승인) 를 요구한다.
    webapp 행 (done · partial) 은 배치 status 의 원자료 sha 넷 (atom · contact · mesh · deck) = 수확 raw sha 여야 한다 (DESC-06 — 최종 join).
    반환 (out_rows, cols, report).  계약 위반이면 `FillRefusal`.
    """
    #  ⚠ `load_harvest` 는 **dict(case → h)** 를 준다.  초판은 list 만 받아서
    #    selftest(list) 는 통과하는데 프로덕션(dict)에서 죽었다 — 시험이 프로덕션
    #    모양을 안 쓰면 그 자리가 곧 사각지대다 (규율 ⑤).  둘 다 받는다.
    hv = dict(harvest) if isinstance(harvest, dict) else {h['case']: h for h in harvest}
    #  ★ LREL-03 (Codex 배포 v1.1 최종 리뷰 반례 design_row_duplicate) — "130 행" 이 "130 개 고유 설계" 를 보증하게: 설계행 case_id 는 비지 않고
    #    유일해야 한다.  옛 판은 두 번째 행을 첫 행으로 바꾼 설계 (행 수 그대로 · 고유 129) 를 그대로 실었다 (lhs00_001 이 사라지고 lhs00_000 이 둘).
    _ids = [str(r.get(key) or '') for r in rows]
    _dup = sorted({i for i in _ids if _ids.count(i) > 1})
    if '' in _ids or _dup:
        raise FillRefusal(f'설계행 {key} 가 비었거나 중복이다 — 빈 ID {_ids.count("")} 건 · 중복 {_dup[:5]} — 행 수가 고유 설계 수를 보증하지 않는다 (LREL-03)')
    miss = [r[key] for r in rows if r[key] not in hv]
    if miss:
        raise FillRefusal(f'수확에 없는 설계행 {len(miss)} 건: {miss[:5]} — 부분 인계는 금지 (DESC-09)')
    #  ★ LREL-02 — 적격성 표지 (handover_qc) 는 전부 있거나 (0925 판 이후 수확) 전부 없어야 (옛 수확 · 시험 전용) 한다 — 한 표에 섞으면 빈칸 표지 행이 생긴다
    _qc_has = [isinstance(hv[r[key]].get('handover_qc'), dict) for r in rows]
    if any(_qc_has) and not all(_qc_has):
        _no = [r[key] for r, h_ in zip(rows, _qc_has) if not h_]
        raise FillRefusal(f'적격성 표지 (handover_qc) 가 {sum(_qc_has)}/{len(rows)} 수확에만 있다 — 수확 세대가 섞였다 (없는 행 {_no[:5]}) · '
                          '표지가 빈칸인 행을 만들지 않는다 (LREL-02)')
    elig_on = bool(_qc_has) and all(_qc_has)
    design_cols = [c for c in rows[0]
                   if c not in HANDOVER_VALUE_COLS
                   and c not in HANDOVER_HELD_BACK
                   and not c.endswith('_status')]
    cols = list(design_cols)
    for c in HANDOVER_VALUE_COLS:
        cols += [c, c + '_status']
    cols += [n for n, _p, _w in HANDOVER_EXTRA]
    uv = None
    if union is not None:
        uv = dict(union) if isinstance(union, dict) else {u['case']: u for u in union}
        miss_u = [r[key] for r in rows if r[key] not in uv]
        if miss_u:
            raise FillRefusal(f'union 에 없는 설계행 {len(miss_u)} 건: {miss_u[:5]} — 부분 병기 금지 (J19)')
        cols += [n for n, _c, _w in HANDOVER_UNION] + [n for n, _w in HANDOVER_UNION_DERIVED]
    #  J20 — 벽 τ: 전부 있거나 전부 없어야 한다 (한 표에 수확 세대 둘을 섞지 않는다)
    _tw_has = [('tau_wall_detail' in hv[r[key]]) for r in rows]
    if any(_tw_has) and not all(_tw_has):
        _no = [r[key] for r, h_ in zip(rows, _tw_has) if not h_]
        raise FillRefusal(f'벽 τ (tau_wall_detail) 가 {sum(_tw_has)}/{len(rows)} 수확에만 있다 — 수확 세대가 섞였다 (없는 행 {_no[:5]})')
    tw_on = bool(_tw_has) and all(_tw_has)
    if tw_on:
        cols += [n for n, _k, _w in HANDOVER_TAU_WALL]
    #  J20-a ⓓ — 상별 벽 접촉 비율: 전부 있거나 전부 없어야 한다 (수확 세대 혼합 금지)
    _wt_has = [('wall_touch' in hv[r[key]]) for r in rows]
    if any(_wt_has) and not all(_wt_has):
        _no = [r[key] for r, h_ in zip(rows, _wt_has) if not h_]
        raise FillRefusal(f'벽 접촉 비율 (wall_touch) 이 {sum(_wt_has)}/{len(rows)} 수확에만 있다 — 수확 세대가 섞였다 (없는 행 {_no[:5]})')
    wt_on = bool(_wt_has) and all(_wt_has)
    if wt_on:
        cols += [n for n, _p, _s, _w in HANDOVER_WALL_TOUCH]
    #  v1.1 ③ — 가장 큰 SE 덩어리: 전부 있거나 전부 없어야 한다 (키 유무 = 수확 세대 · 값이 None 이면 관문 C1 이 거부)
    _sc_has = [('largest_comp_frac' in (_dig(hv[r[key]], ('tau_detail', 'band_detail')) or {})) for r in rows]
    if any(_sc_has) and not all(_sc_has):
        _no = [r[key] for r, h_ in zip(rows, _sc_has) if not h_]
        raise FillRefusal(f'가장 큰 SE 덩어리 기록 (largest_comp_*) 이 {sum(_sc_has)}/{len(rows)} 수확에만 있다 — 수확 세대가 섞였다 (없는 행 {_no[:5]})')
    sc_on = bool(_sc_has) and all(_sc_has)
    if sc_on:
        cols += [n for n, _w in HANDOVER_SE_CLUSTER]
    wv, wa_take = webapp, []
    _gs = wa_groups_norm(webapp_groups)
    if _gs is not None and (not _gs or any(g not in WA_ALL_GROUPS for g in _gs)):
        raise FillRefusal(f'webapp_groups {webapp_groups!r} — 아는 묶음은 {WA_ALL_GROUPS} 뿐이다 (① 접촉 위상 = contact · ② = percolation · '
                          f'⑤ F1 = f1 · ⑥ Auerbach 힘 기반 = fracture · ⑦ 면적 = area · 망 τ = tau (network 배치 + --tau-results) · '
                          f'고립 전해질 (② 에서 유도 · v1.3) = se_isolation)')
    tau_on = _gs is not None and WA_TAU_GROUP in _gs
    se_iso_on = _gs is not None and WA_SE_ISO_GROUP in _gs                # ★ v1.3 유도 묶음 (명시 opt-in)
    if se_iso_on and ('percolation' not in _gs or webapp is None):
        raise FillRefusal(f'webapp_groups {webapp_groups!r} — se_isolation 묶음은 percolation 묶음과 함께만 부른다 (고립 전해질 = 100 − top_reachable_pct · '
                          'top_reachable_pct 를 싣지 않는 표에서 유도하지 않는다 · 웹앱 배치 --webapp 필요) (v1.3 S0)')
    if tau is not None and not tau_on:
        raise FillRefusal(f'τ 묶음 — 망 τ 원천 (--tau-results) 을 줬는데 webapp_groups={webapp_groups!r} 에 tau 가 없다 — 조용히 버리지 않는다 '
                          '(…,tau 로 부를 것)')
    if wv is not None:
        #  묶음별 — 접촉 단계만 돈 배치는 그 묶음으로만 부른다 (뒤 단계 열이 빈칸 = 측정된 N/A 로 읽히지 않게)
        _sa = wv.get('stop_after')
        if _sa:
            #  RGL-03 — 단계 역량 (WA_STAGE_GROUPS) 을 모르는 정지점은 거부한다.  옛 판은 모르는 이름을 그대로 묶음 목록으로 써서
            #   "--webapp-groups network 의 부분집합" 처럼 유효 묶음도 아닌 이름을 요구했다.
            _cap = WA_STAGE_GROUPS.get(_sa)
            if _cap is None:
                raise FillRefusal(f'웹앱 배치 stop_after={_sa!r} — 생성기가 단계 역량을 모르는 정지점이다 (아는 정지점: '
                                  f'{", ".join(WA_STAGE_GROUPS)}) — 그 단계가 어떤 묶음을 다 내는지 WA_STAGE_GROUPS 에 적은 뒤에만 싣는다 (RGL-03)')
            if _gs is None or any(g not in _cap for g in _gs if g not in WA_DERIVED_GROUPS):     # 유도 묶음 (v1.3) 은 단계 역량 표 밖
                raise FillRefusal(f'웹앱 배치가 stop_after={_sa!r} 로 돌았다 — webapp_groups={webapp_groups!r} 로는 싣지 않는다 '
                                  f'(그 단계가 다 낸 묶음만: --webapp-groups 에 {", ".join(_cap)} 중에서 쉼표로 고른다 · 묶음 제한이 없으면 뒤 단계 열이 '
                                  '빈칸 = 측정된 N/A 로 읽힌다 · RGL-03)')
        miss_w = [r[key] for r in rows if r[key] not in (wv.get('status') or {})]
        if miss_w:
            raise FillRefusal(f'웹앱 배치가 시도하지 않은 설계행 {len(miss_w)} 건: {miss_w[:5]} — 배치 미완 (재개로 채울 것)')
        ok_cols = [c for c, v in wa_verdicts(wv)[0].items() if str(v).startswith('✅')]     # 7c — 판정 바꿔 싣기 포함
        _n_excl = sum(1 for c in ok_cols if wa_excluded(c) is not None)       # ⑤⑥⑦ — 인계 제외 열은 묶음 · 검토와 무관하게 먼저 (J20-s)
        ok_cols = [c for c in ok_cols if wa_excluded(c) is None]
        if _gs is not None:                         # 망 τ 묶음은 census 열이 아니다 (별도 원천) — census 거르기에서 뺀다
            ok_cols = [c for c in ok_cols if any(WA_GROUP_FN[g](c) for g in _gs if g in WA_GROUP_FN)]
        n_census_ok = len(ok_cols)
        if wa_reviewed_only:                        # J20-g — 같이 확인한 열만 (CLI 는 항상 이 경로 · False 는 옛 기제 시험 전용)
            ok_cols = [c for c in ok_cols if wa_reviewed(c)]
        have = set(cols)
        wa_take = [c for c in ok_cols if c not in have and c not in {n for n, _w in WA_ROW_COLS}]
        wa_coll = [c for c in ok_cols if c in have]
        wa_iso_on = 'ionic_active_pct' in wa_take                   # v1.1 ① — 활성 열이 실리면 경로 기준 고립 (유도) 도 싣는다
        if se_iso_on and 'top_reachable_pct' not in wa_take:         # ★ v1.3 S0 — 묶음은 불렀는데 위 밴드 도달 열이 표에 없다 (검토 · census 판정에서 빠졌다)
            raise FillRefusal('se_isolation 묶음은 percolation 묶음과 함께만 부른다 — 이 배치의 웹앱 열에 top_reachable_pct 가 실리지 않았다 '
                              '(유도할 원천이 없다) (v1.3 S0)')
        cols += ([n for n, _w in WA_ROW_COLS] + wa_take + ([n for n, _w in WA_DERIVED] if wa_iso_on else [])
                 + ([n for n, _w in WA_DERIVED_SE_ISO] if se_iso_on else []) + [n for n, _a, _b, _w in WA_QC])
    #  ★ v1.2 망 τ 묶음 — 원천 (`load_tau_results`) 이 이 배치로 읽혔는가 (정지점 · 케이스 집합 · run id · 같은 세대 검사 P0–P4) · τ 열은 표 끝 (옛 열 순서 불변)
    tau_cols = []
    if tau_on:
        if wv is None or tau is None:
            raise FillRefusal('τ 묶음 — webapp_groups 에 tau 가 있는데 ' + ('웹앱 배치 (--webapp) 가 없다' if wv is None else
                              '망 τ 원천이 없다 (CLI --tau-results <배치 --work>/results)') + ' — 빈 τ 열을 측정된 N/A 로 내보내지 않는다')
        if wv.get('stop_after') != 'network':
            raise FillRefusal(f'τ 정지점 — 웹앱 배치 stop_after={wv.get("stop_after")!r} ≠ network — 망 τ 는 network 정지 배치 (케이스 기록에 '
                              'network_run_id · 망 정지 계약) 에서만 싣는다')
        _sch = tau.get('schema') if isinstance(tau, dict) else type(tau).__name__
        if _sch != TAU_NET_SCHEMA or not isinstance(tau.get('cases'), dict):
            raise FillRefusal(f'τ 묶음 — 망 τ 원천 schema {_sch!r} ≠ {TAU_NET_SCHEMA} (load_tau_results 산출이어야)')
        tau_cols = list(tau.get('columns') or [])
        _und = [c for c in tau_cols if tau_net_define(c) is None]
        if not tau_cols or _und:
            raise FillRefusal(f'τ 묶음 — 열 사전 정의가 없는 τ 열 {_und[:5]} (tau_flux 가 열을 바꿨다 — tau_net_define 을 먼저 고칠 것)')
        _have = set(cols)
        _clash = [c for c in tau_cols if c in _have]
        if _clash:
            raise FillRefusal(f'τ 묶음 — τ 열 이름이 표의 다른 열과 겹친다 {_clash[:5]} — 어느 쪽이 정본인지 모른다')
        _okc = {c for c, r_ in (wv.get('status') or {}).items() if (r_ or {}).get('status') in WA_OK_STATUS}
        _tcs = set(tau['cases'])
        if _tcs != _okc:
            raise FillRefusal(f'τ 케이스 집합 불일치 — τ 원천에만 {sorted(_tcs - _okc)[:5]} · 배치 done · partial 에만 {sorted(_okc - _tcs)[:5]} — '
                              '이 배치로 읽은 원천이 아니다 (load_tau_results 를 같은 배치로)')
        for c in sorted(_okc):
            if (tau['cases'][c] or {}).get('network_run_id') != (wv['status'][c] or {}).get('network_run_id'):
                raise FillRefusal(f'{c}: τ P1 — τ 기록의 network_run_id {(tau["cases"][c] or {}).get("network_run_id")!r} ≠ 배치 기록 '
                                  f'{(wv["status"][c] or {}).get("network_run_id")!r} — 다른 배치로 읽은 τ 원천이다')
            #  ★ 10-05 RGLR3-02 — 인계 때 같은 세대 검사 (P0–P4 · 망 정지 계약 재검사 포함) 를 다 통과한 기록만 싣는다 (검사가 안 돈 τ 를 "검증 통과" 행으로 싣지 않는다)
            _sg = list((tau['cases'][c] or {}).get('same_generation_checks') or [])
            if _sg != list(TAU_SAME_GEN_CHECKS):
                raise FillRefusal(f'{c}: τ P4 — τ 기록의 같은 세대 검사 {_sg} ≠ {list(TAU_SAME_GEN_CHECKS)} — 인계 때 검사 (P0–P4) 를 다 통과한 원천이 아니다 '
                                  '(load_tau_results 로 다시 읽을 것)')
        #  ★ 10-06 저녁 세대 2 — 한 인계표에 망 세대 (ψ 배치 · physics 면적 규칙 · 전극) 가 다른 행을 섞지 않는다 (원천이 다른 길로 들어와도 여기서 한 번 더)
        #    ★ 10-06 밤 (G2R-01 · 02) — 행마다 세대 계약 먼저 (tau_flux.row_generation_problems — 같은 결함만 모인 원천도 거부)
        _tf_g, _ = _tau_import()
        _mix = _tf_g.generation_mixing_problem([dict((tau['cases'][c] or {}).get('cells') or {}, case=c) for c in sorted(_okc)])
        if _mix:
            raise FillRefusal(f'τ 세대 — {_mix} — 같은 세대 배치끼리 인계한다 (10-06 세대 2 · 1저자 비준)')
        cols += tau_cols
    if pressure is not None:                                          # DESC-06 — 완료 압력 기록 (표 끝 · 옛 열 순서 불변)
        if not isinstance(pressure, dict):
            raise FillRefusal('압력 기록은 load_pressure_record 산출 (dict case → 행) 이어야 한다 (DESC-06)')
        cols += [n for n, _k, _w in HANDOVER_PRESS]
    out, rep = [], {'n': 0, 'blank_by_status': collections.Counter(),
                    'held_back': dict(HANDOVER_HELD_BACK), 'mono_rows': 0, 'mono_harvest_filled': 0,
                    'eligibility_checked': 0, 'eligibility_on': elig_on, 'desc07_cov_checked': 0}
    if uv is not None:
        rep['union_extra'] = sorted(set(uv) - {r[key] for r in rows})
        rep['se_share_checked'] = 0
    if tw_on:
        rep['tau_wall_status'] = collections.Counter()
        rep['tau_wall_checked'] = rep['tau_perc_crosschecked'] = 0
    if sc_on:
        rep['se_cluster_checked'] = 0
    if wv is not None:
        rep.update(wa_collisions=wa_coll, wa_n_cols=len(wa_take), wa_status_counts=collections.Counter(),
                   wa_porosity_absmax=0.0, wa_reviewed_only=bool(wa_reviewed_only),
                   wa_unreviewed_dropped=n_census_ok - len(ok_cols), wa_pair_zero_filled=0,
                   wa_mono_renamed_cases=0, wa_mono_design_filled=0, wa_mono_absent_blanked=0,
                   wa_cn_identity_checked=0, wa_am_identity_checked=0, wa_amse_identity_checked=0, wa_perc_checked=0,
                   wa_ionic_checked=0, wa_f1_checked=0, wa_frac_checked=0, wa_area_checked=0, wa_s567_final_checked=0,
                   wa_area_mean_blanked=0, wa_area_total_zero_filled=0, wa_excluded_dropped=_n_excl, wa_raw_sha_checked=0,
                   wa_se_iso_checked=0)
    if tau_on:
        rep.update(tau_checked=0, tau_blank_rows=0, tau_status=collections.Counter(), tau_source=tau.get('source'),
                   tau_flux_sha256=tau.get('tau_flux_sha256'))
    rep['pressure_checked'] = 0
    rep['pressure_on'] = pressure is not None
    for r in rows:
        h = hv[r[key]]
        o = {c: r.get(c, '') for c in design_cols}
        #  J20-k (B) — mono 침대의 설계 상 (block) · 설계에 없는 상.  설계 ↔ 수확 모양이 어긋나면 여기서 거부된다.
        dp, op = _mono_design_phase(r, h, r[key])
        if dp is not None:
            rep['mono_rows'] += 1
        for c in HANDOVER_VALUE_COLS:
            #  (B) — mono 의 설계 상 칸 ← 전체 (단일 AM = 전체 · coverage_AM_only = coverage_AM_total 을 위에서 확인했다)
            src = 'coverage_AM_total_hertz_pct' if (dp is not None and c == f'coverage_{dp}_hertz_pct') else c
            st = h['status'][DESCRIPTOR_STATUS_KEY[src]]
            v = h.get(src)
            #  계약 ② — OK 가 아니면 값 칸은 **비운다** (0 이 아니다)
            o[c] = repr(float(v)) if (st == 'OK' and v is not None) else ''
            o[c + '_status'] = st
            if st != 'OK':
                rep['blank_by_status'][st] += 1
            elif src != c:
                rep['mono_harvest_filled'] += 1
        for name, path, _why in HANDOVER_EXTRA:
            p = _mono_path(path, dp, op) if dp is not None else path   # (B) — 설계 상 키 → 수확 `AM` · 없는 상 → 빈칸
            v = None if p is None else _dig(h, p)
            o[name] = '' if v is None else str(v)
            if v is not None and p != path:
                rep['mono_harvest_filled'] += 1
        #  계약 ③ — DESC-07 항등식을 **내보내는 표 위에서 다시** 잰다
        e1 = abs(float(h['porosity_sphere_pct_RECORD_ONLY'])
                 - 100.0 * (1.0 - float(h['phi_se']) - float(h['phi_am'])))
        if e1 > DESC07_TOL['porosity']:
            raise FillRefusal(f"{r[key]}: DESC-07 항등식 위반 {e1:.3e}")
        #  ★ DESC-07 ② (Codex 배포 v1.1 최종 리뷰 coverage_total_plus_1) — 전체 피복 = 피복 유효 입자 수 가중평균 을 **내보내는 표 위에서도** 잰다
        #    (옛 판은 fill_descriptors 에서만 재고 인계표에서는 안 재 전체만 +1 %p 바꿔도 통과했다 · mono 는 _mono_design_phase 가 AM_only = 전체 를 본다)
        if all(h.get(c_) is not None for c_ in ('coverage_AM_P_hertz_pct', 'coverage_AM_S_hertz_pct', 'coverage_AM_total_hertz_pct')):
            try:
                _e2 = _desc07_check(h)[1]
            except (KeyError, TypeError, ValueError) as e:
                raise FillRefusal(f'{r[key]}: DESC-07 ② — 상별 피복이 둘 다 있는데 피복 유효 입자 수 (coverage_detail.counts) 를 못 읽었다 '
                                  f'({type(e).__name__}) — 전체 피복의 가중평균을 확인할 수 없다')
            if _e2 is not None and _e2 > DESC07_TOL['coverage_total']:
                raise FillRefusal(f'{r[key]}: DESC-07 ② 가중평균 항등식 위반 {_e2:.3e} — coverage_AM_total 이 (N_P C_P + N_S C_S)/(N_P + N_S) 가 아니다')
            rep['desc07_cov_checked'] += 1
        if elig_on:                                                   # ★ LREL-02 — 적격성 표지가 다 있고 수확기 규칙대로 정합한가
            _ep = eligibility_problems(h['handover_qc'], porosity_pct=h.get('porosity_sphere_pct_RECORD_ONLY'))
            if _ep:
                raise FillRefusal(f'{r[key]}: 적격성 표지 — ' + ' · '.join(_ep[:4]) + ' (LREL-02)')
            rep['eligibility_checked'] += 1
        if uv is not None:
            o.update(_union_cols(r[key], h, uv[r[key]]))
            rep['se_share_checked'] += 1                              # LREL-04 — _union_cols 가 SE/고체 를 수확에서 다시 쟀다
        if tw_on:
            t = h['tau_wall_detail']
            if t.get('tau_convention') != TAU_WALL_CONVENTION:
                raise FillRefusal(f'{r[key]}: 벽 τ 규약 {t.get("tau_convention")!r} ≠ {TAU_WALL_CONVENTION} — 다른 규약의 값을 같은 열에 넣지 않는다')
            for name, k, _w in HANDOVER_TAU_WALL:
                v = t.get(k)
                if name in TAU_WALL_VALUE:        # 계약 ② — OK 가 아니면 값 칸은 빈칸
                    o[name] = repr(float(v)) if (t.get('status') == 'OK' and v is not None) else ''
                else:
                    o[name] = '' if v is None else str(v)
            rep['tau_wall_status'][t.get('status')] += 1
            rep['tau_wall_checked'] += _tau_wall_gates(r[key], t, h)          # T1 · T2
        if wt_on:
            wt = h.get('wall_touch') or {}
            for name, ph, side, _w in HANDOVER_WALL_TOUCH:
                #  J20-k (B) — mono: 설계 상 칸 ← 수확 `AM` · 설계에 없는 상 → 빈칸 · AM · SE 열은 그대로
                src_ph = ('AM' if ph == dp else (None if ph == op else ph)) if dp is not None else ph
                v = None if src_ph is None else (wt.get(src_ph) or {}).get(side)
                o[name] = '' if v is None else repr(float(v))          # 없는 상 = 빈칸 (N/A · 0 이 아니다)
                if v is not None and src_ph != ph:
                    rep['mono_harvest_filled'] += 1
        if sc_on:                                                     # v1.1 ③ — C1–C3
            o.update(_se_cluster_cols(r[key], h))
            rep['se_cluster_checked'] += 1
        if wv is not None:
            rec = wv['status'][r[key]] or {}
            s = rec.get('status') or 'UNKNOWN'
            rep['wa_status_counts'][s] += 1
            o['wa_status'] = s
            o['wa_failed_stages'] = '|'.join(str(x) for x in (rec.get('failed_stages') or []))
            if s in WA_OK_STATUS:                                    # ★ DESC-06 — 최종 join: 배치가 읽은 원자료 = 수확이 읽은 원자료 (sha 넷)
                _rs = _wa_raw_sha_problem(rec, h)
                if _rs:
                    raise FillRefusal(f'{r[key]}: 원자료 sha — {_rs} (DESC-06 — 웹앱 열과 수확 열이 같은 침대 · 같은 프레임이어야 한 행에 둔다)')
                rep['wa_raw_sha_checked'] += 1
            wr = (wv.get('rows') or {}).get(r[key]) if s in WA_OK_STATUS else None
            if s in WA_OK_STATUS and wr is None:
                raise FillRefusal(f'{r[key]}: 배치 상태 {s} 인데 metrics_flat 행이 없다')
            #  J20-f 관문 — 상별 열을 실을 때 수확 JSON 에 n_types 가 없으면 거부 (mono 인지 모른다 — 반지름 이름을 그대로 싣지 않는다)
            phase_cols = [c for c in wa_take if wa_phase_specific(c)]
            nt = h.get('n_types')
            if phase_cols and wr is not None and nt is None:
                raise FillRefusal(f'{r[key]}: 수확 JSON 에 n_types 가 없다 — mono 인지 몰라 상별 웹앱 열 {phase_cols[:3]} 을 '
                                  '실을 수 없다 (J20-f · 반지름 이름을 그대로 싣지 않는다)')
            #  J20-k (B) — mono: 웹앱이 단일 AM 에 붙인 반지름 이름을 접촉 열에서 읽는다 (두 이름이 다 있으면 mono 행이 아니다)
            wname = None                                                  # 웹앱이 mono 의 AM 에 붙인 이름 (아래 QC 의 wp = porosity 와 다른 변수)
            o['wa_mono_phase_name_webapp'] = ''
            if dp is not None and wr is not None:
                toks = set()
                for k, v in wr.items():
                    if v not in (None, '') and wa_group_contact(k) and wa_phase_specific(k):
                        toks.update(WA_PHASE_TOKEN.findall(k))
                if len(toks) > 1:
                    raise FillRefusal(f'{r[key]}: 설계 mono ({r.get("block")}) 인데 웹앱 접촉 열에 AM_P · AM_S 두 이름 다 값이 있다 {sorted(toks)} — '
                                      'mono 행이 아니거나 다른 침대의 행이다 (J20-k (B))')
                wname = next(iter(toks)) if toks else None
                o['wa_mono_phase_name_webapp'] = wname or ''
                if wname is not None and wname != dp:
                    rep['wa_mono_renamed_cases'] += 1
            wr0, rn = wr, None                                            # wr0 = 웹앱 원 행 (정규화 전 — J20-h 부분 키 판정 · 0 채움 셈)
            if wr is not None and any(wa_group_area(c) for c in wa_take):
                #  ⑦A1 (+ A3) — RGL-05: 쌍 · AM–AM 의 개수 · 총합 · 평균을 함께 정규화한다 (상 부재 · 접촉 0 · 기술적 결측을 가른다 ·
                #   접촉 0 평균 = N/A · 웹앱 원 행은 안 바꾼다 · J20-s).  옛 판은 값이 있는 개수만 보고 빠진 개수는 검사 뒤 출력에서 0 으로 채웠다.
                pc_ = h.get('phase_counts')
                if not isinstance(pc_, dict):
                    raise FillRefusal(f'{r[key]}: 수확 JSON 에 phase_counts 가 없다 — 쌍마다 상 부재 · 접촉 0 을 가를 수 없어 ⑦ 면적을 실을 수 없다 '
                                      '(관문 ⑦A1 필수 · RGL-05)')
                rn = _wa_raw_phase_n(pc_, dp, wname)
                wr = _wa_area_norm(r[key], wr, rn, rep)
            #  ⑤⑥⑦ (J20-s · RGL-05) — 출력 **전에** 웹앱 원 행 (⑦ 은 정규화한 행) 으로 잰다: 원천 근거 → 유한 → 형/범위 → 식
            #   (상 이름 옮기기와 무관한 항등식 · 같은 묶음의 짝 열이 표에 없어도 잰다 · 근거 열이 비면 건너뛰지 않고 거부)
            if wr is not None and any(wa_group_f1(c) for c in wa_take):
                rep['wa_f1_checked'] += _wa_f1_gates(r[key], wr, h)
            if wr is not None and any(wa_group_frac(c) for c in wa_take):
                rep['wa_frac_checked'] += _wa_frac_gates(r[key], wr)
            if wr is not None and rn is not None:
                rep['wa_area_checked'] += _wa_area_gates(r[key], wr, h, r, wa_take, rn)
            for c in wa_take:
                src, absent = _wa_src_col(c, dp, op, wname)             # J20-k (B) — 설계에 없는 상 → 빈칸 (N/A) · 설계 이름 칸 ← 웹앱 이름의 값
                v = None if (wr is None or absent) else wr.get(src)
                if absent and wr is not None:
                    rep['wa_mono_absent_blanked'] += 1
                elif dp is not None and wa_phase_specific(c) and v not in (None, ''):
                    rep['wa_mono_design_filled'] += 1
                if (v not in (None, '') and wr is not wr0 and not absent and wr0.get(src) in (None, '')
                        and (WA_PAIR_COUNT.fullmatch(c) or WA_PAIR_TOTAL.fullmatch(c))):
                    rep['wa_pair_zero_filled' if c.endswith('_n') else 'wa_area_total_zero_filled'] += 1   # 정규화가 채운 옛 접촉 0 쌍 (J20-h)
                _pm = ((WA_PAIR_COUNT.fullmatch(c) or WA_PAIR_TOTAL.fullmatch(c))
                       if (v in (None, '') and wr is not None and not absent) else None)
                if _pm is not None:
                    #  RGL-05 — 0 으로 채우는 것은 그 쌍의 세 키 (개수 · 총합 · 평균) 가 웹앱 원 행에 **모두** 빈칸일 때만 (누락 → 0 채움 금지 ·
                    #   Codex: 개수만 빠지고 평균 0.01 인 쌍이 '개수 0 · 평균 0.01' 로 나갔다)
                    _b = src[:src.rfind('_')]
                    _part = [k for k in (_b + '_n', _b + '_total', _b + '_mean') if wr0.get(k) not in (None, '')]
                    if _part:
                        raise FillRefusal(f'{r[key]}: {src} 가 빈칸인데 같은 쌍의 {_part} 에 값이 있다 — 개수 · 총합 없이 0 으로 채우지 않는다 '
                                          '(누락 → 0 채움 금지 · J20-h · RGL-05)')
                    #  J20-h — 웹앱 행이 있는데 쌍 키가 없다 = 접촉 0.  두 상이 다 있어야 0 (없으면 N/A 빈칸) · 상을 모르면 거부 ·
                    #   mono 는 설계 상으로 판단 (J20-k (B) — 설계 상 = 수확 AM)
                    pc = h.get('phase_counts')
                    if not isinstance(pc, dict):
                        raise FillRefusal(f'{r[key]}: 수확 JSON 에 phase_counts 가 없다 — {c} 의 빈칸이 접촉 0 인지 상이 없는 것인지 '
                                          '가를 수 없다 (J20-h)')
                    if all(_phase_n_mono(pc, ph, dp) > 0 for ph in _pm.groups()):
                        if c.endswith('_n'):
                            v = '0'
                            rep['wa_pair_zero_filled'] += 1
                        else:                                            # ⑦ — 총합도 측정된 0 (평균은 N/A 로 둔다 · J20-s)
                            v = '0.0'
                            rep['wa_area_total_zero_filled'] += 1
                o[c] = '' if v is None else str(v)
            #  RGL-05 — 최종 레코드: 0 채움 · 이름 옮김 · 접촉 0 평균 비움 **뒤** 내보내는 행을 다시 본다 (유한 · 형/범위 · 쌍 · AM–AM 의
            #   개수 ↔ 총합 · 평균 상태) — 정규화가 맞으면 쏘지 않는 이중 안전장치 (표에 개수가 없으면 정규화한 웹앱 원 행의 개수로 본다)
            if wr is not None and any(wa_s567_kind(c) is not None for c in wa_take):
                pair_n = {}
                for c in wa_take:
                    if WA_PAIR_ANY.fullmatch(c):
                        b_ = c[:c.rfind('_')]
                        if b_ + '_n' in wa_take:
                            pair_n[b_] = o.get(b_ + '_n', '')
                        else:
                            s_, ab_ = _wa_src_col(b_ + '_n', dp, op, wname)
                            pair_n[b_] = '' if ab_ else (wr.get(s_) or '')
                amn_ = o.get('am_am_n_contacts', '') if 'am_am_n_contacts' in wa_take else (wr.get('am_am_n_contacts') or '')
                rep['wa_s567_final_checked'] += _wa_s567_final(r[key], o, wa_take, pair_n, amn_)
            #  J20-i — 표에 함께 실린 평균 SE–SE CN 과 SE–SE 접촉 수가 같은 접촉 집합에서 왔는가: se_se_cn = 2 × area_SE_SE_n / N_SE
            #   (calc_se_se_cn 은 SE 전 입자로 나눈 평균 · 접촉 하나가 두 입자에 하나씩).  SE 입자 수를 모르거나 어긋나면 거부한다.
            if ('se_se_cn' in wa_take and 'area_SE_SE_n' in wa_take
                    and o.get('se_se_cn', '') != '' and o.get('area_SE_SE_n', '') != ''):
                pc = h.get('phase_counts')
                if not isinstance(pc, dict):
                    raise FillRefusal(f'{r[key]}: 수확 JSON 에 phase_counts 가 없다 — SE 입자 수를 몰라 se_se_cn = 2 × area_SE_SE_n / N_SE '
                                      '를 확인할 수 없다 (J20-i)')
                n_se = _phase_n(pc, 'SE')
                cn_v, n_pairs = float(o['se_se_cn']), float(o['area_SE_SE_n'])
                expect = 2.0 * n_pairs / n_se if n_se > 0 else float('nan')
                if not (n_se > 0 and abs(cn_v - expect) <= WA_CN_IDENTITY_TOL * max(1.0, abs(expect))):
                    raise FillRefusal(f'{r[key]}: se_se_cn {cn_v!r} ≠ 2 × area_SE_SE_n {n_pairs:g} / SE {n_se} = {expect!r} — '
                                      '같은 접촉 집합의 값이 아니다 (J20-i · 다른 프레임 · 다른 접촉 필터)')
                rep['wa_cn_identity_checked'] += 1
            #  J20-j — AM–AM: am_am_n_contacts = 웹앱 원 행의 AM–AM 쌍 개수 합 (없는 쌍 = 0 · J20-h 와 같은 뜻) ·
            #   am_am_cn = 2 × am_am_n_contacts / N_AM (calc_am_am_cn 은 AM 전 입자로 나눈 평균 · 접촉 하나가 두 입자에 하나씩).
            if 'am_am_n_contacts' in wa_take and o.get('am_am_n_contacts', '') != '':
                n_pairs_am = float(o['am_am_n_contacts'])
                s_pairs_am = sum(float(v) for k, v in wr.items() if WA_AM_AM_PAIR.fullmatch(k) and v not in (None, ''))
                if n_pairs_am != s_pairs_am:
                    raise FillRefusal(f'{r[key]}: am_am_n_contacts {n_pairs_am:g} ≠ AM–AM 쌍 개수 합 {s_pairs_am:g} — 같은 접촉 집합의 값이 아니다 (J20-j)')
                if 'am_am_cn' in wa_take and o.get('am_am_cn', '') != '':
                    pc = h.get('phase_counts')
                    if not isinstance(pc, dict):
                        raise FillRefusal(f'{r[key]}: 수확 JSON 에 phase_counts 가 없다 — AM 입자 수를 몰라 am_am_cn = 2 × am_am_n_contacts / '
                                          'N_AM 을 확인할 수 없다 (J20-j)')
                    n_am = _phase_n(pc, 'AM전체')
                    cn_am = float(o['am_am_cn'])
                    expect_am = 2.0 * n_pairs_am / n_am if n_am > 0 else float('nan')
                    if not (n_am > 0 and abs(cn_am - expect_am) <= WA_CN_IDENTITY_TOL * max(1.0, abs(expect_am))):
                        raise FillRefusal(f'{r[key]}: am_am_cn {cn_am!r} ≠ 2 × am_am_n_contacts {n_pairs_am:g} / AM {n_am} = {expect_am!r} — '
                                          '같은 접촉 집합의 값이 아니다 (J20-j)')
                rep['wa_am_identity_checked'] += 1
            #  7c — AM–SE CN · 고립 (G1–G7 · 상 있음/없음): 표에 실린 값들이 calc_am_isolation_risk 의 counts 하나에서 나왔는가
            if wr is not None and any(WA_AMSE_COL.fullmatch(c) for c in wa_take):
                rep['wa_amse_identity_checked'] += _wa_amse_gates(r[key], o, wa_take, h, dp, r)
            #  ② — 퍼콜레이션 (P1 관통 일관 + 수확기 독립 재현 · P2 범위 · P3 관통 SE 개수)
            if wr is not None and any(wa_group_perc(c) for c in wa_take):
                rep['wa_perc_checked'] += _wa_perc_gates(r[key], o, wa_take, h)
            #  ⑤⑥⑦ (J20-s) 관문은 위 — 출력 전에 웹앱 원 행 (⑦ 은 정규화한 행) 으로 잰다 (RGL-05)
            #  v1.1 ① — 경로 기준 고립 = 100 − 활성 (유도) · 웹앱 v1.1 이 같은 이름을 내면 같아야 · ①② 관문 D1–D5
            if wa_iso_on:
                a_ = o.get('ionic_active_pct', '')
                o['am_ionic_isolated_pct'] = repr(100.0 - float(a_)) if a_ not in ('', None) else ''
                w_iso = wr.get('am_ionic_isolated_pct') if wr is not None else None
                if w_iso not in (None, '') and a_ not in ('', None) and abs(float(w_iso) - (100.0 - float(a_))) > WA_PCT_SUM_TOL:
                    raise FillRefusal(f'{r[key]}: 웹앱 am_ionic_isolated_pct {w_iso} ≠ 100 − ionic_active_pct {a_} (v1.1 D1)')
                if wr is not None:
                    rep['wa_ionic_checked'] += _wa_ionic_gates(r[key], o, wa_take, h, dp)
            #  ★ v1.3 — 고립 전해질 = 100 − top_reachable_pct (유도 묶음 se_isolation · AM 경로 고립과 같은 규칙) · 웹앱이 같은 이름을 내면 같아야 (S1) · S2
            if se_iso_on:
                t_ = o.get('top_reachable_pct', '')
                o['se_isolated_pct'] = repr(100.0 - float(t_)) if t_ not in ('', None) else ''
                w_si = wr.get('se_isolated_pct') if wr is not None else None
                if w_si not in (None, '') and (t_ in ('', None) or abs(float(w_si) - (100.0 - float(t_))) > WA_PCT_SUM_TOL):
                    raise FillRefusal(f'{r[key]}: 웹앱 se_isolated_pct {w_si} ≠ 100 − top_reachable_pct {t_!r} (v1.3 S1)')
                rep['wa_se_iso_checked'] += _se_iso_gates(r[key], o)
            for name, wcol, hcol, _w in WA_QC:
                o[name] = ''
            if wr is not None:
                wp = wr.get('porosity_spheresum') or wr.get('porosity')
                if wp in (None, ''):
                    raise FillRefusal(f'{r[key]}: 웹앱 행에 porosity 가 없다 — 같은 프레임인지 확인할 수 없다')
                dpor = float(wp) - float(h['porosity_sphere_pct_RECORD_ONLY'])
                if abs(dpor) > WA_SAME_FRAME_TOL_PCT:
                    raise FillRefusal(f'{r[key]}: 웹앱 porosity − 수확 porosity = {dpor:+.4f} %p (> {WA_SAME_FRAME_TOL_PCT}) — '
                                      '다른 프레임 · 다른 메시의 웹앱 행이다')
                rep['wa_porosity_absmax'] = max(rep['wa_porosity_absmax'], abs(dpor))
                o['qc_wa_porosity_minus_harvest_pct'] = repr(dpor)
                for name, wcol, hcol, _w in WA_QC[1:]:
                    wc, hc = wcol, hcol
                    if dp is not None:                                   # J20-k (B) — 설계 상 칸 검산 = 웹앱 <웹앱 이름> − 수확 전체 · 없는 상 빈칸
                        toks_q = WA_PHASE_TOKEN.findall(name)
                        if any(t == op for t in toks_q):
                            continue
                        if any(t == dp for t in toks_q):
                            hc = 'coverage_AM_total_hertz_pct'
                            wc = _phase_swap(wcol, dp, wname) if (wname is not None and wname != dp) else wcol
                    a, b = wr.get(wc), h.get(hc)
                    st_h = (h.get('status') or {}).get(DESCRIPTOR_STATUS_KEY.get(hc, ''), '')
                    if a not in (None, '') and b is not None and st_h == 'OK':
                        o[name] = repr(float(a) - float(b))
        #  v1.2 망 τ — 칸 = τ 원천의 tau_flux 직렬화 그대로 (값 · 빈칸 · 상태 · 사유 · 메타 — 생성기는 고치지 않는다).  배치가 done · partial 로
        #   적지 않은 행 (failed · REFUSED) 은 τ 칸 전부 빈칸 — tau_flux 를 부르지 않았다 (사유 = wa_status · 옆 웹앱 열과 같은 규칙).
        if tau_on:
            if ((wv['status'].get(r[key]) or {}).get('status')) in WA_OK_STATUS:
                tc_ = tau['cases'][r[key]].get('cells') or {}
                if set(tc_) != set(tau_cols):
                    raise FillRefusal(f'{r[key]}: τ 기록의 칸 {sorted(set(tc_) ^ set(tau_cols))[:5]} 이 τ 열과 다르다 — 빈칸으로 메우지 않는다')
                for c in tau_cols:
                    o[c] = tc_[c]
                rep['tau_checked'] += 1
                for m_ in TAU_NET_MODES:
                    rep['tau_status'][f'{m_}:{tc_.get(f"ion_net_status_{m_}", "")}'] += 1
            else:
                for c in tau_cols:
                    o[c] = ''
                rep['tau_blank_rows'] += 1
        #  τ T3 — 벽 τ 와 ② 퍼콜레이션이 함께 실리면 비관통 판정이 같아야 한다 (수확기 벽 밴드 ↔ 웹앱 밴드 규칙 · SE 단분산이면 같은 집합 · J20-b F8)
        if tw_on and o.get('percolation_pct', '') not in ('', None):
            if (o.get('tortuosity_SE_wall_status') == 'NOT_PERCOLATING') != (float(o['percolation_pct']) == 0.0):
                raise FillRefusal(f'{r[key]}: 벽 τ 상태 {o.get("tortuosity_SE_wall_status")} ↔ 웹앱 percolation_pct {o["percolation_pct"]} — '
                                  '관통 판정이 어긋난다 (τ T3)')
            rep['tau_perc_crosschecked'] += 1
        if pressure is not None:                                      # ★ DESC-06 — 완료 압력 (기록이 없거나 · 도달 아님 · 다른 덱이면 거부)
            _pr = pressure.get(r[key])
            _pp = _press_problem(r[key], _pr, h)
            if _pp:
                raise FillRefusal(f'{r[key]}: 완료 압력 — {_pp} (DESC-06)')
            for name, k_, _w in HANDOVER_PRESS:
                o[name] = str(_pr.get(k_) or '')
            rep['pressure_checked'] += 1
        out.append(o)
        rep['n'] += 1
    return out, cols, rep



def _selftest():
    ok, fail = 0, []

    def chk(n, c):
        nonlocal ok
        (ok := ok + 1) if c else fail.append(n)
        print(('  PASS  ' if c else '  FAIL  ') + n)

    rows = build(n_interior=40, n_end=8, seed=0, restarts=60)
    chk(f'① 행 수 = 40 + 8 + 8 ({len(rows)})', len(rows) == 56)
    bi = [r for r in rows if r['block'] == 'bimodal']
    #  ② 모든 값이 지정 범위 안
    inb = all(RANGES[f][0] - 1e-9 <= r[f] <= RANGES[f][1] + 1e-9 for r in bi for f in FACTORS)
    chk('② 내부 블록의 모든 인자가 지정 범위 안', inb)
    #  ③ ★ 대립 ≥ 소립 이 **구성상** 보장된다 (범위가 안 겹친다)
    chk('③ d_AM_P ≥ d_AM_S 가 모든 행에서 성립 (범위 비중첩)',
        all(r['d_am_p_um'] >= r['d_am_s_um'] for r in bi))
    #  ④ ★ 끝점 블록은 죽은 크기 인자에 좌표를 주지 않는다 (NaN)
    mp = [r for r in rows if r['block'] == 'mono_AM_P']
    ms = [r for r in rows if r['block'] == 'mono_AM_S']
    chk('④ ps=1 행은 d_AM_S 가 NaN (없는 상에 좌표를 안 준다)',
        all(np.isnan(r['d_am_s_um']) for r in mp) and all(r['ps_frac'] == 1.0 for r in mp))
    chk('④b ps=0 행은 d_AM_P 가 NaN',
        all(np.isnan(r['d_am_p_um']) for r in ms) and all(r['ps_frac'] == 0.0 for r in ms))
    #  ⑤ 반경 = 직경/2 (DEM 입력 규약)
    chk('⑤ r_* = d_*/2 (LIGGGHTS 입력은 반경)',
        all(abs(r['r_SE_um'] * 2 - r['d_se_um']) < 1e-12 for r in rows))
    #  ⑥ LHS 층화 — 각 인자가 n 개 층에 정확히 하나씩 (1-D 균일).
    #    ⚠ 이것은 **연속 LHS 의 성질**이다.  정수 격자에서는 수준 수 < n 이라 각 수준이
    #      복제되므로 성립할 수 없다 — 이산 대응물은 ⑩b(수준 점유 균형)다.
    #      ⇒ 이 검사는 연속 경로에 건다 (그 경로를 살려 두는 한 회귀로 유효하다).
    bic = [r for r in build(40, 8, 0, 60, grid=False) if r['block'] == 'bimodal']
    U = np.array([[(r[f] - RANGES[f][0]) / (RANGES[f][1] - RANGES[f][0]) for f in FACTORS]
                  for r in bic])
    strat = all(sorted((U[:, j] * len(bic)).astype(int)) == list(range(len(bic)))
                for j in range(len(FACTORS)) if FACTORS[j] != 'ps_frac')
    chk('⑥ (연속 모드) 각 인자가 n 개 층에 정확히 하나씩 — 이산 대응물은 ⑩b', strat)
    #  ⑦ 재현성 — 같은 seed 는 같은 설계
    chk('⑦ 같은 seed = 같은 설계 (재현 가능)',
        build(40, 8, 0, 60)[7]['d_am_p_um'] == rows[7]['d_am_p_um'])
    #  ⑧ 상관이 낮다 (설계행렬이 교락되지 않았다)
    dg = diagnostics(rows)
    #  ★★ 문턱을 0.35 → 0.30 으로 **조인다** (2026-08-18).  옛 판(maximin 만 최적화)은
    #    am_pct 눈금이 거칠어지자 0.37 까지 튀었다 — 그 회귀를 잡으려면 문턱이 그 아래여야 한다.
    #    현행 기준(상관 벌점 + 열내부 스왑)은 n 40/60 × seed 0–5 에서 전부 ≤ 0.247 이었다.
    chk(f"⑧ 최대 |비대각 상관| < 0.30 ({dg['max_abs_offdiag_corr']})",
        dg['max_abs_offdiag_corr'] < 0.30)
    #  ── ★ 정수 격자 회귀 (2026-08-18) ─────────────────────────────────────
    g = build(40, 8, 1, 60, grid=True)
    def onstep(v, st):
        return abs(v / st - round(v / st)) < 1e-9
    chk('⑨ 모든 크기·조성 값이 지정 눈금 위에 있다 (d 1 µm · SE 0.5 µm · AM 1 %)',
        all(onstep(r[f], STEP[f]) for r in g for f in FACTORS if not np.isnan(r[f])))
    chk('⑨b ps 가 0.1 눈금 → `ps_label` 이 반올림이 아니라 **정확**하다',
        all(abs(r['ps_frac'] * 10 - round(r['ps_frac'] * 10)) < 1e-9 for r in g))
    dgg = diagnostics(g)
    chk(f"⑩ 중복 설계점 0 ({dgg['duplicate_design_points']}건)",
        dgg['duplicate_design_points'] == 0)
    #  ★★ ⑩b 는 **제약이 없을 때**의 성질이다 (2026-08-18).  입자수 상한이 걸리면 후보 풀이
    #    잘려 완전 균형이 **원리적으로 불가능**하다 — `_balanced()` 가 만든 배치가 제약을
    #    위반하고, 위반 행을 갈아끼우면 균형이 깨진다.  ⇒ 두 경로로 나눈다:
    #      · 제약 없음 → 최대−최소 ≤ 1 (엄격, 옛 성질 그대로)
    #      · 제약 있음 → 편차가 기대 점유의 25 % 이내 (후보 풀이 허용하는 최선)
    #    실패한 테스트를 **지우지 않고 적용 범위를 좁힌다** (⑥ 과 같은 처리).
    def _spread(dg_):
        return {k: (int(v.split('점유 ')[1].split('–')[1])
                    - int(v.split('점유 ')[1].split('–')[0]))
                for k, v in dg_['levels'].items()}
    _LVf = [levels_of(f, PS_INTERIOR) for f in FACTORS]
    _constrained = len(feasible_combos(FACTORS, _LVf)) < int(np.prod([len(x) for x in _LVf]))
    if not _constrained:
        chk('⑩b (제약 없음) 수준 점유 최대−최소 ≤ 1', all(v <= 1 for v in _spread(dgg).values()))
    else:
        _n = len([r for r in g if r['block'] == 'bimodal'])
        #  허용폭 = max(2, 기대점유의 25 %).  2 는 이상적 배분 ±1 = 이산 배정의 자연 여유이고,
        #  큰 n 에서는 25 % 가 이긴다 (n=100·11수준이면 기대 9.09 → 허용 2.27).
        _tol = {k: max(2, 0.25 * _n / len(levels_of(k, PS_INTERIOR))) for k in FACTORS}
        _sp = _spread(dgg)
        chk(f'⑩b (제약 있음) 수준 점유 편차가 기대의 25 % 이내 {_sp}',
            all(_sp[k] <= _tol[k] for k in _sp))
        #  ⑩d 제약이 실제로 걸려 있는지 (안 걸렸는데 느슨한 검사를 쓰면 안 된다)
        chk(f'⑩d 제약이 실제로 후보를 자른다 '
            f'({len(feasible_combos(FACTORS, _LVf)):,} / {int(np.prod([len(x) for x in _LVf])):,})',
            True)
    #  ⑩c ★ 기준이 **상관을 실제로 본다** — 순수 maximin 대비 개선되는가.
    #      (옛 결함의 직접 회귀: maximin 만 쓰면 상관이 운에 맡겨진다)
    rng_ = np.random.default_rng(7)
    LV = [levels_of(f, PS_INTERIOR) for f in FACTORS]
    pure, pure_d = None, -1.0                                # 순수 maximin 재현
    for _ in range(400):
        Ic = np.stack([_balanced(40, len(LV[j]), rng_) for j in range(len(LV))], 1)
        _, md = _score(_unit(Ic, LV))
        if md > pure_d:
            pure, pure_d = Ic, md
    mc_pure, _ = _score(_unit(pure, LV))
    mc_new, _ = _score(_unit(lhs_grid(40, LV, np.random.default_rng(7), 400), LV))
    chk(f'⑩c 상관-인지 기준이 순수 maximin 보다 낫다 ({mc_new:.3f} < {mc_pure:.3f})',
        mc_new < mc_pure)
    #  ⑫ ★ 입자수 상한 — 모든 행이 N_TOTAL_CAP 이하 (지시 2026-08-18)
    chk(f'⑫ 모든 행이 입자 {N_TOTAL_CAP:,} 이하 '
        f"(최대 {max(r['n_total_est'] for r in g):,.0f})",
        all(r['n_total_est'] <= N_TOTAL_CAP for r in g))
    #  ⑪ 연속 모드도 여전히 된다 (되돌릴 길을 남긴다)
    c = build(20, 4, 0, 40, grid=False)
    chk('⑪ --continuous 경로 보존 (눈금 밖 값이 나온다)',
        any(not onstep(r['d_am_p_um'], 1.0) for r in c if not np.isnan(r['d_am_p_um'])))
    #  ── ★★ `LHS-01` 회귀 (2026-09-15) ─────────────────────────────────────
    #    규율 ②: 결함을 재현하는 검사를 **먼저** 세우고 고친다.  옛 코드는 ⑬·⑬b 를
    #    **둘 다** 실패했다 (열 이름이 `se_percolation` · 플래그에 `se_` 접합).
    chk('⑬ SE 퍼콜 **추정** 열 이름이 규약을 담는다 (`_est_meanfield`)',
        all('se_percolation_est_meanfield' in r and 'se_percolation' not in r for r in rows))
    #  ⑬b **기하 플래그가 물리 추정을 나르지 않는다** — 두 종류를 한 열에 접합하면
    #      "유한크기가 깨끗한데 플래그가 켜진 행" 과 구별이 불가능해진다.
    chk('⑬b finite_size_flag 에 `se_` 조각이 하나도 없다 (기하 ↔ 물리추정 분리)',
        not any(t.startswith('se_') for r in rows
                for t in (r['finite_size_flag'].split('+') if r['finite_size_flag'] else [])))
    #  ⑬c ★ 분리가 **정보를 잃지 않는다** — 두 열을 합치면 옛 열이 정확히 복원된다.
    def _legacy(r):
        return '+'.join([t for t in (r['finite_size_flag'].split('+')
                                     if r['finite_size_flag'] else [])]
                        + ([r['se_perc_est_flag']] if r['se_perc_est_flag'] else []))
    chk('⑬c 두 열을 합치면 옛 `finite_size_flag` 가 정확히 복원된다 (무손실 분리)',
        all(_legacy(r) == '+'.join(
            [t for t in ([] if not r['finite_size_flag'] else r['finite_size_flag'].split('+'))]
            + ([] if r['se_percolation_est_meanfield'] == 'OK'
               else ['se_' + r['se_percolation_est_meanfield']])) for r in rows))
    #  ⑬d ★★ **실측 상수가 자기 원자료와 일치한다** — 숫자를 주석에 손으로 적고 끝내면
    #      원자료가 바뀌어도 아무도 모른다 (규율 ④: 정본은 밖으로 강제되지 않으면 샌다).
    #      원자료가 없으면 **건너뛰지 않고 실패**한다 (fail-closed).
    _mp = pathlib.Path(__file__).resolve().parent.parent / LHS_PERC_MEASURED['source']
    if _mp.exists():
        #  ⚠ 파일 머리에 `#` 출처 주석이 있다 — 그것을 헤더로 읽으면 **조용히 0행**이 되고
        #    검사가 통과해 버린다 (규율 ⑤ false-green).  주석은 명시적으로 걷어낸다.
        _rows = list(csv.DictReader(
            [ln for ln in _mp.read_text(encoding='utf-8').splitlines()
             if not ln.startswith('#')]))
        _agg = {}
        for _r in _rows:
            _k = _r['se_percolation_est_meanfield']
            _a = _agg.setdefault(_k, [0, 0])
            _a[0] += 1
            _a[1] += (_r['ionic_percolates'] == 'False')
        _hit = (len(_rows) == LHS_PERC_MEASURED['n_measured']
                and all(_agg.get(k, [0, 0]) == [v['n'], v['blocked']]
                        for k, v in LHS_PERC_MEASURED.items()
                        if isinstance(v, dict) and 'blocked' in v))
        chk(f'⑬d LHS_PERC_MEASURED 가 원자료와 일치한다 '
            f'(n={len(_rows)} · {({k: v for k, v in _agg.items()})})', _hit)
    else:
        chk(f'⑬d 실측 원자료가 있다 ({LHS_PERC_MEASURED["source"]})', False)
    #  ── ★★ `LHS-02` 회귀 (2026-09-15) ─────────────────────────────────────
    #    ⑭ **0 을 결측으로 세지 않는다** — 그렇게 세면 검사기가 `DESC-05` 결함을 재생산한다
    #      (*"없는 AM_P → N/A · 존재하는데 무접촉 → 0.0"*).  합성 3행으로 직접 가른다.
    _probe = [{c: '' for c in DESCRIPTORS}, {c: 0.0 for c in DESCRIPTORS},
              {c: float('nan') for c in DESCRIPTORS}]
    _f3 = descriptor_fill(_probe)
    chk(f'⑭ 채움 계수가 0.0 은 **측정으로**, ""·NaN 은 **결측으로** 센다 ({_f3["phi_se"]}/3 = 1)',
        all(v == 1 for v in _f3.values()))
    #  ⑭b **읽기 전 가드가 실제로 거부한다** — 있기만 하고 안 막으면 없는 것과 같다.
    try:
        require_descriptors(_probe, ['phi_se'], 'probe')
        _refused = ''
    except ValueError as e:
        _refused = str(e)
    chk(f'⑭b require_descriptors 가 결측을 **거부**한다 ({_refused[:48]}…)',
        'phi_se 1/3' in _refused and '0 으로 채우지 말 것' in _refused)
    #  ⑭c ★ 그리고 **완전한 행은 통과시킨다** (거부만 하면 그것도 결함이다 — 양방향 확인)
    try:
        require_descriptors([{c: 1.0 for c in DESCRIPTORS}], DESCRIPTORS, 'full')
        _passed = True
    except ValueError:
        _passed = False
    chk('⑭c 완전한 행은 통과시킨다 (거부 과잉이 아니다)', _passed)
    #  ⑮ `LHS-02` 병합 — **거부가 실재하는가** (거부 로직은 안 쏘면 장식이다)
    #  ★ 10-06 (DESC-06 최종 join) — 원자료 sha 넷 (atom · contact · mesh · deck) — 수확 raw · 웹앱 배치 status 가 같은 값을 들고 다닌다 (생산 모양)
    _RAW_SHA = {'atom': 'a' * 64, 'contact': 'b' * 64, 'mesh': 'e' * 64, 'deck': 'f' * 64}

    def _h(case, **kw):
        """최소 수확 fixture — 기본은 전부 OK 인 정상 건."""
        b = dict(case=case, timestep=100, phi_se=0.2, phi_am=0.3,
                 porosity_sphere_pct_RECORD_ONLY=50.0,
                 coverage_AM_P_hertz_pct=10.0, coverage_AM_S_hertz_pct=20.0,
                 coverage_AM_total_hertz_pct=17.5,     # (1·10 + 3·20)/4 = 17.5
                 tortuosity_dijkstra_SE=1.5,
                 status=dict(phi='OK', porosity='OK', coverage_AM_P='OK',
                             coverage_AM_S='OK', coverage_AM_total='OK', tortuosity='OK'),
                 coverage_detail=dict(counts={'AM_P': {'n_valid': 1}, 'AM_S': {'n_valid': 3}}),
                 raw={k_: dict(sha256=v_) for k_, v_ in _RAW_SHA.items()},
                 _file=case + '.json', _sha256='c' * 64)
        b.update(kw)
        return b

    def _neg(name, fn):
        nonlocal ok
        try:
            fn()
        except FillRefusal as e:
            ok += 1
            print(f'  PASS  {name} — 거부: {str(e)[:64]}')
            return
        except Exception as e:                                    # noqa: BLE001
            chk(f'{name} (기대 FillRefusal, 실제 {type(e).__name__}: {e})', False)
            return
        chk(f'{name} (거부하지 않았다)', False)

    _dr = [{'case_id': 'c1'}, {'case_id': 'c2'}]
    _hv = {'c1': _h('c1'), 'c2': _h('c2')}
    _r2, _rp = fill_descriptors([dict(x) for x in _dr], _hv)
    chk('⑮ 정상 건은 일곱 열이 전부 찬다',
        all(_rp['filled'][c] == 2 for c in DESCRIPTORS))
    chk('⑮ 값이 왕복 가능한 정밀도로 쓰인다 (반올림 손실 없음)',
        float(_r2[0]['phi_se']) == 0.2 and _r2[0]['phi_se_status'] == 'OK')
    #  ── ⑰ HND-04 (Codex 09-25 · 비준 09-25): 인계표가 벽 QC · 적격성 · 규약 ID · sha 를 실어 나른다 · 음수도 원값 보존 ──
    _hn = _h('c1', phi_se=0.5135813340456643, phi_am=0.4996409958699752,
             porosity_sphere_pct_RECORD_ONLY=-1.3222329915639541)          # = lhs00_005 실측 (Codex 반례)
    _hn['handover_qc'] = dict(calculation_status='OK', physical_target_status='HOLD',
                              hold_reason_codes='NEGATIVE_POROSITY|BOUNDARY_CENTER_OUT', phi_sum_gt_one=True,
                              thickness_wall_gap_um=45.9, n_floor_center_out=4,
                              boundary_state='CENTER_CROSSED', n_floor_fully_out=0, n_plate_center_out=0, n_plate_fully_out=0,   # 수확기 모양 (LREL-02)
                              boundary_model_id='floor=primitive_zplane_type3|platen=mesh_stl',
                              measurement_protocol_id='harvest_v2_20260925/spheresum_nominal_gap/wall_z0',
                              deck_sha256='d' * 64, contact_sha256='b' * 64, mesh_sha256='m' * 64)
    _hn['deck_floor'] = dict(z=0.0, wall_type=3)
    try:
        _on, _cn, _repn = build_handover([{'case_id': 'c1'}], {'c1': _hn})
        _row = _on[0]
    except Exception as e:                                                # noqa: BLE001
        _row, _cn = {'_err': f'{type(e).__name__}: {e}'}, []
    chk('⑰ HND-04: 음수 porosity · φ 합 > 1 도 **원값 그대로** 나간다 (0 접기 · 빈칸 아님)',
        _row.get('phi_se') == repr(0.5135813340456643)
        and _row.get('porosity_sphere_pct_RECORD_ONLY') == repr(-1.3222329915639541))
    chk('⑰ HND-04: 계산 상태 OK 와 별도로 physical_target_status HOLD · 보류 코드 · phi_sum_gt_one 이 열로 나간다',
        _row.get('phi_se_status') == 'OK' and _row.get('physical_target_status') == 'HOLD'
        and 'NEGATIVE_POROSITY' in (_row.get('hold_reason_codes') or '') and _row.get('phi_sum_gt_one') == 'True')
    chk('⑰ HND-04: 두께 µm · 벽 QC · 규약 ID · deck/contact/mesh sha · 덱 바닥 z 가 열에 있다',
        _row.get('thickness_wall_gap_um') == '45.9' and _row.get('n_floor_center_out') == '4'
        and bool(_row.get('boundary_model_id')) and bool(_row.get('measurement_protocol_id'))
        and len(_row.get('deck_sha256') or '') == 64 and _row.get('deck_floor_z_sim') == '0.0')
    _dh = pathlib.Path(__file__).resolve().parent.parent / str(globals().get('DEFAULT_HARVEST_DIR', ''))
    _dj = sorted(_dh.glob('lhs*.json'))[:1] if _dh.is_dir() else []
    chk('⑰ HND-04 · J19: 기본 수확 디렉터리 = 20260925 판 — 그 JSON 에 handover_qc 가 **실제로** 있다 (0924 판은 없어 HND-04 열이 빈칸이었다)',
        'lhs_descriptors_20260925' in str(globals().get('DEFAULT_HARVEST_DIR', ''))
        and bool(_dj) and 'handover_qc' in json.loads(_dj[0].read_text(encoding='utf-8')))
    #  ★ `DESC-09` — 반쪽 채움 금지 (양방향)
    _neg('⑮a DESC-09: 수확에 없는 설계가 있으면 거부',
         lambda: fill_descriptors([{'case_id': 'c1'}, {'case_id': 'zz'}], _hv))
    _neg('⑮a DESC-09: 설계에 없는 수확이 있으면 거부',
         lambda: fill_descriptors([{'case_id': 'c1'}], _hv))
    #  ★ `DESC-07` — 두 항등식이 병합 시점에 **다시** 검증된다
    _neg('⑮b DESC-07①: porosity 가 φ 둘에서 안 나오면 거부',
         lambda: fill_descriptors([{'case_id': 'c1'}],
                                  {'c1': _h('c1', porosity_sphere_pct_RECORD_ONLY=49.0)}))
    _neg('⑮b DESC-07②: C_total 이 입자수 가중평균이 아니면 거부',
         lambda: fill_descriptors([{'case_id': 'c1'}],
                                  {'c1': _h('c1', coverage_AM_total_hertz_pct=15.0)}))
    #  ★ `GAP2-05` — 실패에 숫자가 붙거나, 성공에 값이 없으면 거부
    _neg('⑮c GAP2-05: status≠OK 인데 값이 있으면 거부',
         lambda: fill_descriptors(
             [{'case_id': 'c1'}],
             {'c1': _h('c1', status=dict(phi='OK', porosity='OK', coverage_AM_P='OK',
                                         coverage_AM_S='OK', coverage_AM_total='OK',
                                         tortuosity='NOT_PERCOLATING'))}))
    _neg('⑮c status 가 OK 인데 값이 없으면 거부',
         lambda: fill_descriptors([{'case_id': 'c1'}],
                                  {'c1': _h('c1', tortuosity_dijkstra_SE=None)}))
    #  ★ 그리고 실패 칸은 **빈 칸 + 사유**다 — 0 이 아니다 (이 한 줄이 GAP2-05 그 자체)
    _hf = _h('c1', tortuosity_dijkstra_SE=None,
             status=dict(phi='OK', porosity='OK', coverage_AM_P='OK', coverage_AM_S='OK',
                         coverage_AM_total='OK', tortuosity='NOT_PERCOLATING'))
    _r3, _rp3 = fill_descriptors([{'case_id': 'c1'}], {'c1': _hf})
    chk('⑮d 실패 칸은 빈 칸이고 사유가 옆에 붙는다 (0 이 아니다)',
        _r3[0]['tortuosity_dijkstra_SE'] == ''
        and _r3[0]['tortuosity_dijkstra_SE_status'] == 'NOT_PERCOLATING'
        and _rp3['filled']['tortuosity_dijkstra_SE'] == 0)
    chk('⑮d 그 행의 다른 여섯 열은 그대로 찬다 (DESC-01: 한 타깃 실패로 행을 안 버린다)',
        all(_rp3['filled'][c] == 1 for c in DESCRIPTORS if c != 'tortuosity_dijkstra_SE'))
    #  ★ `DESC-08` — 291 코퍼스를 읽는 코드가 이 파일에 없다 (정적, AST)
    #  ⚠ 소박한 `낱말 not in src` 는 **자기 자신을 탐지한다** (이 검사문에 그 낱말이 있다).
    #    초판이 실제로 그렇게 FAIL 했다.  그리고 docstring 구분자로 자르는 방식은 **첫 함수
    #    docstring 까지만** 보므로 뒤쪽 본문을 통째로 놓친다 = false-green.  ⇒ AST 로
    #    **문자열 상수의 자리**를 보고, 모듈 docstring 과 이 selftest 는 제외한다.
    _tree = ast.parse(pathlib.Path(__file__).read_text(encoding='utf-8'))
    _skip = set()
    if (_tree.body and isinstance(_tree.body[0], ast.Expr)
            and isinstance(_tree.body[0].value, ast.Constant)):
        _d = _tree.body[0].value
        _skip |= set(range(_d.lineno, (_d.end_lineno or _d.lineno) + 1))
    for _n in ast.walk(_tree):
        if isinstance(_n, ast.FunctionDef) and _n.name == '_selftest':
            _skip |= set(range(_n.lineno, (_n.end_lineno or _n.lineno) + 1))
    _needle = 'design_performance' + '_corpus'
    _hits = sorted({_n.lineno for _n in ast.walk(_tree)
                    if isinstance(_n, ast.Constant) and isinstance(_n.value, str)
                    and _needle in _n.value and _n.lineno not in _skip})
    chk(f'⑮e DESC-08: 291 코퍼스 경로가 코드에 없다 (AST · docstring/selftest 제외; 적중 {_hits})',
        not _hits)
    #  ★ 그 검사가 **실제로 쏘는지** — 같은 판정기에 심은 참조를 먹여 본다 (변이 대조)
    _mut = ast.parse('def f():\n    return open("docs/data/' + _needle + '.csv")\n')
    _mhits = [_n.lineno for _n in ast.walk(_mut)
              if isinstance(_n, ast.Constant) and isinstance(_n.value, str)
              and _needle in _n.value]
    chk('⑮e 그 정적 검사가 장식이 아니다 (심은 참조를 잡는다)', len(_mhits) == 1)

    #  ⑭d ★★ **동결 설계 CSV 의 채움 상태를 수치로 못박는다.**  누가 채우면 이 검사가
    #      실패하면서 알려 준다 — "아무도 안 봤다" 를 "리포가 본다" 로 바꾸는 자리다.
    _dp = pathlib.Path(__file__).resolve().parent.parent / DESCRIPTOR_FILL_EXPECTED['path']
    if _dp.exists():
        _dr = list(csv.DictReader(_dp.open(encoding='utf-8-sig')))
        _df = descriptor_fill(_dr)
        chk(f'⑭d 동결 설계 CSV 채움 상태가 등록값과 일치 '
            f'({len(_dr)}행 · 채움 {sorted(set(_df.values()))})',
            len(_dr) == DESCRIPTOR_FILL_EXPECTED['n_rows']
            and _df == DESCRIPTOR_FILL_EXPECTED['filled'])
    else:
        chk(f'⑭d 동결 설계 CSV 가 있다 ({DESCRIPTOR_FILL_EXPECTED["path"]})', False)

    #  ═══ ⑯ 인계표 계약 (`build_handover`) — 규율 ② 대로 **먼저** 쓴 시험 ═══════════
    def _hrow(case, tau_ok=False, mono=False):
        """수확 한 건을 최소로 흉내낸다.  mono = 수확기의 2-type 모양 (상 라벨 `AM` 하나 · coverage 상별 둘 다 N_A_PHASE_ABSENT ·
        `coverage_AM_only` = 전체 — 실측 0925 130/64 JSON 과 같은 모양)."""
        phi_se, phi_am = 0.20, 0.50
        return {
            'case': case, 'timestep': 100, 'plate_z_sim': 0.04, 'plate_z_source': 'mesh_stl',
            'V_box_sim': 1.0e-4, 'area_channel': 'dem_geometric_c_cpl22 …', 'closure_residual': 0.0,
            'phi_se': phi_se, 'phi_am': phi_am,
            'porosity_sphere_pct_RECORD_ONLY': 100.0 * (1 - phi_se - phi_am),
            'n_types': (2 if mono else 3),
            'phase_counts': ({'AM': 7, 'SE': 50} if mono else {'AM_P': 5, 'AM_S': 9, 'SE': 50}),
            'coverage_AM_P_hertz_pct': (None if mono else 11.0),
            'coverage_AM_S_hertz_pct': (None if mono else 22.0),
            'coverage_AM_only_hertz_pct': (20.0 if mono else None),
            #  ★ 10-06 (DESC-07 ② 관문) — bimodal 전체 = (5·11 + 9·22)/14 (피복 유효 입자 수 가중) · 옛 20.0 은 항등식과 모순이었다 · mono = AM_only
            'coverage_AM_total_hertz_pct': (20.0 if mono else (5 * 11.0 + 9 * 22.0) / 14),
            'tortuosity_dijkstra_SE': (1.5 if tau_ok else None),
            'status': {'phi': 'OK', 'porosity': 'OK',
                       'coverage_AM_P': ('N_A_PHASE_ABSENT' if mono else 'OK'),
                       'coverage_AM_S': ('N_A_PHASE_ABSENT' if mono else 'OK'), 'coverage_AM_total': 'OK',
                       'tortuosity': ('OK' if tau_ok else 'NOT_PERCOLATING')},
            'tau_detail': {'n_sampled': 7, 'n_valid': (7 if tau_ok else 0), 'n_truncated': 0,
                           'tau_convention': 'harvest_v1/…'},
            'coverage_detail': {'n_capped': 0, 'n_free_surface_invalid': 0,
                                'counts': {'AM_P': {'n_valid': (0 if mono else 5)},
                                           'AM_S': {'n_valid': (0 if mono else 9)},
                                           'AM': {'n_valid': (7 if mono else 0)}}},
            'raw': {'atom': {'sha256': 'deadbeef'}},
        }
    _drows = [{'case_id': 'c1', 'block': 'bimodal', 'd_am_p_um': 5.0, 'am_pct': 80.0},
              {'case_id': 'c2', 'block': 'mono_AM_P', 'd_am_p_um': 9.0, 'am_pct': 90.0}]
    _harv = [_hrow('c1', tau_ok=True), _hrow('c2', mono=True)]
    _o, _c, _rep = build_handover(_drows, _harv)
    chk('⑯a 행 수 보존 (2)', len(_o) == 2)
    #  ★ 계약 ① — τ 값 열이 **없어야** 한다 (있으면 학습에 들어간다)
    chk('⑯b τ 값 열이 인계표에 없다', 'tortuosity_dijkstra_SE' not in _c)
    chk('⑯c 대신 τ 진단 열이 있다',
        all(k in _c for k in ('tau_status', 'tau_n_valid', 'tau_convention')))
    #  ★ 계약 ② — status != OK 는 **빈칸**이고 0 이 아니다.  ★ J20-k (B) (1저자 09-30 *"인계할때는 중복되더라도 잘 채워서"* · J20-f (A) 개정):
    #    mono 는 **설계 상 칸** (block mono_AM_P → AM_P) 에 단일 AM 값 (= 전체 열) 을 싣고, 설계에 없는 상 (AM_S) 의 칸은 빈칸 (N/A · 0 아님).
    #    수확기 열 전부 같은 규칙 — coverage 상별 · n_AM_*_measured (LHS-21 해소) · cov_*_n_valid.
    _mono = [r for r in _o if r['case_id'] == 'c2'][0]
    chk('⑯d ★ J20-k (B) mono_AM_P — coverage_AM_P 칸 = 전체 값 (status OK) · AM_S 칸 빈칸 (N_A_PHASE_ABSENT · 0 아님) · '
        'n_AM_P_measured = phase_counts.AM · n_AM_S_measured 빈칸 · cov_AM_P_n_valid = counts.AM · 보고 mono_rows',
        _mono['coverage_AM_P_hertz_pct'] == repr(20.0) and _mono['coverage_AM_P_hertz_pct_status'] == 'OK'
        and _mono['coverage_AM_S_hertz_pct'] == '' and _mono['coverage_AM_S_hertz_pct_status'] == 'N_A_PHASE_ABSENT'
        and _mono['coverage_AM_total_hertz_pct'] == repr(20.0)
        and _mono['n_AM_P_measured'] == '7' and _mono['n_AM_S_measured'] == '' and _mono['n_SE_measured'] == '50'
        and _mono['cov_AM_P_n_valid'] == '7' and _mono['cov_AM_S_n_valid'] == ''
        and _rep.get('mono_rows') == 1)
    _bim = [r for r in _o if r['case_id'] == 'c1'][0]
    chk('⑯d1 bimodal 은 그대로 — 상별 값 둘 다 · n_AM_P/S_measured = phase_counts',
        _bim['coverage_AM_P_hertz_pct'] == repr(11.0) and _bim['coverage_AM_S_hertz_pct'] == repr(22.0)
        and _bim['n_AM_P_measured'] == '5' and _bim['n_AM_S_measured'] == '9' and _bim['cov_AM_S_n_valid'] == '9')
    _drows_s = [dict(_drows[0]), dict(_drows[1], block='mono_AM_S')]
    _mono_s = [r for r in build_handover(_drows_s, _harv)[0] if r['case_id'] == 'c2'][0]
    chk('⑯d2 mono_AM_S 는 거울 — AM_S 칸에 값 · AM_P 칸 빈칸',
        _mono_s['coverage_AM_S_hertz_pct'] == repr(20.0) and _mono_s['coverage_AM_S_hertz_pct_status'] == 'OK'
        and _mono_s['coverage_AM_P_hertz_pct'] == '' and _mono_s['coverage_AM_P_hertz_pct_status'] == 'N_A_PHASE_ABSENT'
        and _mono_s['n_AM_S_measured'] == '7' and _mono_s['n_AM_P_measured'] == ''
        and _mono_s['cov_AM_S_n_valid'] == '7' and _mono_s['cov_AM_P_n_valid'] == '')
    #  ★ (B) 는 설계 block 과 수확 모양이 맞을 때만 — 어긋나거나 모르면 거부 (조용히 (A) 로 돌아가면 한 표에 규약이 섞인다)
    _neg('⑯d3 설계 block mono_AM_P 인데 수확 n_types 3 이면 거부',
         lambda: build_handover(_drows, [_hrow('c1', tau_ok=True), dict(_hrow('c2', mono=True), n_types=3)]))
    _neg('⑯d4 수확 n_types 2 인데 설계 block bimodal 이면 거부',
         lambda: build_handover([dict(_drows[0]), dict(_drows[1], block='bimodal')], _harv))
    _neg('⑯d5 수확 n_types 2 인데 설계행에 block 이 없으면 거부 (설계 상을 모른다)',
         lambda: build_handover([dict(_drows[0]), {k: v for k, v in _drows[1].items() if k != 'block'}], _harv))
    _neg('⑯d6 mono 인데 수확 coverage_AM_S 상태가 N_A_PHASE_ABSENT 가 아니면 거부 (mono 모양이 아니다)',
         lambda: build_handover(_drows, [_hrow('c1', tau_ok=True),
                                         dict(_hrow('c2', mono=True), coverage_AM_S_hertz_pct=22.0,
                                              status=dict(_hrow('c2', mono=True)['status'], coverage_AM_S='OK'))]))
    _neg('⑯d7 설계 block mono 인데 수확 JSON 에 n_types 가 없으면 거부',
         lambda: build_handover(_drows, [_hrow('c1', tau_ok=True), {k: v for k, v in _hrow('c2', mono=True).items() if k != 'n_types'}]))
    _neg('⑯d8 mono 인데 coverage_AM_only ≠ coverage_AM_total 이면 거부 (단일 AM = 전체 항등식)',
         lambda: build_handover(_drows, [_hrow('c1', tau_ok=True), dict(_hrow('c2', mono=True), coverage_AM_only_hertz_pct=19.0)]))
    _neg('⑯d9 mono 인데 phase_counts 에 AM_P 가 있으면 거부 (수확기 mono 라벨은 AM 하나)',
         lambda: build_handover(_drows, [_hrow('c1', tau_ok=True), dict(_hrow('c2', mono=True), phase_counts={'AM': 4, 'AM_P': 3, 'SE': 50})]))
    _neg('⑯d10 설계 block 이 모르는 mono 라벨 (mono_AM) 이면 거부',
         lambda: build_handover([dict(_drows[0]), dict(_drows[1], block='mono_AM')], _harv))
    chk('⑯e 값 칸마다 _status 짝이 있다',
        all(v + '_status' in _c for v in HANDOVER_VALUE_COLS))
    #  ★ 실측 입자수가 설계 추정과 **다른 열**로 들어간다
    chk('⑯f 실측 입자수 열이 있다',
        all(k in _c for k in ('n_AM_P_measured', 'n_SE_measured', 'cov_AM_P_n_valid')))
    #  ★ 변이 대조 1 — 항등식을 깨면 **거부**해야 한다 (안 깨지면 시험이 무의미)
    _bad = [_hrow('c1', tau_ok=True), _hrow('c2', mono=True)]
    _bad[0]['porosity_sphere_pct_RECORD_ONLY'] += 1.0
    try:
        build_handover(_drows, _bad); _r1 = False
    except FillRefusal:
        _r1 = True
    chk('⑯g 변이① DESC-07 항등식을 깨면 거부한다', _r1)
    #  ★ 변이 대조 2 — 수확이 모자라면 **부분 인계 금지**
    try:
        build_handover(_drows, [_hrow('c1')]); _r2 = False
    except FillRefusal:
        _r2 = True
    chk('⑯h 변이② 수확 누락 시 부분 인계를 거부한다', _r2)
    #  ★ 보류 사유가 **기계가 읽는 자리**에 있다 (산문에만 있으면 낡는다)
    #  ★ 변이 대조 3 — **프로덕션 모양(dict)** 으로도 같은 결과여야 한다
    _od, _cd, _ = build_handover(_drows, {h['case']: h for h in _harv})
    chk('⑯j dict 모양(load_harvest 산출)으로도 동일', _od == _o and _cd == _c)
    chk('⑯i 보류 열과 사유가 등록돼 있다',
        'tortuosity_dijkstra_SE' in HANDOVER_HELD_BACK
        and 'LHS-08' in HANDOVER_HELD_BACK['tortuosity_dijkstra_SE'])

    #  ═══ ⑱ J19 (1저자 비준 09-28) — 겹침 보정 porosity 를 **병기** (구 부피 합 열 유지 · 교체 아님) ═══════════════════
    #   union TSV (scripts/lhs_union_webapp.py 산출) 를 수확과 **짝지어** 붙인다.  짝이 맞는지 (같은 수확 · 같은 프레임) 를
    #   구 부피 합 porosity · 두께 · 상별 입자 수로 다시 재고, 어긋나면 거부한다 — 다른 수확 · 다른 프레임의 union 을 붙이지 않는다.
    def _hq(case, eps_s=11.0, th=34.0, n_se=100, n_p=1, n_s=10):
        h = _h(case, porosity_sphere_pct_RECORD_ONLY=eps_s, phi_se=0.5, phi_am=0.5 - eps_s / 100.0)
        h['phase_counts'] = {'AM_P': n_p, 'AM_S': n_s, 'SE': n_se}
        #  ★ 10-06 (LREL-02 · 04) — 수확기 handover_qc 모양: 부피 감사 (V_SE · V_AM — φ 와 같은 비) · 적격성 (calculation_status · physical_target_status ·
        #    hold_reason_codes · boundary_state · 벽 밖 개수 · phi_sum_gt_one) 을 수확기 규칙대로 (eps < 0 → NEGATIVE_POROSITY · HOLD) 채운다.
        #    옛 픽스처는 두께만 있어 적격성 관문 · SE 몫 교차대조가 설 원천이 없었다.
        _neg_p = eps_s < 0
        h['handover_qc'] = {'thickness_wall_gap_um': th, 'V_SE_full_um3': 0.5, 'V_AM_full_um3': 0.5 - eps_s / 100.0,
                            'calculation_status': 'OK', 'boundary_state': 'INSIDE',
                            'n_floor_center_out': 0, 'n_plate_center_out': 0, 'n_floor_fully_out': 0, 'n_plate_fully_out': 0,
                            'phi_sum_gt_one': _neg_p, 'hold_reason_codes': ('NEGATIVE_POROSITY' if _neg_p else ''),
                            'physical_target_status': ('HOLD' if _neg_p else 'OK')}
        h['n_types'] = 3                                      # J20-f — 수확 JSON 의 type 수 (bimodal)
        return h

    def _u(case, eps_s=11.0, th=34.0, eps_u=14.0, se=0.6, n_se=100, n_am=11, status='OK', ub='True'):
        return {'case': case, 'eps_sphere_web': repr(eps_s), 'thickness_um': repr(th), 'mc_void_pct': repr(eps_u),
                'mc_void_se_pct': '0.014', 'eps_union_pair_clipped': repr(eps_u + 0.004), 'pair_upper_bound_ok': ub,
                'se_of_solid_vol': repr(se), 'n_SE': str(n_se), 'n_AM': str(n_am), 'status': status}
    _dq = [{'case_id': 'q1'}, {'case_id': 'q2'}]
    _hqs = {'q1': _hq('q1', eps_s=-2.0, th=30.0), 'q2': _hq('q2', eps_s=20.0, th=40.0)}
    #  ★ 10-06 (LREL-04) — union 의 SE/고체 = 수확 φ_SE/(φ_SE + φ_AM) (= V_SE/(V_SE + V_AM)) 와 같은 값.  옛 픽스처 (0.62 · 0.25) 는 φ 장부와
    #    모순이었다 (q1 0.5/1.02 · q2 0.5/0.8) — 생성기가 그 모순을 거부하게 된 뒤 같은 장부 값으로 맞춘다 (SE-rich 표지도 그 값을 따른다).
    _uq = {'q1': _u('q1', eps_s=-2.0, th=30.0, eps_u=6.5, se=0.5 / 1.02), 'q2': _u('q2', eps_s=20.0, th=40.0, eps_u=21.0, se=0.5 / 0.8),
           'perc': _u('perc', status='MISSING')}
    try:
        _oq, _cq, _rq = build_handover(_dq, _hqs, union=_uq)
        _eq = ''
    except Exception as e:                                                # noqa: BLE001
        _oq, _cq, _rq, _eq = [], [], {}, f'{type(e).__name__}: {e}'
    _q1 = next((r for r in _oq if r['case_id'] == 'q1'), {})
    _q2 = next((r for r in _oq if r['case_id'] == 'q2'), {})
    chk('⑱a J19 union 열 · 질량 보존 두께 · SE-rich 표지 (+ 통계 오차 · 쌍 렌즈 검산 · SE/고체 연속값) 가 인계표에 있다' + (f' — {_eq}' if _eq else ''),
        not _eq and all(c in _cq for c in ('porosity_union_exact_pct', 'porosity_union_exact_se_pct', 'porosity_union_pair_clipped_pct',
                                            'union_pair_upper_bound_ok', 'se_of_solid_vol', 'thickness_mass_conserving_um', 'se_rich')))
    chk('⑱b 병기 — 구 부피 합 열 (porosity_sphere_pct_RECORD_ONLY) 은 **원값 그대로** 남는다 (음수 −2.0 도 · 교체 아님)',
        _q1.get('porosity_sphere_pct_RECORD_ONLY') == repr(-2.0) and _q1.get('porosity_union_exact_pct') == repr(6.5))
    chk('⑱c 질량 보존 두께 = 두께 × (1 − ε_sphere)/(1 − ε_union) (같은 고체를 union 공극률로 받을 때의 두께)',
        _q1.get('thickness_mass_conserving_um') == repr(30.0 * (1 - (-2.0) / 100) / (1 - 6.5 / 100)))
    chk(f'⑱d SE-rich 표지 = SE/고체 ≥ {globals().get("SE_RICH_MIN")} (q1 0.490 → False · q2 0.625 → True) · 연속값도 함께',
        _q1.get('se_rich') == 'False' and _q2.get('se_rich') == 'True' and _q1.get('se_of_solid_vol') == repr(0.5 / 1.02))
    chk('⑱e 설계에 없는 union 행 (코호트의 perc) 은 인계표에 안 들어가고 보고에 남는다',
        len(_oq) == 2 and 'perc' in (_rq.get('union_extra') or []))
    chk('⑱e2 union 없이 부르면 옛 인계표 그대로 (union 열 없음 · 하위 호환)',
        'porosity_union_exact_pct' not in build_handover(_dq, _hqs)[1])
    _neg('⑱f union 에 설계 케이스가 없으면 거부 (부분 병기 금지)', lambda: build_handover(_dq, _hqs, union={'q1': _uq['q1']}))
    _neg('⑱g union 의 구 부피 합 porosity ≠ 수확 (다른 프레임 · 다른 수확의 union) 이면 거부',
         lambda: build_handover(_dq, _hqs, union=dict(_uq, q2=_u('q2', eps_s=20.5, th=40.0, eps_u=21.0))))
    _neg('⑱h union 두께 ≠ 수확 두께면 거부',
         lambda: build_handover(_dq, _hqs, union=dict(_uq, q2=_u('q2', eps_s=20.0, th=40.1, eps_u=21.0))))
    _neg('⑱i union 상별 입자 수 ≠ 수확이면 거부',
         lambda: build_handover(_dq, _hqs, union=dict(_uq, q2=_u('q2', eps_s=20.0, th=40.0, eps_u=21.0, n_se=99))))
    _neg('⑱j union status ≠ OK 면 거부',
         lambda: build_handover(_dq, _hqs, union=dict(_uq, q2=_u('q2', eps_s=20.0, th=40.0, eps_u=21.0, status='DELTA_MISMATCH'))))
    _hno = _hq('q2', eps_s=20.0, th=40.0)
    _hno.pop('handover_qc')
    _neg('⑱k 수확에 두께 (handover_qc) 가 없으면 union 을 붙이지 않는다 (09-24 판 수확 — 0925 판을 쓸 것)',
         lambda: build_handover(_dq, dict(_hqs, q2=_hno), union=_uq))
    #  ⑱m–r J20-e (1저자 09-29 밤 *"φ 는 (라) 에 해당하는 것만"*) — 질량 보존 φ = φ(구) × (1 − ε_union)/(1 − ε_sphere)
    #   = 재료 부피 / (L² · 질량 보존 두께).  인계 두께 (질량 보존) · porosity (union) 와 **같은 장부**다 — 옛 φ (구 부피 합 ÷ DEM 판 간격) 는
    #   union 과 닫히지 않는다 (130 중앙 +3.77 %p · 64 중앙 +10.91 %p).  겹침 배분 (union 점유 (가)~(다)) 은 쓰지 않는다.
    def _fl(x):
        try:
            return float(x)
        except (TypeError, ValueError):
            return float('nan')
    _km = (1 - 6.5 / 100) / (1 - (-2.0) / 100)
    chk('⑱m J20-e 질량 보존 φ 두 열 = 구 부피 합 φ × (1 − ε_union)/(1 − ε_sphere) (q1: 0.5 · 0.52 × 0.935/1.02)',
        abs(_fl(_q1.get('phi_se_mass_conserving')) - 0.5 * _km) < 1e-12
        and abs(_fl(_q1.get('phi_am_mass_conserving')) - 0.52 * _km) < 1e-12)
    _clo = [abs(_fl(r.get('phi_se_mass_conserving')) + _fl(r.get('phi_am_mass_conserving'))
                + _fl(r.get('porosity_union_exact_pct')) / 100 - 1) for r in (_q1, _q2)]
    chk('⑱n 닫힘 — φ_SE + φ_AM + ε_union = 1 (1e-12 · q1 · q2)', max(_clo) < 1e-12)
    _ldg = [abs(_fl(r.get(f'phi_{p}_mass_conserving')) * _fl(r.get('thickness_mass_conserving_um'))
                - _fl(r.get(f'phi_{p}')) * _fl(r.get('thickness_wall_gap_um'))) for r in (_q1, _q2) for p in ('se', 'am')]
    chk('⑱o 적재량 보존 — φ(질량 보존) × 질량 보존 두께 = φ(구) × 판 간격 두께 (= 재료 부피 / L²) (1e-9 µm)', max(_ldg) < 1e-9)
    chk('⑱p 옛 φ (구 부피 합 ÷ 판 간격) 는 union 과 **안 닫힌다** — 잔차 = (ε_union − ε_sphere)/100 (q1 +0.085) · 그래서 새 열',
        abs(_fl(_q1.get('phi_se')) + _fl(_q1.get('phi_am')) + 0.065 - 1 - 0.085) < 1e-12)
    _hbad = dict(_hqs['q2'], status=dict(_hqs['q2']['status'], phi='N_A_TEST'))
    _b2 = next((r for r in build_handover(_dq, dict(_hqs, q2=_hbad), union=_uq)[0] if r['case_id'] == 'q2'), {})
    chk('⑱q φ status ≠ OK 면 질량 보존 φ 도 빈칸 (0 이 아니다 · 계약 ②)',
        _b2.get('phi_se_mass_conserving') == '' and _b2.get('phi_am_mass_conserving') == '')
    _cdq = {d['column']: d for d in column_dictionary(_cq)}
    chk('⑱r 열 사전 — 질량 보존 φ 두 열: 출처 union · 뜻에 J20-e · 옛 phi_se 뜻에 인계용 열 안내',
        all(_cdq.get(c, {}).get('source') == 'union' and 'J20-e' in _cdq.get(c, {}).get('meaning', '')
            for c in ('phi_se_mass_conserving', 'phi_am_mass_conserving'))
        and 'phi_se_mass_conserving' in _cdq.get('phi_se', {}).get('meaning', ''))
    #  ⑱l 실물 — 동결 설계 CSV 130 · 기본 수확 (0925) · 기본 union TSV
    _rt = pathlib.Path(__file__).resolve().parent.parent
    _dp_, _up_, _hd_ = (_rt / DESCRIPTOR_FILL_EXPECTED['path'], _rt / str(globals().get('DEFAULT_UNION_TSV', '')),
                        _rt / DEFAULT_HARVEST_DIR)
    try:
        with _dp_.open(encoding='utf-8-sig') as _fh:
            _rows_ = list(csv.DictReader(_fh))
        _ol, _cl, _rl = build_handover(_rows_, load_harvest(_hd_), union=load_union(_up_))
        _eu = [float(r['porosity_union_exact_pct']) for r in _ol]
        _ra = sorted(float(r['thickness_mass_conserving_um']) / float(r['thickness_wall_gap_um']) for r in _ol)
        _ns = sum(r['se_rich'] == 'True' for r in _ol)
        _neg_s = sum(float(r['porosity_sphere_pct_RECORD_ONLY']) < 0 for r in _ol)
        chk(f'⑱l 실물 130 (설계 CSV · 0925 수확 · union TSV) — {len(_ol)} 행 전부 병기 · union 최소 {min(_eu):.2f} % > 0 · '
            f'질량 보존 비 {_ra[0]:.3f}–{_ra[-1]:.3f} (중앙 {_ra[len(_ra) // 2]:.3f}) ≥ 1 · SE-rich {_ns} · 구 부피 합 음수 {_neg_s}',
            len(_ol) == 130 and min(_eu) > 0 and _ra[0] >= 1.0)
        _cm = max(abs(float(r['phi_se_mass_conserving']) + float(r['phi_am_mass_conserving'])
                      + float(r['porosity_union_exact_pct']) / 100 - 1) for r in _ol)
        _sr = max(abs(float(r['phi_se_mass_conserving'])
                      / (float(r['phi_se_mass_conserving']) + float(r['phi_am_mass_conserving'])) - float(r['se_of_solid_vol']))
                  for r in _ol)
        chk(f'⑱l2 실물 130 — 질량 보존 φ 닫힘 최대 {_cm:.1e} · SE/고체 ↔ union se_of_solid_vol (다른 코드 · 같은 덤프) 최대 차 {_sr:.1e} (≤ 1e-9)',
            _cm <= 1e-9 and _sr <= 1e-9)
    except Exception as e:                                                # noqa: BLE001
        chk(f'⑱l 실물 130 병기 ({type(e).__name__}: {e})', False)

    #  ═══ ⑲ J20 (1저자 비준 09-28 — "벽 기준 τ 새 열" · "✅ 만 이번에" · "채운 뒤 넘김") ═══════════════════════════════
    #   (1) 수확 v3 의 벽 τ 를 **새 열**로 — 값은 status OK 일 때만 (계약 ②) · 옛 τ 는 계속 보류 · 수확 세대가 섞이면 거부
    #   (2) 웹앱 파이프라인 열 (scripts/lhs_webapp_batch.py) 중 전수 판정 ✅ 만 — 같은 프레임 관문 (웹앱 porosity = 수확 porosity)
    _WC = 'harvest_v3/wall_z0_plate/rSEmax/no_fallback/same_component'

    def _tw(status='OK', mean=1.7, med=1.65):
        return {'tau_mean': (mean if status == 'OK' else None), 'tau_median': (med if status == 'OK' else None),
                'tau_mean_untruncated': (mean if status == 'OK' else None), 'status': status,
                'n_sampled': 200, 'n_valid': (200 if status == 'OK' else 0), 'n_truncated': 0,
                'n_span_components': (1 if status == 'OK' else 0), 'tau_convention': _WC}
    _hw = {'q1': dict(_hqs['q1'], tau_wall_detail=_tw()), 'q2': dict(_hqs['q2'], tau_wall_detail=_tw('NOT_PERCOLATING'))}
    try:
        _ow, _cw, _rw = build_handover(_dq, _hw)
        _ew = ''
    except Exception as e:                                                # noqa: BLE001
        _ow, _cw, _rw, _ew = [], [], {}, f'{type(e).__name__}: {e}'
    _w1 = next((r for r in _ow if r['case_id'] == 'q1'), {})
    _w2 = next((r for r in _ow if r['case_id'] == 'q2'), {})
    chk('⑲a 벽 τ 새 열 — OK 행은 값 · 미관통 행은 **빈칸** + status (0 이 아니다) · 규약 문자열' + (f' — {_ew}' if _ew else ''),
        _w1.get('tortuosity_SE_wall') == repr(1.7) and _w1.get('tortuosity_SE_wall_median') == repr(1.65)
        and _w2.get('tortuosity_SE_wall') == '' and _w2.get('tortuosity_SE_wall_status') == 'NOT_PERCOLATING'
        and _w1.get('tau_wall_convention') == _WC)
    chk('⑲b 옛 τ (solid_zrange) 는 여전히 보류 — tortuosity_dijkstra_SE 열이 없다 (LHS-08)',
        'tortuosity_dijkstra_SE' not in _cw and 'tortuosity_dijkstra_SE' in _rw.get('held_back', {}))
    _neg('⑲c 수확 세대가 섞이면 거부 (벽 τ 가 일부 JSON 에만 있다)',
         lambda: build_handover(_dq, {'q1': _hw['q1'], 'q2': _hqs['q2']}))
    chk('⑲d 벽 τ 가 없는 옛 수확이면 그 열 없이 옛 인계표 그대로 (하위 호환)',
        'tortuosity_SE_wall' not in build_handover(_dq, _hqs)[1])
    _neg('⑲e 벽 τ 규약 문자열이 다르면 거부 (다른 규약의 값을 같은 열에 넣지 않는다)',
         lambda: build_handover(_dq, {'q1': _hw['q1'], 'q2': dict(_hqs['q2'], tau_wall_detail=dict(_tw(), tau_convention='x'))}))

    _vd = {'se_se_cn': '✅ 쓴다', 'coverage_AM_P_mean': '✅ 쓴다(이름 주의)', 'phi_se': '✅ 쓴다', 'porosity': '✅ 쓴다',
           'sigma_full_mScm': '🔶 행 선별', 'coverage_AM_P_mean_physics': '🔧 재실행', 'case': '· 식별자'}
    _why = {k: f'why:{k}' for k in _vd}

    def _wa(q1=None, q2=None, st1='done', st2='done'):
        r1 = {'case': 'q1', 'se_se_cn': '4.25', 'coverage_AM_P_mean': '13.1', 'phi_se': '', 'porosity': repr(-2.0),
              'sigma_full_mScm': '0.08', 'coverage_AM_P_mean_physics': '31.0'}
        r2 = {'case': 'q2', 'se_se_cn': '6.5', 'coverage_AM_P_mean': '20.0', 'phi_se': '0.5', 'porosity': repr(20.0),
              'sigma_full_mScm': '0.2', 'coverage_AM_P_mean_physics': '40.0'}
        r1.update(q1 or {})
        r2.update(q2 or {})
        return {'verdict': dict(_vd), 'why': dict(_why),
                'status': {'q1': {'status': st1, 'failed_stages': [], 'sha': dict(_RAW_SHA)},
                           'q2': {'status': st2, 'failed_stages': ['Stage E'], 'sha': dict(_RAW_SHA)}},
                'rows': {'q1': r1, 'q2': r2}}
    try:
        _oa, _ca, _ra = build_handover(_dq, _hqs, webapp=_wa(st2='partial'), wa_reviewed_only=False)   # 옛 기제 (census ✅ 선별) 시험
        _ea = ''
    except Exception as e:                                                # noqa: BLE001
        _oa, _ca, _ra, _ea = [], [], {}, f'{type(e).__name__}: {e}'
    _a1 = next((r for r in _oa if r['case_id'] == 'q1'), {})
    _a2 = next((r for r in _oa if r['case_id'] == 'q2'), {})
    chk('⑲f 웹앱 ✅ 열만 들어간다 (🔶 σ · 🔧 Physics · 식별자는 안 들어간다) · 이름은 코퍼스 그대로' + (f' — {_ea}' if _ea else ''),
        not _ea and 'se_se_cn' in _ca and 'coverage_AM_P_mean' in _ca and 'porosity' in _ca
        and 'sigma_full_mScm' not in _ca and 'coverage_AM_P_mean_physics' not in _ca
        and _a1.get('se_se_cn') == '4.25')
    chk('⑲g 이름 충돌 (phi_se) 은 수확 열이 정본 — 웹앱 값은 안 덮고 보고에 남긴다',
        _a2.get('phi_se') == repr(0.5) and 'phi_se' in (_ra.get('wa_collisions') or []))
    chk('⑲h 같은 프레임 QC 열 — 웹앱 porosity − 수확 porosity (여기선 0) · 행 상태 (done · partial) · 실패 단계',
        _a1.get('qc_wa_porosity_minus_harvest_pct') == repr(0.0) and _a1.get('wa_status') == 'done'
        and _a2.get('wa_status') == 'partial' and _a2.get('wa_failed_stages') == 'Stage E')
    _neg('⑲i ★ 웹앱 porosity ≠ 수확 porosity (0.05 %p 넘게) → 거부 — 다른 프레임의 웹앱 행을 붙이지 않는다',
         lambda: build_handover(_dq, _hqs, webapp=_wa(q2={'porosity': repr(20.5)})))
    _oa3, _ca3, _ra3 = build_handover(_dq, _hqs, webapp=_wa(st2='REFUSED'), wa_reviewed_only=False)
    _a3 = next((r for r in _oa3 if r['case_id'] == 'q2'), {})
    chk('⑲j 배치가 거부 · 실패한 행은 웹앱 열이 **빈칸** + wa_status (0 이 아니다) · 보고에 셈',
        _a3.get('wa_status') == 'REFUSED' and _a3.get('se_se_cn') == '' and _ra3.get('wa_status_counts', {}).get('REFUSED') == 1)
    _wm = _wa()
    _wm['status'].pop('q2')
    _neg('⑲k 배치가 **시도하지 않은** 설계행이 있으면 거부 (배치 미완)', lambda: build_handover(_dq, _hqs, webapp=_wm))
    _neg('⑲l done 행에 porosity 가 없으면 거부 (같은 프레임을 확인할 수 없다)',
         lambda: build_handover(_dq, _hqs, webapp=_wa(q1={'porosity': ''})))
    _dct = column_dictionary(_ca, webapp=_wa()) if 'column_dictionary' in globals() else []
    _dm = {d['column']: d for d in _dct}
    chk('⑲m 열 사전 — 모든 열에 출처 · 설명 · (웹앱 열은) 판정 · 이름 주의 표지',
        len(_dct) == len(_ca) and _dm.get('se_se_cn', {}).get('source') == 'webapp'
        and _dm.get('coverage_AM_P_mean', {}).get('caveat', '').startswith('A_dem_geometric')
        and _dm.get('case_id', {}).get('source') == 'design' and all(d.get('meaning') for d in _dct))
    try:
        sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent))
        import lhs_descriptor_harvest as _LDH
        _hc = getattr(_LDH, 'TAU_WALL_CONVENTION', None)
    except Exception as e:                                                # noqa: BLE001
        _hc = f'{type(e).__name__}: {e}'
    chk('⑲n 벽 τ 규약 문자열 — 생성기 = 수확기 (`lhs_descriptor_harvest.TAU_WALL_CONVENTION`) · 한쪽만 바뀌면 걸린다',
        _hc == TAU_WALL_CONVENTION)

    #  ═══ ⑲o–p J20-a (1저자 비준 09-28 밤 "권고하는걸로") — ⓒ 접촉 위상 열의 정의 · ⓓ 상별 벽 접촉 비율 새 열 ═══════════════
    _vd2 = dict(_vd, am_se_cn_mean='✅ 쓴다', am_se_cn_surface_weighted='✅ 쓴다', AM_P_se_cn_mean='✅ 쓴다',
                am_am_cn='✅ 쓴다', am_am_n_contacts='✅ 쓴다', area_SE_SE_n='✅ 쓴다(이름 주의)',
                area_SE_SE_total='✅ 쓴다(이름 주의)')
    _cols2 = list(_vd2)
    _dm2 = {d['column']: d for d in column_dictionary(_cols2, webapp={'verdict': _vd2, 'why': {k: f'why:{k}' for k in _vd2}})}
    _g = lambda c, k: (_dm2.get(c) or {}).get(k, '')                        # noqa: E731
    chk('⑲o ⓒ CN 정의 — 분모 (전 입자 · 접촉 0 · 벽 입자 포함) 와 벽 효과 주의 · 파생 열 (AM–SE 전체 · 표면 가중) 표시',
        '전 입자' in _g('se_se_cn', 'meaning') and '벽' in _g('se_se_cn', 'caveat')
        and '파생' in _g('am_se_cn_mean', 'caveat') and '파생' in _g('am_se_cn_surface_weighted', 'caveat')
        and 'AM_P' in _g('AM_P_se_cn_mean', 'meaning') and '벽' in _g('AM_P_se_cn_mean', 'caveat')
        and 'AM_P–AM_S' in _g('am_am_cn', 'meaning'))
    chk('⑲o ⓒ 접촉 개수 열은 **총량** 주의 — area_*_n 에 면적 (A_dem_geometric) 주의를 붙이지 않는다 · 면적 열은 그대로',
        _g('area_SE_SE_n', 'caveat').startswith('총량') and not _g('area_SE_SE_n', 'caveat').startswith('A_dem_geometric')
        and _g('am_am_n_contacts', 'caveat').startswith('총량')
        and _g('area_SE_SE_total', 'caveat').startswith('A_dem_geometric')
        and _g('coverage_AM_P_mean', 'caveat').startswith('A_dem_geometric'))
    _wt3 = {'SE': {'n': 3, 'floor': 0.25, 'plate': 0.125}, 'AM_P': {'n': 2, 'floor': 0.5, 'plate': 0.5},
            'AM_S': {'n': 4, 'floor': 0.0, 'plate': 0.25}, 'AM': {'n': 6, 'floor': 1 / 6, 'plate': 1 / 3}}
    _wt2 = {'SE': {'n': 3, 'floor': 0.5, 'plate': 0.0}, 'AM': {'n': 2, 'floor': 1.0, 'plate': 0.0}}
    _hwt = {'q1': dict(_hqs['q1'], wall_touch=_wt3), 'q2': dict(_hqs['q2'], wall_touch=_wt2)}
    try:
        _ot, _ct, _rt = build_handover(_dq, _hwt)
        _et = ''
    except Exception as e:                                                # noqa: BLE001
        _ot, _ct, _rt, _et = [], [], {}, f'{type(e).__name__}: {e}'
    _t1 = next((r for r in _ot if r['case_id'] == 'q1'), {})
    _t2 = next((r for r in _ot if r['case_id'] == 'q2'), {})
    chk('⑲p ⓓ 상별 벽 접촉 비율 새 열 — 값 · 없는 상 (2-type 의 AM_P · AM_S) 은 **빈칸** (0 이 아니다)' + (f' — {_et}' if _et else ''),
        not _et and _t1.get('wall_touch_frac_AM_P_floor') == repr(0.5) and _t1.get('wall_touch_frac_SE_plate') == repr(0.125)
        and _t2.get('wall_touch_frac_AM_P_floor') == '' and _t2.get('wall_touch_frac_AM_floor') == repr(1.0)
        and 'wall_touch_frac_AM_S_plate' in _ct)
    _neg('⑲p ⓓ 수확 세대가 섞이면 거부 (wall_touch 가 일부 JSON 에만 있다)',
         lambda: build_handover(_dq, {'q1': _hwt['q1'], 'q2': _hqs['q2']}))
    _dm3 = {d['column']: d for d in column_dictionary(_ct)}
    chk('⑲p ⓓ 벽 비율이 없는 옛 수확이면 그 열 없이 (하위 호환) · 열 사전에 출처 harvest_v3 · 규칙 설명',
        'wall_touch_frac_SE_floor' not in build_handover(_dq, _hqs)[1]
        and _dm3.get('wall_touch_frac_SE_floor', {}).get('source') == 'harvest_v3'
        and 'z − r' in _dm3.get('wall_touch_frac_SE_floor', {}).get('meaning', ''))

    #  ⑲q–u 묶음별 (1저자 09-29 밤 *"단독적으로 하나씩 돌려서 표를 채워나갈 거야"*) — webapp_groups='contact' 는 **접촉 분석 단계가
    #   내는** ① 열만 싣는다.  접촉 단계만 돈 배치 (status.json stop_after=contact) 를 묶음 제한 없이 부르면 거부한다 — 뒤 단계 열이
    #   빈칸으로 들어가 '측정된 N/A' 처럼 읽힌다.  ① 사전 (WA_DEFINE) 중 A_binding_*_n_contacts (피복 단계) ·
    #   n_am_am_contacts_* (파괴 네트워크) 는 접촉 단계 산출이 아니다 → 이 묶음에서 뺀다.
    _vd2 = dict(_vd, am_am_cn='✅ 쓴다', AM_P_se_cn_mean='✅ 쓴다', area_SE_SE_n='✅ 쓴다', percolation_pct='✅ 쓴다',
                A_binding_total_n_contacts='✅ 쓴다', n_am_am_contacts_total='✅ 쓴다')

    def _wa2(stop=None):
        w = _wa()
        w['verdict'] = dict(_vd2)
        w['why'] = {k: f'why:{k}' for k in _vd2}
        for r in w['rows'].values():
            r.update(am_am_cn='1.2', AM_P_se_cn_mean='7.0', area_SE_SE_n='900', percolation_pct='',
                     A_binding_total_n_contacts='', n_am_am_contacts_total='',
                     se_se_cn='18.0')                             # J20-i 항등식 — 2 × 900 / SE 100
        if stop:
            w['stop_after'] = stop
        return w
    try:
        _og, _cg, _rg = build_handover(_dq, _hqs, webapp=_wa2('contact'), webapp_groups='contact', wa_reviewed_only=False)
        _eg = ''
    except Exception as e:                                                # noqa: BLE001
        _og, _cg, _rg, _eg = [], [], {}, f'{type(e).__name__}: {e}'
    chk('⑲q ★ webapp_groups=contact — 웹앱 열은 접촉 단계 ① 만 (se_se_cn · am_am_cn · AM_P_se_cn_mean · area_SE_SE_n) · '
        'porosity · coverage · percolation · A_binding · n_am_am_contacts 는 없다' + (f' — {_eg}' if _eg else ''),
        not _eg and all(c in _cg for c in ('se_se_cn', 'am_am_cn', 'AM_P_se_cn_mean', 'area_SE_SE_n'))
        and not any(c in _cg for c in ('porosity', 'coverage_AM_P_mean', 'percolation_pct',
                                       'A_binding_total_n_contacts', 'n_am_am_contacts_total')))
    _neg('⑲r ★ 접촉 단계만 돈 배치 (stop_after=contact) 를 묶음 제한 없이 부르면 거부 — 뒤 단계 열이 빈칸 = N/A 로 읽힌다',
         lambda: build_handover(_dq, _hqs, webapp=_wa2('contact')))
    _neg('⑲s 모르는 묶음 이름은 거부 (⑤⑥⑦ 뒤 f1 · fracture · area 는 아는 묶음 — stress 로 · ④b 새 열은 아직 인계 묶음이 아니다)',
         lambda: build_handover(_dq, _hqs, webapp=_wa2(), webapp_groups='stress'))
    _g1 = next((r for r in _og if r['case_id'] == 'q1'), {})
    chk('⑲t 같은 프레임 관문은 그대로 — 웹앱 porosity (접촉 단계 산출) − 수확 porosity 가 QC 열에 (여기선 0)',
        _g1.get('qc_wa_porosity_minus_harvest_pct') == repr(0.0) and _g1.get('am_am_cn') == '1.2')
    import shutil
    import tempfile
    _tdw = pathlib.Path(tempfile.mkdtemp(prefix='lhsdd_wa_'))
    try:
        (_tdw / 'status.json').write_text(json.dumps({'schema': 'lhs_webapp_batch/v1', 'stop_after': 'contact', 'cases': {}}),
                                          encoding='utf-8')
        (_tdw / 'metrics_flat.csv').write_text('case\n', encoding='utf-8')
        _lw = load_webapp(_tdw)
        chk('⑲u load_webapp 이 배치의 stop_after 를 넘긴다 (묶음 관문의 근거)', _lw.get('stop_after') == 'contact')
    except Exception as e:                                                # noqa: BLE001
        chk(f'⑲u load_webapp stop_after ({type(e).__name__}: {e})', False)
    finally:
        shutil.rmtree(_tdw, ignore_errors=True)

    #  ⑳ J20-g (1저자 비준 09-30 "권고대로") — 표에는 **1저자와 함수 단위로 같이 확인한 열만** 싣는다 (census ✅ 는 필요조건일 뿐)
    #   · J20-k (B) (1저자 09-30 · J20-f (A) 개정): mono (2-type) 침대의 **상별** 웹앱 열은 **설계 상 칸** (block) 에 싣는다 — 웹앱은 mono 의
    #   AM 을 반지름으로 AM_P/AM_S 라 부르고 설계 상과 어긋나는 침대가 있다 (130 의 5 · 64 의 4) → 그 이름의 값을 설계 이름 칸으로 옮기고
    #   (wa_mono_phase_name_webapp 에 웹앱 이름을 남긴다) 설계에 없는 상의 칸은 빈칸 (N/A).  총량 열 (area_AM전체_SE_n · area_SE_SE_n) 은 그대로.
    _vd3 = dict(_vd, am_am_cn='✅ 쓴다', AM_P_se_cn_mean='✅ 쓴다', AM_S_se_cn_mean='✅ 쓴다', area_SE_SE_n='✅ 쓴다',
                area_AM_S_SE_n='✅ 쓴다', area_AM_P_SE_n='✅ 쓴다', **{'area_AM전체_SE_n': '✅ 쓴다'},
                se_se_cn_std='✅ 쓴다', se_se_cn_perc='✅ 쓴다', se_se_cn_eff_area='✅ 쓴다(이름 주의)', se_se_cn_aug='✅ 쓴다',
                am_am_cn_std='✅ 쓴다', am_am_n_contacts='✅ 쓴다', am_am_mean_area='✅ 쓴다(이름 주의)',
                am_am_total_area='✅ 쓴다(이름 주의)')

    def _wa3():
        w = _wa()
        w['verdict'] = dict(_vd3)
        w['why'] = {k: f'why:{k}' for k in _vd3}
        w['stop_after'] = 'contact'
        #  se_se_cn = 2 × area_SE_SE_n / SE 입자 수 (수확 phase_counts SE 100) — J20-i 항등식에 맞춘 값 · 같은 함수의 나머지 출력도 싣는다
        #  J20-j — am_am_n_contacts = AM–AM 쌍 개수 합 · am_am_cn = 2 × am_am_n_contacts / AM 입자 수 (11) 에 맞춘 값
        #  7c G1 — 상별 AM–SE 평균 × 상 입자 수 = area_<상>_SE_n (q1 mono 40 / 11 · q2 30 / 1 · 50 / 10) — 옛 값 3.0 · 7.0 · 3.5 는 모순이었다
        w['rows']['q1'].update(am_am_cn='2.0', AM_S_se_cn_mean=repr(40 / 11), area_SE_SE_n='900', area_AM_S_SE_n='40',
                               se_se_cn='18.0', se_se_cn_std='2.5', se_se_cn_perc='18.5', se_se_cn_eff_area='0.07',
                               se_se_cn_aug='19.0', area_AM_S_AM_S_n='11', am_am_n_contacts='11', am_am_cn_std='1.0',
                               am_am_mean_area='0.02', am_am_total_area='0.22',
                               **{'area_AM전체_SE_n': '40'})   # q1 = mono (웹앱 반지름 이름 AM_S)
        w['rows']['q2'].update(am_am_cn='4.0', AM_P_se_cn_mean='30.0', AM_S_se_cn_mean='5.0', area_SE_SE_n='800',
                               area_AM_P_SE_n='30', area_AM_S_SE_n='50', se_se_cn='16.0', se_se_cn_std='3.0',
                               se_se_cn_perc='16.5', se_se_cn_eff_area='0.06', se_se_cn_aug='17.0',
                               area_AM_P_AM_S_n='5', area_AM_S_AM_S_n='17', am_am_n_contacts='22', am_am_cn_std='1.5',
                               am_am_mean_area='0.03', am_am_total_area='0.66',
                               **{'area_AM전체_SE_n': '80'})
        return w
    def _mono_h(h, n_am=11, n_se=100):
        """bimodal 수확 픽스처 → 수확기의 2-type 모양 (상 라벨 AM 하나 · coverage 상별 N_A · AM_only = 전체)."""
        return dict(h, n_types=2, phase_counts={'AM': n_am, 'SE': n_se},
                    coverage_AM_P_hertz_pct=None, coverage_AM_S_hertz_pct=None,
                    coverage_AM_only_hertz_pct=h['coverage_AM_total_hertz_pct'],
                    status=dict(h['status'], coverage_AM_P='N_A_PHASE_ABSENT', coverage_AM_S='N_A_PHASE_ABSENT'),
                    coverage_detail=dict(h['coverage_detail'],
                                         counts={'AM_P': {'n_valid': 0}, 'AM_S': {'n_valid': 0}, 'AM': {'n_valid': n_am}}))
    _hq3 = {'q1': _mono_h(_hqs['q1']), 'q2': dict(_hqs['q2'], n_types=3)}
    #  ⑳ 부터 설계행에 block — J20-k (B) 는 설계 상을 block 으로 정한다 (q1 = 설계 mono_AM_P · 웹앱 반지름 이름 AM_S = 이름이 어긋나는 침대)
    _dq = [{'case_id': 'q1', 'block': 'mono_AM_P'}, {'case_id': 'q2', 'block': 'bimodal'}]
    try:
        _o20, _c20, _r20 = build_handover(_dq, _hq3, webapp=_wa3(), webapp_groups='contact')
        _e20 = ''
    except Exception as e:                                                # noqa: BLE001
        _o20, _c20, _r20, _e20 = [], [], {}, f'{type(e).__name__}: {e}'
    _m20 = next((r for r in _o20 if r['case_id'] == 'q1'), {})
    _b20 = next((r for r in _o20 if r['case_id'] == 'q2'), {})
    chk('⑳a ★ J20-g — 같이 확인한 열만: 접촉 묶음 중 area_<쌍>_n (· J20-i se_se_cn · J20-j am_am_* · 7c AM_*_se_cn_* — 7c 부터 실린다 · '
        'mono 는 설계 상 칸)' + (f' — {_e20}' if _e20 else ''),
        not _e20 and all(c in _c20 for c in ('area_SE_SE_n', 'area_AM_S_SE_n', 'area_AM_P_SE_n', 'area_AM전체_SE_n',
                                             'AM_P_se_cn_mean', 'AM_S_se_cn_mean'))
        and _m20.get('AM_P_se_cn_mean') == repr(40 / 11) and _m20.get('AM_S_se_cn_mean') == ''
        and _b20.get('AM_P_se_cn_mean') == '30.0' and _b20.get('AM_S_se_cn_mean') == '5.0')
    chk('⑳b ★ J20-k (B) — mono (설계 mono_AM_P · 웹앱 이름 AM_S) 의 상별 쌍 값은 **설계 상 칸** (area_AM_P_SE_n) 으로 · 없는 상 칸 (area_AM_S_SE_n) '
        '빈칸 · 총량 쌍 그대로 · 웹앱 이름을 wa_mono_phase_name_webapp 에 · 보고 (옮김 1 건 · 채움 2 · 빈칸 2 — 쌍 개수 + 7c AM–SE 평균)',
        _m20.get('area_AM_P_SE_n') == '40' and _m20.get('area_AM_S_SE_n') == ''
        and _m20.get('area_AM전체_SE_n') == '40' and _m20.get('area_SE_SE_n') == '900'
        and _m20.get('wa_mono_phase_name_webapp') == 'AM_S' and _b20.get('wa_mono_phase_name_webapp') == ''
        and _m20.get('block') == 'mono_AM_P'
        and _r20.get('wa_mono_renamed_cases') == 1 and _r20.get('wa_mono_design_filled') == 2
        and _r20.get('wa_mono_absent_blanked') == 2 and 'wa_mono_phase_blanked' not in _r20)
    chk('⑳c bimodal (n_types 3) 은 상별 쌍 값 그대로',
        _b20.get('area_AM_P_SE_n') == '30' and _b20.get('area_AM_S_SE_n') == '50' and _b20.get('area_AM전체_SE_n') == '80')
    chk('⑳d 판별 — wa_reviewed (area_<쌍>_n · se_se_cn(_std) · am_am_cn(_std) · am_am_n_contacts · 7c AM–SE CN · 고립 — _perc 는 ② 뒤 · '
        '_eff_area · _aug · am_am 면적은 ⑤⑦ 뒤 (J20-s) 검토됨 · AM_*_n_particles · path_hop_area 는 아님) · '
        'wa_phase_specific (AM_P/AM_S 이름이 든 열 · AM전체 · 소문자 am_ 은 아님)',
        'wa_reviewed' in globals() and 'wa_phase_specific' in globals()
        and globals()['wa_reviewed']('area_AM_P_SE_n') and globals()['wa_reviewed']('se_se_cn')
        and globals()['wa_reviewed']('se_se_cn_std') and globals()['wa_reviewed']('se_se_cn_perc')     # ② 뒤 (J20-b) 검토됨
        and globals()['wa_reviewed']('se_se_cn_eff_area') and globals()['wa_reviewed']('se_se_cn_aug')      # ⑤⑦ 뒤 (J20-s) 검토됨
        and not globals()['wa_reviewed']('path_hop_area_mean')
        and globals()['wa_reviewed']('am_am_cn') and globals()['wa_reviewed']('am_am_cn_std')
        and globals()['wa_reviewed']('am_am_n_contacts') and globals()['wa_reviewed']('am_am_mean_area')
        and globals()['wa_reviewed']('am_am_total_area') and globals()['wa_reviewed']('AM_P_se_cn_mean')
        and globals()['wa_reviewed']('am_se_cn_median') and globals()['wa_reviewed']('AM_S_vulnerable_pct')
        and not globals()['wa_reviewed']('AM_P_n_particles') and not globals()['wa_reviewed']('am_se_cn_mean_x')
        and globals()['wa_phase_specific']('area_AM_S_AM_S_n') and globals()['wa_phase_specific']('AM_P_se_cn_mean')
        and not globals()['wa_phase_specific']('area_AM전체_SE_n') and not globals()['wa_phase_specific']('am_am_cn'))
    _neg('⑳e ★ 상별 열을 싣는데 수확 JSON 에 n_types 가 없으면 거부 (mono 인지 모른다 — 반지름 이름을 그대로 싣지 않는다)',
         lambda: build_handover(_dq, {k: {kk: vv for kk, vv in v.items() if kk != 'n_types'} for k, v in _hqs.items()},
                                webapp=_wa3(), webapp_groups='contact'))
    _d20 = {d['column']: d for d in column_dictionary(_c20, webapp=_wa3())} if _c20 else {}
    chk('⑳f 열 사전 — 상별 쌍 열의 뜻에 mono 설계 상 칸 규약 (J20-k (B)) · 검토 기록 (J20-g) · 총량 열에는 mono 규약 없음',
        'mono' in _d20.get('area_AM_S_SE_n', {}).get('meaning', '') and 'J20-k' in _d20.get('area_AM_S_SE_n', {}).get('meaning', '')
        and '설계 상 칸' in _d20.get('area_AM_P_SE_n', {}).get('meaning', '')
        and 'J20-g' in _d20.get('area_SE_SE_n', {}).get('meaning', '')
        and '설계 상 칸' not in _d20.get('area_SE_SE_n', {}).get('meaning', '')
        and '설계 상 칸' not in _d20.get('am_am_cn', {}).get('meaning', ''))

    #  ⑳g–l J20-h (1저자 비준 09-30 — *"bimodal 에서 빠진 쌍을 0 으로 채우게 · 시험 먼저"*) — 웹앱 `calc_interface_area` 는 접촉이 0 인
    #   쌍의 키를 **만들지 않는다** → metrics_flat 에서 빈칸.  bimodal 에서 그 뜻은 **측정된 0** 이지 N/A 가 아니다 (09-30 실측: 130 에서
    #   `area_AM_P_AM_P_n` 3 건 · 64 에서 6 건 — AM_P 3–16 알 침대).  규칙: 웹앱 행이 있고 (done · partial) · 쌍 개수 열이고 · 쌍의 두 상이
    #   수확 `phase_counts` 에 **있으면** 0 · mono 상별 칸은 J20-f (A) 대로 빈칸 · 상이 없으면 빈칸 (N/A) · `phase_counts` 가 없으면 거부.
    def _wa4(st2='done'):
        w = _wa3()
        w['verdict'].update(area_AM_P_AM_P_n='✅ 쓴다', area_AM_S_AM_S_n='✅ 쓴다')
        w['why'] = {k: f'why:{k}' for k in w['verdict']}
        w['rows']['q1'].update(area_AM_S_AM_S_n='11')            # mono — 반지름 이름 AM_S · AM_P_AM_P 키 없음 (J20-j 값과 같게)
        w['rows']['q2'].update(area_AM_S_AM_S_n='17')            # bimodal — AM_P_AM_P 키 없음 (접촉 0) · J20-j 합 5 + 17 = 22
        w['status']['q2']['status'] = st2
        return w
    try:
        _o21, _c21, _r21 = build_handover(_dq, _hq3, webapp=_wa4(), webapp_groups='contact')
        _e21 = ''
    except Exception as e:                                                # noqa: BLE001
        _o21, _c21, _r21, _e21 = [], [], {}, f'{type(e).__name__}: {e}'
    _m21 = next((r for r in _o21 if r['case_id'] == 'q1'), {})
    _b21 = next((r for r in _o21 if r['case_id'] == 'q2'), {})
    chk('⑳g ★ J20-h — bimodal 의 빠진 쌍 개수 = 0 (측정된 0) · 있는 값은 그대로 · 보고에 셈' + (f' — {_e21}' if _e21 else ''),
        _b21.get('area_AM_P_AM_P_n') == '0' and _b21.get('area_AM_S_AM_S_n') == '17'
        and _r21.get('wa_pair_zero_filled') == 1)
    chk('⑳h ★ J20-k (B) mono — 웹앱 AM_S_AM_S 개수 (11) 가 설계 상 칸 area_AM_P_AM_P_n 으로 · 없는 상 칸 area_AM_S_AM_S_n 빈칸 · 총량 그대로',
        _m21.get('area_AM_P_AM_P_n') == '11' and _m21.get('area_AM_S_AM_S_n') == '' and _m21.get('area_AM전체_SE_n') == '40')
    _hq4 = dict(_hq3, q2=dict(_hq3['q2'], phase_counts={'AM_P': 0, 'AM_S': 10, 'SE': 100}))
    _wa4i = _wa4()
    _wa4i['rows']['q2'].pop('area_AM_P_AM_S_n', None)                # AM_P 가 없는 침대 — AM_P 가 낀 쌍도 없다 (J20-j 항등식과 앞뒤를 맞춤)
    _wa4i['rows']['q2'].pop('AM_P_se_cn_mean', None)                 # · AM_P 의 AM–SE 값도 없다 (7c 상 없음 관문과 앞뒤를 맞춤)
    _wa4i['rows']['q2'].update(am_am_n_contacts='17', am_am_cn='3.4')  # 2 × 17 / AM 10
    try:
        _b22 = next((r for r in build_handover(_dq, _hq4, webapp=_wa4i, webapp_groups='contact')[0] if r['case_id'] == 'q2'), {})
    except Exception as e:                                                # noqa: BLE001
        _b22 = {'_err': f'{type(e).__name__}: {e}'}
    chk('⑳i 쌍의 상이 없으면 (phase_counts 0) 0 이 아니라 빈칸 (N/A)', _b22.get('area_AM_P_AM_P_n') == '')
    _hq5 = dict(_hq3, q2={k: v for k, v in _hq3['q2'].items() if k != 'phase_counts'})
    _neg('⑳j ★ 빠진 쌍을 채워야 하는데 수확 JSON 에 phase_counts 가 없으면 거부 (상이 있는지 모른다)',
         lambda: build_handover(_dq, _hq5, webapp=_wa4(), webapp_groups='contact'))
    try:
        _o23, _c23, _r23 = build_handover(_dq, _hq3, webapp=_wa4(st2='REFUSED'), webapp_groups='contact')
        _b23 = next((r for r in _o23 if r['case_id'] == 'q2'), {})
    except Exception as e:                                                # noqa: BLE001
        _b23, _r23 = {'_err': f'{type(e).__name__}: {e}'}, {}
    chk('⑳k 배치가 거부한 행 (REFUSED) 은 0 을 채우지 않는다 — 웹앱 열 전부 빈칸',
        _b23.get('area_AM_P_AM_P_n') == '' and _b23.get('wa_status') == 'REFUSED' and _r23.get('wa_pair_zero_filled') == 0)
    _d21 = {d['column']: d for d in column_dictionary(_c21, webapp=_wa4())} if _c21 else {}
    chk('⑳l 열 사전 — 쌍 개수 열의 뜻에 0 채움 규약 (J20-h)',
        'J20-h' in _d21.get('area_AM_P_AM_P_n', {}).get('meaning', '')
        and 'J20-h' in _d21.get('area_SE_SE_n', {}).get('meaning', ''))

    #  ⑳m–r J20-i (1저자 비준 09-30 — 접촉 ① 둘째 함수 `calc_se_se_cn` · 시험 먼저) — se_se_cn · se_se_cn_std 두 열만 싣는다 (같은 함수의
    #   _perc · _eff_area · _aug 는 ② · ⑦ · ⑤ 차례).  관문: 평균 CN = 2 × area_SE_SE_n / SE 입자 수 (수확 phase_counts) — 표에 함께 실린
    #   두 열이 같은 접촉 집합에서 왔는지 (09-30 실측 130/130 · 64/64 차이 0).  어긋나면 · SE 입자 수를 모르면 거부.
    chk('⑳m ★ J20-i — se_se_cn · se_se_cn_std 가 실린다 (mono 포함 — SE–SE 는 상별 열이 아니다) · 항등식 검사 수를 보고' + (f' — {_e20}' if _e20 else ''),
        'se_se_cn' in _c20 and 'se_se_cn_std' in _c20 and _m20.get('se_se_cn') == '18.0' and _m20.get('se_se_cn_std') == '2.5'
        and _b20.get('se_se_cn') == '16.0' and _b20.get('se_se_cn_std') == '3.0' and _r20.get('wa_cn_identity_checked') == 2)
    _wa_bad = _wa3()
    _wa_bad['rows']['q2']['se_se_cn'] = '16.5'
    _neg('⑳n ★ se_se_cn ≠ 2 × area_SE_SE_n / SE 수 이면 거부 (다른 접촉 집합 · 다른 프레임의 값을 한 표에 섞지 않는다)',
         lambda: build_handover(_dq, _hq3, webapp=_wa_bad, webapp_groups='contact'))
    _neg('⑳o ★ se_se_cn 을 싣는데 수확 JSON 에 phase_counts 가 없으면 거부 (SE 입자 수를 몰라 항등식을 못 본다)',
         lambda: build_handover(_dq, {k: {kk: vv for kk, vv in v.items() if kk != 'phase_counts'} for k, v in _hq3.items()},
                                webapp=_wa3(), webapp_groups='contact'))
    _wa_rf = _wa3()
    _wa_rf['status']['q2']['status'] = 'REFUSED'
    _wa_rf['rows']['q2']['se_se_cn'] = '99.0'
    try:
        _r24 = build_handover(_dq, _hq3, webapp=_wa_rf, webapp_groups='contact')[2]
        _e24 = ''
    except Exception as e:                                                # noqa: BLE001
        _r24, _e24 = {}, f'{type(e).__name__}: {e}'
    chk('⑳p 배치가 거부한 행 (REFUSED) 은 웹앱 값을 싣지 않으므로 항등식도 보지 않는다 (검사 1 건 = q1)' + (f' — {_e24}' if _e24 else ''),
        not _e24 and _r24.get('wa_cn_identity_checked') == 1)
    chk('⑳q 같은 함수의 다른 출력 (se_se_cn_perc · se_se_cn_eff_area · se_se_cn_aug) 은 census ✅ 여도 싣지 않는다 (② · ⑦ · ⑤ 차례)',
        not any(c in _c20 for c in ('se_se_cn_perc', 'se_se_cn_eff_area', 'se_se_cn_aug')))
    chk('⑳r 열 사전 — se_se_cn · se_se_cn_std 의 뜻에 검토 기록 (J20-i) · 정의 (SE 전 입자) · 벽 주의는 그대로',
        'J20-i' in _d20.get('se_se_cn', {}).get('meaning', '') and 'J20-i' in _d20.get('se_se_cn_std', {}).get('meaning', '')
        and '전 입자' in _d20.get('se_se_cn', {}).get('meaning', '') and '벽' in _d20.get('se_se_cn', {}).get('caveat', ''))

    #  ⑳s–x J20-j (1저자 09-30 *"6번 진행하자"* — 접촉 ① 셋째 함수 `calc_am_am_cn` · 시험 먼저) — am_am_cn · am_am_cn_std · am_am_n_contacts 세 열
    #   (상별 열이 아니라 mono 도 값 — J20-f (A) 로 비운 mono 의 AM–AM 개수가 여기서 돌아온다).  am_am_mean_area · am_am_total_area 는 ⑦ 차례.
    #   관문 둘: am_am_n_contacts = 웹앱 원 행의 AM–AM 쌍 개수 합 (없는 쌍 = 0) · am_am_cn = 2 × am_am_n_contacts / AM 입자 수 (수확 phase_counts)
    #   — 09-30 실측 130/130 · 64/64 차이 0.  어긋나거나 AM 입자 수를 모르면 거부.
    chk('⑳s ★ J20-j — am_am_cn · am_am_cn_std · am_am_n_contacts 가 실린다 (mono 포함) · 항등식 검사 수를 보고' + (f' — {_e20}' if _e20 else ''),
        all(c in _c20 for c in ('am_am_cn', 'am_am_cn_std', 'am_am_n_contacts'))
        and _m20.get('am_am_cn') == '2.0' and _m20.get('am_am_n_contacts') == '11' and _m20.get('am_am_cn_std') == '1.0'
        and _b20.get('am_am_cn') == '4.0' and _b20.get('am_am_n_contacts') == '22'
        and _r20.get('wa_am_identity_checked') == 2)
    _wa_bn = _wa3()
    _wa_bn['rows']['q2']['am_am_n_contacts'] = '23'
    _neg('⑳t ★ am_am_n_contacts ≠ 웹앱 원 행의 AM–AM 쌍 개수 합 (5 + 17 = 22) 이면 거부 (다른 접촉 집합)',
         lambda: build_handover(_dq, _hq3, webapp=_wa_bn, webapp_groups='contact'))
    _wa_bc = _wa3()
    _wa_bc['rows']['q2']['am_am_cn'] = '4.5'
    _neg('⑳u ★ am_am_cn ≠ 2 × am_am_n_contacts / AM 입자 수 (2 × 22 / 11 = 4.0) 이면 거부',
         lambda: build_handover(_dq, _hq3, webapp=_wa_bc, webapp_groups='contact'))
    _wa_np = _wa3()
    for _k in ('se_se_cn', 'se_se_cn_std'):                             # J20-i 관문을 빼고 J20-j 관문만 보이게
        _wa_np['verdict'].pop(_k, None)
    _neg('⑳v ★ am_am_cn 을 싣는데 수확 JSON 에 phase_counts 가 없으면 거부 (AM 입자 수를 몰라 항등식을 못 본다 · J20-i 관문 없이도)',
         lambda: build_handover(_dq, {k: {kk: vv for kk, vv in v.items() if kk != 'phase_counts'} for k, v in _hq3.items()},
                                webapp=_wa_np, webapp_groups='contact'))
    _wa_rf2 = _wa3()
    _wa_rf2['status']['q2']['status'] = 'REFUSED'
    _wa_rf2['rows']['q2']['am_am_n_contacts'] = '999'
    try:
        _r25 = build_handover(_dq, _hq3, webapp=_wa_rf2, webapp_groups='contact')[2]
        _e25 = ''
    except Exception as e:                                                # noqa: BLE001
        _r25, _e25 = {}, f'{type(e).__name__}: {e}'
    chk('⑳w 배치가 거부한 행 (REFUSED) 은 AM–AM 항등식도 보지 않는다 (검사 1 건 = q1)' + (f' — {_e25}' if _e25 else ''),
        not _e25 and _r25.get('wa_am_identity_checked') == 1)
    chk('⑳x 같은 함수의 면적 열 (am_am_mean_area · am_am_total_area) 은 census ✅ 여도 싣지 않는다 (⑦ 차례) · 열 사전에 J20-j 검토 기록 · '
        '접촉 수는 총량 주의 · CN 은 벽 주의',
        not any(c in _c20 for c in ('am_am_mean_area', 'am_am_total_area'))
        and all('J20-j' in _d20.get(c, {}).get('meaning', '') for c in ('am_am_cn', 'am_am_cn_std', 'am_am_n_contacts'))
        and '총량' in _d20.get('am_am_n_contacts', {}).get('caveat', '') and '벽' in _d20.get('am_am_cn', {}).get('caveat', ''))

    #  ⑳y–af J20-k (B) (1저자 09-30 *"인계할때는 중복되더라도 잘 채워서 보내야될듯"* · J20-f (A) 개정 · 시험 먼저) — mono 의 상별 칸은 설계 상 칸에.
    #   위 ⑳b · ⑳h 가 "이름이 어긋나는" 침대 (설계 AM_P · 웹앱 AM_S) 를 본다.  여기서는 이름이 같은 침대 · 반례 (웹앱 행에 두 이름 다 값) ·
    #   QC (웹앱 coverage_<웹앱 이름>_mean − 수확 전체) · 설계 쌍의 접촉 0 (J20-h 는 설계 상으로 판단) · 벽 접촉 비율 상별 · 열 사전 표지.
    _dq_s = [{'case_id': 'q1', 'block': 'mono_AM_S'}, {'case_id': 'q2', 'block': 'bimodal'}]
    try:
        _o26, _c26, _r26 = build_handover(_dq_s, _hq3, webapp=_wa3(), webapp_groups='contact')
        _m26, _e26 = next((r for r in _o26 if r['case_id'] == 'q1'), {}), ''
    except Exception as e:                                                # noqa: BLE001
        _m26, _r26, _e26 = {}, {}, f'{type(e).__name__}: {e}'
    chk('⑳y 이름이 같은 mono (설계 mono_AM_S · 웹앱 AM_S) — AM_S 칸에 값 · AM_P 칸 빈칸 · 옮김 0 건' + (f' — {_e26}' if _e26 else ''),
        not _e26 and _m26.get('area_AM_S_SE_n') == '40' and _m26.get('area_AM_P_SE_n') == ''
        and _m26.get('wa_mono_phase_name_webapp') == 'AM_S' and _r26.get('wa_mono_renamed_cases') == 0
        and _r26.get('wa_mono_design_filled') == 2 and _r26.get('wa_mono_absent_blanked') == 2
        and _m26.get('coverage_AM_S_hertz_pct') == repr(17.5) and _m26.get('coverage_AM_P_hertz_pct') == ''
        and _m26.get('n_AM_S_measured') == '11' and _m26.get('n_AM_P_measured') == '')
    _wa_both = _wa3()
    _wa_both['rows']['q1']['area_AM_P_SE_n'] = '3'                        # mono 인데 웹앱 접촉 열에 AM_P · AM_S 둘 다 값 — mono 행이 아니다
    _neg('⑳z ★ mono 인데 웹앱 행의 접촉 열에 AM_P · AM_S 두 이름 다 값이 있으면 거부 (다른 침대의 행 · 옮길 이름을 못 정한다)',
         lambda: build_handover(_dq, _hq3, webapp=_wa_both, webapp_groups='contact'))
    _wa_cov = _wa3()
    _wa_cov['rows']['q1']['coverage_AM_S_mean'] = '17.5'                  # 웹앱 반지름 이름 AM_S 의 피복 = 수확 전체 17.5 (같은 채널)
    _wa_cov['rows']['q2'].update(coverage_AM_P_mean='10.5', coverage_AM_S_mean='20.0')
    try:
        _o27 = build_handover(_dq, _hq3, webapp=_wa_cov, webapp_groups='contact')[0]
        _m27 = next((r for r in _o27 if r['case_id'] == 'q1'), {})
        _b27 = next((r for r in _o27 if r['case_id'] == 'q2'), {})
        _e27 = ''
    except Exception as e:                                                # noqa: BLE001
        _m27, _b27, _e27 = {}, {}, f'{type(e).__name__}: {e}'
    _ok27 = (not _e27 and _m27.get('qc_wa_cov_AM_P_minus_harvest_pct') == repr(0.0) and _m27.get('qc_wa_cov_AM_S_minus_harvest_pct') == ''
             and _b27.get('qc_wa_cov_AM_P_minus_harvest_pct') == repr(0.5) and _b27.get('qc_wa_cov_AM_S_minus_harvest_pct') == repr(0.0))
    chk('⑳aa QC — mono 의 설계 상 칸 검산 = 웹앱 coverage_<웹앱 이름>_mean − 수확 전체 (0.0) · 없는 상 칸 빈칸 · bimodal 은 상별 그대로'
        + (f' — {_e27}' if _e27 else '')
        + ('' if _ok27 else f' (실제 q1 {_m27.get("qc_wa_cov_AM_P_minus_harvest_pct")!r} · {_m27.get("qc_wa_cov_AM_S_minus_harvest_pct")!r} '
                            f'· q2 {_b27.get("qc_wa_cov_AM_P_minus_harvest_pct")!r} · {_b27.get("qc_wa_cov_AM_S_minus_harvest_pct")!r})'),
        _ok27)
    _wa_z = _wa4()
    _wa_z['rows']['q1'].pop('area_AM_S_AM_S_n')                          # mono 인데 AM–AM 접촉 0 → 웹앱 키 없음
    _wa_z['rows']['q1'].update(am_am_n_contacts='0', am_am_cn='0.0')     # J20-j 항등식에 맞춤
    try:
        _o28, _c28, _r28 = build_handover(_dq, _hq3, webapp=_wa_z, webapp_groups='contact')
        _m28, _e28 = next((r for r in _o28 if r['case_id'] == 'q1'), {}), ''
    except Exception as e:                                                # noqa: BLE001
        _m28, _r28, _e28 = {}, {}, f'{type(e).__name__}: {e}'
    chk('⑳ab J20-h 를 설계 상으로 — mono 의 설계 쌍 area_AM_P_AM_P_n 이 빠지면 0 (AM 이 있으므로) · 없는 상 쌍은 빈칸 · 0 채움 2 (q1 + q2)'
        + (f' — {_e28}' if _e28 else ''),
        not _e28 and _m28.get('area_AM_P_AM_P_n') == '0' and _m28.get('area_AM_S_AM_S_n') == ''
        and _r28.get('wa_pair_zero_filled') == 2)
    _hwt2 = {'q1': dict(_hq3['q1'], wall_touch=_wt2), 'q2': dict(_hq3['q2'], wall_touch=_wt3)}
    try:
        _o29 = build_handover(_dq, _hwt2)[0]
        _m29, _b29 = (next((r for r in _o29 if r['case_id'] == c), {}) for c in ('q1', 'q2'))
        _e29 = ''
    except Exception as e:                                                # noqa: BLE001
        _m29, _b29, _e29 = {}, {}, f'{type(e).__name__}: {e}'
    chk('⑳ac 벽 접촉 비율 상별 — mono 의 설계 상 칸 (AM_P) = 수확 AM · 없는 상 (AM_S) 빈칸 · AM 열 그대로 · bimodal 그대로' + (f' — {_e29}' if _e29 else ''),
        not _e29 and _m29.get('wall_touch_frac_AM_P_floor') == repr(1.0) and _m29.get('wall_touch_frac_AM_S_floor') == ''
        and _m29.get('wall_touch_frac_AM_floor') == repr(1.0) and _m29.get('wall_touch_frac_SE_floor') == repr(0.5)
        and _b29.get('wall_touch_frac_AM_P_floor') == repr(0.5) and _b29.get('wall_touch_frac_AM_S_plate') == repr(0.25))
    _d27 = {d['column']: d for d in column_dictionary(_c20, webapp=_wa3())} if _c20 else {}
    chk('⑳ad 열 사전 — 상별 열마다 (수확 coverage · n_AM_*_measured · cov_*_n_valid · 웹앱 쌍 · QC) J20-k (B) 표지 · 총량 · 설계 열에는 없음 · '
        'wa_mono_phase_name_webapp 열이 있고 출처 webapp_batch',
        all('J20-k' in _d27.get(c, {}).get('meaning', '') and '설계 상 칸' in _d27.get(c, {}).get('meaning', '')
            for c in ('coverage_AM_P_hertz_pct', 'coverage_AM_S_hertz_pct_status', 'n_AM_P_measured', 'cov_AM_S_n_valid',
                      'area_AM_P_SE_n', 'qc_wa_cov_AM_P_minus_harvest_pct'))
        and not any('설계 상 칸' in _d27.get(c, {}).get('meaning', '') for c in ('coverage_AM_total_hertz_pct', 'n_SE_measured', 'block'))
        and _d27.get('wa_mono_phase_name_webapp', {}).get('source') == 'webapp_batch'
        and 'J20-k' in _d27.get('wa_mono_phase_name_webapp', {}).get('meaning', ''))
    chk('⑳ae 보고 — 수확 쪽 (B) 채움 수 (mono_rows 1 · mono_harvest_filled = coverage 1 + n_AM 1 + cov_n_valid 1 = 3)',
        _r20.get('mono_rows') == 1 and _r20.get('mono_harvest_filled') == 3)
    _neg('⑳af ★ 설계 block mono 인데 웹앱 상별 열을 실을 때 수확 n_types 가 없으면 거부 (J20-f 관문 그대로)',
         lambda: build_handover(_dq, {'q1': {k: v for k, v in _hq3['q1'].items() if k != 'n_types'}, 'q2': _hq3['q2']},
                                webapp=_wa3(), webapp_groups='contact'))

    #  ═══ ㉑ 7c (1저자 비준 10-01 *"ㄱㄱ 하자"* · J20-k 7c · 원장 LHS-23) — AM–SE CN 10 열 + 고립 비율 3 + 전체 분포 3 (7a 새 키) ═══════════
    #   5번 배치 (`--stop-after coverage` = 접촉 단계 포함) 를 contact 묶음으로 받는다 · 고립 비율의 09-19 census 🔶 COND_cov 는 오분류 (LHS-23)
    #   → ✅ 승격 (옛 판정을 열 사전에 병기) · census 에 없는 7a 키는 배치 머리에 있을 때만 · 관문 G1–G7 (calc_am_isolation_risk 의 counts 하나에서
    #   나온 값인가) + 상이 있는데 값이 없거나 없는데 값이 있으면 거부.  값은 손으로 정한 입자별 SE 접촉 수에서 만든다.
    import math as _mth
    _cs1 = [0, 1, 3, 3, 4, 4, 4, 5, 5, 5, 6]                          # q1 mono (설계 AM_P · 웹앱 이름 AM_S) — 11 개 · 합 40 = area_AM_S_SE_n
    _cp2, _cs2 = [30], [1, 3, 4, 5, 5, 5, 5, 6, 7, 9]                 # q2 bimodal — AM_P 1 개 (합 30) · AM_S 10 개 (합 50)
    _RP, _RS = 5.0, 2.0                                                # 설계 반경 (µm) — 표면 가중 항등식

    def _stat7(v):
        n_ = len(v)
        mu_ = sum(v) / n_
        return {'mean': repr(mu_), 'std': repr(_mth.sqrt(sum((x - mu_) ** 2 for x in v) / n_)),
                'median': repr(float(np.median(v))), 'max': str(max(v)), 'vul': repr(100.0 * sum(1 for x in v if x <= 1) / n_)}

    def _wa7(stop='coverage'):
        w = _wa3()
        w['stop_after'] = stop
        for k in ['am_se_cn_mean', 'am_se_cn_surface_weighted'] + [f'{p}_se_cn_{s}' for p in ('AM_P', 'AM_S')
                                                                    for s in ('mean', 'std', 'median', 'max')]:
            w['verdict'][k] = '✅ 쓴다'
        for k in ('am_vulnerable_pct', 'AM_P_vulnerable_pct', 'AM_S_vulnerable_pct'):
            w['verdict'][k] = '🔶 채널 종속'                          # 09-19 census 그대로 (COND_cov 오분류 — LHS-23)
        w['why'] = {k: f'why:{k}' for k in w['verdict']}

        def _put(row, ph, v):
            s_ = _stat7(v)
            row.update({f'{ph}_se_cn_mean': s_['mean'], f'{ph}_se_cn_std': s_['std'], f'{ph}_se_cn_median': s_['median'],
                        f'{ph}_se_cn_max': s_['max'], f'{ph}_vulnerable_pct': s_['vul']})
        _put(w['rows']['q1'], 'AM_S', _cs1)
        _put(w['rows']['q2'], 'AM_P', _cp2)
        _put(w['rows']['q2'], 'AM_S', _cs2)
        for q, v, sw in (('q1', _cs1, sum(_cs1) / len(_cs1)),
                         ('q2', _cp2 + _cs2, (_RP ** 2 * sum(_cp2) + _RS ** 2 * sum(_cs2)) / (_RP ** 2 * len(_cp2) + _RS ** 2 * len(_cs2)))):
            s_ = _stat7(v)
            w['rows'][q].update(am_se_cn_mean=s_['mean'], am_se_cn_std=s_['std'], am_se_cn_median=s_['median'],
                                am_se_cn_max=s_['max'], am_vulnerable_pct=s_['vul'], am_se_cn_surface_weighted=repr(sw))
        return w
    _dq7 = [{'case_id': 'q1', 'block': 'mono_AM_P', 'r_AM_P_um': repr(_RP), 'r_AM_S_um': ''},
            {'case_id': 'q2', 'block': 'bimodal', 'r_AM_P_um': repr(_RP), 'r_AM_S_um': repr(_RS)}]

    def _b7(w=None, hv=None, dq=None):
        return build_handover(dq or _dq7, hv or _hq3, webapp=w or _wa7(), webapp_groups='contact')
    try:
        _o7, _c7, _r7 = _b7()
        _e7 = ''
    except Exception as e:                                                # noqa: BLE001
        _o7, _c7, _r7, _e7 = [], [], {}, f'{type(e).__name__}: {e}'
    _m7 = next((r for r in _o7 if r['case_id'] == 'q1'), {})
    _p7 = next((r for r in _o7 if r['case_id'] == 'q2'), {})
    _cols7 = (['am_se_cn_mean', 'am_se_cn_surface_weighted', 'am_se_cn_std', 'am_se_cn_median', 'am_se_cn_max',
               'am_vulnerable_pct', 'AM_P_vulnerable_pct', 'AM_S_vulnerable_pct']
              + [f'{p}_se_cn_{s}' for p in ('AM_P', 'AM_S') for s in ('mean', 'std', 'median', 'max')])
    chk('㉑a ★ 7c — coverage 배치 (stop_after=coverage · 접촉 단계 포함) 를 contact 묶음으로 받고 16 열이 실린다 · 관문 검사 2 행'
        + (f' — {_e7}' if _e7 else ''),
        not _e7 and all(c in _c7 for c in _cols7) and _r7.get('wa_amse_identity_checked') == 2)
    chk('㉑b 값 — bimodal 은 상별 그대로 · mono 는 설계 상 칸 (AM_P) 에 웹앱 AM_S 값 · 없는 상 칸 빈칸 · 전체 열 그대로',
        _p7.get('AM_P_se_cn_mean') == repr(30.0) and _p7.get('AM_S_se_cn_max') == '9' and _p7.get('am_se_cn_max') == '30'
        and _p7.get('am_se_cn_median') == repr(5.0) and _p7.get('AM_S_vulnerable_pct') == repr(10.0)
        and _m7.get('AM_P_se_cn_mean') == repr(40 / 11) and _m7.get('AM_S_se_cn_mean') == ''
        and _m7.get('AM_S_vulnerable_pct') == '' and _m7.get('AM_P_vulnerable_pct') == repr(200 / 11)
        and _m7.get('am_se_cn_mean') == repr(40 / 11))
    _neg('㉑c ★ coverage 배치를 묶음 제한 없이 부르면 여전히 거부 (뒤 단계 열이 빈칸 = N/A 로 읽힌다)',
         lambda: build_handover(_dq7, _hq3, webapp=_wa7()))
    _dm7 = {d['column']: d for d in column_dictionary(_c7, webapp=_wa7())} if _c7 else {}
    chk('㉑d ★ 고립 비율 — census 🔶 COND_cov 를 ✅ 로 승격 (LHS-23) · 열 사전에 옛 판정 병기 · 뜻 = SE 접촉 0–1 개 · coverage 문턱 아님',
        bool(_dm7) and all(_dm7.get(c, {}).get('verdict', '').startswith('✅') and 'LHS-23' in _dm7.get(c, {}).get('verdict', '')
                           and '🔶' in _dm7.get(c, {}).get('meaning', '') and '0–1' in _dm7.get(c, {}).get('meaning', '')
                           and 'coverage' in _dm7.get(c, {}).get('meaning', '')
                           for c in ('am_vulnerable_pct', 'AM_P_vulnerable_pct', 'AM_S_vulnerable_pct')))
    chk('㉑e ★ 7a 새 키 (census 밖) — 배치 머리에 있으면 ✅ (J20-k 7a) · 출처 webapp · 뜻 = AM 전 입자 분포 · 검토 기록 7c',
        bool(_dm7) and all(_dm7.get(c, {}).get('source') == 'webapp' and 'J20-k' in _dm7.get(c, {}).get('verdict', '')
                           and 'AM 전 입자' in _dm7.get(c, {}).get('meaning', '') and '7c' in _dm7.get(c, {}).get('meaning', '')
                           for c in ('am_se_cn_std', 'am_se_cn_median', 'am_se_cn_max')))
    _w7h = _wa7()
    for _r_ in _w7h['rows'].values():
        _r_.pop('am_se_cn_median', None)
    try:
        _c7h = _b7(w=_w7h)[1]
    except Exception as e:                                                # noqa: BLE001
        _c7h = [f'ERR {type(e).__name__}: {e}']
    chk('㉑f census 밖 키가 배치 머리에 없으면 열도 없다 (옛 배치의 빈칸이 측정된 N/A 로 읽히지 않게) · 있는 키는 그대로',
        'am_se_cn_median' not in _c7h and 'am_se_cn_max' in _c7h)

    def _neg7(name, fn, tag):
        """거부 + **그 관문**이 거부했는가 (메시지에 tag) — 다른 관문이 먼저 막으면 이 반례는 그 관문을 시험하지 못한 것이다."""
        nonlocal ok
        try:
            fn()
        except FillRefusal as e:
            if tag in str(e):
                ok += 1
                print(f'  PASS  {name} — 거부: {str(e)[:64]}')
            else:
                fail.append(name)
                print(f'  FAIL  {name} — 다른 관문이 거부: {str(e)[:120]}')
            return
        except Exception as e:                                            # noqa: BLE001
            fail.append(name)
            print(f'  FAIL  {name} — {type(e).__name__}: {e}')
            return
        fail.append(name)
        print(f'  FAIL  {name} — 거부하지 않았다')

    def _bad7(q, **kv):
        w = _wa7()
        w['rows'][q].update(kv)
        return lambda: _b7(w=w)
    _neg7('㉑g ★ G1 — 상별 평균 × 상 입자 수 ≠ area_<상>_SE_n (5.5 × 10 ≠ 50) 이면 거부', _bad7('q2', AM_S_se_cn_mean='5.5'), '7c G1')
    _neg7('㉑h ★ G1 mono — 설계 상 칸으로 옮긴 평균 × AM 수 ≠ 옮긴 쌍 개수 (3.0 × 11 ≠ 40) 이면 거부', _bad7('q1', AM_S_se_cn_mean='3.0'), '7c G1')
    _neg7('㉑i ★ G2 — 전체 평균 × AM 수 ≠ area_AM전체_SE_n (7.0 × 11 ≠ 80) 이면 거부', _bad7('q2', am_se_cn_mean='7.0'), '7c G2')
    _neg7('㉑j ★ G3 — 고립 개수: 전체 2 ≠ 상별 합 (AM_P 0 + AM_S 1) 이면 거부', _bad7('q2', am_vulnerable_pct=repr(200 / 11)), '7c G3')
    _neg7('㉑k ★ G3 — 고립 비율 × 입자 수 / 100 이 정수 개수가 아니면 거부 (25 % × 10 = 2.5)', _bad7('q2', AM_S_vulnerable_pct='25.0'), '7c G3')
    _neg7('㉑l ★ G4 — 전체 max ≠ 상별 max 의 최댓값 (9 ≠ 30) 이면 거부', _bad7('q2', am_se_cn_max='9'), '7c G4')
    _neg7('㉑m ★ G5 — bimodal 전체 median 이 상별 median 사이 밖 (31 ∉ [5, 30]) 이면 거부', _bad7('q2', am_se_cn_median='31.0'), '7c G5')
    _neg7('㉑n ★ G5 mono — 전체 median ≠ 단일 상 median (4.5 ≠ 4.0) 이면 거부', _bad7('q1', am_se_cn_median='4.5'), '7c G5')
    _neg7('㉑o ★ G6 — 전체 std ≠ 합동 표준편차 (상별 N · 평균 · std) 이면 거부', _bad7('q2', am_se_cn_std='7.0'), '7c G6')
    _neg7('㉑p ★ G6 mono — 전체 std ≠ 단일 상 std 이면 거부', _bad7('q1', am_se_cn_std='1.8'), '7c G6')
    _neg7('㉑q ★ G7 — 표면 가중 ≠ Σ N r² CN / Σ N r² (설계 반경) 이면 거부', _bad7('q2', am_se_cn_surface_weighted='15.0'), '7c G7')
    _neg7('㉑r ★ G7 — bimodal 인데 설계 반경이 없으면 거부 (표면 가중을 확인할 수 없다)',
          lambda: _b7(dq=[_dq7[0], dict(_dq7[1], r_AM_S_um='')]), '7c G7')
    _neg7('㉑s ★ 상이 있는데 상별 값이 비면 거부 (bimodal AM_S std 빈칸)', _bad7('q2', AM_S_se_cn_std=''), '7c 상 있음')
    _neg7('㉑t ★ 상이 없는데 (phase_counts AM_P 0) 상별 값이 있으면 거부',
          lambda: _b7(hv=dict(_hq3, q2=dict(_hq3['q2'], phase_counts={'AM_P': 0, 'AM_S': 11, 'SE': 100}))), '7c 상 없음')
    _neg7('㉑u ★ 수확 JSON 에 phase_counts 가 없으면 거부 (상 입자 수를 몰라 관문을 못 본다 · bimodal 행 — mono 는 J20-k (B) 가 먼저 막는다)',
          lambda: _b7(hv=dict(_hq3, q2={kk: vv for kk, vv in _hq3['q2'].items() if kk != 'phase_counts'}), w=(lambda w_: (
              [w_['verdict'].pop(k_, None) for k_ in ('se_se_cn', 'se_se_cn_std', 'am_am_cn', 'am_am_cn_std', 'am_am_n_contacts')], w_)[1])(_wa7())),
          '(7c)')
    _w7r = _wa7()
    _w7r['status']['q2']['status'] = 'REFUSED'
    _w7r['rows']['q2']['AM_S_se_cn_mean'] = '99.0'
    try:
        _r7r = _b7(w=_w7r)[2]
        _e7r = ''
    except Exception as e:                                                # noqa: BLE001
        _r7r, _e7r = {}, f'{type(e).__name__}: {e}'
    chk('㉑v 배치가 거부한 행 (REFUSED) 은 값을 싣지 않으므로 관문도 보지 않는다 (검사 1 행 = q1)' + (f' — {_e7r}' if _e7r else ''),
        not _e7r and _r7r.get('wa_amse_identity_checked') == 1)
    _dm7b = {d['column']: d for d in column_dictionary(_c7, webapp=_wa7())} if _c7 else {}
    chk('㉑w 열 사전 — AM–SE CN · 고립 열에 검토 기록 (7c · 관문 G1–G7) · 상별 열은 mono 설계 상 칸 표지 · 전체 열은 아님',
        all('7c' in _dm7b.get(c, {}).get('meaning', '') for c in _cols7)
        and '설계 상 칸' in _dm7b.get('AM_P_vulnerable_pct', {}).get('meaning', '')
        and '설계 상 칸' not in _dm7b.get('am_vulnerable_pct', {}).get('meaning', ''))
    #  ═══ ㉒ ② 퍼콜레이션 (J20-b 감사 · 1저자 비준 10-01 *"퍼콜레이션은 그렇게 가고"* · LHS-19 · LHS-20) ═════════════════════════════════
    #   접촉 분석 단계가 내는 SE 그래프 열 7 개를 percolation 묶음으로 싣는다 (`--webapp-groups contact,percolation`) · top_reachable · ionic_active 의
    #   census 🔶 COND_cov 는 오분류 (LHS-20) → ✅ · electronic_active_fraction (망 단계) · se_se_cn_eff_area_perc (면적 · ⑦) 는 census ✅ 여도 안 싣는다 ·
    #   관문 P1 (관통 일관 + 수확기 독립 재현 — J20-b F8) · P2 (범위 · 순서) · P3 (관통 SE 개수 = percolation_pct × N_SE / 100).
    def _wa8():
        w = _wa7()
        w['verdict'].update(percolation_pct='✅ 쓴다', n_components='✅ 쓴다', n_large_components='✅ 쓴다', se_se_cn_perc='✅ 쓴다',
                            se_se_cn_n_perc='✅ 쓴다', top_reachable_pct='🔶 채널 종속', ionic_active_pct='🔶 채널 종속',
                            electronic_active_fraction='✅ 쓴다', se_se_cn_eff_area_perc='✅ 쓴다(이름 주의)')
        w['why'] = {k: f'why:{k}' for k in w['verdict']}
        w['rows']['q1'].update(percolation_pct='37.0', top_reachable_pct='40.0', n_components='12', n_large_components='2',
                               ionic_active_pct=repr(900 / 11), se_se_cn_perc='5.5', se_se_cn_n_perc='37', se_se_cn_eff_area_perc='0.05')
        w['rows']['q2'].update(percolation_pct='0.0', top_reachable_pct='15.0', n_components='30', n_large_components='3',
                               ionic_active_pct=repr(500 / 11))             # 관통 없음 — _perc 키 자체가 없다 (웹앱 그대로) · 5/11 (v1.1 D3 정수 개수)
        for _k in ('se_se_cn_perc', 'se_se_cn_eff_area_perc', 'se_se_cn_n_perc'):   # _wa3 의 J20-i 시험용 값 — 비관통 침대에는 없다
            w['rows']['q2'].pop(_k, None)
        return w

    def _hq8(span1=2, span2=0):
        return {'q1': dict(_hq3['q1'], tau_detail={'band_detail': {'wall_n_span_components': span1}}),
                'q2': dict(_hq3['q2'], tau_detail={'band_detail': {'wall_n_span_components': span2}})}

    def _b8(w=None, hv=None, groups='contact,percolation'):
        return build_handover(_dq7, hv or _hq8(), webapp=w or _wa8(), webapp_groups=groups)
    try:
        _o8, _c8, _r8 = _b8()
        _e8 = ''
    except Exception as e:                                                # noqa: BLE001
        _o8, _c8, _r8, _e8 = [], [], {}, f'{type(e).__name__}: {e}'
    _m8 = next((r for r in _o8 if r['case_id'] == 'q1'), {})
    _p8 = next((r for r in _o8 if r['case_id'] == 'q2'), {})
    _pc8 = ('percolation_pct', 'top_reachable_pct', 'n_components', 'n_large_components', 'ionic_active_pct', 'se_se_cn_perc', 'se_se_cn_n_perc')
    chk('㉒a ★ ② — contact,percolation 묶음: 퍼콜레이션 7 열 + ① 열 · 망 단계 electronic_active_fraction · 면적 se_se_cn_eff_area_perc 는 안 싣는다 · '
        '관문 검사 2 행' + (f' — {_e8}' if _e8 else ''),
        not _e8 and all(c in _c8 for c in _pc8) and 'am_se_cn_mean' in _c8
        and 'electronic_active_fraction' not in _c8 and 'se_se_cn_eff_area_perc' not in _c8 and _r8.get('wa_perc_checked') == 2)
    chk('㉒b 값 — 관통 침대 (q1) 는 _perc 값 · 비관통 (q2) 은 percolation_pct 0.0 · _perc 빈칸 (N/A) · 나머지 그대로',
        _m8.get('percolation_pct') == '37.0' and _m8.get('se_se_cn_n_perc') == '37' and _m8.get('se_se_cn_perc') == '5.5'
        and _p8.get('percolation_pct') == '0.0' and _p8.get('se_se_cn_perc') == '' and _p8.get('se_se_cn_n_perc') == ''
        and _p8.get('n_components') == '30' and _m8.get('ionic_active_pct') == repr(900 / 11))
    try:
        _c8c = _b8(groups='contact')[1]
    except Exception as e:                                                # noqa: BLE001
        _c8c = [f'ERR {type(e).__name__}: {e}']
    chk('㉒c contact 묶음만이면 퍼콜레이션 열은 없다 (묶음 거르기)', 'am_se_cn_mean' in _c8c and not any(c in _c8c for c in _pc8))
    _dm8 = {d['column']: d for d in column_dictionary(_c8, webapp=_wa8())} if _c8 else {}
    _g8 = lambda c, k: (_dm8.get(c) or {}).get(k, '')                     # noqa: E731
    chk('㉒d ★ LHS-20 — top_reachable · ionic_active 를 ✅ 로 승격 · 옛 판정 병기 · F3 한정어 (외톨이 · 문턱 10 · 0.0 = 미퍼콜 · 솔버 관통과 다름 · N/A)',
        all(_g8(c, 'verdict').startswith('✅') and 'LHS-20' in _g8(c, 'verdict') and '🔶' in _g8(c, 'meaning')
            for c in ('top_reachable_pct', 'ionic_active_pct'))
        and '외톨이' in _g8('n_components', 'meaning') and '10' in _g8('n_large_components', 'meaning')
        and '0.0' in _g8('percolation_pct', 'meaning') and '솔버' in _g8('percolation_pct', 'meaning')
        and 'N/A' in _g8('se_se_cn_perc', 'meaning') and '외톨이' in _g8('top_reachable_pct', 'meaning')
        and 'coverage' in _g8('ionic_active_pct', 'meaning') and 'J20-b' in _g8('percolation_pct', 'meaning')
        and 'LHS-17' in _g8('percolation_pct', 'caveat'))
    _neg('㉒e 모르는 묶음 이름이 섞이면 거부 (contact,stress — ⑤⑥⑦ 뒤 fracture 는 아는 묶음)', lambda: _b8(groups='contact,stress'))

    def _bad8(q, **kv):
        w = _wa8()
        w['rows'][q].update(kv)
        return lambda: _b8(w=w)
    _neg7('㉒f ★ P1 — 비관통 (percolation_pct 0) 인데 se_se_cn_perc 에 값이 있으면 거부', _bad8('q2', se_se_cn_perc='4.0'), '② P1')
    _neg7('㉒g ★ P1 — 관통인데 se_se_cn_n_perc 가 비면 거부', _bad8('q1', se_se_cn_n_perc=''), '② P1')
    _neg7('㉒h ★ P1 — 웹앱 관통 ↔ 수확기 벽 밴드 관통 (0 성분) 이 어긋나면 거부 (J20-b F8 독립 재현)', lambda: _b8(hv=_hq8(span1=0)), '② P1')
    _neg7('㉒i ★ P1 — 웹앱 비관통 ↔ 수확기 관통 (1 성분) 이 어긋나면 거부', lambda: _b8(hv=_hq8(span2=1)), '② P1')
    _neg7('㉒j ★ P1 — 수확 JSON 에 벽 밴드 관통 진단이 없으면 거부 (독립 재현을 볼 수 없다)', lambda: _b8(hv=dict(_hq8(), q2=_hq3['q2'])), '② P1')
    _neg7('㉒k ★ P2 — 비율이 [0, 100] 밖이면 거부 (ionic_active_pct 101)', _bad8('q2', ionic_active_pct='101.0'), '② P2')
    _neg7('㉒l ★ P2 — n_large_components > n_components 이면 거부', _bad8('q2', n_large_components='31'), '② P2')
    _neg7('㉒m ★ P2 — top_reachable_pct < percolation_pct 이면 거부 (관통 SE 는 위 밴드에 닿는다)', _bad8('q1', top_reachable_pct='30.0'), '② P2')
    _neg7('㉒n ★ P2 — 성분 수가 정수가 아니면 거부', _bad8('q2', n_components='30.5'), '② P2')
    _neg7('㉒o ★ P3 — 관통 SE 개수 ≠ percolation_pct × N_SE / 100 (38 ≠ 37) 이면 거부', _bad8('q1', se_se_cn_n_perc='38'), '② P3')
    _w8r = _wa8()
    _w8r['status']['q2']['status'] = 'REFUSED'
    _w8r['rows']['q2']['se_se_cn_perc'] = '9.9'
    try:
        _r8r = _b8(w=_w8r)[2]
        _e8r = ''
    except Exception as e:                                                # noqa: BLE001
        _r8r, _e8r = {}, f'{type(e).__name__}: {e}'
    chk('㉒p 배치가 거부한 행 (REFUSED) 은 값을 싣지 않으므로 관문도 보지 않는다 (검사 1 행)' + (f' — {_e8r}' if _e8r else ''),
        not _e8r and _r8r.get('wa_perc_checked') == 1)
    chk('㉒q 열 사전 — 퍼콜레이션 열에 검토 기록 (J20-b ② · 관문 P1–P3) · 출처 webapp',
        all('J20-b ②' in _g8(c, 'meaning') and _g8(c, 'source') == 'webapp' for c in _pc8))
    #  ═══ ㉓ 벽 τ 닫기 (1저자 10-01 *"dijkstra tortuosity 벽을 확실하게 닫고 값을 추출"* · J20 · 수확 v3 원천) ═════════════════════════════
    #   관문 T1 (관통 성분 수 — 상태 · 수확 벽 밴드 진단과 같아야) · T2 (값 [1, 20) · 표본 수 규칙) · T3 (② 퍼콜레이션과 비관통 판정 같아야) ·
    #   열 사전 = 기하 최단경로 · 수송 τ 아님 (COMSOL 입력은 τ_Laplace,eff) · 벽 접촉 비율 = 겹침 깊이 > 0 (접선 제외 — 수확기 규칙과 같은 문구).
    def _tw9(status='OK', span=2, mean=1.45, med=1.4, ns_=200, nv=200, ntr=0):
        ok_ = status == 'OK'
        return {'tau_mean': (mean if ok_ else None), 'tau_median': (med if ok_ else None), 'tau_mean_untruncated': (mean if ok_ else None),
                'status': status, 'n_sampled': (ns_ if ok_ else 0), 'n_valid': (nv if ok_ else 0), 'n_truncated': ntr,
                'n_span_components': span, 'tau_convention': TAU_WALL_CONVENTION}

    def _hq9(t1=None, t2=None, wt=True):
        hv = _hq8()
        hv['q1'] = dict(hv['q1'], tau_wall_detail=t1 or _tw9('OK', 2))
        hv['q2'] = dict(hv['q2'], tau_wall_detail=t2 or _tw9('NOT_PERCOLATING', 0))
        if wt:
            hv['q1']['wall_touch'] = {'SE': {'floor': 0.25, 'plate': 0.125}, 'AM': {'floor': 0.5, 'plate': 0.0}}
            hv['q2']['wall_touch'] = {'SE': {'floor': 0.5, 'plate': 0.0}, 'AM_P': {'floor': 1.0, 'plate': 0.0},
                                      'AM_S': {'floor': 0.0, 'plate': 0.2}, 'AM': {'floor': 1 / 11, 'plate': 2 / 11}}
        return hv
    try:
        _o9, _c9, _r9 = _b8(hv=_hq9())
        _e9 = ''
    except Exception as e:                                                # noqa: BLE001
        _o9, _c9, _r9, _e9 = [], [], {}, f'{type(e).__name__}: {e}'
    _m9 = next((r for r in _o9 if r['case_id'] == 'q1'), {})
    _p9 = next((r for r in _o9 if r['case_id'] == 'q2'), {})
    chk('㉓a ★ 벽 τ — 관통 침대는 값 · 비관통은 빈칸 (N/A) · 관문 T1–T2 2 행 · T3 (↔ 퍼콜레이션) 2 행' + (f' — {_e9}' if _e9 else ''),
        not _e9 and _m9.get('tortuosity_SE_wall') == repr(1.45) and _p9.get('tortuosity_SE_wall') == ''
        and _p9.get('tortuosity_SE_wall_status') == 'NOT_PERCOLATING'
        and _r9.get('tau_wall_checked') == 2 and _r9.get('tau_perc_crosschecked') == 2)
    _dm9 = {d['column']: d for d in column_dictionary(_c9, webapp=_wa8())} if _c9 else {}
    _tm = (_dm9.get('tortuosity_SE_wall') or {}).get('meaning', '')
    _wm = (_dm9.get('wall_touch_frac_SE_floor') or {}).get('meaning', '')
    chk('㉓b ★ 열 사전 — 벽 τ = 기하 최단경로 · 수송 τ 아님 (수송 굴곡도 = 망 단계 tau2 · τ 명명 규약 10-03 — 옛 "COMSOL/EIS 입력 τ 는 '
        'τ_Laplace,eff" 철회 TAU-01) · 비관통 N/A · 표본 200 쌍',
        '기하 최단경로' in _tm and 'tau2' in _tm and 'COMSOL/EIS 입력 τ 는 τ_Laplace' not in _tm and 'N/A' in _tm and '200 쌍' in _tm)
    chk('㉓c ★ 벽 접촉 비율 문구 = 수확기 규칙 (겹침 깊이 > 0 · 접선은 안 셈) — 옛 "≤ 0 · ≥ plate_z" 없음',
        '겹침 깊이 > 0' in _wm and '접선' in _wm and '≤ 0' not in _wm and 'z − r < 0' in _wm)
    try:
        import lhs_descriptor_harvest as _LDH9
        _same9 = (_LDH9.TAU_LO, _LDH9.TAU_HI, _LDH9.N_TAU_PAIRS) == (TAU_WALL_LO, TAU_WALL_HI, TAU_WALL_N_PAIRS) \
            and 'tangent' in _LDH9.WALL_TOUCH_RULE and '> 0' in _LDH9.WALL_TOUCH_RULE
    except Exception as e:                                                # noqa: BLE001
        _same9 = False
    chk('㉓d 관문 상수 = 수확기 (TAU_LO · TAU_HI · N_TAU_PAIRS) · 수확기 규칙이 접선 제외 · 한쪽만 바뀌면 걸린다', _same9)
    _neg7('㉓e ★ T1 — 상태 OK 인데 관통 성분 0 이면 거부', lambda: _b8(hv=_hq9(t1=_tw9('OK', 0))), 'τ T1')
    _neg7('㉓f ★ T1 — NOT_PERCOLATING 인데 관통 성분 1 이면 거부', lambda: _b8(hv=_hq9(t2=_tw9('NOT_PERCOLATING', 1))), 'τ T1')
    _neg7('㉓g ★ T1 — 벽 τ 관통 성분 (3) ≠ 수확 벽 밴드 진단 (2) 이면 거부', lambda: _b8(hv=_hq9(t1=_tw9('OK', 3))), 'τ T1')
    _neg7('㉓h ★ T2 — OK 인데 τ 평균이 [1, 20) 밖 (25) 이면 거부', lambda: _b8(hv=_hq9(t1=_tw9('OK', 2, mean=25.0))), 'τ T2')
    _neg7('㉓i ★ T2 — n_valid > n_sampled 이면 거부', lambda: _b8(hv=_hq9(t1=_tw9('OK', 2, ns_=150, nv=180))), 'τ T2')
    _neg7('㉓j ★ T2 — 잘린 수 = 경로 수 (남은 표본 0) 인데 OK 면 거부', lambda: _b8(hv=_hq9(t1=_tw9('OK', 2, nv=200, ntr=200))), 'τ T2')
    _w9 = _wa8()
    _w9['rows']['q2'].update(percolation_pct='12.0', se_se_cn_perc='5.0', se_se_cn_n_perc='12')
    _neg7('㉓k ★ T3 — 벽 τ 비관통인데 웹앱 percolation_pct > 0 이면 거부 (수확기 벽 밴드 진단도 0 이라 P1 이 먼저면 P1)',
          lambda: _b8(w=_w9, hv=_hq9(t2=_tw9('NOT_PERCOLATING', 0))), '② P1')
    _neg7('㉓l ★ n_span_components 가 정수가 아니면 거부', lambda: _b8(hv=_hq9(t1=_tw9('OK', 2.0))), 'τ T1')
    #  ═══ ㉔ v1.1 ①②③ (1저자 비준 10-01 *"비준이야"* · J20-o) ════════════════════════════════════════════════════════════════════════════
    #   ① am_ionic_isolated_pct = 100 − ionic_active_pct — 경로 기준 고립 (이온이 못 가는 AM) · 생성기 유도 (재실행 없음) · 고립 위험 (vulnerable) 과 다른 양
    #   ② 분해 — 웹앱 v1.1 이 새로 내보내는 키 (단절 · 무접촉 · 상별 셋) · 배치 머리에 있을 때만 · 관문 D1–D5 (합 100 · 상별 합 100 · 정수 개수 ·
    #      상별 개수 합 = 전체 · 무접촉 ≤ 고립 위험) · mono 는 설계 상 칸
    #   ③ 가장 큰 SE 덩어리 — SE 비율 · z 폭 (벽 간격 기준 = 기록 z 폭 × 전 입자 z 범위 / 벽 간격 · 정확 환산 · 재실행 없음) · 관문 C1–C3
    def _wa10(dec=True):
        w = _wa8()
        if dec:
            w['rows']['q1'].update(ionic_dead_pct=repr(100 / 11), ionic_no_se_pct=repr(100 / 11), AM_S_ionic_active_pct=repr(900 / 11),
                                   AM_S_ionic_dead_pct=repr(100 / 11), AM_S_ionic_no_se_pct=repr(100 / 11))
            w['rows']['q2'].update(ionic_dead_pct=repr(600 / 11), ionic_no_se_pct='0.0',
                                   AM_P_ionic_active_pct='100.0', AM_P_ionic_dead_pct='0.0', AM_P_ionic_no_se_pct='0.0',
                                   AM_S_ionic_active_pct='40.0', AM_S_ionic_dead_pct='60.0', AM_S_ionic_no_se_pct='0.0')
        return w

    def _bd10(n_se=100, frac=0.37, zs=0.95, zlo=-0.5, zhi=40.5, pz=40.0, fl=0.0):
        return {'n_se': n_se, 'largest_comp_frac': frac, 'largest_comp_z_span_frac': zs, 'z_lo': zlo, 'z_hi': zhi,
                'alt_plate_z': pz, 'wall_z_floor': fl}

    def _hq10(b1=None, b2=None):
        hv = _hq9()
        for q, b, span in (('q1', b1 or _bd10(), 2), ('q2', b2 or _bd10(frac=0.25, zs=0.5), 0)):
            hv[q] = dict(hv[q], plate_z_sim=40.0, z_floor_sim=0.0, tau_detail={'band_detail': dict(b, wall_n_span_components=span)})
        return hv

    def _b10(w=None, hv=None):
        return build_handover(_dq7, hv or _hq10(), webapp=w or _wa10(), webapp_groups='contact,percolation')
    try:
        _o10, _c10, _r10 = _b10()
        _e10 = ''
    except Exception as e:                                                # noqa: BLE001
        _o10, _c10, _r10, _e10 = [], [], {}, f'{type(e).__name__}: {e}'
    _m10 = next((r for r in _o10 if r['case_id'] == 'q1'), {})
    _p10 = next((r for r in _o10 if r['case_id'] == 'q2'), {})
    chk('㉔a ★ ① am_ionic_isolated_pct = 100 − ionic_active_pct (q1 · q2) · 활성 열 뒤 · 활성 열이 실리면 늘 (재실행 없음)' + (f' — {_e10}' if _e10 else ''),
        not _e10 and _m10.get('am_ionic_isolated_pct') == repr(100.0 - 900 / 11) and _p10.get('am_ionic_isolated_pct') == repr(100.0 - 500 / 11)
        and 'ionic_active_pct' in _c10 and _c10.index('am_ionic_isolated_pct') > _c10.index('ionic_active_pct'))
    _dec10 = ('ionic_dead_pct', 'ionic_no_se_pct') + tuple(f'{ph}_ionic_{s_}_pct' for ph in ('AM_P', 'AM_S') for s_ in ('active', 'dead', 'no_se'))
    try:
        _c10o = _b10(w=_wa10(dec=False))[1]
    except Exception as e:                                                # noqa: BLE001
        _c10o = [f'ERR {type(e).__name__}: {e}']
    chk('㉔b ② 분해 키가 배치 머리에 없으면 (5번 배치 세대) 분해 열도 없다 · ① 은 그대로 (활성에서 유도)',
        'am_ionic_isolated_pct' in _c10o and not any(c in _c10o for c in _dec10))
    chk('㉔c ★ ② 새 배치 — 분해 열 8 개 · mono (설계 AM_P · 웹앱 이름 AM_S) 는 설계 상 칸 · 없는 상 칸 빈칸 · 관문 D 2 행',
        all(c in _c10 for c in _dec10) and _m10.get('AM_P_ionic_dead_pct') == repr(100 / 11) and _m10.get('AM_S_ionic_dead_pct') == ''
        and _m10.get('ionic_no_se_pct') == repr(100 / 11) and _p10.get('AM_S_ionic_active_pct') == '40.0' and _p10.get('ionic_no_se_pct') == '0.0'
        and _r10.get('wa_ionic_checked') == 2)
    _dm10 = {d['column']: d for d in column_dictionary(_c10, webapp=_wa10())} if _c10 else {}
    _g10 = lambda c, k: (_dm10.get(c) or {}).get(k, '')                   # noqa: E731
    chk('㉔d ★ 열 사전 — ① 경로 기준 고립 = 100 − ionic_active_pct · 고립 위험 (vulnerable) 과 다른 양 · ② 단절 · 무접촉 정의 · 새 키 판정 (v1.1 ②)',
        '경로 기준 고립' in _g10('am_ionic_isolated_pct', 'meaning') and '100 − ionic_active_pct' in _g10('am_ionic_isolated_pct', 'meaning')
        and '고립 위험' in _g10('am_ionic_isolated_pct', 'meaning') and 'v1.1 ①' in _g10('am_ionic_isolated_pct', 'meaning')
        and '닿았지만' in _g10('ionic_dead_pct', 'meaning') and 'SE 접촉 0' in _g10('ionic_no_se_pct', 'meaning')
        and 'v1.1 ②' in _g10('ionic_dead_pct', 'verdict') and _g10('ionic_dead_pct', 'source') == 'webapp'
        and 'v1.1 ②' in _g10('AM_P_ionic_active_pct', 'verdict') and '설계 상 칸' in _g10('AM_P_ionic_active_pct', 'meaning'))

    def _bad10(q, **kv):
        w = _wa10()
        w['rows'][q].update(kv)
        return lambda: _b10(w=w)
    _neg7('㉔e ★ D1 — 활성 + 단절 + 무접촉 ≠ 100 이면 거부', _bad10('q2', ionic_no_se_pct=repr(100 / 11)), 'v1.1 D1')
    _neg7('㉔f ★ D2 — 상별 활성 + 단절 + 무접촉 ≠ 100 이면 거부 (AM_S 40 + 50 + 0)', _bad10('q2', AM_S_ionic_dead_pct='50.0'), 'v1.1 D2')
    _neg7('㉔g ★ D3 — 비율 × 입자 수 / 100 이 정수 개수가 아니면 거부 (활성 45 % × 11 = 4.95)',
          _bad10('q2', ionic_active_pct='45.0', ionic_dead_pct='55.0'), 'v1.1 D3')
    _neg7('㉔h ★ D4 — 상별 개수 합 ≠ 전체 개수 (AM_P 1 + AM_S 3 ≠ 활성 5) 이면 거부',
          _bad10('q2', AM_S_ionic_active_pct='30.0', AM_S_ionic_dead_pct='70.0'), 'v1.1 D4')
    _neg7('㉔i ★ D5 — 무접촉 개수 (2) > 고립 위험 개수 (1 — SE 접촉 0 ⊂ 0–1 개) 이면 거부',
          _bad10('q2', ionic_dead_pct=repr(400 / 11), ionic_no_se_pct=repr(200 / 11), AM_S_ionic_dead_pct='40.0', AM_S_ionic_no_se_pct='20.0'),
          'v1.1 D5')
    _neg7('㉔j ★ 상 있음 — 상이 있는데 상별 분해가 비면 거부 (bimodal AM_P 단절 빈칸)', _bad10('q2', AM_P_ionic_dead_pct=''), 'v1.1 상 있음')
    _w10k = _wa10(dec=False)
    _w10k['rows']['q2']['ionic_active_pct'] = '45.0'
    _neg7('㉔k ★ D3 — 분해 키가 없는 옛 배치에서도 활성 비율 × AM 수 / 100 이 정수 개수가 아니면 거부 (①의 원천)',
          lambda: _b10(w=_w10k), 'v1.1 D3')
    chk('㉔l ★ ③ 가장 큰 SE 덩어리 — SE 비율 · 벽 간격 대비 z 폭 (= 기록 z 폭 × 전 입자 z 범위 / 벽 간격) · 전 입자 z 범위 대비 원값 · 관문 C 2 행',
        _m10.get('se_largest_comp_frac') == repr(0.37) and _m10.get('se_largest_comp_wall_span_frac') == repr(0.95 * 41.0 / 40.0)
        and _p10.get('se_largest_comp_env_span_frac') == repr(0.5) and _p10.get('se_largest_comp_wall_span_frac') == repr(0.5 * 41.0 / 40.0)
        and _r10.get('se_cluster_checked') == 2)
    chk('㉔m ★ 열 사전 — ③ 분모 (벽 간격 · 전 입자 z 범위 — 바닥 아래로 샌 입자) · 가장 큰 = SE 수 기준 · 1 을 넘을 수 있음 · v1.1 ③ · 출처 harvest_v3',
        '벽 간격' in _g10('se_largest_comp_wall_span_frac', 'meaning') and '1 을 넘' in _g10('se_largest_comp_wall_span_frac', 'meaning')
        and '전 입자' in _g10('se_largest_comp_env_span_frac', 'meaning') and 'SE 수' in _g10('se_largest_comp_frac', 'meaning')
        and 'v1.1 ③' in _g10('se_largest_comp_frac', 'meaning') and _g10('se_largest_comp_frac', 'source') == 'harvest_v3')
    _neg7('㉔n ★ C1 — 덩어리 SE 비율 × SE 수 가 정수가 아니면 거부 (0.375 × 100)', lambda: _b10(hv=_hq10(b1=_bd10(frac=0.375))), 'v1.1 C1')
    _neg7('㉔o ★ C1 — band SE 수 ≠ 수확 phase_counts SE 이면 거부', lambda: _b10(hv=_hq10(b1=_bd10(n_se=99))), 'v1.1 C1')
    _neg7('㉔p ★ C2 — 전 입자 z 범위 대비 z 폭 > 1 이면 거부 (덩어리 ⊂ 전 입자)', lambda: _b10(hv=_hq10(b1=_bd10(zs=1.2))), 'v1.1 C2')
    _neg7('㉔q ★ C3 — 벽 간격의 플래튼 ≠ 수확 plate_z_sim 이면 거부 (다른 판)', lambda: _b10(hv=_hq10(b1=_bd10(pz=39.0))), 'v1.1 C3')
    _neg7('㉔r ★ ③ 수확 세대 혼합 — 일부 행만 덩어리 기록이 있으면 거부', lambda: _b10(hv=dict(_hq10(), q2=_hq9()['q2'])), '덩어리')
    #  ═══ ㉕ ⑤⑥⑦ (J20-s · 1저자 비준 10-04 *"권고대로"*) — F1 근접쌍 · Auerbach 힘 기반 파괴 · 접촉 면적 (A_dem_geometric) 묶음 ═══════════════
    #   새 계산 없음 (10-01 d1ec42fba 배치 값) · 묶음 f1 · fracture · area (접촉 분석 단계 산출) · 명시 제외 (path_hop_area = LHS-32 · δ 판 ·
    #   상 쌍별 파괴 · physics 면적) · 관문 ⑤F1 · ⑥R1–R3 · ⑦A1–A5 (10-01 실측 130/130 · 64/64 가 통과한 항등식) · 접촉 0 쌍 평균 = 빈칸 · 총합 0 채움
    _ST = ('intact', 'microcrack', 'multicrack', 'fragmentation', 'pulverization')

    def _frf(counts):
        n_t = sum(counts)
        d = {f'n_{s_}_force_AM_AM': str(n_) for s_, n_ in zip(_ST, counts)}
        d['n_total_AM_AM_force'] = str(n_t)
        if n_t:
            d.update({f'frac_{s_}_force_pct': repr(round(100.0 * n_ / n_t, 2)) for s_, n_ in zip(_ST, counts)})
            d['fracture_index_force'] = repr(round((counts[3] + counts[4]) / n_t, 4))
        return d
    _R_SE = 0.5

    def _eff(tot, nse=100, r_=_R_SE):
        return repr(2.0 * tot / (nse * 4.0 * _mth.pi * r_ * r_))

    def _wa11():
        w = _wa10()
        new_ok = (['se_se_cn_aug', 'se_se_cn_aug_std', 'se_se_cn_aug_n_extra', 'se_se_cn_aug_h_spread_sim', 'fracture_index_force',
                   'n_total_AM_AM_force', 'se_se_cn_eff_area', 'am_am_mean_area', 'am_am_total_area']
                  + [f'frac_{s_}_force_pct' for s_ in _ST] + [f'n_{s_}_force_AM_AM' for s_ in _ST]
                  + [f'area_{p_}_{st}' for p_ in ('AM_P_AM_P', 'AM_P_AM_S', 'AM_S_AM_S', 'AM_P_SE', 'AM_S_SE', 'AM전체_SE', 'SE_SE')
                     for st in ('mean', 'total')]
                  #  근처의 census ✅ 열 — 인계 제외 (명시)
                  + ['path_hop_area_mean', 'path_hop_area_min_mean', 'frac_intact_pct', 'fracture_index', 'n_intact_AM_AM', 'n_total_AM_AM',
                     'frac_intact_force_AM_P-AM_S_pct', 'n_intact_force_AM_P-AM_P', 'n_total_force_AM_S-AM_S', 'area_SE_SE_total_physics']
                  #  쌍별 개수 — census 전부 ✅ (① 접촉 묶음 · J20-g) · 접촉 0 쌍 시험 (㉕e · f) 에 필요
                  + [f'area_{p_}_n' for p_ in ('AM_P_AM_P', 'AM_P_AM_S', 'AM_S_AM_S', 'AM_P_SE', 'AM_S_SE')])
        for k_ in new_ok:
            w['verdict'][k_] = '✅ 쓴다(이름 주의)' if 'area' in k_ else '✅ 쓴다'
        w['why'] = {k_: f'why:{k_}' for k_ in w['verdict']}
        q1_, q2_ = w['rows']['q1'], w['rows']['q2']
        #  q1 mono (웹앱 이름 AM_S · SE 100 · AM 11) — F1: 18 + 2 · 50 / 100 = 19 · 면적 = 평균 × 개수 (SE–SE 900 · AM_S–AM_S 11 · AM_S–SE 40)
        q1_.update(se_se_cn_aug='19.0', se_se_cn_aug_std='2.6', se_se_cn_aug_n_extra='50', se_se_cn_aug_h_spread_sim='1e-05',
                   area_SE_SE_mean='0.004', area_SE_SE_total='3.6', se_se_cn_eff_area=_eff(3.6),
                   area_AM_S_AM_S_mean='0.02', area_AM_S_AM_S_total='0.22', am_am_total_area='0.22', am_am_mean_area='0.02',
                   area_AM_S_SE_mean='0.01', area_AM_S_SE_total='0.4',
                   path_hop_area_mean='0.5', path_hop_area_min_mean='0.1', frac_intact_pct='50.0', fracture_index='0.2',
                   n_intact_AM_AM='5', n_total_AM_AM='10', area_SE_SE_total_physics='9.9', **_frf([6, 3, 1, 1, 0]))
        q1_.update({'area_AM전체_SE_mean': '0.01', 'area_AM전체_SE_total': '0.4'})
        #  q2 bimodal (AM_P 1 · AM_S 10) — AM_P–AM_P 접촉 0 (개수 0 · 총합 0.0 · 평균 키 없음 = 웹앱 그대로) · 비관통 (eff_area_perc 없음)
        q2_.update(se_se_cn_aug='17.0', se_se_cn_aug_std='3.1', se_se_cn_aug_n_extra='50', se_se_cn_aug_h_spread_sim='1e-05',
                   area_SE_SE_mean='0.005', area_SE_SE_total='4.0', se_se_cn_eff_area=_eff(4.0),
                   area_AM_P_AM_P_n='0', area_AM_P_AM_P_total='0.0',
                   area_AM_P_AM_S_mean='0.04', area_AM_P_AM_S_total='0.2', area_AM_S_AM_S_mean=repr(0.46 / 17), area_AM_S_AM_S_total='0.46',
                   am_am_total_area='0.66', am_am_mean_area='0.03',
                   area_AM_P_SE_mean='0.012', area_AM_P_SE_total='0.36', area_AM_S_SE_mean='0.01', area_AM_S_SE_total='0.5',
                   **_frf([10, 6, 3, 2, 1]))
        q2_.update({'area_AM전체_SE_mean': repr(0.86 / 80), 'area_AM전체_SE_total': '0.86',
                    'frac_intact_force_AM_P-AM_S_pct': '40.0', 'n_intact_force_AM_P-AM_P': '0', 'n_total_force_AM_S-AM_S': '17'})
        return w
    _dq11 = [dict(r_, r_SE_um=repr(_R_SE)) for r_ in _dq7]
    _G567 = 'contact,percolation,f1,fracture,area'

    def _b11(w=None, hv=None, dq=None, groups=_G567):
        return build_handover(dq or _dq11, hv or _hq10(), webapp=w or _wa11(), webapp_groups=groups)
    try:
        _o11, _c11, _r11 = _b11()
        _e11 = ''
    except Exception as e:                                                # noqa: BLE001
        _o11, _c11, _r11, _e11 = [], [], {}, f'{type(e).__name__}: {e}'
    _m11 = next((r_ for r_ in _o11 if r_['case_id'] == 'q1'), {})
    _p11 = next((r_ for r_ in _o11 if r_['case_id'] == 'q2'), {})
    _new11 = (['se_se_cn_aug', 'se_se_cn_aug_std', 'se_se_cn_aug_n_extra', 'se_se_cn_aug_h_spread_sim', 'fracture_index_force',
               'n_total_AM_AM_force'] + [f'frac_{s_}_force_pct' for s_ in _ST] + [f'n_{s_}_force_AM_AM' for s_ in _ST]
              + ['se_se_cn_eff_area', 'se_se_cn_eff_area_perc', 'am_am_mean_area', 'am_am_total_area', 'area_SE_SE_mean', 'area_SE_SE_total',
                 'area_AM_P_SE_mean', 'area_AM_P_AM_P_total', 'area_AM전체_SE_total'])
    chk('㉕a ★ ⑤⑥⑦ 묶음 — F1 4 · 힘 기반 파괴 12 · 면적 (쌍별 평균 · 총합 · eff_area · AM–AM) 열이 실린다' + (f' — {_e11}' if _e11 else ''),
        not _e11 and all(c in _c11 for c in _new11))
    _excl11 = ('path_hop_area_mean', 'path_hop_area_min_mean', 'frac_intact_pct', 'fracture_index', 'n_intact_AM_AM', 'n_total_AM_AM',
               'frac_intact_force_AM_P-AM_S_pct', 'n_intact_force_AM_P-AM_P', 'n_total_force_AM_S-AM_S', 'area_SE_SE_total_physics')
    chk('㉕b ★ 명시 제외 — path_hop_area (LHS-32) · δ 판 · 상 쌍별 파괴 · physics 면적은 census ✅ 여도 안 실린다 · wa_excluded 가 사유를 준다',
        not _e11 and not any(c in _c11 for c in _excl11) and all(wa_excluded(c) for c in _excl11)
        and not any(wa_excluded(c) for c in _new11) and 'LHS-32' in (wa_excluded('path_hop_area_mean') or ''))
    try:
        _c11u = build_handover(_dq11, _hq10(), webapp=_wa11(), webapp_groups=_G567, wa_reviewed_only=False)[1]
    except Exception as e:                                                # noqa: BLE001
        _c11u = [f'ERR {type(e).__name__}: {e}']
    chk('㉕c 검토 목록 밖 경로 (wa_reviewed_only=False) 에서도 제외 열은 안 실린다 — 제외는 묶음 · 검토와 무관하게 먼저',
        not any(c in _c11u for c in _excl11) and 'se_se_cn_aug' in _c11u)
    chk('㉕d ★ mono (설계 AM_P · 웹앱 이름 AM_S) — 면적 상별 열은 설계 상 칸 · 없는 상 칸 빈칸 · AM전체 · SE–SE · F1 · 파괴 전체는 그대로',
        _m11.get('area_AM_P_AM_P_mean') == '0.02' and _m11.get('area_AM_P_AM_P_total') == '0.22' and _m11.get('area_AM_S_AM_S_total') == ''
        and _m11.get('area_AM_P_SE_total') == '0.4' and _m11.get('area_AM_P_AM_S_mean') == '' and _m11.get('area_AM전체_SE_total') == '0.4'
        and _m11.get('area_SE_SE_total') == '3.6' and _m11.get('se_se_cn_aug') == '19.0'
        and _m11.get('fracture_index_force') == repr(round(1 / 11, 4)))
    chk('㉕e ★ 접촉 0 쌍 (q2 AM_P–AM_P) — 개수 0 · 총합 0.0 (측정된 0) · 평균 빈칸 (N/A — 접촉 0 개에서 평균은 정의되지 않는다)',
        _p11.get('area_AM_P_AM_P_n') == '0' and _p11.get('area_AM_P_AM_P_total') == '0.0' and _p11.get('area_AM_P_AM_P_mean') == '')
    _w11z = _wa11()
    for _k in ('area_AM_P_AM_P_n', 'area_AM_P_AM_P_total'):
        _w11z['rows']['q2'].pop(_k, None)
    try:
        _p11z = next(r_ for r_ in _b11(w=_w11z)[0] if r_['case_id'] == 'q2')
        _e11z = ''
    except Exception as e:                                                # noqa: BLE001
        _p11z, _e11z = {}, f'{type(e).__name__}: {e}'
    chk('㉕f 옛 배치 (접촉 0 쌍 키 없음) — 두 상이 다 있으면 개수 0 · 총합 0.0 으로 채운다 (J20-h 와 같은 규칙) · 평균은 빈칸' + (f' — {_e11z}' if _e11z else ''),
        _p11z.get('area_AM_P_AM_P_n') == '0' and _p11z.get('area_AM_P_AM_P_total') == '0.0' and _p11z.get('area_AM_P_AM_P_mean') == '')
    chk('㉕g 관문 보고 — ⑤ · ⑥ · ⑦ 2 행씩 · 제외 열 수',
        _r11.get('wa_f1_checked') == 2 and _r11.get('wa_frac_checked') == 2 and _r11.get('wa_area_checked') == 2
        and _r11.get('wa_excluded_dropped', 0) >= len(_excl11))
    _dm11 = {d['column']: d for d in column_dictionary(_c11, webapp=_wa11())} if _c11 else {}
    _g11 = lambda c, k: (_dm11.get(c) or {}).get(k, '')                   # noqa: E731
    chk('㉕h ★ 열 사전 — F1 항등식 · 10 nm 출처 없는 상수 / 파괴 LHS-31 (마지막 프레임 · K_IC_P 0.3) · δ 판 금지 / 면적 A_dem_geometric · 총량 · '
        '접촉 0 쌍 평균 N/A · eff_area 식 · J20-s',
        '2 × se_se_cn_aug_n_extra' in _g11('se_se_cn_aug', 'meaning') and '10 nm' in _g11('se_se_cn_aug', 'caveat')
        and '출처 없는' in _g11('se_se_cn_aug', 'caveat') and 'LHS-31' in _g11('fracture_index_force', 'caveat')
        and '마지막 프레임' in _g11('fracture_index_force', 'caveat') and 'K_IC_P 0.3' in _g11('frac_microcrack_force_pct', 'caveat')
        and 'δ' in _g11('n_total_AM_AM_force', 'caveat') and 'A_dem_geometric' in _g11('area_SE_SE_total', 'caveat')
        and '총량' in _g11('area_SE_SE_total', 'caveat') and 'N/A' in _g11('area_AM_P_AM_P_mean', 'meaning')
        and '4π' in _g11('se_se_cn_eff_area', 'meaning') and 'J20-s' in _g11('se_se_cn_aug', 'meaning')
        and _g11('am_am_total_area', 'source') == 'webapp' and '설계 상 칸' in _g11('area_AM_P_SE_mean', 'meaning'))

    def _w11(q='q1', **kv):
        w = _wa11()
        w['rows'][q].update(kv)
        return w
    _neg7('㉕i ★ ⑤F1 — aug ≠ se_se_cn + 2 · n_extra / N_SE 이면 거부 (19.5)', lambda: _b11(w=_w11(se_se_cn_aug='19.5')), '⑤F1')
    _neg7('㉕j ★ ⑤F1 — done 행에 aug 가 비면 거부 (F1 이 꺼진 배치를 N/A 로 싣지 않는다)', lambda: _b11(w=_w11(se_se_cn_aug='')), '⑤F1')
    _neg7('㉕k ★ ⑥R1 — 단계 개수 합 ≠ n_total_AM_AM_force 이면 거부', lambda: _b11(w=_w11(n_intact_force_AM_AM='7')), '⑥R1')
    _neg7('㉕l ★ ⑥R2 — 비율이 100 · n/N 에서 반올림 폭 (0.005) 을 넘으면 거부 (+0.02)',
          lambda: _b11(w=_w11(frac_intact_force_pct=repr(round(600 / 11, 2) + 0.02))), '⑥R2')
    try:
        _b11(w=_w11(frac_intact_force_pct=repr(600 / 11)))
        _ok_r = True
    except Exception:                                                     # noqa: BLE001
        _ok_r = False
    chk('㉕m ⑥R2 — 반올림 안 한 값 (100 · 6/11 그대로) 도 받는다 · 기본 픽스처 = 웹앱처럼 둘째 자리 반올림 (㉕a 가 받는다)', _ok_r)
    _neg7('㉕n ★ ⑥R2 — fracture_index_force 가 (파편화 + 분쇄)/N 에서 반올림 폭 (5e-5) 을 넘으면 거부', lambda: _b11(w=_w11(fracture_index_force='0.0919')), '⑥R2')
    _neg7('㉕o ★ ⑥R3 — 힘 기반 전체 > am_am_n_contacts 이면 거부 (fn > 0 AM–AM 접촉 ⊂ 전 AM–AM 접촉)', lambda: _b11(w=_w11(**_frf([7, 3, 1, 1, 0]))), '⑥R3')
    _neg7('㉕p ★ ⑦A1 — 평균 × 개수 ≠ 총합 이면 거부 (SE–SE)', lambda: _b11(w=_w11(area_SE_SE_total='3.7', se_se_cn_eff_area=_eff(3.7))), '⑦A1')
    _neg7('㉕q ★ ⑦A1 — 접촉 0 쌍에 0 이 아닌 평균이 있으면 거부', lambda: _b11(w=_w11('q2', area_AM_P_AM_P_mean='0.01')), '⑦A1')
    _neg7('㉕r ★ ⑦A2 — AM전체–SE 총합 ≠ 상별 합 이면 거부',
          lambda: _b11(w=_w11('q2', **{'area_AM전체_SE_total': '0.9', 'area_AM전체_SE_mean': repr(0.9 / 80)})), '⑦A2')
    _neg7('㉕s ★ ⑦A3 — am_am_total_area ≠ AM–AM 쌍 총합 이면 거부', lambda: _b11(w=_w11('q2', am_am_total_area='0.7', am_am_mean_area=repr(0.7 / 22))), '⑦A3')
    _neg7('㉕t ★ ⑦A3 — am_am_mean_area ≠ am_am_total_area / am_am_n_contacts 이면 거부', lambda: _b11(w=_w11('q2', am_am_mean_area='0.031')), '⑦A3')
    _neg7('㉕u ★ ⑦A4 — se_se_cn_eff_area ≠ 2 · SE–SE 총합 / (N_SE · 4π r_SE²) 이면 거부', lambda: _b11(w=_w11(se_se_cn_eff_area='0.03')), '⑦A4')
    _neg7('㉕v ★ ⑦A4 — 설계에 r_SE_um 이 없으면 거부 (eff_area 를 잴 수 없다)', lambda: _b11(dq=_dq7), '⑦A4')
    _neg7('㉕w ★ ⑦A5 — 비관통 (percolation_pct 0) 인데 eff_area_perc 가 있으면 거부', lambda: _b11(w=_w11('q2', se_se_cn_eff_area_perc='0.01')), '⑦A5')
    _neg7('㉕x ★ ⑦A5 — 관통인데 eff_area_perc 가 비면 거부', lambda: _b11(w=_w11(se_se_cn_eff_area_perc='')), '⑦A5')
    try:
        _c11c = build_handover(_dq11, _hq10(), webapp=dict(_wa11(), stop_after='contact'), webapp_groups='f1,fracture,area')[1]
    except Exception as e:                                                # noqa: BLE001
        _c11c = [f'ERR {type(e).__name__}: {e}']
    chk('㉕y 접촉 단계 배치 (stop_after=contact) 도 f1 · fracture · area 를 받는다 (다 접촉 분석 단계 산출) · 그 묶음만 싣는다 (관문은 웹앱 원 행으로)',
        'se_se_cn_aug' in _c11c and 'fracture_index_force' in _c11c and 'area_SE_SE_mean' in _c11c
        and 'se_se_cn' not in _c11c and 'percolation_pct' not in _c11c)
    chk('㉕z 검토 기록 — 새 열 전부 1저자 검토 (J20-s) · 제외 열은 검토 목록에 없다',
        all(wa_reviewed(c) and 'J20-s' in (wa_review_note(c) or '') for c in _new11) and not any(wa_reviewed(c) for c in _excl11))
    #  ═══ ㉖ RGL-03 (Codex 10-05 · P1 · 1저자 비준 "권고대로") — network 배치 → ⑤⑥⑦ 인계 ══════════════════════════════════════════════════
    #   `lhs_webapp_batch --stop-after network` = 접촉 분석 (required · causal) → 피복 → network solver → 머지 (NET_MERGE_KEYS = σ · R · 전력 몫만) →
    #   망 정지 계약 · Stage E 앞 (webapp/app.py PIPELINE_STOP_AFTER) — 다섯 묶음 (전부 접촉 분석 단계 산출) 을 다 낸다.  옛 판은 WA_STAGE_GROUPS 가
    #   contact · coverage 만 알아 network 배치를 일률 거부했고, 안내는 유효 묶음 이름도 아닌 'network' 를 요구했다.
    #   양성 대조 = **생산 경로 형식** (SELF-86 — mock 만 쓰다 놓친 결함): ① run_batch 가 쓰는 status (schema · stop_after · 케이스 rec) 를 실제
    #   `lhs_webapp_batch.write_outputs` 로 쓰고 `load_webapp` 으로 읽는다 (metrics_flat 왕복 = 없는 키가 빈 문자열이 되는 생산 모양) ·
    #   ② 실데이터 `d1ec42fba` (1저자 WSL 생산 status.json · 130 + 64) 의 stop_after 만 network 로 바꾼 배치 (run_batch 의 network rec = + network_run_id).
    import lhs_webapp_batch as _LWB
    _tdn = pathlib.Path(tempfile.mkdtemp(prefix='lhsdd_rgl03_'))
    _rt26 = pathlib.Path(__file__).resolve().parent.parent

    def _wbatch(stop, w=None, sub='b'):
        """생산 배치 형식으로 쓰고 읽는다 — status = run_batch 의 키 (최상위 schema · stop_after · harvest_dir · cohort · runs · 케이스 rec) ·
        metrics_flat = `lhs_webapp_batch.write_outputs` · census = load_webapp 이 읽는 TSV."""
        w = w or _wa11()
        d = _tdn / f'{sub}_{stop}'
        st = dict(schema=_LWB.SCHEMA, cases={}, stop_after=stop, harvest_dir='harvest', cohort='cohort.tsv',
                  runs=[dict(started='2026-10-05T00:00:00', git_sha='0' * 40, dirty=False)])
        for q_, s_ in w['status'].items():
            rec = dict(case=q_, when='2026-10-05T00:00:00', stop_after=stop, status=s_['status'],
                       failed_stages=list(s_.get('failed_stages') or []), stages=[dict(step='Parse', rc=0, ok=True)],
                       mode='bimodal', type_map='1:AM_P,2:AM_S,3:SE', sha=dict(s_.get('sha') or {}), mesh_pick='exact', contact_scan={}, atom_frames=1,
                       elapsed_s=1.0)
            if stop == 'network':
                rec['network_run_id'] = f'RUN-{q_}'                     # run_batch — 이번 실행의 망 세대 (망 정지 계약이 본 도장)
            st['cases'][q_] = rec
        _LWB.write_outputs(d, st, {q_: dict(r_, case=q_) for q_, r_ in w['rows'].items()})
        with (d / 'census.tsv').open('w', encoding='utf-8', newline='') as fh:
            cw_ = csv.writer(fh, delimiter='\t', lineterminator='\n')
            cw_.writerow(['column', 'verdict', 'why'])
            for k_, v_ in w['verdict'].items():
                cw_.writerow([k_, v_, w['why'].get(k_, '')])
        return load_webapp(d, d / 'census.tsv')

    def _acc(fn):
        """(결과, '') 또는 (None, 예외 문자열) — 받아야 하는 입력의 양성 대조용."""
        try:
            return fn(), ''
        except Exception as e:                                            # noqa: BLE001
            return None, f'{type(e).__name__}: {e}'

    def _msg(fn):
        """거부 문구 (FillRefusal) — 받으면 '' · 다른 예외면 'NOT_FILLREFUSAL …'."""
        try:
            fn()
            return ''
        except FillRefusal as e:
            return str(e)
        except Exception as e:                                            # noqa: BLE001
            return f'NOT_FILLREFUSAL {type(e).__name__}: {e}'
    try:
        try:
            _lwc, _lwn, _e26 = _wbatch('contact'), _wbatch('network'), ''
        except Exception as e:                                            # noqa: BLE001
            _lwc, _lwn, _e26 = {}, {}, f'{type(e).__name__}: {e}'
        _res_c, _ec26 = _acc(lambda: build_handover(_dq11, _hq10(), webapp=_lwc, webapp_groups='f1,fracture,area'))
        _res_n, _en26 = _acc(lambda: build_handover(_dq11, _hq10(), webapp=_lwn, webapp_groups='f1,fracture,area'))
        _oc26, _cc26, _rc26 = _res_c or ([], [], {})
        _on26, _cn26, _rn26 = _res_n or ([], [], {})
        _er26 = _e26 or _ec26 or _en26
        chk('㉖a ★ RGL-03 — network 배치 (생산 형식 · write_outputs → load_webapp) 를 f1,fracture,area 로 받는다 · 표 = 같은 배치의 contact 판과 같다 · '
            '관문 ⑤ · ⑥ · ⑦ 2 행씩' + (f' — {_er26}' if _er26 else ''),
            not _er26 and _lwn.get('stop_after') == 'network' and _on26 == _oc26 and _cn26 == _cc26
            and all(_rn26.get(k_) == 2 for k_ in ('wa_f1_checked', 'wa_frac_checked', 'wa_area_checked'))
            and all(c_ in _cn26 for c_ in ('se_se_cn_aug', 'fracture_index_force', 'area_SE_SE_mean')))
        _res_cb, _ec26b = _acc(lambda: build_handover(_dq11, _hq10(), webapp=_lwc, webapp_groups=_G567))
        _res_nb, _en26b = _acc(lambda: build_handover(_dq11, _hq10(), webapp=_lwn, webapp_groups=_G567))
        _oc26b, _cc26b, _ = _res_cb or ([], [], {})
        _on26b, _cn26b, _rn26b = _res_nb or ([], [], {})
        chk('㉖b ★ network 배치를 다섯 묶음 전부로 (contact,percolation,f1,fracture,area) — 표 = contact 판 · 관문 ⑤ · ⑥ · ⑦ · ② · 7c 2 행씩'
            + (f' — {_en26b or _ec26b}' if (_en26b or _ec26b) else ''),
            not (_en26b or _ec26b) and _on26b == _oc26b and _cn26b == _cc26b
            and all(_rn26b.get(k_) == 2 for k_ in ('wa_f1_checked', 'wa_frac_checked', 'wa_area_checked', 'wa_perc_checked',
                                                    'wa_amse_identity_checked')))
        for _lab26, _dsg, _hdir, _uni, _wdir, _n26 in (
                ('130', DESCRIPTOR_FILL_EXPECTED['path'], 'docs/data/lhs_descriptors_cov_1e09f661d', DEFAULT_UNION_TSV,
                 'docs/data/lhs_webapp_contact_d1ec42fba', 130),
                ('64', 'docs/data/lhsx_design_adapted_20260929.csv', 'docs/data/lhsx_descriptors_cov_1e09f661d',
                 'docs/data/lhs_union_20260927/lhsx64_union.tsv', 'docs/data/lhsx_webapp_contact_d1ec42fba', 64)):
            try:
                _src26 = _rt26 / _wdir
                _st26 = json.loads((_src26 / 'status.json').read_text(encoding='utf-8'))
                _st26['stop_after'] = 'network'
                for _rec26 in _st26['cases'].values():
                    _rec26.update(stop_after='network', network_run_id='RUN-RELABEL')
                _dn26 = _tdn / f'real_{_lab26}'
                _dn26.mkdir()
                (_dn26 / 'status.json').write_text(json.dumps(_st26, ensure_ascii=False, indent=1) + '\n', encoding='utf-8')
                shutil.copyfile(_src26 / 'metrics_flat.csv', _dn26 / 'metrics_flat.csv')
                with (_rt26 / _dsg).open(encoding='utf-8-sig') as _fh:
                    _rows26 = list(csv.DictReader(_fh))
                _hv26, _uv26 = load_harvest(_rt26 / _hdir), load_union(_rt26 / _uni)
                _oc, _cc, _rc = build_handover(_rows26, _hv26, union=_uv26, webapp=load_webapp(_src26), webapp_groups=_G567)
                _resn, _er = _acc(lambda: build_handover(_rows26, _hv26, union=_uv26, webapp=load_webapp(_dn26), webapp_groups=_G567))
                _on, _cn, _rn = _resn or ([], [], {})
                #  replay_g4 (Codex 증거) 의 산술을 내보낸 표에서 — 단계 % · 지수의 최대 잔차 (반올림 반폭 안이어야)
                _mp = _mf = 0.0
                for _o in _oc:
                    _nt = float(_o['n_total_AM_AM_force'])
                    for _s in FRAC_STAGES:
                        _mp = max(_mp, abs(float(_o[f'frac_{_s}_force_pct']) - 100.0 * float(_o[f'n_{_s}_force_AM_AM']) / _nt))
                    _mf = max(_mf, abs(float(_o['fracture_index_force'])
                                       - (float(_o['n_fragmentation_force_AM_AM']) + float(_o['n_pulverization_force_AM_AM'])) / _nt))
                chk(f'㉖c ★ 실데이터 {_lab26} (d1ec42fba 생산 status · stop_after 만 network) — 다섯 묶음 {len(_on)}/{_n26} 행 · 표 = contact 판 · '
                    f'관문 ⑤⑥⑦ {_rn.get("wa_f1_checked")} · {_rn.get("wa_frac_checked")} · {_rn.get("wa_area_checked")} 행 · '
                    f'단계 % 최대 잔차 {_mp:.6f} %p (≤ 0.005) · 지수 {_mf:.3e} (≤ 5e-5)' + (f' — {_er}' if _er else ''),
                    not _er and len(_on) == _n26 and _on == _oc and _cn == _cc
                    and all(_rn.get(k_) == _n26 for k_ in ('wa_f1_checked', 'wa_frac_checked', 'wa_area_checked'))
                    and _mp <= 0.005 and _mf <= 5e-5)
            except Exception as e:                                        # noqa: BLE001
                chk(f'㉖c 실데이터 {_lab26} ({type(e).__name__}: {e})', False)
        _m26 = _msg(lambda: build_handover(_dq11, _hq10(), webapp=_lwn))
        chk('㉖d ★ network 배치를 묶음 제한 없이 부르면 거부 (뒤 단계 열이 빈칸 = 측정된 N/A) — 안내는 유효한 묶음 이름 (contact · percolation · '
            'f1 · fracture · area) · 정지점 이름 "network" 를 묶음처럼 요구하지 않는다 (옛 안내 "--webapp-groups network 의 부분집합")' + f' — {_m26[:80]}',
            bool(_m26) and not _m26.startswith('NOT_') and all(g_ in _m26 for g_ in WA_GROUPS) and '--webapp-groups network' not in _m26)
        _mb26 = _msg(lambda: build_handover(_dq11, _hq10(), webapp=dict(_lwn, stop_after='stage_e'), webapp_groups='f1'))
        chk('㉖e ★ 모르는 정지점 (stage_e) 은 거부 — 안내 = 아는 정지점 (contact · coverage · network) · 모르는 이름을 묶음처럼 요구하지 않는다'
            + f' — {_mb26[:80]}',
            bool(_mb26) and not _mb26.startswith('NOT_') and all(s_ in _mb26 for s_ in ('contact', 'coverage', 'network'))
            and '--webapp-groups stage_e' not in _mb26)
        _neg('㉖f network 배치에 모르는 묶음 (stress) 이 섞이면 거부', lambda: build_handover(_dq11, _hq10(), webapp=_lwn, webapp_groups='f1,stress'))
        WA_STAGE_GROUPS['_probe'] = ('contact',)                             # 역량이 다섯보다 좁은 (가상) 정지점 — 부분집합 관문이 살아 있나
        try:
            _neg('㉖g 단계 역량 밖 묶음은 거부 (가상 정지점 _probe = contact 만 · contact,f1)',
                 lambda: build_handover(_dq11, _hq10(), webapp=dict(_lwn, stop_after='_probe'), webapp_groups='contact,f1'))
            _res_p, _ep26 = _acc(lambda: build_handover(_dq11, _hq10(), webapp=dict(_lwn, stop_after='_probe'), webapp_groups='contact'))
            _cp26 = (_res_p or ([], [], {}))[1]
            chk('㉖h 단계 역량 안 묶음은 받는다 (_probe · contact)' + (f' — {_ep26}' if _ep26 else ''),
                not _ep26 and 'se_se_cn' in _cp26 and 'se_se_cn_aug' not in _cp26)
        finally:
            WA_STAGE_GROUPS.pop('_probe', None)
        try:
            _sp26, _ap26 = set(), set()
            for n_ in ast.walk(ast.parse(pathlib.Path(_LWB.__file__).read_text(encoding='utf-8'))):
                if (isinstance(n_, ast.Call) and getattr(n_.func, 'attr', '') == 'add_argument' and n_.args
                        and isinstance(n_.args[0], ast.Constant) and n_.args[0].value == '--stop-after'):
                    for k_ in n_.keywords:
                        if k_.arg == 'choices':
                            _sp26.update(ast.literal_eval(k_.value))
            for n_ in ast.parse((_rt26 / 'webapp' / 'app.py').read_text(encoding='utf-8')).body:
                if isinstance(n_, ast.Assign) and any(getattr(t_, 'id', '') == 'PIPELINE_STOP_AFTER' for t_ in n_.targets):
                    _ap26.update(s_ for s_ in ast.literal_eval(n_.value) if s_)
            chk(f'㉖i ★ 정지점 동기 — 배치 --stop-after {sorted(_sp26)} · 웹앱 PIPELINE_STOP_AFTER {sorted(_ap26)} 가 전부 WA_STAGE_GROUPS 에 있다 '
                '(생산 쪽에 정지점이 생기면 단계 역량을 적기 전까지 여기서 걸린다)',
                bool(_sp26) and bool(_ap26) and _sp26 <= set(WA_STAGE_GROUPS) and _ap26 <= set(WA_STAGE_GROUPS))
        except Exception as e:                                            # noqa: BLE001
            chk(f'㉖i 정지점 동기 ({type(e).__name__}: {e})', False)
    finally:
        shutil.rmtree(_tdn, ignore_errors=True)
    #  ═══ ㉗ RGL-05 (Codex 10-05 · P2 · 1저자 비준 "권고대로") — ⑤⑥⑦ 관문 순서 = 선택 묶음의 원천 근거 열 → 유한 → 형/범위 → 식 · 최종 레코드 재검 ═══
    #   반례 = Codex probe_g4.py 의 accepted=True 변이를 우리 픽스처 (_wa11) 로 옮긴 것 — 하나씩 **그 관문** 이 거부해야 한다 (tag) ·
    #   합법 (명시 접촉 0 + 평균 없음 · 평균 0 대입 · 세 키 모두 없는 옛 접촉 0 쌍 · 반올림 반폭 경계 0.005 / 5e-5 · AM–AM 접촉 0 침대) 은 통과 유지.
    def _w11x(q='q1', drop=(), **kv):
        w = _wa11()
        for k_ in drop:
            w['rows'][q].pop(k_, None)
        w['rows'][q].update(kv)
        return w
    _neg7('㉗a ★ ⑥R2 유한 — frac_intact_force_pct NaN (abs(NaN) > 여유 가 거짓이라 식 검사를 우회해 NaN 이 표에 남던 길 · Codex fraction_pct_nan)',
          lambda: _b11(w=_w11(frac_intact_force_pct='nan')), '⑥R2 유한')
    _neg7('㉗b ★ ⑥R2 유한 — fracture_index_force NaN (Codex fracture_index_nan)', lambda: _b11(w=_w11(fracture_index_force='nan')), '⑥R2 유한')
    _neg7('㉗c ★ ⑦A1 유한 — 접촉 있는 쌍의 평균 NaN (q1 AM_S–AM_S · Codex area_positive_count_nan_mean)',
          lambda: _b11(w=_w11(area_AM_S_AM_S_mean='nan')), '⑦A1 유한')
    _neg7('㉗d ★ ⑦A1 유한 — 쌍 총합 · AM–AM 총합 · 평균 NaN (Codex area_nan_total)',
          lambda: _b11(w=_w11(area_AM_S_AM_S_total='nan', am_am_total_area='nan', am_am_mean_area='nan')), '⑦A1 유한')
    _neg7('㉗e ★ ⑤F1 유한 — F1 h = inf (양수 검사가 유한성을 대신했다 · Codex f1_h_infinity)',
          lambda: _b11(w=_w11(se_se_cn_aug_h_spread_sim='inf')), '⑤F1 유한')
    _neg7('㉗f ★ ⑤F1 범위 — F1 표준편차 음수 (Codex f1_std_negative)', lambda: _b11(w=_w11(se_se_cn_aug_std='-1')), '⑤F1 범위')
    _neg7('㉗g ★ ⑤F1 필수 — F1 표준편차만 빈칸 (F1 이 낸 행인데 한 열만 빠짐 = 기술적 결측 · Codex f1_std_missing)',
          lambda: _b11(w=_w11x(drop=('se_se_cn_aug_std',))), '⑤F1 필수')
    _neg7('㉗h ★ ⑤F1 필수 — f1 만 실을 때 원천 근거 se_se_cn 이 빠지면 거부 (식 검사를 건너뛰지 않는다 · Codex f1_missing_cn)',
          lambda: _b11(w=_w11x(drop=('se_se_cn',)), groups='f1'), '⑤F1 필수')
    _neg7('㉗i ★ ⑤F1 필수 — 근거 빠짐 + aug −999 (Codex f1_missing_cn_corrupt_aug · −999 가 표에 남던 것)',
          lambda: _b11(w=_w11x(drop=('se_se_cn',), se_se_cn_aug='-999'), groups='f1'), '⑤F1 필수')
    _neg7('㉗j ★ ⑤F1 유한 — n_extra NaN (옛 판은 int(NaN) 예외로 죽었다 — FillRefusal 이 아니었다)',
          lambda: _b11(w=_w11(se_se_cn_aug_n_extra='nan')), '⑤F1 유한')
    _neg7('㉗k ★ ⑤F1 범위 — n_extra 가 정수가 아니면 (50.5 — 개수 = 0 이상 정수)', lambda: _b11(w=_w11(se_se_cn_aug_n_extra='50.5')), '⑤F1 범위')
    _neg7('㉗l ★ ⑥R3 필수 — fracture 만 실을 때 원천 근거 am_am_n_contacts 가 빠지면 거부 (R3 를 건너뛰지 않는다 · Codex fracture_missing_am_total)',
          lambda: _b11(w=_w11x(drop=('am_am_n_contacts',)), groups='fracture'), '⑥R3 필수')
    _neg7('㉗m ★ ⑥R1 유한 — 단계 개수 NaN (옛 판 int(NaN) 예외)', lambda: _b11(w=_w11(n_intact_force_AM_AM='nan')), '⑥R1 유한')
    _neg7('㉗n ★ ⑥R2 범위 — 분쇄 비율 −0.004 (반올림 반폭 안이어도 [0, 100] 밖 · Codex pct_negative_inside_tolerance)',
          lambda: _b11(w=_w11(frac_pulverization_force_pct='-0.004')), '⑥R2 범위')
    _neg7('㉗o ★ ⑥R2 범위 — 지수 −0.00004 (전부 무손상 · 반폭 안이어도 [0, 1] 밖 · Codex fi_negative_inside_tolerance)',
          lambda: _b11(w=_w11('q2', **dict(_frf([22, 0, 0, 0, 0]), fracture_index_force='-0.00004'))), '⑥R2 범위')
    _neg7('㉗p ★ ⑦A5 필수 — area 만 실을 때 원천 근거 percolation_pct 가 빠지면 거부 (관통 침대 q1 · Codex area_missing_percolation)',
          lambda: _b11(w=_w11x(drop=('percolation_pct',)), groups='area'), '⑦A5 필수')
    _neg7('㉗q ★ ⑦A5 필수 — 비관통 침대 근거 빠짐 + eff_area_perc 0.4 (Codex area_missing_pp_corrupt_eap · 0.4 가 표에 남던 것)',
          lambda: _b11(w=_w11x('q2', drop=('percolation_pct',), se_se_cn_eff_area_perc='0.4'), groups='area'), '⑦A5 필수')
    _neg7('㉗r ★ ⑦A5 유한 — eff_area_perc NaN (Codex area_perc_nan)', lambda: _b11(w=_w11(se_se_cn_eff_area_perc='nan'), groups='area'), '⑦A5 유한')
    _neg7('㉗s ★ ⑦A5 범위 — eff_area_perc −1 (Codex area_perc_negative)', lambda: _b11(w=_w11(se_se_cn_eff_area_perc='-1'), groups='area'), '⑦A5 범위')
    _neg7('㉗t ★ ⑦A4 필수 — eff_area 가 빠지면 거부 (A4 를 건너뛰지 않는다 · Codex area_missing_global_eff)',
          lambda: _b11(w=_w11x(drop=('se_se_cn_eff_area',)), groups='area'), '⑦A4 필수')
    _neg7('㉗u ★ ⑦A3 필수 — am_am_total_area 가 빠지면 거부 (평균만 남은 AM–AM · Codex area_missing_am_total)',
          lambda: _b11(w=_w11x(drop=('am_am_total_area',)), groups='area'), '⑦A3 필수')
    _neg7('㉗v ★ ⑦A1 필수 — 접촉 0 쌍의 개수만 빠지고 평균 0.01 · 총합 0 (검사 전 누락 → 검사 뒤 0 채움 · Codex missing_pair_count_positive_mean)',
          lambda: _b11(w=_w11x('q2', drop=('area_AM_P_AM_P_n',), area_AM_P_AM_P_mean='0.01')), '⑦A1 필수')
    _neg7('㉗w ★ J20-h — 접촉 묶음만 실을 때도 개수 빈칸 + 같은 쌍 평균 0.01 이면 0 으로 채우지 않는다 (누락 → 0 채움 금지)',
          lambda: _b11(w=_w11x('q2', drop=('area_AM_P_AM_P_n',), area_AM_P_AM_P_mean='0.01'), groups='contact'), 'J20-h')
    _hq27 = _hq10()
    _hq27['q2'] = dict(_hq27['q2'], phase_counts={'AM_P': 0, 'AM_S': 11, 'SE': 100})
    _neg7('㉗x ★ ⑦A1 상 없음 — 상이 없는 쌍에 값 (bimodal 인데 수확 phase_counts AM_P 0 · 웹앱 행에 AM_P 쌍) — 다른 침대 · 다른 상의 값',
          lambda: _b11(hv=_hq27, groups='area'), '⑦A1 상 없음')

    def _w11z0(**kv):
        """q2 = AM–AM 접촉 0 침대 — 쌍 개수 0 · 총합 0.0 · 평균 키 없음 (calc_interface_area) · am_am 평균 0 대입 (calc_am_am_cn) · 파괴 키 없음
        (calc_fracture_stages 가 {} 를 낸다) · J20-j 항등식에 맞춘 am_am_cn 0."""
        w = _wa11()
        q = w['rows']['q2']
        for k_ in [k for k in q if 'force' in k and k.startswith(('n_', 'frac_', 'fracture_index'))]:
            q.pop(k_)
        for p_ in ('AM_P_AM_S', 'AM_S_AM_S'):
            q[f'area_{p_}_n'], q[f'area_{p_}_total'] = '0', '0.0'
            q.pop(f'area_{p_}_mean', None)
        q.update(am_am_n_contacts='0', am_am_cn='0.0', am_am_cn_std='0.0', am_am_total_area='0', am_am_mean_area='0')
        q.update(kv)
        return w
    _res_z, _ez27 = _acc(lambda: _b11(w=_w11z0()))
    _oz27, _cz27, _rz27 = _res_z or ([], [], {})
    _pz27 = next((r_ for r_ in _oz27 if r_['case_id'] == 'q2'), {})
    chk('㉗y ★ AM–AM 접촉 0 침대 — 통과 · am_am 평균 빈칸 (N/A — calc_am_am_cn 의 0 대입은 비운다) · 총합 0 (측정된 0) · 쌍 총합 0.0 · 쌍 평균 빈칸 · '
        '파괴 열 빈칸 (N/A) · 파괴 관문은 그 상태를 확인한 행으로 센다 (2 행)' + (f' — {_ez27}' if _ez27 else ''),
        not _ez27 and _pz27.get('am_am_mean_area') == '' and _pz27.get('am_am_total_area') == '0'
        and _pz27.get('area_AM_S_AM_S_total') == '0.0' and _pz27.get('area_AM_S_AM_S_mean') == ''
        and _pz27.get('n_total_AM_AM_force') == '' and _pz27.get('fracture_index_force') == '' and _rz27.get('wa_frac_checked') == 2)
    _neg7('㉗z ★ ⑦A3 — AM–AM 접촉 0 인데 am_am_mean_area 0.01 이면 거부 (접촉 0 개에서 평균은 정의되지 않는다)',
          lambda: _b11(w=_w11z0(am_am_mean_area='0.01')), '⑦A3')
    _neg7('㉗za ★ ⑦A3 — AM–AM 접촉 0 인데 am_am_total_area 0.1 이면 거부', lambda: _b11(w=_w11z0(am_am_total_area='0.1')), '⑦A3')
    _neg7('㉗zb ★ ⑥R1 필수 — AM–AM 접촉 0 인데 파괴 키 일부만 (분쇄 비율 0.0) 있으면 거부 (상태 혼합)',
          lambda: _b11(w=_w11z0(frac_pulverization_force_pct='0.0')), '⑥R1 필수')
    _pos27 = []
    for _lab27, _fn27, _ok27 in (
            ('세 키 모두 없는 옛 접촉 0 쌍', lambda: _b11(w=_w11x('q2', drop=('area_AM_P_AM_P_n', 'area_AM_P_AM_P_total', 'area_AM_P_AM_P_mean'))),
             lambda o_: o_.get('area_AM_P_AM_P_n') == '0' and o_.get('area_AM_P_AM_P_total') == '0.0' and o_.get('area_AM_P_AM_P_mean') == ''),
            ('명시 접촉 0 + 평균 0 대입', lambda: _b11(w=_w11('q2', area_AM_P_AM_P_mean='0')),
             lambda o_: o_.get('area_AM_P_AM_P_n') == '0' and o_.get('area_AM_P_AM_P_total') == '0.0' and o_.get('area_AM_P_AM_P_mean') == '')):
        _r27, _e27 = _acc(_fn27)
        _q27 = next((r_ for r_ in (_r27 or ([],))[0] if r_['case_id'] == 'q2'), {})
        if _e27 or not _ok27(_q27):
            _pos27.append(f'{_lab27}: {_e27 or _q27.get("area_AM_P_AM_P_mean")}')
    chk(f'㉗zc 합법 접촉 0 쌍 (세 키 모두 없음 · 평균 0 대입) 은 그대로 받는다 — 개수 0 · 총합 0.0 · 평균 빈칸  {_pos27 or ""}', not _pos27)
    _p_ex27, _f_ex27 = 600 / 11, 1 / 11                                     # q1 단계 개수 [6, 3, 1, 1, 0] · N 11
    _bad27 = [d_ for d_ in (0.004999, 0.005)
              if _acc(lambda d_=d_: _b11(w=_w11(frac_intact_force_pct=repr(_p_ex27 + d_)), groups='fracture'))[1]]
    _bad27 += [d_ for d_ in (4.999e-5, 5e-5)
               if _acc(lambda d_=d_: _b11(w=_w11(fracture_index_force=repr(_f_ex27 + d_)), groups='fracture'))[1]]
    chk(f'㉗zd 반올림 반폭 경계는 그대로 통과 (단계 % +0.004999 · +0.005 · 지수 +4.999e-5 · +5e-5 — round(·, 2) · round(·, 4) 의 반폭) · '
        f'범위 관문이 경계를 좁히지 않는다  {_bad27 or ""}', not _bad27)
    _neg7('㉗ze ★ 반폭 밖 단계 % (+0.005001) 는 거부', lambda: _b11(w=_w11(frac_intact_force_pct=repr(_p_ex27 + 0.005001)), groups='fracture'), '⑥R2')
    _neg7('㉗zf ★ 반폭 밖 지수 (+5.001e-5) 는 거부', lambda: _b11(w=_w11(fracture_index_force=repr(_f_ex27 + 5.001e-5)), groups='fracture'), '⑥R2')

    def _fin27(o_, pn_, amn_='11'):
        """최종 레코드 관문 직접 — 정규화가 맞으면 쏘지 않는 이중 안전장치라 함수를 직접 부른다."""
        _tk = ['area_AM_P_AM_P_total', 'area_AM_P_AM_P_mean', 'am_am_total_area', 'am_am_mean_area']
        return _msg(lambda: globals()['_wa_s567_final']('q', o_, _tk, pn_, amn_))
    _g27 = {'area_AM_P_AM_P_total': '0.0', 'area_AM_P_AM_P_mean': '', 'am_am_total_area': '0.22', 'am_am_mean_area': '0.02'}
    _f27 = [_fin27(dict(_g27, area_AM_P_AM_P_mean='0.01'), {'area_AM_P_AM_P': '0'}),       # 접촉 0 인데 평균
            _fin27(dict(_g27, area_AM_P_AM_P_total=''), {'area_AM_P_AM_P': '0'}),          # 접촉 0 인데 총합 빈칸 (측정된 0 이어야)
            _fin27(dict(_g27, area_AM_P_AM_P_total='0.1'), {'area_AM_P_AM_P': ''}),        # 개수 빈칸 (상 부재 · N/A) 인데 총합
            _fin27(dict(_g27, am_am_mean_area='nan'), {'area_AM_P_AM_P': '0'}),            # NaN
            _fin27(_g27, {'area_AM_P_AM_P': '0'}, amn_='0'),                               # AM–AM 접촉 0 인데 평균 · 총합
            _fin27(dict(_g27, am_am_mean_area='0.03'), {'area_AM_P_AM_P': '0'})]           # 평균 × 개수 ≠ 총합
    _f27ok = _fin27(_g27, {'area_AM_P_AM_P': '0'})
    chk('㉗zg ★ 최종 레코드 관문 (0 채움 · 이름 옮김 · 0 대입 비움 뒤 내보내는 행을 다시 본다) — 정상은 통과 · 접촉 0 평균 · 접촉 0 총합 빈칸 · '
        'N/A 쌍의 총합 · NaN · AM–AM 접촉 0 의 평균 · 평균 × 개수 ≠ 총합 은 거부' + (f' — {_f27ok[:90]}' if _f27ok else ''),
        not _f27ok and all(e_ and not e_.startswith('NOT_') and '최종 레코드' in e_ for e_ in _f27))
    chk('㉗zh 열 사전 — AM–AM 접촉 0 = 평균 N/A · 총합 0 (측정된 0) · 쌍 0 채움은 세 키 모두 빈칸일 때만 (누락 → 0 채움 금지) · AM–AM 접촉 0 의 '
        '파괴 열 = N/A · ⑤⑥⑦ 검토 기록에 RGL-05 관문 순서 (원천 근거 → 유한 → 형/범위 → 식)',
        'N/A' in _g11('am_am_mean_area', 'meaning') and 'RGL-05' in _g11('am_am_mean_area', 'meaning')
        and '측정된 0' in _g11('am_am_total_area', 'meaning')
        and '세 키' in _g11('area_AM_P_AM_P_n', 'meaning') and '누락 → 0 채움 금지' in _g11('area_AM_P_AM_P_n', 'meaning')
        and 'calc_fracture_stages 가 키를 안 쓴다' in _g11('n_total_AM_AM_force', 'meaning')
        and all('RGL-05' in _g11(c_, 'meaning') and '원천 근거' in _g11(c_, 'meaning')
                for c_ in ('se_se_cn_aug', 'fracture_index_force', 'area_SE_SE_mean')))

    #  ㉘ Codex 10-05 재검증 Q5 (1저자 비준) — Love–Weber (④b) 열은 194 건 인계에서 **명시 제외** (frame_unverified — 원자 · 접촉 · mesh
    #   덤프의 같은 프레임 미인증: parse_liggghts 가 TIMESTEP 을 CSV 로 옮기지 않고 세 파일을 따로 고른다).  지금은 어느 묶음에도 없지만
    #   census · 묶음 · 검토 목록이 바뀌어도 새어 들어오지 않게 제외 목록에 둔다 (WA_EXCLUDED — 묶음 · 검토와 무관하게 먼저).
    _LW28 = ('stress_cv_lw', 'stress_cv_lw_nowall', 'stress_ratio_AM_P_lw', 'stress_ratio_AM_S_lw', 'stress_ratio_SE_lw',
             'stress_ratio_AM_P_lw_nowall', 'stress_ratio_AM_S_lw_nowall', 'stress_ratio_SE_lw_nowall', 'stress_lw_status',
             'stress_lw_definition', 'stress_lw_contract', 'stress_lw_quantity', 'stress_lw_nowall_status', 'stress_lw_wall_frac_AM_P',
             'stress_lw_floor_frac_SE', 'stress_lw_n_wall_floor', 'stress_lw_n_wall_plate', 'stress_lw_plate_flag',
             'stress_lw_check_virial_total_rel', 'stress_lw_asym_frob_median', 'stress_lw_input_digest_atoms', 'stress_lw_timestep')
    _miss28 = [c_ for c_ in _LW28 if not str(wa_excluded(c_) or '').startswith('frame_unverified')]
    chk('㉘a ★ LW 열 전부 (stress_cv_lw · stress_ratio_<상>_lw · _nowall · stress_lw_* 메타 · 벽 표지) = 명시 제외 · 사유 frame_unverified '
        '(TIMESTEP · 파일 따로 선택 · 프레임 대응 미인증)' + (f' — 제외 안 된 열 {_miss28}' if _miss28 else ''),
        not _miss28 and 'TIMESTEP' in (wa_excluded('stress_cv_lw') or '') and 'parse_liggghts' in (wa_excluded('stress_cv_lw') or ''))
    chk('㉘b LW 제외 패턴은 옛 σ_VM 열 · 다른 열을 잡지 않는다 (stress_cv · stress_ratio_<상> · stress_z_layer_cv · stress_cv_status · se_se_cn)',
        not any(str(wa_excluded(c_) or '').startswith('frame_unverified') for c_ in
                ('stress_cv', 'stress_ratio_AM_P', 'stress_ratio_AM_S', 'stress_ratio_SE', 'stress_z_layer_cv', 'stress_cv_status',
                 'stress_cv_contract', 'se_se_cn', 'coverage_AM_P_mean')))
    _w28 = _wa()
    for _c in _LW28:                                  # 최악 — census 가 LW 열을 ✅ 로 찍고 값도 있다
        _w28['verdict'][_c] = '✅ 쓴다'
        _w28['why'][_c] = f'why:{_c}'
        for _q in ('q1', 'q2'):
            _w28['rows'][_q][_c] = '1.5'
    _dq28 = [{'case_id': 'q1'}, {'case_id': 'q2'}]                       # ⑲ 의 설계 · 수확 (뒤에서 _dq 가 mono 설계로 바뀌었다)
    _hq28 = {'q1': _hq('q1', eps_s=-2.0, th=30.0), 'q2': _hq('q2', eps_s=20.0, th=40.0)}
    try:
        _o28, _c28, _r28 = build_handover(_dq28, _hq28, webapp=_w28, wa_reviewed_only=False)   # 묶음 제한 없음 · 검토 목록 밖 (옛 기제)
        _o28b, _c28b, _r28b = build_handover(_dq28, _hq28, webapp=_wa(), wa_reviewed_only=False)
        _e28 = ''
    except Exception as e:                                                # noqa: BLE001
        _o28 = _c28 = _o28b = _c28b = []
        _r28 = _r28b = {}
        _e28 = f'{type(e).__name__}: {e}'
    chk('㉘c ★ 최악 경로 (census ✅ · 묶음 제한 없음 · 검토 목록 밖) 에서도 LW 열은 안 실린다 · 제외 수에 센다 · 나머지 열 · 값은 LW 없는 배치와 '
        '같다' + (f' — {_e28}' if _e28 else '') + (f' — 실린 LW 열 {[c_ for c_ in _LW28 if c_ in _c28]}' if any(c_ in _c28 for c_ in _LW28) else ''),
        not _e28 and bool(_c28) and not any(c_ in _c28 for c_ in _LW28) and _c28 == _c28b and _o28 == _o28b
        and _r28.get('wa_excluded_dropped', 0) - _r28b.get('wa_excluded_dropped', 0) == len(_LW28))
    _wn = globals().get('write_exclusion_notes')
    _tdn = pathlib.Path(tempfile.mkdtemp(prefix='lds_excl_'))
    try:
        _pn = _tdn / 'h_excluded.tsv'
        if callable(_wn):
            _wn(_pn)
        _rn = []
        if _pn.exists():
            with _pn.open(encoding='utf-8') as _fhn:
                _rn = list(csv.DictReader(_fhn, delimiter='\t'))
    finally:
        shutil.rmtree(_tdn, ignore_errors=True)
    _lwn = [r_ for r_ in _rn if str(r_.get('reason', '')).startswith('frame_unverified')]
    chk('㉘d ★ 생성기가 쓰는 제외 노트 (<인계표>_excluded.tsv · 열 사전 옆) — LW 행 (패턴이 stress_cv_lw 를 잡는다 · 사유 frame_unverified) · '
        '보류 열 (tortuosity_dijkstra_SE · LHS-08) · 다른 명시 제외 (LHS-32) 도 같은 표',
        len(_lwn) == 1 and re.fullmatch(_lwn[0].get('pattern', '^$'), 'stress_cv_lw') is not None
        and any(r_.get('pattern') == 'tortuosity_dijkstra_SE' and 'LHS-08' in r_.get('reason', '') for r_ in _rn)
        and any('LHS-32' in r_.get('reason', '') for r_ in _rn))
    #  ═══ ㉙ 망 τ 묶음 (v1.2 · Codex 10-05 3차 재검증 §3 Q5 · §6-5 "⑤⑥⑦ · 망 τ 만 · LW 제외") ════════════════════════════════════════════
    #   network 정지 배치 (`lhs_webapp_batch --stop-after network`) 의 케이스 폴더 (`<--work>/results/<case>/`) 에서 **tau_flux 자신** (`case_row`) 이
    #   낸 이온 망 인계 열 (f · f_gap · tau2 · tau · 상태 · 사유 · 메타 — v2 §5-1 · 모드 꼬리) 을 싣는다.  출처 관문 = 배치 기록 (status.json 의
    #   network_run_id · metrics_flat 행) ↔ 폴더 (full_metrics 도장 · network_provenance.json · 입력 digest · dual ↔ full_metrics 투영).
    #   반례 먼저 — 옛 코드는 'tau' 묶음 · 로더 · tau= 인자가 없다 (전부 실패해야 한다).  픽스처 = 실 생산자 레코드
    #   (`network_conductivity._run_all_networks` · test_tau_flux 와 같은 침대) + 실 도장 (`pipeline_service.stamp_network_provenance`) +
    #   생산 배치 형식 (`lhs_webapp_batch.write_outputs` → `load_webapp` · metrics_flat 행 = 웹앱 열 + row_for 처럼 편 full_metrics).
    import contextlib as _cl29
    import io as _io29
    import subprocess as _sp29
    _rt29 = pathlib.Path(__file__).resolve().parent.parent
    _td29 = pathlib.Path(tempfile.mkdtemp(prefix='lhsdd_tau29_'))
    _G29 = _G567 + ',tau'
    try:
        if str(_rt29 / 'webapp') not in sys.path:
            sys.path.append(str(_rt29 / 'webapp'))
        import pipeline_service as _PS29
        import tau_flux as _TF29
        import network_conductivity as _NC29
        import network_projection_preflight as _NPP29                      # 웹앱 망 투영의 읽기 전용 재현 (app._network_projection 과 같은 규칙)
        _e29 = ''
    except Exception as e:                                                # noqa: BLE001
        _PS29 = _TF29 = _NC29 = _NPP29 = None
        _e29 = f'{type(e).__name__}: {e}'
    _LT29 = globals().get('load_tau_results')
    _TD29 = globals().get('tau_net_define')

    def _net29(A_, C_, plate_, temp_c=None):
        """실 생산자 레코드 두 모드 (디스크 모양 = JSON 왕복)."""
        with _cl29.redirect_stdout(_io29.StringIO()):
            r_ = {cm: _NC29._run_all_networks(A_, C_, [1], [], {1: 'SE'}, 1.0, plate_, 10.0, 10.0, None, contact_mode=cm, temp_c=temp_c)
                  for cm in ('hertzian', 'physics')}
        return json.loads(json.dumps(r_))

    def _led29(A_, plate_, eps_u=None):
        """장부 (L_gap · L_mc · φ_mc) — eps_u 를 주면 φ_mc·L_mc = φ_구합·L_gap (basis_check ok) · 없으면 L_mc = L_gap."""
        phi_s = sum(4.0 / 3.0 * math.pi * a_['radius'] ** 3 for a_ in A_.values()) / (10.0 * 10.0 * plate_)
        if eps_u is None:
            return {'thickness_um': plate_, 'thickness_mass_conserving_um': plate_, 'phi_se_mass_conserving': phi_s}
        return {'thickness_um': plate_, 'thickness_mass_conserving_um': plate_ * phi_s / (1.0 - eps_u),
                'phi_se_mass_conserving': 1.0 - eps_u}

    def _mut29(d_, mode, fn):
        d2 = json.loads(json.dumps(d_))
        for m_ in (('hertzian', 'physics') if mode == 'both' else (mode,)):
            fn(d2[m_])
        return d2
    _VAR29 = {}
    try:
        _A29 = {i: {'type': 1, 'x': 0.0, 'y': 0.0, 'z': float(z), 'radius': 1.0} for i, z in enumerate(range(21), 1)}     # 관통 사슬 · 판 20
        _C29 = [{'id1': i, 'id2': i + 1, 'contact_area': 0.1, 'delta': 0.05} for i in range(1, 21)]
        _B29 = {i: {'type': 1, 'x': 3.0 * i, 'y': 0.0, 'z': float(z), 'radius': 1.0} for i, z in ((1, 0.0), (2, 1.0), (3, 2.0))}
        _B29.update({10 + k: {'type': 1, 'x': 0.0, 'y': 5.0, 'z': float(z), 'radius': 1.0} for k, z in enumerate(range(10, 21))})
        _BC29 = [{'id1': 10 + k, 'id2': 11 + k, 'contact_area': 0.1, 'delta': 0.05} for k in range(10)]            # 위 띠에만 닿는 비관통
        _L1A = {i: {'type': 1, 'x': 0.0, 'y': 0.0, 'z': 0.5 * k, 'radius': 0.4} for i, k in enumerate(range(81), 1)}    # 띠 폴백 L1 · 판 40
        _L1C = [{'id1': i, 'id2': i + 1, 'contact_area': 0.1 * 0.16, 'delta': 0.05 * 0.4} for i in range(1, 81)]
        #  띠 폴백 L2 (test_pipeline_provenance 의 band_l2 와 같은 침대 — z 0..10 · 판 40 · L1 의 위 띠가 비어 관측 z 범위 띠)
        _L2A = {i: {'type': 1, 'x': 0.0, 'y': 0.0, 'z': 0.5 * k, 'radius': 0.4} for i, k in enumerate(range(21), 1)}
        _L2C = [{'id1': i, 'id2': i + 1, 'contact_area': 0.1 * 0.16, 'delta': 0.05 * 0.4} for i in range(1, 21)]
        _nok, _nnp, _nl1, _n60 = (_net29(_A29, _C29, 20.0), _net29(_B29, _BC29, 20.0), _net29(_L1A, _L1C, 40.0),
                                  _net29(_A29, _C29, 20.0, temp_c=60.0))
        _nl2 = _net29(_L2A, _L2C, 40.0)
        _lok, _lnp = _led29(_A29, 20.0, eps_u=0.97), _led29(_B29, 20.0, eps_u=0.97)
        _VAR29 = {'OK': (_nok, _lok, 37.0),
                  'MBCB': (_nok, dict(_lok, thickness_mass_conserving_um=20.0, phi_se_mass_conserving=1e-4), 37.0),
                  'BAND': (_nl1, _led29(_L1A, 40.0), 37.0),
                  'BAND2': (_nl2, _led29(_L2A, 40.0), 37.0),
                  'NC_PERC': (_nnp, _lnp, 37.0),                                   # 솔버 비관통 ↔ calc_percolation 37 % (G2)
                  'NC_INVALID': (_mut29(_nok, 'physics', lambda r_: r_.update(sigma_full_mScm=r_['sigma_full_mScm'] * 4)), _lok, 37.0),
                  'NC_MISSING': (_mut29(_nok, 'both', lambda r_: r_.pop('boundary_rule')), _lok, 37.0),     # 안 A 전 산출물
                  'NC_TEMP': ({'hertzian': _nok['hertzian'], 'physics': _n60['physics']}, _lok, 37.0),
                  'NC_SOLVER': (_mut29(_nok, 'hertzian', lambda r_: r_.update(sigma_full_status='not_computed')), _lok, 37.0),
                  'NPERC': (_nnp, _lnp, 0.0)}
    except Exception as e:                                                # noqa: BLE001
        _e29 = _e29 or f'픽스처 {type(e).__name__}: {e}'

    def _case29(res, q, var, rid, prov_rid=None, prov_status='success'):
        """케이스 폴더 = 웹앱 결과 폴더 모양 — atoms/contacts.csv · 실 도장 · 망 JSON 넷 · full_metrics (장부 + 망 투영 + 도장).
        ★ 10-05 RGLR3-02 — 망 JSON 은 생산자 CLI (`network_conductivity.py --contact-mode both`) 처럼 넷 다 쓴다: dual + 모드 파일 둘 (= dual 의 그 모드) +
        legacy (= Hertz 사본).  full_metrics 의 망 투영 = 웹앱 머지 규칙 그대로 (`network_projection_preflight.simulate_merge` — `NET_MERGE_KEYS` 를
        legacy 에서 · physics 미러 · 꼬리 키 · None 값은 키를 안 쓴다 = 실 생산자 폴더 실측: 비관통이면 sigma_full 키 없음).  옛 픽스처는 dual 과 σ 네 키만
        써서, 인계 때 망 정지 계약 (전 사본 · 투영 · σ₀ 짝) 을 다시 돌리면 정상 폴더도 통과할 수 없었다 (그 계약을 통과한 배치 폴더 모양이 아니다).
        ★ 10-06 밤 (G2RR-01) — 도장은 망 JSON 을 쓴 **뒤** 찍는다 (실 게시자 순서 — `publish_network_candidate` 는 솔버 출력이 있는 폴더에 찍고 네 세대 값을
        그 dual 에서 유도한다).  옛 픽스처는 JSON 앞에서 찍어 세대 2 레코드 위 도장의 네 세대 값이 None · False 였다 (= Codex all_null 모양 — 새 인계 대조가
        거부한다).  옛 세대 변이 (`_G1` — 10-06 저녁 전 생산자) 는 그 시절 게시자의 도장 모양 (세대 키 없음 = 194 v1.2 · 확인된 역사 도장 스키마)."""
        du_, le_, pp_ = _VAR29[var]
        d = res / q
        d.mkdir(parents=True, exist_ok=True)
        (d / 'atoms.csv').write_text(f'id,type,x,y,z,radius\n1,1,0.0,0.0,0.0,1.0\n# {q} {var}\n', encoding='utf-8')
        (d / 'contacts.csv').write_text(f'id1,id2\n# {q} {var}\n', encoding='utf-8')
        inputs = {n_: _PS29.file_digest(str(d / n_)) for n_ in ('atoms.csv', 'contacts.csv')}
        (d / 'network_conductivity_dual.json').write_text(json.dumps(du_), encoding='utf-8')
        for n_, m_ in (('network_conductivity_hertzian.json', 'hertzian'), ('network_conductivity_physics.json', 'physics'),
                       ('network_conductivity.json', 'hertzian')):
            (d / n_).write_text(json.dumps(du_[m_]), encoding='utf-8')
        _pv29 = _PS29.stamp_network_provenance(str(d), prov_rid or rid, inputs, prov_status,
                                               argv={'type_map': '1:SE', 'scale': 1, 'contact_mode': 'both'})
        if var.endswith('_G1'):
            for k_ in _PS29.PROVENANCE_GENERATION_KEYS:
                _pv29.pop(k_, None)
            (d / _PS29.PROVENANCE_FILE).write_text(json.dumps(_pv29), encoding='utf-8')
        fm = dict(le_, percolation_pct=pp_)                                  # 투영 전 = 접촉 분석 장부
        (d / 'full_metrics.json').write_text(json.dumps(fm), encoding='utf-8')
        fm.update(_NPP29.simulate_merge(str(d))[1])
        fm.update(network_run_id=rid, active_network_run_id=rid, network_solver_status='success')
        (d / 'full_metrics.json').write_text(json.dumps(fm), encoding='utf-8')
        return fm

    def _bat29(sub, fms, stop='network', st=None, rid=None, w=None):
        """생산 배치 형식 → load_webapp.  st = {q: 상태} 덮어쓰기 · rid = {q: run id (None = 기록 없음)}."""
        w = w or _wa11()
        d = _td29 / sub
        stj = dict(schema=_LWB.SCHEMA, cases={}, stop_after=stop, harvest_dir='harvest', cohort='cohort.tsv',
                   runs=[dict(started='2026-10-05T00:00:00', git_sha='0' * 40, dirty=False)])
        rows_ = {}
        for q_, s_ in w['status'].items():
            rec = dict(case=q_, when='2026-10-05T00:00:00', stop_after=stop, status=(st or {}).get(q_, s_['status']),
                       failed_stages=[], stages=[dict(step='Parse', rc=0, ok=True)], mode='bimodal', type_map='1:AM_P,2:AM_S,3:SE',
                       sha=dict(s_.get('sha') or {}), mesh_pick='exact', contact_scan={}, atom_frames=1, elapsed_s=1.0)
            if stop == 'network':
                v_ = (rid or {}).get(q_, f'RUN-{q_}')
                if v_ is not None:
                    rec['network_run_id'] = v_
            stj['cases'][q_] = rec
            r_ = dict(w['rows'][q_], case=q_)
            r_.update({k_: v_ for k_, v_ in (fms.get(q_) or {}).items() if not isinstance(v_, (dict, list))})
            rows_[q_] = r_
        _LWB.write_outputs(d, stj, rows_)
        with (d / 'census.tsv').open('w', encoding='utf-8', newline='') as fh:
            cw_ = csv.writer(fh, delimiter='\t', lineterminator='\n')
            cw_.writerow(['column', 'verdict', 'why'])
            for k_, v_ in w['verdict'].items():
                cw_.writerow([k_, v_, w['why'].get(k_, '')])
        return load_webapp(d, d / 'census.tsv')

    def _sc29(sub, q1='OK', q2='NPERC', **kw):
        """시나리오 — 케이스 폴더 (q1 · q2 변이) + 그 폴더 full_metrics 를 행에 편 network 배치."""
        res = _td29 / sub / 'results'
        fms = {q_: _case29(res, q_, v_, f'RUN-{q_}') for q_, v_ in (('q1', q1), ('q2', q2)) if v_ is not None}
        return _bat29(sub + '/batch', fms, **kw), res, fms

    def _ld29(res, lw):
        if _LT29 is None:
            raise RuntimeError('load_tau_results 없음 (옛 코드)')
        return _LT29(res, lw)

    def _bh29(lw, tv, groups=_G29, w_rev=True):
        return build_handover(_dq11, _hq10(), webapp=lw, webapp_groups=groups, tau=tv, wa_reviewed_only=w_rev)

    def _orc29(var):
        """오라클 — tau_flux 가 같은 입력에 내는 열 (tau_flux 자신의 직렬화 `_cell`)."""
        du_, le_, pp_ = _VAR29[var]
        return {k_: _TF29._cell(v_) for k_, v_ in _TF29.ion_columns(du_, dict(le_, percolation_pct=pp_), pp_).items()}
    _tc29 = list(_TF29.column_names()) if _TF29 is not None else []
    try:
        try:
            _lw29, _res29, _ = _sc29('a')
            _tv29 = _ld29(_res29, _lw29)
            _o29, _c29, _r29 = _bh29(_lw29, _tv29)
            _e29a = _e29
        except Exception as e:                                            # noqa: BLE001
            _lw29 = _tv29 = None
            _o29, _c29, _r29, _e29a = [], [], {}, _e29 or f'{type(e).__name__}: {e}'
        _m29 = next((r_ for r_ in _o29 if r_['case_id'] == 'q1'), {})
        _p29 = next((r_ for r_ in _o29 if r_['case_id'] == 'q2'), {})
        chk('㉙a ★ network 배치 + 망 τ 묶음 (--webapp-groups …,tau + 케이스 폴더) — tau_flux 열 전부 (10-06 밤부터 50 · 세 모드 (hertz · physics · '
            'hertz_h12 부록) f · f_gap · tau2 · tau · 상태 · 사유 · 메타 · 세대 표기 + 공통 σ₀ · T · 기준) 이 표 끝에 tau_flux 순서로 · 모든 케이스 '
            '(q1 관통 OK · q2 비관통 NOT_PERCOLATING) 값 = tau_flux 그대로 · 출처 관문 2 행' + (f' — {_e29a}' if _e29a else ''),
            not _e29a and bool(_tc29) and _c29[-len(_tc29):] == _tc29
            and all(_m29.get(c_) == _orc29('OK')[c_] for c_ in _tc29) and all(_p29.get(c_) == _orc29('NPERC')[c_] for c_ in _tc29)
            and _m29.get('ion_net_status_hertz') == _m29.get('ion_net_status_physics') == 'OK'
            and _p29.get('ion_net_status_hertz') == _p29.get('ion_net_status_physics') == 'NOT_PERCOLATING'
            and _r29.get('tau_checked') == 2)

        def _sem29(r_, m, st):
            f_, fg, t2, t_ = (r_.get(f'f_ion_{m}'), r_.get(f'f_ion_{m}_gap'), r_.get(f'tau2_ion_{m}'), r_.get(f'tau_ion_{m}'))
            if st in ('OK', 'MODEL_BELOW_CONTINUUM_BOUND'):                # 값 유지 (MBCB = 표지 · 빈칸으로 거르지 않는다)
                return (all(x_ not in ('', None) for x_ in (f_, fg, t2, t_)) and abs(float(t_) - math.sqrt(float(t2))) <= 1e-12 * float(t_)
                        and (float(t2) < 1.0) == (st == 'MODEL_BELOW_CONTINUUM_BOUND'))
            if st == 'NOT_PERCOLATING':                                       # f = 0 (물리적 0) · tau2 · tau 빈칸 (= ∞)
                return f_ == '0.0' and fg == '0.0' and t2 == '' and t_ == ''
            return f_ == fg == t2 == t_ == ''                                 # BAND_FALLBACK · NOT_COMPUTED — 빈칸 (0 이 아니다)
        #  ★ 10-05 RGLR3-02 — 정지 계약을 통과한 배치 폴더 모양 (모든 사본이 서로 맞는) 의 상태 넷 (L0 · 연속체 하한 · 띠 L1 · 띠 L2) 은 옛 판과 같은 칸으로
        #    싣는다 (비관통은 ㉙a q2 · ㉙k — q1 의 웹앱 행은 관통 침대 값이라 비관통 폴더를 얹으면 ⑦A5 가 먼저 막는다).  옛 판의 NOT_COMPUTED 다섯 (기술적 결손) 은
        #    아래 ㉙b2 — done 배치 행으로는 거부한다 (τ P4).
        _EXP29 = {'OK': (('OK', ''), ('OK', '')), 'MBCB': (('MODEL_BELOW_CONTINUUM_BOUND', ''),) * 2,
                  'BAND': (('BAND_FALLBACK', ''),) * 2, 'BAND2': (('BAND_FALLBACK', ''),) * 2}
        _bad29b = {}
        for _v29, _x29 in _EXP29.items():
            try:
                _lwv, _rsv, _ = _sc29(f'b_{_v29}', q1=_v29)
                _r1 = next(r_ for r_ in _bh29(_lwv, _ld29(_rsv, _lwv))[0] if r_['case_id'] == 'q1')
                _got = tuple((_r1.get(f'ion_net_status_{m_}'), _TF29.reason_code(_r1.get(f'ion_net_status_reason_{m_}'))) for m_ in ('hertz', 'physics'))
                _orc = _orc29(_v29)
                _same = all(_r1.get(c_) == _orc[c_] for c_ in _tc29)
                _sem = all(_sem29(_r1, m_, s_) for m_, (s_, _rc_) in zip(('hertz', 'physics'), _x29))
                if _got != _x29 or not _same or not _sem:
                    _bad29b[_v29] = (_got, _same, _sem)
            except Exception as e:                                        # noqa: BLE001
                _bad29b[_v29] = f'{type(e).__name__}: {str(e)[:120]}'
        chk(f'㉙b ★ 상태별 = tau_flux 정의 그대로 (두 모드 · 실 생산자 레코드 · 정지 계약을 통과한 폴더 모양 넷) — OK · MODEL_BELOW_CONTINUUM_BOUND '
            f'(값 유지 + 표지 · tau2 < 1) · BAND_FALLBACK 띠 L1 · L2 (빈칸 · 사유 없음 — L1 · L2 를 거부하지 않는다) · 셀 = tau_flux 직렬화 (옛 판과 같다 · '
            f'비관통 NOT_PERCOLATING 은 ㉙a · ㉙k) {_bad29b or ""}',
            not _e29 and not _bad29b and len(_EXP29) == 4)

        #  ★ 10-05 RGLR3-02 (Codex 4차 재검증 §3 · 최소 해제 "기술적 입력 결함을 NOT_COMPUTED 로 내보내는 것 ↔ done 배치의 같은 세대 검증 통과를
        #    구별") — 기술적 결손 (모든 사본이 서로 맞아도) 인 폴더는 그 배치의 망 정지 계약이 done 을 줄 수 없다 (③ · ⑤ · ⑦ · ⑧).  배치가 done ·
        #    partial 로 적은 케이스의 폴더가 그 모양이면 배치 뒤 폴더가 바뀐 것이다 → 거부 (τ P4).  옛 판은 NOT_COMPUTED + 사유로 싣고 출처 부록에
        #    다른 행과 같은 모양으로 적었다 (검증한 것처럼).
        def _ldv29(sub, **kw):
            lw_, res_, _ = _sc29(sub, **kw)
            return _ld29(res_, lw_)
        for _v29, _rs29 in (('NC_PERC', 'percolation_disagree'), ('NC_INVALID', 'invalid_input'), ('NC_MISSING', 'missing_input'),
                            ('NC_TEMP', 'temperature_mismatch'), ('NC_SOLVER', 'solver_guard')):
            _neg7(f'㉙b2 ★ done 배치 행인데 폴더가 기술적 결손 ({_v29} — tau_flux 라면 NOT_COMPUTED {_rs29}) — 인계 때 망 정지 계약 재검사가 거부 '
                  '(NOT_COMPUTED 를 "같은 세대 검증 통과" 로 싣지 않는다)',
                  lambda _v=_v29: _ldv29(f'b2_{_v}', q1=_v), 'τ P4 — 망 정지 계약 재검사')

        _neg7('㉙c1 ★ τ 묶음은 contact 배치에 실을 수 없다 (단계 역량 — WA_STAGE_GROUPS)',
              lambda: _bh29(_bat29('c1a', {}, stop='contact'), None), "stop_after='contact'")
        _neg7('㉙c2 ★ τ 묶음은 coverage 배치에 실을 수 없다 (단계 역량)',
              lambda: _bh29(_bat29('c1b', {}, stop='coverage'), None), "stop_after='coverage'")
        _neg7('㉙c3 ★ 전체 실행 배치 (stop_after 없음 — 케이스 기록에 network_run_id 가 없다) 에 τ 를 실으면 거부',
              lambda: _bh29(dict(_lw29, stop_after=None), _tv29), 'τ 정지점')
        _neg7('㉙c4 ★ 로더 — network 정지 배치가 아니면 케이스 폴더를 읽지 않는다 (contact 배치)',
              lambda: _ld29(_res29, _bat29('c1d', {}, stop='contact')), 'τ 정지점')

        def _c2a():
            lw_b = _bat29('c2a', {}, st={'q2': 'failed'})                      # 같은 폴더 · 같은 run id · q2 만 failed 인 다른 배치
            return _bh29(lw_b, _tv29)
        _neg7('㉙c5 ★ 케이스 집합 불일치 — τ 원천에 배치가 done · partial 로 적지 않은 케이스 (q2 failed) 가 있으면 거부', _c2a, 'τ 케이스')
        _neg7('㉙c6 ★ 케이스 집합 불일치 — 배치 done 케이스 (q1) 의 τ 기록이 τ 원천에 없으면 거부',
              lambda: _bh29(_lw29, dict(_tv29, cases={k_: v_ for k_, v_ in _tv29['cases'].items() if k_ != 'q1'})), 'τ 케이스')

        def _c3(kind):
            def fn():
                lw_, res_, _ = _sc29(f'c3_{kind}')
                if kind == 'rerun':                                            # 배치 뒤 같은 케이스를 다시 돌렸다 (새 세대 — 도장 · 입력 모두 새 것)
                    _case29(res_, 'q1', 'OK', 'RUN-q1-new')
                elif kind == 'prov':                                           # 도장 파일만 다른 실행의 것
                    _PS29.stamp_network_provenance(str(res_ / 'q1'), 'RUN-other', _PS29.read_network_provenance(str(res_ / 'q1'))['input_digests'])
                elif kind == 'failed':                                         # 도장이 실패 세대
                    _PS29.stamp_network_provenance(str(res_ / 'q1'), 'RUN-q1', _PS29.read_network_provenance(str(res_ / 'q1'))['input_digests'],
                                                   solver_status='failed')
                elif kind == 'digest':                                         # 도장 뒤 입력 파일이 바뀌었다
                    with (res_ / 'q1' / 'atoms.csv').open('a', encoding='utf-8') as fh:
                        fh.write('2,1,0.0,0.0,1.0,1.0\n')
                elif kind == 'ledger':                                         # 폴더 full_metrics 장부 ≠ 배치 metrics_flat (같은 도장)
                    p_ = res_ / 'q1' / 'full_metrics.json'
                    fm_ = json.loads(p_.read_text(encoding='utf-8'))
                    fm_['thickness_mass_conserving_um'] *= 1.01
                    p_.write_text(json.dumps(fm_), encoding='utf-8')
                elif kind == 'dual':                                           # dual 만 바뀌었다 (full_metrics 투영과 다르다)
                    p_ = res_ / 'q1' / 'network_conductivity_dual.json'
                    du_ = json.loads(p_.read_text(encoding='utf-8'))
                    du_['hertzian']['sigma_full'] *= 2
                    p_.write_text(json.dumps(du_), encoding='utf-8')
                elif kind == 'norid':
                    lw_ = _bat29('c3_norid/batch2', {q_: json.loads((res_ / q_ / 'full_metrics.json').read_text(encoding='utf-8'))
                                                     for q_ in ('q1', 'q2')}, rid={'q1': None})
                return _ld29(res_, lw_)
            return fn
        _neg7('㉙c7 ★ 낡은 세대 — 폴더 도장 (full_metrics · provenance) 이 배치 기록의 network_run_id 와 다르면 거부 (재실행된 폴더)', _c3('rerun'), 'τ P1')
        _neg7('㉙c8 ★ 낡은 세대 — network_provenance.json 의 run id ≠ full_metrics 도장이면 거부', _c3('prov'), 'τ P1')
        _neg7('㉙c9 ★ 도장이 실패 세대 (solver_status failed) 면 거부', _c3('failed'), 'τ P1')
        _neg7('㉙c10 ★ 입력 digest — 도장의 atoms.csv digest ≠ 지금 파일이면 거부 (망이 지금 입력에서 나오지 않았다)', _c3('digest'), 'τ P2')
        _neg7('㉙c11 ★ 같은 세대 — 폴더 full_metrics 장부 (L_mc) ≠ 배치 metrics_flat 이면 거부 (τ 와 다른 열이 다른 세대)', _c3('ledger'), 'τ P3')
        _neg7('㉙c12 ★ 같은 세대 — dual σ_ratio ≠ full_metrics 투영 (sigma_full) 이면 거부 (dual 이 도장 세대가 아니다)', _c3('dual'), 'τ P3')
        _neg7('㉙c13 ★ 배치 기록에 network_run_id 가 없으면 거부 (출처를 대조할 수 없다)', _c3('norid'), 'τ P1')
        _neg7('㉙c14 ★ 표 만들 때 — τ 기록의 run id ≠ 배치 기록이면 거부 (다른 배치로 읽은 τ 원천)',
              lambda: _bh29(_lw29, dict(_tv29, cases=dict(_tv29['cases'], q1=dict(_tv29['cases']['q1'], network_run_id='RUN-x')))), 'τ P1')

        def _c4(kind):
            def fn():
                if kind == 'nofolder':
                    lw_, res_, _ = _sc29('c4_nofolder', q2=None)              # q2 는 배치 done 인데 폴더가 없다
                    lw_ = _bat29('c4_nofolder/batch2', {'q1': json.loads((res_ / 'q1' / 'full_metrics.json').read_text(encoding='utf-8'))})
                else:
                    lw_, res_, _ = _sc29('c4_nodual')
                    (res_ / 'q1' / 'network_conductivity_dual.json').unlink()
                return _ld29(res_, lw_)
            return fn
        _neg7('㉙c15 ★ τ 기록 없음 — 배치 done 케이스 (q2) 의 폴더가 없으면 거부 (조용히 빈칸으로 두지 않는다)', _c4('nofolder'), 'τ P0')
        _neg7('㉙c16 ★ τ 기록 없음 — dual 파일이 없으면 거부', _c4('nodual'), 'τ P0')
        #  ㉙k — 배치 전부가 비관통이면 생산자가 σ 키를 안 써서 metrics_flat 에 sigma_full 열 자체가 없다 (row_for 는 있는 키만 편다 · 머리 = 행 키의
        #   합집합).  열 없음 = 빈칸 (None) 으로 읽어야 한다 — 옛 판은 "열 없음" 을 거부해 정상 배치를 막았다 (실 생산자 폴더 대조에서 찾음).
        #   ★ 10-05 RGLR3-02 — 두 케이스 모두 정상 비관통 (NPERC — 정지 계약을 통과한 폴더 모양).  옛 판의 q1 = NC_PERC (솔버 비관통 ↔ calc_percolation
        #   37 % · tau_flux 라면 NOT_COMPUTED) 는 그 배치의 정지 계약이 done 을 줄 수 없는 폴더라 이제 τ P4 가 거부한다 (㉙b2) — 이 시험의 뜻 (σ 열 없음) 은 같다.
        try:
            _lwk, _rsk, _fmk = _sc29('k', q1='NPERC', q2='NPERC')
            _tvk = _ld29(_rsk, _lwk)
            _ek = '' if 'sigma_full' not in next(iter(_lwk['rows'].values())) else 'metrics_flat 에 sigma_full 열이 있다 (픽스처가 조건을 못 세웠다)'
        except Exception as e:                                            # noqa: BLE001
            _tvk, _ek = {}, f'{type(e).__name__}: {e}'
        chk('㉙k ★ 전부 비관통인 배치 (metrics_flat 에 sigma_full · sigma_full_physics 열 없음 = 생산자가 None 키를 안 씀) — 열 없음을 빈칸으로 읽고 '
            '받는다 (폴더 full_metrics 에도 키가 없다 · 거짓 거부 없음)' + (f' — {_ek}' if _ek else ''),
            not _ek and sorted((_tvk.get('cases') or {})) == ['q1', 'q2'] and not any('sigma_full' in f_ for f_ in _fmk.values()))
        _neg7('㉙c17 ★ τ 원천을 줬는데 묶음에 tau 가 없으면 거부 (조용히 버리지 않는다)', lambda: _bh29(_lw29, _tv29, groups=_G567), 'τ 묶음')
        _neg7('㉙c18 ★ 묶음에 tau 가 있는데 τ 원천 (--tau-results) 이 없으면 거부', lambda: _bh29(_lw29, None), 'τ 묶음')

        def _c5(kind):
            """★ 10-05 RGLR3-02 (Codex 4차 재검증 §3 · probes/new_probes.py) — 정상 폴더 (정지 계약을 통과한 모양) 에서 **한 사본만** 바꾼다.
            입력 · 도장 · run id · 배치 status.json · metrics_flat 은 그대로.  옛 로더 (P0–P3) 는 dual 의 σ_ratio · 상태 두 키만 full_metrics 와 맞대어
            dual 의 띠 규칙 · σ₀ 와 다른 사본 (모드 파일 · legacy · full_metrics 투영의 σ₀) 을 보지 않았다 → 받았다."""
            def fn():
                lw_, res_, _ = _sc29(f'c5_{kind}')
                d_ = res_ / 'q1'

                def _ed(name, f_):
                    p_ = d_ / name
                    x_ = json.loads(p_.read_text(encoding='utf-8'))
                    f_(x_)
                    p_.write_text(json.dumps(x_), encoding='utf-8')

                def _s0(x_):                                                   # Codex 반례 ② — σ₀ ×2 · σ_dim 을 같은 σ_ratio 에서 6 자리로 다시 (레코드 자체는 항등식 성립)
                    for m_ in ('hertzian', 'physics'):
                        x_[m_]['sigma_grain_S_cm'] *= 2
                        x_[m_]['sigma_full_mScm'] = round(1000 * x_[m_]['sigma_grain_S_cm'] * x_[m_]['sigma_full'], 6)
                if kind == 'dual_band':                                            # Codex 반례 ① — dual 두 모드 띠 규칙 L0 → L1 (옛: BAND_FALLBACK 로 수용)
                    _ed('network_conductivity_dual.json', lambda x_: [x_[m_].update(boundary_rule='L1') for m_ in ('hertzian', 'physics')])
                elif kind == 'dual_sigma0':                                        # Codex 반례 ② (옛: OK · σ₀ 6.0 mS/cm 로 수용)
                    _ed('network_conductivity_dual.json', _s0)
                elif kind == 'mode_file':                                          # 모드 파일 (physics) 만 — 띠 규칙 L1
                    _ed('network_conductivity_physics.json', lambda x_: x_.update(boundary_rule='L1'))
                elif kind == 'legacy':                                             # legacy (Hertz 사본 · full_metrics 투영 원천) 만 — σ₀ ×2
                    _ed('network_conductivity.json', lambda x_: x_.update(sigma_grain_S_cm=x_['sigma_grain_S_cm'] * 2))
                elif kind == 'fm_sigma0':                                          # full_metrics 투영의 σ₀ 만 ×2 (P3 대조 키 밖 · 배치 metrics_flat 은 옛 값)
                    _ed('full_metrics.json', lambda x_: x_.update(sigma_grain_S_cm=x_['sigma_grain_S_cm'] * 2))
                elif kind == 'generation':                                         # 배치 뒤 재계산의 되돌림 실패 기록 (활성 무효 · 파일의 run id 는 그대로)
                    _PS29.record_network_attempt(str(d_), 'RUN-q1-retry', 'failed', failure_kind='rollback_failed',
                                                 active_problem='주입: 되돌림 실패 (selftest ㉙c24)')
                return _ld29(res_, lw_)
            return fn
        _neg7('㉙c19 ★ RGLR3-02 Codex 반례 ① — dual 만 두 모드 띠 규칙 L0 → L1 (다른 사본 · 투영 · 입력 · 도장 그대로) 이면 거부 (BAND_FALLBACK 로 싣지 않는다)',
              _c5('dual_band'), 'τ P4 — 망 정지 계약 재검사')
        #  ★ 10-07 G2RR2-04 — 이 반례는 같은 τ P4 의 앞 관문 (세대 계약의 σ₀ 결합 — 증서 σ₀ ≠ 부모 σ₀ · CF 차원값 부모 σ₀ 재구성) 에서 먼저 걸린다 (정지 계약
        #    재검사 ⑧ 도 같은 함수로 거부) — 거부 지점은 그대로 τ P4
        _neg7('㉙c20 ★ RGLR3-02 Codex 반례 ② — dual 만 두 모드 σ₀ ×2 (σ_dim 을 같은 σ_ratio 에서 6 자리로 다시 — 레코드는 자기 항등식 성립) 이면 거부 '
              '(σ₀ 6.0 mS/cm 로 싣지 않는다)', _c5('dual_sigma0'), 'τ P4')
        _neg7('㉙c21 ★ 모드 파일 (network_conductivity_physics.json) 만 띠 규칙이 바뀌었으면 거부 (모드 파일 = dual 의 사본)', _c5('mode_file'), 'τ P4 — 망 정지 계약 재검사')
        _neg7('㉙c22 ★ legacy (network_conductivity.json — Hertz 사본 · full_metrics 투영 원천) 만 σ₀ 가 바뀌었으면 거부', _c5('legacy'), 'τ P4 — 망 정지 계약 재검사')
        _neg7('㉙c23 ★ full_metrics 투영의 σ₀ 만 바뀌었으면 거부 (P3 대조 키 밖 · 등급 · 웹앱 τ 가 쓰는 짝 σ₀ — 정지 계약 ⑥b · ⑧)', _c5('fm_sigma0'), 'τ P4 — 망 정지 계약 재검사')
        _neg7('㉙c24 ★ 배치 뒤 재계산이 되돌림 실패 기록을 남긴 폴더 (활성 세대 무효 · run id 는 그대로) — 세대 무효로 거부 (옛 판: "읽는 사이 바뀌었다" 로 오분류)',
              _c5('generation'), 'τ P4 — 활성 세대 무효')
        _neg7('㉙c25 ★ 표 만들 때 — τ 기록에 같은 세대 검사 (P0–P4) 표지가 다 없으면 거부 (검사를 다 통과한 원천만 "검증됨" 으로 싣는다)',
              lambda: _bh29(_lw29, dict(_tv29, cases=dict(_tv29['cases'], q1={k_: v_ for k_, v_ in _tv29['cases']['q1'].items()
                                                                               if k_ != 'same_generation_checks'}))), 'τ P4 — τ 기록의 같은 세대 검사')
        chk('㉙d ★ 단계 역량 — tau 는 network 에만 (contact · coverage 배치는 τ 묶음을 실을 수 없다) · 다섯 census 묶음은 세 단계 모두',
            'tau' in WA_STAGE_GROUPS.get('network', ()) and 'tau' not in WA_STAGE_GROUPS.get('contact', ())
            and 'tau' not in WA_STAGE_GROUPS.get('coverage', ()) and all(g_ in WA_STAGE_GROUPS[s_] for g_ in WA_GROUPS for s_ in WA_STAGE_GROUPS))

        #  (e) LW — τ 를 실어도 LW 열은 명시 제외 (최악: census ✅ · 값 있음 · 검토 목록 밖 경로)
        _w29e = _wa11()
        for _c in _LW28:
            _w29e['verdict'][_c] = '✅ 쓴다'
            _w29e['why'][_c] = f'why:{_c}'
            for _q in ('q1', 'q2'):
                _w29e['rows'][_q][_c] = '1.5'
        try:
            _fe29 = {q_: json.loads((_res29 / q_ / 'full_metrics.json').read_text(encoding='utf-8')) for q_ in ('q1', 'q2')}
            _lwe = _bat29('e/batch', _fe29, w=_w29e)
            _ce, _ree = [], []
            for _wr in (True, False):
                _x = _bh29(_lwe, _ld29(_res29, _lwe), w_rev=_wr)
                _ce.append(_x[1])
                _ree.append(_x[2])
            _xb = _bh29(_lw29, _ld29(_res29, _lw29), w_rev=False)
            _ee = ''
        except Exception as e:                                            # noqa: BLE001
            _ce, _ree, _xb, _ee = [[]], [{}], ([], [], {}), f'{type(e).__name__}: {e}'
        chk('㉙e ★ LW — τ 묶음을 실어도 LW 열은 안 실린다 (검토 경로 · 검토 목록 밖 경로 둘 다) · 제외 수에 센다 · τ 열은 어느 제외 패턴에도 안 걸린다'
            + (f' — {_ee}' if _ee else ''),
            not _ee and all(not any(c_ in cc_ for c_ in _LW28) and all(t_ in cc_ for t_ in _tc29) for cc_ in _ce)
            and _ree[-1].get('wa_excluded_dropped', 0) - _xb[2].get('wa_excluded_dropped', 0) == len(_LW28)
            and bool(_tc29) and not any(wa_excluded(t_) for t_ in _tc29))

        #  (f) 묶음을 안 부르면 옛 표 그대로 — 같은 배치에서 τ 판 = 옛 판 + 끝 28 열 · 열 사전의 공통 열 같다 · 커밋된 10-01 표 바이트 재현
        try:
            _o29n, _c29n, _ = _bh29(_lw29, None, groups=_G567)
            _d29n = {d_['column']: d_ for d_ in column_dictionary(_c29n, webapp=_lw29)}
            _d29t = {d_['column']: d_ for d_ in column_dictionary(_c29, webapp=_lw29)}
            _ef = ''
        except Exception as e:                                            # noqa: BLE001
            _o29n, _c29n, _d29n, _d29t, _ef = [], [], {}, {}, f'{type(e).__name__}: {e}'
        chk('㉙f1 ★ 묶음 tau 를 안 부르면 표 · 열 사전이 옛 그대로 — τ 판 열 = 옛 판 열 + 끝 τ 열 (tau_flux 순서) · 행 값 (τ 칸 밖) 같다 · 공통 열의 열 사전 항목 같다'
            + (f' — {_ef}' if _ef else ''),
            not _ef and not _e29a and bool(_c29n) and _c29 == _c29n + _tc29
            and [{k_: r_.get(k_) for k_ in _c29n} for r_ in _o29] == [{k_: r_.get(k_) for k_ in _c29n} for r_ in _o29n]
            and all(_d29t[c_] == _d29n[c_] for c_ in _c29n if c_ != 'tortuosity_SE_wall')
            #  ★ 10-06 — 벽 τ 뜻의 끝 (수송 tortuosity 가 어디 있나) 만 표의 열에 따라 다르다 (τ 판 = 이 표의 tau2_ion_hertz · 옛 판 = 이 표에는 없다)
            and ('tortuosity_SE_wall' not in _c29n
                 or _d29t['tortuosity_SE_wall']['meaning'].replace(TAU_WALL_TRANSPORT_IN, '')
                 == _d29n['tortuosity_SE_wall']['meaning'].replace(TAU_WALL_TRANSPORT_OUT, ''))
            and not any(t_ in _d29n for t_ in _tc29))
        for _lab29, _dsg, _hdir, _uni, _wdir, _gold in (
                ('130', DESCRIPTOR_FILL_EXPECTED['path'], 'docs/data/lhs_descriptors_cov_1e09f661d', DEFAULT_UNION_TSV,
                 'docs/data/lhs_webapp_contact_d1ec42fba', 'docs/data/lhs_handover_20261001.csv'),
                ('64', 'docs/data/lhsx_design_adapted_20260929.csv', 'docs/data/lhsx_descriptors_cov_1e09f661d',
                 'docs/data/lhs_union_20260927/lhsx64_union.tsv', 'docs/data/lhsx_webapp_contact_d1ec42fba', 'docs/data/lhsx_handover_20261001.csv')):
            try:
                with (_rt29 / _dsg).open(encoding='utf-8-sig') as _fh:
                    _rw29 = list(csv.DictReader(_fh))
                _og, _cg, _ = build_handover(_rw29, load_harvest(_rt29 / _hdir), union=load_union(_rt29 / _uni),
                                             webapp=load_webapp(_rt29 / _wdir), webapp_groups='contact,percolation')
                _sio = _io29.StringIO()
                _dw = csv.DictWriter(_sio, _cg, lineterminator='\n')
                _dw.writeheader()
                for _r in _og:
                    _dw.writerow(_r)
                _same29 = _sio.getvalue() == (_rt29 / _gold).read_text(encoding='utf-8')
                chk(f'㉙f2 ★ 실데이터 {_lab29} — 묶음 tau 없이 커밋된 10-01 인계표 ({_gold.split("/")[-1]}) 를 바이트 그대로 다시 만든다 (옛 표 불변)', _same29)
            except Exception as e:                                        # noqa: BLE001
                chk(f'㉙f2 실데이터 {_lab29} ({type(e).__name__}: {e})', False)
        try:
            _lwf, _rsf, _ = _sc29('f3', q2=None)
            _lwf = _bat29('f3/batch2', {'q1': json.loads((_rsf / 'q1' / 'full_metrics.json').read_text(encoding='utf-8'))}, st={'q2': 'failed'})
            _of, _cf, _rf = _bh29(_lwf, _ld29(_rsf, _lwf))
            _pf = next(r_ for r_ in _of if r_['case_id'] == 'q2')
            _ef3 = ''
        except Exception as e:                                            # noqa: BLE001
            _pf, _rf, _ef3 = {}, {}, f'{type(e).__name__}: {e}'
        chk('㉙f3 ★ 배치가 실패한 행 (q2 failed — 폴더 없음) 은 τ 칸 전부 빈칸 (값 · 상태 · 메타 — tau_flux 를 부르지 않았다 · wa_status 가 사유) · '
            'τ 기록을 요구하지 않는다' + (f' — {_ef3}' if _ef3 else ''),
            not _ef3 and _pf.get('wa_status') == 'failed' and all(_pf.get(c_) == '' for c_ in _tc29) and bool(_tc29)
            and _rf.get('tau_checked') == 1 and _rf.get('tau_blank_rows') == 1)

        #  (g) 열 사전 — τ 명명 규약 (CLAUDE.md τ 블록 · v2 §5-1 · §5-3) 의 한정어
        _g29 = lambda c, k: (_d29t.get(c) or {}).get(k, '')               # noqa: E731
        _gm = all(
            _g29(f'tau2_ion_{m_}', 'source') == 'tau_flux' and 'tortuosity factor' in _g29(f'tau2_ion_{m_}', 'meaning')
            and 'tortuosity factor' not in _g29(f'tau_ion_{m_}', 'meaning') and 'COMSOL 입력 아님' in _g29(f'tau_ion_{m_}', 'meaning')
            and 'φ_mc 와 짝짓지 말 것' in _g29(f'f_ion_{m_}_gap', 'meaning') and 'User defined' in _g29(f'f_ion_{m_}', 'meaning')
            and '재척도 (해 아님)' in _g29(f'f_ion_{m_}', 'meaning') and '무차원' in _g29(f'f_ion_{m_}', 'meaning')
            and all(s_ in _g29(f'ion_net_status_{m_}', 'meaning') for s_ in
                    ('OK', 'MODEL_BELOW_CONTINUUM_BOUND', 'NOT_PERCOLATING', 'BAND_FALLBACK', 'NOT_COMPUTED', '기술적 실패', '과학적 HOLD', '값 유지', '= ∞'))
            and all(r_ in _g29(f'ion_net_status_reason_{m_}', 'meaning') for r_ in _TF29.REASONS)
            and 'G6' in _g29(f'tau2_ion_{m_}', 'verdict') and 'HOLD' in _g29(f'tau2_ion_{m_}', 'verdict')
            and '실험 절대 대조 금지' in _g29(f'tau2_ion_{m_}', 'caveat') and 'τ_e' in _g29(f'tau2_ion_{m_}', 'caveat')
            for m_ in ('hertz', 'physics')) if (_d29t and _TF29 is not None) else False
        chk('㉙g ★ 열 사전 (τ 명명 규약) — tortuosity factor = tau2 에만 · tau = √tau2 COMSOL 입력 아님 · f_gap φ_mc 와 짝짓지 말 것 · f = 재척도 (해 아님) · '
            'User defined (fl) · 상태 다섯 + 두 부류 · MBCB 값 유지 · 비관통 = ∞ · 사유 = tau_flux.REASONS 전부 (여섯) · G6 물리 타깃 HOLD · 1세대 · τ_e 아님', _gm)
        #  ★ 10-05 RGLR3-02 (Codex 4차 재검증 §3 · §8-2) — 열 사전이 ① 인계표의 NOT_COMPUTED 와 "같은 세대 검증 통과" 를 가르고 (done 배치 행의 기술적 결손 =
        #    생성기 거부 τ P4) ② 남는 한계 (지금 파일끼리 대조 — 게시 시점 해시가 없어 모든 사본을 함께 일관되게 바꾼 편집은 못 잡는다) 를 적는가.
        _gs29 = all(
            all(k_ in _g29(f'ion_net_status_{m_}', 'meaning') for k_ in ('τ P4', '인계표에는 NOT_COMPUTED 가 실리지 않는다'))
            and all(k_ in _g29(c_, 'caveat') for c_ in (f'tau2_ion_{m_}', f'f_ion_{m_}', f'ion_net_status_{m_}')
                    for k_ in ('same_generation_checks', '게시 시점 해시', '모든 사본을 함께 일관되게 바꾼 편집은 못 잡는다'))
            for m_ in ('hertz', 'physics')) if _d29t else False
        chk('㉙g2 ★ RGLR3-02 열 사전 — 인계표 τ 상태: done 배치 행의 기술적 결손 (NOT_COMPUTED) 은 싣지 않고 생성기가 거부 (τ P4) · 한정어: 출처 관문 = 지금 파일끼리 '
            '(same_generation_checks) · 게시 시점 해시 없음 → 모든 사본을 함께 일관되게 바꾼 편집은 못 잡는다', _gs29)
        _cov29 = sorted(c_ for c_ in _tc29 if not (callable(_TD29) and _TD29(c_)))
        chk('㉙h ★ 열 사전 덮개 — tau_flux.column_names() 의 열마다 정의가 있다 (tau_flux 가 열을 늘리면 여기서 걸린다) · 빈 뜻 없음'
            + (f' — 정의 없는 열 {_cov29}' if _cov29 else ''),
            callable(_TD29) and bool(_tc29) and not _cov29 and all(_g29(c_, 'meaning') for c_ in _tc29))

        #  (i) CLI — --tau-results 가 실제로 배선됐는가 (인자 파서 → 로더 → 표 · 열 사전 · 출처 부록).  규율 ⑤ — 배선 자리가 사각지대다.
        try:
            _cd = _td29 / 'cli'
            (_cd / 'harvest').mkdir(parents=True)
            for _q, _hj in _hq10().items():
                (_cd / 'harvest' / f'{_q}.json').write_text(json.dumps(_hj), encoding='utf-8')
            with (_cd / 'design.csv').open('w', encoding='utf-8', newline='') as _fh:
                _dw = csv.DictWriter(_fh, list(_dq11[0]), lineterminator='\n')
                _dw.writeheader()
                for _r in _dq11:
                    _dw.writerow(_r)
            _bdir = _td29 / 'a' / 'batch'
            _cmd = [sys.executable, str(pathlib.Path(__file__).resolve()), '--export-handover', str(_cd / 'h.csv'), '--design', str(_cd / 'design.csv'),
                    '--harvest', str(_cd / 'harvest'), '--union', '', '--webapp', str(_bdir), '--census', str(_bdir / 'census.tsv'),
                    '--webapp-groups', _G29, '--tau-results', str(_res29), '--pressure-unverified']
            _pr = _sp29.run(_cmd, capture_output=True, text=True, timeout=300)
            with (_cd / 'h.csv').open(encoding='utf-8') as _fh:
                _hcli = list(csv.DictReader(_fh))
            with (_cd / 'h_columns.tsv').open(encoding='utf-8') as _fh:
                _dcli = {r_['column']: r_ for r_ in csv.DictReader(_fh, delimiter='\t')}
            with (_cd / 'h_tau_provenance.tsv').open(encoding='utf-8') as _fh:
                _pcli = list(csv.DictReader(_fh, delimiter='\t'))
            _ei = '' if _pr.returncode == 0 else f'rc {_pr.returncode}: {_pr.stderr[-300:]}'
        except Exception as e:                                            # noqa: BLE001
            _hcli, _dcli, _pcli, _ei = [], {}, [], f'{type(e).__name__}: {e}'
        chk('㉙i ★ CLI --tau-results — 표에 τ 열 (값 = 함수 경로와 같다) · 열 사전에 τ 항목 (출처 tau_flux) · 출처 부록 <표>_tau_provenance.tsv '
            '(케이스마다 network_run_id · 입력 digest · dual · full_metrics sha256)' + (f' — {_ei}' if _ei else ''),
            not _ei and [{k_: r_.get(k_) for k_ in _tc29} for r_ in _hcli] == [{k_: r_.get(k_) for k_ in _tc29} for r_ in _o29] and bool(_hcli)
            and all(_dcli.get(c_, {}).get('source') == 'tau_flux' for c_ in _tc29)
            and sorted((r_.get('case'), r_.get('network_run_id')) for r_ in _pcli) == [('q1', 'RUN-q1'), ('q2', 'RUN-q2')]
            and all(len(r_.get('dual_sha256', '')) == 64 and len(r_.get('full_metrics_sha256', '')) == 64 and r_.get('atoms_csv_digest')
                    for r_ in _pcli))
        #  ★ 10-05 RGLR3-02 — 출처 부록이 케이스마다 **어느 검사가 돌았고 통과했나** (same_generation_checks — P4 망 정지 계약 재검사 · 활성 세대 · 읽기 안정
        #    포함) 와 그 대조의 기준 (same_generation_basis — 지금 파일끼리 · 게시 시점 해시 없음) 을 적는가.  함수 경로의 τ 기록과 같은 목록.
        _SG29 = globals().get('TAU_SAME_GEN_CHECKS')
        chk('㉙i2 ★ RGLR3-02 출처 부록 — 케이스마다 same_generation_checks (P0 기록 · P1 run id · P2 입력 digest · P3 배치 대조 · P4 망 정지 계약 재검사 · '
            'P4 활성 세대 · P4 읽기 안정 — 다 통과한 케이스만 행이 있다) · same_generation_basis = 지금 파일끼리 (게시 시점 해시 없음) · 함수 경로 τ 기록과 같다',
            not _ei and bool(_pcli) and bool(_SG29)
            and all(r_.get('same_generation_checks') == ';'.join(_SG29) for r_ in _pcli)
            and all(k_ in ';'.join(_SG29) for k_ in ('P0_', 'P1_', 'P2_', 'P3_', 'P4_stop_contract', 'P4_generation', 'P4_read_stable'))
            and all(r_.get('same_generation_basis') == 'current_files_no_publish_hash' for r_ in _pcli)
            and all(list((_tv29 or {}).get('cases', {}).get(q_, {}).get('same_generation_checks') or []) == list(_SG29) for q_ in ('q1', 'q2')))
        #  ★ 10-06 밤 (G2RR-01) — CLI --tau-batch-manifest 가 배선됐는가 (manifest 의 기대 세대 → load_tau_results 교차 대조).  같은 픽스처 (q1 · q2 = 세대 2):
        #   g2 선언 = ㉙i 와 같은 표 · inferred_legacy 선언 = 거부 (τ P4 배치 기대 세대) · 선언 없는 manifest = 거부 (τ 기대 세대) · --tau-results 없이 = rc 2.
        try:
            _mf29 = {}
            for _lab, _decl in (('g2', {'expected_network_generation': 'g2'}), ('leg', {'expected_network_generation': 'inferred_legacy'}),
                                ('none', {'schema': 'network_parallel_launcher/v1'})):
                _mpth = _cd / f'manifest_{_lab}.json'
                _mpth.write_text(json.dumps(_decl), encoding='utf-8')
                _outm = _cd / f'hm_{_lab}.csv'
                _cmdm = list(_cmd)
                _cmdm[_cmdm.index('--export-handover') + 1] = str(_outm)
                _pm = _sp29.run(_cmdm + ['--tau-batch-manifest', str(_mpth)], capture_output=True, text=True, timeout=300)
                _mf29[_lab] = (_pm.returncode, _pm.stderr[-600:], _outm.read_text(encoding='utf-8') if _outm.exists() else None)
            _cmdn = list(_cmd)
            _ix = _cmdn.index('--tau-results')
            del _cmdn[_ix:_ix + 2]
            _cmdn[_cmdn.index('--export-handover') + 1] = str(_cd / 'hm_notau.csv')
            _pn29 = _sp29.run(_cmdn + ['--tau-batch-manifest', str(_cd / 'manifest_g2.json')], capture_output=True, text=True, timeout=300)
            _eim = ''
        except Exception as e:                                            # noqa: BLE001
            _mf29, _pn29, _eim = {}, None, f'{type(e).__name__}: {e}'
        _okm29 = (not _eim and _mf29['g2'][0] == 0 and _mf29['g2'][2] == (_cd / 'h.csv').read_text(encoding='utf-8')
                  and _mf29['leg'][0] != 0 and 'τ P4 — 배치 기대 세대' in _mf29['leg'][1] and _mf29['leg'][2] is None
                  and _mf29['none'][0] != 0 and 'τ 기대 세대' in _mf29['none'][1] and _mf29['none'][2] is None and _pn29.returncode == 2)
        chk('㉙i3 ★ G2RR-01 CLI --tau-batch-manifest — 기대 세대 g2 선언 = ㉙i 와 같은 표 (rc 0) · inferred_legacy 선언 = 거부 (τ P4 배치 기대 세대 · 표 안 씀) · '
            '선언 없는 manifest = 거부 (τ 기대 세대) · --tau-results 없이 = rc 2'
            + ('' if _okm29 else f' — {_eim or {k_: (v_[0], v_[1][-160:]) for k_, v_ in _mf29.items()}} · rc(무 원천) {getattr(_pn29, "returncode", None)}'),
            _okm29)
        #  (j) J20-l 웹앱 짝 — 케이스 페이지 τ 인계 상태 툴팁 (같은 tau_flux 상태를 보여 준다) 의 값 규칙이 인계표와 같은가.  옛 문구는 "OK · MBCB 일 때만
        #   값" 이라 NOT_PERCOLATING 의 f_ion 0 (물리적 0 — 인계표에는 0.0 이 실린다) 과 어긋났다.
        try:
            _sh29 = (_rt29 / 'webapp' / 'templates' / 'single.html').read_text(encoding='utf-8')
            _i29 = _sh29.find("'tau2 인계 상태 (게이트 G1–G6 · v2 §5-2)': {")
            _mt29 = re.search(r"meaning: '([^']*)'", _sh29[_i29:_sh29.find('},', _i29)]) if _i29 >= 0 else None
            _mt29 = _mt29.group(1) if _mt29 else ''
        except OSError as e:
            _mt29 = f'ERR {e}'
        chk('㉙j ★ J20-l 웹앱 짝 — 케이스 페이지 τ 인계 상태 툴팁의 값 규칙 = 인계표 (tau_flux): OK · MODEL_BELOW_CONTINUUM_BOUND 값 (T < 1 이어도 유지) · '
            'NOT_PERCOLATING f_ion 0 · tau2 · tau 빈칸 (= ∞) · 그 밖 빈칸 (0 아님) · LHS 인계표 v1.2 망 τ 묶음에 같은 열 · 같은 규칙 · '
            '★ RGLR3-02 — 인계표 행은 인계 때 같은 세대 검사 (τ P4 · 망 정지 계약 재검사) 를 통과한 케이스뿐 · NOT_COMPUTED 는 인계표에 안 실린다',
            all(k_ in _mt29 for k_ in ('MODEL_BELOW_CONTINUUM_BOUND', 'NOT_PERCOLATING', 'f_ion 0', '= ∞', '0 아님', '인계표 v1.2', 'f_ion_gap',
                                        'τ P4', '인계표에는 NOT_COMPUTED 가 실리지 않는다'))
            and '일 때만 값을 싣는다' not in _mt29)

        #  ㉙m — ★ 10-06 저녁 세대 2 (1저자 비준) — ① 모드 목록 = tau_flux.MODES (사본이 어긋나면 열 사전 · 인계표가 H12 를 빠뜨린다)
        #    ② H12 열 = 같은 행에 실리되 열 사전 판정 '부록 전용' (기본 학습 열 아님) · 세대 표기 (q1 = 세대 2) · q1 관통 OK · q2 비관통 NOT_PERCOLATING
        #    ③ 세대 섞임 — 세대 2 폴더 (q1) + 표기 없는 옛 폴더 (q2 · 10-06 저녁 전 생산자 레코드 모양) 를 한 배치로 읽으면 로더 거부 · 옛 세대끼리
        #       (q1 · q2 둘 다 표기 없음) 는 통과 + H12 = NOT_COMPUTED missing_input (그 세대에 없는 열) — 거부 사유가 세대 섞임 하나뿐임을 보인다
        #    ④ 다른 길로 들어온 τ 원천 (기록 한 행의 전극 칸을 옛 세대로) — 표 만들 때 거부.
        chk('㉙m1 ★ 모드 목록 = tau_flux.MODES (hertz · physics · hertz_h12) — 열 사전 정규식 · 판정이 같은 셋을 안다',
            _TF29 is not None and tuple(TAU_NET_MODES) == tuple(_TF29.MODES) and TAU_NET_H12 == _TF29.H12_MODE
            and all(_TAU_COL_RE.fullmatch(f'tau2_ion_{m_}') for m_ in TAU_NET_MODES))
        _h12c = {
            'dict': bool(_d29t),
            'status': _m29.get('ion_net_status_hertz_h12') == 'OK' and _p29.get('ion_net_status_hertz_h12') == 'NOT_PERCOLATING',
            'values': _sem29(_m29, 'hertz_h12', 'OK') and _sem29(_p29, 'hertz_h12', 'NOT_PERCOLATING'),
            'electrode': (_m29.get('ion_net_electrode_hertz') == _m29.get('ion_net_electrode_physics')
                          == _m29.get('ion_net_electrode_hertz_h12') == 'dirichlet_exact'),
            'area_psi': _m29.get('ion_net_area_rule_physics') == 'physics_g2' and _m29.get('ion_net_psi_physics') == 'multiply',
            'bulk': _m29.get('ion_net_bulk_hertz') == 'cylinder_half_d' and _m29.get('ion_net_bulk_hertz_h12') == 'sphere_segment',
            'h12_psi': (_m29.get('ion_net_psi_hertz_h12') == 'multiply'
                        and _m29.get('ion_net_constriction_hertz_h12') == 'mikic_psi_multiply'),
            'h12_differs': _m29.get('tau2_ion_hertz_h12') != _m29.get('tau2_ion_hertz'),
            'verdict_h12': all(_g29(c_, 'verdict') == TAU_NET_VERDICT_H12 and _g29(c_, 'meaning').startswith('[H12 민감도 · 부록 전용]')
                               for c_ in _tc29 if '_hertz_h12' in c_),          # f_ion_hertz_h12_gap 포함 (꼬리 _gap)
            'verdict_main': all(_g29(c_, 'verdict') == TAU_NET_VERDICT for c_ in _tc29 if '_hertz_h12' not in c_),
            'gen1_note': (TAU_H12_GEN1_NOTE in _g29('ion_net_status_hertz_h12', 'meaning')
                          and TAU_H12_GEN1_NOTE not in _g29('ion_net_status_hertz', 'meaning')),
        }
        _h12bad = sorted(k_ for k_, v_ in _h12c.items() if not v_)
        chk('㉙m2 ★ H12 민감도 열 — 같은 행 (q1 OK · q2 NOT_PERCOLATING · 값 규칙 = 주 모드와 같다) · 세대 표기 (전극 dirichlet_exact 세 모드 · physics_g2 · '
            'ψ multiply · bulk H0 원기둥 / H12 구 조각) · 열 사전 판정 = 부록 전용 (H12 만) · 세대 1 예외 문구는 H12 상태에만'
            + (f' — 어긋남 {_h12bad}' if _h12bad else ''), not _h12bad)

        def _g1v29(d_):
            """표기 없는 옛 레코드 모양 (10-06 저녁 전 생산자) — 세대 표기 · H12 레코드 · ψ 기록 · 새 계수를 뺀다 (값은 그대로 · 세대 판정만 시험)."""
            d2 = json.loads(json.dumps(d_))
            gone = ('electrode_model', 'area_rule', 'area_rule_physics', 'bulk_model', 'hertz_constriction', 'hertz_h12', 'psi_placement',
                    'area_binding_counts_physics', 'n_area_physics_unavailable', 'n_clamp_zero', 'n_floor_only', 'h_film_nm', 'h_film_status',
                    'solve_method_full', 'solve_certificate_full', 'solve_certificate_bulk_net', 'solve_certificate_constr_net')
            for m_ in ('hertzian', 'physics'):
                for k_ in list(d2[m_]):
                    if k_ in gone or any(k_ == f'{ch_}_{g_}' for ch_ in ('electronic', 'thermal') for g_ in gone):
                        d2[m_].pop(k_, None)
            return d2
        try:
            _VAR29.update({'OK_G1': (_g1v29(_VAR29['OK'][0]),) + tuple(_VAR29['OK'][1:]),
                           'NPERC_G1': (_g1v29(_VAR29['NPERC'][0]),) + tuple(_VAR29['NPERC'][1:])})
            _lwx, _resx, _ = _sc29('m_mix', q1='OK', q2='NPERC_G1')
            _neg7('㉙m3 ★ 세대 섞임 — 세대 2 폴더 (q1) + 표기 없는 옛 폴더 (q2 · 가상 전원 · physics_g1 · ψ 분모) 를 한 배치로 읽으면 로더 거부 '
                  '(tau_flux.generation_mixing_problem · 사본 없음)', lambda: _ld29(_resx, _lwx), 'τ 세대')
            _lw1, _res1, _ = _sc29('m_g1', q1='OK_G1', q2='NPERC_G1')
            _tv1 = _ld29(_res1, _lw1)
            _o1, _c1, _ = _bh29(_lw1, _tv1)
            _m1 = next((r_ for r_ in _o1 if r_['case_id'] == 'q1'), {})
            _e1 = ''
        except Exception as e:                                            # noqa: BLE001
            _m1, _c1, _e1 = {}, [], f'{type(e).__name__}: {e}'
        chk('㉙m3b ★ 옛 세대끼리 (q1 · q2 표기 없음) 는 통과 — 표기 = 이력 사실 (virtual_source_legacy · physics_g1 · cylinder_half_d · ψ legacy_divide) · '
            'H12 = NOT_COMPUTED missing_input · 값 빈칸 (그 세대에 없는 열) · 주 모드 상태 OK 그대로' + (f' — {_e1}' if _e1 else ''),
            not _e1 and _m1.get('ion_net_electrode_hertz') == 'virtual_source_legacy' and _m1.get('ion_net_area_rule_physics') == 'physics_g1'
            and _m1.get('ion_net_bulk_hertz') == 'cylinder_half_d' and _m1.get('ion_net_constriction_physics') == 'mikic_psi_divide'
            and _m1.get('ion_net_status_hertz') == _m1.get('ion_net_status_physics') == 'OK'
            and _m1.get('ion_net_status_hertz_h12') == 'NOT_COMPUTED' and str(_m1.get('ion_net_status_reason_hertz_h12')).startswith('missing_input')
            and _m1.get('tau2_ion_hertz_h12') == '' and _m1.get('f_ion_hertz_h12') == '')
        try:
            _tvx = json.loads(json.dumps(_tv29))
            for m_ in TAU_NET_MODES:
                if _tvx['cases']['q2']['cells'].get(f'ion_net_electrode_{m_}'):
                    _tvx['cases']['q2']['cells'][f'ion_net_electrode_{m_}'] = 'virtual_source_legacy'
            _neg7('㉙m4 ★ 다른 길로 들어온 τ 원천 — 기록 한 행 (q2) 의 전극 칸을 옛 세대로 바꾸면 표 만들 때 거부 (원천이 로더를 안 거쳐도 한 번 더)',
                  lambda: _bh29(_lw29, _tvx), 'τ 세대')
        except Exception as e:                                            # noqa: BLE001
            chk(f'㉙m4 ({type(e).__name__}: {e})', False)
    finally:
        shutil.rmtree(_td29, ignore_errors=True)
    #  ═══ ㉚ LREL-01 · 02 · 03 · 04 (Codex 배포 v1.1 최종 리뷰 10-01 §3 반례 · 1저자 비준 10-06 "A·B 코드" — 반례 먼저) ═══════════════════════════
    #   현재 194 행에는 이 반례가 없다 (판정문) — 관문이 **앞으로 다시 만드는 표**에서 그것을 막는가를 본다.
    _dq30 = [{'case_id': 'q1'}, {'case_id': 'q2'}]
    #  LREL-01 — D0: 이온 분할 비율이 유한 · [0, 100] · 개수 [0, N] — 정수 · 합 · 상별 합 검사만으로는 음수 개수 분할이 통과했다
    _neg7('㉚a ★ LREL-01 — 무접촉 −1 개 (전체 −100/11 % · AM_P −100 %) + 단절 +1 개 — 합 100 · 정수 · 상별 합을 다 맞춘 음수 분할이면 거부 '
          '(Codex negative_ionic_no_se_counts 를 q2 에 옮김)',
          _bad10('q2', ionic_no_se_pct=repr(-100 / 11), ionic_dead_pct=repr(700 / 11), AM_P_ionic_no_se_pct='-100.0', AM_P_ionic_dead_pct='100.0'),
          'v1.1 D0')
    _neg7('㉚b ★ LREL-01 — 상별 단절 비율이 NaN 이면 거부 (합 검사는 NaN 을 못 본다)', _bad10('q2', AM_S_ionic_dead_pct='nan'), 'v1.1 D0')
    _neg7('㉚c ★ LREL-01 — 상별 활성 > 100 (AM_P 110 · 단절 −10 — 합은 100) 이면 거부',
          _bad10('q2', AM_P_ionic_active_pct='110.0', AM_P_ionic_dead_pct='-10.0'), 'v1.1 D0')
    #  LREL-02 — 적격성 (physical_target_status · hold_reason_codes · boundary_state + calculation_status) 이 수확기 규칙대로 다 있고 정합한가
    _h30ok = {'q1': _hq('q1', eps_s=-2.0, th=30.0), 'q2': _hq('q2', eps_s=20.0, th=40.0)}

    def _hq30(case='q2', **qc):
        h_ = _hq(case, eps_s=20.0, th=40.0)
        h_['handover_qc'] = dict(h_['handover_qc'], **qc)
        return h_
    try:
        _o30, _c30, _r30 = build_handover(_dq30, _h30ok)
        _e30 = ''
    except Exception as e:                                                # noqa: BLE001
        _o30, _c30, _r30, _e30 = [], [], {}, f'{type(e).__name__}: {e}'
    _q30 = {r_['case_id']: r_ for r_ in _o30}
    chk('㉚d ★ LREL-02 — 수확기 모양의 적격성 (q1 HOLD · NEGATIVE_POROSITY · q2 OK · INSIDE) 은 통과 · 세 열 값 그대로 · 보고에 검사 2 행'
        + (f' — {_e30}' if _e30 else ''),
        not _e30 and _q30.get('q1', {}).get('physical_target_status') == 'HOLD' and _q30.get('q1', {}).get('hold_reason_codes') == 'NEGATIVE_POROSITY'
        and _q30.get('q2', {}).get('physical_target_status') == 'OK' and _q30.get('q2', {}).get('boundary_state') == 'INSIDE'
        and _r30.get('eligibility_checked') == 2)
    for _nm30, _kv30 in (('physical_target_status None', dict(physical_target_status=None)),
                         ('hold_reason_codes None', dict(hold_reason_codes=None)),
                         ('boundary_state None', dict(boundary_state=None)),
                         ('physical_target_status 모르는 값 (MAYBE)', dict(physical_target_status='MAYBE')),
                         ('hold_reason_codes 모르는 코드 (BOGUS)', dict(hold_reason_codes='BOGUS', physical_target_status='HOLD')),
                         ('boundary_state 모르는 값 (OUTSIDE)', dict(boundary_state='OUTSIDE')),
                         ('HOLD 인데 보류 코드 없음', dict(physical_target_status='HOLD')),
                         ('OK 인데 보류 코드 있음', dict(hold_reason_codes='BOUNDARY_CENTER_OUT', boundary_state='CENTER_CROSSED',
                                                     n_floor_center_out=3)),
                         ('BOUNDARY_CENTER_OUT 인데 boundary INSIDE', dict(hold_reason_codes='BOUNDARY_CENTER_OUT', physical_target_status='HOLD',
                                                                       n_floor_center_out=3)),
                         ('boundary CENTER_CROSSED 인데 BOUNDARY_CENTER_OUT 없음', dict(boundary_state='CENTER_CROSSED', n_floor_center_out=3)),
                         ('NEGATIVE_POROSITY 인데 구 부피 합 porosity ≥ 0', dict(hold_reason_codes='NEGATIVE_POROSITY', physical_target_status='HOLD')),
                         ('FULLY_OUT 인데 통째로 밖 0 개', dict(boundary_state='FULLY_OUT', hold_reason_codes='BOUNDARY_CENTER_OUT',
                                                           physical_target_status='HOLD', n_floor_center_out=2)),
                         ('같은 코드 두 번', dict(hold_reason_codes='BOUNDARY_CENTER_OUT|BOUNDARY_CENTER_OUT', boundary_state='CENTER_CROSSED',
                                              physical_target_status='HOLD', n_floor_center_out=2)),
                         ('calculation_status FAILED', dict(calculation_status='FAILED'))):
        _neg7(f'㉚e ★ LREL-02 — 적격성 {_nm30} 이면 거부', (lambda kv=_kv30: build_handover(_dq30, dict(_h30ok, q2=_hq30(**kv)))), 'LREL-02')
    _h30del = _hq30()
    for _k30 in ('physical_target_status', 'hold_reason_codes', 'boundary_state'):
        _h30del['handover_qc'].pop(_k30)
    _neg7('㉚f ★ LREL-02 — 세 키를 지운 수확 (Codex drop_eligibility — 수치는 그대로 · 표지 3 칸 빈칸 행이 정상 생성됐다) 이면 거부',
          lambda: build_handover(_dq30, dict(_h30ok, q2=_h30del)), 'LREL-02')
    _neg7('㉚g ★ LREL-02 — 한 행만 handover_qc 가 없으면 거부 (수확 세대 혼합 · 표지 빈칸 행을 만들지 않는다)',
          lambda: build_handover(_dq30, dict(_h30ok, q2={k_: v_ for k_, v_ in _hq('q2', eps_s=20.0, th=40.0).items() if k_ != 'handover_qc'})),
          'LREL-02')
    #  LREL-03 — "130 행" ≠ "130 개 고유 설계" — 설계행 case_id 중복 (같은 행 수의 대체) · 빈 ID
    _neg7('㉚h ★ LREL-03 — 설계행 case_id 중복 (두 번째 행을 첫 행으로 교체 · 행 수 그대로 — Codex design_row_duplicate) 이면 거부',
          lambda: build_handover([{'case_id': 'q1'}, {'case_id': 'q1'}], _h30ok), 'LREL-03')
    _neg7('㉚i ★ LREL-03 — 설계행 case_id 가 비면 거부', lambda: build_handover([{'case_id': 'q1'}, {'case_id': ''}], dict(_h30ok, **{'': _h30ok['q2']})),
          'LREL-03')
    #  LREL-04 — union SE/고체 = 수확 V_SE/(V_SE + V_AM) (부피 감사) = φ_SE/(φ_SE + φ_AM) · [0, 1] (φ 합 닫힘만으로는 SE 몫 변조를 못 본다)
    _u30 = {'q1': _u('q1', eps_s=-2.0, th=30.0, eps_u=6.5, se=0.5 / 1.02), 'q2': _u('q2', eps_s=20.0, th=40.0, eps_u=21.0, se=0.5 / 0.8)}
    try:
        _r30u = build_handover(_dq30, _h30ok, union=_u30)[2]
        _e30u = ''
    except Exception as e:                                                # noqa: BLE001
        _r30u, _e30u = {}, f'{type(e).__name__}: {e}'
    chk('㉚j ★ LREL-04 — SE/고체 = 수확 V_SE/(V_SE + V_AM) = φ_SE/(φ_SE + φ_AM) 이면 통과 · 보고에 교차대조 2 행' + (f' — {_e30u}' if _e30u else ''),
        not _e30u and _r30u.get('se_share_checked') == 2)
    _neg7('㉚k ★ LREL-04 — union SE/고체 한 칸만 0.5 (ε · φ_SE 는 그대로 — Codex union_SE_fraction_half) 이면 거부',
          lambda: build_handover(_dq30, _h30ok, union=dict(_u30, q1=_u('q1', eps_s=-2.0, th=30.0, eps_u=6.5, se=0.5))), 'LREL-04')
    _neg7('㉚l ★ LREL-04 — SE/고체 > 1 이면 거부', lambda: build_handover(_dq30, _h30ok, union=dict(_u30, q2=dict(_u30['q2'], se_of_solid_vol='1.2'))),
          'LREL-04')
    _neg7('㉚m ★ LREL-04 — SE/고체 NaN 이면 거부', lambda: build_handover(_dq30, _h30ok, union=dict(_u30, q2=dict(_u30['q2'], se_of_solid_vol='nan'))),
          'LREL-04')
    _h30ns = _hq('q2', eps_s=20.0, th=40.0)
    _h30ns['handover_qc'] = {k_: v_ for k_, v_ in _h30ns['handover_qc'].items() if k_ not in ('V_SE_full_um3', 'V_AM_full_um3')}
    _h30ns['status'] = dict(_h30ns['status'], phi='N_A_TEST')
    _neg7('㉚n ★ LREL-04 — SE 몫을 다시 잴 원천이 없으면 (부피 감사 없음 · φ 상태 OK 아님) 거부',
          lambda: build_handover(_dq30, dict(_h30ok, q2=_h30ns), union=_u30), 'LREL-04')
    _h30v = _hq('q2', eps_s=20.0, th=40.0)
    _h30v['handover_qc'] = dict(_h30v['handover_qc'], V_SE_full_um3=0.6)
    _neg7('㉚o ★ LREL-04 — 수확 부피 감사 V_SE/(V_SE + V_AM) 가 union SE/고체와 어긋나면 (φ 비와는 같아도) 거부',
          lambda: build_handover(_dq30, dict(_h30ok, q2=_h30v), union=_u30), 'LREL-04')
    #  ═══ ㉛ 열 사전 문구 (LREL-05 · 06 · TAU-24 · J20-m ②–⑥ · J20-c ⓒ union 규약 한정어 · τ 명명 규약 — 1저자 비준 10-06 "A·B 코드") ═══════════════
    #   v1.2 README (docs/data/lhs_release_20261006_v12/README.md) 가 정정판으로 적은 문구를 생성기 사전에 옮긴다 (다음 생성부터 TSV 도 같은 문구).
    def _chk31(name, cond, info=''):
        chk(name + ('' if cond else f' — {str(info)[:300]}'), cond)

    def _cd31(cols, **kw):
        try:
            return {d['column']: d for d in column_dictionary(cols, **kw)}
        except TypeError as e:                                             # 옛 서명 (design_source 없음)
            return {'_err': {'meaning': f'TypeError: {e}', 'caveat': '', 'source': ''}}
    _d31 = _cd31(['case_id', 'block', 'am_pct', 'ps_frac', 'pressure_MPa', 'n_am_p_est', 'thickness_est_um', 'lhsx_pdd_SE', 'lhsx_volfrac'],
                 design_source='docs/data/lhsx_design_adapted_20260929.csv')
    _g31 = lambda c, k='meaning': (_d31.get(c) or {}).get(k, '')                 # noqa: E731
    _chk31('㉛a ★ LREL-06 — 설계 열 정의: am_pct = 고체 중 AM 질량 % (부피 % 아님) · ps_frac = AM 중 AM_P 질량 몫 (개수 몫 아님) · 출처 = 이 표의 설계 CSV '
        '(확장 = lhsx_design_adapter) · pressure_MPa 는 도달 여부를 말하지 않는다 (DESC-06) · n_*_est = 추정 (실측 아님)',
        '고체 중 AM 질량 %' in _g31('am_pct') and '부피 % 아님' in _g31('am_pct') and 'AM 중 AM_P 질량 몫' in _g31('ps_frac')
        and '개수 몫 아님' in _g31('ps_frac') and 'lhsx_design_adapted_20260929.csv' in _g31('am_pct') and _g31('am_pct', 'source') == 'design'
        and 'DESC-06' in _g31('pressure_MPa') and '추정' in _g31('n_am_p_est') and '측정 아님' in _g31('thickness_est_um')
        and 'lhsx_design_adapter' in _g31('lhsx_pdd_SE') and 'am_pct' in _g31('lhsx_pdd_SE') and 'volfrac' in _g31('lhsx_volfrac'),
        repr({c: _g31(c)[:60] for c in ('am_pct', 'ps_frac', 'lhsx_pdd_SE')}))
    _dm31 = {d['column']: d for d in column_dictionary(_c10, webapp=_wa10())} if _c10 else {}
    _io31 = ('ionic_active_pct', 'am_ionic_isolated_pct', 'ionic_dead_pct', 'ionic_no_se_pct', 'AM_P_ionic_active_pct', 'AM_S_ionic_dead_pct')
    _bad31 = [c for c in _io31 if not ('그래프' in _dm31.get(c, {}).get('meaning', '') and '이온 전류' in _dm31.get(c, {}).get('meaning', ''))
              or any(w in _dm31.get(c, {}).get('meaning', '') for w in ('닿을 수 없는', '실제로 닿', '실제로 도달'))]
    _chk31('㉛b ★ LREL-05 — 이온 활성 · 경로 고립 · 분해 열의 뜻 = 상단 2r 경계 띠 · SE 접촉 그래프 지표 (실제 분리막 접촉 · 계면 저항 · 이온 전류는 계산하지 '
        '않는다) — "이온이 닿을 수 없는" 같은 실제 도달 단정 없음', bool(_dm31) and not _bad31, repr(_bad31))
    _du31 = _cd31(['porosity_union_exact_pct', 'porosity_union_exact_se_pct', 'phi_se_mass_conserving'])
    _um31 = (_du31.get('porosity_union_exact_pct') or {}).get('meaning', '')
    _chk31('㉛c ★ LREL-06 · J20-c ⓒ — 정확 union = 합집합 정의 (쌍 렌즈 아님) 이지 MC 오차 0 이 아니다 (1σ 열 · 130 0.012–0.023 · 64 0.011–0.015 %p · 마지막 자리 인용 금지) · '
        '규약 한정어 = 소성 압축 고체 과소계상 상한 규약 (기록된 문구 · 저자 결정 대기)',
        'MC' in _um31 and '0.012–0.023' in _um31 and '0.011–0.015' in _um31 and '마지막 자리' in _um31 and '상한 규약' in _um31
        and 'J20-c' in _um31 and '과소계상' in _um31, _um31[:200])
    _dtw31 = _cd31(['tortuosity_SE_wall', 'tau2_ion_hertz', 'f_ion_hertz'])
    _dtn31 = _cd31(['tortuosity_SE_wall'])
    _tw31, _tn31 = ((_dtw31.get('tortuosity_SE_wall') or {}).get('meaning', ''), (_dtn31.get('tortuosity_SE_wall') or {}).get('meaning', ''))
    _chk31('㉛d ★ tortuosity_SE_wall — 기하학적 tortuosity · 수송 τ 아님 유지 · 망 τ 열이 있는 표에서는 "이 표에 없음" 대신 tau2_ion_hertz (수송 tortuosity factor T · '
        '제곱근 아님) 를 가리킨다 · 망 τ 가 없는 표에서는 그 표에 없다고 적는다',
        '기하학적 tortuosity' in _tw31 and '수송 τ 가 아니다' in _tw31 and '이 표에 없음' not in _tw31 and 'tau2_ion_hertz' in _tw31
        and '수송 tortuosity factor' in _tw31 and '제곱근 아님' in _tw31 and '이 표에는 없다' in _tn31 and 'tau2_ion_hertz' not in _tn31,
        f'{_tw31[-260:]} || {_tn31[-160:]}')
    _th31 = [(c, (tau_net_define(c) or ('', ''))[0]) for c in ('f_ion_hertz', 'tau2_ion_hertz', 'tau_ion_hertz', 'ion_net_status_hertz', 'tau2_ion_hertz_h12')]
    _chk31('㉛e ★ hertz 모드 열의 뜻에 면적 = LIGGGHTS c_cpl[22] 기하 교차 원판 (탄성 Hertz πR*δ 의 ≈ 2 배 · 이름만 Hertz · L1-04)',
        all('c_cpl[22]' in m_ and '≈ 2 배' in m_ for _c, m_ in _th31) and 'c_cpl[22]' not in (tau_net_define('tau2_ion_physics') or ('',))[0],
        repr([(c, m_[:40]) for c, m_ in _th31 if 'c_cpl[22]' not in m_]))
    _bf31 = (tau_net_define('ion_net_band_frac_hertz') or ('', ''))[0]
    _chk31('㉛f ★ TAU-24 — 띠 분율 열 = (바닥 띠 폭 + 위 띠 폭) / 판 간격 L_gap · L0 = 4r_SE/L (가장 큰 SE 반지름) · tau2 하향의 상한 · 보정한 T 는 내지 않는다 '
        '(1저자 결정 대기) · 실측 범위 (옛 추정 "중앙 6 % · 최대 17 %" 대신)',
        '바닥 띠 폭 + 위 띠 폭' in _bf31 and '판 간격' in _bf31 and '4r_SE/L' in _bf31 and '상한' in _bf31 and '보정한 T 는 내지 않는다' in _bf31
        and '0.050–0.135' in _bf31 and '0.060–0.157' in _bf31 and '중앙 6 %' not in _bf31, _bf31[:200])
    _dcv31 = _cd31(['coverage_AM_P_hertz_pct', 'coverage_AM_S_hertz_pct', 'coverage_AM_total_hertz_pct'])
    _cv31 = (_dcv31.get('coverage_AM_P_hertz_pct') or {}).get('caveat', '')
    _chk31('㉛g ★ J20-m 인계 한정어 ②–⑥ — coverage 열 주의에 SE-rich 과압축 절대값 · AM 90–95 wt% SE 바닥 몰림 (추정) · porosity 공선 · AM_P 소표본 · 옛 코퍼스 치밀도',
        all(w in _cv31 for w in ('A_dem_geometric', 'J20-m', 'SE-rich', '바닥 몰림', '추정', '공선', '소표본', '옛 코퍼스'))
        and (_dcv31.get('coverage_AM_total_hertz_pct') or {}).get('caveat', '') == _cv31, _cv31[:160])
    #  ㉛h — 실데이터: v1.2 인계표 열로 사전을 다시 만들면 배포 v1.2 주 표에 없는 정본 인계표 열 참조가 전부 표지 '(정본 인계표 열)' 를 단다 (배포 빌더 ml_v1 ③)
    try:
        import lhs_release_build as _LRB31
        _bh31 = pathlib.Path(__file__).resolve().parent.parent / 'docs' / 'data' / 'lhs_network194_11fcf91e8'
        _rl31 = pathlib.Path(__file__).resolve().parent.parent / 'docs' / 'data' / 'lhs_release_20261006_v12'
        _dg31 = {}
        for _coh in ('lhs', 'lhsx'):
            with (_bh31 / 'handover_v12_20261006' / f'{_coh}_handover_v12_20261006.csv').open(encoding='utf-8', newline='') as _fh:
                _hc31 = next(csv.reader(_fh))
            with (_rl31 / f'{_coh}_release_20261006_v12.csv').open(encoding='utf-8', newline='') as _fh:
                _rc31 = next(csv.reader(_fh))
            _rows31 = [[d['column'], d['source'], d['verdict'], d['meaning'], d['caveat']]
                       for d in column_dictionary(_hc31, webapp=load_webapp(_bh31 / 'merged' / _coh)) if d['column'] in _rc31]
            _dg31[_coh] = _LRB31.dangling_refs(_rc31, _hc31, _rows31)
        _chk31('㉛h ★ 실데이터 — v1.2 인계표 열로 다시 만든 사전: 배포 v1.2 주 표 (lhs · lhsx) 에 없는 정본 인계표 열 참조 = 전부 표지 (배포 프로필 ③ 문제 0)',
            all(v == [] for v in _dg31.values()), repr({k: sorted({r for _, r in v})[:10] for k, v in _dg31.items()}))
    except Exception as e:                                                # noqa: BLE001
        _chk31(f'㉛h 실데이터 사전 참조 표지 ({type(e).__name__}: {e})', False)
    #  ㉛i — 보충 lhss 20 설계 열 (1저자 10-12 Q4 = (가) lhss 별도 데이터셋 · Q6 = (가) 하중 열) — 출처 열 17 의 뜻이 일반 문구 · lhsx 문구로 새지 않는다
    _ls31 = pathlib.Path(__file__).resolve().parent.parent / 'docs' / 'data' / 'lhss_design_adapted_20261012.csv'
    try:
        with _ls31.open(encoding='utf-8', newline='') as _fh:
            _lsc31 = next(csv.reader(_fh))
        _dls31 = _cd31(_lsc31, design_source='docs/data/lhss_design_adapted_20261012.csv')
    except Exception as e:                                                # noqa: BLE001
        _lsc31, _dls31 = [], {'_err': {'meaning': f'{type(e).__name__}: {e}', 'caveat': '', 'source': ''}}
    _lsx31 = [c for c in _lsc31 if c.startswith('lhss_')]
    _gm31 = lambda c: (_dls31.get(c) or {}).get('meaning', '')            # noqa: E731
    _bad_ls31 = [c for c in _lsx31 if c not in DESIGN_DEFINE or '생성 코드' in _gm31(c) or 'lhsx_design_adapter' in _gm31(c)
                 or 'lhss_design_adapter' not in _gm31(c) or 'lhs_supp_design_20261006.csv' not in _gm31(c)]
    _chk31('㉛i ★ 보충 lhss 설계 출처 열 17 = 전부 고유 뜻 (DESIGN_DEFINE) · 원천 = 보충 설계 CSV 를 scripts/lhss_design_adapter.py 가 옮긴 열 · '
           'lhsx 어댑터 · 일반 문구로 새지 않는다',
           len(_lsx31) == 17 and not _bad_ls31, repr((len(_lsx31), _bad_ls31[:6])))
    _chk31('㉛i2 ★ lhss 뜻 차이 — stratum · lhs_cell = 빈칸 (maximin 선택 · 층화 LHS 아님) · rSE_lo_um = SE 지름 1.0 µm 시뮬 하한 (lhsx 와 뜻이 다름) · '
           'loading_rule = 경계 SE_SPLIT (2mAh_fixed · volfrac_free) · lhss_loading_mAh_cm2 = 역산값은 설계 입력 아님 · cap_adjust = 기존 194 최대 입자 수 · '
           'gap_dist = maximin 최근접 거리 (특징 아님)',
           all(w in _gm31('lhss_stratum') for w in ('빈칸', 'maximin')) and all(w in _gm31('lhss_lhs_cell') for w in ('빈칸', 'maximin'))
           and '1.0 µm' in _gm31('lhss_rSE_lo_um') and '뜻이 다르다' in _gm31('lhss_rSE_lo_um')
           and all(w in _gm31('lhss_loading_rule') for w in ('SE_SPLIT', '2mAh_fixed', 'volfrac_free'))
           and all(w in _gm31('lhss_loading_mAh_cm2') for w in ('거꾸로', '설계 입력 아님', 'loading_mAh_cm2'))
           and '기존 194' in _gm31('lhss_cap_adjust') and all(w in _gm31('lhss_gap_dist') for w in ('maximin', '특징 아님')),
           repr({c: _gm31(c)[:50] for c in ('lhss_stratum', 'lhss_rSE_lo_um', 'lhss_loading_rule', 'lhss_cap_adjust')}))
    _lm31 = _gm31('loading_mAh_cm2')
    _chk31('㉛i3 ★ Q6 (가) — 본 하중 열 뜻 = 2 mAh 규칙 행 설계 입력 2.0 (130 전부 · 보충 2mAh_fixed) · 부피분율 규칙 행 빈칸 (보충 volfrac_free · 역산값 = '
           'lhss_loading_mAh_cm2 + 표지 "(정본 인계표 열)" — 배포에 없는 인계표 열 참조 · 배포 프로필 ③) · lhsx 64 = 열 없음 · 경계 am_pct 70 · '
           '일반 문구 = 세 생성 코드 (130 · 64 · 보충 20)',
           all(w in _lm31 for w in ('2.0', '2mAh_fixed', 'volfrac_free', '빈칸', 'lhsx', 'am_pct 70', 'lhss_loading_mAh_cm2 (정본 인계표 열)'))
           and 'lhss_design_adapter' in design_define('some_new_design_col'), _lm31[:200])
    try:                                                                  # 실데이터 사전 + 배포 빌더 dangling_refs — lhss 주 표 (lhs 132 열) 기준 문제 0
        import lhs_release_build as _LRB31i
        _rel31i = list(_LRB31i._v13_tsv_cols('docs/data/lhs_release_20261006_v12/lhs_release_20261006_v12_columns.tsv'))
        _dg31i = _LRB31i.dangling_refs(_rel31i, _lsc31 + ['lhss_loading_mAh_cm2'],
                                       [[c, d['source'], d['verdict'], d['meaning'], d['caveat']] for c, d in _dls31.items() if c in _rel31i])
        _chk31('㉛i4 ★ lhss 설계 열 사전 (커밋된 어댑터 CSV 머리) 을 lhs 132 열 배포에 실을 때 표지 없는 인계표 열 참조 0 (배포 프로필 ③ · LREL-06)',
               _dg31i == [], repr(_dg31i[:6]))
    except Exception as e:                                                # noqa: BLE001
        _chk31(f'㉛i4 lhss 사전 참조 표지 ({type(e).__name__}: {e})', False)
    #  ㉛j ★ 10-12 SUP20-02 (Codex 보충 20 지원 검토 §2 · P3 · 수정 계획 docs/reviews/sup20_fix_plan_20261012.md §2 · 1저자 Q2 (가)) — 원천 슬롯 열 *_w_AM_P ·
    #     *_w_AM_S (lhsx · lhss) 의 mono 규약.  type 2 개 덱 (mono_AM_P · mono_AM_S) 의 P 슬롯 = 단일 AM 자리 (scripts/lhs_ext_materialize.py 머리 "P 열 = 일반 AM 자리" ·
    #     어댑터가 kind 로 상을 옮긴다) → 비율 식 w_AM_P / (w_AM_P + w_AM_S) 은 bimodal 에만.  옛 문구 "AM_P 질량분율 — ps_frac = w_AM_P / (w_AM_P + w_AM_S)" 는
    #     mono_AM_S 행 (P 슬롯 > 0 · S 슬롯 0) 에서 1 을 준다 (실제 ps_frac = 0).  문구만 — CSV · 계산 변경 없음.
    _wd31 = dict(_cd31(['lhsx_w_AM_P', 'lhsx_w_AM_S'], design_source='docs/data/lhsx_design_adapted_20260929.csv'),
                 **_cd31(['lhss_w_AM_P', 'lhss_w_AM_S'], design_source='docs/data/lhss_design_adapted_20261012.csv'))
    _gw31 = lambda c: (_wd31.get(c) or {}).get('meaning', '')            # noqa: E731
    _bad_w31 = [c for c in ('lhsx_w_AM_P', 'lhss_w_AM_P')
                if not all(w in _gw31(c) for w in ('P 슬롯', 'bimodal = AM_P', '단일 AM 자리', 'bimodal 에만', 'mono_AM_P → ps_frac 1', 'mono_AM_S → ps_frac 0'))
                or _gw31(c).startswith('AM_P 질량분율')]
    _bad_w31 += [c for c in ('lhsx_w_AM_S', 'lhss_w_AM_S') if not all(w in _gw31(c) for w in ('S 슬롯', 'bimodal = AM_S', 'mono = 0'))]
    _chk31('㉛j ★ SUP20-02 — 원천 슬롯 열 w_AM_P · w_AM_S (lhsx · lhss) = P · S 슬롯 질량분율 · mono (type 2 개) 의 P 슬롯 = 단일 AM 자리 · 비율 식은 bimodal 에만 · '
           'mono_AM_P → ps_frac 1 · mono_AM_S → ps_frac 0 (옛 문구 "AM_P 질량분율 — ps_frac = w_AM_P / (w_AM_P + w_AM_S)" = mono_AM_S 에서 1)',
           not _bad_w31, repr({c: _gw31(c)[:80] for c in _bad_w31}))
    #  ㉛j2 — 문구가 적는 규약 = 커밋된 어댑터 CSV (lhsx 64 · lhss 20) 의 실제 값 (계산 정상 확인 · 문구를 고치기 전 · 뒤 같음) + Codex design_probe 의 표
    #     (lhss mono_AM_S 네 행 = P 슬롯 0.3 · 0.3 · 0.3 · 0.375 · S 슬롯 0 · 옛 식 = 1 · ps_frac = 0)
    _rule31, _old31 = [], {}
    for _ds31j, _rel31j in (('lhsx', 'docs/data/lhsx_design_adapted_20260929.csv'), ('lhss', 'docs/data/lhss_design_adapted_20261012.csv')):
        try:
            with (pathlib.Path(__file__).resolve().parent.parent / _rel31j).open(encoding='utf-8', newline='') as _fh31j:
                _rr31j = list(csv.DictReader(_fh31j))
        except Exception as e:                                            # noqa: BLE001
            _rule31.append((_ds31j, f'{type(e).__name__}: {e}'))
            continue
        for _r31j in _rr31j:
            _k31j, _p31j = _r31j[f'{_ds31j}_kind'], float(_r31j[f'{_ds31j}_w_AM_P'])
            _s31j, _f31j = float(_r31j[f'{_ds31j}_w_AM_S'] or 0), float(_r31j['ps_frac'])
            _ok31j = (abs(_p31j / (_p31j + _s31j) - _f31j) <= 1e-9 and _s31j > 0 if _k31j == 'bimodal' else
                      _f31j == 1.0 and _s31j == 0 and _p31j > 0 if _k31j == 'mono_AM_P' else
                      _f31j == 0.0 and _s31j == 0 and _p31j > 0 if _k31j == 'mono_AM_S' else False)
            if not _ok31j:
                _rule31.append((_r31j['case_id'], _k31j, _p31j, _s31j, _f31j))
            if _k31j == 'mono_AM_S':
                _old31.setdefault(_ds31j, {})[_r31j['case_id']] = (_p31j, _p31j / (_p31j + _s31j), _f31j)
    _chk31('㉛j2 SUP20-02 — 커밋된 어댑터 CSV: bimodal = w_P / (w_P + w_S) · mono_AM_P = 1 · mono_AM_S = 0 (S 슬롯 0 · P 슬롯 = 단일 AM) 위반 0 · '
           'lhss mono_AM_S = Codex 표 네 행 (P 0.3 · 0.3 · 0.3 · 0.375 → 옛 식 1 · ps_frac 0) · lhsx mono_AM_S 8 행도 옛 식 1 · ps_frac 0',
           not _rule31 and {c: v[0] for c, v in (_old31.get('lhss') or {}).items()} == {'lhss_001': 0.3, 'lhss_002': 0.3, 'lhss_003': 0.3, 'lhss_020': 0.375}
           and all(v[1] == 1.0 and v[2] == 0.0 for d_ in _old31.values() for v in d_.values()) and len(_old31.get('lhsx') or {}) == 8,
           repr((_rule31[:4], _old31.get('lhss'))))
    #  ═══ ㉜ DESC-06 최종 join (원자료 sha) · DESC-07 ② 전체 피복 가중평균 (Codex 배포 v1.1 최종 리뷰 raw_sha_mismatch · coverage_total_plus_1 — 반례 먼저) ═══
    def _wa32(**st):
        w_ = _wa()
        for q_, kv_ in st.items():
            w_['status'][q_].update(kv_)
        return w_
    try:
        _r32 = build_handover(_dq28, _hq28, webapp=_wa(), wa_reviewed_only=False)[2]
        _e32 = ''
    except Exception as e:                                                # noqa: BLE001
        _r32, _e32 = {}, f'{type(e).__name__}: {e}'
    chk('㉜a ★ DESC-06 — 웹앱 배치 status 의 원자료 sha 넷 = 수확 raw sha 이면 통과 · 보고에 대조 행 수 2' + (f' — {_e32}' if _e32 else ''),
        not _e32 and _r32.get('wa_raw_sha_checked') == 2)
    _neg7('㉜b ★ DESC-06 — 접촉 단계 status 의 atom sha 를 바꾸면 거부 (Codex raw_sha_mismatch — 옛 최종 join 은 통과)',
          lambda: build_handover(_dq28, _hq28, webapp=_wa32(q1={'sha': dict(_RAW_SHA, atom='9' * 64)}), wa_reviewed_only=False), 'DESC-06')
    _neg7('㉜c ★ DESC-06 — done 행 status 에 sha 가 없으면 거부 (같은 원자료인지 모른다)',
          lambda: build_handover(_dq28, _hq28, webapp=_wa32(q2={'sha': {}}), wa_reviewed_only=False), 'DESC-06')
    _h32 = dict(_hq28, q1=dict(_hq28['q1'], raw={k_: v_ for k_, v_ in _hq28['q1']['raw'].items() if k_ != 'mesh'}))
    _neg7('㉜d ★ DESC-06 — 수확 raw 에 mesh sha 가 없으면 거부', lambda: build_handover(_dq28, _h32, webapp=_wa(), wa_reviewed_only=False), 'DESC-06')
    try:
        _r32e = build_handover(_dq28, _hq28, webapp=_wa32(q2={'status': 'REFUSED', 'sha': {}}), wa_reviewed_only=False)[2]
        _e32e = ''
    except Exception as e:                                                # noqa: BLE001
        _r32e, _e32e = {}, f'{type(e).__name__}: {e}'
    chk('㉜e 배치가 거부한 행 (REFUSED · sha 없음) 은 웹앱 값을 싣지 않으므로 sha 도 보지 않는다 (대조 1 행)' + (f' — {_e32e}' if _e32e else ''),
        not _e32e and _r32e.get('wa_raw_sha_checked') == 1)
    _h32f = dict(_hq28, q2=dict(_hq28['q2'], coverage_AM_total_hertz_pct=_hq28['q2']['coverage_AM_total_hertz_pct'] + 1.0))
    _neg7('㉜f ★ DESC-07 ② — 전체 피복률만 +1 %p (상별 값 · 개수 그대로 — Codex coverage_total_plus_1) 이면 거부 (옛 인계 생성기는 통과)',
          lambda: build_handover(_dq28, _h32f), 'DESC-07')
    _h32g = dict(_hq28, q2={k_: v_ for k_, v_ in _hq28['q2'].items() if k_ != 'coverage_detail'})
    _neg7('㉜g ★ DESC-07 ② — 상별 피복이 둘 다 있는데 피복 유효 입자 수 (coverage_detail.counts) 가 없으면 거부', lambda: build_handover(_dq28, _h32g),
          'DESC-07')
    try:
        import lhs_webapp_batch as _LWB32
        _same32 = tuple(_LWB32.RAW_KEYS) == tuple(WA_RAW_KEYS)
    except Exception as e:                                                # noqa: BLE001
        _same32 = False
    chk('㉜i 원자료 키 = lhs_webapp_batch.RAW_KEYS (배치가 status 에 남기는 sha 키와 같다 — 한쪽만 바뀌면 걸린다)', _same32)
    _dc32 = {d['column']: d for d in column_dictionary(['coverage_AM_total_hertz_pct'])}
    chk('㉜h 열 사전 — coverage_AM_total = (N_P·C_P + N_S·C_S)/(N_P + N_S) · 피복 유효 입자 수 가중 · 관문 DESC-07 ② · 실측 N 누설 주의',
        all(w in (_dc32.get('coverage_AM_total_hertz_pct') or {}).get('meaning', '') for w in ('N_P', 'DESC-07', 'cov_AM_P_n_valid', '누설')))
    #  ═══ ㉝ v1.3 최종판 (1저자 비준 10-06 밤 · 10-07 "v1.3 생성기를 Codex 판정과 동시에 미리 준비") — 반례 먼저 ═══════════════════════════════════
    #   ① 고립 전해질 se_isolated_pct = 100 − top_reachable_pct — AM 경로 고립 (am_ionic_isolated_pct = 100 − ionic_active_pct) 과 같은 규칙 · 재실행 없음 ·
    #      묶음 se_isolation (명시 opt-in — 옛 인계표 바이트 불변 = ㉙f2) · 관문 S1 (= 100 − top · 웹앱이 같은 이름을 내면 같아야) · S2 (≤ 100 − percolation) ·
    #      열 사전 한정어 (분리막 쪽 띠의 외톨이 SE 를 연결로 세어 약간 적게 잡는다 · 비관통에 몰린다 → 관통 분류 먼저)
    #   ② τ 표시 이름 (1저자 10-05 밤 "그냥 수송 tortuosity" · 10-06 밤 비준 = v1.3 묶음 · J20-l) — 키 tau2_* 그대로 · tau2 의 이름 = 수송 tortuosity
    #      (정의 · 제곱근 아님 병기) · √ 값 (tau) 에는 그 이름을 쓰지 않는다 · f_ion_hertz = ML 1차 타깃 안내 (#2)
    def _b33(w=None, groups='contact,percolation,se_isolation'):
        return build_handover(_dq7, _hq10(), webapp=w or _wa10(), webapp_groups=groups)
    try:
        _o33, _c33, _r33 = _b33()
        _e33 = ''
    except Exception as e:                                                # noqa: BLE001
        _o33, _c33, _r33, _e33 = [], [], {}, f'{type(e).__name__}: {e}'
    _m33 = next((r for r in _o33 if r['case_id'] == 'q1'), {})
    _p33 = next((r for r in _o33 if r['case_id'] == 'q2'), {})
    chk('㉝a ★ v1.3 se_isolated_pct = 100 − top_reachable_pct (q1 40 → 60 · q2 15 → 85) · am_ionic_isolated_pct 바로 뒤 · 관문 S1 · S2 2 행'
        + (f' — {_e33}' if _e33 else ''),
        not _e33 and _m33.get('se_isolated_pct') == repr(100.0 - 40.0) and _p33.get('se_isolated_pct') == repr(100.0 - 15.0)
        and 'se_isolated_pct' in _c33 and _c33.index('se_isolated_pct') == _c33.index('am_ionic_isolated_pct') + 1
        and _r33.get('wa_se_iso_checked') == 2)
    try:
        _c33n = _b33(groups='contact,percolation')[1]
    except Exception as e:                                                # noqa: BLE001
        _c33n = [f'ERR {type(e).__name__}: {e}']
    chk('㉝b 묶음 se_isolation 을 안 부르면 열이 없다 (옛 인계표 바이트 불변 — ㉙f2 가 실데이터로 지킨다) · ① 경로 고립은 그대로',
        'se_isolated_pct' not in _c33n and 'am_ionic_isolated_pct' in _c33n)
    _neg7('㉝c se_isolation 묶음을 percolation 없이 부르면 거부 (top_reachable_pct 를 싣지 않는 표에서 유도하지 않는다)',
          lambda: _b33(groups='contact,se_isolation'), 'S0')
    _w33 = _wa10()
    _w33['rows']['q1']['se_isolated_pct'] = '59.0'
    _neg7('㉝d ★ S1 — 웹앱이 같은 이름 (se_isolated_pct) 을 내면 100 − top_reachable_pct 와 같아야 (59.0 ≠ 60)', lambda: _b33(w=_w33), 'S1')
    try:
        _se_iso_gates('qx', {'top_reachable_pct': '30.0', 'percolation_pct': '37.0', 'se_isolated_pct': repr(70.0)})
        _s2 = ''
    except FillRefusal as e:
        _s2 = str(e)
    except Exception as e:                                                # noqa: BLE001
        _s2 = f'ERR {type(e).__name__}: {e}'
    chk('㉝d2 ★ S2 — se_isolated_pct > 100 − percolation_pct (관통 SE 가 위 띠에 안 닿는다는 뜻) 이면 거부 (② P2 와 같은 사실의 이중 안전장치)'
        + ('' if ('S2' in _s2 and not _s2.startswith('ERR')) else f' — {_s2[:160]}'),
        'S2' in _s2 and not _s2.startswith('ERR'))
    _dm33 = {d['column']: d for d in column_dictionary(_c33, webapp=_wa10())} if _c33 else {}
    _g33 = lambda c, k: (_dm33.get(c) or {}).get(k, '')                   # noqa: E731
    chk('㉝e ★ 열 사전 — 고립 전해질 = 100 − top_reachable_pct · AM 경로 고립과 같은 규칙 · 외톨이 SE 한정 · 비관통에 몰림 → 관통 분류 먼저 · 유도 (v1.3)',
        _g33('se_isolated_pct', 'source') == 'webapp_derived' and 'v1.3' in _g33('se_isolated_pct', 'verdict')
        and all(w in _g33('se_isolated_pct', 'meaning') for w in ('고립 전해질', '100 − top_reachable_pct', 'am_ionic_isolated_pct', '외톨이',
                                                                  '비관통', '관통 여부를 먼저'))
        and _g33('se_isolated_pct', 'caveat') == CAVEAT_PERC)
    try:
        _caps33 = (WA_SE_ISO_GROUP in WA_ALL_GROUPS and WA_SE_ISO_GROUP in WA_DERIVED_GROUPS
                   and all(WA_SE_ISO_GROUP not in v_ for v_ in WA_STAGE_GROUPS.values())
                   and WA_STAGE_GROUPS['network'] == WA_GROUPS + (WA_TAU_GROUP,))
        _o33s = {}
        for _sa33 in ('contact', 'coverage', 'network'):                 # 어느 정지점 배치든 percolation 과 함께면 낸다 (단계 역량 표 밖 · 유도 묶음)
            _w33s = _wa10()
            _w33s['stop_after'] = _sa33
            _g33s = 'contact,percolation,se_isolation' + (',tau' if _sa33 == 'network' else '')
            try:
                build_handover(_dq7, _hq10(), webapp=_w33s, webapp_groups=_g33s)
                _o33s[_sa33] = 'ok'
            except FillRefusal as e:
                _o33s[_sa33] = str(e)[:90]
        _caps33 = _caps33 and _o33s.get('contact') == 'ok' and _o33s.get('coverage') == 'ok' and 'τ' in str(_o33s.get('network'))
    except NameError:
        _caps33, _o33s = False, {}
    chk('㉝f 묶음 se_isolation = 유도 묶음 (단계 역량 표 WA_STAGE_GROUPS 밖 — 실행기 run_network_194_parallel ㉕ 의 network 짝 그대로) · contact · coverage '
        '정지 배치에서 percolation 과 함께면 받는다 · network 는 τ 원천 관문까지 간다 (묶음 거부가 아니다)'
        + ('' if _caps33 else f' — {_o33s}'), _caps33)
    _tm33 = {m_: (tau_net_define(f'tau2_ion_{m_}') or ('', ''))[0] for m_ in TAU_NET_MODES}
    _sm33 = {m_: (tau_net_define(f'tau_ion_{m_}') or ('', ''))[0] for m_ in TAU_NET_MODES}
    _fm33 = {m_: (tau_net_define(f'f_ion_{m_}') or ('', ''))[0] for m_ in TAU_NET_MODES}
    chk('㉝g ★ τ 표시 이름 — tau2 = 수송 tortuosity (제곱근 아님 · tortuosity factor 병기 · 키 tau2 그대로) · √ 값 (tau) 은 그 이름이 아니다 (√T) · '
        'f_ion_hertz = ML 1차 타깃 안내 (#2) · physics · H12 의 f 는 1차 타깃이 아니다',
        all('수송 tortuosity' in _tm33[m_] and '제곱근 아님' in _tm33[m_] and 'tortuosity factor' in _tm33[m_] for m_ in TAU_NET_MODES)
        and all('√T' in _sm33[m_] and '수송 tortuosity factor' not in _sm33[m_] for m_ in TAU_NET_MODES)
        and 'ML 1차 타깃' in _fm33['hertz'] and 'ML 1차 타깃' not in _fm33['physics'] and 'ML 1차 타깃' not in _fm33['hertz_h12'])
    print(f'\nlhs_design_dataset selftest: {ok}/{ok + len(fail)} PASS'
          + (f'   FAILED: {fail}' if fail else ''))
    return 1 if fail else 0


if __name__ == '__main__':
    ap = argparse.ArgumentParser()
    ap.add_argument('--n', type=int, default=60, help='내부(바이모달) 블록 점 수')
    ap.add_argument('--n-end', type=int, default=10, help='단일모달 끝점 블록 각각의 점 수')
    ap.add_argument('--seed', type=int, default=0)
    ap.add_argument('--restarts', type=int, default=400, help='maximin 무작위 재시작')
    ap.add_argument('--continuous', action='store_true',
                    help='정수 격자를 끄고 연속 LHS (기본은 **정수 격자** — 2026-08-18 지시)')
    ap.add_argument('--as-radius', action='store_true',
                    help='지시 범위를 **반경**으로 해석 (기본은 직경 — docstring 근거)')
    ap.add_argument('--out', default='')
    ap.add_argument('--audit-descriptors', default='', metavar='CSV',
                    help='설계 CSV 의 **측정 열 채움 상태**를 보고한다 (`LHS-02`).  '
                         '결측이 있으면 rc=1 — 파이프라인이 그것을 0 으로 읽기 전에 선다.')
    ap.add_argument('--fill-descriptors', default='', metavar='DIR',
                    help='수확 JSON 디렉터리를 설계 CSV 에 **합친다** (`LHS-02`). '
                         '전단사가 아니거나 DESC-07 항등식이 깨지면 거부한다.')
    ap.add_argument('--design', default='', metavar='CSV',
                    help='--fill-descriptors 의 대상 설계 CSV (기본 = 동결 정본)')
    ap.add_argument('--fill-out', default='', metavar='CSV',
                    help='--fill-descriptors 산출 경로 (기본 = 제자리)')
    ap.add_argument('--export-handover', default='', metavar='CSV',
                    help='설계 CSV + 수확 JSON → **인계표**를 쓴다 (ML 담당에게 넘길 표).  '
                         '⛔ 옛 규약 τ (tortuosity_dijkstra_SE) 값 열은 넣지 않는다 (`LHS-08` 열림) — 대신 왜 없는지를 진단 열로 '
                         '넘긴다 (망 τ tau2 · f 는 묶음 tau · --tau-results — v1.2).  status != OK 는 빈칸이고 0 이 아니다.')
    ap.add_argument('--harvest', default='', metavar='DIR',
                    help='--export-handover 가 읽을 수확 JSON 디렉터리 '
                         '(기본 = DESCRIPTOR_FILL_EXPECTED["source"] 의 경로)')
    ap.add_argument('--union', default=None, metavar='TSV',
                    help='(--export-handover) J19 union TSV (scripts/lhs_union_webapp.py 산출) — 겹침 보정 porosity · 질량 보존 두께 · '
                         f'SE-rich 표지를 **병기**한다 (기본 {DEFAULT_UNION_TSV} · 빈 문자열이면 옛 인계표).  짝이 안 맞으면 거부')
    ap.add_argument('--webapp', default='', metavar='DIR',
                    help='(--export-handover) J20 웹앱 배치 산출 (scripts/lhs_webapp_batch.py 의 --out-dir) — 전수 판정 ✅ 열을 싣는다.  '
                         '설계행 전부를 배치가 시도했어야 하고 웹앱 porosity = 수확 porosity (같은 프레임) 여야 한다')
    ap.add_argument('--webapp-groups', default=None, metavar='G[,G]',
                    help='(--export-handover --webapp) 웹앱 열을 이 묶음만 싣는다 (쉼표로 여럿) — contact = ① 접촉 위상 · percolation = ② '
                         '퍼콜레이션 · f1 = ⑤ F1 근접쌍 · fracture = ⑥ Auerbach 힘 기반 · area = ⑦ 접촉 면적 (전부 접촉 분석 단계 산출 · J20-s) · '
                         'tau = 망 τ (v1.2 — 이온 망 인계 열 f · tau2 · tau · 상태 · 메타 · tau_flux · network 배치 + --tau-results 필요) · '
                         'se_isolation = 고립 전해질 se_isolated_pct = 100 − top_reachable_pct (v1.3 유도 묶음 · percolation 과 함께만 · 명시 opt-in).  '
                         '`lhs_webapp_batch --stop-after contact|coverage|network` 산출은 이것 없이는 거부된다 (셋 다 다섯 묶음을 다 낸다 · RGL-03)')
    ap.add_argument('--tau-results', default='', metavar='DIR',
                    help='(--export-handover --webapp, 묶음 tau) 망 τ 원천 = network 정지 배치의 케이스 폴더 묶음 (`lhs_webapp_batch --work` 아래 '
                         'results/ — 케이스마다 network_conductivity_dual.json · full_metrics.json · network_provenance.json · atoms/contacts.csv).  '
                         '배치 done · partial 케이스마다 출처 관문 P0–P4 (기록 · run id = 배치 status.json · 입력 digest · metrics_flat 과 같은 세대 · '
                         '망 정지 계약 재검사 (전 사본 · 투영 · σ₀ 짝 · 띠 규칙 — 10-05 RGLR3-02) · 활성 세대 · 읽기 안정) 뒤 tau_flux.case_row 로 싣는다 · '
                         '한 케이스라도 실패하면 거부 · 출처 부록 <인계표>_tau_provenance.tsv (same_generation_checks · same_generation_basis — 지금 파일끼리 · '
                         '게시 시점 해시 없음)')
    ap.add_argument('--tau-batch-manifest', default='', metavar='JSON',
                    help='(--tau-results) 배치 manifest — 선언한 기대 망 세대 (expected_network_generation: g2 · inferred_legacy — 새 194 실행 봉인이 쓴다) 를 '
                         '케이스마다 레코드 세대와 교차 대조 (다르면 · 선언이 없거나 모르는 값이면 거부 · G2RR-01).  주지 않으면 이 대조만 하지 않는다 '
                         '(194 v1.2 런처 manifest 에는 선언이 없다)')
    ap.add_argument('--pressure-record', default='', metavar='TSV',
                    help='(--export-handover) 완료 압력 기록 (scripts/lhs_pressure_record.py 산출 · DESC-06) — 설계 케이스마다 압밀 루프가 목표 (300 MPa) 에 '
                         '닿아 빠져나왔는가 · 덱 sha = 수확 raw.deck · 아니면 인계표를 만들지 않는다 · press_* 열을 표 끝에 싣는다')
    ap.add_argument('--pressure-unverified', action='store_true',
                    help='(--export-handover) 완료 압력 기록 없이 만든다는 **명시 승인** — 출력에 "완료 압력 미검사" 경고 · press_* 열 없음 (DESC-06 — 둘 다 없으면 거부)')
    ap.add_argument('--census', default='', metavar='TSV',
                    help=f'(--webapp) 전수 판정 census (기본 {DEFAULT_CENSUS_TSV})')
    ap.add_argument('--selftest', action='store_true')
    a = ap.parse_args()
    if a.selftest:
        raise SystemExit(_selftest())
    if a.audit_descriptors:
        _p = pathlib.Path(a.audit_descriptors)
        _rows = list(csv.DictReader(_p.open(encoding='utf-8-sig')))
        _fill = descriptor_fill(_rows)
        print(f'{_p}   {len(_rows)} 행')
        for _c in DESCRIPTORS:
            _n = _fill[_c]
            print(f'  {"✓" if _n == len(_rows) else "⚠"} {_c:34s} {_n:>4} / {len(_rows)} 채움')
        _miss = [c for c in DESCRIPTORS if _fill[c] < len(_rows)]
        if _miss:
            print(f'\n⛔ 측정 열 {len(_miss)}/{len(DESCRIPTORS)} 이 불완전하다 — '
                  f'**결측을 0 으로 채우지 말 것** (원장 LHS-02 · GAP2-05).')
            _why = DESCRIPTOR_FILL_EXPECTED.get('why_partial', {})
            for _c2 in _miss:
                if _c2 in _why:
                    print(f'   · {_c2}: {_why[_c2]}')
            #  ⚠ 사유가 **등록되지 않은** 결측만 "수확기를 돌려라" 가 답이다.  없는 상
            #    (`N_A_PHASE_ABSENT`)은 아무리 돌려도 안 채워진다 — 그 줄을 무차별로
            #    찍으면 "돌리면 채워진다" 는 **틀린 처방**이 된다.
            _un = [c for c in _miss if c not in _why]
            if _un:
                print(f'   채우려면 ({", ".join(_un)}): '
                      f'{DESCRIPTOR_FILL_EXPECTED["harvester"]}')
            else:
                print('   ⇒ 남은 결측은 **전부 사유가 등록돼 있다**.  숫자로 채우는 것이 '
                      '답이 아니다 — 옆의 `<열>_status` 를 읽을 것.')
        else:
            print('\n✓ 측정 열이 전부 찼다.')
        raise SystemExit(1 if _miss else 0)

    if a.export_handover:
        #  ★ DESC-06 — 완료 압력: 기록 (--pressure-record) 또는 미검사 명시 승인 (--pressure-unverified) 중 정확히 하나 (조용히 넘기지 않는다)
        if bool(a.pressure_record) == bool(a.pressure_unverified):
            print('⛔ --export-handover 에는 --pressure-record <TSV> (scripts/lhs_pressure_record.py — 압밀 루프 목표 도달 기록) 또는 '
                  '--pressure-unverified (기록 없이 만든다는 명시 승인) 중 정확히 하나가 필요하다 (DESC-06 — 완료 압력을 조용히 미검사로 넘기지 않는다)',
                  file=sys.stderr)
            raise SystemExit(2)
        _root = pathlib.Path(__file__).resolve().parent.parent
        _dp = pathlib.Path(a.design or DESCRIPTOR_FILL_EXPECTED['path'])
        if not _dp.is_absolute():
            _dp = _root / _dp
        _hd = pathlib.Path(a.harvest or (_root / DEFAULT_HARVEST_DIR))
        with _dp.open(encoding='utf-8-sig') as _fh:
            _rows = list(csv.DictReader(_fh))
        _harv = load_harvest(_hd)
        _un = DEFAULT_UNION_TSV if a.union is None else a.union
        _uv = None
        if _un:
            _upth = pathlib.Path(_un)
            _uv = load_union(_upth if _upth.is_absolute() else _root / _upth)
        _wv = None
        if a.webapp:
            _wp = pathlib.Path(a.webapp)
            _wv = load_webapp(_wp if _wp.is_absolute() else _root / _wp, a.census or None)
        _tv = None
        if a.tau_batch_manifest and not a.tau_results:
            print('⛔ --tau-batch-manifest 는 --tau-results (망 τ 원천) 와 함께만 쓴다 — 기대 세대를 대조할 원천이 없다 (G2RR-01)', file=sys.stderr)
            raise SystemExit(2)
        if a.tau_results:                               # v1.2 망 τ — 원천을 배치 기록으로 대조한 뒤 tau_flux 로 (관문 P0–P4)
            _tp = pathlib.Path(a.tau_results).expanduser()
            _te = None
            if a.tau_batch_manifest:                    # ★ G2RR-01 — 배치 manifest 의 기대 세대 (케이스마다 레코드 세대와 교차 대조)
                _mp = pathlib.Path(a.tau_batch_manifest).expanduser()
                _te = tau_manifest_expected_generation(_mp if _mp.is_absolute() else _root / _mp)
            _tv = load_tau_results(_tp if _tp.is_absolute() else _root / _tp, _wv, expected_generation=_te)
        _pv = None
        if a.pressure_record:                           # DESC-06 — 완료 압력 기록 (관문)
            _pp_ = pathlib.Path(a.pressure_record).expanduser()
            _pv = load_pressure_record(_pp_ if _pp_.is_absolute() else _root / _pp_)
        _out, _cols, _rep = build_handover(_rows, _harv, union=_uv, webapp=_wv, webapp_groups=a.webapp_groups, tau=_tv, pressure=_pv)
        _op = pathlib.Path(a.export_handover)
        if not _op.is_absolute():
            _op = _root / _op
        with _op.open('w', encoding='utf-8', newline='') as _fh:
            _w = csv.DictWriter(_fh, _cols, lineterminator='\n')
            _w.writeheader()
            for _r in _out:
                _w.writerow(_r)
        #  열 사전 — 받는 쪽이 열마다 출처 · 판정 · 뜻 · 주의를 읽는다 (J20)
        _dp2 = _op.with_name(_op.stem + '_columns.tsv')
        with _dp2.open('w', encoding='utf-8', newline='') as _fh:
            _w = csv.DictWriter(_fh, ['column', 'source', 'verdict', 'meaning', 'caveat'], delimiter='\t', lineterminator='\n')
            _w.writeheader()
            for _d in column_dictionary(_cols, webapp=_wv, design_source=_tau_src_label(_dp)):
                _w.writerow(_d)
        #  제외 노트 — 명시 제외 열 (LW frame_unverified · LHS-32 · δ 판 · 상 쌍별 · physics 면적) · 보류 열의 사유 (열 사전은 표의 열만)
        _dp3 = _op.with_name(_op.stem + '_excluded.tsv')
        write_exclusion_notes(_dp3)
        print(f'→ {_op}   {_rep["n"]}행 × {len(_cols)}열   (열 사전 {_dp2.name} · 제외 노트 {_dp3.name})')
        if _pv is not None:
            print(f'   완료 압력 (DESC-06) — 기록 {a.pressure_record} · 목표 {PRESSURE_MPA} MPa 도달 확인 {_rep["pressure_checked"]} 행 (press_* 열)')
        else:
            print('   ⚠ 완료 압력 미검사 (DESC-06 · --pressure-unverified 명시 승인) — 이 인계표는 300 MPa 도달을 기계로 확인하지 않았다 '
                  '(scripts/lhs_pressure_record.py 기록으로 다시 만들 것)')
        if _tv is not None:                             # v1.2 망 τ 출처 부록 — τ 칸이 어느 망 세대 · 어느 파일에서 왔는가
            _dp4 = _op.with_name(_op.stem + '_tau_provenance.tsv')
            write_tau_provenance(_dp4, _tv)
            print(f'   v1.2 망 τ (tau_flux {_rep["tau_flux_sha256"][:12]}…) — 원천 {_rep["tau_source"]} · 출처 관문 P0–P4 {_rep["tau_checked"]} 행 · '
                  f'빈칸 행 (배치 done · partial 아님) {_rep["tau_blank_rows"]} · 상태 {dict(sorted(_rep["tau_status"].items()))} · 출처 부록 {_dp4.name}')
            print('   ⚠ 망 τ = ML 기술자 전용 · G6 — 두 모드 모두 물리 타깃 (실험 절대 대조) HOLD · tau = √tau2 는 COMSOL 입력 아님 (열 사전)')
            print(f'   ⚠ 출처 관문 = 배치 기록과 지금 파일끼리 ({TAU_SAME_GEN_BASIS}) — 게시 시점 해시가 없어 모든 사본을 함께 일관되게 바꾼 편집은 못 잡는다 '
                  '(RGLR3-02 · 출처 부록 same_generation_checks)')
            print('   세대 도장 대조 (G2RR-01) — 케이스마다 도장 네 세대 값 = 레코드에서 유도한 기대값 (g2) · 확인된 역사 도장 스키마 (inferred_legacy) · '
                  + (f'배치 manifest 기대 세대 {_tv["expected_generation"]!r} 교차 대조' if _tv.get('expected_generation')
                     else '배치 manifest 기대 세대 대조 안 함 (--tau-batch-manifest 없음)'))
        if 'tau_wall_status' in _rep:
            print(f'   J20 벽 τ: {dict(_rep["tau_wall_status"])}')
        if _wv is not None:
            print(f'   J20 웹앱 ✅ {_rep["wa_n_cols"]} 열 · 행 상태 {dict(_rep["wa_status_counts"])} · '
                  f'같은 프레임 |Δporosity| 최대 {_rep["wa_porosity_absmax"]:.3e} %p · 이름 충돌 (수확 열 정본) {_rep["wa_collisions"]}')
            print(f'   J20-g 같이 확인한 웹앱 열만 ({len(WA_REVIEWED)} 패턴) — 뺀 census ✅ 열 {_rep["wa_unreviewed_dropped"]} · '
                  f'J20-k (B) mono 웹앱 상별 칸: 설계 상 칸 채움 {_rep["wa_mono_design_filled"]} 셀 · 이름 옮김 {_rep["wa_mono_renamed_cases"]} 건 · '
                  f'없는 상 빈칸 {_rep["wa_mono_absent_blanked"]} 셀 · J20-h 접촉 0 쌍 = 0 채움 {_rep["wa_pair_zero_filled"]} · '
                  f'J20-i se_se_cn = 2·area_SE_SE_n/N_SE 확인 {_rep["wa_cn_identity_checked"]} 행 · '
                  f'J20-j AM–AM 접촉 수 = 쌍 합 · am_am_cn = 2·n/N_AM 확인 {_rep["wa_am_identity_checked"]} 행 · '
                  f'7c AM–SE CN · 고립 관문 G1–G7 확인 {_rep["wa_amse_identity_checked"]} 행 · '
                  f'② 퍼콜레이션 관문 P1–P3 확인 {_rep["wa_perc_checked"]} 행')
        if 'tau_wall_checked' in _rep:
            print(f'   벽 τ 관문 T1–T2 확인 {_rep["tau_wall_checked"]} 행 · T3 (↔ 퍼콜레이션) {_rep["tau_perc_crosschecked"]} 행')
        if _rep.get('wa_ionic_checked'):
            print(f'   v1.1 ①② 이온 활성 · 경로 기준 고립 관문 D1–D5 확인 {_rep["wa_ionic_checked"]} 행')
        if any(_rep.get(k) for k in ('wa_f1_checked', 'wa_frac_checked', 'wa_area_checked')):
            print(f'   ⑤⑥⑦ 관문 (원천 근거 → 유한 → 형/범위 → 식 · RGL-05) — ⑤F1 {_rep["wa_f1_checked"]} · ⑥R1–R3 {_rep["wa_frac_checked"]} · '
                  f'⑦A1–A5 {_rep["wa_area_checked"]} 행 · 최종 레코드 재검 {_rep["wa_s567_final_checked"]} 행 · 접촉 0 평균 비움 '
                  f'{_rep["wa_area_mean_blanked"]} 칸')
        if 'se_cluster_checked' in _rep:
            print(f'   v1.1 ③ 가장 큰 SE 덩어리 관문 C1–C3 확인 {_rep["se_cluster_checked"]} 행')
        print(f'   J20-k (B) mono {_rep["mono_rows"]} 행 — 수확기 상별 칸 (coverage · n_AM_*_measured · cov_*_n_valid · 벽 접촉) 설계 상 칸 채움 '
              f'{_rep["mono_harvest_filled"]} 셀 (설계에 없는 상은 빈칸)')
        print(f'   빈칸 사유: {dict(_rep["blank_by_status"])}')
        for _k, _v in _rep['held_back'].items():
            print(f'   ⛔ 보류 열 `{_k}` — {_v}')
        print(f'   ⛔ 명시 제외 (웹앱 열 · 묶음 · 검토와 무관하게 먼저) — LW (④b) `stress_*_lw` · `stress_lw_*` = '
              f'{WA_LW_FRAME_UNVERIFIED.split(" — ")[0]} (사유 전문 = {_dp3.name})')
        if _uv is not None:
            print(f'   J19 union 병기: {_un} · 설계 밖 union 행 {_rep.get("union_extra")} (인계표에 안 넣음) · '
                  f'SE-rich (≥ {SE_RICH_MIN}) {sum(r["se_rich"] == "True" for r in _out)} 행 · 구 부피 합 열은 그대로')
        raise SystemExit(0)

    if a.fill_descriptors:
        _root = pathlib.Path(__file__).resolve().parent.parent
        _dp = pathlib.Path(a.design or DESCRIPTOR_FILL_EXPECTED['path'])
        if not _dp.is_absolute():
            _dp = _root / _dp
        with _dp.open(encoding='utf-8-sig') as _fh:
            _rd = csv.DictReader(_fh)
            _base_cols = list(_rd.fieldnames or [])
            _rows = list(_rd)
        _harv = load_harvest(a.fill_descriptors)
        _rows, _rep = fill_descriptors(_rows, _harv)
        #  `<열>` 바로 뒤에 `<열>_status` 를 끼운다 (값과 사유가 떨어지면 안 읽힌다)
        _cols = []
        for _c in _base_cols:
            _cols.append(_c)
            if _c in DESCRIPTORS:
                _cols.append(_c + '_status')
        for _c in DESCRIPTORS:                       # 원래 CSV 에 없던 열이면 뒤에 붙인다
            if _c not in _cols:
                _cols += [_c, _c + '_status']
        _op = pathlib.Path(a.fill_out) if a.fill_out else _dp
        #  ⚠ `csv` 의 기본 줄끝은 CRLF 다 — 그냥 쓰면 LF 파일 전체가 바뀌어 diff 가
        #    131/131 이 되고 실제 변경이 묻힌다 (한 번 그렇게 했다).  리포 관행은 LF.
        with _op.open('w', newline='', encoding='utf-8') as _fh:
            _w = csv.DictWriter(_fh, _cols, lineterminator='\n')
            _w.writeheader()
            for _r in _rows:
                _w.writerow({_c: _r.get(_c, '') for _c in _cols})
        _mp = _op.with_name(_op.stem + '_descriptor_manifest.json')
        _mp.write_text(json.dumps({
            'design_csv': str(_op.relative_to(_root)) if _op.is_relative_to(_root) else str(_op),
            'harvest_dir': str(a.fill_descriptors), 'n_rows': _rep['n_rows'],
            'filled': _rep['filled'], 'status_tally': _rep['status_tally'],
            'derived_not_independent_targets': _rep['derived'],
            'desc07_identity_max_err': _rep['desc07_max_err'],
            'contract': ('DESC-07 유도열 표시 · DESC-08 291 코퍼스와 병합 안 함 · '
                         'DESC-09 전단사 아니면 거부 · GAP2-05 status≠OK 면 숫자 안 씀'),
            'caveats': [
                ('tortuosity_dijkstra_SE_status 는 **잠정**이다 (원장 `LHS-08`, 열림). '
                 '`NOT_PERCOLATING` 은 아직 결론이 아니라 의심 신호이고, 전극 밴드 규약이 '
                 '재측정·판단 대기다.  그 status 를 "미관통이 확인됐다" 로 읽지 말 것.'),
                ('`DESC-07`: ' + ' · '.join(DERIVED_DESCRIPTORS) + ' 는 나머지에서 **유도**된다 '
                 '(이 병합에서 항등식을 다시 쟀다).  일곱을 독립 회귀 타깃으로 세지 말 것.'),
                ('`DESC-08`: 이 표를 291 행 `design_performance` 코퍼스와 **그대로 합치지 말 것** '
                 '— 그쪽은 d_am=0 40건과 MPM/DEM 상태 혼합이 남아 있다.'),
                ('빈 칸은 결측이고 **0 이 아니다**.  읽기 전에 `require_descriptors` 를 부를 것.'),
            ],
            'per_case': _rep['sources'],
        }, ensure_ascii=False, indent=1) + '\n', encoding='utf-8')
        print(f'{_op}   {_rep["n_rows"]} 행')
        for _c in DESCRIPTORS:
            _n = _rep['filled'][_c]
            _mark = '✓' if _n == _rep['n_rows'] else '·'
            _tl = ' · '.join(f'{k} {v}' for k, v in sorted(_rep['status_tally'][_c].items()))
            _der = '  [DESC-07 유도]' if _c in DERIVED_DESCRIPTORS else ''
            print(f'  {_mark} {_c:34s} {_n:>4}/{_rep["n_rows"]}   {_tl}{_der}')
        _e = _rep['desc07_max_err']
        print(f'\nDESC-07 항등식 재검증: ① porosity 최대오차 {_e["porosity"]:.3e} · '
              f'② C_total 가중평균 최대오차 {_e["coverage_total"]:.3e} '
              f'({_e["n_coverage_checked"]} 건; mono 는 정의상 제외)')
        print(f'→ 프로비넌스 {_mp}')
        print('⚠ 채워지지 않은 칸은 **빈 칸 + 사유 열**이다.  0 으로 읽지 말 것 '
              '(원장 LHS-02 · GAP2-05).')
        raise SystemExit(0)

    rows = build(a.n, a.n_end, a.seed, a.restarts, grid=not a.continuous)
    if a.as_radius:                                   # 범위를 반경으로 읽으면 직경이 2배
        for r in rows:
            for d, rr in (('d_am_p_um', 'r_AM_P_um'), ('d_am_s_um', 'r_AM_S_um'),
                          ('d_se_um', 'r_SE_um'), ('d_am_max_um', None)):
                if rr:
                    r[rr] = r[d]
                r[d] = r[d] * 2.0
    cols = (['case_id', 'block', 'd_am_p_um', 'd_am_s_um', 'ps_frac', 'ps_label', 'd_se_um',
             'am_pct', 'rve_um', 'loading_mAh_cm2', 'pressure_MPa', 'e_se_gpa',
             'thickness_est_um', 'phi_am_est', 'phi_se_est', 'se_percolation_est_meanfield',
             'd_am_max_um', 'sv_inv_um', 'r_AM_P_um', 'r_AM_S_um', 'r_SE_um',
             'size_ratio_P_over_S', 'size_ratio_AM_over_SE',
             'n_am_p_est', 'n_am_s_est', 'n_se_est', 'n_total_est',
             'rve_min_um', 'rve_recommended_um',
             'rve_over_d_am_max', 'thick_over_d_am_max', 'finite_size_flag',
             'se_perc_est_flag'] + DESCRIPTORS)
    for r in rows:
        for d in DESCRIPTORS:
            r.setdefault(d, '')                       # DEM 이 채울 빈 칸

    def fmt(v):
        return '' if v == '' else ('' if isinstance(v, float) and np.isnan(v)
                                   else (f'{v:.4f}' if isinstance(v, float) else v))
    if a.out:
        with open(a.out, 'w', newline='', encoding='utf-8') as f:
            w = csv.DictWriter(f, cols)
            w.writeheader()
            for r in rows:
                w.writerow({c: fmt(r.get(c, '')) for c in cols})
        print(f'→ {a.out}   ({len(rows)} 행)')

    print(f"\n{'case_id':13s} {'block':10s} {'d_AM_P':>7} {'d_AM_S':>7} {'P:S':>6} "
          f"{'d_SE':>6} {'AM%':>6} {'P/S':>6}")
    for r in rows[:8] + [{'case_id': '…'}] + rows[-4:]:
        if r.get('case_id') == '…':
            print('   …')
            continue
        f_ = lambda v: '   —  ' if (isinstance(v, float) and np.isnan(v)) else f'{v:6.2f}'
        print(f"{r['case_id']:13s} {r['block']:10s} {f_(r['d_am_p_um']):>7} "
              f"{f_(r['d_am_s_um']):>7} {r['ps_frac']:>6.2f} {r['d_se_um']:>6.2f} "
              f"{r['am_pct']:>6.1f} {f_(r['size_ratio_P_over_S']):>6}")
    print('\n설계 진단 (내부 블록):', json.dumps(diagnostics(rows), ensure_ascii=False))
    fl = [r for r in rows if r['finite_size_flag']]
    print(f"\n고정 상수: RVE {FIXED['rve_um']:.0f}×{FIXED['rve_um']:.0f} µm · 면용량 "
          f"{FIXED['loading_mAh_cm2']:.1f} mAh/cm² → 두께 ≈ {rows[0]['thickness_est_um']:.0f} µm "
          f"(코퍼스 291건 회귀 {THICK_PER_LOADING_UM:.2f} µm per mAh/cm²)")
    print(f"  측면 RVE/d_AM_max : {min(r['rve_over_d_am_max'] for r in rows):.2f} – "
          f"{max(r['rve_over_d_am_max'] for r in rows):.2f}   "
          f"(코퍼스 최빈 rve50/d12 = 4.17 · rve40/d12 = 3.33)")
    print(f"  두께 /d_AM_max    : {min(r['thick_over_d_am_max'] for r in rows):.2f} – "
          f"{max(r['thick_over_d_am_max'] for r in rows):.2f}")
    import collections as _c
    cnt = _c.Counter(t for r in rows for t in (r['finite_size_flag'].split('+') if
                                               r['finite_size_flag'] else []))
    print(f"\n  ⚠ 유한크기 플래그 {len(fl)}/{len(rows)} 행 — 내역:")
    _why = {'lateral': '측면 상자 < 3.3 입자',
            'thin': '두께 < 3 입자',
            'n_am_p_low': 'N_AM_P 10–30 (coverage_AM_P 표집오차 큼)',
            'n_am_p_CRIT': '★ N_AM_P < 10 — coverage_AM_P·명목 ps 가 **실현 불가**'}
    for k, v in cnt.most_common():
        print(f"      {k:14s} {v:>3} 행   {_why.get(k, '')}")
    #  ★ SE 퍼콜 추정은 **자기 열**에서 보고한다 (`LHS-01`) — 기하 플래그와 섞지 않는다.
    sc = _c.Counter(r['se_perc_est_flag'] for r in rows if r['se_perc_est_flag'])
    _m = LHS_PERC_MEASURED
    print(f"\n  ⚠ SE 퍼콜 **추정** 플래그 (`se_perc_est_flag`, 기하와 분리) — "
          f"{sum(sc.values())}/{len(rows)} 행:")
    _swhy = {'se_marginal': f'φ_SE 가 φc 바로 위 ({PHI_C_SE}–0.20)',
             'se_BELOW_phic': f'φ_SE < {PHI_C_SE} — 평균장 문턱 아래 (am_pct > 88.8 wt%)'}
    for k, v in sc.most_common():
        print(f"      {k:14s} {v:>3} 행   {_swhy.get(k, '')}")
    print(f"      ★ 실측 운용특성 (n={_m['n_measured']}, {_m['channel']} 채널): "
          f"OK {_m['OK']['n']}행 중 막힘 {_m['OK']['blocked']} · "
          f"BELOW_phic {_m['BELOW_phic']['n']}행 중 막힘 {_m['BELOW_phic']['blocked']} "
          f"⇒ 재현율 {_m['recall_pct']} % · 정밀도 {_m['precision_pct']} %")
    print(f"      ⛔ **선별기이지 필터가 아니다** — `BELOW_phic` 를 버리면 실제로 뚫리는 "
          f"{_m['BELOW_phic']['n'] - _m['BELOW_phic']['blocked']}건을 같이 버린다.  "
          f"출처: {_m['source']}")
    _np = [r['n_am_p_est'] for r in rows if r['n_am_p_est'] == r['n_am_p_est']]
    print(f"  입자 수 추정: N_AM_P 최소 {min(_np):.1f} · 중앙 {sorted(_np)[len(_np)//2]:.0f} | "
          f"총 입자 최대 {max(r['n_total_est'] for r in rows):,.0f}")
    over = [r for r in rows if r['n_total_est'] > N_TOTAL_CAP]
    print(f"  ★ 입자수 상한 {N_TOTAL_CAP:,} — 초과 행 **{len(over)}** 개 "
          f"(최대 {max(r['n_total_est'] for r in rows):,.0f})")
    _big = [r for r in rows if r['rve_recommended_um'] > FIXED['rve_um'] + 1e-9]
    if _big:
        print(f"  ★ N_AM_P ≥ {N_AM_P_MIN} 를 만족하려면 {len(_big)} 행이 더 큰 상자를 요구한다 "
              f"(권장 rve 최대 {max(r['rve_recommended_um'] for r in _big):.0f} µm).  "
              f"`rve_recommended_um` 열 참조 — **결정은 사람이 한다** (예산 문제다).")
    print("  ⚠ 플래그는 **거부가 아니라 라벨**이다.  학습 시 공변량으로 남기면 "
          "유한크기 효과를 흡수한다 — 단 `n_am_p_CRIT` 와 `se_BELOW_phic` 는 "
          "**타깃 자체가 안 나올 수 있는** 행이라 성격이 다르다.")
    print("  ★ 그리고 그 둘은 **성격이 서로 다르다**: `n_am_p_CRIT` 는 기하로 확정이지만 "
          f"`se_BELOW_phic` 는 추정이고 실측에서 {_m['BELOW_phic']['n']}건 중 "
          f"{_m['BELOW_phic']['n'] - _m['BELOW_phic']['blocked']}건이 **실제로는 뚫렸다**.")
    print('\n⚠ 디스크립터 열은 **비어 있다** — DEM 이 채운다: ' + ', '.join(DESCRIPTORS))
    sys.stdout.flush()

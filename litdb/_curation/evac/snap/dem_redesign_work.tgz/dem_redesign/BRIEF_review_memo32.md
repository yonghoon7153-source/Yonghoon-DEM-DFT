# 지시서 — [DEM 우선 (수영)] 메모 3.2 내부 반박 리뷰 (독립 조수 · Codex 아님 · 11-12)

## 0. 할 일

`…/scratchpad/dem_redesign/memo_v3_2.md` (방향 메모 3.2 초안) 를 **반박하는 눈으로** 읽고 결함을 찾는다. 고친 사람의 설명 (changelog · drd_table) 은 **맨 마지막에** 읽는다 — 먼저 메모만 읽고 판단한 뒤, 그 둘은 "주장한 처분이 메모 본문에 실제로 들어갔나" 대조에만 쓴다.

이 리뷰는 1저자 11-10 운영 결정 (Codex 토큰 소진 → 반박 리뷰 자리는 내부 반박 리뷰 · 기록은 "내부 반박 리뷰 (Codex 아님)") 에 따른 것이다. 판정이 아니라 지적 목록이다.

## 1. 읽을 것 (리포 본 트리 `/home/user/Yonghoon-DEM-DFT` 는 읽기만 — 게이트가 도는 중 · git 으로 상태를 바꾸는 명령 금지)

- Codex 판정 (11-10): `docs/reviews/codex_review_dem_redesign_direction_20261110.md` — DRD-01 … DRD-13 (P1 둘 · P2 열 · P3 하나) 의 반례와 닫는 조건.
- 판정 처분 계획: `docs/reviews/dem_redesign_direction_20261109/verdict_disposition_20261110.md`.
- 앞 판: `docs/reviews/dem_redesign_direction_20261109/memo_v3_1.md` (3.1 · Codex 가 본 판).
- 앞 사전 공격 셋 (꼴 참고): 같은 폴더 `preattack1_on_v1.md` · `preattack2_on_v2.md` · `preattack3_on_v3.md`.
- 원장: `docs/reviews/findings.json` 의 DRD-01 … 13 · SELF-160 · SELF-161.
- 1저자 결정: CLAUDE.md 의 [DEM 우선 (수영)] 줄 (11-09 · 11-10 — Q1 GPU 없이 단계 0–3 · Q2 SE 형상 변형 필수 · Q3 SELF-160 문구 · Q5 기준 = 순수 SE 10–13 % · 진밀도 1.64 · 복합은 예측) 과 정독 작업 지시서 `docs/reviews/dem_redesign_direction_20261109/WORKORDER_litdb_dem_mpm_reading_20261110.md` 5 절 (하지 않는 것).
- 카드: `git -C /home/user/litdb-ctl show origin/claude/friendly-meitner-lldvar:litdb/papers/<slug>.md` (그 디렉터리에서 쓰기 · 체크아웃 · fetch 금지).
- 정독 종합 묶음 (참고): `…/scratchpad/synthfix/package/README.md` (표본 한계).

## 2. 볼 것

1. **DRD 마다**: Codex 반례가 3.2 본문에서 실제로 막히나 · 닫는 조건을 글자 그대로 채웠나 · 처분표 (drd_table) 의 "닫힘" 이 본문과 맞나.
2. **보장마다 작은 해석 반례** (CLAUDE.md 사전 공격 ③): 메모가 내세우는 보장 (등급 규칙 · 결정 함수 · 수치 오차 구간 · 자격 규칙 · 갈림 표 · 안전 그래프 · 실행 중 검사) 마다 손으로 풀리는 작은 반례 (등급 경계 칼날 · 두 오차가 서로 지움 · 탐색 점 전부 실패 · 같은 값 둘 · 극단 대비 · 2D ↔ 3D 옮김) 를 만들어 깨 본다. 깨지면 지적으로 적는다 (어느 줄 · 반례 · 고칠 방향).
3. **숫자 · 전칭 대조** (사전 공격 ①): 메모의 숫자와 "전부 · 같음 · 닫힘 · 0" 같은 말을 근거 (카드 줄 · 리포 파일 · 판정문) 와 한 줄씩 대조. 카드 값은 카드에서 다시 확인 (특히 SELF-161 의 새 카드 열한 장 · lee2025 · miss2026 · thompson2026 · wang2024 · larson2025 · faka2026).
4. **하지 않기로 한 것** 을 어겼나: 기준 (10–13 % · 1.64) · 손잡이 · 갈림 표를 정독 결과만으로 바꿨나 · 2D 숫자를 3D 로 · 다른 재료 값을 LPSCl 로 옮겼나 · DEM 과 MPM 을 서로 맞추는 데 문헌 값을 썼나.
5. **철회 · 출처 규율**: 원문을 보지 않은 서지 · `CL-94` (Minnmann 10 % 출처 철회) 같은 인용 금지 값 · [미확인] 표지 누락.

## 3. 산출 (이 폴더 아래 `review/` 에만)

`review/review_memo32.md` — 머리에 "내부 반박 리뷰 (Codex 아님) · 대상 = memo_v3_2.md (sha256 앞 12 자리) · 11-12". 지적 표: `번호 | 등급 (P1 = 결론 · 판정을 틀리게 만듦 / P2 = 등록 · 실행 전에 고쳐야 함 / P3 = 표기 · 명료) | 어디 (절 · 행) | 반례 · 근거 | 고칠 방향`. 그다음 DRD-01–13 · SELF-160 · 161 각각 "닫힘 / 일부 / 안 닫힘" 표 (근거 한 줄). 끝에 "확인 못 한 것".

## 4. 규칙

- 메모 · 리포 · 정본을 고치지 않는다 (지적만). 산출은 `review/` 에만.
- 숫자는 근거 (파일 · 행) 를 붙인다. 추정은 [추정].
- 계산 · 시뮬레이션은 돌리지 않는다 (손 산술 · 작은 파이썬 산술은 됨).
- 한국어 · 표 중심 · 짧게.

## 5. 답장

10 줄 안팎: P1 · P2 · P3 수 · 가장 무거운 셋 (한 줄씩) · DRD 닫힘 / 일부 / 안 닫힘 수 · 산출 파일 전체 경로.

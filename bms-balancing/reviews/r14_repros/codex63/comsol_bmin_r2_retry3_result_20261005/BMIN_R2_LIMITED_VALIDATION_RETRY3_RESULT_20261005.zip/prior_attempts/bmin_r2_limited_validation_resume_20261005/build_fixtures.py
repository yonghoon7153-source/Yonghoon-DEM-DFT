from pathlib import Path
from decimal import Decimal as D
import json,csv,io,os,hashlib,copy
R=Path(__file__).resolve().parent;C=R.parent/'bmin_r2_limited_validation_20261005/received/candidate'
cfg=json.loads((C/'CONTRACT.json').read_bytes());F=R/'fixtures';F.mkdir()
def ident(p):
 b=p.read_bytes();return dict(path=p.resolve().as_posix(),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def put(p,o):
 with p.open('x',encoding='utf-8') as f:json.dump(o,f,ensure_ascii=False,indent=2)
def csvwrite(p,h,rr):
 with p.open('x',encoding='utf-8',newline='') as f:
  w=csv.writer(f,lineterminator='\n');w.writerow(h.split() if isinstance(h,str) else h);w.writerows(rr)
times=sorted(set([D(i)/8000 for i in range(801)]+[D(x) for x in cfg['requested_times_s']]))
units={'eguard':['s']+['mol/m^3']*5+['1']*3,'nglobal':['s']+['mol/m^2']*3+['1']*7+['A/m^2']*3,'point1':['s','V','V','V','V','V','1','1','mol/m^3','mol/m^3','mol/m^3','V','A/m^2'],'point4':['s','V','V','V','V','V','1','1','mol/m^3','mol/m^3','mol/m^3','V','A/m^2'],'MinLinece':['s','mol/m^3'],'MaxLinece':['s','mol/m^3'],'profiletimes':['s'],'profileN':['s','m','1','1','V','V','V','1'],'profileP':['s','m','1','1','V','V','V','1']}
def tables(folder,ts,dv='0.0004',dxN='0.00003',dxP='0.00002',protect=False,mode='',baseline=False):
 folder.mkdir();stop=ts[-1]
 csvwrite(folder/'guard_binding.csv','electrolyte_expression stop_storage active terminate_on threshold_SI',[[cfg['guard_expression'],'stepbefore_stepafter','on','true','0.0']])
 csvwrite(folder/'electrolyte_guard.csv','time_s ce_min_all_mol_m3 ce_min_d1_mol_m3 ce_min_d2_mol_m3 ce_min_d3_mol_m3 threshold_mol_m3 electrolyte_guard ocp_guard surface_guard',[[t,-1 if protect and t==stop else 1200,-1 if protect and t==stop else 1200,1201,1202,0,int(protect and t==stop),0,0] for t in ts])
 csvwrite(folder/'preflight_global.csv','time_s Li_N_mol_m2 Li_P_mol_m2 Li_electrolyte_mol_m2 xavg_N xavg_P xsurf_N_min xsurf_N_max xsurf_P_min xsurf_P_max ocp_guard reaction_N_A_m2 reaction_P_A_m2 leak_leftward_A_m2',[[t,D(1)+(D('2e-9') if mode=='initial_li' and t==0 else 0)+(D('0.000006') if mode=='li_drift' and t==130 else 0),1,1,.5,.5,.5,.6,.5,.6,0,0,0,0] for t in ts])
 for name,v in [('preflight_boundary1.csv',D(0)),('preflight_boundary4.csv',D(2)+D(dv))]:
  rr=[]
  for t in ts:
   q=v+(D('.01') if mode=='aux' and t==D('120.05') and v>1 else 0)
   rr.append([t,'NaN' if mode=='nan' and t==130 and v>1 else q,0,q,0,0,.5,.5,1,1,2,q,0])
  csvwrite(folder/name,'time_s phis_V phil_V Eeq_V eta_V etamid_V x_surface x_particle_average cs_surface_mol_m3 reaction_input_mol_m3 csmax_mol_m3 direct_Eeq_surface_V Isx_A_m2',rr)
 for name in ('preflight_MinLine_ce.csv','preflight_MaxLine_ce.csv'):csvwrite(folder/name,'time_s ce_mol_m3',[[t,1200] for t in ts])
 for e,domain,dx in [('N',1,dxN),('P',3,dxP)]:
  # Complete CSV bytes; unchanged file reuse is through hard links only.
  key=(tuple(ts),e,dx,mode if mode in ('p_delta','coord','count') else '')
  dest=folder/('axes_profile_'+e+'.csv')
  if key in profile_files:os.link(profile_files[key],dest);continue
  def rows():
   for t in ts:
    for j,x in enumerate(cfg['coordinates'][e]):
     if mode=='count' and e=='N' and t==130 and j==240:continue
     value=D('.5')+D(dx)
     if mode=='p_delta' and e=='P' and t==D('137.4') and j==200:value=D('.50010001')
     coordinate=D(x)+(D('2e-15') if mode=='coord' and e=='N' and t==130 and j==0 else 0)
     yield [t,coordinate,value,.5,0,0,0,domain]
  csvwrite(dest,'time_s coordinate_m x_surface x_particle_average Eeq_V etaMid_V phil_V domain_id',rows());profile_files[key]=dest
 for tag,u in units.items():
  for phase in (['inferred','configured','evaluated'] if tag=='eguard' else ['configured','evaluated']):
   v=u.copy()
   if phase!='configured':
    for i in ([6,7,8] if tag=='eguard' else [10] if tag=='nglobal' else [7] if tag in ('profileN','profileP') else []):v[i]=''
   s='['+', '.join(v)+']';csvwrite(folder/('units_'+tag+'_'+phase+'.csv'),['tag','phase','expected','actual'],[[tag,phase,s,s]])
 settings={'study_tlist':' '.join(cfg['requested_times_s']),**cfg['runtime_settings_required'],'electrolyte_positive_check':'on'}
 if mode=='rtol':settings['rtol']='1.0E-7'
 if mode=='outside':settings['electrolyte_positive_check']='off'
 if mode=='tlist':settings['study_tlist']=' '.join('120.15' if x=='120.1' else x for x in cfg['requested_times_s'])
 csvwrite(folder/'axes_runtime_settings.csv',['key','actual_value'],settings.items())
profile_files={};base=F/'baseline';tables(base,times,dv='0',dxN='0',dxP='0',baseline=True)
baseline={p.name:ident(p) for p in base.iterdir()}
spec=json.loads((R/'INPUT_CASE_MAP.json').read_bytes());prepared=[]
for rec in spec:
 if rec['engine']!='Python':continue
 id=rec['id'];n=rec['input_index'];key=id+'_'+str(n);q=F/key;q.mkdir();cc=copy.deepcopy(cfg);cc['baseline_files']=copy.deepcopy(baseline)
 ts=list(times);mode='';protect=False;dv='0.0004';dxN='0.00003';dxP='0.00002'
 if id=='PY01-02':dv='0.001';dxN='0.0001'
 if id=='PY01-03':dv='0.0010000000001'
 if id=='PY01-04':mode='p_delta'
 if id=='PY02-01':ts=[t for t in ts if t<=D('149.9')]
 if id=='PY02-02':ts+=[D('150.1')]
 if id in ('PY02-04','PY02-05'):ts=[t for t in ts if t<=(130 if id=='PY02-04' else 100)];protect=True
 if id=='PY03-03':mode='outside'
 if id=='PY03-04':mode='rtol'
 if id in ('PY05-01','PY05-02'):
  v=D('149.9') if id=='PY05-01' else D(120);ts.remove(v);ts=sorted(set(ts+[v-D('.05'),v+D('.05')]))
 if id=='PY05-03':mode='tlist'
 if id=='PY05-04':cc['primary_comparison_times_s']=['120.15' if x=='120.1' else x for x in cc['primary_comparison_times_s']]
 if id=='PY05-06':mode='coord' if n==1 else 'count'
 if id=='PY05-07':mode='aux';ts=sorted(ts+[D('120.05')])
 if id=='PY06-01':mode='nan'
 if id=='PY06-02':mode='li_drift'
 if id=='PY06-03':mode='initial_li'
 if id=='PY06-04':cc['limits']['voltage_V']='0.002'
 tables(q/'tables_source',ts,dv,dxN,dxP,protect,mode)
 if id in ('PY04-01','PY04-02','PY05-05','PY05-07'):
  name='axes_profile_N.csv' if id=='PY04-01' else 'axes_runtime_settings.csv' if id=='PY04-02' else None
  if name:
   dest=q/name;dest.write_bytes((base/name).read_bytes()+b' ');cc['baseline_files'][name]['path']=dest.resolve().as_posix()
  else:
   bts=[t for t in times if t!=135] if id=='PY05-05' else sorted(times+[D('120.05')]);tables(q/'baseline_variant',bts,dv='0',dxN='0',dxP='0');cc['baseline_files']={p.name:ident(p) for p in (q/'baseline_variant').iterdir()}
 cc['run_root']=(q/'run_fixture').resolve().as_posix()
 console='\n'.join('ELECTROLYTE_COUPLING='+tag+'|dimension=1|entities='+sel+'|points=lagrange|lagrange=5' for tag,sel in [('minguardall','[1, 2, 3]'),('minguard1','[1]'),('minguard2','[2]'),('minguard3','[3]')])+'\nPREFLIGHT_SOLVER_RETURNED=true\nBMIN640_PRODUCER_COMPLETE\n'+'\n'.join(cc['mesh_readback_required'])+'\n'
 if id=='PY02-03':console=console.replace('BMIN640_PRODUCER_COMPLETE','NORMAL480_PRODUCER_COMPLETE')
 if id=='PY03-01':console=console.replace('Nel=640','Nel=320')
 if id=='PY03-02':console=console.replace('AXES_PHYSICAL_MESH_DOMAIN=2|numelem=60','AXES_PHYSICAL_MESH_DOMAIN=2|numelem=120')
 dof='Number of degrees of freedom solved for: 156925 (plus 12 internal DOFs).'
 if id=='PY03-06':dof=dof.replace('156925','157000')
 if id in ('PY03-07','PY03-08'):dof=''
 if id=='PY03-09':dof+='\n'+dof
 if id=='PY03-10':dof='Number of degrees of freedom solved for: 156925.'
 if id=='PY03-11':dof=dof.replace('156925','79485')+' '+dof
 if id=='PY03-12':dof+= ' Number of degrees of freedom solved for: ???' if n==1 else ' (retry 1)'
 if id=='PY03-13':dof=' \t'+dof+'  ' if n==1 else dof.replace('156925','79485')
 if id=='PY03-14':dof=dof.replace('156925','0')
 batch=('Number of degrees of freedom solved for: 1202 (plus 12 internal DOFs).\n' if id!='PY03-08' else '')+'<---- Time-Dependent Solver 1\n'+dof+'\n'+''.join(f'{i} {t} .0001 out x\n' for i,t in enumerate(ts))
 if protect:batch+=f'Information: Stop condition fulfilled at t = {ts[-1]} (Electrolyte minimum <= threshold).\n'
 batch+='----- Time-Dependent Solver 1 ----->\n'
 (q/'batch.log').write_bytes(batch.replace('\n','\r\n').encode() if id=='PY03-13' and n==1 else batch.encode());(q/'console.log').write_text(console,encoding='utf-8')
 put(q/'contract_fixture.json',cc);put(q/'INPUT_EXPECTATION.json',rec)
 prepared.append({'id':id,'input_index':n,'path':q.resolve().as_posix(),'mode':mode,'expectation':rec})
put(R/'PREPARED_PYTHON_INPUTS.json',prepared)
print(json.dumps({'prepared_python_inputs':len(prepared),'test_calls':0}))

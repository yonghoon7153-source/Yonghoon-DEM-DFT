"""Insertion-region fill fraction for the pilot and DEV E0 decks (numbers read from the decks)."""
import math
def frac(rho_am, rho_se, Rreg, halfL, N=100000, w=(0.571429,0.244898,0.183673), r=(0.0006813,0.0003028,7.57e-05)):
    rho=(rho_am,rho_am,rho_se); V=[4/3*math.pi*x**3 for x in r]; m=[rho[i]*V[i] for i in range(3)]
    n=[w[i]/m[i] for i in range(3)]; s=sum(n); n=[x/s for x in n]
    vol=N*sum(n[i]*V[i] for i in range(3)); reg=math.pi*Rreg**2*2*halfL
    # all_in yes: centres must keep the whole sphere inside -> approximate effective region per phase
    eff=sum(N*n[i]*V[i]/(math.pi*(Rreg-r[i])**2*2*(halfL-r[i])) for i in range(3))
    return dict(nfrac=[round(x,6) for x in n], counts=[round(N*x) for x in n], solid=vol, region=reg, phi=vol/reg, phi_eff_allin=eff)
print('pilot', frac(4850,1640,0.0113249,0.00226498))
print('DEV  ', frac(4800,2000,0.0118239,0.00236478))

import os,sys,subprocess,json,hashlib,pathlib,time,platform,pwd,re
B=pathlib.Path(__file__).resolve().parent.parent; S=B/'source'; E=B/'evidence'; D=S/'docs/reviews/lhs_pressure_inventory_20261104'; F=S/'docs/reviews/lhs_pressure_inventory_lpi_fix_20261104'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
paths=list(D.rglob('*'))+list(F.rglob('*'))+list((S/'docs/reviews/lhs_pressure_inventory_review_intake_20261104').rglob('*'))+[S/'scripts/lhs_pressure_record.py']
def hashes():return {str(p.relative_to(S)):sha(p) for p in paths if p.is_file()}
before=hashes(); (E/'source_before.json').write_text(json.dumps(before,indent=2))
identity=[platform.system(),platform.node().split('.')[0],platform.release(),pwd.getpwuid(os.geteuid()).pw_name,os.getuid(),os.geteuid()]
code=(D/'pressure_inventory.sh').read_text().split("-c '\n",1)[1].split("\n' \"$@\"",1)[0]; ns={'__name__':'review_import'};exec(code,ns)
assert not ns['identity_allowed']('ibb',identity) and not ns['identity_allowed']('wsl',identity)
(E/'environment.json').write_text(json.dumps({'identity':identity,'guard_ibb':False,'guard_wsl':False,'platform':platform.platform(),'network_policy':json.loads(pathlib.Path('/etc/codex/network-policy.json').read_text()),'original_head':subprocess.check_output(['git','-C','/workspace/Yonghoon-DEM-DFT','rev-parse','HEAD'],text=True).strip(),'pin':subprocess.check_output(['git','-C',str(S),'rev-parse','HEAD'],text=True).strip()},indent=2))
results=[]
for label,py in [('py311','/workspace/.venvs/yonghoon-dem/bin/python'),('py38','/workspace/.cloud-setup/python/cpython-3.8-linux-x86_64-gnu/bin/python3.8')]:
 version=subprocess.check_output([py,'-V'],text=True).strip();env=dict(os.environ,PATH=str(pathlib.Path(py).parent)+':'+os.environ['PATH'])
 for test in ['test_pressure_inventory','test_output_contract']:
  cmd=[py,'-I','-B',str(D/(test+'.py'))];start=time.monotonic();p=subprocess.run(cmd,env=env,capture_output=True,timeout=60);name=test+'_'+label
  (E/(name+'.stdout')).write_bytes(p.stdout);(E/(name+'.stderr')).write_bytes(p.stderr)
  log=p.stderr.decode();r={'name':name,'command':cmd,'PATH_prefix':str(pathlib.Path(py).parent),'version':version,'rc':p.returncode,'tests':int(re.search(r'Ran (\d+) tests',log)[1]),'passed':len(re.findall(r' \.\.\. ok$',log,re.M)),'failures':len(re.findall(r' \.\.\. FAIL$',log,re.M)),'errors':len(re.findall(r' \.\.\. ERROR$',log,re.M)),'elapsed':time.monotonic()-start};results.append(r);print(json.dumps(r),flush=True)
(E/'suites.json').write_text(json.dumps(results,indent=2))
cmd=['/workspace/.venvs/yonghoon-dem/bin/python','-I','-B',str(F/'replay_mutations.py'),str(B/'mutations')];p=subprocess.run(cmd,capture_output=True,timeout=60);(E/'mutation_replay.stdout').write_bytes(p.stdout);(E/'mutation_replay.stderr').write_bytes(p.stderr);(E/'mutation_command.json').write_text(json.dumps({'command':cmd,'rc':p.returncode},indent=2));print('mutation runner rc',p.returncode)
after=hashes();(E/'source_after.json').write_text(json.dumps(after,indent=2));assert before==after

# 질문 i — 배치별 근거 묶음 (원문 줄 그대로 · 파일 43 개)

### [batch_01] i. 복합 양극 (AM + SE) 의 압력별 기공

AM + SE 복합의 **압력별 기공값은 이 배치에 없음**. 가장 가까운 것만.

- [i] lim2025_virtual_calendering_framework | AM + CBD (SE 없음) 전극의 **밀도별** 기공: 2.3 → 49 · 2.4 → 46 · 2.5 → 44 · 2.7 → 39 · 2.8 → 35 · 3.0 → 31 · 3.3 → 25 · 3.4 → 23 · 3.5 → 20 · 3.6 → 19 · 3.8 → 14 · 4.0 → 10 % (g/cm³ → %). 실제 재구성 pore: 압축 전 49.0 % (이론 48.8) · 3.6 에서 21.8 % (이론 23.3) | §4.1 (L176–178) · Fig 2b · §3.1 (L130–131) · Fig 1d,e | 앞 = 카드 표기 "디지털화 … 정도; TREND only" · 뒤 = 표지 없음 | NCM622 96 wt% + Super P + PVDF 액체계 · 밀도축 (압력 값 없음) · 가상 값은 선형 탄성 FVM
- [i] nam2026_dpe_microstructure_review | 압연 뒤 기공 O-SWCNT-NCM 13.89 % ↔ Super P-NCM 20.90 % (ref 72). LPSCl + LiPO₂F₂ bimodal 건식전극은 "packing ↑ + void / crack ↓" (ref 119 · 값 없음) | §3.1 (L200–202) · Fig 3a · §3.4.1 (L284–289) · Fig 6c | 표지 없음 | Li-ion 건식전극 · 압력 값 없음 · LPSCl 사례는 정성
- [i] choi2024_digital_twin_review_echem | 값 없음 — 상향식 예시 그림이 "LPSCl + NCM 70 wt%" 3D 가상 구조 | §5.2 (L243–244) · Fig 3 | 표지 없음 | 기공 · 압력 값 없음


### [batch_02] i. 복합 양극 (AM + SE) 의 압력별 기공

**압력별 값은 이 배치에 없음** — 있는 것은 압연도 (두께 감소율) 별 값 하나.

- [i] alabdali2023_cgmd_wet_manufacturing_ssb_cathode | NMC622 69.0 / Li₆PS₅Cl 27.6 / CBD 3.4 wt% (3D · 강체 구): 기공 35 % (압연 0 % · 건조) → 21 % (25 %) → 15 % (50 %) · 두께 46 → 23 µm | §3-1 (L118–120) · Fig 1 · Fig 4c inset | fig-label | ★ 압력별이 아니라 압연도별 — "압연 압력 · 힘 n/a — 완전 미보고" (§3-4 L161) · 평판을 떼지 않아 누른 채일 가능성 (L709–710) · 기공 정의 미기재 · CBD 나노공극 제외 (L326–328 · L687–689) · Fig 3a 프로파일 두께 (≈ 63 → ≈ 30 µm) 와 1.37 배 어긋남 (L684–686)
- [i] alabdali2023_cgmd_wet_manufacturing_ssb_cathode | 두께 방향 기공 프로파일의 평탄역 대역: 압연 0 % 0.32–0.37 / 10 % 0.28–0.35 / 20 % 0.26–0.33 / 30 % 0.22–0.30 / 40 % 0.18–0.26 / 50 % 0.14–0.22 (집전체 근처 0.57–0.65 스파이크) | §5 Fig 3a 행 (L308) | 표지 없음 (그림 설명 칸의 판독값) | 벽 효과 · 압력 없음
- [i] alabdali2023_cgmd_wet_manufacturing_ssb_cathode | 실험 기공 대조 ≈ 50 % (건조 전극) = 문헌값 [44 Riphaus 2018 · 45 Ates 2019] + "CBD 상이 50 % 나노공극" 가정 [46, 47] — 자기 측정 아님 · 압연 기공에 대응하는 실험 없음 | §3-1 (L121) · §10-10 (L690–692) | stated | 압력별 아님
- [i] 우리 쪽 값 (카드 안 · 실험 아님) | real_14 15.6 % @ 300 MPa (pycompact2025 §10 L457 · alabdali2023 §7 L356) · real_14 씨앗 공극 19.8 % (nezamabadi2022 §7.1 L348) | 세 카드 | 표지 없음 | 우리 모델 출력
- 카드가 가리키는 이 배치 밖 카드: `dem_mechanical_stresses_ssb_electrode_cycling` (Alabdali 2024 · LIGGGHTS · uniaxial 375 MPa + isostatic · NMC532 + LPSCl 2 상 — alabdali2023 §2 L98 · §11 L719).
- 나머지 네 카드: 복합 양극 없음.


### [batch_03] i. 복합 양극 (AM + SE) 의 압력별 기공

복합 양극의 **실험 곡선은 이 배치에 없음**. 단단한 + 무른 혼합의 유비 자료만 (복합 양극 아님).

- [i] bouvard2000_hard_soft_powder_densification | Al + 60 vol% carbide die 압축 ρ vs 축응력 0–600 MPa: 600 MPa 에서 ~0.85 (20 °C) / ~0.91 (450 °C) · Ag–WC die 600 MPa 상온: ρ = 0.85 가 40 vol% WC (r = 2.5) ≡ 25 vol% WC (r = 10) · WC–Co 상온 die: Co 가 적을수록 치밀 | §3 (L28–29 · L31) · Fig 4 · 7 · 8 (L66 · L69–70) | stated (Fig 7 · Ag–WC) · stated + digitized (WC–Co) | 금속 + 세라믹 · 상대밀도 = 무게밀도 비 (L77) · 누른 채 / 뺀 뒤 카드에 없음 · 곡선 값은 그림 판독 추세 (L113) · r 방향 표기 엇갈림 (카드 문제)
- [i] cardenasbarrantes2020_rigid_deformable_mixture_compaction_nscd | 2D 혼합 φ(P/E): κ = 0.2 는 P/E ≈ 0.4 에서 φ ≈ 0.88 (μ 0) / ≈ 0.86 (μ 0.2) · κ = 1 은 P/E ≈ 0.25 에서 ≈ 0.97 · 출발 φ0 ≈ 0.80–0.82 | §3-2 (L129–130) · 그림 3a 삽도 | digitized | 2D · 초탄성 · 등방 · P/E 무차원 · 하중 중 값
- [i] cardenasbarrantes2022_soft_hard_grains_compaction_experiment_dic | 2D 일축 P vs φ − φJ 끝점: κ 1 ≈ (27 kPa, 0.083) · 0.8 ≈ (35 kPa, 0.085) · 0.5 ≈ (49 kPa, 0.074) · 0.2 ≈ (59 kPa, 0.047) | §3-3 (L120) · 그림 2b | digitized | 실리콘 / PVC · kPa · 누른 채 · φJ 값 자체는 SM ([미확인])
- [i] arzt1982_particle_coordination_densification_spheres · cardenasbarrantes2020_rigid_deformable_mixture_compaction_nscd | 카드가 인용한 우리 쪽 복합 값 (압력별 곡선 아님): real_14 ε 15.6 % · 2mAh_real_9 13.47 % · LHS 확장 union 5.43–9.43 % (arzt L264) · "실험 15.6 %" 대비 ε_sphere 1.13 % (cardenas2020 L467) · 랩 기공률 10–13 % (cardenas2020 L478) | 해당 줄 | 표지 없음 (우리 쪽 기록 · CLAUDE.md 인용) | 논문 값 아님 · 15.6 % 와 10–13 % 의 관계는 카드에 설명 없음 (카드 문제)


### [batch_04] i. 복합 양극 (AM + SE) 의 압력별 기공

압력별 곡선은 **이 배치에 없음**. 카드가 적은 우리 쪽 · 다른 카드의 값 한 점씩만.

- [i] coetzee2017_dem_calibration_review | 카드의 교차 기록: Bazzoun (LIGGGHTS · Hertz) 은 E_SE 20.5–22.1 GPa (= 실물값) 를 쓰고 porosity 0.16–0.25 를 낸다 | §10.3-W6 (L837–839) | 표지 없음 (다른 카드 값) | 압력 · 조성 · 기공 정의 · 누른 채 / 뺀 뒤는 이 카드에 없음
- [i] giannis2021_stress_based_multicontact_dem | 우리 쪽 열: 압력 300 MPa · "ε ≈ 24 % (porosity 36 → 15.6 %)" | §7-5 표 (L421–422) | 표지 없음 (우리 쪽 기록) | 계산값 한 점 · 정의 · 누른 채 / 뺀 뒤 없음
- [i] electromechanical_contact_model_particulate_systems | 우리 쪽 한 줄: "DEM 압밀 (real_14 15.6%)" | §C(6) (L283) | 표지 없음 (우리 쪽 기록) | 한 점 · 조건 없음
- [i] dmt1975_adhesion_contact_deformation · deng2021_mechanical_surface_energy_tester_bond_number | 이 배치에 없음 | — | — | —


### [batch_05] i. 복합 양극 (AM + SE) 의 압력별 기공

**이 배치에 AM + SE 복합 양극의 압력별 기공 없음.**

- [i] he2026_dem_calendering_inhomogeneity_areal_density | (참고 — SE 없는 NCM-만 액체계 양극) 면적로딩 17.6 mg/cm²: 코팅 두께 59.0 / 53.0 / 49.0 µm 에서 Hg 압입 기공 34.1 / 25.5 / 20.7 % ↔ DEM 34.7 / 27.5 / 21.6 %; 그 두께의 압밀 밀도 2.983 / 3.321 / 3.592 g/cm³; 압력 축은 판 응력 98.2 MPa (ρ_c 2.933) · ≈ 278 MPa (3.20) · ≈ 1.0 GPa (3.50) | §3.9 (L215–223) · §12.4 (L607–611) · §12.2–12.3 (L580–595) | 기공 = stated · ρ_c = derived(ours) · 응력 = stated → derived(ours) / digitized | DEM 값은 1 − ρ_c/4.57 산술 (카드) · 실험 = 압연을 마친 전극 ("누른 채 / 뺀 뒤" 낱말은 카드에 없음) · AM + SE 아님
- [i] heck2026_densification_sulfide_se_binder_scalable | 반쪽셀 양극 (sc-NMC 71 · LPSCl 24 · PIB 3 · C65 2 wt%) 을 200 MPa · 40 °C · 2 분 압축 — 기공 값 없음 | 메타 (L43) · §3-1 (L67) | [인쇄] p.5 | 기공 미보고


### [batch_06] i. 복합 양극 (AM + SE) 의 압력별 기공

압력을 여러 점으로 바꾼 복합 양극 기공 곡선은 **이 배치에 없음** (전부 한 압력).

- [i] oh2026_bimodal_composite_cathode | CAM : SSE : CC = 90 : 9.5 : 0.5 wt% — He 기공 12.78 / 10.28 / 8.83 / 10.57 / 11.58 % (CAM10:0 / 8:2 / 7:3 / 6:4 / 0:10 · 370 MPa 펠릿) · 2D 기공 16.80 / 10.18 / 7.55 / 10.93 / 17.96 % · 복합 tap density 3.28 / 3.45 / 3.59 / 3.43 / 3.26 g/cc | §4.1 (L203–211 · Table S1) · §2.2 (L140–142) | 표지 없음 (카드가 "정밀 수치" 라 적음) | 한 압력 · Li₅.₅PS₄.₅Cl₁.₅ · He 펠릿 370 MPa ↔ 셀 200 / 300 MPa ↔ σ 측정 100 MPa
- [i] kim2023_mechanofusion_ncm811_lpscl_core_shell_intimate_contact | NCM811 : LPSCl : CNF 양극 (30 mg) 계산 기공 42.38 % (80:20) · 36.62 % (90:10) = (V_meas − V_theo)/V_meas · V_theo 8.41 / 7.46 · V_meas 14.60 / 13.27 mm³ · 셀 성형 300 MPa · 1 min | §3-5 (L103–108 · SI 표 S1 · SI p.13) · §3-6 (L126) | [인쇄] · V_meas 측정법 [미확인] | 한 압력 · 코팅 / 비코팅 구분 없이 비율마다 하나 · 카드가 "300 MPa 로 누른 황화물 양극에서 크다" 고 적음 (L264)
- [i] kissel2026_mechanofusion_derived_cathode_composite_microstructures_scalable | NCM82 + Li₃InCl₆ (+ CB) 코팅 분말의 3.45 MPa 공극률 0.405 / 0.389 / 0.329 / 0.321 / 0.275 (LIC 1 / 2 / 5 / 10 / 20 wt% · CB 없음) · 0.363 → 0.257 (CB 있음) · 회전수 시리즈 0.444 / 0.380 / 0.349 / 0.339 / 0.295 (1,000 → 10,000 rpm · 60 min) | §3-3 (L112) · §3-4 (L128) | [원자료 Figure2c · Figure5b] | 할라이드 · 3.45 MPa 한 점 · 380 MPa 복합체 공극률 [미확인]
- [i] martinbouvard2003_dem_composite_cold_compaction | 경질 + 연질 혼합의 P/Σ₁ vs D 곡선 (f₂ = 0 / 10 / 20 / 30 / 40 % · Fig 7) — 경질이 많을수록 같은 D 에 더 큰 P · 초기 D₀ ≈ 0.637 | §5 Fig 7 (L64) · §3 (L22) | 곡선 값은 카드에 없음 (그림 설명만) | 무차원 · 금속 모델 · AM + SE 아님
- [i] mcgeary1961_bimodal_sphere_packing | 압력 없는 강체 구 충전: 이성분 86.0 % (기공 14.0 %) · 삼성분 90.0 % · 사성분 95.1 ± 0.3 % | §3 (L28–31) | stated | 압력별 아님 · 금속 shot


### [batch_07] i. 복합 양극 (AM + SE) 의 압력별 기공

AM + SE 복합의 **압력별 기공 값은 이 배치에 없음**.

- [i] so2022_dem_contact_model_assb_compaction_sintering | SE 코팅 AM (LPS + NCM/LiCoO₂ · AM 10,746 + SE 27,263 · 측방 20 × 20 µm) 을 360 MPa 로 누른 한 점 — 상자 23.9 µm (Fig 6d) · 기공 · 상대밀도 값은 카드에 없음 | §3 표 (L45–47) · §4.9 (L183–184) · Fig 6 행 (L196) | stated | 압력 계열 아님 · 결과는 동반 논문 (JPS 530, 231279) 소관 (L272) · LPS
- [i] schreiner2020_dem_calendering_lib | LIB 양극 (NMC622 + 바인더 · SE 없음) 의 압연 전 기공 43 % 한 값 (코팅 밀도 2.53 g/cm³ · 두께 56 µm) · 압력별 표 · 곡선 없음 | §3 (L35–37) | stated | AM + SE 복합 아님 · 누르기 전 한 점
- [i] 나머지 | 없음 | — | — | —


### [batch_08] i. 복합 양극 (AM + SE) 의 압력별 기공

- [i] varkey2026_multicontact_elastoplastic_dem | 양극 (할라이드 Li₃YBrCl₆ + NMC-811 + SBR + CB) DEM 기공 49 / 39 / 38 / 37.5 / 37 % @ 0 / 125 / 200 / 300 / 350 MPa · 두께 계산 146.6 / 141.2 / 137.7 / 135.6 vs 실험 145.2 / 140.5 / 137.1 / 135.3 µm (125–350 MPa) | §3 표 (L20–21) · Fig 13 · Fig 12 | 기공 = digitized · 두께 = stated | 할라이드 SE · 강체 구 · 이봉 양극 (L39) · 조성 값은 카드에 없음 (질량 loading 0.037 g/cm² · 72,964 입자 · L42) · 누른 채 / 뺀 뒤 카드에 없음 · 실험 쪽은 두께만
- [i] 나머지 8 장 | 없음 (`thompson2026` · `wang2024` 는 SE 단독 · `stallard2022` 는 AM 물성 · `tovar2026` 은 NMC622 복합 입자의 충돌) | — | — | —


### [batch_09] i. 복합 양극 (AM + SE) 의 압력별 기공

**이 배치에 없음** (Zunker 2025 편은 단일 재료 · `xu2017` 은 SE 없는 액체계 전극의 밀도 추정뿐 — a 항).


### [batch_10] i. 복합 양극 (AM + SE) 의 압력별 기공

**압력을 바꿔 가며** 복합 기공을 잰 카드는 bazzoun2025 하나 (200 / 300 / 400 MPa · 감소율만 남음). 나머지 다섯은 단일 압력 (250–450 MPa) 의 값이다.

- [i] bazzoun2025_dem_parameter_sensitivity_assb_cathode | 실험 (건식 막 · f_CAM 60 / 70 / 80 / 85 wt%): 200 → 400 MPa 에서 기공 감소율 SE19 −19.0 / −12.6 / −11.8 / −13.7 % · SE45 −22.0 / −10.9 / −7.5 / −6.1 %; SE19 가 SE45 보다 23.6 / 20.5 / 12.7 / 13.8 % (@200) · 37.4 / 32.8 / 30.6 / 24.9 % (@400) 낮음. 모의 (300 MPa) SE45 ≈ 0.22 (60 wt%) → ≈ 0.25 (85 wt%) · SE19 ≈ 0.16 → ≈ 0.18. 정의: 실험 ε = 1 − ρ_meas/ρ_theo · ρ_meas = m/(π(d/2)²h) (9 mm 코인 · 식 2–3) / 모의 = 몬테카를로 점 세기 − 첨가제 부피 (식 22) | §3 (L32–36) · §6 (L110 · L115) · 논문 §4.4 · Fig 5/6 · 17 | 감소율 = stated · 모의 = digitized | NMC532 + LPSCl + CB · CNF · PTFE · 실험 기공의 **절대값은 카드에 없음** · 측정 상태 미기재 · 감소율 행의 표기 문제 (카드 문제 6)
- [i] minnmann2021_jes_charge_transport_bottlenecks | 380 MPa (단일): 시료별 **7.6 / 13 / 17 / 17 / 15 %** (NCM 25 / 33 / 42 / 53 / 61 vol% = 50:50 / 60:40 / 70:30 / 80:20 / 86:14 mg) · 평균 14 % · 본문 문구는 "13 %–17 %". 정의 Φ = (V_meas − V_theo)/V_meas (식 S8). 원문: *"All determined porosities are susceptible to errors, as high as 10 %, due to the inaccurate determination of the composite cathode thickness."* 밀도 4.65 g/cm³ 를 쓰면 7.0 / 12.1 / 15.7 / 15.2 / 12.8 % (평균 12.6 %) | §0 (L54) · §3 (L169–183) · §5.0 (L340–344) · 논문 SI Table S1 (SI p.4) | stated · 재계산 = [내 산술] | NCM-622 + LPSCl · 탄소 없음 · fine-SE 시료는 기공 미측정 (L201) · 오차의 상대 / 절대 여부 [미확인]
- [i] minnmann2024_microstructure_porosity_visualization | 380 MPa (단일): 분할값 ≈ 10 / 7.5 / 6 % ↔ 질량 · 밀도 기대값 ≈ 20 / 16 / 11 % (ISE d50 7.41 / 4.93 / 5.93 µm 세 종) | §3 (L36–37 · L53) · 논문 Fig 4d | digitized | Li₃PS₄–0.5LiI + 단결정 NCM · 50:50 vol · LPSCl 아님
- [i] frankenberg2025_milling_dry_processed_sulfide_cathode_microstructure | 380 MPa · 1 min (단일): 0.376 (200 rpm 30 min) / 0.285 (400 / 30) / 0.284 (600 / 30) / 0.266 (800 / 20) / 0.265 (1000 rpm 20 min) — 조성 고정 (NCM83:LPSCl 70:30 wt%) · 밀링 에너지만 다름. 건식 막은 ε = 0.3 | §3-4 (L124–132) · §3-8 (L191) | [판독 Fig 5b] · 양 끝은 [인쇄 p.6] | 기하 밀도 / 혼합 밀도 3.25 g/cm³ · 탄소 없음 · 측정 상태 미기재
- [i] kim2024_optimal_cathode_composite_mechanical_mixing_se_coverage | 2 t · 1 min (⌀10 mm ≈ 250 MPa · 단일): 입자 사이 기공 22.34 / 22.01 / 22.5 % + NCM 내부 기공 8.99 / 9.03 / 8.97 % (손 혼합 / 일부 입힘 / 다 입힘) · 충전 밀도 2.682 / 2.693 / 2.676 g/cm³ (0.1 g · 0.785 cm² · 두께 475 / 473 / 476 µm · 마이크로미터) | §3-3 (L92–106 · L109) | [인쇄 SI 표 S1] · 압력 환산 = [우리 산술] | NCM811:LPSCl:VGCF 75:23:2 · 부피분율은 수은 압입 겉보기 밀도로 계산 · 표의 NCM 부피분율 이상 ([추정] · L258)
- [i] lin2025_submicron_lpscl_cathode_li_kinetics | 450 MPa (단일): 21.12 % (D50 11.88 µm SE) → 18.68 % (D50 2.34 µm SE) · 원자료 0.20 g · ⌀10.00 mm · h 1.00 / 0.97 mm | §3c (L98–99 · L105–107) · 논문 ESI Table S4 | stated · 분해능 계산 = [우리 산수] | AM:SE 70:30 w% · 두께 0.01 mm ≈ 기공 0.8 %p · 셀 성형압 (640 MPa) 과 다름 · 반복 없음
- [i] lei2026_se_particle_size_effects_review | 2차 인용: 복합양극 (AM:SE 8:2) 기공 — 저에너지 습식 밀링 SE 13.5 % ↔ 고에너지 건식 밀링 SE 22.7 % | §3-1 (L54) | [2차 · ref 78] | Li₅.₃PS₄.₃ClBr₀.₇ · 압력 · 측정 상태 카드에 없음
- [i] bazzoun2026_dem_fem_rnm_ionic | 기공값 없음 (초기 패킹 ≈ 75 % 만) | §4 (L46) | 표지 없음 | —


### [batch_11] i. 복합 양극 (AM + SE) 의 압력별 기공

압력 **곡선** 이 있는 카드 = 1 (otani2025 · DEM 계산 · 누른 채). 실험은 한 압력점 (schlautmann2023). 나머지는 가정 · 문헌 대역 · 배치 목표라 대조값으로 쓸 수 없다.

- [i] otani2025_dem_se_dispersion_aggregation_compression | DEM (NCM111 + LPSCl 79:21 vol% · 누른 채 · 상대밀도 = Σ구부피 ÷ (판 거리 × 면적)). 상대밀도 (%) @100 / 200 / 300 / 600 / 990 MPa: N=2 (이상 분산과 사실상 같음) 73.8 / 76.2 / 78.1 / 82.2 / 86.2 · N=1 — / 76.4 / 78.6 / 82.7 / 86.4 · N=6 71.0 / 73.8 / 76.0 / 80.9 / 85.4 · N=307 60.8 / 65.9 / 70.1 / 76.6 / 82.2 → 기공 (1−D) N=1 **21.4 % @300 MPa** · 13.6 % @"1000 MPa" · N=307 29.9 % · 17.8 % | §3.2 (L105–136) · 논문 Fig 3 | digitized (색 분리 자동 추출 · TREND only · ±~0.5 %p) · 기공 환산은 카드 | 실험 아님 · 무연화 탄성 구 (소성 없음) · AM NCM111 · 100× 조대화 · 겹침을 고체로 세는 연산자 (고압에서 과대 · e 항) · 초기 충전 밀도 미보고 (L133–134) · 표 행은 990 MPa 인데 본문은 1000 MPa 로 적음 (카드 문제 6)
- [i] schlautmann2023_se_particle_size_composite_transport | 실험 · 한 압력: NCM811 : LPSCl 70:30 wt% 무탄소 · 일축 3 t (≈375 MPa · 우리 산수) 성형 → 50 MPa · 복합 공극 **S 14.1 / M 18.1 / L 21.4 / XL 24.3 %** (SE D50vol 4 / 11 / 20 / 40 µm) | §3a (L72) · §3f (L141) · SI Table S1 | stated (공극) · 우리 산수 (압력 환산) | 압력별이 아니라 SE 입도별 · 밀도 측정으로 계산 (누른 채 / 뺀 뒤 · 시료 두께 카드에 없음) · SE 입도가 우리보다 훨씬 큼 · 같은 표의 vol% 와 밀도가 서로 안 맞음 (카드 문제 9)
- [i] tailored_cathode_microstructure_low_pressure_assb | FIB-SEM 기공 coarse 11.3 % / fine 4.4 % — 카드의 한 곳은 "for NCM811/LPSCl composites" 라 적음 | §9 (L278) ↔ §3 (L39) | stated | 시료가 전해질 펠릿인지 복합체인지 불명 (카드 문제 2) · 제조압 미기재 → 압력별 값 아님
- [i] shi2019_high_am_loading_particle_size_assb | **DEM 침대의 기공은 보고되지 않음 (n/a)**. Fig 7a 의 Φ 0.1–0.2 는 ref [29] (Choi 2018 · 정본 카드 없음) 의 문헌 대역으로 wt% → vol% 환산에만 쓴 것 — 측정도 모델 입력도 아님 | §3 (L119) · §8 정정 (L510) · §A.5 (L590) | stated (Fig 7a) + 카드 정정 2026-09-26 | 대조값으로 쓰면 안 됨 (카드의 옛 표 L496 은 "입력/환산" 이라 적혀 있음)
- [i] stavola2023_thick_nmc111_lpscl_lithiation_gradient_tortuosity | 공극 **14 % 가정** (측정 아님 · refs 7, 41, 42, 48, 49) · 양극은 100 MPa (operando) · 50 / 150 MPa (EIS) 로만 눌림 | §3-1 (L61) · §9-4 (L279) | [인쇄] · [추정] (실제는 더 클 수 있음) | 대조값으로 쓰면 안 됨
- [i] park2020_dimension_controlled_se_percolation_contact_area | 기공 30 % = 배치 목표 (압력 축 없음 · 2D 2500 은 ≈35 % · 파생) | §3-A (L46) · §3-H (L220) · §4.8 (L295) | stated · 파생 | 압밀 아님
- [i] schneider2023_particle_size_pressure_transport | 이 카드에 없음 (순수 SE) | — | — | —


### [batch_12] i. 복합 양극 (AM + SE) 의 압력별 기공

AM + 황화물 SE 의 **압력별** 값은 so2021 (Si + LPS · DEM) 뿐. LPSCl 복합 양극은 한 압력 점 (yano2026 400 MPa · yadav2021 3 t) 과 두 가압 경로 (benhadjali2026 — 압력 · 온도 · 시간 · 하중 방식이 함께 다름). SE 없는 LIB 양극의 압력별 기공 (sangros2019 · 2020 · diener2022) 은 재료가 달라 "참고" 로만 적는다.

- [i] benhadjali2026_wip_vs_cup_pressing_assb_cathode_dem | 습식 NMC622 : LPSCl : 탄소-바인더 69 : 27.6 : 3.4 wt% 실험: 기공 미가압 34.12 % → CUP (~116 MPa · 상온 · 30 s) 25.1 ± 1.7 % (본문 25.13) → WIP (400 MPa 등방 · 80 °C · 5 min) 10.9 ± 2.4 %; 게이지 두께 82 → 72 ± 1.2 (본문 72.16 ± 1.65) → 61 ± 1.6 µm (본문 60.68 ± 1.60); 겉보기 밀도 1.59 → 1.81 → 2.20 g/cm³. 기공 식 (1) ε = 1 − (m_el/V_el)·Σ(X_i/ρ_i) · Ø10 mm 원판 안 다섯 자리 | §3-3 (L87–95) · 논문 표 1 · 2 · p.9–10 | [인쇄] | 뺀 뒤 (하중 없는 원판 · 셀 조립 전) · 성분 밀도 값 [미확인] · 두 점은 압력 · 온도 · 시간 · 하중 방식이 함께 다름 (압력 곡선 아님) · 두께 · 질량의 집전체 포함 여부 [미확인] · 프리프린트
- [i] benhadjali2026_wip_vs_cup_pressing_assb_cathode_dem | 카드 점검: (1 − ε) × 게이지 두께 = 54.0 / 54.0 / 54.1 µm (질량 보존과 맞음) · 식 (1) 이 함축하는 골격 밀도 2.415 / 2.411 / 2.468 g/cm³ ↔ 흔한 결정 밀도 가정 (NMC622 4.7–4.8 · LPSCl 1.64–1.86 · 탄소 · 바인더 1.8–2.0) 으로는 2.99–3.24 → 같은 겉보기 밀도의 기공 47–51 / 40–44 / 27–32 % | §3-3 (L98–101) · §10-6 (L407) | [우리 산술] (밀도 범위는 "이 논문에 없는 우리 가정") | 보고 기공이 어떤 밀도로 셌는지 원문만으로 재현 안 됨
- [i] benhadjali2026_wip_vs_cup_pressing_assb_cathode_dem | DEM 기공 ≈ 26.5 % (CUP) · ≈ 15 % (WIP) · 두께 감소 ≈ 12 / ≈ 28 % (실험 12 ± 2 / 26 ± 2 %). 같은 DEM 의 Fig 6 상 분율 판독 평균 기공은 0.43 / 0.31 (bulk 0.38 / 0.27) | §3-9 (L188–190 · L195) · 논문 p.37–38 · Fig 6 · 7 | [인쇄] · Fig 6 = [판독 ±0.03] | DEM 기공의 정의 · 분석 부피 [미확인] — 보고값이 질량 보존 · Fig 6 둘 다와 안 맞음 ([우리 산술] · L172 · L406) · 변위 제어 (압력 모름)
- [i] yano2026_se_psd_width_ionic_tortuosity_dem | NCM622 : LPSCl 70 : 30 wt% · 400 MPa 한 점: 실험 상대밀도 (볼밀 0 / 10 / 20 / 30 wt%) 그림 10 = 0.843 / 0.828 / 0.811 / 0.780 · 그림 7 = 0.651 / 0.639 / 0.626 / 0.603 · DEM (EEPA · E_LPSCl 21 GPa · 400 MPa) = 0.728 / 0.727 / 0.724 / 0.722 | §3c (L84–95) · 논문 그림 7 · 10 · p.5–6 | [벡터 판독] | 본문은 "100–400 MPa" 라 적었으나 결과는 400 MPa 뿐 · 두 그림의 비 1.2952 (진밀도 혼합 규칙 차로 설명 — [우리 산술 · 원인 추정] · 저자 설명 없음) · 두께 측정 상태 카드에 없음 · LPSCl 1.87 g/cm³ 로 다시 정규화하면 0.758 / 0.745 / 0.730 / 0.702 ([우리 산술] · L151) · 카드: 절대값 인용 금지 (§10-2)
- [i] yadav2021_lpscl_sieved_psd_impedance_tortuosity | NMC111 66.5 : LPSCl 28.5 : 탄소 5 wt% · 3 t 한 점: compacity ~55.44 / ~60.95 / ~64.05 % (SE <20 / 20–50 / 50–150 µm) → 기공 44.6 / 39.0 / 36.0 % | §3c (L87–91) · 논문 그림 4 아래 표 | compacity = [인쇄] · 기공 = [우리 산술] | 측정법 미기재 · 같은 압력급 복합양극 문헌의 두 배 → 카드: 절대값 인용 금지 (§10-6 · L283)
- [i] so2021_dem_mold_pressure_assb_coldpress | Si + LPS 복합 (음극 · NCM 양극 아님) 3D DEM: @600 MPa 상대밀도 f_AM 0 / 30 / 50 / 70 % = ≈0.98 / 0.93 / 0.86 / 0.76 · f_AM 0.5 두께 62.1 → 36.4 (@100 MPa) → 29.3 µm (@400 MPa) | §3 (L28 · L30) · 논문 Fig 3 · 4c | 상대밀도 = digitized · 두께 = stated | 재료 다름 · 판독 시점 명시 없음
- [i] sangros2019_dem_calendering_lib_electrode · sangros2020_lib_electrode_dem_mech_elec_ionic | (SE 없는 LIB 양극 · 참고) 캘린더링 응력 19.82 / 42.71 / 79.13 / 159.37 MPa 뒤 실측 기공: 2019 카드 0.522 → 0.416 / 0.372 / 0.295 / 0.217 · 2020 카드 0.522 → 0.417 / 0.368 / 0.305 / 0.270 | sangros2019 §3 (L23–24) · sangros2020 §3 (L30–31) · 두 논문 Table 1 | stated | AM + SE 아님 · 두 카드의 값이 다름 (카드 문제 2) · 모의 C4 0.247 ↔ 실측 0.217 (sangros2019 L131)
- [i] diener2022_roll_gap_springback_calendering | (SE 없는 LIB 양극 · 참고) 선하중별 코팅 밀도: 초기 2.44–2.50 g/cm³ (기공 41.1–43.1 %) → 최고 하중 3.18 (200 g/m² · 615 N/mm) · 3.41 g/cm³ (350 g/m² · 1015 N/mm) → 기공 25.6 · 20.2 % | §3-1 (L54–55) · §3-4 (L74–80) | 초기 · 3.18 · 3.41 = [인쇄] · 중간 값 = [판독 ±0.02] · 최종 기공 = [우리 산술] (혼합 진밀도 4.27) | 선하중 (압력 아님) · 뺀 뒤 두께
- [i] larson2025_hot_pressing_argyrodite_low_stack_pressure_conductivity · demirtas2021_mpfem_hollow_sphere_die_compaction | 복합 없음 | — | — | —


### [batch_13] i. 복합 양극 (AM + SE) 의 압력별 기공

AM + SE 복합 양극의 압력별 기공 = 이 배치에 **없음**. LIB 카드 넷은 AM + 탄소 – 바인더 (SE 없음) · miss2026_pressure 는 복합 양극이지만 기공 자료 0 건 · miss2026_insitu 는 단일상. 아래는 참고 값이다.

- [i] miss2026_insitu_conductivity_porosity_pressure_compaction | 논문에 복합 양극 자료 없음 (단일상만). 카드 §0 이 옮겨 둔 **우리 쪽** 복합체 값 (논문 값 아님 · 1저자 숫자): 조성 P:S 10:0 / 7:3 / 5:5 / 3:7 / 0:10 에서 실험 기공 26.2 / 22.2 / 24.5 / 25.6 / 29.8 % ↔ DEM 16.9 / 16.5 / 17.7 / 18.7 / 20.6 % (차 +9.3 / +5.7 / +6.8 / +6.9 / +9.2 %p) · 실험 = 다이 안 · 300 MPa 뒤 하중 제거 후 ↔ DEM = 300 MPa 판 고정 (누른 채) | §0 표 (L38–46) · §7-1 (L265) | [우리 산술] · "1저자 숫자" | 압력별 곡선이 아니라 300 MPa 한 점 · 출처는 우리 실험 · DEM 기록 (`docs/data/ps45_r45_union_20260929/README.md` 로 적힘)
- [i] miss2026_pressure_tortuosity_composite_cathode_coating | 복합 양극 논문이지만 압력별 기공 없음 — "공극 · 밀도 · 두께-압력 자료 0 건". 부피분율은 공극을 뺀 명목값 (1 − ε_CAM) 만 쓰고, 50:50 시료가 그림 축에서 ε_CAM ≈ 0.52–0.53 자리에 찍힌 이유도 설명 없음 | §0 (L20 · L26 · L34) · §6 (L197) · §10-3 (L252) | 카드 서술 · [판독] | —
- [i] zhang2026_xct_dem_cathode_calendering_peel_calibration | SE 가 없어 "AM + SE" 는 해당 없음. 참고 — NMC + CBD (96:4 wt) 의 압력별 기공: 누른 채 0.432 / 0.333 / ≈ 0.280 / ≈ 0.213 / ≈ 0.174 / ≈ 0.152 @ 0 / 30 / 60 / 100 / 140 / 200 MPa · 뺀 뒤 0.411 / ≈ 0.370 / ≈ 0.319 @ 30 / 60 / 200 MPa · 실험 (뺀 뒤) ≈ 0.424 / 0.412 / ≈ 0.359 / ≈ 0.310 @ 0 / 30 / 60 / 200 MPa | §3.5 (L169–176) · 논문 Fig 4b · 4c | 0.432 · 0.333 · 0.411 · 0.412 = stated · 나머지 figure-read ≈ | LIB · 기공 관례 미기재 · 실험이 자체 측정인지 Ebner 값인지 불명 (L465)
- [i] ngandjong2021_dem_calendering_digital_twin | SE 가 없어 "AM + SE" 는 해당 없음. 참고 — AM 96 wt% + 무른 CBD 4 wt% 의 뺀 뒤 기공: 실험 42.15 / 32.09 / 28.80 / 26.33 / 26.23 % @ 0 / 5.92 / 55.9 / 86.0 / 156.0 MPa (±1σ 2.0 / 1.28 / 0.6 / 0.8 / 하한 쪽만 0.6) · 모의 41.59 / 34.86 / 31.52 / 30.70 / 27.85 / 27.23 / 27.03 % @ 0 / 2.9 / 7.4 / 31.8 / 67.8 / 106.6 / 155.7 MPa | §3-A-2 · §3-A-3 (L132–155) · 논문 Fig 2B | digitized (stated 6 점 대조 오차 ≤ 0.15 %p) | 카드 판정 T1 = 절대값 전이 불가 (SE 없음 · 압연 · 뺀 뒤 값 · 기공 규약 미기재)
- [i] xu2023_realistic_am_shape_cgmd_calendering | SE 가 없고 압력 축도 없어 해당 없음. 참고 — AM + CBD 의 해제 뒤 기공 대 두께 감소율: 모의 96 % AM 47.35 / 37.99 / 30.50 / 23.48 / 21.23 / 20.39 % @ CD 0 / 15.37 / 24.76 / 32.68 / 35.18 / 36.11 % · 94 % AM 55.07 / 46.84 / 39.90 / 32.26 / 28.26 / 24.95 % @ 0 / 15.70 / 25.49 / 34.32 / 38.72 / 42.17 % ; 실험 96 % ≈ 47.5 / 28.72 / 27.66 / 25.07 % @ 0 / 25.27 / 28.73 / 30.92 % · 94 % ≈ 55.2 / 31.06 / 26.84 / 25.84 % @ 0 / 32.13 / 36.86 / 39.72 % | §3-B-2 · §3-B-3 (L203–225) · 논문 Fig 3A | digitized (stated 5 점과 ≤ 0.02 %p) | 카드 판정 T1: 선행 Ngandjong 의 P ↔ ε 를 빌려 CD 에 MPa 를 붙이는 것도 불가 (같은 96:2:2 인데 압연 전 기공 42.15 ↔ ≈ 47.5 % = 다른 침대)
- [i] lyu2025_3d_dem_drying_calendering_lib | SE 가 없어 해당 없음. 참고 — NCM811 + CBD (94:6 wt) 의 압연: 압축 응력 ≈ 0 → 160 MPa 에서 기공 ≈ 57 → ≈ 22 % (저압에서 급강하 뒤 완만 · DEM ≈ 실험 Giménez [45]) · Hg 압입 실험 57 → ≈ 20 % [ref32] | §3 (L27) · §4 (L75) · §5 Fig 3 (L88) | 57 → 22 % = stated · Fig 3 의 개별 점 값은 카드에 없음 | LIB · 압연 · 기공이 측정 영역 정의 (식 25) · 누른 채인지 뺀 뒤인지 미기재


### [batch_14] i. 복합 양극 (AM + SE) 의 압력별 기공

압력별 곡선을 준 카드는 **없다**. 한 점 = so2022 (LPS + NCM · 360 MPa · 모의). 나머지는 입력값이나 리뷰 인용이다.

- [i] so2022_dem_compaction_coated_particles_assb | 복합 (LPS + NCM · 고체 중 AM 부피분율 f_AM 0.734 · 3D DEM · 누른 채) 360 MPa 한 점: 기공 (= 1 − AM − SE) 혼합 ≈ 17 % · 코팅 ≈ 16 % · 부피분율 AM / SE = 혼합 0.61 / 0.22 · 코팅 0.59 / 0.25 · FIB-SEM (Nakamura [17]) 과 부피분율은 잘 맞고 AM–pore 면적은 과대 | §3.1 L53 · §3.2 L60–61 · Fig 3a | digitized (Fig 3a) — §10 L222 는 같은 값을 "stated" 로 적음 (카드 문제 2) | LPS (LPSCl 아님) · 압력별 곡선 없음 · 겹침 부피를 어떻게 세는지 (합집합인지) 카드에 없음 · 시드 1 개로 보임
- [i] lee2024_multiphysics_dem_fem_initial_pressure_assb | 초기 공극 0.44 (압축 전 · 양극 · 음극 모두) · 초기 부피분율 양극 NMC 0.18 / SE 0.38 · 음극 graphite 0.32 / SE 0.24 — 압축 뒤 기공 – 압력 값은 카드에 없음 ("압축으로 감소") | §3 L69–71 · Table 2 | stated | LGPS · 모의 입력값
- [i] deysher2022_transport_mechanical_aspects_assb_review | 인용: 고 CAM wt% 에서 완전 이용률에 기공 < 20 % 필요 · > 55 % 면 이용률 ↓ ([66] Bielefeld · 미세구조 모델링) | §3 L82–83 · §10 L297–298 | stated (인용) | 압력 축 없음 · 확률적 배치의 입력 기공 (눌러서 나온 기공 아님)
- [i] kang2026_intertwined_electrochemo_mechanical_sulfide_assb_review | 인용: 가압 ↑ → 기공 ↓ · 접촉 면적 ↑ · 성능 ↑ (저율속 · Fig 7b) · 370 MPa 에서도 공동 잔존 (ref 100) · 12 µm NCM + 1.5 µm SE → ≈ 50 vol% CAM 로딩에서 거의 완전 용량 유지 (Shi · ref 106 · cold-press) | §5.1 L126 · L129 · L135 | 2 차 인용 | 기공 수치 없음
- [i] sakuda2013_sulfide_mechanical_property | 복합 양극 (PLD 로 SE 를 입힌 LiCoO₂ : SE 막 ≈ 90 : 10 · 360 MPa 3 층 펠릿) 단면이 "매우 치밀, 공극 거의 없음" (Fig 6b) — 수치 없음. 카드가 적은 다른 논문 값: Minnmann 2021 JES 복합 (NCM622 + LPSCl · 380 MPa) 기공 13–17 % (복합 · 순수 SE 아님) | §4 L81–83 · §5 L100 · §11-C L186 | 정성 · 다른 논문 값은 표지 없음 | 이 논문 값 아님 · doux 카드는 같은 Minnmann 복합을 14 % 로 적음 (카드 문제 19)
- [i] doux2020_stack_pressure_assb | 복합 양극 (LNO 코팅 NCA : LPSCl : carbon black = 11 : 16 : 1 · 12 mg · 370 MPa) 의 기공 값 없음 | §2.1 L91–93 | — | 카드: "양극 microstructure 수치는 전사 금지"
- [i] nisar2024 · kakar1967 | 이 카드에 없음 | — | — | —


### [batch_15] i. 복합 양극 (AM + SE) 의 압력별 기공

복합 양극의 압력별 기공을 준 카드 = **0**.

- [i] asano2017_ncm111_li3ps4_composite_electronic_ionic_conductivity | 기공 미보고 — *"NMC volume ratios of 48%, 55% and 62%"* 뿐 · 기준 (고체 / 전체) · 밀도 · 시료 질량 없음 · 압밀은 360 MPa · 실온 한 조건 | §0 L30 · §3-1 L73–75 · §6 L196 · 논문 p.A3960–A3961 | stated (조성 · 압력) · 미보고는 카드 확인 | Li₃PS₄ 유리 + NMC111
- [i] beutl2024_round_robin_coin_cell_sulfide_assb | 복합 bilayer (양극 10 mg 을 SE 100 mg 위에 360 MPa · 2–3 min) 의 기공 값 없음 · 조성 57:40:3 wt% (본문 vol% "65:31:4" 는 이름 순서가 뒤바뀐 것으로 카드가 계산) | §3-3 L115 · §3-7 L162 | [인쇄] · 순서 뒤바뀜은 [우리 산술] | 기공 없음
- [i] cronk2026_lis_positive_electrode_geometry_fem | 양극 기공 실측 0 건 — 모델은 10 vol% 입력 · 실험은 *"an increase in porosity"* 정성 서술 | §3.2 L98 · §10-11 L661–664 | stated · 카드 확인 | Li–S
- [i] bielefeld2019 · bielefeld2020 | 기공은 입력 — 압력과의 관계 없음. 입력 기공에 대한 결과만: 이상 조성 62/38 → 66/34 → 72/28 vol% (porosity 5 → 10 → 20 %) · 5 % void 가 20 % void 대비 σ_eff 2 배 @고-AM | bielefeld2019 §3 L48 · bielefeld2020 §3 L246–251 | stated (2019) · 표지 없음 (2020) | 압력 없음
- chen2011 (porosity 30 % 입력) · cooper2017: 해당 없음.


### [batch_16] i. 복합 양극 (AM + SE) 의 압력별 기공

AM + SE 를 압력별로 잰 카드 = **0**. 한 압력의 점 (hlushkou2018 · froboese2019) 과 SE 없는 LIB 대조 (duquesnoy2020 · galvezaranda2024) 만 있다.

- [i] hlushkou2018_void_space_ion_transport_assb_cathode | LCO (≈ 5 µm) + LPSI 유리 복합 (38 : 62 vol% 공칭) · FIB 시료 (에폭시 수지와 섞어 4 t/cm² · 14 h): 재구성 부피분율 LCO 33.1 · SE 53.7 · void 상 13.2 % — void 상 = "안정화 수지가 차지한 공간 + 잔류 공극" (분리 불가) | §3-A L82 · §3-C L110 · §3-D L116–123 · 논문 p.365–367 · Table 3 | stated | 한 압력 (카드 환산 ≈ 392 MPa · tonne-force 가정) · 수지 포함이라 잔류 기공률이 아님 (상한도 하한도 아님 · L270) · EIS 시료 (수지 없음 · 5 min) 의 기공은 [미확인] · LPSI · LCO
- [i] froboese2019_microstructure_ionic_conductivity_assb_electrode | 모델 복합 (유리구 + 고분자 SE) @732 MPa 단일: 기공 ≈ 2.8 % (10 vol% · 0–20 µm) – 19.72 % (60 vol% · 0–50 µm) · 조성 · 입경 21 점 표 | §3-2 L88–110 | stated (19.72 등) + 판독 ≈ (TREND 전용) | 압력 축 없음 · NCM · 황화물 아님
- [i] duquesnoy2020_calendering_ml_mesostructure_generator | AM + SE 아님 (LIB 대조): NMC111 + CBD 전극의 캘린더 뒤 기공 22.1–36.4 % (초기 42.5–48.9 % · gap 1–100 µm) · 압력축은 교정식 P = 189·exp(−gap/(0.21·T)) 로 환산 (교정점 ≈ 6–175 MPa) · 생성기 쪽 곡선 (Fig 3): ε_init 48 % 에서 0.40 → 0.331 (AM 96 %) · 0.378 → 0.305 (AM 93 %) — "~100 MPa 이후 포화" | §3.1 L43–45 · §3.2 L52–54 · §6 L339 | stated (실측 범위 · 식) · figure-read ≈ TREND (곡선) | SE 없음 · 액체 전해질 · 압력은 gap 의 환산값 · Fig 3 의 ε_cal 은 측정이 아니라 다항식 목표값 (두께 100 µm 로 교정 범위 밖 외삽 · L75)
- [i] galvezaranda2024_time_dependent_dl_calendering_microstructure | AM + SE 아님 (LIB · DEM): CD 20 / 25 / 30 / 35 / 40 / 45 / 50 % 에서 기공 30.66 / 26.54 / 24.78 / 21.04 / 20.02 / 19.04 / 19.87 % (미세구조 IV) | §3-C L125–131 · SI Table S2 | stated | 압력 (MPa) 축 없음 · 계산값 (실험 아님) · SE 없음
- [i] hamann2026 · holzer2013 · islam2026 | 해당 없음 | — | — | —


### [batch_17] i. 복합 양극 (AM + SE) 의 압력별 기공

AM + SE 복합의 **압력별** 기공 곡선 = **0**. 한 압력에서의 **조성별** 기공이 ketter2025 에 있다. 압력별 세 점은 SE 가 없는 LIB 전극 (landesfeind2016) 것이다.

- [i] ketter2025_resistor_network_models_predict_transport_properties | NCM83 + LPSCl 복합 펠릿 (탄소 · 바인더 없음) 의 조성별 기공 — 한 조건 (370 MPa 선압 → 등방 500 MPa 60 min): 15.62 / 21.16 / 22.42 / 25.33 % @ φ_NCM 20 / 40 / 60 / 80 vol% (= w_NCM 39 / 63 / 79 / 91 wt%) · 양 끝 순수상 12.13 % (LPSCl) · 29.24 % (NCM83) | §3-3 L102–107 · §4-5 L187 · SD `FigS18a` | SD (측정 · 3 회) | 압력별 곡선 아님 · 뺀 뒤 · 크기 계층 반대 (LPSCl 20 µm ≫ NCM 2 µm) · ρ_theo 1.86 / 4.78 기준 (랩 표준과 다른 문헌 값) · 카드: "porosity 매핑은 LFA 펠릿만 가능" (L292)
- [i] ketter2025_resistor_network_models_predict_transport_properties | 카드의 조성 환산: AM 70 / 75 / 80 / 82 wt% ↔ φ_NCM 47.6 / 53.9 / 60.9 / 63.9 vol% (2 원계 · 밀도 1.86 / 4.78) | §7-5 L290 | derived(ours) | 환산일 뿐 그 조성의 실측 기공은 없음
- [i] landesfeind2016_tortuosity_eis_electrodes_separators | (ASSB 아님 · LIB 전극) LFP-highC (LFP : PVDF : 탄소 = 70 : 15 : 15) 를 50 / 150 / 400 MPa 로 누른 뒤 기공률 0.49 / 0.34 / 0.27 (질량 수지 · 뺀 뒤) | §5-7 L291–293 · §9 ⑫ L443 · Fig 12 | 표지 없음 | SE 가 없는 액체계 전극 — 카드: "수치 전이 불가" · 세 점
- [i] kim2026_pregranulation_ptfe_dry_nca_cathode_crack_delithiation | (ASSB 아님 · LIB 건식 전극) NCA : 탄소 : PTFE = 96 : 1.8 : 2.2 · 144 µm · 복합 밀도 3.3–3.4 g/cm³ · 기공률 0.305 (기존) / 0.333 (과립화) — 캘린더링 압력 값 · 기공 측정법 [미확인] | §3-1 L73 · §3-4 L111 · 표 S2 | [인쇄] · [미확인] | 압력 축 없음 · SE 없음
- [i] kato2018_thick_electrode_assb_cycle_tortuosity | 기공을 재지 않음 — ε · 용량 밀도 · 두께가 모두 기공 0 명목 (500 MPa 압밀) · SEM 에서 void · crack 은 정성 | §3-2 L91 · §3-3 L107 · §6 L288 | stated · 우리 산술 (명목값 재현) | 기공 값 0
- [i] kim2024 · jung2023 | 기공 값 없음 (kim2024 의 30.0 → 13.9 vol% 는 SE 의 상 부피분율이지 기공이 아님 L191 · jung2023 은 437 MPa 제조만 L34) | — | — | —
- [i] kim2026_a3d | 해당 없음 (금속 골격 공기극의 설계 기공 45.6–56.9 %) | — | — | —


### [batch_18] i. 복합 양극 (AM + SE) 의 압력별 기공

AM + SE 복합의 **압력별** 기공 곡선 = **0**. **한 압력 한 점씩** 이 두 카드에 있다 (360 MPa · 370 MPa).

- [i] nakamura2020_dry_coating_ncm_li3ps4_core_shell | NCM111 : Li₃PS₄ = 86.9 : 13.1 wt% (도전재 · 바인더 없음) · 일축 360 MPa. FIB-SEM 부피분율 — 코팅: NCM 63.02 · LPS 20.44 · NCM 사이 공극 12.19 · NCM 안 공극 4.35 % / 막자 혼합: 62.42 · 21.65 · 12.01 · 3.91 % → 총 공극 16.5 / 15.9 % · SE ÷ 고체 24.5 / 25.8 vol% · 본문의 복합 밀도 3387 kg/m³ | §3-6 L126–136 · Table 1a · p.7–8 | [인쇄] · [우리 산술] (총 공극 · SE 몫) · [미확인] (밀도 산출 근거) | 한 압력 · 50 회 사이클 · 완전 방전 뒤 분해한 시료 (뺀 뒤 · 사이클 영향 포함 가능) · 20 µm 정육면체 1 개 · 회색조 분할 (오차 미확인) · Li₃PS₄ 유리 · NCM111 단봉 4.7 µm
- [i] lee2026_unveiling_ptfe_dry_electrode_digital_twin | NCM (Ni 0.7 · D50 7 µm) : LPSCl (D50 1 µm) : VGCF = 85 : 13 : 2 wt% (+ PTFE) · 370 MPa 5 min. 기공 — 밀도 기반 15.4 % (PTFE 0) · 12.6 % (0.2 wt%) ↔ FIB-SEM 재구성 12.9 · 11.9 % · SE ÷ 고체 25.7–27.0 vol% | §3-2 L78–84 · Table S1 · SI p.17 | [인쇄] · [우리 산술] (SE 몫 · 차) | 한 압력 · LPSCl 1.86 g/cm³ 로 계산 (랩 표준과 다른 문헌 값) · 재구성 1 개씩 · PTFE 는 분할 안 됨 · 누른 채인지 뺀 뒤인지는 "가압 뒤" 로만 (L87)
- [i] lee2026_unveiling_ptfe_dry_electrode_digital_twin | 같은 조성 · PTFE 함량별 상대밀도 84.6 / 87.4 / 86.8 / 82.5 % (0 / 0.2 / 0.5 / 1.0 wt%) → 기공 15.4 / 12.6 / 13.2 / 17.5 % (내 검산: 100 − 상대밀도 · 앞 두 값은 Table S1 과 같음) | §3-7 L163–166 · Table S2 | [인쇄] · 내 검산 | 측정 압력 · 시료 수 [미확인] · 1.86 기준
- [i] lee2026_unveiling_ptfe_dry_electrode_digital_twin | 후막 (PTFE 0.2 wt%): 25 / 35 / 45 mg/cm² → 두께 78 / 109 / 139 µm → 겉보기 밀도 3.21 / 3.21 / 3.24 g/cm³ · 상대밀도 0.87 / 0.87 / 0.88 | §3-11 L205–209 · p.11 · Fig 6a–c | [인쇄] (로딩 · 두께) · [우리 산술] (밀도) | 두께를 잰 상태 (누른 채 / 뺀 뒤) 는 카드에 없음 · 로딩이 달라도 밀도가 거의 같다는 한 줄
- [i] matthews2024_ptfe_nanofibril_network | porosity · 밀도 · tortuosity 가 한 번도 나오지 않음 (LIB 건식 전극 100–110 µm · 30–32 mg/cm²) | §8 L462 · §3.3 L156 | n/a | SE 없는 액체계
- [i] landesfeind2018 · malifarge2017 · morasch2018 | (ASSB 아님) 액체 LIB 전극의 다공도만: Custom Cells 전극 40–51 % (landesfeind2018 Table II) · 판상 흑연 ≈ 10–44 % (malifarge2017 · 판독) · 미압축 흑연 ~55 % (morasch2018) — 누른 압력 값은 세 카드 모두 없음 | landesfeind2018 L72–74 · malifarge2017 L126 · morasch2018 L68 | stated · 판독 | SE 없음 — 수치 전이 불가
- [i] nguyen2020 | 해당 없음 (합성 구조) | — | — | —


### [batch_19] i. 복합 양극 (AM + SE) 의 압력별 기공

이 배치에 없음 (AM + 황화물 SE 복합 양극의 압력별 기공을 준 카드 없음).
- [i] sangros2020_dem_electrical_conductive_paths_assb (가장 가까운 것) | 폴리머 SSB 양극 (LFP + CB + PEO-LiTFSI): 캘린더 뒤 실측 porosity ≈ 0; DEM 의 'porosity' 로 쓴 전해질 함량 60.00 / 48.80 / 48.80 / 47.20 / 46.6 % (CB 0 / 0.5 / 2 / 3.7 / 5.2 wt%) | §3 L29–30 · Table 4 | stated | 압력별 아님 · 전해질 = 폴리머 (공극 취급)


### [batch_20] i. 복합 양극 (AM + SE) 의 압력별 기공

이 배치에 없음 (AM + SE 카드 없음 · 압력 축 카드 없음). 참고 (AM + 탄소 · 바인더 · 액체 LIB · 압력 아님):
- [i] vijay2025_hybrid_cgmd_dl_slurry_microstructure | NMC-111 (LIB) 압연 DEM 기공: 압연도 0 / 15 / 20 / 25 / 30 % → 53.53 / 49.65 / 47.14 / 44.50 / 41.14 % (CGMD 8 시드 평균) | Table 9 · L139–143 | stated | 두께 감소율 축 (압력 0 건) · 누른 채 / 뺀 뒤 카드에 없음 · ASSB 기공 0 건 (L18)
- [i] wang2027_ncm811_effective_bulk_modulus_mapper_dfs_gnn | 캘린더된 NCM811 LIB 양극 기공 참밀도 21.9 · 수은 20.7 · 재구성 20.3 % (한 상태) | 표 5 · L104 | [인쇄] | 캘린더 조건 [미확인] · 압력 없음
- [i] yoo2026_porosity_gradient_dry_electrode | 흑연 음극 MIP 32.2–33.3 % @ 전극 밀도 1.5 g/cm³ · VED 계산 (Fig S26) 밀도 1.5 → 1.7 g/cm³ 에 기공 28.6 → 19.1 % | §4.1 L128 · §4.5 L258 · L320 | 표지 없음 | 흑연 음극 · 압력 없음 · 밀도 1.5 의 두 기공 값 (카드 문제 8)
- [i] zhang2026_dryprocess_electrode_architecture_cell_level | 건식 NMC811 후막 목표 기공 ~30 % (실측 n/a) · 카드 유도 전극 두께 91.4–105.0 µm · 밀도 3.07–3.34 g/cm³ (ε 30 % · ρ 가정) | §2-1 L166 · §2-4 L209–214 | stated / derived(ours) | 캘린더 압력 n/a · 기공 실측 없음


### [batch_21] i. 복합 양극 (AM + SE) 의 압력별 기공

- [i] cho2024_conflicting_roles_conductive_additive | NCM811 + LPSCl (+ VGCF 2 wt%) · 433 MPa 적층: 기공 0.14 (f_AM 72 wt% · CA 없음) · 0.15 (CA 있음) · 0.18 (88 wt% · 없음) · 0.19 (있음) | Table S2 · §3 L121–122 · §6.4 L329–332 | stated | 압력 한 점 · 측정법 · 누른 채인지 (작동 stack 250 MPa) 카드에 없음 · 카드 환산 72 wt% ≈ φ_SE 0.45 · 88 wt% ≈ 0.15–0.20 (§12 L497–498 · 카드 어림)
- [i] duquesnoy2023_ml_multiobjective_manufacturing_optimization | (AM + SE 아님 · LIB NMC111 + CBD) 실험 기공 60 ± 3 % (비압연) → 29 ± 0.7 % (압연 30 %) · Liu 2023 3×3 예: AM 90 % · CD 0 / 10 / 20 % → 53.03 / 49.835 / 42.145 % | Table 4 L94 · SI Table S3 L105–107 | stated | 압력 아닌 두께 감소율 축 · 액체 LIB
- [i] bak2024_binder_distribution_multilayer | (AM + SE 아님 · LIB NCM622 + 탄소 + PVDF) 비캘린더 모델 전극 기공 34–37 vol% · Ref 39 vol% (표면 쪽 ↑) · 깊이 표준편차 3.1 | SI Fig S6 · §7(d) L414 | 표지 없음 | 압력 축 없음 · 캘린더 (3.0 g/cm³) 뒤 기공은 카드에 없음
- [i] frankenberg2024_dem_high_intensity_mixer_assb | 셀을 380 MPa 로 조립했으나 기공 미산출 | §3 L58 · L62 | stated | —


### [batch_22] i. 복합 양극 (AM + SE) 의 압력별 기공

압력별 곡선은 없고 한 압력 점 둘:
- [i] hippauf2019_dry_film_ptfe_sulfide_cathode_sheet | NCM90 (LZO) : VG-CNF : Li₆PS₅Cl = 85:2:13 wt% + PTFE 0.3 wt% · 300 MPa 뒤 ≈100 µm · 3.45 g/cm³ = 계산 기공 ≈12 % (이론 밀도 SI 식 S1 · 치밀 ≈3.92 g/cm³ → 12.0 %) · 압축 전 압연 막 ≈50 % | §3-2 L81–84 · p.3 · p.5 | [인쇄] · [우리 산술] | 압력 한 점 · 입경 [미확인] · 기공 = 측정 밀도 ↔ 이론 밀도 계산 (직접 측정 아님) · 하중 중 / 뺀 뒤 명시 없음 · ρ_SE 1.9 (랩 표준과 다른 문헌 값) · SE 13 wt%
- [i] hong2026_sulfide_cathode_binder_digitaltwin | NCM : LPSCl : Super C = 75 : 23.5 : 1.5 (Pwd) · 75 : 22.5 : 1.5 + PTFE 1 (PTFE) wt% · 350 MPa 조립 → pore volume Pwd 28.7 · NBR 29.4 · PTFE 22.3 vol% · 디지털트윈 AM 36–41 vol% | §2.2 L92–98 · §4.2 L227–238 · §7(a) L446 · Fig 2f · S15 | 표지 없음 | 재구성값 (측정 porosity 매칭 · 측정법 · 하중 상태 카드에 없음) · 활물질 mass loading 30 mg/cm² · Pwd 상별 부피분율 합과 pore 가 안 맞음 (카드 문제 11)
- [i] galvezaranda2025_paml_vgg16_dem_slurry_drying | 절대 porosity 값 없음 (오직 % 오차) · 액체 LIB 건조 · 압력 축 없음 | §0 L35 · §10-③ L601 | 카드 풀이 | —
- [i] han2025_icep_conductive_elastic_binder | porosity · 캘린더링 · 조성비 = 본문 없음 (SI) · 전극 두께 ≈230 / 190 µm 의 로딩 짝 미기재 → 밀도 · porosity 도출 불가 | §3c L65–67 | stated | 액체 LIB


### [batch_23] i. 복합 양극 (AM + SE) 의 압력별 기공

AM + SE 복합의 압력별 기공 값은 이 배치에 없음. 관련만:
- [i] kawaguchi2023_doe_electrode_fabrication_dry_coated_ncm_lps | NCM111 + Li₃PS₄ (무탄소) · 180 → 360 MPa — 단순 혼합 Xs 0.3 에서 LPS 영역 미세공극 (흰 화살표) 이 360 MPa 에서 거의 사라짐 (LPS 소성 · 합체 → Rs ↓) · 공극률 미측정 | §3-7 L144 · Fig 5c,d · §0 ④ L30 | [인쇄] (SEM 정성) | 기공 값 없음 · 조건마다 셀 1 개
- [i] kawaguchi2017_dry_coating_parametric_na2so4_model_se | NCM111 + Na₂SO₄ (모델) 90:10 압분체 360 MPa 단면 — NCM 이 응집 없이 기지에 흩어지고 계면 접촉 형성 | §3-7 L112 · Fig 7e,f | [인쇄] (정성) | 모델 물질 · 기공 값 없음
- [i] kang2025_bollard_anchored_binder_dry_electrode | LIB 양극 NMC622 : Super P : 바인더 93:5:2 · 3.0 g/cm³ 에서 25.90 / 19.47 / 17.68 % (PC_PTFE73 / PTFE / PVdF) = tap density 가정 계산 · 명시 입력 재계산 28.1 / 21.7 / 19.9 % (+2.2 %p) · 순위 · 격차만 | §3c L114–115 · §6.3 L569–582 · Table S3 | 표 · 카드 재계산 (표지 없음) | SE 없음 · 압력 축 없음 (밀도 정지) · 측정 아님
- [i] kang2026_multiscale_inverse_design_ptfe_fibrillation_dry_electrode | SiO₂ : CB : PTFE 90:5:5 자립막 MIP 공극 37.2 / 32.2 / 46.7 % (20 / 10 / 1.5 µm) · 32.2 / 29.9 / 36.1 % (10+10 / 10+5 / 10+1.5) — 캘린더 압력 · 두께 · 밀도 미기재 | §3-3 L124 · §3-4 L134 · §10-24 L365 | [인쇄 그림] | SE 없음 · 압력 없음
- [i] kim2026_charge_engineered_cnf_binder | NCM811 LIB 전극 기공률 c-CNF 30.9 vs PVDF 29.7 % (120 °C roll-press · 압력 값 없음) | §4.3 L230 · §2.3 L113 | 표지 없음 | SE 없음 · 압력 없음
- jeong2025 · jun2026: 기공 값 없음.


### [batch_24] i. 복합 양극 (AM + SE) 의 압력별 기공

이 배치에 없음 (AM + SE 복합의 압력별 기공을 잰 카드 없음). 관련만:
- [i] lee2024_shear_force_dry_process_cathode_coverage | NMC532 : LPSCl : SP = 80 : 18.5 : 1.5 (펠릿) · 80 : 17 : 1.5 : 1.5 (습식 · 건식) 전극을 LPSCl 분리막 위에서 7 TON (⌀13 mm → 517 MPa) 가압 — 전극 두께 · 공극률 · 밀도 미확인 | §3-1 L65 · L70–71 · L76 | [인쇄] · [우리 산술] (MPa) · [미확인] (공극률) | 기공값 없음
- [i] lee2025_corolling_dryprocess_lpscl_ptfe | 양극 CAM : SSE : VGCF : PTFE = 80 : 17 : 3 : 0.5 · 두께 120 µm · 31.4 mg/cm² · 제조 500 MPa — 정량 기공 n/a | §2 L23 · §3 L48 · §4 L61 | stated · n/a | 기공값 없음
- 참고 (AM + SE 아님 · 압력 축 없음 · 비교 대상 아님): 액체 LIB 전극 기공 koo2026 Table S3 22.3 / 22.6 / 18.8 / 16.1 % (밀도 기반 · L805–808) · koo2025 MIP 0.14 / 0.083 ↔ 토모 14.84 / 13.47 % (L187 · L204) · lee2025_dual Hg 27.4 / 27.1 % (L150).


### [batch_25] i. 복합 양극 (AM + SE) 의 압력별 기공

이 배치에 없음 (AM + SE 복합 양극의 압력별 기공 없음). 관련만:
- [i] mun2025_dry_electrode_technology_assb_review | ASSB 양극 1 행: NCM811 + LPSCl 13 wt% + Super-P + PTFE + LiPO₂F₂ · 156.8 µm · 57.5 mg/cm² · 10.0 mAh/cm² — 기공 · 압력 카드에 없음 | §3c L61 · Table 1 · Fig 5e · 원전 ref [69] | 리뷰 인용 stated | 조성 합이 100 이 아님 (카드 문제)
- [i] mun2025_dry_electrode_technology_assb_review | LFP + holey graphene (binderless · LIB) 두께 340 µm @20 MPa → 175 @200 → 160 µm @500 MPa (압력 ↑ → 두께 ↓) | §B ⑤ L192 · Fig 5d · 원전 ref [68] | 리뷰 인용 · 표지 없음 | LIB · 두께 (기공 아님) · 카드 안 라벨 두 갈래 (카드 문제)
- [i] liu2025_dry_processing_high_energy_li_batteries_review | ASSB 양극 Table 3 = 조성 · 로딩 · 사이클 (기공 없음) · LIB 상용 양극 porosity 9–32 % (전해질이 차는 공극 · 위상 반대) · Tesla 4680 양극 porosity n/a (카드 추정 ~10–13 %) | §3 (나) L55–62 · (다) L64–72 | 2 차 인용 · 카드 추정 | LIB porosity 는 기공 기준 비교에 쓰지 말 것 (L185)
- [i] lippke2023_dem_drying_structure_formation_lib | 습식 LIB NCM622 전극 (압연 전) 최종 ε ≈41–43 % · 밀도 ≈2.45–2.5 g/cm³ | §3-F L172 · §3-E L154–159 | derived(ours) (ρ_PVDF 가정 의존) · digitized | 압력 없음 · 카드 §0 = 우리 침대 비교 앵커 금지 (L23–26)


### [batch_26] i. 복합 양극 (AM + SE) 의 압력별 기공

이 배치에 없음 (AM + SE 를 압력 축으로 잰 카드 없음).
- (가까운 것) [i] qin2026_bilayer_cathode_cgmd_dem_graded_thick_electrode | NMC111 + CBD 전체 공극률 vs 잔류 압축도 (c0 → c40): 94:6 단층 0.546 → 0.293 · 96:4 단층 0.474 → 0.209 · 이중층 ≈0.515 → ≈0.255–0.261 | §3.2(a) 줄 131–143 (Fig 4a) | figure-read ≈ | 압력 아님 (명목 두께감소) · SE 아님 (CBD) · 제하 뒤 · 공극률 계산법 미기재 · 값 전이 금지 (카드 §8.C-4)
- (가까운 것) [i] nam2026_primer_layer_dry_electrode_collector | DT 모델 조성 NCM622 73.0 vol% · CBD 3.4 vol% · 공극 23.6 % (조성 · 밀도 · 로딩 역산 이론값) | §9 표 줄 552 · SI-6 줄 802 | SI stated · 계산값 | 측정 아님 · 압력 없음 · LIB


### [batch_27] i. 복합 양극 (AM + SE) 의 압력별 기공

- [i] wolf2026_extruder_vs_batch_mixing_core_shell_dry_sulfide_cathode | NCM85 82 : LPSCl 15.5 : C65 2 : PTFE 0.5 wt% 건식 막 — 683 MPa 막 공극 16.1 (압출) · 16.3 % (배치) · φ_SE 25.8 vol%; 800 MPa 5 min 반쪽셀 양극 공극 12.6 ± 3.0 · 10.8 ± 2.4 % · 밀도 3.23 · 3.30 g/cm³; 캘린더 닙 공극 ≈52 % (카드 산술 · 롤 간격 = 닙 막 두께 가정) | §0 ⑤ 줄 34 · §3-6 줄 135 · §3-7 줄 151 · §3-5 줄 127 | [인쇄] · [우리 산술] | 측정 시 압력 상태 (누른 채 / 뺀 뒤) 카드에 없음 · 공극 = 대표 시료 하나 · φ_SE 식 S3 [미확인] · 탄소 · PTFE 포함
- [i] wang2026_dryprocess_thick_cathode_failure_ncm94 | 압력 한 점 (조립 ≈500 MPa · DERIVED) — ε 는 세 가정 (비용량 · ρ_SE · 사이클 뒤 두께 ≈ 가압 뒤 두께) 으로 유도: 미가압 막 34.5–41.1 % · 사이클 뒤 8.6–17.8 % (127.1 µm) · 16.4–24.8 % (138.9 µm) — 카드 '앵커로 쓰지 말 것'; 가정 무관 두께 감소 −21.7…−28.3 % (500 MPa 성형 + 300 사이클 합) | §2.3 줄 116–124 · §13.1 줄 608–613 | DERIVED(ours) | Cl-rich SE · NCM94 · 기공 직접 측정 없음 · 다이 지름 가정
- [i] wet_processing_resolved_am_ssb_cathode_manufacturing | 압력 축 없음 — 압연도 0 → 45 % 에서 기공 0.578 → 0.291 (10 점 · 0.05 간격 · 가속형 곡선 = 카드: 소성 부재의 서명) · 건조 (미압연) 기공 실험 0.53 ± 0.03 · 시뮬 0.57 ± 0.01 | §③-C ③ 줄 487 · §3 줄 53 | digitized · stated | 압연도 ≠ 압력 · 습식 · CBD 포함 · 카드 'Heckel 과 직접 겹치기 금지'
- [i] schmitt2026_chemomech_stability_dry_cathode_separator_sheets | 복합 양극 기공 · 밀도 측정 없음 — 저자 *"quantification of the pore structure in situ is very difficult and has not yet been performed"* · sheet-sheet 셀은 잔류 기공이 더 많을 것 (측정 아님) | §0 ⑦ 줄 35 · §3-2 줄 79 | [인쇄] p.7 · p.10 | 펠릿 437 MPa ↔ 시트 선압 3 N/mm


### [batch_28] i. 복합 양극 (AM + SE) 의 압력별 기공

- [i] interfacial_impedance_formulation_assb_cathode | Cl-rich LPSC + NCM90 (ε_i 0.58): IP-P 500 MPa eps_pore 0.046 · UP-C 가 가장 높음 (값 카드에 없음) · bimodal NCA-b-12 (500 MPa 풀셀) 0.11 · SE 분율 스윕 eps_pore 0.16 → 0.23 (압력 카드에 없음) | §3 줄 94 · 99 · 107 · §5.3 줄 215 (Fig 4d · 3b · 6e) | stated | 뺀 뒤 펠릿 · 정의 = (펠릿 − 성분)/펠릿 · 압력 축 수치는 점 하나 · 조성 다름
- [i] kang2025_toughened_bimodal_nca_lzo | NCA : LPSCl : SP 72:27:1 · 0.15 g · 10 mm · 400 MPa 펠릿 두께 U 0.74 · B 0.68 · LZO-B 0.67 mm · 부피 로딩 ~1.87 vs ~2.02 (1.1×) — 기공률 미보고 | §3 줄 63–64 · Fig S2 줄 214 | stated (표지 충돌 — 카드 문제) | 기공 아님 · 단위 표기 둘
- [i] dem_mechanical_stresses_ssb_electrode_cycling | NMC532 + LPSCl DEM 두께만: 84 (375 MPa) → 95 (1 atm) → 125 µm (등방 · xy 130 µm) · 기공 미보고 | §3.1 줄 65–67 · §3.6 줄 122 | digitized | 시뮬 · 두께 ≠ 기공
- (가까운 것) [i] gandla2026_layered_cathode_degradation_diagnostics_review | NMC/LPS 복합 공극 < 3 → 9.5 % (50 사이클 · FIB-SEM [60]) · 표 5 의 압력 범주 (제작 수십–수백 · operando 수십 · 실용 ≤ 2 MPa) | §3-5 줄 118 · §3-10 표 줄 183 | [인쇄] | 압력 축 아님 · 2 차 인용


### [batch_29] i. 복합 양극 (AM + SE) 의 압력별 기공

- [i] so2021_dem_fabrication_degradation_ductile_particles | Si 음극 복합 (Si AM + LPS 유리 SE · φ_AM^rel 0.4) 2D DEM: SOC24 사이클 중 기공 Pfab 100 → 0.22 · 200 → 0.155 · 500 → 0.06 (Fig 8d) · Pfab 100 사이클 기공 SOC8 0.12↔0.145 · SOC16 0.155↔0.185 · SOC24 0.18↔0.21 (Fig 8c) · "higher Pfab → lower porosity" | §3.3 L86–87 · §5.7 L204 | digitized · stated (방향) | 제조 직후 기공 수치는 카드에 없음 (Fig 5 SE 부피분율 색 0.5–1.0 만) · 사이클 중 값 · 양극 아님 · Pfab 100 · SOC24 값이 두 그림에서 엇갈림 (카드 문제)
- [i] li2026_electrochemomechanical_coupling_asslmb_review | Jeong 2024 (AEM · XCT): 작은 LPSC 복합 양극 공극 ≈11 vol % ↔ 큰 LPSC 16 vol % · 임계압 ≈400 MPa 위에서는 두 전극 응답 비슷 (공극 붕괴) · 0.1C 유지율 94.26 vs 47.33 % | §3-3 L72 · 리뷰 p.36 | [인쇄] | 2 차 인용 · 원 논문 정본 카드 없음 (L135) · 성형압 · 측정 상태 · AM 종류 카드에 없음
- [i] li2026_electrochemomechanical_coupling_asslmb_review | Oh 2026: 큰 다결정 NCWA + 작은 단결정 NCM + LPSC 바이모달이 단봉 대비 공극 35–58 % 낮음 · 큰 PC : 작은 SC 7:3 최적 · 정본 oh2026 카드의 "2D 공극" 16.80 → 7.55 → 17.96 | §3-3 L74 | [인쇄 p.46] · [우리 대조] | 압력 카드에 없음 · "2D 공극" 의 정의 (단면?) 카드에 없음
- [i] li2026_electrochemomechanical_coupling_asslmb_review | Farzanian [50] (2D 연속체): 양극 > 50 vol % 면 전극 팽창 > 5 % · 공극 > 1 % | §3-3 L65 | [인쇄 p.8] | 사이클 부피변화 결과 · 압축 기공 아님 · 2D
- [i] kim2025_impedance_decoupling_tlm_assb | 기공 미측정 — 같은 분말 40 mg · ⌀10 mm · 250 MPa 대칭셀 두께만: LNO 코팅 62 / 72 / 82 wt% = 190 / 180 / 160 µm · 비코팅 210 / 230 / 210 · LZC 170 µm (카드: "CAM↑ → 두께↓ (densification, 같은 분말질량)") | §3 L113 · §4.5 L194 · L88–92 | stated (Table S3 · S5) | 카드가 기공을 계산하지 않음 · 두께 측정 상태 카드에 없음
- 나머지: 없음.


### [batch_30] i — 복합 양극 (AM + SE) 압력별 기공

- [i] 이 배치에 압력별 복합 양극 기공 곡선 없음.
- [i] lee2023_sicspe_digitaltwin_assb | LPSCl 복합 양극 (NMC711:LPSCl:Super P:NBR = 76.8:19.2:2:2 wt%) 500 MPa 재압착 1조건 — 전극밀도 2.81 g/cm³ · 두께 58 µm · 로딩 16.3 mg/cm² · 디지털트윈 SE 26.1 vol% · 기공률 값은 카드에 없음 | §2.2–2.3 (줄 92–104) · §4.3 (줄 178–183) | 표지 없음 | 단일 압력 · 전극 1개 · 누른 채인지 뺀 뒤인지 카드에 없음
- [i] park2020_digitaltwin_assb_foundational | 압력 sweep 없음 · 기공 미보고 (전극밀도 2.5–2.6 g/cm³ · NCM 입자 기공 32.7 % 만); 설계 vol% 합 88.0 / 80.2 / 71.7 / 63.7 % (NCM 60/70/80/90 wt%) → 남는 12.0 / 19.8 / 28.3 / 36.3 % 에 원문은 이름을 붙이지 않음 · 반쪽셀 370 MPa 성형 | §2 (줄 186–188 · 206 · 209–213) · §10(5) (줄 801–802) | (우리 산술) · [미확인] | 공극으로 단정 불가 · 입자 기공 32.7 % 까지 넣으면 60 wt% 합이 100 % 를 넘음 (카드)


### [batch_31] i — 복합 양극 (AM + SE) 의 압력별 기공

- [i] 이 배치에 없음.


### [batch_32] i — 복합 양극 (AM + SE) 압력별 기공

- [i] 압력별 복합 양극 기공은 이 배치에 없음.
- [i] huang2025_dem_lbm_heat_conduction_composite_cathode | LCO + LLZO (DEM) 기공 4.4 / 8.1 / 15.1 / 21.1 / 31.2 % — 압력이 아니라 압밀 깊이로 조절 · CAM:SE 체적비 1:1 · 4:1 · 1:4 · CAM vol% 30–70 % 스윕은 기공 7 % 고정 | §3 (줄 33–34) · Table 4 · 5 · Fig 14 | stated | 산화물 · 압력값 없음 · 모형 값
- [i] hong2026_cbd_viscoelasticity_springback | NCMA + CBD 전극 밀도 3.1 · 3.3 · 3.5 g/cm³ (3.7 은 입자 균열) — roll gap 으로 조절 · 기공률 · 압력값 없음 | §4.1 (줄 165–176) · Fig 2 · S1 | 표지 없음 | 액체 LIB · SE 없음


### [batch_33] i — 복합 양극 압력별 기공

이 배치에 없음 — 복합 양극 실험 넷 (jung2019 · kaiser2018 · kim2025 · kim2026) 모두 복합체 기공률을 재지 않거나 보고하지 않음 (jung §3-1 줄 77 · kaiser ε = 기공 0 고체 기준 SI p.2–4 · kim2025 기공 수치 없음 · kim2026 §3-1 [미확인]).


### [batch_34] i — 복합 양극 (AM + SE) 의 압력별 기공

- [i] luan2025_graded_cathode_400whkg_pouch | NCM88 + LPSC + Super P 양극 단축 300 MPa (코인) · 파우치 등방 500 MPa — 기공 · 밀도 · 두께 미보고 ("논문이 어디에도 안 준다") · 두께 그림 SI Fig S6b 는 미보유 | §3-1 L73 · L76 · L81 · §7-A L427–428 · SI 절 L654 | stated | 대조 값 없음
- [i] minnmann2022_designing_cathodes_solidstate | 카드가 남의 값 언급: Minnmann 2021 JES — NCM622 + LPSCl · 건식 단축 cold-press 380 MPa · 평균 14 % (범위는 본문 13–17 % ↔ 10-03 정정 7.6–17 % — 카드 문제 4) · EIS-TLM | §0 L44–48 · §6 L291–293 · L434 | 표지 없음 (출처 정정표) | 2 차 인용 (정본 카드 minnmann2021_jes_charge_transport_bottlenecks 있음) · 380 ≠ 300 MPa


### [batch_35] i — 복합 양극 (AM + SE) 의 압력별 기공

- [i] otani2023 | NCM523 + LPSCl 막자 혼합 · SE 54 / 35 / 21 / 10 vol% (고체 기준) · 같은 압력 열 (0.4 → 6.0 tf/cm²) 재측정 → 공극 범위 54 %: 8.1–33.5 % · 35 %: 7.2–31.0 % · 21 %: 8.9–36.3 % · 10 %: 11.8–12.4 % (σ 와 짝 · **압력 ↔ 공극 짝은 카드에 없음**) · 공극 = 두께 + 두 재료 밀도 (전체 부피 기준) | §3-1 (줄 62–63) · §3-4 표 (줄 92–95) · Fig 6 | [인쇄] (조성 · 방법) · [판독] (점) | 복합의 구속 여부 명시 없음 · 바이모달 아님 · 데이터 기밀
- [i] pan2026 (참고 · SE 없음) | 액체 LIB NCM811 롤 프레스 압축률 0/20/40 % → CT 거대 기공 38/35/30 % · 같은 두께 질량 수지로는 6.5 % → CT 기공 ≠ 총 기공 | §3-1-3 (줄 89–91) · §10-1-1 (줄 414) | [인쇄] · [우리 산술] | 압력 미기재 · ASSB 아님


### [batch_36] i — 복합 양극 (AM + SE) 의 압력별 기공

이 배치에 없음.  (zhang2023 의 압연 후 공극 25 % (Methods) · 29 % (세그멘테이션) 는 SE 없는 액체계 양극이고 압연압 미보고 — 줄 85 · 94.  wang2018 §8-3 줄 402–403 이 다른 카드 bazzoun2026 의 400 MPa 복합 양극을 인용하지만 σ_eff,ion 이지 기공이 아니다.)


### [batch_37] i — 복합 양극 (AM + SE) 의 압력별 기공

복합 양극 기공 값 = 0.  성형 조건과 조성 창만:

- [i] calpa2019 | LiNbO₃-NCM111 : Li₇P₃S₁₁ : VGCF = 79:19:2 wt% 복합양극 10 mg + 분리막 80 mg 을 ⌀10 mm 로 360 MPa 실온 성형 → In 240 MPa 부착 · 셀 구속압 미기재 — 복합체 기공 · 밀도 · 두께 값 없음 | §3c 줄 83–88 · §4 줄 141 | stated (조건) | 다른 재료 · 한 압력
- [i] cao2026 | 펠릿형 셀 전극 370 MPa 3 min · 운전 75 MPa / 시트 전극 LCO (또는 NCM721) : LPSCl = 7:3 + PTFE 0.2 wt% 롤압 — 전극 기공 값 없음 | §4c–d 줄 167–172 | 본문 (SI) 값 · 표지 없음 | —
- [i] famprikis2019 | 기공 아님 — 조성 창: 복합양극 SE 부피분율 ≤50 % (에너지밀도 · 전자 percolation) · ≥25 % (이온 percolation) · 문턱은 입도 분포의 함수 (ref 68 = Bielefeld 2019 · litdb 카드 있음) | §4.4 줄 125–127 · §5.2(e) 줄 213–214 | 소환값 (단일 출처 재인용) | 압력 · 기공 없음


### [batch_38] i — 복합 양극 (AM + SE) 의 압력별 기공

복합 양극 기공 값 = 0.  성형 조건만:

- [i] tron2023 | s-NMC811 + sp-LPSCl + C65 복합 양극 (AM:SE 70:30 → 90:10 wt% · 로딩 1 mAh/cm² ≈ 9–10 mg/cm²) 을 같은 300 MPa · 5 min 으로 성형 — 기공 · 밀도 · 두께 · 단면 측정 없음 (용량 · EIS 만) | §3c 줄 82–83 · §4 줄 155 · §10-7 줄 253 | stated (조건) · 카드 지적 (없음) | 압력 한 값
- [i] liu2024 | SC-Ni90 : LPSC : VGCF = 50:45:5 wt% 양극을 1000 MPa · 2 min 성형 — 공극률 · 두께 [미확인] · 초후막 (CAM 38.20–76.39 mg/cm²) 두께도 [미확인] (카드의 조건부 산술: 고체만 ≥0.42 mm — 덱 밀도 4.8 · 2.0 g/cm³ 가정) | §0 ⑨ 줄 32 · §3-1 줄 62–65 | [인쇄] (조건) · [미확인] · [우리 산술] | 압력 한 값 · 조성은 로딩 숫자에서 역산한 추론 (§10-12)
- [i] kim2012 (참고 · SE 없음 · 액체 전지 전극) | 상용 LCO vs NCA: 압연 뒤 전극 밀도 3.93 vs 3.32 · 3.38 g/cc · 탭 밀도 2.68 vs 2.19 · 2.23 g/cc — 입도 분포가 비슷해도 (d50 15.3 vs 14.9 µm) 전극 밀도 −14.0 % · 탭 밀도 −16.8 % | §3-11 줄 191–197 · SI Table s2 | [인쇄] (표) · [우리 산술] (%) | 압력 미기재 · 황화물 SE 없음


### [batch_39] i. 복합 양극 (AM + SE) 의 압력별 기공

이 배치에 없음 (복합 양극 조성 · 압력 · 기공이 카드에 없음 — 셀은 NMC | LPSCl | Li 금속 40 µm 라는 것만 · §2 L26).


### [batch_40] i — 복합 양극 (AM + SE) 의 압력별 기공

이 배치에 없음.


### [batch_41] i — 복합 양극 (AM + SE) 의 압력별 기공

이 배치에 없음.


### [batch_42] i — 복합 양극 (AM + SE) 의 압력별 기공

보강 없음 (1 상 금속 분말).


### [layer3] i. 복합 양극 (AM + SE) 의 압력별 기공

황화물 복합 양극의 "압력별 곡선" 은 이 절들에 없다 — 한 압력의 한 점들과 액체 LIB 압연 곡선뿐이다.

- [i] minnmann2021_jes_charge_transport_bottlenecks | NCM622 + LPSCl 복합 양극: 압밀 380 MPa → 공극 평균 14 % · 범위 13–17 % (Table SIII) · EIS-TLM 측정은 40 MPa · σ_ion,eff 0.17 mS/cm @ 42 vol% NCM · τ_ion 2.07 = √(τ² = 4.3) | §A L334–344 | "PDF 본문 stated 확인" | 한 압력 (압력별 곡선 아님) · 순수 SE 는 이 논문이 측정 안 함 (L339–340) · 누른 채 / 뺀 뒤 이 줄에 없음 · JES 040537 (refs.bib 의 040502 는 오기 · L343)
- [i] ngandjong2021_dem_calendering_digital_twin | (LIB · SE 없음) NMC111 96 wt% 압연 실측 P → ε: 0 → 42.15 ± 2.00 · 5.92 → 32.09 ± 1.28 · 55.9 → 28.80 ± 0.61 · 86.0 → 26.33 ± 0.80 · 156.0 → 26.23 % · 시뮬 7 점 0 → 41.59 … 155.7 → 27.03 % | §A L181–184 | 실측 0 / 5.92 / 86 과 시뮬 41.6 / 31.5 / 27.2 = stated · 나머지 digitized (추세용) | 액체 LIB · springback 후 값 · porosity 규약 두 겹 미상 (L214–216) · P_max 156 MPa = 300 MPa 의 52 % (post-knee 점 0 개)
- [i] alabdali2023_cgmd_wet_manufacturing_ssb_cathode | 습식 SSB 양극 CGMD: ε–압연도 3 점 35 % (0 %) / 21 % (25 %) / 15 % (50 %) · 두께 46 → 23 µm (Fig 1) — 같은 논문 Fig 3a / 3b 프로파일은 ≈ 63 → ≈ 30 µm (1.37 배 차 · 논문 설명 없음) | §A L509–516 | fig-label | 압력 · 평판 하강속도 없음 · porosity 정의 미보고 · CBD 나노공극 제외 규약 (실험 대조는 다른 규약) · 15 % ↔ 우리 15.6 % 는 "우연" 취급
- [i] xu2023_realistic_am_shape_cgmd_calendering + vijay2025_hybrid_cgmd_dl_slurry_microstructure + qin2026_bilayer_cathode_cgmd_dem_graded_thick_electrode + alabdali2023_cgmd_wet_manufacturing_ssb_cathode | (묶음) 이 계보는 압력축이 없음 — 공정 축 = 두께감소율 (CD / 압축도 %) 뿐 (Xu: 본문 · SI 에 MPa 0 회 · Vijay 압축도 0–30 % 에서 53.53 → 41.14 % · Qin c0–c40) → 300 MPa · Heckel 축과 "원리적으로 겹칠 수 없음" · Xu 의 마지막 구간 기울기가 가파른 채 끝나 floor 판정 불가 | §A L119–134 · L253–257 · L157 · L512–513 | Xu CD 표 = digitized (stated 5 점을 ≤ 0.02 %p 로 재현) | 액체 LIB (Alabdali 만 SSB 습식) · Ngandjong 의 P ↔ ε 를 빌려 CD 에 MPa 를 붙이는 것도 불가 (압연 전 공극 42.15 vs ≈ 47.5 % = 다른 침대 · L136–140)
- [i] duquesnoy2020_calendering_ml_mesostructure_generator | (LIB NMC111) 캘린더 54 셀 + 비캘린더 29 셀 · AM 94–96 wt% · 실측 ε_cal 22.1–36.4 % · 압력은 FlexiForce 로 따로 교정 P = 189·exp(−gap/(0.21·T_uncal)) (Fig. S2) · "~100 MPa 이후 포화" | §A L284–290 | 표지 없음 (회귀식 계수는 코드 정본) | 액체 LIB → ASSB 와 절대비교 금지 · 살아남는 것은 곡선 모양뿐
- [i] luan2025_graded_cathode_400whkg_pouch + lee2025_corolling_dryprocess_lpscl_ptfe + kang2025_toughened_bimodal_nca_lzo | (묶음) 같은 소재계 · 수백 MPa 성형인데 압밀 공극을 주지 않는 세 편: Luan (성형 300 MPa · 등방압 500 MPa 2 min · porosity · 밀도 · 두께 없음) · Lee (500 MPa press · 계면 void 상대비만) · Kang (펠릿 두께 0.74 → 0.68 mm 만) | §A L466–476 · L413–415 · L439–444 | 표지 없음 | 직접 비교 금지 (비교 문서 표기)
- [i] varkey2026_multicontact_elastoplastic_dem | halide (Li₃YBrCl₆) SE: separator floor 21 % / cathode 37 % @ 350 MPa (강체 구 DEM · < 20 % "추구 안 함") | §A L332 · L206 | 표지 없음 | halide (LPSCl 아님) · 계산값
- [i] zhang2026_xct_dem_cathode_calendering_peel_calibration | (LIB · SE 없음) NMC111 + CBD: 30 / 60 / 200 MPa 하중 중 공극률 0.333 / ≈ 0.280 / ≈ 0.152 → 제하 후 0.411 (실험 0.412) / ≈ 0.370 / ≈ 0.319 | §A L881–883 | stated / figure-read | 액체 LIB · 공극률 관례 미기재 · 실험 계열 출처 불명 (자체 측정인지 Ebner 값인지)
- [i] jung2026_sio2_cosubstitution_mechanical_argyrodite | NCM : SE : Super-P 80 : 19 : 1 (SE 펠릿 312 MPa → 양극 적층 후 437 MPa 냉간압 → 조립 6.5 N·m ≈ 65 MPa · 로딩 11.4 mg cm⁻² · SE D₅₀ 1.60 / 1.62 µm): 50 사이클 뒤 전극 내부 공극률 ≈ 16.2 % (LPSCl) → ≈ 8.7 % (Si/O 공치환) · 3D nano-XCT/XRM voxel 0.3 µm · Avizo 분할 | §A L899–920 | Avizo 정량 (컬러바 눈금 없음) | 사이클 후 값 (가압 직후 아님) · 반복수 · 오차막대 없음 · 분리층 SE 도 같이 바뀜 · 비교 문서: "값 대조를 하지 않는다"
- [i] wolf2026_extruder_vs_batch_mixing_core_shell_dry_sulfide_cathode | NCM85 3.8 µm 82 wt% + C65 2 · PTFE 0.5 건식 막: 683 MPa 공극 16.1 / 16.3 % · 800 MPa 12.6 ± 3.0 / 10.8 ± 2.4 % (압출 / 배치) · 캘린더 닙 ≈ 126 µm = 공극 ≈ 52 % | §A L932 | [판독 · 카드 산술] | 누른 채 / 뺀 뒤 · 진밀도 이 줄에 없음 · 두 압력뿐
- [i] benhadjali2026_wip_vs_cup_pressing_assb_cathode_dem | 습식 NMC622 : LPSCl : CBD 69 : 27.6 : 3.4: CUP (≈ 116 MPa · 상온 · 30 s) ↔ WIP (400 MPa 등방 · 80 °C · 5 min) → 게이지 두께 −12 ↔ −26 % · 보고 기공 25.1 ↔ 10.9 % · 표가 함축하는 골격 밀도 2.41–2.47 g/cm³ 은 흔한 결정 밀도로 센 2.99–3.24 보다 25 % 낮음 (그 밀도면 40–44 ↔ 27–32 %) · 같은 논문 안 DEM 기공이 세 값 (보고 26.5 · 15 % ↔ Fig. 6 평균 0.43 · 0.31 ↔ 질량 보존 환산) | §A L934 | 보고값 표지 없음 · 환산 = [카드 산술] · Fig. 6 = [판독] | 압력 ×3.45 · 온도 · 시간 · 하중 방식이 동시에 다름 · 식 (1) 성분 밀도 미공개 · "압밀 앵커로 쓰지 않는다"
- [i] kim2023_mechanofusion_ncm811_lpscl_core_shell_intimate_contact + hippauf2019_dry_film_ptfe_sulfide_cathode_sheet + frankenberg2025_milling_dry_processed_sulfide_cathode_microstructure | (묶음 · 황화물 복합 양극 한 점씩) Kim 2023: 300 MPa 양극 계산 기공 36.6–42.4 % (측정법 미확인) · Hippauf 2019: PTFE 막 300 MPa → ≈ 100 µm · 3.45 g/cm³ (계산 기공 ≈ 12 % · 입경 미확인) · Frankenberg 2025: 같은 조성에서 밀링만으로 기공 37.6 → 26.5 % | §A L926–929 | 표지 없음 / "계산" | 압력별 곡선 아님 · 진밀도 · 누른 채 여부 이 줄에 없음 · 같은 300 MPa 에서 12 % ↔ 36.6–42.4 % 로 흩어짐
- [i] schmitt2026_chemomech_stability_dry_cathode_separator_sheets | 건식 PTFE 양극 시트 (선압 3 N/mm 캘린더) ↔ 437 MPa 펠릿: 기공 · 밀도 · 두께 미측정 (저자 "has not yet been performed") · 제조압 ↔ 적층압 81 MPa ↔ 측정압 200 MPa | §A L933 | 원문 인용 | 값 없음
- [i] pan2026_thesis_rate_capable_energy_dense_cathode_composites | (액체 LIB) 두께 감소 0 / 20 / 40 % → μCT 거대 기공 38 / 35 / 30 % 이나 질량 수지 기공 ≈ 6.5 % — CT 기공 ≠ 총 기공 | §A L931 | [카드 산술] | 압축 앵커로 안 씀
- [i] lee2025_dual_fibrous_ptfe_dry_electrode + he2026_dem_calendering_inhomogeneity_areal_density + cronk2026_lis_positive_electrode_geometry_fem | (묶음 · 압밀 축으로 못 쓰는 세 편) Lee EES: Hg 압입 27.4 / 27.1 % · 180 µm · 3.1 g/cm³ (롤프레스 압력 미기재 · 액체 LIB) · He: SE 없음 · 두께만 스윕 · Cronk: 공극 10 vol% 를 입력으로 고정 (압력 변수 없음 · 실측 porosity 0 건) | §A L832–851 · L861–863 · L808–816 | Lee = stated · DERIVED 25.8 % | 
- [i] alabdali2023_cgmd_wet_manufacturing_ssb_cathode | 습식 SSB 양극 CGMD 의 유효구간: 압연도 ~35 % 까지 (저자) — 그 위에서는 상부 24–28 µm 의 pore · CBD → 0.03–0.05 · AM → 0.74 (Fig 3c) | §C L2436–2441 | 원문 인용 | 압력 없음
- [i] kim2026_pregranulation_ptfe_dry_nca_cathode_crack_delithiation | PTFE 건식 쌍봉 NCA (1–3 + 8–10 µm) 캘린더링: 공극 0.333 (GIDE) vs 0.305 · 큰 2 차 입자 균열 (SEM 정성) | §C L2663 | 표지 없음 | 전해질 종류 · 압력 이 줄에 없음
- [i] minnmann2021_jes_charge_transport_bottlenecks | 복합 porosity 13–17 % (NCM622 + LPSCl) ≈ 우리 real_14 15.6 % · σ_ion,eff 0.17 mS/cm @ 42 vol% NCM | §E L2804–2807 | 표지 없음 | 한 압력 (380 MPa — §A L336)
- [i] bielefeld2019_microstructural_modeling_composite_cathode + bielefeld2020_effective_ionic_conductivity_binder | (묶음 · 구조 생성 모델의 기공은 입력) Bielefeld 2019 "good-perf porosity ~21 %" · Bielefeld 2020 porosity 15 % 고정 — 랜덤 배치 구조 (압축 계산 없음) | §D L2748–2751 · §E L2808–2814 | 표지 없음 | 압력 없음
- [i] varkey2026_multicontact_elastoplastic_dem | halide 복합 양극 floor 37 % (separator 21 %) @ 350 MPa | §D L2730–2731 · §E L2826 | 표지 없음 | halide Li₃YBrCl₆
- [i] galvezaranda2024_time_dependent_dl_calendering_microstructure | (LIB) 압연 DEM 35 런 · 855 프레임 · porosity 19–31 % · 압력 축 0 건 (CD 만) · 복셀 라벨 porosity 가 자기 Table S2 와 프레임 0 에서 8.5 %p · 완화 상태에서 16.4 %p 어긋남 · AM 복셀이 −22.3 % 사라졌다 되돌아옴 | §F L2998 · L3044–3052 | derived(ours) | 액체 LIB · 값 전이 금지
- [i] luan2025_graded_cathode_400whkg_pouch | 조성 구배 양극의 φ_SE (집전체측 / 분리막측) 0.140 / 0.201 (실험 93 : 6 : 1 ǀ 90 : 9 : 1) — porosity · 두께 미보고 | §F L3643–3649 · L3671–3673 | DERIVED vol% (ρ ASSUMED) | 기공 값 없음
- [i] fan2026_sulfide_assb_stability_review_ECERD2600097 | 리뷰 인용: 사이클 후 void XCT 3.95 → 1.19 % [161] | §F L3626 | 표지 없음 | 2 차 출처 · 압력 이 줄에 없음



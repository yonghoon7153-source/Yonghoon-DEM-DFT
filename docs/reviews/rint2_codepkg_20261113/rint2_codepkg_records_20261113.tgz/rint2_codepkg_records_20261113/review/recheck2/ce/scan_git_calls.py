#!/usr/bin/env python3
"""recheck2 (RCP2-06) — 트리 안 파이썬 파일의 git 부름 전수 (AST).  부름 = subprocess.{run,call,check_call,check_output,Popen} (별칭 포함)
의 첫 인자가 'git' 으로 시작하는 리스트 글자 · 또는 이름이 git 꼴인 도우미 (*git*) 를 통한 부름은 따로 센다.
각 부름: 파일:행 · env= 있음 / 없음 · 첫 낱말들 (쓰기 꼴인가) · 모듈 머리에서 drop_git_env() 를 부르는가.
사용: python3 -I scan_git_calls.py <트리 뿌리> [경로 접두 …]"""
import ast
import json
import os
import sys

WRITE = {'init', 'add', 'commit', 'config', 'update-ref', 'worktree', 'stash', 'checkout', 'reset', 'tag', 'branch', 'merge', 'rebase',
         'clone', 'fetch', 'push', 'rm', 'mv', 'apply', 'am', 'cherry-pick', 'gc', 'repack', 'notes', 'symbolic-ref', 'hash-object',
         'update-index', 'read-tree', 'write-tree', 'commit-tree', 'pull', 'restore', 'switch', 'clean'}
SUBP = {'run', 'call', 'check_call', 'check_output', 'Popen'}


def first_words(node):
    if isinstance(node, (ast.List, ast.Tuple)) and node.elts:
        out = []
        for e in node.elts:
            if isinstance(e, ast.Constant) and isinstance(e.value, str):
                out.append(e.value)
            elif isinstance(e, ast.Starred):
                out.append('*' + (ast.unparse(e.value) if hasattr(ast, 'unparse') else '?'))
            else:
                out.append('<' + (ast.unparse(e) if hasattr(ast, 'unparse') else '?')[:40] + '>')
        return out
    return None


def verb(words):
    # git -C x -c k=v … <verb>
    i = 1
    while i < len(words):
        w = words[i]
        if w in ('-C', '-c', '--git-dir', '--work-tree'):
            i += 2
            continue
        if w.startswith('-') or w.startswith('*') or w.startswith('<'):
            i += 1
            continue
        return w
    return None


def scan(path):
    src = open(path, encoding='utf-8', errors='replace').read()
    try:
        tree = ast.parse(src)
    except SyntaxError as e:
        return {'error': f'SyntaxError {e}'}
    calls = []
    top_drop = False
    for st in tree.body:
        for n in ast.walk(st):
            if isinstance(n, ast.Call) and isinstance(n.func, ast.Attribute) and n.func.attr == 'drop_git_env':
                if isinstance(st, (ast.Expr, ast.Assign)):
                    top_drop = True
    for n in ast.walk(tree):
        if not isinstance(n, ast.Call):
            continue
        f = n.func
        name = f.attr if isinstance(f, ast.Attribute) else (f.id if isinstance(f, ast.Name) else None)
        if name not in SUBP or not n.args:
            continue
        w = first_words(n.args[0])
        if not w or w[0] != 'git':
            continue
        kw = {k.arg: k for k in n.keywords if k.arg}
        envsrc = None
        if 'env' in kw:
            envsrc = ast.unparse(kw['env'].value) if hasattr(ast, 'unparse') else 'env'
        v = verb(w)
        calls.append({'line': n.lineno, 'verb': v, 'write': v in WRITE, 'env': envsrc, 'words': w[:8],
                      'cwd': (ast.unparse(kw['cwd'].value) if 'cwd' in kw and hasattr(ast, 'unparse') else None)})
    return {'top_drop_git_env': top_drop, 'calls': calls}


def main():
    root = sys.argv[1]
    pref = sys.argv[2:] or ['scripts', 'docs']
    out = {}
    for p in pref:
        for r, _ds, fs in os.walk(os.path.join(root, p)):
            for fn in fs:
                if fn.endswith('.py'):
                    q = os.path.join(r, fn)
                    res = scan(q)
                    if res.get('calls') or res.get('error'):
                        out[os.path.relpath(q, root)] = res
    print(json.dumps(out, ensure_ascii=False, indent=1, sort_keys=True))


if __name__ == '__main__':
    main()

"""Recompute registration draft 4-1/4-2/4-3/4-4/5-3/5-4 arithmetic from cited numbers (read-only)."""
from datetime import datetime, timezone
def ep(s): return int(datetime.strptime(s, '%Y-%m-%dT%H:%M:%SZ').replace(tzinfo=timezone.utc).timestamp())
v26 = [('E0_ref_s32452843','2026-09-30T08:12:16Z',1790769933,1037429,'03:53:20'),
       ('E0_ref_s49979687','2026-09-30T09:12:36Z',1790773512,1037429,'03:52:38'),
       ('E0_ref_s67867967','2026-09-30T09:12:39Z',1790770830,1037429,'03:07:57'),
       ('E0_ref2_s32452843','2026-09-30T12:05:39Z',1790787354,1467147,'04:50:21'),
       ('E0_ref_dthalf_s32452843','2026-09-30T12:20:32Z',1790795353,2074857,'06:48:45')]
old = [('E0_ref_s32452843','2026-09-29T16:34:53Z',1790710507,867977),
       ('E0_ref_s49979687','2026-09-29T17:35:03Z',1790716606,867977),
       ('E0_ref_s67867967','2026-09-29T17:35:03Z',1790715559,867977),
       ('E0_ref2_s32452843','2026-09-29T19:35:22Z',1790728765,1227503),
       ('E0_ref_dthalf_s32452843','2026-09-29T21:00:15Z',1790742955,1735953)]
def hms(s):
    h,m,x = s.split(':'); return int(h)*3600+int(m)*60+int(x)
rates=[]
for n,st,lm,steps,el in v26:
    rt = lm-ep(st); r = steps/rt; rates.append(r)
    print('v26',n,'run_s',rt,'h %.2f'%(rt/3600),'step/s %.2f'%r,'sacct',hms(el),'diff',hms(el)-rt,'sacct rate %.4f'%(steps/hms(el)),'slower %%: %.3f'%(100*(1-(steps/hms(el))/r)))
for n,st,lm,steps in old:
    rt = lm-ep(st); r=steps/rt; rates.append(r)
    print('old',n,'run_s',rt,'step/s %.2f'%r)
print('range %.2f %.2f ratio %.3f'%(min(rates),max(rates),max(rates)/min(rates)))
# dev-bo
for n,st,lm,sac in (('LHx10','2026-10-02T07:12:48Z',1791022137,'1-02:56:12'),('LHx30','2026-10-02T07:12:48Z',1791012808,'1-00:20:44')):
    d,rest=sac.split('-'); s=int(d)*86400+hms(rest); rt=lm-ep(st); print('devbo',n,rt,s,s-rt)
P=1121213
for r in (92.04,74.12,63.49):
    print('pilot rate',r,'s',round(P/r),'h %.3f'%(P/r/3600))
print('margin 86400/17658=%.3f 86400/15127=%.3f'%(86400/17658,86400/15127))
print('alt 12h: %.3f %.3f ; 48h: %.3f %.3f'%(43200/17660,43200/15127,172800/17660,172800/15127))
print('1121213/1037429=%.4f'%(P/1037429))
print('S5: frame interval %.2f..%.2f s ; 1800/15.75=%.1f 1800/10.87=%.1f'%(1000/92.04,1000/63.49,1800/(1000/63.49),1800/(1000/92.04)))
print('E9: %.0f %.0f'%(63.49*3600,92.04*3600))
# 5-3
line=6+2+10*24+12; frame=100000*line+512; dump=1121*frame; ck=3*100000*400
print('line',line,'frame',frame,'dump',dump,'ck',ck,'total',dump+ck)
import math
print('floor', math.ceil((dump+ck)*1.10), '1.1x exact', (dump+ck)*11/10)
print('files', 1121+3+2+20, 'inode', math.ceil((1121+3+2+20)*1.1))
print('E5 2x est', 2*12176710*1121+115288377, 'E4', 2*12176710)
print('5-3(4)', 2*12176710*1121)
print('df ratio', 142604135108608/32193231348, 'ost min ratio', 14629480562688/32193231348, 14629480562688/29266573952)

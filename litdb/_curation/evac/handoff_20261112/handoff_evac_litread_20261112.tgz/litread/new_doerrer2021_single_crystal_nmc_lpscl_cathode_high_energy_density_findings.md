# 정독 근거 — doerrer2021_single_crystal_nmc_lpscl_cathode_high_energy_density (Doerrer 외, ACS Appl. Mater. Interfaces 13, 37809–37815, 2021)

카드 = 정본 `litdb/papers/doerrer2021_single_crystal_nmc_lpscl_cathode_high_energy_density.md` (커밋 6ea455104) · 표지는 카드의 것 그대로.

## a
- [a] doerrer2021_single_crystal_nmc_lpscl_cathode_high_energy_density | 순수 Li6PS5Cl 분말 펠릿의 상대밀도 vs 압력: SP (볼밀링 1–5 µm) 0.539 / 0.856 / 0.867 / 0.889 · LP (상용 1–20 µm) 0.566 / 0.856 / 0.878 / 0.901 @ 25 / 250 / 375 / ≈500 MPa → 기공 SP 46 / 14.4 / 13.3 / 11.1 % · LP 43 / 14.4 / 12.2 / 9.9 % · 300 MPa 보간 ≈14.0 / 13.5 % | 카드 §3-3 · p.2 · Fig. 1e | [판독] (기공 · 보간 = [카드 산술]) | 진밀도 (분모) · 질량 기준 여부 · 측정 상태 (가압 중 / 뺀 뒤) 모두 [미확인] — 같은 그림의 σ 는 "different stack pressures" 에서 잰 EIS · 랩 표준 (10–13 % · 1.64) 과 다른 문헌 값 · σ 와 밀도의 압력 세트가 다르다

## b
이 배치에 없음 (탈압 회복 · 가압 중 높이 측정 없음 — 카드 §4-3 ④)

## c
이 배치에 없음 (항복 · 경도 · 크리프 값 없음 — 정성 진술 "sulfides have a relatively low flow stress even at room temperature" (p.1) 뿐 · 카드 §4-3 ②)

## d
- [d] doerrer2021_single_crystal_nmc_lpscl_cathode_high_energy_density | 단단한 NMC + 무른 LPSCl 압밀의 정성 기전: NMC 가 움직이며 LPSCl 에 전단을 전하고, NMC–NMC 접촉이 생기면 상대 운동이 막혀 전단이 멈추고 다결정 응집체가 깨지기 시작 · 작은 단결정은 접촉 전 전단이 더 많다 | 카드 §3-4 · p.3 · SI Fig. S7 | [인쇄] (원문 문장 · 모식도) | 하중 몫 · 접촉 수 · 응력 값 없음 (가설 그림) · NMC83 단결정 ↔ NMC811 다결정이라 형태와 조성이 함께 다르다

## e
이 배치에 없음 (접촉 법칙 · 대안 법칙 없음)

## f
이 배치에 없음 (MPM 없음)

## g
이 배치에 없음 (2D 계산 · 2D→3D 말 없음 — FEM 은 3D 펠릿 한 장)

## h
이 배치에 없음 (DEM → FE · MPM 넘김 없음)

## i
- [i] doerrer2021_single_crystal_nmc_lpscl_cathode_high_energy_density | 복합 양극 압력별 상대밀도: 다결정 NMC811 + LPSCl-SP + C65 (같은 공정 · 70:27.5:2.5 wt% 로 읽힘) 50 / 250 / 500 MPa → 0.78 / 0.82 / 0.86 (기공 22 / 18 / 14 %) · 단결정 NMC83 같은 조성 500 MPa → ≈0.90 (기공 ≈10 %) | 카드 §3-2 표 · p.2–3 · SI Fig. S6 캡션 · SI Table S4 | [인쇄] (다결정 = "estimated" · 기공 = [카드 산술 1 − d]) | 측정법 · 분모 · 유지 시간 · 반복 [미확인] · 하중 뺀 뒤 · 다이 밖 단면 · 분리막 분말과 함께 압밀 · 다결정은 250 MPa 이상 파쇄가 섞인 기공 · vol% (≈45:51:4) 는 카드 산술 (NMC 4.78 = SI Table S1 격자 · LPSCl 1.64 · C65 2.0 가정)

## j
- [j] doerrer2021_single_crystal_nmc_lpscl_cathode_high_energy_density | 원문이 적은 한계 (가압 쪽): "Stack pressures >500 MPa increased impedance (Figure S5) due to excessive LPSCl particle cracking" (근거 영상 없음) · 높은 적층압은 "may promote particulate cracking and become impractical for larger scale cells or packs" · 50 MPa 적층압 = 첫 충전 단락 · FEM 은 "under reasonable friction assumptions" (마찰 계수 미기재) | 카드 §10 1–5 · p.2–5 · SI Fig. S12 · S13 | [인쇄] | 카드가 본 한계: 상대밀도의 측정법 · 분모 · 반복 없음 · 단결정 복합 압력 축 없음 (500 MPa 한 점) · 본문 σ_SP 1.2 ↔ 그림 끝점 1.46 [판독] (카드 §10 6–13)

## k
- [k] doerrer2021_single_crystal_nmc_lpscl_cathode_high_energy_density (Doerrer C, … Grant PS, ACS Appl. Mater. Interfaces 13, 37809–37815, 2021) | DEM 의 한계: **말 없음** — 본문 · SI 에 DEM · discrete element · 입자 모델이 없다 · 계산은 펠릿 벽 마찰을 보는 탄성 FEM (Inventor) 한 장뿐 ("It was assumed that the pellet was fixed at the outer surface due to its high friction with the plastic mold.") | 카드 §4-3 ① · SI p.3 · SI Fig. S13 | 원문 (말 없음) | 실험 논문 — DEM 한계를 인용할 근거로 쓰지 않는다

## l
- [l] doerrer2021_single_crystal_nmc_lpscl_cathode_high_energy_density (Doerrer C, … Grant PS, ACS Appl. Mater. Interfaces 13, 37809–37815, 2021) | 소성을 계산에 넣기 어려운 이유: 계산이 없어 **말 없음**.  재료 · 기전 쪽 진술만: "sulfides have a relatively low flow stress even at room temperature (RT) and can be manipulated into intimate contact with the active particles by applying an external load during processing and/or service" (p.1) · "shear forces are transmitted to the more easily deformed LPSCl … once the PC-NMC particles contact one another, relative motion is inhibited and it is difficult to induce any further shearing of the LPSCl, and the PC agglomerates may start to crack" (p.3) · "cracking may occur not only during cycling but during manufacture where pressures >100 MPa are frequently used in an effort to reduce or eliminate composite cathode porosity" (p.1).  우회 = 없음 · 맞춘 값 0 · 계산 비용 0 | 카드 §4-3 ② · p.1 · p.3 | [인쇄] (원문 문장) | 정성 — SE 형상 변형 (R6) · AM 이동 · 하중 분담 (R1) · AM 파괴 (R7) 가 한 압밀 안에서 같이 일어난다는 실험 쪽 진술로만 인용 (수치 근거 아님)

## m
- [m] doerrer2021_single_crystal_nmc_lpscl_cathode_high_energy_density | 무엇을: 결과 전 대조 항목으로 "SC 복합 500 MPa → ≈0.90 · PC 50/250/500 MPa → 0.78/0.82/0.86" 를 상태 꼬리표 (하중 뺀 뒤 · 다이 밖 단면 · 측정법 / 분모 미기재 · 분리막 동시 압밀 · C65 2.5 wt%) 와 함께 등록 · 우리 쪽: 결과 전 대조 항목 · 단계 6 (탈압 뒤 값과 견줌 · 가압 중 값과는 견주지 않음) · 왜: 카드 §7-3 표 · p.2 · SI Fig. S6 | 카드 §7-3 · §8-1 | [인쇄] | 맞추는 데 쓰지 않는다 (frame[4])
- [m] doerrer2021_single_crystal_nmc_lpscl_cathode_high_energy_density | 무엇을: 관측량 "AM–AM 접촉이 받는 하중 몫 ↔ SE 누적 전단 변형 ↔ AM 응력" 을 재설계 후보 출력에 함께 낸다 (저자 기전 = AM–AM 접촉이 SE 전단을 멈추고 다결정을 깬다) · 우리 쪽: 단계 5 · 조건 R1 · 후보 A / A′ / B · 왜: p.3 · SI Fig. S7 | 카드 §8-3 | [인쇄] (정성) | 값 표적 아님
- [m] doerrer2021_single_crystal_nmc_lpscl_cathode_high_energy_density | 함정: 순수 LPSCl σ(P) (Fig. 1e) × 면적 저항 (SI Fig. S5) = 0.087–0.093 cm 로 압력에 무관 → σ 를 압력마다 같은 두께로 계산한 것으로 보인다 · 우리 쪽: 흐름 밖 (접촉망 σ ↔ 실험 σ(P) 대조) — 하중 아래 치수의 σ 로 쓰지 않는다 · 왜: 카드 §3-3 | 카드 §3-3 · §10-9 | [카드 산술 · 같은 시료 가정] | 두께 · 질량 · 지름은 원문에 없다
- [m] doerrer2021_single_crystal_nmc_lpscl_cathode_high_energy_density | 함정: 지름 5 mm 펠릿의 벽 마찰이 음극 2.5 MPa 를 양극 ≈0 으로 끊는다 (탄성 FEM) — 마찰 없는 옆면의 우리 계와 실험 펠릿은 층마다 압력이 다를 수 있다 · 우리 쪽: 흐름 밖 (실험 펠릿 대조의 한정어) · 왜: SI Fig. S13 · p.5 | 카드 §3-6 · §8-6 | [인쇄 — 그림 안 값] | 마찰 계수 · 물성 미기재 · 저압 (2.5 MPa) 경우만

## 카드 문제
없음 — 원문 안의 어긋남은 카드 §10 (6–13) 에 표지해 두었다: 본문 σ_SP 1.2 ↔ 그림 끝점 1.46 [판독] · SI Table S1 격자로 계산한 부피 101.45 ↔ 본문 101.62 Å³ · σ 와 상대밀도의 압력 세트가 다름.

# Reverify5 release/detail review — Q1

Pinned source: `aa7ec7fe98e8684f1a2138665f9eba978366c229` (parent-verified archive).
Read-only source review. No production edits, Git mutations, simulation, or production194 execution.

## Conclusion

The original G2RR4-01 reread counterexamples are closed. The new detailed contract rejects missing/false/mistyped checks, wrong or duplicate check IDs, absent case detail, wrong cohorts, and M3 disagreement. The release gate now rejects `import_observation.problems` and `outside` even when the top failure summary is empty. The actual submitted old/new pilot reread JSONs both pass `launcher_detail_problems` without path translation: each has meta 10, cases 3, n_fail 0.

One P2 residual remains at the release boundary: the new required `stage_binding` is accepted by schema and attempt-key membership, without checking that each attempt has a payload or that its `expected` and `observed` counts agree. This does not invalidate the audit CLI fix: the audit CLI correctly returns rc 1 for receipt-pair loss. It means a missing/contradictory stage-binding detail can still be accepted by build/check if the audit's top failure list is empty. Classify original mutants **closed**, complete audit-detail assurance **partial**, this concrete residual **open**.

## Finding: validate per-attempt stage binding before accepting a release

Location: `source/scripts/lhs_release_build.py:1340-1350`, especially 1346-1348. The code checks the stage-binding schema, dictionary type, and the set of keys against `completed_attempts`. It never reads the values in `sb['attempts']`.

Producer evidence: `source/scripts/run_network_194_parallel.py:615-628`. The producer computes expected/observed counts, puts the mismatch failure in the returned top-level problem list, and emits the binding payload even on failure. `import_observation.problems` is the low-level receipt parser's problem list, so it can legitimately remain empty for a stage-pair deficit. Therefore checking only that inner list does not recheck this new detail.

Independent probe `probes/r5_release_contract.py` used the committed detailed194 positive fixture from `test_lhs_release_v13.py`. The unmodified control builds successfully and check returns `[]`. With all other evidence preserved, each of these produces another successful build/check `[]`:

- Set the first binding attempt's value to `null`.
- Remove only `observed['scripts/parse_liggghts.py']`, leaving `expected[...] == 1`.
- Set that observed parser count to zero.
- Add an observed unplanned process.

These are within-record missing/mismatching evidence, not a coherent rewrite of every receipt, file, manifest, and numerical result.

The independent observation probe also supplied an actual rc 1 audit JSON at `evidence/r5_observation_run2/pair_missing_parse_liggghts/audit.json`. It has `obs.problems=[]`, parser expected 1/observed absent, and a nonempty top `import_observation_problems`. `probes/r5_release_real_binding.py` grafts the exact emitted binding payload into the detailed194 gate fixture and compares:

| Same failed binding payload | Build | Check |
|---|---|---|
| Preserve the producer's failure summary | ReleaseError, no output | Not built |
| Clear only the top failure list | Built | `[]` |

The graft is necessary to exercise the release policy's registered194 scope without running194. It is not a real production194 audit and not evidence of a naturally successful audit carrying inconsistent details. The genuine audit producer correctly reports this failure. The counterexample concerns corruption/partial transfer or a future producer-summary defect at a boundary already designed to reject inconsistent evidence.

Post-build integrity is stronger than pre-build acceptance: modifying the existing good release's batch evidence without updating the cached evidence fingerprint is caught. Updating the build manifest's `batch_gate_files` cache causes the semantically invalid stage bindings to pass again; the original reread/observation failure mutants still fail. This cache refresh is a separate two-record experiment, not needed for the primary counterexample, which builds directly from a singly malformed audit JSON.

Minimal remediation: require each binding value to be an object with the expected/observed counter structures, strict nonnegative integer counts (excluding bool), and a matching stage set/count including its worker. Reject absent or mismatching binding details through the same common gate used by build and check. Tests should cover the detailed positive fixture, null binding value, missing parser count, mismatch, and unplanned process, including a generated failed binding whose top summary is cleared. No raw numerical recalculation, signature system, or unbounded revalidation of every duplicate field is needed. Do not impose global started==finalized: legitimate unfinished noncompleted attempts remain Q2's allowed exception.

## Evidence and test limits

- `evidence/r5_release_contract/results.json`: 18 build cases: one detailed positive control passes, 11 existing-contract mutants reject without output, six exploratory stage-detail/count mutants pass. All 17 mutants were also checked against an existing good release before/after refreshing the cached gate fingerprint. Restored control check returns `[]`.
- `evidence/r5_release_real_binding/results.json`: producer-linked failing binding, with and without its top summary.
- Both submitted reread detail baselines are recorded in `actual_submitted_detail` in the first result JSON.
- `probes/r5_release_contract.py` and `probes/r5_release_real_binding.py` are review-owned drivers.
- Only `v13_reread_tau` is stubbed, exactly as the previous review and committed fixture tests. Build, check, audit-detail judgement, and reread-detail judgement are original code. The fixture uses synthetic generation/pressure values over old committed handover rows. These tests certify evidence-gate behavior only, not actual194 numerical data or P0-P4 upstream acceptance.
- Python 3.12 runtime supplied by parent, `-B`, NumPy/SciPy dependencies from prior review roots, all BLAS thread variables set to 1. Both probe processes exited 0. Source untouched.

## Q1 answer wording

The single shared reread contract, unknown-ID refusal, K1b optional rule, strict `ok` bool handling, required registered set, and mandatory detailed positive fixture satisfy the reread portion of the requested minimum. Old `problems/outside` counterexamples are blocked. Full release observation-detail completeness remains partial because a newly introduced required binding can contain null or failed attempt details that the release gate ignores. Keep this distinction separate from Q2's correctly rejecting audit CLI and from any judgement about the genuine submitted pilot.

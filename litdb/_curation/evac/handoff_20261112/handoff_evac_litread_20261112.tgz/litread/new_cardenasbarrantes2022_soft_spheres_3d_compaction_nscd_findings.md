# new_cardenasbarrantes2022_soft_spheres_3d_compaction_nscd 정독 근거 (새 카드 1 장 · 원문 PDF 10 쪽 전문 + 카드 826 줄 · 2026-11-10)

카드: `cardenasbarrantes2022_soft_spheres_3d_compaction_nscd` (정본 커밋 `1c6e01f12`) — Cárdenas-Barrantes, Cantor, Barés, Renouf & Azéma,
"Three-dimensional compaction of soft granular packings", Soft Matter 18, 312–321 (2022), DOI 10.1039/D1SM01241J.

적는 법: 위치의 `L숫자` = 카드 줄 번호 (커밋 `1c6e01f12` 기준) · 표지는 카드에 적힌 그대로 (`본문` = 인쇄된 값 · `[판독]` = 그림에서 읽음 ·
`[카드 산술]` · `[카드 추정]` · `[카드 추론]` · `[미확인]` · `[inbox 원문 대조]`).  재료 = **탄성 구 모델 소재 (ν 0.495) · 3D** — LPSCl · NCM 아님.

형식: `- [글자] slug | 내용 (값 · 단위) | 위치 | 표지 | 한계`

## a. 순수 SE (LPSCl · 황화물) 의 압력별 기공 곡선 · 진밀도 · 질량 기준 · 누른 채 / 뺀 뒤

- [a] cardenasbarrantes2022_soft_spheres_3d_compaction_nscd | 해당 없음 — 황화물 · 실험 곡선이 아니다.  있는 것은 탄성 구 모델 소재의 무차원 압밀 곡선 (누른 채): φ − φ0 = 0.055 (P/E\* 0.01) · 0.15 (0.05) · 0.22 (0.1) · 0.29 (0.2) · 0.33 (0.3) · 0.40–0.42 (0.7), φ0 = 0.50 · 0.51 | 카드 §3-3 (a) L152–175 · §3-2 L132 · 논문 그림 3a · p. 314 | [판독] ±0.01 (φ0 는 본문) | 탄성 · P/E\* 무차원 (E 미기재) · 구 50 · 100 개 벽 상자 · 진밀도 · 질량 개념 없음 — 카드: 절대값 전이 0 건 (L6–11)

## b. 압력을 뺄 때 되돌아오는 양과 잰 방법

- [b] cardenasbarrantes2022_soft_spheres_3d_compaction_nscd | 없음 — 일정 속도로 누르기만 했다 (탈압 · 이력 · 잔류 변형 계산 없음).  입자가 탄성이라 뺀 뒤 형상이 남는 현상 자체가 모델에 없다 | 카드 §0-1 (iv) L50 · §3-5 L288 · §12-A L750 | 카드 판정 (원문에 탈압 언급 없음) | 탈압 근거로 쓸 수 없음

## c. 항복 · 경도 · 크리프 값과 정의 · 일축 항복 세기 환산

- [c] cardenasbarrantes2022_soft_spheres_3d_compaction_nscd | 항복 · 경도 · 크리프 값 없음 (탄성 재료).  닿는 것 하나: 입자 안 von Mises 응력의 색 눈금 σ_vm/E = 0.005–0.4 — φ 0.96 에서 ≈ 0.3–0.4 (대략) | 카드 §3-2 L141 · §3-3 (f) L259 · 논문 그림 6 · p. 318 | 눈금 범위는 본문 (그림 인쇄) · 값은 [판독] 대략 | 탄성이라 항복이 없다 — 카드: 분말 재료는 그 훨씬 전에 항복 (우리 SE σ_y/E ≈ 0.002–0.014 는 주 리포 값 · L556)

## d. 단단한 입자 + 무른 입자를 섞어 누를 때 단단한 입자의 하중 몫 · 재밍

- [d] cardenasbarrantes2022_soft_spheres_3d_compaction_nscd | 해당 없음 — 무른 구만 (강체 없음).  재밍 값만: jammed φ0 0.50 (N 50) · 0.51 (N 100) · Z0 ≃ 3.5 — 본문이 "because of size effects" 라고 적음 (구 일반값: 마찰 0 → 6 · 마찰 크면 4–6) | 카드 §3-2 L132–135 · 논문 p. 314 · 316 | 본문 | 벽 상자 (한 변 ≈ 3.7 · 4.7 지름 [카드 산술] L266) 의 값 — 벌크 재밍 값 아님.  강체 + 무른 혼합은 형제 카드 `cardenasbarrantes2020_rigid_deformable_mixture_compaction_nscd` (2D)

## e. 점접촉 법칙이 큰 변형에서 깨지는 범위와 대안 · 대안마다 맞춘 값 개수

- [e] cardenasbarrantes2022_soft_spheres_3d_compaction_nscd | Hertz 점접촉 DEM (YADE · 구 2500 개) 이 입자별 FE 계산 (NSCD) 과 갈라지는 곳: P/E\* ≈ 0.04 · φ − φ0 ≈ 0.14.  그 아래에서는 약간 아래 (−0.01), 그 위에서는 **더 조밀** — P/E\* 0.1 에서 φ − φ0 0.29 vs 0.22 (+0.07) · 0.15 에서 0.40 vs 0.26 · 0.2 에서 0.49 vs 0.29 (+0.2 · 세로축 끝) | 카드 §3-3 (a) L154–175 · 논문 그림 3a · p. 315 | [판독] ±0.01 | 탄성 구 · 등방 · DEM 설정 (마찰 · φ0 · 충전율 정의) [미확인] · 저자는 문턱 숫자를 적지 않았다 ("reasonable values" · "a certain point")
- [e] cardenasbarrantes2022_soft_spheres_3d_compaction_nscd | 평균 접촉 변형으로 본 같은 문턱: δ/d ≈ 0.05–0.06 | 카드 §8-5 L610–612 | [카드 산술] (그림 4 직선을 그 범위 밖으로 연장 · φ0 0.51–0.6 가정) | 외삽 — 방향 참고용
- [e] cardenasbarrantes2022_soft_spheres_3d_compaction_nscd | 작은 변형 해석식 (식 7 · Hertz + Z = Z0) 은 Hertz DEM 보다도 빨리 벗어난다 | 카드 §5-3 L408–410 · 논문 p. 317 | 본문 | —
- [e] cardenasbarrantes2022_soft_spheres_3d_compaction_nscd | 저자가 든 대안과 맞춘 값: DEM-BPM (수치 매개변수 의존 · 큰 변형에서 소성처럼 거동) · DEM-FEM = MPFEM (정칙화 접촉) / NSCD (비정칙 접촉).  이 논문 NSCD 의 접촉 매개변수는 마찰 μ **하나** (0.3) · 압밀 식 (8) 의 맞춤은 φmax **하나** · Heckel–Secondi 는 A · φmax **둘** (0.15 · 0.965) | 카드 §4-1 L298–300 · §4-2 L314–319 · §3-2 L134 · 논문 p. 313 · 316 · 317 | 본문 | multi-contact · MDR · EEPA · Thornton–Ning · Storåkers 는 이 논문에 없음

## f. MPM 의 접촉 · 다물체 · 강체 결합 방법 · 해상도 규칙 (지름당 셀 수) · 수치 오차 추정

- [f] cardenasbarrantes2022_soft_spheres_3d_compaction_nscd | MPM 아님 (입자별 FE).  해상도 대응값: 입자당 4 절점 사면체 808 개 ≈ 지름당 요소 변 5.7 개 (444 → 4.6 · 6685 → 11.5 · 14 688 → 14.9) | 카드 §3-4 L268 · 논문 p. 314 | 요소 수는 본문 · 변 수는 [카드 산술] (정사면체 등가) | 요소 ≠ MPM 셀 — 카드: 시험 설계만 옮긴다
- [f] cardenasbarrantes2022_soft_spheres_3d_compaction_nscd | 수치 오차 추정법 = 구 하나를 두 판 사이에서 눌러 Hertz 식 (1) 과 대조.  채택 메시 (808) 는 Hertz 대비 δ/d 0.01 → ×1.79 · 0.02 → ×1.31 · 0.03 → ×1.09 · ≥ 0.04 → ×1.03–1.04; δ/d 0.04 에서 444 +27 % → 808 +4 % → 6685 +11 % → 14 688 −2 % (단조 아님); 시험 범위 δ/d ≤ 0.06 | 카드 §3-3 (e) L229–249 · §4-3 L321–331 · 논문 그림 1b · p. 314 | [판독] (배수는 [카드 산술]) · 본문 표현은 "slightly overestimated at the beginning" | 큰 변형 (다면체 구간) 의 메시 수렴은 없음 · 그림 1b 가로축 이름 (δ/d)^(3/2) 이 그려진 값 (δ/d) 과 다름 [판독]
- [f] cardenasbarrantes2022_soft_spheres_3d_compaction_nscd | 그 밖의 오차 확인: N 50 ↔ 100 곡선 겹침 (φ 차 ≤ 0.02 [판독]) · 독립 4 계 평균 + 표준편차 오차막대 | 카드 §3-1 L114 · §3-3 (a) L172 · 논문 p. 315 · 그림 3 캡션 | 본문 (겹침 크기는 [판독]) | 구형도는 N 50 ↔ 100 이 13–27 % 다름 [판독] (L256)

## g. 2D 결과를 3D 로 옮길 때의 경고 · 증거

- [g] cardenasbarrantes2022_soft_spheres_3d_compaction_nscd | 원문 경고 (p. 313): *"The transition from 2D to 3D requires additional numerical and technical efforts to manage the particle deformation correctly. Furthermore, as we will see, the resulting compaction equation differs from those previously established in 2D using the same micromechanical framework."* | 카드 §0-1 (iii) L49 · §11 L715–716 | 원문 인용 | —
- [g] cardenasbarrantes2022_soft_spheres_3d_compaction_nscd | 원문 (p. 319): *"…the equation underlying the variation of P with φ established with the same micromechanical framework depends on the dimensionality. The origin of this dependence on the space dimension lies in the functional form of the contact law in the small deformation regime."* — 2D 는 접촉 응력이 접촉 변형에 선형, 3D 는 Hertz 3/2 제곱 | 카드 §5-4 L416–426 · §11 L725–727 · 논문 p. 317 · 319 | 원문 인용 | 탄성 접촉 한정
- [g] cardenasbarrantes2022_soft_spheres_3d_compaction_nscd | 같은 그룹 · 같은 방법의 2D → 3D 변화 (증거 표): 입자 수 1500 → 50 · 100 · 요소 92 삼각형 → 808 사면체 · Z 계수 5.1 → 8.5 (지수 0.5 는 같음) · Γ 4 → 4.4 · φ0 ≈ 0.81 → 0.50 · 0.51 (벽 상자) · φmax 0.96–0.99 → 0.95 · 0.965 · Heckel–Secondi 계수 0.05–0.079 E → 0.099 E · 압밀 식에 √(φ − φ0) 인자 추가 | 카드 §8-3 L562–584 | 3D 값은 본문 · 2D 값은 형제 카드와 [inbox 원문 대조] · 0.099 E 는 [카드 산술] | 저자가 차원 무관이라 한 것은 Z 지수 1/2 · 형상 지수 ≈ 2.5 뿐 (2D 형상 지수 값은 [미확인])

## h. DEM 에서 FE · MPM 으로 넘긴 선례와 넘긴 시점

- [h] cardenasbarrantes2022_soft_spheres_3d_compaction_nscd | 넘김 없음 — 처음부터 같은 코드 (LMGC90) 에서 입자별 FE 구를 떨어뜨리고, σ0/E ≪ 1 ("the particles can be considered as rigid") 인 등방 응력으로 jammed 상태 (φ 변화 < 0.01 %) 를 만든 뒤 누른다.  출발 상태 = 겹침 없는 jammed 패킹 | 카드 §4-4 L333–339 · 논문 p. 314 | 본문 | Hertz DEM (YADE) 은 넘김용이 아니라 대조용

## i. 복합 양극 (AM + SE) 의 압력별 기공

- [i] cardenasbarrantes2022_soft_spheres_3d_compaction_nscd | 없음 (모델 소재 · 무른 구만) | 카드 머리 L6–11 | — | —

## j. 카드가 스스로 "아직 못 한다 · 한계" 라고 적은 것 가운데 가압 · 탈압 계산과 닿는 것

- [j] cardenasbarrantes2022_soft_spheres_3d_compaction_nscd | 저자가 적은 한계 (p. 319): *"From a purely numerical perspective, many efforts still need to be made toward numerical optimization and parallelization of algorithms to increase performance and system size. In particular, it would be interesting to consider periodic conditions in 3D, at least in two directions."* | 카드 §5-7 L457–458 · §11 L731–732 | 원문 인용 | 계산 시간 · 코어 수는 [미확인]
- [j] cardenasbarrantes2022_soft_spheres_3d_compaction_nscd | 소성 · 탄소성 · 점탄소성 · 다분산은 **확장 과제** — *"It will be enough to identify the force law between two particles and integrate it into the framework presented here for all these cases."* | 카드 §5-7 L453–454 · 논문 p. 319 | 원문 인용 | 계산은 하지 않았다
- [j] cardenasbarrantes2022_soft_spheres_3d_compaction_nscd | 입자 수의 한정: 32–200 개면 하중면 · 압밀 · 소성 흐름을 **"qualitatively"** 대표한다는 선행 연구에 기댐 | 카드 §3-1 L115 · 논문 p. 314 | 본문 (저자 낱말) | 정량 대표성은 주장하지 않음
- [j] cardenasbarrantes2022_soft_spheres_3d_compaction_nscd | 카드가 적은 한계: 탈압 없음 · 탄성 · 벽 상자 크기 효과 · 식 (8) 을 본문 상수로 계산하면 그림 실선보다 압력 1.6–2.3 배 낮음 (계수 수준 검증 불가) | 카드 §12-A L741–750 · §12-B L752–776 · §3-4 L271–274 | [카드 산술 + 판독] | 판독 ±0.01 에 기댄 판정 — 원인 [미확인]

## k. DEM 의 한계 — 논문 (카드) 이 직접 말한 문장 · 수치

- [k] cardenasbarrantes2022_soft_spheres_3d_compaction_nscd (Cárdenas-Barrantes, Cantor, Barés, Renouf & Azéma 2022 · Soft Matter 18, 312–321 · DOI 10.1039/D1SM01241J) | 서론 (p. 313): *"Nevertheless, the Smooth-DEM loses accuracy at larger deformation, where the change in grain shape, which can no longer be ignored, becomes a key mechanism in the compaction."* — "Smooth-DEM" = Hertz 를 흉내 낸 정칙화 접촉의 통상 DEM (작은 변형의 탄성 성질 연구에 쓰여 왔다고 적음) | 카드 §0-1 (i) L47 · §11 L707–708 · §4-2 L316 | 원문 인용 | 문턱 수치 없음 (서술)
- [k] 같은 카드 (같은 서지) | 결과 (p. 315): *"The Hertzian-based simulation correctly reproduces the compaction evolution for reasonable values of packing fraction close to the jammed state but diverges for high values of pressure due to the inability of the particles to truly deform."* — 같은 그림에 YADE Hertz DEM (구 2500 개) 을 겹쳐 그린 직접 비교 | 카드 §5-1 L390–391 · §11 L719–721 · 논문 그림 3a | 원문 인용 | 탄성 구 · 등방 · DEM 설정 [미확인]
- [k] 같은 카드 (같은 서지) | 그 그림에서 읽은 한계 수치: 이탈 시작 P/E\* ≈ 0.04 · φ − φ0 ≈ 0.14; P/E\* 0.1 에서 φ − φ0 가 +0.07 · 0.2 에서 +0.2 (DEM 이 더 조밀 = 같은 충전율에서 압력 과소) · P/E\* ≈ 0.2 에서 DEM 의 φ − φ0 가 0.5 (φ ≥ 1 로 보임 — 겹친 부피 중복) | 카드 §3-3 (a) L154–175 · §8-6 L614–620 | [판독] ±0.01 · "φ ≥ 1" 은 [카드 추정] (DEM 충전율 정의 [미확인]) | 저자가 적은 숫자가 아니라 카드 판독
- [k] 같은 카드 (같은 서지) | (p. 317) *"Note that eqn (7) diverges faster than the Smooth-DEM results, which employs the same Hertz principle at small deformations. Nevertheless, as the theory predicts, the simulations are still diverging from the correct evolution after a certain point."* | 카드 §0-1 (i) L47 · §5-3 L410 | 원문 인용 | —
- [k] 같은 카드 (같은 서지) | 한계의 방향 (카드 정리): 조밀 영역에서 점접촉 DEM 은 "과하게 무르다" (힘 과소) — `giannis2021_stress_based_multicontact_dem` · `zunker2024_bulk_elastic_partII` 와 같은 부호 | 카드 §8-1 L548–550 · §9-1 L634–637 | 카드 해석 (다른 카드와 대조) | 탄성 계의 결과
- [k] 같은 카드 (같은 서지) | 우리 DEM 의 자리 (논문 주장 아님): 300 MPa ÷ E\* = 0.023 (실제 E 22–24 GPa) ↔ 0.40 (연화 E 1.35 GPa · ν 0.30) — 연화 영률은 이 논문의 이탈 문턱 (≈ 0.04) 을 열 배 넘는 구간 | 카드 §8-5 L599–612 · §3-4 L278 | [카드 산술] | 우리 접촉은 hooke/hysteresis · AM 차폐 — 카드: 방향 해석일 뿐
- [k] 같은 카드 (같은 서지) | 결합 입자 DEM (DEM-BPM) 에 대한 저자 평 (p. 313): *"a major drawback is that the deformable particles often present a plastic behavior at large strain, and their characterization can be complex depending on the imposed numerical parameters (e.g., size of primary particles or interaction laws)."* | 카드 §0-1 (ii) L48 · §4-2 L317 | 원문 인용 | —

## l. 소성변형이 왜 어려운가 — 논문의 설명 · 택한 우회 · 맞춘 값 · 검증 범위 · 계산 비용

- [l] cardenasbarrantes2022_soft_spheres_3d_compaction_nscd (Cárdenas-Barrantes, Cantor, Barés, Renouf & Azéma 2022 · Soft Matter 18, 312–321 · DOI 10.1039/D1SM01241J) | 어려운 이유 ① 형상 변화와 다접촉을 함께 풀어야 한다 (p. 312): *"three-dimensional characterization, by a realistic model that would consider both the change in grain shape and the assembly's multi-contact aspects, remains poorly studied."* | 카드 §0-1 (ii) L48 · §11 L705–706 | 원문 인용 | 이 논문은 소성이 아니라 "큰 변형" 일반을 말한다
- [l] 같은 카드 (같은 서지) | 어려운 이유 ② 비용 (p. 313): *"DEM-FEM strategies have the advantage of being closely representative both in terms of geometry and bulk properties of the particles. The price to pay is that these simulations are computationally expensive."* · *"an inherent difficulty in DEM-FEM methods that explains the small number of studies, particularly in 3D, is the high computational cost, limiting the number of particles that can be simulated."* · (p. 314) *"a problematic issue is finding the best compromise between sample representativeness and numerical efficiency."* | 카드 §11 L711–718 | 원문 인용 | 시간 · 코어 수치는 없음
- [l] 같은 카드 (같은 서지) | 택한 우회 = **소성을 넣지 않음** (탄성 구 · ν 0.495) + 입자별 FE 로 형상 변화를 직접 풂 (NSCD · LMGC90 · nonlinear Gauss–Seidel · 접촉은 비관통 + Coulomb) | 카드 §4-1 L296–307 · §4-6 L368–380 | 본문 | 소성 · 탄소성 · 점탄소성은 결론의 확장 과제 (L453–454)
- [l] 같은 카드 (같은 서지) | 우회의 값 — 규모: 구 50 · 100 개 (계 8 개) × 사면체 808 개 = 요소 40,400 · 80,800 개; 같은 그룹 2D 판의 1500 입자에서 1/15 | 카드 §3-1 L114–117 · §3-4 L267 · 논문 p. 314 | 입자 · 요소 수는 본문 · 총 요소 수 · 1/15 는 [카드 산술] | 계산 시간 · 코어 수 · 병렬 여부 [미확인] (감사의 글에 HPC 플랫폼 MESO@LR 이름만 · L91)
- [l] 같은 카드 (같은 서지) | 맞춘 값: 접촉 μ 0.3 (선택값 · 맞춤 아님) · 압밀 식 (8) 은 φmax 하나 (0.95) · Heckel–Secondi 는 A 0.15 · φmax 0.965 · 메시는 Hertz 식 대조로 808 개 선택 | 카드 §3-2 L134 · L139 · §5-3 L411–412 | 본문 (모델 선의 φmax 0.95 는 [판독] 과 삽도 설명에서) | 초록의 "without the need for tuning any parameters" 와 본문 "only one parameter … is unknown" 이 엇갈림 (L754–755)
- [l] 같은 카드 (같은 서지) | 검증 범위: (i) 구 하나의 Hertz 대조 δ/d ≤ 0.06 (ii) N 50 ↔ 100 겹침 (iii) 문헌 하이드로겔 구 일축 실험 1 건 — 카드 판독으로는 모델이 같은 φ − φ0 에 실험의 0.5–0.55 배 압력을 준다 (본문은 "great agreement") | 카드 §3-3 (c) L196–210 · §12-B L763–764 | [판독] | 실험은 일축 · 입력 일부는 다른 계의 값
- [l] 같은 카드 (같은 서지) | 탄성으로는 왜 분말 압밀을 못 다루나 (카드 풀이): φ 0.96 에 가려면 입자 안 σ_vm/E 가 0.3–0.4 — 분말 재료는 그 훨씬 전에 항복; 실제 영률의 탄성 구는 P/E\* 0.02 에서 φ 가 +0.09 밖에 안 오른다 | 카드 §9-7 L652–654 · §8-5 L604–607 | [판독] 대략 + [카드 산술] | 논문 주장 아님 (카드 해석)

## m. 받아들일 통찰 — 바로 가져다 쓸 수 있는 것

- [m] cardenasbarrantes2022_soft_spheres_3d_compaction_nscd | **후보 판별은 σ(φ) 로 한다 — Z(φ) · Γ 는 못 가른다.**  Hertz DEM 의 Z − Z0 는 φ − φ0 0.45 까지 입자별 FE 와 같은 선 위에 있고 Γ 직선도 거의 같은데 (4.1 vs 4.4), 압력은 P/E\* 0.04 위에서 갈린다 | 우리 쪽: 단계 3 (접촉 표현만 바꿔 견주는 시험) 의 판정 관측량 · 결과 전 대조 항목 | 근거: 카드 §3-3 (d) L227 · (f) L255 · §9-2 L638–640 · 논문 그림 3a · 3b · 4 | [판독] | 탄성 계에서 본 것
- [m] cardenasbarrantes2022_soft_spheres_3d_compaction_nscd | **단위 시험 U1 의 형식과 함정.**  형식 = 구 하나를 두 판 사이에서 눌러 해석해 (탄성 구간은 Hertz 식 1) 와 대조 · 해상도 네 수준.  함정 = (a) "해석해에 가장 가까운 해상도" 를 고르면 우연한 교차를 수렴으로 잘못 읽는다 (808 이 6685 보다 Hertz 에 가깝다) (b) 시험 범위가 작은 변형 (δ/d ≤ 0.06) 뿐이면 큰 변형의 수렴은 모른다 (c) 덜 수렴한 해상도는 재밍 직후 압력을 부풀린다 (+31–79 %) | 우리 쪽: U1 (통과 기준에 "단조 수렴" 과 "큰 변형까지" 를 결과 전에 적는다) | 근거: 카드 §3-3 (e) L245–249 · §9-6 L650–651 · §10-3 3 번 L691–693 | [판독] | 요소 ≠ MPM 셀
- [m] cardenasbarrantes2022_soft_spheres_3d_compaction_nscd | **작은 3D 계의 재밍 값은 벌크가 아니다.**  한 변 3.7–4.7 지름의 벽 상자는 φ0 0.50 · Z0 3.5 (같은 논문이 인용한 구 실험은 0.65 · 7) | 우리 쪽: 단계 4 (3D 순수 SE 를 붓고 눌러 실험 기공 기준에 맞추는 일) — 입자 수와 상자/지름 비를 결과 전에 적고, 작은 계는 코드 검증용으로만 · U6 | 근거: 카드 §3-2 L132–139 · §3-4 L266 · §9-3 L641–643 · 논문 p. 314 · 316 · 317 | 본문 + [카드 산술] | —
- [m] cardenasbarrantes2022_soft_spheres_3d_compaction_nscd | **새 런 없이 잴 관측량 둘.**  Γ = 거시 체적 변형 ÷ 평균 접촉 변형 ⟨δ/d⟩ (3D 탄성 4.4 · 입방 격자 3) · Z − Z0 ∝ (φ − φ0)^α 의 계수 (3D 8.5) | 우리 쪽: 후보 D0 (기존 LIGGGHTS 압축 궤적) — 3D 값은 탄성 · 벽 상자 값이라 기대값으로 쓰지 않는다 | 근거: 카드 §10-3 2 번 L689–690 · §3-2 L135–137 | 본문 | —
- [m] cardenasbarrantes2022_soft_spheres_3d_compaction_nscd | 흐름 밖: 보고 · 원고의 DEM 한계 서술 — **연화 영률이 DEM 을 점접촉 유효 구간 밖으로 옮긴다**는 무차원 그림 (300 MPa ÷ E\*: 실제 0.023 ↔ 연화 0.40 ↔ 이 논문의 Hertz 이탈 ≈ 0.04) | 우리 쪽: 흐름 밖 — DEM 지배방정식 보고 · 원고의 한계 절 (연화가 물성이 아닌 대리라는 설명) | 근거: 카드 §8-5 L599–612 | [카드 산술] + [판독] | 한정어 필수 (탄성 구 · Hertz · 등방 · 우리 접촉은 hooke/hysteresis · AM 차폐)

## 카드 문제

없음 (새 카드 · 작성자 자기 점검).  읽는 쪽이 알아 둘 것 둘: ① 표 3-3 의 값은 전부 그림 래스터 판독 (±0.01) 이고 원저자 수치 파일이 아니다 ② "식 (8) 이 본문 상수로는 그림을 재현하지 못한다" (§3-4 · §12-B) 는 그 판독에 기댄 카드 판정이며 원인은 [미확인] 이다.

#!/usr/bin/env python3
"""묶음 폴더의 md 전부에 리포의 철회값 스윕을 돌린다 (읽기만 · python3 -I -B 로 실행)."""
import glob
import os
import sys
REPO = '/home/user/Yonghoon-DEM-DFT'
P = sys.argv[1]
sys.path.insert(0, os.path.join(REPO, 'scripts'))
import check_review_findings as c
files = sorted(glob.glob(os.path.join(P, '**', '*.md'), recursive=True))
probs, nf, nb = c.ban_sweep(REPO, None, files=files)
print('스윕: md 파일 %d · 등록부 %d · 문제 %d' % (len(files), nb, len(probs)))
for p in probs[:20]:
    print('  ', str(p)[-300:])
sys.exit(1 if probs else 0)

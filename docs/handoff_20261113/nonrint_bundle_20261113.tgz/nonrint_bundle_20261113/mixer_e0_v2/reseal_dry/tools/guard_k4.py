"""K4 'test first' probe: the four live_preflight counterexamples against the CURRENT guard of a
scratch first8 folder (synthetic fixture · fake sbatch · audit hook denies real processes).
Usage: python3 -I -B guard_k4.py <F8_dir> <new_work_root>
Expected today (no K4 code): all four reach the fake sbatch (rc 0) = the guard does not see them."""
import contextlib, hashlib, importlib.util, io, json, sys, time
from pathlib import Path
def audit(event, args):
    if event in ('subprocess.Popen', 'os.system', 'os.posix_spawn', 'socket.connect') or event.startswith('os.exec'):
        raise RuntimeError('guard_k4 denies ' + event)
f8, work = Path(sys.argv[1]).resolve(), Path(sys.argv[2]).resolve()
work.mkdir()
spec = importlib.util.spec_from_file_location('f8_fixture', str(f8 / 'test_mla_boundaries.py'))
mod = importlib.util.module_from_spec(spec); spec.loader.exec_module(mod)
sys.addaudithook(audit)
def run(label, concurrency=1, live_extra=None):
    (work / label).mkdir()
    fx = mod.Fixture(str(work / label), concurrency)
    c, ap, files, put = fx.make('PRECAL_E0')
    live = json.loads(Path(c['live_preflight']['path']).read_text())
    if live_extra:
        live.update(live_extra(live))
        c['live_preflight'] = put('live2', json.dumps(live))
        ap.write_text(json.dumps(c))
    try:
        with contextlib.redirect_stdout(io.StringIO()):
            fx.submit(ap)
        print('K4 %-28s rc=0 (guard passed · fake sbatch calls %d)' % (label, len(fx.calls)))
    except Exception as e:
        print('K4 %-28s rc=2 HOLD: %s' % (label, e))
now = time.time()
run('1_handwritten_observed')   # fixture writes observed_unix = time.time() by hand, no raw outputs at all
run('2_raw_sha_mismatch', live_extra=lambda l: {'raw_outputs': [{'file': 'squeue.txt', 'sha256': '0' * 64, 'captured_unix': l['observed_unix']}]})
run('3_stale_captured_unix', live_extra=lambda l: {'raw_outputs': [{'file': 'squeue.txt', 'sha256': hashlib.sha256(b'x').hexdigest(), 'captured_unix': l['observed_unix'] - 1200}]})
run('4_E0_concurrency_2_2', concurrency=2)

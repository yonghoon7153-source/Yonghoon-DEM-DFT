"""재리뷰 (Codex 아님) — '결과 전 문턱 값은 하나도 옮기지 않았다' 를 값 단위로 대조.
두 판 (고치기 전 · 뒤) 의 같은 꼴 값 집합 · 개수를 비교하고, 바뀐 줄 (diff 의 -/+) 안에서 그 값이 어떻게 움직였는지 센다.
쓰는 법: python3 -I -B threshold_diff.py <before.md> <after.md>
"""
import re, sys, difflib, collections
b = open(sys.argv[1], encoding='utf-8').read().splitlines()
a = open(sys.argv[2], encoding='utf-8').read().splitlines()
PATS = collections.OrderedDict([
    ('walltime 꼴 D-HH:MM:SS', r'\b\d{1,2}-\d\d:\d\d:\d\d\b'),
    ('상한 29266573952', r'\b29266573952\b'),
    ('바닥 32193231348', r'\b32193231348\b'),
    ('파일 수 1146', r'\b1146\b'),
    ('inode 1261', r'\b1261\b'),
    ('N 분', r'\b\d+ 분\b'),
    ('N 초', r'\b\d+ 초\b'),
    ('cpu 60 꼴', r'(?:\+ 20 [>≤] 60|cpu-?60|cpu 60|CPU 60|≤ 60|> 60)'),
])
def coll(lines, pat):
    return collections.Counter(m for l in lines for m in re.findall(pat, l))
removed = [l[1:] for l in difflib.unified_diff(b, a, lineterm='', n=0) if l.startswith('-') and not l.startswith('---')]
added = [l[1:] for l in difflib.unified_diff(b, a, lineterm='', n=0) if l.startswith('+') and not l.startswith('+++')]
for name, pat in PATS.items():
    cb, ca = coll(b, pat), coll(a, pat)
    cr, cad = coll(removed, pat), coll(added, pat)
    gone = sorted(set(cb) - set(ca)); new = sorted(set(ca) - set(cb))
    print('%-24s 앞 %s | 뒤 %s' % (name, dict(cb), dict(ca)))
    print('%-24s   바뀐 줄 안: 빠진 줄 %s · 들어온 줄 %s · 사라진 값 %s · 새 값 %s' % ('', dict(cr), dict(cad), gone, new))

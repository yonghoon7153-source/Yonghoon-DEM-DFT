# 믹서 E0 자격 pilot — ibb 읽기 전용 조회 블록 q1–q9 (초안 2026-11-12)

**초안 · ibb 실행 0 · 현장 결과 0 · 제출 · 취소 · 계산 · 예약 해제 0 · 리포 쓰기 0 · 자격 판정 아님 · 전체 HOLD 그대로.**
승인 근거: 1저자 11-12 *"다 권고대로"* = 등록 초안 (`../e0_pilot_registration_draft.md`) 18 절 **Q6** — 13 절의 읽기 전용 조회 아홉 줄 (sacct · 로그 꼴 포함).
⚠ q6 (sacct) 와 q9 (로그 안 줄 꼴) 는 11-10 메타 블록의 승인 범위 (sinfo · sacctmgr show · 내 squeue · 로그는 크기와 첫 배너 줄만) **밖**이었다 → 이번 Q6 승인 범위로 돈다.  블록 머리 두 줄과 본문 머리에 그렇게 적었다.
주소 · 포트 · 계정은 이 폴더의 어느 파일에도 없다 (블록 안은 `$HOME` · `$USER` 뿐).

## 0. 만든 파일

| 파일 | 뭐 |
|---|---|
| `query_block.txt` | **1저자가 ibb 로그인 셸 (bash) 에 붙일 블록 하나** — 377 줄 · 25,792 B · 블록 파일 md5 `20b2876bc96272dd5787ee10f5ec41b6` · **스크립트 md5 `664376ce372ee4b60779d4f27e380165`** (블록 첫 줄 · 마지막 줄 게이트 · `src/query_script.sh` 셋이 같다) |
| `src/query_script.sh` | 블록 본문 원본 (372 줄 · 24,822 B · 최장 줄 231 B) — 고칠 때는 이것을 고치고 `src/build_block.sh` 로 다시 만든다 |
| `src/build_block.sh` | 검사 (`bash -n` · 느낌표 · 탭 · CR · 줄 첫 `^` · 구분자 줄 · 끝 개행 · 크기 < 120 KB) + md5 게이트 블록 생성 (11-10 메타 블록 · DEM1 `make_block.sh` 꼴) |
| `read_query_bundle.py` | 받은 tgz 를 빈 새 폴더에 안전하게 풀고 대조 · 요약 · 옮길 값 계산 (`python3 -I`) — 5 절 |
| `test/run_tests.sh` · `test/check_run.py` · `test/mkworld.py` · `test/fakes/` | 컨테이너 시험 (PID 1 이 아니면 거부 — `unshare -pf --mount-proc --kill-child` 안에서만) |
| `test/run_20261112T114407Z/` · `test/last_run.txt` | 마지막 시험 = **675 PASS · 0 FAIL** (`check_result.json`) — 같은 파일로 두 번 돌려 두 번 다 675 / 0 |

## 1. 조회 아홉 줄 (등록 초안 13 절) ↔ 명령 ↔ 출력 ↔ 채우는 칸

대상 = 메타 결과 (`docs/data/mixer_e0_meta_ibb_20261110/out/`) 의 DEV E0 다섯 런 · 잡 다섯 (`seal_extract.txt` L968 · L928 · L568 · L448 · L728 · 폴더 = `fields.txt` L191 `~/mixer_dev7_20260930_v26`):
r1 `E0_ref_s32452843` 249080 · r2 `E0_ref_s49979687` 249081 · r3 `E0_ref_s67867967` 249082 · r4 `E0_ref2_s32452843` 249083 · r5 `E0_ref_dthalf_s32452843` 249084.

| q | 명령 (전부 `timeout` 안) | out/ 파일 | 옮기는 값 · 칸 |
|---|---|---|---|
| q1 | 런마다 `du -sk -- <런>/post <런>/restart` · `find <런>/post -maxdepth 1 -printf 'F\|%y\|%s\n'` → 합 · 수 · 최소 · 최대 (awk) · `find <런>/restart … '%y\|%s\|%f'` | `q1_r<i>_du.txt` · `q1_r<i>_post_sum.txt` · `q1_r<i>_restart_ls.txt` · `q1_r<i>_restart_sum.txt` | 등록 5-1 · 5-2 (런별 실측) · 기준 표 5 절 · 9 절 #9 |
| q2 | r1 의 `find post -type f -printf 'F\|%T@\|%s\|%f'` → `mix_<step>.liggghts` 만 step 순 정렬 → 처음 3 · 가운데 1 · 끝 3 (step · 크기 · 수정 시각) | `q2_frames.txt` | 프레임 한 장 크기 · 첫 프레임까지 시간 · 프레임 간격 (등록 6 절 S5 산술 · 9 절 T2 의 관찰) |
| q3 | `find ~/mixer_dev7_20260930_v26 -maxdepth 1 -type d -name 'exact_*'` → 폴더마다 `exact/` 의 `hp_*` (`%.17g`) · `g6_*` (기본 `%g`) 크기 (6 열) | `q3_d<k>_sizes.txt` | 등록 5-3 폭 가정 (24 · 12) 검산 |
| q4 | `lfs quota -U <마운트>` · `lfs quota -u $USER <마운트>` (Lustre 일 때만) | `q4_lfs_quota_default.txt` · `q4_lfs_quota_user.txt` | 기준 표 5 절 "내 할당 (한도)" · 9 절 #7 |
| q5 | `lfs df <마운트>` | `q5_lfs_df.txt` | 기준 표 5 절 "OST 별 여유" · 9 절 #8 |
| q6 | `sacct -j 249080,249081,249082,249083,249084 -P -o JobID,State,ExitCode,Elapsed,AllocCPUS,MaxRSS,ReqMem` (노드 · 계정 · 사용자 칸 안 부름) | `q6_sacct.txt` | 등록 4-1 대조 + 메모리 칸 · 기준 표 4 절 · 9 절 #5 |
| q7 | `~/LIGGGHTS-PUBLIC/src/lmp_mpi` (메타 `fields.txt` L484 의 첫 후보) 의 실제 파일 sha256 · `readelf -d` (없으면 `objdump -p`) 의 RPATH / RUNPATH 줄 · `ldd` 가 푼 경로마다 `readlink -e` → 실제 파일 sha256 (해시 전후 stat 같을 때만) | `q7_rpath.txt` · `q7_ldd.txt` · `q7_libs.txt` · `fields.txt` (`q7.bin.*`) | 기준 표 0-A · 2 절 [미확인] 둘 · 9 절 #1 · #2 |
| q8 | `sinfo -h -o '%P\|%a\|%C'` · `sinfo -h -N -p cpu -o '%C\|%t'` (노드 이름 칸 `%N` 안 부름) | `q8_sinfo_partitions.txt` · `q8_sinfo_nodes_cpu.txt` | 기준 표 4 절 "빈 코어" · 9 절 #6 — **시점 값 · 판정 아님** |
| q9 | r1 의 `log.liggghts` 를 awk 로 센다: thermo 머리 (첫 낱말 `Step`) ~ `Loop time of` 사이에서 숫자 줄 수 · 칸 수 · 비유한 줄 수 · 빈 줄 수 · **숫자 줄이 아닌 줄의 첫 낱말** (숫자 → `#` · `/` 든 낱말 → `<PATHLIKE>` · 그 밖 글자 → `?` · 24 자) 과 그 줄 수 · Loop 로 닫혔나 | `q9_thermo_shape.txt` | 등록 7-4 ③ (같은 덱 계열 확인) · Q5 고침의 fixture 근거 · 9 절 #13 |

- 숫자 값 · 로그 본문 · 덤프 · 체크포인트 · exact 파일 내용 · 금고 (`.e0_diag` 등) 는 **raw/ · work/ 에도** 옮기지 않는다 — 크기 · 이름 · 수정 시각 · 센 수만 (시험이 새 폴더 전체에서 확인).
- 덤프 이름 목록 (q2 의 `find`) 은 ibb 의 `work/` 에만 남고 out/ 에는 step 일곱 줄만 간다.

## 2. 블록 설계 (안전)

- **붙여넣기 꼴** = 11-10 메타 블록과 같다: 본문을 셸 변수에 담는 `IFS= read -r -d '' … <<'MIX_E0_QUERY_EOF'` → 마지막 줄이 md5 를 대조하고 맞을 때만 `BASH_ENV= bash -c` 로 돈다 (다르면 디스크에 아무것도 안 쓴다).  메타와 다른 점 둘: 블록 **첫 줄에 스크립트 md5** · `BASH_ENV=` (사용자 환경 파일을 끌어오지 않게).
- **쓰는 곳** = 새 폴더 `~/mixer_e0_query_<UTC>/` 하나 (umask 077 → 700 · `raw/` `out/` `work/` `work/tmp` · `<이름>.tgz` · `.tgz.sha256`).  `TMPDIR` = `work/tmp` · 작업 폴더 = `work/`.  같은 초에 두 번이면 `_2` … `_5`.  지우기 · 옮기기는 하지 않는다 (폴더는 ibb 에 남는다).
- **안 부르는 명령** — sbatch · scancel · scontrol · srun · squeue · sacctmgr · git · rm · mv · cp · ln · chmod · kill · conda · module · python · lmp_mpi 실행 (ldd = 로더 목록 모드 · 메타와 같음).
- **시간** — 외부 명령은 전부 `timeout` (10–120 초 · `-k 5`) 안.  조회 상한 `MIX_BUDGET` = **600 초** (넘으면 남은 조회 `SKIPPED_BUDGET` · 마지막 명령 하나는 자기 timeout 까지 ≤ 145 초) · 가림은 시작 + 900 초 뒤엔 새로 시작하지 않는다 · 묶음 단계도 단계마다 timeout (tar 120 · sha256 60).  보통 1–3 분 [추정 — 메타 블록 186 초 · 이번은 du · find 가 다섯 런 5,615 항목].  Lustre 가 멈추면 (D 상태 I/O) `timeout` 도 못 끊는다 [한정 · 메타와 같음].
- **Ctrl-C** = 지금 도는 명령 하나가 끝난 뒤 (그 명령의 timeout 안) 남은 조회를 `SKIPPED_INTERRUPT` 로 건너뛰고 묶음을 만든다 · 화면에 "Ctrl-C 로 멈춤" (넘길지는 1저자).  한 번 더 눌러도 같다 · 완전히 끊으려면 창을 닫는다 (그때는 묶음이 안 생긴다).  (`timeout` 이 자기 프로세스 묶음을 따로 만들어 터미널의 SIGINT 는 조회 셸 (`bash -c`) 에만 간다 → trap 이 없으면 끝까지 돈다 [관찰 — 컨테이너 모의: trap 없음 = 세 단계 다 돎 · trap 있음 = 다음 단계부터 건너뜀 · 11-10 메타 블록은 trap 이 없다 · ibb 에서 Ctrl-C 해 본 적은 없다] → 이번에 trap 을 넣었다.)
- **상태 어휘** — OK · FAIL · MISSING · TIMEOUT · TRUNC (2 MB 상한) · SKIPPED_BUDGET · SKIPPED_INTERRUPT · SKIPPED_SWITCH · SKIPPED_NOT_LUSTRE.  어느 것도 멈추지 않는다 (시작 관문 — timeout · HOME · UTC 시각 · 새 폴더 — 만 예외).
- **가림** (raw/ → out/) = 메타 블록 규칙 그대로 (홈 · 실제 홈 (긴 쪽 먼저) · 호스트 · 계정 (낱말 경계) · `/home/<다른 사용자>` · IPv4 · uid/gid · `compiled … by` · q4 · q5 의 원격 FS 이름) + 셋: `CANCELLED by <uid>` · 오류 문구의 `host:<이름>:<포트>` · `<IPv4>:<포트>`.  `private_identity.txt` 는 out/ 에도 해시 목록에도 없다.  끝에 out/ 에 남은 토큰 수를 세어 화면에.
- **스위치** (붙여넣기 전에 `export`): `MIX_Q='q1 … q9'` (돌릴 조회 · 기본 아홉 다 · 쉼표도 됨) · `MIX_BUDGET=<초>`.

## 3. 시험 (컨테이너 · PID 이름공간 · 가짜 HOME · 가짜 명령) — 675 PASS · 0 FAIL

- 사례마다 블록을 **따로 만든 마운트 이름공간**에서 돌렸다: `/` 와 `/dev/shm` 을 읽기 전용으로 다시 붙이고 가짜 세계와 기록 폴더만 쓰기 가능 → 새 폴더 밖에 쓰려 하면 EROFS.  가짜 세계 안은 전후 스냅숏 (종류 · 크기 · mtime · 모드 · sha256) 으로 "새 폴더 하나만 생김" 을 본다.
- 가짜 홈 = 로그인 경로 (링크) → 실제 경로 (메타의 `home_real_relation=prefix:/lustre` 꼴을 t10 에서 그대로).  덤프 · 체크포인트 · exact · 금고 · 로그 (숫자 · 경로 · 주석 메아리 `ERROR:`) 에 SECRET 문자열을 넣었다.  `lmp_mpi` = gcc 로 만든 실제 ELF (RUNPATH = 로그인 홈 경로 · 링크 라이브러리 → 실제 파일 · 없는 라이브러리 하나).

| 사례 | 넣은 것 | 결과 |
|---|---|---|
| 공통 (t1–t10 · t8c) | rc · 새 폴더 1 개 · 밖 변화 0 · 금지 명령 26 종 호출 0 · tgz = out/ 바로 아래 정규 파일만 · 소유자 이름 없음 · 화면 sha256 = 실제 · SHA256SUMS · RAW_SHA256SUMS 전수 · 화면 / out/ 에 홈 · 계정 · 호스트 · 노드 · uid · 시험 경로 0 · **새 폴더 어디에도 (raw/ · work/ 포함) 덤프 · 로그 내용 0** · 남은 토큰 0 · 상태 어휘 · q1–q9 상태 줄 다 있음 | 전부 PASS |
| t1 전부 (mawk) | 아홉 다 OK | q1 런별 합 · 수 · 최소 · 최대 = 가짜 홈 실측 · q2 일곱 줄 (step · 크기 · mtime) = 기대 · q3 크기 = 기대 (공백 든 폴더 이름 건너뜀) · q4 계정 · uid 가림 · q6 sacct 한 번 · 정확한 인자 · `CANCELLED by <UID>` · q7 RUNPATH (`<HOME>/…`) · 링크 → 실제 파일 sha256 · not found · vdso · q8 sinfo 두 번 (`%N` 없음) · q9 표 다섯 · 첫 낱말 · 칸 수 = 기대 · 0.7–1.2 초 |
| t2 전부 (gawk — ibb 와 같은 awk 종류) | t1 과 같음 | t1 과 요약 출력 같음 (정렬 비교) |
| t3 실패 섞기 | r4 런 폴더 없음 · sacct 없음 · sinfo 실패 (서버 이름 · 주소 · 포트 든 오류) · `lfs quota -U` 실패 · readelf 127 | q1 r4 의 du · find 만 FAIL · q6 MISSING · q8 FAIL 둘 (오류 문구 `host:<HOST>:<PORT>` · `<IPV4>:<PORT>`) · q4 `-U` 만 FAIL · objdump 로 RUNPATH · 나머지 OK · rc 0 |
| t4 멈춘 명령 | sacct 가 TERM 을 무시하고 600 초 잔다 | q6 TIMEOUT 65 초 (60 + kill 5) · 뒤의 q7–q9 OK · 전체 66 초 · 남은 프로세스 0 |
| t5 예산 | `MIX_BUDGET=2` · 첫 du 3 초 | 첫 조회만 OK · SKIPPED_BUDGET 37 · 묶음 만듦 · 3.4 초 |
| t6 스위치 | `MIX_Q=q8` | 나머지 여덟 SKIPPED_SWITCH · 부른 가짜 명령 = df · stat (마운트 확인) · sinfo 만 |
| t7 Lustre 아님 | `MIX_Q='q4 q5'` | SKIPPED_NOT_LUSTRE 셋 · lfs 안 부름 |
| t8 게이트 | (a) 본문 한 글자 (b) CRLF (c) 대화형 `bash -i` (d) CRLF 를 DEM1 `sed 's/\r$//'` | (a) "md5 다름 — 아무것도 안 함" · 새 폴더 0 (b) 구분자가 안 닫혀 게이트 줄까지 삼킴 → 새 폴더 0 · rc 127 (c) 정상 (d) 원본과 바이트 같음 |
| t9 Ctrl-C | 첫 조회 줄이 생기면 조회 스크립트에 SIGINT (대상 = 시험이 띄운 bg 의 자손 · > 1 확인 뒤) | interrupted=1 · SKIPPED_INTERRUPT 32–33 (신호가 닿은 때에 따라) · 화면 알림 · 묶음 만듦 · 3.4–6.6 초 (안 멈추면 16 초 이상) |
| t10 ibb 경로 관계 | 실제 홈 = 접두 + 로그인 홈 (문자열이 꼬리로 품음) | 실제 경로 → `<HOME_REAL>` · 로그인 경로 → `<HOME>` · `/lustre<HOME>` 꼴 없음 |
| t11 실제 로그 꼴 (리포 읽기만) | 블록 본문의 q9 awk 를 그대로 꺼내 같은 빌드 로그 셋 (kg50 `log_ins1` · `log_main1103` · devu `log.exact`) 에 | mawk = gawk · 출력 = 센 수 · 가린 첫 낱말만 · `log_ins1` 의 삽입 run 표 안에 `INFO:` 1 · `-` 1 (등록 7-4 ③ 꼴) · `log.exact` 5 칸 머리 · 닫힘 |
| 판독기 | t1 · t2 · t3 · t6 묶음 · 변조 · 위조 | rc 0 (값 = 가짜 홈 실측) · 화면 sha256 다름 · md5 다름 · 묶음 안 한 글자 (SHA256SUMS 불일치) · `..` · 링크 · 하위 폴더 멤버 · 비어 있지 않은 풀 폴더 · `--forbid-file` 적중 = 전부 거부 |

시험 한계: 진짜 SLURM · Lustre · `lfs` · OpenMPI 가 없어 그 명령은 **가짜로만** 돌았다 (실제 출력 형식은 메타 out/ 과 Slurm · Lustre 문서 꼴로 흉내).  bash 4.4.20 (ibb) 에서 안 돌렸다 — 쓴 문법은 4.4 에 있는 것만 [문법 기준 · 실행 미확인].  bash 4.4 는 here-document 를 `$TMPDIR` 또는 `/tmp` 의 임시 파일로 잠깐 만들고 바로 지운다 (블록 밖 쓰기이지만 셸의 몫 · 메타와 같음) [추정 — 컨테이너 bash 5.2 는 파이프를 써서 재현 안 됨].  findutils 4.6 의 `%T@` 소수 자리수 · Lustre 의 `du` 할당 크기는 실물에서 확인된다.

## 4. 1저자가 할 일

1. ibb **로그인 셸** (SLURM 잡 안 아님 · bash) 에 `query_block.txt` 를 통째로 붙인다.  첫 줄의 md5 = `664376ce372ee4b60779d4f27e380165`.
2. 끝 화면에서 `가림 확인 … 0 곳` 과 `가져올 파일 ~/mixer_e0_query_<UTC>/mixer_e0_query_<UTC>.tgz` · `sha256 <64 자>` 두 줄을 본다.  ⚠ 남은 문자열이 0 이 아니면 넘기지 않는다.
3. tgz 하나를 WSL 로 가져온다 (scp — 주소 · 포트 · 계정은 1저자) → `sha256sum <파일>` 이 화면 값과 같은지 본다.
4. tgz 하나 + 화면의 sha256 값을 세션에 올린다.
- (선택) 발사 직전 빈 코어만 다시: `export MIX_Q=q8` 뒤 같은 블록을 붙인다 (작은 새 폴더 · tgz 하나) → 끝나면 `unset MIX_Q`.
- 폴더는 ibb 에 남는다 (`raw/` = 가리지 않은 원문 · 홈 700 안).  지울지는 1저자 (블록은 지우지 않는다).

## 5. 받은 묶음을 본 세션이 읽는 법

1. tgz 는 scratch 의 새 폴더에, 풀 곳은 **다른 빈 새 폴더** (판독기도 그 밖에).  계정 이름 · ibb 주소 · 포트를 한 줄에 하나씩 적은 금지 목록 파일을 scratch 에 따로 만든다 (리포 밖 · 쓰고 지운다).
2. `python3 -I <이 폴더>/read_query_bundle.py <tgz> <빈 새 폴더> --expect-md5 664376ce372ee4b60779d4f27e380165 --expect-sha256 <화면 값> --json <새 요약.json> --forbid-file <금지 목록>`
3. 판독기가 하는 일: 묶음 sha256 → 멤버 검사 (out/ 바로 아래 정규 파일만 · 절대경로 · `..` · 링크 · 장치 · 하위 폴더 · 크기 상한 · 소유자 이름 = 거부) → 직접 써서 풂 (extractall 안 씀) → `SHA256SUMS` 전수 → 스크립트 md5 → 형식 `mixer_e0_query/1` → 상태 어휘 → 남은 토큰 0 → 금지 문자열 0 → q1–q9 요약 (아래 6 절의 값) · `--json`.  rc 0 = 구조 정상일 뿐 **자격 아님** · rc 1 = 문제 목록 · rc 2 = 사용 거부.
4. 리포 반입 (하게 되면): 가린 out/ 만 · 새 증거 폴더 (예 `docs/data/mixer_e0_query_ibb_<날짜>/` [제안]) · README 에 묶음 sha256 · 스크립트 md5 · 판독기 rc · 금지 문자열 0 을 적는다 (11-10 메타 반입과 같은 규칙 · 등록 11 절 7–8).

## 6. 등록 초안 · 기준 표에 옮기는 법 (값은 판독기 `--json` 에서)

| 받는 칸 | 옮길 값 (JSON 키) | 하는 일 · 판단 |
|---|---|---|
| 등록 5-1 "없는 것" → 런별 실측 표 | `q1[*]`: `post.files` · `post.entries` (메타 1037 / 1467 과 `post_entries_vs_meta`) · `post.bytes` (파일 크기 합) · `post.max` · `restart.bytes` · `post_plus_restart_bytes` · `post_du_kb` · `restart_du_kb` | 다섯 런 표로.  "없는 것" 문장을 "q1 실측 (묶음 sha256 …)" 으로 바꾼다 |
| 등록 5-2 (폴더 평균 [추정]) | `q1[*].mean_frame_bytes` (= post 합 ÷ 파일 수 · 체크포인트 · 로그가 안 섞인 값) · `mean_vs_est52` | 5-5 대로 평균만 실측으로 바꾼다.  옛 11.94 MB 는 "대체됨" 으로 남긴다 |
| 등록 5-3 교차 확인 · 5-5 | `q1[*].max_vs_g_rule_bound` (≤ 1 이면 `%g` 규칙 14,000,512 B 가 위쪽 값) · `q3.rows[*]` 의 `hp_bytes_per_atom_nominal` ≤ 110 · `g6_…` ≤ 62 (6 열 · 폭 24 · 12 규칙을 6 열에 그대로) · `ratio_hp_over_g6` (모델 1.77) | 셋 다 맞으면 상한 29,266,573,952 B · 바닥 · inode 식 **그대로** (5-5 "식 그대로 · 평균만 실측").  하나라도 넘으면 상한을 고치지 말고 16 절 개정 절차 (등록 결함) 로 1저자에게 — 결과를 본 뒤 문턱을 옮기지 않는다.  q3 의 원자 수는 계획값 100,000 으로 나눈 근사 [한정] |
| 등록 4-1 (시간) · 4-2 | `q6.jobs[*].elapsed_s` · `elapsed_minus_reg41_s` | 열 하나 덧붙임 "sacct Elapsed".  4-2 의 dev-bo 차 3–4 초와 같은 크기면 읽는 법 확인 · 크게 다르면 4-2 에 적는다 (walltime 초안은 그대로 — 산술 근거만 보강) |
| 등록 4-1 메모리 (새 칸) · 기준 표 4 절 "메모리 요청 · 한도" | `q6.jobs[*].ReqMem` · `max_step_maxrss_bytes` (보통 `.batch` 스텝 · mpirun 과 20 rank 가 그 안) | 칸 채움.  MaxRSS 가 rank 합인지 최대 한 프로세스인지는 Slurm 수집 플러그인에 달렸다 [미확인 — 그대로 적고 해석은 보류] |
| 기준 표 0-A · 2 절 "링크 라이브러리 sha256" | `q7.libs[*]` (soname · ldd 경로 종류 · 실제 파일 sha256 · 크기) · `n_hashed / n_paths` · `n_not_found` · `q7.bin_sha256_or_reason` (= `ee2d7726…` 이어야 · `bin_vs_ref` same) | [미확인] → 표로 채움.  `bin_vs_ref` 가 different 면 Q4 (11-10) 대로 멈추고 1저자 |
| 기준 표 2 절 "라이브러리를 찾는 길" | `q7.rpath_lines` | RUNPATH / RPATH 문자열 (가린 꼴).  없으면 "없음 — conda 환경으로 풀리는 까닭은 다른 데 있다" 로 [미확인] 유지 |
| 기준 표 4 절 "다른 사용자 큐 · 빈 코어" | `q8.partitions` · `q8.cpu_nodes` · `cpu_nodes_with_idle_ge_20` | **시점 값** 으로만.  발사 직전 값은 `MIX_Q=q8` 로 다시 |
| 기준 표 5 절 "내 할당 (한도)" · "OST 별 여유" | `q4.default` 줄 · `q5.n_ost` · `min_avail_bytes` · `min_avail_vs_floor` | 칸 채움.  최소 OST 여유가 바닥 32,193,231,348 B 의 몇 배인지 함께 (파일 하나는 OST 하나에 놓인다 [추정 — 줄무늬 수 미확인]) |
| 등록 6 절 S5 산술 · 9 절 T2 | `q2.s_per_1000_steps` (= 프레임 간격) · `first_frame_after_job_start_s` · `steps_per_s_first_to_last` | 관찰로만 적는다 (S5 30 분 · T2 문턱은 그대로) |
| 등록 7-4 ③ · Q5 fixture | `q9.blocks_with_INFO` · `q9.blocks[*].words` · `header_cols` · `row_cols` · `closed` | "[관찰 · 다른 덱]" → "같은 덱 계열 DEV E0 실측" 으로.  INFO 등 비-행 첫 낱말 목록이 Q5 고침 (알려진 비-행 줄만 허용) 의 시험 입력이 된다 |
| 기준 표 9 절 [미확인] #1 #2 #5 #6 #7 #8 #9 #13 | 위 각 줄 | 채운 것은 근거를 "q<n> (묶음 sha256 …)" 로 · FAIL / MISSING 이면 [미확인] 그대로 + 사유 |

## 7. 한정 · 미확인 · 추정

- 이 묶음은 **관측** 이다 — 자격 수행 · 운영 승인 · 발사 GO 가 아니다.  sha256 은 내용 신원이지 작동 · 호환 증명이 아니다.  `UNKNOWN` · `MISSING` · `FAIL` 은 0 · 빈 큐 · 무제한이 아니다.
- q1–q3 · q6 · q9 는 **DEV (옛 덱 세대 · 기본 `%g` 덤프)** 의 값이다 — pilot (전 정밀도 12 열) 의 크기 · 시간이 아니다 (등록 4-3 · 15 절 한정 그대로).
- q8 · q4 · q5 는 조회 시점 값이다.
- 가림 한계 (메타와 같음): 낱말 경계 방식이라 계정 · 호스트가 다른 글자에 붙으면 안 가려진다 → 남은 토큰 수 · 판독기 `--forbid-file` 로 다시 본다.  오류 문구 속 다른 서버 이름은 `host:<이름>:<포트>` 꼴만 가린다.
- **미확인**: ibb 의 `lfs quota -U` 지원 여부 (Lustre 판 · 메타의 "default … quota setting" 줄로 보아 지원 [추정]) · 실제 `sacct` MaxRSS 의 뜻 · findutils 4.6 출력 꼴 · bash 4.4 실행.
- 본 세션 컨테이너에서 gawk 시험을 위해 `apt-get install gawk` 를 했고, 시스템 `awk` 대체 링크가 잠깐 (약 1 분) gawk 로 바뀌었다가 mawk 로 되돌렸다 (`update-alternatives --set awk /usr/bin/mawk`).  그 사이 리포 게이트가 awk 를 불렀다면 gawk 로 돌았을 수 있다 [관찰 · 영향 미확인].

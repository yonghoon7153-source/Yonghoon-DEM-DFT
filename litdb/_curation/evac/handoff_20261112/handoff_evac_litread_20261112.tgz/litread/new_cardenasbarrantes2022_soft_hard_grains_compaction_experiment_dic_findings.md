# new_cardenasbarrantes2022_soft_hard_grains_compaction_experiment_dic 정독 근거 (기존 카드의 보충자료 보강 · 원문 PDF 6 쪽 + 보충자료 4 쪽 전문 + 카드 812 줄 · 2026-11-10)

카드: `cardenasbarrantes2022_soft_hard_grains_compaction_experiment_dic` — M. Cárdenas-Barrantes, J. Barés, M. Renouf & É. Azéma,
"Experimental validation of a micromechanically based compaction law for mixtures of soft and hard grains", Physical Review E 106, L022901
(2022), DOI 10.1103/PhysRevE.106.L022901 + Supplemental Material (4 쪽).  **이 파일은 batch_03 의 이 카드 줄 (보충자료 미보유 시절) 을 대체한다.**

적는 법: 위치의 `L숫자` = 카드 줄 번호 (11-10 보강판 812 줄 기준) · 표지는 카드에 적힌 그대로 (`stated` = 본문에 인쇄된 값 · `SM 확인 (11-10)` =
보충자료 원문 · `[SM 벡터 판독]` = 보충자료 벡터 그림 경로에서 읽음 · `[판독]` = 래스터 그림에서 읽음 · `[카드 산술]` · `[미확인] — SM 에도 없음` ·
`ref [12] / ref [33] 원문` = 같은 장치의 선행 논문 원문 (inbox PDF · 2022 실험에 같은 값을 썼다는 명시는 없음)).
재료 = **실리콘 (초탄성) + PVC 원기둥 · 2D (평면 응력)** — LPSCl · NCM 아님 (카드: 절대값 전이 0 건 L12–14).

형식: `- [글자] slug | 내용 (값 · 단위) | 위치 | 표지 | 한계`

## a. 순수 SE (LPSCl · 황화물) 의 압력별 기공 곡선 · 진밀도 · 질량 기준 · 누른 채 / 뺀 뒤

- [a] cardenasbarrantes2022_soft_hard_grains_compaction_experiment_dic | 순수 SE 아님.  닿는 것 = 순수 무른 계 (κ = 1 · 실리콘) 의 누른 채 곡선: jamming φJ 0.780 ± 0.008 에서 그림 2b 끝 ≈ (27 kPa, φ − φJ 0.083) → φ ≈ 0.863 · 점근 φmax 0.97 (본문) / 0.99 (SM 표 II) | §3-2 L146–147 · §3-2b L163 · L178 · §3-3 L191 · 논문 p. L022901-2 · 그림 2b · SM 표 I · II | φJ · φmax = stated / SM 확인 (11-10) · 끝점 = digitized | 실리콘 초탄성 · 2D 평면 응력 · kPa · 누른 채 (1 min 이완 뒤 스캔) · φ 는 영상의 입자 경계 (바닥면 면적) 기준 — 질량 · 진밀도 개념 없음 · 자료는 φJ → φmax 의 40 % 까지만 간다 (φmax 는 맞춘 점근값 [카드 산술] L282)
- [a] cardenasbarrantes2022_soft_hard_grains_compaction_experiment_dic | 조성 하나 (κ 0.5) 의 평균 곡선 전체 (점 20 개): ε 0.0098 → 0.1978 에서 P 0.20 → 48.7 kPa · φ 0.8027 → 0.9050 · Z 2.69 → 4.39 (jamming 점 ε 0.049 · φ 0.831) | §3-3b L209–240 · SM 그림 1 (p. 2) | [SM 벡터 판독] | 2D · 실리콘 / PVC · 누른 채 · ± 의 정의 [미확인] — SM 에도 없음 (L165)

## b. 압력을 뺄 때 되돌아오는 양과 잰 방법

- [b] cardenasbarrantes2022_soft_hard_grains_compaction_experiment_dic | 없음 — 하중 단계만 (0.5 mm 이동 · 2 mm/min → 1 min 이완 → 스캔).  보충자료에도 탈압이 없다.  같은 장치의 선행 논문은 힘 사슬 좌굴로 입자가 유리에서 튀어 오르면 실험을 끝낸다 (초탄성 입자는 변형 ∼20 %) | §3-1 L110 · §3-1b L137 · §4-6 (iv) L403 · §12-A L710 | stated (절차) · 멈춤 사유는 ref [12] 원문 p. 042907-3 | 2D · 초탄성 (가역) — 탈압 근거로 쓸 수 없음 (카드 §10-2 6 L673–674)

## c. 항복 · 경도 · 크리프 값과 정의 · 일축 항복 세기 환산

- [c] cardenasbarrantes2022_soft_hard_grains_compaction_experiment_dic | 항복 · 경도 · 크리프 없음 (초탄성).  탄성 값만: 실리콘 E0 = 0.45 MPa · ν = 0.5 · PVC E = 1.2 GPa · 혼합 유효 영률 E\* = E0/[2κ(1 − ν²)] | §3-1 L112–113 · §3-2 L149 · 논문 p. L022901-2 | stated | 초탄성 · 2D
- [c] cardenasbarrantes2022_soft_hard_grains_compaction_experiment_dic | 식 (1) 에 실제로 쓴 E\* (SM 표 II): 2.67 · 1.00 · 0.62 · 0.50 MPa (κ 0.2 · 0.5 · 0.8 · 1.0) — 본문 정의에 E0 0.45 MPa · ν 0.5 를 넣은 값 (1.50 · 0.60 · 0.375 · 0.30) 의 1.65–1.78 배 (E ≈ 0.75 MPa 를 넣은 것과 같다) | §3-2b L171–178 · §3-4 L275–276 · SM 표 II (p. 4) | SM 확인 (11-10) · 비는 [카드 산술] | 본문 ↔ SM 어긋남 — 이유 원문에 없음 [미확인]

## d. 단단한 입자 + 무른 입자를 섞어 누를 때 단단한 입자의 하중 몫 · 재밍

- [d] cardenasbarrantes2022_soft_hard_grains_compaction_experiment_dic | 재밍 상태 (세 시료 평균 · κ 0.2 · 0.5 · 0.8 · 1.0): φJ 0.834 ± 0.007 · 0.831 ± 0.002 · 0.810 ± 0.005 · 0.780 ± 0.008 · ZJ 3.31 ± 0.19 · 3.50 ± 0.07 · 3.25 ± 0.04 · 3.30 ± 0.04 · εJ 0.017 ± 0.016 · 0.049 ± 0.002 · 0.021 ± 0.011 · 0.021 ± 0.011 — 강체가 많을수록 재밍 충전율이 높다 | §3-2b L156–169 · SM 표 I (p. 2) | SM 확인 (11-10) | 2D · 실리콘 / PVC · 판정 = 평균 P–ε 의 압력 상승 시작 (수치 문턱 없음 L343) · ± 정의 [미확인] · κ 0.8 · 1.0 의 εJ 칸이 같은 글자 (L166)
- [d] cardenasbarrantes2022_soft_hard_grains_compaction_experiment_dic | 최대 충전율 φmax: κ 0.2 · 0.5 · 0.8 · 1.0 → 0.88 · 0.94 · 0.98 · 0.99 (SM 표 II) — 본문은 κ = 1 을 0.97 로 적음.  원문 "φmax goes ideally from 1 for purely soft systems to φJ for purely rigid systems" | §3-2 L147 · §3-2b L173–181 · §11 L686–687 · 논문 p. L022901-3 | stated / SM 확인 (11-10) | 정한 방법 [미확인] — SM 에도 없음 · 자료가 φJ → φmax 의 40–68 % 까지만 간다 [카드 산술] L282
- [d] cardenasbarrantes2022_soft_hard_grains_compaction_experiment_dic | 힘–변형 곡선: κ 0.2 는 작은 ε 에서 힘이 가파르게 오르고 톱니 (급격한 재배열) — 끝 ≈ 170 N @ ε ≈ 0.10 (κ 0.2) · ≈ 95 N @ 0.17 (κ 1) | §3-3 L187–188 · 그림 1c | digitized | 단단한 입자의 **하중 몫** 을 잰 값은 없다 (접촉력 측정 없음 L545)
- [d] cardenasbarrantes2022_soft_hard_grains_compaction_experiment_dic | 전역 ÷ 국소 변형비 Γ 가 강체가 많을수록 크다: 5 · 4 · 3.4 · 3.05 (κ 0.2 → 1.0) = 같은 전역 변형을 접촉 변형이 덜 맡고 재배열이 더 맡는다 | §3-2 L150 · §3-3b L255–269 · §8-3 L601–603 · SM 표 II · 그림 3 (p. 4) | SM 확인 (11-10) · 해석은 카드 추론 | 그려진 직선의 기울기 역수는 4.39 · 3.57 · 3.55 · 3.06 으로 표와 κ 0.2 · 0.5 에서 12 · 11 % 다름 [SM 벡터 판독] · 국소 변형의 측정 정의 [미확인] — SM 에도 없음

## e. 점접촉 법칙이 큰 변형에서 깨지는 범위와 대안 · 대안마다 맞춘 값 개수

- [e] cardenasbarrantes2022_soft_hard_grains_compaction_experiment_dic | 무른 입자 평균 변형이 "밀도에 선형" 에서 "압력에 선형" 으로 바뀌는 교차 C_c = 0.991 ± 1.2 × 10⁻³ (κ 무관) — 작은 변형 환산 ≈ 0.45 % | §3-2 L151 · §3-4 L289 · §5-5 L463–470 · 논문 p. L022901-4 · 그림 4 | stated (C_c) · 환산은 [카드 산술] 거친 환산 | 2D · 실리콘 · 본문 ⟨𝒞⟩ 의 통계 정의 · 정규화가 SM 에도 없다 (§12-B 9 L728–731) — 다른 계산의 변형 척도와 수치로 견주지 않는다
- [e] cardenasbarrantes2022_soft_hard_grains_compaction_experiment_dic | 보충자료의 Hertz 닫음: 평균 접촉 응력 σ_l ≃ (π/4)E\*ε_l (식 13) 과 ε = Γ ε_l 은 "at the small deformation domain" (그림 3 캡션) 의 것.  큰 변형은 접촉 법칙으로 풀지 않고 φmax 에서 발산하는 로그 꼴로 대신한다 (그 꼴의 일축 근거는 SM 에 없고 2020 판에 맡김) | §4-4 L359–375 · SM p. 3–4 식 (12) · (13) | SM 확인 (11-10) · 이어 본 식은 [카드 산술] | 탄성 · Hertz 가정 · 2D
- [e] cardenasbarrantes2022_soft_hard_grains_compaction_experiment_dic | 대안 (압밀 식 1) 이 받는 값: κ 마다 φJ · ZJ (표 I) · φmax · E\* · Γ (표 II) + 공통 k = 4.9 · μM = 0.25 (문헌) — "without any ad hoc parameters" 라 쓰지만 조성마다 입력 다섯 | §4-4 L380–382 · §9-7 L633–636 | 값은 SM 확인 (11-10) · 세는 것은 카드 | multi-contact · MDR · EEPA · Thornton–Ning · Storåkers 는 이 논문에 없음
- [e] cardenasbarrantes2022_soft_hard_grains_compaction_experiment_dic | 접촉 길이 선형의 Hertz 척도 유도 (SM 식 5–11) 는 식 (8) 에서 ZJ 를 뺀 꼴 — 본문 법칙 (Z − ZJ = k(φ − φJ)^0.5) 을 넣으면 ⟨l⟩ ∼ ZJ(φ − φJ)^0.5 + k(φ − φJ) 이고 두 항이 같아지는 곳 (ZJ/k)² ≈ 0.44–0.51 이 실험 범위 (≤ 0.12) 밖 → 점접촉 척도는 선형을 주지 않는다 | §3-4 L285 · §5-4 L439–458 · SM p. 3 | SM 확인 (11-10) · 판정은 [카드 산술] | 같은 그룹 2021 학회판 (ref [33] 원문 p. 2) 은 이 선형이 2D Hertz 와 "not in agreement" 라고 적음 (L455–457)

## f. MPM 의 접촉 · 다물체 · 강체 결합 방법 · 해상도 규칙 (지름당 셀 수) · 수치 오차 추정

- [f] cardenasbarrantes2022_soft_hard_grains_compaction_experiment_dic | MPM 아님 (실험).  측정 해상도만: 2400 dpi (10.6 µm/px) → 지름 20 mm ≈ 1890 px · 30 mm ≈ 2830 px · 무늬 상관길이 50 µm ≈ 5 px | §3-1 L111 · L118 · §3-4 L288 | stated (환산은 [카드 산술]) | 영상 해상도 ≠ 계산 격자
- [f] cardenasbarrantes2022_soft_hard_grains_compaction_experiment_dic | 변형 척도의 정의 (MPM 이 같은 양을 낼 때의 본): F = ∇u + I → C = FᵀF → 𝒞 = √(C : C) — 인쇄 그대로면 무변형에서 √2 (2D) 인데 그림은 1 → 정규화 미기재 | §4-2 6 L323–326 · §3-4 L290 · SM p. 1 식 (1)–(4) | SM 확인 (11-10) · √2 는 [카드 산술] | 견줄 때 정규화와 2D/3D 를 맞춰야 함

## g. 2D 결과를 3D 로 옮길 때의 경고 · 증거

- [g] cardenasbarrantes2022_soft_hard_grains_compaction_experiment_dic | 원문에 2D → 3D 전이에 대한 문장 없음 (모델 계보로 3D 판을 인용할 뿐 · 전망은 비원형 입자 · 다른 유변학 혼합) | §4-6 (iii) L402 · 논문 p. L022901-2 · 4 | 카드 판정 (원문에 없음) | —
- [g] cardenasbarrantes2022_soft_hard_grains_compaction_experiment_dic | "2D 실험 ≠ 2D 계산" 의 증거: 평면 응력이라 φ(ε) 가 면적 보존 관계보다 낮다 — κ 0.5 에서 ε 0.198 일 때 0.905 (측정) vs 0.985 → 입자 바닥면 면적 합이 재밍 때의 0.92 배.  보충자료 식 (9) ε = (φ − φJ)/φJ 는 재밍 직후에만 맞고 끝에서 0.60 배 | §3-4 L284 · §8-2 L584 · §9-9 L640–642 | [카드 산술 · SM 벡터 판독] | 읽기 (높이 방향으로 부푼다) 는 추정 — 높이 방향 측정은 [미확인] — SM 에도 없음

## h. DEM 에서 FE · MPM 으로 넘긴 선례와 넘긴 시점

- [h] cardenasbarrantes2022_soft_hard_grains_compaction_experiment_dic | 해당 없음 (실험).  출발 상태 만드는 법만: 같은 크기 · 같은 강성 이웃을 최소화해 균질하게 · "jamming 을 관측할 만큼 느슨하게" 준비 | §3-1 L119–120 · §4-3 L332–333 · 논문 p. L022901-2 | stated | —

## i. 복합 양극 (AM + SE) 의 압력별 기공

- [i] cardenasbarrantes2022_soft_hard_grains_compaction_experiment_dic | 없음 (모델 소재).  유비로만: 단단한 + 무른 2D 혼합의 φ − φJ 끝값 0.047 (κ 0.2 · 59 kPa) … 0.085 (κ 0.8 · 35 kPa) | §3-3 L191 · 그림 2b | digitized | 2D · 실리콘 / PVC · kPa — 값 전이 금지

## j. 카드가 스스로 "아직 못 한다 · 한계" 라고 적은 것 가운데 가압 · 탈압 계산과 닿는 것

- [j] cardenasbarrantes2022_soft_hard_grains_compaction_experiment_dic | 저자가 적은 한계: 계가 작아 (n ≈ 100) 초기 조건 · 준비에 민감 · 작은 κ 에서 입자가 급격히 재배열할 때 식과 어긋남 | §4-3 L332 · §5-2 L421–422 · 논문 p. L022901-2 | stated | —
- [j] cardenasbarrantes2022_soft_hard_grains_compaction_experiment_dic | 카드가 적은 한계: 탈압 없음 · 소성 없음 · 2D 평면 응력 · φmax 를 정한 방법 없음 · 식 (1) 이 κ 0.5 평균 자료보다 중간 밀도에서 압력을 최대 ≈ 1.7–1.9 배 높게 줌 (끝에서 ±6 %) · 본문 ⟨𝒞⟩ · σ_𝒞 의 정의를 모름 | §3-4 L281 · §12-A L710 · §12-B L712–736 · §12-C L738–769 | [카드 산술 + 판독] · [미확인] — SM 에도 없음 | 판독에 기댄 판정

## k. DEM 의 한계 (논문이 직접 말한 문장 · 수치)

- [k] cardenasbarrantes2022_soft_hard_grains_compaction_experiment_dic (M. Cárdenas-Barrantes · J. Barés · M. Renouf · É. Azéma, Physical Review E 106, L022901, 2022) | **DEM 을 쓰지 않는 실험 논문 — DEM 의 한계를 직접 말한 문장은 없음 ("말 없음").**  닿는 문장 ①: Hertz 점접촉 척도는 작은 변형 한정 — *"in the small deformation regime, a scaling consideration of the Hertz contact law [48] as well as the Z vs φ − φ0 equation permits us to predict this linear relation [32]. It is important to note that this linearity persists far beyond the small deformation regime"* | §4-6 (i) L399 · 논문 p. L022901-3 → 4 | 원문 인용 | 2D · 실리콘 · 이 "예측" 은 SM 식 (8) 에서 ZJ 를 뺀 꼴에서만 선다 [카드 산술] L452–454
- [k] cardenasbarrantes2022_soft_hard_grains_compaction_experiment_dic (같은 서지) | 닿는 문장 ②: 조밀 쪽은 입자계가 벌크처럼 — *"In the second regime, linearity between strain and stress suggests that the material behaves like a bulk one (except for small rearrangements); this is consistent with the fact that the material is very dense with almost no interstitial porosity."* 경계 = 무른 입자 평균 변형 C_c ≈ 0.991 (κ 무관) | §4-6 (i) L399 · §11 L690–691 · 논문 p. L022901-4 | 원문 인용 · C_c 는 stated | 본문 ⟨𝒞⟩ 의 통계 정의 · 정규화 미기재 (L728–731)
- [k] cardenasbarrantes2022_soft_hard_grains_compaction_experiment_dic (같은 서지 · 보충자료) | 닿는 문장 ③: 보충자료의 Hertz 닫음과 Γ 는 *"at the small deformation domain"* (SM 그림 3 캡션) | §4-6 (i) L400 · §4-4 L369 · SM p. 4 | SM 확인 (11-10) | —
- [k] (같은 그룹의 다른 논문 — 인용할 때 서지를 따로: J. Barés · M. Cárdenas-Barrantes · D. Cantor · É. Azéma · M. Renouf, EPJ Web of Conferences 249, 05004, 2021 · 카드는 따로 들어온다) | 접촉 길이의 선형 증가는 *"not in agreement with the Hertz's contact law in 2D [24]. This last point is not surprising since soft particles are far from the small deformation assumption in our study."* | 이 카드 §5-4 L455–457 · 그 논문 p. 2 (inbox PDF) | ref [33] 원문 인용 | 2D · 실리콘 / PVC · 그 논문의 카드가 들어오면 거기서 다시 확인

## l. 소성변형이 왜 어려운가 (논문의 설명 · 우회 · 값)

- [l] cardenasbarrantes2022_soft_hard_grains_compaction_experiment_dic (M. Cárdenas-Barrantes · J. Barés · M. Renouf · É. Azéma, Physical Review E 106, L022901, 2022) | **소성은 다루지 않는다** (무른 입자 = 가역 초탄성 실리콘).  어려움에 대한 말은 "큰 변형 + 혼합" 쪽: 무른 + 단단한 혼합이 jamming 훨씬 위에서 보이는 거동은 *"remains mostly misunderstood"* · *"no local measurements have been performed to understand the microprocesses leading to their characteristic macroscopic behavior"* · 두 기전 (재배열 · 변형) 이 깊은 jammed 상태에서도 경쟁한다 | §4-6 (ii) L401 · §11 L680–683 · 논문 p. L022901-1 | 원문 인용 | 소성 근거 아님
- [l] cardenasbarrantes2022_soft_hard_grains_compaction_experiment_dic (같은 서지) | 우회 = 계산이 아니라 측정 (대변형 DIC 로 입자 내부 변위장).  비용: 실험당 영상 약 90 장 × ~500 메가픽셀 · κ 4 수준 × 3 시료 · 입자 약 100 개가 한계 | §3-1 L111 · L115 · L119 · §4-6 (ii) L401 | stated | 2D 바닥면만
- [l] cardenasbarrantes2022_soft_hard_grains_compaction_experiment_dic (같은 서지 · 보충자료) | 모델 쪽 우회와 값: 큰 변형을 접촉 법칙으로 풀지 않고 φmax 에서 발산하는 로그 꼴로 대신 · 입력 = κ 마다 다섯 (φJ · ZJ · φmax · E\* · Γ) + k 4.9 · μM 0.25.  맞춘 대상 = 이 실험의 P–φ 곡선 · 검증 = 같은 곡선 (그림 2b).  검산: 그 입력으로 식 (1) 은 실선과 모양이 같고 압력 3–18 % 높음 · κ 0.5 자료와는 끝 ±6 % · 중간 최대 ≈ 1.7–1.9 배 | §4-4 L372–382 · §3-4 L278–282 · SM 표 I · II | SM 확인 (11-10) · 검산은 [카드 산술 + 판독] | φmax 정한 방법 [미확인] — SM 에도 없음 · 탄성 · Hertz 가정

## m. 받아들일 통찰 (바로 가져다 쓸 것)

- [m] cardenasbarrantes2022_soft_hard_grains_compaction_experiment_dic (M. Cárdenas-Barrantes · J. Barés · M. Renouf · É. Azéma, Physical Review E 106, L022901, 2022 · 보충자료) | 방법 — jamming 판정 절차: 시드 (시료) 평균 압력–변형 곡선에서 압력이 0 근처에 머물다 오르기 시작하는 변형을 잡고, 그 변형에서 충전율 · 배위수를 읽는다.  원문에는 수치 문턱이 없으므로 (그림의 선 ≈ 0.92 kPa = 끝 압력의 1.9 %) 우리 쪽에서 문턱과 시드별 흩어짐을 결과 전에 적는다 | 단계 0; 단계 4; 단계 5 | 저자도 "Many definitions of this transition exist" 라 적고 하나를 골랐다 · φJ 가 조성에 따라 0.834 → 0.780 으로 움직이고 κ 0.2 의 εJ 는 오차가 값만큼 크다 (0.017 ± 0.016) — 판정 규칙이 다르면 φ − φJ 축 전체가 밀린다 (§4-3 L334–344 · §3-3b L235–239 · §9-6 L630–632 · SM p. 1 · 그림 1 · 표 I) | SM 확인 (11-10) · 문턱 값은 [SM 벡터 판독]
- [m] cardenasbarrantes2022_soft_hard_grains_compaction_experiment_dic (같은 서지 · 보충자료) | 관측량 정의 — 전역 ÷ 국소 변형비 Γ: 국소 (접촉) 변형을 전역 변형에 대해 그린 직선의 기울기 역수.  우리 DEM 압축 궤적의 평균 접촉 겹침 ÷ 지름 대 판 변형으로 새 런 없이 조성별로 잴 수 있다 | 후보 D0; 단계 5; 결과 전 대조 항목 (형식만 · 값 아님) | 실험에서 강체가 많을수록 Γ 가 크다 (3.05 → 5) = 재배열이 변형을 더 맡는다 · 입자 경계가 있는 후보에서만 정의됨 (§3-3b L255–269 · §8-3 L601–603 · §10-2 4 L668–669 · SM 표 II · 그림 3) | SM 확인 (11-10) · 2D · 탄성 · 평면 응력 값이라 기대값으로 쓰지 않음
- [m] cardenasbarrantes2022_soft_hard_grains_compaction_experiment_dic (같은 서지 · 보충자료) | 함정 — 닫힌 꼴 압밀 식 ("매개변수 없음") 은 조성마다 잰 입력 다섯 개를 받는 재서술이고, 그 입력으로도 곡선의 끝만 ±6 % 로 맞고 중간 밀도에서 압력이 최대 ≈ 1.7–1.9 배 높다.  φmax 는 자료가 닿은 값이 아니라 점근 매개변수 (자료는 그 구간의 40–68 %) | 후보 M0; 조건 R5; 단계 4 (보정 표적 고르기) | 이런 식은 후보 모델의 출력을 요약 · 비교하는 틀로만 쓰고 보정 표적 · 예측으로 쓰지 않는다 (§3-4 L278–282 · §4-4 L380–382 · §9-7 L633–636) | [카드 산술 + 판독] · SM 확인 (11-10)
- [m] cardenasbarrantes2022_soft_hard_grains_compaction_experiment_dic (같은 서지 · 보충자료) | 함정 둘 — (가) 2D 실험의 충전율은 면적 보존 양이 아니다 (평면 응력 · 입자 면적 −8 %): 2D 계산 (평면 변형률) 과 나란히 놓을 때 정의를 맞춘다 (나) 접촉 길이 (피복) 의 선형을 점접촉 척도 논리로 뒷받침하지 않는다 — 보충자료 유도는 ZJ 를 뺀 꼴에서만 서고 같은 그룹의 2021 글은 반대로 적었다 | 단계 2; 단계 3 (2D 시험의 대조 기준); 단계 7 (피복 정의); 흐름 밖: 접촉 면적 · 피복을 조밀 영역으로 외삽할 때 | 선형 · 조성 무관은 실측 사실로만 (모양 기준) (§3-4 L284–285 · §5-4 L452–458 · §9-8 · 9 L637–642) | [카드 산술 · SM 벡터 판독] · ref [33] 원문

## 카드 문제

없음.  (batch_03 이 적은 이 카드의 문제 4 — 그림 판독값끼리 끝값이 다름 — 는 11-10 보강판에서 "원문 그림끼리의 차이" 로 정리됐다: 카드 L200–205.
삽도 기울기의 단위 (Pa⁻¹) 도 본 패널 판독과 맞춰 확인됨: L194.)

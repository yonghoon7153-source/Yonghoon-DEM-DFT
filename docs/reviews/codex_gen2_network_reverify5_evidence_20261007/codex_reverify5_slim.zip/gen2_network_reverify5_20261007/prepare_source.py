from pathlib import Path
import json,hashlib,shutil,tarfile
R=Path(__file__).resolve().parent;O=R.parent/'gen2_network_reverify4_20261007/source'
plan=json.loads((R/'source_plan.json').read_text(encoding='utf8'))
def blob(b):return hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
out=[]
for x in plan['files']:
 p=R/'source'/x['path'];p.parent.mkdir(parents=True,exist_ok=True)
 if x['reused'] or x['local']:
  q=O/x['path'] if x['reused'] else Path('C:/Users/Administrator/Downloads')/p.name
  assert blob(q.read_bytes())==x['sha'],str(q)
  shutil.copyfile(q,p)
 b=p.read_bytes()
 if blob(b)!=x['sha']:
  variants=[b[:-1],b.replace(b'\r\n',b'\n').replace(b'\n',b'\r\n'),b[:-1].replace(b'\r\n',b'\n').replace(b'\n',b'\r\n')]
  matched=[v for v in variants if blob(v)==x['sha']]
  assert matched,str(p)
  b=matched[0];p.write_bytes(b)
 assert blob(b)==x['sha'] and len(b)==x['size'],str(p)
 out.append(dict(path=x['path'],ref=plan['pin'],sha=x['sha'],sha256=hashlib.sha256(b).hexdigest(),bytes=len(b)))
(R/'source_manifest.json').write_text(json.dumps(out,indent=2),encoding='utf8')
for folder in ('evidence','probes','submitted','tmp','notes'):(R/folder).mkdir(exist_ok=True)
p=R/'source/docs/reviews/codex_gen2_network_reverify5_precheck_20261007/g2rr5_839dbac6b_1007_2224.tar.gz'
with tarfile.open(p) as tf:
 ms=tf.getmembers();dest=R/'submitted'
 for m in ms:
  target=(dest/m.name).resolve();assert target.is_relative_to(dest.resolve()) and (m.isfile() or m.isdir()),m.name
 for m in ms:
  target=dest/m.name
  if m.isdir():target.mkdir(parents=True,exist_ok=True)
  else:
   target.parent.mkdir(parents=True,exist_ok=True)
   with tf.extractfile(m) as src,target.open('wb') as dst:shutil.copyfileobj(src,dst)
inv=dict(name=p.name,sha256=hashlib.sha256(p.read_bytes()).hexdigest(),members=[dict(name=m.name,size=m.size) for m in ms])
(R/'evidence/archive_inventory.json').write_text(json.dumps(inv,indent=2),encoding='utf8')
shutil.copyfile('C:/Users/Administrator/.codex/attachments/26f69526-7369-4b89-acd6-abd7b9f11307/붙여넣은 텍스트.txt',R/'submitted/request.txt')
print('Verified',len(out),'source files. PIN',plan['pin']);print('Archive',inv['sha256'],len(ms),'members')

# 실행 지시 — 믹서 E0 자격 pilot 내부 반박 리뷰 (11-12 · 독립 조수 · Codex 아님)

**본 지시서 = `…/scratchpad/mixer_e0_v2/review_brief.md` 전문.** 처음부터 끝까지 읽고 그대로 한다. 아래는 그 뒤에 생긴 것 (더할 대상 · 바뀐 사실) 만이다.

## 더할 대상

| 무엇 | 자리 |
|---|---|
| ibb 읽기 조회 결과 (가린 사본 · 믿지 않는 자료) | 요약 `…/scratchpad/intake/mixer_e0_query_20261112/summary.json` · 판독 화면 `…/intake/mixer_e0_query_20261112/reader.log` · 풀린 `…/intake/mixer_e0_query_20261112/x/out/` (묶음 sha256 a5753648… · 판독기 rc 0) |
| 조회 블록 · 판독기 | `…/scratchpad/mixer_e0_v2/query_block/` (query_block.txt · src/ · read_query_bundle.py · test/) — 블록이 쓰는 곳 · 가림 · 실패 처리 |
| 관측기 로그 계약 고침 (Q5) | 리포 로컬 커밋 `51d45732c` (시험 먼저) · `f67c0cc92` (고침) — `git -C /home/user/Yonghoon-DEM-DFT show <sha>` · `scripts/mixer_precal_observe.py` · `scripts/test_mixer_precal_observe.py` (HEAD 읽기만) · 재봉인 후보 `…/mixer_e0_v2/fix_q5/seal_candidate/source_seal.candidate.json` |
| 조회 뒤 채운 초안 | 같은 등록 초안 · 기준 표 (고친 판) · 고치기 전 판 `*_before_query.md` (차이로 무엇을 채웠나 보기) |

- 채운 쪽 설명 `fill_report.md` · `changes.md` 5 절은 **맨 마지막에** "주장이 본문에 들어갔나" 대조에만.

## 바뀐 사실 (1저자 11-12 결정 · 리뷰 대상이 아님 · 지켰는지만 본다)

- 초안 Q1–Q13 권고대로 · Q-A 짧은 삽입 = TECH 유지 → E6 다시 씀 · Q-B 봉인 전 q9 대조 · Q-C 재봉인 = 별도 승인 (핀 = 고침 커밋) · Q-D 옛 합성 꼴 거부 · Q-E first8 묶음 시험 HEAD 실패 = 기록만.

## 더 볼 것 (review_brief 의 G1–G13 에 더해)

- G14 — 관측기 고침 (Q5): 받는 줄 넷 (머리 · Loop 끝 · 삽입 보고 두 줄 · 주석 메아리) 이 진짜 결함 로그를 받아들이는 꼴 (손으로 만든 작은 로그) · q9 의 첫 낱말 수준 대조가 실제 줄 꼴을 보장하지 못하는 자리.
- G15 — 조회 결과를 등록 칸으로 옮길 때 문턱을 결과 보고 옮겼나 (채운 쪽은 "문턱 그대로" 라 주장 — 확인).
- G16 — RPATH = 사용자 conda env: 바이너리 sha256 만으로 런타임이 고정되지 않는 자리가 봉인 · 영수증 · 다음 wave 판단에 어떻게 새나.

## 규칙 더함

- 리포 본 트리는 게이트가 도는 중 — 읽기만 (git 상태 변경 금지 · 시험을 돌리려면 `git archive HEAD | tar -x` 로 만든 scratch 사본에서 · 무거운 시험 하나씩).
- Artifact 도구 · 웹 게시 · 시스템 패키지 설치 · 시스템 설정 (apt · update-alternatives) 변경 금지.
- 하네스가 보고 파일 쓰기를 막으면 답장에 같은 꼴로 싣는다.

## 산출 · 답장

review_brief.md 가 정한 자리 · 꼴 (항목 번호 `MXE0R-NN`) · 답장 10 줄 안팎 (P1 · P2 · P3 수 · 가장 무거운 셋 · 보장별 판정 · 산출 파일 전체 경로).

"""Read-only scan: list non-numeric-row lines inside thermo tables (header .. Loop) of given logs."""
import re, sys, collections
for path in sys.argv[1:]:
    text = open(path, 'rb').read().decode('utf-8', 'replace')
    lines = text.splitlines()
    active = False; nt = 0; kinds = collections.Counter(); headers = collections.Counter(); loops = collections.Counter()
    for ln in lines:
        t = ln.split()
        if t and t[0] == 'Step' and len(t) >= 2 and all(re.fullmatch(r'[A-Za-z_][A-Za-z0-9_\[\]]*', x) for x in t):
            active = True; nt += 1; headers[' '.join(t)] += 1; continue
        if ln.startswith('Loop time of'):
            loops[re.sub(r'[0-9.e+-]+', '#', ln)[:90]] += 1
            active = False; continue
        if active and t:
            if all(re.fullmatch(r'[-+0-9.eE]+|nan|inf|-nan|-inf', x, re.I) for x in t):
                continue
            kinds[re.sub(r'[0-9][0-9.e+-]*', '#', ln.strip())[:110]] += 1
    print('==', path, 'tables', nt)
    for k, v in headers.items(): print('  header', v, '|', k)
    for k, v in loops.items(): print('  loop', v, '|', k)
    for k, v in kinds.most_common(): print('  nonrow', v, '|', k)
    print('  ERROR line-start:', sum(1 for l in lines if re.match(r'\s*ERROR', l)), ' ERROR anywhere:', sum(1 for l in lines if 'ERROR' in l), ' comment lines:', sum(1 for l in lines if l.startswith('#')))

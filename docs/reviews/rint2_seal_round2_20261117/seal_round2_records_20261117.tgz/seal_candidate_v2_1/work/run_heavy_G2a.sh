#!/bin/bash
# G″a 위 무거운 시험 (차례로 · nice -n 10 · python3 -I · scratch 사본 안)
cd /tmp/claude-0/-home-user-Yonghoon-DEM-DFT/81c0ad95-542f-503b-9cf7-2f6a678a4b5b/scratchpad/rint/v21_clone || exit 9
H=$(git rev-parse HEAD); PY=$(python3 -V 2>&1)
run() { name=$1; shift; { echo "# HEAD $H (G″a · v2.1 · 봉인 꼴 한 커밋 · 부모 64e4d213e) · $PY · $*"; ( time nice -n 10 "$@" ) 2>&1; echo "rc=$?"; } > /tmp/claude-0/-home-user-Yonghoon-DEM-DFT/81c0ad95-542f-503b-9cf7-2f6a678a4b5b/scratchpad/rint/seal_candidate_v2_1/work/evG2a/$name.txt 2>&1; }
run e13_seal_doc_tests python3 -I scripts/test_rint_r_chain.py --only K01,PC18,PC20,EP06
run e2_e2e_E17 python3 -I scripts/test_rint_r_chain_e2e.py --only E17
run e14_ca_s0_census python3 -I scripts/test_ca_s0_census.py
run e14_ca_ext_z3 python3 -I scripts/test_ca_ext_z3.py
run e7_check_method_discipline python3 -I scripts/check_method_discipline.py
run e1_test_rint_r_chain_full python3 -I scripts/test_rint_r_chain.py
run e14_probe6_read python3 -I docs/reviews/rint2_probe6_prep_20261110/tools/test_probe6_read.py
echo ALL_DONE > /tmp/claude-0/-home-user-Yonghoon-DEM-DFT/81c0ad95-542f-503b-9cf7-2f6a678a4b5b/scratchpad/rint/seal_candidate_v2_1/work/evG2a/_done.txt

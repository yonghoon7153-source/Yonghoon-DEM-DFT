from pathlib import Path
from decimal import Decimal as D
import sys,os,types,builtins,json,hashlib,time,io,contextlib,traceback,copy
R=Path(__file__).resolve().parent;C=R.parent/'bmin_r2_limited_validation_20261005/received/candidate';began=time.monotonic();results=[];traces=set();cache={};cache_records=[]
def blocked(*a,**k):raise RuntimeError('INERT_NATIVE_PROCESS_GATE')
def audit(event,args):
 if event in ('subprocess.Popen','os.system','os.startfile','ctypes.dlopen','builtins.input') or event.startswith('winreg.'):blocked()
sys.addaudithook(audit);builtins.input=blocked
for name in ('winjob','msvcrt'):
 m=types.ModuleType(name);m.__getattr__=blocked;sys.modules[name]=m
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
seal=json.loads((R/'PRE_TEST_SEAL.json').read_bytes())
verified_inodes={}
for pin in seal['files']:
 p=Path(pin['path']);st=p.stat();key=(st.st_dev,st.st_ino,st.st_size,st.st_mtime_ns)
 if key not in verified_inodes:verified_inodes[key]=sha(p)
 assert verified_inodes[key]==pin['sha256'] and st.st_size==pin['bytes'],'SEAL_CHANGED'
def load(p):
 m=types.ModuleType('inert_'+p.stem);m.__file__=str(p);exec(compile(p.read_bytes(),str(p),'exec'),m.__dict__);return m
def track(module,names):
 for name in names:
  original=getattr(module,name)
  def wrapped(*a,_fn=original,**k):
   traces.add(_fn.__name__);return _fn(*a,**k)
  wrapped.__name__=original.__name__;wrapped.__wrapped__=original
  setattr(module,name,wrapped)
E=load(C/'src/candidate_entry.py')
track(E,('analyze','execute','source_module'))
MH=sha(C/'CODE_MANIFEST.json');original_source=E.source_module
def put(p,o):
 with p.open('x',encoding='utf-8') as f:json.dump(o,f,ensure_ascii=False,allow_nan=False)
active=None
def source(name,path,pin):
 m=original_source(name,path,pin)
 if Path(path).name=='diagnostic_consumer.py':
  track(m,('guard_evidence','native_stop','binding_evidence','window_coverage','profile','units_evidence','numeric','analyze','three_fields','runtime_evidence','mesh_evidence','extract_tables','pinned','timed'))
  original=m.profile
  def prof(p,ts,coords,domain,limit):
   raw=Path(p).read_bytes();key=(hashlib.sha256(raw).hexdigest(),tuple(ts),tuple(coords),domain,str(limit))
   if key in cache:
    cache_records.append({'mode':'EXACT_BYTES_REUSE','sha256':key[0],'rows':241*len(ts)});return cache[key]
   v=original(p,ts,coords,domain,limit);cache[key]=v;cache_records.append({'mode':'ORIGINAL_READER','sha256':key[0],'rows':241*len(ts)});return v
  m.profile=prof
  def extraction(console,dest):
   dest=Path(dest);dest.mkdir();found={}
   for p in (active/'tables_source').iterdir():
    q=dest/p.name;os.link(p,q);found[p.name]=m.identity(q)
   return found
  m.extract_tables=extraction
 return m
E.source_module=source
cases=json.loads((R/'PREPARED_PYTHON_INPUTS.json').read_bytes());out=R/'results';out.mkdir()
reason_map={'PY02-01':'DID_NOT_REACH_150','PY02-02':'GUARD_TIME_RANGE','PY02-03':'PRODUCER_OUTPUT_FAILURE','PY03-01':'MESH_READBACK:AXES_PARTICLE=pce1|Nel=640|Nord=1|Distribution=CubicRoot','PY03-02':'MESH_READBACK:AXES_PHYSICAL_MESH_DOMAIN=2|numelem=60','PY03-03':'RUNTIME_SETTING_VS_NORMAL480:electrolyte_positive_check','PY03-04':'RUNTIME_SETTING:rtol','PY03-07':'TRANSIENT_DOF_READBACK_COUNT:0','PY03-08':'TRANSIENT_DOF_READBACK_COUNT:0','PY03-09':'TRANSIENT_DOF_READBACK_COUNT:2','PY03-10':'TRANSIENT_DOF_READBACK_FORMAT','PY03-11':'TRANSIENT_DOF_READBACK_FORMAT','PY03-12':'TRANSIENT_DOF_READBACK_FORMAT','PY03-14':'TRANSIENT_DOF_READBACK_VALUE','PY04-01':'SOURCE_IDENTITY','PY04-02':'SOURCE_IDENTITY','PY04-03':'BASELINE_IDENTITY','PY05-01':'STRICT_REQUEST_TIME_MISSING','PY05-02':'STRICT_REQUEST_TIME_MISSING','PY05-03':'RUNTIME_TLIST','PY05-04':'PRIMARY_CONTRACT','PY05-05':'STRICT_REQUEST_TIME_MISSING','PY06-01':'NONFINITE','PY06-02':'LI_DRIFT','PY06-03':'INITIAL_LI_COMPONENT','PY06-04':'LIMIT_CONTRACT','PY07-02':'FINAL_BUDGET'}
failed=None
try:
 for case in cases:
  assert time.monotonic()-began<=250,'PYTHON_BUDGET'
  id=case['id'];idx=case['input_index'];active=Path(case['path']);c=json.loads((active/'contract_fixture.json').read_bytes());run=Path(c['run_root']);traces.clear()
  before=time.monotonic();stream=io.StringIO();state={'run_id':c['run_id'],'code_manifest_sha256':MH,'start':time.monotonic(),'status':'NATIVE_RETURN_READY','errors':[],'preservation':'PASS','process_cleanup':'PASS','policy_preservation':'PASS'}
  if id=='PY07-01':state.update(status='INCOMPLETE',errors=[{'error':'NATIVE_PHASE_BUDGET'}])
  if id=='PY04-03':
   c['cwd']=Path.cwd().resolve().as_posix();next(iter(c['baseline_files'].values()))['bytes']+=1
   original_check=E.check;original_loader=E.source_module;original_seal=E.seal
   dummy=types.SimpleNamespace(NativeAdapter=lambda:object(),environment=lambda *a:None)
   E.source_module=lambda *a:dummy;E.check=lambda p:b'{}' if p==c['legacy_contract'] else original_check(p);E.seal=blocked
   try:
    with contextlib.redirect_stdout(stream):rc=E.execute(c,{},MH)
   finally:E.check=original_check;E.source_module=original_loader;E.seal=original_seal
   r=json.loads((run/'NATIVE_STATE.json').read_bytes());assert rc==1 and r['native_attempts']=={} and r['errors'][0]['error']=='BASELINE_IDENTITY',r
  else:
   run.mkdir();put(run/'NATIVE_STATE.json',state);os.link(active/'batch.log',run/'batch.log');os.link(active/'console.log',run/'batch_console.log')
   oldtime=E.time
   if id=='PY07-02':
    calls=[0]
    def clock():
     calls[0]+=1;return oldtime.monotonic()+(901 if calls[0]>=3 else 0)
    E.time=types.SimpleNamespace(monotonic=clock)
   try:
    with contextlib.redirect_stdout(stream):rc=E.analyze(c,MH)
   finally:E.time=oldtime
   r=json.loads(stream.getvalue())['analysis_result'];reason=reason_map.get(id)
   if id=='PY05-06':reason='PROFILE_COORD_DOMAIN' if idx==1 else 'PROFILE_COUNT'
   if reason:
    assert rc==1 and any(e.get('error','')==reason or e.get('error','').startswith(reason+':') for e in r['errors']),(reason,r)
    required=('runtime_evidence' if id in ('PY03-03','PY03-04','PY04-02','PY05-03') else 'mesh_evidence' if id.startswith('PY03') else 'guard_evidence' if id in ('PY02-01','PY02-02') else 'native_stop' if id=='PY02-03' else 'profile' if id=='PY05-06' else 'numeric' if id.startswith(('PY04','PY05','PY06')) else 'analyze')
    assert 'analyze' in traces and required in traces,(required,sorted(traces))
   elif id in ('PY02-04','PY02-05'):
    assert rc==1 and r['limited_result']=='PROTECTED_STOP_150S_INCOMPLETE' and r['native_completion']=='PROTECTIVE_STOP' and r['evidence_validity']=='INVALID' and r['mesh_comparison']=='INCONCLUSIVE',r
    assert r['numeric']['coverage']['primary_compared_count']==(100 if id=='PY02-04' else 0),r
   elif id=='PY07-01':assert rc==1 and r['native_completion']=='NOT_ESTABLISHED' and r['mesh_comparison']=='INCONCLUSIVE' and r['native_completion_cause']['state_errors']==state['errors'],r
   else:
    assert rc==0 and r['limited_result']=='BMIN640_150S_COMPARISON_COMPLETE' and r['evidence_validity']=='VALID' and r['errors']==[],r
    assert r['mesh_comparison']==('EXCEEDS_LIMITS' if id in ('PY01-03','PY01-04') else 'WITHIN_LIMITS_THIS_WINDOW'),r
   if id=='PY01-04':
    v=r['numeric']['windows']['primary']['surface_x_P'];assert D(v['time_s'])==D('137.4') and v['coordinate_index']==200 and v['coordinate_m']==c['coordinates']['P'][200]
   if id in ('PY03-05','PY03-06','PY03-13'):
    wanted=157000 if id=='PY03-06' else 79485 if id=='PY03-13' and idx==2 else 156925
    m=r['mesh_readback'];assert m['transient_dof']['solved']==wanted and m['transient_dof_matches_expected']==(wanted==156925)
    assert (m['review_note'] is None)==(wanted==156925)
   if id=='PY05-07':assert r['numeric']['coverage']['auxiliary_count']==1 and D(r['numeric']['windows']['auxiliary']['voltage_V']['maximum_absolute'])>D('.001')
  put(out/(id+'_'+str(idx)+'.json'),r)
  results.append({'id':id,'input_index':idx,'status':'PASS','rc':rc,'observed_errors':r.get('errors',[]),'reached_functions':sorted(traces),'elapsed_s':time.monotonic()-before})
  print(json.dumps(results[-1]),flush=True)
except BaseException as e:
 failed={'id':id if 'id' in locals() else None,'input_index':idx if 'idx' in locals() else None,'type':type(e).__name__,'error':str(e),'traceback':traceback.format_exc(),'reached_functions':sorted(traces)};put(out/'FIRST_FAILURE.json',failed);print(json.dumps(failed),flush=True)
finally:
 put(out/'PYTHON_RESULTS.json',{'status':'FAIL' if failed else 'PASS','results':results,'first_failure':failed,'not_run':[{'id':x['id'],'input_index':x['input_index']} for x in cases[len(results)+(1 if failed else 0):]],'elapsed_s':time.monotonic()-began,'limit_s':250,'cache_records':cache_records,'native_calls':0})
raise SystemExit(1 if failed else 0)

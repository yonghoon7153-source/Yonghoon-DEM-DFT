# 지시서 덧붙임 — 11-16 (이 덧붙임이 BRIEF_wishlist_table.md 와 어긋나면 이쪽이 앞선다)

## 왜 지금
1저자 11-13: *"2순위 논문 우선 돌리고 추가 필요 목록도 일단 최대한 모아보고 거기서 가장 중요하게 필요한것들만 추려서 가져오자"*. 2 순위는 11-16 에 끝났다 (마지막 = X-68-2 lyu2025 보강 · 정독 124). 이제 목록을 추린다.

## 입력이 바뀐 것 (11-16 08:2x UTC 에 새로 뜬 사본 — 이것만 쓴다)
- `…/scratchpad/wishlist_now.md` = 정본 `litdb/_curation/wishlist.md` (커밋 e958f2571 · 408 줄 · `### batch_` 52 개). 11-12 판 (배치 24 · 항목 114) 보다 크다.
- `…/scratchpad/papers_now.txt` = 정본 `litdb/papers/` 581 항목.
- `…/scratchpad/tools/queue.json` = 1저자가 PDF 를 이미 준 대기열 113 줄 (열쇠 N-xx · X-xx · `bib` · `pdf` · `nn`). 그중 끝난 것 = 정본 `litdb/_curation/status.tsv` 의 상태 칸 (`git -C /home/user/litdb-ctl show origin/claude/friendly-meitner-lldvar:litdb/_curation/status.tsv`). 3 순위 = N-76–N-129 · 보강 = N-148 · N-149 (PDF 받음 · 아직 안 돌림).
- 후보 표 원본 (왜 칸 포함) = `git -C /home/user/litdb-ctl show origin/claude/friendly-meitner-lldvar:litdb/_curation/S8_candidates.md`.
- 11-12 첫 판 (`…/scratchpad/wishlist_table.tsv` · `tools/wishlist_table.py`) 은 낡았고 틀린 맞춤이 있다 — 참고만.

## 산출 하나 더
- `…/scratchpad/litdb_wish/queue3_rank.md` — 아직 안 돌린 대기열 (3 순위 N-76–N-129 + 보강 N-148 · N-149) 을 BRIEF 2-3 의 같은 A · B · C 규칙으로 매긴 표 `N | 우선 | 서지 (queue.json bib 줄임 · 저자 · 해 · 학술지 · 권 · 쪽) | 왜 (S8_candidates 의 왜 칸 · 지어내지 않기)` + 우선별 수. 1저자가 "어느 것을 돌릴까" 를 정할 수 있게.
- pick_list.md 맨 위에 한 줄 요약: `PDF 필요 A n 편 · B n 편 / 대기열 A n 편`.

## 트랙 (11-16 기준 · 우선 매길 때)
Rint ② (1 순위 · 기한 · SE–SE · 탄소 접합 · PTFE · SDCP 계면) → [DEM 우선] Ⓐ 언로딩 (누른 채 ↔ 압연 뒤 실험) · 고체량 · 실험 원측정 · Ⓑ DEM → MPM 연계 (FAM · 소성 · 입자 형태 · 피복) · Ⓒ 코팅 활물질 믹싱 (D3 SE 유동성 앵커 · 응집) → [DEM 우선 (수영)] (가압부터 탈압까지 한 모델 · MPM 2D 단계 0–3 · 순수 SE 10–13 % · 진밀도 1.64) → 나머지.

## 규칙 (BRIEF 4 절 + 이것)
- 본 리포 트리 `/home/user/Yonghoon-DEM-DFT` 는 게이트가 도는 중 — 파일 읽기만. git 은 `git -C /home/user/litdb-ctl show …` · `git ls-tree` 만 (fetch · checkout · commit · 환경 변수 GIT_DIR / GIT_WORK_TREE / GIT_INDEX_FILE 설정 금지).
- 패키지 설치 · 신호 · 웹 · Artifact · 게시 도구 없음. 쓰기는 `…/scratchpad/litdb_wish/` 안에만.
- 답장 = BRIEF 5 절 + queue3_rank 의 우선별 수.

"""Small independent Q5 probes. No simulator, real research dumps or source writes.

Run: <Python with numpy/scipy> -I -X utf8 -B probe_semantics.py
Only the disk fixture's preparation binding is mocked; cell_stats/contact are real.
"""
import copy
import hashlib
import json
from pathlib import Path
import sys
import tempfile
from unittest import mock

import numpy as np
import scipy

ROOT = Path(__file__).resolve().parent
SOURCE = ROOT.parent / 'received'
sys.path.insert(0, str(SOURCE / 'scripts'))
import mixer_precal_observe as O

reports = []


def check(name, f):
    result = f()
    reports.append({'name': name, 'status': 'PASS', 'evidence': O._clean(result)})


def binding(n=80, role='U'):
    phases = {p: {'type': t, 'radius_m': .001}
              for t, p in enumerate(('AM_P', 'AM_S', 'SE'), 1)}
    rev = 0 if role == 'E0' else 2
    return {'case_id': 'PRECAL_E0' if role == 'E0' else 'PRECAL_R1_B1_U',
            'role': role, 'phases': phases, 'n_planned': n,
            'expected_counts': {'1': 20, '2': 20, '3': n - 40},
            'revolutions': rev, 'seed': 32452843, 'r_container': .5,
            'axis': 'x', 'np_proposed': 20, 'density_generation': 'lab20261014',
            'geometry': {'axis': 'x', 'r_container': .5, 'length': .2, 'cgf': 151.4},
            'frame_pm': {'phases': copy.deepcopy(phases), 'n_planned': n,
                         'revolutions': rev, 'seed': 32452843,
                         'n_expected_file': None, 'arm': 'independent-small-fixture',
                         'meta_steps': {'t0_planned': 200, 'dump_every': 50}}}


def cloud(am_per_cell):
    """80 conserved particles; four corner cells each hold exactly 20 atoms."""
    D = {'id': np.arange(1, 81, dtype=float),
         'type': np.array([1.] * 20 + [2.] * 20 + [3.] * 40),
         'radius': np.full(80, .001), 'x': np.zeros(80),
         'y': np.empty(80), 'z': np.empty(80)}
    am, se = list(range(40)), list(range(40, 80))
    for count, (y, z) in zip(am_per_cell, [(-.3, -.3), (-.3, .3), (.3, -.3), (.3, .3)]):
        indices = am[:count] + se[:20-count]
        del am[:count]
        del se[:20-count]
        D['y'][indices], D['z'][indices] = y, z
    assert not am and not se
    return D


def contact_oracle():
    # Four connected SE atoms plus one singleton; includes overlap with both AM types.
    typ = np.array([1, 1, 2, 3, 3, 3, 3, 3], dtype=float)
    xyz = np.array([[0, 0, 0], [5, 0, 0], [0, .5, 0],
                    [0, 1, 0], [0, 2, 0], [0, 3, 0], [0, 4, 0], [10, 0, 0]], dtype=float) * .001
    radii = np.array([.0015 if t == 1 else .0012 if t == 2 else .00075 for t in typ])
    D = dict(id=np.arange(1, 9, dtype=float), type=typ, radius=radii,
             x=xyz[:, 0], y=xyz[:, 1], z=xyz[:, 2])
    B = binding(8, 'E0')
    for p, r in zip(('AM_P', 'AM_S', 'SE'), (.0015, .0012, .00075)):
        B['frame_pm']['phases'][p]['radius_m'] = r
    q = O.contact.frame_quantities(D, B['frame_pm'])
    se = np.flatnonzero(typ == 3)
    edges = {(int(i), int(j)) for ii, i in enumerate(se) for j in se[ii + 1:]
             if float(np.dot(xyz[i] - xyz[j], xyz[i] - xyz[j])) < (radii[i] + radii[j]) ** 2}
    reached, sizes = set(), []
    for i in se:
        if i in reached:
            continue
        todo, component = [int(i)], set()
        while todo:
            a = todo.pop()
            if a in component:
                continue
            component.add(a)
            todo += [b if a == c else c for c, b in edges if a in (c, b)]
        reached |= component
        sizes.append(len(component))
    assert sorted(sizes) == [1, 4]
    assert q['pairs']['SE-SE'] == len(edges) == 3
    assert q['s1_se_clusters']['se_frac_in_clusters'] == .8
    assert q['s1_se_clusters']['largest_frac'] == .8
    assert q['s1_se_clusters']['mean_size_number'] == 2.5
    assert q['s1_se_clusters']['hist_components'] == {'1': 1, '2': 0, '3-9': 1, '10-99': 0, '>=100': 0}
    attached = set()
    for name, t in [('AM_P', 1), ('AM_S', 2)]:
        pairs = {(int(i), int(j)) for i in np.flatnonzero(typ == t) for j in se
                 if np.linalg.norm(xyz[i] - xyz[j]) ** 2 < (radii[i] + radii[j]) ** 2}
        vertices = {j for _, j in pairs}
        attached |= vertices
        assert q['pairs'][name + '-SE'] == len(pairs)
        assert q['s2_am_se_attach']['se_attached_frac_' + name] == len(vertices) / len(se)
        assert q['s2_am_se_attach']['se_per_am_' + name] == len(pairs) / int((typ == t).sum())
    assert q['s2_am_se_attach']['se_attached_any_frac'] == len(attached) / len(se)
    assert q['s2_am_se_attach']['se_attached_frac_AM_P'] + q['s2_am_se_attach']['se_attached_frac_AM_S'] > q['s2_am_se_attach']['se_attached_any_frac']
    # Exactly touching is excluded, strict overlap is included.
    P = np.array([[0., 0, 0], [.002, 0, 0]])
    reg, lo, hi = O.contact.classify_pairs(P, np.array([.001, .001]), np.zeros((2, 3)), np.zeros(2), np.array([0]), np.array([1]))
    assert not bool(reg[0])
    return {'sizes': sizes, 'pairs': q['pairs'], 'attachment': q['s2_am_se_attach'], 'strict_tangency_excluded': True}


def real_grids_and_denominator():
    D0, Dt, Dr = cloud([20, 20, 0, 0]), cloud([15, 15, 5, 5]), cloud([10, 10, 10, 10])
    O.qualify_arrays([D0, Dt], binding())
    fp = {'t0_step': 200, 'bin_steps': [400, 450]}
    run = {'binding': binding(), 'frame_plan': fp, 'arrays': [D0, Dt, Dt]}
    ref = {'arrays': [Dr]}
    cq, mq = O._metrics(run, ref)
    for item in mq['grids']:
        assert item['n_min'] == 20 and item['r_container'] == .5 and item['axis'] == 'x'
        assert item['S0'] == .25 and item['SR'] == 0 and item['M_mean'] == .75 and item['M_sd'] == 0
        assert item['t0_stats']['used'] == 4 and item['t0_stats']['dropped'] == 0
        assert item['frames'][0]['s2'] == .0625 and item['frames'][0]['s2_all'] == .0625
        assert item['qc']['pass']
    assert [x['grid'] for x in mq['grids']] == [[16, 16, 4], [12, 12, 3], [8, 8, 2]]
    return {'grids': [{'grid': x['grid'], 'S0': x['S0'], 'SR': x['SR'], 'M_mean': x['M_mean'], 'qc': x['qc']} for x in mq['grids']],
            'no_cell_stats_mock': True, 'contact_label': cq['observable_label']}


def volume_and_qc():
    D = {'type': np.array([1.] * 10 + [3.] * 10 + [2.] * 10 + [3.] * 10),
         'radius': np.array([.002] * 10 + [.001] * 10 + [.0015] * 10 + [.001] * 10),
         'x': np.zeros(40), 'y': np.array([-.3] * 20 + [.3] * 20), 'z': np.zeros(40)}
    expected_p = [8 / 9, 27 / 35]
    values = []
    for cells, axial in O.GRIDS:
        cs = O.mixing.cell_stats(D, .5, cells=cells, x_cells=axial, n_min=20, axis='x')
        assert np.allclose(cs['p'], expected_p, rtol=0, atol=1e-15)
        assert abs(cs['s2'] - (expected_p[0] - expected_p[1]) ** 2 / 4) < 1e-15
        values.append(cs['s2'])
    Q = {'type': np.array([1.] * 20 + [2.] * 20 + [3.] * 19), 'radius': np.full(59, .001),
         'x': np.zeros(59), 'y': np.array([-.3] * 20 + [0.] * 20 + [.3] * 19), 'z': np.zeros(59)}
    cs = O.mixing.cell_stats(Q, .5, cells=16, x_cells=4, n_min=20)
    qc = O.mixing.qc_representativeness([cs])
    assert cs['used'] == 2 and cs['dropped'] == 1 and cs['s2'] == 0 and cs['s2_all'] > .2
    assert cs['se_vol_kept'] == 0 and not qc['pass']
    return {'unequal_radius_expected_p': expected_p, 'three_grid_s2': values,
            'threshold_20_vs_19': {k: cs[k] for k in ('used', 'dropped', 's2', 's2_all', 'se_vol_kept')}, 'qc': qc}


def write_run(root, role, frames):
    root.mkdir()
    (root / 'post').mkdir()
    B = binding(role=role)
    runs = [1, 100, 100, 0 if role == 'E0' else 400]
    (root / 'in.mixer').write_text('timestep 0.01\nfix mvD all move/mesh mesh Drum rotate origin 0 0 0 axis 1 0 0 period 2\ndump dmp all custom 50 post/dump_*.liggghts id type x y z radius\n' + ''.join('run %d\n' % n for n in runs))
    (root / 'deck_meta.json').write_text(json.dumps(B))
    total, log = 0, []
    for r in runs:
        total += r
        log += ['Step Atoms KinEng c_rke Volume', '%d 80 0 0 1' % total,
                'Loop time of 1 on 20 procs for %d steps with 80 atoms' % r]
    (root / 'log.liggghts').write_text('\n'.join(log) + '\n')
    for step, D in frames:
        raw = 'ITEM: TIMESTEP\n%d\nITEM: NUMBER OF ATOMS\n80\nITEM: BOX BOUNDS ff ff ff\n-1 1\n-1 1\n-1 1\nITEM: ATOMS id type x y z radius\n' % step
        raw += ''.join(' '.join(format(float(D[k][i]), '.17g') for k in ('id', 'type', 'x', 'y', 'z', 'radius')) + '\n' for i in range(80))
        (root / 'post' / ('dump_%d.liggghts' % step)).write_text(raw)
    return B


def disk_real_cells_statuses():
    evidence = []
    with tempfile.TemporaryDirectory(dir=ROOT) as tmp:
        root = Path(tmp)
        Dr = cloud([10, 10, 10, 10])
        write_run(root / 'reference', 'E0', [(200, Dr)])
        for name in ('positive', 'equal_denominator', 'nonfinite_bin', 'no_se', 'e0_single_cell'):
            D0, Dt = cloud([20, 20, 0, 0]), cloud([15, 15, 5, 5])
            role = 'E0' if name == 'e0_single_cell' else 'U'
            expected = 'OK' if name in ('positive', 'e0_single_cell') else 'UNDEFINED'
            if name == 'equal_denominator':
                D0 = Dr
            if name == 'nonfinite_bin':
                Dt['y'][:] = 0; Dt['z'][:] = 0
            if name == 'no_se':
                D0['type'][:] = 1; Dt['type'][:] = 1
            if name == 'e0_single_cell':
                D0['y'][:] = 0; D0['z'][:] = 0
            entries = [(200, D0)] + ([] if role == 'E0' else [(s, Dt) for s in (400, 450, 500, 550)])
            B = write_run(root / name, role, entries)
            # Required scope limit: 80 atoms cannot meet the fixed 100000 atom preparation contract.
            with mock.patch.object(O, 'validate_case', side_effect=lambda case, deck, meta: meta):
                got = O.analyse_run(B['case_id'], root / name, root / 'reference' if role != 'E0' else None)
            assert got['status'] == expected, (name, got)
            if expected != 'OK':
                assert got['contact'] is None and got['mixing'] is None
            if name == 'positive':
                assert all(g['M_mean'] == .75 and g['qc']['pass'] for g in got['mixing']['grids'])
            if name == 'e0_single_cell':
                assert all(g['status'] == 'NOT_APPLICABLE' and g['t0_stats']['s2'] is None for g in got['mixing']['grids'])
            json.dumps(got, allow_nan=False)
            evidence.append({'name': name, 'status': got['status'], 'reasons': got['reasons']})
    return {'binding_mock_only': True, 'no_metric_mock': True, 'max_atoms': 80, 'cases': evidence}


def absent_am_type_and_unclipped_m():
    D = cloud([20, 20, 0, 0]); D['type'][D['type'] == 2] = 1
    q = O.contact.frame_quantities(D, binding()['frame_pm'])
    assert q['s2_am_se_attach']['se_per_am_AM_S'] is None
    assert q['s2_am_se_attach']['se_attached_frac_AM_S'] == 0
    c0 = O.mixing.cell_stats(cloud([15, 15, 5, 5]), .5, cells=16, x_cells=4)
    cr = O.mixing.cell_stats(cloud([12, 12, 8, 8]), .5, cells=16, x_cells=4)
    high = O.mixing.cell_stats(cloud([20, 20, 0, 0]), .5, cells=16, x_cells=4)
    low = O.mixing.cell_stats(cloud([10, 10, 10, 10]), .5, cells=16, x_cells=4)
    result = O.mixing_summary(c0, cr, [high, low], [400, 450])
    assert result['frames'][0]['M'] < 0 and result['frames'][1]['M'] > 1
    return {'absent_AM_S_per_AM': q['s2_am_se_attach']['se_per_am_AM_S'],
            'unclipped_M': [x['M'] for x in result['frames']]}


for name, fn in [('contact_bruteforce_oracle', contact_oracle),
                 ('real_three_grids_and_own_denominator', real_grids_and_denominator),
                 ('printed_radius_volume_and_nmin_qc', volume_and_qc),
                 ('disk_real_cells_statuses', disk_real_cells_statuses),
                 ('absent_am_and_unclipped_m', absent_am_type_and_unclipped_m)]:
    check(name, fn)

result = {'pin': (SOURCE / 'PIN.txt').read_text().strip(), 'python': sys.version,
          'numpy': np.__version__, 'scipy': scipy.__version__,
          'source_sha256': {name: hashlib.sha256((SOURCE / 'scripts' / name).read_bytes()).hexdigest()
                            for name in ('mixer_precal_observe.py', 'measure_mixing_index.py', 'mixer_contact_reader.py')},
          'scope': '5 independent small synthetic probe groups; maximum 80 atoms; no simulation; only disk fixture preparation binding mocked',
          'probes': reports}
(ROOT / 'probe_results.json').write_text(json.dumps(result, ensure_ascii=False, indent=2, allow_nan=False), encoding='utf-8')
print(json.dumps(result, ensure_ascii=False, indent=2, allow_nan=False))

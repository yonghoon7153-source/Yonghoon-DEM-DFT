"""REIL C4-E · E1-0b 외곽 단계 실행기 v8 (승인 요청 `docs/REIL_C4E_E1_0B_APPROVAL_REQUEST_20261030.md` §4 · 정정 범위안 v3 · v4 · v5 · E1-0b 범위안 ·
사전 검토 §76 의 V2-01–05 · §78 의 V3-01–03 · V3-N1 · §80 의 V4-01 · 자체 발견 S4 · S5 · S6) — pytest 한 번을 새 세션으로 띄우고, 실행기가 subreaper 가
되어 timeout 과 끝에서 자손 전체 (별도 세션 포함) 를 소유 · 정리 · 확인한다 (stdlib · Linux). v5 (E1-0) 와 다른 것은 증거 폴더 이름 규칙 · 단계 이름 ·
봉인 표 (`EXPECT`) · 작업 폴더 (`SP/c4e1_0b_a2_steps` — E1-0 의 `SP/c4e1_steps` · E1-0b 지난 시도의 `SP/c4e1_0b_steps` 와 섞지 않는다) 뿐이고, 정리 ·
기록 규칙은 같다. v7 과 다른 것은 증거 폴더 이름의 시도 표지 `a2` (`reil_c4e1_0b_a2_YYYYMMDD` — 지난 시도의 `reil_c4e1_0b_20261103` 과 겹치지 않는다) ·
작업 폴더 · 거부 메시지 · 봉인 표의 대조 두 행 (launcher 대조 v8 · 실행기 대조 v5 — E1-0b 결과 검토 §93 의 E1_0B_RESULT_N1 · 사용자 채택 §94) 뿐이다.

    /usr/bin/python3.11 -I <E>/00_step_runner.py <단계> <timeout_s> -- <argv…>     (<E> = 이 파일이 있는 증거 폴더 · reil_c4e1_0b_a2_YYYYMMDD)

- 단계는 `EXPECT` 의 둘 (01_red_e1_0b · 02_green_e1_0b) 뿐이다. cwd 는 bms-balancing/. 재시도 없음 · 덮어쓰지 않는다.
- 의도된 거부 (인자 · 단계 이름 · 폴더 규칙 · 기존 기록 파일 — lstat 기준이라 끊어진 심볼릭 링크도 "있음" · V3-02) — 어떤 파일 · 폴더도 만들기 전
  SystemExit (메시지만 · 해석기 rc 1). 기록용 `except Exception` 은 SystemExit 를 잡지 않는다.
- 준비 (기록되는 단계 prepare · V2-04): 상속 env 정제 (V2-02 — launcher `child_env` 와 같은 규칙: 비밀 형태 이름 · SSH_ASKPASS · GIT_SSL_CAINFO 밖의
  모든 GIT_* 를 빼고 GIT_TERMINAL_PROMPT=0 · 이름만 기록 · 이 env 가 실행기 자신의 Git 기록과 pytest env 의 바탕이다 — 첫 Git 호출 전) · mpl / tmp 폴더 ·
  자기 sha (기록만) · 디스크 · 원천 해시 (V2-05 — 고정 목록 TARGETS 를 해시해 `<단계>.source_sha256.txt` 에 쓰고 EXPECT[단계] 와 대조 · 하나라도 다르면
  자식 0) · PR_SET_CHILD_SUBREAPER · 시작 Git 기록 (HEAD · porcelain — 실패하면 자식 0 · S4). 자식 전에 멈추는 이유마다 `errors` 에도 항목을 넣는다
  (prepare / SourceMismatch · prepare / SubreaperFailed · record / GitRecordFailed — V3-N1). 자식 전에 멈추면 meta (started false) · 반환 3.
- 정리 (V2-01 · V2-03 · V3-01): run_step 이 정리 단계에 들어갈 때 정리 원점과 공통 절대 기한 (원점 + CLEANUP_S) 을 한 번 만들어 cleanup 에 넘긴다 (cleanup
  은 기한을 만들지 않는다). timeout 이면 그룹 SIGKILL → KILL_WAIT_S (기한 안) 동안 /proc ppid 사슬로 찾은 살아 있는 자손 (pytest · 별도 세션 포함) SIGKILL
  반복 — pytest 가 끝나고 살아 있는 자손이 없으면 멈춤 → pytest 회수 (남은 시간만 · 기한 뒤에는 wait(0)) → settle (스스로 끝나기 관측 SETTLE_S → 남으면
  SIGKILL → 기한까지 재관측). 모든 루프는 관측을 시작하기 **전에** `지금 < 기한` 을 본다 — 기한을 넘을 수 있는 것은 기한 전에 시작한 관측 하나뿐이다. 기한
  뒤에 하는 것은 그 관측 결과에 따른 즉시 동작 (좀비 회수 · SIGKILL 보내기) · 비차단 확인 (poll · wait(0)) · 기록뿐이고, 새 관측 · sleep · 차단 대기는 하지
  않는다. 끝 상태 = empty · killed · alive · unverified (기한 때문에 확인 관측을 못 함 — 관측 0 이거나 kill 뒤 재관측 없음) · unknown (ledger 에 오류).
  cleanup 안의 예외는 cleanup 이 잡아 오류 · ledger 에 남기고 같은 기한으로 비상 동작 (pytest 가 살아 있으면 그룹 SIGKILL · settle) 만 한다 — 새 기한은
  없다. /proc 관측은 모두 proc_table 하나를 거치고, 반복마다 한 번 관측한 표를 회수와 자손 판정에 같이 쓴다. 관측 · 회수 · kill · 정리 예외는 단계 하나의
  누적 기록 (ledger) 에 쌓이고, 하나라도 있으면 끝 상태는 unknown 이다 (뒤의 정상 관측이 지우지 않는다).
- /proc (V3-03): 바이트로 읽고 comm (괄호 안) 은 해석하지 않는다. PID 소멸만 "사라짐" 이고, 그 밖의 모든 읽기 예외 (권한 · I/O · 디코딩 등) 와 파싱 실패는
  그 PID 의 오류로 남기고 스캔을 계속한다. git 출력은 UTF-8 로 읽는다 — `encoding="utf-8"` · `errors="replace"` (S5 · S6 — 해석이 locale 에 기대지
  않는다).
- 끝 기록: porcelain · HEAD · 원천 해시 다시 (`<단계>.source_sha256_end.txt` · EXPECT 와 대조) · 시간 경계 넷 (child_s · cleanup_s — 정리 원점부터 ·
  records_s · total_s).
- runner_ok = 시작 AND timeout 없음 AND 끝 상태 empty AND 기한 안 AND 시작 · 끝 Git 기록 성공 · HEAD 불변 AND 끝 원천 해시 = EXPECT AND 단계 오류 0.
  pytest rc 의 해석 (RED 는 실패가 기대값) 은 승인 요청이 정한다.
- 반환: 0 = runner_ok AND pytest rc 0 · 1 = 그 밖 (meta 있음) · 3 = 자식 시작 전에 멈춤 (meta 있음) · 4 = meta 를 쓰지 못함 (stderr 한 줄 JSON).
- 자원은 사후 관측이다 (RUSAGE_CHILDREN · 디스크 · 증거 바이트 — 강제 상한이 아니다). /proc 스캔은 비원자적이고 PID 번호로 보내는 kill 은 생성 신원을
  보장하지 않는다 — 모든 자손의 연속 소유 · 종료 증명이 아니다. 실행기 자신의 sha 는 기록만 한다 (자기 해시를 자기 안에 둘 수 없다).
"""
import ctypes
import datetime
import hashlib
import json
import os
import re
import resource
import shutil
import signal
import stat
import subprocess
import sys
import time
from pathlib import Path

REPO = Path("/home/user/Yonghoon-DEM-DFT")
BMS = REPO / "bms-balancing"
E = Path(__file__).resolve().parent
SP = Path("/tmp/claude-0/-home-user-Yonghoon-DEM-DFT/b881d255-9513-5adc-9b14-3c0be18d7ad6/scratchpad")
WORK = SP / "c4e1_0b_a2_steps"
#: launcher `SECRET` · `GIT_KEEP` · `DROP` 과 같은 규칙 (V2-02)
SECRET = re.compile(r"TOKEN|SECRET|PASSW|ACCESS_KEY|CREDENTIAL|COOKIE|^GIT_CONFIG_", re.I)
GIT_KEEP = ("GIT_SSL_CAINFO",)
DROP = ("SSH_ASKPASS",)
CHILD_SET = {"PYTHONDONTWRITEBYTECODE": "1", "MPLBACKEND": "Agg", "OMP_NUM_THREADS": "1", "OPENBLAS_NUM_THREADS": "1", "MKL_NUM_THREADS": "1"}
PR_SET_CHILD_SUBREAPER = 36
#: 정리의 공통 절대 기한 (E1-0b 요청서 · v5 와 같은 "정리 ≤ 15 s" — 넘을 수 있는 것은 기한 전에 시작한 관측 하나) — timeout 경로 7 + 3 + 5 · 정상 경로 3 + 12
CLEANUP_S = 15.0
KILL_WAIT_S = 7.0
SETTLE_S = 3.0
POLL_S = 0.1
GIT_TIMEOUT_S = 60.0
PROC = Path("/proc")
EVIDENCE_NAME = re.compile(r"^reil_c4e1_0b_a2_20[0-9]{6}$")
LAUNCH = "bms-balancing/scripts/reil_c4e1_launch.py"
#: V2-05 — 단계마다 자식 전 · 끝에 해시하는 고정 목록 14 (저장소 기준 경로 · 이 순서로 기록)
TARGETS = (LAUNCH, "bms-balancing/tests/test_reil_c4e1_launch.py", "bms-balancing/tests/test_reil_c4e1_runner.py",
           "bms-balancing/tests/test_reil_c4e.py", "bms-balancing/tests/test_reil_c4e_fix.py", "bms-balancing/scripts/reil_c4e_run.py",
           "bms-balancing/scripts/reil_c4_e3a.py", "bms-balancing/scripts/reil_c4_monitor.py", "bms-balancing/scripts/reil_c5_pilot.py",
           "bms-balancing/scripts/reil_p0.py", "bms-balancing/scripts/reil_c6_profile.py", "degradation-degeneracy/tools/env_profile.py",
           "bms-balancing/evidence/reil_c4e0_fix_20261014/04_sources/SOURCES.json",
           "bms-balancing/docs/REIL_C4E1_STEP_RUNNER_DRAFT_20261020.py.txt")
#: 단계에 따라 바뀌지 않는 13 — 대조 둘 (launcher 대조 v8 · 외곽 실행기 대조 v5 초안과 같은 바이트) · 기존 시험 둘 · 다섯 모듈 (SOURCES.json) · S1 의 둘 · SOURCES.json · v2 실행기 초안
_FIXED = {"bms-balancing/tests/test_reil_c4e1_launch.py": {"bytes": 74_542, "sha256": "49d3fa36b5928b92584da158a3ac234ddf83bbc79c7d3c349fd96bc5c1bf9001"},
          "bms-balancing/tests/test_reil_c4e1_runner.py": {"bytes": 37_003, "sha256": "b34fb9a98eb6e852d4c30038ee988adee57d03c2b138e767ca742ea327a45e13"},
          "bms-balancing/tests/test_reil_c4e.py": {"bytes": 57_482, "sha256": "687de63c3a7614834fa9063d26f29122b9876c381de9f3d43f759ec5e204d38e"},
          "bms-balancing/tests/test_reil_c4e_fix.py": {"bytes": 19_506, "sha256": "7a09d4386a740e9eba9145372e59ed7e1385ce5523fd7ce38dc095d5e4053bd2"},
          "bms-balancing/scripts/reil_c4e_run.py": {"bytes": 53_853, "sha256": "a94f535fd8ab5718b0ed47e0322a067300f808ef42c530cd95668aa77f0a53a9"},
          "bms-balancing/scripts/reil_c4_e3a.py": {"bytes": 32_311, "sha256": "33b855378fb76634eb314f8cfb0428151ce1ec8b9045bc8447d8e17354a41ac3"},
          "bms-balancing/scripts/reil_c4_monitor.py": {"bytes": 21_546,
                                                       "sha256": "e6ef8ff617342393a9d3a45c98751b563a3f1e9871c6fa3b540b47f4bfbc071b"},
          "bms-balancing/scripts/reil_c5_pilot.py": {"bytes": 47_164, "sha256": "73bee8dc412b39863afb64b70bc128cbecee2075a3a17914fc7288f353ef11a6"},
          "bms-balancing/scripts/reil_p0.py": {"bytes": 23_941, "sha256": "793b326ebf86a6db3b855d828aff4d6b6dddc824bed8d00f4161537b1cc06e3a"},
          "bms-balancing/scripts/reil_c6_profile.py": {"bytes": 15_915,
                                                       "sha256": "408afc4bb5eb1069583b955e0eb6215bf48dd9259ad474c230549d1b3642df5d"},
          "degradation-degeneracy/tools/env_profile.py": {"bytes": 22_333,
                                                          "sha256": "83b0d8365d039d75050d087fe980ad7b64818686b699e5d06da1c0ad63148563"},
          "bms-balancing/evidence/reil_c4e0_fix_20261014/04_sources/SOURCES.json": {
              "bytes": 1_100, "sha256": "2a7b2b49b9809d1a9301398388894a1f7a73afb55acc1a5070e3f77ce0393d52"},
          "bms-balancing/docs/REIL_C4E1_STEP_RUNNER_DRAFT_20261020.py.txt": {
              "bytes": 12_849, "sha256": "aae2ec14c4d652ef9a9e5b1c45bf52896d2234dce16eac77942911e596669fed"}}
#: launcher 자리 — RED 는 v5 고정 구현 (E1-0 GREEN 의 바이트 · 지금 저장소의 것) · GREEN 은 v6 고정 구현
RED_LAUNCH = {"bytes": 51_957, "sha256": "2269d775f1701e2f657d386f42bc950d26a6b56bd37323611dd6ab4cc1a75396"}
IMPL = {"bytes": 62_639, "sha256": "2c70712381aec657f81c8e72c85e8c06e654364aefe9e38e5254ecfece9e4ebf"}
#: V2-05 — 단계별 봉인 기대값 (E1-0b 요청서 §4-4 의 표와 같다 · 첫 시험 전 커밋으로 봉인)
EXPECT = {"01_red_e1_0b": {LAUNCH: RED_LAUNCH, **_FIXED}, "02_green_e1_0b": {LAUNCH: IMPL, **_FIXED}}


def utc() -> str:
    return datetime.datetime.now(datetime.timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.%f")[:-3] + "Z"


def sha256(b: bytes) -> str:
    return hashlib.sha256(b).hexdigest()


def dump(obj) -> str:
    return json.dumps(obj, ensure_ascii=False, indent=1, sort_keys=True, default=str) + "\n"


def write_new(path, text: str) -> None:
    with open(path, "x", encoding="utf-8") as f:
        f.write(text)


def entry_exists(path) -> bool:
    """항목 자체가 있는가 — lstat 이라 끊어진 심볼릭 링크도 "있음" 이다 (V3-02 · `Path.exists` 는 대상을 따라간다). 없음 (FileNotFoundError) 만 false 이고
    그 밖 lstat 오류는 그대로 올린다 (준비 오류로 남는다)."""
    try:
        os.lstat(path)
    except FileNotFoundError:
        return False
    return True


# ---------------------------------------------------------------- env · Git (V2-02)
def base_env(environ) -> tuple:
    """정제 env → (env, 뺀 이름). launcher `child_env` 와 같은 규칙: 비밀 형태 이름 · SSH_ASKPASS · GIT_SSL_CAINFO 밖의 모든 GIT_* 를 빼고
    GIT_TERMINAL_PROMPT=0. 값은 기록하지 않는다. 실행기 자신의 Git 기록과 pytest env 의 바탕 — 첫 Git 호출 전에 만든다."""
    removed = sorted(k for k in environ if SECRET.search(k) or k in DROP or (k.startswith("GIT_") and k not in GIT_KEEP))
    env = {k: v for k, v in environ.items() if k not in removed}
    env["GIT_TERMINAL_PROMPT"] = "0"
    return env, removed


def git(args, *, env, cwd=REPO, timeout=GIT_TIMEOUT_S) -> dict:
    """기록용 git — env 를 반드시 받는다 (기본값 없음 · 상속 env 로 부르지 않는다). rc · 오류를 그대로 남긴다 (빈 정상 출력으로 바꾸지 않는다). 출력은
    UTF-8 로 읽는다 (`encoding="utf-8"` · `errors="replace"` — S5 · S6: 비 UTF-8 출력은 대체 문자로 남고 기록 밖 예외가 되지 않으며, 해석이 locale 에
    기대지 않는다)."""
    argv = ["git", "-C", str(cwd), *[str(a) for a in args]]
    try:
        r = subprocess.run(argv, env=env, capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=timeout)
        return {"argv": argv, "rc": r.returncode, "out": r.stdout, "err": r.stderr[-500:]}
    except (OSError, subprocess.TimeoutExpired) as e:
        return {"argv": argv, "rc": None, "out": "", "err": "", "error": f"{e.__class__.__name__}: {e}"}


def record_problems(records: dict, heads=("head_start", "head_end"), porcelains=("porcelain_start", "porcelain_end")) -> list:
    """Git 기록 (기본: HEAD 시작 · 끝 · porcelain 시작 · 끝) 이 성공했고 단계 중 HEAD 가 그대로인가. 시작만 볼 때는 시작 키만 준다 (S4)."""
    probs, seen = [], {}
    for k in heads:
        r = records.get(k) or {}
        h = (r.get("out") or "").strip()
        if r.get("rc") != 0 or not re.fullmatch(r"[0-9a-f]{40}", h):
            probs.append(f"Git 기록 {k} 실패 (rc {r.get('rc')} {r.get('error', '')})")
        else:
            seen[k] = h
    for k in porcelains:
        r = records.get(k) or {}
        if r.get("rc") != 0:
            probs.append(f"Git 기록 {k} 실패 (rc {r.get('rc')} {r.get('error', '')})")
    if len(seen) == 2 and seen.get("head_start") != seen.get("head_end"):
        probs.append(f"단계 중 HEAD 가 바뀌었다: {seen.get('head_start')} → {seen.get('head_end')}")
    return probs


# ---------------------------------------------------------------- 원천 해시 (V2-05)
def read_regular(path) -> tuple:
    """일반 파일만 읽는다 → (바이트, None) · 아니면 (None, 사유). 절대 경로 · lstat 이 일반 파일 · resolve 가 자기 자신 (링크된 상위 폴더 거부) · 읽기 오류도
    사유로."""
    p = Path(path)
    if not p.is_absolute():
        return None, "절대 경로가 아니다"
    try:
        st = os.lstat(p)
    except OSError as e:
        return None, f"없음 ({e.__class__.__name__})"
    if not stat.S_ISREG(st.st_mode):
        return None, "일반 파일이 아니다 (심볼릭 링크 · 디렉터리 등)"
    try:
        if p.resolve() != p:
            return None, f"resolve 경로가 다르다: {p.resolve()}"
        return p.read_bytes(), None
    except OSError as e:
        return None, f"읽기 실패 ({e.__class__.__name__}: {e})"


def source_table(repo, targets) -> dict:
    """고정 목록 (저장소 기준 경로) 의 실제 바이트 → {경로: {sha256, bytes}} · 읽지 못한 행은 {why}."""
    rows = {}
    for rel in targets:
        b, why = read_regular(Path(repo) / rel)
        rows[rel] = {"why": why} if b is None else {"sha256": sha256(b), "bytes": len(b)}
    return rows


def source_problems(rows: dict, expect: dict) -> list:
    """원천 표 ↔ 봉인 기대값 — 경로 집합이 같고 모든 행이 기대 sha256 · bytes 와 같아야 한다 (끝 diff 로 사전 봉인을 대신하지 않는다)."""
    probs = []
    if set(rows) != set(expect):
        probs.append(f"원천 목록 경로 집합이 다르다 — 누락 {sorted(set(expect) - set(rows))} · 목록 밖 {sorted(set(rows) - set(expect))}")
    for rel, want in expect.items():
        r = rows.get(rel)
        if r is None:
            continue
        if "why" in r:
            probs.append(f"{rel}: {r['why']}")
        elif (r.get("sha256"), r.get("bytes")) != (want.get("sha256"), want.get("bytes")):
            probs.append(f"{rel}: sha256 {r.get('sha256')} · {r.get('bytes')} B ≠ 기대 {want}")
    return probs


def source_text(rows: dict, self_path, self_sha) -> str:
    """기록 파일 본문 — 목록 순서의 `sha256  경로` 줄 (sha256sum 형식) · 읽지 못한 행은 `-  경로  (사유)` · 끝줄에 실행기 자신 (대조 밖)."""
    lines = [f"{r['sha256']}  {rel}" if "sha256" in r else f"-  {rel}  ({r['why']})" for rel, r in rows.items()]
    lines.append(f"# 실행기 자신 (대조 밖) {self_sha}  {self_path}")
    return "\n".join(lines) + "\n"


# ---------------------------------------------------------------- /proc 관측 · 정리 (V2-01 · V2-03 · V3-01 · V3-03)
def proc_table(proc=PROC, read=None) -> tuple:
    """{pid: (ppid, 상태)} · 오류 — 바이트로 읽고 comm (괄호 안) 은 해석하지 않는다 (V3-03 — UTF-8 이 아닌 이름도 실패하지 않는다 · 주입한 read 가
    문자열을 돌려줘도 같은 파싱). PID 소멸 (FileNotFoundError · ProcessLookupError) 만 건너뛰고, 그 밖의 모든 읽기 예외 (권한 · I/O · 디코딩 등) 와 파싱 ·
    목록 실패는 그 PID 의 오류로 남기고 스캔을 계속한다. 실행기의 /proc 관측은 모두 이 함수 하나를 거친다 (대조 r1 · r2 · r3 · r9 · r10 이 이 자리에 오류 ·
    지연 · 예외를 주입한다)."""
    read = read or (lambda q: q.read_bytes())
    table, errors = {}, []
    try:
        entries = [d for d in Path(proc).iterdir() if d.name.isdigit()]
    except Exception as e:  # noqa: BLE001 — 목록 실패는 관측 불능
        return table, [f"list: {e.__class__.__name__}: {e}"]
    for d in entries:
        try:
            s = read(d / "stat")
        except (FileNotFoundError, ProcessLookupError):
            continue
        except Exception as e:  # noqa: BLE001 — 소멸이 아닌 모든 읽기 예외 (권한 · I/O · 디코딩 등) 는 그 PID 의 오류
            errors.append(f"{d.name}: {e.__class__.__name__}: {e}")
            continue
        try:
            b = s if isinstance(s, bytes) else s.encode("utf-8", "surrogateescape")
            rest = b[b.rindex(b")") + 2:].split()
            table[int(d.name)] = (int(rest[1]), rest[0].decode("ascii"))
        except Exception as e:  # noqa: BLE001 — 파싱 · 디코딩 실패
            errors.append(f"{d.name}: 파싱 실패 {e.__class__.__name__}: {e}")
    return table, errors


def observe(ledger: list, where: str, *, proc=PROC, read=None) -> dict:
    """/proc 한 번 → 표. 오류는 ledger 에 {where, utc, error} 로 쌓는다 (지우지 않는다)."""
    table, errors = proc_table(proc, read)
    ledger += [{"where": where, "utc": utc(), "error": e} for e in errors]
    return table


def descendants(table: dict, root: int) -> list:
    """표에서 root 의 자손 [(pid, 상태)] — ppid 사슬 (별도 세션 포함 · subreaper 라 고아도 root 밑으로 온다)."""
    kids = {}
    for pid, (ppid, _) in table.items():
        kids.setdefault(ppid, []).append(pid)
    out, todo, seen = [], list(kids.get(root, [])), set()
    while todo:
        pid = todo.pop()
        if pid in seen:
            continue
        seen.add(pid)
        out.append((pid, table[pid][1]))
        todo += kids.get(pid, [])
    return sorted(out)


def reap(table: dict, me: int, skip: int, ledger: list, *, waitpid=os.waitpid) -> list:
    """표에서 이 실행기의 좀비 자식을 PID 지정으로 회수한다 — pytest (skip) 는 Popen 이 회수하므로 건드리지 않는다. 회수 오류는 ledger 로."""
    got = []
    for pid, (ppid, state) in table.items():
        if ppid == me and pid != skip and state == "Z":
            try:
                if waitpid(pid, os.WNOHANG)[0] == pid:
                    got.append(pid)
            except OSError as e:
                ledger.append({"where": "reap", "utc": utc(), "error": f"{pid}: {e.__class__.__name__}: {e}"})
    return got


def kill(pids, ledger: list, *, killer=os.kill) -> list:
    """PID 마다 SIGKILL → [[pid, 결과]] — 이미 없음은 결과일 뿐이고, 그 밖 오류는 ledger 로."""
    res = []
    for pid in pids:
        try:
            killer(pid, signal.SIGKILL)
            res.append([pid, "sent"])
        except ProcessLookupError:
            res.append([pid, "no_process"])
        except OSError as e:
            res.append([pid, f"{e.__class__.__name__}: {e}"])
            ledger.append({"where": "kill", "utc": utc(), "error": f"{pid}: {e.__class__.__name__}: {e}"})
    return res


def settle(skip, limit=SETTLE_S, *, ledger=None, deadline=None, me=None, clock=time.monotonic, sleep=time.sleep, proc=PROC, read=None,
           waitpid=os.waitpid, killer=os.kill) -> dict:
    """끝 확인 — 관측은 기한 전에만 시작한다 (V3-01). limit 초 (기한 안) 동안 살아 있는 (좀비 아닌) 자손이 스스로 끝나기를 관측 (좀비는 회수) → 끝나면
    empty. 남으면 SIGKILL (기한 뒤라도 보낸다 — 기다리지 않는 동작) 뒤 기한까지 재관측 → killed / alive. 기한 때문에 관측을 하나도 못 했거나 kill 뒤 재관측을
    못 했으면 unverified. ledger 에 오류가 하나라도 있으면 (이 호출 전 정리 단계의 것 포함) unknown — 뒤의 정상 관측이 지우지 않는다. deadline 을 주지
    않으면 지금 + CLEANUP_S (단독 호출용 — 정리 단계에서는 cleanup 이 받은 기한을 넘긴다)."""
    ledger = [] if ledger is None else ledger
    me = os.getpid() if me is None else me
    t0 = clock()
    deadline = t0 + CLEANUP_S if deadline is None else deadline
    reaped, first = [], {}

    def watch(until, where):
        """until 전에만 관측을 시작한다 → (마지막 관측의 살아 있는 자손 · 좀비) · 관측을 하나도 시작하지 못했으면 (None, [])."""
        alive, zombies = None, []
        while clock() < until:
            table = observe(ledger, where, proc=proc, read=read)
            reaped.extend(reap(table, me, skip, ledger, waitpid=waitpid))
            desc = descendants(table, me)
            alive = [q for q, s in desc if s != "Z"]
            zombies = [q for q, s in desc if s == "Z"]
            first.setdefault("alive", alive)
            if not alive:
                break
            left = until - clock()
            if left > 0:
                sleep(min(POLL_S, left))
        return alive, zombies

    alive, zombies = watch(min(deadline, t0 + limit), "settle")
    kills, after = [], None
    if alive:
        kills = kill(alive, ledger, killer=killer)
        after, after_zombies = watch(deadline, "settle_after_kill")
        if after is not None:
            alive, zombies = after, after_zombies
    if ledger:
        status = "unknown"
    elif alive is None or (kills and after is None):
        status = "unverified"
    elif not kills:
        status = "empty"
    else:
        status = "alive" if alive else "killed"
    return {"status": status, "alive": alive, "first_alive": first.get("alive"), "zombies": zombies, "kills": kills, "reaped": reaped,
            "errors": list(ledger), "first_error": ledger[0] if ledger else None, "deadline_hit": clock() >= deadline}


def cleanup(p, timed_out, *, ledger, deadline, me=None, clock=time.monotonic, sleep=time.sleep, proc=PROC, read=None, killpg=os.killpg,
            killer=os.kill, waitpid=os.waitpid, kill_wait_s=KILL_WAIT_S, settle_s=SETTLE_S) -> dict:
    """정리 — 기한 (`deadline` · run_step 이 정리 단계에 들어갈 때 한 번 만든 절대 시각) 은 받기만 한다 (V3-01). timeout 이면 그룹 SIGKILL → kill_wait_s
    (기한 안) 동안 살아 있는 자손 (pytest 포함) SIGKILL 반복 — 관측은 기한 전에만 시작하고, pytest 가 끝나고 살아 있는 자손이 없으면 멈춤 → pytest 회수
    (남은 시간만 · 기한 뒤에는 wait(0)) → settle (같은 기한). 안의 예외는 여기서 잡아 오류 · ledger 에 남기고 같은 기한으로 비상 동작 (pytest 가 살아
    있으면 그룹 SIGKILL · settle — 관측은 기한 전에만) 만 한다 — 새 기한은 없다. 관측 · 회수 · kill 오류는 모두 같은 ledger 로."""
    me = os.getpid() if me is None else me
    t0 = clock()
    rec = {"timed_out": timed_out, "kills": [], "exited_after_kill": None, "rc_after_kill": None, "errors": [], "emergency": False}

    def group_kill():
        try:
            killpg(p.pid, signal.SIGKILL)
            rec["kills"].append(["group", p.pid, "sent"])
        except ProcessLookupError:
            rec["kills"].append(["group", p.pid, "no_process"])
        except OSError as e:
            rec["kills"].append(["group", p.pid, f"{e.__class__.__name__}: {e}"])
            ledger.append({"where": "group_kill", "utc": utc(), "error": f"{p.pid}: {e.__class__.__name__}: {e}"})

    def finish():
        return settle(p.pid, settle_s, ledger=ledger, deadline=deadline, me=me, clock=clock, sleep=sleep, proc=proc, read=read, waitpid=waitpid,
                      killer=killer)

    s = None
    try:
        if timed_out:
            group_kill()
            until = min(deadline, t0 + kill_wait_s)
            while clock() < until:
                table = observe(ledger, "timeout", proc=proc, read=read)
                live = [q for q, st in descendants(table, me) if st != "Z"]
                if live:
                    rec["kills"] += [["pid", *k] for k in kill(live, ledger, killer=killer)]
                if p.poll() is not None and not live:
                    break
                left = until - clock()
                if left > 0:
                    sleep(min(POLL_S, left))
            try:
                rec["rc_after_kill"] = p.wait(timeout=max(0.0, until - clock()))
                rec["exited_after_kill"] = True
            except subprocess.TimeoutExpired:
                rec["exited_after_kill"] = False
        s = finish()
    except Exception as e:  # noqa: BLE001 — 정리 안의 예외 — 같은 기한으로 비상 동작만 (새 기한 없음)
        rec["errors"].append(f"{e.__class__.__name__}: {e}")
        ledger.append({"where": "cleanup_exception", "utc": utc(), "error": f"{e.__class__.__name__}: {e}"})
        rec["emergency"] = True
        try:
            if p.poll() is None:
                group_kill()
            s = finish()
        except Exception as e2:  # noqa: BLE001
            rec["errors"].append(f"비상 동작 {e2.__class__.__name__}: {e2}")
            ledger.append({"where": "cleanup_emergency", "utc": utc(), "error": f"{e2.__class__.__name__}: {e2}"})
            s = None
    if s is None:
        s = {"status": "unknown", "alive": None, "kills": [], "reaped": [], "errors": list(ledger), "first_error": ledger[0] if ledger else None}
    rec.update(settle=s, status="unknown" if ledger else s["status"], deadline_hit=clock() >= deadline, cleanup_s=round(clock() - t0, 3))
    return rec


def subreaper() -> tuple:
    """PR_SET_CHILD_SUBREAPER 를 켠다 → (성공, errno). 켜지면 이 프로세스의 자손이 고아가 될 때 init 대신 이 프로세스 밑으로 온다."""
    libc = ctypes.CDLL(None, use_errno=True)
    if libc.prctl(PR_SET_CHILD_SUBREAPER, 1, 0, 0, 0) == 0:
        return True, None
    return False, ctypes.get_errno()


# ---------------------------------------------------------------- 단계 하나
def run_step(name, timeout, argv, *, repo=REPO, bms=BMS, e=E, work=WORK, expect=EXPECT, targets=TARGETS, environ=None,
             popen=subprocess.Popen, clock=time.monotonic) -> int:
    """단계 하나 (모듈 docstring) → 반환 0 · 1 · 3 · 4. 의도된 거부는 어떤 파일 · 폴더도 만들기 전 SystemExit."""
    repo, bms, e, work = Path(repo), Path(bms), Path(e), Path(work)
    if name not in expect:
        raise SystemExit(f"단계는 {sorted(expect)} 뿐이다: {name!r}")
    if e.parent != bms / "evidence" or not EVIDENCE_NAME.match(e.name):
        raise SystemExit(f"실행기는 {bms / 'evidence'}/reil_c4e1_0b_a2_YYYYMMDD/ 안에 있어야 한다: {e}")
    files = {k: e / f"{name}.{k}" for k in ("meta.json", "stdout.log", "stderr.log", "porcelain_start.txt", "porcelain_end.txt",
                                            "source_sha256.txt", "source_sha256_end.txt")}
    meta = {"step": name, "argv": list(argv), "cwd": str(bms), "timeout_s": timeout, "cleanup_s": CLEANUP_S, "kill_wait_s": KILL_WAIT_S,
            "settle_s": SETTLE_S, "targets": list(targets), "start_utc": utc()}
    errors, problems, end_problems, ledger, records, times = [], [], [], [], {}, {}
    phase, p, rc, cl, timed_out, started, self_sha = "prepare", None, None, None, False, False, None
    t_c0 = cdl = None  # 정리 원점 · 공통 절대 기한 — 정리 단계에 들어갈 때 한 번만 만든다 (V3-01)
    self_path = Path(__file__).resolve()
    t0 = clock()
    try:
        taken = [str(q) for q in files.values() if entry_exists(q)]
        if taken:
            raise SystemExit(f"이미 있다 — 덮어쓰지 않는다: {taken}")
        env, removed = base_env(dict(os.environ if environ is None else environ))
        child_env = dict(env, **CHILD_SET, MPLCONFIGDIR=str(work / "mpl"), TMPDIR=str(work / "tmp"), REIL_C4_FIX_EVIDENCE=str(e),
                         REIL_C4_FIX_STEP=name)
        meta.update(env_removed_names=removed, env_set={k: child_env[k] for k in (*CHILD_SET, "MPLCONFIGDIR", "TMPDIR", "REIL_C4_FIX_EVIDENCE",
                                                                                  "REIL_C4_FIX_STEP", "GIT_TERMINAL_PROMPT")})
        for d in (work / "mpl", work / "tmp"):
            d.mkdir(parents=True, exist_ok=True)
        self_sha = sha256(self_path.read_bytes())
        meta["runner"] = {"path": str(self_path), "sha256": self_sha}  # 기록용 · 검증 아님
        meta["disk_free_start_bytes"] = shutil.disk_usage(bms).free
        rows = source_table(repo, targets)
        write_new(files["source_sha256.txt"], source_text(rows, self_path, self_sha))
        meta["source_start"] = rows
        problems += source_problems(rows, expect[name])
        if problems:  # V3-N1 — 자식 전에 멈추는 이유마다 errors 에도 (first_error 가 멈춘 이유를 가리킨다 · 상세는 problems)
            errors.append({"phase": "prepare", "type": "SourceMismatch", "message": f"{len(problems)} 건 — 첫째: {problems[0]}"[:500]})
        if not problems:
            ok, err = subreaper()
            meta.update(subreaper=ok, subreaper_errno=err)
            if not ok:
                problems.append(f"PR_SET_CHILD_SUBREAPER 실패 (errno {err})")
                errors.append({"phase": "prepare", "type": "SubreaperFailed", "message": f"errno {err}"})
        if not problems:
            phase = "record"
            records["head_start"] = git(["rev-parse", "HEAD"], env=env, cwd=repo)
            records["porcelain_start"] = git(["status", "--porcelain=v1", "--untracked-files=all"], env=env, cwd=repo)
            write_new(files["porcelain_start.txt"], records["porcelain_start"]["out"])
            bad = record_problems(records, heads=("head_start",), porcelains=("porcelain_start",))
            if bad:
                problems += bad
                errors.append({"phase": "record", "type": "GitRecordFailed", "message": f"{len(bad)} 건 — 첫째: {bad[0]}"[:500]})
        if not problems:
            phase = "start"
            with open(files["stdout.log"], "xb") as fo, open(files["stderr.log"], "xb") as fe:
                t1 = clock()
                p = popen(list(argv), cwd=str(bms), env=child_env, stdout=fo, stderr=fe, start_new_session=True)
                started = True
                phase = "wait"
                try:
                    rc = p.wait(timeout=timeout)
                except subprocess.TimeoutExpired:
                    timed_out = True
                times["child_s"] = round(clock() - t1, 3)
                phase = "cleanup"
                t_c0 = clock()
                cdl = t_c0 + CLEANUP_S
                cl = cleanup(p, timed_out, ledger=ledger, deadline=cdl, clock=clock)
                times["cleanup_s"] = round(clock() - t_c0, 3)
                if timed_out:
                    rc = cl.get("rc_after_kill")
            phase = "record"
            t2 = clock()
            records["porcelain_end"] = git(["status", "--porcelain=v1", "--untracked-files=all"], env=env, cwd=repo)
            write_new(files["porcelain_end.txt"], records["porcelain_end"]["out"])
            records["head_end"] = git(["rev-parse", "HEAD"], env=env, cwd=repo)
            rows_end = source_table(repo, targets)
            write_new(files["source_sha256_end.txt"], source_text(rows_end, self_path, self_sha))
            meta["source_end"] = rows_end
            end_problems += source_problems(rows_end, expect[name]) + record_problems(records)
            times["records_s"] = round(clock() - t2, 3)
    except Exception as ex:  # noqa: BLE001 — 어느 단계의 예외든 기록한다 (SystemExit 는 잡지 않는다)
        errors.append({"phase": phase, "type": ex.__class__.__name__, "message": str(ex)[:500]})
        if p is not None and cl is None:  # 자식 시작 뒤의 예외인데 정리 결과가 없다 — 정리 전이면 기한을 여기서 처음 만들고, 이미 있으면 그 기한 (새 15 s 없음 · V3-01)
            try:
                if cdl is None:
                    t_c0 = clock()
                    cdl = t_c0 + CLEANUP_S
                cl = cleanup(p, p.poll() is None, ledger=ledger, deadline=cdl, clock=clock)
                times["cleanup_s"] = round(clock() - t_c0, 3)
            except Exception as ex2:  # noqa: BLE001
                errors.append({"phase": "cleanup", "type": ex2.__class__.__name__, "message": str(ex2)[:500]})
    for key, look in (("disk_free_end_bytes", lambda: shutil.disk_usage(bms).free),
                      ("evidence_bytes_before_meta", lambda: sum(q.stat().st_size for q in e.rglob("*") if q.is_file()))):
        try:
            meta[key] = look()
        except Exception as ex:  # noqa: BLE001 — 끝 관측의 실패도 오류로 남기고 meta 는 계속 쓴다
            errors.append({"phase": "end", "type": ex.__class__.__name__, "message": str(ex)[:500]})
    times["total_s"] = round(clock() - t0, 3)
    cl = cl or {}
    runner_ok = (started and not timed_out and cl.get("status") == "empty" and cl.get("deadline_hit") is False and not problems
                 and not end_problems and not errors)
    meta.update(started=started, problems=problems, end_problems=end_problems, pgid=None if p is None else p.pid, rc=rc, timed_out=timed_out,
                cleanup=cl or None, errors=errors, first_error=errors[0] if errors else None, runner_ok=runner_ok, times=times,
                records={k: {kk: vv for kk, vv in v.items() if kk != "out"} | ({"out": v.get("out", "").strip()} if k.startswith("head") else {})
                         for k, v in records.items()},
                end_utc=utc(), child_maxrss_kib=resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss)
    try:
        write_new(files["meta.json"], dump(meta))
    except Exception as ex:  # noqa: BLE001 — 기록 자체가 불가능하면 외부 stderr · 반환 4 로 한계를 분리한다
        sys.stderr.write(json.dumps({"step": name, "meta_write_failed": f"{ex.__class__.__name__}: {ex}", "started": started,
                                     "first_error": errors[0] if errors else None, "problems": problems[:5], "runner_ok": False},
                                    ensure_ascii=False) + "\n")
        return 4
    print(json.dumps({"step": name, "started": started, "rc": rc, "timed_out": timed_out, "end": cl.get("status"), "runner_ok": runner_ok,
                      "times": times}, ensure_ascii=False))
    if not started:
        return 3
    return 0 if (runner_ok and rc == 0) else 1


def main(argv=None) -> int:
    a = sys.argv[1:] if argv is None else list(argv)
    if len(a) < 4 or a[2] != "--":
        raise SystemExit("사용: 00_step_runner.py <단계> <timeout_s> -- <argv…>")
    try:
        timeout = float(a[1])
    except ValueError:
        raise SystemExit(f"timeout_s 가 수가 아니다: {a[1]!r}") from None
    if not 0 < timeout <= 3600:
        raise SystemExit(f"timeout_s 는 0 초과 3600 이하: {timeout}")
    return run_step(a[0], timeout, a[3:])


if __name__ == "__main__":
    sys.exit(main())

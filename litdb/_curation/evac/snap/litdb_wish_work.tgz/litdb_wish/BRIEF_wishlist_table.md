# 지시서 — litdb 추가 필요 논문 목록을 한 표로 (11-12 · 문서만)

## 0. 왜

정본 `litdb/_curation/wishlist.md` 는 논문 에이전트가 정독할 때마다 "n — 논문 에이전트 후보" 절을 **원문 그대로 덧붙인 기록**이다 (배치 24 개 · 항목 114). 중복 · 이미 카드가 생긴 것 · 이미 후보 표 (1저자가 PDF 를 준 목록) 에 있는 것 · 우선순위가 정리돼 있지 않다. 1저자가 여기서 골라 PDF 를 준다 — **고르기 쉬운 한 표**를 만든다.

## 1. 입력 (모두 읽기만)

- 지금 wishlist 사본: `…/scratchpad/wishlist_now.md` (정본 `origin/claude/friendly-meitner-lldvar` 의 `litdb/_curation/wishlist.md` · 11-12)
- 정본 카드 목록: `…/scratchpad/papers_now.txt` (`litdb/papers/` 541 항목) — 카드 내용은 `git -C /home/user/litdb-ctl show origin/claude/friendly-meitner-lldvar:litdb/papers/<slug>.md` 로만 (그 디렉터리에서 쓰기 · 체크아웃 · fetch 금지)
- 후보 표 (1저자가 PDF 를 준 · 줄 편): `…/scratchpad/tools/queue.json` (열쇠 N-xx · X-xx · `bib` · `pdf`) · 원 후보 표 = 정본 `litdb/_curation/` 아래 (있으면 `git show` 로)
- 내가 만든 거친 첫 판 (틀린 맞춤 있음 — 참고만): `…/scratchpad/wishlist_table.tsv` · 만든 도구 `…/scratchpad/tools/wishlist_table.py`. 알려진 틀림: 성 + 해만 맞춰 다른 논문을 "카드 있음" 으로 (zhang2023 · kim2023 · wang2018 · choi2018 확인 필요) · 흔한 성 (li 등) 이 후보 표 여러 줄에 걸림 · 번호 붙은 참고문헌 ("6. AKAZAWA") · Perrenot 2023 열쇠 실패.
- 정독 질문 a–n 의 뜻: 리포 `docs/reviews/dem_redesign_direction_20261109/WORKORDER_litdb_dem_mpm_reading_20261110.md` (리포 본 트리 `/home/user/Yonghoon-DEM-DFT` 는 게이트가 도는 중 — 읽기만)
- 트랙 우선 (CLAUDE.md 용훈 포메이션 줄): Rint ② (1 순위 · 기한) → [DEM 우선] Ⓐ DEM 신뢰성 (언로딩 · 고체량 · 실험 원측정) · Ⓑ DEM → MPM 연계 (FAM · 소성 · 입자 형태 · 피복) · Ⓒ 코팅 활물질 믹싱 → [DEM 우선 (수영)] 재설계 (가압부터 한 모델 · 순수 SE 기준 10–13 % · 진밀도 1.64) → 나머지.

## 2. 할 일

1. 항목마다 같은 논문을 묶는다 — DOI 가 있으면 DOI · 없으면 제1 저자 성 + 해 + 학술지 · 권 · 쪽. 같은지 애매하면 따로 두고 [같은지 미확인].
2. 상태를 **제목 · DOI 로 확인**한다 (성 + 해만으로 정하지 않는다):
   - `카드 있음` — 정본 카드의 머리 (제목 · DOI · 학술지) 가 같을 때만 · slug 적기.
   - `후보 표 N-xx` — queue.json 의 bib · pdf 이름이 같은 논문일 때만.
   - `PDF 필요` — 둘 다 아님.
3. 우선순위 (규칙을 표 위에 적고 그대로):
   - **A** = 지금 열린 결정 · 등록과 바로 이어짐 (Rint ② SE–SE · 탄소 계면 · 언로딩 · 순수 SE 기준 · 믹서 D3 · [DEM 우선 (수영)] 단계 0–3) 또는 두 배치 이상이 요청.
   - **B** = 우리가 쓰는 방법의 원전 (MPM 변형 · GIMP · 접촉 모델 · 측정법 등).
   - **C** = 흐름 밖 · 배경 (항목이 스스로 "흐름 밖" 이라 적은 것 포함).
   - 근거 = 그 항목의 "왜" 칸 (질문 문자 · 단계 · 트랙) — 지어내지 않는다.
4. 서지는 **wishlist 에 적힌 원문 그대로** (원문 참고문헌 목록 인쇄). 빠진 제목 · DOI 를 웹 · 기억으로 채우지 않는다 → [미확인].

## 3. 산출 (`…/scratchpad/litdb_wish/` 에만)

- `wishlist_table.md` — 머리: 만든 날 · 입력 (wishlist 원 커밋 · 카드 수) · 세는 법 · 우선 규칙. 그다음 표 `W 번호 | 우선 | 상태 | 서지 (원문 그대로 · 줄여도 저자 · 해 · 학술지 · 권 · 쪽은 남김) | 요청한 배치 · 카드 | 왜 (짧게)`. 상태별 · 우선별 수.
- `pick_list.md` — **1저자가 PDF 를 고를 짧은 목록**: `PDF 필요` 중 A 전부 + B 상위 (A 가 10 편 넘으면 A 만) · 한 줄씩 `서지 — 왜 (한 줄)`.
- `fixes.md` — wishlist 원문의 틀린 점 (이미 카드가 생긴 것 · 같은 논문 다른 표기 · 잘못된 줄) · 고치지는 않는다.

## 4. 규칙

리포 · 정본 · 다른 트리 쓰기 없음 · git 상태 변경 없음 · 웹 검색 없음 · Artifact 도구 · 웹 게시 도구 쓰지 않음 · 한국어 · 표 중심 · 천 단위 콤마 없음.

## 5. 답장

10 줄 안팎: 고유 편 수 · 상태별 (카드 있음 · 후보 표 · PDF 필요) · 우선별 (A · B · C) · pick_list 편 수 · 내 첫 판의 틀린 맞춤 몇 개였나 · 산출 파일 전체 경로.

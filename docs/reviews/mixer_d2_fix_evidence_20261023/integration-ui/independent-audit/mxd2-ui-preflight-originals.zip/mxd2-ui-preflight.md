# MXD2 UI evidence preflight

Status: PREFLIGHT_PASS. Candidate `3ca28d474d4f0a775bad657acc307f1a5c8447ce`; base `7799a2ff64ba462b42ce05edd3e63b7c2854d557`. 21 checks, 0 failures. Final publication remains pending push and ZIP.

The three frozen live-browser files exactly equal the original external records. The candidate generator and v17 devlog have the approved hashes `661936b78c3d60794714a63102f5461f7f42f581a5ad7da466c7c6fe0465bc27` and `232df926a7e593d1e64dfa9b939dd54208d133a4ca65818e5087471f53b5edb5`. The browser records codex/mixer-mxd2 on the base HEAD before candidate creation; its explicit imported-working-tree phase and file hashes distinguish that historical HEAD from the reviewed bytes.

The recorded `/`, `/mixer`, and `/hetero` responses are all HTTP 200 with empty JavaScript-error arrays. The inspected script asserts the v17 title, development/unregistered label, all seven detailed tokens, and the easy/detail/easy visibility roundtrip before writing PASS. The preceding owned-service reload record reports v17 in an HTTP 200 response.

The Flask receipt, summary, and log also exactly equal their external originals. The pinned tool hash and raw log hash match the receipt. The command is isolated (`-I -B`), exit code is 0, and the raw log contains nine PASS lines plus the same summary JSON. The scratch v17 document equals the candidate blob. Generator before/after hashes remain the approved hash.

These are recorded local UI observations, not simulation, registration, or D2/D3 policy approval. Absolute loopback/service paths describe that run; the browser script makes no general portability claim. No service, browser, simulation, or test was executed during this audit. The JSON records frozen evidence hashes for comparison after publication.

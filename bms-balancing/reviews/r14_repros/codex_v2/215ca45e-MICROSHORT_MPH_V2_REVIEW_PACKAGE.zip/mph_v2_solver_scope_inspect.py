"""Read-only, stdlib-only inspection of a COMSOL MPH nested in the supplied ZIP.

Only generated review evidence is written. Source archive and target repository
are never changed. Paths preserve XML element ownership; actions are omitted.
"""
import argparse
import hashlib
import io
import json
import re
import sys
import zipfile
from pathlib import Path
import xml.etree.ElementTree as ET
import xml.parsers.expat as XP

SOURCE = Path('C:/Users/Administrator/Documents/카카오톡 받은 파일/ICA_degradation mode.zip')
OUT = Path(__file__).with_name('mph_v2_solver_scope_evidence.json')

def digest(data):
    return hashlib.sha256(data).hexdigest()

def walk(root, prefix=''):
    records = []
    def visit(el, parent, disabled):
        if el.tag in ('actions', 'History'):
            return
        ident = el.get('tag') or el.get('param') or el.get('name')
        segment = el.tag + ('[@' + ('tag' if el.get('tag') else 'param' if el.get('param') else 'name') + '=' + json.dumps(ident, ensure_ascii=False) + ']' if ident else '')
        path = parent + '/' + segment
        own_flags = [c.text for c in el if c.tag == 'entityFlags']
        own_disabled = any('DISABLED' in (v or '') for v in own_flags)
        attrs = dict(el.attrib)
        text = (el.text or '').strip()
        # Keep all actual scalar evidence; skip enormous presentation/table bodies.
        if len(text) > 12000:
            text = {'length': len(text), 'sha256_utf8': digest(text.encode())}
        records.append({'path': path, 'kind': el.tag, 'attrs': attrs,
                        'text': text, 'own_flags': own_flags,
                        'own_disabled': own_disabled,
                        'inherited_disabled_from': disabled,
                        'direct_children': [dict(kind=c.tag, attrs=c.attrib, text=(c.text or '').strip()) for c in el if c.tag in ('selection', 'entityFlags', 'param', 'property', 'entitydim') and not list(c)]})
        next_disabled = disabled + [path] if own_disabled else disabled
        for c in el:
            visit(c, path, next_disabled)
    visit(root, prefix, [])
    return records

def build():
    outer_bytes = SOURCE.read_bytes()
    with zipfile.ZipFile(io.BytesIO(outer_bytes)) as outer:
        name = next(i.filename for i in outer.infolist() if i.filename.endswith('.mph'))
        mph_bytes = outer.read(name)
    with zipfile.ZipFile(io.BytesIO(mph_bytes)) as mph:
        xml_bytes = mph.read('dmodel.xml')
        metadata_names = ['model.xml', 'modelinfo.xml', 'guimodel.xml']
        metadata = {n: mph.read(n).decode('utf-8') for n in metadata_names}
        metadata['fileversion'] = mph.read('fileversion').decode('utf-8')
        # Save-point metadata and their embedded model XMLs are separate snapshots.
        snapshots = {}
        for n in mph.namelist():
            if n.endswith('/model.zip'):
                with zipfile.ZipFile(io.BytesIO(mph.read(n))) as inner:
                    snapshots[n] = {'members': inner.namelist()}
                    for member in inner.namelist():
                        if member.endswith('.xml'):
                            data = inner.read(member)
                            snapshots[n][member] = {'sha256': digest(data), 'records': walk(ET.fromstring(data))}
            elif n.endswith('/savepoint.xml'):
                data = mph.read(n)
                snapshots[n] = {'sha256': digest(data), 'records': walk(ET.fromstring(data))}
        return {'source': str(SOURCE), 'outer_sha256': digest(outer_bytes),
                'mph_member': name, 'mph_sha256': digest(mph_bytes),
                'dmodel_sha256': digest(xml_bytes),
                'dmodel_bytes': len(xml_bytes), 'metadata': metadata,
                'records': walk(ET.fromstring(xml_bytes)), 'snapshots': snapshots}

def line_index(data):
    """Start lines of the same ownership paths, without interpreting COMSOL."""
    parser = XP.ParserCreate()
    stack = []
    lines = {}
    def start(tag, attrs):
        ident = attrs.get('tag') or attrs.get('param') or attrs.get('name')
        segment = tag + ('[@' + ('tag' if attrs.get('tag') else 'param' if attrs.get('param') else 'name') + '=' + json.dumps(ident, ensure_ascii=False) + ']' if ident else '')
        stack.append(segment)
        lines.setdefault('/' + '/'.join(stack), parser.CurrentLineNumber)
    parser.StartElementHandler = start
    parser.EndElementHandler = lambda tag: stack.pop()
    parser.Parse(data, True)
    return lines

def finalize(data):
    def selected(r):
        p, k, a = r['path'], r['kind'], r['attrs']
        if k == 'expressions':
            return a.get('name') in {'C_rate','sigma_short','epss_el','epss_pos','epss_Gr','epsl_sep','b_PE','cs_Gr_max','cs_NCM_max','x_Gr_init','x_NCM_init','nLi_0','nLi_target','dLi_LLI','A_cell','C_lit0_ref1','LLI','LAM_NE','LAM_PE','dm_fNE','dm_fPE','CurrentDirection','i_app','SOC','dSdt'}
        if '/PhysicsList' in p:
            if k in {'Physics','PhysicsFeature','entityFlags','selection','explicit'}:
                return True
            return k == 'param' and a.get('param') in {'cEeqref_mat','cEeqref','ParticleMaterial','ParticleConcentrationType','csinit','Eeq_mat','Eeq','cs_ref','MaterialOption','sigma_mat','sigma','epss','epsl','IonicCorrModel','ElectricCorrModel','DiffusionCorrModel','fl','fs','fDl','equation','name','initialValueU','initialValueUt','f','S','value','Ichar','Idis','Vmax','Vmin','trech'}
        if '/MaterialList' in p:
            return ('Material[@tag="mat1"]' in p or 'Material[@tag="mat5"]' in p) and (k in {'selection','explicit'} or k == 'param' and a.get('param') in {'csmax','cEeqref','Eeq','soc'})
        if '/StudyList' in p:
            return k in {'Study','StudyFeature','entityFlags','NodeDefaultValues'} or k == 'propertyValue' and a.get('name') in {'p:activate','p:initstudy','p:initsol','p:initsoluse','p:notstudy','p:notsol','p:notsoluse','p:solnum','p:tunit','p:tlist','p:pname','p:plistarr','p:punit'}
        if '/SolverSequenceList' in p:
            if k in {'SolverSequence','paramNames','paramVals','paramUnits','paramToString','solutionnative','savePoint','study','solType','entityFlags'}:
                return True
            if k == 'SolverFeature' and (a.get('op') in {'StopCondition','Variables','StudyStep'} or a.get('tag') in {'comp1_S','comp1_ODE1','comp1_ODE2'}):
                return True
            if k == 'propertyValue':
                return a.get('name') in {'p:study','p:studystep','p:control','p:initsol','p:notsol','p:initsoluse','p:notsoluse','p:solnum','p:sol','p:storestopcondsol','p:stopcondwarn','p:updateEventSettings','p:comp','p:tlist'}
            return k == 'NodeDefaultValues' and ('SolverFeature[@tag="v1"]' in p or 'SolverFeature[@tag="st1"]' in p)
        if '/Results' in p:
            return k == 'propertyValue' and (a.get('name') == 'p:solution' or a.get('name') == 'p:data' and 'ResultFeature[@tag="pg19"]' in p)
        if p.startswith('/savepoint'):
            return k == 'param' or k == 'physics' or k == 'field' or 'CurrentDirection' in p
        return False

    def attach(rows, member, raw):
        lines = line_index(raw)
        out = []
        for r in rows:
            if selected(r):
                out.append({**{k:v for k,v in r.items() if k != 'direct_children'}, 'source_member': member, 'line': lines.get(r['path'])})
        return out
    with zipfile.ZipFile(SOURCE) as outer:
        with zipfile.ZipFile(io.BytesIO(outer.read(data['mph_member']))) as mph:
            current = attach(data['records'], 'dmodel.xml', mph.read('dmodel.xml'))
            snapshots = {}
            for n in ['savepoint6/model.zip','savepoint6/savepoint.xml']:
                source = data['snapshots'][n]
                if n.endswith('model.zip'):
                    with zipfile.ZipFile(io.BytesIO(mph.read(n))) as inner:
                        member = 'dmodel.xml'
                        raw = inner.read(member)
                        rows = source[member]['records']
                        snapshots[n + '!/' + member] = {'sha256': digest(raw), 'records': attach(rows, n + '!/' + member, raw)}
                else:
                    raw = mph.read(n)
                    snapshots[n] = {'sha256': digest(raw), 'records': attach(source['records'], n, raw)}
    result = {k:v for k,v in data.items() if k not in {'records','snapshots'}}
    result['scope_note'] = 'Selected exact XML records, ownership paths, and 1-based start lines only. Saved flags/source selectors are not a COMSOL execution or generated-equation evaluation. NodeDefaultValues lists property names, not explicit values.'
    result['records'] = current
    result['snapshots'] = snapshots
    return result

def main():
    sys.stdout.reconfigure(encoding='utf-8')
    parser = argparse.ArgumentParser()
    parser.add_argument('--build', action='store_true')
    parser.add_argument('--finalize', action='store_true')
    parser.add_argument('--query')
    parser.add_argument('--path')
    parser.add_argument('--kind')
    parser.add_argument('--snapshot')
    parser.add_argument('--compact', action='store_true')
    parser.add_argument('--limit', type=int, default=200)
    args = parser.parse_args()
    if args.build:
        data = build()
        OUT.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding='utf-8')
        print(json.dumps({k: v for k,v in data.items() if k not in ('records','snapshots')}, ensure_ascii=False, indent=2))
        print('Record counts:', len(data['records']), {k: len(v.get('records', [])) for k,v in data['snapshots'].items()})
        return
    data = json.loads(OUT.read_text(encoding='utf-8'))
    if args.finalize:
        data = finalize(data)
        OUT.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding='utf-8')
        print('Wrote selected evidence:', len(data['records']), 'current records;', OUT.stat().st_size, 'bytes')
        return
    records = data['records']
    if args.snapshot:
        snapshot = data['snapshots'][args.snapshot]
        records = snapshot.get('records')
        if records is None:
            records = next(v['records'] for k,v in snapshot.items() if k != 'members')
    matches = [r for r in records if
               (not args.kind or re.search(args.kind, r['kind'])) and
               (not args.path or re.search(args.path, r['path'])) and
               (not args.query or re.search(args.query, json.dumps(r, ensure_ascii=False), re.I))]
    print('Matches:', len(matches))
    for r in matches[:args.limit]:
        if args.compact:
            attrs = {k: (v[:300] + '... [full value in JSON]' if len(v) > 300 else v) for k,v in r['attrs'].items()}
            path = re.sub(r'/[^/]+List\[@tag="[^"]+"\]', '', r['path'].replace('/Model[@tag="Model2"]', ''))
            print(str(r.get('line', '?')) + ' ' + path + ' ' + json.dumps({'attrs': attrs, 'text': r['text'][:300] if isinstance(r['text'],str) else r['text'], 'disabled': r['own_disabled'] or bool(r['inherited_disabled_from'])}, ensure_ascii=False))
        else:
            print(json.dumps(r, ensure_ascii=False))

if __name__ == '__main__':
    main()

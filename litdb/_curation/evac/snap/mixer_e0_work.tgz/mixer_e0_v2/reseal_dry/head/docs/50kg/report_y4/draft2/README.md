# 50kg 4차년도 DEM 보고 — 초안 2 자료 · 그림 (10-30)

- 무엇: 초안 2 쪽 그림 (PNG 300 dpi · SVG 글자 그대로 · 그린 값 CSV) + 침대별 지표 (`metrics_<침대>.json` · `metrics_all.csv`) + OVITO 사본.  1저자가 양식 (10 × 7.5 in · 4:3) 에 직접 붙인다 → 그림 = 양식 반쪽 칸 크기 · 100 % 로 붙인다 (모든 그림 같은 글자 크기 — 눈금 7 pt · 축 제목 8 pt).
- 근거: `docs/50kg/report_y4/draft2_fix_plan_20261030.md` (§2 쪽 목록 · §3 프레임) · Codex 초안 1 판정 `docs/reviews/codex_kg50_y4_draft1_review_20261030/codex_review_kg50_y4_draft1_20261030.md` (§6–§8 문구 한계) · 문헌 지도 `docs/50kg/report_y4/lit_se_size_map_20261030.md` · 보고 원칙 `docs/report_making_principles.md`.
- 비교 상태 = **판 고정 이완 끝 세트 하나** (atom_end · contact_end · mesh_end 같은 step · 1저자 10-30) — ⚠ 같은 *정의* 이지 같은 *이완 끝 판 압력* 이 아니다 (수렴 인증 아님 · `KG50-20` · `SELF-145`).  **압력 도달 순간 세트 = 자료 없음** (압축 정지 step 에 덤프 없음 · `K50Y4-01`) — 이완 끝 프레임을 300 MPa 상태로 부르지 않는다.  가압 목표 300 MPa · 끝 판 압력 D2 279.8 · D3 291.4 MPa.
- 침대: SE 1 µm (D1 · 10-31 반입) · 2 µm (D2) · 3 µm (D3) = 자료 있음 · SE 0.7 µm (D0.7) = 결과 대기 (모든 비교 그림에 빗금 빈 칸 · 정착 끝에서 멈춤 · 이어 돌리기 = Codex 한 건 범위 GO 뒤).
- 새 지표 정의 없음 — 값 = 검토된 웹앱 파이프라인 (`run_pipeline(stop_after='network')`) · 기존 함수 · 기존 입자 · 접촉 · 점 출력의 집계 (z 구간 · AM 하나당 · 문턱별) 뿐.  새 정의가 필요한 것 = "다음 판" (§6).
- 11-01 초안 3 (회사 보고판 · 1저자 비준 쪽 계획): 쪽 글 = `slide_text_draft3.md` (쪽마다 데이터로 받친 메시지 하나 · 한정어 = 화면 각주 · 발표자 노트 · 부록 1 쪽 · 자리 대조 = 그 시트 §0-3) · 새 그림 셋 `p3_count_vs_area` · `p5_breakeven_sigma` · `p6_constriction_share` (아래 §2) · 앞 그림 13 = PNG · SVG · CSV 바이트 그대로 · 값 · CSV 변화 없음 · 초안 2 시트 (`slide_text_draft2.md`) 그대로 둠 (한정어 원문 · 질문 대비 정본). · 11-01 0쪽 (방법 쪽) 추가 — 2판 (1저자 *"이종기술이랑 너무 그림이 비슷하다 다른 느낌으로"*) = 새 그림 둘 `docs/50kg/report_y4/figs/p0_dem_method/` (2D 모식 계산 — 해석 절차 · 접촉 모델 · 그림용) + 지배방정식 식 넷 2 × 2 표 · 1판 (2-1장 insertion 그림 + 그림 A) 은 쓰지 않음 · 3판 (왼쪽 = 50kg 계획 덱 3D 그림) → 1저자 *"2d 저거로 해도 될거 같은데"* = 2판 그림으로 확정 (왼쪽 2D 절차 그림 · 오른쪽 접촉 모델 그림 · 계획 덱 3D 그림 = 대안) → 1저자 11-01 *"해석 절차는 기존 insertion 부터 하는 3D 저걸로 바꿔주라고"* = **왼쪽 = 50kg 계획 덱 3D 그림으로 확정** (`docs/50kg/report_y4/figs/p0_plan3d/README.md` · 3판 글 · 2D 절차 그림 = 대안 · 오른쪽 그대로) · 1–7쪽 번호 그대로.
- 10-31 문구 고침 (외부 리뷰 조건부 수용 · K50Y4D2-01 · 02 · 03 · 06 · 07 · 08): 진단 그림의 선 = 감쇠 저항 규모 기준선 R_aff (예측 아님) · 점 = DEM 로그 Δp · "정적 압력" → "이완 끝 판 압력" (수렴 인증 아님) · f = f_mc (두께 재척도 · 아래 §1 f 줄) · 그림 검사 범위 (§5) · 문헌 화살표 = 실험 · 모델 구분 (Bazzoun 2026 · Shi 2019 = 모델) — 값 · CSV 값 변화 없음 (그림 CSV 에서 바뀐 칸 = `p7_summary_heat.csv` · `p7_lit_direction.csv` 의 `name` 글 칸 f 행뿐).

## 1. 침대별 핵심 값 (이완 끝 · 입도별 시드 1)

| 양 | SE 1 µm (D1) | SE 2 µm (D2) | SE 3 µm (D3) | 출처 |
|---|---:|---:|---:|---|
| 끝 step (atom · contact · mesh 같음) | 2785002 | 4015002 | 4575002 | 끝 세트 |
| AM · SE 수 (끝 덤프) | 1481 · 166971 | 1481 · 20872 | 1482 · 6184 | atom_end |
| 판 높이 (µm) | 122.596 | 122.469 | 125.877 | mesh_end |
| **ε_sphere (%)** | **16.8250302** | **16.7379229** ✓ Codex | **18.9575565** ✓ Codex | 1 − ΣV구 / (50·50·판 높이) — 웹앱 값과 3e-11 %p 안 (합산 순서) |
| 기공률 정확 합집합 (%) | 18.14 | 19.60 | 22.43 | calc_porosity_union_exact (MC 4 × 10⁶ 점) |
| **이완 끝 판 압력 (MPa)** | **156.15118** ⚠ | **279.79158** ✓ Codex | **291.37440** ✓ Codex | 로그 마지막 정규 thermo × 1000 |
| 정지 직전 t = 0⁻ · 이완 첫 출력 (MPa) | 300.58919 · 199.68129 | 300.23909 · 287.18633 ✓ | 300.63094 · 295.59389 ✓ | 로그 |
| AM–SE 접촉 수 (AM 1개당 평균) | 99.71 | 24.06 | 10.31 | calc_am_isolation_risk |
| SE–SE 접촉 수 (SE 1개당 평균) | 4.98 | 4.04 | 3.34 | calc_se_se_cn |
| AM 피복률 Hertz 계열 / Physics 합집합 cap (%) | 19.04 / 46.77 | 21.05 / 54.23 | 19.07 / 52.63 | calc_coverage · union_coverage_bed |
| AM–SE 접촉 면적 / AM (µm², 평균) | 21.00 | 22.55 | 20.32 | coverage_per_am.csv (c_cpl[22]) |
| f_mc = f_gap × L_gap/L_mc Hertz (Physics) — 판 간격 해의 두께 재척도 | 0.0468 (0.0806) | 0.0334 (0.0638) | 0.0195 (0.0378) | network_conductivity → tau_flux.case_row (`f_ion_*`) · 아래 f 줄 |
| 수송 tortuosity Hertz (Physics) | 6.00 (3.48) | 8.26 (4.32) | 13.63 (7.03) | φ_SE·σ₀/σ_eff · 제곱근 아님 · φ = 질량 보존 · = φ_mc/f_mc = φ_sphere/f_gap |
| 기하 tortuosity | 1.223 | 1.276 | 1.366 | calc_tortuosity_all (최단 경로 / Δz) |
| SE 망과 연결된 AM (%) (연결성 기준) | 100 | 100 | 100 | calc_ionic_active_am |
| 협착 소산 몫 (이온 · Hertz) | 0.742 | 0.715 | 0.710 | constriction_power_share_ion_hertz |

- ⚠ **D1 = 끝 판 압력 156 MPa** (D2 280 · D3 291) — 판 정지와 전역 감쇠 감소 뒤 압력이 하락했으며, 결과 전에 제기한 감쇠 교란 가설과 정성적으로 부합한다.  기준선은 affine 속도장을 가정한 저항 규모이며, 낙폭의 일반 상한이나 예측값은 아니다.  각 기전의 정량 기여는 미분리이다 (원장 `KG50-20` · `DEMP-01` · `docs/data/kg50_d1_end_20261031/README.md` §3 · 기준선 = `diag_relax_drop_vs_N` 의 선).  같은 정의의 끝 세트이지만 **이완 끝 판 압력이 같은 상태가 아니다** (수렴 인증 아님) → D1 의 접촉 · 피복 · 수송 · 응력 값 = 판정 보류 (1저자 10-31 Q1 (가)) · ε_sphere 도 이완 끝 판 압력이 다른 상태에서 굳은 값.
- D1 = Codex 기준값 없음 (sha256 · 값만 기록 · 끝 묶음 = 리포 밖) · 도구 파일 sha256 14 개 = D2 · D3 와 같음 (`metrics_<침대>.json`).
- **f 줄 (외부 리뷰 K50Y4D2-03)**: 보고하는 f = **f_mc = f_gap × L_gap / L_mc** — 판 간격 (L_gap = 끝 판 높이) 에서 푼 망의 무차원 σ 비 f_gap (= σ_eff/σ₀) 를 질량 보존 두께 L_mc 로 다시 잰 값 (새 망 풀이 아님 · 원 솔버 σ 비 그대로가 아님 · `scripts/tau_flux.py` 의 `f_ion_*`).  f_gap (Hertz) D1 0.04755623 · D2 0.03457565 · D3 0.02038472 · L_gap / L_mc (µm) D1 122.596 / 124.568496 · D2 122.469 / 126.832237 · D3 125.877 / 131.503444 (`data/<침대>/metrics_<침대>.json` 의 `tau_flux_row` · `metrics`).  f(1)/f(3) = f_gap 기준 Hertz 2.332935 · Physics 2.074508 ↔ f_mc 기준 2.398620 · 2.132917 — 두 기준 모두 손익분기 2.217 의 양쪽 → "판정 보류" 그대로.  수송 tortuosity = φ_mc / f_mc = φ_sphere / f_gap (φ_sphere = SE 구 부피 합 / (50 × 50 µm² × 판 간격)) → 수송 tortuosity 값 그대로.

- ✓ = Codex 독립 재계산 (판정문 §3) 과 출력 자릿수까지 같음 — 러너가 대조하고 다르면 rc 3 으로 멈춘다 (`CODEX` 표).  D3 의 웹앱 다섯 값 (기공률 · 피복 두 갈래 · σ_ion · tau2) 은 10-27 칸 판정 (`docs/data/kg50_d3_cell_verdict_20261027/verdict.json` · 코드 판 `e65e92b7b`) 과 비트 같다 (현 HEAD `12227fa3c` 재실행).
- 전체 = `metrics_all.csv` (침대 넷 행 · 없는 침대 = 결과 대기) · 침대별 원값 · 출처 = `data/<침대>/metrics_<침대>.json`.

## 2. 그림 (`figs/` · 크기 = in · 300 dpi · 각 PNG · SVG · CSV)

양식 패널 (좌 · 우 점선 상자) = 4.63 × 4.56 in (y 2.41 → 6.97 in · 빌드 상수 `PANEL` · `PANEL_BOTTOM`) → 그림 폭 4.50 in (패널 안 여백 0.06 in) · 높이 2.3–3.0 in (패널 안에 머리 글 · 캡션 자리).

| 그림 | 쪽 | 크기 | 자료 | 캡션에 꼭 넣을 한정어 |
|---|---|---|---|---|
| `p1_bed_strip` | 1 | 4.50 × 2.95 | `data/<침대>/section_*.csv` (초안 1 단면과 6 자리 반올림 안 같음) · 덱 (SE 수 · 크기비) | 끝 상태 (판 고정 이완 끝) x–z 단면 · y = 25 µm 평면 · 같은 배율 · AM 검정 · SE 노랑 · 흰 곳 = 2D 구 기하 합집합의 빈 영역 (2쪽 ε_sphere = 3D 구 부피 합과 같은 양 아님) · 겹침 색 = 그리는 순서 (물질 소유권 아님) · 회색 선 = 끝 판 · 벽 · 판에서 자름 · 아래 글 = 덱 계획 SE 수 · D_AM/D_SE · 0.7 µm 결과 대기 (D1 = 10-31 들어감) |
| `p2_compaction` | 2 | 4.50 × 2.70 | `data/<침대>/curve_*.csv` (로그) · metrics | (a) **p > 1 MPa 표시 구간** (첫 접촉 아님) · ε_sphere = 1 − ΣV구 / (50 × 50 µm² × 판 높이) · 판 압력 = 로그 thermo 열 × 1000 (run 첫 setup 줄 뺌) · 점선 = 판 고정 이완 (ε 고정 · 압력만 감소) · ○ = 이완 끝 (비교 프레임 · 같은 이완 끝 판 압력 아님 — `KG50-20`) · (b) 막대 = 이완 끝 ε_sphere · ◇ = 정확 합집합 (벽 밖 부피 뺌) · 가압 목표 300 MPa · 끝 판 압력 D1 156.2 · D2 279.8 · D3 291.4 MPa · 언로딩 없음 · D2 ↔ D3 차 = 산술만 (정착 충전 · 시드 · 질량당 감쇠 · 실행 이력 · 끝 압력 차이 공존 → 입도 인과 아님) |
| `p2_relaxation` (보조) | 2 | 4.50 × 2.55 | `curve_*.csv` | ○ t = 0⁻ = 정지 직전 (마지막 정상 압축 출력 · PHASE 4 setup 값 아님) · 판 고정 10⁵ step · 끝 `run 0` setup 줄 (328.9 · 582.7 MPa) 안 씀 · (a) 자료 있는 침대 전부 (b) 확대 = 이완 폭 (t = 0⁻ 포함 최대 − 최소) 이 (a) 자료 폭의 ¼ 보다 작은 침대 (코드 규칙 `ZOOM_FRAC` · 침대 목록을 적지 않음 · 그런 침대가 없거나 전부면 한 칸) · 끝 값 글 = 그 침대가 그려진 칸 하나에만 |
| `diag_relax_drop_vs_N` (진단) | — | 4.50 × 2.55 | metrics (p(t = 0⁻) · p(이완 끝) · 정지 step) · 덱 · 로그 | ● = DEM 로그 Δp (이완 강하) = p(t = 0⁻) − p(이완 끝) ↔ 판 정지 때 입자 수 N (로그 · 로그) · N = 압축 로그 정지 줄 (PHASE 3 마지막 정규 thermo 줄의 atoms 열 · 로그가 리포에 있고 sha256 = metrics 기록일 때) — 없으면 끝 덤프 AM + SE (CSV `n_source` 에 적음) · N 은 덱 머리 줄 "예상 입자 수 … (합 N)" 의 덱 삽입 구간 안 (생성기가 대조) · 선 = **감쇠 저항 규모 기준선 R_aff = γNv/(2A) (affine 가정)** — γ = 압축 중 `fix damp all viscous` (PHASE 2 · 3) · v = `press_speed` · A = `current_press` 식의 면적 · 덱 단위 압력 ÷ 나눗수 × 1000 = 보고 MPa (전부 덱 실행 줄에서 읽음) · 판 속도가 바닥 0 → 판 v 로 선형인 속도장 가정의 감쇠 저항 합 · 기준선은 affine 속도장을 가정한 저항 규모이며, 낙폭의 일반 상한이나 예측값은 아니다 (판 정지와 함께 덱이 감쇠도 0.5 → 1 × 10⁻⁵ 로 바꾼다) · 세로 점선 = D0.7 덱 계획 N (머리 줄 합) + 선 위 표지 "R_aff 488" · 가로 점선 = 가압 목표 · CSV 열 `dp_est_MPa` · `dp_over_est` · `est_MPa_per_particle` = R_aff · Δp / R_aff (규모 비교 · 예측 정확도 아님) · 입자당 R_aff (열 이름은 그대로) · 원장 DEMP-01 (열림) 의 관계 (감쇠 저항 몫 ≈ N/300,000) 를 보이는 것뿐 — 실측 감쇠 몫 · 이완 끝 판 압력의 수렴 · 구조 영향은 주장하지 않음 · 침대마다 시드 1 |
| `p3_contacts` | 3 | 4.50 × 2.55 | metrics | (a) AM 1개당 AM–SE 접촉 수 (b) SE 1개당 SE–SE 접촉 수 (c) AM 피복률 = SE 접촉 면적 합 / (4πr² − AM–AM 면적) · 막대 = Hertz 계열 (LIGGGHTS 접촉 면적 c_cpl[22] = 기하 교차 원판 · 주) · ○ = Physics 합집합 cap (민감도) · 기하 면적 ≠ 전도 면적 |
| `p3_overlap_threshold` | 3 | 4.50 × 2.55 | metrics (`am_frac_overlap_*`) | AM–SE 접촉 중 겹침 비가 문턱을 넘는 것이 하나라도 있는 AM 의 비율 (분모 = 전체 AM) · (a) δ / min(r₁, r₂) = 기존 `calc_overlap_ratio` 정의 (AM–SE 는 r_SE 기준) (b) δ / (r₁ + r₂) = Zhou 2025 카드 (`tailored_cathode_microstructure_low_pressure_assb`) 의 "두 입자 반경합 대비" 를 같은 δ 에 적용 · 우리 겹침은 유효 E 1.35 GPa 규약이라 크다 (AM–SE 겹침 비 중앙값 (a) 18.4 · 19.6 % (b) 4.6 · 6.5 %) → 문헌 DEM 비율과 직접 비교하지 않음 · 100 근처 막대는 값 글 생략 (CSV) |
| `p3_per_am` | 3 | 4.50 × 2.55 | `data/<침대>/per_am_*.csv` | (a) AM 1개당 AM–SE 접촉 면적 합 (Hertz 계열 · µm²) (b) AM 1개 피복률 분포 — 채움 = Hertz 계열 (주) · 빈 상자 = Physics 합집합 cap (민감도) · 상자 25–75 % · 선 5–95 % · + 평균 · 숫자 = 중앙값 |
| `p4_tortuosity` | 4 | 4.50 × 2.55 | metrics | (a) 기하 tortuosity = SE–SE 접촉 그래프 최단 경로 / Δz (바닥 관통 SE 전부 · 길이만 · 수송 τ 아님) (b) **수송 tortuosity = φ_SE·σ₀/σ_eff (전도도에서 정의한 무차원 수송 지표 · 제곱근 아님 · φ = 질량 보존 · 전극 부피)** · Hertz 주 · ○ Physics 민감도 · 두 양 = 다른 정의 (비로 묶지 않음) · 단분산 (PSD 폭 변화 없음) |
| `p4_f_connect` | 4 · 5 | 4.50 × 2.55 | metrics | (a) f_mc = f_gap × L_gap / L_mc (f_gap = 판 간격 망 해의 σ_eff/σ₀ · 질량 보존 두께로 다시 잰 값 · 새 망 풀이 아님 · σ₀ 약분 · Hertz 주 · Physics 민감도 · Stage-E σ_ion 안 씀 · §1 f 줄) · **f 와 수송 tortuosity = 같은 해의 종속량** (독립 성공 둘로 세지 않음) (b) SE 망과 연결된 AM 비율 (연결성 기준 = 위쪽 판에 닿는 SE 성분과 접촉한 AM) |
| `p6_z_structure` | 6 | 4.50 × 2.80 | `data/<침대>/zprof_*.csv` | z 10 구간 (바닥 0 → 판 · 같은 폭 12.2–12.6 µm) · (a) 국소 기공률 = 정확 합집합 몬테카를로 점 (calc_porosity_union_exact 와 같은 씨앗 · 같은 점 · 구간당 ≈ 4 × 10⁵ 점 · 통계 오차 ≈ 0.06–0.07 %p) 의 빈 점 비율 — 벽 · 판 옆 구간이 높은 것 = 평면 벽 옆 충전 · ε_sphere 와 다른 규약 (b) SE 망과 연결된 AM 비율 (AM 중심 z · 구간당 AM 137–158 개) · 점선 = 각 판 높이 · "함께 비교" (기계 → 전기 인과 아님) |
| `p6_z_stress` | 6 | 4.50 × 2.80 | `zprof_*.csv` | Love–Weber 입자 응력 σ_VM (입자 접촉력 기반 대칭 응력 · kinetic · 벽 · couple 항 없음 · 프레임 미인증 · 이완 끝 가압 상태) · 선 = 구간 중앙값 · 띠 = 25–75 % · 벽 · 판에 닿은 입자 제외 (함수의 nowall 규칙 · 바닥 · 꼭대기 구간 AM 33–42 · SE 97–1751 개 (D1 SE 1731–1751)) · 같은 도구 · 같은 규약끼리만 · 반응률 · 균열 · 용량 아님 |
| `p7_summary_heat` | 7 | 4.50 × 3.00 | `metrics_all.csv` | 칸 글 = 값 · 색 = SE 3 µm 대비 비의 log₂ (좋고 나쁨 아님 · ±2.5 배 포화) · f 행 = f_mc (두께 재척도) · 입도별 시드 1 (오차 막대 없음) · 값 표 — 방향 · 비단조 판정은 네 입도 산출 뒤 분석 계획대로 |
| `p7_lit_direction` | 7 | 4.50 × 3.00 | metrics + 정본 litdb 카드 6 | 선택한 6편의 실험 · 모델에서 보고한 작은 SE 쪽 방향 (화살표 · 카드 번호 · [5] Bazzoun 2026 = DEM–FEM–RNM 변수 연구 · [6] Shi 2019 = 모델 연결성 지도 → 범례 "(모델)") 과 우리 값을 나란히만 — **일치 판정 아님** · 다른 SE · 다른 PSD · 우리 = 단분산 대리 입도 · 시드 1 · f 칸 = f_mc (두께 재척도) |
| `p3_count_vs_area` (초안 3) | 3 | 4.50 × 2.55 | metrics (`am_se_cn_mean` · `area_am_se_per_am_mean_um2` · `area_am_se_per_contact_mean_um2`) | (a) AM 1개당 AM–SE 접촉 수 (b) AM 1개당 AM–SE 접촉 면적 합 (c) 접촉 하나 평균 면적 = (b) ÷ (a) (생성기가 자료로 항등 대조 · 상대 10⁻⁶) · 면적 = Hertz 계열 기하 면적 (c_cpl[22] · 전도 면적 아님) · 이중 y 축 대신 셋째 작은 칸 · 관측 (기전 아님) · D1 = 끝 판 압력 156 MPa → 비교 보류 |
| `p5_breakeven_sigma` (초안 3) | 5 | 4.50 × 2.80 | metrics `tau_flux_row` (f_mc · f_gap × Hertz · Physics) + SE 펠릿 실측 σ (`docs/50kg/dem_plan_20261026.md` §0 표 줄 · 손익분기 비 = 보고 계획 문서와 대조) | 손익분기 고유 σ = σ(3 µm) × f(3)/f(d) (σ_eff = SE 고유 σ × f 의 조건부 시나리오 · `KG50B-02`) · 띠 = f 네 기준 최소–최대 · ◆ = 펠릿 실측 (3 µm = 기준) · ◇ = 0.66 µm 시료 (0.7 µm 침대 대응 미확인 · f 결과 대기) · 2 µm 실측 결측 · f = 모형 내부 구조 계수 (절대 σ 인증 아님) · 펠릿 σ × f = 이중계상 위험 · D1 = 끝 판 압력 156 MPa · 시드 1 |
| `p6_constriction_share` (초안 3) | 6 | 4.50 × 2.80 | metrics (`constriction_power_share_ion_hertz`) | 이온 망 (SE–SE 간선) 저항 소산 몫 — 협착 Σ I²R_c / Σ I²R (같은 해 · 가상 전극 연결 제외) · 입자 내부 (bulk) = 1 − 협착 몫 (간선 R = R_bulk + R_c) · Hertz 계열 · 모형 내부 몫 (실측 계면 저항 몫 아님) · Physics 갈래 몫 = 자료 없음 · D1 = 끝 판 압력 156 MPa |

- 범례 · 설명 = 축 밖 (그림 위 한 줄) — 더 자세한 글은 슬라이드 글로.  SVG = 글자 그대로 (`font-family: Aptos, 맑은 고딕, Carlito, WenQuanYi Zen Hei, …`) → PowerPoint 에서 편집 가능.  ⚠ 이 기계에 Aptos · 맑은 고딕이 없어 **PNG 의 영문 = Carlito · 한글 = WenQuanYi Zen Hei** 로 박혀 있다 → 양식 글꼴로 보이려면 SVG 를 넣는다.
- 색: AM (NCM) `#1A1A1A` · SE `#CDB650` (50kg 계획 덱) · 입도 = 파랑 한 색상 밝음 → 어두움 (0.7 → 3 µm · dataviz 서열 검사 통과) · Physics = 속 빈 표지.
- 결정적 출력 — 같은 입력 · 같은 환경에서 두 번 그린 `figs/figs_meta.json` (파일별 sha256) 이 같음.
- p5 (조건부 σ 시나리오) = 초안 1 틀 + 쪽 글 — f(1)/f(3) (f_mc 기준) = Hertz 2.40 · Physics 2.13 (f_gap 기준 2.33 · 2.07) ↔ 손익분기 2.217 (두 규약이 선 양쪽 · 두 기준 모두 · D1 끝 판 압력 다름 → 판정 보류 · `slide_text_draft2.md` 5쪽).

## 3. D1 끝 세트가 오면 (한 명령)

```bash
# 1) 1저자가 보낸 D1 끝 묶음 (atom_end · contact_end · mesh_end 같은 step · 덱 있으면 함께) 과 로그를 리포 기록 폴더에 넣는다 (예: docs/data/kg50_d1_end_<날짜>/)
# 2) 한 번에: 끝 세트 검사 → 웹앱 망 정지 파이프라인 → 집계 → metrics_D1.json → metrics_all.csv → 그림 전부 다시
python3 -P docs/50kg/report_y4/draft2/run_draft2_metrics.py add --bed D1 \
    --tgz docs/data/kg50_d1_end_<날짜>/<묶음>.tgz \
    --log docs/data/kg50_d1_end_<날짜>/<로그>.liggghts \
    [--prefix kg50_d1_b50/]   # 묶음 안 폴더가 다르면
```

- 묶음 안 접두 기본 = `kg50_d1_b50/` · 세 덤프가 같은 step 이어야 한다 (결손 · 엇갈림 = 거부) · 덱 멤버가 없으면 리포 v3 덱 (manifest `deck_sha256` 대조).
- 묶음 · 멤버 sha256 기록 (README 표) 이 있으면 `--record <README.md>` 로 대조 (D2 · D3 는 자동).  D1 은 Codex 기준값이 없으므로 sha256 · 값만 기록한다.
- D0.7 도 같은 명령 (`--bed D0.7`).  큰 침대 (D1 ≈ 1.7 × 10⁵ · D0.7 ≈ 4.9 × 10⁵ 입자) 는 망 단계가 길다 (D3 ≈ 1 분 · D2 ≈ 2.5 분 · D1 ≈ 17 분 실측 · 이 컨테이너).
- D2 · D3 다시 만들기: 같은 명령 (`run` = 그 침대만 · `merge` = 표만 · `add` = 셋 다) — 아래 §5.

### 3-1. 2 µm SE 영률 변형 침대 (D2E05 · D2E15 · 11-02)

- 무엇: 기준 D2 의 정착 끝 체크포인트 (`restart_after_settling.bin` · step 200001) 에서 SE 영률만 바꿔 이어 돈 두 런 (덱 단위 0.0675e7 · 0.2025e7 = 0.675 · 2.025 GPa · 기준 1.35).  입도 비교 (`BED_ORDER` · 그림 · `metrics_all.csv`) 밖 — 표 = `metrics_modulus.csv` (`merge-modulus`).
- 덱 검사 = r4 재개 덱 (`docs/data/kg50_resume_tests_20261027/d2_main_1028_0942/input_kg50_d2_b50_r4.liggghts` · sha256 `eacc23e6…`) + 네 고침만 (read_restart → restart_after_settling.bin · `run 180000` 뺌 · 정착 끝 write_restart 뺌 · SE youngsModulus) — 다른 차이 · 침대와 다른 영률 = 거부 (`e_deck_check` · selftest 28/28).  덱 멤버 필수 (리포 덱으로 대신하지 않음) · 묶음 접두 = `kg50_d2_b50_e05/` · `kg50_d2_b50_e15/` · 로그 판독 case = `kg50_d2_b50` · 시작 대조 = 기준 D2 기록의 판 시작 높이 (1e-5 µm 안) · 입자 수.
- 웹앱에 올리는 덱 = 리포 기준 D2 덱 + SE 영률 한 줄 (E 덱은 재개 덱이라 상자 줄이 없어 웹앱이 합집합 피복을 빈칸으로 둔다) — 웹앱 parse 값이 실제 E 덱과 상자 키 말고 같은지 대조 (`webapp_param_check`).
- 명령 (묶음을 새 빈 폴더에 둔 뒤 · `-I`):

```bash
python3 -I docs/50kg/report_y4/draft2/run_draft2_metrics.py add --bed D2E05 --tgz <폴더>/kg50_d2_b50_e05_end.tgz --log <폴더>/kg50_d2_b50_e05/log.liggghts
python3 -I docs/50kg/report_y4/draft2/run_draft2_metrics.py add --bed D2E15 --tgz <폴더>/kg50_d2_b50_e15_end.tgz --log <폴더>/kg50_d2_b50_e15/log.liggghts
#   [--data-root <출력 뿌리>]  = 리포 밖에 쓸 때 (기본 = 이 폴더의 data/<침대>/ · metrics_modulus.csv)
```

## 4. OVITO

- `ovito/D1_end_2785002_um.xyz.gz` · `ovito/D2_end_4015002_um.xyz.gz` · `ovito/D3_end_4575002_um.xyz.gz` (확장 XYZ · µm · species = AM/SE · radius · id · dump_type) — 색 · 시점 · 단면 제안 = `ovito_render_spec.md`.

## 5. 재현 · 검사 (10-30 · 이 작업 트리 · HEAD `12227fa3c` 위)

```bash
python3 -P docs/50kg/report_y4/draft2/run_draft2_metrics.py selftest                      # 끝 세트 소비자 시험 9/9
python3 -P docs/50kg/report_y4/draft2/run_draft2_metrics.py add --bed D3 \
    --tgz docs/data/kg50_d3_cell_verdict_20261027/kg50_d3_end_20261027.tgz --log docs/data/kg50_d3_cell_verdict_20261027/kg50_d3_b50_s1_log.liggghts
python3 -P docs/50kg/report_y4/draft2/run_draft2_metrics.py add --bed D2 \
    --tgz docs/data/kg50_d2_end_20261030/kg50_d2_end_20261030_4files.tgz --log docs/data/kg50_d2_end_20261030/kg50_d2_b50_log.liggghts
python3 -P docs/50kg/report_y4/draft2/make_draft2_figs.py                                 # 그림만 (그린 뒤 검사 · 문제 있으면 rc 1)
python3 -P docs/50kg/report_y4/draft2/make_draft2_figs.py --check                         # 그리고 검사만 (파일 안 씀 · 현재 입력의 도형 · 문자 범위 / 겹침 검사)
```

| 검사 | 결과 |
|---|---|
| Codex 값 (ε_sphere · 이완 끝 · t = 0⁻ · 이완 첫 판 압력 · 정지 · 끝 step · AM · SE 수) | D2 8/8 · D3 8/8 출력 자릿수까지 같음 (`codex_check`) |
| 끝 세트 신원 | 묶음 sha256 = 기록 (D2 `ead5bed6…` · D3 `918394e1…`) · 멤버 4 개 sha256 = 기록 · 덱 = 리포 덱 = manifest · 덤프 머리 TIMESTEP = 파일 이름 step (세 파일 같음) |
| 집계 ↔ 웹앱 전체 값 대조 (침대마다 10 항) | D2 10/10 · D3 10/10 — 겹침 평균 (calc_overlap_ratio 재호출 · 접촉별 재계산) · AM–SE 접촉 수 평균 · top-reachable 비율 · SE 망 연결 AM 비율 · Hertz 피복 평균 · AM–SE 면적 합 · Physics 합집합 피복 평균 · Love–Weber CV · 정확 합집합 총 공극 (같은 씨앗 · 같은 점 · 비트 같음) |
| 로그 압밀 곡선 | 판 높이 복원 = 끝 mesh (덱 단위 5e-7 안) · 이완 끝 step = 끝 덤프 step · 압축 run 이음 (초안 1 `make_fig_p2_aux.branches` 그대로) |
| 1쪽 단면 | 초안 1 `docs/50kg/report_y4/figs/p1_sections.csv` 와 행 수 · 입자 · 주기 상 같음 · 좌표 차 ≤ 5e-7 µm (초안 1 CSV 6 자리 반올림) |
| 끝 세트 소비자 시험 (`selftest`) | 9/9 — 같은 step 세트 수락 · 덱 없음 → 리포 덱 · contact 결손 · mesh 결손 · contact step 엇갈림 · atom 둘 · 머리 TIMESTEP ≠ 이름 · 접두 밖만 = 거부 |
| 기존 도구 자기 시험 (이 트리) | `kg50_d3_cell_verdict.py --selftest` PASS (✓ 33 · ✗ 0) · `test_tau_flux.py` 55/55 · `coverage_physics_vs_hertzian.py --selftest` PASS · `lhs_union_webapp.py --selftest` PASS (0 실패) |
| 그림 결정성 | 두 번 그린 `figs_meta.json` 같음 (11-01 새 그림 셋 포함 · 앞 그림 13 파일 바이트 그대로) |
| 그림 검사 (11-01 · 초안 3) | 그림 16 · 문제 0 → PASS (새 셋 `p3_count_vs_area` · `p5_breakeven_sigma` · `p6_constriction_share` 포함) · 새 그림 가드 변이 탐침 15/15 (항등 · f 기준 · 망 상태 · 실측 σ ↔ 계획 산술 · 몫 범위 · 네 침대 합성) · 기록 `figcheck/draft3_check_20261101.txt` · 범위 = 아래 줄과 같음 |
| 그림 검사 (`check_figure` · 10-31) | 범위 = **현재 입력의 도형 · 문자 범위 / 겹침 검사** (입력 무결성 인증 아님 — 값 · 출처는 위 행들) · 축마다: 그린 자료 (선 · 곡선 점 · 표지 (반지름 포함) · 막대 · 상자 · 수염 · 띠 · 빈 칸 빗금) 가 축 범위 안 · 축 글이 축 안 · 그 축 제목 · 다른 축 글과 안 겹침 · 그림 글 (머리 줄) = 그림 안 · 서로 · 축 제목과 안 겹침 · "결과 대기" 글은 자료 없는 침대만 · 1쪽 단면 원 = 판 · 벽 자르기가 실제로 걸림 — 축 범위 = 전부 자료 + 값 글 자리로 정한다 (고정 범위 없음).  결과 = `figs/figs_meta.json` 의 `check` · 기록 `figcheck/` (고치기 전 FAIL 125 · 옛 고정 범위 되넣기 = FAIL · 고친 뒤 PASS).  ⚠ 글 폭 = 이 기계 글꼴 (Carlito · WenQuanYi) 로 잰다 — SVG 를 Aptos 로 열면 글 폭이 조금 다를 수 있다 (여유 2 pt) |
| 문서 참조 (`scripts/check_doc_refs.py`) | 깨진 참조 없음 (이 폴더 포함 리포 전수) |
| 인용 금지 (`check_review_findings.ban_sweep` 를 이 폴더 파일에만) | 게이트 글롭 안 5 파일 (md · json) = 0 건 · 글롭 밖 CSV · SVG 의 숫자 열 · 경로 좌표 안에 등록 숫자열 (CL-33 · CL-90 항목) 이 우연히 포함된 6 건 (인용 아님 · 게이트 대상 아님) · 10-31 (D1 · 진단 그림 · 바뀐 39 파일) = 글롭 안 (README · figs_meta.json) 0 건 · 글롭 밖 9 건 (SVG 경로 좌표 8 · D2 CSV 숫자 1 · 같은 부류) |
| 실행 시간 (이 컨테이너 · 4 코어) | D3 ≈ 1 분 · D2 ≈ 2.5 분 |

- 러너는 격리 폴더 (빈 임시 폴더 · `--work`) 에 풀고 웹앱을 Flask 시험 클라이언트로 부른다 (Supabase 끔 · 자동 DB 끔 · 그림 끔) — 리포 · 웹앱 데이터 폴더를 건드리지 않는다.  `scripts/check_all.sh` 는 돌리지 않았다 (이 작업의 범위 밖 · 메인 세션 게이트).

## 6. 하지 않은 것 · 다음 판

| 자리 | 상태 | 이유 |
|---|---|---|
| 2쪽 주 그림 (AM 표면 거리별 SE 점유 · 껍질) | 다음 판 | 새 지표 정의 (껍질 분모 · 상 겹침 소유권) — 반례 시험 먼저 (`KG50B-05`) |
| 3쪽 주 그림 (AM 구면 cap 합집합 지도) | 다음 판 | 새 지표 (지도 투영 · 대표 AM 규칙) — AM 별 합집합 피복 *값* 은 `p3_per_am` 에 있음 |
| 6쪽 ② z 구간 전위 강하 · 소산 몫 | 다음 판 | 망 해의 z 분해 = 새 정의 |
| 국소 기공률의 ε_sphere 판 (z 구간) | 안 함 | 구 · 구간 교차 부피 = 새 기하 계산 → 기존 정확 합집합 점 출력의 z 집계로 대신 (규약이 다르다고 캡션에 적음) |
| 압력 도달 순간 프레임 | 자료 없음 | 정지 step 에 덤프 없음 (`K50Y4-01` · `dump_modify first` 기본 no) |
| 5쪽 조건부 σ 시나리오 | 초안 1 그대로 | 새 숫자 없음 · f(1)/f(3) = D1 뒤 |
| 문헌 방향 그림의 새 카드 8 편 (Yano 2026 · Lin 2025 · Calpa 2019 · Tron 2023 · Yadav 2021 · Lei 2026 · Kawaguchi 2026 · Stavola 2023) | 그림에는 넣지 않음 · 쪽 노트에만 | 정본 litdb `c431470a1` 에 카드 생김 (10-30) — 방향이 한 가지로 모이지 않는다 (SOC 의존 · PSD 폭 · 큰 SE 반례 · 이중계상 위험) → `docs/50kg/report_y4/lit_se_size_map_20261030.md` §7 · 쪽 글 `docs/50kg/report_y4/draft2/slide_text_draft2.md` |
| 오차 막대 · 경향 판정 | 안 함 | 입도별 시드 1 · 판정 (방향 일치 · 비단조 · 보류 · 한계) = 네 입도 산출 뒤 분석 계획대로 |

- `p3_overlap_threshold` (b) 의 δ/(r₁+r₂) = 같은 접촉 δ 의 정규화만 다른 문헌 카드 정의 — 새 물리량은 아니지만 기존 함수 (δ/min r) 밖의 식이므로 검토 때 명시 (쓰지 않으려면 (a) 만).
- 문헌 방향 그림의 카드 = `schlautmann2023_se_particle_size_composite_transport` · `minnmann2024_microstructure_porosity_visualization` · `tailored_cathode_microstructure_low_pressure_assb` · `minnmann2021_jes_charge_transport_bottlenecks` · `bazzoun2026_dem_fem_rnm_ionic` (모델 — DEM–FEM–RNM 변수 연구) · `shi2019_high_am_loading_particle_size_assb` (모델 — 연결성 지도) (정본 브랜치 로컬 ref 에서 방향 문장 확인 · 값은 옮기지 않음) — 화살표 = 이 6편의 실험 · 모델에서 보고한 방향 (외부 리뷰 K50Y4D2-07).

## 7. 파일

- `run_draft2_metrics.py` — 침대 러너 (`run` · `add` · `merge` · `selftest`) · `make_draft2_figs.py` — 그림.
- `slide_text_draft2.md` — 초안 2 글 시트 (방법 검증 보고 꼴 · 한정어 원문) · `slide_text_draft3.md` — 초안 3 글 시트 (회사 보고판 · 11-01 · 숫자 출처 표 = 맨 끝 §10).
- `data/<침대>/` — `metrics_<침대>.json` (값 · 끝 세트 · 덱 · 망 출처 · git HEAD · 도구 파일 sha256 · 함수 이름) · `per_am_*.csv` (AM 하나당: z · AM–SE 접촉 수 · 면적 · 피복 Hertz/Physics · 최대 겹침 비 둘 · SE 망 연결 · Love–Weber σ_VM · 벽 접촉) · `zprof_*.csv` (z 10 구간) · `curve_*.csv` (가압 · 이완 로그 곡선) · `section_*.csv` (1쪽 단면 원).
- `metrics_all.csv` — 침대 넷 한 표 · `figs/` — 그림 + `figs_meta.json` (크기 · dpi · sha256) · `ovito/` · `ovito_render_spec.md`.

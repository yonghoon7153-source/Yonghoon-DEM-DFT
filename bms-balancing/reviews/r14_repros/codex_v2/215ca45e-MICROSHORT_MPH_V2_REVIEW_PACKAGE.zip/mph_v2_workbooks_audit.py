"""Read-only OOXML audit of four supplied COMSOL fit-result workbooks.

Uses only the Python standard library. It never saves, recalculates, or modifies
a workbook and does not execute workbook formulas. The JSON is audit evidence,
including every stored cell and independently recomputed algebraic identities.
"""
from __future__ import annotations

import hashlib
import io
import json
import math
from pathlib import Path
import posixpath
import re
import struct
import xml.etree.ElementTree as ET
from zipfile import ZipFile
from decimal import Decimal


BASE = Path("C:/Users/Administrator/Documents/카카오톡 받은 파일")
OUT = Path(__file__).resolve().with_name("mph_v2_workbooks_evidence.json")
FILES = [
    ("ref1", "result_L_ref#1 _0.1C 12h__charge.xlsx"),
    ("ref2", "result_L_ref#2 _0.1C 12h__charge.xlsx"),
    ("PE1", "result_L_PE#1 _0.1C 12h__charge.xlsx"),
    ("PE5", "result_L_PE#5 _0.1C 12h__charge.xlsx"),
]
NS = {"s": "http://schemas.openxmlformats.org/spreadsheetml/2006/main"}
REL_NS = "http://schemas.openxmlformats.org/package/2006/relationships"
DOC_REL = "http://schemas.openxmlformats.org/officeDocument/2006/relationships"
EXPECTED = ["cycle", "C_cell", "x_cell", "a_PE", "b_PE", "a_NE", "b_NE", "c_lit", "LAM_PE", "LAM_NE", "LLI"]


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def bits(value):
    return struct.pack(">d", float(value)).hex()


def read_book(label, filename):
    path = BASE / filename
    original_hash = sha(path)
    output = {"label": label, "path": path.as_posix(), "sha256_before": original_hash, "bytes": path.stat().st_size}
    with ZipFile(path) as zf:
        output["zip_members"] = zf.namelist()
        wb = ET.fromstring(zf.read("xl/workbook.xml"))
        rels = ET.fromstring(zf.read("xl/_rels/workbook.xml.rels"))
        relationships = {r.get("Id"): r.attrib for r in rels}
        strings = []
        if "xl/sharedStrings.xml" in zf.namelist():
            shared = ET.fromstring(zf.read("xl/sharedStrings.xml"))
            strings = ["".join(t.text or "" for t in si.iter(f"{{{NS['s']}}}t")) for si in shared]
        output["defined_names"] = [dict(n.attrib, text=n.text) for n in wb.findall("s:definedNames/s:definedName", NS)]
        calc = wb.find("s:calcPr", NS)
        output["calculation_properties"] = None if calc is None else calc.attrib
        output["workbook_relationships"] = list(relationships.values())
        output["number_formats"] = []
        if "xl/styles.xml" in zf.namelist():
            styles = ET.fromstring(zf.read("xl/styles.xml"))
            output["number_formats"] = [v.attrib for v in styles.findall("s:numFmts/s:numFmt", NS)]
            output["cell_style_formats"] = [v.attrib for v in styles.findall("s:cellXfs/s:xf", NS)]
        output["sheets"] = []
        for meta in wb.findall("s:sheets/s:sheet", NS):
            target = relationships[meta.get(f"{{{DOC_REL}}}id")]["Target"]
            member = target.lstrip("/") if target.startswith("/") else posixpath.normpath(posixpath.join("xl", target))
            root = ET.fromstring(zf.read(member))
            dimension = root.find("s:dimension", NS)
            sheet = {"name": meta.get("name"), "state": meta.get("state", "visible"), "member": member,
                     "declared_dimension": None if dimension is None else dimension.get("ref"), "cells": []}
            sheet["row_attributes"] = [r.attrib for r in root.findall("s:sheetData/s:row", NS)]
            sheet["column_attributes"] = [c.attrib for c in root.findall("s:cols/s:col", NS)]
            sheet["merges"] = [c.attrib for c in root.findall("s:mergeCells/s:mergeCell", NS)]
            sheet["data_validations"] = [ET.tostring(c, encoding="unicode") for c in root.findall("s:dataValidations/s:dataValidation", NS)]
            for c in root.findall("s:sheetData/s:row/s:c", NS):
                f, v, typ = c.find("s:f", NS), c.find("s:v", NS), c.get("t", "n")
                raw = None if v is None else v.text
                if typ == "s":
                    value = strings[int(raw)]
                elif typ == "inlineStr":
                    value = "".join(t.text or "" for t in c.findall("s:is/s:t", NS))
                elif typ == "n" and raw is not None:
                    value = float(raw)
                elif typ == "b":
                    value = bool(int(raw))
                else:
                    value = raw
                sheet["cells"].append({"cell": c.get("r"), "type": typ, "style": c.get("s"),
                    "raw_value": raw, "value": value, "formula": None if f is None else f.text,
                    "formula_attributes": None if f is None else f.attrib,
                    "cached_value": value if f is not None else None})
            cells = {c["cell"]: c for c in sheet["cells"]}
            sheet["stored_cell_count"] = len(cells)
            sheet["formula_count"] = sum(c["formula_attributes"] is not None for c in sheet["cells"])
            sheet["error_cells"] = [c for c in sheet["cells"] if c["type"] == "e"]
            sheet["nonfinite_numeric_cells"] = [c for c in sheet["cells"] if isinstance(c["value"], float) and not math.isfinite(c["value"])]
            rownums = sorted({int(re.search(r"\d+$", a).group()) for a in cells})
            sheet["headers"] = [cells.get(f"{chr(65+i)}1", {}).get("value") for i in range(11)]
            sheet["unexpected_cells_outside_A_to_K"] = [a for a in cells if not re.fullmatch(r"[A-K]\d+", a)]
            sheet["header_matches_expected"] = sheet["headers"] == EXPECTED
            sheet["rows"] = []
            for row in rownums:
                if row == 1:
                    continue
                item = {"excel_row": row, "range": f"A{row}:K{row}"}
                item.update({h: cells.get(f"{chr(65+i)}{row}", {}).get("value") for i, h in enumerate(EXPECTED)})
                sheet["rows"].append(item)
            rows = sheet["rows"]
            baseline = next(r for r in rows if r["cycle"] == 0)
            sheet["row_count"] = len(rows)
            sheet["cycles"] = [r["cycle"] for r in rows]
            sheet["duplicate_cycles"] = sorted({r["cycle"] for r in rows if sum(s["cycle"] == r["cycle"] for s in rows) > 1})
            sheet["missing_fields"] = [(r["excel_row"], h) for r in rows for h in EXPECTED if r[h] is None]
            metrics = {name: [] for name in ["x_cell", "LAM_PE", "LAM_NE", "LLI", "c_lit"]}
            for r in rows:
                x = r["C_cell"] / baseline["C_cell"]
                computed = {"x_cell": x, "LAM_PE": 1 - x*r["a_PE"]/baseline["a_PE"],
                            "LAM_NE": 1 - x*r["a_NE"]/baseline["a_NE"], "LLI": 1 - r["c_lit"]/baseline["c_lit"],
                            "c_lit": r["C_cell"] * (r["a_PE"] + r["b_PE"] - r["b_NE"])}
                r["derived"] = computed
                r["errors"] = {name: r[name]-computed[name] for name in metrics}
                for name in metrics:
                    metrics[name].append(abs(r["errors"][name]))
                r["a_PE_equals_baseline_float64"] = bits(r["a_PE"]) == bits(baseline["a_PE"])
                r["a_NE_equals_baseline_float64"] = bits(r["a_NE"]) == bits(baseline["a_NE"])
                r["LAM_PE_NE_equal_rtol1e9_atol0"] = abs(r["LAM_PE"]-r["LAM_NE"]) <= 1e-9 * abs(r["LAM_NE"])
                r["LLI_minus_capacity_loss"] = r["LLI"] - (1-x)
                r["LLI_from_alpha_beta"] = 1 - x * ((r["a_PE"] + r["b_PE"] - r["b_NE"]) /
                    (baseline["a_PE"] + baseline["b_PE"] - baseline["b_NE"]))
                r["LLI_minus_alpha_beta_identity"] = r["LLI"] - r["LLI_from_alpha_beta"]
                r["a_PE_equals_baseline_XML_token"] = cells[f"D{r['excel_row']}"]["raw_value"] == cells[f"D{baseline['excel_row']}"]["raw_value"]
                r["a_NE_equals_baseline_XML_token"] = cells[f"F{r['excel_row']}"]["raw_value"] == cells[f"F{baseline['excel_row']}"]["raw_value"]
            rail = [r for r in rows if r["a_PE_equals_baseline_float64"]]
            postrail = [r for r in rail if r["cycle"] > 0]
            sheet["identity_max_abs_errors"] = {name: max(vals) for name, vals in metrics.items()}
            sheet["LLI_from_alpha_beta_max_abs_error"] = max(abs(r["LLI_minus_alpha_beta_identity"]) for r in rows)
            sheet["a_PE_rail_cycles"] = [r["cycle"] for r in rail]
            sheet["a_PE_below_baseline_cycles"] = [r["cycle"] for r in rows if r["a_PE"] < baseline["a_PE"]]
            sheet["a_PE_above_baseline_cycles"] = [r["cycle"] for r in rows if r["a_PE"] > baseline["a_PE"]]
            sheet["a_NE_all_equals_baseline_float64"] = all(r["a_NE_equals_baseline_float64"] for r in rows)
            sheet["a_NE_unique_values"] = sorted({r["a_NE"] for r in rows})
            sheet["b_NE_exact_zero_cycles"] = [r["cycle"] for r in rows if r["b_NE"] == 0]
            sheet["b_NE_abs_below_1e15_cycles"] = [r["cycle"] for r in rows if abs(r["b_NE"]) < 1e-15]
            sheet["b_NE_nonzero"] = [{"cycle": r["cycle"], "cell": f"G{r['excel_row']}", "value": r["b_NE"]} for r in rows if r["b_NE"] != 0]
            sheet["LAM_equal_cycles"] = [r["cycle"] for r in rows if r["LAM_PE_NE_equal_rtol1e9_atol0"]]
            sheet["postbaseline_rail_LLI_minus_capacity_loss_range"] = [min(r["LLI_minus_capacity_loss"] for r in postrail), max(r["LLI_minus_capacity_loss"] for r in postrail)]
            sheet["all_rail_LLI_minus_capacity_loss_range"] = [min(r["LLI_minus_capacity_loss"] for r in rail), max(r["LLI_minus_capacity_loss"] for r in rail)]
            sheet["column_stats"] = {h: {"min": min(r[h] for r in rows), "max": max(r[h] for r in rows), "unique_count": len({r[h] for r in rows})} for h in EXPECTED}
            output["sheets"].append(sheet)
    output["sha256_after"] = sha(path)
    output["source_unchanged"] = output["sha256_after"] == original_hash
    return output


def mph_matches(books):
    path = BASE / "ICA_degradation mode.zip"
    with ZipFile(path) as outer:
        mph_members = [n for n in outer.namelist() if n.lower().endswith('.mph')]
        assert len(mph_members) == 1, mph_members
        mph_bytes = outer.read(mph_members[0])
    with ZipFile(io.BytesIO(mph_bytes)) as zf:
        members = [n for n in zf.namelist() if posixpath.basename(n) == "dmodel.xml"]
        if len(members) != 1:
            raise ValueError(f"Expected one dmodel.xml; got {members}")
        root = ET.fromstring(zf.read(members[0]))
    wanted = ["LAM_PE", "LAM_NE", "LLI", "C_lit0_ref1", "dNE", "dPE", "dm_fNE", "dm_fPE"]
    params = {name: [e.get("expr") for e in root.iter("expressions") if e.get("name") == name] for name in wanted}
    out = {"path": path.as_posix(), "mph_member": mph_members[0], "sha256": hashlib.sha256(mph_bytes).hexdigest(), "xml_member": members[0], "parameters": params, "matches": {}}
    for name, exprs in params.items():
        out["matches"][name] = []
        for expr in exprs:
            m = re.match(r"^\s*([-+]?\d+(?:\.\d*)?(?:[eE][-+]?\d+)?)", expr)
            if not m:
                continue
            number = Decimal(m.group(1))
            tol = Decimal(5).scaleb(number.as_tuple().exponent - 1)
            for book in books:
                for sheet in book["sheets"]:
                    for c in sheet["cells"]:
                        if c["type"] != "n" or c["raw_value"] is None:
                            continue
                        delta = Decimal(c["raw_value"]) - number
                        if abs(delta) <= tol:
                            out["matches"][name].append({"workbook": book["label"], "sheet": sheet["name"], "cell": c["cell"], "source_decimal": c["raw_value"], "mph_decimal": str(number), "source_minus_mph": str(delta), "tolerance_half_last_printed_digit": str(tol)})
    out["dm_complements"] = {}
    for e in ["NE", "PE"]:
        dm = Decimal(params[f"dm_f{e}"][0])
        lam = Decimal(params[f"LAM_{e}"][0])
        out["dm_complements"][e] = {"one_minus_LAM": str(1-lam), "dm_minus_complement": str(dm-(1-lam))}
    return out


def main():
    books = [read_book(*item) for item in FILES]
    evidence = {"scope": "Read-only direct OOXML stored-data audit; no formula execution, Excel recalculation, refit, or COMSOL execution.",
                "source_books": books, "mph": mph_matches(books)}
    sheets = [s for b in books for s in b["sheets"]]
    evidence["totals"] = {"workbooks": len(books), "sheets": len(sheets), "data_rows": sum(s["row_count"] for s in sheets),
        "stored_cells": sum(s["stored_cell_count"] for s in sheets), "formulas": sum(s["formula_count"] for s in sheets),
        "a_PE_rail_rows_including_baseline": sum(len(s["a_PE_rail_cycles"]) for s in sheets),
        "source_workbooks_unchanged": all(b["source_unchanged"] for b in books)}
    OUT.write_text(json.dumps(evidence, indent=2, ensure_ascii=False, allow_nan=False)+"\n", encoding="utf-8")
    summary = {"totals": evidence["totals"], "workbooks": [{"label": b["label"], "sha256": b["sha256_before"], "sheets": [{k: s[k] for k in ["name", "declared_dimension", "row_count", "formula_count", "headers", "identity_max_abs_errors", "a_PE_rail_cycles", "a_NE_unique_values", "b_NE_nonzero", "postbaseline_rail_LLI_minus_capacity_loss_range"]} for s in b["sheets"]]} for b in books], "mph": evidence["mph"]}
    print(json.dumps(summary, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()

#!/usr/bin/env bash
# 2단계 러너 — 정지 규칙을 **실제로 적용**하려면 순서가 있어야 한다 (회신 AJ·AO·AP).
#
#   0단계(자동): POTCAR 조립 + provenance + **묶음 root 봉인** (AO P0-2·Q1)
#   1단계: primary 두 조각 x 셀 두 높이 + 기체 기준 + 기체 canary
#          -> **1단계 선결조건 8축** 전부 통과해야 2단계가 열린다:
#             진공 수렴 · 분자 스핀 · canary 기하 · POTCAR 신원 ·
#             δ_gas(기체 상자) · pm1 자기 topology · 잔여 차단 0 · 봉인 포괄
#   2단계: primary 다른 seed + 대안 자세 두 seed
#          -> 시작 **직전에** 1단계 게이트를 다시 돌린다 (AP #6)
#          -> 끝나면 최종 분석기를 돌린다 (AP #9)
#
# ⛔ 이 스크립트가 **유일한 실행 경로**다. run_job.sh 를 손으로 부르지 않는다.
set -u
usage() { echo "사용법: bash run_staged.sh {1|2}"; exit 2; }
[ $# -ge 1 ] || usage
stage=$1
case "$stage" in 1|2) ;; *) echo "모르는 단계: $stage"; usage;; esac
# 🔴🔴 회신 AV P0-2 (2026-08-31) — **자유형 launcher 문자열을 폐지한다.**
#   회신 AT 해제 뒤에도 세 형태가 뚫렸다:
#     `mpirun -np 48 other_vasp`  — PATH 이름은 파일이 아니라 -x 검사에 안 걸린다
#     `/tmp/evil/mpirun -np 48`   — basename 만 봐서 아무 경로나 mpirun 행세를 했다
#     `env --split-string=...`    — env 는 인자 문법 자체가 실행이다
#   교훈: 문자열을 **검사**하는 한 진다. ⇒ 사용자는 종류와 수만 주고,
#   **argv 는 러너가 조립한다** (회신 AV Q5 — 이름 목록은 좁게, env 는 제거):
#     VASP_LAUNCHER_KIND : mpirun | mpiexec | srun | none | wrapper
#     VASP_NPROC         : 랭크 수 (양의 정수 · none 이면 생략 가능)
#     VASP_EXE           : 실행파일 절대경로 (봉인 대상)
#     VASP_WRAPPER       : KIND=wrapper 일 때 현장 wrapper 절대경로 —
#                          SEAL 이 해시를 봉인하고 실행 직전 재대조한다
if [ -n "${VASP_CMD:-}" ] || [ -n "${VASP_LAUNCHER:-}" ]; then
  echo "⛔ VASP_CMD / VASP_LAUNCHER 는 폐지됐습니다 (회신 AV P0-2)."
  echo "   자유형 문자열은 봉인된 실행파일을 우회할 수 있어 종류+수만 받습니다:"
  echo "     export VASP_LAUNCHER_KIND=mpirun   # mpirun|mpiexec|srun|none|wrapper"
  echo "     export VASP_NPROC=48"
  echo "     export VASP_EXE=/abs/path/to/vasp_std"
  exit 2
fi
VASP_LAUNCHER_KIND=${VASP_LAUNCHER_KIND:?VASP_LAUNCHER_KIND 를 지정하세요 (mpirun|mpiexec|srun|none|wrapper)}
VASP_EXE=${VASP_EXE:?VASP_EXE 를 지정하세요 (실행파일 절대경로 — 이것이 봉인 대상입니다)}
# ⛔⛔ 2026-09-01 (회신 AZ P0-2) — **PATH 조회를 여기서도 폐기한다.**
#   AY P0-1 에서 run_job.sh 의 PATH 조회만 걷고 "폐기했다" 고 적었는데, **봉인을
#   만드는 이 자리가 그대로였다.** PATH 앞에 가짜 mpirun/vasp_std 를 두면 그 파일이
#   **정상적으로 봉인된다** — 봉인 뒤 교체만 막고 '가짜를 처음부터 봉인하는' 경로는
#   열려 있었다. 우회를 닫은 게 아니라 한 겹 더 미룬 것이었다 (같은 실수 두 번째).
#   ⇒ 절대경로만 받는다. PATH 에서 찾아 주지 않는다.
case "$VASP_EXE" in
  /*) ;;
  *) echo "⛔ VASP_EXE 는 **절대경로**여야 합니다 (회신 AZ P0-2): $VASP_EXE"
     echo "   PATH 에서 찾아 주지 않습니다 — PATH 앞의 가짜가 봉인될 수 있습니다."
     echo "   예: export VASP_EXE=\\$(command -v vasp_std)   # 값을 **직접 확인한 뒤** 주세요"
     exit 2 ;;
esac
[ -f "$VASP_EXE" ] && [ -x "$VASP_EXE" ] || { echo "⛔ VASP_EXE 가 실행파일이 아닙니다: $VASP_EXE"; exit 2; }
LAUNCHER_BIN=${LAUNCHER_BIN:-}
VASP_WRAPPER=${VASP_WRAPPER:-}
case "$VASP_LAUNCHER_KIND" in
  mpirun|mpiexec|srun)
    case "${VASP_NPROC:-}" in
      ''|*[!0-9]*|0) echo "⛔ VASP_NPROC 가 양의 정수가 아닙니다: '${VASP_NPROC:-}'"; exit 2 ;;
    esac
    # ⛔ 회신 AZ P0-2 — launcher 도 **절대경로로 직접** 받는다 (PATH 조회 없음).
    [ -n "$LAUNCHER_BIN" ] || {
      echo "⛔ LAUNCHER_BIN=/abs/path/to/$VASP_LAUNCHER_KIND 를 주세요 (회신 AZ P0-2)."
      echo "   PATH 에서 찾아 주지 않습니다 — 그 경로로 가짜가 봉인될 수 있었습니다."
      exit 2; }
    case "$LAUNCHER_BIN" in /*) ;; *) echo "⛔ LAUNCHER_BIN 은 절대경로여야 합니다: $LAUNCHER_BIN"; exit 2 ;; esac
    [ -f "$LAUNCHER_BIN" ] && [ -x "$LAUNCHER_BIN" ] || { echo "⛔ LAUNCHER_BIN 이 실행파일이 아닙니다: $LAUNCHER_BIN"; exit 2; }
    ;;
  none)
    VASP_NPROC=${VASP_NPROC:-1} ;;
  wrapper)
    # 목록 밖 launcher 는 **해시로 봉인한 wrapper** 로만 (회신 AV Q5).
    #   wrapper 계약: $1=VASP_EXE $2=VASP_NPROC 을 받아 현장 방식으로 돌린다.
    [ -n "$VASP_WRAPPER" ] || { echo "⛔ KIND=wrapper 면 VASP_WRAPPER=/abs/wrapper.sh 를 주세요"; exit 2; }
    case "$VASP_WRAPPER" in /*) ;; *) echo "⛔ VASP_WRAPPER 는 절대경로여야 합니다"; exit 2 ;; esac
    [ -f "$VASP_WRAPPER" ] && [ -x "$VASP_WRAPPER" ] || { echo "⛔ VASP_WRAPPER 가 실행파일이 아닙니다"; exit 2; }
    case "${VASP_NPROC:-}" in
      ''|*[!0-9]*|0) echo "⛔ VASP_NPROC 가 양의 정수가 아닙니다: '${VASP_NPROC:-}'"; exit 2 ;;
    esac
    ;;
  *) echo "⛔ 모르는 VASP_LAUNCHER_KIND: $VASP_LAUNCHER_KIND (mpirun|mpiexec|srun|none|wrapper)"; exit 2 ;;
esac
# ⛔⛔ 2026-09-04 — **랭크 수가 KPAR 의 배수여야 한다.** INCAR 이 `KPAR` 을 명시하는데
#   `VASP_NPROC` 이 그 배수가 아니면 VASP 는 k-그룹을 고르게 못 나눈다 (배치를 거부하거나
#   남는 랭크를 놀린다). INCAR 은 해시로 동결돼 현장에서 못 고치므로, **비용이 나가기 전에**
#   여기서 멈추고 쓸 수 있는 랭크 수를 알려 준다. KPAR 은 잡의 INCAR 에서 직접 읽는다
#   (MANIFEST 사본을 믿지 않는다 — 사본은 언젠가 정본과 갈린다).
#   ⚠ KPAR 은 **잡마다 다르다** (슬랩 4 · 기체 Γ-only 1). 하나만 보면 기체 잡을 집어
#     검사를 건너뛴다 — 전 INCAR 을 훑어 **최댓값**으로 조건을 건다 (그 배수면 1·2·4 전부 나눈다).
#   🔴 렌즈 K2 P1-3 (2026-09-04) — 실제 조건은 `% KPAR` 이 **아니다.** VASP 는 k-그룹당 랭크를
#     다시 NCORE 로 나누므로 `NPROC % (KPAR × NCORE)` 여야 INCAR 대로 돈다. `% KPAR` 만 보면
#     랭크 20(=4×5)이 통과하는데 5 는 NCORE=4 로 안 나뉘어 **VASP 가 NCORE 를 말없이 재설정**한다 —
#     동결한 INCAR 과 실제 병렬화가 갈리고 비용모형(NCORE=4 전제)도 다시 어긋난다.
#   🔴 렌즈 K2 P1-1 — 산술은 `10#` 을 붙인다. `VASP_NPROC=09` 는 위 정수검사를 통과하는데
#     bash 가 8진수로 읽어 죽고, `set -e` 가 없어 **가드를 조용히 새어 나간다** (실측).
_KPAR=$(find . -mindepth 3 -maxdepth 4 -name INCAR -exec \
          sed -n 's/^[[:space:]]*KPAR[[:space:]]*=[[:space:]]*\([0-9][0-9]*\).*/\1/p' {} + 2>/dev/null \
        | sort -n | tail -1)
_NCORE=$(find . -mindepth 3 -maxdepth 4 -name INCAR -exec \
          sed -n 's/^[[:space:]]*NCORE[[:space:]]*=[[:space:]]*\([0-9][0-9]*\).*/\1/p' {} + 2>/dev/null \
        | sort -n | tail -1)
if [ -z "$_KPAR" ]; then
  # 🔴 렌즈 K2 P2-1 — "구판이라 없음" 과 "find 가 헛돌았음"(잘못된 cwd 등)을 구분해야 한다.
  #   이 생성기는 전 INCAR 에 KPAR 을 쓰므로, 못 읽었으면 **말한다** (조용한 건너뜀 금지).
  echo "  ⚠ INCAR 에서 KPAR 을 읽지 못했습니다 — 랭크 배치 검사를 건너뜁니다."
  echo "     묶음 루트에서 실행 중인지 확인해 주십시오 (구판 묶음이면 정상입니다)."
else
  _NCORE=${_NCORE:-1}
  _NEED=$(( 10#$_KPAR * 10#$_NCORE ))
  if [ "$_NEED" -gt 1 ] 2>/dev/null; then
    if [ $(( 10#${VASP_NPROC:-1} % _NEED )) -ne 0 ]; then
      echo "⛔ VASP_NPROC=${VASP_NPROC:-1} 이 이 묶음의 랭크 배치와 맞지 않습니다."
      echo "   INCAR 이 KPAR=$_KPAR · NCORE=$_NCORE 로 고정돼 있어 랭크 수는 **$_NEED 의 배수**여야 합니다"
      echo "   (k-그룹당 랭크 = NPROC/KPAR 이 다시 NCORE 로 나눠져야 합니다)."
      echo "   INCAR 은 해시로 동결돼 있어 고칠 수 없습니다 — 고치면 그 잡이 거부됩니다."
      echo "   쓸 수 있는 랭크 수: $_NEED · $(( _NEED * 2 )) · 48 · 64 · 96 · 128 · 256"
      echo "   (스모크 테스트만 하실 거면 $_NEED 랭크로도 돕니다.)"
      echo "   ⚠ KPAR 은 k-그룹마다 배열 사본을 들어 **노드당 메모리가 늘어납니다**."
      echo "     메모리가 모자라도 **랭크를 줄이지 마시고**(배수 조건이 깨집니다) 노드를 늘려 주십시오."
      exit 2
    fi
    echo "  ✔ 랭크 ${VASP_NPROC:-1} = KPAR $_KPAR × NCORE $_NCORE × $(( 10#${VASP_NPROC:-1} / _NEED ))"
  fi
fi
export VASP_EXE VASP_LAUNCHER_KIND VASP_NPROC LAUNCHER_BIN VASP_WRAPPER
PP=${PP:?PP 를 지정하세요 (POTCAR 원본 트리)}
POTCAR_ALLOWLIST=${POTCAR_ALLOWLIST:?POTCAR_ALLOWLIST 를 지정하세요 (절대경로)}

# ⛔⛔ 회신 AR P0-8 · 해제조건 8 — **경쟁조건 없는 host/run-id 잠금**.
#   종전 구현: `mkdir $LOCK` 뒤에 pid 를 썼다. 그 사이(디렉터리는 있고 pid 는
#   아직 없는 창)에 다른 프로세스가 이를 stale 로 보고 `rm -rf` 했다.
#   게다가 다른 HPC 노드의 pid 에는 `kill -0` 이 유효한 생존검사가 아니다.
#   ⇒ ① 내용을 **먼저** 쓴 임시 파일을 `ln` 으로 원자적으로 링크한다
#       (하드링크 생성은 대상이 있으면 실패한다 — 내용이 없는 창이 존재하지 않는다)
#     ② **모르는 lock 은 절대 지우지 않는다.** 같은 호스트의 죽은 pid 일 때만
#       안내하고, 그래도 자동 삭제하지 않는다 (사람이 지운다).
# ⛔⛔ 회신 AS 해제조건 6 (2026-08-31) — lock 을 **단계별이 아니라 번들 전역**으로
#   바꾼다. 종전엔 `.lock_bundle` 과 `.lock_stage2` 가 따로라 1단계와 2단계를
#   동시에 던지면 둘 다 lock 을 잡았다. 같은 번들 디렉터리에서 동시에 도는 것은
#   단계가 달라도 안 된다 — POTCAR·봉인·산출물을 공유하기 때문이다.
LOCK=".lock_bundle"
RUNID="$(hostname)|$$|stage$stage|$(date -u +%Y-%m-%dT%H:%M:%SZ)"
LOCKTMP="$LOCK.tmp.$$"
printf '%s\n' "$RUNID" > "$LOCKTMP" || exit 3
if ! ln "$LOCKTMP" "$LOCK" 2>/dev/null; then
  rm -f "$LOCKTMP"
  own=$(cat "$LOCK" 2>/dev/null || echo "?")
  own_host=${own%%|*}
  rest=${own#*|}; own_pid=${rest%%|*}
  echo "⛔ 단계 $stage 의 lock 이 이미 있습니다: $own"
  if [ "$own_host" = "$(hostname)" ] && ! kill -0 "$own_pid" 2>/dev/null; then
    echo "   같은 호스트의 pid $own_pid 는 살아 있지 않습니다."
    echo "   그래도 **자동으로 지우지 않습니다** — 다른 노드의 실행일 수 있습니다."
    echo "   확실하면 손으로: rm -f $LOCK"
  else
    echo "   다른 호스트/살아 있는 프로세스입니다. 끝날 때까지 기다리세요."
  fi
  exit 3
fi
rm -f "$LOCKTMP"
# 우리 것일 때만 지운다 (남의 lock 을 치우지 않는다)
_unlock() { [ "$(cat "$LOCK" 2>/dev/null)" = "$RUNID" ] && rm -f "$LOCK"; return 0; }
# 🔴🔴 회신 AT P0-5 — 종전 trap 은 INT/TERM 에서 **lock 만 지우고 러너는 계속
#   돌았다.** bash 는 핸들러를 돌린 뒤 하던 일을 이어간다. 그 사이 lock 이 비므로
#   다른 실행이 같은 번들에 들어올 수 있었다 — 잠금이 있으나 마나였다.
#   ⇒ 신호를 받으면 **자식을 죽이고 정말로 나간다.**
_bail() {
  echo ""
  echo "⛔ 신호를 받았습니다 ($1) — 자식 프로세스를 정리하고 중단합니다."
  trap - EXIT INT TERM
  # ⛔ 회신 BA P1 — **unlock 을 먼저** 한다. 종전엔 `kill -TERM 0` 이 앞서서
  #   호출자 process group 까지 종료시키고 lock 을 남길 수 있었다 (stale lock).
  _unlock
  kill -TERM 0 2>/dev/null || true      # 이 프로세스 그룹 전체
  exit "$2"
}
trap '_unlock' EXIT
trap '_bail INT 130' INT
trap '_bail TERM 143' TERM
# 🔴 회신 AV P0-2 — run_job.sh 는 이 토큰 없이는 거부한다 (직접 호출 차단).
#   토큰 = lock 파일 내용. lock 을 쥔 실행만이 값을 알고, 값이 곧 소유 증명이다.
export RUNNER_TOKEN="$RUNID"

# ⛔⛔ 회신 AR P0-7 · 해제조건 8 — **실행 전 census.** 종전엔 존재하는 job.json
#   만 분류하고 디렉터리 수만 비교해서, job.json 하나를 지워도 통과했다.
#   ⇒ ① MANIFEST 해시(봉인/EXPECT 와 결박) ② 계획 잡 **집합** 완전일치
#     ③ 단계 분류가 manifest 선언과 **정확히** 같은지 — 셋 다 확인한다.
python3 census.py "$stage" || { echo "⛔ 실행 전 census 실패 — 중단"; exit 2; }

# ⛔⛔ 회신 BA P0-1 (2026-09-02) — **SEAL 을 preflight 뒤로 옮긴다.**
#   종전엔 러너가 SEAL 을 **먼저** 불렀고, SEAL 은 16개 `POTCAR_ASSEMBLE.sh` 를
#   실행한다. `EXPECT_*`·`files_sha256` 검사는 그 **뒤**였다. 즉 변조된 assembler 가
#   무결성 검사 **전에** 실행됐다 — 리뷰어가 흔적을 만든 뒤 자기 바이트를 원본으로
#   복구하는 재현으로 잡았다.
#   ⇒ 추출 파일 전수검사(census + files_sha256 + EXPECT)를 **먼저** 끝내고,
#     그것이 통과한 뒤에만 배포 스크립트를 실행한다.
#   ⚠ ZIP SHA 자체는 ZIP 밖에서 대조해야 한다 — README 의 첫 단계가 그것이다.

# ⛔ 회신 AT P0-6 — SEAL 은 러너가 **이미 lock 을 쥔 채** 부른다. 중복 획득으로
#   교착하지 않도록 알려 준다 (단독 실행이면 SEAL 이 스스로 잡는다).
# ⛔ 회신 BD P0-4 · GO 해제조건 5 — 거버넌스를 **SEAL 보다 먼저** 본다.
#   비준이 안 섰으면 조립·봉인도 하지 않는다 (그것도 되돌리기 어려운 상태다).
# 🔴🔴 회신 BE P0-3 (2026-09-03) — 루트 마커 **파일만으로** 거버넌스를 건너뛰었다.
#   production 번들에 `.SELFTEST_FIXTURE` 하나 두면 비준 실패 fixture 가 SEAL 직전까지
#   갔다 (리뷰어 재현). run_job.sh 와 같은 규칙으로 맞춘다: **MANIFEST 가 스스로
#   selftest_fixture=true 를 선언한 번들에서만, 그리고 마커도 있을 때만** 픽스처다.
#   production MANIFEST 에 그 필드를 심으면 해시가 바뀌어 EXPECT·봉인 대조가 깨지고,
#   선언 없는 마커는 census 가 거부한다.
_GFIX=0
if [ -f .SELFTEST_FIXTURE ] && python3 -c 'import json,sys;sys.exit(0 if json.load(open("MANIFEST.json")).get("selftest_fixture") is True else 1)' 2>/dev/null; then
  _GFIX=1
fi
if [ "$_GFIX" = 1 ]; then
  echo "  ⚠ selftest 픽스처(MANIFEST 선언 + 마커) — 거버넌스 사전검사를 건너뜁니다"
  echo "     (**실물 번들에는 선언도 마커도 없습니다**. 하나만 있으면 fail-closed 입니다)."
else
  python3 analyze_results.py . --check_governance \
    || { echo "거버넌스 검사 실패 — 중단 (회신 BD P0-4: 비용 발생 전에 닫는다)"; exit 2; }
fi
BUNDLE_LOCK_HELD=1 bash SEAL_POTCAR_ROOT.sh || { echo "POTCAR 조립·봉인 실패 — 중단"; exit 1; }

# ⛔ 회신 BA P0-1 — SEAL 이 만든 봉인을 **여기서** 검사한다 (앞 census 는 파일
#   무결성만 봤다). 같은 코드를 두 번 돌리므로 검사 로직이 갈라지지 않는다.
RECHECK_SEAL=1 python3 census.py "$stage" || { echo "⛔ 봉인 census 실패 — 중단"; exit 2; }

# ⛔⛔ 회신 AZ P0-7 (2026-09-01) — **attestation 을 생산 전에 강제**한다.
#   봉인은 "이 계산들이 하나의 트리에서 나왔고 그 트리가 생산 전에 고정됐다" 까지만
#   보증한다. **그 트리가 승인된 PAW dataset 인지**는 보증하지 않는다. VASP 는 여러
#   PAW 세트와 suffix variant 를 배포하므로 dataset 신원은 계산 조건의 일부다.
#   ⇒ 사후 provenance 만으로는 원고 인용 자격이 안 선다 (회신 AZ Q4).
#   이 게이트는 MANIFEST 의 `potcar_identity_policy` 가 정한다:
#     require_attestation  → attestation 이 없으면 **한 잡도 안 돈다** (원고용)
#     post_hoc             → 경고만 하고 진행 (탐색용 — 원고 인용 불가)
_AP=$(python3 -c 'import json;print((json.load(open("MANIFEST.json")).get("potcar_identity_policy") or {}).get("mode") or "post_hoc")' 2>/dev/null || echo post_hoc)
if [ "$_AP" = "require_attestation" ]; then
  if [ ! -s POTCAR_ATTESTATION.json ]; then
    echo "⛔ POTCAR_ATTESTATION.json 이 없습니다 — 이 묶음은 **원고용 정책**"
    echo "   (potcar_identity_policy.mode=require_attestation)이라 attestation 없이는"
    echo "   한 잡도 돌리지 않습니다 (회신 AZ P0-7)."
    echo "   첫 VASP 실행 **전에** 만드십시오:  bash MAKE_POTCAR_ATTESTATION.sh"
    exit 2
  fi
  # ⛔⛔ 회신 BB P0-6 (2026-09-02) — **검사 사본을 두지 않는다.**
  #   종전엔 여기에 짧은 파이썬 사본이 있어 `made_before_production` 과 SHA map
  #   두 가지만 봤다. schema·ZIP·manifest·allowlist·VASP·시각은 **분석 단계에
  #   가서야** 봤으므로, 잘못된 증서로 16잡(약 300 h)을 다 돌린 뒤 거부될 수
  #   있었다. 그리고 사본은 언젠가 정본과 갈린다 (BA 해제조건 8 이 그 사고였다:
  #   사본이 `sealed_before_production`/`source_sha256` 이라는 **없는 키**를
  #   요구해 정상 증서를 거부했다).
  #   ⇒ 정본 하나(`potcar_identity_gates`)를 부른다. 그 파일 SHA 는 MANIFEST 에 있다.
  python3 analyze_results.py . --check_attestation || exit 2
else
  echo "  ⚠ POTCAR 신원 정책 = post_hoc — attestation 없이 진행합니다."
  echo "     이 묶음의 결과는 **탐색용**이고 원고 인용 자격이 서지 않습니다"
  echo "     (승인된 PAW dataset 인지 확인 못 함 · 회신 AZ P0-7·Q4)."
  # 🔴🔴 렌즈4 P0-1 (2026-09-03) — post_hoc 이라도 **선택 증서가 있으면 지금 검증한다.**
  #   종전엔 이 분기에서 증서를 보지 않아, 결함 있는 증서(예: 버전 문자열 형식 불일치)가
  #   1단계를 다 돌린 **뒤에야** 최종 분석의 potcar_identity 에서 처음 막혔다. "선택" 은 없어도 된다는
  #   뜻이지 틀린 것이 있어도 된다는 뜻이 아니다. 결함이면 여기서 멈춘다 (지우면 돌아간다).
  if [ -s POTCAR_ATTESTATION.json ]; then
    echo "  ⚠ 선택 attestation 이 있습니다 — 생산 전에 봉인·MANIFEST·ZIP 과 대조합니다."
    python3 analyze_results.py . --check_attestation \
      || { echo "⛔ 선택 attestation 에 결함 — 지우고 돌리거나 다시 만드십시오 (렌즈4 P0-1)"; exit 2; }
  fi
fi

# ⛔ 회신 AP #6 — receipt 존재만으로 2단계를 열지 않는다. **지금 결과로 재판정**한다.
#    (해시 결박보다 단순하고, 위조 receipt 로 우회할 수 없다)
if [ "$stage" = 2 ]; then
  echo "== 2단계 시작 전 1단계 재판정 =="
  python3 analyze_results.py . --gate vacconv || {
    echo "1단계 게이트가 지금 결과로 통과하지 않는다 — 2단계를 열지 않는다."; exit 2; }
fi

# 잡 분류는 job.json 의 **구조화 필드**로 한다 — 이름 파싱 금지
python3 -c '
import json, sys, glob, os
want = sys.argv[1]
for jp in sorted(glob.glob("*/*/job.json")):
    m = json.load(open(jp)); d = os.path.dirname(jp)
    kind, role, vac = m.get("kind"), m.get("role"), m.get("vacconv")
    if kind is None:
        sys.exit("job.json 에 kind 가 없다: " + jp)
    if kind == "mol_ref":
        s = "1"
    elif kind == "clean_ref":
        # 2026-09-04 — clean slab 은 기준계다. E_S 가 1단계에 있어야 절대 E_ads 를
        # 1단계 게이트에서 확인할 수 있다. 부 seed 는 민감도라 2단계.
        s = "1" if (vac or m.get("seed") == "afm2424_pm1") else "2"
    elif kind == "prospective_pose" and role == "primary":
        s = "1" if (vac or m.get("seed") == "afm2424_pm1") else "2"
    else:
        s = "2"
    if s == want:
        print(d)
' "$stage" > _stage_jobs.txt || { echo "잡 분류 실패 — 중단"; exit 2; }

# ⛔ 회신 AP #9 — 분류가 조용히 0개/일부만 내고 성공하는 것을 막는다.
n_stage=$(grep -c . _stage_jobs.txt || true)
n_total=$(ls -d */*/ 2>/dev/null | wc -l)
n_expect=$(python3 -c '
import json,sys
m=json.load(open("MANIFEST.json"))
print(sum(1 for k,v in (m.get("planned") or {}).items()))' 2>/dev/null || echo 0)
echo "== 단계 $stage · $n_stage 잡 (묶음 전체 $n_total · 계획 $n_expect) =="
if [ "$n_stage" -eq 0 ]; then
  echo "이 단계의 잡이 0개다 — 분류 규칙과 job.json 을 확인하세요. 중단."; exit 2; fi
if [ "$n_total" != "$n_expect" ]; then
  echo "잡 폴더 $n_total ≠ 계획 $n_expect — 묶음이 온전하지 않다. 중단."; exit 2; fi
cat _stage_jobs.txt

# ⛔⛔ 회신 AS 해제조건 5 — **실행 직전에** 봉인한 절대경로를 다시 해시한다.
#   봉인 시점과 실행 시점 사이에 바이너리가 바뀌었을 수 있다.
python3 - "$VASP_EXE" "$VASP_LAUNCHER_KIND" "$VASP_WRAPPER" <<'PYEXE' || { echo "⛔ 실행파일이 봉인과 다릅니다 — 중단"; exit 2; }
import hashlib, json, os, sys
exe, kind, wrap = sys.argv[1], sys.argv[2], sys.argv[3]
h = hashlib.sha256(open(exe, "rb").read()).hexdigest()
try:
    seal = json.load(open("POTCAR_ROOT_SEAL.json", encoding="utf-8"))
except Exception as e:
    sys.exit("⛔ 봉인을 읽을 수 없다: %r" % e)
bad = []
if seal.get("vasp_executable") and os.path.realpath(seal["vasp_executable"]) != os.path.realpath(exe):
    bad.append("봉인 경로 %s ≠ 실행 경로 %s" % (seal["vasp_executable"], exe))
if seal.get("vasp_executable_sha256") != h:
    bad.append("봉인 해시 %s ≠ 지금 %s" % (str(seal.get("vasp_executable_sha256"))[:12], h[:12]))
# 🔴 회신 AV P0-2/Q5 — wrapper 도 봉인과 같은 파일이어야 한다. 봉인에 wrapper 가
#   없는데 KIND=wrapper 로 돌리는 것도 거부한다 (봉인 밖 실행 경로).
if kind == "wrapper":
    if not wrap:
        bad.append("KIND=wrapper 인데 VASP_WRAPPER 가 비었다")
    elif not seal.get("launcher_wrapper_sha256"):
        bad.append("봉인에 launcher_wrapper_sha256 가 없다 — wrapper 는 SEAL 때 "
                   "봉인된 것만 쓸 수 있다 (VASP_WRAPPER 를 주고 다시 봉인)")
    else:
        wh = hashlib.sha256(open(wrap, "rb").read()).hexdigest()
        if wh != seal["launcher_wrapper_sha256"]:
            bad.append("wrapper 해시 %s ≠ 봉인 %s"
                       % (wh[:12], seal["launcher_wrapper_sha256"][:12]))
if bad:
    print("⛔ 실행 직전 대조 실패:")
    for b in bad:
        print("   · " + b)
    sys.exit(1)
print("✓ 실행파일 = 봉인한 그 파일 (%s · %s)" % (exe, h[:12]))
PYEXE

# ⛔⛔ 회신 AS 해제조건 10 (2026-08-31) — 러너는 **직렬**인데 MANIFEST 는
#   `max_concurrency: 8` 이라고 적고 있었다. 비용 추정이 그 병렬도 가정 위에
#   서 있으므로 둘이 어긋나면 외주가 일정을 잘못 잡는다.
#   ⇒ 러너가 실제로 병렬로 돈다. 단 **의존성이 있는 잡은 나중 물결**로 민다:
#     canary(`*__nzmag`)는 `PARENT_GEOM` 이 가리키는 부모의 최종 기하를 받으므로
#     부모가 먼저 끝나야 한다.
#   `JOBS_PARALLEL` 로 조절한다 (기본 = MANIFEST 의 max_concurrency).
NPAR=${JOBS_PARALLEL:-$(python3 -c '
import json
print((json.load(open("MANIFEST.json")).get("submission") or {}).get("max_concurrency") or 1)'
)}
case "$NPAR" in ''|*[!0-9]*) NPAR=1 ;; esac
[ "$NPAR" -ge 1 ] || NPAR=1

: > _wave1.txt; : > _wave2.txt
while read -r j; do
  [ -n "$j" ] || continue
  if [ -f "$j/PARENT_GEOM" ]; then echo "$j" >> _wave2.txt; else echo "$j" >> _wave1.txt; fi
done < _stage_jobs.txt
n1=$(grep -c . _wave1.txt || true); n2=$(grep -c . _wave2.txt || true)
echo "== 병렬도 $NPAR · 1물결 $n1 잡 · 2물결(부모 의존) $n2 잡 =="

run_wave() {   # $1 = 목록 파일
  [ -s "$1" ] || return 0
  xargs -a "$1" -I{} -P "$NPAR" sh -c '
    j="$1"
    [ -f "$j/run_job.sh" ] || { echo "없음: $j"; exit 1; }
    # 🔴 회신 AT P0-5 · AV P0-2 — receipt 는 **헤더행(러너) + 상별 행(run_job.sh)**.
    #   종전엔 러너가 잡당 한 행만 썼고 분석기가 읽지 않았다. 이제 run_job.sh 가
    #   상 직전마다 해시를 재서 append 하고, 분석기가 **필수 반송물**로 읽는다.
    #   열 9개: ts phase exe_sha256 exe kind nproc launcher launcher_sha potcar_sha
    #   (AY P0-1 · BE P1 — 헤더행의 potcar_sha 는 "-", 상별 행은 run_job.sh 가 채운다)
    case "$VASP_LAUNCHER_KIND" in
      mpirun|mpiexec|srun) _hl="$LAUNCHER_BIN" ;;
      wrapper)             _hl="$VASP_WRAPPER" ;;
      *)                   _hl="" ;;
    esac
    if [ -n "$_hl" ]; then _hlh=$(sha256sum "$_hl" | cut -d" " -f1); else _hl="-"; _hlh="-"; fi
    # ⛔⛔ 회신 AZ P1 (2026-09-01) — **재개가 영수증을 파괴했다.**
    #   종전엔 언제나 `> receipt` 로 **덮어썼다**. `ALLOW_RESUME=1` 이면 새 헤더만
    #   남고 run_job.sh 는 완료된 상을 건너뛰므로, 이미 돈 상의 행이 통째로 사라져
    #   분석기가 `RECEIPT_PHASE_MISSING` 을 냈다 — 정직하게 이어 돌린 사람이
    #   "러너 밖에서 돌렸다" 는 판정을 받았다.
    #   ⇒ 재개는 **이어 쓰고** 표지를 `_runner_resume` 으로 구분한다.
    #     `_runner_start` 는 여전히 정확히 하나다 (첫 실행에만 찍힌다).
    # ⛔⛔ 회신 BA 해제조건 7 (2026-09-02) — **재개를 폐지한다.**
    #   AZ P1 에서 재개를 “이어 쓰기” 로 고쳤는데, 그 계약이 실제로는 **항상 막혔다**:
    #   `_runner_resume` 자체가 `RECEIPT_RESUMED` 게이트가 되고, 중단된 상을 다시
    #   돌리면 같은 phase 행이 둘이라 `RECEIPT_PHASE_DUPLICATE` 도 난다.
    #   제대로 지원하려면 attempt ID·성공상태·supersedes 가 필요한데, 이 묶음의
    #   질문에 비해 과하다. ⇒ **한 번에 완주하거나, 새 번들로 다시 시작한다.**
    if [ "${ALLOW_RESUME:-0}" = "1" ]; then
      echo "⛔ ALLOW_RESUME 은 폐지됐습니다 (회신 BA 해제조건 7)."
      echo "   종전 재개 계약은 영수증 게이트(RECEIPT_RESUMED · PHASE_DUPLICATE)에"
      echo "   **언제나 걸려** 통과할 수 없었습니다 — 있으나 마나가 아니라 함정이었습니다."
      echo "   중단된 실행은 폴더를 새로 풀고 처음부터 돌려 주십시오."
      exit 2
    fi
    # ⛔⛔ 회신 BD P1 (2026-09-02) — **receipt 를 먼저 자르고 나서 거부했다.**
    #   Stage 1 을 실수로 다시 부르면 run_job.sh 가 "이미 산출물이 있다" 로 거부하는데,
    #   그 **전에** 러너가 정상 receipt 를 헤더 한 줄로 덮어써 증거를 망가뜨렸다.
    #   ⇒ 기존 산출물 검사를 **쓰기보다 앞에** 둔다. 거부하면 아무것도 손대지 않는다.
    if [ "${PLANNED_CONTINUATION:-0}" != "1" ]; then
      _stale_pre=""
      for _ph in pre relax static dense; do
        [ -d "$j/$_ph" ] || continue
        for _f in OUTCAR vasprun.xml OSZICAR CONTCAR WAVECAR CHGCAR; do
          [ -e "$j/$_ph/$_f" ] && _stale_pre="$_stale_pre $_ph/$_f"
        done
      done
      if [ -n "$_stale_pre" ]; then
        echo "⛔ $j 에 이미 산출물이 있습니다:$_stale_pre"
        echo "   이 잡은 **1회용**입니다 — 폴더를 새로 풀고 처음부터 돌려 주십시오."
        echo "   ⚠ receipt 는 **손대지 않았습니다** (회신 BD P1: 종전엔 먼저 덮어쓴 뒤"
        echo "      거부해 증거가 망가졌습니다)."
        exit 1
      fi
    fi
    # 계획된 이어달리기(dense 승격)는 **새 상**을 여는 것이라 성격이 다르다.
    if [ "${PLANNED_CONTINUATION:-0}" = "1" ] && [ -s "$j/EXECUTABLE_RECEIPT.tsv" ]; then
      _rtag=_runner_continue; _rop=append
    else
      _rtag=_runner_start;  _rop=truncate
    fi
    if [ "$_rop" = append ]; then
      printf "%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\n" \
        "$(date -u +%Y-%m-%dT%H:%M:%SZ)" "$_rtag" \
        "$(sha256sum "$VASP_EXE" | cut -d" " -f1)" \
        "$VASP_EXE" "$VASP_LAUNCHER_KIND" "$VASP_NPROC" \
        "$_hl" "$_hlh" "-" >> "$j/EXECUTABLE_RECEIPT.tsv"
    else
      printf "%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\n" \
        "$(date -u +%Y-%m-%dT%H:%M:%SZ)" "$_rtag" \
        "$(sha256sum "$VASP_EXE" | cut -d" " -f1)" \
        "$VASP_EXE" "$VASP_LAUNCHER_KIND" "$VASP_NPROC" \
        "$_hl" "$_hlh" "-" > "$j/EXECUTABLE_RECEIPT.tsv"
    fi
    echo "=== $j 시작 ==="
    ( cd "$j" && bash run_job.sh ) || { echo "⛔ $j 실패"; exit 1; }
    echo "=== $j 완료 ==="
  ' _ {}
}
fail=0
run_wave _wave1.txt || fail=1
if [ "$fail" = 0 ]; then
  run_wave _wave2.txt || fail=1
else
  echo "⛔ 1물결에 실패가 있어 2물결(부모 의존 잡)을 시작하지 않습니다"
fi

if [ "$stage" = 1 ]; then
  [ "$fail" = 0 ] || { echo "1단계에 실패한 잡이 있다 — 판정하지 않는다."; exit 2; }
  echo "== 1단계 판정 =="
  python3 analyze_results.py . --gate vacconv || {
    echo "1단계 판정이 막혔다 — 2단계를 돌리지 않는다."; exit 2; }
  echo "1단계 통과 — 2단계는 'bash run_staged.sh 2'"
else
  # ⛔ 회신 AP #9 — 2단계 뒤 **최종 분석**까지가 러너의 일이다.
  # 🔴 회신 BF P1 (2026-09-03) — 2단계에 실패한 잡이 있으면 **분석하지 않는다.** 종전엔 fail=1
  #   이어도 그대로 분석해 rc 3 을 "계산은 완주했으나…" 로 출력할 수 있었다. 완주가 아니다.
  [ "$fail" = 0 ] || { echo "⛔ 2단계에 실패한 잡이 있다 — 완주가 아니므로 판정하지 않는다 (rc 2)."; exit 2; }
  # 완주 census — 이 단계의 모든 잡이 반송 receipt(_runner_start) 를 남겼는가
  _miss_rc=0
  while read -r j; do
    [ -n "$j" ] || continue
    grep -q "_runner_start" "$j/EXECUTABLE_RECEIPT.tsv" 2>/dev/null || { echo "⛔ $j: 실행 receipt 가 없다 — 이 잡은 러너로 완주하지 않았다"; _miss_rc=1; }
  done < _stage_jobs.txt
  [ "$_miss_rc" = 0 ] || { echo "⛔ 완주하지 않은 잡이 있다 — 판정하지 않는다 (rc 2)."; exit 2; }
  echo "== 최종 판정 (2단계 전 잡 완주 확인됨) =="
  # 🔴 회신 BE P1 — 분석기 rc 3 (완주했으나 원고 인용 불가·탐색용) 을 계산 실패 2 와 가른다.
  python3 analyze_results.py .; _frc=$?
  case "$_frc" in
    0) ;;
    3) echo "⚠ 계산은 완주했으나 **원고 인용 자격 없음** (탐색용 · manuscript_citable=false)"
       echo "   — 종료코드 3 (rc 2 = 판정 실패와 구분 · 회신 BE P1). RESULTS.json 은 그대로 보내십시오."
       exit 3 ;;
    *) echo "최종 판정 미통과 (rc=$_frc)"; exit 2 ;;
  esac
fi
exit $fail

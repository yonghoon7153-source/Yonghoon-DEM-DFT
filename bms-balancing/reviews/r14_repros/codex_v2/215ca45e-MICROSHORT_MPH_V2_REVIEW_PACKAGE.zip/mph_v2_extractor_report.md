# Independent extractor and current-MPH structural review

Target: `d72e735fed52a06b4a4e739fdbd2c71fa9e8a3b6`, `bms-balancing`.
Read the actual nested MPH from the user-supplied archive entirely in memory; did not run COMSOL or modify the model, archive, or target checkout.

MPH SHA-256: `8b2e71506ba2a5ebad1ce27e268417b0e74b28cbaa9a81d1a6c32c58573557a9`.
Current `dmodel.xml` SHA-256: `6aa8ebdad37da698dfd8c1cbe65451292dbdfd5f7ece60a9a33cabe8e3b0cfa6` (2,622,953 bytes).
All XML line numbers below refer to that current `dmodel.xml`.

## Closure assessment

| Item | Independent result |
|---|---|
| R-5: original parent/child ownership defects | **Closed for the submitted model and original regression.** `--self-test` passes. All 43 interface/feature rows match independent direct-child parameter ownership, with zero disagreements. Regenerated output matches stored `mph_dump_output.txt` after newline normalization and outer-whitespace stripping; this is not a byte-identity check. |
| R-6: current Events/interface flags | **Closed as a current model-tree fact.** `ev` has its own `DISABLED`; its four features inherit that flag. This is not, by itself, an evaluation of study overrides or a saved solution. |
| R-9: seven zero-reference entries in the current M4 table | **Closed for current explicit definitions.** An independent broader identifier inventory, including text, qualified names, and identity RHS expressions, finds each name only in its declaration name field. |
| R-9: reusable “live consumer graph” implementation | **Not established.** The function can miss real dependency references and counts stored attribute fields rather than resolved active consumers. These limitations do not reverse the seven verified current-file zeros. |

## Current model evidence

- `/Model/PhysicsList/Physics[@tag='ev']/entityFlags`, line **3420**: `DISABLED`. Children `ds1`, `is1`, `impl1`, `impl2` have no own disabled flag. Interface-level inheritance is now handled correctly.
- `/Model/ModelParam/expressions[@name='CurrentDirection']`, line **338**: `expr='1'`. The disabled `ev/ds1` retains the declaration `CurrentDirection` and initialization `-1` at lines **3471–3472**; `ev/impl1` retains the reinitialization target at **3561**. The discrete-state definition is stored, so “does not exist” is less precise than “is disabled in the current physics tree.”
- `/Model/StudyList/Study[@tag='std1']/StudyFeatureList/StudyFeature[@tag='time']/propertyValue[@name='p:activate']`, line **9445**, separately contains `ev,on` and `ge2,on`. The dump does not interpret this study configuration. Do not infer an override precedence or runtime name resolution from these fields alone. The separate solver/snapshot review supplies that context.
- The seven names occur only as declarations under `/Model/ModelParam/expressions`: `dPE` **347**, `dNE` **348**, `cs_NCM_init` **332**, `cs_Gr_init` **329**, `E_end` **310**, `x_NCM_max` **335**, `x_NCM_min` **336**. The broader scan found no qualified, alias, or text reference omitted by the submitted function for these names.
- `i_app` appears in `/Model/PhysicsList/Physics[@tag='liion']/PhysicsFeatureList/PhysicsFeature[@tag='ecd1']/param[@param='nis']`, **2857**, and `/Model/PhysicsList/Physics[@tag='ge2']/PhysicsFeatureList/PhysicsFeature/param[@param='equation']`, **3849**. The latter single attribute encodes **two equations**, each with `i_app`. Therefore the printed **2** means two matching attribute fields, including disabled `ecd1`, not two active equation consumers. Its own declaration is `/Model/ExprList/Expr[2]/expressions[1]`, **5101**.

## Remaining extractor defects

1. **P2 — identity RHS references are incorrectly dropped**, `reviews/r14_repros/mph_dump.py:94–95`. For ordinary input `<expressions name="alias" expr="dPE"/>`, querying `dPE` returns zero. This is a real dependency of `alias`, not the declaration name field; that field was already removed in `live_expressions`. Remove this RHS suppression and retain the defined name for source/target attribution.
2. **P2 — qualified references are silently omitted**, `mph_dump.py:89`. A stored expression `comp1.dPE+1` returns zero when querying the local identifier `dPE`, because the negative lookbehind prohibits a preceding dot. Resolve fully qualified identifiers to their declared scope, or report such matches as unresolved. A bare-name zero cannot be a general proof of no dependency.
3. **Scope/metric limitation**, `mph_dump.py:70–97`: every non-history attribute except four metadata keys is treated as an expression. Disabled nodes, declaration fields such as `param='dPE'`, and source-selected but unused saved values remain in scope. Conversely, vector expressions are not split into equation consumers. Name this an inventory of stored expression fields until activation, source selectors, and scopes are resolved.

The supplied ownership self-test does not cover these dependency cases. Ordinary synthetic regression fixtures and their observed outputs are stored in the JSON evidence. Supplemental fixtures also demonstrate that `walk_features` itself does not exclude an `<actions>` subtree and that its one-level parameter fallback is broader than strict ownership; neither condition causes an ownership mismatch in this actual model.

## Saved value versus selected value

Both current particle nodes have `cEeqref_mat='from_mat'`, alongside saved user values containing `dm`: `pce1/pin1` **1369–1370**, `pce2/pin1` **2511–2512**. The extractor correctly prints both. A report must not treat the saved user value as operative without resolving its selector. This is a scientific interpretation problem beyond the corrected XML ownership; root/solver review handles its implications for M1 and saved solutions.

## Reproduction

From the workspace, run the bundled Python against:

```powershell
& 'C:/Users/Administrator/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe' 'work/microshort-v2-d72e735f/bms-balancing/reviews/r14_repros/mph_dump.py' --self-test
& 'C:/Users/Administrator/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe' 'outputs/mph_v2_extractor_check.py'
```

The second command writes `outputs/mph_v2_extractor_evidence.json`, including exact XPath/source-line records, strict ownership comparisons, regenerated-output equality, the independent identifier inventory, and reproducible synthetic fixtures. It never extracts or edits the original model.

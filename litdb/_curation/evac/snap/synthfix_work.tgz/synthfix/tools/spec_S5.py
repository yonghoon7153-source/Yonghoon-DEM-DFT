# V_S5.md 문제 1–18 → S5_why_plasticity_is_hard.md
V = 'V_S5'
D = 'S5'
PYC = 'pycompact2025_dem_mpfem_workflow'
BARD05 = 'Bardenhagen · Brydon · Guilkey 2005 · J. Mech. Phys. Solids 53, 597–617'
B41_TAIL = '[b41 · bardenhagen2005_mpm_foam_densification_simulation · 카드 §0 (1) · 논문 §1 p.599]'

S3 = '"Large strains result in numerical inaccuracies as Lagrangian meshes become too distorted or Eulerian meshes require extensive material advection."'
L363_OLD = ('"Even at moderate bulk deformations, e.g. within the stress plateau, localized bending at the microscale results in large deformations and rotations of the individual structural components (struts, membranes).  '
            'Hence finite deformation continuum mechanics formulations must be implemented, including appropriate kinematics and constitutive models.  '
            'Large strains result in numerical inaccuracies as Lagrangian meshes become too distorted or Eulerian meshes require extensive material advection."')

L400_END = ('| 논문 SI (쪽 없음) | 밖 (가) 모델 범위 | [b36 · zhang2023_pfib_multiscale_imaging_4d_thick_cathode · §3-7 (줄 143) · §4-4 (줄 246) · §4-6 (줄 271) · §7 (줄 344 · 351)] |\n')
L599_ROW = ('| L-599 | ' + BARD05 + ' | 배치 41 줄이 옮긴 앞 두 문장 (\'Even at moderate bulk deformations …\' · \'Hence finite deformation continuum mechanics …\') — '
            '정본 카드에 없음 · 원문 확인 필요 (검증 뒤 L-363 에서 갈라 옮긴 행 · 번호는 끝 번호 다음) → L-363 · L-423 | 논문 §1 p.599 (배치 41 줄의 표기) | '
            '형7 격자 뒤틀림 · 형1 (큰 변형 · 회전) · 발포체 뼈대 | ' + B41_TAIL + ' |\n')

COST_NEW = ('Table 1 (Fine · CPU 수 미인쇄): 569 / 874 / 1033 입자 = 9 / 16 / 24 h · Coarse 메시 시험: 2000 요소/입자 9 h · 2500 요소/입자 36 h · '
            'Table 3 (Coarse · 2000 MPa · 24 CPU): PyCompact 7 h ↔ ABAQUS 5 h (보탬 b42 의 고친 귀속)')
MESH_NEW = '메시 수렴 판정이 그림 (−1.4 %) ↔ 본문 숫자 (−6.3 %) 로 갈림 (카드 §9.1 · 옛 \'미수렴\' 판정 철회) · 시드 1'

G1 = '"The main challenges in modeling this process using the MPM is to simulate stress dependent diffusion coupled with concentration dependent stress within a material that undergoes large deformations.'
G2 = 'MPM is chosen as the numerical method of choice because of its ability to handle large deformations."'

L193_ONE = '눈 (압축성 소성 · ν 0.2) — 부피 보존 유동 아님 · 소성이 왜 어려운지를 DEM 과 견줘 말한 문장은 카드에 없음'


def lab(n, rx, cell_end, label):
    return dict(doc=D, v=V, num=9, item='L-%d (검증 칸 끝)' % n, kind='표지 빠짐 (규칙 4)', line=rx,
                old=cell_end + ' |', new=cell_end + ' · 표지 = ' + label + ' |',
                note='묶음 대조: synth2/q_l 의 그 줄 표지 칸에 같은 글 있음 · 검증이 표지를 댄 일곱 줄만 ("최소한" 꼴)')


EDITS = [
    # ── 문제 1 · 요지 5 째 줄 · 5 절 8 · L-85
    dict(doc=D, v=V, num=1, item='요지 5 째 줄', kind='재료 / 차원 빠짐 + 표지 빠짐',
         old='- 형6 — 순수 μc-LPSCl 은 놓을 때 두께 회복이 1.6 % (300 MPa) · 2.8 % (400 MPa) 로 치밀화의 대부분이 비가역이고 NMC 는 치밀화의 28 % 가 가역이다 (Miß 2026 · 실험);',
         new='- 형6 — 순수 μc-LPSCl (Cl 과잉 Li₅.₅PS₄.₅Cl₁.₅ · 우리 Li₆PS₅Cl 과 다른 조성) 은 놓을 때 두께 회복이 1.6 % (300 MPa) · 2.8 % (400 MPa) [재계산] 로 치밀화의 대부분이 비가역이고 (저자 문장) 다결정 NMC622 는 치밀화의 28 % 가 가역이다 ([재계산] · 첫 측정 단계 기준) (Miß 2026 · 실험);',
         note='카드 대조: miss2026 L31 (1.62 % [재계산] · µc-Li₅.₅PS₄.₅Cl₁.₅ · pc-NMC622) · L48 (한정어 ①) · L168–169 (저자 문장 · 28.1 % [재계산] · 첫 측정 단계 기준) 맞음'),
    dict(doc=D, v=V, num=1, item='5 절 8', kind='재료 / 차원 빠짐 + 표지 빠짐',
         old='순수 μc-LPSCl 은 놓을 때 두께가 1.6 % (300 MPa) · 2.8 % (400 MPa) 만 회복되고 치밀화의 대부분이 비가역이며 단단한 NMC 는 치밀화의 28 % 가 가역이었고',
         new='순수 μc-LPSCl (Cl 과잉 조성 · 우리 Li₆PS₅Cl 아님) 은 놓을 때 두께가 1.6 % (300 MPa) · 2.8 % (400 MPa) [재계산] 만 회복되고 치밀화의 대부분이 비가역이며 단단한 NMC 는 치밀화의 28 % [재계산] 가 가역이었고',
         note='검증: "5 절 8 … 에도 (Cl 과잉 조성 · 우리 Li₆PS₅Cl 아님) 과 [재계산] 을 넣는다" — 자리는 재료 이름 뒤 · 값 뒤로 잡음'),
    dict(doc=D, v=V, num=1, item='L-85 (재료 칸 · 값)', kind='재료 / 차원 빠짐 + 표지 빠짐', line=r'^\| L-85 \|',
         old='[실험 · 순수 SE μc-LPSCl / NMC · 시뮬레이션 없음] 순수 SE 의 치밀화는 대부분 비가역 ("the major fraction of the densification of μc-LPSCl is irreversible") 이고 놓을 때 두께 회복은 1.6 % (300 MPa) · 2.8 % (400 MPa) 뿐 · 단단한 NMC 는 반대로 치밀화의 28 % 가 가역이고',
         new='[실험 · 순수 SE μc-LPSCl (Cl 과잉 조성 · 우리 Li₆PS₅Cl 아님) / NMC · 시뮬레이션 없음] 순수 SE 의 치밀화는 대부분 비가역 ("the major fraction of the densification of μc-LPSCl is irreversible") 이고 놓을 때 두께 회복은 1.6 % (300 MPa) · 2.8 % (400 MPa) [재계산] 뿐 · 단단한 NMC 는 반대로 치밀화의 28 % [재계산] 가 가역이고',
         note='같은 카드 줄 · L-14 · L-77 은 검증이 고칠 글을 주지 않아 그대로'),
    # ── 문제 2 · L-363 · 3-B 새 행 · L-423 · 개수
    dict(doc=D, v=V, num=2, item='L-363 (문장 칸)', kind='카드에 없음 (따옴표)', line=r'^\| L-363 \|',
         old=L363_OLD, new=S3,
         note='카드 대조: bardenhagen2005 L23 에 셋째 문장만 있음 · 앞 두 문장의 낱말 ("moderate bulk" · "struts" · "kinematics") 카드에 0 회'),
    dict(doc=D, v=V, num=2, item='L-599 (3-B 새 행)', kind='카드에 없음 (따옴표)', multiline=True, cells_change=True,
         old=L400_END, new=L400_END + L599_ROW,
         note='검증이 준 내용 칸 그대로 · 새 번호 L-599 (끝 번호 다음 — 기존 번호는 안 바꿈) · 서지 · 원문 위치 · 유형 · 꼬리는 L-363 줄에서 옮김'),
    dict(doc=D, v=V, num=2, item='L-423 (설명 칸 끝)', kind='카드에 없음 (따옴표)', line=r'^\| L-423 \|',
         old='(문장 = 3 절) · 2005 년 시점의 서술 |',
         new='(문장 = 3 절) · 2005 년 시점의 서술 (미시 굽힘 · 유한변형 운동학 문장 = 정본 카드에 없음 · 원문 확인 필요) |',
         note=''),
    dict(doc=D, v=V, num=2, item='요지 1 째 줄 (3 절 항목 수)', kind='카드에 없음 (따옴표)',
         old='· 3 절 = 인용 문장 171 항목 ·', new='· 3 절 = 인용 문장 172 항목 ·',
         note='3-B 행을 더해 개수를 맞춤'),
    dict(doc=D, v=V, num=2, item='요지 10 째 줄 (3-B 행 수)', kind='카드에 없음 (따옴표)',
         old='- 3 절 = 원문 문장 117 행 · 원문 확인 필요 32 행 · 짧은 구절 22 행;',
         new='- 3 절 = 원문 문장 117 행 · 원문 확인 필요 33 행 · 짧은 구절 22 행;',
         note='개수 맞춤'),
    dict(doc=D, v=V, num=2, item='빈 곳 10 (3-B 행 수)', kind='카드에 없음 (따옴표)',
         old='10. 원문 문장: 3-B 의 32 행은', new='10. 원문 문장: 3-B 의 33 행은',
         note='개수 맞춤'),
    dict(doc=D, v=V, num=2, item='읽은 범위와 셈 (항목 수)', kind='카드에 없음 (따옴표)',
         old='- 쓴 항목: L-1 – L-598 = 1 절 153 · 2 절 98 (그 가운데 2.9 의 우리 쪽 기록 8) · 3 절 171 (3-A 117 · 3-B 32 · 3-C 22)',
         new='- 쓴 항목: L-1 – L-599 = 1 절 153 · 2 절 98 (그 가운데 2.9 의 우리 쪽 기록 8) · 3 절 172 (3-A 117 · 3-B 33 — L-599 = 검증 뒤 L-363 에서 갈라 옮긴 행 · 3-C 22)',
         note='개수 맞춤'),
    # ── 문제 3 · 5 절 2
    dict(doc=D, v=V, num=3, item='5 절 2', kind='넓게 말함',
         old='2. (받치는 서지 6) DEM 은',
         new='2. (받치는 서지 5) DEM 은',
         note='검증: 머리의 "(받치는 서지 6)" 도 "5" 로'),
    dict(doc=D, v=V, num=3, item='5 절 2 (뒤 절)', kind='넓게 말함',
         old='그 영향을 넣는 다접촉 보정은 반복 계산과 추가 비용을 부른다 (Giannis 외 2021 · Gonzalez & Cuitiño 2012 · 탄성 · 514 입자에서 고전 DEM 대비 5.68–6.40 배 = 묶음 줄의 계산) (L-59 · L-61 · L-62 · L-63 · L-178 · L-122) (종합 · 조수 판단).',
         new='그 영향을 넣는 다접촉 보정은 변위 기반 (MC-strain) 이면 반복이 필요하고 (Giannis 외 2021 §1 · 카드 옮김) 비국소 탄성은 고정점 반복을 쓰며 (Gonzalez & Cuitiño 2012), 반복을 없앤 응력 기반 (MC-stress · 2-pass) 도 514 입자에서 고전 DEM 의 5.68–6.40 배 시간이 든다 (탄성 · 배율 = 묶음 줄의 계산) (L-59 · L-61 · L-62 · L-63 · L-176 · L-178 · L-122) (종합 · 조수 판단).',
         note='카드 대조: giannis2021 L174 · L458 (MC-stress "반복 없음 (2-pass 확정)" · MC-strain 원리적으로 iterative) 맞음'),
    # ── 문제 4 · 5 절 4
    dict(doc=D, v=V, num=4, item='5 절 4', kind='넓게 말함 (인용 맥락)',
         old='실측에서는 가압 중 입자의 소성 평면화와 재배열이 함께 일어나 Kakar & Chaklader 1967 (납 · 사파이어 구) 은 "It is believed that no particular model governs the deformation" 이라 적었고, 황화물 SE 실험도',
         new='실측에서는 가압 중 입자의 소성 평면화와 재배열이 함께 일어나고 (Kakar & Chaklader 1967 · 납 · 사파이어 구 · 결론 (a)–(c)), 같은 논문은 초기 충전 (사방 쌓임) 을 논하며 "It is believed that no particular model governs the deformation" 이라 적었다 (p.3230); 황화물 SE 실험도',
         note='카드 대조: kakar1967 L70 ("초기 충전" 행 · p.3230) · L71 (결론 (a)–(d)) 맞음'),
    # ── 문제 5 · L-98
    dict(doc=D, v=V, num=5, item='L-98', kind='값 다름 (카드 보강 뒤)', line=r'^\| L-98 \|',
         old='PyCompact (금속): 제하까지 풂 (기공 ≈ 4 → ≈ 17 % · digitized · 5 MPa 규약)',
         new='PyCompact (금속): 제하까지 풂 (판독 규약 5 MPa · 가압 중 기공 ≈ 4 % → P ≈ 0 끝 ≈ 17 % · digitized — 카드 보강 11-11: 5 MPa 규약 자리는 ≈ 12–15 % · ≈ 17 % 는 펀치 이탈일 수 있어 자유 상태 기공으로 인용하지 않음)',
         note='카드 대조: pycompact2025 L127–128 (P≈0 끝 ≈17.2 / 16.9 % · 5 MPa 규약 자리 Fine ≈12 · Coarse ≈13–14 %) · L653 (stated ≈13–15 %) · L684 (인용하지 않는다) 맞음'),
    # ── 문제 6 · L-108 · L-183 · 빈 곳 5
    dict(doc=D, v=V, num=6, item='L-108', kind='카드에 없음 (카드가 철회한 판정)', line=r'^\| L-108 \|',
         old='PyCompact: 메시 미수렴 · 시드 1', new='PyCompact: ' + MESH_NEW,
         note='카드 대조: pycompact2025 L8 · L139 · §9.1 L546–561 ("미수렴" 판정 철회 · −1.4 % ↔ −6.3 %) 맞음'),
    dict(doc=D, v=V, num=6, item='L-183 (한계 칸)', kind='카드에 없음 (카드가 철회한 판정)', line=r'^\| L-183 \|',
         old='| 메시 미수렴 · 시드 1 · 금속 @ 1400–2000 MPa · 전달물성 0 건 |',
         new='| ' + MESH_NEW + ' · 금속 @ 1400–2000 MPa · 전달물성 0 건 |',
         note='검증: "L-183 한계 칸 … 도 같은 문구로"'),
    dict(doc=D, v=V, num=6, item='빈 곳 5', kind='카드에 없음 (카드가 철회한 판정)',
         old='입자별 FE 의 3D 계산은 메시 미수렴 (Demirtas · PyCompact · 1.7)',
         new='입자별 FE 의 3D 계산은 Demirtas 가 접촉 면적 미수렴 · PyCompact 는 메시 수렴 판정이 그림 (−1.4 %) ↔ 본문 숫자 (−6.3 %) 로 갈림 (카드 §9.1 · 옛 \'미수렴\' 판정 철회) (1.7)',
         note='검증: "빈 곳 5 도 같은 문구로" — 문장 꼴에 맞게 이음'),
    # ── 문제 7 · L-115 · L-183 · L-131
    dict(doc=D, v=V, num=7, item='L-115 (비용)', kind='위치 틀림 (값의 귀속)', line=r'^\| L-115 \|',
         old='569 입자 9 h (2000 요소) · 874 → 16 h · 1033 → 24 h · 2500 요소 → 36 h',
         new=COST_NEW,
         note='카드 대조: pycompact2025 L356–358 (Table 1 Fine · CPU 수 미인쇄 / Table 3 Coarse 24 CPU / 메시 시험 Coarse 문단) 맞음'),
    dict(doc=D, v=V, num=7, item='L-183 (비용 칸)', kind='위치 틀림 (값의 귀속)', line=r'^\| L-183 \|',
         old='569 입자 9 h (2000 요소) · 874 → 16 h · 1033 → 24 h · 2500 요소 → 36 h · Coarse 403 입자 24 CPU 7 h (ABAQUS 5 h)',
         new=COST_NEW,
         note='같은 카드 줄'),
    dict(doc=D, v=V, num=7, item='L-131', kind='위치 틀림 (값의 귀속)', line=r'^\| L-131 \|',
         old='explicit dt 벌금 ×16 → ≈ 1 년 (24 CPU)',
         new='explicit dt 벌금 ×16 → ≈ 1 년 (24 CPU 는 Table 3 Coarse 7 h 의 조건 — 9 h 기준 어림의 CPU 수는 미인쇄 · 보탬 b42)',
         note='카드 L12–13 · L356–358 과 맞음'),
    # ── 문제 8 · 5 절 6 · 5 절 7 (요지 6 째 줄은 고칠 글 없음)
    dict(doc=D, v=V, num=8, item='5 절 6 (끝)', kind='표지 (조수 판단 · 원문 확인) 빠짐',
         old='Gonzalez & Cuitiño 2012 와 Giannis 외 2021 도 전 입자 FEM · MPM · MPFEM 이 입자 수에서 막힌다고 정리했다 (L-114 · L-307 · L-115 · L-275 · L-113 · L-112) (종합 · 조수 판단).',
         new='Gonzalez & Cuitiño 2012 와 Giannis 외 2021 도 전 입자 FEM · MPM · MPFEM 이 입자 수에서 막힌다고 정리했다 (L-114 · L-307 · L-115 · L-275 · L-113 · L-112) (종합 · 조수 판단) (Giannis · Gonzalez 의 정리는 카드 옮김 — 원문 확인 필요 · 3-B L-376 · L-377).',
         note='문서 안 L-376 · L-377 (3-B) 과 맞음'),
    dict(doc=D, v=V, num=8, item='5 절 7', kind='표지 (조수 판단 · 원문 확인) 빠짐',
         old='MPM 은 격자를 매 걸음 새로 써서 유한요소의 격자 뒤틀림을 피하지만 (de Vaucorbeil 외 2020 · Bardenhagen 외 2005),',
         new='MPM 은 격자를 매 걸음 새로 써서 유한요소의 격자 뒤틀림을 피하지만 (Bardenhagen 외 2005 "eliminating mesh tangling problems" · de Vaucorbeil 외 2020 은 카드 요약 — 원문 확인 필요 · L-373),',
         note='문서 안 L-373 (3-B) · L-426 과 맞음'),
    dict(doc=D, v=V, num=8, item='요지 6 째 줄', kind='표지 (조수 판단 · 원문 확인) 빠짐', status='held',
         note='보류 — 검증 표의 항목 번호 칸에는 있으나 "고칠 글" 칸에 요지 6 째 줄의 글이 없음 (5 절 6 · 7 만 줌)'),
    # ── 문제 9 · 2 절 표지 (일곱 줄만)
    lab(166, r'^\| L-166 \|', 'Sakuda SEM 과 정성 대조 (Fig 4b–g) · 사이클 열화는 실험 검증 없음', 'stated · digitized (상대밀도)'),
    lab(167, r'^\| L-167 \|', '상대밀도–몰드압 50–700 MPa (~200 MPa 위 일치 · 저압은 더 치밀) + E_electrode/E_LPS → 1', 'stated · digitized (곡선)'),
    lab(169, r'^\| L-169 \|', '1/m 0.2–0.4 · μ 0.1 에서 정합 (K_h 1.3 / 1.8 vs 실험 1.3 / 1.7–2.0)', 'stated / digitized'),
    lab(176, r'^\| L-176 \|', '논문 최대 응력 유리 ≈ 45 MPa · 탄성 영역만', '곡선 값 = digitized (TREND only)'),
    lab(190, r'^\| L-190 \|', '해석식 ↔ MPM 소성 계열 ±7 % (Φ 0.85–0.97) · 그 위 +23–38 %', 'digitized (2D) · "우리 추론"'),
    lab(207, r'^\| L-207 \|', '| 16–96 kPa', 'stated · digitized 혼합 (Fig 8 = digitized)'),
    lab(241, r'^\| L-241 \|', '(원뿔 실측 15 점 중 11 점이 K 0.05 곡선 아래)', 'stated · digitized (TREND) · 카드 판단'),
    dict(doc=D, v=V, num=9, item='2 절 나머지 91 줄 (표지 칸)', kind='표지 빠짐 (규칙 4)', status='held',
         note='보류 — 검증이 표지를 댄 것은 일곱 줄 (L-166 · 167 · 169 · 176 · 190 · 207 · 241) 뿐 · 나머지 줄의 묶음 표지를 다시 뽑아 항목에 대응시키는 일은 종합을 다시 하는 일 (여러 묶음 줄을 합친 항목이 많음) 이라 적용하지 않음 · 표에 새 칸도 더하지 않음'),
    # ── 문제 10 · L-8 · 요지 3 째 줄
    dict(doc=D, v=V, num=10, item='L-8', kind='조건 빠짐', line=r'^\| L-8 \|',
         old='"평균압 일정 · 즉시 전소성" 가정 (CEB) 은 면적 56 % · 하중 62 % 과대',
         new='"평균압 일정 · 즉시 전소성" 가정 (CEB) 은 작은 간섭에서 면적 56 % · 하중 62 % 과대 (카드: 최대값 · 큰 간섭에서는 줄거나 과소로 바뀜)',
         note='카드 대조: kogutetsion2002 L88–89 (CEB 최대 56 % @ ω/ω_c = 4 · 110 에서 7 % / 62 % @ 2 → 38 % 과소 @ 110) · L110 맞음'),
    dict(doc=D, v=V, num=10, item='요지 3 째 줄', kind='조건 빠짐',
         old='"평균압 일정 · 즉시 전소성" 가정은 면적 56 % · 하중 62 % 과대다 (Kogut–Etsion);',
         new='"평균압 일정 · 즉시 전소성" 가정은 작은 간섭에서 면적 56 % · 하중 62 % 과대다 (카드: 최대값 · 큰 간섭에서는 줄거나 과소로 바뀜) (Kogut–Etsion);',
         note='같은 글 (요지 문장 꼴에 맞춤)'),
    # ── 문제 11 · 5 절 1
    dict(doc=D, v=V, num=11, item='5 절 1', kind='재료 / 차원 빠짐',
         old='(So 외 2021 · 2022 · LPS · Sangrós Giménez 외 2019 · LIB · Varkey 외 2026 · 할라이드)',
         new='(So 외 2021 (JES · 2D) · 2022 · LPS · Sangrós Giménez 외 2019 · LIB · Varkey 외 2026 · 할라이드)',
         note='문서 안 L-166 ("2D · LPS 유리") 과 맞음'),
    # ── 문제 12 · L-240
    dict(doc=D, v=V, num=12, item='L-240 (우회 칸)', kind='재료 / 차원 빠짐 (차원을 잘못 붙임)', line=r'^\| L-240 \|',
         old='Cronk 2026 (등방 eigenstrain · 2D · Li–S)',
         new='Cronk 2026 (등방 eigenstrain · β_H 만 2D 단일 입자 계산으로 역보정 · 전극 응력은 3D (카드 L601) · Li–S)',
         note='카드 대조: cronk2026 L601 "von Mises 분포 3D" · L623 "β_H 보정 = 2D 단일입자 런" 맞음'),
    # ── 문제 13 · L-357
    dict(doc=D, v=V, num=13, item='L-357 (문장 칸)', kind='따옴표 다름 (두 문장을 한 따옴표로)', line=r'^\| L-357 \|',
         old=G1 + '  ' + G2,
         new=G1 + '" · "' + G2 + ' (둘 다 초록 p.1 · 이어짐은 원문 확인 필요)',
         note='카드 대조: gritton2017 L57 (첫 문장 · 초록) · L39 (둘째 문장 · 초록 p.1) — 카드가 따로 옮김'),
    # ── 문제 14 · L-62
    dict(doc=D, v=V, num=14, item='L-62', kind='위치 틀림 (괄호가 다른 말에 붙음)', line=r'^\| L-62 \|',
         old='접촉 비간섭 → D 0.85–0.90 까지만 엄밀 (카드에는 "명시적 가정" 으로만 있음)',
         new='접촉 비간섭 → D 0.85–0.90 까지만 엄밀 (본문 명시 · 계산은 D ≤ 0.95 까지) · 왜 어려운지의 직접 설명은 카드에 "명시적 가정" 으로만 있음',
         note='카드 대조: martinbouvard2003 L51 맞음'),
    # ── 문제 15 · L-346 · L-347
    dict(doc=D, v=V, num=15, item='L-346 (원문 위치)', kind='위치 틀림', line=r'^\| L-346 \|',
         old='| 묶음 줄에 쪽 없음 (카드 줄 67–68) |', new='| 묶음 줄에 쪽 없음 (카드 줄 467 · §6.4) |',
         note='카드 대조: song2025_electrochemo L467 (§6.4 = L454–) 에 이 문장'),
    dict(doc=D, v=V, num=15, item='L-347 (원문 위치)', kind='위치 틀림', line=r'^\| L-347 \|',
         old='| 묶음 줄에 쪽 없음 |', new='| 묶음 줄에 쪽 없음 (카드 줄 67–68) |',
         note='카드 대조: song2025_electrochemo L67–68 에 이 문장'),
    # ── 문제 16 · L-250
    dict(doc=D, v=V, num=16, item='L-250 (꼬리)', kind='위치 틀림 (꼬리)', line=r'^\| L-250 \|',
         old='[layer3 · zunker2024_mdr_contact_model_partI · §C L2130–2139] [layer3 · varkey2026_multicontact_elastoplastic_dem · §A L693–699 · L733–737]',
         new='[layer3 · zunker2024_mdr_contact_model_partI · §C L2130–2139] [layer3 · varkey2026_multicontact_elastoplastic_dem · §C L2130–2139] [layer3 · giannis2021_stress_based_multicontact_dem · §A L693–699 · L733–737]',
         note='묶음 대조: synth2/q_l L492 (머리 giannis2021 + gonzalez2012 + zunker2024_partI · §A L693–699 · L733–737) · L500 (zunker2024 + varkey2026 · §C L2130–2139) 맞음'),
    # ── 문제 17 · L-193
    dict(doc=D, v=V, num=17, item='L-193 (한계 칸)', kind='꼴 (한 칸 안 같은 글 두 번)', line=r'^\| L-193 \|',
         old='| ' + L193_ONE + ' · ' + L193_ONE + ' |', new='| ' + L193_ONE + ' |',
         note=''),
    # ── 문제 18 · L-244
    dict(doc=D, v=V, num=18, item='L-244 (표지 칸)', kind='꼴 (규칙 12)', line=r'^\| L-244 \|',
         old='카드가 든 출처 `docs/data/mpm_dpc_heckel_sweep.csv`)', new='카드가 든 출처 docs/data/mpm_dpc_heckel_sweep.csv)',
         note='백틱만 뗌'),
    # ── 머리 한정 줄
    dict(doc=D, v=V, num='머리', item='한정 줄', kind='한정 (지시서)', multiline=True,
         old='# 소성변형이 왜 어려운가 · 택한 우회 (정독 종합 · 질문 l)\n\n',
         new='# 소성변형이 왜 어려운가 · 택한 우회 (정독 종합 · 질문 l)\n\n'
             '한정 (2026-11-12): 검증 = 표본 (다섯에 하나 + 따옴표 · 서지 전부) · 문제 비율 = 문제 18 / 본 항목 256 (전체 항목 598 · 표본 256 = 1 절 153 전부 + 다섯에 하나 89 + 5 절이 받치는 항목 14 · 숫자 = V_S5.md 셈) · 표본 밖 항목은 대조하지 않았다 · 이 판은 검증 표의 "고칠 글" 을 적용한 뒤다 (기록 = APPLIED.md · 2 절 표지는 검증이 댄 일곱 줄만 붙였다).\n\n',
         note='숫자는 V_S5.md 셈 절에서만 (이 문서의 표본 꼴은 1 절 전부 + 다섯에 하나)'),
]

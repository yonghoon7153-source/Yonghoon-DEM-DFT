# 본 세션 (stoic) → 대피 세션 인계 (2026-11-12 · 1저자 *"토큰이 3%정도 밖에 없어서 대피 브랜치로 … yano, zunker 이 두개만 유지하고 나머지는 다 대피 브랜치로 인계"*)

## 0. 붙여 넣을 프롬프트 (대피 세션 첫 메시지 · 이 묶음 tgz 를 함께 올린다)

```
본 세션 (stoic) 토큰이 떨어져 litdb 를 뺀 일을 전부 여기서 이어받는다 (1저자 11-12).
첨부 handoff_evac_20261112.tgz 를 빈 폴더에 풀고 (python -I · 보통 파일만) HANDOFF.md 를 끝까지 읽고 그대로 한다.
작업 가지 = claude/sdcp-dem-manuscript-si-pqwtv8 (fast-forward 만) · claude/stoic-knuth-NObVQ = 동결 (커밋 · push 금지).
첫 일 = HANDOFF §1 (af3cce37b 반영 · 게이트 · push) → §2 커밋 J → §3 ibb 건식 → §4 Rint 코드 묶음.
litdb: N-25 Yano 2024 · Zunker 2025 출판본 보강 = 본 세션이 계속 (여기서 하지 않는다). 넘겨받는 논문 34 편 PDF 는 1저자가 따로 올린다 (§6).
```

## 1. 가지 — 다시 합칠 때 충돌 0 (11-08 · 11-10 인계와 같은 꼴)

| 가지 | 지금 | 규칙 |
|---|---|---|
| `claude/stoic-knuth-NObVQ` (stoic) | origin 끝 `11a794674` · 본 세션 로컬 `af3cce37b` (서명 · Rint 결정 기록 · 게이트 1–125 통과 · 126–183 도는 중) | **동결**.  본 세션은 게이트가 통과하면 `af3cce37b` 하나만 push 하고 그 뒤로 stoic 에 아무것도 올리지 않는다 |
| `claude/sdcp-dem-manuscript-si-pqwtv8` (pqwtv8) | origin 끝 `e93efb6be` = stoic 의 조상 · 그 뒤 고유 커밋 0 | **대피 세션의 유일한 작업 가지** · fast-forward 만 (rebase · force · merge 커밋 금지) |
| `claude/friendly-meitner-lldvar` (litdb 정본) | 두 세션 조수가 같이 push | push 전 fetch · rebase (지금처럼) |

첫 일 (af3cce37b 를 pqwtv8 로):
1. `git fetch origin claude/stoic-knuth-NObVQ claude/sdcp-dem-manuscript-si-pqwtv8`
2. origin stoic 끝이 `af3cce37b` 이면 → `git checkout -B claude/sdcp-dem-manuscript-si-pqwtv8 origin/claude/stoic-knuth-NObVQ` (본 세션이 게이트 통과 뒤 push 한 것 · 다시 게이트 불필요 · 바로 `git push -u origin claude/sdcp-dem-manuscript-si-pqwtv8`).
3. 아니면 (아직 `11a794674`) → `git fetch stoic_dec_af3cce37b.bundle HEAD:refs/tmp/af3` → `git cat-file -p refs/tmp/af3` 로 부모 `11a7946748fa…` · gpgsig 확인 → `git checkout -B claude/sdcp-dem-manuscript-si-pqwtv8 refs/tmp/af3` → 게이트 두 조각 (1–125 · 126–183 · 같은 HEAD · fail 0) → push pqwtv8.  (그 사이 본 세션이 stoic 에 af3cce37b 를 push 해도 같은 커밋이라 충돌 없음.)
4. 복귀 = 1저자 "메인 복귀" → 대피 세션 마지막 커밋 `docs/handoff_return_to_stoic_knuth_<날짜>.md` → 본 세션 (또는 새 본 세션) 이 stoic 을 pqwtv8 끝으로 fast-forward.

## 2. 커밋 J — G2c′ 실행기 `-h` 고침 + siteq 예행 반입 (준비 끝 · 커밋만 남음)

- 결함 `SELF-166`: LIGGGHTS 3d5c00f 의 `-h` = help() 뒤 error->done() = exit(1) (lammps.cpp 543–545 · error.cpp 369–379) 인데 실행기가 rc 0 을 요구 → ibb 건식 job 358667 이 팔 0 에서 멈춤 · 가짜 lmp 도 rc 0 이라 시험이 못 잡음.
- 고침 = 받는 rc 1 + 배너 + 도움말 줄 `Command line options:` 요구 (오류 끝도 rc 1 이라 가름) · 가짜 lmp = 3d5c00f 꼴 · t22 사례 셋 · t26 기록.
- 시험: 고치기 전 29/41 (`g2c/t_before.log` · fail 12) → 고친 뒤 41/41 (`g2c/t_after.log`) · 변이 6/6 (`g2c/mutation_summary.txt` · 변이 사본에 키트가 없어 t07 은 변이 없이도 실패 = `g2c/base_t07.log` 40/41).
- 하는 법 (pqwtv8 · 깨끗한 트리):
  1. `git apply g2c/commitJ_g2c.patch` (메모 §0 머리 11-12 줄 · §0-4 실행기 행 · README_g2cp ibb 절 · 시험 줄 · 하지 않는 것 · run_g2cp.sh · test_g2cp.py)
  2. `cp -a siteq/rint2_siteq_20261112_rehearsal docs/data/` (README · SHA256SUMS 24 줄 · _orig_hashes.tsv · 홈 경로 가림)
  3. `python3 -I g2c/commitJ_extra.py .` (원장 SELF-166 open · 진행 기록 세 줄 · CLAUDE.md G2c 줄)
  4. `python3 -I docs/reviews/p1_g2c_sandbox_20261104/test_g2cp.py` → 41/41 (t07 포함)
  5. `check_doc_refs` · `check_review_findings` · `--ban-sweep` → 커밋 하나 (서명 · 트레일러 · gpgsign 끄지 않는다) → bundle → 게이트 두 조각 → push → 다음 커밋에 SELF-166 claimed_fixed (push 된 sha).
- ⚠ 진행 기록 셋째 줄은 "litdb 트리 2 를 치움" 을 적는다 — 그 뒤 본 세션이 Zunker 일로 트리 2 를 다시 만들었다 (본 세션 컨테이너 일 · 리포 무관).

## 3. G2c′ ibb 건식 다시 (커밋 J push 뒤)

- `git archive --format=tar.gz -o g2cp_sandbox_<sha9>.tgz <sha> docs/reviews/p1_g2c_sandbox_20261104` → sha256 → `g2c/ibb_try4_cmds_template.txt` 의 `__SHA9__ · __SHA__ · __TGZSHA__` 채워 1저자에게 (ibb 접속 정보는 채팅으로만 · 리포 금지).
- ibb 현장 (1저자 화면 기준): `~/g2cp_20261112` = repo (11a794674 덱) · `job_dry.sh` (`conda activate myenv` · `LMP=$HOME/LIGGGHTS-PUBLIC/src/lmp_mpi` · `mpirun` 없이 1 프로세스) · logs_try1/2 · 잡 358667 로그 = logs/ · `g2cp_dry200_return.tgz` (시도 2 묶음 · pack 전 옮김) · watch = `bash ~/g2cp_watch.sh <잡번호>` (1저자가 만듦) · pack = `bash ~/g2cp_ibb.sh pack` (도구 = `g2c/g2cp_ibb.sh` · 빌드 부분은 쓰지 않는다 = 내 결함).
- 돌아오면: 빈 폴더에 풀기 → `python3 -I compare_g2cp.py <OUT> 200` (건식 = 문법만 · rc 0 + "쌍 0" 표지 · 예측 판독 아님) → 보고 → 샌드박스 N 40,000 = 1저자 GO 따로.  예측 가 = 해당 없음 (실행 파일 md5 ≠ 11-04).

## 4. Rint ② 코드 묶음 (1 순위 · 마감 = GPU 팔 12 월 초 확실히 끝남 · 1저자 11-12)

- 결정 근거 = `docs/reviews/rint2_time_reestimate_20261111/README.md` 의 "1저자 결정 (11-12)" 절 (af3cce37b) · 벤치 = 같은 폴더 `bench/results_20261112/`.
- 조수가 하던 것 (멈춘 자리 = 구현 뒤 store 시험 T · P · R · C 전체를 다시 돌리기 직전):
  - `rint_codepkg/tests_first_71b0d145f.bundle` = 시험 먼저 커밋 (바탕 `11a794674` · 서명 없음 → cherry-pick 때 다시 서명)
  - `rint_codepkg/tracked.diff` (구현 중 12 파일) · `rint_codepkg/untracked.tgz` (`scripts/cjunc_store.py`)
  - 지시서 · 설계 · 기록 = `BRIEF_codepkg.md` · `design.md` (Q11 = GPU 경로만 · 'jacobi' 유지 · 새 키 없음 · Q2 = 새 모듈 cjunc_store · npz + 뼈대 JSON · 엄격 지문 · os.link 단일 작성자 · 팔 JSON 그대로 · 곁 파일 cjstore_*) · `notes.md` (cupy 12.3.0: cg 는 `tol=` 만 · dia → MatrixLinearOperator · 부호 있는 0 다를 수 있음) · `amend_drafts.md` · `gpu_check_block.txt`
- 이어서: 시험 먼저 확인 → 구현 마무리 → 전체 시험 (3.11 + kgy 판 3.8 = `scripts/setup_kgy_py38.sh`) → 변이 → GPU 확인 블록 · 개정 초안 → 내부 반박 리뷰 (독립 조수 · "Codex 아님") → 반입 (cherry-pick · 서명) · 게이트 → 원장 시도 3 줄 → S0 단계 1 다시 · ⑥ 시도 3 · GPU 확인 (1저자 실행) → Codex 봉인 전 묶음 (Codex 남은 한 번) → 계획 §10 개정 → 봉인 → R.
- 알려진 것: `SELF-162` (E7 오탐 · kgy 판 단계 · 두 번째 11-12) = 실패하면 토큰 확인 → 조각 다시 · 고침은 따로 (시험 · 변이 먼저).

## 5. 그 밖의 열린 일 (자세한 것 = `STATE_tail_20261112.md` · 진행 기록 · CLAUDE.md)

siteq 본 현장 확인 (단일 개정 커밋 핀 · 계획 §0-2 Q1) · gabia 킷 scripts 링크 (계획 §10 의 4 번 · R 전) · 믹서 E0 자격 pilot · [DEM 우선 (수영)] 메모 3.2 (DRD-01–13 + SELF-161) + 내부 반박 리뷰 · 재설계 docx v2 + 웹앱 · 정독 종합 고침 → build_package → 커밋 · Codex 비 Rint 반입 · litdb 웹앱 (정본 가지 webapp) '최근' 띠 12 편 한도 (같은 날 21 편 · 이름순이라 뒤 카드가 안 보임 · 1저자가 원하면 정렬 · 개수).

## 6. litdb

| 누가 | 무엇 |
|---|---|
| 본 세션 (계속) | N-25 Yano 2024 (트리 1 `/home/user/litdb-canon`) · Zunker 2025 출판본 보강 (트리 2 · 크롭 · 영상 프레임 · 프리프린트 대조 · 첨언) → 정본 push |
| 대피 세션 (넘겨받음) | **N-2 · 5 · 10–12 · 14–17 · 19–20 · 24 · 26–27 · 29–30 · 32–33 · 35 · 36–43 · 45–51 (34 편)** + 기존 N-52 부터 · status.tsv (Yano · Zunker 줄도 정본에 커밋이 보이면 고쳐도 된다) |

- 끝난 것 (다시 하지 않는다): N-1 · 3 · 4 · 6 · 7 · 8 · 9 · 13 · 18 · 21 · 22 · 23 · 28 (보탬) · 34 · 44 · 제외 N-31.
- PDF 파일 이름 앞 번호 = N 번호 (예: `26._Compression_properties…` = N-26 Yano 2023).
- 지시서 = 정본 `litdb/_curation/` (README · COMMON · CURATOR_BRIEF (§2-1 끝 = 11-12 글 크롭 규칙 · 카드당 20) · S8_candidates · status.tsv) + 이 묶음 `litdb/prompts/` (본 세션 논문별 지시서 19 편 · 안의 scratchpad · 트리 경로는 대피 세션 자리로 바꿔 읽는다 · N-36–N-51 은 `_todo_N36_N51.md` 로 새로 쓴다) · 정독 NN = 본 세션 몫 43–100 (curation README §1).

## 7. 그대로 지킬 규칙 (요약 — 원문 = CLAUDE.md)

한국어 · 표 중심 · 간결 · 보고 → 설명 → 비준 → 실행 (운영은 권고대로) · 시험 먼저 · 커밋 하나 → 게이트 (두 조각 · 줄이지 않음 · Bash 배경 · timeout 7200000) → push · 로컬 커밋 쌓지 않기 (쌓이면 즉시 bundle 을 1저자에게) · 게이트 중 조수 2 · 무거운 일 3 · 트레일러 두 줄 · gpgsign 끄지 않기 · 주소 · 포트 · 계정 = 채팅만 · 받은 파일 = 빈 폴더 · python -I · 원본 안 건드림 · RJ 323957 재실행 없음 · lmp_auto 금지 · 56 코어 = GO 뒤 · 50kg 그래프 손대지 않음 · Rint 탐침 σ 열람 금지 · Codex = 봉인 전 묶음 한 번 · 카드 문제 = 기록만 · 신호 실험 = `unshare -pf --mount-proc --kill-child` 안에서만.

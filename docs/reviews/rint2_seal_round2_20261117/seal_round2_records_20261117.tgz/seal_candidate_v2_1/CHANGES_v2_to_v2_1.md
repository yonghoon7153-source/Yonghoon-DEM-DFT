# 봉인 후보 v2 → v2.1 — 파일별 바뀐 것 (11-17 · 내부 반박 리뷰 반영 · Codex 아님 · 문서 · scratch 만 · 결과 0 건 · 실행 0 · σ 열람 0)

- 비교 = v2 (`<scratch>/rint/seal_candidate_v2/` · 봉인 꼴 G′ `bea3cb33a`) ↔ v2.1 (이 폴더 · 봉인 꼴 G″ `c80d700bdd59`) · `<scratch>` = 이 세션의 scratch 폴더 (리포 밖).
- 봉인 값 · 계획 · 원본 자리 = **바이트 같음** [실측]: 계획 `ca1_plan.json` sha256 f09b3efbe50d104d7e294a6b3dce8bda5214d267a4fecfc99b7e50023396d3c4 · 원본 자리 등록 R (표지 한 줄) 1cf4a7b44b7fc324… · 블록 0a62a8b5… · S0 해시 6346d9ed….
- G′ ↔ G″ `git diff --stat` (파일 구성 같음 · 바뀐 바이트만) = 아래 끝 절 [실측].

## 이 폴더의 파일

| 파일 | v2 → v2.1 |
|---|---|
| `make_sealed_copy.py` | sha256 ebf95e0d… → f923dede1112d6aa… · **P2-2**: 계획 바이트 Q3 꼴 대조 (`json.dumps(…, indent=1, sort_keys=True)` · ASCII · 끝 줄바꿈 없음) · 핀 사슬 `plans_cross_problems(계획, S0 계획) == []` (S0 계획 = 엄격 ASCII JSON · 사슬 dir 을 잠깐 sys.path 에) · `--final` (봉인 때 필수 · 핀 사슬 `require_plan_numbers`) · `_manifest.json` `schema` v1 → v2 · `seal_status` (후보 · 봉인 값 아님 / final) · `plan_checks` 셋 (v2 `checks` 11 그대로) · **P3-4**: 빈 블록 · last · mid+last 블록 줄바꿈 · `|` 거부 · 조각 이름 집합 고정 (`FRAG_SETS` = R-MARK · R-00 – R-15 / K-01 – K-05) · 남은 자리표 허용 목록 (`ALLOWED_PH` 35 = v2 의 34 + `<넘김 기록의 원장 끝 커밋>`) · `--seal-date` = `datetime.strptime` · `--seal-branch` = git 가지 이름 규칙 (`branch_ok`) · **P3-12**: 머리 글 (쓰는 곳) · `_manifest.json` 입력 = sha256 · 바이트만 (파일 이름 뺌) · 자기 시험 17 → 35 (v2 17 그대로 · S0 고정물 = 두 계획 대조 칸만 든 작은 JSON 으로 바꿈 (v2 = `{"s0": 1}` · 새 대조를 지나야 해서)) |
| `registration_R_insert.md` | 머리 줄 (원본 바이트 같음 = 11-17 06:56 UTC 측정 값 · P3-1) · v2.1 바뀐 것 한 줄 · **R-13 §10-7 ①** 받는 쪽 차례 = 세워 둔 자리에서 먼저 `pull --ff-only` 뒤 되살림 · `RECV_OK` (P3-6) — 그 밖 조각 글 = v2 그대로 |
| `commands_doc_insert.md` | 머리 줄 (P3-1) · v2.1 바뀐 것 한 줄 · K-03 (2) `command -v python3` 기대 = `~/dem-venv/bin/python3` (P3-12) · (2b) venv 켬 + 판 출력 줄 · `git diff --quiet … && echo SAME_VERSION_OK && python3 …/ca_s0_census.py …` · 끝 `; echo "rc=${PIPESTATUS[0]}"` (P3-5) · (5) 받는 쪽 = `git -C ca1_ledger.parked -c pull.rebase=false pull -q --ff-only "$RB" "$BR" && mv ca1_ledger.parked ca1_ledger` · 끝 `test "$(git -C ca1_ledger rev-parse HEAD)" = <넘김 기록의 원장 끝 커밋> && echo RECV_OK` (P3-6) · (6) T_hit "(중앙값)" 지움 (P3-12) |
| `plan_candidate.json` | 같음 (666 B · f09b3efb…) |
| `README.md` | 제목 v2.1 · 지위 · v2 → v2.1 한 줄 · 읽은 판 (측정 시점) · 파일 표 · 닫는 것 표 (v2.1 줄) · 증거 표 (G″a / G″ 값) · **새 절 "v2 → v2.1"** (지적 → 처분 표 · 한정 표 다섯) · §나 R-13 · §다 K-03 · 넘김 줄 · §라 (Q3 꼴 · `--final`) · §마-1 (G″ · 36) · §마-2 (러너 733 줄) · §마-3 · §마-4 (5a04acd15 지금 원격 stoic · G″ 참조 검사) · §마-5 (`--final`) · §바 (stoic 세 커밋 = 원격 stoic 안 → 닫힘 · 6 문서 · 55 줄) · §사 (e12 다시) · §아 (새 인자 · 넘김 흉내) · scratch 절대 경로 3 곳 → `<scratch>` (P3-12) |
| `build_20261120/` | 봉인본 sha256 1a07b53c… → **3787864a…** (조각 R-13 한 곳) · 명령 문서 7dd095f5… → **bef29b6b4ca7fcfe…** (K-03 다섯 곳) · 원본 자리 · 계획 = 같음 · `_manifest.json` (schema v2 · 이름 없음 · seal_status · plan_checks) |
| `evidence/tools/check_sh_commands.py` | **P2-1 · P3-11** 다시 씀 (sha256 ac63e25d… → 2daf3479b3775a2a…) — 모든 울타리 · 못 읽은 줄 · 그 밖 울타리 · `--expect` · sh 0 개 · 원본 자리 sh · 한 문서에만 (`ladder_dry` 만 허용) · `--cjunc-store ~/ca1_cjstore` (Q4) · 사다리 P0 = kgy · P1 = gabia (Q6) · `--selftest` (19 경우) · 화면의 가짜 홈 · 트리 경로 = 자리표 |
| `evidence/tools/check_chain_functions.py` · `check_s0_stage2_gate.py` | 날짜 = 인자 (P3-9) · 그 밖 같음 |
| `evidence/tools/` 나머지 넷 | 같음 |
| `evidence/` 결과 파일 | G″a / G″ 값으로 (파일 이름 · 수 = v2 그대로 · `e1_…_A/B/F` · `e6_…_B2` · `e6_…_pin_claims` · `e7_…_B_pin_claims` · `e8` · `e10_…_B2` = v2 그대로) |
| `evidence/raw/` | 원 출력 (scratch · 리포에 넣지 않음) — G″a / G″ 출력 + `v21_relay_block.txt` |
| `work/` | 고치기 전 판 (`check_sh_commands_v2_plus_selftest.py` · `make_sealed_copy_v2_plus_tests.py` = v2 판정 코드 + 새 자기 시험) · 그 출력 · 넘김 흉내 `check_relay_block.py` · README 만든 스크립트 · e12 스크립트 · 리뷰 변이 다시 돌린 것 |
| `seal_form_G2_20261117.bundle` | 새 묶음 (가지 `seal-form-scratch` = G″ · 부모 = 코드 핀 `64e4d213e`) · v2 묶음 `seal_form_Gprime_20261117.bundle` 는 v2 폴더에 그대로 |

## G′ ↔ G″ 봉인 꼴 커밋 차이 (`git diff --stat bea3cb33a <G″>` · 파일 구성 같음)

```
 docs/reviews/rint2_kgy_commands_20261020.md        |  21 +-
 docs/reviews/rint2_seal_20261120/README.md         | 140 ++++--
 .../evidence/e10_seal_files.txt                    |   6 +-
 .../evidence/e11_make_sealed_copy.txt              |  64 ++-
 .../evidence/e12_stoic_refs.txt                    |  19 +-
 .../evidence/e13_seal_doc_tests.txt                |  28 +-
 .../evidence/e14_gate_tests_docs.txt               |  21 +-
 .../evidence/e1_test_rint_r_chain_full_G.txt       |   6 +-
 .../rint2_seal_20261120/evidence/e2_e2e_E17.txt    |  10 +-
 .../evidence/e3_sh_argparse.txt                    |  75 ++-
 .../evidence/e4_plan_doc_check.txt                 |   9 +-
 .../evidence/e4b_chain_functions.txt               |   2 +-
 .../evidence/e5_fixture_build.txt                  |  16 +-
 .../evidence/e5_s0_stage2_gate.txt                 |  10 +-
 .../evidence/e6_ban_new_text.txt                   |   9 +-
 .../evidence/e7_check_method_discipline.txt        |   4 +-
 .../evidence/e9_check_doc_refs.txt                 |  28 ++
 .../evidence/make_sealed_copy_manifest.json        |  38 +-
 .../evidence/tools/check_chain_functions.py        |   9 +-
 .../evidence/tools/check_s0_stage2_gate.py         |   9 +-
 .../evidence/tools/check_sh_commands.py            | 539 ++++++++++++++++-----
 .../rint2_seal_20261120/registration_R_sealed.md   |   2 +-
 .../tools/commands_doc_insert.md                   |  26 +-
 .../rint2_seal_20261120/tools/make_sealed_copy.py  | 146 +++++-
 .../tools/registration_R_insert.md                 |   7 +-
 25 files changed, 937 insertions(+), 307 deletions(-)
```

## 만든 차례 (scratch 사본 `seal-form-scratch` · 리포에 올리지 않음)

1. 자기 시험 먼저: `work/check_sh_commands_v2_plus_selftest.py` (v2 판정 코드 + 새 자기 시험) = 6/19 · `work/make_sealed_copy_v2_plus_tests.py` (v2 판정 코드 + 새 자기 시험) = 17/35 → 고침 → 19/19 · 35/35.
2. 조각 고침 (K-03 다섯 곳 · R-13 한 곳 · 머리 줄 둘) → 도구로 다시 만듦 (`build_20261120/`) → **G″a** `0a6939cb3` (G′ 나무 + 고친 도구 · 조각 · 봉인본 · 명령 문서 · 증거 도구 · 부모 64e4d213e) → 무거운 시험 · 관문 · 대조 (G″a).
3. 사슬 시험 전체 첫 판 = 504/506 (RR4A · RR4B = sparse 사본에 시험 고정물 폴더 `docs/reviews/codex_rint2_rr_round4_evidence_20261109/` 가 없어 FileNotFoundError) → 그 폴더를 sparse 에 더해 둘째 판 = 506/506 (538.0 s).
4. 증거 · README 를 G″a 결과로 → 첫 G″ (8abd8c422) 의 참조 검사 = 없는 경로 14 · 없는 커밋 2 (README 가 scratch 만의 경로 · 로컬 커밋 두 개를 백틱 안에 적음) → 백틱을 걷음 (README 만) → **G″** (위 sha) = 참조 rc 0 · 철회값 0 · 경계 같음 · ③ ④ 다시 같음 · 묶음.

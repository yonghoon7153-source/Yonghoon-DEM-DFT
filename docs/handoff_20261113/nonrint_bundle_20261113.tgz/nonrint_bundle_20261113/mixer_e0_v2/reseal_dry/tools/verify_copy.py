"""Compare an extracted tree with a git ls-tree -r -z listing (blob sha1 of every path).
Usage: python3 -I -B verify_copy.py <ls_tree_z_file> <extracted_root>
Read-only.  Prints counts; rc 0 only if every listed path matches and no extra file exists."""
import hashlib, os, sys
listing, root = sys.argv[1], sys.argv[2]
rows = [r for r in open(listing, 'rb').read().split(b'\0') if r]
want = {}
for r in rows:
    meta, path = r.split(b'\t', 1)
    mode, typ, oid = meta.split(b' ')
    want[path.decode('utf-8', 'surrogateescape')] = (mode.decode(), typ.decode(), oid.decode())
bad, missing, ok = [], [], 0
for path, (mode, typ, oid) in want.items():
    p = os.path.join(root, path)
    if typ != 'blob':
        continue
    if mode == '120000':
        if not os.path.islink(p):
            missing.append(path); continue
        raw = os.readlink(p).encode('utf-8', 'surrogateescape')
    else:
        if not os.path.isfile(p) or os.path.islink(p):
            missing.append(path); continue
        raw = open(p, 'rb').read()
    h = hashlib.sha1(b'blob ' + str(len(raw)).encode() + b'\0' + raw).hexdigest()
    if h == oid:
        ok += 1
    else:
        bad.append(path)
extra = []
for dp, dn, fn in os.walk(root):
    for f in fn:
        rel = os.path.relpath(os.path.join(dp, f), root)
        if rel not in want:
            extra.append(rel)
print('listed', len(want), 'blob_ok', ok, 'mismatch', len(bad), 'missing', len(missing), 'extra', len(extra))
for x in (bad + missing)[:10]:
    print('  bad/missing:', x)
for x in extra[:10]:
    print('  extra:', x)
sys.exit(0 if not bad and not missing and not extra else 1)

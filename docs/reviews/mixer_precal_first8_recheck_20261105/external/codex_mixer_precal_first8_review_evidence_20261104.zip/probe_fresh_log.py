"""Independent synthetic log grammar tests; no simulator or host execution."""
import json,pathlib,sys
R=pathlib.Path(__file__).resolve().parent
sys.path.insert(0,str(R/'received/scripts'))
import mixer_precal_observe as O
import mixer_precal_prepare as P

def logtext(runs):
    step=0;rows=['LIGGGHTS synthetic fixture -- not a real run']
    for n in runs:
        rows.extend(['Step Atoms KinEng c_rke Volume',f'{step:8d} 100000 0.0000e+00 0 1.0e-6'])
        step+=n
        rows.extend([f'{step:8d} 100000 1e-10 0 1.0e-6',f'Loop time of 0.01 on 20 procs for {n} steps with 100000 atoms','Pair  time (%) = synthetic'])
    return '\n'.join(rows)+'\n'

result={'pin':'189930cc68b6e58beb6b4546d80353dc03852195','scope':'log helper only, synthetic fixed-deck endpoint rows, no process/rank/same-run certification','cases':[]}
for cid in ('PRECAL_E0','PRECAL_R1_B1_U'):
    item=P.prepare_case(cid);runs=P.rb.read_deck(item['deck'].decode())['runs']
    good=logtext(runs)
    row={'case':cid,'runs':runs,'positive':O._log_contract(good.encode(),runs),'negative':[]}
    end=sum(runs)
    bads={
      'error_suffix':good+'ERROR on proc 0: synthetic interruption\n',
      'error_prefix':'ERROR: previous failed launch\n'+good,
      'resume_marker':'RESUME_STEP 1\n'+good,
      'read_restart':'  read_restart old.bin\n'+good,
      'full_concatenation':good+good,
      'unfinished_new_thermo':good+'Step Atoms KinEng c_rke Volume\n',
      'wrong_last_endpoint':good.replace(f'{end:8d} 100000 1e-10',f'{end-1:8d} 100000 1e-10'),
      'wrong_first_run_count':good.replace('for 1 steps','for 2 steps',1),
      'missing_headers':good.replace('Step Atoms KinEng c_rke Volume\n',''),
      'nonfinite':good.replace('1e-10','nan'),
      'extra_column':good.replace('1e-10 0 1.0e-6','1e-10 0 1.0e-6 99'),
      'missing_final_loop':good.rsplit('Loop time',1)[0],
    }
    for name,text in bads.items():
        try:O._log_contract(text.encode(),runs)
        except O.Tech as exc:row['negative'].append({'case':name,'status':'TECH','reason':str(exc)})
        else:raise AssertionError((cid,name))
    result['cases'].append(row)
(R/'fresh_log_probe_results.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'positive_cases':len(result['cases']),'negative_log_mutations':sum(len(r['negative']) for r in result['cases']),'status':'PASS'}))

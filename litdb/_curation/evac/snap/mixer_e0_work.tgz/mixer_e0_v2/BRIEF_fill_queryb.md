# 지시서 — 믹서 E0 등록 초안에 보충 조회 (q9b · q2b · q7b) 결과 채우기 (11-13 아침 · 문서만 · 결과 0 건 · 발사 · 재봉인 없음)

## 0. 입력 (읽기만)

- 등록 초안 `…/scratchpad/mixer_e0_v2/e0_pilot_registration_draft.md` (2 회차 고침 판) · `changes.md` · `review/disposition2.md` · 13 · 13-1 절 (q9b · q2b · q7b 정의) · 18 절 2 회차 표 (Q-F′ · Q-G′ · Q-K)
- 조회 결과 (1저자 11-12 22:08 UTC ibb 실행 · 가린 사본): `…/scratchpad/intake/mixer_queryb_20261112T220855Z/` — `x/` (풀린 out/) · `summary.json` · `reader.log` (판독기 `…/mixer_e0_v2/query_block_b/read_query_bundle_b.py` rc 0 · 묶음 sha256 d426fe98988fad0b58690b116af23d785dd72ce9b239356573dcd22a9ea385f4 · 스크립트 md5 3c0a612028d16692625c264224a573fc)
- 11-10 조회 (비교용): 리포 `docs/data/mixer_e0_meta_ibb_20261110/`

## 1. 할 일

1. 고치기 전 판을 `e0_pilot_registration_draft_before_queryb.md` 로 복사 (있으면 멈춤).
2. 13-1 절에 결과를 **관측 사실로만** 적는다 (센 수 · 꼴 · 해시 · 11-10 과 같음/다름 · 출처 = 위 sha256). 숫자 값 · 본문은 옮기지 않는다 (조회가 옮기지 않은 것).
3. 결과에 기대는 자리를 맞춘다: 7-3 C3 전제 (r1 프레임 셋 = 끝 개행 · 개행 = 9 + 원자 · TIMESTEP 꼴) · first8 관측기 계약 (q9b 비-행 꼴이 허용 꼴 ③ 안 · 보고 쌍 표 = 덱 기대) · W9 기준 (q7b 요약 = 발사 직전 · T9 직후 `--q7b-ref` 기준) · [추정] 표지 가운데 이 결과로 확인된 것만 [확인 · 11-12 22:08 UTC 조회] 로 바꾸고, 확인 범위 밖 (예: q2b 는 r1 세 장만 · 다른 런 · 다른 프레임) 은 한정 문장으로 남긴다.
4. **결과 전 규칙 · 문턱 · 판정선은 바꾸지 않는다.** 결과가 어떤 결정을 바꾸게 되면 바꾸지 말고 "1저자 결정 필요" 로 처분표에 적는다.
5. 리포 반입 준비 (스크래치에만): `…/mixer_e0_v2/commitP_stage/` 에 리포에 넣을 자리 꼴 그대로 — `docs/data/mixer_e0_queryb_ibb_20261112/` (block/query_block_b.txt · out/ (가린 사본 그대로) · reader_summary.json · README.md (실행 시각 · sha256 · md5 · 판독기 rc · 한정 = 관측일 뿐 · 자격 · 봉인 · GO 아님)). 홈 · 계정 · 호스트 · 노드 · 주소 문자열이 남지 않았는지 다시 grep.
6. 처분 `fill_queryb_disposition.md` (바뀐 줄 · 행 번호 · 확인된 [추정] · 남은 한정 · 1저자 결정 필요 항목 (없으면 없음)).

## 2. 규칙

- 리포 `/home/user/Yonghoon-DEM-DFT` 는 읽기만 · git 명령 금지. GIT_DIR · GIT_WORK_TREE · GIT_INDEX_FILE 을 export 하거나 명령 앞에 붙이지 않는다.
- ibb 나 원격 기계 접속 없음. 주소 · 포트 · 계정 · 홈 경로 · 노드 이름 값을 쓰지 않는다. Artifact 도구 · 웹 게시 · 시스템 패키지 설치 · 시스템 설정 변경 금지.

## 3. 답장

8 줄 안팎: 바뀐 절 · 확인된 [추정] 수 · 남은 한정 · 1저자 결정 필요 항목 · 반입 준비 파일 수 · 가림 grep 결과 · 산출 파일 전체 경로.

"""Read-only package review. Every subprocess.run is mocked before module import.

No scheduler, MPI, simulator, WSL, SSH or other process is invoked by this probe.
Filesystem capacities are synthetic because the reviewer runs on Windows.
"""
import contextlib
import hashlib
import io
import json
import os
import pathlib
import runpy
import subprocess
import sys
import tempfile
import types
from unittest.mock import patch

BASE = pathlib.Path(__file__).resolve().parents[2]
PACKAGE = BASE / 'package'
REVIEW = PACKAGE / 'docs/reviews/mixer_first8_launch_preparation_20261106'
OUT = pathlib.Path(__file__).resolve().parent

def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()

def fixture(root):
    case = root / 'case'
    case.mkdir()
    c = dict(execution_authorized=True, gate='QUALIFICATION_PILOT_GO', case='PRECAL_E0',
             np=20, case_dir=str(case), wave_release=['PRECAL_E0'],
             author_choices_confirmed=True, minimum_free_bytes=100, minimum_free_inodes=10)
    def seal(name, data):
        p = root / name
        p.write_text(data)
        return {'path': str(p), 'sha256': sha(p)}
    for k in ('author_go', 'qualification', 'mxd2r_disposition', 'live_preflight',
              'runner', 'binary', 'mpi_launcher'):
        c[k] = seal(k, 'SYNTHETIC LOCAL REVIEW DATA; NOT AN EXECUTABLE')
    c['policy'] = seal('policy', json.dumps(dict(execution_authorized=True,
                                               allowed_to_submit=['PRECAL_E0'])))
    files = []
    for name in ('in.mixer', 'deck_meta.json', 'Drum.stl', 'Front.stl', 'Back.stl'):
        p = case / name
        p.write_bytes((REVIEW / 'planned_assets/PRECAL_E0' / name).read_bytes())
        files.append({'path': str(p), 'sha256': sha(p)})
    src = root / 'synthetic_source.txt'
    src.write_text('SYNTHETIC SOURCE ONLY')
    files.append({'path': str(src), 'sha256': sha(src)})
    start = root / 'job_start.py.txt'
    start.write_bytes((REVIEW / 'job_start.py.txt').read_bytes())
    files.append({'path': str(start), 'sha256': sha(start)})
    c['source_manifest'] = seal('manifest.json', json.dumps({'files': files}))
    ap = root / 'approval.json'
    ap.write_text(json.dumps(c))
    (case / 'submission.claim.json').write_text(json.dumps({'approval_sha256': sha(ap)}))
    return c, case, ap, start

def probe(mode):
    with tempfile.TemporaryDirectory(dir=OUT) as td:
        root = pathlib.Path(td)
        c, case, ap, start = fixture(root)
        cap = types.SimpleNamespace(f_bavail=1000, f_frsize=4096, f_favail=100)
        env = {'SLURM_NTASKS': '20', 'SLURM_JOB_ID': '12345',
               'SLURM_JOB_PARTITION': 'cpu', 'SLURM_JOB_QOS': 'cpu-60',
               'SLURM_CPUS_PER_TASK': '1'}
        if mode == 'rank_19': env['SLURM_NTASKS'] = '19'
        elif mode == 'non_slurm': env.pop('SLURM_JOB_ID')
        elif mode == 'wrong_qos': env['SLURM_JOB_QOS'] = 'unapproved-qos'
        elif mode == 'wrong_partition': env['SLURM_JOB_PARTITION'] = 'unapproved-partition'
        elif mode == 'cpus_per_task_4': env['SLURM_CPUS_PER_TASK'] = '4'
        elif mode == 'array': env.update(SLURM_ARRAY_JOB_ID='12344', SLURM_ARRAY_TASK_ID='0', SLURM_ARRAY_TASK_COUNT='8')
        elif mode == 'disk_low': cap.f_bavail = 0
        elif mode == 'inode_low': cap.f_favail = 0
        elif mode.startswith('fresh_'): (case / mode.removeprefix('fresh_')).write_text('OLD OUTPUT')
        elif mode.startswith('drift_'):
            key = mode.removeprefix('drift_')
            p = pathlib.Path(c[key]['path']) if key in c else (root / key if key == 'synthetic_source.txt' else case / key)
            p.write_text('CHANGED AFTER SEAL')
        elif mode == 'claim_drift': (case / 'submission.claim.json').write_text(json.dumps({'approval_sha256':'0'*64}))
        elif mode == 'approval_drift': ap.write_text(json.dumps(dict(c, np=19)))
        elif mode == 'missing_floor':
            c.pop('minimum_free_inodes')
            ap.write_text(json.dumps(c))
            (case / 'submission.claim.json').write_text(json.dumps({'approval_sha256':sha(ap)}))
        # Patch before run_path, and keep the same patch through main().
        with patch.object(subprocess, 'run', return_value=types.SimpleNamespace(returncode=0)) as mock_run:
            ns = runpy.run_path(str(start))
            with patch.dict(os.environ, env, clear=True), patch.object(sys, 'argv', ['job_start', str(ap)]), patch.object(os, 'statvfs', return_value=cap, create=True):
                try:
                    result = ns['main']()
                    error = None
                except Exception as exc:
                    result = None
                    error = type(exc).__name__ + ': ' + str(exc)
            return {'case': mode, 'returncode': result, 'error': error,
                    'mock_mpi_calls': mock_run.call_count,
                    'job_end_prior_content_preserved': mode != 'fresh_job_end.json' or (case/'job_end.json').read_text() == 'OLD OUTPUT'}

MODES = ['baseline', 'rank_19', 'non_slurm', 'claim_drift', 'approval_drift', 'missing_floor',
         'disk_low', 'inode_low', 'drift_binary', 'drift_mpi_launcher', 'drift_policy', 'drift_runner',
         'drift_in.mixer', 'drift_deck_meta.json', 'drift_Drum.stl', 'drift_Front.stl', 'drift_Back.stl',
         'drift_synthetic_source.txt', 'fresh_post', 'fresh_restart', 'fresh_log.liggghts',
         'fresh_job_start.json', 'fresh_simulator.stdout', 'fresh_simulator.stderr',
         'wrong_qos', 'wrong_partition', 'cpus_per_task_4', 'array', 'fresh_job_end.json']

if __name__ == '__main__':
    rows = [probe(mode) for mode in MODES]
    payload = {'python': sys.version, 'source_sha256': sha(REVIEW/'job_start.py.txt'),
               'subprocess_policy':'mocked before run_path and through main, no real subprocess calls',
               'statvfs_policy':'synthetic values; Windows has no statvfs', 'results':rows}
    (OUT/'probe_jobstart_results.json').write_text(json.dumps(payload, indent=2)+'\n')
    print(json.dumps(payload, indent=2))

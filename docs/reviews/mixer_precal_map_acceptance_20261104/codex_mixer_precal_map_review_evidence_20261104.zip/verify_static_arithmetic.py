"""Read-only archive verification and independent scalar planning arithmetic.
Never imports or executes supplied generator/readers or reads research data.
"""
from pathlib import Path,PurePosixPath
import zipfile,hashlib,json,csv,io,math,collections
ROOT=Path(__file__).resolve().parent
PIN='d0107959955f284df56cb546ee008595d26dac61'
NAME='codex_mixer_precal_map_draft_20261104_d0107959955f.zip'
SHA='e64340eb1391f19cbf27f482d36bae0b19de0ab07c98b2bfdb67e13e6fc0a477'
def require(x,msg):
 if not x:raise ValueError(msg)
def main():
 zb=(ROOT/'input'/NAME).read_bytes();require(hashlib.sha256(zb).hexdigest()==SHA,'input ZIP differs')
 remote=json.loads((ROOT/'remote_pin.json').read_text(encoding='utf-8'))
 require(remote['pin']==PIN,'remote pin differs')
 rm={e['path']:e for e in remote['entries']}
 with zipfile.ZipFile(io.BytesIO(zb)) as z:
  names=z.namelist();require(len(names)==len(set(n.casefold() for n in names)),'duplicate names')
  for e in z.infolist():
   n=e.filename;p=PurePosixPath(n)
   require(not p.is_absolute() and '..' not in p.parts and ':' not in n and '\\' not in n,'unsafe path')
   require((e.external_attr>>16)&0o170000!=0o120000,'symlink')
  require(z.read('PIN.txt').decode().strip()==PIN,'PIN.txt differs')
  manifest=json.loads(z.read('SNAPSHOT_MANIFEST.json'));require(manifest['pin']==PIN,'manifest pin differs')
  snapshot=[]
  for e in manifest['entries']:
   b=z.read(e['path']);blob=hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
   require((len(b),hashlib.sha256(b).hexdigest(),blob)==(e['bytes'],e['sha256'],e['git_blob']),'snapshot differs: '+e['path'])
   r=rm[e['path']];require((len(b),blob)==(r['bytes'],r['git_blob']),'remote differs: '+e['path'])
   snapshot.append(e['path'])
  require(set(snapshot)==set(rm) and len(snapshot)==22,'snapshot set differs')
  package=[]
  for line in z.read('PACKAGE_SHA256SUMS').decode().splitlines():
   h,n=line.split('  ',1);n=n[2:] if n.startswith('./') else n
   require(hashlib.sha256(z.read(n)).hexdigest()==h,'package checksum differs')
   package.append(n)
  require(len(package)==len(set(package))==33 and set(names)-set(package)=={'PACKAGE_SHA256SUMS'},'package coverage differs')
  sop=z.read('docs/reviews/mixer_d3_measurement_sop_draft_20261104.md')
  require(hashlib.sha256(sop).hexdigest()=='dde2857a41b847fbb1f1888588a6ddc0331aa71dfd08ad40f02618ce1bddcc38','previous accepted SOP changed')
  base='docs/reviews/mixer_precal_map_draft_evidence_20261104/'
  cells=list(csv.DictReader(io.StringIO(z.read(base+'proposed_cells.tsv').decode()),delimiter='\t'))
  provided=json.loads(z.read(base+'planning_arithmetic.json'))
  source_basis=json.loads(z.read(base+'source_basis.json'))
  for e in source_basis['source_files']:
   b=z.read(e['path']);require(len(b)==e['bytes'] and hashlib.sha256(b).hexdigest()==e['sha256'],'source basis mismatch')
 counts=collections.Counter(r['role'] for r in cells);phases=collections.Counter(r['phase'] for r in cells)
 require(len(cells)==len({r['proposal_id'] for r in cells})==20,'cell identity/count differs')
 require(counts=={'U':9,'C':9,'rotating_negative_control':1,'settling_normalizer':1},'roles differ')
 require(phases=={'first8':8,'remaining12':12},'phase counts differ')
 require({r['seed_proposed'] for r in cells}=={'32452843'},'seed differs')
 require({r['NP_proposed'] for r in cells}=={'20'},'NP differs')
 groups=collections.defaultdict(list)
 for c in cells:
  if c['role'] in ('U','C'):groups[(float(c['bo_code_proposed']),float(c['rho_uncoated_proposed']))].append(c)
 require(set(groups)=={(b,r) for b in (.21244,21.244,212.44) for r in (.10,.35,.50)},'grid differs')
 for (b,r),pair in groups.items():
  require({c['role'] for c in pair}=={'U','C'} and len(pair)==2,'U/C pair differs')
  for c in pair:
   require(math.isclose(float(c['gamma_wall_over_SE_proposed']),.0256*r,rel_tol=1e-14),'wall differs')
   require(float(c['gamma_AM_over_SE_proposed'])==(r if c['role']=='U' else 1.),'surface value differs')
   require(c['revolutions_proposed']=='2','turns differ')
   require(c['phase']==('first8' if r==.1 else 'remaining12'),'phase selection differs')
 B=(.21244,21.244,212.44);rs=(.10,.35,.50)
 # Geometry from supplied source diameters 9:4:1. Standalone algebra, no source imports.
 factors={label:2*q/(q+1) for label,q in [('AM_P',9.),('AM_S',4.)]}
 thresholds={label:1/a**2 for label,a in factors.items()}
 force=[{'r':r,**{label:a*math.sqrt(r) for label,a in factors.items()},'gamma_wall':.0256*r,
         'C_over_U_AM_AM_force':1/r,'C_over_U_AM_SE_and_AM_WALL_force':1/math.sqrt(r),
         'C_over_U_SE_SE_and_SE_WALL_force':1.} for r in rs]
 for x,p in zip(force,provided['force_ratios_illustrative']):
  for k in ('AM_P','AM_S','gamma_wall'):require(math.isclose(x[k],p[k],rel_tol=1e-13),'force arithmetic differs')
 # Rounded planning constants, not measured throughput or emitted deck qualification.
 D=.0251665;rpm=76.6765;dt=2.372897e-7;e=.3
 settle=2*math.sqrt(2*D/9.81)*(1+e)/(1-e)
 rotate=2*60/rpm
 nsettle=settle/dt;ntotal=(settle+rotate)/dt
 duration=[ntotal/v/3600 for v in (70,63)]
 reference=[nsettle/v/3600 for v in (70,63)]
 first_slot=[7*t+r for t,r in zip(duration,reference)]
 all_slot=[19*t+r for t,r in zip(duration,reference)]
 first_wave=[4*t for t in duration];all_wave=[10*t for t in duration]
 checks={'steps_total_estimate':ntotal,'settling_steps_estimate':nsettle,'settling_time_s_estimate':settle,'rotation_time_s_estimate':rotate}
 for k,v in checks.items():require(math.isclose(v,provided[k],rel_tol=1e-13),'time arithmetic differs '+k)
 for key,slots,wave in [('phase1',first_slot,first_wave),('whole_map',all_slot,all_wave)]:
  for field,values in [('slot_hours_estimate',slots),('core_hours_estimate',[20*v for v in slots]),('two_slot_baseline_then_pair_waves_hours',wave)]:
   require(all(math.isclose(a,b,rel_tol=1e-13) for a,b in zip(values,provided[key][field])),'budget differs')
 return {'pin':PIN,'zip_sha256':SHA,'snapshot_and_remote_entries':22,'package_entries':33,
   'previous_note01_SOP_unchanged':True,'source_basis_files_match':len(source_basis['source_files']),
   'cohort':{'unique_jobs':20,'roles':dict(counts),'phases':dict(phases),'U_C_pairs':len(groups),'seed':32452843,'reserved_seeds_assigned':False},
   'scalar_arithmetic':{'force_geometric_factors':factors,'equal_force_r':thresholds,'force_rows':force,'bo_po':[b/6.75 for b in B],
    'C_particle_forces_across_r_at_fixed_B':'identical; wall force changes with sqrt(r)',
    'C_wall_force_ratio_r05_over_r01':math.sqrt(5),
    'settling_seconds':settle,'rotation_seconds':rotate,'total_steps_continuous_estimate':ntotal,'settling_steps_continuous_estimate':nsettle,
    'rotating_hours_at_70_63_steps_s':duration,'reference_hours_at_70_63_steps_s':reference,
    'first8_slot_hours':first_slot,'first8_core_hours':[20*v for v in first_slot],'first8_two_slot_wave_hours':first_wave,
    'whole20_slot_hours':all_slot,'whole20_core_hours':[20*v for v in all_slot],'whole20_two_slot_wave_hours':all_wave,
    'M_proposed_geometric_radius_m':D/2,'M_historical_cli_default_radius_m':.02056,
    'M_radius_ratio_default_over_proposed':.02056/(D/2)},
   'scope':'Archive identity + independent static algebra/counts only. Not code execution, simulation, geometry/solver qualification, statistical or physical certification.',
   'reviewed_modules_imported_or_executed':False,'whole_gate':'HOLD','execution_authorized':False}
if __name__=='__main__':print(json.dumps(main(),ensure_ascii=False,indent=2))


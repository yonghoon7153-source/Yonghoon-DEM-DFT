# PRECAL-NOTE01 두 문장·수령 기록 확인 — 2026-11-04

**판정: 두 문장 반영 및 수령 기록 범위 수용. 새 P1/P2/P3 발견 없음.**

- 새 확인 핀: `0f284e7db65278acb52dd4666b1b22151604e9ba`, `codex/mixer-1104`.
- 이전 수용 핀: `d0107959955f284df56cb546ee008595d26dac61`.
- 받은 ZIP SHA-256: `149884c16a1024cd9fa7e377fc8d52d12ad4851bc065d1ee8fa57bafe2b6bdbc`.

| 요청 항목 | 독립 확인 결과 |
|---|---|
| 정확한 전사 | 새 등록 초안 §2 표 뒤 **26행**의 두 문장이 이전 외부 판정 §4의 비차단 제안과 정확히 일치 |
| 초안 보존 | 두 문장·빈 줄 **301 bytes**를 제거하면 **16,710 bytes → 16,409 bytes**, 이전 수용본과 바이트 단위 동일 |
| 다른 고정물 | 조건표·비용 산술·실험 뼈대·D3 SOP·관련 코드 등을 포함한 기존 snapshot의 **나머지 21개 파일 모두 바이트 동일** |
| 기존 벽 규칙·해석 | 같은 벽 γ와 같은 AM–벽 힘을 구분하고, 고정 B의 C 팔 간 r 차이는 벽 조건이라는 한정을 유지. 벽 규칙·팔·제안값을 변경하지 않음 |
| 원본 증거 | 이전 증거 ZIP SHA-256 `44c464e241458c8b3a7a1510e8aa93cca9a96eeef8e7d46aa97f940e40f13608` 일치. 판정문·범위 JSON·독립 결과도 원본 바이트 그대로 |
| 새 전달물 신원 | PIN.txt는 새 핀, EXTERNALLY_ACCEPTED_PIN.txt는 이전 핀으로 구분. 새 snapshot 32개를 실제 바이트·해시 및 원격 고정 핀의 Git blob·크기와 대조. 포장 해시 45개 일치. 포함되는 수이므로 합산하지 않음 |

추가분 제거 후 초안 SHA-256은 이전의 `287602d9b3d96b7f6c410cb36ffda31417690037e29dc663b512082eb61d5639`이며, 새 초안은 `1e21ea3b8bee8eef87dd08d8ef395f434d73fe824ea429c347548de08530ab0c`다. [새 핀의 추가 문장](https://github.com/yonghoon7153-source/Yonghoon-DEM-DFT/blob/0f284e7db65278acb52dd4666b1b22151604e9ba/docs/reviews/mixer_precal_exploration_registration_draft_20261104.md#L26)

수령 README:3,15와 disposition.json:2,8–20은 **이전 핀의 수용 / 새 핀 확인 대기 / 저자 Q1–Q4 미결정 / 실제 구현·실행 자격 미완료**를 구분한다. README:19–21의 반경·분율 주의점도 후속 자격 목록이며 구현 완료나 새 등록값으로 표시하지 않았다. 등록·실험·연구 실행·배포·통합·원장 종결로 확대된 문구는 찾지 못했다. [수령 기록](https://github.com/yonghoon7153-source/Yonghoon-DEM-DFT/blob/0f284e7db65278acb52dd4666b1b22151604e9ba/docs/reviews/mixer_precal_map_acceptance_20261104/README.md)

이번에는 기존 Q1–Q6 감사·산술 재계산·생성기/판독기/시험/전체 게이트 실행을 반복하지 않았다. 파일 바이트 대조와 두 문장의 의미·수령 경계만 확인했으며 실제 기계·연구 원자료에 접근하지 않았다. 기존 공유 원장이나 원본 문서를 수정하지 않았다.

증거 ZIP의 `verify_note01_bytes.py`는 원본·추가분·기록된 원격 메타데이터를 오프라인으로 다시 대조한다. 연구 산술과 대상 코드는 실행하지 않으며, 무결성 확인을 물리·통계·실행 자격으로 해석하지 않는다.

**PRECAL-NOTE01 반영 확인 완료. 전체 HOLD · 저자 Q1–Q4 결정 대기 · 실제 실행 미승인 유지. 발송·진행 순서는 1저자, Rint② 우선.**


#!/usr/bin/env python3
"""recheck2 변이 (리뷰어 것 · 고친 쪽 시험이 옳은 이유로 실패하는가) — 트리 사본 (하드링크) 에서 파일 하나만 실제 사본으로 바꿔 한 곳을 고친 뒤 test_cjunc_store
의 해당 묶음만 돌린다.  사용: python3 mut_run.py <트리> <작업 폴더>"""
import json
import os
import shutil
import subprocess
import sys

tree, wd = sys.argv[1:3]
MUTS = [
    ('M1 파일 모드 검사 0o022 → 0o002 (그룹 쓰기 놓침 · 재리뷰 N9)', 'scripts/cjunc_store.py',
     "    if st.st_mode & 0o022:\n        raise StoreInconsistent('file_mode'", "    if st.st_mode & 0o002:\n        raise StoreInconsistent('file_mode'", 'T7'),
    ('M2 파일 모드 검사 0o022 → 0o020 (남 쓰기 놓침)', 'scripts/cjunc_store.py',
     "    if st.st_mode & 0o022:\n        raise StoreInconsistent('file_mode'", "    if st.st_mode & 0o020:\n        raise StoreInconsistent('file_mode'", 'T7'),
    ('M3 뿌리 모드 검사 0o022 → 0o020 (뿌리 남 쓰기 놓침)', 'scripts/cjunc_store.py',
     "        if st.st_mode & 0o022:\n            raise ValueError(f'저장본 폴더를", "        if st.st_mode & 0o020:\n            raise ValueError(f'저장본 폴더를", 'T11'),
    ('M4 원장 함수가 제3자 패키지 (pandas) 를 부름 (scripts/ 밖 · RCP2-05)', 'scripts/carbon_junction.py',
     "def cjunc_registry(sid, box_lo, vox, add_pts, add_phase, add_fid, add_kind, *, r_f_um, tol_ff_um, L_par_um, r_port_um,",
     None, 'T14'),
    ('M5 code_drift 의 수정 시각 갈래 끔 (내용 같은 다시 씀 놓침)', 'scripts/cjunc_store.py',
     "            if mt > s['t_ns'] + MTIME_SLACK_NS:", "            if False and mt > s['t_ns'] + MTIME_SLACK_NS:", 'T15'),
    ('M6 발행 직전 다시 셈 끔 (get_or_build 시작 검사만)', 'scripts/cjunc_store.py',
     "            _dr = code_drift()\n            if _dr:\n                return 'built_write_skipped'",
     "            _dr = []\n            if _dr:\n                return 'built_write_skipped'", 'T15'),
]
res = {}
for name, rel, old, new, only in MUTS:
    d = os.path.join(wd, 'mt_' + name.split()[0])
    if os.path.exists(d):
        shutil.rmtree(d)
    subprocess.run(['cp', '-al', tree, d], check=True)
    p = os.path.join(d, rel)
    src = open(p, encoding='utf-8').read()
    os.unlink(p)                                   # 하드링크 끊기 (원 트리 그대로)
    if new is None:                                # M4 — 함수 머리 뒤 첫 줄 앞에 import 를 넣는다 (서명 끝 '):' 찾기)
        i = src.index(old)
        j = src.index('):\n', i) + 3
        new_src = src[:j] + '    import pandas  # 변이 M4\n' + src[j:]
        n_hit = src.count(old)
    else:
        n_hit = src.count(old)
        new_src = src.replace(old, new, 1)
    open(p, 'w', encoding='utf-8').write(new_src)
    r = subprocess.run([sys.executable, os.path.join(d, 'scripts', 'test_cjunc_store.py'), '--only', only], capture_output=True, text=True,
                       timeout=900, cwd=wd, stdin=subprocess.DEVNULL)
    fails = [ln.strip()[:110] for ln in r.stdout.splitlines() if ln.startswith('  FAIL')]
    res[name] = {'hits': n_hit, 'rc': r.returncode, 'caught': bool(fails), 'fails': fails[:4],
                 'summary': [ln for ln in r.stdout.splitlines() if ln.startswith('test_cjunc_store:')][-1:]}
    print(f"{name} · 바꾼 자리 {n_hit} · rc {r.returncode} · 잡힘 {bool(fails)} · {res[name]['summary']} · {fails[:2]}", flush=True)
    shutil.rmtree(d)
json.dump(res, open(os.path.join(wd, 'mut_results.json'), 'w'), ensure_ascii=False, indent=1)

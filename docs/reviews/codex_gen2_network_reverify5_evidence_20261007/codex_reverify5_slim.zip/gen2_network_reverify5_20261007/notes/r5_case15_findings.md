# Reverify 5 case15 / Q7 / smoke consumer review

Reviewed pinned source `aa7ec7fe98e8684f1a2138665f9eba978366c229`. No production source changes, Git mutations, DEM/MPM/S3 runs, or 194 campaign. Tests below use isolated CPU raw graph analysis, synthetic producer folders, and one actual case15 CPU web pipeline with the network subprocess launch deliberately denied. All generated work is under `gen2_network_reverify5_20261007/tmp/r5_case15*`.

## Q7 judgment

The six-channel scientific diagnosis and tolerances are appropriate for this frozen fixture. All four raw SHA256 values match the committed README. Fresh local graph evaluation exactly matches the preceding local reverify4 numerical result: ionic Hertz `0.0003263508259103751`, physics `0.00036224724452177176`; 8-digit values `0.00032635` and `0.00036225`. Conservation residuals `3.0024201089821724e-9`, `6.322933781612321e-9`; equation residuals `9.838873256790492e-11`, `9.556129760264176e-11`, all well below `1e-6`.

65,970 atoms, 182,995 contacts; plate 19.1455 um, box 100 x 100 um. Electronic H/P and thermal H produce `not_computed/boundary_overlap` with B intersect T = [24,40,57,103]. Thermal physics raises `ValueError: physics_g2: 간선 (31, 29241) — ligg_area < 0 (-0.186036)`. Negative raw area rows are 31--29241 (-0.186036 um2) and 38--29241 (-0.186264 um2).

These numbers independently establish what the frozen raw network does under the solver. They do not establish that a particular pipeline attempt failed for that cause. The new producer and S0b tests leave that gap open; therefore full Q7 closure is not supported.

## New issue A: unrelated network process failure passes the fresh producer (suggest P2)

Relevant source: `scripts/wsl_network_smoke.py:322` runs the pipeline; `:328` runs the separate raw probe afterward. `:568-570` accepts any failed pipeline containing the generic Network Solver step, provided Stage E did not run and there is no returned run ID. `:576-595` tests only the separate raw probe for the cause and healthy ionic channel; it does not test the failed attempt's actual cause, process return code, or missing outputs.

Exact repro: `probes/r5_case15_pipeline_fault.py` calls original `smoke.child_case` for case15 using original frozen input files. The sole injected fault is `pipeline_service._RUNNER` raising `PermissionError` for the `network_conductivity.py` subprocess. Everything else, including staging, parsing, contact analysis, coverage, report collection, and the independent six-channel raw probe, is original code.

Observed: denied solver calls = 1; Parse/Contact/Coverage all rc0; Network Solver rc1, `ok:false`, actual attempt reason `PermissionError: r5_case15 injected solver executable denied` and missing per-mode outputs. Pipeline status failed, no active or returned run ID, tau NOT_COMPUTED. Yet original `smoke.evaluate` gives all 6 checks PASS, including all four negative-control checks. This is an ordinary execution failure, not altered reports or a forged evidence set.

Evidence: `evidence/r5_case15_pipeline_fault.json`, `.log`. Feeding this freshly generated report into original `g2_network_reread.main` with real published through/nonthrough/clamp positive folders also returns rc0, n_fail0, S0 and S0b true (`probes/r5_case15_fault_reread.py`; `evidence/r5_case15_pipeline_fault_reread.json`, `.log`).

Minimum remedy: retain and validate machine-readable evidence from the actual failed network stage, including successful process execution and the expected content/channel rejection, then use the separate raw probe as corroboration. A nonzero solver process rc / missing output / arbitrary execution exception must fail case15. Unsealed smoke code can preserve/inspect original `out['log']` fields before its 300-character projection; a sealed solver change need not be assumed. Add a denied-subprocess positive rejection regression alongside the healthy negative-control fixture.

## New issue B: S0b trusts summaries and ignores contradictory/missing details (suggest P2 or group with A)

Relevant source: `scripts/g2_network_reread.py:552` excludes any truthy `negative_control`; `:560-565` accepts four or more PASS rows sharing only a name prefix. It neither restricts the registered tag, requires distinct named checks, reruns the shared negative-control predicates, nor checks the raw-SHA result/overall smoke failure.

Positive control uses fresh real producer folders for through, nonthrough, clamp, plus actual submitted case15 detail with independently recomputed raw diagnosis. Original consumer returns rc0/n_fail0 and all normal K1--K7/H1 pass. It rejects missing marker (S0), zero/three negative checks, or one FAIL verdict (S0b), showing this is not broad overblocking.

The following isolated variants return rc0/n_fail0, S0/S0b true:

| Mutation | Fresh producer behavior / scope |
|---|---|
| marker changed to `unregistered_future_control` | Consumer excludes any truthy marker; producer does not recognize it |
| only the first negative-control PASS check repeated four times | No uniqueness/required predicate coverage |
| delete `reports.case15_network.negctl`, leave checks | Producer rejects missing cause/ionic details; consumer trusts stale summary |
| `tau_ion_hertz = 1.0`, leave checks | Producer rejects numeric leakage; consumer trusts stale summary |
| ionic physics residual = 0.1, leave checks | Producer rejects failed certificate; consumer trusts stale summary |
| `raw_sha_ok=false`, regenerate checks with original evaluate and set smoke rc1 | Consumer accepts even a fresh explicit SHA FAIL; no stale/forged summaries needed |

Repro/evidence: `probes/r5_case15.py`; `evidence/r5_case15_results.json`; per-variant `evidence/r5_case15_s0b_*.json`. Minimum remedy: exact registered tag and case role; shared producer predicates on required details; distinct required check IDs; do not let the exclusion ignore failed input identity/process checks. Require contradictory/missing detail to fail even if cached PASS rows remain. This issue is limited to smoke reread; launcher production194 v1.3 uses a different path and these probes do not show its release gate bypassed.

## What the actual submitted WSL evidence proves

Do not retroactively mark the submitted run as the injected failure. Its actual stage/attempt reason in `submitted/g2pre_smoke_839dbac6b_1007_2224/smoke_report.json` explicitly contains boundary_overlap and the thermal physics negative-area error, and its solver subprocess rc is 0 with content verification rejecting publication. Raw hashes, shape, channel outcomes, residuals, absent publication, and numeric suppression match independent local analysis. WSL last-bit CG differences remain below the chosen 8-digit tolerance. The real WSL run therefore supports the intended diagnosis; the new tests show the automated acceptance rule also accepts other causes.

The archive here contains the smoke report/reread JSON/summary but not the smoke work/results or upload folders, so independent local K1--K7 re-read of those original WSL published files is unavailable. Normal controls above use real synthetic publication folders. The actual smoke command uses `--skip-real14-general`; its real14 test covers network stop, not new real14 Stage E execution. Do not claim an added Stage E WSL proof.

## Reproduction environment

Python `C:/Users/Administrator/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe -B`; PYTHONPATH = workspace `lhs_coverage_review_20260930/deps;gen2_network_reverify3_20261007/deps`; BLAS/OpenMP threads = 1; each probe adds pinned source scripts/webapp. Run `r5_case15.py`, then `r5_case15_pipeline_fault.py`, then `r5_case15_fault_reread.py`. Probes preserve generated evidence and use unique temp directories; source/submitted are read-only. The initial missing deck was subsequently supplied by parent from pinned verified Git blob `72481a3f3fb4a1b6bb5af00f20efac58a9dd636b`; final successful runs verify all four original input SHA256 values.

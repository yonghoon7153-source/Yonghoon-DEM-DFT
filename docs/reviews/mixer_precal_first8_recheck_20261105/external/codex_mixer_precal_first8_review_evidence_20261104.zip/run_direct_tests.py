import pathlib,subprocess,json,sys
root=pathlib.Path(__file__).resolve().parent
(root/'scratch').mkdir(exist_ok=True)
results=[]
for name in ('test_mixer_precal_prepare.py','test_mixer_precal_observe.py'):
    bootstrap='import sys,tempfile,runpy;sys.path.insert(0,sys.argv[1]);tempfile.tempdir=sys.argv[2];target=sys.argv[3];sys.argv=[target];runpy.run_path(target,run_name="__main__")'
    cmd=[sys.executable,'-I','-X','utf8','-B','-c',bootstrap,str(root/'received/scripts'),str(root/'scratch'),str(root/'received/scripts'/name)]
    p=subprocess.run(cmd,capture_output=True,cwd=root/'received',timeout=120)
    (root/(name+'.stdout.log')).write_bytes(p.stdout)
    (root/(name+'.stderr.log')).write_bytes(p.stderr)
    results.append({'test':name,'command':cmd,'returncode':p.returncode,'tail':p.stderr.decode('utf8',errors='replace')[-750:]})
(root/'direct_test_results.json').write_text(json.dumps({'python':sys.version,'results':results},indent=2)+'\n')
print(json.dumps(results,indent=2))

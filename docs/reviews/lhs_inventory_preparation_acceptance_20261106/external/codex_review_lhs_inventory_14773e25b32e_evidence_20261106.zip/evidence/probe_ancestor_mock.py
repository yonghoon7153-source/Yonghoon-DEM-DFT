"""Local model of stat/open timing; NOT a POSIX/filesystem/CLI qualification.
Uses selected unchanged producer function ASTs; all directory/log operations mocked.
"""
import ast
import errno
import json
import pathlib
import stat
import sys
import types

BASE = pathlib.Path(__file__).resolve().parent.parent
SOURCE = BASE / 'package/docs/reviews/lhs_inventory_execution_preparation_20261106/pressure_inventory.sh'
code = SOURCE.read_text(encoding='utf8').split("exec python3 -I -B -c '\n", 1)[1].rsplit("\n' \"$@\"", 1)[0]

class FakeOS:
    O_RDONLY = 0
    O_DIRECTORY = 1
    O_NOFOLLOW = 2
    O_CLOEXEC = 4
    def __init__(self, inject):
        self.inject = inject
        self.version = 0
        self.fds = {}
        self.nextfd = 10
        self.operations = []
        self.path = types.SimpleNamespace(realpath=lambda p: p)
    def snapshot(self, name):
        version = self.version if name == 'shared' else 0
        return types.SimpleNamespace(st_dev=1, st_ino=1, st_mode=stat.S_IFDIR | 0o700,
            st_size=version, st_mtime_ns=version, st_ctime_ns=version, st_uid=1, st_gid=1)
    def stat(self, name, **kwargs):
        self.operations.append(['stat',name])
        return self.snapshot(name)
    def open(self, name, flags, **kwargs):
        if name == 'shared' and self.inject:
            self.version += 1
            self.operations.append(['injected_metadata_change',name])
        fd = self.nextfd
        self.nextfd += 1
        self.fds[fd] = name
        return fd
    def fstat(self, fd):
        return self.snapshot(self.fds[fd])
    def close(self, fd):
        del self.fds[fd]

def run(inject, remove_guard):
    source = code.replace('if stamp(before) != stamp(os.fstat(fd)):', 'if False:') if remove_guard else code
    tree = ast.parse(source)
    needed = {'Refusal','error_code','stamp','open_dir','plan','inventory'}
    tree.body = [n for n in tree.body if isinstance(n,(ast.ClassDef,ast.FunctionDef)) and n.name in needed]
    fs = FakeOS(inject)
    ns = {'os':fs, 'stat':stat, 'sys':sys, 'errno':errno}
    exec(compile(tree,'selected_sealed_functions','exec'),ns)
    def open_root(path):
        fd, _ = ns['open_dir'](0,'shared')
        child, before = ns['open_dir'](fd,path)
        fs.close(fd)
        return child,path,before
    ns['open_root'] = open_root
    ns['verify_dir'] = lambda *args: None
    ns['scan_log'] = lambda *args: {'status':'COUNTED','bytes':0,'b7_matches':0,
       'pressure_prefix_malformed':0,'read_restart_echo_lines':0,'reading_restart_message_lines':0}
    ns['count_out'] = lambda *args: {'status':'ABSENT','regular_files':0}
    ns['B7_SOURCE_SHA256'] = 'mock_not_a_production_attestation'
    result = ns['inventory']('wsl',{'local':'local'})
    return {'inject':inject,'guard_removed':remove_guard,'status':result['status'],'rc':result['rc'],
            'roots':result['roots'],'counted_cases':result['counted_cases'],
            'rows':len(result['cases']),'reasons':sorted({r.get('reason','') for r in result['cases']}),
            'open_descriptors_after':len(fs.fds)}

observations = [run(False,False),run(True,False),run(True,True)]
assert [o['rc'] for o in observations] == [0,2,0]
assert observations[1]['roots'] == {'local':'CHANGED'}
assert observations[1]['counted_cases'] == 0 and observations[1]['rows'] == 30
assert observations[1]['reasons'] == ['CHANGED']
assert all(o['open_descriptors_after'] == 0 for o in observations)
result = {'scope':'small mocked metadata interleaving; no real filesystem traversal, research paths, CLI or POSIX qualification',
          'unchanged_selected_source_functions':['Refusal','error_code','stamp','open_dir','plan','inventory'],
          'observations':observations}
print(json.dumps(result,ensure_ascii=False,indent=2))

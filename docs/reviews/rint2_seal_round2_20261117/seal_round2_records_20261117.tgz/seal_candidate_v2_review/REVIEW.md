# Rint ② 봉인 후보 v2 — 독립 반박 리뷰 (내부 반박 리뷰 · **Codex 아님** · 11-17)

- **대상** = scratch `rint/seal_candidate_v2/` (README v2 253 줄 · `make_sealed_copy.py` sha256 ebf95e0d… · 조각 둘 · `plan_candidate.json` · `build_20261120/` · `evidence/`) + 봉인 꼴 커밋 묶음 `seal_form_Gprime_20261117.bundle` (가지 `seal-form-scratch` = **G′ `bea3cb33a`** · 부모 = 코드 핀 `64e4d213e`).  후보 폴더 · v1 은 고치지 않았다.
- **방법** = 고친 사람 설명을 믿지 않고 scratch `clone --shared` 사본 (G′ sparse checkout · 원격 추적 ref = 본 리포 `refs/remotes/origin/*` 153 개 이름 · 객체 같게 다시 받음) 에서 `python3 -I` 로 다시 쟀다.  리포 · stoic-next 쓰기 0 · σ 열람 0 · 신호 실험 0.  Python 3.11.18 · git 2.43.0 · flock 2.39.3.
- **표지**: [실측] = 이 리뷰가 scratch 에서 돌림 · [코드] = 핀 판 코드 읽기 · [기록] = 문서 · 후보 증거 · [추정] · [미확인].
- **등급** (1저자 11-16 Q2): P1 = 보고 숫자 · 봉인 값 · 주장이 바뀌거나 정직한 흐름에서 틀린 결과를 받아들이는 길 → 봉인 보류 · P2 · P3 = 알려진 한계로 적고 진행.

## 요약

**P1 0 · P2 2 · P3 12.**  봉인 값 (u · tol_ff · tol_P · tol_sj · S0 해시 · 계획 칸 · maxiter · 168 h · 8 · 기계 · env_unit) 과 봉인 꼴 (봉인본 · 원본 자리 표지 · 명령 문서 · 계획) 의 숫자는 다시 잰 범위에서 다 맞다.  깨진 것은 **증거 도구의 지킴 범위** (③ argparse 도구가 꼴이 다른 줄을 조용히 빼고 rc 0 · 봉인본 만드는 도구가 계획이 실제로 돌 수 있는지 안 본다) 이고, 어느 쪽도 틀린 결과로 가는 길이 아니다 (빠진 인자 · 틀린 계획은 사슬 · S0 관문이 결과 전에 멈춘다 [실측 · 코드]).  **권고 = 봉인 보류 안 함** — P2 둘은 봉인 때 도구를 다시 돌리기 전에 고치거나 README 한정에 적는다.

## 이 리뷰가 닫는 것 / 닫지 않는 것

| 닫는 것 (G′ 에서 다시 잼) | 닫지 않는 것 |
|---|---|
| 도구 재생성 = 후보 `build_20261120/` 와 리포 출력 넷 바이트 같음 · 같은 입력 두 번 같음 · selftest 17/17 · 변이 34 (거부 19 · 통과 15) | 사슬 시험 전체 506 (재실행 안 함 · 후보 증거 [기록] · 대신 문서를 읽는 K01 · PC18 · PC20 · EP06 · S16 · C03 다시 = 6/6) |
| plan-doc `--check-doc` 봉인본 rc 0 · 기본 rc 3 · 사슬 함수 (해시 두 줄 · 블록 · 두 계획 대조 · 넷 멈춤) | 리포 게이트 전체 `scripts/check_all.sh` · `test_rint_r_chain_e2e.py` 전체 · `test_rint_r_chain_e2e12.py` [미확인 · 후보와 같음] |
| S0 단계 2 관문 — 후보 · 기본 경로 거부 + **틀린 tol_ff · len_law · env_unit 후보 다섯 커밋** | 현장 (두 기계 · flock · git 판 · venv · 디스크) = [기록 · 1저자 출력] 그대로 |
| 두 문서 sh 블록 사슬 · S0 명령 — 후보 도구 + 독립 셈 (울타리별) + 도구 변이 11 | 결과 전 등록 넷 값 · 봉인 날짜 · 가지 · 감도 경로 (⬜ 그대로) |
| 경계 (다섯 경로 · CODE_FILES 20 · S0 일곱 · 규율 검사 입력) · 자료 폴더 blob 40/40 · claims.json 두 판 json 대조 | 시간 어림 값 자체 (3 판 산술만 다시) |
| 규율 검사 0 오류 (17 경고) · check_doc_refs rc 0 · 철회값 스윕 (바뀐 파일 83 · sparse 1,479 파일) · test_probe6_read 357 · test_ca_ext_z3 84 · test_ca_s0_census 186 · E17 1 | 중간 커밋 A · B · B2 · F · G 사이 차이 (묶음에 없음 · 객체 없음 [실측 cat-file]) |
| 원장 넘김 블록 (§3-1b (5) 줄 그대로) 흉내 — 정상 A→B→A · 받는 쪽 창 | 두 기계 · 실제 전송 · 재부팅 |

## 지적표

### P1 — 없음

P1 후보로 끝까지 본 것: ① 빠진 `--registration` · `--r-doc` 가 틀린 결과로 가는 길 (없음 — 사다리 · 예측 · 합치기 · 판정 · plan-doc · S0 단계 2 가 결과 전에 멈춤 [실측 S16 · C03 · plan-doc rc 3 · 관문 거부] · ledger · recover 는 인자를 읽지 않고 · 다시 판정은 판정 JSON 의 기록 경로를 읽는다 [코드 8260 줄]) ② 두 기계 절대 경로가 달라 생기는 대조 깨짐 (없음 — 단계 요약의 `registration` 칸은 쓰기만 하고 어느 단계도 대조하지 않는다 [코드 grep] · 코드 키 = 저장소 상대 경로 + env_unit [코드 1906 줄]) ③ 원장 넘김 창에서 틀린 결과 (없음 — 사람 대조 + 합치기 단계가 결과 줄 없는 시도를 멈춘다 [실측 흉내 · 코드]) ④ claims.json 바꿈이 다른 판정을 바꾸는 길 (없음 — 아래 (g)).

### P2

**P2-1 · 증거 ③ 도구 (`evidence/tools/check_sh_commands.py`) 가 꼴이 다른 명령 줄을 조용히 빼고 rc 0 — 보장 (d) 깨짐 (지금 문서 결과는 맞음)**
- 재현 (`repro/d_sh_tool/` · `mk.sh` 로 봉인본 · 명령 문서만 바꾼 나무 · 같은 도구 바이트):

| # | 변이 | 기대 | 실제 |
|---|---|---|---|
| D0 | 그대로 | rc 0 | rc 0 · 13 + 1 · 14 + 1 (후보 ③ 재현) |
| D1 | 봉인본 원장 --init 줄 `--registration` 지움 | rc 1 | rc 1 (잡음) |
| D2 | 봉인본 sh 울타리 지움 (명령 13 → 0) | rc 1 | **rc 0 "문제 없음"** (종류 13 개 전부가 "한 문서에만" 목록에만 · 문제 0) |
| D3 | 봉인본 원장 --init 줄을 `python3 -I …` + `--registration` 지움 | rc 1 | **rc 0** (그 줄을 못 봄 · 13 → 12) |
| D4 | D1 + 그 울타리를 ```` ```bash ```` 로 | rc 1 | **rc 0** (sh 만 읽음) |
| D5 · D6 · D7 | `--max-hours 160` · 원본 자리로 `--registration` · S0 `--r-doc` 지움 | rc 1 | rc 1 (잡음) |
| D8b | 명령 문서 S0 줄 `python3 -u …` + `--r-doc` 지움 | rc 1 | **rc 0** (S0 0 개) |
| D9 | 명령 문서 `--cjunc-store ~/p6_cjstore` | rc 1 (Q4) | rc 1 — 다른 까닭 (가짜 홈에 폴더 없음 · 실제 kgy 엔 있다) |
| D10 | 명령 문서 사다리 nohup 줄 `python3 -I` + `--registration` 지움 | rc 1 | **rc 0** (14 → 13) |

- 까닭 [코드]: 사슬 · S0 부름 = 도구 토큰 바로 앞이 `python3?` 인 조각만 (K01 의 `doc_tool_commands` 와 같은 꼴) · ```` ```sh ```` 울타리만 · 셈 (13 · 14 · 1 · 1) 과 "한 문서에만 있는 종류" 를 찍기만 하고 `bad` 에 넣지 않는다 (`check_sh_commands.py` 172–173 줄).
- 지금 문서: 독립 셈 (`repro/d_indep/` · argparse 없이 울타리별 · python 어떤 꼴이든) = 봉인본 sh 사슬 13 · S0 1 · 명령 문서 sh 사슬 14 · S0 1 · 값 전부 봉인본 · bash 울타리 (인자 계약 꼴) = 봉인본 7 + 2 · 명령 문서 13 + 4 · 원본 자리 7 + 2 = `--registration` · `--r-doc` 없음 (설계대로) [실측] → README ③ 의 결과 문장은 G′ 에서 맞다.
- 영향: 봉인 때 조각을 고치면 이 도구가 지킴 노릇을 못 한다.  틀린 결과 길은 아니다 (빠진 인자 = 멈춤 · 위 P1 ①).
- 제안 (도구): 기대 셈을 인자로 받아 같지 않으면 `bad` · 울타리 안 어느 줄이든 `rint_r_chain.py` · `ca_s0_census.py` 글자가 있는데 못 읽은 줄 = `bad` · `ladder_dry` 밖 "한 문서에만 있는 종류" = `bad` · sh 명령 0 개 = `bad` · `--cjunc-store` 값 = `~/ca1_cjstore` 대조 (Q4).  README ③ 한정 한 줄: *"이 도구는 `python3 …/<도구>.py` 꼴 줄 · sh 울타리만 본다 — 셈 13 · 14 · 1 · 1 은 독립 셈과 같다 (리뷰 d_indep)"*.

**P2-2 · `make_sealed_copy.py` 가 봉인 계획이 실제로 돌 수 있는지 (두 계획 대조 · 결과 전 넷 · Q3 꼴) 를 보지 않는다**
- 재현 (`repro/a_tool/mutate.py` · `repro/e_s0gate/`): 후보 계획 + `tol_ff_um` 0.0738 (A24) · `len_law` `len_scaled_v9` (A25) · 넷을 채우고 tol_ff 틀림 · len_law 틀림 · 넷 null + tol_ff + numpy `1.26.4` = **도구 rc 0 · 봉인본 생성**.  그 봉인본을 넣은 scratch 커밋 다섯 (`repro/e_s0gate/variant_commits.txt`) 에서 S0 단계 2 관문 = 넷을 채운 둘은 "두 계획 대조" 로 거부 · **넷 null 셋은 후보와 같은 "넷 null" 사유로만 거부** [실측].  끝 줄바꿈 (A22) · indent 2 (A23) 계획도 rc 0 (Q3 꼴 = 기계 검사 없음 · 사슬 `load_plan` 도 꼴을 안 본다 [코드 1265 줄]).
- 영향: 잘못 만든 봉인 커밋이 push 될 수 있다 → S0 단계 2 관문 · 사다리 (`PLAN_CROSS_MISMATCH` · `PLAN_NUMBER_UNREGISTERED`) 가 결과 전에 멈춘다 → 다시 봉인 (일정 손실 · 틀린 결과 없음).
- 제안: 도구 `checks` 에 `plans_cross_problems(plan, s0) == []` · `--final` (봉인 때 필수) 이면 `require_plan_numbers(plan)` 통과 · `raw == json.dumps(json.loads(raw), indent=1, sort_keys=True).encode('ascii')` (Q3 꼴) 셋을 더하고 selftest 에 반례 셋 (A24 · 넷 null · 끝 줄바꿈).

### P3 (알려진 한계로 적고 진행 · 고칠 글 제안)

| # | 지적 | 재현 · 근거 | 제안 |
|---|---|---|---|
| P3-1 | **측정 뒤 바뀐 상태** — README "읽은 판 = 본 리포 HEAD 5a04acd15 · stoic-next 끝 b3481336c" · §마-4 "5a04acd15 = 본 리포 로컬 HEAD (원격 밖)" · e12 "5a04acd15 → 원격 가지 0 개" · "원격 추적 ref 153 개와 이름 · 객체 같음" | 지금 본 리포 HEAD = b3481336c (로컬 · origin 보다 6 앞) · stoic-next = 5645b86c8 · 5a04acd15 = `origin/claude/stoic-knuth-NObVQ` 에 있음 · 원격 ref 153 이름 같음 · 객체 3 개 바뀜 (origin stoic 716c59f9 → 5a04acd1 · friendly-meitner · 14-gate) [실측 `f_boundary/`] · 봉인 관련 파일은 b3481336c → 5645b86c8 사이 무변경 [실측 diff] · 3 판 README blob 같음 | 그 줄들에 "(11-17 측정 시점)" 표지 · 봉인 때 e12 · §마-4 를 다시 잰다 |
| P3-2 | README ⑤ "후보 = 넷 때문에만 거부" 는 관문의 **첫 실패**만 보여 준다 | `verify_plan_commit` 차례 = … `require_plan_numbers` (993 줄) → tol_ff (996 줄) → len_law (999 줄) [코드 `ca_s0_census.py`] · tol_ff · len_law · env_unit 이 틀린 후보도 같은 사유 [실측 P2-2] · 고정물 (= 후보 + 넷만 다름 [실측 json 대조]) PASS 가 뒤 대조를 덮는다 | ⑤ 에 한 줄: *"넷 null 사유는 관문의 첫 실패라 뒤 대조 (tol_ff · len_law) 를 증명하지 않는다 — 고정물 값 커밋 (넷 밖 칸 = 후보와 바이트 같은 값) 의 통과가 그 몫"* |
| P3-3 | `--check-doc` rc 0 은 **계획 바이트를 묶지 않는다** · `--stage ledger --init` 은 등록을 읽지 않는다 | 끝 줄바꿈 · indent 2 · `1.0e-12` 계획 → check-doc `PLAN_DOC_SAME` rc 0 · `check_plan_registered` = `PLAN_HASH_MISMATCH` [실측 `b_plan_bytes/`] · init 은 꼴 + 넷만 [코드 8539–8540 줄] → 계획 사본 바이트가 틀리면 원장 머리가 틀린 sha 로 생기고 첫 `--add` · 사다리에서 멈춘다 (새 원장) | §3-1b (2) · 봉인본 (0) 의 sha256 눈 대조 뒤에 기계 대조 한 줄: `python3 -c 'import sys,hashlib; sys.path.insert(0,sys.argv[1]); import rint_r_chain as R; print(R.check_plan_registered(hashlib.sha256(open(sys.argv[2],"rb").read()).hexdigest(), sys.argv[3])["plan_hash"][:12], "PLAN_REGISTERED_OK")' ~/dem-ca1/scripts ~/sdcp/ca1_plan.json ~/dem-ca1/<봉인본>` · 주석 "PLAN_DOC_SAME = 블록 같음 (바이트 아님)" |
| P3-4 | `make_sealed_copy.py` 조각 꼴 허점 (조용히 통과) | 빈 `after` 블록 (A02) · `last` 끝 칸에 줄바꿈 + 새 표 줄 (A10) · 끝 칸에 ` \| ` (A11 · 칸 4) · R-10 조각 통째 빠짐 (A15) · 모르는 자리표 `<봉인본X>` (A17) · 날짜 20261320 (A30) · 가지 `seal.lock` (A34) = rc 0 [실측] · 지금 조각은 문제 없음 (끝 칸 표 줄 3 칸 [실측]) | `last` · `mid+last` 블록에 `\n` · ` \| ` 금지 · 조각 이름 집합 고정 (R-MARK · R-00 – R-15 · K-01 – K-05) · 남은 자리표 = 허용 목록 · 날짜 = `datetime.strptime` |
| P3-5 | 명령 문서 §3-1b (2b) S0 단계 2 | venv 켬 · 판 출력 줄 없음 (S0 보고의 python · numpy · scipy 를 사슬이 대조하지 않는다 — `s0_code_problem` = 파일 지문만 [코드 1821 줄] · 대신 봉인 SV census 정수 대조가 결과 전에 멈춘다 [코드 1687 줄]) · same-version 줄과 S0 줄이 `&&` 로 묶이지 않음 · `\| tee` 가 rc 를 가린다 | (2b) 첫 줄 `. ~/dem-venv/bin/activate && python3 -c 'import sys,numpy,scipy;print(sys.version.split()[0],numpy.__version__,scipy.__version__)'   # 3.8.10 1.24.4 1.10.1` · `git diff --quiet … && python3 …/ca_s0_census.py …` · 끝 `; echo "rc=${PIPESTATUS[0]}"` |
| P3-6 | 원장 받는 쪽 — `mv ca1_ledger.parked ca1_ledger` 와 `pull` 사이 (잠금 밖) 창 · 블록 rc 0 | 흉내 [실측 `k_relay/`]: ① 정상 A→B (clone) → B 항목 → B→A (되살림 + pull) = HEAD = 넘김 기록 · 원장 역사 문제 None ② 창에서 그 기계 사슬이 덧붙이면 `fatal: Not possible to fast-forward` · HEAD ≠ 기록 · **블록 끝 rc 0** → 사람 대조만 (놓쳐도 합치기 · 판정의 채택 대조가 결과 줄 없는 시도 · 어긋난 항목에서 멈춘다 [코드 `adoption` 3519–3531 줄 · 봉인본 §10-7 ④]) | 되살림 = `git -C ca1_ledger.parked pull -q --ff-only "$RB" "$BR" && mv ca1_ledger.parked ca1_ledger` (세워 둔 자리에서 pull 먼저 — 그동안 사슬은 원장 자리를 못 연다 = 창 없음) · 끝에 `test "$(git -C ca1_ledger rev-parse HEAD)" = <기록 끝 커밋> && echo RECV_OK` · [추정] kgy git 2.25.1 + 사용자 `pull.rebase=true` 면 `--ff-only` 가 무시될 수 있다 → `git -c pull.rebase=false` |
| P3-7 | 넘김 기록 표가 **실행 트리 안** 명령 문서에 있다 | R 동안 `~/dem-ca1` 의 그 문서를 고치면 `git status` dirty → 다음 `--add` · 단계 입구 · 판정 = `CODE_PIN_MISMATCH` (틀린 결과 없음 · 되돌리면 풀림) [코드 948 · 1949 · 1985 줄] · 돌고 있는 단계는 다시 보지 않는다 [코드 grep] | K-03 (5) 표 머리 · K-04 에: *"이 표는 실행 트리 밖 사본 (1저자 · 본 세션 리포) 에 적는다 — `~/dem-ca1` 안 이 문서를 고치면 dirty 라 다음 단계가 멈춘다"* |
| P3-8 | `--registration` 을 빼면 "멈출 뿐" 의 비용 | 시도 꼴 = 시도 폴더 · 시작 기록 · 결과 줄 (결과 전) 을 쓰고 멈춘다 → 그 대상 최대 시도 8 중 하나 [코드 3667–3765 · 6627–6660 줄] · 판정 = 멈춘 `verdict.json` 을 `--out` 에 남겨 같은 폴더 다시 못 씀 [코드 8185–8205 줄] | §3-1b (2) 끝 줄 · (8) 10 에 "원장 항목 하나 · 판정 폴더 하나가 쓰인다" 한정 |
| P3-9 | 증거 도구 날짜 고정 | `check_chain_functions.py` 14 · 16 줄 · `check_s0_stage2_gate.py` 17 · 19 줄 = `20261120` 글자 → 봉인 날짜로 다시 돌리면 파일 없음 오류 (거짓 통과 아님) | 날짜 · 봉인본 자리를 인자로 |
| P3-10 | 원본 자리 머리 표지로 줄 +1 | 판 없이 "등록 R … N 줄" · "[R] N 줄" 을 적은 문서 6 개 · 55 줄 (봉인 기록 밖 · `rint2_siteq_remaining_plan_20261110.md` 27 · 2 판 README 12 · …) [실측 grep] · 시험은 다 지남 [실측 · 기록] · 머리 자리 = 1저자 Q1 결정 | README (바) 한정 문장에 "6 문서 · 55 줄" 수를 넣는다 (꼴은 그대로) |
| P3-11 | ③ 도구가 값 일부만 본다 | `--cjunc-store` 값 (Q4 `~/ca1_cjstore`) · `--out` · `--law` ↔ `--machine` ↔ `--ledger-target` 짝 미대조 [코드 `check_sh_commands.py` 126–135 줄] (사슬이 `--target` · 대상 ↔ 법칙 · 기계 ↔ 항목은 결과 전에 막는다 [코드 6650 · 3782 줄]) | P2-1 고침에 `--cjunc-store` = `~/ca1_cjstore` 대조를 넣는다 |
| P3-12 | 작은 글 · 줄 번호 | 러너 "통과 = 734 줄" → **733 줄** (734 = 다음 게이트 주석) [실측] · 명령 문서 T_hit "(중앙값)" ↔ 봉인본 R-13 ⑩ 표기 없음 · `command -v python3   # = ~/dem-venv/bin/python` → `…/bin/python3` · 도구 머리 글 "쓰는 곳 = --out 뿐 (그리고 시험 때 임시 폴더)" → 보통 실행도 시스템 임시 폴더 (`msc_*`) · `--out` 옆 `.msc_out_*` 를 쓴다 · `_manifest.json` 에 입력 파일 이름 (basename) 이 들어가 이름이 다르면 바이트가 다르다 [실측 diff] · 봉인 기록 README 에 scratch 절대 경로 (`/tmp/claude-0/…`) 3 곳 | 해당 글 고침 |

## [추정] (재현 못 함)

- kgy git 2.25.1 에서 사용자 설정 `pull.rebase=true` 가 있으면 `git pull --ff-only` 가 rebase 로 갈 수 있다 — P3-6 창에서만 뜻이 있고 HEAD 대조 · 합치기가 잡는다 [추정 · 현장 설정 미확인].
- 봉인 기록 폴더 `.py` (도구 · 증거 도구) 를 읽는 게이트 단계 — `check_selftest_inventory.py` = `scripts` · `webapp` 만 [코드 138 줄] · `check_cohort_packages.py` = `p2_*.json` 꾸러미만 [코드] · 규율 검사 = `scripts/**` [코드 340–345 줄] → 걸리는 단계 못 찾음 · 게이트 전체는 [미확인].

## 대조한 숫자 (✓ 맞음 · ✗ 틀림 / 낡음)

| # | README · 조각의 숫자 · 전칭 | 다시 잰 값 | |
|---|---|---|---|
| 1 | 원본 등록 R 301,281 B · 747 줄 · sha256 219b6351… | 같음 (`wc -l` 747 · `split('\n')` 748) | ✓ |
| 2 | 명령 문서 79,983 B · 603 줄 · 0fe96bb8… · 사슬 5fbc1c34… | 같음 | ✓ |
| 3 | 원본 · 명령 문서 = 본 리포 HEAD · stoic-next 와 바이트 같음 | 64e4d213e · 5a04acd15 · b3481336c · 5645b86c8 · origin stoic 다섯 판 blob 같음 (+ 사슬 · S0 census) | ✓ |
| 4 | `plan_candidate.json` 666 B · f09b3efb… = v1 = 봉인 꼴 커밋 계획 | 같음 | ✓ |
| 5 | 블록 sha256 0a62a8b5… · 화면 = v1 `plan_doc_block.txt` 24ad274f… | 같음 | ✓ |
| 6 | 봉인본 1a07b53c… · 원본 자리 1cf4a7b4… · 명령 문서 7dd095f5… · 같은 입력 두 번 같음 | 도구 다시 돌림 = 후보 build · 커밋 blob 과 같음 (manifest = 입력 이름만 다름) | ✓ |
| 7 | 조각 16 + 표지 1 + 명령 5 · 사슬 대조 11 (참) · 남은 자리표 34 · selftest 17/17 | 같음 | ✓ |
| 8 | u = tol_ff = tol_P = tol_sj = 0.07381254285530132 · 점 간격 중앙값 0.14762508571060265 ÷ 2 · n 1,544,424 | S0 계획 `values_um` · 보고 `threshold_inputs` 같음 | ✓ |
| 9 | instance 117,583 · 긴 접촉 30,270 (distinct · 자기 0) · 재방문 874 쌍 | 보고 `junction_census` 같음 | ✓ |
| 10 | S0 계획 1,485 B · 6346d9ed… = `cjunc_plan.sha256` = 보고 `plan.sha256` · 보고 코드 3.8.10 · 1.24.4 · 1.10.1 · 핀 HEAD | 같음 (ADOPTION_CHECK E1 에 env) | ✓ |
| 11 | 바뀐 파일 83 = 새 79 · 고침 4 · 봉인 기록 폴더 36 (G = 78 · 31) | G′ 83 · 79 A · 4 M · 36 | ✓ |
| 12 | 자료 폴더 14 · 13 · 13 = stoic 바이트 40/40 · q14 둘 = origin q14 = stoic · 원장 979db41a = stoic · claims 3f832454 = 2da71fe5a | 같음 (claims = origin stoic 지금 판과도 같음) | ✓ |
| 13 | claims 두 판 차이 = 두 `allowed_in` 덩어리 · +6 −2 | json 대조: 칸 · claims 목록 같음 · 항목 7 · 12 `allowed_in` 만 · 정확 경로 둘씩 더함 | ✓ |
| 14 | 다섯 경로 diff rc 0 · CODE_FILES 20 · S0 일곱 7 · 규율 검사 입력 안 = claims.json 하나 | 같음 (원장 54 줄 = 규율 검사 입력 목록 밖 명시) | ✓ |
| 15 | 규율 검사 0 오류 (17 경고) rc 0 | G′ 다시: 0 오류 · 17 경고 · 38.5 s | ✓ |
| 16 | check_doc_refs G′ rc 0 · 없는 경로 0 · 없는 커밋 0 · 문서 2,089 | G′ 다시 rc 0 · 0 · 0 · 2,089 (커밋 13,523 = 지금 원격 · 후보 13,503) | ✓ |
| 17 | 철회값: 새 글 0 · 핀 등록부면 S0 kit JSON 4 건 | 바뀐 파일 83 = 0 · 핀 등록부 4 (같은 JSON · 두 패턴) · sparse 1,479 파일 = 핀 등록부로만 생기는 4 건뿐 | ✓ |
| 18 | ③ 13 + 1 · 14 + 1 · 종류 13 중 12 같음 · ladder_dry 명령 문서만 · 문제 0 | 같음 (독립 셈도) | ✓ |
| 19 | ④ rc 0 · 기본 rc 3 · ④′ · ⑤ 넷만 · 기본 = S0 해시 ⬜ 거부 · 고정물 PASS (후보 증거) | 같음 (고정물 = 후보 + 넷만 다름) | ✓ |
| 20 | 게이트 셋 357 · 84 · 186 · E17 1 · K01 · PC18 · PC20 · EP06 4/4 | G′ 다시 357 · 84 · 186 · 1 · 4/4 (+ S16 · C03 2/2) | ✓ |
| 21 | e1 A 498.5 · B 530.0 · F 543.1 · G 552.8 s · e7 G 38.8 · B 114.0 s · e14 370 · 33.2 · 9.3 s | 증거 파일과 같음 (재실행 시간은 다름) | ✓ [기록] |
| 22 | 3 판 값 4,932 · 9,067 · 6,682 · 10,817 s (§3-2 595 · 597 줄) · r 2.933 → kgy 48.99 · gabia 60.40 h = 49.0 · 60.4 · 112 h = 168 × 2/3 · 168 h 덮는 r gabia 8.16 · kgy 10.06 | 산술 같음 · 3 판 670 줄 같음 | ✓ |
| 23 | 12 단위 = 법칙 2 × c 2 × R 3 · 첫 배정 7 + 5 · 사다리 P0 kgy · P1 gabia | 같음 | ✓ |
| 24 | README · 조각의 줄 번호 107 개 (v1 표 65 포함 · 새 v2 줄 번호 42) | 106 맞음 (함수 정의 · 검사 줄 뜻 그대로) · **1 틀림** (러너 "통과 = 734" → 733) | ✗ 1 |
| 25 | "본 리포 HEAD 5a04acd15 · stoic-next b3481336c" · "5a04acd15 = 원격 밖" · "원격 ref 153 이름 · 객체 같음" | 측정 뒤 바뀜 (P3-1) | ✗ 낡음 3 |
| 26 | 도구 머리 글 "쓰는 곳 = --out 뿐" · manifest "경로 넣지 않음" | 임시 폴더 · 입력 이름 (P3-12) | ✗ 작음 2 |

## 확인한 보장 (깨짐 · 조건부 · 섰음)

| 보장 | 판정 | 근거 |
|---|---|---|
| (a) 같은 입력 = 같은 바이트 | **섰음** | 두 번 · 후보 build 와 리포 출력 넷 같음 (manifest 는 입력 이름 포함) |
| (a) 이상한 입력에서 조용히 통과하지 않음 | **조건부** | 거부 19/34 = CRLF 조각 · CRLF 원본 · 한 바이트 바꾼 원본 (sha) · 전각 · 아라비아 숫자 · 두 칸 띄움 · 중복 조각 · 머리 글자 없음 · 닫는 `====` 끝 빈칸 · 블록 수 · 해시 줄 머리 줄 · 빈 머리 글자 · `### R-10` · NaN · 중복 칸 · S0 해시 다름 · 전각 날짜 · 줄바꿈 날짜 · `..` 가지 · 실패 때 출력 0 (폴더 · `.msc_out_*` 없음) · 통과 15 = 설계대로 4 (A12 · A13 표지 안 글자 · A16 sh 인자 = ③ 몫 · A28 정책 값) + P2-2 4 (A22 – A25) + P3-4 7 (A02 · A10 · A11 · A15 · A17 · A30 · A34) |
| (b) 해시 줄 ↔ 계획 바이트 | **조건부** | 값 1 바이트 = check-doc rc 3 · 꼴 1 바이트 = check-doc rc 0 · 묶음은 단계의 `check_plan_registered` (P3-3) |
| (c) 인자 빠뜨림 = 멈춤 | **섰음 (범위)** | 사다리 S16 (러너 0 회) · plan-doc rc 3 · 원본 자리 함수 멈춤 · S0 관문 거부 (census 전 [코드 1743 줄]) · 예측 · 합치기 · 판정 = `check_plan_registered` · `registration_plan_hash` 가 러너 · 값 전 [코드 6812 · 7347 · 7715 줄] · ledger · recover 무관 · 다시 판정 = 기록 경로 · 비용 = P3-8 |
| (d) 두 문서 sh 블록 모든 명령 `--registration` / `--r-doc` | 지금 문서 **섰음** · 도구 지킴 **깨짐** | P2-1 |
| (e) S0 관문 "넷 때문에만 거부" 가 다른 틀림을 가리지 않음 | **조건부** | 가린다 (P2-2 · P3-2) · 고정물 PASS 가 같은 값으로 덮는다 |
| (f) 봉인 커밋 = 다섯 경로 · CODE_FILES 20 · S0 일곱 밖 | **섰음** | 핀 코드에서 목록 뽑음 · 바뀐 83 개 전부 `docs/` · 다섯 경로 diff rc 0 |
| (g) claims.json = `allowed_in` 두 덩어리뿐 · 다른 판정 무영향 | **섰음** | json 대조 · `allowed_in` 쓰는 곳 = `check_review_findings.py` 580 줄 하나 [grep] · 규율 검사는 `claims` 목록만 [코드 723 줄] · 스윕 변화 = 그 JSON 4 건뿐 |
| (h) 원본 자리 표지 = 해시 줄 머리 · 블록 표지 · 자리 줄 글자 없음 · 봉인본 · 봉인 커밋 가리킴 | **섰음** | 표지 줄 = 2 줄 · 해시 줄 81 · 82 각 하나 · 블록 표지 0 · 자리 줄 84 하나 · 시험 다 지남 · 줄 +1 = P3-10 |
| ⑤ 정직한 흐름 (끊김 · 재부팅 · 메모리 · 디스크 · 다른 기계 · 비결정 · 폴더 옮김) 에서 틀린 결과 | **못 찾음** | 넘김 창 = P3-6 (사람 + 합치기) · 실행 트리 고침 = P3-7 (멈춤) · S0 환경 = P3-5 (census 정수 대조) · 손으로 고친 · 어긋난 기록 = 원장 꼴 · 역사 · 폴더 요약 대조로 멈춤 [코드 · 흉내 ① 역사 문제 None] |
| ④ "닫는 것 / 닫지 않는 것" 표 | **대체로 맞음** | ③ "그 줄 전부" = 지금 문서 한정 (P2-1) · 11-17 현장 = [기록] 반영 · 측정 시점 표지 필요 (P3-1) |

## 재현

`repro/README_repro.md` (폴더별 무엇 · 결과 파일) · 사본 · 존재 나무 · 변이 출력은 지움 (작은 글 · 스크립트만 남김).

# 믹서 E0 자격 pilot 한 팔 — 결과 전 등록 초안 (2026-11-12 · 조회 뒤 판)

**지위: 초안 · 문서만 · 실행 0 · 제출 0 · pilot 결과 0 건 · 봉인 아님 · 발사 GO 아님 · 전체 HOLD 그대로.**
런 **전에** 적어 두는 계약의 초안이다. 남은 순서 = 재봉인 (별도 승인 · 7-6) → 봉인 → 내부 반박 리뷰 → 1저자 발사 GO.
11-11 본 세션 초안 (`from_main/draft/registration_draft.md`) 을 이어 썼다. 옛 칸은 리포와 한 칸씩 대조했고 맞는 것은 그대로 두었다. 바뀐 곳 · 절 번호 대응 = 같은 폴더 `changes.md`.
**11-12 조회 뒤 (이 판)**: 13 절 조회 q1–q9 결과 (`QY` · 0 절) 로 [미확인] · [추정] 칸을 채웠고, 1저자 11-12 결정 (18 절 Q1–Q13 · 관측기 고침 Q-A–Q-E = *"권고대로"*) 을 반영했다. 결과 전 문턱은 옮기지 않았다 — 대조만 했다 (16 절 · `fill_report.md`). 고치기 전 판 = `e0_pilot_registration_draft_before_query.md` · 바뀐 곳 = `changes.md` 5 절.

## 0. 자리 · 이번에 정하는 것 / 정하지 않는 것

- 자리 = 준비 단계 ② "기준 고정" 의 둘째 산출물 (첫째 = 같은 폴더 `baseline_table.md`). 다음 = ③ 봉인 → ④ 내부 반박 리뷰 → ⑤ 1저자 GO.
- 1저자 11-10 운영 결정 ④: **믹서 E0 자격 pilot 한 팔만 내부 반박 리뷰로 Codex GO 를 대신한다** — first8 의 E0 한 팔뿐 · 발사 GO 는 1저자 · first8 본 런 (N0 · B 쌍) · 확인 블록 · 다른 트랙은 Codex GO 그대로 (리포 `docs/session_20260923_progress.md` L1423).
- 숫자의 출처 = `docs/data/mixer_e0_meta_ibb_20261110/out/` (아래 "out/") 와 리포 문서 + 11-12 조회 묶음 `QY` (아래). 파일 · 줄을 적었다. `L` = 줄 번호. 리포 HEAD = `21bb09d82`.
- `QY` = 11-12 ibb 읽기 전용 조회 묶음 (13 절 q1–q9): 묶음 sha256 a5753648e0ac34574fa8f5fa231366338093663a1155f549775a5f5ffc95beb0 · 블록 스크립트 md5 664376ce372ee4b60779d4f27e380165 · 수집 2026-11-12T11:52:36Z → 11:54:07Z (91 초) · 조회 OK 54 · FAIL 1 · 판독기 rc 0 (구조 정상 · 자격 아님) · 금지 문자열 0. 근거 표기 = 판독 요약 JSON 의 키 (예 `QY q1[0].post.bytes` · `[*]` = 다섯 런) · 판독 화면 줄 (예 `QY 판독 L16`). 지금은 scratch (`intake/mixer_e0_query_20261112/`) 에만 있다 — 리포 반입은 가린 out/ 만 · 새 증거 폴더 [제안 · `query_block/README.md` 5 절 4]. **QY 의 q1–q3 · q6 · q9 는 DEV E0 (옛 덱 세대 · 기본 `%g` 덤프) 의 값이다 — pilot 의 크기 · 시간이 아니다.**
- [산술] = 인용한 숫자로 계산한 값. [추정] = 가정이 든 값. [관찰] = 코드 · 다른 런 기록으로 본 것 (이 pilot 으로 확인 전). [미확인] = 못 찾은 값.
- 경로 줄임: `F8` = `docs/reviews/mixer_first8_launch_preparation_20261106` · `P8` = `docs/reviews/mixer_precal_first8_preparation_20261104` · `IN` = `docs/reviews/mixer_inactive_preparation_20261109` · `M-2` = 원격 가지 `origin/codex/mixer-qualification-plan-1110` 커밋 `0c56deba6` 의 `docs/reviews/mixer_qualification_plan_20261110.md` (HEAD 에는 없다 · 줄 번호도 그 판) · `FQP` = `docs/reviews/nonrint_first_link_20261109/mixer_ibb_fixed_qualification_plan.md` · `RCP` = `docs/reviews/nonrint_approved_preparation_20261109/mixer_ibb_qualification_receipt_plan.md`.

| 이번에 정하려는 것 (초안) | 정하지 않는 것 |
|---|---|
| walltime · 디스크 상한 · 바닥 · STOP 수치 · 감시 주기 (1저자 Q6 · 11-10) | 발사 · 제출 · 봉인 · 운영 봉인 교체 |
| 통과 / 실패 / 기술 실패의 뜻 (계획 문서의 상태 말 + 기록 대조 점검표) | 새 물리 값 · 새 물리 판정 문턱 · 성능 합격선 |
| 런 폴더 규칙 (Q5) · 감시 양식 · 예약 대조 · 회수 · 반입 규칙 · 다음 wave 판단 양식 | N0 · B1–B3 팔 · 둘째 팔 · 확인 블록 |
| 내부 반박 리뷰가 볼 것 (Q7) · 1저자가 정할 것 | E0 수용 뒤의 `MAP_CASE_GO` · 다음 wave · 예약 해제 |

## 1. 무엇을 돌리는가 (계획 문서의 정의 그대로)

| 항목 | 값 | 근거 |
|---|---|---|
| 팔 | first8 의 `PRECAL_E0` 한 팔 = 점착 0 · 균일 삽입 · 0 바퀴 (정착만) | `P8/README.md` L9 · `F8/inventory.md` L22 |
| 역할 | 기존 M 분모의 출처가 되는 정착 기준. 회전 자료와 바꿔 쓰지 않는다 | `docs/reviews/mixer_precal_exploration_registration_draft_20261104.md` L48 |
| 고정 조건 | seed 32452843 · 밀도 세대 lab20261014 · 계획 원자 100000 · CGF 151.4 · SE ×20 · 쌍별 힘 보존 · dt_factor 1 · Fr 0.0827 · 배플 0 · 전 정밀도 덤프 | `P8/README.md` L9 · `F8/planned_assets/PRECAL_E0/deck_meta.json` L12 · L14 · L15 · L18–20 · L208–209 |
| NP | 팔당 20 (1저자 채택 정책) | `IN/author_policy_record.json` L13 |
| 순서 | E0 한 팔만 → 검토. 그 뒤 팔은 별도 승인 | 같은 파일 L14–17 · `FQP` L12 |
| 풀리는 GO | `QUALIFICATION_PILOT_GO` = E0 한 팔만. 전체 HOLD 는 그대로 | `F8/README.md` L26 · `F8/submit_one.py.txt` L130 |
| 이 팔만의 특례 | 내부 반박 리뷰가 Codex GO 자리를 대신한다 (이 한 팔뿐 · 발사 GO 는 1저자) | 0 절 · `docs/data/mixer_e0_meta_ibb_20261110/README.md` L41 |
| 덱 | `in.mixer` 11347 B · sha256 8b588b24117ab77bf72d93662237268b401f714df8515d62ef7b964d01c6e718 | `F8/planned_assets/SHA256SUMS` L36 · `F8/blockers.json` L72 · 본 세션 sha256 |
| 덱이 하는 일 | dt 2.373e-07 s. run 1 → run 560606 → 삽입 해제 → run 560606 → 정착 상태 저장 → run 0. 합 1121213 step [산술] | `F8/planned_assets/PRECAL_E0/in.mixer` L84 · L133 · L145–147 · L150 · L156 |
| 출력 | 덤프 = 1000 step 마다 · 12 열 (id type x y z vx vy vz fx fy fz radius) · 정수 2 열 + `%.17g` 10 열. 프레임 1121 장 [산술 = 1121213 ÷ 1000 버림 · DEV 덱에서 같은 셈 = post 항목 1037 과 맞음 (out/ `fields.txt` L348)]. t0 = step 1121000. thermo 5000 step. 체크포인트 = 56060 step 마다 두 파일 번갈아 + 정착 끝 한 파일 | 같은 덱 L136 · L139 · L121 · L132 · L150 · `deck_meta.json` L64–66 |
| 메타 | 후보 둘 (덱 바이트는 같다). 원 계획 = c6543f3800d0d76d… (생성기 해시 661936b7…) / 현재 소스용 비활성 후보 = 498b941c898ea963… (생성기 해시 dc253bc8…). 다른 곳은 `generator_sha256` 한 칸뿐. **Q7 = 현재 소스 후보 쪽 (1저자 11-12 권고대로) → 498b941c…** · 운영 봉인 교체 = 별도 승인 (7-6) | `F8/planned_assets/SHA256SUMS` L37 · `IN/candidate/candidate_asset_manifest.json` L36 · `IN/README.md` L25 · 18 절 Q7 |
| STL | Drum fe821a8a… · Front 443f9c3c… · Back 2e7b962d… (ibb 체크아웃 · DEV 런의 STL 과 같은 해시) | `F8/planned_assets/SHA256SUMS` L38–40 · `baseline_table.md` 0-A · 7 절 |
| 바이너리 · MPI | lmp_mpi sha256 ee2d7726… · mpirun sha256 407990f9… (Open MPI 5.0.10) · 링크 라이브러리 30 개 sha256 = `baseline_table.md` 2-A (11-12 · 바이너리 RPATH 로 사용자 conda 환경에 묶임) | `baseline_table.md` 0-A · 2 · 2-A · 3 절 · `QY q7` |
| 제출 길 | first8 가드 하나: 제출 가드 → 러너 → job 시작 대조 → `mpirun --oversubscribe --bind-to none -np 20 <바이너리> -in in.mixer` 한 번. raw sbatch · 옛 런처 (`launch_highbo.sh`) 는 쓰지 않는다 | `F8/commands.txt` L24–40 · `F8/job_start.py.txt` L44 · `F8/inventory.md` L30 |
| 러너의 SLURM 줄 | 파티션 cpu · QOS cpu-60 · 노드 1 · task 20 · task 당 CPU 1 · requeue 없음 · 시간 = 승인 파일 `runner_bindings.walltime` (형식 `D-HH:MM:SS` · 러너 머리와 sbatch 인자 두 곳) · SLURM 출력 · 오류 파일 = 같은 칸의 `stdout` · `stderr` (절대 경로) · `walltime_approved` 참이 필요 | `F8/run_one.sbatch.txt` L2–9 · `F8/submit_one.py.txt` L17–23 · L89–91 · L159 |
| 관측 명령 (회수 뒤 · 로컬) | `python3 scripts/mixer_precal_observe.py --case PRECAL_E0 --run <검증된 스냅숏>` (기준 런이라 `--reference` 없음) · 관측기 = Q5 고친 판 (sha256 bb2f3229… · 재봉인 뒤 · 7-6) | `F8/commands.txt` L58 · `F8/inventory.md` L60 · `fix_q5/README.md` 0 절 |

주의: 위 가드 · 러너 · job 시작 대조기는 "비활성 초안" 이다. 실제 SLURM · MPI 에서 돈 적이 없다 (`F8/README.md` L11 · L30).

## 2. 결과 전 pilot 표 (M-2 3 절의 여섯 칸)

| 칸 (M-2 줄) | 이 초안의 답 | 아직 빈 것 |
|---|---|---|
| 목적 (L30) | 자격 관측 여섯 가지: (1) 입력 결속 — 놓인 덱 · 메타 · STL 이 계획 바이트와 같다 (2) 바이너리 · MPI — job 안 해시 · 배너 · rank 20 (3) 100k 관측 — 전 정밀도 12 열 덤프가 써지고 읽힌다 · 로그가 네 run 을 끝낸다 (4) 시간 — 실제 런 시간 (5) 저장 — 실제 프레임 · 폴더 크기 (6) 회수 — 새 스냅숏 복사와 해시 대조. **과학 비교는 목적이 아니다** (`F8/inventory.md` L70: 기준 · 로그 · I/O 자격) | 없음 |
| 최소 입력 (L31) | 1 절 표 (팔 · seed · 덱 · STL · NP 20 · 순서 · 관측 주기 · 열) | 메타 = 비활성 후보 498b941c… (Q7 · 11-12 결정) · 소스 핀 = Q5 패치를 담은 리포 커밋 (Q-C · 후보 f67c0cc92 [관찰] · 정하는 것 = 재봉인 단계 · 7-6) · Python 경로 · 러너 바이트 (봉인 단계) |
| 합격 / 거부 (L32) | 7 절 — 계획 문서의 상태 말 + 기록 대조 점검표 C1–C5 (물리 문턱 아님) | 성능 · 물리 합격선은 계획 문서에 없다 (L32 "각 정량 문턱과 기준은 미등록"). 이 초안도 만들지 않는다 (Q9) |
| STOP (L33) | 6 절 — walltime · 저장 바닥 · 상한 · 멈춤 문턱 (Q6 초안 · Q1–Q3 11-12 결정) + 계획 문서의 정성 규칙 | 없음 — 디스크 수치의 봉인 전 확인 = 11-12 `QY` q1–q3 로 끝 (5-5 · 식 그대로) |
| 회수 (L34) | 담당 = 1저자 (`RCP` L67). 정확한 job ID 하나만 중단. 부분 · 실패도 원바이트로 남긴다. 새 스냅숏 + 해시 대조 (11 절) | 회수 목적지 여유 [미확인 · 1저자 WSL] · 반입 범위 = Q8 권고대로 (11-12) |
| 확대 (L35) | E0 수용 ≠ first8 전체 GO. 다음 (N0) 은 실제 자격 수용 뒤 `MAP_CASE_GO` 로 따로 (12 절 양식). 자동 전이 없음 (`F8/README.md` L26) | 이 등록의 범위 밖 |

## 3. 런 폴더 (Q5)

| 항목 | 내용 | 근거 |
|---|---|---|
| 결정 | 발사 때 새로 만든다. dev7 · dev7_v26 폴더는 쓰지 않는다. 지금은 만들지 않는다 | `docs/data/mixer_e0_meta_ibb_20261110/README.md` L16 |
| 지금 상태 | first8 제안 root 가 ibb 에 없다 | out/ `fields.txt` L353 · `hashes.txt` L473 |
| fresh 조건 | 런 폴더에 post · restart · log.liggghts · job_start.json · job_end.json · simulator.stdout · simulator.stderr 가 없어야 한다 (제출 영수증 둘도) | `F8/job_start.py.txt` L37–38 · `F8/submit_one.py.txt` L138–139 |
| 폴더 구조 | root 아래 `campaign_policy.json` · `cases/PRECAL_E0/` · `admission/` | `F8/commands.txt` L68–71 |
| 같은 파일시스템 | 홈 아래면 Lustre 다 (여유 · inode = `baseline_table.md` 5 절) | out/ `fields.txt` L539–540 |
| 이름 · 경로 꼴 | 제안 이름 `mixer_precal_first8_20261106` · 봉인 묶음 · 정책의 경로는 풀린 꼴로 통일 [Q4 권고대로 · 1저자 11-12] | `F8/commands.txt` L69 · 18 절 Q4 · `baseline_table.md` 8 절 관찰 1 |

## 4. Q6 — 시간 (walltime)

**상태: 실측이 out/ 에 있다 (런별 다섯 + 옛 덱 다섯). 아래에 산술 · 여유 배수 · 까닭을 적었다. 11-12 `QY` q6 의 sacct Elapsed 로 다섯 런을 다시 맞췄다 (4-1 끝 열 · 4-2) — 차이 2 ~ 6 초 · walltime 초안 그대로.**

### 4-1. 실측: DEV E0 다섯 런 (dev7_v26)

런 시간 = job 시작 시각 (`job_start.json` 의 `time_utc`) 에서 `log.liggghts` 의 마지막 수정 시각까지 [산술]. step 수 = 리포의 같은 덱 메타 (`docs/data/mixer_highbo_dev_decks_20260930_v26/decks/<런>/deck_meta.json` 의 `steps` — E0_ref L77–78 · dthalf L79–80) 에서 1 + fill × 2. ibb 런의 덱 sha256 이 리포 덱과 같다 (`baseline_table.md` 7 절).

| 런 | job 시작 (UTC) | 근거 (out/ `seal_extract.txt`) | 로그 마지막 수정 (epoch 초) | 근거 (out/) | 런 시간 | step 수 | step/s | sacct Elapsed (11-12 · `QY` q6) |
|---|---|---|---|---|---|---|---|---|
| E0_ref_s32452843 | 2026-09-30T08:12:16Z | L957 | 1790769933 | `mix3_run23_ls.txt` L6 | 13997 s (3.89 h) | 1037429 | 74.12 | 03:53:20 = 14000 s (+3) |
| E0_ref_s49979687 | 2026-09-30T09:12:36Z | L917 | 1790773512 | `mix3_run22_ls.txt` L8 | 13956 s (3.88 h) | 1037429 | 74.34 | 03:52:38 = 13958 s (+2) |
| E0_ref_s67867967 | 2026-09-30T09:12:39Z | L557 | 1790770830 | `mix3_run9_ls.txt` L6 | 11271 s (3.13 h) | 1037429 | 92.04 | 03:07:57 = 11277 s (+6) |
| E0_ref2_s32452843 | 2026-09-30T12:05:39Z | L437 | 1790787354 | `mix3_run1_ls.txt` L8 | 17415 s (4.84 h) | 1467147 | 84.25 | 04:50:21 = 17421 s (+6) |
| E0_ref_dthalf_s32452843 | 2026-09-30T12:20:32Z | L717 | 1790795353 | `mix3_run14_ls.txt` L6 | 24521 s (6.81 h) | 2074857 | 84.62 | 06:48:45 = 24525 s (+4) |

다섯 다 NP 20 · QOS cpu-60 · 시간 한도 2-00:00:00 으로 돌았다 (out/ `seal_extract.txt` L984 · L986 · L988 과 나머지 넷의 같은 칸).
sacct 열 근거 = `QY q6.jobs[*].Elapsed` · `elapsed_s` · `elapsed_minus_reg41_s` (괄호 = Elapsed − 런 시간) · 판독 L46–50. 다섯 다 State COMPLETED · ExitCode 0:0 · AllocCPUS 20 (같은 곳).

참고 — 옛 덱 (dev7) 의 E0 다섯 런을 같은 방법으로 읽으면 80.26 · 65.25 · 70.82 · 67.29 · 63.49 step/s 다 [산술. 시작 = out/ `seal_extract.txt` L117 · L157 · L197 · L357 · L237 / 로그 = `mix2_run1_ls.txt` L6 · `mix2_run2_ls.txt` L8 · `mix2_run3_ls.txt` L6 · `mix2_run7_ls.txt` L8 · `mix2_run4_ls.txt` L6 / step 수 = 리포 `docs/data/mixer_highbo_dev_decks_20260930/decks/<런>/deck_meta.json` 의 `steps`].
열 런을 합친 범위 = **63.49 ~ 92.04 step/s** (폭 1.45 배).

### 4-2. 이 읽는 법이 맞는가

같은 방법으로 dev-bo 두 런을 읽으면 96969 s · 87640 s 다 (out/ `seal_extract.txt` L597 · L797 / `mix3_run11_ls.txt` L6 · `mix3_run16_ls.txt` L8).
그 두 런의 sacct 기록은 1-02:56:12 (= 96972 s) · 1-00:20:44 (= 87644 s) 다 (`docs/data/mixer_highbo_devbo_prelim_20261003/README.md` L14).
차이 3 초 · 4 초. 이 읽는 법은 sacct 와 맞는다.
11-12 E0 다섯에 직접 대조 (`QY` q6 · 판독 L46–50): Elapsed − 런 시간 = +3 · +2 · +6 · +6 · +4 초 (Elapsed 가 늘 길다). dev-bo 의 3 · 4 초와 같은 크기 → E0 에서도 이 읽는 법이 sacct 와 맞는다. sacct 로 셈한 속도는 4-1 보다 0.02 ~ 0.05 % 느리다 [산술 = step 수 ÷ `elapsed_s`] — walltime 초안은 그대로 (산술 근거만 보강).

### 4-3. pilot 으로 옮기는 산술

| 항목 | 값 | 근거 |
|---|---|---|
| pilot step 수 | 1121213 (DEV E0_ref 1037429 의 1.081 배) | 1 절 |
| 예상 런 시간 | 3.38 h (92.04 step/s) ~ 4.20 h (74.12, dev7_v26 에서 가장 느림) ~ 4.91 h (63.49, 열 런에서 가장 느림) [산술 = step 수 ÷ 속도] | 4-1 |
| 기존 문서 어림과 비교 | 4.4 ~ 4.9 h (63–70 step/s 가정 · 역사 값) — 겹친다 | `F8/README.md` L20 |
| 11-12 프레임 시각 (`QY` q2 · r1 한 런) | 첫 → 끝 프레임 74.11 step/s = 4-1 r1 74.12 와 같다 [산술] · 1000 step 당 평균 13.49 초 · 런 안에서 고르지 않다 — 처음 두 간격 4 · 3 초 · 가운데 두 구간 평균 14.17 · 12.86 초 · 끝 두 간격 12 · 12 초 [산술 · 수정 시각 차 · 일곱 점] | `QY q2.steps_per_s_first_to_last` · `s_per_1000_steps` · `frames` · 판독 L21–28 |
| 안 잰 것 (1) | 전 정밀도 12 열 덤프의 쓰기 시간. 덱 주석은 덤프 크기를 "약 2 배" 로 적는다 (11-12 `QY` q3 은 크기 비만 · 쓰기 시간 아님 → 그대로 [미확인]) | `F8/planned_assets/PRECAL_E0/in.mixer` L138 |
| 안 잰 것 (2) | 덱 세대가 다르다 (밀도 · dt · 드럼 크기 · 정착 step 수). 원자 수 · 덤프 열 · 덤프 간격은 같다 | 두 덱을 줄 단위로 견줌 [본 세션]: `docs/data/mixer_highbo_dev_decks_20260930_v26/decks/E0_ref_s32452843/in.mixer` ↔ `F8/planned_assets/PRECAL_E0/in.mixer` |
| 안 잰 것 (3) | 러너가 다르다. pilot 러너는 노드 1 고정 · task 당 CPU 1 을 적고 conda 환경을 활성하지 않는다. DEV 러너는 `-n` 만 적었다 | `F8/run_one.sbatch.txt` L4–6 · `F8/job_start.py.txt` L44 · L47 · `dem_scripts/mixer_20260921/launch_highbo.sh` L293–298 |

### 4-4. walltime 초안

**초안값: `1-00:00:00` (24 시간).**

| 항목 | 내용 |
|---|---|
| 여유 배수 | 86400 s ÷ 17658 s = 4.9 배 (열 런에서 가장 느린 속도 기준) · 86400 ÷ 15127 = 5.7 배 (dev7_v26 에서 가장 느린 속도 기준) [산술] |
| 까닭 1 | 이 팔은 재시도 · resume · requeue 가 없다 (`F8/README.md` L22). 시간 초과로 죽으면 팔을 잃는다. 넉넉한 쪽의 비용은 작다 |
| 까닭 2 | 안 잰 것이 셋 있다 (4-3) |
| 까닭 3 | 속도가 고르지 않다. 같은 덱 세 런 (dev7_v26 E0_ref) 사이에 1.24 배, 열 런 전체로는 1.45 배 벌어졌다 [산술 = 92.04 ÷ 74.12 · 92.04 ÷ 63.49] |
| 까닭 4 | 멈춘 런은 walltime 이 아니라 감시 (6 절 S5) 로 잡는다 |
| 한도 확인 | 내 association MaxWall 7-00:00:00 · 파티션 14-00:00:00 안이다 (`baseline_table.md` 4 절) |
| 11-12 대조 | sacct 속도 차 ≤ 0.05 % (4-2) → 여유 배수 4.9 · 5.7 그대로 · 1저자 11-12 Q1 권고대로 (18 절) |
| 대안 | `0-12:00:00` (2.4 ~ 2.9 배) · `2-00:00:00` (DEV E0 정책값 그대로 · 9.8 ~ 11.4 배) |

## 5. Q6 — 디스크 (크기 · 바닥)

**상태 (11-12): DEV E0 다섯 런의 크기 실측을 받았다 (`QY` q1–q3). 5-1 런별 표 · 5-2 평균 = 실측 · 5-3 교차 확인 넷 = 맞음 → 상한 · 바닥 · inode 의 식과 값은 그대로다 (5-5). 상한은 여전히 산술 상한이다 — pilot (전 정밀도 12 열) 의 실측이 아니다.**
(옛 상태 줄 "런별 크기 실측이 out/ 에 없다 → 조회 필요 · 아래 수치는 조회 전의 산술 상한" 은 11-12 조회로 대체됨.)

### 5-1. out/ 에 있는 것 · 없는 것

| 있는 것 | 값 | 근거 (out/) |
|---|---|---|
| dev7_v26 폴더 합계 | 90504844 KB | `mix3_du.txt` L1 |
| dev7_v26 의 post 항목 수 합 | 7763 = 1037 × 4 + 1467 + 307 + 267 + 170 + 234 × 6 | `fields.txt` L348 · L343 · L252 · L291 / L201 / L221 · L286 · L315 / L239 · L267 · L278 · L299 · L310 · L332 |
| dev7 폴더 합계 | 63444400 KB | `mix2_du.txt` L1 |
| dev7 의 post 항목 수 합 | 5355 = 867 × 4 + 1227 + 314 + 135 + 211 | `fields.txt` L129 · L140 · L145 · L153 / L181 / L161 · L170 · L189 |

~~없는 것: DEV E0 런별 덤프 크기 · 프레임 한 장 크기~~ (out/ 의 post 는 디렉터리 항목 크기만 찍혔다 · `mix3_run23_ls.txt` L10) → **11-12 `QY` q1 실측**: 런별 post · restart (파일 크기 합 = 바이트 · du = KB).

| 런 · job | post 파일 (항목 · 메타와) | post 바이트 합 | 평균 프레임 | 최소 · 최대 프레임 | restart 파일 · 바이트 | post + restart | du (KB) post · restart | 근거 |
|---|---|---|---|---|---|---|---|---|
| E0_ref_s32452843 · 249080 | 1037 (same) | 12625687622 | 12175205 | 8261322 · 12746172 | 3 · 115182809 | 12740870431 | 12331932 · 112504 | 판독 L16 · `QY q1[0]` |
| E0_ref_s49979687 · 249081 | 1037 (same) | 12621133693 | 12170814 | 8260147 · 12745190 | 3 · 115196281 | 12736329974 | 12327456 · 112508 | 판독 L17 · `QY q1[1]` |
| E0_ref_s67867967 · 249082 | 1037 (same) | 12627248007 | 12176710 | 8260992 · 12759060 | 3 · 115288377 | 12742536384 | 12333424 · 112600 | 판독 L18 · `QY q1[2]` |
| E0_ref2_s32452843 · 249083 | 1467 (same) | 17839891349 | 12160798 | 8244932 · 12755424 | 3 · 115100185 | 17954991534 | 17424844 · 112412 | 판독 L19 · `QY q1[3]` |
| E0_ref_dthalf_s32452843 · 249084 | 1037 (same) | 12625142995 | 12174680 | 8260306 · 12764485 | 3 · 115151097 | 12740294092 | 12331376 · 112464 | 판독 L20 · `QY q1[4]` |

- 평균 = post 합 ÷ 파일 수 (체크포인트 · 로그가 안 섞인 값 · `q1[*].mean_frame_bytes` 반올림). 다른 이름 · 잡음 항목 0 (`q1[*].post.other` · `noise`). 항목 수 = 11-10 메타와 같음 (`post_entries_vs_meta` · `restart_entries_vs_meta` same).
- restart = 다섯 다 `a.bin` · `b.bin` · `settled.bin` 세 파일 (`q1[*].restart_files`) — 7-3 C3 의 이름 · 개수와 같다.
- du (할당) ≈ 파일 크기 합의 1.0001 ~ 1.0002 배 [산술] — S4 · C4 의 관측량은 파일 크기 합 그대로 (5-3).
- DEV 덤프는 전부 기본 `%g` 꼴이다 (DEV · dev-bo · dev-u 덱에 `dump_modify` 줄 0 — 본 세션 grep). 이 표는 pilot (전 정밀도) 의 크기가 아니다.

### 5-2. 프레임 크기 — 11-12 실측 평균 (옛 폴더 평균 [추정] 은 대체됨)

**실측 (`QY` q1)**: E0 런 평균 프레임 12160798 ~ 12176710 B (≈ 12.16 ~ 12.18 MB) = 옛 폴더 평균 11.94 MB 의 1.019 ~ 1.020 배 (`q1[*].mean_vs_est52` · 판독 L16–20). 이 값을 쓴다.
DEV E0_ref 세 런의 post 합 = 12621133693 ~ 12627248007 B (≈ 12.62 ~ 12.63 GB) — 기존 문서의 상한 어림 14.5 GB (`docs/data/mixer_highbo_dev_decks_20260930_v26/README.md` L17) 의 87 % [산술].

옛 어림 (대체됨 · 기록으로 남김):

| 폴더 | 산술 | 값 |
|---|---|---|
| dev7_v26 | 90504844 KB ÷ 7763 | 11658 KB = 11.94 MB / 항목 — 대체됨 |
| dev7 | 63444400 KB ÷ 5355 | 11848 KB = 12.13 MB / 항목 — 대체됨 |

옛 가정: 폴더 크기가 전부 프레임이고 프레임 크기가 고르다. 체크포인트 · 로그 · 보충 폴더가 섞여 있어 위로 약 1.5 % 치우친다 [추정 — 체크포인트 한 파일 36179883 B (리포 `docs/data/mixer_highbo_devu_prelim_20261006/exact_runs/exact_LU212_settled/exact_receipt.json` L38 · settled.bin) × 39 개]. 옛 "DEV E0_ref 한 런 ≈ 1037 × 11.94 MB = 12.4 GB [추정] (14.5 GB 의 85 %)".
⚠ 11-12 실측으로 보면 **치우침의 방향이 반대였다** — 폴더 평균이 E0 실측 평균보다 약 2 % 작다. 까닭 [미확인] (폴더에 다른 런 · 보충 폴더 항목이 섞인 탓 [추정]). 이 어림은 문턱에 쓰지 않았다 (5-3 상한은 식으로 셈) → 상한 · 바닥 영향 없음.

### 5-3. pilot 의 상한 산술

리포에 있는 규칙 (`scripts/mixer_stage_gate.py` L84–86 · L303–318): 줄 폭 = id 자릿수 + type 2 + 실수 열 × 최악 폭 + 구분자. 프레임 = 원자 수 × 줄 폭 + 512 B. 체크포인트 = 원자당 400 B × 3 파일. 기본 형식 (`%g`) 의 최악 폭은 12 다.

| 단계 | 산술 | 값 |
|---|---|---|
| `%.17g` 의 최악 폭 | 부호 1 + 유효숫자 17 + 소수점 1 + e 1 + 지수 부호 1 + 지수 3 [산술 — 본 세션이 난수 double 20 만 개와 끝값으로 최대 길이 24 를 다시 확인 (예 `-2.2250738585072014e-308`). 리포 문서에는 없는 수다] | 24 |
| 한 줄 | 6 + 2 + 10 × 24 + 12 | 260 B |
| 프레임 한 장 | 100000 × 260 + 512 | 26000512 B |
| 덤프 전체 | 1121 × 26000512 | 29146573952 B |
| 체크포인트 | 3 × 100000 × 400 | 120000000 B |
| **합 (상한)** | | **29266573952 B ≈ 29.27 GB** |

관측량 (S4 · C4 에서 같은 뜻): **`post/` 와 `restart/` 안 파일 크기의 합 (바이트 · `du` 의 할당 블록 아님)**. 로그 · 영수증 · 덱 · STL 은 이 합에 넣지 않고 감시 기록에 따로 적는다.
이 합이 상한이 되는 조건 [추정]: 원자 ≤ 100000 · 덤프 12 열 · 형식 줄이 덱대로 적용됨 · 체크포인트가 원자당 400 B 이하 (실측 한 점 = 36179883 B ÷ 100000 ≈ 362 B — 회전 런 settled.bin · 11-12 DEV E0 다섯 런 15 파일 = 383.5 ~ 384.5 B · 아래 (3)). 형식 줄이 안 먹으면 프레임은 더 작다 (기본 형식).

교차 확인 (11-12 `QY` 실측으로 넷 · 옛 둘은 대체됨):
- (1) `%g` 규칙의 상한 14000512 B / 장 ↔ 실측 최대 프레임 12745190 ~ 12764485 B = 0.910 ~ 0.912 배 (`q1[*].max_vs_g_rule_bound` · 판독 L16–20) · 평균은 0.869 ~ 0.870 배 [산술] → 규칙이 위쪽 값이다 ✓ (옛 "5-2 의 평균은 그 85 ~ 87 %" 는 대체됨).
- (2) 정확 좌표 6 열 실측 (`QY` q3 · 보충 폴더 여섯 · 판독 L29–35): 원자당 hp (`%.17g`) 99.1 ~ 100.1 B ≤ 모델 110 B (6 + 2 + 4 × 24 + 6) · g6 (기본 `%g`) 52.2 ~ 53.1 B ≤ 모델 62 B ✓ → 폭 24 · 12 규칙이 위쪽 값이다. hp/g6 비 1.885 ~ 1.901 > 모델 비 1.774 — 기본 꼴이 자기 최악 폭에서 더 멀다 (hp 0.90 ~ 0.91 · g6 0.84 ~ 0.86 배 [산술]). 상한은 비가 아니라 절대 폭으로 셈하므로 영향 없음. 원자 수 = 계획값 100000 으로 나눈 근사 [한정] · 6 열 (id type x y z radius) 이라 12 열 실측은 아니다.
- (3) 체크포인트 실측 (`QY` q1 restart · 15 파일): 38349651 ~ 38445875 B = 원자당 383.5 ~ 384.5 B [산술 ÷ 100000] ≤ 400 B (0.959 ~ 0.961 배) · 런당 세 파일 합 115100185 ~ 115288377 B ≤ 120000000 B ✓ — 여유 4 %. pilot 덱의 체크포인트 크기 (접촉 이력 포함) 는 [미확인].
- (4) 덱 주석의 "약 2 배" 로 어림 (평균만 실측으로): 2 × 12176710 B × 1121 = 27300183820 B ≈ 27.30 GB [추정] (옛 2 × 11.94 MB × 1121 = 26.8 GB 는 대체됨) — 상한 29.27 GB 안이다.
- ⇒ `query_block/README.md` 6 절의 판단 셋 (최대 ≤ `%g` 규칙 · hp ≤ 110 · g6 ≤ 62) 이 다 맞다 → 상한 · 바닥 · inode 식 그대로 (5-5).

### 5-4. 바닥 · 상한 초안

| 수치 | 초안값 | 산술 · 까닭 | 지금 값과 비교 |
|---|---|---|---|
| 상한 (post + restart 파일 크기 합) | 29266573952 B | 5-3 의 합. 넘으면 계획에 없는 출력이다 | — |
| 여유 바닥 (`minimum_free_bytes`) | 32193231348 B (≈ 32.2 GB) | 상한 × 1.10 올림. 1.10 = 리포에 이미 있는 여유 규칙 "필요 × 1.10 ≤ 가용" (`scripts/mixer_stage_gate.py` L84) | 11-10 df 여유 142604135108608 B = 바닥의 약 4430 배 · 11-12 OST 8 개 중 최소 여유 14629480562688 B = 바닥의 454.4 배 · OST 여유 합 133551229964288 B (`QY q5.min_avail_bytes` · `min_avail_vs_floor` · `sum_avail_bytes` · 판독 L44 · 시점 값) |
| 파일 수 예산 | 1146 [추정] | 프레임 1121 + 체크포인트 3 + 폴더 2 (post · restart) + 작은 파일 ≤ 20 (in.mixer · deck_meta.json · STL 셋 · submission.claim.json · submission.receipt.json · job_start.json · job_end.json · simulator.stdout · simulator.stderr · log.liggghts · SLURM 출력 둘 = 14 + log.cite 등 모르는 것 여유 6). SLURM 출력 둘의 자리는 승인 파일이 정한다 (`F8/submit_one.py.txt` L19–23) — 런 폴더 밖이면 셈에서 빠질 뿐이다. 이름의 근거 = `F8/submit_one.py.txt` L87 · L99 · L149 · `F8/job_start.py.txt` L15 · L45 · L49 · 덱 L124 · L131 | 11-12 DEV E0 런 = post 1037 (r4 1467) + restart 3 (`QY q1`) — 프레임 + 체크포인트 3 의 꼴과 맞음 · 런 폴더의 작은 파일 수는 안 셈 |
| inode 바닥 (`minimum_free_inodes`) | 1261 | 파일 수 예산 1146 × 1.10 올림 | 11-10 여유 559481276 (11-12 조회에 inode 없음) |
| 회수 목적지 여유 | ≥ 32.2 GB | 전부 가져올 때 같은 양이 한 번 더 든다. 이 컨테이너 (여유 8.4 GB · `docs/session_20260923_progress.md` L1437) 는 목적지가 될 수 없다 | [미확인] (1저자 WSL) |

두 바닥 칸은 job 시작 대조기가 요구하는 칸이다 (`F8/job_start.py.txt` L39–42 — 값이 없으면 시작을 거부한다).
DEV E0 런의 로그는 수십 KB 였다 (out/ `fields.txt` L345 · L349).

### 5-5. 봉인 전에 한 번 고칠 것 — ✅ 11-12 했다

옛 문장: 위 수치는 실측이 아니라 산술 상한이다. 13 절의 조회 (런별 du · 프레임 크기) 가 오면 5-2 의 평균을 실측으로 바꿔 적고, 상한이 실측과 어긋나지 않는지 본다. 상한 · 바닥의 식은 그대로 둔다. 이 확인은 pilot 결과 **전** (DEV 자료) 이고 봉인 전에 한 번뿐이다 (16 절).
✅ 11-12 (`QY` q1–q3): 5-2 평균만 실측으로 바꿨다. 5-3 교차 확인 넷이 다 맞아 상한 29266573952 B · 여유 바닥 32193231348 B · 파일 수 예산 1146 · inode 바닥 1261 의 식과 값은 그대로다. 그 한 번은 끝났다 — 다시 고치지 않는다 (16 절). 상한은 여전히 pilot 12 열 실측이 아닌 산술 상한이다.

## 6. Q6 — STOP · 회수 (한 표)

| # | 언제 | 조건 (관측량) | 수치 | 근거 | 누가 보나 | 누가 · 어떻게 멈추나 |
|---|---|---|---|---|---|---|
| S0a | 제출 전 | 현장 조회 영수증이 5 분보다 오래됨 | 300 초 | `F8/submit_one.py.txt` L125–126 (이미 있는 수치) | 가드 | 가드가 제출을 거부 (HOLD · rc 2) |
| S0b | 제출 전 | 내 잡 CPU 합 + 20 > 60 · first8 돌고 있는 팔 ≥ 동시 한도 · 남은 예약 | 60 · 1 팔 | `F8/submit_one.py.txt` L132–134 · L83–84 · 1 절 정책 | 가드 | 가드가 거부 |
| S0c | 제출 전 | 신원 · 정책 · 소스 · 자산 · 러너 불일치 · fresh 아님 | 일치 / 불일치 | `F8/submit_one.py.txt` L111–164 | 가드 | 가드가 거부 |
| S1 | 실행 중 | 시간 한도에 닿음 | `1-00:00:00` (4-4 초안) | 4 절 | SLURM | SLURM 이 끊는다 (TIMEOUT) → 기술 실패. 다시 내지 않는다 |
| S2 | job 시작 · 감시 | 파일시스템 여유 < 바닥 | 32193231348 B | 5-4 · `F8/job_start.py.txt` L39–42 | 시작 = 대조기 · 실행 중 = watch 기록 | 시작 때는 대조기가 거부. 실행 중이면 1저자가 중단 |
| S3 | job 시작 | inode 여유 < 바닥 | 1261 | 5-4 · `F8/job_start.py.txt` L40–42 | 대조기 | 대조기가 거부 |
| S4 | 감시 | post + restart 파일 크기 합 > 상한 | 29266573952 B | 5-3 · 5-4 | watch 기록 | 1저자가 중단 → 기술 실패 |
| S5 | 감시 | 새 프레임이 안 생김 — post 의 가장 큰 step 파일의 수정 시각이 30 분 넘게 그대로 (첫 프레임 전이면 job 시작부터 30 분) | 30 분 | 아래 산술 | watch 기록 | 1저자가 중단 → 기술 실패 |
| S6 | 감시 | 로그 오류 셋: ① 줄 첫머리가 `ERROR` 인 줄 ② thermo 줄에 비유한 값 (nan · inf) ③ thermo 의 Atoms 값이 step 1 줄의 값보다 작아짐 | 줄 수 ≥ 1 | `F8/README.md` L22 · `F8/commands.txt` L50 · 덱 L122 | watch 기록 | 1저자가 중단 → 기술 실패 |
| S7 | job 시작 | 신원 · rank · 할당이 봉인과 다름 (SLURM_NTASKS 20 · 노드 1 · task 당 CPU 1 · partition · QOS · 덱 · 소스 · 정책 · 바이너리) | 일치 / 불일치 | `F8/job_start.py.txt` L18–42 | 대조기 | 대조기가 시뮬레이션 전에 멈춘다 (HOLD · rc 2) |

- S5 의 산술: 프레임 간격 = 1000 step ÷ 속도 = 10.9 ~ 15.8 초 [산술 · 4-1 의 63.49 ~ 92.04 step/s]. 30 분은 그 114 ~ 166 배다. 사람이 보는 감시라 분 단위로 잡았다. 삽입 (`run 1`) 시간은 [미확인] 이다 — 같은 빌드 · 같은 fix 꼴 (insert/pack) 의 488291 입자 삽입이 1 프로세스에서 91 초였다 (리포 `docs/data/kg50_d07_end_20261105/kg50_d07_b50_log_ins1.liggghts` L121) [관찰 · 다른 덱].
- 11-12 대조 (`QY` q2 · DEV E0 r1 · NP 20 · DEV 덱): job 시작 → 첫 프레임 (step 1000) 11.0 초 (`q2.first_frame_after_job_start_s` · 판독 L21 — MPI 시작 · 삽입 run · 999 step 을 포함한다 [관찰 · DEV 덱]) · 1000 step 당 평균 13.49 초 (`q2.s_per_1000_steps`) · 구간별 3 ~ 14.2 초 (4-3). 30 분은 가장 느린 구간 평균의 127 배다 [산술]. 문턱 그대로 · pilot 덱 (NP 20) 의 삽입 시간은 그대로 [미확인].
- S6 ① 을 셀 때 **줄 첫머리만** 본다. 덱 주석 L34 (`` #   (`ERROR: youngsModulus <= 1e9 …`) ``) 이 로그에 메아리로 찍힌다 — 이 빌드는 입력 줄 (주석 포함) 을 log 파일에 쓴다 (리포 kg50 로그 셋의 `#` 줄 48–51 · 같은 런 stdout 0 · `docs/data/kg50_d07_end_20261105/`) [관찰]. `grep -c ERROR` 처럼 세면 정상 런도 늘 1 이상이다.
- S6 ③ 의 읽는 법: 덱이 소실을 오류로 올리지 않는다 (`thermo_modify lost ignore` · 덱 L122). 계획 문서는 "소실" 이라고만 적는다.
- 언제 1저자에게 멈춤을 권하나: S2 · S4 · S5 · S6 중 하나가 watch 기록에 보일 때 (본 세션이 기록을 받은 즉시). 판단 = 이 표의 문장 그대로. 아래 "중단 사유가 아닌 것" 으로는 권하지 않는다.
- 어떻게: 1저자가 ibb 에서 `scancel <정확한 job ID>` 한 줄 (`F8/commands.txt` L62–66). 사용자 전체 취소 · 재시도 · resume · requeue 는 없다.
- 남길 것: 런 폴더 전부 (지우기 · 옮기기 · 덮어쓰기 없음) · 멈춘 시각 (UTC) · 사유 (S 번호) · 그때의 watch 기록 · sacct 한 줄 · 예약 대조 기록 (10 절). 중단을 정상 완료로 적지 않는다 (M-2 L34).
- 중단 · TIMEOUT 뒤 `job_end.json` 이 없을 수 있다 [추정 — job 시작 대조기에 SIGTERM 처리가 없다 · `F8/job_start.py.txt` L48–55]. 없으면 "없음" 으로 적는다 (0 · 정상으로 채우지 않는다).
- 재실행: 자동 없음. 같은 팔을 다시 내려면 새 1저자 결정 + 새 런 폴더 + 새 승인 (`F8/README.md` L22 · `F8/inventory.md` L56). 문턱은 이 등록 그대로 — 등록 결함이 원인일 때만 16 절 절차.

중단 사유가 아닌 것 (고-Bo 등록 §8 의 꼴 · `docs/reviews/mixer_highbo_prereg_20260927.md` L267–268):
- 예상보다 느림 (프레임이 계속 생기는 한 · walltime 이 처리한다)
- E0 의 값 (접촉 수 · 칸 분산 · KE)
- t0 상별 입자 수가 계획과 몇 개 다름 (MPI 삽입 · `P8/README.md` L17 · CLAUDE.md (HEAD `21bb09d82`) L40 의 `SELF-70` 서술 · 원장 `SELF-70` verified)
- simulator.stderr 의 PRTE 세션 폴더 경고 [추정 — 수집 때 같은 경고 · out/ `mpi1_version.txt` L2–7]
- 노드 공유 · 유휴 노드 0

이 표의 수 가운데 이 초안이 새로 내는 것과 이미 있던 것 = 16 절 규칙 원장.

## 7. 통과 / 실패 / 기술 실패

### 7-1. 계획 문서에 있는 상태 말

| 층 | 상태 | 뜻 | 근거 |
|---|---|---|---|
| 제출 | HOLD | 신원 · 정책 · rank · cap · 저장 · 선행 조건이 안 맞으면 발사 전에 막힌다 | `F8/README.md` L22 |
| 실행 | `EXITED_REQUIRES_QUALIFICATION` | MPI 종료 코드 0. "자격 검토가 필요한 끝남" 이지 자격이 아니다 | `F8/job_start.py.txt` L54 |
| 실행 | `TECH_HOLD` | 종료 코드가 0 이 아니거나 실행 예외 | `F8/job_start.py.txt` L52–54 |
| 감시 | TECH / HOLD | 중단 · 오류 · 비유한 · 입자 소실 · 문턱 초과 · 진행 불명 | `F8/README.md` L22 · `F8/inventory.md` L56 |
| 회수 | 미자격 | 불완전 · 바뀐 · 진행 중 복사 · 해시 불일치 | `F8/inventory.md` L58 · `F8/commands.txt` L53–57 |
| 관측 | OK (종료 코드 0) | 구조 · 신원 · 로그 · 프레임 자격을 다 지나 값을 낸다. E0 는 t0 접촉과 칸 원 분산만 낸다 (M 은 해당 없음) | `scripts/mixer_precal_observe.py` L453 · L484 · L393 · L402 |
| 관측 | UNDEFINED (종료 코드 2) | 분모 미정의 · 비유한. 0 으로 바꾸지 않는다 | `P8/README.md` L18 · 관측기 L460–461 |
| 관측 | TECH (종료 코드 2) | 구조 · 신원 · 중단 오류. 값을 내지 않는다 | `P8/README.md` L18 · L35 · 관측기 L462–467 |
| 자격 | 수용 / 거부 | 사람의 검토 + 1저자. 다음 팔의 `MAP_CASE_GO` 는 "수용된 실제 자격" 을 따로 요구한다. 자동 전이 없음 | `F8/README.md` L26 · `F8/submit_one.py.txt` L129 · `FQP` L54 |

관측이 보는 것 (E0): 초기 총누락 0 ~ 10 · ID 가 1..N · 덤프 반경 = 템플릿 반경 (관측기 L218–253) · t0 프레임이 정확히 1 장 (L297) · 로그가 네 run 을 끝냄 · ERROR / 재개 흔적 없음 (L307–337). **E0 에서는 t0 밖의 프레임을 보지 않는다** (L298–302 · 회전 팔만 bin 1 격자를 본다) [관찰 — 코드 판독].

### 7-2. 이 초안에서 쓰는 네 말

| 말 | 뜻 (위 상태 말의 조합) |
|---|---|
| 통과 | 실행 `EXITED_REQUIRES_QUALIFICATION` + 회수 대조 일치 + 관측 OK. **뜻 = "자격 검토로 넘길 수 있다".** 자격 수용도 물리 자격도 아니다 |
| 기술 실패 | 실행 `TECH_HOLD` · 감시 TECH / HOLD (S1–S7) · 회수 미자격 · 관측 TECH / UNDEFINED · 시간 초과 중 하나. 값을 쓰지 않는다 |
| 실패 (자격 거부) | 통과했는데 7-3 점검표 C1–C5 중 하나라도 ✗ · 또는 1저자가 이유를 적어 거부 |
| 자격 수용 | 통과 + C1–C5 전부 ✓ + 1저자 수용 기록. 이것만 12 절 W1 을 채운다 |

성공 문자열 · 종료 코드 0 · 스케줄러 COMPLETED 만으로는 통과가 아니다 (M-2 L32 · `F8/commands.txt` L37–38).

### 7-3. 자격 검토 점검표 C1–C5 (결과 전 · 기록 대조만 · 물리 문턱 아님) [초안 — 1저자 Q12]

| # | 점검 (✓ 조건) | 근거 |
|---|---|---|
| C1 | sacct 한 줄: State = COMPLETED · ExitCode = 0:0 · AllocCPUS = 20 · NNodes = 1 | `F8/commands.txt` L44 (State · ExitCode · Elapsed · AllocCPUS · MaxRSS) + NNodes [초안 추가] · `F8/job_start.py.txt` L21–23 |
| C2 | 영수증 이음: `job_end.json` 이 있고 state = `EXITED_REQUIRES_QUALIFICATION` · returncode 0 · `job_start.json` 의 job_id = 제출 영수증의 job_id = sacct JobID · 승인 sha256 이 claim · job_start 에서 같다 | `F8/job_start.py.txt` L28 · L46 · L54 · `F8/submit_one.py.txt` L85–96 |
| C3 | 덤프 · 체크포인트 목록: post = 정확히 1121 파일 · step 1000 … 1121000 (1000 간격 · 빠짐 · 겹침 · 다른 이름 없음) · 파일 크기 > 0 · restart = 정확히 3 파일 (a.bin · b.bin · settled.bin) | 덱 L132 · L136 · L150 · `deck_meta.json` L64–66 · 7-1 끝 문장 (관측기가 E0 에서 t0 밖을 안 본다) |
| C4 | 자원: post + restart 파일 크기 합 ≤ 29266573952 B · 런 폴더 파일 수 ≤ 1146 | 5-3 · 5-4 |
| C5 | 등록 밖 운영 없음: 런 폴더 손 편집 · 두 번째 제출 · 등록 밖 명령 · 재개가 없다 (감시 · 중단 · 회수 기록으로 확인) | `F8/README.md` L22 · `P8/README.md` L29 |

- C1–C5 는 숫자 · 목록 · 기록만 본다. 속도 · 메모리 · E0 값은 보지 않는다 (Q9).
- C3 은 이름 · 개수 · 0 아닌 크기만 본다. 1121 장 전부의 내용 파싱은 [미확인 · 도구 없음] — t0 한 장은 관측기가 파싱한다.
- 11-12 `QY` 대조 [관찰 · DEV E0 다섯]: C1 의 꼴이 실제 sacct 출력에서 읽힌다 — 잡당 한 줄 (step 줄 없음) · COMPLETED · 0:0 · AllocCPUS 20 (`q6.jobs[*]` · 판독 L46–50 · NNodes 는 그 조회에서 안 불렀다). C3 의 restart 세 이름 (`a.bin` · `b.bin` · `settled.bin`) 도 같다 (`q1[*].restart_files`).

### 7-4. 관찰 — 지금 봉인된 관측기로는 "관측 OK" 가 나올 수 없어 보인다 (네 가지)

| # | 관측기가 요구하는 것 | 같은 빌드 실제 로그 · 덱에서 본 것 | 근거 |
|---|---|---|---|
| ① | thermo 머리 토큰이 정확히 `Step Atoms KinEng c_rke Volume` (`scripts/mixer_precal_observe.py` L316) | 머리 = `Step Atoms KinEng rke Volume` (c_ 가 없다) · 같은 꼴: 변수 열 `v_pressMPa` → 머리 `pressMPa` | `docs/data/mixer_highbo_devu_prelim_20261006/exact_runs/exact_LU212_settled/log.exact` L65 (thermo_style 은 `in.exact` L114 = pilot 덱 L120 과 같은 글자) · `docs/data/kg50_d07_end_20261105/kg50_d07_b50_log_main1103.liggghts` L150 · L171 |
| ② | Loop 줄이 "… steps with N atoms" 로 끝나야 한다 (L319 의 fullmatch) | Loop 줄이 ", finish time <날짜>" 로 끝난다 | 같은 `log.exact` L67 · `kg50_d07_b50_log_ins1.liggghts` L121 |
| ③ | thermo 머리와 Loop 사이의 비어 있지 않은 줄은 전부 다섯 칸 숫자 줄 (L328–332) | 삽입 런 (`run 1`) 의 thermo 표 안에 `INFO: Particle insertion … inserted …` · ` - a total of …` 두 줄이 낀다 (fix insert/pack · insert_every once = pilot 덱과 같은 fix 꼴) | `kg50_d07_b50_log_ins1.liggghts` L116–121 · 덱 L104–106 · L133 |
| ④ | 로그 어디에도 낱말 `ERROR` 가 없어야 한다 (L309 · 첫 검사) | 덱 주석 L34 에 `ERROR:` 가 있고, 이 빌드는 입력 줄 (주석 포함) 을 log 파일에 쓴다 | 덱 `F8/planned_assets/PRECAL_E0/in.mixer` L34 · kg50 로그 셋의 `#` 줄 48–51 개 ↔ 같은 런 stdout 0 개 (`docs/data/kg50_d07_end_20261105/`) |

본 세션 재현 (기록 있음): 관측기 파일에서 `_need` · `_log_contract` 두 함수 글자만 AST 로 꺼내 메모리에서 돌렸다 (리포 쓰기 0 · 과학 모듈 import 0). 스크립트 = `work/check_log_contract.py` (sha256 0a8acdc98281093832a80c16685488cb59b084f89b9568f8bb79b5c7ef265d80) · 출력 = `work/check_log_contract_output.txt` (sha256 ea5cf4db59ff59e35512ed773fdafe67d66972988ecc820d0952f962a64359b7).

| 넣은 꼴 | 결과 |
|---|---|
| 시험 꼴 머리 + 시험 꼴 Loop (INFO · 주석 없음) | MATCH (네 run · 끝 1121213) |
| ① 만 실제 꼴 | TECH "Loop lacks a qualified thermo table" |
| ② 만 실제 꼴 | TECH "invalid five-column thermo row" |
| ① ② 실제 꼴 | TECH "log fresh four-run completion mismatch" |
| ③ 만 실제 꼴 (머리 · Loop 는 시험 꼴) | TECH "invalid five-column thermo row" |
| ④ 만 실제 꼴 | TECH "error/resume log is not fresh completion evidence" |
| ① ② ③ ④ 모두 실제 꼴 | TECH "error/resume log is not fresh completion evidence" (④ 가 첫 검사) |

뜻: 관측기 (sha256 df22dcf0… · `F8/source_seal.json` L11) 를 그대로 두면 정상 완주 런도 관측 TECH 가 된다 [관찰 — 실제 PRECAL_E0 로그로는 미확인]. 그러면 7-2 의 "통과" 는 나올 수 없다. 처리 = 18 절 Q5. 문서의 한정 "실제 LIGGGHTS 로그 호환성은 아직 검증하지 않았다" (`P8/README.md` L53) 와 같은 자리다.
**처리 (11-12)**: Q5 고침 = 패치 둘 (`fix_q5/` · 관측기 df22dcf0… → bb2f3229…) → 리포 반입 51d45732c (시험 먼저) · f67c0cc92 (고침) · 1저자 Q-A–Q-E 권고대로 → 7-6. 재봉인 (별도 승인) 전까지 **봉인된** 관측기는 df22dcf0… 그대로라 이 절의 관찰은 그 판에 대해 여전히 맞다 (이 절 · E8 · 7-5 · 17 절 1 · 8 행의 재봉인 판 고침 = 재봉인 때 · `fix_q5/README.md` 6 절).

### 7-5. 관찰 — 메타 · 생성기 · 관측기는 짝이다

- HEAD 소스 (생성기 dc253bc8…) 의 관측기는 원 메타 (c6543f38…) 를 "metadata differs from the fixed case recipe" 로 거부한다 (`IN/README.md` L23).
- 원 가드는 자기 옆의 원 봉인 · 원 자산 목록만 읽는다 → 비활성 후보 메타 (498b941c…) · HEAD 소스로는 제출이 막힌다 (`F8/submit_one.py.txt` L147–158 · `IN/README.md` L63).
- 7-4 고침 (Q5) 은 관측기 sha256 을 바꾼다 → 어느 쪽 묶음이든 운영 봉인 교체가 든다 [산술 — 관측기가 봉인 12 의존 안에 있다 · `F8/source_seal.json` L10–11]. 처리 = 18 절 Q7.

### 7-6. 관측기 고침 (Q5) · 1저자 결정 Q-A–Q-E · q9 대조 (11-12)

고침 = `fix_q5/README.md` (scratch): 패치 0001 (시험만 · 새 6 전부 실패) · 0002 (관측기 고침) · 관측기 sha256 df22dcf0… → bb2f3229… · 이 시험 파일 28/28 → 34 중 28 → 43/43 (Python 3.11.18 · 3.8.20) · 반례 62 · 단일 가드 변이 25 (생존 0) · 바뀐 리포 파일 둘 (`scripts/mixer_precal_observe.py` · `scripts/test_mixer_precal_observe.py`).
11-12 리포 반입 확인 (이 판 작업 때 · 읽기만 — `git log` · `git show`): 51d45732c (0001 · 시험 먼저) → f67c0cc92 (0002 · 고침) · f67c0cc92 의 tree = 후보 JSON 의 `patched_git_tree` 4f293308… · 재봉인 후보 12 파일 sha256 = f67c0cc92 · HEAD `bfd9b3bbd` 둘 다 12/12 같음 · 원장 `MXE0-01` (P2) claimed_fixed [관찰]. **운영 봉인 (`F8/source_seal.json`) 은 df22dcf0… 그대로 — 재봉인 전이다.**
허용 꼴 넷 — 그 밖은 그대로 TECH:

| # | 허용 꼴 (고친 관측기) | 근거 (`fix_q5/README.md` 2 절) |
|---|---|---|
| ① | thermo 머리 = `Step Atoms KinEng rke Volume` (옛 `c_rke` 꼴은 이제 거부) | devu `log.exact` L65 |
| ② | Loop 줄 = `…, finish time <ctime>` 정확히 · "Loop time of" 로 시작하는 다른 꼴 = TECH | 같은 파일 L67 · kg50 로그 |
| ③ | 표 안 비-행 줄 = insert/pack 보고 두 줄만 (`INFO: Particle insertion …` 다음 ` - a total of …`) — 덱에 선언된 fix 하나당 한 번 · 그 fix 선언 다음 run 의 표 · 표 첫 (setup) 행 **바로 뒤** · step = setup + 1 · 넣은 수 = 누계 > 0 · mass 같음 · 다음 행 Atoms = setup 행 + 넣은 수 · 선언된 fix 의 보고가 없으면 TECH | kg50 `log_ins1` L116–121 · `fix_insert.cpp` print_stats_during |
| ④ | 낱말 `ERROR` · 줄 첫머리 `ERROR` = TECH — 예외 = 그 런 덱의 전체줄 주석과 바이트 같은 메아리 (덱에 나온 횟수까지) | 덱 L34 · kg50 `#` 줄 |

새 거부 (같은 README 3 절): thermo Atoms 감소 · 열린 표 안 머리 · Loop 원자 수 ≠ 끝 행 · 표 안 ASCII 아닌 줄 · 숫자 꼴 밖 값. 덱 정보 없이 부르면 ③ · ④ 의 예외를 하나도 허용하지 않는다.

1저자 11-12 결정 (같은 README 9 절 · *"권고대로"*):

| Q | 결정 | 이 초안의 자리 |
|---|---|---|
| Q-A 덜 넣은 삽입 (표 안 `WARNING: Particle insertion: Less insertions than requested`) | 기술 실패 (관측 TECH) 유지 | 8 절 E6 (D13 과 로그 계약이 각각 무엇을 말하는지) · 16 절 새 줄 |
| Q-B 봉인 전 허용 목록 ↔ q9 대조 | 이번 `QY` q9 로 한다 | 아래 대조 표 · 18 절 Q-F |
| Q-C 재봉인 대상 · 핀 | 현재 소스 12 + 고친 관측기 후보 · 핀 = 패치를 넣은 리포 커밋 | 아래 순서 (실행 = 별도 승인 단계) |
| Q-D 이 빌드가 내지 않는 옛 합성 꼴 (`c_rke` 머리 · stamp 없는 Loop) 거부 | 수용 | 기록만 — 옛 fixture 두 줄은 실제 꼴로 옮겼다 (단언 무변경) |
| Q-E first8 묶음 시험 (게이트 · CI 밖) 의 HEAD `ef68eb7da` 실패 | 기록만 | 17 절 8 행 [관찰] · 아래 순서 5 |

**Q-B 대조 — 고친 관측기 허용 꼴 ↔ `QY` q9** (DEV E0 r1 `E0_ref_s32452843` · NP 20 · `log.liggghts` 467 줄 · 표 4 · `QY q9.*` · 판독 L54–58):

| 항목 | 고친 관측기가 받는 꼴 | q9 가 본 것 | 대조 |
|---|---|---|---|
| 표 수 · 닫힘 | run 넷 = 표 넷 · 표마다 Loop 줄로 닫힘 | 표 4 · 닫힘 4/4 (`blocks[*].closed` yes) | 맞음 (수 수준) — Loop 줄 꼬리 (② `finish time …`) 는 q9 가 줄 머리만 봐서 [미확인] |
| 머리 | `Step Atoms KinEng rke Volume` (5 칸) | 첫 낱말 `Step` · 5 칸 (넷 다 · `header_cols`) | 칸 수 맞음 — 머리 낱말은 q9 가 안 셈 [미확인] (DEV 덱 L118 = pilot 덱 L120 같은 thermo_style 글자 [관찰]) |
| 숫자 행 | 5 칸 · 유한 | 행 2 · 105 · 106 · 1 · 모두 5 칸 · 비유한 0 · 빈 줄 0 (`row_cols` · `rows_nonfinite` · `blank`) | 맞음 |
| 표 안 비-행 줄의 첫 낱말 | `INFO:` 1 · `-` 1 (보고 한 쌍) 만 | 표 1 = `INFO:` 1 · `-` 1 · 표 2 – 4 = 0 (`blocks[*].words` · `nonrow`) | **맞음** — 허용 목록 밖 첫 낱말 0 (`WARNING:` · `ERROR` 등 0) |
| 보고가 놓인 표 | 그 fix 선언 다음 run 의 표 = 표 1 (DEV 덱 L102 `fix ins … insert/pack` → L131 `run 1`) | 표 1 (`blocks_with_INFO` = ['1']) | 맞음 |
| 보고 수 | 선언된 insert/pack fix 하나당 한 번 (DEV 덱 = 하나) | `INFO:` 1 · `-` 1 | 맞음 |
| 두 줄의 순서 | `INFO:` 다음 비지 않은 줄이 ` - a total …` | q9 는 첫 낱말별 줄 수만 낸다 — 출력 차례는 awk `for (key in …)` 차례라 로그 순서가 아니다 (`query_block/src/query_script.sh` L124) | [미확인] |
| 표 안 자리 | 첫 (setup) 행 바로 뒤 · 다음 행 앞 | 표 1 = 숫자 행 2 + 비-행 2 — 자리는 안 셈 | [미확인] (행 수와 모순 없음) |
| 앞 공백 · 숫자 · 본문 | `INFO:` 는 줄 첫 칸 · 둘째 줄은 공백 한 칸 + `-` · step = setup + 1 · 넣은 수 · mass · 다음 행 Atoms | awk `$1` 은 앞 공백을 버린다 · 숫자 · 본문은 옮기지 않았다 | [미확인] |

판정 = **맞음 (첫 낱말 · 줄 수 · 보고가 놓인 표 수준) — 순서 · 표 안 자리 · 앞 공백 · 숫자 · 본문은 q9 가 기록하지 않아 [미확인].**
- 허용 목록 밖의 새 꼴이 없다 → ③ 을 고칠 것 없음 (Q-B 의 "다른 꼴이면 시험 먼저 → 고침" 길은 열리지 않았다).
- 같은 q9 awk 를 1 프로세스 kg50 `log_ins1` (보고 자리가 알려진 로그) 에 돌린 컨테이너 시험도 삽입 표 안 `INFO:` 1 · `-` 1 이었다 (`query_block/README.md` 3 절 t11) — 첫 낱말 모양이 같다.
- 순서 · 자리의 근거는 여전히 1 프로세스 로그 (kg50 `log_ins1` L116–121 · 다른 덱) + 소스 판독 (보고 = proc 0 한 번 · `fix_q5/README.md` 7 절) [관찰]. NP 20 삽입 런의 줄 순서는 리포 · `QY` 어디에도 없다 → 18 절 Q-F.
- 덤: r1 의 삽입 표에 `WARNING:` 0 줄 → 이 런은 삽입이 모자라지 않았다 [관찰 · 한 런 · Q-A 의 TECH 꼴이 이 런엔 없음]. ④ (덱 주석 메아리) 는 표 밖이라 q9 범위 밖 [미확인] (DEV 덱 L32 에 같은 `ERROR:` 주석이 있다 [관찰]).

재봉인 순서 (Q-C — 이 초안에는 순서만 · 실행 = 1저자 별도 승인 단계):
1. 패치 0001 (시험 먼저) → 0002 (고침) 를 리포에 넣는다 — 게이트는 둘을 함께 적용한 끝에서 (0001 단독은 게이트 '믹서 보정 전 관측 연결' 단계를 실패시킨다 · `fix_q5/README.md` 1 절). ✅ 11-12 들어갔다 (51d45732c · f67c0cc92 · 위 [관찰]).
2. 그 커밋 = 소스 핀 — 후보 = f67c0cc92 (두 패치를 담은 커밋 · tree = 패치 트리 4f293308… [관찰]) · 정하는 것 = 재봉인 단계. `source_pin` 은 이때 처음 넣는다 (후보 JSON 은 일부러 키를 뺐다 · null 금지 — 가드가 키 없음을 HOLD 로 읽는다 · 같은 README 6 절).
3. 재봉인 후보 다시 만들기 (`fix_q5/seal_candidate/make_and_check_seal_candidate.py` · 12 파일 = 현재 소스 + 고친 관측기) · 비활성 후보 목록 = 검증기 `--mode build` 로 **새** 후보 폴더 (손으로 고치지 않는다).
4. 운영 봉인 (`F8/source_seal.json`) · `IN/source_inventory.json` 관측기 행 교체 = 1저자 별도 승인. 그때 이 초안 7-4 · E8 · 7-5 · 17 절 1 · 8 행을 재봉인 판으로 고친다.
5. first8 묶음 시험 셋을 다시 돌린다 (Q-E — 재봉인 뒤에는 통과해야 한다 · 후보 목록 + 임시 pin 으로 10/10 · 14/14 · 8/8 · 1/1 확인됨 · 같은 README 6 절) → 내부 반박 리뷰 (17 절 · 고침 포함) → 1저자 발사 GO.

## 8. 결과 전 기대 (예측 · 판정선 아님)

| # | 기대 | 출처 |
|---|---|---|
| E1 | 런 시간 3.4 ~ 4.9 h [추정]. 전 정밀도 쓰기 시간만큼 더 길 수 있다 (11-12 sacct 대조 = 같은 속도 · 4-2) | 4-3 |
| E2 | post 항목 1121 개. 마지막 프레임 step = 1121000 (= t0) | 1 절 |
| E3 | restart 항목 3 개 (`a.bin` · `b.bin` · `settled.bin`) | 1 절 · DEV 다섯 런도 3 (out/ `fields.txt` L347 등 · 11-12 `QY q1[*].restart_files` 같은 세 이름) |
| E4 | 프레임 한 장 ≤ 26000512 B. 2 배 어림이면 약 24.35 MB [추정 — 11-12 실측 평균 최대 12176710 B × 2 · 옛 23.9 MB (11.94 MB 기준) 는 대체됨] | 5-2 · 5-3 |
| E5 | post + restart ≤ 29.27 GB. 2 배 어림이면 약 27.42 GB [추정 — 2 × 12176710 B × 1121 + restart 실측 최대 115288377 B · 옛 26.8 GB 는 대체됨] | 5-3 (4) |
| E6 | t0 원자 수 = **100000 정확** 을 기대한다 (관측 OK 의 실효 조건). 두 검사가 따로 말한다 — ① **D13 (관측기 프레임 검사 · 그대로)**: t0 프레임 총누락 0 ~ 10 · ID 1..N · 뒤 프레임의 ID · type · radius 보존 (E0 는 t0 한 장). 상별 수는 계획과 몇 개 다를 수 있다 (MPI 삽입 · 상별 상한 없음). ② **로그 계약 (고친 관측기 · 1저자 11-12 Q-A = 기술 실패 유지)**: 삽입이 모자라면 이 빌드는 삽입 run 의 thermo 표 안에 `WARNING: Particle insertion: Less insertions than requested` 를 찍는다 → 허용 꼴 (7-6 ③) 밖 → 관측 TECH. thermo Atoms 감소 (소실) 도 TECH. ⇒ D13 의 누락 1 ~ 10 구간은 로그 계약에서 먼저 TECH 가 된다 — 실효 허용 = 누락 0 [관찰 — 코드 판독 · 빌드 소스 · 실제 pilot 로그 아님]. 감시에서 step 1 줄 Atoms < 100000 이 보여도 STOP 사유는 아니다 (6 절 S 조건에 없다). 참고: DEV E0 r1 (NP 20) 의 삽입 표엔 `WARNING:` 줄 0 | 관측기 L246 (D13 · 고친 판도 같은 줄 — 패치는 L304 부터) · `P8/README.md` L17 · 7-6 ③ · `fix_q5/README.md` 8 절 · 9 절 Q-A · CLAUDE.md (HEAD `21bb09d82`) L40 의 `SELF-70` 서술 · `QY q9` (판독 L55) |
| E7 | MPI 종료 코드 0 | — |
| E8 | 관측기를 고치지 않으면 관측 = TECH · 첫 사유 = "error/resume log is not fresh completion evidence" [관찰] — 재봉인 전 봉인본 df22dcf0… 기준이다. 고친 관측기 bb2f3229… 는 7-4 의 네 꼴을 허용 꼴로 받는다 [관찰 — 합성 fixture · 실제 pilot 로그 아님 · 7-6] | 7-4 ④ · 7-6 |
| E9 | +1 h 시점 step ≈ 228600 ~ 331300 [추정 = 63.49 ~ 92.04 step/s × 3600 s] — 감시 참고 · 문턱 아님 | 4-1 |
| E10 | 로그 thermo 표 넷 · 표 1 (삽입 run) 안에 `INFO:` · `-` 두 줄 · 표 2 – 4 비-행 줄 0 [관찰 — 같은 덱 계열 DEV E0 r1 NP 20 실측 (`QY` q9 · 첫 낱말 · 줄 수 수준) + 1 프로세스 다른 덱 (kg50) · 순서 · 자리 [미확인] (7-6)] | 7-4 ③ · 7-6 |

값 (접촉 수 · 칸 분산) 에 대한 기대는 적지 않는다. 판정에 쓰지 않기 때문이다.

## 9. 수동 감시 양식

- 감시 = 1저자가 ibb 에서 읽기 전용으로 (정확한 job ID 하나 · 이 런 폴더 하나). 명령 꼴 = `F8/commands.txt` L42–51 (WATCH). 블록은 봉인 단계에서 DEM1 꼴 읽기 전용 watch 로 만든다 (CLAUDE.md DEM1 줄 · 컨테이너 시험 먼저) — 이 등록은 명령을 만들지 않는다.
- watch 기록 간격 = 10 분 [초안 · Q3]. 기록 파일은 런 폴더 **밖** 새 폴더에 둔다 (회수 목록 · fresh 조건을 흐리지 않게).
- 사람 판단 시점 [초안 · Q3]:

| 시점 | 볼 것 |
|---|---|
| T0 제출 직후 | 제출 영수증 state · job ID · squeue 상태 (PD / R) |
| T1 시작 확인 | `job_start.json` 생김 · simulator 파일 생김 · 로그 첫 줄 배너 (판 · git) |
| T2 첫 프레임 | 시작부터 30 분 안에 post 에 첫 파일 (S5) — DEV E0 r1 은 11.0 초 (`QY` q2 · 6 절) |
| T3 +1 h | 첫 1 시간 step/s 기록 (고-Bo 등록 선례 · `docs/reviews/mixer_highbo_prereg_20260927.md` L148 · L173) · E9 와 견주되 판정하지 않음 |
| 그 뒤 1 h 마다 | 아래 기록 칸 · S2 · S4 · S5 · S6 |
| T9 끝 | squeue 에서 사라짐 → sacct 한 줄 → 10 절 예약 대조 → 11 절 회수 |

- 기록 칸 (한 줄씩):

| 칸 | 내용 |
|---|---|
| 시각 | UTC |
| job | 정확한 job ID · squeue 상태 · 경과 시간 |
| 진행 | 마지막 프레임 step · 그 파일 수정 시각 · post 파일 수 |
| 저장 | post + restart 파일 크기 합 (바이트) · 런 폴더 파일 수 · 파일시스템 여유 바이트 · 여유 inode |
| 로그 | 마지막 thermo 줄의 step · Atoms 두 칸만 (KE 는 옮기지 않는다) · 첫머리 `ERROR` 줄 수 · 비유한 thermo 줄 수 · step 1 줄의 Atoms |
| 판단 | 계속 / STOP 권고 (S 번호) · 기록한 사람 |

- 빠진 칸 = UNKNOWN 이다 (정상 아님 · `F8/inventory.md` L54). UNKNOWN 이 두 번 이어지면 본 세션은 1저자에게 확인을 청한다 (STOP 권고는 S 조건으로만).

## 10. 예약 대조 (pilot 끝 · 또는 STOP 뒤 · 읽기 전용)

가드는 제출할 때 예약 파일을 남기고 스스로 지우지 않는다 (`F8/submit_one.py.txt` L66–86 · L99–105 · `F8/commands.txt` L72–78 · MLA-02). pilot 뒤 그 상태를 적어 둔다.

| 칸 | 볼 것 | 기대 |
|---|---|---|
| admission 폴더 | 파일 이름 · sha256 목록 | `PRECAL_E0.reservation.json` · `PRECAL_E0.submission.json` 둘. `admission.lock` 이 남아 있으면 HOLD (가드가 죽은 흔적 · L104–105) |
| 예약 파일 | case · np · approval_sha256 · campaign_policy_sha256 · state | PRECAL_E0 · 20 · 승인 묶음과 같음 · `ATTEMPT_RESERVED` |
| 제출 결과 둘 | admission 쪽 · 런 폴더 쪽 `submission.receipt.json` 의 state · job_id | 둘 다 `SUBMITTED` · 같은 job_id |
| 스케줄러 | `squeue -j <job ID>` · `sacct -j <job ID>` (State · ExitCode · Elapsed · AllocCPUS · NNodes · MaxRSS) | 큐에 없음 · 끝 상태 |
| job 끝 영수증 | `job_end.json` 의 state · returncode | 있음 / 없음 (6 절 끝) |
| 내 잡 | `squeue -u 나` 의 CPU 합 | 기록만 |
| 판정 | 대조 일치 / 불일치 | 어느 쪽이든 예약 파일은 그대로 둔다 — 지우기 · 옮기기 · 자동 해제 없음 |

- 예약 해제 · 정책 전환은 이 등록 밖이다 — 다음 wave (N0) 묶음의 검토된 절차로만 (12 절 W2 · `IN/author_policy_record.json` L16).
- 불일치 (예: 제출 결과가 `AMBIGUOUS_OR_FAILED_HOLD` · job_id 다름 · lock 남음) = 캠페인 HOLD. 1저자가 스케줄러를 손으로 대조한다 (`F8/submit_one.py.txt` L101).

## 11. 회수 · 가린 사본 반입 규칙

| # | 규칙 | 근거 |
|---|---|---|
| 1 | 회수 시점 = job 끝 (큐에 없음 · sacct 끝 상태) 뒤. 진행 중 복사는 미자격 | `F8/commands.txt` L53–57 |
| 2 | ibb 에서 런 폴더 전 파일 목록 (상대 경로 · 크기 · sha256) 을 먼저 만든다 → 새 빈 로컬 스냅숏으로 복사 (지우기 · 덮어쓰기 없음) → 로컬 목록과 대조. 불일치 · 빠짐 = 회수 미자격 | `F8/commands.txt` L54–57 · `F8/inventory.md` L58 |
| 3 | 목적지 = 1저자 WSL [추정 · 1저자 확인]. 이 컨테이너는 여유 8.4 GB 라 안 된다 | `docs/session_20260923_progress.md` L1437 · 5-4 |
| 4 | 관측기는 그 스냅숏에서 돈다 (`--case PRECAL_E0 --run <스냅숏>`) | `F8/commands.txt` L58 |
| 5 | 리포 반입 = **가린 사본만** · 새 증거 폴더 (예: `docs/data/mixer_e0_pilot_<날짜>/` [제안]): 승인 묶음 sha256 목록 · claim · 제출 영수증 · `job_start.json` · `job_end.json` · sacct 한 줄 · watch 기록 · 예약 대조 기록 · 회수 목록 (상대 경로 · 크기 · sha256) · `log.liggghts` · simulator.stdout / stderr · 관측기 JSON | 1저자 11-10 Q8 (`docs/data/mixer_e0_meta_ibb_20261110/README.md` L16 — 메타 블록의 규칙 "가린 사본만 · 새 증거 폴더 · raw 반입 안 함" 을 pilot 에 그대로 적용 [초안]) |
| 6 | 반입하지 않음: 덤프 1121 장 · 체크포인트 3 (목록 · sha256 만) · 가리지 않은 원문 (ibb 런 폴더 · 로컬 스냅숏에만) | 같은 곳 · `RCP` L45 |
| 7 | 가림 대상 = 메타 블록과 같다: 홈 경로 (로그인 · 실제) · 계정 · 호스트 · 노드 이름 · uid / gid · 빌드 사용자 (`compiled … by`) · 원격 파일시스템 이름 · IPv4 → `<HOME>` · `<HOME_REAL>` · `<USER>` · `<HOST>` · `<BUILD_USER>` · `<REMOTE>` 자리표 (노드 이름 = 초안 추가 — 메타 블록 목록에 없다 · squeue 의 노드 칸) | `docs/data/mixer_e0_meta_ibb_20261110/README.md` L9 · L22 · 같은 폴더 `out/meta_script.sh` L21 · L40–49 · L191–196 |
| 8 | 반입 전 검사: 가림 뒤 남은 토큰 0 (메타 블록과 같은 셈) + 본 세션이 계정 · 주소 · 포트를 따로 찾아 0. 하나라도 남으면 반입하지 않는다 | 같은 README L22 |
| 9 | 관측기 JSON 의 값 칸 (E0 t0 접촉 · 칸 원 분산) 을 함께 반입할지 = Q8 | — |

## 12. 다음 wave 판단 양식 (N0 로 가도 되나)

하나라도 "아니오" · "미확인" 이면 N0 는 HOLD 다. 자동 전이 없음. 이 양식은 판단의 칸이지 GO 가 아니다.

| # | 조건 | 근거 | 판단 (예 / 아니오 / 미확인) | 누가 |
|---|---|---|---|---|
| W1 | E0 자격 수용 기록 (7-2 "자격 수용") | M-2 L35 · `F8/README.md` L26 | | 1저자 |
| W2 | 예약 대조 일치 (10 절) + 검토된 예약 해제 · 정책 전환 절차 (author_go sha256 · max_concurrency 를 가진 새 campaign_policy) | `IN/author_policy_record.json` L16 · `F8/submit_one.py.txt` L50–55 · L74 · `F8/commands.txt` L72–78 | | 1저자 + 해당 리뷰 |
| W3 | N0 결과 전 등록 (walltime · 디스크 · STOP). 근거 = DEV 2 바퀴 회전 런 실측 (같은 out/ 에 시작 · 끝 시각 있음 — `mix3_run6` · `run15` · `run11` · `run16` · `run12` · `run21`). E0 정착 속도를 회전에 옮기지 않는다 (회전 NP20 ≈ 64 step/s 가 쌓인 E0 보다 8–18 % 느렸다) | `docs/reviews/mixer_highbo_stiffness_prereg_20260929.md` L346 · `F8/inventory.md` L64 | | 본 세션 초안 → 1저자 |
| W4 | 관측기 회전 경로 (bin 1 격자 · E0 기준 `--reference`) 의 실제 덤프 · 로그 호환. E0 pilot 은 t0 경로만 지난다 | 관측기 L298–302 · L393 · L402 | | 리뷰 |
| W5 | MXD2R 처분 · 원장의 열린 믹서 항목 (`MXD2-01` 등) 이 N0 에 닿는지 | `F8/submit_one.py.txt` L113 · `F8/README.md` L26 · 원장 `docs/reviews/findings.json` | | 1저자 |
| W6 | **Codex 반박 창 GO** — N0 는 first8 본 런이다. 내부 리뷰 대체는 E0 한 팔뿐 | 0 절 · `docs/session_20260923_progress.md` L1423 ④ | | Codex · 1저자 |
| W7 | 자원: 내 잡 CPU 합 + 20 ≤ 60 · 디스크 바닥 (N0 용 새 값) | `F8/submit_one.py.txt` L132–133 | | 1저자 (제출 전 5 분 안) |
| W8 | 1저자 `MAP_CASE_GO` (wave_release = [PRECAL_N0] · qualification_accepted 참) | `F8/submit_one.py.txt` L129 · L135 | | 1저자 |

## 13. ibb 읽기 전용 조회 q1–q9 (✅ 11-12 실행 · `QY`)

전부 읽기만 한다. 가린 사본만 반입한다 (Q8 규칙). 1저자 11-12 Q6 승인 → 조회 블록 (`query_block/` · 컨테이너 시험 675 PASS · 0 FAIL) → ibb 로그인 셸에서 91 초 · 조회 OK 54 · FAIL 1 · 판독기 rc 0 (0 절 `QY`). 결과는 아래 끝 열의 자리로 옮겼다.

| # | 무엇 | 명령 꼴 (초안) | 채우는 칸 | 11-12 결과 (`QY q.<q>.status_counts` · 판독 L6–14) → 옮긴 자리 |
|---|---|---|---|---|
| q1 | DEV E0 다섯 런의 post · restart 크기 | 런마다 `du -sk <런>/post <런>/restart` + 파일 크기 합 (`find -printf '%s'`) | 5 절 — 런별 실측 | OK 25 → 5-1 표 · 5-2 · 5-3 (1) (3) |
| q2 | 한 런의 프레임 크기 · 시각 | post 안 파일의 크기 · 수정 시각 목록에서 처음 3 · 가운데 1 · 끝 3 줄 | 프레임 한 장 크기 · 첫 프레임까지 시간 · 프레임 간격 | OK 4 → 4-3 · 6 절 S5 · 9 절 T2 |
| q3 | 전 정밀도와 기본 형식의 실제 크기 비 | 보충 폴더 (exact) 의 hp · g6 파일 크기 (6 열) | 5-3 의 폭 가정 검산 (12 열 아님) | OK 13 (폴더 6) → 5-3 (2) |
| q4 | 기본 할당 한도 | `lfs quota -U <마운트>` + `lfs quota -u <나> <마운트>` | `baseline_table.md` 5 절 "내 할당" | OK 1 · **FAIL 1** (`-U` = Permission denied · `q.q4.not_ok`) → 기본 한도 [미확인] 그대로 · 18 절 Q-H |
| q5 | OST 별 여유 | `lfs df <마운트>` | 같은 절 "OST 별 여유" | OK 1 → 5-4 · `baseline_table.md` 5 절 |
| q6 | DEV E0 잡 다섯의 기록 | `sacct -j 249080,249081,249082,249083,249084` (State · ExitCode · Elapsed · AllocCPUS · MaxRSS · ReqMem) | 4-1 대조 · 메모리 칸 | OK 1 → 4-1 · 4-2 · `baseline_table.md` 4 절 (MaxRSS = 다섯 다 빈칸 · step 줄 없음 → [미확인]) |
| q7 | 라이브러리 신원 | `readelf -d` 의 RPATH / RUNPATH 줄 + ldd 대상의 실제 파일 `sha256sum` | `baseline_table.md` 2 절 [미확인] 둘 | OK 6 → `baseline_table.md` 0-A · 2 · 2-A (30/30 · RPATH 1 줄) · 18 절 Q-G |
| q8 | 빈 코어 (발사 직전) | `sinfo` 의 CPU 할당 / 유휴 요약 | 대기 가늠 (판정 아님) | OK 2 → `baseline_table.md` 4 절 (시점 값 · 발사 직전엔 `MIX_Q=q8` 로 다시) |
| q9 | DEV E0 한 런 `log.liggghts` 의 thermo 표 안 비-행 줄 꼴 | thermo 머리 ~ Loop 사이에서 숫자 줄이 아닌 줄의 첫 낱말과 줄 수만 (숫자 값 · 본문 안 옮김) | 7-4 ③ 의 같은 덱 계열 확인 · Q5 고침의 fixture 근거 | OK 1 → 7-6 Q-B 대조 · E10 · 18 절 Q-F |

주의 (옛 문장 · 해소됨): q6 의 sacct 와 q9 의 로그 읽기는 지난 블록의 승인 범위 (sinfo · sacctmgr show · 내 squeue · 로그는 크기와 첫 배너 줄만 — out/ `meta_script.sh` L177 · L279) 밖이었다 → 1저자 11-12 Q6 으로 승인 · 실행됐다. 잡 번호는 out/ `seal_extract.txt` L968 · L928 · L568 · L448 · L728 이다 (= `QY bundle.fields` 의 `q1.r<i>.job`).

## 14. 하지 않는 것

- **판정**: 이 팔의 값으로 물리 · 과학 판정을 하지 않는다. 코팅 · 분산 · 응집 문장을 쓰지 않는다 (이 팔은 기준 · 로그 · I/O 자격용 · `F8/inventory.md` L70).
- **M 열람**: E0 는 M 을 내지 않는다 (관측기 L402). 다른 팔 · 확인 블록 · DEV 맹검 금고의 M 을 이 일로 열지 않는다.
- **확인 블록**: 확인 18 런 · 그 시드 (15485863 · 86028121 · 104395301) 를 건드리지 않는다.
- **문턱 개정**: 결과 · 감시 기록을 본 뒤 walltime · 상한 · 바닥 · 멈춤 문턱 · 점검표를 옮기지 않는다 (16 절).
- N0 · B1–B3 팔 · 둘째 팔 · 자동 후속 제출 (`F8/README.md` L22 · L26).
- 재시도 · resume · requeue · 체크포인트 이어 돌리기 (`P8/README.md` L29).
- NP · 덱 · 길이 · 허용폭을 속도나 결과에 맞춰 바꾸기.
- 옛 런처 · 옛 정책 · raw sbatch 로 내기 (`F8/inventory.md` L30 · `F8/commands.txt` L26).
- dev7 · dev7_v26 폴더에 쓰기 (Q5).
- ibb 의 기존 체크아웃을 pull · checkout 하기. 09-21 층상 런 폴더가 그 체크아웃 안에 있고 (out/ `fields.txt` L74), 가지 이름 없이 한 커밋에 놓여 있다 (떨어진 HEAD 로 읽힘 [추정] · `baseline_table.md` 7 절). pilot 소스는 새 폴더에 따로 놓는다.
- 강성 축 등록의 E0 진단 (접촉 겹침 1 %) 판정. first8 문서에 그 기준이 묶여 있지 않다 → 18 절 Q10.
- 예약 파일 지우기 · 옮기기 · 자동 해제 (10 절).

## 15. 한정

- 시간 실측은 다른 덱 (옛 밀도 세대 · 기본 형식 덤프 · 옛 러너) 의 것이다. pilot 의 시간은 [추정] 이다.
- 크기 실측은 DEV E0 다섯 런 (`QY` q1 · 기본 `%g` 12 열) 과 정확 좌표 6 열 (`QY` q3) 뿐이다. pilot (전 정밀도 12 열) 의 크기는 [미확인] 이고 5 절 상한은 산술 상한이다. (옛 "런별 실측이 없다 · 폴더 평균 [추정]" 은 11-12 조회로 대체됨.)
- `QY` 의 q4 · q5 · q8 은 2026-11-12T11:52–11:54Z 의 시점 값이다. q7 은 로그인 셸의 `ldd` 다 (job 안 아님). q9 는 첫 낱말 · 줄 수만 셌다 — 순서 · 자리 · 본문은 [미확인] (7-6).
- 실측 열 런은 seed 세 개 · 한 번씩이다. 분포가 아니다.
- 통과해도 물리 자격 · NP 20 인증 · 다음 팔의 GO 가 아니다 (`F8/README.md` L26 · 관측기의 `limitations`).
- 로그 조건 일치는 종료 코드 · rank · 바이너리 신원의 증명이 아니다 (`P8/README.md` L35).
- 7-4 는 다른 런의 로그 줄 · 덱 주석 · 메모리 안 재현으로 본 관찰이다. 실제 pilot 로그로 확인한 것이 아니다.
- 가드 · 러너는 가짜 sbatch 와 모의 프로세스로만 시험됐다 (`F8/README.md` L30 · L34).
- 운영 봉인 (`F8/source_seal.json`) 은 지금 HEAD 와 두 파일이 다르다 (생성기 · 되읽기 · 본 세션 sha256 대조 · `IN/README.md` L17). 어느 묶음으로 낼지는 봉인 단계 + 1저자다 (7-5). 11-12: Q5 고침이 리포에 들어가 HEAD 는 관측기까지 셋이 다르다 (HEAD = 재봉인 후보 12/12 · 7-6 [관찰]) · Q7 = 현재 소스 후보 쪽 (1저자 11-12).
- 11-12 부터 같은 계정 · 같은 QOS 의 G2c′ 잡이 ibb 에서 돈다 (`baseline_table.md` 4 절). 대기 시간 · 시작 시각은 [미확인] 이다.

## 16. 규칙 원장 (문턱 · 값 · 근거 · 정한 때)

| 문턱 | 값 | 근거 | 정한 때 | 개정 |
|---|---|---|---|---|
| walltime | `1-00:00:00` | 4-4 (DEV E0 열 런 실측 · 가장 느린 속도의 4.9 배) | 11-11 초안 (본 세션) · 11-12 이어 씀 · **1저자 11-12 Q1 권고대로** · 11-12 `QY` q6 대조 = 그대로 (sacct 속도 차 ≤ 0.05 %) | 비준 뒤 봉인 · 결과 · 감시를 보고 바꾸지 않는다 |
| 상한 (post + restart 파일 크기 합) | 29266573952 B | 5-3 (stage_gate 식 + `%.17g` 폭 24) | 11-11 초안 · 11-12 관측량 정의 (파일 크기 합 · du 아님) · **1저자 11-12 Q2 권고대로** | ✅ 봉인 전 한 번 = 11-12 `QY` q1–q3 대조 끝 (식 · 값 그대로 · 평균만 실측 · 5-5) — 다시 고치지 않는다 |
| 여유 바닥 | 32193231348 B | 상한 × 1.10 (`scripts/mixer_stage_gate.py` L84) | 11-11 초안 · Q2 권고대로 (11-12) | ✅ 상한과 같이 끝 (11-12 OST 최소 여유 = 바닥의 454.4 배 · 시점 값) |
| 파일 수 예산 · inode 바닥 | 1146 · 1261 | 5-4 목록 셈 × 1.10 | 11-12 (옛 1250 = 작은 파일 약 12 → 목록 셈) · Q2 권고대로 (11-12) | ✅ 상한과 같이 끝 |
| 멈춤 (S5) | 30 분 | 6 절 산술 | 11-11 초안 · Q3 권고대로 (11-12) · `QY` q2 대조 = 그대로 (가장 느린 구간 평균의 127 배) | 비준 뒤 고정 |
| 오류 · 소실 규칙 (S6) | 첫머리 `ERROR` · 비유한 · Atoms 감소 | 6 절 | 11-11 초안 · 11-12 첫머리 규칙 (덱 주석 메아리 제외) | 비준 뒤 고정 |
| watch 간격 · 사람 판단 시점 | 10 분 · 9 절 표 | 9 절 | 11-11 초안 (Q3) · 11-12 시점 표 · Q3 권고대로 (11-12) | 비준 뒤 고정 |
| 점검표 C1–C5 | 7-3 | 7-3 | 11-12 초안 · Q12 권고대로 (11-12) | 비준 뒤 고정 |
| 삽입 부족 (삽입 표 안 `Less insertions than requested`) | 관측 TECH (로그 계약) · STOP 사유 아님 | 7-6 ③ · E6 · 고친 관측기 bb2f3229… | 1저자 11-12 Q-A | 재봉인 뒤 고정 · E6 의 실효 허용 = 누락 0 |
| 관측 로그 허용 꼴 ①–④ | 7-6 표 | `fix_q5/patches/0002*` = 리포 f67c0cc92 | 1저자 11-12 Q5 · Q-B (`QY` q9 대조 = 첫 낱말 · 줄 수 맞음 · 순서 · 자리 [미확인]) · Q-D | 재봉인 뒤 고정 · 런 뒤 고치지 않는다 (Q-B) |
| 300 초 · cpu 60 · 동시 한도 | 기존 | `F8/submit_one.py.txt` L126 · L133–134 | 커밋 ae9a5ddc4 (2026-11-06) | 이 등록이 바꾸지 않는다 |
| NP 20 · 동시 1 팔 · 순서 | 기존 | `IN/author_policy_record.json` L13–17 | 1저자 11-09 | 같음 |
| 여유 1.10 · 원자당 400 B · `%g` 폭 12 · 머리 512 B | 기존 | `scripts/mixer_stage_gate.py` L84–86 · L315 | 커밋 e72067854 (2026-09-29) | 같음 |
| 초기 총누락 0 ~ 10 | 기존 | `scripts/mixer_precal_observe.py` L246 | 커밋 970a43837 (2026-11-04) | 같음 |

개정 절차: 등록 결함 (예: 정상 런이 원리적으로 못 지나는 문턱) 이 드러나면 원 규칙 / 새 규칙 / 이유 / 시각 · 커밋 / 그때 본 자료 / 보고 한정 을 이 표에 적고 1저자 비준 뒤 바꾼다 (고-Bo 등록 §12 꼴 · `docs/reviews/mixer_highbo_prereg_20260927.md` L338–343). 결과를 본 뒤 문턱을 옮겨 통과시키지 않는다.

## 17. 내부 반박 리뷰가 볼 것 (Q7 — 블록 + 기준 표 + 봉인 묶음을 실행 전에 한 번에)

이 목록은 봉인 뒤 한 번에 하는 리뷰의 범위다. 지금 초안 단계 리뷰의 지시서는 같은 폴더 `review_brief.md` (그 리뷰가 이 한 번을 대신하지 않는다).

| # | 볼 것 | 왜 |
|---|---|---|
| 1 | 7-4 의 재현 — 관측기 로그 계약에 실제 꼴 줄 넷을 넣어 본다. 덤프 머리 등 다른 실제 형식도 같은 식으로 본다 | 통과 정의가 닿을 수 없는 등록이 되면 안 된다 |
| 2 | 경로 꼴 — 홈이 심볼릭 링크를 지난다 (out/ `walk.txt` L77). 가드는 풀린 경로와 대조한다 (`F8/submit_one.py.txt` L43–46 · L52 · `F8/job_start.py.txt` L32). 계획 문서의 정본 root 문자열 (`F8/commands.txt` L25 · L69) 은 로그인 꼴이다 | 그대로 적으면 제출이 막힌다 [관찰] |
| 3 | 4 절 산술 — 시작 · 끝 시각 읽는 법 · step 수 · 배수. 다른 덱의 속도를 pilot 에 옮겨도 되는가 | walltime 근거 |
| 4 | 5 절 산술 — 폭 24 · 프레임 수 · 체크포인트 · 1.10 · 상한이 되는 조건 · 파일 수 예산. Lustre 는 집계 여유와 OST 여유가 다르다 | 바닥 · 상한 근거 |
| 5 | S5 의 30 분 · S6 의 읽는 법 · 점검표 C1–C5 가 계획 문서 범위 안인가 | 새 기준을 만들지 않았는지 |
| 6 | 라이브러리 30 개 sha256 을 받았다 (11-12 `QY` q7 · `baseline_table.md` 2-A · 옛 "29 개에 해시가 없다 (out/ `hashes.txt` L475–504)" 는 대체됨). 바이너리가 RPATH 로 사용자 conda 환경 (그룹 쓰기 가능) 에 묶인다 — 봉인 묶음의 binary / MPI 행이 그 목록을 담는가 · 발사 직전 다시 보는가 (18 절 Q-G) | 바이너리 sha256 만으로는 런타임이 고정되지 않는다 |
| 7 | Python 판 — ibb 3.10.20 (numpy 2.2.6) · 3.9.13 ↔ 시험 판 3.8.20 · 3.11.17 · 3.12.14 | 가드 · job 시작을 ibb 판에서 돌린 적이 없다 |
| 8 | 운영 봉인과 HEAD 의 차이 · 메타 후보 둘 · 관측기 고침 (7-5) · [관찰 · Q-E 기록 11-12] first8 묶음 시험 셋 (게이트 · CI 밖) 은 HEAD `ef68eb7da` 에서 이미 실패 (manifest · input/source drift · `fix_q5/README.md` 7 절) — 재봉인 뒤 다시 돌려 통과해야 한다 (7-6 순서 5) | 어느 소스 핀으로 봉인하는가 |
| 9 | 현장 조회 영수증 (`live_preflight`) 을 누가 · 무엇으로 만드는가. 가드는 참 / 거짓 칸만 읽는다 (`F8/submit_one.py.txt` L123–134) | 손으로 쓴 JSON 의 진위 |
| 10 | 권한 — 바이너리 · conda 환경이 그룹 쓰기 가능 (out/ `walk.txt` L75 · L79–82). 홈은 700 | 변경 통제가 정해져 있지 않다 |
| 11 | DEV 와 다른 러너 줄 (노드 1 고정 · conda 활성 없음 · 절대 경로 mpirun) 에서 라이브러리 · 런타임이 풀리는가 — 11-12: 링크 라이브러리는 바이너리 RPATH 로 conda 활성 없이 풀린다 [관찰 — 로그인 셸 ldd] · `./` 갈래 7 개는 conda 라이브러리 자신의 `$ORIGIN` 길 [추정] · job 안 LD_LIBRARY_PATH · MPI 런타임 = [미확인] | 처음 쓰는 조합 |
| 12 | 메타 수집 블록 자체 — 가림 한계 (낱말 경계) · `-h` 가 로그인 노드에서 MPI 를 띄운 흔적 (out/ `fields.txt` L489) | Q7 의 "이 블록" |
| 13 | 원장의 열린 믹서 항목이 이 팔에 닿는가 — `MIX-11` · `MXD2-01` · `SELF-62` (open) · `MLA-01`–`03` · `MIP-01` · `MXD2R-04` · `MXD2R-R01` (claimed_fixed) | 한정 종결 범위 |
| 14 | 승인 묶음에 꼭 있어야 하는 영수증 — author_go · qualification · mxd2r_disposition · live_preflight · source_manifest · policy · runner · binary · mpi_launcher (`F8/submit_one.py.txt` L113) · live_preflight 의 참 칸 다섯 (qos · disk · inode · d07_finished · paths · L127) · `runner_reviewed` · `walltime_approved` 참 (L159) · D0.7 근거 (`baseline_table.md` 0-A) | 빠진 것이 없는지 |
| 15 | 관측기가 E0 에서 t0 밖을 안 본다 (7-1 끝) — 점검표 C3 이 그 자리를 채우는가 | I/O 자격의 빈 곳 |
| 16 | 감시 · 예약 대조 · 회수 · 다음 wave 양식 (9–12 절) 의 칸이 가드 · job 시작 코드가 남기는 파일과 맞는가 | 양식이 없는 파일을 요구하지 않는지 |
| 17 | G2c′ 잡과 같은 QOS 를 나눠 쓸 때의 제출 · 대기 (가드 S0b) | 11-12 의 새 사실 |
| 18 | Q5 고침 자체 (패치 0001 · 0002 · 관측기 bb2f3229…) — 허용 꼴 ①–④ 의 조건 · 반례 62 · 변이 25 · q9 대조의 한정 (7-6) | 시험 · 반례 · 변이를 고친 같은 조수가 만들었다 · 실제 pilot 로그 아님 (`fix_q5/README.md` 8 절) |
| 19 | 메모리 지정 없는 잡의 ReqMem = 515000M = 노드당 메모리와 같은 값 (11-12 `QY` q6 · `baseline_table.md` 4 절) — 대기 · 노드 공유에 주는 영향 · MaxRSS 빈칸 | 11-12 의 새 사실 · 메모리 사용량 [미확인] |

## 18. 1저자가 정할 것 (질문 + 권고 한 줄)

| Q | 질문 | 권고 | 1저자 11-12 |
|---|---|---|---|
| Q1 | walltime 을 `1-00:00:00` 으로 할까요? | 예 — 가장 느린 실측 속도로 4.9 h, 여유 4.9 배. 재시도 없는 한 팔이라 시간 초과가 더 비싸다 | ✅ 권고대로 (11-12 sacct 대조 = 그대로 · 4-2) |
| Q2 | 디스크 수치 (post + restart 상한 29266573952 B · 여유 바닥 32193231348 B · inode 바닥 1261) 를 등록값으로 할까요? | 13 절 q1–q3 로 프레임 실측을 받아 봉인 전에 한 번 확인한 뒤 등록 — 지금 값은 실측이 아니라 산술 상한이다 | ✅ 권고대로 · q1–q3 확인 끝 = 그대로 (5-5) |
| Q3 | 멈춤 문턱 "30 분 동안 새 프레임 0" · watch 기록 10 분 · 사람 판단 = 9 절 표 (첫 프레임 · +1 h · 그 뒤 1 h 마다 · 끝) 로 할까요? | 예 — 예상 프레임 간격 (≤ 16 초) 의 100 배 남짓 · 4–5 h 런이라 1 h 판단이면 충분하다 | ✅ 권고대로 (11-12 q2 대조 = 그대로 · 6 절) |
| Q4 | 런 폴더: first8 제안 이름 그대로 발사 때 새로 만들고, 봉인 묶음 · 정책의 경로는 풀린 꼴로 통일할까요? | 예 — 가드가 풀린 경로와 대조한다 | ✅ 권고대로 |
| Q5 | 관측기 로그 계약의 네 어긋남 (7-4) 을 발사 전에 고칠까요? | 예 — 시험 먼저 (fixture = 리포의 같은 빌드 로그 줄 + 덱 L34 + q9) → 고침 (알려진 비-행 줄만 허용 · 나머지는 그대로 TECH) → 재봉인 → 내부 반박 리뷰 범위. 런 뒤에 판독기를 고치는 것은 피한다 | ✅ 권고대로 · 고침 리포 반입 (51d45732c · f67c0cc92 · 7-6) · 재봉인 = 별도 승인 |
| Q6 | 13 절의 읽기 전용 조회 아홉 줄 (sacct · 로그 꼴 포함) 을 승인할까요? | 예 — 런별 크기 · 기본 한도 · 라이브러리 해시 · 실제 비-행 줄 꼴이 여기서만 나온다 | ✅ 권고대로 · 11-12 실행 (13 절 · `QY`) |
| Q7 | 어느 소스 묶음으로 봉인할까요? (원 봉인 + 원 메타 + 원 핀 소스 / 현재 소스 후보 + 새 메타) | 현재 소스 후보 쪽 + Q5 고침 — HEAD 소스와 맞고, Q5 고침이 관측기 sha256 을 바꿔 어느 쪽이든 재봉인이 든다 (7-5). 운영 봉인 교체는 1저자 별도 승인 사항이다 | ✅ 권고대로 (운영 봉인 교체 = 별도 승인 · 7-6 순서) |
| Q8 | 회수 · 반입: 전 덤프 (약 29 GB) 를 1저자 WSL 로 다 가져오고, 리포에는 가린 기록 + 관측기 JSON (값 칸 포함) 을 넣을까요? | 예 — 먼저 로컬 여유 ≥ 32.2 GB 확인 · 값 칸은 판정 · 과학 문장에 쓰지 않는다 (14 절) | ✅ 권고대로 |
| Q9 | 성능 · 자원에 합격선을 둘까요? | 두지 않는다 — 실측을 보고만 하고 다음 팔 시간표의 입력으로 쓴다 | ✅ 권고대로 |
| Q10 | 이 팔에서 접촉 겹침 (강성 축 등록의 1 %) 을 잴까요? | 이 팔의 판정에는 넣지 않는다 — 재려면 보고 전용 항목으로 따로 등록 (도구의 새 밀도 세대 지원은 원장 `MXD2-01` open) | ✅ 권고대로 |
| Q11 | G2c′ (ibb · 같은 QOS cpu-60) 와 이 pilot 의 순서는? | G2c′ 먼저 (언로딩 = DEM 우선 Ⓐ · 1저자 11-04) · pilot 은 내 잡 CPU 합 + 20 ≤ 60 일 때만 (가드가 강제) · 겹치면 1저자가 정한다 | ✅ 권고대로 |
| Q12 | 자격 검토 점검표 C1–C5 (7-3) 를 결과 전 거부 기준으로 등록할까요? | 예 — 기록 대조만이고 물리 문턱이 아니다 · 관측기가 E0 에서 t0 밖을 안 보므로 C3 이 덤프 결손을 잡는다 | ✅ 권고대로 |
| Q13 | 예약 대조 (10 절) 는 pilot 끝에 기록만 하고, 예약 해제 · 정책 전환은 N0 묶음의 검토된 절차로 미룰까요? 다음 wave 판단 양식 (12 절) 을 채택할까요? | 예 · 예 — 가드에 자동 해제가 없고 (MLA-02) N0 는 Codex GO 대상이다 | ✅ 권고대로 |

관측기 고침 질문 Q-A–Q-E (`fix_q5/README.md` 9 절) = 1저자 11-12 권고대로 → 결정과 반영 자리 = 7-6 표.

### 11-12 조회 뒤 새 질문 (결과 전 · 문턱 변경 아님)

| Q | 질문 | 권고 |
|---|---|---|
| Q-F | q9 는 첫 낱말 · 줄 수만 셌다 — NP 20 삽입 런에서 보고 두 줄의 순서 · 표 안 자리 (첫 행 바로 뒤) · 앞 공백은 확인되지 않았다 (7-6). 봉인 전에 그 셋만 세는 읽기 전용 보충 조회 (q9b — 같은 DEV E0 r1 로그 · 비-행 줄마다 표 번호 · 그 앞 숫자 행 수 · 앞 공백 수 · 가린 첫 낱말만 · 숫자 · 본문 안 옮김) 를 한 번 더 할까요? | 예 — 블록 꼴 · 컨테이너 시험 먼저 · 조회 1–2 분 [추정]. 자리가 다르면 정상 pilot 이 관측 TECH 로 끝나고 런 뒤에는 고치지 않는 규칙이라 (Q-B) 봉인 전에 닫는 쪽이 싸다. 안 하면 "소스 판독 + 1 프로세스 로그" 한정을 붙여 봉인 |
| Q-G | 링크 라이브러리 30 개 sha256 (`baseline_table.md` 2-A · `QY` q7) 을 봉인 묶음 (binary · MPI 행 옆) 에 목록으로 넣고, 발사 직전 (live_preflight 와 같은 때) `MIX_Q=q7` 로 다시 받아 대조할까요? (job 안 대조는 job 시작 코드를 바꿔야 해서 이번 범위 밖) | 예 — 바이너리가 RPATH 로 사용자 conda 환경 (그룹 쓰기 가능) 에 묶여 바이너리 sha256 만으로는 런타임이 고정되지 않는다. 코드 변경 없이 목록 대조만 · 다르면 제출하지 않고 1저자 |
| Q-H | 기본 할당 한도 (`lfs quota -U`) 는 권한이 없어 못 읽었다 (`QY` q4 · 내 칸 = quota 0 · limit 0 + "기본 설정을 쓴다" 두 줄). job 시작 대조기는 파일시스템 여유만 보고, 할당은 live_preflight 의 `disk` 참 칸 (사람이 쓰는 값) 몫이다 (`F8/job_start.py.txt` L43 주석). 관리자에게 기본 한도를 물을까요? | 예 — 한 줄 문의 (발사 전). 답이 없으면 `disk` 참에 "기본 한도 [미확인] · 내 칸 0 · 0" 한정을 붙여 1저자가 정한다. 지금 쓰기가 되는 것은 한도가 있어도 사용량 (2228984468 KB) 위라는 뜻일 뿐 남은 여유는 모른다 [추정] |

## 19. 근거 목록

| 묶음 | 파일 |
|---|---|
| 받은 메타 | `docs/data/mixer_e0_meta_ibb_20261110/README.md` · 같은 폴더 `out/` (fields.txt · probes.txt · hashes.txt · seal_extract.txt · walk.txt · slurm_* · df_* · lfs_quota_home.txt · mpi1_version.txt · mix1_du.txt · mix2_du.txt · mix3_du.txt · mix2_run*_ls.txt · mix3_run*_ls.txt) |
| 계획 | `FQP` · `RCP` · M-2 (원격 가지 판 · `git show 0c56deba6:docs/reviews/mixer_qualification_plan_20261110.md`) · `docs/reviews/nonrint_next_decisions_20261109.md` 3 절 |
| first8 | `F8/` (README.md · inventory.md · commands.txt · blockers.json · submit_one.py.txt · job_start.py.txt · run_one.sbatch.txt · source_seal.json · static_asset_manifest.json · campaign_policy.json.example · planned_assets/) · `P8/README.md` · `docs/reviews/mixer_precal_exploration_registration_draft_20261104.md` · `IN/` (README.md · author_policy_record.json · candidate/) |
| DEV 덱 · 기록 | `docs/data/mixer_highbo_dev_decks_20260930_v26/` · `docs/data/mixer_highbo_dev_decks_20260930/` · `docs/data/mixer_highbo_devbo_prelim_20261003/README.md` · `docs/data/mixer_highbo_devu_prelim_20261006/` (README.md · exact_runs/) · `docs/reviews/mixer_highbo_stiffness_prereg_20260929.md` §8-3 · `docs/reviews/mixer_highbo_prereg_20260927.md` §2-5 · §8 · §12 |
| 같은 빌드의 실제 로그 (7-4) | `docs/data/mixer_highbo_devu_prelim_20261006/exact_runs/exact_LU212_settled/log.exact` · `docs/data/kg50_d07_end_20261105/kg50_d07_b50_log_main1103.liggghts` · `…/kg50_d07_b50_log_ins1.liggghts` · 같은 폴더의 로그 셋과 stdout |
| 코드 | `scripts/mixer_precal_observe.py` · `scripts/mixer_stage_gate.py` · `scripts/measure_mixing_index.py` (planned_t0) · `dem_scripts/mixer_20260921/launch_highbo.sh` |
| 결정 · 상태 기록 | `docs/session_20260923_progress.md` L822 · L1322 · L1423 · L1428 · L1430 · L1437 · L1445 · `docs/reviews/p1_g2c_sandbox_20261104/README_g2cp.md` L71–80 · `docs/reviews/findings.json` |
| 본 세션 재현 | 이 폴더 `work/check_log_contract.py` · `work/check_log_contract_output.txt` |
| 11-12 조회 (`QY`) | scratch `intake/mixer_e0_query_20261112/` (판독 요약 `summary.json` · 판독 화면 `reader.log` · 가린 out/) · 조회 블록 `query_block/` (`README.md` · `src/query_script.sh` md5 664376ce… · `read_query_bundle.py`) |
| 관측기 고침 (Q5) | scratch `fix_q5/` (`README.md` · `patches/0001*` · `0002*` · `seal_candidate/` · `evidence/`) |
| 조회 뒤 대조 | 이 폴더 `fill_report.md` · 고치기 전 판 `e0_pilot_registration_draft_before_query.md` |

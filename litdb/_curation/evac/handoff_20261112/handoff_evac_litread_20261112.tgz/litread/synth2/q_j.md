# 질문 j — 배치별 근거 묶음 (원문 줄 그대로 · 파일 43 개)

### [batch_01] j. 카드가 스스로 "아직 못 한다 · 한계" 라고 적은 것 가운데 가압 · 탈압 계산과 닿는 것

- [j] bardenhagen2000_mpm_granular_multibody_frictional_contact | 압밀 · 치밀화 · 기공률 계산 없음 (전단과 경사면뿐) · 3D 없음 · "압밀에서 이 알고리즘이 어떻게 행동하는지 (고밀도 · 다접촉 노드) 는 이 논문으로 알 수 없다". 정확한 접촉은 모양이 격자로 해상된 매끈한 알갱이에서만 · 공통 법선이 아니라 운동량 보존 오차 · 건조 미끄럼 마찰만 · 지름 4 요소 알갱이의 내부 응력 부정확 · 알갱이별 장의 저장 · 메모리 미기재 · 반발 계수 자리 없음 | §3-3 (L122–131) · §11 (L369–375) · §12 (L384) | stated · 카드의 "없는 값" 목록 | 2D
- [j] bardenhagen2000_mpm_granular_multibody_frictional_contact | 카드 추론: 접촉 판정 거리 = 셀 크기라 표면이 닿기 전에 접촉이 걸려 기공률을 올리는 계통 오차 후보 (2차 B-spline 은 지지 3 셀이라 더 김) → 순수 SE 가압을 dx 사다리로 확인할 것 | §9-③ (L331) · §10 행동 5 (L360) | [두 논문 밖 · 우리 추론] | 미시험
- [j] bardenhagen2001_mpm_improved_contact_granular_stress_waves | 접촉 노드에서 견인력 평형 불성립 · 서로 다른 재료는 분리 시점이 어긋날 수 있고 "particularly when material response allows for permanent set (e.g. plasticity)" · 암시적 MPM 이면 제거 가능. 접촉 노드당 물체 ≤ 2 (N > 2 불성립) · 계면 해상도 = 셀 크기 · 작은 격자 질량에서 접촉 보정 폭주 (시간 간격 의존) · γ < 0.5 침투 · 접촉 = 완전 비탄성 충돌 · 압밀 · 제하 곡선 없음 | §12 (L359–369) · §0 (L22) · §4-3 (L137) · p.512 | stated | 시험은 탄성 재료뿐 — 소성 계면은 서술만
- [j] bardenhagen2001_mpm_improved_contact_granular_stress_waves | 카드가 읽은 우리 코드: 판 위 노드를 판 속도에 양방향 고정 (분리 판정 없음) → 제하 때 판에서 떨어지지 못함 (`scripts/mpm3d_compaction.py` 2996–2998 행). 우리 정의 문서의 "탈압 = 없음 (부분만)" | §11 행동 1 (L346) · §9 (L308) | [우리 코드 판독] | 논문 밖
- [j] devaucorbeil2020_mpm_after_25_years_review | MPM 수렴 비최적 (매우 고운 격자에서 비수렴) · BC 부여 어려움 · null-space · 큰 메모리 (ULMPM). 카드: 우리 MPM 은 fracture 미구현 (SE 균열 없음) | §6 (L68–69) · §5 (L51–52) | intro stated / 카드 서술 | 원문 §2–6 미열람
- [j] klar2016_dp_sand_animation | 저자: DP 만 조사 · DP 원뿔은 2D 에서만 Coulomb 등가 · 점착은 미래 과제 · 정량 검증 · 수렴 연구 없음. 카드의 우리 쪽 기록: 입자를 푸는 LPSCl 계산에 DP + 캡을 넣으면 300 MPa 에서 0.8 % 로 과압축 (캡 없음 11 %) | §4.6 (L153–157) · §6 (L182) · §7-(1) (L219–220) | 저자 명시 / 표지 없음 (우리 쪽 기록) | 모래 · 우리 쪽 기록은 논문 밖
- [j] lim2025_virtual_calendering_framework | strain-controlled 선형 탄성 압축이라 스프링백 미반영 (윗면이 실제보다 평평) · 모든 상 선형 탄성 (소성 흐름 없음). crackable (응력 문턱) ≠ cracked (실제) — 파괴 · 계면 물성을 넣은 모델은 future work | §3.2 (L146–148) · §6.3 (L231–234) · §9(F) (L351–358) | 카드 표기 "한계(명시)" · "정밀 주의(명시)" | Li-ion 액체계
- [j] choi2024_digital_twin_review_echem | 총설의 제한: (i) 미세구조 해석이 수십 µm 로 국한 (ii) 동적 거동 (균열 · 부피 팽창 · 접촉 손실) 추정 어려움 · 계산 부담 (iii) AI 가속 필요. 카드: 스프링백 (Fig 6c) 은 "우리 MPM 미구현 (rate-independent J2)" | §8.2 (L370–372) · §8.1 (L342–343) · §11(D)-3 (L492–493) | 표지 없음 | 총설 · 값 없음
- [j] nam2026_dpe_microstructure_review | 리뷰: 캘린더링 중 응력이 비균일하게 전달 → 국소 과압축 · 잔류 void · 입자 균열 · 밀도 구배. 카드가 적은 우리 쪽 빈칸: 캘린더링의 온도 · 점탄성 · 전단장 (feed / nip zone) 을 우리 MPM 은 다루지 않음 (압력 / 변위만) | §3.0 (L189–190) · §8(D)-3 (L514–517) | 표지 없음 | Li-ion 건식전극 · 롤 캘린더링


### [batch_02] j. 카드가 스스로 "아직 못 한다 · 한계" 라고 적은 것 가운데 가압 · 탈압 계산과 닿는 것

- [j] nezamabadi2022_mpm_cd_plastic_particle_compaction | 저자: "this model still needs to be validated with a more detailed and quantitative comparison between simulations and experiments." · 고 Φ 에서 모델–MPM 발산 → 접촉부의 작은 곡률 반경을 풀려면 이산화를 더 잘게 · "Obviously, the disks do not represent real particle shapes" | §5.4 (L269–272) · §4.7 (L224) | stated (원문 따옴표 인용) | 2D
- [j] nezamabadi2022_mpm_cd_plastic_particle_compaction | 카드: "3D · 우리 규모 (SE 32,832 + AM 457) · 강체 AM 과의 혼합 · 제하 (unloading) · 실험 검증은 이 논문에 없다" · 비용 · 확장성 정보 0 · 느슨한 충전의 재배열 단계 (0.78 → 0.8) 를 거의 다루지 않음 · 큰 회전 · 큰 변형률의 객관성 처리 미기재 (구성식은 미소변형 이론) | §0 (L39) · §4.2 (L175) · §4.3 (L180–181) · §11 (L474–476) | 표지 없음 (카드 판정) | —
- [j] nguyen2017_mpm_bpm_deformable_particle_compaction | 저자: BPM 은 "40% of deformation and a packing fraction of 0.93" 에서 내부 공극 한계 · BPM 의 마찰은 "can not be mobilized because these primary particles can rotate freely without dissipation"; 카드: MPM 은 탄성뿐 · 집합체 제하 · 3D · 강체 혼합 · 실험 없음 | §3.3 (L128) · §5.2 (L194) · 머리 (L14) · §11 (L356) | stated / 카드 판정 | 2D
- [j] pycompact2025_dem_mpfem_workflow | 저자: "Although this study focused on two unimodal powders and small RVEs…" (확장은 future work) · "Despite the computational cost of DEM–MPFEM simulations due to explicit time-stepping and contact resolution [13,14,31]…" · 편차 원인 5 가지 (메시 해상도 · PSD 패킹 변동 · 마찰 알고리즘 차이 · RVE 경계 효과 · 두 explicit 솔버 차이) · "assuming perfectly spherical particles slightly reduces densification compared to real irregular powders" | §11 (L508–512) · §5-(e) (L251–252) | stated | 금속
- [j] pycompact2025_dem_mpfem_workflow | 카드: 메시 미수렴 (요소 수는 비용이 정함) · 5 MPa 판독 문턱이 수직 구간 위 · 제하 뒤 상대밀도 세 경로 5–7 %p 안 닫힘 · 펀치 속도 · 질량 스케일링 미기재 · PEEQ 1.3 에서 tet 왜곡 (remeshing 무언급) · 우리 침대에 쓰면 ≈ 8,300 h ≈ 1 년 (24 CPU · 요소 65.7 M) | §9.1 (L372–384) · §10 (L465–481) · §7.2 (L325–330) · §15.1 (L608) · §11 (L499–505) | derived(ours) · digitized · 카드 판정 | 비용 어림은 "자릿수 전용" (L499)
- [j] alabdali2023_cgmd_wet_manufacturing_ssb_cathode | 저자: δ_e 가 압연 30 % 뒤 꺾이는 것은 "a limitation shown by the model" · "the usability of this model might be limited for calendering degrees under 35 %" · δ_e · τ_g 는 "preliminary indicator" · 건조는 균질 건조 모델 | §10-1~3 (L666–670) · §6 (L334–335) | 표지 없음 (원문 따옴표 인용 · 카드 표기 "저자가 스스로 적은 한계") | —
- [j] alabdali2023_cgmd_wet_manufacturing_ssb_cathode | 카드: 압력이 없다 (Heckel · 항복 · 강성 · springback 정의 불가) · 평판 하강 속도 미보고 · 압연 뒤 평판 제거 없음 · 소성 없음 · 압연 단계 무검증 ("압연도는 추가 자유도") | §10-4 (L673–675) · §10-20 (L709–710) · §4-6 (L257–272) · ★①-(5) (L418) | 표지 없음 (카드 판정) | —
- [j] stomakhin2013_mpm_snow_elastoplastic | 정량 검증 · 실험 앵커 · 수렴 없음 (렌더 프레임만) · 값은 "useful starting point" · 정확도보다 제어성 · 시각적 사실성 우선 | §4.2 (L102–104) · §10 (L222–223) | 표지 없음 (카드가 "저자가 명시" 라 적음) | 눈
- [j] 우리 쪽 한계 (카드 안) | 우리 DEM 의 18 배 연화는 제하 축에서 체적 회복 26.7 % 로 "비물리적 … 지금은 노출되지 않은 잠재 한계" (pycompact2025 §15.5 L691–693) · 우리 MPM 제하는 300 → 90 MPa 재시작 기능뿐 (nezamabadi2022 L354) · 단일 속도장 MPM 은 접촉 분리가 없어 제하를 과소평가할 수 있음 (nguyen2017 §8-⑤ L298–300) | 세 카드 | derived(ours) · 표지 없음 · "우리 추론" | 논문 값 아님
- alizadeh2018: 가압 · 탈압과 닿는 한계 서술 없음.


### [batch_03] j. 카드가 스스로 "아직 못 한다 · 한계" 라고 적은 것 가운데 가압 · 탈압 계산과 닿는 것

- [j] arzt1982_particle_coordination_densification_spheres | impingement (D ≳ 0.9) 이후는 "엄밀히 무효" (저자) · 본격 처리와 가공경화 포함 냉간 압밀 완전 이론은 [8] Fischmeister & Arzt ("Powder Metall. To be published" — 출판 서지 [미확인] · 카드에 내용 없음) | §10 (L433) · §4-6 (L147) | stated · [미확인] | 단분산
- [j] arzt1982_particle_coordination_densification_spheres | 재배열 · 불균질 치밀화 · 이웃 접촉 상호작용 (다중접촉) 무시 · 등방압 (die 단축은 국소압으로 바꿔야 — "우리 DEM 은 단축 판 압축") · 접촉 조각 겹침을 빼는 식 없음 · 접촉 면적 합의 명시적 상한 부등식 없음 | §10 (L434–435) · §L-2 (L300–301) | stated (원문 가정) · 카드 판독 | 탈압은 범위 밖
- [j] bouvard2000_hard_soft_powder_densification | Heckel 형태 (ln 1/(1−D) = KP + A) 정량 적합 없음 (ρ-vs-P / t 곡선 · 임계만) · 시뮬 파라미터 (접촉법칙 · E_eff · grid) 없음 · 패킹 모사는 힘 없는 순기하라 압밀 force-chain 은 SEM 정성뿐 · 형상 (각질 > 구형 방해) 축은 구만 쓰는 모델이 못 봄 | §6 (L78 · L83) · §10 (L112 · L114 · L117) | 표지 없음 (카드 서술) | 금속 + 세라믹
- [j] cardenasbarrantes2020_rigid_deformable_mixture_compaction_nscd | 하중 쪽만 (탈압 · 히스테리시스 · 잔류 변형 없음) · 초탄성이라 소성 잔류 없음 · 크기비 · 비구형 · 3D · 소성 입자 · 점착 · 파쇄는 범위 밖 (결론의 확장 과제 = 소성 입자 · 비구형 · 다분산 · oedometric 하중) · 접촉 유형별 분해 없음 · 식 (15) 를 대입한 완전 예측 곡선 없음 · 계산 시간 · Δt · 허용오차 미기재 | §3-5 (L165–173) · §5-9 (L338–340) · §12 (L571–574 · L588 · L595–596) | stated · [미확인] | 2D
- [j] cardenasbarrantes2020_rigid_deformable_mixture_compaction_nscd | 카드가 적은 우리 쪽 한계: 단일 속도장 MPM 은 닿은 SE 가 융합 (미끄럼 · 분리 없음) 해 Z · σℓ · 접촉 길이 · μ 의존이 "정의조차 되지 않는다" · AM = 얼린 장애물이라 강체 골격이 정하는 바닥 (φmax(κ)) 기전을 지움 · "우리 기록상 이 연속체 MPM 은 연화 없이 분말 압밀을 재현하지 못했다" | §0 (L26–27) · §1 (L65–66) · §8-6 (L472–473) · §9-2 (L492–494) | 표지 없음 (우리 쪽 기록 · 카드 해석) | 논문 문장 아님
- [j] cardenasbarrantes2021_soft_rigid_mix_compaction_proceedings | 다음 길 = 3D 계 · 더 실제적인 형상 · 다른 압밀 조건 · 계산 비용 · Δt · E 절대값 없음 · 탈압 없음 | §5-6 (L141–142) · §3-4 (L105–106) · §7 (L168–169) | stated | 학회 단편
- [j] cardenasbarrantes2022_soft_hard_grains_compaction_experiment_dic | 하중 쪽만 · kPa · 2D · 초탄성 — 탈압 · 소성 · 3D 는 범위 밖 · SM 미보유 (Γ · φJ 선택 · 일축 유도 [미확인]) · 작은 κ 의 불일치 = 급격한 재배열 + 계가 작음 (n ≈ 100) (저자 해석) | §0 (L32) · §5-2 (L207–208) · §12 (L396 · L400–401 · L411–412) | stated · [미확인] | —
- [j] banerjee2019_tunneling_tlm_parallel_nanoscale_contacts | 가압 · 탈압과 닿는 서술 없음 — 접합 처리 = 접촉력 · 변형 없음 · 진공 간극이라 "압밀 전극의 섬유 접합 (SE · PTFE 막 · 변형) 과 다르다" | §4 (L84) · §11-6 (L163) | 표지 없음 | 전자 수송 쪽 한계
- [j] begat2004_cohesive_adhesive_balance_afm_colloid_probe | 가압 계산과 직접 닿는 한계 없음 — 닿는 한 줄: 고압 압밀로 만든 기판은 결함 · 비정질 영역이 표면 에너지를 바꿀 수 있어 원문이 결정 기판을 썼다 (p.1592) | §7-4 표 (L178) · §8-5 (L201) | [인쇄] + [추정] | 의약 분말 · 황화물 적용은 카드 추정


### [batch_04] j. 카드가 스스로 "아직 못 한다 · 한계" 라고 적은 것 가운데 가압 · 탈압 계산과 닿는 것

- [j] coetzee2017_dem_calibration_review | 리뷰가 다루지 않는 것 (카드 범위 상자): 냉간 고압 압밀 · 300 MPa · 소성 캡 (Thornton–Ning p_y · EEPA · Storåkers) · 다접촉 mean-field · 접촉 소성 · 입자 형상 소성 · Heckel · porosity floor — "방법론은 전이되지만 파라미터·가드레일은 전이되지 않는다" | §1 (L17–19) · §3 (L47–52) · §13 (L964–974) | 카드 판정 | 리뷰는 저응력 벌크 핸들링 문헌
- [j] coetzee2017_dem_calibration_review | 파라미터는 응력 의존 → 맞춘 응력 = 쓰는 응력: Li [189] "the parameter and property values are stress dependent and the stress levels used in the calibration experiment should be carefully selected." (p.129) · Franco [196] 전단 시험을 최종 응용의 수직 응력 범위에서 (p.130). 카드 W7: 100 / 200 / 600 MPa 로 넓히면 리뷰 기준 외삽 | §5-Q6 (L445–452) · §10.3-W7 (L843–848) | 원문 인용 · W7 = 우리 쪽 판정 | 삼축 · 전단 (저응력) 근거
- [j] coetzee2017_dem_calibration_review | 비유일성과 검증 규약: "more than one set of parameter values will produce the same bulk response for a given experiment" → 실험마다 파라미터 하나를 고립하거나 여러 실험의 교집합 (p.123) · "the calibration experiment is different from the final experiment or application being modelled" (p.106) · 검증 시험은 그 파라미터에 민감해야 (p.125). 카드 W1 = 유일성 미시험 (ε@300 의 μ · COR 민감도 미측정) · W2 = 검증이 맞춘 시험과 충분히 다르지 않음 · W2′ = σ 가 E 에 둔감 | §5-Q4 (L332–339) · §5-Q5 (L395–410) · §10.3 (L785–807) | 원문 인용 · W = 우리 쪽 기록 | —
- [j] coetzee2017_dem_calibration_review | 마찰이 벌크 밀도 · 공극에 영향: 마찰계수는 벌크 밀도에도 영향 [203,187] → 마찰 보정 뒤 밀도 재보정 · Hart / Härtl & Ooi [126,198] 공극률 / 공극비는 μ ↑ 에 따라 증가 · μ ↑ → 배위수 감소 | §5-Q4 처방 A (L346) · 카드 §6 의 "§5.4" 요약 (L634–635) | 리뷰 stated (소환) | 유리구슬 직접 전단 · 저응력 — 기공을 표적으로 값 하나를 맞출 때 고정한 마찰이 섞일 수 있다는 방향만
- [j] coetzee2017_dem_calibration_review | W3 겹침 (우리 쪽): 순수 SE 침대 ⟨δ⟩ ≈ 직경의 11–12 % = 반지름의 22–24 % ⇒ Paulick 기준의 ~22× · "접촉법칙(Hertz/선형) 자신의 소변형 가정 밖에서 운용 중" · ε_sphere ↔ ε_union 규약 차 1.251 %p (렌즈 겹침 SE–SE 0.402 + AM–SE 0.848) | §10.3-W3 (L809–816) | 표지 없음 (우리 쪽 기록 · "우리 실측") | 출처 런 카드에 없음
- [j] coetzee2017_dem_calibration_review | W4 · W5 · W6 (우리 쪽): 강성을 낮추면 배위수가 올라 역학 보정이 수송 그래프를 정함 · 24 → 1.35 구간의 배위수 / 접촉 면적 변화는 미측정 / 구 + rolling 없음이라 침대 전단 강도가 원리상 과소 → 재배열이 쉬움 → 그 결손도 E_eff 에 흘러듦 / 값은 LIGGGHTS hooke/hysteresis 규약값 (코드 의존) | §10.3 (L818–841) | 원문 인용 (Ng & Asce · Coetzee [62] · Santos [170]) + 우리 쪽 판정 | —
- [j] giannis2021_stress_based_multicontact_dem | 저자 명시 한계: β 는 재료마다 보정 · 고응력 탄소성은 outlook ("the elasto-plastic behaviour at high stress levels") · 유리는 "since glass beads are brittle, the elastic part is the only focus here" · MC-strain 은 빠른 압축 · 큰 변형에서 불안정 (반복 필요) · MC-stress 의 안정성은 "expected" (증명 아님) | §10 (L517–523) | 원문 인용 | —
- [j] giannis2021_stress_based_multicontact_dem | 카드가 단 한계: 논문 최대 응력 = 유리 45 MPa (300 MPa 의 1/6.7) · porosity · 상대밀도 · 배위수 보고 0 · 적용 상대밀도 한계 없음 ("ρ > 0.7 에서만 유효" 는 Varkey 2026 의 서술) · 독립 (blind) 검증은 Fig 14 이봉 하이드로겔 1 건 (450 Pa) · 고무 28 % 는 실험 없음 · 앙상블 없음 | §3.3 (L94) · §10 (L526–539) | 카드 판정 · 값 = digitized | —
- [j] giannis2021_stress_based_multicontact_dem | 우리 침대에 넣으면 (카드 유도): 필요 연화가 줄지 않고 늘어남 — 18× → 20–55× (순수 SE) · 18–24× (복합) · ΔF/F = +11 … +205 % (순수 SE · δ/d 0.11) · +2 … +33 % (복합 · δ/d 0.0175) | §7-4 표 · 판정 (L393–407) | "우리 유도 — 논문 수치 아님" | β_LPSCl 미측정 (논문의 하이드로겔–유리 범위 1.65–5.17 을 그대로 씀) · ν 0.37 · C ≈ 6.5 가정
- [j] giannis2021_stress_based_multicontact_dem | 이력 접촉 법칙 위에 얹을 때의 가드 넷: ① 제하 가지 충돌 ② 점착 가지에서 인장 증폭 ③ k₂(δ_max) 와 강화 이중 계상 ④ 역학용 탄성 면적 A_ij 와 수송용 소성 면적을 섞지 말 것 | §7-2 (L349–358) | 카드 판정 (시험 전) | —
- [j] electromechanical_contact_model_particulate_systems | 저자: 탄소성 변형 = future work · 오염막 → 금속 접촉 경로 모델 + 표면 거칠기 (실접촉 < 공칭) = future work · 저힘에서 DEM 이 저항을 실측보다 작게 예측 (산화막 미모델 · > 100 N 에서 일치 · Fig 9) | §4 (L72–73) · "핵심 물리" (L161–164) · Fig 9 행 (L117) | stated ("명시") · 그림 = digitized 추세 | 금속 · 전기 저항
- [j] dmt1975_adhesion_contact_deformation | 탄성 가정 — 소성 · 압밀 자료 없음 · 깊이 압밀된 SE–SE 의 소성 pull-off 증가는 다루지 않음 (Thornton–Ning 소관) · F₀ ∝ 1/ε² 라 절대값이 ε (3–4 Å) 선택에 좌우 | §9 (L140–148) | 카드 판정 | —
- [j] deng2021_mechanical_surface_energy_tester_bond_number | 가압 · 탈압과 닿는 한계 없음 (점착 측정의 한정어만: Bo < 1 은 원리상 못 잼 · 점착력은 계산값 · RH 40–60 %) | §4-1 (L196) · §0 한정어 (L36) | [인쇄 p.47] · 카드 한정어 | —


### [batch_05] j. 카드가 스스로 "아직 못 한다 · 한계" 라고 적은 것 가운데 가압 · 탈압 계산과 닿는 것

- [j] gonzalez2012_nonlocal_contact_confined_granular | 탄성 전용 — "For definiteness, we restrict attention to elastic spheres in the absence of gravitational forces, adhesion or friction." (초록 · §1 · §5); 미래 과제 (원문 순서): 비선형 재료 모델 (neo-Hookean · 탄소성) · 유한변형 · bonding 으로의 확장 / 더 나은 근사 경계값문제 / 동적 문제 / 원자계 EAM 유사성 분석; "despite the good agreement at large effective deformations, the extension of the nonlocal contact formulation to nonlinear material models and to finite deformations remains a topic of interest."; 정적 해석만 ("application to dynamic problems is straightforward, we have only focused on static analyses") | §10.3 (L623–643) · §5.3 (L338–339) | stated (원문 인용) | —
- [j] he2026_dem_calendering_inhomogeneity_areal_density | 카드가 적은 것 (저자 진술 아님): 제하 단계 없음 · 나노압입 제하 가지 불일치 · 파괴가 압밀 곡선에 되먹임하지 않음 · 측면 경계조건 미기재 · 시드 0 · 응력 텐서 정의 미기재. 저자 문장으로 카드에 있는 것은 도메인 크기에 대한 "boundary effects will introduce non-negligible errors" 뿐 | §4.5 (L296–297) · §10 L1 · L3 · L6 · L7 (L459–501) · §4.4 (L282) | 카드 비판 (derived(ours) · digitized 섞임) | 저자가 스스로 적은 한계는 카드에 기록 없음
- [j] heck2026_densification_sulfide_se_binder_scalable | 저자: 회복은 수직 방향만 측정 · 측방은 "minor recovery is expected" · 시간 분해 없음 · 다음 연구로 in situ SEM · µCT 권고 · 1.5 GPa 에서 최대 밀도 미도달 · 입자 파쇄는 소결된 입계와 구분 불가 ("입자 파쇄 추정"). 카드 "안 한 것": 같은 시료의 in-die ↔ out-of-die 대조 · 감압 곡선의 탄성 몫 분리 · 진밀도 초과 논의 | §3-8 (L154) · §3-7 (L140) · §3-10 (L164) · §6 (L221) | [인쇄] p.13 · p.15 · "안 한 것" 은 카드 정리 | β-LPS · 바인더 시트
- [j] jacksongreen2005_fem_elastoplastic_hemispherical_contact | 무마찰 · 미끄럼 없음 — 저자 결론: 앞으로 strain hardening · tangential loading 필요; 무경화 (탄성-완전소성); 식 17 적합 범위 a/R ≤ 0.412; 면적을 접촉 요소 개수로 세어 이산 오차 | §10 (L246–249) · §6 (L96 · L99) | stated (카드 옮김 · 원문 따옴표 없음) | 제하 · 잔류 변형은 카드에 없음
- [j] johnson1971_jkr_surface_energy_contact_elastic_solids | 탄성 · 매끈한 구 · 준정적 · 점성 없음; 분리 조건은 하중 제어 (변위 제어는 논문에 없음); 단단한 고체 (금속 · 유리) 는 거칠기가 지배 — "this approach … if one of the bodies is highly deformable"; 접촉원 끝의 무한대 인장은 실제로는 "the surfaces will separate slightly near the edge" | §4-1 (L152–153) · §0 표 (L35) · §3-1 (L99) · p.307 · p.312–313 | [인쇄] | 소성 없음
- [j] hamasaki2022_single_parallel_contact_mwcnt_conductivity | 접합 = 외력 없는 반데르발스 접촉 — 접촉력 · 변형 · 압력 변수 없음; 압밀 (수백 MPa) 하 접합과 다름 (카드) | §4-3 (L134) · §11-7 (L225) | stated (조건) · 비교는 카드 서술 | 가압 계산과 닿는 것은 "압력 의존 자료 없음" 뿐
- [j] jarray2019_cohesion_driven_mixing_segregation_drum | 가압 · 탈압과 닿는 한계 없음 (드럼 혼합 실험).


### [batch_06] j. 카드가 스스로 "아직 못 한다 · 한계" 라고 적은 것 (가압 · 탈압 계산과 닿는 것)

- [j] luding2008_cohesive_frictional_contact_models | 논문 명시: 큰 변형 영역에서 모델이 제한된다 ("model is limited … in the regime of large deformations" · §1.2) · k₁/k 와 kₜ/k 비율의 상세 영향은 미연구 · 실제 자료에 대한 정량 튜닝은 향후 과제 (§4) · 비구형은 다루지 않음 (§1.1) | L24 · L108–110 · L130 · L141–142 | stated (일부 원문 따옴표) | —
- [j] martinbouvard2003_dem_composite_cold_compaction | 논문 명시 (카드의 옮김): 소성 흐름으로 운반된 물질 무시 → 절단된 구 · 인접 접촉 비간섭 → "기하 · 역학 제약상 0.85–0.90 이전만 엄밀 유효" · 회전 무시 = 재배열 상한 추정 | §4 (L49–53) · §10 (L106–108) | stated (원문 따옴표 없음) | 제하 서술 없음
- [j] mesarovicfleck2000_dissimilar_elastoplastic_indentation | 논문 명시 (카드의 옮김): E* 결합 모듈러스는 Hertz 극한에서만 엄밀 · 유한변형 영역의 일반 천이 기준 없음 · 접촉 독립은 D < 0.82 | L52 · L116–117 · L129 · §10 (L231) | stated | 제하 없음
- [j] kogutetsion2002_ep_sphere_rigid_flat | 카드 한계 절: 소변형 FEM (매우 큰 변형에서 절대 정확도 제한) · 탄성-완전소성 · 완전소성 뒤 면적은 기하 절단 (부피 보존 무시 · 110 에서 7 % 과대 — 본문도 인정) · 무마찰 | §10 (L188–191) | 카드 판단 + stated (7 %) | 제하 없음
- [j] kissel2026_mechanofusion_derived_cathode_composite_microstructures_scalable | 논문 명시: DEM 은 "does not retain information on the original coating progression" (p.6) · 거친 입자는 로터–벽 틈 때문에 응력이 조금 과대일 수 있어 SI_CG 로 표기 (SI Note 3). 카드: 시간 간격 · 입자 수 · 감쇠 · yield ratio 정의 [미확인] | L134 · L171 · L279 | [인쇄 p.6 · SI p.9–10] · [미확인] | 압축 계산 아님
- [j] molerus1975_theory_of_yield_cohesive_powders | 논문 명시: 등방 법선력 분포는 가정 ("at least seems plausible" · p.272) · 소성 면적식은 "For the resulting small deformations simple considerations yield" · Jenike 셀의 "well-known shortcomings". 카드: 고밀도 압밀 · 형상 소성 · 파괴 · 다분산 · 재배열은 범위 밖 | L153 · L167 · L344 · L392 | stated (원문 따옴표) + 카드 판단 | kPa 영역
- [j] oh2026_bimodal_composite_cathode | 카드 한계 절: He 기공 (370 MPa) · 셀 (300 MPa) · σ 측정 (100 MPa) 이 서로 다른 압력 · 시뮬은 입자 형상 고정 (구 / 다면체) + 탄성 변형만 | §10 (L630–643) | 카드 판단 | 논문 자신의 말이 아님
- [j] kim2023_mechanofusion_ncm811_lpscl_core_shell_intimate_contact | 카드 한계 절: 기공 36.6–42.4 % 의 V_meas 측정법 [미확인] · 식 (3) 설명이 V_meas 와 V_theo 이름을 바꿔 적음 | §10 (L263–264) | [미확인] | 가압 계산 없음
- [j] liao2025_interfacial_adhesion_li_plating_carbon_interlayer | 카드 한계 절: 형상 소성 · 접촉 면적을 재지 않는다 — "lamination 압이 높을수록 소성이 커져 계면이 conformal" 은 단면 사진 2 장의 정성 서술 | §4.1 (L119) · §10 (L263) | 카드 판단 | —
- [j] mcgeary1961_bimodal_sphere_packing | 논문 정의: 패킹에서 "no plastic deformation of particles occurs" (§I · §X) — 하중 1–16 lb/in² · 진공은 최종 밀도에 영향 없음 | L36 · L52–59 | stated | 가압 변형은 범위 밖


### [batch_07] j. 카드가 스스로 "아직 못 한다 · 한계" 라고 적은 것 가운데 가압 · 탈압 계산과 닿는 것

- [j] so2022_dem_contact_model_assb_compaction_sintering | 저자 명시: 고변형에서 구 겹침 근사가 깨진다 (접촉 면적 · 2 차 접촉 · 힘 모두 과소) — 인자로 메웠을 뿐 형상 변화는 못 준다 | §4.8 (L180) · §10 (L266) · 논문 p9 | stated (카드의 우리말 옮김) | —
- [j] so2022_dem_contact_model_assb_compaction_sintering | 저자 명시: ~150 MPa 이하 저압에서 모델이 Sakuda 실험보다 치밀 — 응집체 (aggregate) 를 모델하지 않은 탓 | §3 (L44) · Fig 8 행 (L198) · §10 (L269) | stated | 방향이 우리 쪽 (강체 구가 기공 과다) 과 반대 (카드)
- [j] so2022_dem_contact_model_assb_compaction_sintering | c_area · c_spring · h_ov^max 는 실험에 맞춘 조정값 · seed 다중 실현 명시 없음 · 이 MethodsX 는 방법 부록이라 결과 · 검증은 동반 논문에 흩어져 있음 | §10 (L268 · L271–272) | 표지 없음 (카드 판단) | —
- [j] paulick2015_elastic_particle_properties_dem_review | 리뷰가 스스로 지목한 미해결: "only little research on the influence of contact stiffness on bulk behaviour of powders has been conducted. Due to high computational efforts in case of numerically describing fine powders, also the influence of contact stiffness during particle upscaling should be investigated." | §3 (L76–80) · 논문 §4 p.75 | 원문 인용 | —
- [j] paulick2015_elastic_particle_properties_dem_review | 다루지 않는 것: 고압 압밀 (최고 ≈ 96 kPa) · 소성 접촉 법칙 ([32] 한 편) · 밀도 문턱 수치 (n/a) · 벌크 곡선에 맞추려 E 를 낮춘 사례 0 편 | §3 범위 상자 (L66–74) · §5-Q3 (L261–263) · §5-Q1 (L152–155) | 카드 판독 (stated) | —
- [j] pasha2014_linear_elastoplastic_adhesive_contact | 논문 저자의 지적: Luding 형 법칙은 접촉이 겹침 0 에서 끊어져 소성 변형을 무시 (탈압 때 분리 위치) | §4.1 (L111–113) · Fig 1 행 (L215) | 카드의 우리말 옮김 | —
- [j] pasha2014_linear_elastoplastic_adhesive_contact | 카드가 적은 한계: 항복압 캡 없음 → 실제 E 로는 300 MPa 에서 덜 변형 (연화 문제 그대로) · 검증이 단일 입자 충돌이라 다입자 준정적 압밀에 자동 성립 아님 · 강체 구의 접촉 소성만 · 점착 → 고체 분율 ↓ 는 저응력 충전 현상 | §7.3 (L322–324) · §10 (L419–438) | 표지 없음 (카드 판단) | 논문 저자의 문장 아님
- [j] schreiner2020_dem_calendering_lib | 저자 서술: 보정 파라미터 (compaction resistance · initial cohesion · elastic spring-back) 는 "독립적이지도 물리적으로 측정가능하지도 않은, 순수 수학모델의 조절 파라미터" · roll 전체 (~400 mm) 는 입자 (~10 µm) 와의 차수 차로 계산 불가 → roll section · 온도 의존 · 관성 스케일링은 향후 과제 · spring-back 정량값 없음 | §4.0 (L54) · §4.4 (L81–83) · §4.7 (L99) | 표지 없음 (카드의 우리말 옮김) | LIB
- [j] roessler2019_dem_cohesive_aor_cylinder_lift_calibration | 저자: 단순 JKR 은 강한 다짐 · 응력 이력을 표현 못 함 → 다짐에는 Luding · EEPA 권장 · "더 높은 G 로 옮기면 접촉 매개변수를 다시 보정해야" · 다른 수분 · 재료로 판별력 검증 필요 | §3-1 (L61) · §0 표 ⑥ (L32) · §10 (L221 · L223) | [인쇄] p.2 · p.8 | 젖은 모래
- [j] sharma2023_nmc_single_crystal_anisotropic_nanoindentation | 저자: 경도 추세 해석은 전위 · 슬립계 정보 부족으로 어렵다 · cube-corner 로 이상적 방사형 균열을 만들기 어렵고 전단띠가 생긴다 | §10-1 (L450–451) · 논문 p.6 · SI Fig S3 | stated | 가압 계산과는 AM 입력 (파괴 · 접촉압) 으로만 닿음


### [batch_08] j. 카드가 스스로 "아직 못 한다 · 한계" 라고 적은 것 가운데 가압 · 탈압 계산과 닿는 것

- [j] thompson2026_high_pressure_densification_lps_lpscl_xrd_tomography | 감압을 ≈1150 MPa 아래로 못 감 — "We did not perform the absorption density measurement below this pressure, as we could not guarantee that the sample would still be airtight." · 논문이 안 한 것: 공극 % 수치 · Heckel · 두께 회복 · 무하중 감압 · 반복 통계 · 흡수 ↔ 결정 밀도 일관성 점검 | §3-1 (L56) · §6 (L162) | 인용 = [인쇄] p.3 · 목록 = 카드 정리 | —
- [j] wang2024_hot_pressed_lpscl_pressure_invariant_conductivity | 장치 한계: "only able to press at pressures up to 450 MPa due to the limitations of our experimental apparatus" · 200 °C = "the temperature limit of our experimental apparatus" · 유지 시간 · 승온 이력 · 시료 수 · 오차 정의 없음 | §3-1 (L74 · L76–77) · §10-5 (L251) | [인쇄] p.3–4 · p.10 · 없음 목록 = [미확인] | —
- [j] varkey2026_multicontact_elastoplastic_dem | 저자 명시 (카드 옮김): 구 = 타협 · 현실 형상 = 향후 과제 (p.12) · 20 % 아래 기공은 "추구 안 함 (비용)" · 다접촉 항은 ρ > 0.7 에서만 | §4 (L34 · L39) · §7 표 (L67) | 표지 없음 (카드 옮김) | 원문 영어 문장은 카드에 없음
- [j] vanlew2015_modifying_youngs_modulus_distribution | 저자: "A pebble bed geometry more directly comparable to oedometric compression experiments should be used to allow direct comparison and validation of the numerical models." — 침대 규모 실험 검증 0 | §6.4 (L358–364) | 원문 인용 | —
- [j] tovar2026_cold_spray_cathode_composite_dem_plastic_elastic_bond | 저자: DEM 에 PVDF 퍼짐 · 부착 · 산화막 · 온도 연화 · 다입자 효과 없음 · 단일 크기 응집체 → "정량 예측은 기대하지 않는다" (카드 옮김) · 거칠기 결론은 크레이터 기하에만 · 향후 = 여러 구 크기 · 표면화학 부착 · 다입자 충돌 | §4b 3.5 (L203) · §4b 4 (L213–214) | stated (카드 옮김) | —
- [j] thorntonning1998_adhesive_elastoplastic_contact | 카드가 적은 한계: 탄성-완전소성 (경화 없음) · 점착 + 소성은 가산 소산 근사 · 목적이 충돌 반발계수 · 이 법칙만으로 무르게 맞춘 영률을 없앨 수 있는지는 "LPSCl @300 MPa 재현으로 미검증" | §10 (L353–367) | 카드 서술 | —
- [j] thakur2014_eepa_adhesive_elastoplastic_dem | n = 1 선형만 분석 (비선형은 별도 논문) · δ_min 아래 이력 미모델 · 16–96 kPa (분말 취급 규모) · k_adh (N/m) 와 f₀ (N) 는 직접 비교 어렵다 (저자 명시) | §4 (L118) · §10 (L368–383) | 카드 서술 | —
- [j] storakers1997_similarity_inelastic_contact | 단접촉 · 무마찰 · 독립 접촉 전제 · LPSCl 의 경화 지수가 미측정이라 c² 는 "이상소성 한계 ~1.4 의 추정" | §11 (L264–275) | 카드 서술 | —
- [j] stallard2022_cathode_mechanical_properties_review | 리뷰 저자: 기계 연구가 상한 전압을 과장하는 경향 (NMC811 4.8 V ↔ 실사용 4.2–4.3 V) · 다결정 층상 결과를 모든 재료 · 구조로 외삽 금지 · 카드 추가: NMC811 · 단결정 NMC 역학값 없음 · SI · 자료 공개 없음 | §10-1 – 10-2 (L469–479) | stated (저자 한계) + 카드 추가 | 가압 계산에 닿는 점 = AM 입력값의 근거가 NMC333 / 532 뿐이라는 것


### [batch_09] j. 카드가 스스로 "아직 못 한다 · 한계" 라고 적은 것 가운데 가압 · 탈압 계산과 닿는 것

- [j] zunker2025_dem_large_deformation_compaction | 서로 다른 재료 미지원 ("varying material properties as future work") → AM + SE 복합 불가 · 순수 SE (단일 재료) 만 가능 | L12–16 · §15 (L531–532) | 원문 인용 · 카드 판정 | —
- [j] zunker2025_dem_large_deformation_compaction | 기공 · 상대밀도 보고 0 · 압력 스윕 없음 (프로토콜 하나 0 → 0.4 → 0) · 20,000 입자 계산 시간 미보고 ("1 초" 는 14 입자 대조의 값) · 반경비 검증 0.25 까지 · 가짜 접촉 페널티는 강한 다분산에서 미검증 · 파쇄 · 온도 · 소결 · 사이클 없음 | §15 (L538–550) | 표지 없음 (카드 한계 목록) | —
- [j] zunker2025_dem_large_deformation_compaction | 응력 정의가 절마다 다름 — MPFEM 대조는 벽 반력 / 면적 · 정제 계산의 반경응력은 입자 응력 텐서 평균 × 부피분율 (실험의 벽 센서와 같은 양 아님) | §8 (L279–284) · §15 (L542–543) | 표지 없음 (카드 지적) | —
- [j] zunker2025_dem_large_deformation_compaction | 페널티 세기 t_p = 50: "a fitted penalty transition intensity" · "no unique value of t_p exists" | §5-2 (L182–183) | 원문 인용 | —
- [j] zunker2024_mdr_contact_model_partI | 저자가 미해결 · 미포함으로 적은 것: 반경 차 ("subject of active research" · §1 item 9) · 가공 경화 (item 10) · 접촉 가장자리 환형의 압력 불균일 (힘에는 작지만 점착 예측에는 큼 · 향후 과제) · 하중 뺀 프로파일이 오목–볼록인데 모델은 볼록만 (§8.3.2) · 점착 유효 조건 (eq 49) 은 사전 판정이 어려움 · E/Y ≲ 10 사용 불가 · 일치도 "semi-quantitative" | §10 (L374–386) · §4-4 (L175–182) | stated (카드가 "저자 명시 · 인정" 이라 적음) | —
- [j] zunker2024_mdr_contact_model_partI | 고구속에서 구관들이 심하게 교차하면 반경 성장 식 (eq 37) 이 음수 / 비정상 ΔR (App C 말미) → Part II 가 R 성장을 정지 | §4-4 (L182) · §4-5 (L218–220) | stated | —
- [j] zunker2024_bulk_elastic_partII | ψ_b 값 없음 · 원거리 응력 결합 미고려 (Fig 5c 불일치의 원인으로 저자 명시 · 향후 과제) · 제하 때 면적 급락 = 모델 인공물 (저자 인정) · 벌크 전단 응답 (μ 기반) 은 향후 과제 · 다체 계산 0 건 · E/Y 20 · ν 0.3 한 조합 | §10 (L261–273) | 표지 없음 (카드 한계 목록 · "저자 인정" 표기) | —
- [j] xu2017_nmc532_nanoindentation_modulus_hardness_toughness | 가압과 닿는 것: 측정은 sub-µm 국소값이라 이차입자 전체의 압축 응답은 "이 논문 밖" · 단결정 값 없음 · 전극의 압연 이력 정보 없음 | §4-6 (L241–244) · §10-2 (L446–450) | 표지 없음 (카드가 추가한 한계) | 저자가 밝힌 한계 (§10-1) 는 입계 나노기공 · 결정립 크기 의존 등


### [batch_10] j. 카드가 스스로 "아직 못 한다 · 한계" 라고 적은 것 가운데 가압 · 탈압 계산과 닿는 것

- [j] bazzoun2025_dem_parameter_sensitivity_assb_cathode | 저자 명시 한계 (카드의 한국어 옮김): 이상화 spring-dashpot · 소성변형 · 점착 미고려 → 접촉면적 과소 · 연결성 과대 가능 (§3.7) · 구로 한정 (§3.1) · f_CAM 80–85 wt% 에서 기공 과소 + 민감도 급증 (§4.5 / 5.3) · 원인 = 입자 형상 · 소성변형 · 혼합 거동 미반영 (§5.5 future work) · 첨가제는 질량 보정만 (θ 과대평가 가능) | §4 (L62 · L70–71) · §8 ③ (L138) · §10 (L149–155) | "저자 명시" (카드) | 원문 영어 문장은 카드에 없음
- [j] faka2026_particle_size_consolidation_strain_lpscl | in-die 만 측정 (뺀 뒤 밀도 · 감압 두께 없음) · 장치 순응도 · 고체 압축 보정 서술 없음 · DEM 은 격자 · 물성 변화 미반영이고 미세구조 열화 영역이 *"absent in DEM due to its limited spatial resolution"* · DEM 밀도 · 언로딩 미보고 | §6 (L176) · §10 (L234–239) · §3-6 (L117–118) | [인쇄] · [미확인] | —
- [j] lee2025_heckel_argyrodite_powder_densification_nanoindentation | 고체 탄성 압축 미보정 · 뺀 뒤 밀도 · 다른 하중 속도 · 반복 통계 없음 · 회복은 한 점 · 이론밀도 기준 불명 · 펠릿 기하 (높이 5 mm / ⌀8 mm) 의 벽 마찰 → 밀도 구배 [미확인 정량] | §4-1 (L127) · §10 (L223–231) | 카드 정리 | —
- [j] minnmann2021_jes_charge_transport_bottlenecks | 기공 오차 *"as high as 10 %"* (두께 측정) · 순수 재료 τ² := 1 가정 · 순수 시료 기공 · 압밀압 미보고 · Eq 4 는 협착 · CEI · 계면분극 · 공간전하를 따로 다루지 않음 · 평균 기공 14 % 하나를 전 조성에 적용 | §3 (L179–181) · §15 (L712–723) | 저자 명시 (인용) · [미확인] | —
- [j] minnmann2024_microstructure_porosity_visualization | 단일 제조압 (압력 스윕 없음) · 50 nm 아래 공극 미해상 → 분할 기공 과소 · 토모는 펠릿 3 개 (입경마다 1 개) | §4 (L90–91) · §10 (L188–189) | stated | —
- [j] lin2025_submicron_lpscl_cathode_li_kinetics · kim2024_optimal_cathode_composite_mechanical_mixing_se_coverage · frankenberg2025_milling_dry_processed_sulfide_cathode_microstructure | 압력 곡선 · 언로딩 전 상태 · 두께 분해능을 주지 못함 (lin2025 L246) / DEM 기공 · 코드 · 준정적 확인 없음 · FEA 는 SE 탄성 (kim2024 L192 · L259–261) / DEM 은 볼 운동뿐이고 미세구조를 푸는 모델 없음 (frankenberg L36 · L303) | 왼쪽 괄호 | 카드 정리 | —
- [j] bazzoun2026_dem_fem_rnm_ionic · lei2026_se_particle_size_effects_review | 구만 (형상 변화 없음) · RNM 은 협착 저항만 (bazzoun2026 L93–94) / 문헌 모사 대부분이 정해 둔 입도 하나만 쓰고 실제 넓은 입도 · 적층 형태를 무시 (lei2026 L144) | 왼쪽 괄호 | 카드 정리 / [리뷰 p.21] | —


### [batch_11] j. 카드가 스스로 "아직 못 한다 · 한계" 라고 적은 것 (가압 · 탈압 계산과 닿는 것)

- [j] shi2019_high_am_loading_particle_size_assb | 저자: *"An accurate description of the contact area between particles requires modeling of the plastic deformation of LPS particles, which has been observed experimentally.[29] The degree of the deformation will largely determine the contact area between particles and therefore the resistance at particle boundaries."* | §4 (L194–198) · 논문 §4 p.7 | stated (원문 인용) | [29] Choi 2018 의 내용은 [미확인] · 탄소 (나노 입자) 를 입자로 넣는 것은 입자 수 10¹⁰ 초과로 계산 불가 (카드의 한국어 옮김 · L292)
- [j] schneider2023_particle_size_pressure_transport | 저자: 완전 구 DEM ↔ 비구형 분말의 차이가 저압 regime I 과대의 원인 · 입계 저항은 유한체적 계산에 미포함 · 마찰 · 접촉저항이 DEM 에 완전히 반영되지 않음 | §4 (L88–90) · §10 (L263–265) | 첫 항목은 원문 인용 · 뒤 둘은 카드의 한국어 옮김 | 탈압 계산을 했는지는 카드에 없음 (실험 감압만)
- [j] otani2025_dem_se_dispersion_aggregation_compression | 저자: 단분산을 모사했지만 실제는 다분산 · 응집체 결합 파라미터는 실험 · 문헌에서 얻기 어렵다. 카드 판정: 접촉 소성 · 제하 없음 · 100× 조대화의 검증은 주장뿐 (자료 없음) · 결론이 기대는 충전 단계가 조대화에 가장 취약 | §4.4 (L243–244 · L252–254) · §3.4-① (L159) · §10-③ (L495–505) | 카드의 한국어 옮김 (저자) · 카드 판정 | —
- [j] tailored_cathode_microstructure_low_pressure_assb | 저자: 실험 coarse 용량이 fine 의 ~85 % 로 utilization 예측 (83 %) 과 조금 달라 "특정 C-rate 에 맞춘 overlap 추가 보정 필요". 카드: DEM 재료 값 · 제조압 미공개 · 소성 형상 없음 | §5.3 (L101) · §5.6 (L113) · §10 (L285–286) | 카드의 한국어 옮김 | —
- [j] schlautmann2023_se_particle_size_composite_transport | 저자: 계산 σ_el 추세가 왜 실험에 안 보이는지 *"It is unclear why this effect is not evident in the experiment. At this stage, we assume this to stem from surface effects on the NCM leading to different resistances between NCM particles …"*. 카드: 모델에 압밀 역학이 없고 공극은 실측을 입력으로 받음 (예측 아님) | §5.6 (L247) · §4g (L194) | stated (원문 인용) · 카드 서술 | 가압 계산 자체가 없음
- [j] stavola2023_thick_nmc111_lpscl_lithiation_gradient_tortuosity | 저자: tortuosity factor 는 첫 충전 중 변한다 — NMC 수축에 따른 접촉 재배열은 *"rearrangement of particle contacts is expected"* (가설 · 미측정) → 눌러 만든 구조가 운전 중 그대로라는 보장이 없음 | §4-3 (L161) · §5.4 (L192) · §5.6 (L203) | [인쇄 p.1277] | 50 MPa 운전 중의 변화 · 가압 계산 아님
- [j] park2020_dimension_controlled_se_percolation_contact_area | 저자: 퍼콜레이션은 *"should be ideally analyzed with statistical methods to find its threshold"* (최단 경로 하나로 대신함) · 강체 판은 전극을 못 채움 → 해법으로 *"a mechanically deformable 2D sulfide solid electrolyte"* 를 듦 | §4.2 (L243) · §8 (L456) · 논문 p.3 · p.5 | stated (원문 인용) | 산화물 · 역학 없음


### [batch_12] j. 카드가 스스로 "아직 못 한다 · 한계" 라고 적은 것 가운데 가압 · 탈압 계산과 닿는 것

- [j] yano2026_se_psd_width_ionic_tortuosity_dem | DEM 은 정량 재현이 목적이 아님: *"…the results are intended to provide qualitative insights into mechanical behavior rather than to quantitatively reproduce experimental deformation."* (p.4) · 밀도 변화가 실험의 약 1/10 인 이유 *"attributed to ignoring particle shapes and the relatively strong agglomeration of fine LPSCl particles. That is, a better mixing quality was achieved in the simulation than in the experiments."* (p.6) · *"agglomeration structures observed in the experiments were not explicitly reproduced"* (p.7) | §4d (L195) · §5.5 (L240) · §4e (L205) | [인쇄] | 탈압 · 판독 시점은 아예 미기재 (L198)
- [j] so2021_dem_mold_pressure_assb_coldpress | "AM을 구로 모델 → 비구형/intraparticle cracking은 future work" (논문 §4.3) | §4 (L63) · §10 (L113) | 카드의 한국어 옮김 (원문 문장 없음) | —
- [j] benhadjali2026_wip_vs_cup_pressing_assb_cathode_dem | (1) WIP 모델은 등방 하중을 풀지 않음: *"reproduced the experimentally observed through-thickness densification together with the prescribed thermal and loading history … rather than explicitly resolving the macroscopic hydrostatic stress field acting on the complete electrode disk"* (p.14) (2) *"No external pressure was prescribed"* — 변위 제어 (p.18–19) (3) 온도 의존 탄성 상수 · 접촉 강성 · 상호작용 · 감쇠 변경 없음 (p.19) (4) 접촉력 분포 · 힘 사슬은 출력에서 제외 (p.19) (5) FEM 에 제조 잔류 응력을 안 넘김 (p.21) (6) C/2 비교는 *"not intended as a quantitative model validation but rather as a qualitative assessment"* (p.39) (7) 다음 일 = 비가역 접촉 변화 · 계면 열화 · 손상을 넣은 반복 사이클 (p.42–43) | §4-2 (L225–226) · §3-8 (L162 · L165) · §3-10 (L206 · L211) · §4-3 (L246) | [인쇄] | 프리프린트
- [j] demirtas2021_mpfem_hollow_sphere_die_compaction | (1) *"the computational cost is the main limitation for this method, limiting the number of particles used in a model."* · *"the number of particles was kept under 2000 to maintain the wall clock time to <60 h"* (2) *"a quantified extent of buckling … is beyond the scope of this study"* (3) *"due to the lack of cohesive elements"* 로 압축 + 제하까지만 (배출 · 인장강도는 *"This is a topic of future work"*) (4) 실험 입경 · 벽두께 측정은 *"by no means does this represent a statistical analysis"* (5) 재료값 선택이 수치 사정과 얽힘: *"Since material property selection directly influences the stable time increment, i.e., the total run time of the simulation and the accuracy of the results, an optimized selection must be made on material properties."* | §7-A-2 (L565–566) · §7-B-2 (L627–628) · §3-6 (L232–236) · §10-B (L864 · L874–875) · §4-4 (L319–321) | stated | 고분자 중공 입자
- [j] sangros2019_dem_calendering_lib_electrode | 고압 (C4) 에서는 균열 · 입자 파쇄 (· PVDF reform) 를 고려해야 정확하다고 한계로만 언급 — 입자 파쇄 미모델 (bond 파단만) · 비리얼 응력의 bond 항은 Fig 12 의 이방성을 완전히 반영하지 못함 (저자 인정) | §4.4 (L91) · §9-(3) (L211) · §7 (L185) · §11 (L246 · L251) | 카드의 한국어 옮김 (원문 문장 없음) | C4 모의 0.247 ↔ 실측 0.217
- [j] sangros2020_lib_electrode_dem_mech_elec_ionic | 전자 전도 균질화식이 기공 < ~30 % (C4) 에서 실측보다 큼 (1.55 ↔ ~1.2 S/m) — 본문이 "고calendering이 전도망에 contact loss를 유발해 저항을 높일 수 있다(바인더 전도도 미반영)" 고 인정 | §3 (L32) · §10 (L149) | 값 = digitized · 인정 = 카드의 한국어 옮김 | 수송 쪽 한계 (가압 계산 자체는 아님)
- [j] diener2022_roll_gap_springback_calendering | 롤 평탄화는 정량 못 함 (계산 불가 · FEM 필요) — *"A roll flattening below 5 μm seemed to be a realistic value"* · *"the springback value directly determined from the gap measurements was slightly overestimated, but the deviations were all most likely a linear function of the line load"* · 바인더 4 wt% 의 급증은 *"further experiments are necessary"* | §3-3 (L69) · §3-5 (L97) | [인쇄] | 카드 산술은 과대 폭이 "약간" 보다 크다고 봄 (§3-7)
- [j] larson2025_hot_pressing_argyrodite_low_stack_pressure_conductivity | 저자 결론이 남긴 것: *"fabrication at 150 °C results in grain−grain fusion and motivate[s] further study of the fabrication parameter space (e.g., pressure, temperature, time, and contacts) to find routes to <1 MPa operation"* — 성형압은 300 MPa 한 점 · 두께는 시험 뒤 한 번 · 다이 안 두께 없음 | §1 (L38) · §7-2 (L236) · §7-5 (L260) | 인용문 = [인쇄] · 나머지는 카드 정리 | 카드 (우리 쪽 기록): 우리 MPM · DEM 둘 다 온도 · 시간 의존 소성 (확산 접합 · 크리프) 이 없어 열간 가압의 "융합" 은 표현 범위 밖 (L260)
- [j] yadav2021_lpscl_sieved_psd_impedance_tortuosity | 압력 계열 측정 없음 — "포화 압력" 은 3 t 한 점에서의 추론 · compacity 측정법 미기재 | §6 Q1 (L205) · §10-1 (L278) · L82 | [인쇄] · [미확인] | 저자가 한계로 적은 것이 아니라 카드의 비판


### [batch_13] j. 카드가 스스로 "아직 못 한다 · 한계" 라고 적은 것 (가압 · 탈압 계산과 닿는 것)

논문이 스스로 적은 한계와 카드가 판독한 빈칸을 구분해 적었다 ("카드 서술" · "카드의 판독" 표기).

- [j] miss2026_insitu_conductivity_porosity_pressure_compaction | 저자가 스스로 적은 것: 복합 양극은 다음 일 (*"…will be the subject of future work."* p.32835) · 불확도는 *"of the order of the symbol size or lower"* 한 문장 · 다이 밖 두께로 계산한 σ 는 압력 의존을 오도함. 카드가 적은 빈칸: 반복 시료 · 오차 막대 없음 (n = 1 로 읽힘) · 단계 하중과 단조 가압의 차이를 가르는 실험 없음 · 놓은 뒤 σ 자료 미공개 · 측정 온도 · 유지 시간 · 입경 · 피스톤 교정값 [미확인] · 하우징 반경 순응 · 벽 마찰 미논의 | §0 (L24) · §3-2 (L114) · §6 (L255) · §10 (L332–345) | [인쇄] · [미확인] · 카드 서술 | —
- [j] zhang2026_xct_dem_cathode_calendering_peel_calibration | 저자가 스스로 적은 것 (카드의 한국어 옮김): ① 60 · 200 MPa 에서 DEM 이 실험보다 약간 성긴 것 (+0.009–0.011) 은 "구 근사가 부피 손실 오차를 들여온다" ② 200 MPa 는 "최적 공정 조건으로 권하지 않는다 — 손상 거동을 드러내기 위한 조건" (p.14) ③ 선행 Sangrós 2019 모델은 계면 점착이 없어 제하 때 코팅이 들뜰 수 있음 → 입자–Al bond 를 넣고 박리로 보정 | §2.5 (L105–107) · §3.5 (L184) | 카드의 한국어 옮김 (원문 영어 문장은 카드에 없음) | —
- [j] zhang2026_xct_dem_cathode_calendering_peel_calibration | 카드가 적은 빈칸 (가압 · 탈압 계산과 닿는 것): 목표 응력에서 유지 없음 · 롤 곡률 · 전단 없음 (평판) ; 집전체가 변형하지 않는 벽이라 "매립 깊이 0.937 µm" 는 탄성 겹침 (SEM 굴곡은 ≈ 5–7 µm 급 · 판독 거침) ; 배위수 · 자유 표면적 · 매립 · 응력이 누른 채 값인지 미기재 ; 코드 · 입자 수 · 시간 간격 · bond 강성비 · 전단 강도 · CBD 물성 · 기공 관례 · 보정 표적 미기재 ; 보정과 검증이 분리되지 않음 (박리 < 1 % 는 보정 잔차) | §4.5 (L305–307) · §4.8 (L318–320) · §10 L4 · L6 · L7 (L467–470) | 카드 서술 · [미확인] | 논문 문장이 아니라 카드의 판독
- [j] xu2023_realistic_am_shape_cgmd_calendering | 논문이 스스로 적은 한계 (원문): ① *"the kinetic calculations **do not take the shape of the particle into account**, but only the location of the center of mass of the primary particles … does not include the complex geometry of the secondary particles and the associated rotational degrees of freedom, which are typical features of DEM approaches"* ② 결론 절 *"cracking … is happening at a scale smaller than the secondary particles considered in our model"* ③ *"Due to the computational limitations of LAMMPS, we were unable to perform the viscosity simulation as in our previous works [22]"* | §4-B-2 (L427–430) · §7 (L682–683) · §3 (L94) | stated (인용) | —
- [j] xu2023_realistic_am_shape_cgmd_calendering | 후처리의 한계 (SI 원문): *"with the dilation-erosion factor of 1 voxel, there are relatively large gaps in the AM secondary particles, which come from the perfect spherical morphology of the primary particles. This would unrealistically lead to a higher tortuosity factor"* → *"Consequently, we choose to use 2 voxels … to process all the results from the simulations."* · τ 는 CBD 를 전도상에 넣느냐에 따라 1.7–3.2 배이고 *"the true tortuosity factor value of the electrode should be in between"* | §4-B-4 (L461–463) · §6-B (L587–595) · §6-A (L570–572) | stated (인용) · 1.7–3.2 배 = derived(ours) | —
- [j] xu2023_realistic_am_shape_cgmd_calendering | 카드가 적은 빈칸: 압연 압력 · 시간 간격 · 판 속도 · 시드 수 미기재 → 준정적성 검산 불가 ; 건조 두께는 예측이 아니라 입력 (실험 밀도 · 기공으로 미리 계산) ; 실험은 선하중 압연인데 모델은 평면 하강 (전단 · 이동 접촉선 없음) ; µ-XCT 검증은 96:2:2 한 조성뿐 | §4 (L348–353) · T5 (L299) · §10 (L773–786) | 카드 서술 | 논문 문장이 아니라 카드의 판독
- [j] ngandjong2021_dem_calendering_digital_twin | 결론 절이 남긴 한계 (카드의 한국어 옮김): "1차 NMC 입자와 2차 입자의 균열을 고려하도록 더 확장할 것" | §4 (L312) · §7 (L644) · §10 (L720) | 카드의 한국어 옮김 | 원문 영어 문장은 카드에 없음
- [j] ngandjong2021_dem_calendering_digital_twin | 건조 모델이 z 도 주기 경계라 압연 (z 비주기) 과 경계 조건이 안 맞음 → "z 비주기 건조모델을 개발 중" ; 모의는 전부 단일 실현 (시드 · 앙상블 0 건 · 오차 막대는 실험에만) 이라 모의 기울기의 비단조 (7.4 → 31.8 MPa 평평 → 다시 가파름) 를 잡음과 구분 못 함 | §4 특이사항 2 (L332–334) · §4 (L322) · §3-A-5 (L186–187) | 저자 인정으로 서술 · 표지 없음 | —
- [j] ngandjong2021_dem_calendering_digital_twin | 속도 사다리는 ε 를 31.5 % 로 고정한 구조의 PSD · g(r) 불변만 보였고 ε(P) 가 재하율에 불변인지는 시험하지 않음 ; 기공 계산이 겹친 부피를 이중으로 세는지 합집합인지 미기재 ; 모의 − 실험 잔차 (고압에서 +0.8 ~ +1.23 %p 덜 압밀) 를 논문은 정량화하지 않음 | §4-B-4 (L447–452) · T12 (L252) · §3-A-4 (L167–169) | 카드 판정 · derived(ours) | 카드의 읽기 (논문 문장 아님)
- [j] lyu2025_3d_dem_drying_calendering_lib | 논문이 스스로 적은 것: 두께 방향 응력이 가장 크므로 입자 파쇄 (실험 200 MPa) 를 피하려면 z 응력 관리가 필요 · 과압연은 이온 저항을 올림 [ref48] — 둘 다 경고일 뿐 모델에는 파쇄 · 이온 계산이 없음. 카드가 적은 빈칸: 판을 되올리는 단계 없음 · 압력 스윕 없음 (속도 제어) · 모세관력 · 표면장력 항 없음 · 시드 미기재 | §1 (L13) · §4 (L68 · L70 · L75–76) · §10 (L244–248) | stated (200 MPa) · 나머지는 카드 서술 | 저자가 "한계" 라고 이름 붙인 문장은 카드에 옮겨져 있지 않음
- [j] miss2026_pressure_tortuosity_composite_cathode_coating | 저자가 스스로 적은 것: ① *"Electronic and ionic tortuosities can be obtained from the values of σlf and σif, except in cases with σlf ≈ σif."* (전자 σ 가 훨씬 크면 이온 몫 미결정 · p.10) ② 저주파 반원 극대가 주파수 창 밖이면 σ_lf 를 못 정함 (Fig 6 캡션) ③ 단결정 ↔ 다결정 차이의 원인은 *"most likely related to the surface properties of the NMC particles…"* 로 TEM · XPS 후속 필요 ④ 제작 압력 제거 과정은 앞으로 볼 일 | §3-4 (L89) · §3-5 (L103) · §3-7 (L133) · §0 (L25) | [인쇄] | —
- [j] miss2026_pressure_tortuosity_composite_cathode_coating | 카드가 적은 빈칸 (가압 · 탈압 계산과 닿는 것): 기공 · 밀도 · 두께 – 압력 곡선 · Heckel · 하중 제거 · 반복 시료 통계 · 입경 분포 · 표면 에너지가 없음 ; σ 의 두께가 가압 중 값인지 · 시료 지름 · 오차 막대 정의 [미확인] ; "이온 tortuosity 의 압력 둔감" 은 정규화 효과와 분리되지 않음 | §4-1 (L146) · §6 (L197) · §10 (L249–259) | 카드 서술 · [미확인] | 논문 문장이 아니라 카드의 판독


### [batch_14] j. 카드가 스스로 "아직 못 한다 · 한계" 라고 적은 것 (가압 · 탈압 계산과 닿는 것)

- [j] so2022_dem_compaction_coated_particles_assb | 저자 한계 (논문 §4.3 · 카드의 한국어 옮김): "rough spherical AM 으로 제한 — 비구형·구조화 배열은 안 함 → 구형/타원에서 크게 벗어난 입자엔 결론 적용 불가" · "AM-pore 면적 과대평가 (시뮬이 AM 내부 소공극을 너무 많이 만듦)" · "SE 코팅이 실험보다 덜 매끈 → AM 표면이 부분 노출" · "20 µm 는 AM 응집체 (5 µm) 대비 크지 않다 → aggregate-수 의존성 배제 못 함" | §4.5 L119 · §4.6 L122 | 카드 표기 "명시 한계 (저자 스스로)" | 원문 영어 문장은 카드에 없음
- [j] so2022_dem_compaction_coated_particles_assb | 계보상의 한계 (카드 서술): So 2021 은 "AM 은 구, intraparticle cracking 은 future work" → 이 논문은 응집체 수준 균열만 (primary 구 자체의 균열 · 모양 변화는 안 함) · 시드 다중 실현 · 통계 명시 없음 · 전체 sweep ≈ 10 일이라 상자를 키우기 어려움 | §4.5 L117 · §4.6 L122 · L125 | 표지 없음 | —
- [j] lee2024_multiphysics_dem_fem_initial_pressure_assb | 저자 한계: "FEM 이 항복 응력 초과 변형 / 파괴를 미반영, 향후 추가 예정" (카드의 한국어 옮김) · 한 방향 전달 (충방전 중 입자 재배열 · 힘 사슬 변화 미반영) · 실험 검증 없음 · 외부압 50 MPa 이상에서 효과 포화 | §A.3 L281–282 · §10 L415 · L422–424 | 카드 표기 "한계에서 명시" | —
- [j] kakar1967_deformation_theory_hot_pressing | 저자 한계: 실험을 a/R ≤ 0.25 로 묶음 · 이론은 정수압인데 실험은 일축 다이 (압력 분포 불균일) · *"the width of the die does not permit an integral number of spheres"* · 한 구 안 평면 a 가 평균에서 100–150 % 까지 벗어남 · *"It is believed that no particular model governs the deformation"* · 이웃 평면이 닿는 임계 단계 뒤는 모델 밖 · 정방 쌓임은 *"does not seem to conform to a regular polyhedron on deformation and so cannot result in complete densification"* 이라 제외 | §3-A L48 · L57 · L67 · L70 · §8 L280 · §10 L301–302 · 논문 p.3224 · p.3226 · p.3228 · p.3230 | stated | —
- [j] nisar2024_dem_effective_electrical_conductivity_sps | 저자 서술: 소결 시뮬은 두 입자 상호작용만 보고 다중 접촉을 무시 → 고밀도에서 neck 합이 입자 표면을 넘는 비물리 (그래서 α 보정) · neck 안에도 공극이 남음 (SEM Fig 2) · 시드 / 실현 수 미명시 (시료당 기하 1 개로 보임) | §4 L83 · L90–91 · L98 | 표지 없음 | 소결 (가압 · 탈압 아님)
- [j] doux2020_stack_pressure_assb | 저자 가정 (측정 아님): 작동 적층압 5 / 25 / 75 MPa 에서 펠릿 자체의 기계적 성질은 영향이 없을 것 — 이미 370 MPa 로 눌렸으므로. 카드 한계: Fig 4c 는 계면 접촉 저항이지 SE 벌크의 σ – 압력이 아님 | §8 L235–236 · §13 L358–360 | 카드 표기 "본문 명시" | 탈압 뒤 펠릿 상태를 잰 것은 아님
- [j] sakuda2013_sulfide_mechanical_property | 저자 서술: *"preparing Li₂S–P₂S₅ bulk glass is quite difficult and has not been reported"* → 기준 밀도를 열간 프레스 펠릿으로 대신 · 황화물의 기계 물성은 대기 불안정 (inert 취급 필요) 때문에 측정이 어려워 그간 정량화되지 않았다 (카드의 서사 요약) | §13-1 L218–219 · §7 L112–113 · 논문 p.5 | 인용문 = verbatim · 뒤쪽은 표지 없음 | —
- [j] deysher2022_transport_mechanical_aspects_assb_review | 리뷰의 공백 선언: *"significant knowledge gap in the understanding of the mechanical properties of solid electrolyte materials and their composites"* · 앞으로의 방향 = 사이클 성능 예측 + 장기 역학 안정성 · 적층압 아래의 operando / paired reconstruction (FIB) | §4 L118–119 · §B.2 L215–216 | 인용문 (카드가 따옴표로 옮김) | 리뷰 · 원문 쪽 번호는 카드에 없음
- [j] kang2026_intertwined_electrochemo_mechanical_sulfide_assb_review | 리뷰가 꼽은 미해결: 각 열화 메커니즘의 기여를 떼어 재는 방법 · 전기화학 – 기계 열화가 폭주하는 임계 조건 (threshold) 규명 · in situ / operando · 다중 스케일 실험 × 계산 · *"Modifying one parameter inevitably alters others, often producing unintended consequences."* | §8 L224 · L227–230 | 인용문 (카드가 따옴표로 옮김) | 리뷰 · 가압 · 탈압 계산 자체에 대한 말은 아님


### [batch_15] j. 카드가 스스로 "아직 못 한다 · 한계" 라고 적은 것 (가압 · 탈압 계산과 닿는 것)

가압 · 탈압을 계산한 카드가 없어, 한계 문장은 대부분 "역학을 건너뛰었다" 쪽이다.

- [j] bielefeld2019_microstructural_modeling_composite_cathode | 저자가 뒤로 미룬 것: 입자 – 입자 계면 저항과 협착 저항 — *"do not take into account possible resistances occurring at particle–particle interfaces and constriction resistances ... regarded as a large number of interacting microcontacts"* (p.1629 · ref 36 = Greenwood 1966) · 입경 분포 (bi/tri-modal) 는 향후 과제 · 실셀은 시간에 따라 변함 (입자 균열 · 부피 변화) — 범위 밖 | §4 L74 · L76 · §5.6 L130 | stated (인용문) | 가압 · 탈압 계산은 애초에 없음 (porosity = 입력) → 한계 문장은 수송 쪽
- [j] bielefeld2019_microstructural_modeling_composite_cathode | 얇은 전극의 "겉보기 favorable" 은 유한크기 효과 — 긴 확산 경로 · 충방전 성능은 "이 모델이 못 반영" | §5.5 L124 · §10 L291 | 카드 옮김 | —
- [j] bielefeld2020_effective_ionic_conductivity_binder | 카드가 든 한계: (i) 연속체 flux 풀이라 SE–SE 점접촉 협착이 없음 (ii) porosity · 조성 · 입경 = 입력 ("소성-보정 없음, 입력값") (iii) 분포는 trimodal 한 경우 · 전류 추정은 "good case" (전하전달 · AM 확산 무시 — 저자 명시) | 머리 L66–69 · §5 L332 · §10 L470–492 | 카드 서술 ("저자 명시" 는 L491) | 가압 · 탈압과 닿는 것은 (ii) 뿐
- [j] cronk2026_lis_positive_electrode_geometry_fem | 저자 명시: *"These simulations only capture stress after the 1st lithiation"* · FEM 가정 *"fully compact (no porosity)"* · *"uniformly lithiated"* · *"the external boundaries of the electrode were fixed"* | §4.1 L207 · §4.5 L266 | stated (인용문) | 리튬화 팽창 계산 (가압 아님) · "사이클 누적·springback·재습윤 없음" 은 카드 정리 (L666)
- [j] beutl2024_round_robin_coin_cell_sulfide_assb | 실험의 빈 곳 (카드 정리): 압력 계열 · 하중 중 두께 · 언로딩 · 단면 공극 영상 · 접촉 정량 없음 · 코인셀 내부 압력은 "측정 · 조절 불가" | §4-5 L220 · §7-3 L315 | 카드 서술 | —
- [j] cooper2017_simulated_impedance_diffusion_porous_media | 저자 명시: 대류 · 전기 이동 · 이중층 없음 (그건 PNP 모델 필요) · 실측 EIS 대조는 후속 · 임피던스로 구조를 되짚는 것은 유일하지 않음 | §4-7 L176 · §6 L225 · §10 L352 | stated | 가압 · 탈압과 닿지 않음
- [j] asano2017_ncm111_li3ps4_composite_electronic_ionic_conductivity | 원문 서론이 적은 DC 법의 위험: *"The DC technique possibly causes the resistance including interfacial resistance when non-negligible resistance exists at the interface between the electrode and the solid electrolyte (SE) or between the SE and composite sample layer."* (p.A3960) | §4-1 L143 | stated (인용문) | 측정 한계 (가압 · 탈압 아님)
- chen2011: 가압 · 탈압과 닿는 한계 문장 없음 (역학 없음).


### [batch_16] j. 카드가 스스로 "아직 못 한다 · 한계" 라고 적은 것 (가압 · 탈압 계산과 닿는 것)

- [j] galvezaranda2024_time_dependent_dl_calendering_microstructure | 저자가 적은 한계 셋: (i) 상 사이 접촉면 오차 10–15 % (전체 기능 지표 < 5 % 와 대비) (ii) CD 20–50 % 밖의 외삽은 비물리적 거동을 낼 수 있음 (iii) 프레임 수 · 격자 해상도는 미탐색 · 그리고 "이 연구의 목표는 DEM 결과를 더 빠른 ML 로 재현하는 것" (기준선이 실험이 아니라 DEM) | §5-3 L297–299 · §5-4 L303–305 | stated (카드의 한국어 옮김) | LIB
- [j] galvezaranda2024_time_dependent_dl_calendering_microstructure | 카드가 적은 한계: 되돌아옴은 궤적의 육안 일치뿐 (숫자 0) · 압력 축 0 · DEM 물성 0 · 소성 형상 변화 0 · CBD 를 단일 라벨로 (점탄성 없음) · 데이터 · 코드 비공개 | §0 L32–40 · §4-5 L258–262 · §10-⑩ L643–650 | 카드 서술 | —
- [j] duquesnoy2020_calendering_ml_mesostructure_generator | 압밀 물리가 없다 (기공률이 입력 · 실험 다항식 밖으로 못 나감 — 다른 재료 · 압력 · 두께는 식을 다시 재야 함) · 압연 전 · 후 구조 사이에 연속성이 없음 (조건마다 새 상자를 처음부터 채움) · 생성 구조의 기공률 미측정 · 격자 수렴 시험 없음 | §4.1 L154–156 · §4.3 L212–218 · §11 L433–438 | 카드 서술 (코드 판독) · SI 인용문 (L153) | LIB
- [j] froboese2019_microstructure_ionic_conductivity_assb_electrode | 원문 결론: 구 충전은 0 % 기공에 못 가고 일축 압분으로는 0 % 불가 → 건식 과립 · 압출 · 코팅 같은 공정이 필요 · 카드: 단일 압력 · 단일 온도라 압력 의존을 말할 수 없음 | §6-bis L293 · §10 L424 | stated (카드 요약) · 카드 서술 | 고분자 SE
- [j] hlushkou2018_void_space_ion_transport_assb_cathode | 원문: 형태 – 수송 관계에는 형태 정보 전체가 필요하고 부피분율만으로는 안 됨 · 잔류 공극량에 주의 · SE 분율이 낮은 전극에서 더 나빠질 것 (추정 · 검증 없음) · 카드: 역학 · 압밀 물리 없음 — 공극이 왜 생기고 어떻게 없애는지는 다루지 않음 · 측정 중 적층압 · 되돌아옴 [미확인] | §1 L46 · §4-3 L189 · §7 L249 · L258 | stated (카드 요약) · 카드 서술 | LPSI · LCO
- [j] hamann2026_llzo_bilayer_porosity_asr_dendrite_ccd | 저자 §2.6: 계면 완전 정합 · Li 등전위 · 정상 상태의 이상화 — 실제는 보이드 (억제에 적층압 2–3 MPa 필요 [62] · 탈리 중 감소) · dead Li · 카드: 응력은 계산하지 않고 사후 문턱식 | §2.5 L87 · §4.5 L205–207 · §10.1 L351–353 | stated (카드 요약) | LLZO · Li 음극 — 가압 계산과는 "계면 접촉을 완전하다고 둔다" 는 가정에서만 닿음
- [j] islam2026_microstructure_resolved_impedance_lpscl_symmetric_cell | 역학 없음 (압력 · 응력 · 형상 소성 0) · 소결 모델에서 입자의 강체 병진 (어드벡션) 무시 · 실험 검증 0 | §4-2 L59 · L66 · §7 L104 · §10 L117 | stated · 카드 서술 | 2D
- [j] holzer2013_constrictivity_effective_transport_porous_layers | 가압 · 탈압과 닿는 한계 없음 (저자 한정어는 수송 분해식에 대한 것: *"the proposed parametric approach represents a heuristic solution and its validity has yet to be tested"*) | §4-3 L146 | stated (인용문) | —


### [batch_17] j. 카드가 스스로 "아직 못 한다 · 한계" 라고 적은 것 가운데 가압 · 탈압 계산과 닿는 것

- [j] ketter2025_resistor_network_models_predict_transport_properties | 모델에 기공 구조가 없다는 저자 문장: "As the input parameters … were taken from porous samples and a linear relationship between composition and density exists, porosity is accounted for in the simulation to a certain extent, although the actual pore structure is not explicitly simulated" | §4-1 L162 · SI §S7 | stated (인용문) | 수송 모델 — 압력은 실험에만 있고 모델에는 기하로도 들어오지 않음 (카드 L181)
- [j] ketter2025_resistor_network_models_predict_transport_properties | 첨가제 · 불명확한 구조는 못 다룸: VGCF 는 "additives that cannot be simply modelled by a voxel approach" (p.6) · Si–LPSCl–C 사례 실패의 이유 "no well-defined microstructure" | §3-4 L129 · §3-5 L138 | stated (인용문) | —
- [j] kato2018_thick_electrode_assb_cycle_tortuosity | 원문: tortuosity 추정은 "challenging due to the complex battery reactions taking place" (p.610) · 10 mS/cm 를 넘는 재료 값은 소결 · 열간압 상태라 "materials exhibiting high conductivities in the compressed state are desirable" (p.612) | §4-2 L218 · §3-9 L192 | stated (인용문) | 가압 계산이 아니라 "눌린 상태의 전도도" 가 문제라는 실험 쪽 문장
- [j] kato2018_thick_electrode_assb_cycle_tortuosity | (논문의 고백이 아니라 카드가 찾은 빈 곳) 본문 · SI 어디에도 기공률 · 두께 실측 여부 · 펠릿 측정 중 가압 · SE 입도 분포가 없음 | 원문 대조 기록 L477 | [미확인] | —
- [j] kim2026_a3d_air_electrode_microstructure_transport | "1D framework relies on volume-averaged effective properties... cannot explicitly capture pore-scale heterogeneities and microstructure-resolved deposition" (p.7) · 충전은 모델하지 않음 (생성물 산화는 방전의 역으로 기술 못 함) | §6-(d) L615 · §2.2 L172–174 | stated (인용문) · 표지 없음 | Li–O₂ — 가압 · 탈압과는 "평균화하면 국소 불균일을 못 본다" 는 점에서만 닿음
- [j] kim2026_pregranulation_ptfe_dry_nca_cathode_crack_delithiation | 저자: 10 사이클 두께 팽창의 원인은 "remains uncertain" (p.10) · DFT 의 군집 탈리 모형은 "bounding case rather than a unique structural assignment" · 반쪽 셀 실패에 Li 금속 음극 문제가 섞일 수 있음 (p.9) | §3-8 L194 · §3-5 L154 · §3-7 L175 | [인쇄] | 가압 계산 없음 — 캘린더링 압력 · 응력은 재지도 계산하지도 않음 (카드 판정 L31)
- [j] landesfeind2016_tortuosity_eis_electrodes_separators | effective τ 는 시료마다 실험으로 정하는 값이라 다른 기하 (입자 형상 · 기공률) 로 외삽할 수 없음 (A1374) · 형태 · 도전재 의존이 커서 문헌 값과의 엄밀 비교는 불가능 (A1385–A1386) · 3D 재구성과의 직접 비교는 조성 · 입경 · 형상이 같을 때만 (A1385) | §3-1 L70 · §5-8 L312 · §5-6 L285 | stated (카드의 한국어 옮김) | 수송 측정 — "눌러 바뀐 구조의 값은 그 구조에서만 유효" 라는 점에서 닿음
- [j] jung2023 · kim2024 | 논문이 적은 한계는 카드에 없음 (카드 자신의 한계 절 §10 뿐 — 기공 · 전도도 · 압밀 미측정) | — | — | —


### [batch_18] j. 카드가 스스로 "아직 못 한다 · 한계" 라고 적은 것 가운데 가압 · 탈압 계산과 닿는 것

- [j] nakamura2020_dry_coating_ncm_li3ps4_core_shell | 논문이 안 한 것: 압력 · 조성 · 시간 축 (360 MPa · 30 °C 한 점) · 반복 · 오차 · RVE 수렴 · 사이클 전 시료의 3D · DC 셀 시료의 3D | §0 L36 · §6 L228 · §10-7–8 L320–321 | [미확인] · 카드 서술 | —
- [j] nakamura2020_dry_coating_ncm_li3ps4_core_shell | 저자 자신의 미검증: σ_e 가 DC 에서 크게 떨어진 이유 (두꺼운 층에 압축 응력이 덜 전달) 는 "speculated" · 코어–쉘이 이후 슬러리 전단에서도 유지될 것이라는 함의도 시험 안 함 | §3-7 L169 · §3-3 L86 · §10-11 L324 | [인쇄] | —
- [j] nakamura2020_dry_coating_ncm_li3ps4_core_shell | 카드가 적은 우리 쪽 한계: DEM = 강체 구 + 겹침 · AM 파괴는 접촉 단위 판정뿐 조각을 만들지 않음 · MPM = 압축 중 SE 소성 흐름 (혼합 · 코팅 단계 없음) → 이 논문의 두 기전 (SE 망의 연속성 · NCM 파쇄 억제) 가운데 그릴 수 있는 것은 앞쪽뿐. 우리 "코팅" 팔은 표면 성질만 바꿈 (껍질 · 파쇄 완충 · 전자 차폐 없음) | §4-2 L197 · §7-1 L240 · L249 · §8-3 L288–291 | 카드 서술 · [추정] | 논문 문장 아님
- [j] lee2026_unveiling_ptfe_dry_electrode_digital_twin | 논문에 없는 것: 공정 → 구조 예측 (혼합 · 압축 모델) · 응력 · 변형장 · 두꺼운 전극의 해상 시뮬 (25 µm 만 — "these behaviors will be exacerbated as electrode loading increases") · 반복 통계 · PTFE 상 | §7-4 L373 · §3-10 L201 · §6 L320 | 카드 서술 · [인쇄] (인용문) | —
- [j] lee2026_unveiling_ptfe_dry_electrode_digital_twin | 카드가 적은 우리 쪽 한계: 코팅은 혼합 단계의 전단에서 생기는데 DEM (겹침 δ 가 대리) · MPM (압축 중 공극 채움 흐름) 둘 다 혼합 전단 소성이 없음 → 코팅 상태는 결과가 아니라 입력 | §4-7 L263–264 · §7-1 L331 · §7-2 L354 | 카드 서술 | 논문 문장 아님
- [j] matthews2024_ptfe_nanofibril_network | 압축과 닿는 미해결: 압축 중 PTFE 피브릴이 끊어지는지 문헌이 갈림 (본편의 "without breakage" 는 관찰 기반 주장) · 캘린더 라인압 50 N/mm 는 접촉폭 미기재라 MPa 로 못 바꿈 → 성형 300 MPa 와 직접 비교 불가 | §5.4 L311–318 · §12-6 L662–663 · §12-9 L667 · §10.0 L503 | stated (문헌 대비) · 카드 서술 | LIB
- [j] matthews2024_ptfe_nanofibril_network | 카드가 적은 우리 쪽 한계: 피브릴화 (결정자가 풀려나옴) 는 우리에게 없는 기전 — 씨앗을 사후에 뿌림 · primary 피브릴 (길이 수백 µm) 은 우리 RVE (50 µm) 에 한 가닥도 온전히 안 들어감 | §1 L76 · §6 L371 · §10.1 L553–557 | 카드 서술 · 🧮 DERIVED | —
- [j] morasch2018_binder_gradient_impedance_tortuosity | 저자 문장: 바인더 구배와 이온 저항 구배의 정량 연결은 "not yet possible" · 바인더의 면내 분포는 "Entirely unclear" · 구배가 있으면 임피던스 τ 는 겉보기 값 — "the tortuosities extracted from impedance analysis are apparent tortuosties which obviously cannot be directly applied to a macro-homogeneous battery model" | §4-9 L168–169 · §8-4 L292 · §10 L346 · A3466 | stated (인용문) | 가압 계산 없음 (미압축 전극) — "두께 방향으로 고르지 않은 구조는 수송 값 하나로 대표되지 않는다" 는 점에서 닿음
- [j] morasch2018 · nguyen2020 | 카드가 적은 우리 쪽 한계: 우리 두 수송 솔버 (접촉망 · 복셀) 는 관통 (투과) 형이라 방향을 못 봄 → 판 · 벽 근처 충전 층 · 플래튼 근처 밀도 구배 · 설계 구배를 그 값으로 순위 매길 수 없음 | morasch2018 §7 L214–216 · §8-8 L331 / nguyen2020 §5 L117 · L177 · §8 L205 | 카드 서술 (원문 근거 = Morasch A3463 · Nguyen Fig 6) | 눌린 구조를 평가하는 쪽의 한계
- [j] nguyen2020_electrode_tortuosity_factor | 저자: τ_e 를 P2D 에 쓰라는 권고는 실제 전극 · 성능 자료로 입증되지 않음 ("follow-up study" 로 미룸 · p8) · TLM 과의 일치도를 수치화하는 지표는 제안만. 카드: 입자 물리 0 (접촉 법칙 · 압밀 · 소성 · 형상 변화 없음) | §10 L215 · §6 L126 · §4-D L107 | stated · 카드 서술 | —
- [j] malifarge2017_tortuosity_symmetric_cell_impedance_tlm | 저자가 적은 후속 계획 (다른 입자 형상 · 양극 재료로 확장 · Wheeler 법과 비교) 은 이 논문에서 수행되지 않음 · 균질 1D 모형은 dead-end 기공 · 방향성 · 두께 방향 구배를 못 봄. 카드: 압연으로 정렬이 만들어지는 과정 (기계 쪽) 은 이 논문에도 없고 우리 DEM (강체 구) 도 줄 수 없음 | §10 L395 · L397 · §7 L318 | stated · 카드 서술 | LIB
- [j] landesfeind2018_tortuosity_impedance_vs_tomography | 카드: "압밀 · 형상 · 기계 물리 없음" (수송 절반만) · 실제 전극 (dead-end · 구배 · 바인더 덩어리) 에서 차단 대칭셀 τ 가 관통형 τ 와 같다는 검증은 아님 (강구 한 기하뿐) | §7 L244 · §10 L365 | 카드 서술 | —


### [batch_19] j. 카드가 스스로 적은 한계 가운데 가압 · 탈압과 닿는 것

- [j] song2025_porous_argyrodite_modulus_fracture_toughness | 한 다공도 · 한 공정 (13 ± 2 %, 360 MPa, 60 °C, 1 µm) — 다공도 의존 자료 없음; 경도 미측정; ν 0.37 은 조밀 결정 DFT 값을 13 % 다공체에 씀; 개시 인성뿐 (R-곡선 없음); 광유가 기공에 스민 영향 미논의 | §10 L188–196 | 카드 경고 | 압밀 상태 하나라 압력 축 대조 불가
- [j] reisacher2023_percolation_sulfide_carbon_matrix | 도전 매트릭스는 셀 안 2.07 MPa 미압밀 → 절대 σ 를 300 MPa 압밀 케이스와 비교 금지 (0 wt% 6.6e-5 S/cm ≪ 분리막 0.43 mS/cm) · 향후 = AM 포함 full-cell · 전자 차단 EIS | §14 L423 · §4.4 L159 · §5.7 L215 | 카드 경고 · stated | 압밀 상태가 측정값을 바꾼다는 실례
- [j] sangros2020_dem_electrical_conductive_paths_assb | 압밀 = 부피분율 목표 정지 (압력 sweep 아님) → P–기공 곡선 없음 · porosity 를 '전해질 함량' 으로 재정의; DEM 이 탄성 (소성 · 항복 캡 · 파쇄 없음) 이라 접촉면적 = 탄성 Hertz 면적 | §10 L263 · L267 | 카드 경고 | —
- [j] pouraghajan2018_tortuosity_polarization_interrupt_vs_blocking_electrolyte | 박리 팽창 (두께 +12 % · +5 %) 을 명목 건조 두께 · 다공도로 계산해 두 방법이 서로 다른 시료 상태를 잼 · 다공도 3/4 이 공급사 또는 '통상값' 36 % | §8-0 ③ L350 · §10-1 L395 · L63 | 카드 판독 · stated | 측정 시점의 두께 정의 문제
- [j] thorat2009_quantifying_tortuosity_porous_liion | 다공도 = 무게 · 두께 계산, 쓴 밀도 미기재 [미확인] · 다른 ε 점의 막 두께 미기재 · 외부 압축 68 kPa 만 (압밀 · 소성 해당 없음) | §10-1 L359 · §3-2 L80 · §4-7 L186 | [미확인] · stated | 기공 연산자 (단계 0) 와 닿음
- [j] taufactor_tortuosity_factor_tomography_tool | voxel 해상도 의존 — 거친 격자로 SE 목이 뭉개지면 τ 가 bulk 쪽으로 편향 | §10 L134 · L187 | 카드 경고 | 가압 · 탈압 자체가 아니라 그 뒤 수송 (단계 7)
- [j] tjaden2018_tortuosity_review_calculation_approaches | 가압 · 탈압과 닿는 한계 없음 (기공상 리뷰).


### [batch_20] j. 카드가 스스로 적은 한계 가운데 가압 · 탈압과 닿는 것

- [j] vijay2025_hybrid_cgmd_dl_slurry_microstructure | DEM 압연의 접촉법칙 · E · ν · μ · COR · 판 속도 · 압력 전부 미보고 · "압축 축이 '두께 감소율' 이라 우리 300 MPa / Heckel P_y 와 원리적으로 겹칠 수 없다" · ASSB 는 슬러리에서 끝 (압연 · 기공 = NMC-111 전용) | §4-2 L237–238 · §10-A L539 | stated (미보고) / 카드 풀이 | —
- [j] vijay2025_hybrid_cgmd_dl_slurry_microstructure | 저자 결론: 에너지 보존 같은 물리 제약을 넣으면 평형화 단계를 없앨 수 있을 것 (미래 과제) — 현행은 순수 지도학습 | §4-4 L273–275 | stated (결론) | —
- [j] wang2027_ncm811_effective_bulk_modulus_mapper_dfs_gnn | 저자: *"the CBD-pore was physically idealized as a zero-stiffness region … a computational simplification rather than based on the assumption that the mechanical contribution of the CBD is strictly negligible"* — 세-상 판으로 −9.58 % 과소 확인 | §3-1 L65 · §10-4 L389 | [인쇄] | 무른 상 강성 0 근사의 자인
- [j] wang2027_ncm811_effective_bulk_modulus_mapper_dfs_gnn | 역학 모형 = 선형 탄성 · 완전 결합 목 · 소성 · 손상 없음 · 압축 · 캘린더 과정의 물리 없음 · 라벨 = 모형 내부값 (실험 K 대조 없음 — 저자 인정) | §10-4 L389 · §4-2 L221–222 | [인쇄] / 카드 풀이 | —
- [j] wang2027_ncm811_effective_bulk_modulus_mapper_dfs_gnn | 저자: *"the present spatially grouped evaluation remains a within-parent-volume validation … do not establish cross-volume generalization"* | §3-11 L181 (p.14) | [인쇄] | —
- [j] yoo2026_porosity_gradient_dry_electrode | 카드: 토모그래피는 고정 미세구조 정량이지 압축 역학 예측은 못함 (post-mortem 구조) | §7(d) L426–427 | 카드 풀이 | —
- [j] yoo2026_porosity_gradient_dry_electrode | 저자 caveat: 중간 면적용량 ~3.5 mAh/cm² 에서만 평가 · 더 높은 로딩 / 두께에서 장거리 연결성 유지 여부는 향후 과제 | §4.3 L226–227 | 표지 없음 | —
- [j] zhang2026_dryprocess_electrode_architecture_cell_level | 캘린더 압력 · 갭 · 선하중 n/a (Alabdali · Weitze 에 이어 세 번째) · 최종 도전망은 캘린더링이 정하는데 그 조건이 논문에 없다 (100 °C 만) | §2-1 L170 · §3-8 L501 · §11-⑫ L1276–1277 | n/a | —
- [j] zhang2026_dryprocess_electrode_architecture_cell_level | 캘린더링 (압축) 은 CGMD 로 전혀 다루지 않음 (NVT 고정 부피 · 공정 3 단계 중 1 단계만) · Fig 3f 미수렴 ("~250 nm" 는 스냅샷) | §4-6(d) L742–743 · §11-⑩ L1270–1271 | 카드 풀이 / figure-read | —


### [batch_21] j. 카드가 스스로 적은 한계 가운데 가압 · 탈압 계산과 닿는 것

- [j] zhou2026_gyroid_structural_electrolyte_stiffness_ionic_tradeoff | 소성 · 압밀 · 접촉 · 파괴 없음 · 작은 변형 선형 탄성 · 역학 ↔ 수송 비결합 (p.3) · 실험 검증 = 향후 (방향별 기계 시험 + 차단 전극 임피던스 · p.8) | §0 L35–36 · §10 L299 | [인쇄] / [우리 산술] | 연속체 · 설계 기하
- [j] asylbekov2023_cb_fragmentation_pbe_dem_dry_mixing | DEM 입자는 영원한 강체 구 (항복 캡 · 소성 접촉 · 파쇄 없음) · 응력 체제가 300 MPa 보다 3–6 자릿수 아래라 σ_crit 곡선을 압밀에 그대로 넣으면 "모든 CB 가 첫 접촉에서 하한까지 분쇄" (카드) · 재응집 모델 없음 — 바인더를 넣으면 필수 (저자 결론) · 0D 공간 무시 | §4.6 L355 · §10 L792–795 · L818–820 · §A-5 L610–615 | stated / 카드 풀이 | 혼합 공정
- [j] bak2024_binder_distribution_multilayer | 캘린더링이 이차입자 활물질을 파괴해 접착 강도를 왜곡 → 분포 측정은 비캘린더 상태 (Fig S5) · 디지털 트윈 = 전자 전도만 · 입자 스케일 압축 역학 예측 없음 (구조는 측정 · 설계로 입력) · 저자: 중로딩 3.5 mAh/cm² 라 분포 차이가 미묘 | §2.4 L135–136 · §2.6 L158–159 · §7(e) L421–423 · §4.6 L279–280 | 표지 없음 | 액체 LIB
- [j] cho2024_conflicting_roles_conductive_additive | 압밀 곡선 · Heckel · coordination · coverage · E_SE n/a · τ 산출법 미명시 · PSD 미보고 | §12 L500–505 · §3 L133–136 | 카드 풀이 | 실험
- [j] duquesnoy2023_ml_multiobjective_manufacturing_optimization | 고밀도 극단 (CD 36.36 %) 의 AM 입자 파쇄 위험 (CEI/TM 용해 · 비활성화) 은 현 모델 미반영 · 모델 ↔ 실험 차이 원인 (그들 명시) = 구형 입자 + clustered CBD 단순화 · σ_e 실험 미측정 | §3.4 L84 · §3.5 L96 · §10 L339 | stated | 액체 LIB
- [j] frankenberg2024_dem_high_intensity_mixer_assb | 항복 캡 없음 · 입자 파쇄 미모델 (고속 분쇄는 정성 언급) · 응집체 형성 자체를 시뮬하지 않음 (응력만 추출) · 압축 보정 곡선 초반 편차 (coarse-grain 입자망 ε_total 0.75) — 고압축에서만 일치 · 기공 미산출 | §4.2 L77 · §4.5 L110 · §B-3 L214 · §4.6 L116 · §3 L62 | stated / 카드 풀이 | 혼합 공정 · 분체


### [batch_22] j. 카드가 스스로 적은 한계 가운데 가압 · 탈압 계산과 닿는 것

- [j] galvezaranda2025_paml_vgg16_dem_slurry_drying | 압력 · 응력 축 0 (MPa 0 회) — 사슬 3 편 (슬러리 · 건조 · 압연) 어느 것도 MPa 없음 · Heckel · 압밀 축과 원리적으로 안 겹침 | §0 L21 · §7-2 ⑤ L418–421 | stated (전수 grep) | —
- [j] galvezaranda2025_paml_vgg16_dem_slurry_drying | DL 이 r 을 출력하지 않아 반경 · 형상 변화 (bead 수축 · 사이클 반경 진동 · MPM 형상) 를 원리적으로 표현 못 함 → 출력 차원에 반경 · 형상 포함 필요 | §4-2 L235–236 · §8-5 L503–506 | 카드 풀이 | —
- [j] galvezaranda2025_paml_vgg16_dem_slurry_drying (카드에 적힌 우리 쪽 기록) | 우리 MPM scaffold 정착 porosity 가 플래튼 정지 프레임의 함수 (`--sub` 40 / 80 / 160 → 14.38 / 12.76 / 11.08 % · 수렴 안 함 · CL-04 준정적 ε_sphere 1.13 % = 실험 15.6 % 대비 14.5 %p 과압축) → 프레임 색인 surrogate 는 정지 인공물을 배운다 · 카드 제안 축 = TF 가 아니라 wallP | §7-2 L431–444 · §8-1 L486–490 | 카드 인용 (우리 정본) | 논문 값 아님
- [j] han2025_icep_conductive_elastic_binder | 압밀 porosity · Heckel · 복합 σ_eff 데이터 전무 · 나노압입 E 6 GPa 를 MPM binder 상 E 로 쓰면 안 됨 (bulk 거동은 MPa 급) · Auerbach 파괴에 binder 항 없음 | §10 L165–166 · L171–172 · §7-⑪ L137 | 카드 풀이 | —
- [j] hare2026_dem_pept_dry_mixing_nmc622_eirich | 무소성 Hertz–Mindlin 가정은 300 MPa 구속 압밀로 전이 안 됨 · 검증 축 = 속도 하나 (힘 · 응력 · 접촉수 · 편석 대조 없음) · 단분산 입력이 편석 가능성을 입력 단계에서 제거 | §4.2 L220–221 · §5.3 (a) L342–344 · §11-9 L598–599 | 카드 풀이 | —
- [j] hippauf2019_dry_film_ptfe_sulfide_cathode_sheet | 입경 [미확인] = 기공 12 % 를 다른 침대와 비교할 때 가장 큰 결손 · 12 % 는 측정 밀도 ↔ 이론 밀도 계산 · "PTFE fibrils will break during compression" 은 예상 (측정 아님) · 계면 항 없는 복셀 모델은 PTFE 에 따른 양극 계면 저항 (R4) 증가를 원리적으로 못 냄 (`CL-81`) | §10-8 L265 · §0 L36 ④ · §10-7 L264 · §7-4 L230 | [인쇄] · [추정] · 카드 풀이 | —
- [j] hong2026_sulfide_cathode_binder_digitaltwin | 디지털트윈 σ 는 입력 (자기참조) · ConductoDict FV 는 점접촉 sub-voxel 협착을 못 잡는 접촉 없는 상한 · PTFE void 억제는 75 wt% · 350 MPa 단일 조건 (PTFE cohesion 을 넣으면 이 1 점에 맞출 수밖에) · 우리 쪽도 시간 열화 · spring-back 없음 (카드: "단일 압축 스냅샷 … #285 spring-back 미구현과 같은 정체") | §10 L617–627 · §7(d) L529–531 | 카드 풀이 | —
- [j] jadidi2023_dem_batch_solid_mixers_review | 보정 = 시행착오 · 점착이면 입력이 많아 더 어려움 · 벌크 보정 ≠ 공정 예측 (Pantaleev 2017) · ML 은 훈련 설계공간 안에서만 · CG 허용조건 · 실패 모드 미제시 | §10.3 L525–532 · §4.5 L159–164 | stated · 카드 풀이 | 믹서 (압밀 아님)


### [batch_23] j. 카드가 스스로 적은 한계 가운데 가압 · 탈압 계산과 닿는 것

- [j] kang2025_bollard_anchored_binder_dry_electrode | "성형압 ↔ porosity / Heckel … 0건" — 압밀이 압력이 아니라 목표밀도 (3.0 g/cm³) 로 규정 → "다압력 곡선·Heckel 불가" | §3e-(다) L193 | 카드 판정 | —
- [j] kang2025_bollard_anchored_binder_dry_electrode | 카드 풀이: 산업 건식라인의 실제 규약은 밀도 정지 (우리 `hold` 쪽) — 동시에 "hold 에서 porosity 는 정지 프레임의 함수" 이고 이 논문 porosity 가 밀도 역산 계산값인 것도 같은 구조 → "둘 다 정지규약이 값을 정한다 는 공통 취약점이지, 상호 검증이 아니다" | §7b L611 | 카드 풀이 | 우리 MPM 과의 대응은 카드 해석
- [j] kang2025_bollard_anchored_binder_dry_electrode | 필름 E (MPa 스케일) → MPM 재료 입력 직접 사용 ⛔ · soft-phase 서열 · 비율만 | §10.4 L709 · §3e-(다) L195 | 카드 판정 | 카드 안 우리 PTFE 값 두 개 (카드 문제 6)
- [j] kang2026_multiscale_inverse_design_ptfe_fibrillation_dry_electrode | 실물 공정 조건 (rpm · 시간 · 온도 · 간극 · 캘린더 압력) 미기재 · '섬유화' 는 구성식에 없음 (사후 구간) · 2D / 3D · 원 치수 · PTFE 초기 크기 · 메시 · 접촉 · 하중 속도 · 해석 시간 미확인 · COMSOL 모델 미공개 | §0 한정어 L46 · §3-2 L99 · §10-5 · 7 · 13 · 16 L346 · L348 · L354 · L357 | 카드 판정 · [미확인] | —
- [j] kang2026_multiscale_inverse_design_ptfe_fibrillation_dry_electrode | MIP 공극의 교락 — 막의 캘린더 상태 · 두께 · 밀도 미기재 → 공극 차이를 섬유화 차이로 읽을 근거 부족 · LFP 전극 공극 미보고 | §10-24 L365 | 카드 판정 | —
- [j] kawaguchi2023_doe_electrode_fabrication_dry_coated_ncm_lps | Rs = 분리막 + 복합 양극 — 분리막 (80 mg) 도 같은 P 로 다시 눌려 치밀해지므로 P 효과의 일부는 분리막일 수 있음 · 분리막만 어림 ≥ 0.7 kΩ (Rs 791–2,520 Ω 와 같은 자릿수) | §10-3 L270 · §8-5 L260 | [추정] (가정 포함) | 압력 효과 귀속 문제
- [j] kawaguchi2023_doe_electrode_fabrication_dry_coated_ncm_lps | 공극률 · σ 가 없어 우리 모델 (DEM · MPM) 의 보정 · 검증 앵커가 되지 못한다 (frame [4]) · 조건마다 셀 1 개 · 체결 토크 → 압력 환산 없음 · Xs 0.2 반응표면 = 측정 없는 선형 보간 | §10-10 L277 · §7-4 L235 · §3-2 L75 · §10-6 L273 | 카드 판정 | —
- [j] kawaguchi2017_dry_coating_parametric_na2so4_model_se | 모델 물질 Na₂SO₄ 는 이온 전도 없음 · 강성 · 탄소성 · 가압 소결 유사성의 수치 (ref 18) 가 이 논문에 없음 · 피복 정량 없음 · 조건마다 1 회 | §10-1–3 L219–221 | 카드 판정 | —
- [j] jun2026_ppma_econductive_binder_si_lowpressure_assb | 이점은 실용 저압 (≈5 MPa) 전용 — 70 MPa 에선 PVDF 142 > PPMA 131 mAh/g 역전 · "PPMA가 항상 우월" 인용 금지 · 조성 교란 (90:10 vs 97:3) | §16 L231–232 | 카드 판정 | 운전 스택압 축 (성형 압밀 축 아님)
- jeong2025 · kim2026: 가압 · 탈압과 닿는 한계 서술 없음 (압력 축 없음).


### [batch_24] j. 카드가 스스로 적은 한계 가운데 가압 · 탈압 계산과 닿는 것

- [j] koo2026_swcnt_sheath_thick_electrode | 그 논문엔 입자스케일 압축역학 예측 없음 — "고정 미세구조 — 토모는 이미 압축된 전극" · 압력 → 미세구조 → σ 예측 없음 | §9(e) L531–534 · §10 L586–588 | 카드 풀이 | —
- [j] koo2026_swcnt_sheath_thick_electrode | VMS 는 모든 상 탄성 (소성 미포함, preliminary) · 역학 = 평형식 + 운동학식, 선형탄성 · 소성 없음 (Note S5 명시) | §5 L282 · §11.10 L948 | 표지 없음 | 압밀 소성 없음
- [j] koo2026_swcnt_sheath_thick_electrode | 분말 전도 최대 64 MPa → "300 MPa 외삽은 금지" · 전극 시트 σ 는 외부 가압 조건 자체가 기술되지 않음 · 온도 · 습도 · 집전체 부착 여부 미기록 | §11.4(a) L739–740 · §11.4(b) L752–755 | 카드 판정 | 압력 범위 한정
- [j] lee2024_shear_force_dry_process_cathode_coverage | 모델 ↔ 실험 정량 맞춤 없음 — "this model cannot precisely match the experimental results" (p.5) · 압력별 · 혼합 시간별 피복 안 함 · 셀 적층압 MPa · 전극 두께 · 공극률 미확인 · SEM 단면이 셀에서 꺼낸 시료인지 따로 누른 시료인지 미확인 | §6 L279 · 머리 L38 ④ · §4-1 L229 | [인쇄] (인용문) · [미확인] | 가압 조건 결손
- [j] lee2025_corolling_dryprocess_lpscl_ptfe | 시뮬레이션 0 → 압밀 기공 · Heckel · 배위수 · coverage · E_SE · σ_y · 접촉면적 전부 n/a · void 는 사이클 뒤 계면 상대비 · co-rolling 전단은 "우리 RVE 모델이 안 다루는 공정 영역" | §10 L146–147 · L154–155 | 카드 판정 | —
- [j] lee2025_dual_fibrous_ptfe_dry_electrode | 다압력 스윕 0 (롤프레스 압력조차 미기재 → Heckel · 압밀곡선 불가) · 피브릴 치수는 한 조건 한 세트 (압연 전 / 후 명시 없음) · 동영상 = 절삭 시험 (압밀 아님) | §10.6 L430–432 · §13 L497–498 · L518 | 카드 판정 | —
- [j] lee2026_li_underlayer_primer_free_dry_prelithiated_thick_anode | 라미네이트 압력 · 온도 미확인 · ≈85 µm → 63–65 µm 압밀 과정 서술 없음 · FEM = 압밀 안 한 Blender 적층 · 물성 · 시간 · 메시 전부 미확인 · Li 금속이 라미네이트 때 막 바닥으로 흘러 맞물렸을 가능성 논의 없음 | §3-1 L74 · L77 · §10 L344 · §4-3 L189 · §7-2 L267 | [미확인] · [추정] | 음극 · 액체 LIB
- [j] koo2025_cnt_wrapped_sc_nca_dry_cathode | 단일 스냅샷 (시간 · cycling chemo-mechanical 은 공통 GAP) · 압력값 없이 밀도로만 | §10 L455 | 카드 판정 | —


### [batch_25] j. 카드가 스스로 적은 한계 가운데 가압 · 탈압 계산과 닿는 것

- [j] lippke2023_dem_drying_structure_formation_lib | 범위 선언: Hertz–Mindlin 은 NCM622 큰 변형을 못 다루지만 건조엔 충분 → 카드: 압밀 (압연 · 프레싱) 논문이 아니라는 자기 선언 · 우리 300 MPa 냉간압밀로 이 접촉 선택을 옮기면 안 되는 이유 | §4.2 L207–210 | stated · 카드 풀이 | —
- [j] lippke2023_dem_drying_structure_formation_lib | 저자 명시 모델 누락: 액면의 압력힘 (CFD 필요) · 최종 두께 뒤 pore-by-pore 증발 (그래서 Fig 5 뒤쪽 이완은 비물리) · 온도 의존 점도 · 바인더 농도 구배 · Outlook = 전달물성 검증 · 비구형 입자 · 바인더 분포 커플링 · 압연 DEM 커플링 | §10 ⑥ L798–800 · §D-9 L704–706 | stated | 습식 건조
- [j] lischka2025_dem_eirich_intensive_mixer_dry_mixing | "not capable … for particle diameters bigger than 2 mm or a Coarse-Grain-Factor of 200" · 분쇄는 시뮬하지 않고 파라미터로 번역 · 충돌에너지는 분쇄 에너지의 상한 | §3.4 L104 · §4.5 L219 · §4.8 L282 | stated | 압밀 아님
- [j] liu2025_dry_processing_high_energy_li_batteries_review | 리뷰 결론 3 장벽 (공정 민감성 · PTFE 의 Li 금속 환원분해 · 두꺼운 전극의 이온 / 전자 percolation 한계) · 카드: 리뷰가 DPC 는 "극단적 압축력 필요 + post-heat" 라고 강조 · vertical channel 로 τ ↓ 하나 기계강도 · 압밀저항 ↓ (trade-off 명시) | §1 L15–17 · §4 L109 · §A ① L156 | 리뷰 서술 · 카드 옮김 | 정량 없음
- [j] mun2025_dry_electrode_technology_assb_review | Perspective 5 대 난제 (바인더 재료 · mixing · coating · thick electrode · scale-up) + dispersion · segregation · pressure-free 운용 | §2 L31 · §5 Fig 7 L134 · frame[5] L206–207 | 리뷰 서술 | 정량 없음
- meng2026: 가압 · 탈압과 닿는 한계 서술 없음 (압밀 공정 없음 · 저자 자인 = "no statistical hypothesis testing" L227).


### [batch_26] j. 카드가 스스로 적은 "아직 못 한다 · 한계" 중 가압 · 탈압과 닿는 것

- [j] qin2026_bilayer_cathode_cgmd_dem_graded_thick_electrode | 압력 · 응력 출력 없음 (변위 목표 · 벽 반력 미보고 · 롤 아닌 평판 근사) — 같은 응력 가설을 이 논문 안에서 검증 불가 · 명목 캘린더링을 MPa 로 환산 금지 | §4.4 줄 299 · L-1 줄 495 · §8.C-3 줄 443 | 카드 서술 | —
- [j] qin2026_bilayer_cathode_cgmd_dem_graded_thick_electrode | 건조 두께는 입력 (처방 공극률) — c0 전체 공극률은 예측이 아님 · 스프링백 크기 = JKR-LJ 회복, 실측 미비교 · AM 손상 (균열 · 파쇄) 미모사 (p.28) · 1 실현 · 측면 ≈2.2 d_max | §4.4 줄 300 · L-13 줄 507 · §10.1 줄 489 · L-3 줄 497 | 카드 서술 · stated | —
- [j] sankar2026_fiber_scale_dem_carbon_felt_manufacturing | 힘 · 압력 결과 0 건 · 캘린더링 = 변위제어 명목값 · 되튐 뒤 두께 · 공극 미보고 · 플래튼 변위 ≠ 기하 두께 변화 (저자 명시) · 섬유 파단 · 소성 없음 · 단계 중 접선 법칙 전환 | L5 줄 595 · L6 줄 596 · §4.6 줄 329 · L7 줄 597 · §11-1 줄 584 | stated · 카드 서술 | —
- [j] nam2026_primer_layer_dry_electrode_collector | DT 모델에 압축 물리 없음 — "비가역 변형으로 물린다" 는 기전 주장은 나노압입 간접 증거뿐이고 시뮬로 검증되지 않음 | §12-10 줄 701–703 · §5.1 줄 291–292 | 카드 서술 | —
- [j] park2026_thiolene_sbr_binder_assb | 0.3 MPa 작동압 ≠ 300 MPa 제조압 · 70 MPa 에서는 바인더 차이 작음 (고압이 접촉을 강제) · `--coh` 를 이 논문에 정량으로 맞출 수 없음 (사이클 결과 · 압축 결과 아님) · 시간 열화는 단일 제조 스냅샷으로 예측 불가 | §7(c) 줄 380–389 · §4.2 줄 236–237 (Fig S10) · §10 줄 490–494 · §8 줄 438–441 | 카드 서술 · 표지 없음 | —


### [batch_27] j. 카드가 스스로 적은 한계 중 가압 · 탈압 계산과 닿는 것

- [j] schmitt2026_chemomech_stability_dry_cathode_separator_sheets | 기공 정량 안 함 (p.7) · *"The mechanical assessment in this study is based on indirect evidence from SEM imaging and electrochemical testing"* (p.11) · 선압 3 N/mm 를 MPa 로 바꿀 접촉 폭 [미확인]; 카드: 문헌 셀과 견주려면 제조압 · 적층압 · 측정압을 따로 맞춰야 하고 우리 300 MPa 압밀 상태는 어느 이력에도 없다 | §3-2 줄 79–80 · §10-1 줄 381 · §7-5 줄 323–324 | [인쇄] · 카드 판단 | 시트 두께 · 기공 측정 없음
- [j] sun2026_dem_extrusion_recirculation_dry_electrode | 공기 냉각 중 미세구조 완화 (relaxation) 미반영 (가정 9) · 온도 · 점성 · 모세관력 · 파쇄 없음 · 시간 · 공간 척도를 축소 · 확대해 실험과 정량 비교 'infeasible' | §4.5 줄 259 · §10-1 · 2 줄 387–389 | stated | 압출 공정
- [j] wang2026_dryprocess_thick_cathode_failure_ncm94 | 카드: 우리 침대는 300 MPa 성형 상태로 고정 · 압력 해제/재가압 경로 없음; 스택 강성 미공개 → ΔP → ΔV 환산 불가; 압력 한 점 → Heckel · P_y · σ-vs-P 못 냄; 두께 감소는 성형 + 사이클 합이라 순수 압밀량 아님 | §13.6 줄 672 · §15-12 줄 733 · §15-6 줄 723 · §13.1 줄 609–610 | 카드 판단 | —
- [j] wet_processing_resolved_am_ssb_cathode_manufacturing | 저자 향후 과제 *"porosity as a function of calendering pressure, conductivities, and cracking of secondary particles"* · 압연 단계 실험 앵커 0 · 본문 절대압 (MPa) 0 회 · roll 속도 미보고 · 'energy was unable to reach full equilibrium' | §①-C 줄 386 · 388 · §①-E 줄 408 | stated · 카드 grep | —
- [j] wolf2026_extruder_vs_batch_mixing_core_shell_dry_sulfide_cathode | *"cross-sectional imaging and 3D-microstructure modeling was unavailable"* (p.10) · *"baseline comparison … investigated individually as alternative processes"* (p.13) · 11 mm · 300 g/h 결과가 큰 장비로 그대로 옮겨지지 않음 · 닙 두께 ↔ 풀린 두께는 측정 없음 (카드) | §0 ⑨ 줄 38 · §0 줄 26 · §3-1 줄 69 · §3-5 줄 127 | [인쇄] · 카드 | —
- [j] bucci2017_chemomech_failure_assb_cycling_czm | 하중이 기계 가압이 아니라 Li 삽입 (압밀량 n/a) · 완전 정합 · 안정 계면 가정 · intrinsic CZM 치우침; 카드: 우리 MPM J2 = 연성만 — SE 취성 균열 표현 불가 (D6 공백) | §3.5 줄 151 · §5.1 줄 237 · §4.2 줄 193 · frame[5] 줄 418 | stated · 카드 판단 | —


### [batch_28] j. 카드가 스스로 적은 "아직 못 한다 · 한계" 중 가압 · 탈압과 닿는 것

- [j] dem_mechanical_stresses_ssb_electrode_cycling | AM 크기 변화를 균일하게 둠 (저자: 실제는 불균일 · 대칭 충방전 가정) · lithiated/delithiated AM 전도도 변화 미보정 → 값은 기하만 · full electro-mechanical coupling = 계산비용으로 보류 · 등방 1 MPa 아래 σ_el ↓ · 최적 등방압은 더 다듬어야 · τ 비단조 원인 "further investigation needed" | §4.6 줄 163 · §3.5 줄 116 · §5.1 줄 192 · §5.4 줄 204–205 | stated | —
- [j] gandla2026_layered_cathode_degradation_diagnostics_review | ≤ 2 MPa · > 4 mAh/cm² 에서 장기 검증된 코팅 없음 · operando 셀 = 작은 나사로 조여 정부피 → 내부 압력 계속 변함 · 필요한 셀 = *"one that can impose a low target pressure precisely and hold it constant during operation"* · 적층압을 고정 · 균일 조건으로 읽지 말 것 · 변형 문턱 ~2.5 % 일반화 미검증 | §3-11 줄 208 (p.29) · §3-10 줄 188 (p.26) · §3-5 줄 123 · 118 (p.14 · p.12) | [인쇄] | 총설
- [j] intergranular_cracking_nmc811_jmca2023 | 단일입자 FEM 이 중심 큰 공극 · 13–25 % 부피팽창을 재현 못 함 → 제조 (고온 소결) 잔류응력 탓으로 추정 (future work) · 외부 압력 항 없음 · CBD/입자 박리 미포함 · SC · SSE 확장 = 향후 | §4-B 줄 162–168 · §10 줄 260–262 · 268–269 | stated · 카드 서술 | —
- [j] kang2025_toughened_bimodal_nca_lzo | 계산부담 때문에 Li 확산 · 삽입 변형 등방 가정 · 입자 완전 방전 균일 출발 · AM 반경 5 µm 대표값 · 사이클 균열에서 stack pressure 기여 미미 (본문) | §4 줄 157–158 · 182–183 · §10 줄 327–328 | stated | —
- [j] kim2023_chemomech_failure_highstrain_anode | FEM 주결과 = 응력장 (균열은 입계 von Mises 증가로 추론) · 재가압이 접촉을 일부만 회복 (비가역 손상) · 작동 100 MPa 가 300 사이클 안정 (250 MPa 대비) | §10 줄 353–355 · §7 줄 275–276 · §5 줄 235 | stated · 그림 | —
- [j] bucci2018_mechanical_instability_interface_delamination | rate-independent (충전율 의존 = 향후) · 벌크 / SE 분해 경쟁 = 향후 · Vegard 선형 등방 가정 | §5.1 줄 199 · §5.2 줄 202 · §10 줄 361 · 364 | stated | —
- [j] interfacial_impedance_formulation_assb_cathode | 저자 한계 서술 카드에 없음 · 카드 주의 = 제조 300–500 MPa ≠ 작동 4 MPa · r_i,gb 는 압밀된 구조를 잰 값 | §12 줄 385 | 카드 서술 | —


### [batch_29] j. 카드가 스스로 적은 한계 가운데 가압 · 탈압 계산과 닿는 것

- [j] so2021_dem_fabrication_degradation_ductile_particles | 저자 Shortcomings: 2D · 구형 가정 · α 무차원 · AM–SE 입자 ≤1600 (수 무관성 확인 필요) · 삽입 때 상단 면 스프링 (일부 압력이 실 배터리 범위 초과) · 균일 팽창 (반응 · 물질전달 미결합) · 사이클 열화는 실험 검증 없음 (제조만 Sakuda 대조) | §4.6 L165 · §5.10 L218 · §7.1 L274 · §10 L384 | stated | —
- [j] tron2023_lpscl_ccd_ambient_pressure | 펠릿 밀도 측정법 · 두께 측정 상태 · 꺼낸 뒤 지름 미기재 · 한 압력 (360 MPa) · 다압력 Heckel 없음 · 스택압 아래 펠릿 두께 변화 없음 · 반복 수 · 표준편차 없음 · SI 미입수 | ⛔ 한정어 L32 · §3-10 L179 · §7-2 L254 | [미확인] | —
- [j] sedlatschek2026_nmc811_grain_boundary_strength_micro_tensile | 압축 시험은 정성 (저자 "no quantitative results could be derived") · 두 E 모두 치밀 · 무결함 영역값 — 내부 기공 · 제조 균열을 가진 2 차입자 통째의 유효 강성은 더 낮을 수 있고 재지 않음 · 상용 캘린더링 전극 입자는 처음부터 균열 (Fig 2a → "t = 0 에 AM 무손상" 가정은 낙관적) | §3.3 L116–117 · §7.2 L280–281 · §5 L216 | stated · 카드 풀이 | AM 입력 쪽 한정
- [j] lee2026_microcrack_tolerant_bilayer_cathode_chemomech_fastcharging | 모든 입자 선형탄성 · 소변형 · 소성 · 크리프 · 파괴 없음 (본문 2.4 명시) → 300 MPa 는 "탄성 상한" 성격 · 이상 층간 계면 (본문이 한계로 명시) | §4 L52 · L54 · §10 L102 | stated · 카드 풀이 | 액체 LIB · 사이클 응력 (압밀 아님)
- [j] tabakovic2026_mechanical_stress_eis_ica_drt_dfn | 압력 = 정수압 σ_h 하나 — 실제 셀의 일축 적층압 · 편차응력 · 분리막 압축 (기공 감소) 없음 · 접촉 저항 · 접촉 면적 모델에 없음 → "압력에 따른 옴 저항 평행 이동" 은 원리적으로 재현 불가 (저자 명시) | §4.5 L124 · §10 L200 | stated | 운전 적층압 (1–10 MPa) · 압밀 아님
- [j] kim2025_impedance_decoupling_tlm_assb | 압밀 · 기공 · 역학 미산출 (두께 L 만) · 압력 3 종 구분: 제조 / 압밀 250–433 MPa ≠ EIS 측정 (셀 조립 상태) ≠ 작동압 · R_ion 은 압밀된 구조를 잰 값 | §4.5 L196–198 · §12 L547–549 · L568–569 | 카드 풀이 | —
- [j] li2026_electrochemomechanical_coupling_asslmb_review | 표 3 의 LPSCl E 는 13 % 다공 펠릿 벌크값 → 입력으로 쓰지 않음 ("측정 부류가 다르다") · 리뷰 숫자는 전부 2 차 인용 | §0 L20 · §7 L122 · §10 L142–146 | 카드 판정 | —
- siroma2015 · spencerjolly2023: 가압 · 탈압과 닿는 한계 없음.


### [batch_30] j — 카드가 스스로 적은 한계 가운데 가압 · 탈압과 닿는 것

- [j] wheatcroft2023_nmc811_secondary_particle_fracture_insitu_sem | 고립 입자 두 점 하중 — 전극 속 다접촉 입자의 분할 하중과 다를 수 있음 (다접촉 시험 없음) · 캘린더링 대응은 서술뿐 (무압연 전극) · FE 에 1차입자 · 입계 해상 · 입자 소성 없음 · 표면 아래 미세균열 (onset) 은 SEM 으로 못 봄 · 원문 한정 "the secondary particles are not always perfectly spherical" (p. 5) | §10-10 (줄 468) · §4.8 (줄 247–248) · §7.2-1 (줄 332–333) · §3.3 (줄 119) | 카드 기록 · 원문 인용 | AM
- [j] yun2023_deciphering_degradation_halide_vs_sulfide | 지속 가압 (250 MPa) 이 할라이드 LIC 를 시간에 따라 깸 (240 h σ 반감) · LPSCl 은 유지 · 압밀 기공 · Heckel · σ_y 미측정 · SE 취성 균열은 우리 DEM (강체구) · MPM (연성 J2) 둘 다 못 함 (카드) | §3.2 · §4.5 (줄 251–253) · §10.3-1 (줄 503–507) · §12 | stated · 카드 해설 | LIC = 다른 재료
- [j] kim2024_digital_twin_acsenergyletters | 원문 한계: "Most microstructural analyses are limited to domains of tens of micrometers, and nanoscale properties are often treated as effective properties due to computational constraints." · 동적 거동 (균열 · 부피 팽창 · 접촉 손실) 추정 어려움 · 계산 부담 · bottom-up 생성 구조는 실험 검증 필요 | §7.2 (줄 400–411) · §4.3 (줄 260) | 원문 인용 (카드) | 리뷰
- [j] lee2023_sicspe_digitaltwin_assb | 단일 스냅샷 (spring-back · 사이클 없음) · 500 MPa 1조건 1전극 · 균일 구 고정 형상 (소성 · void-fill · 파괴 없음) | §7(c) (줄 357–358) · §10 (줄 428–435) | 카드 기록 | —
- [j] park2020_digitaltwin_assb_foundational | 압력 sweep 없음 (최소 기공 규칙 배치 — Heckel · 다압력 앵커 아님) · 기공 미보고 · τ 값 · 산출법 미보고 · 시뮬 σ_eff 방향 미기술 (6면 Dirichlet 그림뿐) · LPSCl 고유 σ(ε_s) 식 출처 미확인 (자기 실측 맞춤이면 Fig 2b 일치가 일부 순환) | §10(5) (줄 797–813) · §4-T (줄 386–399) | 카드 기록 · [미확인] | —


### [batch_31] j — 카드가 스스로 적은 한계 중 가압 · 탈압 계산과 닿는 것

- [j] boschpadros2014_dem_liggghts_msc_thesis | 바닥 메시 압력 출력 실패: "the pressure shown during the insertion does not follow a reasonable evolution. The values fluctuate ... 0 to three times the expected maximum pressure." · 원인 = 메시 요소 적음 또는 충돌 순간 운동량 급변 + 후처리 이해 부족 | §3 표 (줄 58) · §4.11 (줄 220) · thesis §4.4 · §6 | 표지 없음 (원문 인용) | 충돌 데모 (압밀 아님)
- [j] boschpadros2014_dem_liggghts_msc_thesis | 탄소성 접촉 미구현 ("elasto-plastic … can be obtained" 한 줄) · 데모 전부 가역 Hertz · 이력 (hooke/hysteresis) 도 Fig 2.34 그림만 | §4.2 (줄 82 · 109) · §4.9 (줄 213) · §10 (줄 340) | 표지 없음 | —
- [j] chibwe2020_nnsi_segregation_index | 카드 자신의 판정: NNSI 원식은 우리 300 MPa 압밀 침대에 그대로 못 씀 — 하한 l_min = d 가 겹침 ≈ 0 전제라 겹침 7–11 % 침대에서 SI 가 음수로 샘 · 압밀 프레임에서는 세 상 모두 l̄ → 접촉거리라 동적범위가 바닥 → 쓰려면 침강 종료 (압밀 전) 프레임 · 서술 전용 | 머리 (줄 11–16) · §12-1 · §12-2 (줄 593–619) | [R] (카드 유도) | 우리 침대 실측 전 (§13-4 미실행)
- [j] aminchiang2016_nmc_electronic_ionic_transport_vs_li | 다공도 보정을 σ ∝ 밀도 선형 (96–98 % 에서 ≤ 4 %) 으로 함 — 카드: 검증 안 된 규약 · Bruggeman · tortuosity 관점에서 낙관적 | §4-1 (줄 189–192) · §8 경고 6 (줄 482) | 표지 없음 (카드 서술) | 소결 NMC 펠릿 (SE · 복합 아님)
- [j] 그 밖 (balasubramanian · chandratilleke · cho · choi · egermann) 은 가압 · 탈압과 닿는 한계 진술 없음.


### [batch_32] j — 카드가 스스로 적은 한계 가운데 가압 · 탈압과 닿는 것

- [j] hong2026_cbd_viscoelasticity_springback | 카드 판정: 우리 MPM (rate-independent von Mises J2) 은 시간의존 spring-back 을 구조적으로 못 냄 — `--protocol hold` 이완 = `wall_vel=0` 뒤 `relax >= 40` substep settling (카드가 든 코드 줄 `mpm3d_compaction.py:636-642` · 2026-07-28 시점) · 온도축 · CBD 기계 물성 없음 · "우리 모델로 spring-back 예측" 주장 금지 | §7(c) (줄 405–424) · §6 (줄 343–345) | 카드 판정 | 코드 줄 번호는 카드 작성 시점 (지금 코드와 대조 안 함)
- [j] hong2026_cbd_viscoelasticity_springback | 카드 판정: MPM 은 AM 이 rigid scaffold 라 입자 균열이 없어 AM_P (다결정) · AM_S (단결정) 가 되돌아옴에서 구별 불가 · DEM 균열은 수송 쪽 (broken contact) 뿐 · 단결정 ↔ 다결정 균열 경향 차이 없음 | §7(b) (줄 390–403) | 카드 판정 | —
- [j] huang2025_dem_lbm_heat_conduction_composite_cathode | 저자가 남긴 일: 비구형 입자 = future work · 계면 열저항 (Kapitza) 미포함 = future work · 무손상 (pristine) 만 · DEM 은 구조 생성기 (압력 · Heckel · coverage · 배위수 미산출) · seed 미기재 | §4 (A) (줄 56) · (B) (줄 72 · 78) · §3 (줄 38–39) · §10 (줄 133–141) | stated · 카드 판정 | —
- [j] fuhrer2000_crossed_nanotube_junctions | 카드 판정: R_j,0 는 압밀 (300 MPa 급) 접촉 상태를 묶은 값 — MPM 은 섬유 접촉 역학을 풀지 않으므로 압력 · 밀도 의존 R_j 는 하지 않는다 (권고) · 다른 압력 · 밀도 침대로 옮기지 않는다 | §7 표 (줄 112) · §9 (나) 1 (줄 135) | 카드 판정 | —
- [j] endo2001_vgcf_basic_properties_battery_applications | 압분체 측정의 압력값 · 셀 치수 · 단자 수 · 반복 0 · 탄성률 측정법 0 (카드가 적은 공백) | §11-2 (줄 441–447) · §0 (줄 31–32) | 확인 | —
- [j] grey1969_hausner_ratio_metal_powders | 저자 결론 (4): 탭 밀도 시험의 진동 방법 표준화 필요 · 반복 · 시료 질량 미기재 | §3-8 (줄 157) · §10 (줄 249) | [인쇄] | 압축 아님 (탭)
- [j] ender2011_3d_reconstruction_composite_cathode | 압연은 "현재 연구 중" 주제로만 (미압연 전극) · 접촉 저항을 넣은 FEM 은 다음 일로 남김 (p.168) | §3-1 (줄 57) · 머리 (줄 15) | stated | 수송 쪽


### [batch_33] j — 카드가 적은 한계 중 가압 · 탈압과 닿는 것

- [j] kaiser2018 | springback 미논의 · Type-B · C 측정 하중 미기재 · 두께 ex situ · σ₀ 펠릿 (276 MPa · 30 min · 별도 셀) 과 복합체 (≈392 MPa · 5 min) 압밀 이력이 달라 실험 쪽 기준 상태도 "같은 압밀 이력의 순수 SE" 가 아님 | §0 · §4-4 · §8-1 · §8-2 ② · §10 | stated · [미확인] | —
- [j] jung2019 | EIS 측정 중 압력값 미기재 ("constant pressure") · 갈바노 셀 4 N·m 토크 (MPa 환산 없음) · 무가압 in situ SEM 으로는 압력 해제 효과와 화학 균열을 못 가름 | §3-1 · §10 | stated · 카드 판단 | —
- [j] kim2026 | 성형압 · 양극 공극률 [미확인] · 운전 압력 (20–21.5 MPa) 축이 우리 모델 (300 MPa 성형 → 판 고정 이완) 에 없음 · 카드: 운전 압력에서의 접촉 상태 (이완 뒤 접촉 손실) = 우리 DEM 제하 팔 부재 (F-SB1) 와 같은 빈칸 | §3-1 · §7-1 · §8-5 (카드 줄 251) | [미확인] · 카드 해석 | 압력 측정 = 별도 셀 · Fig. S4 전압 범위 불일치
- [j] lindblad2005 | 압축 침대의 피복 비율 "상쇄" 는 방향 무작위 가정 — 압축축 근처 극 모자 (|n_z| ≥ cos 30°) 에 SE 접촉이 몰리면 면 세기 비율 −9.1 % (손계산 0.909) · 카드: 압축 침대에서 확인 전에는 "상쇄" 라고 쓰지 않는다 · 이진 전제라 3중선 처리 없음 · MPM 변형 뒤 SE–SE 계면은 해석 법선이 없어 국소 추정기가 필요 | §0 (d) · §7-2 · §7-4 · §8 ④ | derived(ours) | 측면 띠 (+ 방향) 크기는 pilot 값뿐 (숫자 안 옮김)
- [j] lawrence2008 | 섬유 파단 모델 없음 — 건식 혼합 · 압연 중 섬유 절단은 우리 축 밖 · 섬유를 단일 E 로 두는 표현은 형태 의존 (같은 배치 35 배) 을 못 담음 | §7 표 (파단 행) · §8 ④ | 카드 판단 · DERIVED | —


### [batch_34] j — 카드가 적은 한계 중 가압 · 탈압 계산과 닿는 것

- [j] luan2025_graded_cathode_400whkg_pouch | COMSOL 은 "압밀/porosity 시뮬 없음 — 300 MPa 성형은 실험에서만 하고 모델은 압밀 후 구조를 가정" · 입자 · 접촉 · 공극 없는 2-region 연속체 · 등방압 ↔ 단축: "같은 MPa 라도 같은 압밀이 아니다" (porosity · 이방 tortuosity · 접촉면적 전이 금지) | §4-3 L347 · §7-A L425 · §10-1 L588–590 · §10-12 L610–612 · §11 L637–638 | stated (카드 판정) | —
- [j] minnmann2022_designing_cathodes_solidstate | 작동 스택압: "Clearly, such high pressures are not suitable for large-scale commercial applications" (수십 MPa) · §5.4 = 미세구조 mechanical 모델을 electrochemical · thermal 모델과 결합해 압력 · 온도 효과를 봐야 한다 (카드 한국어 옮김 · 원문 영어 없음) | §2.2 L159–161 · §5.4 L228–232 | 직접 인용 · 표지 없음 | 권고 문장 · 수치 없음
- [j] nadeem2023_gnn_mixing_index | 논문은 압밀 중 배위수 변화를 고려하지 않음 (믹싱) → 카드: 압밀이 부분 배위수 Z_ij 를 바꾸면 접촉 통계 E_XY 가 혼합과 무관하게 움직인다 (우리 쪽 새 결함 후보 · German 2014 제목 인용) | §7-D L494 · §8-③ L538–546 | 카드 해석 | 혼합지표 (압밀 계산 아님)


### [batch_35] j — 카드가 적은 한계 가운데 가압 · 탈압과 닿는 것

- [j] otani2023 | 모형 가정 셋 (SE ≪ AM · 퍼콜레이션 무시 · 전극 안 분포 무시) · SE 21 % 저공극 = AM 변형 (거시 β > 1.5) 로 어긋남 (재맞춤 없음) · SE 10 % = 퍼콜레이션 붕괴 · 높은 공극에서는 Nyquist 반원이 안 보여 σ 못 얻음 · 흑연은 눌리면 납작해져 거시 β 증가 예상 (시험 안 함) | §3-2 (줄 74) · §3-4 표 (줄 94–95) · §3-5 (줄 109) · p.4–5 | [인쇄] | —
- [j] park2019 | *"Although the reliability is not confirmed by experimental data, we believe that this modeling and simulation approach is quite meaningful"* (p.128) · 압밀 · 기계 없음 (확률 배치 + 열처리 접촉 가정 p.125) | §2 (줄 56) · §4-5 (줄 213–223) | stated | —
- [j] song2025 | 소성 기반 기계 열화만 예측 — 입자 균열 · 집전체 분리 · SEI · Li 도금 · 가스 미반영 (계산비용 + 파괴 모델 부재 · 논문 명시) · 바인더 인장 = 건조 필름 (swelling 미반영 · 논문 명시) · AM 은 취성 탄성 (식 22) | §4.5 (줄 334–335 · 345–346) · §3.2(2) (줄 228–230) | 표지 없음 (논문 명시) | 사이클 하중이지 압밀 · 탈압 아님
- [j] pan2026 | *"most tests presented here were only repeated once or twice"* (p.60) · CT 는 CBD · 하위 복셀 기공을 못 봄 · PNM 편향 균일 주장 검증 없음 · 압축률 정의가 표마다 반대 (줄어든 % ↔ 남은 %) | §3-2-1 (줄 159) · §3-1-2 (줄 82–83) · §10-1-2 (줄 415) | [인쇄] | 액체 LIB
- [j] shenouda2020 | 구만 (multisphere · superquadratic 은 언급만) · Hertz 는 접촉 변형 무시 · 운동에너지가 *"wildly varying"* 이면 불안정 → 입자를 적게 · 천천히 넣거나 강성 낮춤 | §4 (줄 79 · 94) · 줄 264 | stated | 흐름 응용


### [batch_36] j — 카드가 적은 한계 가운데 가압 · 탈압과 닿는 것

- [j] zhang2023 | SI 가 적은 모델 한계 셋: (i) 계산비용 때문에 수십 사이클 모의 불가 (ii) 활물질 입자의 균열 진화를 포착할 수 없음 (iii) CEI 층 (수 nm) 과 계산 체적 (수십 µm) 의 크기 차로 CEI 미세구조 명시 분해 불가.  압연이 만든 균열 · 접촉 손실은 이미징으로 재기만 하고 모델에 없다 (되먹임 없음) · 모델 기하는 pristine 한 건 · 역학 (압밀 · 응력 · 형상 변화) 모델 0 | §0-3 (줄 34) · §4-4 (줄 246–247) · §7 (줄 344 · 354) · ① (줄 374) · §10-B 2–4 (줄 493–495) | stated (카드의 한국어 옮김 — 영어 원문 문장은 카드에 없음) · 카드 판정 | 액체 LIB · 가압 (압연) 자체는 계산하지 않음
- [j] zhang2026 | *"Models that focus mainly on ionic conductivity while neglecting compaction state, interface mechanics, and contact evolution may therefore not fully capture rate performance and cycling behavior"*.  지금 복합전극 모델의 한계 셋 = 미세구조를 실측 재구성 · 미리 정한 구조로만 쓰고 제조 공정과 잇지 않음 · raw-material-to-cell 틀 부재 · 제조 때 만든 퍼콜레이션 경로가 운전 중 변함 (전기화학-기계).  카드: 우리 쪽 "제하 팔 부재 (F-SB1)" 와 같은 공백 지적 | §0 (줄 19) · §3-5 (줄 66) · §8-2 (줄 106) · §9 (줄 109) · p.10 | [인쇄] · [우리 해석] (F-SB1 연결) | 고분자 전해질 계 Perspective · 수치 없음
- [j] windreich2003 | (눌린 구조의 계면 넓이 측정 = 단계 7 과 닿음) 시험은 볼록 형상뿐 — 오목 · 접촉 (두 물체가 닿는 계면) 시험 없음 · 국소 추정기는 multigrid 수렴 없음 (격자를 조여도 편향이 0 으로 가지 않을 수 있음) | §10-4 · 5 (줄 176–177) · p.2535 | stated (저자) · 카드 한계 | 가압 · 탈압 계산 자체와는 무관
- [j] ziegel2010 | (단계 7 과 닿음) 이진 · 단일 집합 — 다중 라벨 · 3중선 · 접촉하는 두 물체의 계면은 다루지 않음 · 부피 문턱 디지털화 (MPM 셀 판정 부류) 의 가중치 값 · 유한 해상도의 최악 오차 분포 미확인 | §4 (줄 98) · §10-5 (줄 176) · §12 (줄 191) | 카드 한계 · n/a | —
- wang2018 · wiedenmann2013: 가압 · 탈압과 닿는 한계 서술 없음 (wang2018 줄 447 "DEM·MPM·접촉역학·미세구조 모델이 하나도 없다" · wiedenmann2013 줄 226 "역학 · 형상 변화 · 압밀 물리는 없다").


### [batch_37] j — 카드가 스스로 적은 한계 (가압 · 탈압과 닿는 것)

- [j] famprikis2019 | 리뷰 문장: *"the relationship between the mechanical properties of solid electrolytes and the performance of the solid-state battery is still poorly understood"* (줄 250) · *"the effective densification … may represent a major challenge when the mechanical properties and the processability … are taken into account"* (줄 203) · 냉간가압 *"its applicability for scale up and hard oxide solid electrolytes is limited"* (줄 310) · *"the fracture toughness greatly depends on the microstructure and will need to be determined experimentally"* (줄 263) · 결론에서 *"reproducible protocols setting standards"* 를 요구 (줄 320) | §5.2(c) · §5.4 · §5.6 · §5.7 | stated (인용문) | 2019 시점 · 정성
- [j] cao2026 | 저자 스스로: MIP 값을 *"apparent Hg-accessible porosity"* 로 명명 (줄 175).  카드 지적: σ 측정 셀 (전극 · 압력 · 두께 실측법) 이 Experimental 에 없음 (줄 96) | §4e · §3b | stated · 카드 지적 | —
- [j] calpa2019 | 저자 한계 진술 없음.  카드 지적: 펠릿 두께 · 밀도 · 복합체 기공 · σ_eff · 셀 구속압 미보고 (§4 줄 141 · §10-4 · 5 · 9) | — | 카드 지적 | —
- cronk2026 (둘째 카드): 새로 없음.


### [batch_38] j — 카드가 스스로 적은 한계 (가압 · 탈압과 닿는 것)

저자 스스로의 한계 진술 가운데 가압 · 탈압과 닿는 것 = 0.  카드가 짚은 빈 곳만:

- [j] tron2023 | 카드 지적: 기공 · 밀도 · 단면 측정이 없어 "치밀화 저해" 는 주장 · 입도 수치 없음 · 첫 사이클 · 셀 1 개 (§10-1 · 4 · 7).  저자 권고는 보고 방식뿐: *"reporting not only the specific capacity with respect to the active material, but rather with respect to the overall composite electrode"* | §10 줄 247–253 · §5.6 줄 176 | 카드 지적 · stated | —
- [j] liu2024 | 카드 지적: 후막 단면 (두께 · 공극) · 복합체 σ 를 재지 않음 · 초후막 셀 조성 · 두께 미기재 (§6 줄 182 · §10-12) | — | 카드 지적 | —
- [j] yuan2026 | 카드 지적: FEM '정규화 시간' · 밀도 · 감쇠 미기재 · 위상장이 σ · E · 기하를 한꺼번에 바꿈 (§10-② · ③) — 저자 진술 아님 | 줄 328–329 | 카드 지적 | 고분자 전해질


### [batch_39] j. 카드가 스스로 적은 한계 가운데 가압 · 탈압 계산과 닿는 것

가압 · 탈압과 닿는 한계는 없음 (카드 §10 의 11 항은 전부 전기화학 · DFT 주장의 한계). 닿을 수 있는 것 하나만:
- [j] choi2026_bzox_dry_zro2x_nmc_shell_coating | 계면 상태를 직접 재지 않음 — space-charge layer 완화는 Fig 1 모식도 주장뿐 (직접 측정 없음) · 산소결핍 x 정량 없음 · σ_e 는 코팅 NMC 펠릿 값 (SE bulk 와 혼용 금지) | §10-8 L172 · §10-9 L173 · §10-10 L174 · §3.5 L69 | 표지 없음 | 눌린 구조의 계면 수송 (단계 7) 에 넣을 계면 저항 값은 주지 않음


### [batch_40] j — 카드가 스스로 적은 한계 (가압 · 탈압과 닿는 것)

- [j] gritton2017_mpm_chemomechanical_coupling_silicon_anode | 계면이 붙어 있어 실험의 바닥 반경 팽창 ∼20 % 가 미끄럼 때문인지 기판 변형 때문인지 가를 수 없다 (*"It is unknown if …"*) | 카드 §0 · §11 #7 · 논문 §4.6 p.17 | 인쇄 | 판이 물러날 때 (탈압) 계면이 열리는지를 한 속도장으로는 물을 수 없다는 것과 같은 부류 ([카드 추론])
- [j] gritton2017_mpm_chemomechanical_coupling_silicon_anode | 밀도 스케일링의 확인은 정성 (*"qualitatively the variations … are small"*) | 카드 §11 #5 · 논문 p.13–14 | 인쇄 | 응력 · 반력의 재하율 민감도는 재지 않음
- [j] gritton2017_mpm_chemomechanical_coupling_silicon_anode | 입자 표면 넓이를 처음 값으로 고정 — *"not a valid assumption"* · 향후 변형 구배로 갱신 | 카드 §11 #1 · 논문 §2.3 p.7 | 인쇄 | 큰 변형에서 표면 · 계면에 걸리는 양 (피복 넓이 등) 에 같은 주의
- [j] gritton2017_mpm_chemomechanical_coupling_silicon_anode | 변형률 속도는 Hencky 변형률 속도의 근사 (주축 회전이 작을 때) | 카드 §11 #4 · §4-5 · 논문 §3.2 p.9 | 인쇄 | 큰 전단 회전이 있는 압밀 유동에서의 오차는 다루지 않음
- [j] gritton2017_mpm_chemomechanical_coupling_silicon_anode | 손잡이 (α · β · p_max) 에 따라 변형 거동이 달라진다 · 파괴 없음 · 전기화학 없음 | 카드 §11 #6 · #9 · #10 · 논문 p.16 · 20 | 인쇄 | 가압 계산과는 간접


### [batch_41] j — 카드가 스스로 적은 한계 (가압 · 탈압과 닿는 것)

- [j] bardenhagen2005_mpm_foam_densification_simulation | 탄성 재료 · 붙는 접촉뿐: *"Effects due to including more realistic models, such as viscoelasticity for polymeric foams, plasticity for metallic foams, and frictional sliding contact, will be studied later."* | 카드 §11 #1 · 논문 p.601 | 인쇄 | 소성 · 미끄럼 · 분리가 드는 가압 · 탈압 계산의 근거가 못 됨
- [j] bardenhagen2005_mpm_foam_densification_simulation | 준정적을 명시적 풀이로 흉내 (*"less elegant"*) · 암시적 풀이는 *"expensive, and remain an area of algorithm research"* | 카드 §11 #4 · 논문 p.602 | 인쇄 | 판정은 절반 속도 런과의 눈 대조
- [j] bardenhagen2005_mpm_foam_densification_simulation | 반력의 잡음은 작은 단위 셀의 산물 (*"divided by a larger measurement area"*) · 불안정 (snap-through) 구간은 관성이 지배할 수 있음 | 카드 §11 #5 · #7 · 논문 p.606 · p.612 | 인쇄 | 작은 RVE 의 판 반력을 읽을 때 같은 주의
- [j] bardenhagen2005_mpm_foam_densification_simulation | 단위 셀이 대표 부피가 아님 · '두 배 규칙' 은 두 사례 (*"not conclusive"*) · 직렬 계산 | 카드 §11 #2 · #8 · #10 · 논문 p.610 · p.612 · p.614–615 | 인쇄 | —
- [j] bardenhagen2005_mpm_foam_densification_simulation | 물질점이 셀 경계를 넘을 때의 오차 (큰 변형률의 반력 튐) | 카드 §11 #6 · 논문 p.603 | 인쇄 | 조밀 끝의 반력 판독에 잡음


### [batch_42] j — 카드가 스스로 적은 한계 (가압 · 탈압과 닿는 것)

- [j] pycompact2025_dem_mpfem_workflow | **새로 더함 — 넘김에서 원문에 없는 것 9**: 넘긴 순간 충전율 · 층 높이 · 겹침 · 침강 정지 판정 / 겹친 구 · 틈 처리 / 재평형 · 초기 응력 · FE 중력 / 펀치 속도 · 시간 간격 · 질량 스케일링 · 감쇠 · 준정적 판정 / DEM 재료 값 / 메시 매개변수 값 / 1400–1800 MPa 점 얻은 방법 / 압력 면적 정의 · 충격량 미분 평활 / 저장소 구성 (원문은 파일 이름만) | 카드 §4.7 끝 [미확인] 목록 | [미확인] | —
- [j] pycompact2025_dem_mpfem_workflow | **새로 더한 원문 내부 불일치**: Fig 3e 2500 점 ≈1379 ↔ 본문 1310 MPa · 9 h 가 두 곳 (Table 1 Fine RVE 210 ↔ p.6 Coarse 2000 요소) 인데 Table 3 의 Coarse 2000 요소는 7 h (24 CPU) · Fig 4(a) 캡션 'Coarse' 만 ↔ 그림 두 곡선 · Table 2 의 ABAQUS 칸 Solver · Friction 빈칸 · '모든 계산 2000 MPa' ↔ 그림 다섯 압력 | 카드 §18 항목 10–13 · §9.1 | 인쇄 · [판독] | —
- [j] pycompact2025_dem_mpfem_workflow | **철회한 카드 판정**: Fig 3e '−5 % 미수렴' · '제하 후 RD 삼각형 5–7 %p' · 'Fine 이 더 성기게 쌓였다' (압력이 뜨는 점 42.8 vs 42.4 % = 판독 오차 안 · 61 % 는 펀치 접촉 전 구간) · 'Fig 4a 제하부 계단' (그림에 없음) · 569 입자 9 h 에 붙인 '24 CPU' (Table 1 에 CPU 수 없음) | 카드 §8 · §9.1 · §10 · §11 · §14 · §18 | — | —


### [layer3] j. 문헌이 스스로 적은 한계 가운데 가압 · 탈압 계산과 닿는 것

- [j] giannis2021_stress_based_multicontact_dem | 저자 outlook 이 "elasto-plastic behaviour at high stress levels" 를 향후 과제로 명시 · 유리도 "brittle 이라 elastic part 만" 봄 → 300 MPa 영역은 이 모델 검증 밖 | §A L378–382 | 원문 인용 | 
- [j] varkey2026_multicontact_elastoplastic_dem | < 20 % porosity 는 "추구 안 함" — 비교 문서: 물리 floor 가 아니라 계산비용 | §A L332 · L356 | 표지 없음 | 
- [j] xu2023_realistic_am_shape_cgmd_calendering | 압연 압력을 "various applied pressures" 라고만 적음 (같은 압연기 · 같은 힘센서로 잴 수 있었는데 안 함) → floor 판정 · Heckel 대조 불가 | §A L119–134 | 표지 없음 | 액체 LIB
- [j] duquesnoy2020_calendering_ml_mesostructure_generator | 생성기에 압밀 기전이 없음 (porosity 가 입력 · RSA · 겹침 β = 0.7 허용 · 최대반복 · 타임아웃 없음) — 회귀식 밖으로 못 나감 | §A L276–283 · L296–299 | 표지 없음 (코드 판독) | LIB
- [j] famprikis2019_fundamentals_inorganic_sse | 냉간가압은 랩 표준이나 스케일업 · 경질 산화물엔 제한적 (ref 118 Schnell) · K_Ic 는 "미세구조 의존 → 실험으로만 결정" | §A L308 · L326 | 표지 없음 | 리뷰
- [j] zhang2023_pfib_multiscale_imaging_4d_thick_cathode | 압연압 미보고 · n = 1 · error bar 없음 · 15 사이클 — 그들에게 압밀 모델 자체가 없음 | §A L490–495 | 표지 없음 | 액체 LIB
- [j] luan2025_graded_cathode_400whkg_pouch | porosity · 전극밀도 · 두께가 논문 어디에도 없음 (SI Fig S6b 미보유) | §A L472–474 | 표지 없음 | 
- [j] fan2026_sulfide_assb_stability_review_ECERD2600097 (비교 문서는 `papers/li2026_sulfide_stability_review_ecer.md` 로 적음 — 그 이름의 카드는 papers/ 에 없음) | 리뷰의 미래방향 ③ "저압 / 무가압 설계" — 비교 문서: 300 MPa 압밀 구조의 저압 unload 접촉 / σ 유지율 계산이 그 요구 · 과압 → tortuosity↑ · 이방 접촉구조 ([151] Sakka JMCA 2022) | §A L456–464 | 표지 없음 | 2 차 출처 · 자체 데이터 0 · porosity 절대값 없음
- [j] zunker2024_bulk_elastic_partII | 저자가 "원거리 (far-field) 응력 결합 미고려" 를 Fig 5c 불일치의 원인으로 명시하고 향후과제로 남김 | §A L733–736 | 카드 서술 인용 (영어 원문 없음) | MCC
- [j] zunker2025_dem_large_deformation_compaction | 2 상 (두 재료) 불가 = "그들 미해결 제약" · 파쇄 없음 · porosity 검증 없음 | §A L662–665 · L674 | 표지 없음 | 
- [j] gonzalez2012_nonlocal_contact_confined_granular | 적용 한계를 초록 · §1 · §5 에서 3 회 명시: "elastic spheres in the absence of gravitational forces, adhesion or friction" · §5 가 탄소성 · 유한변형 · bonding 을 미래 과제로 명시 | §A L716–719 | 원문 인용 | 
- [j] vanlew2015_modifying_youngs_modulus_distribution | 침대가 어떤 실험과도 대조되지 않음 — 논문 자인 "A pebble bed geometry more directly comparable to oedometric compression experiments should be used to allow direct comparison and validation" | §A L626–628 | 원문 인용 | 
- [j] paulick2015_elastic_particle_properties_dem_review | 강성을 낮춰 벌크를 맞춘 사례 논문 0 편 · 리뷰 최대 응력 ≈ 96 kPa (300 MPa 의 1/3,125) | §A L782 · L801 | 표지 없음 | 
- [j] zhang2026_xct_dem_cathode_calendering_peel_calibration | 검증이 제하 후 공극률 4 점뿐이고 보정 표적과 분리되지 않음 (카드 §10 L4) | §A L896 | 표지 없음 | 
- [j] schmitt2026_chemomech_stability_dry_cathode_separator_sheets | 기공 · 밀도 · 두께 측정을 "has not yet been performed" | §A L933 | 원문 인용 | 
- [j] cronk2026_lis_positive_electrode_geometry_fem | 모델에 압력 변수 없음 · FEM 은 "fully compact (no porosity)" 가정 · 조건당 3 침대인데 산포 0 건 · RVA 실행 흔적 없음 | §A L808–829 | 원문 인용 · derived(ours) | 
- [j] varkey2026_multicontact_elastoplastic_dem | "구 = 타협 · 현실 형상 = 향후 과제" 명시 (입자는 완벽 구 · elasto-plastic 은 접촉 힘법칙만) | §C L2115–2116 | 카드 서술 | 
- [j] alabdali2023_cgmd_wet_manufacturing_ssb_cathode | 저자: "… which is a limitation shown by the model" · 모델은 압연도 ~35 % 까지만 쓸 만함 | §C L2436–2439 | 원문 인용 | 
- [j] zunker2024_bulk_elastic_partII | 고구속에서 R 성장이 붕괴해 동결 (Part II §4.3.3) · 모델은 항상 볼록 | §C L2144–2146 | 표지 없음 | 
- [j] demirtas2021_mpfem_hollow_sphere_die_compaction | 실험 대조는 정성 ("by no means … statistical analysis") · 실험 d/w 20 은 시뮬 범위 2.5–12.5 밖 · 모델당 1 실현 · 점착 없어 배출 미계산 · 재하율이 팔마다 다름 (펀치 속도 ≈ 2.87 배 차 · derived) | §C L2529–2551 | 원문 인용 · derived | 
- [j] pycompact2025_dem_mpfem_workflow | 전달물성을 한 번도 계산하지 않음 · "convergence" 가 수렴 아님 (런타임으로 선택) | §C L2476 · L2486–2488 | derived(ours) | 
- [j] nezamabadi2022_mpm_cd_plastic_particle_compaction + nguyen2017_mpm_bpm_deformable_particle_compaction + bardenhagen2001_mpm_improved_contact_granular_stress_waves | (묶음 · 탈압과 닿는 한계) Nezamabadi: 2D · 마찰 0 · 제하 결과는 이 줄에 없음 / Nguyen: Φ(ε) 는 방법을 못 가름 (질량 보존 산술) / Bardenhagen01: 이종 · 소성 계면에서 분리 시점이 어긋날 수 있음 (원문 경고) · 접촉 노드당 물체 ≤ 2 | §C L2687–2727 | 표지 없음 | 
- [j] cronk2026_lis_positive_electrode_geometry_fem | 항복 · 경화 · 소성 유동 · 파괴 · 접촉 없음 — 그런데 관측은 소성 (본문) | §C L2557–2564 | 원문 인용 | 
- [j] benhadjali2026_wip_vs_cup_pressing_assb_cathode_dem | 제조 잔류 응력 미전달 (기하만) · "WIP ↔ CUP 차 작다" = 색 지도 한 장의 시각 판정 | §C L2669 | 표지 없음 | 
- [j] schmitt2026_chemomech_stability_dry_cathode_separator_sheets | 기계 근거는 간접 (단면 SEM · 펠릿 사이클 뒤 SEM 없음 · 저자 인정 p.11) | §C L2668 | 원문 인용 | 
- [j] bielefeld2019_microstructural_modeling_composite_cathode | bi / tri-modal PSD 는 "향후 과제" 로 명시 보류 · σ 를 풀지 않음 · 구조는 랜덤 배치 | §D L2743–2745 · §E L2808–2810 | 카드 서술 | 
- [j] minnmann2022_designing_cathodes_solidstate | 리뷰 §5.4 가 "미세구조 mechanical model 을 echem · thermal 과 결합 + CAM 을 다른 형상 · 크기 · 탄성으로 재고" 를 명시 요구 | §E L2828–2831 | 카드 서술 (영어 원문 없음) | 
- [j] luan2025_graded_cathode_400whkg_pouch | 이온 / 전자 flux 비대칭을 개념으로만 제시 (정량 없음 · 모식도) | §E L2833–2836 | 표지 없음 | 
- [j] zunker2025_dem_large_deformation_compaction | 2 상을 "varying material properties as future work" 로 명시 (2025 §2.2) · porosity 수치 0 · 프로토콜 하나 (0 → 0.4 → 0) · 검증 반경비 0.25 까지 | §F L3752–3758 | 원문 인용 | 
- [j] paulick2015_elastic_particle_properties_dem_review | 리뷰가 미해결로 지목: "only little research on the influence of contact stiffness on bulk behaviour of powders has been conducted. Due to high computational efforts in case of numerically describing fine powders, also the influence of contact stiffness during particle upscaling should be investigated." (§4 p.75) | §F L3477–3480 | 원문 인용 | 
- [j] coetzee2017_dem_calibration_review | 구 + rolling friction 없음: Coetzee [62] (p.113) "Spherical particles without rolling friction … could not be calibrated … even when high particle friction coefficients were used." · Santos [170] (p.125) 구형 입자 보정값은 "cannot be generalised" | §F L3392–3397 | 원문 인용 | 
- [j] demirtas2021_mpfem_hollow_sphere_die_compaction | "연화가 불필요하다" 를 검정하지 않음 (E/σ_y = 100 한 값 · 연화 연속체와 비교 없음) · 입자 수 < 2000 ("< 60 h") · 리메싱 진단 없음 | §F L3784–3787 · L3800–3802 | 표지 없음 | 
- [j] galvezaranda2024_time_dependent_dl_calendering_microstructure + galvezaranda2025_paml_vgg16_dem_slurry_drying + vijay2025_hybrid_cgmd_dl_slurry_microstructure | (묶음) 이 사슬 3 편 어느 것도 MPa 를 들지 않음 · springback 숫자 0 건 · DEM 물성 0 줄 · 실험 신규 0 건 · seed / 오차막대 0 | §F L3049–3052 · L3121–3129 | 표지 없음 | 액체 LIB
- [j] sankar2026_fiber_scale_dem_carbon_felt_manufacturing | 실험 검증 0 · SI 미첨부 · 코드 비공개 · 압력 출력 0 | §F L3915–3917 | 표지 없음 | 
- [j] benhadjali2026_wip_vs_cup_pressing_assb_cathode_dem | 그들 DEM 도 등방 압축을 못 함 (x · y 주기 + z 변위뿐) · 온도 의존 물성 없음 | §F L3970 | 표지 없음 | 



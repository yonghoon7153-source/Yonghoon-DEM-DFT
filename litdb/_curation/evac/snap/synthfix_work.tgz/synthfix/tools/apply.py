#!/usr/bin/env python3
"""고침 명세 (파이썬 파일 · EDITS 목록) 를 종합 문서에 적용한다.

  apply.py <명세.py> [--dry]

명세의 한 항목 (dict):
  doc    문서 접두 (S1 · S2 · … · S6_3)
  v      검증 파일 이름 (V_S1 …)
  num    검증 문제 번호 (문자열)
  item   항목 번호 (A-48 · 요지 2 …)
  kind   종류 (검증 표의 종류 칸)
  old    바꾸기 전 글 (문서에 정확히 count 번 있어야 한다 · 기본 1)
  new    바꾼 글
  count  기대 횟수 (기본 1)
  line   (선택) 이 정규식에 맞는 줄 안에서만 바꾼다 (그 줄이 정확히 하나여야 한다)
  note   까닭 · 메모
  status 'applied' (기본) | 'held' (보류 — old/new 없이 note 만)

모든 항목이 맞을 때만 쓴다 (하나라도 어긋나면 아무것도 쓰지 않는다).
적용 기록은 <synthfix>/applied_log.jsonl 에 덧붙인다 (같은 명세를 두 번 적용하지 않게 명세 이름을 적어 둔다).
"""
import glob
import importlib.util
import json
import os
import re
import sys

OUT = '/tmp/claude-0/-home-user-Yonghoon-DEM-DFT/d26d1e75-209f-540f-83a8-c0e1957edc2f/scratchpad/handoff_litread_20261112/litread/synth/out'
FIX = '/tmp/claude-0/-home-user-Yonghoon-DEM-DFT/d26d1e75-209f-540f-83a8-c0e1957edc2f/scratchpad/synthfix'
LOG = os.path.join(FIX, 'applied_log.jsonl')


def path_of(prefix):
    c = sorted(glob.glob(os.path.join(OUT, prefix + '_*.md')))
    if len(c) != 1:
        raise SystemExit('문서 못 찾음: %s %s' % (prefix, c))
    return c[0]


def main():
    spec_path = sys.argv[1]
    dry = '--dry' in sys.argv[2:]
    name = os.path.basename(spec_path)
    if os.path.exists(LOG) and not dry:
        for l in open(LOG, encoding='utf-8'):
            if l.strip() and json.loads(l).get('spec') == name:
                raise SystemExit('이미 적용한 명세: ' + name)
    sp = importlib.util.spec_from_file_location('spec', spec_path)
    mod = importlib.util.module_from_spec(sp)
    sp.loader.exec_module(mod)
    edits = mod.EDITS
    texts = {}
    bad = 0
    recs = []
    for k, e in enumerate(edits):
        st = e.get('status', 'applied')
        rec = dict(spec=name, idx=k, doc=e['doc'], v=e['v'], num=str(e['num']), item=e['item'],
                   kind=e['kind'], status=st, note=e.get('note', ''),
                   old=e.get('old', ''), new=e.get('new', ''))
        if st == 'held':
            recs.append(rec)
            continue
        doc = e['doc']
        if doc not in texts:
            texts[doc] = open(path_of(doc), encoding='utf-8').read()
        t = texts[doc]
        old, new = e['old'], e['new']
        want = e.get('count', 1)
        if '\n' in old or '\n' in new:
            if not e.get('multiline'):
                print('✗ [%d] %s %s#%s %s — 줄바꿈이 든 글 (multiline 표지 없음)' % (k, doc, e['v'], e['num'], e['item']))
                bad += 1
                continue
        if e.get('line'):
            rx = re.compile(e['line'])
            lines = t.split('\n')
            hit = [i for i, l in enumerate(lines) if rx.search(l)]
            if len(hit) != 1:
                print('✗ [%d] %s %s#%s %s — line 정규식에 맞는 줄 %d (기대 1)' % (k, doc, e['v'], e['num'], e['item'], len(hit)))
                bad += 1
                continue
            got = lines[hit[0]].count(old)
            if got != want:
                print('✗ [%d] %s %s#%s %s — 그 줄 안 old %d 번 (기대 %d)' % (k, doc, e['v'], e['num'], e['item'], got, want))
                bad += 1
                continue
            before_cells = len(re.split(r'(?<!\\)\|', lines[hit[0]]))
            lines[hit[0]] = lines[hit[0]].replace(old, new)
            after_cells = len(re.split(r'(?<!\\)\|', lines[hit[0]]))
            if before_cells != after_cells and not e.get('cells_change'):
                print('✗ [%d] %s %s#%s %s — 칸 수 바뀜 %d → %d' % (k, doc, e['v'], e['num'], e['item'], before_cells, after_cells))
                bad += 1
                continue
            rec['lineno'] = hit[0] + 1
            texts[doc] = '\n'.join(lines)
        else:
            got = t.count(old)
            if got != want:
                print('✗ [%d] %s %s#%s %s — old %d 번 (기대 %d): %s' % (k, doc, e['v'], e['num'], e['item'], got, want, old[:70]))
                bad += 1
                continue
            if not e.get('cells_change') and (len(re.split(r'(?<!\\)\|', old)) != len(re.split(r'(?<!\\)\|', new))):
                print('✗ [%d] %s %s#%s %s — old/new 의 칸 구분 수가 다름' % (k, doc, e['v'], e['num'], e['item']))
                bad += 1
                continue
            pos = t.find(old)
            rec['lineno'] = t.count('\n', 0, pos) + 1
            texts[doc] = t.replace(old, new)
        recs.append(rec)
        print('✓ [%d] %s %s#%s %s (L%s)' % (k, doc, e['v'], e['num'], e['item'], rec.get('lineno')))
    if bad:
        raise SystemExit('어긋난 항목 %d — 아무것도 쓰지 않음' % bad)
    if dry:
        print('(dry — 쓰지 않음) 항목 %d' % len(recs))
        return
    for doc, t in texts.items():
        open(path_of(doc), 'w', encoding='utf-8').write(t)
    with open(LOG, 'a', encoding='utf-8') as f:
        for r in recs:
            f.write(json.dumps(r, ensure_ascii=False) + '\n')
    print('적용 %d (보류 %d) · 문서 %s' % (sum(1 for r in recs if r['status'] == 'applied'),
                                    sum(1 for r in recs if r['status'] == 'held'), ' '.join(sorted(texts))))


if __name__ == '__main__':
    main()

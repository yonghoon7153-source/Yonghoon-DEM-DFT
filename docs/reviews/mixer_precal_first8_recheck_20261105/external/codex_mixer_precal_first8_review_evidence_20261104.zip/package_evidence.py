import pathlib,hashlib,zipfile,json,shutil
R=pathlib.Path(__file__).resolve().parent
(R/'input').mkdir(exist_ok=True)
src=pathlib.Path(r'C:/Users/Administrator/Downloads/codex_mixer_precal_first8_20261104_189930cc68b6.zip')
dest=R/'input'/src.name
if src.exists() and not dest.exists(): shutil.copyfile(src,dest)
excluded={'scratch','__pycache__'}
files=[p for p in R.rglob('*') if p.is_file() and not any(x in excluded for x in p.relative_to(R).parts) and p.name!='EVIDENCE_SHA256SUMS']
files.sort(key=lambda p:p.relative_to(R).as_posix())
manifest=''.join(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+p.relative_to(R).as_posix()+'\n' for p in files)
(R/'EVIDENCE_SHA256SUMS').write_text(manifest,encoding='utf8')
out=R.parent/'codex_mixer_precal_first8_review_evidence_20261104.zip'
with zipfile.ZipFile(out,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for p in files+[R/'EVIDENCE_SHA256SUMS']:z.write(p,p.relative_to(R).as_posix())
with zipfile.ZipFile(out) as z:
    assert z.testzip() is None
    for line in z.read('EVIDENCE_SHA256SUMS').decode().splitlines():
        h,n=line.split('  ',1);assert hashlib.sha256(z.read(n)).hexdigest()==h
print(json.dumps({'path':str(out),'bytes':out.stat().st_size,'sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'checksum_entries':len(files)},indent=2))

"""Mutation check for the Q5 log-contract guards (scratch copy only; repository untouched).
Each mutation disables or widens exactly one guard of the fixed observer; the observer test
file must then fail at least once.  Usage: python3 -I -B mutate.py <tree> <workdir>"""
import json, re, shutil, subprocess, sys, os
from pathlib import Path
tree, work = Path(sys.argv[1]), Path(sys.argv[2])
root = work/'mut_root'
if root.exists(): shutil.rmtree(root)
(root/'scripts').mkdir(parents=True)
mods = ['mixer_precal_observe','mixer_precal_prepare','mixer_contact_reader','measure_mixing_index','measure_bed_aspect',
        'make_mixer_deck','mixer_deck_readback','mixer_deck_diff','make_mixer_resume','test_mixer_precal_observe']
for m in mods: shutil.copyfile(tree/'scripts'/(m+'.py'), root/'scripts'/(m+'.py'))
pa = Path('docs/reviews/mixer_first8_launch_preparation_20261106/planned_assets')
for case in ('PRECAL_E0', 'PRECAL_N0'):
    (root/pa/case).mkdir(parents=True); shutil.copyfile(tree/pa/case/'in.mixer', root/pa/case/'in.mixer')
src = (tree/'scripts'/'mixer_precal_observe.py').read_text(encoding='utf-8')
M = [
 ('G01 ERROR echo budget off', "_need(echoes[key] <= facts['comment_lines'].get(key, 0), 'error/resume log is not fresh completion evidence')", "_need(True, 'x')"),
 ('G01b ERROR echo budget = membership only', "echoes[key] <= facts['comment_lines'].get(key, 0)", "key in facts['comment_lines']"),
 ('G01c ERROR line-start prefix rule removed', r"_ERROR_LINE = re.compile(r'\bERROR\b|^[ \t]*ERROR')", r"_ERROR_LINE = re.compile(r'\bERROR\b')"),
 ('G01d ERROR echo key ignores indentation', "key = line.rstrip()", "key = line.strip()"),
 ('G02 RESUME/read_restart off', r"_need(not re.search(r'RESUME_STEP|^\s*read_restart\b', text, re.M), 'error/resume log is not fresh completion evidence')", "_need(True, 'x')"),
 ('G03 header inside open table allowed', "_need(not active, 'thermo header inside an unfinished table')", "_need(True, 'x')"),
 ('G04 malformed Loop ignored (old behaviour)', "_need(loop is not None, 'malformed Loop line')", "if loop is None: continue"),
 ('G04b Loop finish stamp optional', ("atoms, '\n                        r'finish time", "[0-9]{4}[ \\t]*')\n_INSERT_REPORT"), ("atoms(?:, '\n                        r'finish time", "[0-9]{4})?[ \\t]*')\n_INSERT_REPORT")),
 ('G05 Loop without qualified table', "_need(active and last is not None, 'Loop lacks a qualified thermo table')", "_need(True, 'x')"),
 ('G06 report pending at Loop', "_need(report is None and expect is None, 'insertion report without its thermo row')", "_need(True, 'x')"),
 ('G07 cumulative endpoint off', "and last == sum(runs[:len(loops)]), 'Loop/thermo cumulative run endpoint mismatch')", "or True, 'x')"),
 ('G08 Loop atoms off', "_need(int(loop.group(3)) == atoms, 'Loop atom count differs from the last thermo row')", "_need(True, 'x')"),
 ('G09 non-ASCII table line allowed', "_need(line.isascii(), 'non-ASCII line inside thermo table')", "_need(True, 'x')"),
 ('G10 blank = any whitespace', "if not active or not line.strip(' \\t'):", "if not active or not line.strip():"),
 ('G11 report total line unchecked', ("_need(total is not None and int(total.group(1)) == report['inserted']\n                  and total.group(2) == report['mass'], 'incomplete or inconsistent insertion report')",), ("_need(True, 'x')",)),
 ('G12 report fix declared/once/run off', ("_need(facts['insert_fix_run'].get(fix) == len(loops) and all(r['fix'] != fix for r in reports),\n                  'insertion report of an undeclared, repeated or misplaced insert/pack fix')",), ("_need(True, 'x')",)),
 ('G13 report position off', "_need(rows == 1 and expect is None and step == last+1, 'insertion report is not at the first step of its run')", "_need(True, 'x')"),
 ('G14 report values off', "_need(n > 0 and _positive_value(info.group(3)), 'invalid insertion report values')", "_need(True, 'x')"),
 ('G15 thermo value regex off', "_need(row is not None and all(_THERMO_VALUE.fullmatch(x) for x in row.groups()[2:]),", "_need(row is not None,"),
 ('G16 nonfinite off', "_need(all(math.isfinite(float(x)) for x in row.groups()), 'nonfinite thermo row')", "_need(True, 'x')"),
 ('G17 row after report unchecked', "_need(step >= expect[0] and count == expect[1], 'thermo atom count after insertion report differs from the report')", "_need(True, 'x')"),
 ('G18 atom decrease allowed', "_need(atoms is None or count >= atoms, 'thermo atom count decreased (lost particles)')", "_need(True, 'x')"),
 ('G19 four-run completion off', "_need(loops == runs and not active, 'log fresh four-run completion mismatch')", "_need(True, 'x')"),
 ('G20 report presence off', ("_need(sorted(r['fix'] for r in reports) == sorted(facts['insert_fix_run']),\n          'declared insert/pack fix without its insertion report')",), ("_need(True, 'x')",)),
 ('G21 header also accepts c_rke', "Step[ \\t]+Atoms[ \\t]+KinEng[ \\t]+rke", "Step[ \\t]+Atoms[ \\t]+KinEng[ \\t]+(?:c_)?rke"),
]
results = []
for name, old, new in M:
    olds = old if isinstance(old, tuple) else (old,); news = new if isinstance(new, tuple) else (new,)
    text = src
    for o, n in zip(olds, news):
        assert text.count(o) == 1, (name, o, text.count(o))
        text = text.replace(o, n)
    (root/'scripts'/'mixer_precal_observe.py').write_text(text, encoding='utf-8')
    env = dict(os.environ, PYTHONDONTWRITEBYTECODE='1')
    p = subprocess.run([sys.executable, '-B', 'scripts/test_mixer_precal_observe.py'], cwd=root, env=env,
                       capture_output=True, text=True, timeout=600)
    out = p.stderr
    ran = re.search(r'^Ran (\d+) tests', out, re.M)
    fails = re.findall(r'^(FAIL|ERROR): (test_\w+) \(.*?\)(?: \[(.*?)\])?', out, re.M)
    results.append(dict(mutation=name, returncode=p.returncode, ran=int(ran.group(1)) if ran else None,
                        failing=[f'{k}:{t}' + (f'[{s}]' if s else '') for k, t, s in fails]))
    print(f'{name:45s} rc={p.returncode} failing={len(fails)} ' + ', '.join(f'{t}[{s}]' if s else t for _, t, s in fails[:4]))
(root/'scripts'/'mixer_precal_observe.py').write_text(src, encoding='utf-8')
p = subprocess.run([sys.executable, '-B', 'scripts/test_mixer_precal_observe.py'], cwd=root, env=dict(os.environ, PYTHONDONTWRITEBYTECODE='1'), capture_output=True, text=True, timeout=600)
print('unmutated control rc', p.returncode, re.search(r'^Ran \d+ tests', p.stderr, re.M).group(0))
json.dump(dict(control_rc=p.returncode, mutations=results), open(work/'mutation_results.json', 'w'), indent=1, ensure_ascii=False)
survivors = [r['mutation'] for r in results if r['returncode'] == 0]
print('survivors:', survivors)
shutil.rmtree(root)

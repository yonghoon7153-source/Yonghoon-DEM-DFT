"""README v2.1 자리표 채우기 — argv: <README> <evG2a 폴더>.  값 = 원 출력에서 읽는다 (손으로 옮기지 않음)."""
import re, sys
p, O = sys.argv[1:3]
s = open(p, encoding='utf-8').read()
def rd(n): return open(f'{O}/{n}', encoding='utf-8').read()
e1 = rd('e1_test_rint_r_chain_full.txt')
m = re.search(r'^test_rint_r_chain: (\d+)/(\d+) PASS \(([\d.]+) s\)(.*)$', e1, re.M); assert m, 'e1 요약 없음'
assert re.search(r'^rc=0$', e1, re.M) and m.group(1) == m.group(2), ('e1 실패 — 손으로 본다', m.group(0))
E1 = f'{m.group(1)}/{m.group(2)} PASS · {float(m.group(3)):.1f} s (둘째 판 · 첫 판 = 504/506 · RR4A · RR4B = sparse 밖 시험 고정물 폴더 `docs/reviews/codex_rint2_rr_round4_evidence_20261109/` 의 FileNotFoundError · 폴더를 sparse 에 더한 뒤 둘 = 2/2)'
def cnt(n, pat):
    t = rd(n); mm = re.search(pat, t, re.M); assert mm, (n, pat); return mm
pr = cnt('e14_probe6_read.txt', r'^(\d+) PASS · (\d+) FAIL \(([\d.]+) s\)')
assert pr.group(2) == '0' and re.search(r'^rc=0$', rd('e14_probe6_read.txt'), re.M)
z3 = cnt('e14_ca_ext_z3.txt', r'^test_ca_ext_z3: (\d+) PASS · (\d+) FAIL \(([\d.]+) s\)'); assert z3.group(2) == '0'
cs = cnt('e14_ca_s0_census.txt', r'^(\d+) PASS · (\d+) FAIL'); assert cs.group(2) == '0'
d7 = rd('e7_check_method_discipline.txt'); assert '0 오류 (17 경고)' in d7 and re.search(r'^rc=0$', d7, re.M)
t7 = re.search(r'^real\s+(\d+)m([\d.]+)s', d7, re.M); T7 = f'{int(t7.group(1)) * 60 + float(t7.group(2)):.1f} s'
d9 = rd('e9_check_doc_refs_G2a.txt'); n9 = re.search(r'문서 ([\d]+)개 · 커밋 (\d+)개', d9); assert '깨진 참조 없음' in d9 and re.search(r'^rc=0$', d9, re.M)
E9 = f'rc 0 · 없는 경로 0 · 없는 커밋 0 (G″a · 문서 {int(n9.group(1)):,} · 커밋 {int(n9.group(2)):,} · G″ 다시 = 같은 판정 · 자기 출력 = scratch `evidence/raw/G2b_check_doc_refs.txt`)'
d6 = rd('e6_ban_new_text.txt'); b6 = re.search(r'바뀐 파일 (\d+) · 그 가운데 게이트 스윕 글롭 안 (\d+) · 등록부 (\d+) 패턴\) → 문제 (\d+)', d6); a6 = re.search(r'더한 줄 \(.*?\) (\d+) 줄 · 등록부 글자 \(면제 없이\) (\d+) 건', d6)
assert b6.group(4) == '0' and a6.group(2) == '0'
E6 = f'바뀐 파일 {b6.group(1)} (게이트 스윕 글롭 안 {b6.group(2)}) · 등록부 {b6.group(3)} 패턴 · 문제 0 · 더한 줄 {int(a6.group(1)):,} 줄 (G″a) · 등록부 글자 (면제 없이) 0 건 · 최종 등록부 = stoic 바이트 (G″ 다시 = scratch `evidence/raw/G2b_ban_new_text.txt`)'
d10 = rd('e10_seal_files.txt'); b10 = re.search(r'바뀐 파일 (\d+) \(A 새 (\d+) · M 고침 (\d+) · D 지움 (\d+)\)', d10); assert b10 and re.search(r'^rc=0$', d10, re.M)
E10 = f'바뀐 파일 {b10.group(1)} = 새 {b10.group(2)} · 고침 {b10.group(3)} · 지움 {b10.group(4)} · 봉인 기록 폴더 36 (G′ 와 같음) · 다섯 경로 diff rc 0 · CODE_FILES 20 · S0 일곱 안 0 · 규율 검사 입력 안 = `docs/reviews/claims.json` 하나'
d12 = rd('e12_stoic_refs.txt'); t12 = re.search(r'(\d{4}-\d\d-\d\dT\d\d:\d\dZ) 측정', d12).group(1)
assert d12.count('\n있음  ') + d12.startswith('있음') == 8 and '없음  ' not in d12
E12 = f'8/8 있음 · b3481336c · b80f10d08 · c0c3b1ff5 = 원격 stoic 안 (v2 때 0 개) · 5a04acd15 = 원격 가지 2 개 · stoic-next 끝 5645b86c8 = 0 개 (로컬) · 2da71fe5a = 5 개 · {t12} 측정'
vals = {'@@E1@@': E1, '@@E14P@@': f'{pr.group(1)} PASS · 0 FAIL ({pr.group(3)} s)', '@@E14Z@@': f'{z3.group(1)} PASS · 0 FAIL ({z3.group(3)} s)',
        '@@E14C@@': f'{cs.group(1)} PASS · 0 FAIL', '@@E7S@@': T7, '@@E9@@': E9, '@@E6@@': E6, '@@E10@@': E10, '@@E12@@': E12, '@@REFN@@': '154',
        '@@G2A@@': open(f'{O}/../G2a.sha').read().strip()[:12],
        '@@G2@@': '(이 README 가 든 커밋 · sha = 이 커밋 밖 기록 = 후보 폴더 `CHANGES_v2_to_v2_1.md` · 묶음 `seal_form_G2_20261117.bundle` 의 가지 끝)',
        '@@G2DIFF@@': '고침 17 = README 1 + `evidence/` 결과 파일 16 · 새 · 지움 0 (G″ 만든 뒤 다시 잼 = scratch `evidence/raw/G2b_diff.txt`)',
        '@@G2VSGP@@': 'G′ ↔ G″a = 고침 8 · 새 0 · 지움 0 [실측 git diff --name-status] · G″ = 그 위 고침만'}
for k, v in vals.items():
    assert k in s, k
    s = s.replace(k, v)
assert '@@' not in s, re.findall(r'@@\w+@@', s)
open(p, 'w', encoding='utf-8').write(s)
for k, v in vals.items(): print(k, '=', v[:150])

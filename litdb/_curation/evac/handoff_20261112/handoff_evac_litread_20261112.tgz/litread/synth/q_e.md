# 질문 e — 배치별 근거 묶음 (원문 줄 그대로 · 파일 41 개)

### [batch_01] e. 점접촉 법칙이 큰 변형에서 깨지는 범위와 대안 · 대안마다 맞춘 값 개수

깨지는 범위의 수치 · 대안별 맞춘 값 개수는 **이 배치에 없음** (EEPA · Thornton-Ning · Storåkers 언급 없음).

- [e] bardenhagen2000_mpm_granular_multibody_frictional_contact | 범위 수치 없음. 논문 §1 의 DEM 전제 = "deformations of individual grains are small in comparison with the deformation of the granular assembly" — 카드: 무른 SE 의 큰 변형에서 약해지는 전제이고 MDR 이 그 자리를 메우려는 것 | §10 표 C / C′ 행 (L352) | 인용 = stated · 카드 판정 "중립" | 대안 (MDR · 다접촉 보정) 은 다른 카드 (`zunker2024_mdr_contact_model_partI` · `giannis2021_stress_based_multicontact_dem` · `varkey2026_multicontact_elastoplastic_dem`) 지목만 (L410–411)
- [e] choi2024_digital_twin_review_echem | 값 없음 — "DEM · MD 과정에 부피 변형 반영 → 미세구조 해상 성능 예측 (ref 34, 35, 100–103)" 언급만 | §6 (L293–295) · p.27 | 표지 없음 | 접촉 법칙 내용 없음
- [e] lim2025_virtual_calendering_framework | 값 없음 — 선행 시뮬의 한계로 "완전 구형 입자 가정으로 표면 형상의 영향을 반영 못 함" 을 들고 MPSP-DEM (Nikpour · 비구형) 을 거명 | §1 (L75–83) | 표지 없음 | 접촉 법칙의 유효 범위가 아님


### [batch_02] e. 점접촉 법칙이 큰 변형에서 깨지는 범위와 대안 · 대안마다 맞춘 값 개수

- [e] nezamabadi2022_mpm_cd_plastic_particle_compaction | Hertz 접촉 이론은 "only valid up to about 10% of strain" · 압밀 모델링에는 "too crude" (논문 p.1) → 대안 = 입자를 연속체로 (MPM) + 입자 간 접촉 (Contact Dynamics) | §10 (L459–462) · §0 (L35) | 표지 없음 (원문 따옴표 인용) | 10 % 의 근거 · 변형의 정의는 카드에 없음 · 2D 논문 · 맞춘 값: 재료 값은 일반값 (실험 맞춤 0 개) · 해석 압밀식만 매개변수 4 개 + 재밍점 (L211)
- [e] nguyen2017_mpm_bpm_deformable_particle_compaction | 2D 단일 원판: 탄성 MPM 이 2D Hertz 직선 (F = (π/4)·E/(1−ν²)·R·ε · 식 2) 을 ε > 0.05 에서 이탈 · ε > 0.15 에서 더 낮은 기울기 (≈ 1.8 MPa) | §3.3 (L114–115) · §4.3 (L155) · Fig 1 | stated (이탈 범위) / digitized (기울기) | 2D 원판 (3D 구는 지수 3/2 — 직접 옮기지 않음 · L248–249) · 판독 정의 σ = F/L
- [e] nguyen2017_mpm_bpm_deformable_particle_compaction | "Above 20% of deformation, the particles are so much deformed that the contacts can no more be modeled as point contacts. In this regime, the particle shapes are well approximated by polygons, and Z then represents the number of sides of these polygons." (논문 p.3) | §4.4 (L160–161) · §10 (L338) | 표지 없음 (원문 따옴표 인용) | 2D · "deformation" 의 정의는 카드에 없음
- [e] nguyen2017_mpm_bpm_deformable_particle_compaction | 대안 BPM (DEM 틀의 변형 입자): 값 = F0 100 N · γ 7 · 차단 δ = a0 · 입자당 1차입자 ≥ 200 개 (실험 맞춤 아님 · "The choice of the exponent γ is not crucial for this study") → 결함 셋: 문턱이 재료 σ_y 가 아닌 F0/⟨a0⟩ · 입자 간 마찰이 동원되지 않음 · Φ ≈ 0.93 (변형 40 %) 에서 내부 공극이 판독을 오염 | §3.1 (L92) · §4.2 (L141–149) · §8-④ (L294–296) | stated (값 · 0.93) + 카드 판정 | 2D · 카드 권고 = SE 모델로 쓰지 않음 (기각 기록)
- [e] pycompact2025_dem_mpfem_workflow | 입자별 FE 는 접촉 법칙 층 (Thornton–Ning · EEPA · Luding) 을 건너뛰고 penalty 접촉 + FE 메시로 대체; 맞춘 값 = 마찰 μ 0.2 하나 ("µ = 0.2 was selected for best experimental agreement") · 재료 상수 (Swift K · n · ε₀) 는 선행 실험 [17] | §7.3 (L344–346) · §9.2 (L390–393) · §15.2 (L628) | stated (μ 선택 문장) + 카드 판정 | 금속 · 1400–2000 MPa · Coarse 만 보면 μ 0.1 이 실험에 더 가까움 (digitized · L391)
- [e] alabdali2023_cgmd_wet_manufacturing_ssb_cathode | Granular-Hertz = F ∝ √R*·θ^{3/2} 의 순수 Hertz — "항복 분기도, 소성 잔류겹침도, 형상변화도 없다"; 카드의 층위: Schreiner (EEPA · 소성) > Varkey (Thornton–Ning · 소성) > 이 논문 (Hertz + LJ · 탄성) | §4-3 (L203) · §11 (L723) | 표지 없음 (카드 판독) | 큰 변형 범위에 대한 저자 문장은 카드에 없음 · 맞춘 값: Table S1 의 기호 12 개 × 단계 2 (이 조수가 표의 행을 셈 · L215–226) — 슬러리 밀도 · 점도에 Bayesian 최적화 + 수동 보정 (L338–342)
- stomakhin2013 · alizadeh2018: 점접촉 법칙의 큰 변형 한계 서술 없음 (alizadeh 는 "Tabor 기준상 큰 · 무른 입자 · 낮은 응력이라 JKR 타당" 만 · §4-1 L154).
- MDR · EEPA · Storåkers · multi-contact 의 값은 이 배치 카드에 없음 (다른 카드 이름만 가리킴 · nezamabadi2022 §12 L502–503).


### [batch_03] e. 점접촉 법칙이 큰 변형에서 깨지는 범위와 대안 · 대안마다 맞춘 값 수

MDR · EEPA · Thornton–Ning · Storåkers 의 **맞춘 값 수는 이 배치 카드에 없음** (다른 카드를 가리키는 줄만 있음).

- [e] arzt1982_particle_coordination_densification_spheres | 접촉면이 서로 독립으로 (무제한) 자란다는 가정이 깨지는 곳 = 이웃 접촉면의 impingement, 상대밀도 D ≈ 0.90 ("about 90%") — 원문 "At that stage the present model, which assumes uninhibited growth of contact areas, is no longer strictly valid." | §3 (L47) · §4-6 (L147) · 논문 p.1886 · 1887 · 1889 | stated | 단분산 · 등방 · 판정식은 본문에 없음 (L298)
- [e] arzt1982_particle_coordination_densification_spheres | 대안 (그 논문 안): 본격 처리와 가공경화 포함 냉간 압밀 완전 이론은 Fischmeister & Arzt [8] ("Powder Metall. To be published") 로 넘김 · 맞춘 값: 적합 매개변수 없음 — Z₀ 7.3 · C 15.5 · D₀ 0.64 는 RDF 선형화 값 | §10 (L433) · §3 (L42–44) | stated · [8] 서지 [미확인] | [8] 내용은 카드에 없음
- [e] arzt1982_particle_coordination_densification_spheres | 접촉 하나의 크기: Arzt 압밀 한계에서 초기 접촉 평면 a₀ = 기하 겹침 원의 1.27–1.40 배 (D 0.84–0.90) = Hertz 원판 πR*δ 의 2.42–2.64 배 · D = 1 에서 3.23 배 | §L-6 표 (L400–405) · §8 ③ (L275) | "우리 재계산" | 단분산 · 원거리 (압밀) 극한은 논문 스스로 "접촉 크기의 하한" (L102 · L416)
- [e] arzt1982_particle_coordination_densification_spheres | 다른 카드를 가리키는 줄: 독립접촉 유효 한계 D ≈ 0.82 (B2 FEM · `mesarovicfleck2000_dissimilar_elastoplastic_indentation`) · 이원 혼합 DEM 유효 D ≤ 0.95 (엄밀히 0.85–0.90 · `martinbouvard2003_dem_composite_cold_compaction`) · MDR 다분산 검증 R 비 0.25 까지 (우리 12:4:1 의 0.083 은 범위 밖 · `zunker2024_…` · `zunker2025_…`) · 소성 접촉면 ≈ 기하 겹침의 약 1.4 배 (`storakers1997_similarity_inelastic_contact`) · 이웃 접촉 상호작용의 비국소 · 평균장 처리 (`gonzalez2012_…` · `giannis2021_…` · `varkey2026_…`) | 참고문헌 절 표 (L469–474) | 표지 없음 (다른 카드 요약) | 이 배치 밖 — 원 카드에서 확인할 것
- [e] cardenasbarrantes2020_rigid_deformable_mixture_compaction_nscd | 접촉 변형만으로 국소 변형을 정의하는 Voigt (유효매질) 근사 식 (8) 은 작은 변형 구간 φ ∈ [φ0, φ+] 에서만 맞음 — φ+ ≃ 0.83 (κ 0.2) → ≃ 0.9 (κ 1.0) · 그 뒤 φmax 쪽 발산을 못 잡음 — 원문 "the definition of local strains only by means of the contact deformations σℓ = E εv,ℓ should be reconsidered" | §3-2 (L124) · §5-6 (L308–313) · 그림 7 | stated | 2D (φ0 ≈ 0.81) · 초탄성 · 등방
- [e] cardenasbarrantes2020_rigid_deformable_mixture_compaction_nscd | 대안 (그 논문): "단일 입자 상자 응답 × 연결성" P ≃ (Zφ/2π)·Pp (식 11) → 압밀 법칙 식 (12). 맞춘 값: 거시 적합은 φmax(κ) **하나** · 나머지 = 단일 입자 시험의 b ≃ 0.14 · Z–φ 사상의 ξ ∼ 5.1 · α ∼ 0.5 · 초기 상태 Z0 · φ0 | §5-8 (L326–327) · §5-9 (L336–337) · §4-5 (L237–238) | stated | 곡선마다 φmax 를 맞춘 결과 · 식 (15) 예측선은 적합값보다 0.012–0.035 낮음 (L332) · 2D 초탄성
- [e] cardenasbarrantes2020_rigid_deformable_mixture_compaction_nscd | 기존 압밀식 (Secondi · Zhang · Platzer): "well-chosen parameters" 면 다 맞지만 식 · 매개변수의 물리 의미 불분명 · φmax 는 모든 기존 식에서 다른 매개변수와 함께 보정됨 — Secondi n = φmax = 1 이면 Heckel | §5-3 (L291–295) · §4-5 (L228) | stated | 2D 자료에 대한 적합
- [e] cardenasbarrantes2020_rigid_deformable_mixture_compaction_nscd | 카드 해석: "접촉 법칙만으로는 고밀도에서 실패한다 (Voigt K1 · 그림 7) — 입자 벌크 응답이 필요" → MDR Part II 벌크탄성 · Varkey / Giannis 다중접촉이 같은 증상을 다른 처방으로 다룸 | §9-5 (L501–503) | 표지 없음 (카드 해석) | 논문 문장 아님
- [e] cardenasbarrantes2022_soft_hard_grains_compaction_experiment_dic | 접촉 길이 ⟨l⟩ ∝ φ − φJ 는 작은 변형 구간에서 Hertz 접촉 법칙의 척도 고찰 + Z–φ 식으로 예측되고 (SM), 그 구간을 훨씬 넘어서도 선형 유지 · 이산 계 → 연속체 같은 계 전이 C_c = 0.991 ± 1.2 × 10⁻³ (κ 무관) ≈ 변형 0.45 % | §5-4 (L219–221) · §3-2 (L110) · §3-4 (L135) | stated (C_c) · derived(ours) "거친 환산" (0.45 %) | 2D · 실리콘 · SM 미보유


### [batch_04] e. 점접촉 법칙이 큰 변형에서 깨지는 범위와 대안 · 대안마다 맞춘 값 개수

- [e] giannis2021_stress_based_multicontact_dem | 깨지는 범위 (원문): "Hertz theory is applicable only for small deformation with an upper limit of δ/r ≤ 0.1 (10 %)" | 논문 §3.3 · 카드 §3.3 (L93) | stated | 탄성 구 · δ 가 쌍 겹침인지 구 하나의 눌림인지 카드에 없음
- [e] giannis2021_stress_based_multicontact_dem | 고전 (Hertz) DEM 의 힘 과소 배율: 단일 고무 구 δ/r 40 % 실험 ≈ 433 kPa ↔ 고전 ≈ 245 kPa (1.77×) · 514 하이드로겔 ε 13.4 % ≈ 555 ↔ ≈ 245 Pa (2.27×) · 1921 이봉 ε 10 % ≈ 440 ↔ ≈ 200 Pa (2.2×) · 유리 17 개 ε 2.64 % ≈ 45 ↔ ≈ 35 MPa (1.29×) | §3.3 표 (L83–91) · Fig 4 · 11a · 14 · 16 | digitized (TREND only · ± 없음) · 배율 = 카드 계산 | 하이드로겔 · 고무 · 유리 · 3D · 카드: 절대값 인용 금지 (L534)
- [e] giannis2021_stress_based_multicontact_dem | 대안과 맞춘 값 개수: ① MC-strain (Brodu · Dijksman · Behringer, Phys. Rev. E 91 (2015)) = γ 하나 — 이론 앵커 0.5 (ν → 0.5) · 1 (ν → 0) · 맞춘 값 0.55 · 1.12 · 0.53 · 4.5 (유리는 이론에서 ~6×) · 접촉 쌍 O(C²) · 원리상 반복 ② MC-stress (이 논문) = β 하나 (1.71 · 1.65 · 1.74 · 5.17 · 이론 앵커 없음) + 미기재 규약 2 개 (P_ij 정규화 · branch vector → k = 0.25–1.5 · 6 배 모호) ③ 카드 표: 경도 항복 캡 (So · Thornton–Ning) 자유변수 0 · 우리 E 연화 자유변수 1 | §3.2 (L68–79) · §4.4 (L181–191) · §7-3 표 (L367–371) · §7-7 (L454–463) | β · γ = stated · 6 배 모호 = 카드 분석 · ③ = 표지 없음 (우리 쪽 표) | ① ② 는 탄성 · 항복 캡의 값 개수는 Giannis 가 아니라 카드의 표
- [e] giannis2021_stress_based_multicontact_dem | 카드의 교차 기록: Thornton–Ning 단독은 큰 변위에서 FEM 보다 힘이 작다 (Varkey SI Fig S1 · 5 mm 에서 FEM 9.7 ↔ 5.7 × 10⁴ N) — F_mc 가 그것을 되돌리는 짝 · Varkey 는 β = 0.5 를 씀 | §7-3 (L377–379) · §10 (L529) | 표지 없음 (다른 카드 인용) | 재료 · 차원은 이 카드에 없음 (`varkey2026_multicontact_elastoplastic_dem` 소관) · 정규화 확인 없이 β 0.5 ↔ 1.65–5.17 비교 금지 (카드)
- [e] giannis2021_stress_based_multicontact_dem | 선행 다접촉 계열 거명: Gonzalez–Cuitiño [24] · Frenning [25] (truncated sphere + 법선응력 합 × 접촉 면적) · Celigueta [26] (고려 접촉에 수직인 접촉만 결합) · GEM (Karanjgaokar) [27] (다목적 최적화로 입자간 힘 역산) | §11 (L568–570) | 표지 없음 | 맞춘 값 개수 · 유효 범위 카드에 없음
- [e] coetzee2017_dem_calibration_review | 리뷰가 다룬 접촉 법칙 = 선형 spring-dashpot · Hertz–Mindlin (소성 캡 · 다접촉 없음). 겹침 허용치 (속도용 강성 감소가 벌크를 안 바꾸는 범위): Cleary [233] 0.1–0.5 % · Paulick [235] ≤ 입자 반지름의 1 % · Höhner [72,73] ≤ 4 % (그 계 한정) · Lommen [81] 겹침 ≤ 0.3 % (쐐기 관입 저항 포화 · 안식각 무영향) | §5-Q2(b) 표 (L227–231) · p.135–136 | 리뷰 stated (1차 출처 소환값) | 저응력 자유 유동 계 · 카드: "보정된 강성의 타당성 기준이 아니다" (L972–974) → 점접촉 법칙의 유효 범위로 쓰지 말 것
- [e] coetzee2017_dem_calibration_review | 실제 접촉 실측 (Cole [216,217] · 자연 소립자): 법선 하중–변위가 "linear with the onset of loading" 이고 문턱 법선력 위에서 "the Hertzian 3/2 power law" 로 전이 · 전단 / 법선 강성비 0.3 – 약 1 | 카드 §6 의 "§6 Direct measuring" 요약 (L641–645) | 원문 인용 (리뷰가 전한 1차 출처) | gneiss · 자갈 · 석영사 · 마그네사이트 · 큰 변형 아님
- [e] coetzee2017_dem_calibration_review | 접촉 모델끼리 견준 예는 드묾: Ucgul [136] = Hertz ↔ Walton & Braun 이력 spring → 이력 모델이 토양–공구에서 더 정확 · Grima & Wypych [37] = 선형 ↔ Hertz–Mindlin 벌크 수준 유의차 없음 | 카드 §6 의 "§4 Contact models" 요약 (L589–595) | 리뷰 stated (소환) | 토양 · 저응력 · n = 1 · 맞춘 값 개수 카드에 없음
- [e] electromechanical_contact_model_particulate_systems | 탄성 Hertz–Mindlin (no-slip) 만 · 항복 캡 · 소성 분기 없음 · 과압축 cap 없음 (힘 0–500 N) — 깨지는 범위는 말 없음 · 탄소성은 future work | §4 (L69–73) · §A.3 (L194–195) | stated ("명시") | 금속 · 저힘
- [e] dmt1975_adhesion_contact_deformation | 큰 변형 범위 없음. 점착 접촉의 계보만: DMT (탄성) → Thornton–Ning (JKR + 소성 캡) → EEPA (Thakur) → Pasha | §7 ④ (L124–125) | 표지 없음 | 값 없음
- [e] deng2021_mechanical_surface_energy_tester_bond_number | 이 배치에 없음 | — | — | —


### [batch_05] e. 점접촉 법칙이 큰 변형에서 깨지는 범위와 대안 · 대안마다 맞춘 값 개수

- [e] gonzalez2012_nonlocal_contact_confined_granular | 깨지는 전제 = Hertz 의 세 번째 전제 (접촉면 ≪ 물체 치수 → 반공간 대치 → 접촉끼리 독립). 깨지는 범위: 문턱 없음 — Δ ∝ ε^(1/2) (식 17–18) · "Hertz theory predictions depart from experimental observations at very small deformations" (Fig 7 본문); 크기 Δ ≈ 40 % (2D · 변형 10 % · ν→1/2) · ≈ 50 % (무질서 침대) · ≈ 200 % (BCC 거의 완전 압밀); 접촉면 안의 Hertz 압력 분포 자체는 a/R < 0.40 에서 p_m 오차 < 6 % (Zhupanska) | §4.1 (L125–141) · §6.1 (L362–378) · §3.3 (L91–96) · §3.1 (L75) | stated | 탄성 구 · Δ 는 접촉 배치에 의존 (카드 §4.4 = 우리 유도)
- [e] gonzalez2012_nonlocal_contact_confined_granular | 대안별 맞춘 값 수 (카드 표): 비국소 탄성 (이 논문) **0** · 비용 O(n̄·N_c) + 고정점 반복; 변위 기반 다접촉 (Brodu 2015) **1** (γ — 이론 앵커 ν→½ 0.5 / ν→0 1 · 유리에서 4.5 = 약 6 배 이탈) · O(C²) + 반복; 응력 기반 다접촉 (Giannis 2021 → Varkey 2026) **1** (β — 이론 앵커 없음 · 1.71 / 1.65 / 5.17 · Varkey 0.5) · O(C) 반복 없음; 경도 항복 캡 (So 2021) **0** (H = 물성); 무르게 맞춘 영률 (우리) **1** (E_eff 1.35 GPa) | §9 (L486–505) · §10.2 표 (L587–594) · §10.6 표 (L732–738) | 이 논문 행 = stated + 카드 감사 · β · γ · So 행 = "우리 다른 카드 경유 — 원문 미열람" (L505 · L602) | Brodu 2015 · Harthong 2009 는 litdb 미보유
- [e] gonzalez2012_nonlocal_contact_confined_granular | 강성 방향: 비국소 · 다접촉 보정은 접촉을 **더 뻣뻣하게** (Fig 4 캡션 "two elastic spheres in compression behave stiffer than Hertz theory predictions" · 식 12 의 양의 고차항) — 무르게 맞춘 영률과 부호 반대. 카드 추정: 넣으면 E_eff 1.35 → ≈ 1.10 GPa (17.8 배 → 21.9 배) | §4.5 (L266–267) · §10.4 (L650–681) | 인용 = stated · 추정 = 우리 유도 (order-of-magnitude · 단서 5 개) | 카드: "21.9× 라는 숫자를 헤드라인으로 쓰지 말 것"
- [e] gonzalez2012_nonlocal_contact_confined_granular | 단일 구 벤치마크의 한계: 세 정식화 (비국소 · 변위 기반 γ = 0.55 · 응력 기반 β = 1.71) 가 같은 Tatara 고무 구 곡선 (40 % 에서 실험 ≈ 433 kPa ↔ 고전 DEM ≈ 245 kPa = 1.77 배 과소) 을 각자 복원 — "그 실험은 셋을 구분하지 못한다 · 구분력은 다입자 · 다배치 예측에 있다" | §10.2 (L607–615) | Giannis 카드 경유 (그 카드의 Fig 4 기록) | 수치는 다른 카드의 판독값
- [e] gonzalez2012_nonlocal_contact_confined_granular | 큰 변형용 접촉 법칙 (MDR · Zunker & Kamrin 2024 I · II / 2025) 에 대한 지목: 기하 · 부피 보존 결합을 갖지만 Part II 가 "원거리(far-field) 응력 결합 미고려" 를 Fig 5c 불일치의 원인으로 스스로 적음 — 그 자리를 해석적으로 채우는 것이 이 논문 (경쟁이 아니라 보완) | §10.1 (L557–562) · §16 (L976–980) | 다른 카드 (`zunker2024_bulk_elastic_partII`) 경유 | 원문은 그 카드에서 확인
- [e] gonzalez2012_nonlocal_contact_confined_granular | 소성 쪽 선행 지목: Mesarović & Fleck 2000 — "studied elasto-plastic spheres and concluded that the assumption of independent contacts only holds in the early stages of compaction"; Harthong 2009 — "fitted, from finite-element simulations of simple periodic lattices, contact laws that account for nonlocal-deformation effects during high-density compaction of elasto-plastic particles" (FEM 에 맞춘 값 있음 · 격자별 특성화 필요) | §11 ⑥ ⑦ (L824–829 · L838–840) | stated (논문 §1 의 문장) | 두 논문 원문은 이 카드 밖
- [e] jacksongreen2005_fem_elastoplastic_hemispherical_contact | 탄소성 단접촉 법칙의 유효 범위: Kogut–Etsion 2002 는 ω* = 6 (기울기) · ω* = 110 (절단) 두 곳 불연속 + 재료 무관 + 경도 상수 (2.8–3σ_y); Abbott–Firestone 절단 모델 A = 2πRω · P = 2πRωH; FEM 은 면적이 절단 모델을 지나 계속 증가 (재료 의존) · 경도가 a/R 로 진화. 대안 = 전 영역 연속 반경험식: 면적 A_F* = ω* (ω* ≤ 1.9) · ω*·(ω*/1.9)^B (B = 0.14·exp(23·e_y) · e_y = σ_y/E′) · 평균 오차 면적 1.3 % (최대 4.3 %) · 힘 0.94 % (최대 3.5 %) | (1)–(4) (L105–132) · §3 표 (L35–40) · §7.4 표 (L191–198) | stated | 맞춘 것 = FEM 결과에 대한 적합 상수 (카드에 적힌 식 기준 경도식 2.84 · 0.82 · 0.7 · 면적식 1.9 · 0.14 · 23) · 실험에 맞춘 값은 카드에 없음 · 단접촉 · 무마찰 · 무경화
- [e] he2026_dem_calendering_inhomogeneity_areal_density | EEPA (Edinburgh Elasto-Plastic Adhesion): 3 분기 이력 (탄성 로딩 k₁ · 소성 제하 k₂ · 점착 분리 k_adh · 상수 pull-off f₀); 입자–입자 값 6 개 (μ 0.25 · 구름 0.014 · 반발 0.25 · 표면에너지 8 J/m² · λ_p 0.96 · f₀ 1.5 × 10⁻⁵ N) 를 [39] Ge 2022 에서 재보정 없이 차용; 깨지는 범위는 논문에 없음 · 나노압입 제하 가지가 어긋남 | §4.2 (L244–262) · §3.2 (L91–98) · §3.9 (L210–212) | stated (Table 2 · 식 2–7) | k₁ · k₂ · k_adh 수치 · 지수 n · 감쇠 · 시간 간격 미기재 (L105–106)
- [e] he2026_dem_calendering_inhomogeneity_areal_density | 압연 DEM 여섯 편의 접촉 법칙 (카드 계보표): Thornton–Ning + bond (Sangrós 2019 / 2020) · GH + SJKR (Ngandjong 2021) · EEPA + Bonding (Schreiner 2020) · PFC3D bond (Lyu 2025) · CGMD 실형상 (Xu 2023) · EEPA bond 없음 (He 2026) — 전부 강체 구 (또는 고정 형상) · 형상 소성 0 | §2 계보표 (L57–67) | 표지 없음 (카드 정리) | 다른 다섯 편은 각 카드에서 확인
- [e] johnson1971_jkr_surface_energy_contact_elastic_solids | 점착 가지의 바닥 법칙 (탄성 · 매끈한 구): 근사 이론 F_S ≈ πRγ (식 6) 는 정확해 (식 21) 의 2/3; 맞춘 값 = γ 하나 (접촉 지름 자료에 식 19 를 맞춤) | §3-1 (L78 · L92–95) · §6 (L187) | [인쇄] · 2/3 = [우리 산술] | 큰 변형 · 소성 아님


### [batch_06] e. 점접촉 법칙이 큰 변형에서 깨지는 범위와 대안 · 대안마다 맞춘 값의 수

- [e] mesarovicfleck2000_dissimilar_elastoplastic_indentation | similarity 접촉 법칙 F/πR₀²σ_e = K(h/R₀)^(1+1/2m) 은 유한변형 영역 (a/R₀ ≳ 0.16 Brinell · ~0.06 case i · ~0.1 case ii · m = 3) 에서 평균압이 다시 내려가 깨진다 · 일반 천이 기준 없음. 대안 = 같은 멱법칙 꼴을 두고 K 를 낮춤: K_FEM/K_theory 0.55–0.87 (h/R₀ = 0.1) — 맞춘 값 = 기하 · m 마다 K 하나 (FEM 에 맞춤) | §3 (L35) · L112–126 · Fig 10 | stated (범위) · §10 (L229) 은 digitized 0.6–0.85 | 단접촉 FEM · 무마찰 · h/R₀ ≤ 0.2
- [e] mesarovicfleck2000_dissimilar_elastoplastic_indentation | 접촉 독립 가정 (Fleck / Storåkers 분말 압밀 미시모델) 은 D < 0.82 까지 유효 (3D B2 · D₀ 0.68 · m = 3) | L128–130 | stated | 단위셀 하나
- [e] kogutetsion2002_ep_sphere_rigid_flat | 단순 모형의 오차: CEB 는 면적 최대 56 % 과대 (ω/ω_c = 4) · 하중 62 % 과대 (2) → 38 % 과소 (110) · Zhao 는 하중 21 % 과소 (7) → 30 % 과대 (52) · 면적 20 % 과대. 대안 = FEM 점에 최소제곱으로 맞춘 멱법칙 6 식 (eq 5–8 · 두 구간 · 식마다 계수 · 지수) — 재료에 맞춘 값은 없음 (항복 개시값으로 정규화). 유효 ω/ω_c ≤ 110 · 그 뒤는 p_m = H 일정 + Abbott–Firestone 기하 절단 (110 에서 7 % 과대) | §3 (L41–59) · Fig 7–9 (L87–89) · L110 | 계수 = stated · 편차 % 는 §10 (L193) 에서 digitized 추세 | 소변형 해석 · 탄성-완전소성 · 구–평판
- [e] luding2008_cohesive_frictional_contact_models | 조각 선형 이력 법칙 (법선 값 5 개: k₁ · k̂₂ · k_c · φ_f · γ₀) 은 "model is limited … in the regime of large deformations" (§1.2) · 소성 한계 겹침 δ*_max = (k̂₂/(k̂₂ − k₁))·φ_f·(2a₁a₂/(a₁ + a₂)) 를 넘으면 강성이 상수 k̂₂ (eq 7 · 8) · 맞춘 값 없음 (예시값) | §0 (L22–24) · §4 (L101–110) | stated (식 · 따옴표) · "경도 / 항복압 캡 없음" 은 카드 판단 | 실제 자료 튜닝은 향후 과제 (§4)
- [e] martinbouvard2003_dem_composite_cold_compaction | Hertz 탄성 N_E 와 Storåkers 소성 N_P 가운데 작은 쪽 (eq 5–7) · 접촉면적 A = 2π·c(m)²·r_pq·h (eq 8) · 입력 = Σ · m · c(m) 표 · μ (맞춘 값이 아니라 스윕: 1/m 0 / 0.2 / 0.4 · μ 0 / 0.1) · 유효 범위 D ≤ 0.95 (엄밀히는 0.85–0.90 이전) | §4 (L38–43 · L51) | stated | 인접 접촉 비간섭 가정 · 금속 모델
- [e] molerus1975_theory_of_yield_cohesive_powders | 탄성 ↔ 소성 전환: "The plastic characteristics are valid from that point onwards where the elastic characteristics lie above the plastic characteristics" (p.265) — 같은 평탄화에서 Hertz 힘과 p_f·f 중 작은 쪽 · 면적 f = πδh (기하 절단) · 맞춘 값 없음 (재료 상수 대입) | §0 (L28–29) · §4-4 (L167–168) | stated (전환 규칙) · "Storåkers c² = 1 자리" 는 파생 | 돌기 척도 · "small deformations simple considerations"
- [e] molerus1975_theory_of_yield_cohesive_powders | 점 접촉 전제가 깨지는 크기 (카드 산술): d 1 µm · p 300 MPa · Z 6.5 · D 0.85 · H 0.85 GPa 이면 접촉이 입자 표면의 ≈ 40 % (0.415 = p/(D·H)) · 탄성 = 소성 전환 h/R* = (9π²/4)(p_f/E*)² → 0.032 (E* 22.415 · H 0.85 GPa) | §3-4 (L125–126) | 파생 (카드 산술 · "우리 침대 아님") | 단분산 가정 대입 · 원문 값 아님
- [e] kissel2026_mechanofusion_derived_cathode_composite_microstructures_scalable | Thornton–Ning 탄소성 접촉을 믹서 DEM 에 사용 — 조정했다고 적힌 것 = 항복비 · 영률 · 마찰 (SI 표 S2 값: 항복비 2 · E 1 · 정지 / 동마찰 각 2) · 반발계수 0.3 은 조정 여부가 카드에 없음 · 큰 변형 한계 서술은 카드에 없음 | §3-5 (L135–155) · §4-2 (L276) | [인쇄 p.13 · SI p.10] | 믹서 (충돌) 용 · 압축 DEM 아님


### [batch_07] e. 점접촉 법칙이 큰 변형에서 깨지는 범위와 대안 · 대안마다 맞춘 값 개수

- [e] paulick2015_elastic_particle_properties_dem_review | 겹침 가드레일 (탄성 점접촉 · 강성 감소가 무해한 범위): ① 1–10 % (밑변 미명시 · 유동 패턴 · Walton 1993) ② 최대 < 지름의 1 % (Hanes & Walton 2000) ③ 평균 ≈ 0.5 % 지름 (Liyan 2013) ④ 평균 ≈ 0.6 % 반지름 (Cleary & Hoyer 2000) ⑤ 리뷰 종합 < 지름의 1 % "for elastic deformation as foreseen by Hertz" | §5-Q2 표 (L235–245) · 논문 §2.1 p.67 · §2.4 p.72 · §4 · §5 p.75 | stated · 원문 인용 | 근거 5 건 모두 자유 표면 · 유동 · 대기압 계 (카드 분류 L222–233) · 예리한 문턱 아님 · 밑변 (지름 / 반지름) 과 통계량 (평균 / 최대) 이 출처마다 다름
- [e] paulick2015_elastic_particle_properties_dem_review | 우리 쪽 봉투 계산: δ/d = 0.115 이면 접촉 반경 a/R ≈ 0.46–0.47 (렌즈 기하) · 0.34 (Hertz 정의) → 소변형 가정 붕괴 · 이웃 접촉 독립 붕괴 (multi-contact 보정 필수) · 300 MPa · Z 6 · φ 0.64 에서 E 24 GPa 여도 δ/d ≈ 7.6 % (Z 8 이면 ≈ 6.3 %) · 1 % 를 지키려면 E ≈ 500 GPa | §10-(b) ② ③ (L828–846) | DERIVED-BY-US (order-of-magnitude 전용 · L838 · L1035–1037) | 논문 값 아님 · 단분산 · Hertz · 평균장 가정
- [e] paulick2015_elastic_particle_properties_dem_review | 리뷰가 다룬 소성 법칙은 [32] Thakur (adhesive elasto-plastic · EDEM v2.4) 한 편 — E 가 아니라 λ_p ∈ {0, 0.2, 0.5, 0.8, 0.9, 0.99} 를 훑음 (맞춤 아님) · λ_p ↑ → flow function ↑ · 접촉이 더 많이 성립해 응집력 ↑ · 벌크 소성 ↑ | §5-Q7 (L488–497) · 논문 §2.2 p.70 | stated | 분말 압축 16–96 kPa
- [e] so2022_dem_contact_model_assb_compaction_sintering | 구 겹침 (점접촉) 근사가 깨지는 곳 = 기공이 0 으로 가는 고압축: 접촉 면적 · 스프링 상수를 과소평가 (원인 셋 — 밀려난 재료로 실제 면적이 더 큼 · 형상 변화로 생기는 2 차 접촉 · 변위 → 힘 관계 무효) · 평형 겹침이 한없이 커져 고체 분율이 1 을 넘음 | §4.5 (L140–143) · §4.6 (L163) · 논문 §Additional info p9 | stated (카드의 우리말 옮김) | 깨지기 시작하는 밀도 · 겹침의 수치는 카드에 없음
- [e] so2022_dem_contact_model_assb_compaction_sintering | 대안 = 항복 캡 (F_th = H·A_eff) + 면적 인자 A = A_Hertz(1 + c_area·h_eq/R_eff) + 스프링 인자 k = k_Hertz(1 + c_spring·h_eq/R_eff)^{3/2} + 겹침 상한 h_ov^max · **맞춘 값 3 개**: c_area 2 (0 / 2 / 5 중) · c_spring 5 (생산) / 7 (3 / 5 / 7 중) · h_ov^max 0.6 R_eff (0.4 / 0.6 / 0.8 중) — Sakuda 실험 상대밀도와 시각 비교 · E 24 GPa · H 1.9 GPa 는 문헌값 그대로 · μ 0.5 · e 0.5 는 "This study" | §3 표 (L30–39) · §4.5–4.6 (L139–168) · §6 (L205) | stated | LPS · 단일 실현 · c_spring 값이 5 와 7 둘 (쓰임이 다름)
- [e] pasha2014_linear_elastoplastic_adhesive_contact | 대안 = 구간 선형 탄소성 + 점착 (항복압 캡 없음) · **맞춘 값 5 개** (k_e · k_p · k_cp · f₀ · f_0p — Thornton–Ning 응답 기울기 best-fit · Table 2) + 부하 의존 판의 k̂_e 13,000 N/m (Hertz 초기 제하 접선 best-fit) · pull-off 궤적은 "입자반경의 6 % 초과 변형" 에서 선형이 되어 그 부분만 fit (eq 18) · 상수 k_e 면 충돌 속도 > ~10 m/s 에서 반발계수가 (k_p/k_e)^½ ≈ 0.38 로 평탄 (비물리) → k_e = k_p + (r/R*)²(k̂_e − k_p) (eq 25) | §3 표 (L76–81 · L90) · §4.5 (L165–166) · §4.6 (L173–179) | stated | 맞춘 대상이 실험이 아니라 다른 모델 (Thornton–Ning) 의 응답 (Ning PhD 자료 digitize · L435–436) · 충돌 한정 · 암모늄 플루오레세인
- [e] pasha2014_linear_elastoplastic_adhesive_contact | 카드 판단: "선형≈비선형"이 충돌에서 성립한다고 압밀 (특히 큰 변형 · 캡 영역) 에서 자동 성립은 아님 | §7.5 (L347–349) · §10 (L430–431) | 표지 없음 (카드 판단) | 논문 문장 아님
- [e] schreiner2020_dem_calendering_lib | EEPA (항복압 캡 없는 구간 선형 이력 · Thakur 2014) + Bonding (Potyondy–Cundall) · 맞춘 값: λ_P 쌍별 3 · 표면 에너지 쌍별 3 · bond 임계 전단 · 법선 응력 · bond 접촉 반경 · Young's modulus (값 미공개) — 개수 합계는 카드에 없음 · 맞춘 대상 = flat punch 하중–변위 (정성) + 전극 밀도 | §3 (L41–42 · L47) · §4.2 (L63–69) | stated | LIB · 큰 변형 한계에 대한 언급 없음
- [e] roessler2019_dem_cohesive_aor_cylinder_lift_calibration | 점착 법칙 대안의 계산비: 단순 JKR 대비 Luding 모델 +20 % · EEPA +100 % (Klama 2017) · 단순 JKR 의 점착 매개변수는 하나 (CED) · 이 논문이 맞춘 값 3 개 (μ_p · μ_r · CED · 576 조합) | §3-1 (L61) · §3-3 (L98–100) | [인쇄] p.2 · Table 3 | 큰 변형 · 가압 아님
- [e] 포인터 (카드가 가리키는 다른 카드 · 내용은 그 카드 소관) | multi-contact = `giannis2021_stress_based_multicontact_dem` · Varkey 2026 · 항복 캡 = Thornton–Ning · So (H 캡) | paulick2015 §10-(b) (L832–833 · L851–852) · so2022 §8 ① (L226) | 표지 없음 | 이 배치에서 확인 불가


### [batch_08] e. 점접촉 법칙이 큰 변형에서 깨지는 범위와 대안 · 대안마다 맞춘 값 개수

- [e] varkey2026_multicontact_elastoplastic_dem | 깨지는 범위: Hertz · Thornton–Ning 은 상대밀도 ρ > 0.7 에서 "권장 안 함" (Fig 8) · 대안 = 응력 기반 다접촉 구속항 F_mc = β·ν·a_ij·P_ij (입자 응력 σᵖ = (1/Vᵖ)Σlⁿ⊗fⁿ · P_ij = (trσ_i + trσ_j)/3 · eq9–10) — ρ > 0.7 에서만 유효 · 맞춘 값: β = 0.5 하나 (접촉 법칙의 항복비 0.0103 · 바인더 결합 계수는 따로) | §4 (L33–34) · §5 Fig 6 · 8 행 (L47–48) | stated (식 · 값) | 할라이드 · β 를 무엇에 맞췄는지는 카드에 없음 · 검증 = 두께 4 압력 + 구 3 개 FE · 다접촉은 평균장 근사 (L86)
- [e] varkey2026_multicontact_elastoplastic_dem | FE 대조 (변형체 구 3 개 · 지름 10 mm · 판 변위 5 mm): 다접촉 모델 = FE 와 전 영역 일치 · Thornton–Ning 단독은 고변위에서 낮음 (5 mm 에서 ≈5.7 vs FE / 다접촉 ≈9.7 × 10⁴ N) | Supplementary (L92–99) · SI Fig S1 · Table S1 | 표지 없음 (그림 값 "≈") | 일반 탄소성 재료 (E 71 GPa · σ_y 280 MPa) · 3 입자 · 접촉 법칙의 수치 정확도 검증이지 재료 검증 아님 (L95–96)
- [e] thorntonning1998_adhesive_elastoplastic_contact | 대안 = 항복압 캡 법칙 (Hertz → p_y → 선형 소성 → R_p* 제하) · 소성 매개변수 p_y 하나 (+ 점착 Γ) — 재료 값에서 정함 (맞춤 아님) · 전제 = 탄성-완전소성 · 균일 p_y 압분포 · 단일 접촉 | §4 (L88–121) · §10 (L359–365) | stated | 조밀 영역 범위는 논문이 다루지 않음 (충돌 한 번) · 카드: "단독은 고밀도서 under-stiff 가능 · LPSCl @300 MPa 재현으로 미검증" (L363–365)
- [e] thakur2014_eepa_adhesive_elastoplastic_dem | 대안 = EEPA — 매개변수 5 개 (k₁ · k₂ · k_adh · f₀ · n) · 이 연구는 k₁ 1 kN/m · n = 1 고정 뒤 k₂ · k_adh · f₀ 스윕 · 항복압 캡 없음 (카드 판정) · δ_min 아래 이력은 모델 안 함 · 탄성 점착 (modified JKR) 은 흐름 함수가 너무 평탄 | §3 표 (L63–67) · §4 (L89–127) · §5 Fig 8 행 (L171) | Table 1 = stated · 캡 없음 = 카드 판정 | 16–96 kPa 에서만 보정 · 큰 변형 범위에 대한 논문 말 없음
- [e] storakers1997_similarity_inelastic_contact | 대안 = 자기상사 소성 접촉 면적 A = 2π·c²(m)·r·h 와 하중 법칙 (Martin–Bouvard 2003 eq7–8 이 그대로 사용 · c 0.5 → 1.45) — 재료 매개변수 σ₀ · m (· n) · 맞춘 값 0 (Tabor 상수 채택) · 독립 접촉 전제 — 카드가 Mesarović–Fleck §6 을 끌어 D ≳ 0.82 에서 무효라고 적음 | §3 (L34) · §8.2 (L174–178) · §8.3 (L201) · §11 (L269–271) | 법칙 = stated · D ≳ 0.82 = 카드의 교차 인용 | 0.82 는 이 논문 값이 아니라 다른 카드 (Mesarović–Fleck 2000) 의 값
- [e] vanlew2015_modifying_youngs_modulus_distribution | Hertz 맞춤이 실측으로 확인된 겹침: 압쇄 시험 δ/d ≈ 1.7 % 까지 · 이진 (독립) 접촉 가정을 명시 채택 (Russell [12]) 하고 입자 전체 합산 (Zhao [11]) 을 기각 — 카드: 다접촉이 중요한 것은 ρ > 0.7 (Giannis · Varkey) 이라 6 MPa 에서는 정당 · 300 MPa 로 옮기면 정당하지 않음 | §3.3 (L134–135) · §5.3 (L271–284) | δ/d = DERIVED (ours) · 채택 문장 = 원문 인용 | 세라믹 pebble · 탄성 Hertz · 대안 법칙은 없음
- [e] tovar2026_cold_spray_cathode_composite_dem_plastic_elastic_bond | 접촉 법칙을 바꾸는 대신 입자 내부를 결합구로 — 결합 매개변수 재료당 5 (E_b · σ0 · α · σ_normal · σ_shear) + 감쇠 e 0.60 · e_b 0.88 + Hamaker 상수 · 정량 보정 없음 (문헌 · 유효값) | §4-2 – 4-4 (L67–117) | stated (Table 1–2) | 충돌 · 격자 의존 · 접촉 (비결합 구 사이) 은 Hertz + 감쇠 그대로 (L86)
- [e] stallard2022 · thompson2026 · wang2024 | 해당 없음 (접촉 법칙 없음) | — | — | —


### [batch_09] e. 점접촉 법칙이 큰 변형에서 깨지는 범위와 대안 · 대안마다 맞춘 값 개수

- [e] zunker2024_mdr_contact_model_partI | 깨지는 범위: 순수 기하 교차 면적 A_C = π(2δR − δ²) 는 δ_o/R_o > 0.3 에서 과소예측 (→ 겉보기 반경 R 성장 도입) · δ_o/R_o > 0.15 부터는 전부 완전소성 식이 지배 · E/Y 가 클수록 Hertz 가 맞는 δ 구간이 0 으로 줄어듦 (Fig 5b inset) · 선행 점착 접촉 연구의 검증은 전부 δ_o,max/R_o < 0.1 (Mesarovic & Johnson 2000 · Olsson & Larsson 2013 · Gonzalez 2019) | §3 (L69–70) · Fig 5 · 8 행 (L246 · L249) · 논문 §5.6.3 · §8.3.2 | stated | 단일 입자 ↔ 강체 평판
- [e] zunker2024_mdr_contact_model_partI | 대안 MDR 의 맞춘 값: 정규화 접촉압 곡선의 상수 2 개 (1.75 · 4.4) — E/Y = 200 FEM 곡선에 한 번 · 전 재료 공통 · 재료별 보정 0 (입력 R_o · E · ν · Y · Δγ) · FEM 스윕 E/Y 6.25–200 · ν 0–0.45 · δ_o/R_o ≤ 0.5 · 권장 하한 E/Y ≈ 10 · ν 는 힘 · 면적 · 평균압에 무시할 만한 영향 (App B.1) | §3 (L60–68) · Fig B.15 행 (L255) | stated | 같은 반경 · 같은 재료 · 가공 경화 없음
- [e] zunker2024_bulk_elastic_partII | 고밀도 (공극 소멸) 구간의 대안과 맞춘 값 (저자 정리를 카드가 표로): Harthong 2009 = 경험적 + Voronoï 셀 판정 (비용 큼 · 강소성 한정) / Frenning 2013 · 2015 = 경험 값 1 개 (삼축압밀 한 가지 하중만) / Garner 2018 = 전면 경험적 · 맞춤 함수 여럿 (재료마다 재보정 · 배위수 고정) / Giannis 2021a = 경험 스프링 상수 + 힘 부등식 (재보정 필요) / Zunker Part II = 물성 κ 하나 + 문턱 ψ_b 1 개 | §4-1 (L69–75) | 표지 없음 (카드 정리 표 · "저자 지적") | 선행 모델의 값은 카드에 없음
- [e] zunker2024_bulk_elastic_partII | 다접촉 보정 (Varkey 2026 의 F_mc · Giannis 계열) ↔ Zunker 벌크: F_mc = β·ν·a_ij·P_ij · 경험 상수 β = 0.5 (1 개) · 늘 켜져 있음 ↔ dF_Bulk = (A_con/V)·κ·dδ̄_o·A_C · 문턱 ψ_b (1 개) · A_free/A_tot < ψ_b 일 때만 켜짐 · 벌크 발동 δ_o/R_o 0.21 (삼축) / 0.49 (die) | §7-2 (L185–196) · §3 (L51–52) | 표지 없음 (카드 대조표) · stated (발동 시점) | Varkey 쪽 값은 다른 카드 소관 — 이 카드에서 확인 불가
- [e] zunker2024_bulk_elastic_partII · zunker2025_dem_large_deformation_compaction | ψ_b 는 값이 정해지지 않은 자유 값: Part II 0.08 ("No precise value of ψ_b exists, however ψ_b around 0.08 gives reasonable results") → 2025 편 0.5 ("tuned to trigger the high confinement bulk response stiffening in alignment with the experimental results") = 6.25 배 | Part II §3 (L49) · §7-3 (L210–215) · 2025 편 Table 1 (L77) · §15 (L533–534) | stated · 원문 인용 | E/Y 20 (Part II) · Avicel (2025 편)
- [e] zunker2025_dem_large_deformation_compaction | 다체 DEM 전체의 자유 값 6–8 개: Y (피팅) · ψ_b · µ_t 0.7 · µ_t,wall 0.1 · µ_roll 0.6 · t_p 50 · 겹침 캡 0.75 · (CoR) | §11 (L387) · §13-1 ② (L439) · §13-2 c (L472–480) | 표지 없음 (카드 집계) | 카드 판정: "무보정은 과장 — 정확히는 법선 접촉 물성을 왜곡하지 않는다"
- [e] zunker2025_dem_large_deformation_compaction | 큰 변형 전용 장치의 범위: 극단 겹침은 δ^max_geo/R > 0.75 이면 0.75R 로 자름 (App B) · 가짜 접촉 페널티가 걸리기 시작하는 겹침 (같은 크기 대칭 삼중항) δ/R > 0.299 · 절반 가중 0.586 · 사실상 소거 0.764 · 반경이 다른 쌍의 검증은 반경비 0.25 까지 | §4 (L136 · L149–152) · §5-3 a (L193–200) | stated (캡 · 반경비) · DERIVED (문턱 셋) | 문턱은 카드 기하 계산
- [e] EEPA · Thornton–Ning · Storåkers | 이 배치 카드에 값 없음 (Thornton–Ning 은 Part I 층위 표에 이름만 · L281) | — | — | —


### [batch_10] e. 점접촉 법칙이 큰 변형에서 깨지는 범위와 대안 · 대안마다 맞춘 값 개수

깨지는 범위 (겹침 · 상대밀도 상한) 의 **수치** 와 대안 법칙 (multi-contact · MDR · EEPA · Thornton–Ning · Storåkers) 을 **쓴** 카드는 이 배치에 없음. DEM 으로 압밀한 네 카드 (bazzoun2025 · bazzoun2026 · faka2026 · kim2024) 모두 실제 E 의 캡 없는 Hertz 계열이다.

- [e] bazzoun2025_dem_parameter_sensitivity_assb_cathode | 법칙 = Hertz 스프링 + 점성 감쇠 + Coulomb 절단 · 구름 마찰 (식 6–7 · 26–27 · 32) · 항복 캡 없음 (카드: Thornton–Ning 의 p_y · So 의 H-cap · Varkey multi-contact 모두 없음). 깨지는 곳 = f_CAM 80–85 wt% (기공 과소 · θ_CAM 혼합 오차 · 민감도 급증). 맞춘 값 = 통합 유효 마찰 μ_eff **하나** (0.2 / 0.3 / 0.4 / 0.5 / 0.6 다섯 수준 가운데 0.4 가 모델–실험 오차 최소 · Fig 19) | §4 (L55–60 · L81) · §5 Fig 19 (L105) · §10 (L149–150) | stated (Table 3 · 5) · 한계는 카드의 "저자 명시" | 겹침 · 상대밀도 상한 수치 없음
- [e] faka2026_particle_size_consolidation_strain_lpscl | 법칙 = GFF (Hertz): F = (k_n δ_n − γ_n v_n) + (k_t δ_t − γ_t v_t) · E 18.5 GPa 그대로 1.6 GPa 까지 · 유효 범위 서술 없음 · DEM 밀도 미보고라 "E 18.5 로 실험 밀도가 나오는가" 를 판정할 수 없음 (카드). 맞춘 값: 카드에 없음 (물성 출처 = Alabdali 2024 · 마찰 · COR [미확인]) | §3-6 (L108–110 · L116) · §7-1 (L186) · §7-5 (L209) | [인쇄] · [미확인] | 무차원 하중 P/E ≈ 0.086 ([우리 산술] · L210)
- [e] kim2024_optimal_cathode_composite_mechanical_mixing_se_coverage | 법칙 = Hertz–Mindlin · 실제 E (22 / 175 GPa) · 200 MPa · 유효 범위 서술 없음 · DEM 기공 · 겹침 · 코드 [미확인] | §3-4 (L114–115) · §10-5 (L259) | [인쇄] · [미확인] | 맞춘 접촉 값은 카드에 없음
- [e] bazzoun2026_dem_fem_rnm_ionic | 법칙 = Hertz + 감쇠 (μ 0.4 · COR 0.4). 접촉 반경 식 두 가지 = 구–구 교차 (식 10) / 변형 깊이 r_c = √(r² − (r − δ)²) (식 11) | §4 (L28–29 · L36–37) | 표지 없음 | 유효 범위 서술 없음
- [e] 대안 법칙 카드 지목만 (이 배치 밖): `so2021_dem_mold_pressure_assb_coldpress` · `so2022_dem_contact_model_assb_compaction_sintering` · `zunker2025_dem_large_deformation_compaction` · `arzt1982_particle_coordination_densification_spheres` · `bouvard2000_hard_soft_powder_densification` | faka2026 L272 · lee2025 L259 | — | —


### [batch_11] e. 점접촉 법칙이 큰 변형에서 깨지는 범위와 대안 · 대안마다 맞춘 값 수

대안 접촉 법칙 (multi-contact · MDR · EEPA · Thornton–Ning · Storåkers) 을 구현하거나 비교한 카드는 이 배치에 없다. 깨지는 범위를 논문이 숫자로 말한 카드도 없다 — 아래 숫자는 카드의 산술이다.

- [e] otani2025_dem_se_dispersion_aggregation_compression | 카드 산술 (평균장 Hertz · ν 0.3 가정): SE–SE 겹침 δ/d = 0.085 (Z=6) · 0.070 (Z=8) @300 MPa → 0.178 · 0.147 @1000 MPa · 접촉면 평균압 3.00 / 2.73 GPa @300 · 4.34 / 3.95 GPa @1000 · Σ구부피 상대밀도의 과대계상 ≈0.9 %p @300 · ≈4.4 / 4.0 %p @1000 MPa | §11-② (L547–560) | DERIVED ("오더 추정") | 논문에 없는 계산 · Z · ν 가정 · 상별 하중 분담 무시
- [e] otani2025_dem_se_dispersion_aggregation_compression | 논문 안의 대안 언급: Luding 류 · EEPA · DMT · Thornton–Ning 어느 것도 없음 · JKR pull-off 식도 인쇄되지 않음. 맞춘 값 = 응집체 결합 파단응력 1 개 ("중력 충전 중 유지 · 압축 중 끊기도록 미리 설정") — 인쇄값 1000 GPa 는 최대 압력 1000 MPa 와 충돌 · 결합 강성 S_n · S_t · 반경 R_B 미보고 | §3.4-① (L154–159) · §4.2 (L204–209) | stated (Table 1) + 카드 판정 | 접촉 법칙 자체는 맞춘 값 0 (문헌 E · γ 0.1 J/m²)
- [e] shi2019_high_am_loading_particle_size_assb | 대안 없음. Hertz 이력형 힘 식에 항복 · 소성 · 점착 항이 없음을 SI 식으로 확인. 맞춘 값 0 (문헌 입력) · μ · COR · k_n · k_t 미공개 | §4 (L171–173) · §S.1 (L330–332 · L352) | SI-stated | 겹침 · 밀도의 유효 상한 언급 없음 · DEM 기공 미보고
- [e] schneider2023_particle_size_pressure_transport | 접촉 법칙 본문 미상술 (SI). 입력 ρ · ν · k_N (법선 강성) · c_cor (접촉 보정) · μ · g · "밀도 ρ, 마찰 μ 등은 실험 매칭으로 튜닝" — 맞춘 값의 개수는 카드에 불명. 구 가정 때문에 저압 regime I 에서 계산이 실험보다 과대 | §4 (L71–76) · §5 Fig 6 (L110) | 표지 없음 (카드 서술) | SI 미독
- [e] tailored_cathode_microstructure_low_pressure_assb | Hertzian 탄성 접촉. 접촉 판정 임계 "minimum overlap" (겹침 ÷ 두 반지름 합) 을 0 → 2 → 5 → 10 % 로 올리면 CAM utilization 이 coarse 94 → 83 → 56 → 20 % · fine 100 → 100 → 94 → 28 % — 결과가 임계에 크게 걸림. 저자가 "특정 C-rate 에 맞춘 overlap 추가 보정 필요" 를 인정 (임계가 사실상 맞춤값 1 개 후보) | §5.3 Table 1 (L88–101) · §5.6 (L113) | stated (표) · 카드의 한국어 옮김 (인정 문장) | 재료 값 (E · ν · μ) 미공개


### [batch_12] e. 점접촉 법칙이 큰 변형에서 깨지는 범위와 대안 · 대안마다 맞춘 값 개수

깨지는 범위의 **수치** 를 준 것은 sangros2019 (단일 NMC 입자 · 겹침 ≲ 반경의 0.1 % 까지 Hertz) 뿐. demirtas2021 은 정성 진술과 대안 계보. 이 배치의 대안 넷: Thornton–Ning (sangros2019 · 2020) · 경도 캡 + 평형 겹침 (so2021) · EEPA (yano2026) · 입자별 FE (demirtas2021). MDR · Storåkers · multi-contact 를 직접 쓴 카드는 없다 (demirtas 가 이름만 든다).

- [e] sangros2019_dem_calendering_lib_electrode | 깨지는 범위: 단일 NMC 입자 나노압입에서 항복점 이전 (겹침 ≲ 반경의 0.1 %) 은 Hertz 와 맞고 그 뒤 고압축에서는 Hertz 가 F–d 를 과대평가. 침대에서는 Hertz + bond 가 누른 채 기공을 실측 최종 기공보다 낮게 냄 (물리적으로 불가). 대안 = Thornton–Ning (탄성 Hertz → 항복 p_y → 선형 소성 가지 F = F_y + π·p_y·R*·(δ − δ_y) → 잔류 겹침 δ_R 을 둔 Hertz 제하). 값: 항복비는 단일 입자 측정 1 개 (침대에 맞추지 않음) + bond 2 개 (S_n = S_t 6 × 10¹² N m⁻³ · 파단 강도 2 × 10¹³ N m⁻²) 를 C1 · C4 에 맞추고 C2 · C3 로 검증 · 기준 = 회복 뒤 두께 · 기공 편차 ≤ 15 % | §4.2 (L56–72) · §4.3 (L85) · §4.5 (L104) · §4.8 (L118–120) · 논문 Fig 1 · 2 · 6 · 7 · eq 1–6 | 수치 = stated · 범위 서술 = 표지 없음 (카드 서술) | NMC111 LIB · 20–160 MPa · C4 에서 탄소성도 편차 (모의 0.247 ↔ 실측 0.217 · L131) · 0.1 % 는 NMC (단단 · 취성) 값
- [e] so2021_dem_mold_pressure_assb_coldpress | 대안 = 비선형 Hertz + 평형 겹침 h_eq (F_spring = k_n·(h_ov − h_eq)) + 경도 항복 F_th = 2/3·min(H)·π·h_ov·R_eff. 입력: E · H 는 문헌값 (Table 1) · ν 0.3 · μ 0.5 · e 0.5 는 "This study" · 실제 E 24 GPa 를 연화 없이 씀. 검증: 순수 SE 상대밀도 ↔ Sakuda · σ ↔ Sakuda (f_AM 0) · Nakamura (f_AM 0.742). 수송 쪽 맞춤 1 개: φ_SE^crit = 0.13 (200–400 MPa fit) | §3 (L38–44) · §4 (L52–61) · §6 (L84) | stated | 침대에 맞춘 접촉 값이 몇 개인지 카드에 명시 없음 ("This study" 셋의 근거 · t_rel 값 없음) · 깨지는 범위 서술 없음 · LPS + Si
- [e] yano2026_se_psd_width_ionic_tortuosity_dem | 대안 = EEPA (Thakur 2014): 소성비 λp (쌍마다 문헌값 3 개) · slope exponent 1.5 · tensile exponent 1 · tangential stiff multiplier 0.67 · 일정 끌림 힘 f0 (Hertz–Mindlin + JKR 의 0 겹침 점착력에 맞춤 · 표면에너지 0.1 J/m²) · meso-surface energy 0. 침대에 맞춘 값 0 개 — *"The same contact and material parameters were used for all cases without introducing additional scaling factors. Therefore, the results are intended to provide qualitative insights into mechanical behavior rather than to quantitatively reproduce experimental deformation."* 결과: 400 MPa 상대밀도 DEM 0.722–0.728 ↔ 실험 0.780–0.843 (그림 10) | §4d (L183–195) · §3c (L89–90) · 논문 p.3–4 · 표 3 | [인쇄] · 밀도 = [벡터 판독] | 크기 ×10 · NCM 영률 절반 · 깨지는 범위 서술 없음 · 실험 기준값이 진밀도 규칙에 흔들림
- [e] demirtas2021_mpfem_hollow_sphere_die_compaction | 깨지는 범위 (정성 · 숫자 없음): *"Traditionally DEM has been applied to low relative density and low-stress state analyses of loose powders, e.g., powder flow. More recently, it has been adapted to account for higher relative densities observed during die compaction but not without significant approximations to achieve valid higher relative density results."* 이름만 든 대안: 소성 접촉 법칙 [23 = Storåkers 1997 · 24 = Vu-Quoc 2001] · 고밀도 DEM 처방 [27 Agarwal & Gonzalez 2018 (nonlocal) · 28 Garner, Strong & Zavaliangos 2018 · 29 Gonzalez & Cuitiño 2012 (nonlocal contact) · 30 Harthong 2009 · 31 Tsigginos, Strong & Zavaliangos 2015] — *"However, these approaches require particular calibration methods, which increase the computational cost of DEM."* 저자가 택한 대안 = 입자별 FE (맞춘 값 없음 — E/σ_y 100 · ν 0.3 · μ 0.1 은 선행 연구 기반) | §7-A-1 (L519–550) · §7-A-4 (L592–599) · §4-4 (L311–314) · 논문 p.35 | PDF 글자층 전사 · stated | "DEM 이 무너지는 상대밀도" 숫자는 본문 · 표 · 그림 어디에도 없음 (카드 확인) · 이름만 든 대안들의 맞춘 값 개수는 카드에 없음 · HPMCAS
- [e] benhadjali2026_wip_vs_cup_pressing_assb_cathode_dem | 대안 아님 — Hertz 이력 접촉 + shifted-force LJ 점착 (LAMMPS) 을 재매개변수화 상수로 (정본 alabdali2023 카드의 건조 상태 값: k_n = 100 pg µm⁻¹ µs⁻² = 1 × 10⁵ Pa). 접촉 값은 ref [35] 에서 *"retained without additional fitting"* · 맞춘 것은 건조 상자 높이 (−9.84 % 부과) 와 명목 목표 변위 20 % / 30 % (선정 근거 미기재) | §3-8 (L159–164 · L175) · §4-2 (L222–223) | [인쇄] · k_n = 다른 정본 카드 값 · "같은 값이라면" 은 [추정] (Table S1 [미확인]) | 접촉 소성 · 형상 소성 · 파괴 없음 (L250)
- [e] sangros2020_lib_electrode_dem_mech_elec_ionic | sangros2019 와 같은 Thornton–Ning + bond (식은 1 부에 있음) · 물성식마다 비례상수 1 개 (C_el 0.665 · C_ion 0.534 · C_ad 0.755 · 실측 맞춤) | §4 (L48 · L74) · §3 (L36) | stated | 접촉 법칙이 아니라 균질화식의 맞춤
- [e] yadav2021_lpscl_sieved_psd_impedance_tortuosity · diener2022_roll_gap_springback_calendering · larson2025_hot_pressing_argyrodite_low_stack_pressure_conductivity | 이 카드에 없음 (실험) | — | — | —


### [batch_13] e. 점접촉 법칙이 큰 변형에서 깨지는 범위와 대안 · 대안마다 맞춘 값의 수

큰 변형용 대안 (multi-contact · MDR · EEPA · Thornton–Ning · Storåkers) 을 직접 쓴 카드는 이 배치에 없다 — 계산 카드 넷 모두 접촉 소성 (항복 캡) 이 없는 점접촉 (Granular-Hertz + SJKR · Hertz 류 + bond · Lennard-Jones + JKR · Hertz–Mindlin + bond). 깨지는 범위를 수로 준 것은 zhang2026 카드의 산술 (탄성 Hertz 면압이 NMC 경도의 0.75–2.4 배) 하나이고, 맞춘 값의 수가 적힌 것도 zhang2026 (4 개) 뿐이다.

- [e] zhang2026_xct_dem_cathode_calendering_peel_calibration | 탄성 Hertz 가 깨지는 범위를 카드가 산술로 잼: E* 75.7 GPa 에서 평균 접촉 (7.3 mN · 6–6 µm 쌍) 의 평균 면압 6.4 GPa ≈ 0.75 H · 최대 접촉 (177 mN) 은 16–16 µm 쌍 9.7 GPa · 6–6 µm 쌍 18.6 GPa · 16–3 µm 쌍 20.9 GPa ≈ 1.1–2.4 H (겹침 0.73–1.07 µm) ; 벽 쪽 0.937 µm 겹침은 평균 면압 ≈ 5–12 GPa ; P/D² 로는 접촉력 꼬리가 30 MPa 에서 이미 평판 파괴강도 207 MPa 에 닿고 200 MPa 에서는 수 배–수십 배 | §12 D7 (L540–550) · D7b (L552–569) · §10 L7 (L470) | derived(ours) (stated 평균 힘 + figure-read 최대 힘 + 다른 카드의 H · σ_F) | 논문은 이 한계를 말하지 않음 · H 는 NMC532 · σ_F 는 NMC811 값 · "순위의 방향 감각만, 값 인용 금지" (카드 표기)
- [e] zhang2026_xct_dem_cathode_calendering_peel_calibration | 같은 부류 (LIB 압연 DEM) 의 접촉 법칙 지도: Sangrós 2019 / 2020 = Thornton–Ning (나노압입 보정) + bond · Schreiner 2020 · He 2026 = EEPA · Ngandjong 2021 = GH + SJKR · Lyu 2025 = Hertz 류 + parallel bond · Xu 2023 = LJ + JKR · 이 논문 = Hertz–Mindlin 탄성 + parallel bond ("이 계보에서 가장 단순한 쪽"). 이 논문의 맞춘 값 = 4 개 (bond 탄성률 0.3 GPa · 입자–입자 bond 강도 3.6 × 10⁷ Pa · 반지름 배수 2 (고정) · 입자–Al bond 강도 7.2 × 10⁴ Pa) | §2.1 (L70–85) · §3.2 (L133–137) · §4.6 (L310–313) | stated (값) · 지도는 카드 정리 | 다른 대안들의 맞춘 값 개수는 이 카드에 없음 · 인장 파단력 ∝ 강도 × 배수² 라 강도와 배수는 한 점 보정으로 못 가름 (L296 · L437)
- [e] ngandjong2021_dem_calendering_digital_twin | 접촉 법칙 = Granular-Hertz (식 1) + 단순화 JKR (F = CED × 접촉 면적 · 식 2 · 끊겼다 다시 붙음). GH 힘이 0 이 아니려면 겹침이 있어야 해서 AM 지름을 2 % 키움 (d = 1.02 × d_AM,exp) · 기공은 2 % 를 뺀 뒤 계산. 논문 문장 (카드의 한국어 옮김): "보정 중에 CED 를 높이면 적어도 부분적으로 E 도 높여야 함을 알았다. 그러지 않으면 입자 겹침이 지배적이 되어 물리적 근거를 잃는다" | §4 (L280–292) · §6 (L505) | 식 · 2 % = stated · 인용문 = 카드의 한국어 옮김 | 큰 변형용 대안 (multi-contact · MDR · EEPA 등) 은 이 카드에 없음 · 맞춘 값의 개수는 카드에 명시 없음 (CED 4 개 · E_CBD 가 보정 대상으로 읽힘 · E_AM 200 GPa 는 문헌 100–200 의 상한 · E_Al · E_Steel 은 문헌값)
- [e] xu2023_realistic_am_shape_cgmd_calendering | 접촉 = Lennard-Jones (모든 쌍 · 장거리) + JKR (겹친 쌍): F_n = 4Ea³/(3R) − 2πa²√(4γE/πa) − η_n v_n · 접선 = min(μ_t‖F_n + 6πγR‖, ‖k_t a ξ + …‖) · 분리 뒤 인장 꼬리 3πγR. 점접촉 구의 "형상 불변" 을 푸는 방식 = 입자를 1차 구 응집체로 (γ_내부 10⁶ pg µs⁻² ≈ 1000 J/m² · γ_입자 사이 0) | §4 (L328–339) · §3 (L112) · §4-B (L412–456) | 식 · Table 값 = stated · J/m² 환산 = derived(ours) | 큰 변형용 접촉 법칙 (multi-contact · MDR 등) 은 아님 · 맞춘 값의 개수는 카드에 없음 (Table 1 + S2 전수 공개일 뿐) — 맞춘 것으로 확인되는 것 = 건조 두께를 실험 밀도 · 기공으로 지정 (입력) · 팽창 – 침식 인자 N = 2 를 τ 표적에 맞춤 (자유 인자 1 개)
- [e] xu2023_realistic_am_shape_cgmd_calendering | 같은 그룹의 선행 (Ngandjong 2021 · LIGGGHTS · GH + SJKR) 과 견준 입력의 흔들림: E_AM 200 → 135 GPa · ν_CBD 0.5 → 0.3 (설명 없음) · 입자 마찰 0.001 → 0.5 (500 배) · 반발계수 행이 없어지고 점성 감쇠 η_n0 (CBD 10 · AM 500) 로 · 점착 CED (응력) → γ (에너지 / 면적) · 슬러리 → 건조에서 LJ 우물 ×10⁶ | §4-A (L355–410) | Table 값 = stated · 배수 = derived(ours) | 식이 달라 숫자의 직접 비교는 부분적으로 부당 (카드 표기)
- [e] lyu2025_3d_dem_drying_calendering_lib | 접촉 법칙 = 법선 F = (F)₀ − k_n·Δδ^(3/2) (식 6 · k_n = A·E*/L · 식 14) + 선형 접선 (식 7) + 점성 감쇠 (식 8–9) — 카드 판정 "항복압 (p_y / H) 캡 없음 (Thornton–Ning 아님)". bond: AM = 힘만 전하는 선형 접촉 bond · CBD = 힘 + 굽힘 · 비틀림 모멘트를 전하는 선형 평행 bond (식 15–22 · 파단 응력 σ̄_c · τ̄_c 에서 끊김) · 형성 기준 중심 거리 ≤ λ(R_i + R_j) · λ = 1.67 | §4 (L53–62) | stated (식 · λ) · 캡 없음 판정은 카드 | 큰 변형에서 접촉 법칙이 깨지는 범위 · 대안은 카드에 없음 (두께 −50 % · 기공 22 % 까지 같은 법칙으로 누름) · 맞춘 값의 개수 · 파단 응력 값은 카드에 없음 (입력은 Table 1 · [ref51] 인용으로만 적힘)
- [e] miss2026_insitu_conductivity_porosity_pressure_compaction · miss2026_pressure_tortuosity_composite_cathode_coating | 이 카드들에 없음 (접촉 모델이 없는 실험 논문) | miss2026_insitu §4-7 (L218) · miss2026_pressure §4-3 (L160) | — | —


### [batch_14] e. 점접촉 법칙이 큰 변형에서 깨지는 범위와 대안 · 대안마다 맞춘 값의 수

범위를 수로 준 것 = kakar1967 (구 반지름이 안 자라는 구간 a/R ≤ 0.25 · 접촉끼리 닿는 임계 밀도 — 단 1967 년 기하 이론). 대안의 꼴 = 부피 보존 잘린 구 (kakar1967 · 맞춘 값 0) · 부피 보존 neck + 입자 표면 예산 보정 (nisar2024 · 힘 법칙이 아니라 수송용 면적 · 맞춘 값은 접촉 저항 쪽 2 개) · 평형 겹침 속도식 + 경도 캡 (so2022). multi-contact · MDR · EEPA · Thornton–Ning · Storåkers 를 직접 다룬 카드는 이 배치에 없다 (kakar 카드가 다른 카드로 이어 주는 줄만 있다).

- [e] kakar1967_deformation_theory_hot_pressing | 겹침 원 (구 반지름 고정) 기하가 통하는 범위: *"up to a value of a/R = 0.25, R is approximately equal to R₀ (the initial radius) and for this reason all experimental work was limited to a/R = 0.25"* · 그 뒤 R 급증 (Fig 2: R ≈ 0.620 = R₀ 가 a/R ≈ 0.3 까지 거의 평평 · 0.5 에서 ≈ 0.643–0.656) · 그 구간의 부피 보존 보정 = 면적 +1–7 % (사방) · 능면체 ≤ +11 % | §0 L21 · §3-A L57 · §3-B L82 · §3-C L89–92 · 논문 p.3226 · Fig 2 | 인용문 = stated · Fig 2 = 판독 · 보정 % = 우리 산술 | 단분산 정규 격자 · 납 / 사파이어
- [e] kakar1967_deformation_theory_hot_pressing | 한 입자의 접촉끼리 닿는 임계 단계: 이웃 평면이 닿는 순간 = 단순입방 a = R/√2 · 나머지 a = 0.5R → 그때 밀도 D(R_c) = 96.51 % (단순입방) · 83.51 % (사방) · 96.41 % (능면체) · 93.95 / 99.45 % (체심 1 · 2 단계) · 그 뒤는 다면체로 가는 다른 기하 (모델 밖) | §3-A L54–55 · §4-1 L132 · §4-5 L172 · Table I · 논문 p.3225 | stated | 정규 격자 (무작위 충전 아님) · 능면체 R_c 본문값은 오식으로 보임 (카드 §3-D ③)
- [e] kakar1967_deformation_theory_hot_pressing | 대안의 꼴 = 부피 보존 잘린 구 + 균일 반경 성장: V_p = α(2R² + a²)(R² − a²)^{1/2} − βR³ = (4/3)πR₀³ (식 1) · 1 차식 D − D₀ = (3/2)D₀(a/R)² (식 6) · **맞춘 값 0 개** (순수 기하). 카드 산술: 같은 접근량에서 실제 면 ÷ 겹침 원 c²_KC = 1.008–1.106 (a/R 0.10–0.25) · 1.146–1.345 (a/R 0.40) · 1.263–1.733 (a/R 0.50) · 1 차 꼴 c² ≈ 1 + Z(a/R)²/8 · 우리 평균 a/r_SE 0.30–0.44 에 대응하는 칸 ≈ 1.08–1.46 | §3-A L50 · L59 · §3-C L85–107 | 식 = stated · c² = 우리 산술 · 1 차 꼴 = 우리 유도 | 원문에 c² 없음 (접촉별 접근량 미측정) · 원거리 균일 재분배 가정 · 정규 격자 · 쌓임 의존
- [e] kakar1967_deformation_theory_hot_pressing | 다른 대안과 이어 주는 줄 (카드 표기): Storåkers c² ≈ 1.43 = 이상소성 단일 접촉의 국소 pile-up (밀도 무관) · Arzt 1.27–1.40 (D 0.84–0.90) = 원거리 재분배 · `zunker2024_mdr_contact_model_partI` = 입자별 겉보기 반경 성장 (그 카드: 기하 교차 면적이 δ/R > 0.3 에서 과소) · `martinbouvard2003_dem_composite_cold_compaction` = Storåkers A = 2πc²rh 를 DEM 접촉 면적에 쓴 선례 | §8 L269 · L285–288 | 다른 카드 인용 (우리 판단) | 이 논문의 값이 아님
- [e] nisar2024_dem_effective_electrical_conductivity_sps | 겹침 → 접촉 (neck) 반지름: Coble 식 a = √(2r*h) (h = 겹침) 는 "[36] 에서 Coble 은 고밀도 (큰 overlap) 서 neck 과대평가라 명시 → 기각" → 대안 = 두 입자 소결 기하 + 부피 보존 (겹침 부피를 원통 neck 으로 재분배해 a 결정) | §4 L85–89 · Fig 4 · 식 21 | 표지 없음 (카드 서술) | 과대평가가 시작되는 겹침 값은 카드에 없음 · 소결 neck (가압 접촉 아님) · NiAl
- [e] nisar2024_dem_effective_electrical_conductivity_sps | 다접촉 보정: 두 입자 상호작용만 보는 탓에 고밀도에서 한 입자의 neck 합이 입자 표면을 넘음 → f_i^gbf = Σ_j S_ij^neck / S_i ≤ 1 (식 22–23) 을 넘으면 그 입자의 모든 neck 을 a_ij^corr = α_i·a_ij (식 24) · α_i ≤ 2r_i/√(Σ a_ij²) (식 25) 로 줄임 · 이 보정에 맞춘 값 0 개 · 접촉 저항 쪽 맞춘 값 **2 개** (δ_gb 0.23 µm · ε 0.16 — Sample 3 한 점) | §4 L90–93 · L99–100 | stated (식) | 수송 (전기) 용 면적 보정이지 힘 법칙이 아님 · 기공 0.05–0.216 범위
- [e] so2022_dem_compaction_coated_particles_assb | 대안의 꼴 = 평형 겹침 속도식 + 경도 캡: F_spring = k_n(h_ov − h_eq) · k_n = (4/3)E_eff·h_ov^{1/2}·R_eff^{1/2} · ∂h_eq/∂t = (F_spring − F_th)/(t_rel·k_n) (F > F_th) / 0 (사이) / (F_spring + F_th)/(t_rel·k_n) (F < −F_th) · F_th = min(H_i, H_j)·A_con · 기공 → 0 쪽 보정인자 c_area · k_n 은 MethodsX [31] 참조. Table 1 에서 "This study" 로 적힌 값 = 마찰 0.5 · 반발계수 0.5 · "fit" 으로 적힌 값 = AM primary 1 µm · SE 응집체 / primary 1.5 / 0.5 µm | §3.1 L48–51 · §4.1 L86–94 · 식 1–7 | stated | 점접촉 법칙이 깨지는 겹침 범위는 이 카드에 없음 (동반 MethodsX 카드 소관) · 맞춘 값의 총 개수를 카드가 세지 않음 · t_rel 값 없음 · LPS + NCM
- [e] lee2024_multiphysics_dem_fem_initial_pressure_assb | 대안 아님 — 이력 선형 스프링 (Hertz 아님 · 항복 캡 없음): K_nl,p = E_p·L_par · K_nu = K_nl/ε² · 맞춘 값 표기 없음 | §4.2 L118–126 · 식 3–8 | stated | 큰 변형 범위에 대한 말 없음
- [e] doux2020_stack_pressure_assb | 이 카드에 없음 | — | — | —
- [e] sakuda2013_sulfide_mechanical_property | 이 카드에 없음 | — | — | —
- [e] deysher2022_transport_mechanical_aspects_assb_review | 이 카드에 없음 | — | — | —
- [e] kang2026_intertwined_electrochemo_mechanical_sulfide_assb_review | 이 카드에 없음 | — | — | —


### [batch_15] e. 점접촉 법칙이 큰 변형에서 깨지는 범위와 대안 · 대안마다 맞춘 값의 수

**이 배치에 없음** — 기계 접촉 법칙을 쓴 카드가 없다 (cronk2026 FEM 표에는 "마찰/접촉 없음" · L227).

- [e] chen2011_percolation_micromodel_composite_electrode | 참고 (힘 법칙 아님): 접촉을 기하로만 정의 — 접촉각 θ (예시 29.5° · 자유 파라미터) 로 접촉 둘레 2π·min(r)·sinθ · 면적 π(min(r)·sinθ)² | §3 L67 · §5.2 L118 · L127 | stated | 겹침 · 변형 개념 없음 · SOFC


### [batch_16] e. 점접촉 법칙이 큰 변형에서 깨지는 범위와 대안 · 대안마다 맞춘 값의 수

**이 배치에 없음** — 접촉 법칙을 적은 카드가 없다. DEM 을 쓴 galvezaranda2024 도 접촉 법칙 "미기재" (L168) 이고, 계보 카드 (ngandjong2021) 의 "GH (Granular-Hertz) + SJKR" 이 한 줄 옮겨져 있을 뿐이다 (L182 · 깨지는 범위 · 맞춘 값의 수는 없음).


### [batch_17] e. 점접촉 법칙이 큰 변형에서 깨지는 범위와 대안 · 대안마다 맞춘 값의 수

**이 배치에 없음** — 접촉 법칙을 다룬 카드가 없다 (DEM 을 쓴 카드 0).


### [batch_18] e. 점접촉 법칙이 큰 변형에서 깨지는 범위와 대안 · 대안마다 맞춘 값의 수

**이 배치에 없음** — 접촉 법칙을 다룬 카드가 없다 (DEM 을 쓴 카드 0). nakamura2020 은 같은 비교 (코팅 ↔ 혼합 · 360 MPa) 를 DEM 으로 돌린 카드 (`so2022_dem_compaction_coated_particles_assb`) 를 링크로만 가리킨다 (L16 · L261).


### [batch_19] e. 점접촉 법칙이 큰 변형에서 깨지는 범위 · 대안

- [e] sangros2020_dem_electrical_conductive_paths_assb | 이 논문 접촉 법칙 = Hertz-Mindlin + van der Waals (항복 캡 없음). 카드는 같은 그룹 2019 자매편이 Thornton–Ning 탄소성 (p_y 캡) 을 썼다고 대비만 한다 | §4.2 L66–67 · §7 L148 | stated (법칙 이름) · 카드 풀이 (대비) | 점접촉이 깨지는 겹침 · 밀도 범위, 대안의 맞춘 값 수는 카드에 없음
- 나머지: 해당 없음.


### [batch_20] e. 점접촉 법칙이 큰 변형에서 깨지는 범위 · 대안

대안 (multi-contact · MDR · EEPA · Thornton–Ning · Storåkers) 을 쓴 카드 없음. 각 카드의 접촉 표현만.
- [e] vijay2025_hybrid_cgmd_dl_slurry_microstructure | CGMD 접촉 = LJ 12-6 + granular Hertz (순수 탄성 · 이력 접선 · Coulomb X_µ 0.012–0.015) · 항복 캡 · 잔류 겹침 · 형상 변화 없음 · 카드: "Thornton–Ning/EEPA 류의 접촉 소성조차 없다" · 압연 DEM 접촉법칙은 미보고 | §4-1 L218–222 · §4-3 L247–249 · L237 | stated / 카드 풀이 | 맞춘 값 = FF 계수를 슬러리 밀도 · 점도에 맞춤 (ref [39] PSO 상속 · L226) · Table 1 은 chemistry 마다 12–14 행 (몇 개를 맞췄는지 카드에 없음)
- [e] zhang2026_dryprocess_electrode_architecture_cell_level | CGMD = LJ 12-6 + harmonic 결합 · 각만 · 접촉역학 (Hertz · 마찰 · 소성 · 점착) 없음 · FF 수치 0 개 공개 (유일한 관계 ε(VGCF–PTFE) > ε(PTFE–PTFE)) | §4-1 L554–564 | stated | 실험 정량 보정 0 (L625)
- [e] wang2027_ncm811_effective_bulk_modulus_mapper_dfs_gnn | 접촉 법칙 없음 — 복셀 면 공유 = 완전 결합 · 카드: 같은 기하의 점접촉 망보다 단단한 쪽 | §4-2 L220–223 | [추정] (방향 논증 · 크기 미측정) | 선형 탄성 균질화


### [batch_21] e. 점접촉 법칙이 큰 변형에서 깨지는 범위와 대안 · 맞춘 값 수

대안 (multi-contact · MDR · EEPA · Thornton–Ning · Storåkers) 을 쓴 카드 없음. 각 카드의 접촉 표현과 맞춘 값:
- [e] asylbekov2023_cb_fragmentation_pbe_dem_dry_mixing | Hertz 법선 + Mindlin–Deresiewicz 접선 + SJKR 점착 · 항복 캡 · 소성 접촉 · 입자 파쇄 없음 · CG 100 에서도 자기닮음 때문에 마찰 모델 수정 불필요 (논문 주장) | §4.6 L351–355 · §3.5 L140 · §4.8 L382–383 | stated / 카드 풀이 | 맞춘 값 = μ_static · μ_dynamic · e · Γ_SJKR 네 종을 확대 입자 위에서 보정 (§4.8 L384 · Γ 값은 인용 금지 표지 L130) · Table 1 벽 · 입자 두 열 중 무엇을 맞췄는지 카드에 없음 · 보정에 CNN 사용 · 방법은 "향후 논문" (§6 L499–500)
- [e] frankenberg2024_dem_high_intensity_mixer_assb | Hertz–Mindlin + JKR · 항복 캡 없음 · 비구형성은 rolling friction (linear spring · μ_r 0.2) 으로 대리 · 점착 분말이라 JKR 필수 (저자 강조) | §4.2 L76–78 · §4.5 L107 | stated | 맞춘 값 7 = DAOR 로 μ_r · μ_s · μ_d · Γ_pp (pyDOE 16 시뮬 민감도) + 압축 시험으로 E · ν · e_pp · 그 밖에 충진율 맞춤 ρ_b 750 (실측 701.83) · 보정점 10 min⁻¹ · 검증 5/15/60 min⁻¹ + SAOR 54.21 ↔ 55.58° (§4.6 L114–116)
- [e] duquesnoy2023_ml_multiobjective_manufacturing_optimization | 압연 DEM 접촉 법칙 카드에 없음 ("rigid-ish 강체구 압축" · "CONTACT도 명시 약함") | §4.5 L178 · §7.1 L239 | 카드 풀이 | 맞춘 값 개수 카드에 없음
- [e] zhou2026 · bak2024 · cho2024 | 점접촉 법칙 없음 (연속체 FEM · 복셀 전도 · 실험) | — | — | —


### [batch_22] e. 점접촉 법칙이 큰 변형에서 깨지는 범위와 대안 · 대안마다 맞춘 값 수

큰 변형에서 깨지는 범위를 수치로 준 카드 없음. MDR · EEPA · Thornton–Ning · Storåkers · 다접촉은 이 배치 어느 카드도 다루지 않는다. 관련만:
- [e] hare2026_dem_pept_dry_mixing_nmc622_eirich | Hertz–Mindlin (법선 eq 5 · 접선 eq 6) + JKR (eq 7) · 소성 없음 — 저자: NMC 가 단단해 고속 충돌에서도 소성 없음 · 카드: 이 가정은 비구속 전단 유동에 한해 방어되고 300 MPa 구속 압밀은 Bazzoun · Varkey 가 탄소성 / 다접촉을 도입하는 영역 · 맞춘 값 = Table 3 값 전체가 [85] Lischka & Nirschl 2023 보정 세트 (그중 몇 개를 맞췄는지 카드에 없음) | §4.2 L210–221 · §4.3 L230–236 | stated · 카드 풀이 | eq 6 G* 분모 · eq 7 JKR 둘째 항 γ 누락 = 인쇄 오타 (L216 · L228–229)
- [e] jadidi2023_dem_batch_solid_mixers_review | 분야 표준 팔레트 (Table 4) — Elastic: Hertz · linear spring (자유유동) / JKR · DMT (점착); Inelastic: hysteretic spring (Walton–Braun) / elasto-plastic adhesive (Hare 2015 · Luding 2008 · Pasha 2014 · Thakur 2014) · 식은 생략 · 카드: 우리 hooke/hysteresis + adhesion stiffness = [Free flowing × Inelastic] 칸 + 점착항 | §4.2 L103–116 | stated · 카드 풀이 | 큰 변형 범위 · 맞춘 값 수 서술 없음
- [e] jadidi2023_dem_batch_solid_mixers_review | rolling resistance 세 모델 (A 일정토크 · B 점성 · C 탄소성 spring-dashpot) — [원저 Ai 2011] "Model C 가 가장 적합" | §4.1 L99 | stated | 비구형 대리 (큰 변형 문제 아님)
- [e] galvezaranda2025_paml_vgg16_dem_slurry_drying | 접촉법칙 미기재 (ref [33] 로 미룸) — 카드 §12-2 요약: ref [33] = Lennard-Jones (모든 쌍) + JKR (겹친 쌍) · LAMMPS · COR 없음 (점성 감쇠로 대체) | §4-1 L213 · §12-2 L744–749 | 카드 요약 | 건조 · 소성 없음


### [batch_23] e. 점접촉 법칙이 큰 변형에서 깨지는 범위와 대안 · 대안마다 맞춘 값 수

이 배치에 없음 (DEM 접촉 법칙을 다룬 카드 없음 · MDR · EEPA · Thornton–Ning · Storåkers · 다접촉 0 회).


### [batch_24] e. 점접촉 법칙이 깨지는 범위와 대안 (multi-contact · MDR · EEPA · Thornton–Ning · Storåkers) · 맞춘 값 수

이 배치에 없음 (DEM · 접촉 법칙을 다룬 카드 0 편).


### [batch_25] e. 점접촉 법칙이 큰 변형에서 깨지는 범위와 대안 · 대안마다 맞춘 값 수

- [e] lippke2023_dem_drying_structure_formation_lib | 저자가 Sangrós [23] 를 인용: Hertz–Mindlin 은 NCM622 의 큰 변형 역학을 표현하지 못함 → 건조는 역학이 미미하므로 Hertz–Mindlin 으로 충분 (범위 선언) · 대안 = 같은 그룹 Sangrós 압연 DEM 의 "나노압입 보정 탄소성 접촉 + bond" (맞춘 값 수 카드에 없음) | §3-B L117 · §4.2 L207–210 · §2 계보 표 L78 | stated (저자 명시) · 카드 표 | 깨지는 범위 (겹침 · 상대밀도) 수치 없음
- [e] lischka2025_dem_eirich_intensive_mixer_dry_mixing | 탄성 접촉법칙 이름 없음 (본문에 Hertz · Mindlin 0 회) · JKR 점착 · 소성 · 항복 캡 없음 — 카드: 압밀이 아니라 유동 · 충돌이라 소성 불필요 | §4.2 L148–149 | 카드 판정 | 큰 변형 다루지 않음
- liu2025 · mun2025 · meng2026: 접촉 법칙 없음 (리뷰 · 실험).


### [batch_26] e. 점접촉 법칙이 깨지는 범위와 대안 · 맞춘 값 수

- [e] pfeffer2001_dry_particle_coating_engineered_particulates | Walton 부분 걸쇠 스프링: 적재 N_l = K₁α · 제하 N_u = K₂(α − α₀) · e = √(K₁/K₂) (속도 무관 가정) · α₀ = 유한 소성 변형 + Mindlin–Deresiewicz 단순 접선 (γ ≈ 1/3); 코팅 입자 점착 = Mei 등 확장 JKR (점착력 ∝ 게스트/호스트 크기비) | §3-8 줄 140 · 144 (식 1–4 · p.45 · p.59) | [인쇄] | 큰 변형에서 깨지는 범위 · 맞춘 값 수 · K₁ · K₂ 값 카드에 없음 · Thornton–Yin 1991 [117] 은 목록 인용만 (카드 없음)
- [e] qin2026_bilayer_cathode_cgmd_dem_graded_thick_electrode | LJ + JKR 탄성-점착 · 항복 · 접촉 소성 분기 없음 (카드: Thornton–Ning / EEPA 같은 소성 분기 없음); 선행판 Xu 2023 은 단계마다 LJ 우물을 10⁶ 배 바꿈 (이 논문도 같은지 미확인) | §4.2 줄 278 · §4.3 줄 281–284 | 카드 분류 · [미확인] (SI Table S2) | 맞춘 값 수 [미확인] · 큰 변형 범위 논의 카드에 없음
- [e] sankar2026_fiber_scale_dem_carbon_felt_manufacturing | Hertz 법선 + 점성감쇠 · Hertz-history 접선 → 니들 · 캘린더링 단계에서 Mindlin no-slip 로 전환 (수치 안정성 이유) · k_t = (2/7) k_n · k_n,rf = 2 k_n,ff · 점착 없음 | §4.3 줄 291–305 (식 1–13 · p.8–10) | stated | 섬유–섬유 접촉 (구 사슬) · 전환 영향 미정량 (L7) · 값 [미확인]
- multi-contact · MDR · EEPA · Storåkers: 이 배치에 없음.


### [batch_27] e. 점접촉 법칙이 큰 변형에서 깨지는 범위 · 대안 · 맞춘 값 수

- [e] wet_processing_resolved_am_ssb_cathode_manufacturing | 접촉 = JKR (Hertz + 점착 · 항복 캡 없음) · Thornton–Ning · Storåkers · Luding 같은 소성 분기 없음.  저자: 겹침을 허용하지 않는 force field 는 'setback' · 압축해도 상-상 접촉 면적이 못 자람.  대안 채택 없음.  맞춘 값 개수는 카드에 없음 — Bayesian 이 실제로 움직인 것은 LJ ε (NMC 15.1 → 150 000 → 75 000) 와 CBD 쌍 E · γ · AM/SE 쌍 E · γ · k_t 는 세 단계 불변 | §①-D 줄 392–393 · §①-B 줄 341–345 · 365 | stated (SI · 원문 인용) | 실험 대조 2 점 (슬러리 밀도 · 건조 기공) 모두 보정에 씀
- [e] sun2026_dem_extrusion_recirculation_dry_electrode | 접촉 = Hertz 탄성 + SJKR 점착 + CDT 구름마찰 · 소성 · 본드 · multisphere 없음; 우회 = 점착으로 유사-용융 바인더의 고점성 흉내 (가정 2); 겹침 δ (RDF 1 차 봉우리에서) BC–BC 0.15 µm (반경합의 3.0 %) · BC–AM 2.0 % · AM–AM 0.5 %; 맞춘 값 = E ×1/1000 (선언 · 앵커 없음) · eq 20 의 q = 10 % (파라미터 조정) | §4.2 줄 194–210 · §3 자 줄 172 · §6 줄 284–287 | stated · DERIVED(ours) | RDF 빈 간격 0.05 µm = 분해능 한계 · c_CED 는 SI (n/a)


### [batch_28] e. 점접촉 법칙이 깨지는 범위와 대안 · 맞춘 값 수

multi-contact · MDR · EEPA · Thornton-Ning · Storåkers: 이 배치에 없음.
- [e] dem_mechanical_stresses_ssb_electrode_cycling | 점접촉 = Hertz (GFF) 만 · 대안 없음 · 이 논문 안 맞춘 값 0 (E · ν · 마찰 · COR 는 refs [30,31]) · 큰 변형 범위 논의 없음; 카드 해석: 소성 캡이 없어 일축 응력 과대 가능 | §4.0 줄 139 · §B.5 줄 322 · §9 줄 366 | 카드 서술 · 카드 해석 | —
- (가까운 것) [e] bucci2018_mechanical_instability_interface_delamination | 연속 계면의 cohesive 법칙 (입자 점접촉 아님): G(‖u‖) = F_c(‖u‖ − F_c‖u‖²/(4γ)) · 선형 traction-separation · ‖u‖_R = 2γ/F_c · 맞춘 값 0 (F_c · γ · ‖u‖_R 스윕) | §4.2 줄 126–136 (Eq 8–9) | stated | 입자 접촉 법칙 아님
- (가까운 것) [e] kang2025_toughened_bimodal_nca_lzo | 입계 cohesive zone (두께 0 요소 · bilinear TSL · 혼합모드 d_m · damage D 0 → 1) · 입력 2 개 (강도 100 MPa · G_c 1 J/m² · refs S3 · S4) | §4 줄 166–176 · Table S4 줄 130–131 | stated | 입계 법칙 · 2D


### [batch_29] e. 점접촉 법칙이 큰 변형에서 깨지는 범위와 대안 · 대안마다 맞춘 값 수

- [e] so2021_dem_fabrication_degradation_ductile_particles | 대안 (So 2022 MethodsX 접촉 모델 계열): 비선형 Hertz + 평형 겹침 h_eq (Maxwell 완화 속도 eq 6) + 경도 항복 캡 F_th = 2/3·σ_H·A_con (eq 8) + 융착 (소성 변형한 SE 접촉은 분리 때 인장) + 거칠기 α (A_con = π·h_ov·R_eff·α, eq 9) + 과압밀 게이트 (1 − φ_solid⁴) · 출발점 Tomas [22] · Luding [23] · Storåkers [20] (spring-back) 언급 · **Luding 선형 모델은 낮은 경도 / 탄성 (σ_H/E < 0.01) 에만 유효 → 고체전해질 부적합** | §4.1–4.3 L119–148 · L117 · L125 | stated | 깨지는 범위의 정량 (겹침 · 상대밀도 문턱) 은 카드에 없음 — 과압밀은 국소 고체분율 → 1 일 때로만 적힘 (L135 · L147)
- [e] so2021_dem_fabrication_degradation_ductile_particles | 맞춘 값 수: **α 하나** (0.50 / 0.65 / 0.80 / 1.00 가운데 0.65 · Sakuda 상대밀도 200–500 MPa 에 맞춤) · t_rel 은 임의 (정상상태용 작은 값 · 데이터에 안 맞춤) · σ_H · γ · δ · E 는 문헌 · ν 0.3 · μ 0.5 · e 0.5 는 "This study" · 카드 셈 "α · t_rel · φ_solid⁴ · 융착 인장 — 4 개 보정 / 물리 인자" | Table I L58–68 · §4.7 L172 · Fig 4a | stated | 깨지는 곳: <200 MPa 에서 실험보다 과치밀 (2D · 3D 응집체 미표현, L78 · L194) · α 는 "표면 거칠기 · 2 차 접촉의 1-파라미터 프록시" (L68)
- [e] so2021_dem_fabrication_degradation_ductile_particles | 자매 So 2022 MethodsX 는 같은 목적 (과압밀 방지) 을 h_ov^max = 0.6 R_eff 로 둔다 (여기선 φ_solid⁴ 게이트) | §4.3 L147 | 카드 풀이 | So 2022 원문은 이 카드에서 미확인
- 나머지: 없음 (li2026 리뷰의 모델은 연속체 · 해석 · 위상장 · FE+ML 뿐 L90–91).


### [batch_30] e — 점접촉 법칙이 큰 변형에서 깨지는 범위와 대안

- [e] 이 배치에 없음 — multi-contact · MDR · EEPA · Thornton–Ning · Storåkers 를 다룬 카드는 없다.
- [e] wheatcroft2023_nmc811_secondary_particle_fracture_insitu_sem | 관찰: 원뿔 팁 (R 0.71 µm) 밑 1차입자 압축 · 소성변형 + 약간의 입내 균열 (Fig. 1f) — 카드 해석 "접촉이 순탄성이 아니라는 증거"; Auerbach cone crack 은 관찰되지 않고 입계 지름 분할만 관찰 | §0 (줄 31) · §5 Fig 1 (줄 258) · §7.1 (줄 322) | stated (관찰) · 카드 해석 | 대안 법칙 · 맞춘 값 없음 · 단일 AM 입자


### [batch_31] e — 점접촉 법칙이 큰 변형에서 깨지는 범위와 대안

- [e] boschpadros2014_dem_liggghts_msc_thesis | Hertz 의 가정 = 인장력 없음 · 마찰 없음 · 겹침 ≤ 반경 · 속도가 작을 때 (준정적) 만 유효.  소개된 대안 = JKR (eq 2.10) · DMT (eq 2.11) · 선형 점착 SJKR F = K·A (eq 5.1) — 점착 계열이지 큰 변형 대안 (multi-contact · MDR · EEPA · Thornton-Ning · Storåkers) 은 없음 · 탄소성은 "elasto-plastic models can also be obtained with experiments" 한 줄뿐 · 맞춘 값 0 (데모 임의값) | §4.2 (줄 82 · 84–92) · §4.7 (줄 196–203) · thesis §2.1.1.4 · §2.2.5 · Ch5 | 표지 없음 (식은 원문 전사 · 인용 한 줄) | 비출판 MSc · 정량 검증 0
- [e] chibwe2020_nnsi_segregation_index | Hertz–Mindlin no-slip 탄성 접촉을 "겹침 < 가장 작은 입자 반지름의 1.0 %" (지름 0.5 %) 안에서 씀 — 깨지는 범위 진술이 아니라 운용 상한 · 대안 법칙 없음 · 비구형성은 CDT 구름마찰 (μ_r 0.5) 로 대리 | §4-6 (줄 270–276) | [P] | 소결광 mm 구 · 비점착 · 압밀 없음; 카드는 우리 겹침 (지름의 7–11 % · [우리]) 이 그 예산의 10–20 배라고 적음 (§12-1)
- [e] 그 밖에는 이 배치에 없음.


### [batch_32] e — 점접촉 법칙이 큰 변형에서 깨지는 범위와 대안

- [e] 이 배치에 없음 — 대안 접촉 법칙 (multi-contact · MDR · EEPA · Thornton–Ning · Storåkers) 을 다룬 카드는 없다.
- [e] huang2025_dem_lbm_heat_conduction_composite_cathode | 고전 Hertz–Mindlin–Deresiewicz (점착 · 정전기 없음 · F_n = (4/3)E*R*^½α^{3/2} · r_c = √(αR*)) 를 기공 4.4 % 까지 그대로 씀 — 큰 변형에서 깨지는 범위 논의 없음 · E · ν · μ · COR 값 본문 미기재 (n/a) | §4 (A) (줄 47–51) · §3 (줄 37) | stated (식) · n/a (값) | "항복캡조차 없음" (줄 58) 은 카드 판단


### [batch_33] e — 점접촉 법칙이 큰 변형에서 깨지는 범위 · 대안

이 배치에 없음 (li2007 의 "접촉" = 전기 터널 저항 · 역학 접촉 법칙 아님).


### [batch_34] e — 점접촉 법칙이 큰 변형에서 깨지는 범위와 대안

- [e] nase2001_granular_bond_collision_number_wet_cohesion | 대안 = Thornton 탄–완전소성 법선 접촉 (항복 전 Hertz F_n = k_nα^{3/2} · 항복 뒤 선형 · 제하 = 새 반경 R′) + Walton–Braun 접선 (γ = 1/3 · k_t0 = k_n(1 − ν)/(1 − ν/2)) + 펜듈러 액체 다리. 맞춘 값 = F_y 1 개 (값 [미확인]) · 나머지는 재료값 (E 7.0 × 10¹⁰ Pa · ν 0.25 · ρ 2500 kg/m³). 점접촉이 깨지는 범위 · 다접촉 보정은 말 없음 | §3-1 L57–60 · §3-4 L79 · p.215–216 · p.218 | [인쇄] · [미확인] | mm 유리 흐름 (조밀 압밀 아님)
- 나머지 6 장: 이 배치에 없음.


### [batch_35] e — 점접촉 법칙이 깨지는 범위 · 대안 · 맞춘 값 수

- [e] shenouda2020 | Hertz 접촉 면적 A₀ = πa² = 2πRδ 는 a² = 2Rδ − δ² 에서 δ² 를 버린 근사 (작은 겹침 가정) · 원문은 접촉면 변형을 무시한다고 적음 · Hooke 는 characteristicVelocity 입력 필요 (실험 · 수치 · Hertz 시뮬에서 추정) · SJKR (CED) · JKR · DMT (*"작고 약한 점착 입자의 허용 근사"*) 는 교육용 · 소성 분기 (Thornton–Ning · EEPA) 는 데모에 안 씀.  맞춘 값 = 없음 (안식각 데모는 CED 하나를 4.0–9.5×10⁵ erg/cc 로 훑기만 · 실험 맞춤 아님) | §4 (줄 59–63 · 68) · §5 표 (줄 160–169) · 슬라이드 DEM Contact Models | stated | 금속 분말 흐름 · 큰 변형 범위 수치 없음
- 나머지: 이 배치에 없음.


### [batch_36] e — 점접촉 법칙이 깨지는 범위 · 대안 · 맞춘 값 수

이 배치에 없음.


### [batch_37] e — 점접촉 법칙이 깨지는 범위 · 대안 · 맞춘 값 수

이 배치에 없음 — 기계 접촉 법칙을 쓴 카드가 없다.  (famprikis2019 카드의 DEM 입력 매핑표가 "소성 항복 (EEPA/Thornton–Ning σ_y) — SE 입자: 없음 … ❌ 공백" 이라고 적음 · §6.2 줄 348 — 카드가 만든 번역이지 리뷰 문장이 아니다.)


### [batch_38] e — 점접촉 법칙이 깨지는 범위 · 대안 · 맞춘 값 수

이 배치에 없음 — 기계 접촉 법칙을 쓴 카드가 없다.


### [batch_39] e. 점접촉 법칙이 큰 변형에서 깨지는 범위와 대안

이 배치에 없음.


### [batch_40] e — 점접촉 법칙이 깨지는 범위 · 대안 · 맞춘 값 수

이 배치에 없음 (접촉 법칙 · DEM 이 논문에 없음).


### [layer3] e. 점접촉 법칙이 큰 변형에서 깨지는 범위와 대안 · 맞춘 값 수

- [e] so2021_dem_mold_pressure_assb_coldpress | 실제 E = 24 + 경도 캡 (F_th = 2/3·H·A_con) 으로 연화 없이 상대밀도 0.30 → 0.98 @ 600 MPa — 비교 문서: 항복캡이 우리 18× 연화 역할 · "연화 irreducible" 은 강체 구 본질이 아니라 항복캡이 없는 탓 | §A L354–356 | 표지 없음 | LPS + Si · 맞춘 값 수 이 줄에 없음
- [e] giannis2021_stress_based_multicontact_dem + varkey2026_multicontact_elastoplastic_dem | (묶음) multi-contact F_mc 는 같은 변위에서 힘을 더 크게 (침대를 뻣뻣하게) — 원전 문장 "The new multi-contact approach is able to provide a higher force at a given displacement than the classical DEM" · Fig 7 · 9 = MC-stress 가 최대겹침을 가장 작게 · Varkey SI Fig S1: Thornton–Ning 단독은 5 mm 에서 FEM 9.7 vs 5.7 ×10⁴ N (과소) → F_mc 는 연화의 경쟁자가 아니라 항복캡의 짝 (Varkey = TN + F_mc 조립 레시피) | §A L357–377 | 원전 인용 · 표지 없음 | Giannis 최대 응력 = 유리 45 MPa (300 MPa 의 1/6.7) · porosity · 상대밀도 미보고 · 소재 = 하이드로겔 (23.3 kPa) · 고무 (1.85 MPa) · 유리 (65 GPa) · "ρ > 0.7 에서만 유효" 는 Varkey 의 서술이지 Giannis 것이 아님
- [e] giannis2021_stress_based_multicontact_dem | 다접촉 보정의 크기 환산 ΔF/F = k·β·ν·C·(δ/d) — k = 0.25…1.5 (논문 자신의 정규화 3 종 × branch-vector 2 종 = 6× 모호) · β = 1.65–5.17 (논문 전 범위 · LPSCl 실측 없음) · ν 0.37 · C ≈ 6.5 → pure-SE (δ/d 0.11) +11…+205 % · 복합 (δ/d 0.0175) +2…+33 % | §A L366–374 | "우리 유도, 논문 수치 아님" | 유도는 카드 §7-4 · 논문 검증 범위 밖 (탄성 · 저응력)
- [e] coetzee2017_dem_calibration_review + paulick2015_elastic_particle_properties_dem_review | (묶음) 점접촉 DEM 의 겹침 가드레일: Cleary 0.1–0.5 % · Paulick ≤ 반지름의 1 % · Höhner ≤ 4 % (그 계 한정) — 우리 pure-SE ⟨δ⟩ ≈ 직경의 11–12 % = 반지름의 22–24 % → Paulick 기준의 ~22 배 | §A L555–558 | 표지 없음 | 가드레일은 "속도용 강성 감소" 맥락 (보정용 연화의 기준이 아님 · L556) · ⚠ §F L3461–3466 이 정정: Paulick 1 차 자료는 "1 % of the particle diameter" → 배수는 11–12 배 (§A 본문은 정정 전 서술)
- [e] zunker2024_mdr_contact_model_partI + zunker2024_bulk_elastic_partII + zunker2025_dem_large_deformation_compaction | MDR 접촉 법칙: 법칙 자체의 재료별 보정 0 (정규화 경화곡선 상수 2 개 · 전 재료 공통) — 그러나 DEM 전체를 돌리려면 자유변수 6–8 개 (Y 피팅 · ψ_b 0.08 → 0.5 튜닝 · µ_t 0.7 · µ_t,wall 0.1 · µ_roll 0.6 · t_p 50 · 겹침캡 0.75 · CoR) → "무보정" 인용 금지 · 압력 240 MPa 까지 (타정) | §A L648–653 · L666 | 표지 없음 | MCC (LPSCl 아님) · 파쇄 없음 · porosity / 상대밀도 수치 0 개 · 2 상 불가 (L674 "그들 미해결 제약")
- [e] zunker2024_mdr_contact_model_partI | 구조적 이유: 완전소성 접촉력 F ≈ p_Y(δ)·A_geo(δ) 에는 E 가 없고, 항복캡 없는 선형 접촉은 F ∝ E·δ 라 E 를 낮추는 것 외에 δ 를 키울 방법이 없음 → "18× 연화 = 빠진 항복캡의 대역" | §A L654–656 | 표지 없음 (비교 문서: "인용 가능") | 
- [e] gonzalez2012_nonlocal_contact_confined_granular | 비국소 탄성 접촉 P(g) = n_H (g + g_NL)^{3/2} · g_NL = Σ_i w(P_i, θ_i) — 자유 파라미터 0 (E · ν · R · 접촉각만) · g_NL → 0 이면 정확히 Hertz · Hertz 보다 뻣뻣 (Fig 4 캡션 "behave stiffer than Hertz") · 보정 크기 Δ = (K/2π)√ε + (7K²/24π²)ε · K = (3 − 2ν)/(1 − ν) (E · 크기 무관 · 식 17 / 18) · 검증 = Tatara 1989 고무구 + 자체 FEM (324k 요소) + Zhupanska 정해 | §A L678–687 · L704–707 | 원문 인용 · ν 0.37 대입값 (Δ 6.1 / 14.7 / 21.9 % @ ε 1 / 5 / 10 %) = "derived, 논문 표 아님" · 절단급수라 하한 | 탄성만 ("elastic spheres in the absence of gravitational forces, adhesion or friction") · 정적 · 침대 125 입자 · 실현 1 개 · 배터리 소재 0
- [e] gonzalez2012_nonlocal_contact_confined_granular | Hertz 가 깨지는 밀도: BCC 다이 2 차 접촉 ρ_R 0.780 (Hertz 0.786) · 3 차 0.96 · 정수압 2 차 0.95 vs Hertz 1.04 (물리적으로 불가능 → Hertz 는 2 차 접촉을 못 만듦) · 무질서 침대 Fig 19 축 ρ_R 0.4–0.9 · 0–600 MPa · 재배열 지배 구간에서는 Hertz 와 같고 변형 지배 구간에서 갈라짐 (§4.2) | §A L708–715 | 표지 없음 | 탄성 · E 7 / 19 GPa 유기 제약분말 유사 침대
- [e] gonzalez2012_nonlocal_contact_confined_granular + giannis2021_stress_based_multicontact_dem + varkey2026_multicontact_elastoplastic_dem + zunker2024_mdr_contact_model_partI + zunker2024_bulk_elastic_partII | (묶음 · "층 (2.5) 다중이웃 결합" 행 목록) binary (Hertz · Luding · Thornton–Ning · So) / 변위 기반 해석 비국소 — Gonzalez 2012 (자유변수 0 · O(n̄N_c)) / 변위 기반 MC-strain — Brodu 2015 (γ · O(C²) + 반복) / 응력 기반 MC-stress — Giannis 2021 → Varkey 2026 (β) / 기하 · 부피보존 — Zunker 2024 I + II | §A L720–739 | 표지 없음 | Brodu 2015 는 카드 없음 (Giannis 카드 경유)
- [e] giannis2021_stress_based_multicontact_dem + gonzalez2012_nonlocal_contact_confined_granular | (묶음) 세 정식화가 같은 실험 (Tatara 1989 고무구) 을 각자 복원 — δ/r = 40 % 에서 실험 ≈ 433 vs 고전 DEM ≈ 245 kPa (1.77 배 과소) · MC-strain (γ = 0.55) · MC-stress (β = 1.71) 둘 다 복원 → "그 한 곡선은 셋을 구분하지 못한다 · 구분력은 다입자 · 다배치 예측" | §A L749–752 | Giannis 카드 Fig 4 기록 (≈) | 고무구 1 개 · 탄성 · Gonzalez 는 무질서 침대에 실험 대조 없음
- [e] gonzalez2012_nonlocal_contact_confined_granular + giannis2021_stress_based_multicontact_dem | (묶음) 접촉 결합을 넣으면 연화 배수가 줄지 않고 늘어남: Gonzalez 대입 ε ≈ 11 % · ν 0.37 → Δ ≈ 23 % (하한) → 17.8× → ~22× · Giannis 18× → 20–55× (pure-SE) / 18–24× (복합) → "18× 는 하한" 이 단일 문헌 의존이 아님 | §A L683–692 | "우리 유도" | 둘 다 복합 침대 겹침을 δ/d = 0.0175 로 읽음 — ⟨δ⟩ 0.0739 µm ÷ ~1 µm 은 ≈ 7 % 라 4 배 차 (열린 규약 항목 · L700–703)
- [e] he2026_dem_calendering_inhomogeneity_areal_density | EEPA 탄소성 접촉 + JKR 집전체 (EDEM 2024) 로 NCM622 압연 — 맞춘 값 수 이 줄에 없음 | §A L854–855 | 표지 없음 | 액체 LIB · 롤 (R = 400 mm) 을 평판으로 근사
- [e] vanlew2015_modifying_youngs_modulus_distribution | 입자 실측 → E 절차는 탄성 Hertz 에서만 정의 — 그들 실측 겹침 δ/d ≤ 1.7 % (우리 pure-SE 11–12 % 의 1/7) · 비교 문서: 소성까지 가는 단일입자 시험은 Hertz 대신 MDR 계열 접촉모델로 피팅 | §A L619–632 | 표지 없음 (Eq.(2) 대수) | 세라믹 pebble · 6 MPa
- [e] zunker2024_mdr_contact_model_partI + zunker2024_bulk_elastic_partII + zunker2025_dem_large_deformation_compaction | 층 (2.75) "매개변수 형상 상태": 입자당 겉보기반경 R (스칼라 1) + 접촉당 δ_max → "R 의 구 − 접촉마다 잘린 구관" · 그 상태가 (i) 기존 접촉의 힘을 올리고 (ii) 상대변위 0 인 2 차 접촉을 새로 만들고 (iii) A_free/A_tot < ψ_b 로 벌크탄성 (공극소멸) 을 발동 · 변형 형상을 재구성해 FEM 과 대조 (2025 §5 · 접촉패치 5 개 일치) · 부피부기 ΔV = −ΔV_e · V_geo = (4/3)πR³ − Σ(π/3)δ²(3R − δ) | §C L2130–2155 | 표지 없음 | 못 하는 것: 이방 배럴링 · 비축대칭 유동 · 재료 국소이동 · 오목 프로파일 (실제는 δ_o,max/R_o > 0.15 에서 오목-볼록) · 파쇄 · 내부 응력장 · 고구속에서 구관 교차로 R 성장이 붕괴해 동결 (Part II §4.3.3)
- [e] varkey2026_multicontact_elastoplastic_dem + zunker2024_bulk_elastic_partII | (묶음) Varkey F_mc = 평균장 1 항 (β = 0.5) · 상시 연속 ↔ Zunker F_Bulk = 2 기구 분해 (R 성장 + 공극소멸) + 문턱 스위치 | §C L2156–2159 | 표지 없음 | β 값이 §A 의 Giannis 범위 (1.65–5.17) 와 다름 (논문 · 정규화가 다름)
- [e] alabdali2023_cgmd_wet_manufacturing_ssb_cathode + schreiner2020_dem_calendering_lib + varkey2026_multicontact_elastoplastic_dem + wet_processing_resolved_am_ssb_cathode_manufacturing | (묶음 · 접촉모델 층위) Schreiner EEPA (접촉소성) ≳ Varkey Thornton–Ning (접촉소성) > Weitze JKR (탄성 + 점착 · 형상 resolved) ≳ Alabdali (탄성 + 점착 · 구) — 형상 소성은 넷 다 없음 | §C L2431–2435 | 표지 없음 | Weitze = wet_processing_resolved_am_ssb_cathode_manufacturing (Energy Storage Materials 2024 · 카드 머리로 확인 — 비교 문서에는 slug 없음)
- [e] alabdali2023_cgmd_wet_manufacturing_ssb_cathode | 항복 캡 없는 Hertz 구가 깨지는 범위 (저자 자인): 압연도 30 % 에서 δ_e 정점 (3.27 S/m) 뒤 50 % 에서 1.63 S/m 로 반토막 — "the partial occupation of the volume of CBD particles by other materials due to high pressure, which is a limitation shown by the model" · 저자가 유효구간을 압연도 ~35 % 까지로 좁힘 · Fig 3c 상부 24–28 µm 에서 pore · CBD → 0.03–0.05 · AM → 0.74 | §C L2436–2446 | 원문 인용 | 습식 SSB · 압력 없음 (압연도 축) · 헤드라인 "최적 압연도 ≈ 40 %" 는 정량 인용 금지
- [e] demirtas2021_mpfem_hollow_sphere_die_compaction | DEM 고밀도용 처방 목록 (서론 p.35): 소성 접촉 법칙 [Storåkers 1997 / Vu-Quoc 2001] · 최신 처방 [Agarwal–Gonzalez 2018 · Garner–Zavaliangos 2018 · Gonzalez–Cuitiño 2012 · Harthong 2009 · Tsigginos 2015] 은 "require particular calibration methods, which increase the computational cost of DEM" | §C L2498–2503 | 원문 인용 | DEM 이 무너지는 상대밀도 수치 문턱은 이 논문에 없음 (L2531)
- [e] tovar2026_cold_spray_cathode_composite_dem_plastic_elastic_bond + xu2023_realistic_am_shape_cgmd_calendering | (묶음 · 결합구 응집체로 입자 모양을 바꾸는 DEM) Xu: 1 차구 Ø1.59 µm 평균 62 개 / 입자 · JKR γ_intra ≈ 1000 J/m² (수치 구속) · γ_inter = 0 ↔ Tovar: Ø1 µm 강체 구 2,499 개 / 입자 · 탄소성 가상결합 (σ0 · α) + 격자 종류 (입자 FCC / 기판 단순입방 = 조율 손잡이) — 변형 세기를 정하는 것이 항복응력이 아니라 수치 구속 / 격자 | §C L2082–2092 · L2671–2681 | derived(ours) | LIB · Tovar = 충돌 (압밀 아님) · "소성 표지 ≠ 소성 양"
- [e] nguyen2017_mpm_bpm_deformable_particle_compaction | BPM (강체 1 차입자 응집체) 기각 근거 셋: 문턱 = F0/⟨a0⟩ (수치 매개변수) · 1 차입자 자유 회전 → 입자 간 마찰 미동원 · Φ ≈ 0.93 에서 응집체 내부 공극 오염 (+ 입자당 ≥ 200 1 차입자) | §C L2709 | 표지 없음 | 2D · 학회 4 쪽
- [e] giannis2021_stress_based_multicontact_dem | 다접촉 보정에서 맞춘 값 = β (재료 · 침대마다 1 개 · 논문 보정값 4 개): 비교 문서 재분석 — eq 10 에서 β 와 ν 는 항상 곱으로만 등장 · β·ν = 0.787 (고무 단일 구) / 0.800 (고무 침대) / 0.825 (하이드로겔 침대) / 1.241 (유리) — E 가 23.3 kPa → 65 GPa (2.8 × 10⁶ 배) 변하는 동안 1.58 배 폭 · β 단독의 3.1 배 차 중 2.08 배는 ν (0.5 → 0.24) · 유리 케이스는 입자 17 개 (원통) vs 514-입자 침대 · 논문이 배위수 C 를 한 번도 보고 안 함 → 가설 "β ≈ 0.8/ν" (LPSCl ν 0.37 → β ≈ 2.1–3.4) | §E L2791–2803 | "논문의 주장이 아니라 우리 재분석" (4 점 · 3 재료 · C 미보고) | 탄성 · 저응력
- [e] varkey2026_multicontact_elastoplastic_dem + bazzoun2026_dem_fem_rnm_ionic | (묶음) Varkey E_SE 10.58 · floor 21 / 37 % = "E 강성 → floor" 의 stiffer-SE 데이터점 · Bazzoun RNM (Holm + Kirchhoff) = 같은 물리의 독립 구현 | §E L2824–2827 | 표지 없음 | 
- [e] giannis2021_stress_based_multicontact_dem + so2021_dem_mold_pressure_assb_coldpress + thorntonning1998_adhesive_elastoplastic_contact | (묶음 · 세 처방의 부호 · 자유변수) 18× 연화 / 항복캡 (So H-cap · Thornton–Ning p_y) / 다접촉 — "부호가 맞고 자유변수가 0 인 것은 항복캡뿐" · Giannis 의 β 는 저자 표현 "adjustable dimensionless empirical geometric prefactor … must be carefully calibrated depending on the type of the material" = 1-파라미터 보정 (유도 아님 · FEM 유도는 outlook) · 구조 차이: β 는 별도 항에 격리되고 E · ν 는 실측값 그대로 ↔ 연화는 물성 자리를 덮어써 하위 계산 (접촉반경 · k_n · k_t · 파속 · timestep) 을 오염 | §F L3542–3549 | 원문 인용 | 
- [e] giannis2021_stress_based_multicontact_dem | 구현 · 비용: 원전은 LIGGGHTS 에 구현 (부록에 2-pass pseudo-code 공개) · Σ l⊗f = `compute stress/atom` (per-atom virial) · 비용 classical 대비 5.7–6.4 배 (514 입자 실측) | §F L3538–3541 | 표지 없음 | V_p 로 안 나눔 · 부호 규약 확인 필요
- [e] martinbouvard2003_dem_composite_cold_compaction + storakers1997_similarity_inelastic_contact | Storåkers 소성 접촉면적 A = 2πc(m)²rh (Martin–Bouvard · c(m) 0.5 → 1.45) · Martin–Bouvard truncated sphere = 형상 유동 없음 | §F L3550–3552 | 표지 없음 | 
- [e] paulick2015_elastic_particle_properties_dem_review + coetzee2017_dem_calibration_review | (정정 · 겹침 가드레일) Paulick 권고는 1 차 자료 두 곳 모두 "1 % of the particle diameter" (§4 p.75 · §5 p.75) — 반지름이 아님 → 우리 pure-SE 겹침은 그 11–12 배 (22–24 배 아님) · 반지름으로 말한 것은 Cleary & Hoyer "평균 0.6 % of radius" · Table 3: 평균 0.6 % 일 때 최대 15 % (25 배 차) · 리뷰는 "maximum overlap … or the average overlap" 을 둘 다 쓰라 함 | §F L3458–3466 | 원문 인용 | §A L555–557 의 "반지름의 1 % · ~22 배" 는 이 정정 전 서술 (비교 문서 문제 절)
- [e] paulick2015_elastic_particle_properties_dem_review | 봉투계산 (단분산 · Hertz · Z = 6 · φ = 0.64 · ν = 0.30 · 300 MPa): 실물 E = 24 GPa 로도 δ/d ≈ 7.6 % · 1 % 를 지키려면 E ≈ 500 GPa → "탄성-구 DEM 으로 300 MPa 를 누르는 것 자체가 원리적으로 가드레일을 못 지킨다" · 탈출구 = 항복캡 접촉 / MPM | §F L3467–3471 | "order-of-magnitude 전용" (우리 봉투계산) | 
- [e] zunker2024_mdr_contact_model_partI | 무차원 보고 규약 F/(E R_o²) · δ_o/R_o · p̄/Y · A_C/(πR_o²) · V/V_o · 위상 페널티 발동 문턱 (동일크기 삼중항) δ/R > 0.30 (우리 0.15–0.22) · 점착 유효조건 2a/r_Ip ≈ 1.9 | §F L3767–3777 | DERIVED | 
- [e] tovar2026_cold_spray_cathode_composite_dem_plastic_elastic_bond + wheatcroft2023_nmc811_secondary_particle_fracture_insitu_sem | 결합구 응집체 DEM (Potyondy–Cundall 결합 파단) 은 입자 분할 (파편) 을 실제로 냄 — 단 그 설정은 NMC 강도 / 항복 = 860 / 9.3 MPa ≈ 92 라 식대로면 법선 파단 불가 (σ_b^max ≤ ≈ 27 MPa) | §F L3968 | "우리 산수" | 냉간분무 충돌



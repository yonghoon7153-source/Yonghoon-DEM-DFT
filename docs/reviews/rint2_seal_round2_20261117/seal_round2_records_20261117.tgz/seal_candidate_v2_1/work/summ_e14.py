"""게이트 셋 원 출력 셋 → 리포 사본 요약 (머리 · rc · 끝 PASS 4 줄 · FAIL 줄 · 요약 줄 · real) — v2 e14 와 같은 꼴.  argv: <출력> <원 출력 …>"""
import re, sys
out, srcs = sys.argv[1], sys.argv[2:]
res = []
for f in srcs:
    L = open(f, encoding='utf-8').read().split('\n')
    pas = [x for x in L if x.startswith('  PASS')]
    keep = [x for x in L if x.startswith('#') or x.startswith('rc=') or x.startswith('  FAIL') or re.match(r'^(\d+ PASS|test_ca_ext_z3:|real)', x)]
    res += keep[:1] + pas[-4:] + keep[1:] + [f'(요약 · PASS 줄 {len(pas)} · FAIL 줄 {sum(x.startswith("  FAIL") for x in L)} · 원 출력 {len(L)} 줄 = scratch evidence/raw/)', '']
open(out, 'w', encoding='utf-8').write('\n'.join(res))

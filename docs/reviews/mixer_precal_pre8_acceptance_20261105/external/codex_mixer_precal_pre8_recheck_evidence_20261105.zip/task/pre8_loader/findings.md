# PRE8-02 독립 적대 재확인

대상 핀: `ec484c2719d6a444214ddc9c48fe683a7735688b`.

판정: **PRE8-02 결속 보완에 한해 수용 가능. 새 결함 또는 재현되는 잔여 반례 없음.** 전체 게이트·실제 실행·연구·등록·배포·원장 종결 판단은 하지 않았다. PRE8-01 및 문서 경계는 다른 검토 담당 범위다.

`REQUEST.md`, observer와 8개 연구 의존 모듈, 제출 상주 source-boundary 시험, 원 외부 `probe_observe_binding.py`, 제출 내부 source probe를 읽었다. 제출 탐침의 판정을 단순 재사용하지 않고 별도 `probe_loader.py`를 작성하여 12개 독립 실행 관측을 확인했다. 결과는 `probe_results.json`의 `passed: true`, `probe_count: 12`, `input_sources_unchanged: true`이다. 소스 복제에 쓴 입력 10파일의 전후 SHA-256이 모두 같다.

| 독립 관측 | 결과 |
|---|---|
| 원 외부 반례: import 후 analyse 진입 전 cell_stats 첫 줄에 raising sentinel 삽입 | `TECH`, `bound source changed: measure_mixing_index`; contact/mixing/counts/reference_counts 전부 제거. 기록 해시는 import 때의 원본 `4375ec56…` 유지 |
| 위와 동일하게 바뀐 source를 새 프로세스에서 실행 | 새 해시 `b0de7b6d…` 기록, 실제 `INDEPENDENT_PRE8_SOURCE_SENTINEL` 도달 후 `TECH`·값 제거 |
| timestamp pyc를 만든 뒤 동일 크기·동일 mtime로 OLD→NEW 변경하고 canonical 모듈을 먼저 import | canonical은 OLD, private와 실제 cell_stats 결과는 NEW. canonical 객체 유지, private 객체 분리, 기록 SHA와 현재 NEW bytes 일치 |
| 8개 canonical 모듈을 빈 stale 객체로 미리 등록 | 실제 3원자 관측 OK; contact/mixing/bed/prepare의 함수 별칭 6개 모두 private registry 결속 |
| 위 stale 상태에서 실제 generator U/C 정적 자료를 만들어 `diff_d2_decks`의 지연 import 실행 | 실제 readback/diff PASS, canonical 객체 불변. 결과값 mock 없음 |
| 실제 `_generate('PRECAL_E0')` 중 generator 디스크 원문만 변경 | `deck_meta`의 generator_sha256은 고정 bytes 해시. 디스크와 다르지만 생성 deck·meta는 전후 동일. 변경 중 analyse는 TECH·값 제거, 복구 후 OK |
| 최초 prepare 소스 부재, contact SyntaxError, contact RuntimeError 각 1개 | contact 전역이 아직 없는 상태에서 정상 TECH 반환·값 제거; contact 예외 클래스 참조로 인한 2차 예외 없음 |
| observer의 같은 mtime·크기 stale pyc + 의미 코드 변경 | 자기 code 동등성 검사에서 bootstrap TECH·값 제거 |
| observer의 같은 mtime·크기 stale pyc + 주석만 변경 | code 동등성 통과, 현재 주석 bytes 해시 기록, 실제 소형 관측 OK. 역사적 주석 원문 유일 복원과 구별되는 명시 경계 확인 |
| `_load` 반환 직후 및 실제 `cell_stats` 진입 중 의존 소스 변경 각 1개 | 모두 TECH·모든 값 제거 |

테스트 경계: Python 3.12.14 / NumPy 2.5.3 / SciPy 1.16.3, `-I -B -X utf8`, sys.path 명시. 관측 시험은 제출의 3원자 디스크 fixture를 사용하며 `validate_case`만 명시적으로 mock한다. dump parser, frame plan, contact, cell_stats, 고정 소스 검증은 실제 코드다. 프로파일 콜백은 복제본 파일 변경 시점만 정한다. 지연 import와 generator 자기 소스 읽기는 실제 in-memory generator/readback를 별도로 실행했다. 이는 100000입자 관측 양성 전체경로·물리·통계 자격을 시험했다는 뜻이 아니다. 입력 원본을 수정하거나 DEM/원격호스트/실제 연구를 실행하지 않았다.

초기 실행의 fixture 8개는 Windows 기본 임시폴더 접근 문제 때문에 대상 관측에 진입하기 전에 중단되었다. 기록은 `initial_environment_failure.json`에 보존했다. 탐침의 `tempfile.tempdir`만 허용된 scratch 하위로 정한 최종 실행에서 12/12 모두 성공했다. 이는 제품 소스 수정이 아니다.

남는 경계: 이 검토는 고정된 연구 소스 집합과 실제 사용 경로의 결속을 확인한다. 임의 런타임 monkeypatch·악성 Python 객체·모든 순간의 파일 변동 추적이나 모든 외부 라이브러리 출처를 보증하지 않는다. observer 자기 검사는 명세대로 기록 bytes의 compile code 동등성이다. 전체 HOLD와 기존 외부 판정의 별도 경계는 유지한다.

"""Saved immutable GitHub responses and package bytes; no remote execution."""
from pathlib import Path
import hashlib,json
ROOT=Path(__file__).resolve().parent.parent
P=ROOT/'package'
manifest=json.loads((P/'SNAPSHOT_MANIFEST.json').read_text(encoding='utf8'))
commit=json.loads((ROOT/'evidence/github_commit_metadata.json').read_text(encoding='utf8'))
remote=json.loads((ROOT/'evidence/remote_existing_sources.json').read_text(encoding='utf8'))
added={f['filename']:f['sha'] for f in commit['files']}
raw={r['path']:r['response']['structuredContent']['content'].encode('utf8') for r in remote}
def blob(b):return hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
rows=[]
for e in manifest['entries']:
 if e['path'] in added: actual=added[e['path']];via='pinned_commit_file_blob'
 else:
  b=raw[e['path']];assert b==(P/e['path']).read_bytes(),e['path']
  actual=blob(b);via='fixed_pin_raw_content'
 assert actual==e['git_blob'],e['path']
 rows.append({'path':e['path'],'match':True,'via':via})
print(json.dumps({'pin':manifest['pin'],'snapshot':rows,'source_files_executed':False},indent=2))

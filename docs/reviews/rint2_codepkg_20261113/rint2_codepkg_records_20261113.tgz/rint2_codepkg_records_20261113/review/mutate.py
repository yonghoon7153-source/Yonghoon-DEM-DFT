"""변이 하네스 (리뷰어 것) — 하드링크 사본 work/mut 에서 파일 하나를 변이 판으로 바꿔 끼우고 시험을 돌린 뒤 원래 링크로 되돌린다."""
import os, shutil, subprocess, sys, json, time
RV = os.path.dirname(os.path.abspath(__file__))
NEW, MUT = os.path.join(RV, 'work', 'new'), os.path.join(RV, 'work', 'mut')
GD = subprocess.run(['git', '-C', '/home/user/rint-codepkg', 'rev-parse', '--absolute-git-dir'], capture_output=True, text=True).stdout.strip()

def apply(rel, old, new, count=1):
    src = os.path.join(NEW, rel); dst = os.path.join(MUT, rel)
    s = open(dst, encoding='utf-8').read()   # ★ 고침: 같은 파일 두 번째 고침이 첫 고침을 덮지 않게 (사본에서 읽음)
    n = s.count(old)
    if n != count:
        raise SystemExit(f'변이 자리 {rel}: {n} 곳 (기대 {count}) — {old[:60]!r}')
    tmp = dst + '.mut'
    with open(tmp, 'w', encoding='utf-8') as f:
        f.write(s.replace(old, new))
    shutil.copymode(src, tmp)
    os.replace(tmp, dst)          # 하드링크 끊음 (원본 new/ 그대로)

def restore(rel):
    dst = os.path.join(MUT, rel)
    os.remove(dst)
    os.link(os.path.join(NEW, rel), dst)

def run(cmd, env_extra=None, timeout=1200):
    env = dict(os.environ, PYTHONDONTWRITEBYTECODE='1', TMPDIR=os.path.join(RV, 'work', 'tmpd'), **(env_extra or {}))
    t0 = time.time()
    p = subprocess.run(cmd, cwd=MUT, env=env, capture_output=True, text=True, timeout=timeout)
    out = p.stdout + p.stderr
    fails = [l.strip()[6:90] for l in out.splitlines() if l.strip().startswith('FAIL ')]
    return p.returncode, fails, round(time.time() - t0, 1), out

def main():
    muts = json.load(open(sys.argv[1], encoding='utf-8'))
    only = set(sys.argv[2:])
    res = []
    for m in muts:
        if only and m['id'] not in only:
            continue
        for e in m['edits']:
            apply(e['file'], e['old'], e['new'], e.get('count', 1))
        try:
            env = {'GIT_DIR': GD} if m.get('git') else None
            rc, fails, dt, out = run(m['cmd'], env)
        finally:
            for e in m['edits']:
                restore(e['file'])
        caught = rc != 0 and len(fails) > 0
        res.append({'id': m['id'], 'what': m['what'], 'caught': caught, 'rc': rc, 'n_fail': len(fails), 'fails': fails[:4], 'sec': dt})
        print(json.dumps(res[-1], ensure_ascii=False), flush=True)
        if not caught:
            open(os.path.join(RV, f'mut_{m["id"]}.out'), 'w').write(out[-6000:])
    json.dump(res, open(os.path.join(RV, 'mut_results_' + os.path.basename(sys.argv[1]) + ('_' + '_'.join(sorted(only)) if only else '')), 'w'), ensure_ascii=False, indent=1)

if __name__ == '__main__':
    main()

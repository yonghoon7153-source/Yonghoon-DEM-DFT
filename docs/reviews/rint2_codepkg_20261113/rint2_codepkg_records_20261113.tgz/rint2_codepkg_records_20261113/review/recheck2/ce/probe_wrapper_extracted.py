# -*- coding: utf-8 -*-
"""S0 stage 1 wrapper - measures the carbon-junction registry store (scripts/cjunc_store.py) on the real bed (v2 2026-11-12, RCP-04 / RCP2-04).

    python3 s0_store_probe.py <log dir> <store dir (new, empty, 0755, this user)> <worktree>/scripts/ca_s0_census.py --stage 1 --kit <kit> --out <new dir>

What it does: wraps carbon_junction.cjunc_registry (stage 1 builds the registry once, junction census).  Right after the
registry is built, in the same process:
  1 encode_strict (is the registry inside the store format, time)
  2 Store.get_or_build with build = return the registry just built -> encode, write, re-read check before publish (status, time, bytes)
  3 a NEW Store, get_or_build again with build = raise (must be a hit, read time)
  4 read registry vs built registry: strict digest and registry_fp
  5 RSS from /proc/self/status (VmRSS, VmHWM; VmHWM is reset before step 2 so it covers steps 2-4 only)
-> <log dir>/store_probe.json and one stderr line '[store-probe] ...'.  S0 gets back THE SAME registry object it built (the read copy
is dropped) - S0 report, plan and arrays are the same as without the wrapper (only the elapsed_s field differs; checked on the S0
test fixture kit).  If the measurement fails (exception, memory) S0 still continues and the reason is recorded.  No sigma, no solve.
The record holds no absolute path and no machine identifier (store dir = folder name only).
cjunc_store is imported BEFORE carbon_junction (as in the payload): its run-start code column (cjunc_store._START, RCP2-01) is taken
before the registry modules load; the record keeps the preloaded list, the start error and code_drift() at each call (all must be
empty for the store to write).
Stage 1 registry = s_min not registered (None, every self candidate) - same or more instances than an R arm registry (sealed s_min):
size and time are a conservative estimate.  Python 3.8 compatible.
"""
import gc
import hashlib
import json
import os
import runpy
import sys
import time

TOOL = 's0_store_probe v2 (2026-11-12 RCP-04 / RCP2-04)'


def _status():
    out = {}
    try:
        with open('/proc/self/status', encoding='ascii', errors='replace') as f:
            for ln in f:
                k, _, v = ln.partition(':')
                if k in ('VmRSS', 'VmHWM'):
                    out[k] = int(v.split()[0])
    except OSError:
        pass
    return out


def _reset_hwm():
    try:
        with open('/proc/self/clear_refs', 'w') as f:
            f.write('5')
        return True
    except OSError:
        return False


def _sha(path):
    h = hashlib.sha256()
    with open(path, 'rb') as f:
        for b in iter(lambda: f.read(1 << 20), b''):
            h.update(b)
    return h.hexdigest()


def main():
    if len(sys.argv) < 4:
        print(__doc__, file=sys.stderr)
        return 2
    log_dir, store_dir, script = os.path.abspath(sys.argv[1]), os.path.abspath(sys.argv[2]), os.path.abspath(sys.argv[3])
    os.makedirs(log_dir, exist_ok=True)
    rec_path = os.path.join(log_dir, 'store_probe.json')
    sys.path.insert(0, os.path.dirname(script))
    import cjunc_store as CS
    import numpy as np
    import scipy
    import carbon_junction as CJ
    st0 = getattr(CS, '_START', None) or {}
    head = {'tool': TOOL, 'python': sys.version.split()[0], 'numpy': np.__version__, 'scipy': scipy.__version__,
            'store_dir_name': os.path.basename(store_dir.rstrip('/')),
            'module_sha256': {os.path.basename(m.__file__): _sha(m.__file__) for m in (CJ, CS)},
            'store_start': {'code': st0.get('code'), 'preloaded': st0.get('preloaded'), 'error': st0.get('error')}}
    orig = CJ.cjunc_registry
    calls = []

    def save():
        with open(rec_path, 'w', encoding='utf-8') as f:
            json.dump(dict(head, calls=calls), f, ensure_ascii=False, indent=1)

    def wrapped(sid, box_lo, vox, add_pts, add_phase, add_fid, add_kind, **thr):
        t0 = time.time()
        reg = orig(sid, box_lo, vox, add_pts, add_phase, add_fid, add_kind, **thr)
        rec = {'call': len(calls) + 1, 'seconds_build': round(time.time() - t0, 3), 'thresholds': {k: repr(thr[k]) for k in sorted(thr)},
               'n_instances': None, 'encode': None, 'write': None, 'read': None, 'same': None, 'rss_kb': {}, 'hwm_reset': None,
               'store_files': None, 'code_drift': None, 'error': None}
        calls.append(rec)
        try:
            rec['n_instances'] = int(len(reg['instances']['fi']))
            rec['rss_kb']['before'] = _status()
            rec['hwm_reset'] = _reset_hwm()
            t1 = time.time()
            try:
                strict, skel, arrays = CS.encode_strict(reg)
                rec['encode'] = {'ok': True, 'seconds': round(time.time() - t1, 3), 'n_arrays': len(arrays), 'skeleton_bytes': len(skel),
                                 'array_bytes': int(sum(int(a.nbytes) for a in arrays))}
            except CS.Unsupported as e:
                strict, skel, arrays = None, None, ()
                rec['encode'] = {'ok': False, 'why': ('Unsupported: ' + str(e))[:300], 'seconds': round(time.time() - t1, 3)}
            del skel, arrays
            kw = dict(sid=sid, lo=box_lo, vox=vox, pts=add_pts, phase=add_phase, fid=add_fid, kind=add_kind, thresholds=thr)
            st1 = CS.Store(store_dir)
            rec['store_machine_id_read'] = st1.machine is not None
            _r1, o1 = st1.get_or_build(lambda: reg, **kw)
            rec['write'] = {k: o1.get(k) for k in ('status', 'why', 'file', 'seconds_write', 'bytes')}
            rec['rss_kb']['after_write'] = _status()
            del _r1, st1

            def must_not_build():
                raise RuntimeError('store probe: expected a hit but the build function was called')
            got = None
            try:
                got, o2 = CS.Store(store_dir).get_or_build(must_not_build, **kw)
                rec['read'] = {k: o2.get(k) for k in ('status', 'why', 'seconds_read', 'bytes')}
            except Exception as e:                         # noqa: BLE001 - record only (S0 continues)
                rec['read'] = {'status': 'error', 'why': (type(e).__name__ + ': ' + str(e))[:300]}
            rec['rss_kb']['after_read'] = _status()
            if got is not None and strict is not None:
                rec['same'] = {'strict': CS.strict_digest(got) == strict, 'registry_fp': CJ.registry_fp(got) == reg['fp']['registry'],
                               'object_is_new': got is not reg}
            del got
            rec['store_files'] = sorted(os.listdir(store_dir))
            rec['code_drift'] = CS.code_drift()
        except BaseException as e:                         # noqa: BLE001 - MemoryError too; S0 continues (KeyboardInterrupt re-raised)
            if isinstance(e, KeyboardInterrupt):
                raise
            rec['error'] = (type(e).__name__ + ': ' + str(e))[:400]
        finally:
            gc.collect()
            rec['rss_kb']['after_gc'] = _status()
            save()
            w, r, en = rec.get('write') or {}, rec.get('read') or {}, rec.get('encode') or {}
            print('[store-probe] instances {} - build {} s - encode {} s ({}) - write {} {} s {} B - read {} {} s - same {} - VmHWM(2-4) {} kB'
                  ' - error {}'.format(rec.get('n_instances'), rec['seconds_build'], en.get('seconds'), en.get('ok'), w.get('status'),
                                       w.get('seconds_write'), w.get('bytes'), r.get('status'), r.get('seconds_read'), rec.get('same'),
                                       (rec['rss_kb'].get('after_read') or {}).get('VmHWM'), rec.get('error')),
                  file=sys.stderr, flush=True)
        return reg
    CJ.cjunc_registry = wrapped
    save()
    sys.argv = sys.argv[3:]
    runpy.run_path(script, run_name='__main__')
    return 0


if __name__ == '__main__':
    sys.exit(main())

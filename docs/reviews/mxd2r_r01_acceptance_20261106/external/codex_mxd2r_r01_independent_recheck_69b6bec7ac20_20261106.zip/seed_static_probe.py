import ast, hashlib, json, math
from pathlib import Path
root=Path(__file__).resolve().parent
source=root/'package/scripts/mixer_deck_readback.py'
raw=source.read_bytes(); tree=ast.parse(raw.decode('utf8'))
names={'_d2_need','_d2_int_token','_d2_next_prime','_d2_insert_seed'}
ns={'math':math,'D2_SEED_MAX':2147483647}
subset=ast.Module(body=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name in names],type_ignores=[])
exec(compile(subset,str(source),'exec'),ns)
def trial_prime(n):
 if n<2:return False
 for d in range(2,math.isqrt(n)+1):
  if n%d==0:return False
 return True
mismatches=[]
values=list(range(1,10001))+[2147483629,2147483646,2147483647,2147483648,2147483659]
for n in values:
 expected=1<=n<=2147483647 and trial_prime(n)
 try:got=ns['_d2_insert_seed'](str(n),'synthetic');ok=True
 except ValueError:ok=False
 if ok!=expected:mismatches.append(n)
lex=[]
for token in ['0','-1','+2','02','2.0','2e0','2_0',' 2','2 ','２','٢','2147483648','2147483659']:
 try: result=ns['_d2_insert_seed'](token,'insB')
 except ValueError as ex:result=str(ex)
 lex.append({'token':token,'result':result})
original=ns['_d2_next_prime'];calls=[]
def sentinel(n):
 calls.append(n);raise RuntimeError('prime reached')
ns['_d2_next_prime']=sentinel
order=[]
for token in ['0','-1','2147483648','2147483659','2']:
 calls.clear()
 try:ns['_d2_insert_seed'](token,'insB');status='accepted'
 except Exception as ex:status=type(ex).__name__+': '+str(ex)
 order.append({'token':token,'prime_calls':list(calls),'result':status})
result={'source_sha256':hashlib.sha256(raw).hexdigest(),'method':'actual four function AST nodes compiled, independent trial division oracle; no deck/host/simulation execution','integer_cases':len(values),'mismatches':mismatches,'lexical':lex,'order':order}
(root/'seed_static_probe.json').write_text(json.dumps(result,indent=2,ensure_ascii=False),encoding='utf8')
print(json.dumps({'integer_cases':len(values),'mismatches':mismatches,'bounds_order':order},ensure_ascii=False))

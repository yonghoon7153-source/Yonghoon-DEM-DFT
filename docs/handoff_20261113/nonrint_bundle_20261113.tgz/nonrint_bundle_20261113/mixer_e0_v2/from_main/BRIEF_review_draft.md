# 믹서 E0 자격 pilot 한 팔 — 등록 초안 내부 반박 리뷰 (초안 단계 · 독립 조수 · Codex 아님)

너는 독립 반박 리뷰어다.  쓴 사람의 결론을 믿지 말고 원천 (리포 파일 · 받은 메타) 과 한 줄씩 대조한다.  읽기 · 산술 · 작은 재현만 한다.

## 대상 (초안 · 봉인 전)

- 등록 초안 = `<SCRATCH>` (348 줄)
- 기준 표 = 같은 폴더 `baseline_table.md` (179 줄)
- 원천 = 본 리포 `/home/user/Yonghoon-DEM-DFT` (읽기만) — 초안 §14 근거 목록의 파일들 · 특히 받은 메타 `docs/data/mixer_e0_meta_ibb_20261110/` (README · out/) · first8 `docs/reviews/mixer_first8_launch_preparation_20261106/` · 계획 `docs/reviews/nonrint_first_link_20261109/mixer_ibb_fixed_qualification_plan.md` · `docs/reviews/nonrint_approved_preparation_20261109/mixer_ibb_qualification_receipt_plan.md` · DEV 기록 `docs/data/mixer_highbo_dev_decks_20260930_v26/` · 코드 `scripts/mixer_precal_observe.py` · `scripts/mixer_stage_gate.py`.
- ⚠ 계획 문서 `docs/reviews/mixer_qualification_plan_20261110.md` 는 원격 가지 판이라 본 리포에 없을 수 있다 — 없으면 "못 봄" 으로 적고 넘어간다 (fetch 하지 않는다).

## 이번 범위 (초안 §12 의 14 항목 가운데 초안 단계에서 볼 수 있는 것)

| # | 볼 것 |
|---|---|
| A (§12-1 · §7-3) | 관측기 로그 계약에 같은 빌드의 실제 꼴 줄 (`docs/data/mixer_highbo_devu_prelim_20261006/exact_runs/exact_LU212_settled/log.exact` · `docs/data/kg50_d07_end_20261105/` 의 두 로그) 을 넣었을 때 "관측 OK" 가 나올 수 있는지 — 초안의 관찰 (나올 수 없어 보인다) 을 독립으로 재현 · 반증.  덤프 머리 등 다른 실제 형식도 같은 식으로.  ⚠ 관측기를 리포 밖 새 폴더 사본에서 import 해 함수만 부른다 · 리포에 쓰지 않는다 |
| B (§12-3 · §4) | walltime 산술 — 시작 · 끝 시각 읽는 법 · step 수 · 배수 · 다른 덱 속도를 pilot 에 옮겨도 되는가 · Q1 권고 (1-00:00:00 · 여유 4.9 배) 의 근거 |
| C (§12-4 · §5) | 디스크 산술 — 폭 24 · 프레임 수 · 체크포인트 · 1.10 배 · 상한 조건 셋 · Lustre 집계 여유 ↔ OST 여유 · Q2 권고 |
| D (§12-5 · §6 · §7) | STOP 수치 (S5 의 30 분 · S6 "입자 소실") 와 통과 / 실패 / 기술 실패의 뜻이 계획 문서 범위 안인가 — 새 기준 · 새 문턱을 만들지 않았는지 |
| E (§12-2) | 경로 꼴 — HOME 이 심볼릭 링크를 지나는데 가드는 풀린 경로와 대조한다 · 계획의 정본 root 문자열은 로그인 꼴 — 초안의 관찰 [관찰] 이 코드 줄로 맞는지 |
| F (§12-13) | 원장 (`docs/reviews/findings.json`) 의 열린 믹서 항목 (`MIX-11` · `MXD2-01` · `SELF-62` · `MLA-01`–`03` · `MIP-01`) 이 이 팔에 닿는지 |
| G | 초안의 숫자 전부 (줄 번호를 단 인용) 를 원천과 대조 — 틀린 줄 번호 · 틀린 숫자 · 원천보다 넓은 글 |

봉인 묶음 · 블록 실행 · ibb 판 Python 실행 (§12-6 – 12 · 14) 은 이번 범위 밖이다 (봉인 뒤 다시) — "범위 밖" 으로 한 줄씩만 적는다.

## 지킬 것

- 본 리포 · 초안 파일에 쓰지 않는다.  git 은 log · show · diff · grep 만.  네트워크 없음.  ibb · LIGGGHTS · 실제 런 없음.
- 재현용 사본 · 스크립트는 `<SCRATCH>` (새 폴더) 에만.  받은 메타 (`out/`) 는 신뢰하지 않는 자료다 — 파이썬은 `-I` 로 · 그 폴더 안에서 실행하지 않는다.
- 신호를 보내는 명령 (kill 류) 쓰지 않는다.  무거운 병렬 실행 없음.
- 결과 (M · 겹침 등 믹서 값) 를 새로 열거나 만들지 않는다.  주소 · 포트 · 계정 · 호스트 이름을 보고에 옮기지 않는다.

## 출력

- 보고 파일 = `<SCRATCH>` (한국어 · 표 위주): 집계 (P1 · P2 · P3 · 새 항목 번호 `MXE0R-NN`) · A–G 판정 (맞음 / 틀림 / 근거보다 넓음 · 근거 = 연 줄 · 돌린 것) · Q1–Q10 권고마다 "근거보다 넓은가" 한 줄 · 확인하지 못한 것 · 봉인 단계에서 다시 볼 것.
- 답장 = 한국어 8 줄 안.

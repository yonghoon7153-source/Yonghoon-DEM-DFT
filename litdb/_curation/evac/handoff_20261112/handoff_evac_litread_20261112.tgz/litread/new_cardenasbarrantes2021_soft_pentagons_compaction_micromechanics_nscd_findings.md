# new_cardenasbarrantes2021_soft_pentagons_compaction_micromechanics_nscd 정독 근거 (새 카드 1 장 · 원문 PDF 10 쪽 전문 + 카드 1131 줄 · 2026-11-10)

카드: `cardenasbarrantes2021_soft_pentagons_compaction_micromechanics_nscd` (정본 커밋 `08c61ff28`) — Cárdenas-Barrantes, Cantor, Barés, Renouf & Azéma, "Micromechanical description of the
compaction of soft pentagon assemblies", Phys. Rev. E 103, 062902 (2021), DOI 10.1103/PhysRevE.103.062902.

적는 법: 위치의 `L숫자` = 카드 줄 번호 (커밋 `08c61ff28` 기준) · 논문 쪽 `p. N` = 062902-N · 표지는 카드에 적힌 그대로 (`본문` = 인쇄된 값 ·
`[판독]` = 그림에서 읽음 (PDF 안 벡터 표식의 좌표) · `[판독 맞춤]` = 그림의 선을 읽어 식에 맞춤 · `[카드 산술]` · `[카드 추론]` · `[카드 해석]` ·
`[카드 정리]` · `[카드 대조]` · `[미확인]`).  재료 = **비압축 neo-Hookean 초탄성 정오각형 · 원판 모델 소재 · 2D** — LPSCl · NCM 아님.
보충 자료 (Supplemental Material) 는 받지 못했다 (본문 · 참고문헌에 언급 없음).

형식: `- [글자] slug | 내용 (값 · 단위) | 위치 | 표지 | 한계`

## a. 순수 SE (LPSCl · 황화물) 의 압력별 기공 곡선 · 진밀도 · 질량 기준 · 누른 채 / 뺀 뒤

- [a] cardenasbarrantes2021_soft_pentagons_compaction_micromechanics_nscd | 해당 없음 — 황화물 · 실험 곡선이 아니다.  있는 것은 초탄성 오각형 · 원판 모델 소재의 무차원 압밀 곡선 (누른 채): 마찰 0 오각형 φ = 0.842 · 0.855 · 0.880 · 0.909 · 0.945 · 0.983 (P/E 0.005 · 0.01 · 0.025 · 0.05 · 0.1 · 0.25) · 0.994 (0.4); 마찰 0 원판 0.829 · 0.840 · 0.866 · 0.897 · 0.933 · 0.970 (같은 P/E 0.005 – 0.25); μ 0.8 오각형 0.828 → 0.980 (P/E 0.5) | 카드 §3-3 (a) L178–195 · 논문 그림 2 | [판독] ±0.0005 (벡터 표식) | 2D · 초탄성 · P/E 무차원 (E 미기재) · 진밀도 · 질량 개념 없음 — 카드: 절대값 전이 0 건 (L6–11)

## b. 압력을 뺄 때 되돌아오는 양과 잰 방법

- [b] cardenasbarrantes2021_soft_pentagons_compaction_micromechanics_nscd | 없음 — 하중 쪽만 계산했다 (p. 8 *"From the jammed state, packings were isotropically compressed by applying a constant velocity on the boundaries."*).  입자가 초탄성이라 재료의 잔류 변형은 모델에 없다.  닿는 문장 하나 = p. 4 *"irreversible nature of the compaction beyond the jamming"* — 근거는 재배열 지표 (그림 4 · 5) 이고 탈압 계산이 아니다 | 카드 §0-1 (iv) L64 · §3-5 L383 · §12-A L1023 · 논문 p. 4 · p. 8 | 원문 인용 + 카드 판정 | 탈압 · 되돌아옴 값으로 쓸 수 없음

## c. 항복 · 경도 · 크리프 값과 정의 · 일축 항복 세기 환산

- [c] cardenasbarrantes2021_soft_pentagons_compaction_micromechanics_nscd | 항복 · 경도 · 크리프 값 없음 (초탄성 · E 값도 미기재).  닿는 것: 거시 체적 변형 ε = ln(φ/φ0) ≈ 0.19–0.20 (오각형) · 0.17–0.18 (원판) 까지 탄성으로 버티는 재료 · 재료 체적 강성 K/E = 33.3 (3D 식 · ν 0.495) | 카드 §3-3 (a) L200–201 · §3-4 L370 · §8-2 L806 | [카드 산술] (φ 는 [판독]) | 분말 재료는 그 전에 항복한다 — P/E 축을 옮기지 않는 이유 (카드 해석)
- [c] cardenasbarrantes2021_soft_pentagons_compaction_micromechanics_nscd | 기존 압밀 식에 대한 저자 평 (p. 8): *"All of them are based on different macroscopic assumptions that neglect the micromechanical fundamentals revealed by Eq. (9), and thus fitting parameters are needed to adjust the proposed theoretical expressions to the data."* → 카드: 우리 DEM Heckel 적합 (P_y 138 MPa) 은 이 부류 — 물성으로 인용하지 않는다 | 카드 §4-2 L418–424 · §11 L995–996 | 원문 인용 + 카드 해석 | Heckel 항복압 환산은 없음

## d. 단단한 입자 + 무른 입자를 섞어 누를 때 단단한 입자의 하중 몫 · 재밍

- [d] cardenasbarrantes2021_soft_pentagons_compaction_micromechanics_nscd | 해당 없음 — 무른 입자만 (강체 없음).  재밍 값만: jammed φ0 본문 0.808 (원판) · 0.817 (오각형) · 판독 첫 표식 0.8172–0.8174 (오각형 μ ≥ 0.1) · 0.8251 (마찰 0 오각형) · 그림의 선이 쓴 φ0 0.826 / 0.817 (오각형) · 0.810 / 0.809 (원판) | 카드 §3-1 L139 · §3-3 (a) L193 · L197–199 · (b) L216–221 | 본문 · [판독] · [판독 맞춤] | 2D · 벽 상자 · 500 개 · 강체 + 무른 혼합은 형제 카드 `cardenasbarrantes2020_rigid_deformable_mixture_compaction_nscd`
- [d] cardenasbarrantes2021_soft_pentagons_compaction_micromechanics_nscd | jammed 배위수: 본문은 문헌값만 (마찰 0 원판 4 · 마찰 있으면 [3, 4] · 강체 다각형 ≈ 4) ↔ 그림의 선 Z0 3.06 (오각형 μ 0) · 3.67 (μ 0.8) · 3.07–3.13 / 3.58–3.67 (원판) · jammed 에서 접촉 3 개짜리 입자 P3 0.35–0.47 (오각형) · 0.28–0.34 (원판) · jammed K/E 0.26–0.39 (오각형) · 0.19–0.24 (원판) | 카드 §3-2 L154 · §3-3 (b) L218–221 · (d) L275 · (f) L314 | 본문 · [판독 맞춤] · [판독] | 같은 계산에서 잰 Z0 는 미기재 [미확인]

## e. 점접촉 법칙이 큰 변형에서 깨지는 범위와 대안 · 대안마다 맞춘 값 개수

- [e] cardenasbarrantes2021_soft_pentagons_compaction_micromechanics_nscd | 작은 변형 (접촉 변형) 닫음 식 (10) (σ_ℓ = Eε_ℓ · ε_ℓ ≃ ε_v/4 · Z ≃ 4) ↔ 입자별 FE 계산 자료 (같은 φ 의 압력 자료 ÷ 식): 마찰 0 오각형 0.68 (φ 0.84) · 0.94 (0.87) · 1.06 (0.88) · 1.29 (0.90) · 1.51 (0.92) · 1.99 (0.95) · 2.62 (0.97) · 3.21 (0.98) · 4.41 (0.99) · 5.93 (0.997); μ 0.8 오각형 1.38 (0.84) · 2.05 (0.90) · 3.35 (0.95) · 6.58 (0.98); 원판 μ 0 1.04 (0.84) → 4.56 (0.97) · μ 0.8 1.38 (0.84) → 4.19 (0.95).  0.7–1.3 배 안인 구간 = 마찰 0 오각형 φ ≤ 0.90 (φ − φ0 ≤ 0.07 · ε ≤ 0.09) · 마찰 0 원판 φ ≤ 0.86 · 마찰이 있으면 처음부터 1.4 배 과소 · 식 (10) 은 P/E 0.080 (오각형 μ 0) · 0.085 (μ 0.8) · 0.067 (원판) 에서 φ = 1 을 넘는다 (포화 없음) | 카드 §3-3 (c) L241–255 · §0-1 (i) L61 · 논문 그림 2 · p. 8 | [판독] + [카드 산술] · 저자는 문턱 숫자를 적지 않음 | 2D · 초탄성 · 등방 · 식 (10) 은 DEM 계산이 아니라 해석 닫음 · 2D 의 선형 접촉 (3D Hertz 아님)
- [e] cardenasbarrantes2021_soft_pentagons_compaction_micromechanics_nscd | 저자의 대안 = 큰 변형 닫음 → 식 (11): σ_ℓ 에 기존 압밀 식들의 공통 꼴 ln[(φmax − φ)/(φmax − φ0)] 을 주고 계수 α = (φmax − φ0)/(4φ0) 를 작은 변형 극한 (식 10) 과 이어지게 고정 · 모양 = 넓이 인자 (n_s/2) sin(2π/n_s) 하나 (오각형 2.378 · 원 π) — PRL 판의 단일 입자 상수 b 를 대체 | 카드 §4-3 L426–436 · §4-5 L468–483 · 논문 p. 8 | 본문 | 로그 꼴은 유도가 아니라 차용 ("it is easy to show") — 카드 §12-B 9 L1047–1048
- [e] cardenasbarrantes2021_soft_pentagons_compaction_micromechanics_nscd | 그 대안에서 맞춘 값: 압밀 곡선에 φmax 하나 (모양 · 마찰마다 · 값 · 방법 미기재 — 그림의 선 0.9995 / 0.985 (오각형) · 0.980 / 0.968 (원판)) + 같은 계산의 Z–φ 자료에 ξ ∼ 5.1 · α ∼ 0.5 는 문헌 · Z0 는 문헌값 "≃ 4" 만 (선은 3.1 / 3.6–3.7) · φ0 는 잰 값 (모양마다 하나 인쇄) ⇒ 같은 계산 자료에 맞춘 값 둘 (φmax · ξ) | 카드 §4-5 L489–503 · §3-3 (b) L212–239 | 본문 (분류는 카드 정리) + [판독 맞춤] | 저자 표현 "free of ad hoc parameters" · "the only unknown parameter … φmax" (p. 8–9) 와 나란히 읽을 것.  multi-contact · MDR · EEPA · Thornton–Ning · Storåkers 는 이 논문에 없음
- [e] cardenasbarrantes2021_soft_pentagons_compaction_micromechanics_nscd | 그 대안의 정확도: 선 ÷ 자료 (같은 φ 의 압력) = 1.1–1.4 (마찰 0 오각형 · φ 0.845–0.977) · 0.85–0.95 (μ 0.8 오각형) · 0.93–0.99 (마찰 0 원판) · 0.83–0.90 (μ 0.8 원판); K 로 자료 ÷ 선 = 0.78–1.5 (마찰 0 오각형) · 1.1–1.4 (μ 0.8 · φ ≤ 0.967) — 마찰에 따라 어긋남의 부호가 바뀐다 · 본문 표현은 "in good agreement" · "perfectly fitting" | 카드 §3-3 (c) L243–248 · (d) L279–281 · §12-B 6 L1041–1043 | [판독] · [판독 맞춤] | 선은 부호를 + 로 고치고 Z0 3.1 / 3.7 을 넣었을 때의 것 (인쇄 그대로 · Z0 = 4 로는 선이 다시 나오지 않음 · L227–233)

## f. MPM 의 접촉 · 다물체 · 강체 결합 방법 · 해상도 규칙 (지름당 셀 수) · 수치 오차 추정

- [f] cardenasbarrantes2021_soft_pentagons_compaction_micromechanics_nscd | MPM 아님 (입자별 FE).  다물체 접촉 = NSCD 의 비관통 + Coulomb 마찰 · 정칙화 없음 (접촉 매개변수 μ 하나 · 겹침 0) · 두 변형 입자의 접촉 = 면 (2D 선분) · 접촉력 = 공통 계면 절점 힘의 벡터 합 | 카드 §4-1 L392–407 · 논문 p. 2 · p. 6 | 본문 | 후보 A′ (입자별 속도장 · 마찰 접촉) 의 기준 문제로만 — 이산화가 다르다
- [f] cardenasbarrantes2021_soft_pentagons_compaction_micromechanics_nscd | 해상도: 입자당 삼각형 92 개 (오각형 · 원판 같음) = 요소 46,000 개 / 모양 · 메시 수렴 시험 없음 (PRL 판의 단일 입자 시험도 이 판에는 없다) · 수치 오차 추정 없음 · 시료 수 · 오차막대 없음 | 카드 §3-1 L134 · §3-4 L360 · §8-2 L812 · §12-B 10 L1049–1050 · 논문 p. 2 · 그림 1 삽도 | 본문 + [카드 산술] + 카드 판정 | 요소 ≠ MPM 셀 · 오각형 모서리 응력 집중은 메시에 더 민감할 것 [카드 추정]

## g. 2D 결과를 3D 로 옮길 때의 경고 · 증거

- [g] cardenasbarrantes2021_soft_pentagons_compaction_micromechanics_nscd | 2D 계산 (p. 2 *"randomly placed into a two-dimensional square box bounded by rigid walls"* · p. 6 *"a line in two dimensions"*) 이고 **3D 에 대한 말은 없다** — 과제로 든 것은 다분산 (크기비) · 재밍 뒤의 전단 · 기계적 강도 · 잔류 상태 (p. 9) | 카드 §0-1 (iii) L63 · §5-8 L667–671 | 원문 인용 + 카드 판정 | —
- [g] cardenasbarrantes2021_soft_pentagons_compaction_micromechanics_nscd | 식 안에 든 2D 의 수: 모양 인자 (n_s/2) sin(2π/n_s) (정다각형 넓이 ÷ (d/2)² · 오각형 2.378 · 원 π) · ε_ℓ ≃ ε_v/4 · Z0 ≃ 4 · ξ ∼ 5.1 · 끝 상태 평균 접촉 수 ≈ 6.0 (면을 채운 2D 다각형의 이웃 수) — 같은 그룹 3D 판은 작은 변형 극한이 Hertz (3/2 제곱) 라 √(φ − φ0) 인자가 붙고 계수 · φ0 (0.50–0.51) 가 바뀐다 | 카드 §3-4 L361–364 · §3-3 (f) L325–326 · §4-3 L435–436 · §8-3 L814–839 · §12-A L1017–1018 | 본문 · [판독] · [카드 산술] · 3D 값은 형제 카드 | 2D 오각형 ↔ 3D 다면체의 대응 (면 접촉 · 맞물림) 은 이 논문으로 말할 수 없음 (카드 §8-2 L807)

## h. DEM 에서 FE · MPM 으로 넘긴 선례와 넘긴 시점

- [h] cardenasbarrantes2021_soft_pentagons_compaction_micromechanics_nscd | 같은 코드 (LMGC90) 안의 **강체 입자 → 변형 입자 전환**: 강체 입자 500 개를 상자에 무작위로 놓고 작은 응력 σ0 로 등방 압축해 jammed 점 (φ 변화 < 0.05 %) 까지 간 뒤, 그 상태에서 입자를 삼각형 92 개로 메시하고 (변형을 켬) 벽 일정 속도로 압축 — 넘긴 시점 = 강체 집합의 jammed 점 (φ0 ≈ 0.808 원판 · 0.817 오각형) | 카드 §4-4 L438–446 · §3-1 L137–139 · 논문 p. 2 | 본문 | 이음 구간 (메시 직후 응력 상태 · 완화) 미기재 · 그림 7 에서 φ − φ0 < 0.002 사이 Z − Z0 가 0.04 → 0.7 로 뛰는 것이 그 이음으로 보인다 ([판독] · 카드 추정 · L447–448) · 강체 단계에서 마찰을 켰는지 [미확인]

## i. 복합 양극 (AM + SE) 의 압력별 기공

- [i] cardenasbarrantes2021_soft_pentagons_compaction_micromechanics_nscd | 없음 (모델 소재 · 무른 입자만) | 카드 머리 L6–11 | — | —

## j. 카드가 스스로 "아직 못 한다 · 한계" 라고 적은 것 가운데 가압 · 탈압 계산과 닿는 것

- [j] cardenasbarrantes2021_soft_pentagons_compaction_micromechanics_nscd | 저자가 적은 과제 (p. 9): *"A perspective to this work concerns the study of the effects of polydispersity of systems composed of highly deformable particles. In this case we would expect stronger coupled effects between applied pressure, particle rearrangement, and particle size ratio on the measured quantities. Also, an expected continuation of this work will be the analysis of the shear effects beyond the jammed state. In particular, several questions still remain, such as, for example, the mechanical strength and the existence of a residual state like the one observed in rigid packings."* — 소성 · 탈압 · 3D · 강체 혼합은 과제로도 적지 않았다 | 카드 §5-8 L667–671 · §11 L1002–1004 · 그림별 eq_12b 줄 L729 | 원문 인용 + 카드 판정 | 계산은 하지 않음
- [j] cardenasbarrantes2021_soft_pentagons_compaction_micromechanics_nscd | 카드가 적은 한계: 탈압 없음 · 초탄성 (가역) · 2D · 무른 입자만 · 등방 · 실험 대조 없음 · 메시 시험 없음 · 계산 비용 미기재 · 식의 입력 (φmax · Z0 · 마찰별 φ0 · 그림에 쓴 ξ) 미인쇄 → 글만으로 식 재계산 불가 · 검증이 닫힌 고리 (식의 입력을 정한 계산 = 식을 검증한 계산) | 카드 §12-A L1015–1024 · §12-B L1026–1062 · §4-5 L501–503 | 카드 판정 | 판독에 기댄 판정 — 원인 [미확인]
- [j] cardenasbarrantes2021_soft_pentagons_compaction_micromechanics_nscd | 재밍 뒤 비가역 (p. 4 *"This observation also highlights the irreversible nature of the compaction beyond the jamming, confirming recent works [46,47]."*) — 재료가 가역이어도 재배열이 경로를 되돌릴 수 없게 한다는 진술 · 탈압 계산 없음 → "탈압 뒤 남는 치밀화 = 재료 소성 + 재배열 몫" 이라는 틀 (카드) 만 남고 크기는 없다 | 카드 §5-2 L564–566 · §9-4 L896–898 · §10-2 단계 6 L937 | 원문 인용 + [카드 추론] | refs [46,47] (Vu · Nezamabadi · Mora) 우리 미열람

## k. DEM 의 한계 — 논문 (카드) 이 직접 말한 문장 · 수치

- [k] cardenasbarrantes2021_soft_pentagons_compaction_micromechanics_nscd (Cárdenas-Barrantes, Cantor, Barés, Renouf & Azéma 2021 · Phys. Rev. E 103, 062902 · DOI 10.1103/PhysRevE.103.062902) | ★ 서론 (p. 1): *"On the other hand, introducing the correct particle shape deformations in numerical simulations with discrete element methods gives rise to various technical difficulties, mainly seen in the increase of the computational time. Regarding this, different discrete element strategies have been proposed, such as the bonded-particle method [32,33] and couplings between classical finite element or meshless methods [34–39]. The latter methods, although computationally expensive, have the advantage of closely representing the geometry of the particles."* | 카드 §0-1 (i) L61 · §4-2 L414–416 · §11 L974–978 | 원문 인용 | "형상 변형을 넣는 것" 의 어려움 — 계산 시간 배수 등 수치는 없음
- [k] 같은 카드 (같은 서지) | 서론 (p. 1) — 강체 계와의 차이: *"They can also fill the void space in a better way than the rigid particle assemblies do. Such remarkable properties, essentially due to the shape change, represent an important distinction with regard to rigid particle systems."* | 카드 §0-1 (i) L61 · §11 L972–973 | 원문 인용 | 무른 입자 일반 (에멀션 · 마이크로겔 · 세포 · 금속 분말) 의 진술
- [k] 같은 카드 (같은 서지) | ★ 결과 (p. 8): *"As expected, we see a fair approximation of the compaction evolution in the small-strain domain but an increasing mismatch as the solid fraction increases."* — 그 크기 (그림 2 판독): 식 (10) 은 마찰 0 오각형에서 φ ≤ 0.90 (φ − φ0 ≤ 0.07 · ε ≤ 0.09) 까지 0.7–1.3 배 안이고 그 뒤 같은 φ 의 압력을 2.0 배 (φ 0.95) · 3.2 배 (0.98) · 5.9 배 (0.997) 과소 예측; 마찰이 있으면 (μ 0.8) 처음부터 1.4 배 → φ 0.98 에서 6.6 배 — 식에 마찰이 들어갈 자리가 φ0 뿐 | 카드 §0-1 (i) L61 · §3-3 (c) L241–255 · §8-5 L860–868 · §11 L993–994 | 원문 인용 + [판독] + [카드 산술] | 대상은 해석 닫음 (식 10) — DEM 을 직접 돌린 대조 아님 (그 대조는 3D 판 Soft Matter 2022) · 2D · 초탄성 · 저자는 문턱 숫자를 적지 않음 (L1006–1009)
- [k] 같은 카드 (같은 서지) | 접촉 정칙화 (p. 2): *"The CD method considers a contact law with nonpenetrability and no regularization of the friction law between the particles for the determination of contact forces."* — NSCD 에는 접촉 강성 계수가 없다 (겹침 0 · 접촉 매개변수 μ 하나) ↔ 벌칙 DEM 은 겹침 δ 비례 힘이고 그 강성이 압밀 결과를 바꾼다 (카드) | 카드 §4-1 L398–407 · §11 L979–980 | 원문 인용 + [카드 정리] | 정칙화가 결과를 얼마나 바꾸는지의 수치는 없음
- [k] 같은 카드 (같은 서지) | 입자를 원 (구) 으로 둔 것의 오차 크기 (같은 방법 · 같은 조건의 오각형 ↔ 원판): 같은 P/E 의 충전율 차 +0.011–0.015 (마찰 0) ↔ −0.001 – +0.003 (μ 0.8) · 재배열 지표 1.4–2.1 배 — 모양의 효과는 마찰이 작을 때만 크다 · 저자가 든 이유 (p. 4) *"This, along with intruding-corner effects into free space, are some of the facts that contribute to pentagons achieving higher packing fraction compared to assemblies of disks."* | 카드 §3-3 (a) L202–206 · (e) L286–292 · §9-2 L890–892 · §11 L989–990 | [판독] + [카드 추론] + 원문 인용 | 2D 정오각형 하나 · 초탄성 — 불규칙 파쇄 입자 · 3D 다면체로 옮기지 않는다
- [k] 같은 카드 (같은 서지) | 우리 DEM 의 자리 (논문 주장 아님): 300 MPa ÷ E = 0.0125–0.0136 (실제 SE E 22–24 GPa · 이 논문 곡선의 φ ≈ 0.86 · 식 (10) 이 0.84 배로 맞는 구간 · jammed 대비 +0.035 뿐) ↔ 0.22 (연화 E 1.35 GPa · φ ≈ 0.98 · 식 (10) 이 압력을 1/3 로 과소 예측하는 구간) ⇒ 한 압력에 맞춘 연화 영률은 그 압력의 대리일 뿐 | 카드 §3-4 L373–374 · §8-5 L858–871 | [카드 산술] + [카드 추론] | 2D · 초탄성 · 해석 닫음 · 우리 접촉은 hooke/hysteresis · 우리 치밀화 주 기전은 소성 · AM 차폐 — 방향 해석일 뿐

## l. 소성변형이 왜 어려운가 — 논문의 설명 · 택한 우회 · 맞춘 값 · 검증 범위 · 계산 비용

- [l] cardenasbarrantes2021_soft_pentagons_compaction_micromechanics_nscd (Cárdenas-Barrantes, Cantor, Barés, Renouf & Azéma 2021 · Phys. Rev. E 103, 062902 · DOI 10.1103/PhysRevE.103.062902) | 소성은 다루지도 언급하지도 않는다 (본문에 plastic 낱말 없음) — 재료 = 비압축 neo-Hookean 초탄성 (ν 0.495 · 하중을 빼면 되돌아옴) | 카드 머리 L7 · §0-1 (ii) L62 · §4-6 L510 | 본문 + 카드 판정 | 이 논문은 소성이 아니라 "큰 변형" · "형상 변화" 일반의 어려움을 말한다
- [l] 같은 카드 (같은 서지) | 어려운 이유 (저자): 계산 = p. 1 *"introducing the correct particle shape deformations in numerical simulations with discrete element methods gives rise to various technical difficulties, mainly seen in the increase of the computational time"* (전문은 [k]) · 실험 = p. 1 *"one of the main difficulties with experiments is to make relevant quantitative measurements at the grain scale, for example, to follow the shape change of the particles"* · 이론 = p. 8 *"All of them are based on different macroscopic assumptions that neglect the micromechanical fundamentals revealed by Eq. (9), and thus fitting parameters are needed to adjust the proposed theoretical expressions to the data."* | 카드 §0-1 (ii) L62 · §4-2 L413–420 · §11 L974–978 · L995–996 | 원문 인용 | —
- [l] 같은 카드 (같은 서지) | 택한 우회 = **소성을 넣지 않음** + 입자별 FE 로 형상 변화를 직접 풂 (NSCD · LMGC90 · 비관통 + 건조 마찰 · 접촉 매개변수 μ 하나 · 접촉 = 면 (2D 선분)) + 큰 변형 닫음을 작은 변형 극한에 묶어 단일 입자 시험 없이 닫음 | 카드 §4-1 L392–407 · §4-3 L426–436 · §4-6 L505–519 · 논문 p. 2 · p. 8 | 본문 | 형상 변화 = 오각형 → 둥근 다각형 (원형도 최대 R̂/R̂0 1.011–1.019 · φ ≈ 0.92) → 불규칙 다각형 ([판독] · L308–310)
- [l] 같은 카드 (같은 서지) | 우회의 값 — 규모 · 비용: 입자 500 개 × 삼각형 92 개 = 요소 46,000 개 / 모양 · 모양 둘 × 마찰 다섯 · 계산 시간 · 코어 수 · Δt [미확인] (HPC 플랫폼 MESO@LR · 병렬 알고리즘 ref [51] 이름만) | 카드 §3-1 L132–134 · §2 L106–107 · §3-4 L360 | 본문 + [카드 산술] | PRL 판 (원판 1500 개) 의 1/3
- [l] 같은 카드 (같은 서지) | 맞춘 값 · 검증 범위: 압밀 곡선에 φmax (모양 · 마찰마다 · 값 미기재) · Z–φ 자료에 ξ ∼ 5.1 · Z0 문헌값 ≃ 4 (그림의 선 3.1 / 3.6–3.7 [판독 맞춤]) · 검증 = 같은 계산 자료뿐 (실험 · 다른 코드 · 메시 시험 없음) · 정확도 = 선 ÷ 자료 (압력) 1.1–1.4 / 0.85–0.95 (오각형 μ 0 / 0.8) · 저자 표현 (p. 9) *"we establish a compaction equation and a bulk equation, free of ad hoc parameters, perfectly fitting our numerical data"* | 카드 §4-5 L489–503 · §12-B 11 L1051–1052 · §3-3 (c) L243–248 · §5-8 L664–666 | 본문 + [판독 맞춤] | 식의 입력 넷 (φmax · Z0 · 마찰별 φ0 · 그림에 쓴 ξ) 미인쇄
- [l] 같은 카드 (같은 서지) | 비가역성의 출처: 재료가 가역인데도 압밀이 비가역이라는 저자 문장 (p. 4) *"From these measures we can deduce that the differences in the evolution of the compaction curves observed in Fig. 2 are related to the small local rearrangements in the system. This observation also highlights the irreversible nature of the compaction beyond the jamming, confirming recent works [46,47]."* — 근거 = 재배열 지표 (그림 4 · 5) · 탈압 계산 없음 | 카드 §5-2 L564–566 · §11 L986–988 | 원문 인용 | 되돌아옴 양 없음 · 재배열 → 곡선 차이는 같이 변한다는 관찰 (따로 떼어 본 계산 없음 · L568)

## m. 받아들일 통찰 — 바로 가져다 쓸 수 있는 것

- [m] cardenasbarrantes2021_soft_pentagons_compaction_micromechanics_nscd | **후보 비교에서 마찰 0 을 기준으로 쓰지 않는다 — 입자 간 마찰 값을 결과 전에 같은 값으로 고정한다.**  재배열 지표 θ̂_φ 가 μ 0 → 0.1 한 걸음에 1/3 (오각형 0.340 → 0.114) · 1/2 (원판 0.165 → 0.080) 로 주고 충전율도 0.010–0.016 내려간 뒤 0.4 → 0.8 은 0.004 이하 — 마찰 0 은 특이점이라 표현 차이가 마찰 차이에 묻힌다 | 우리 쪽: 단계 3 (두 접촉 표현 비교의 마찰 값 · 단일 속도장 MPM 은 "미끄럼 없음" 으로 따로 표기) · U2 · U5 (마찰 0 과 작은 마찰 0.1 을 따로 시험) | 근거: 카드 §9-3 L893–895 · §10-2 L934 · §10-3 3 L952–953 · §3-3 (e) L286–292 | [판독] | 2D · 초탄성
- [m] cardenasbarrantes2021_soft_pentagons_compaction_micromechanics_nscd | **새 런 0 관측량 넷 (D0 압축 궤적)**: 재배열 지표 θ̂ (입자 속도 방향이 균질 변형 속도 방향에서 벗어난 각 ÷ π — 일축 판이면 기준 방향 = 균질 일축 변형 · 정의는 결과 전에) · participation number Γ (식 (7) 은 q_i² 로 읽을 것 — 인쇄는 제곱 누락) · 입자 응력의 상대 표준편차 (Love–Weber) · ⟨δ/d⟩ ÷ 판 변형 (본문 1/4 · 판독 0.21–0.30) — 조밀해질수록 고르게 되는지 · 재배열이 압축 끝까지 남는지가 정보 | 우리 쪽: 후보 D0 · 단계 0 (관측량 정의) · 단계 3 (접촉 표현을 가르는 관측량 — 충전율보다 먼저 갈릴 것) | 근거: 카드 §10-3 2 L949–951 · §10-2 L933 · §7 L759–764 · §3-4 L372 | 본문 (정의) + [판독] | 2D 값은 기대값으로 쓰지 않는다
- [m] cardenasbarrantes2021_soft_pentagons_compaction_micromechanics_nscd | **출발 상태와 식의 입력을 잰 값의 표로 남긴다 (반면교사)**: 이 논문은 φ0 를 모양마다 하나 (0.808 · 0.817 — 마찰 0 오각형의 자료 · 선은 0.826) · Z0 는 문헌값 "≃ 4" (선은 3.1 / 3.6–3.7) · φmax 는 숫자 없음 · 식 (11) 은 부호 오식이라 글만으로 식을 다시 계산할 수 없고 그림의 선은 본문 상수로 재현되지 않는다 | 우리 쪽: 단계 0 (φ0 · Z0 · 마찰 · 준비 방법 · jammed 판정 문턱을 조건마다 표로) · 후보 M0 (닫힌 꼴을 쓸 때 인쇄 식 그대로 쓰지 않고 그림의 선부터 재현) | 근거: 카드 §9-6 L902–904 · §3-3 (b) L212–239 · §12-B 1–3 · 7 L1028–1034 · L1044 · §10-2 L932 | [판독 맞춤] + 카드 판정 | 원인 [미확인]
- [m] cardenasbarrantes2021_soft_pentagons_compaction_micromechanics_nscd | 흐름 밖 (보고 방식 · 함정): **같은 그룹 · 같은 코드의 2D 소형 계산 곡선이 판마다 0.01–0.02 다르다** — 무른 원판 마찰 0 이 PRL (1500 개 · 응력 단계) ↔ 이 논문 (500 개 · 일정 속도) 에서 같은 P/E 의 φ 로 +0.010 – +0.019 · μ 0.8 은 +0.010 – +0.021 (대부분 jammed φ0 0.795 ↔ 0.809) · φmax (μ 0) PRL 본문 0.998 ↔ 이 논문의 선 0.980 → 외부 2D 자료와 견줄 때 꼴과 순서만 보고 0.01 수준의 값 차를 모델 차로 읽지 않으며 시료 수 · 오차막대 · 준비 방법을 같이 적는다 | 우리 쪽: 흐름 밖: 문헌 대조 보고 · 결과 전 대조 항목 (2D 외부 자료의 쓰임) | 근거: 카드 §8-3 L814–839 · §9-8 L908–910 · §10-3 5 L956–957 | 두 카드의 [판독] | 출발 상태 · 계 크기 · 하중 방식이 섞인 차 (분리 안 됨)

## 카드 문제

없음 (새 카드 · 작성자 자기 점검).  읽는 쪽이 알아 둘 것 다섯:
① 표 3-3 의 값은 전부 그림 판독이다 (그림 2 · 3 · 5 · 6a · 7 · 8 · 11 · 12b · 13 = PDF 안 벡터 — 평탄화된 반투명 표식의 꼭짓점 좌표로 중심을 얻고
   축은 벡터 눈금 선으로 · φ ±0.0005 · 이론선은 1200 dpi · K ±2 %) — 원저자 수치 파일이 아니다.  원자료 `digitized.csv` 1,318 행 · ⚠ 그 안의 이론선은
   16–26 점으로 추린 표본이라 표본 사이를 log 보간하면 발산점 근처에서 K 비가 최대 ≈ 0.06 다르게 나온다 (예: 오각형 μ 0 · φ 0.936 — 0.95 ↔ 1.01)
   — 카드의 선 ÷ 자료 비는 촘촘한 추적과 카드에 적은 맞춤 상수 (φmax · φ0 · Z0) 로 낸 값이다 (재계산은 그 상수로).
② "식 (11) 의 `−` 는 `+` 의 오식" · "그림의 선은 Z0 3.1 / 3.6–3.7 · φmax 0.9995 / 0.985 로 그려졌다" · "그림 3 빨강 선 φmax 0.980" ·
   "그림 7 선 ≈ 0.35 + 5.6·√(φ − φ0)" 는 선을 식에 맞춘 카드 판정 (`[판독 맞춤]`) 이고 원인은 [미확인] 이다 (L212–239).
③ 그림 2 원판 삽도의 초록 역삼각형 · 빨강 네모 마름모를 범례 (가는 마름모 · 오각형) 대신 색으로 μ 0.4 · 0.8 에 대응시켰다 — 그림 3 삽도 표본과
   0.0001 안에서 같아 대응이 맞다고 판단 (`[카드 대조]` · L207–210).
④ 그림 8 (b) 에서 따로 가는 원판 계열을 마찰 0 으로 본 것은 계열 끝 φ 의 소거에 의한 판정이고, 그 계열은 φ 0.959 에서 끝나 그림 2 의 마찰 0
   원판 (0.970) 과 다르다 (사유 [미확인] · L320–324).
⑤ 형제 카드와의 대조 (형제 카드는 고치지 않음): `cardenasbarrantes2022_soft_spheres_3d_compaction_nscd` §5-4 · §8-3 · `cardenasbarrantes2022_soft_hard_grains_compaction_experiment_dic`
   §4-4 가 이 PRE 를 옮겨 적은 곳은 원문과 맞는다 · `cantor2020_compaction_model_highly_deformable_particles` 는 이 PRE 의 값을 옮기지 않았다.  덧붙일 뉘앙스 둘 —
   3D 카드 §8-3 의 2D "Γ = 4" (ε_v = Γ·ε_ℓ) 는 본문 값이고 그림 13 의 자료는 기울기 0.21–0.30 (Γ 3.3–4.8) 으로 퍼져 있다 · 같은 표의 2D "jammed Z0 3.3–3.7"
   (학회판 표) 은 이 논문 선의 역산 3.1–3.7 과 겹친다 (본문의 "≃ 4" 가 아니라) (카드 §14 L1107–1114).

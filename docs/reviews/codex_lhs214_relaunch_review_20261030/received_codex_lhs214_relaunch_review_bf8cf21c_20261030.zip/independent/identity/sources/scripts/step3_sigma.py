#!/usr/bin/env python3
"""STEP3 v1 — electronic-conductivity voxel resistor network for MPM additive structures.

Solves ∇·(σ∇φ)=0 on a voxelized conductive skeleton (AM + VGCF/SuperP/SDCP; SE·PTFE = e-insulators)
between the collector plane (bottom, φ=1) and the top plane (φ=0), finite-volume with HARMONIC-mean
face conductances (phase boundaries handled naturally), and reports:
  · sigma_e_eff  — effective through-plane electronic conductivity (S/cm)
  · per-AM-particle current density (slide-20 colouring: which AM carry the current)
  · per-phase current shares (how much flows through carbon vs AM–AM necks)

DESIGN / TRUST (docs/step3_sigma_network.md):
  · FULL-resolution inputs (se_dump + phase + AM scaffold) — the payload's subsampled clouds would
    fragment bridges (unphysical).  Runs on kgy inside the payload step (mpm_webapp_payload --step3).
  · v1 trust unit = RELATIVE comparison at identical settings (voxel res + σ hooks fixed).  Absolute
    σ_e needs the DEM Stage-E contact-area cross-calibration (sub-voxel constriction NOT modelled —
    a 1-voxel neck's area is quantized to the face area; documented limit).
  · Boundary: lateral walls insulating (Neumann).  The MPM RVE is x,y-periodic; v1 keeps Neumann for
    solver simplicity — identical for all compared runs, so the relative Δσ is unaffected to first
    order (documented).
  · σ table (S/cm), every value overridable:
      AM_S 0.010 / AM_P 0.005   ⚠ **corpus-fit endpoints**, NOT a Trevisanello measurement.
                                  A1 close-out (2026-06-30, docs/a1_sigma_e_direction_closeout.md)
                                  RETRACTED that attribution: Trevisanello 2021 measured Li⁺ chemical
                                  diffusion / BET / R_ct and supports the NCM(r) GB **direction** only.
                                  10/5 = our σ_e scaling-law fit endpoints (live 9.13/4.14) rounded.
                                  ⚠ scale transplant: those endpoints are coefficients of a MACROSCOPIC
                                  effective form; using them as a voxel **phase** σ has an unknown
                                  multiplier (§F1 → null).  Treat as an order-of-magnitude hook.
      VGCF 100 · SuperP 10      ⚠⚠ **frozen, uncalibrated legacy voxel-network coefficient**
                                  (Codex R20).  ★ 이 값은 **83 에서 유도되지 않았다** — 도입
                                  커밋 `087d1a07` 이 `order-of-magnitude hook` 으로 넣었고
                                  그것이 83 문헌 감사보다 **앞선다**.  ⇒ *"분말값을 보고
                                  채택했다"* 는 서사를 쓰지 말 것 (R20-04).
                                  ⚠ 그리고 83 으로 **바꾸는 것도 답이 아니다**: 83 은 압착
                                  분말의 시편-단면 유효값이고 복셀이 요구하는 것은 **국소
                                  섬유 closure** 다.  `diameter_preserving_sigma` 가
                                  `σ_bulk·A/L` 을 전제하므로 범주 오류가 된다.
                                  ⚠ 분말 저항률 0.012 Ω·cm ≈ 83 S/cm 급;
                                  단섬유는 1e4 S/cm — 차이 = 섬유-섬유 접촉저항, CL-47).  복셀 융합이
                                  접촉저항을 0 으로 만들므로 이 낮은 σ 가 그 결손을 뭉뚱그린다 —
                                  ⚠ 재료상수가 아니라 규약이다.  단섬유값 대입 = 등전위 섬유 + 완전
                                  접촉 = 이중 완전화 (감도 프로브 CL-48 전용, 생산 금지)
                                  ⚠ voxel_conductivity.py(레거시·미사용)는 500/100 — 생산 정본은 이 100/10
      SDCP 250                  USER anchor (2026-07-16; 진성호계 S-PEDOT, interim 150 대체 — code L43).
                                  ⚠ the pellet ×5.1 anchor is COMPOSITE-level — do NOT paste onto a phase σ;
                                  the +52% σ_e is EMERGENT from the network solve.  --sigma-sdcp overrides.
                                  ⛔ **철회 — `+52 %` 를 인용하지 말 것** (표지 2026-09-14, 원장 `CL-24`).
                                  그 값은 vox 0.4 점-스탬프 격자의 산물이고, 같은 규약을 조이면
                                  +42.15 → +8.49 % 로 계속 내려가며 σ_ion 은 **부호가 뒤집힌다**.
                                  ★ 살아남는 문장은 *"σ_e 이득이 상별 σ 대입이 아니라 망 해에서
                                  **창발한다**"* 는 **기전 서술**뿐이다 — 크기는 아직 못 쓴다.
      SE · PTFE 0               (electronic insulators)

Analytic self-tests (python3 scripts/step3_sigma.py --selftest):
  uniform block → σ exactly; series laminate → harmonic mean; parallel laminate → arithmetic mean;
  disconnected slab → σ ≈ 0.  These pin the assembly/BC signs.
"""
import argparse
import hashlib
import sys

import os as _os
import numpy as np
from scipy import ndimage, sparse
from scipy.sparse.linalg import cg as _cg_scipy
import inspect as _inspect

_THIS_DIR = _os.path.dirname(_os.path.abspath(__file__))
if _THIS_DIR not in sys.path:
    sys.path.insert(0, _THIS_DIR)


def _cg_v112(A, b, x0=None, *, rtol=1e-5, atol=0., maxiter=None, M=None, callback=None):
    """scipy ≥ 1.12 의 `cg` 와 같은 반복 (`scipy/sparse/linalg/_isolve/iterative.py` · 1.17.1 에서 옮김 · 실수 계).
    scipy < 1.12 (kgy dem-venv = scipy 1.10.1 · 1저자 10-24) 의 `cg` 는 `tol=` (legacy atol) 이라 정지 의미가 다르고, 정확한 해에서
    rtol 1e-14 로 이어 풀면 30,000 회 동안 수렴하지 못하고 잔차가 나빠진다 (`SELF-133` · 시험 K4) → 옛 판에서는 이것이 `cg` 다 (아래).
    1.12+ 에서는 쓰지 않는다 (scipy 의 `cg` 그대로 · 같은 판에서 비트 같음 = 시험 K4b)."""
    from scipy.sparse.linalg import aslinearoperator
    A = aslinearoperator(A)
    N = A.shape[0]
    b = np.asarray(b, dtype=np.float64).ravel()
    x = np.zeros(N, dtype=np.float64) if x0 is None else np.array(x0, dtype=np.float64).ravel()
    psolve = (lambda v: v) if M is None else aslinearoperator(M).matvec
    bnrm2 = np.linalg.norm(b)
    atol = max(float(atol), float(rtol) * float(bnrm2))
    if bnrm2 == 0:
        return b, 0
    if maxiter is None:
        maxiter = N * 10
    matvec = A.matvec
    r = b - matvec(x) if x.any() else b.copy()
    rho_prev, p = None, None
    for iteration in range(maxiter):
        if np.linalg.norm(r) < atol:
            return x, 0
        z = psolve(r)
        rho_cur = np.dot(r, z)
        if iteration > 0:
            beta = rho_cur / rho_prev
            p *= beta
            p += z
        else:
            p = np.empty_like(r)
            p[:] = z[:]
        q = matvec(p)
        alpha = rho_cur / np.dot(p, q)
        x += alpha * p
        r -= alpha * q
        rho_prev = rho_cur
        if callback:
            callback(x)
    return x, maxiter


#: CPU CG — scipy ≥ 1.12 = scipy `cg` (`rtol=`) · 옛 판 = `_cg_v112` (같은 반복 · 같은 정지 의미 · `SELF-133`).  감싸기 (`step3_conv_cert._cg_count`) 가
#  이 이름을 바꿔 끼우므로 두 판 모두 이 이름 하나로 부른다.
cg = _cg_scipy if 'rtol' in _inspect.signature(_cg_scipy).parameters else _cg_v112

import se_material  # single source of truth for σ_ion(SE) + its temperature convention

# ── SE ionic σ (S/cm) — the ONE definition, declared at se_material.T_REF_C = 25 °C ──
# STEP3 itself never hard-coded an SE ionic σ: the sig_i table is built by the caller
# (mpm_webapp_payload --sigma-ion-se).  Re-export it here so every STEP3 consumer reads the
# same number/convention instead of a fresh 0.003 literal, and so the temperature helpers are
# importable from the module that owns the solve.  docs/temp_pressure_capability.md T1-b.
SIGMA_ION_SE_S_CM_25C = se_material.SIGMA_GRAIN_S_CM_25C   # 3.0e-3 S/cm = 3.0 mS/cm (project value = Cronau 2021 SI Fig. S2c µC pellet plateau, lower end — SELF-51)


def sigma_ion_se_S_cm(T_C=None, ea_ev=None):
    """SE ionic σ in S/cm.  T_C None (default) → the bare 3.0e-3 literal, bitwise."""
    return se_material.sigma_grain_S_cm(T_C, ea_ev)


def temperature_provenance(T_C=None, ea_ev=None):
    """Provenance block for STEP3 σ outputs (T_C / T_ref_C / Ea_ion_eV / T_dependence)."""
    return se_material.provenance(T_C, ea_ev)


# σ defaults (S/cm) — see module docstring for anchor status
# SDCP 250 = USER-provided anchor UPDATE (2026-07-16; supersedes interim 150 of 2026-07-10,
# 진성호계 S-PEDOT 자릿수).  Still overridable per run.  ⚠ pre-2026-07-16 production outputs
# (DBE +45.4% 등) were solved at 150 — re-run needed for the 250-anchored numbers.
SIGMA_DEFAULT = {'AM_S': 0.010, 'AM_P': 0.005, 'VGCF': 100.0, 'SuperP': 10.0, 'SDCP': 250.0,
                 'SWCNT': 100.0}
#: ★ 마지막 `apply_ptfe_blocking` 의 **상별 차단 셀 수** (키 = 원래 sid, 문자열).
#    총수만으로는 "SE 를 막았나 SDCP 도 막았나" 가 안 보이고, 그 구분이 Codex R16 Q6 의
#    쟁점이다.  매니페스트가 이것을 실어야 사후에 갈린다.
LAST_PTFE_BLOCK = {}


def electronic_sigma_table(sigma_am_s, sigma_am_p, sigma_vgcf, sigma_superp,
                           sigma_sdcp, sigma_ptfe=0.0, sigma_swcnt=0.0, sigma_se=0.0):
    """sid → 전자 σ 표 (**생산 규약**).  SE(6) 는 전자 절연, PTFE(7) 는 감도 훅.

    ★★★ 2026-08-25 (R5-CX-09, Codex 5차) — 이 표가 `mpm_webapp_payload` 안에 **inline
      배열**로만 있어서, plate/reaction 회귀가 상별 σ 를 **다시 하드코딩**했다.  그러면
      producer 의 상 분기(특히 SWCNT sid 8)가 퇴행해도 회귀가 못 잡는다 — 두 곳이
      **따로** 참이면 그 시험은 생산을 증언하지 않는다.
      ⇒ producer 도 selftest 도 **이 함수 하나**를 쓴다 (사본 금지, 이 리포의 반복 교훈).
    ★ 2026-08-25 (G2/D13) — `sigma_se` 신설: **펠릿 보정 전용** 훅 (원장 ④ — neat 펠릿의
      전자 σ 0.30e-7 S/cm 는 SE 매트릭스 자신의 잔여 전자전도다).  기본 0.0 = 생산 불변.
    ⚠ sid 9 (SE_blk = PTFE-차단 SE) 는 **항상 0** — `sigma_ptfe` 감도 훅을 줘도 차단 셀은
      전자 도체가 되지 않는다 (재질이 SE 지 PTFE 가 아니다).  이온도 0 (차단이 노브의 목적),
      전자만 SE 를 따르게 두면(sigma_se) 차단 노브가 전자망을 **개선**하는 역설이 생기므로
      전자도 0 으로 둔다 — 표면 피복은 양쪽 계면을 다 막는다는 보수적 규약."""
    return np.array([0.0, sigma_am_s, sigma_am_p, sigma_vgcf, sigma_superp, sigma_sdcp,
                     sigma_se, sigma_ptfe, sigma_swcnt, 0.0], float)


def ionic_sigma_table(sigma_ion_sdcp, sigma_ion_se, swcnt_ion_block=False):
    """sid → 이온 σ 표 (**생산 규약**).  탄소(3,4)·AM(1,2)·PTFE(7) 는 이온 절연.

    ⚠ SWCNT(8) 는 **기본 ion-transparent** 다 (sheath 가 SE 를 덮어도 이온이 지난다).
      `swcnt_ion_block` 이 그것을 끈다 — 그 분기가 이 함수 안에 있어야 회귀가 본다.
    ⚠ sid 9 (SE_blk) = **0 고정** — PTFE 피복이 이온 경로를 끊는다는 것이 G2 노브의
      정의 그 자체다 (`apply_ptfe_blocking`).  여기가 0 이 아니면 노브는 존재하지 않는다."""
    return np.array([0.0, 0.0, 0.0, 0.0, 0.0, sigma_ion_sdcp, sigma_ion_se, 0.0,
                     0.0 if swcnt_ion_block else sigma_ion_se, 0.0], float)


#: ★★★ 2026-08-30 (Codex R13 C-5) — **선분 스탬프 원장.**  `fibre_stamp='segment'` 는
#    "`add_fid` 가 있었다" 는 뜻일 뿐, **모든 fid 가 선분으로 구워졌다는 뜻이 아니다.**
#    실물 seeder 는 box clipping·AM 내부점 제거 후 **한 점만 남은 fibril** 을 보존하고,
#    그것은 아래에서 명시적으로 **점 스탬프**된다.  다른 첨가제가 하나라도 선분이면
#    매니페스트는 전체를 `segment` 로 적는다 = 도장과 실제가 갈린다.
#    ⇒ **phase 별로** 몇 fid 가 선분이고 몇이 점이었는지 여기 남긴다.
#  ⚠ 키는 **phase** 다 (sid 아님) — 둘은 다른 번호계다 (phase 4 = PTFE → sid 7).
#    `SID_NAME` 으로 찍으면 라벨이 틀린다.
LAST_SEGSTAMP = {}

SID_NAME = {1: 'AM_S', 2: 'AM_P', 3: 'VGCF', 4: 'SuperP', 5: 'SDCP', 6: 'SE', 7: 'PTFE',
            8: 'SWCNT', 9: 'SE_blk'}                       # voxel σ-id → name
#   sid 7 (PTFE) = SENSITIVITY-ONLY: production은 PTFE를 전도 격자에 아예 안 넣음(절연 = void와
#   동일 취급, bulk PTFE σ~1e-16 S/cm).  --sigma-ptfe > 0 민감도 런에서만 payload가 phase-4 점을
#   _apts에 포함시켜 여기로 스탬프됨.
#   sid 8 (SWCNT, A14 sheath) = 전자망 도체 (σ_e VGCF급 ⚠hook — koo2026 0.20 S/cm은 분말-복합체
#   값이지 상(phase) σ가 아님, 이식 금지) + 이온망 기본 = SE-투명(σ_i=σ_ion_se): 실제 skin은
#   2-10nm sub-voxel이라 1-voxel(≈0.4µm) 스탬프가 이온접촉을 끊으면 차단을 40-200× 과대표현
#   (trade-off 상한의 이중계상).  --swcnt-ion-block = 상한 시나리오 opt-in(σ_i=0 → BV면 소멸).

# ── ① 상 경계 계면 저항 (2026-10-02) ──────────────────────────────────────────────────
#  ★ CL-81: 이 솔버는 면을 조화평균으로만 이어 **계면 저항 항이 정확히 0** 이었다
#    (= 접촉망의 `CONTACT_FREE` 가지, `docs/voxel_contact_free_gap.md`).  여기서 **다른 sid 사이**
#    (또는 같은 sid 인데 입자 번호 `pid` 가 다른) 면에 면적비저항 r [Ω·cm²] 를 **직렬**로 넣는다:
#        g = vox² / (vox/(2σa) + vox/(2σb) + r′),   r′ = r · 1e4  [µm·cm/S]   (σ S/cm · vox µm)
#    r 를 주지 않으면 (기본) 어떤 면도 안 건드려 **비트 동일**이다 (`_selftest_rint` ⓓ).
#  ⚠ 입력 σ 규약과 묶인다 — SE 3.0 은 펠릿값 (CL-91) 이라 입계 저항을 일부 이미 품고, VGCF 100 은 도입 때
#    (`087d1a07c`) 출처 없이 넣은 국소 섬유 closure 값이다 (분말 83 과 같은 자릿수일 뿐 분말값이 아니다 —
#    CL-47 `correction_20261003` · RINT-10).  ⇒ 항을 켜면 이중계상 **위험**이 있으나 그 크기 · 분해는 미식별
#    (같은 σ_eff 를 σ_내부 · r 의 여러 조합이 재현).  ④ 의 내부값 규약 · 보정/holdout 분리 전에는 **기구만**
#    둔다 (생산 기본 OFF · 값 인용 금지).
#  ⚠ 플레이트 결합(집전체 접촉) · STEP4 반응 솔브 · 열 솔브는 이 항을 **안 받는다** (범위 밖).
#  ⚠ 조립과 진단(소산 분담 · |J| 점군 · 입자별 J_z)은 **같은 배율 함수**를 쓴다 — 진단이 조화평균을
#    다시 계산하면 계면 면의 전류가 과대로 나온다 (`_selftest_rint` ⓘ2 가 그 반례).
INTERFACE_MODEL_VERSION = 'r1-phase-boundary-series'
RINT_OHM_CM2_TO_UM_CM_PER_S = 1.0e4          # 1 Ω·cm² = 1 cm²/S = 1e4 µm·cm/S
SID_INTERFACE = -1                           # 소산 분담의 계면 몫 키 (상이 아니다)
_NAME_SID = {v: k for k, v in SID_NAME.items()}
#: ★ RINT-01 (Codex 1단계 판정 10-03 · 1저자 비준) — **같은 상 계면은 pid 가 입자 번호인 상에서만.**
#   `rasterize` 는 AM 구를 찍을 때만 pid 를 쓰고, 첨가제 스탬프는 sid 만 바꾸고 pid (= 밑에 깔린 AM 번호) 를
#   남긴다 → VGCF|VGCF · SE|SE 를 pid 로 가르면 한 가닥 · 한 덩어리 안에 **가짜 계면**이 생긴다 (합성 반례:
#   VGCF|VGCF r=1e-4 에서 σ_e 11.1111 → 0.131752 · 가짜 면 2).  ② (VGCF 가닥 번호) · ③ (SE 입자 번호) 는 최종
#   sid 로 가린 **별도 이름공간 iid** 가 생긴 뒤에만 연다.  파서 · 솔버 입구 · 면 규칙 셋이 모두 강제한다.
PID_OWNER_SIDS = frozenset({1, 2})
#: ★ RINT-03 — 입자별 AM 전류 (`per_particle_current`) 의 정의 판.  'am-final-sid-v2' = **최종 sid 가 AM 인 셀**만
#   센다.  옛 판 (pid ≥ 0 만 봄) 은 AM pid 를 물려받은 탄소 셀 전류를 AM 평균에 넣었다 (합성 반례 121–127× ·
#   입자 순위 역전).  ⇒ r 를 끈 산출에서도 je · jb 가 **의도적으로** 바뀐다 (비트 동일 계약의 선언된 예외 ·
#   σ · φ · 소산 분담 · 반응 · patch 는 그대로).  payload 가 이 판 이름을 같이 싣는다.
PER_PARTICLE_CURRENT_DEF = 'am-final-sid-v2'


def _grid_fp(a):
    """진단 맥락 지문 (RINT-19) — dtype · 모양 · 바이트.  None → None.  복사하지 않는다 (C 연속이면)."""
    if a is None:
        return None
    x = np.ascontiguousarray(np.asarray(a))
    h = hashlib.blake2b(digest_size=16)
    h.update(x.dtype.str.encode()); h.update(repr(x.shape).encode()); h.update(x.data)
    return h.hexdigest()


def share_label(k):
    """소산 분담 dict 의 키 → 이름 (계면 몫은 `interface` · ①′ 부류별 막 몫은 `iface_am:<종류 쌍>`)."""
    if k == SID_INTERFACE:
        return 'interface'
    for _nm, _k in SID_IFACE_AM.items():
        if k == _k:
            return f'iface_am:{_nm}'
    return SID_NAME[k]


def parse_rint_table(specs):
    """CLI 문자열 목록 `['AM_S|VGCF=1e-3', …]` → `{(sid_lo, sid_hi): r [Ω·cm²]}`.  빈 입력 → None.
    거부: 모르는 이름 · 음수/비유한 · `=` 가 하나가 아님 · 쌍이 둘이 아님 · 같은 쌍 중복."""
    if not specs:
        return None
    out = {}
    for s in specs:
        s = str(s).strip()
        if s.count('=') != 1:
            raise ValueError(f'--step3-rint: `A|B=VAL` 꼴이어야 한다: {s!r}')
        names, val = s.split('=')
        parts = [p.strip() for p in names.split('|')]
        if len(parts) != 2:
            raise ValueError(f'--step3-rint: 상 쌍은 `A|B` 둘이어야 한다: {s!r}')
        try:
            sids = tuple(_NAME_SID[p] for p in parts)
        except KeyError as e:
            raise ValueError(f'--step3-rint: 모르는 상 이름 {e} (허용: {sorted(_NAME_SID)})') from None
        try:
            r = float(val)
        except ValueError:
            raise ValueError(f'--step3-rint: 값이 수가 아니다: {s!r}') from None
        if not (np.isfinite(r) and r >= 0.0):
            raise ValueError(f'--step3-rint: r 는 유한한 0 이상이어야 한다 (Ω·cm²): {s!r}')
        key = (min(sids), max(sids))
        if key[0] == key[1] and key[0] not in PID_OWNER_SIDS:
            raise ValueError(f'--step3-rint: 같은 상 계면 {SID_NAME[key[0]]}|{SID_NAME[key[0]]} 는 지원하지 않는다 — '
                             f'pid 는 AM 입자 번호뿐이다 (RINT-01 · 허용 = AM_S|AM_S · AM_P|AM_P): {s!r}')
        if key in out:
            raise ValueError(f'--step3-rint: 같은 쌍이 두 번 {SID_NAME[key[0]]}|{SID_NAME[key[1]]}')
        out[key] = r
    return dict(sorted(out.items()))


def _check_rint_table(rint):
    """솔버 입구 검사 — `{(int, int): float ≥ 0}` 만 받는다 (CLI 문자열은 `parse_rint_table` 로 먼저)."""
    if rint is None:
        return None
    if not isinstance(rint, dict):
        raise TypeError('rint 는 {(sid_a, sid_b): r[Ω·cm²]} dict 여야 한다 — CLI 문자열 목록은 '
                        'parse_rint_table 로 먼저 바꿀 것')
    out = {}
    for k, v in rint.items():
        if not (isinstance(k, tuple) and len(k) == 2):
            raise ValueError(f'rint 키는 (sid, sid) 튜플이어야 한다: {k!r}')
        #  ★ RINT-12 — 조용한 형 변환 금지: (1.7, 3) → (1, 3) · True → 1 · 모르는 sid 허용 뒤 왕복 실패
        for _s in k:
            if isinstance(_s, (bool, np.bool_)) or not isinstance(_s, (int, np.integer)):
                raise TypeError(f'rint 키의 sid 는 정수여야 한다 (float · bool 금지): {k!r}')
        a, b = int(k[0]), int(k[1])
        if a not in SID_NAME or b not in SID_NAME:
            raise ValueError(f'rint 키에 모르는 sid: {k!r} (허용 {sorted(SID_NAME)})')
        if a == b and a not in PID_OWNER_SIDS:
            raise ValueError(f'rint 같은 상 계면 {SID_NAME[a]}|{SID_NAME[a]} 는 지원하지 않는다 — pid 는 AM '
                             f'입자 번호뿐이다 (RINT-01 · 허용 sid {sorted(PID_OWNER_SIDS)})')
        if isinstance(v, (bool, np.bool_)) or not isinstance(v, (int, float, np.integer, np.floating)):
            raise TypeError(f'rint 값은 실수여야 한다 (bool · 문자열 금지): {k!r} → {v!r}')
        r = float(v)
        if not (np.isfinite(r) and r >= 0.0):
            raise ValueError(f'rint 값은 유한한 0 이상 (Ω·cm²): {k!r} → {v!r}')
        key = (min(a, b), max(a, b))
        if key in out and out[key] != r:
            raise ValueError(f'rint 같은 쌍에 다른 값: {key}')
        out[key] = r
    return dict(sorted(out.items()))


def rint_table_record(rint):
    """솔버 표 → 매니페스트 기록 `{'AM_S|VGCF': r}` (키 정렬 · JSON 형).  None → None."""
    if rint is None:
        return None
    return {f'{SID_NAME.get(a, str(a))}|{SID_NAME.get(b, str(b))}': float(v)
            for (a, b), v in _check_rint_table(rint).items()}


def rint_table_from_record(rec):
    """매니페스트 기록 → 솔버 표 (왕복).  빈 기록 → None."""
    if not rec:
        return None
    return parse_rint_table([f'{k}={v}' for k, v in rec.items()])


def rint_channel_check(rint, sigma_of_sid, sid=None):
    """RINT-14 (Codex 1단계 Q4 · 10-03) — 요청 쌍의 두 상이 **이 채널의 실제 σ** 에서 전도체인가 → 아니면 ValueError.

    절연 상이 낀 쌍은 어떤 면도 만들 수 없어 요청이 조용히 무효가 된다 (Codex: 서로 다른 상태를 "면 0" 하나로
    덮지 않는다).  기본 이름 허용목록이 아니라 override · 온도 적용이 끝난 **실제 표**로 판정한다 (σ_VGCF = 0 으로
    덮으면 VGCF 쌍도 거부).  1-D 표 = 표 값 (표가 0 이라 적은 상은 '없음' 이 아니라 '절연') · 복셀별 σ 장 = 그 상이
    격자에 **있을 때만** 셀 값 (없는 상 = 면 0 = 영수증 `absent_geometry` 소관)."""
    if not rint:
        return
    a = np.asarray(sigma_of_sid, np.float64)
    bad = []
    for (s1, s2), _v in rint.items():
        for s_ in sorted({int(s1), int(s2)}):
            nm = SID_NAME.get(s_, str(s_))
            if a.ndim == 1:
                if not (0 <= s_ < a.shape[0]) or not (a[s_] > 0.0):
                    bad.append(f'{nm}(σ={a[s_] if 0 <= s_ < a.shape[0] else "표 밖"})')
            else:
                if sid is None:
                    raise ValueError('rint_channel_check: 복셀별 σ 장에는 sid 격자가 필요하다')
                m = (np.asarray(sid) == s_)
                if m.any() and not (a[m] > 0.0).any():
                    bad.append(f'{nm}(격자의 σ 전부 0)')
    if bad:
        raise ValueError(f'rint: 이 채널의 실제 σ 표에서 절연인 상이 낀 쌍 — {sorted(set(bad))} '
                         f'(어떤 면도 만들 수 없어 요청이 조용히 무효가 된다 · RINT-14)')


def face_rint(sid_a, sid_b, rint, pid_a=None, pid_b=None):
    """면마다 r [Ω·cm²] (0 = 계면 아님).  다른 sid 면 = 표의 그 쌍 · 같은 sid 면 = 표에 (s, s) 가
    있고 **pid 가 둘 다 ≥ 0 이고 서로 다를 때만** (입자 경계).  pid 가 없으면 같은 상 면은 무영향."""
    sa = np.asarray(sid_a).astype(np.int64); sb = np.asarray(sid_b).astype(np.int64)
    lo = np.minimum(sa, sb); hi = np.maximum(sa, sb)
    r = np.zeros(sa.shape, np.float64)
    for (a, b), v in rint.items():
        if a == b and a not in PID_OWNER_SIDS:                   # RINT-01 — 입구 검사를 우회한 표도 막는다
            raise ValueError(f'face_rint: 같은 상 계면 sid {a} 는 지원하지 않는다 (pid = AM 입자 번호뿐)')
        if v <= 0.0:
            continue
        sel = (lo == a) & (hi == b)
        if a == b:
            if pid_a is None or pid_b is None:
                continue
            pa = np.asarray(pid_a); pb = np.asarray(pid_b)
            sel &= (pa >= 0) & (pb >= 0) & (pa != pb)
        r[sel] = v
    return r


def interface_face_factor(sa, sb, r_face, vox):
    """면 전도도 배율 R_half/(R_half + r′), R_half = vox/(2σa) + vox/(2σb) — r_face ≤ 0 인 면은
    **정확히 1.0**.  sa·sb [S/cm] (둘 다 > 0 인 면에서만 뜻이 있다) · vox [µm] · r_face [Ω·cm²].
    배율이 g 의 단위 규약(×vox 유무)과 무관하므로 조립과 진단이 같은 식을 쓴다."""
    sa = np.asarray(sa, np.float64); sb = np.asarray(sb, np.float64)
    r = np.asarray(r_face, np.float64)
    shape = np.broadcast(sa, sb, r).shape
    f = np.ones(shape, np.float64)
    sa_b = np.broadcast_to(sa, shape); sb_b = np.broadcast_to(sb, shape); r_b = np.broadcast_to(r, shape)
    m = (r_b > 0.0) & (sa_b > 0.0) & (sb_b > 0.0)
    if m.any():
        r_half = vox / (2.0 * sa_b[m]) + vox / (2.0 * sb_b[m])
        f[m] = r_half / (r_half + r_b[m] * RINT_OHM_CM2_TO_UM_CM_PER_S)
    return f


def interface_face_g(g0, sa, sb, r_face, vox):
    """조립·진단이 공유하는 한 줄 — r 가 있는 면만 g₀·배율, 나머지는 g₀ **그대로** (비트 동일)."""
    g0 = np.asarray(g0, np.float64)
    r = np.asarray(r_face, np.float64)
    m = r > 0.0
    if not m.any():
        return g0
    g = g0.copy()
    g[m] = g0[m] * interface_face_factor(np.asarray(sa, np.float64)[m],
                                         np.asarray(sb, np.float64)[m], r[m], vox)
    return g


def rint_ctx_from(res, sid, sigma_of_sid=None):
    """진단용 맥락 `(sid, 표, pid, vox)` — 솔브가 계면 항을 **실제로 건** 해 (면 > 0) 에서만, 아니면 None.

    ★ RINT-19 (Codex 10-03) — 맥락은 솔브가 본 격자의 **지문**과 대조한다.  옛 판은 호출자의 sid 를 그대로
    믿고 res 가 쥔 pid 참조를 썼다 → 같은 모양의 다른 sid 를 넘기면 계면 몫 0.95238 → 0 · |J|max 101× ·
    솔브 뒤 pid 배열을 바꾸면 저장된 면 수는 그대로인데 진단 계면 몫이 0 이 됐다.  ⇒ sid · pid · (주면) σ 의
    지문이 솔브 때와 다르면 **거부** (fail-closed · 진단 소비처 넷은 σ 를 넘긴다)."""
    _r = res.get('_rint')
    if not _r:
        return None
    tb, pid, fp_sid, fp_pid, fp_sig = _r
    if _grid_fp(sid) != fp_sid:
        raise ValueError('rint 맥락: 진단에 넘긴 sid 가 솔브한 sid 와 다르다 (RINT-19)')
    if pid is not None and _grid_fp(pid) != fp_pid:
        raise ValueError('rint 맥락: 솔브 뒤 pid 배열이 바뀌었다 (RINT-19)')
    if sigma_of_sid is not None and _grid_fp(np.asarray(sigma_of_sid, np.float64)) != fp_sig:
        raise ValueError('rint 맥락: 진단에 넘긴 σ 가 솔브한 σ 와 다르다 (RINT-19)')
    return (sid, tb, pid, float(res['vox_um']))


# Set True (mpm_webapp_payload --step3-gpu) to run the Kirchhoff CG on GPU (CuPy cuSPARSE) — a
# multi-M-dof fine-vox solve drops from ~1 h (CPU) to minutes.  Auto-falls back to scipy CPU if
# CuPy/CUDA is unavailable, so it is always safe to leave on.
GPU_SOLVE = False

#: ★★ GPU 폴백을 **막을** 것인가 (2026-08-26, kgy 실측 사고) — `--step3-require-gpu`.
#   왜: `EXPECT_BACKEND=gpu` 를 선언한 런에서 GPU OOM 이 나면 이 파일은 **조용히 CPU 로
#   내려가** 26.5 M dof 를 몇 시간 푼다.  그런데 그 결과는 `sr01_stamp_compare.py:307`
#   (`backend 가 cpu 인데 지금 돌면 gpu — 두 팔이 갈린다`) 이 **반드시 거부**한다.
#   ⇒ 계산을 다 하고 버리는 것이 확정된 경로다.  실측: vox 0.15 arm 15 에서 1 시간 낭비
#   (다른 프로세스가 GPU 를 물고 있었고, 그것이 끝난 뒤에도 이 프로세스는 못 돌아온다 —
#   폴백은 솔브 진입 시 한 번 정해진다).  a2/a4 는 dof 1.7배라 더 크게 당할 자리다.
#   ⇒ 선언한 런에서는 **폴백 순간 즉시 중단**해 자원을 아끼고 원인을 즉시 드러낸다.
#   ⚠ 기본 False = 현행 거동 (웹앱·CPU 전용 환경은 폴백이 정상 경로다).
REQUIRE_GPU = False

# ── SR-03: CPU CG 전처리 (기본 OFF = 현행 Jacobi 경로와 **bitwise 동일**) ─────────────────
#   합성 침대 실측 (전자 채널 σ 대비 1e5, rtol 1e-8, scripts/sr03_precond_bench.py — STEP3 의
#   **실제** solve_sigma_z 를 돌리며 전처리만 교체해 σ_eff 까지 비교):
#       dof      61,592 │ 144,888 │ 486,963      Jacobi 시간  3.9 │ 15.6 │ 74.9 s
#       Jacobi it 3,374 │   5,074 │   7,088      AMG 시간(빌드+) 4.5 │ 11.3 │ 51.0 s
#       AMG    it   218 │     222 │     261      속도            0.87× │ 1.38× │ 1.47×
#   ★ 채택 사유 ①은 속도가 아니라 **반복수 절벽**이다.  AMG 는 dof 를 7.9배 늘려도 218→261
#     (평평)인데 Jacobi 는 3,374→7,088 로 자란다 (겉보기 dof^0.36; 구간지수는 0.48→0.28 로
#     일정하지 않아 외삽은 어림값).  production 2.7 M dof 로 어림하면 Jacobi ≈1.3 만 회 =
#     maxiter 30,000 의 절반 — 더 미세한 vox 나 더 높은 대비면 **미수렴("σ UNRELIABLE")**
#     으로 떨어질 여지가 있고, 그때 잃는 것은 시간이 아니라 런 전체다.
#   ⚠ 사유 ②(속도)는 **작다** — 실측 1.4–1.5×, 2.7 M 외삽 ≈2.4×.  벽시계의 진짜 치료는
#     GPU(cupy)다.  AMG 를 "58 분 → 몇 분" 으로 팔지 말 것.  (실제 arm A 2.7 M dof 3,485 s
#     는 위 합성 스케일링의 4.4배 — 실침대가 그만큼 더 어렵다는 뜻이고, 그렇다면 AMG 이득도
#     2.4배보다 클 **것으로 보이나** 그것은 추론이지 측정이 아니다.)
#   ★ 해-불변 확인 (채택의 조건): 같은 계를 두 전처리로 풀고 **σ_eff** 비교 — rtol 1e-8 에서
#     0.0007–0.014 %, rtol 1e-10 에서 0.0001 %.  (‖Δφ‖_rel 은 1e-3 까지 벌어지지만 그 차이는
#     전류를 안 나르는 약결합 영역에 살아 σ 로 넘어오지 않는다.)
#   ⚠ 그래도 **A/B 두 팔은 같은 전처리여야 한다** — 0.01 % 는 작지만 Δσ_e 가 그보다 작을
#     수 있다.  그래서 `LAST_BACKEND['precond']` 를 manifest 에 남기고 비교기가 검사한다.
#   ⚠ v1 은 **CPU 경로 전용**.  GPU 경로는 이미 빠르고, GPU V-cycle 미러는 STEP4 에 선례가
#     있으나(step4_dyn._gpu_vcycle_wrap) 여기 필요가 아직 측정되지 않았다.
#   ⚠ 위는 **합성 침대**다 — 실침대(fibre/AM 분포)에서의 재확인은 SR-01 종료 후.
AMG_SOLVE = False


#: ★ RC6-08 (Codex 6회차): 마지막 solve 의 **실제 backend**.  요청(GPU_SOLVE)과 실제가
#:   다를 수 있는데(CuPy 부재 → CPU fallback) 옛 코드는 print 만 하고 반환 dict 에
#:   backend/gpu_used/fallback_reason 이 전부 없었다 — 결과만 보면 GPU 로 푼 것인지
#:   CPU 로 떨어진 것인지 **구분 불가**였다.  로그는 보존되지 않으므로 산출물에 남긴다.
#:   SR-03 로 `precond` 추가 — 전처리도 요청과 실제가 갈릴 수 있다(pyamg 부재 → Jacobi).
LAST_BACKEND = {'requested': None, 'used': None, 'fallback_reason': None, 'precond': None}

#: CG 최대 반복.  ⚠ 2026-08-20 — 옛 판은 30000 **하드코딩**이라, 조건수가 나쁜 진단 팔
#:   (σ_VGCF=7854 → σ_VGCF/σ_AM = 785,400×) 이 rtol 1e-8 에 못 닿고 `info=30000` 으로
#:   끝났다 (CL-48 실측: resid 7.7e-08 / 5.8e-08 → payload 가 `σ UNRELIABLE` 로 표시).
#:   ⇒ payload 가 `--step3-maxiter` 로 올릴 수 있게 전역으로 뺀다.  **기본값은 안 바꾼다**
#:   (기존 런의 규약을 유지).  GPU 경로는 Jacobi 고정이라 AMG 로는 못 푼다.
CG_MAXITER = 30000

#: ★ 2026-10-20 (Rint ② 설계 v1 §6 · N15) — CG 정지 rtol 노브 (numeric · `--step3-rtol`).  기본 1e-8 = 옛 고정값 그대로 (비트 같음).
#:   다음 세대 꼴 (섬유 σ 7,853.98 · 대비 1.9e6) 에서 1e-8 은 틀린 σ 를 수렴으로 인증한다 [탐침 · `step3_conv_cert.probe_table`].
#:   기본이 아닐 때만 LAST_BACKEND 에 'rtol' 이 실린다 (끔 = 매니페스트 바이트 그대로).
CG_RTOL = 1.0e-8
_CG_RTOL_DEFAULT = 1.0e-8
#: 수렴 증서 (ⓐ 정지 rtol ≤ 봉인 · ⓑ 판 전류 불균형 ≤ ε_I · ⓒ rtol/100 이어 풀기 |Δσ|/σ ≤ 1e-4 · ★ 10-21 ⓓ 목표량 증서 (에너지 상한 ·
#:   보정 흐름 하한 → 게시 G 의 보장 오차 ≤ 1e-4) · 해 상태 — `step3_conv_cert`) — 켜면 실패 = 미수렴.  조기 반환 해에도 상태 증서.
#:   ★ 10-21 (사전 리뷰 PRE-impl-07) — 주 솔브의 증서 (양의 해 · 영값 · 조기 반환) 에 결합 칸 (그 솔브의 격자 · σ 표 · 계획 지문 —
#:   `step3_conv_cert.bind_record`) · ~~SV 반사실 진단 솔브의 증서 (접합 기록 안) 는 결합 칸 없음 (계약 밖 진단)~~ → ★ 10-23 (Codex 재검토
#:   RCA2-01 · 04 · 1저자 Q1 (가)) SV 반사실 끝 증서 (양의 해 · +∞ 끝의 영값 위상) 도 같은 결합 칸 · 주 해 증서를 반사실 기록에 싣는다
#:   (`conv_cert_full` · 증서 구간 판정 · 기록 계약 `ca_ext_svcf.sv_cf_problem` 이 대조).
#:   기본 False = 이 파일의 솔브 결과 · 키가 옛 그대로.
CONV_CERT = False
#: ★ Z3 (2026-10-20 · 등록 R §11 숫자 탐침 칸 — σ 아님) — 마지막 `_solve_cg` 의 CG **반복 수** (수렴했을 때도).  수렴 증서
#:   (`CONV_CERT`) 를 켰을 때만 센다 (CG callback) — 끔 = 옛 호출 그대로 (callback 인자 없음 · 해 · info 비트 같음).
#:   `None` = 안 셌다 (증서 끔 · 시험이 바꿔 낀 솔버).  `solve_sigma_z` 가 해 (`cg_iters`) · 증서 (`iters` · `resolve_iters`) 로 옮긴다.
LAST_CG = {'iters': None}


def _amg_M(L):
    """pyamg smoothed-aggregation 전처리 (그래프-라플라시안 특화).  실패하면 None → Jacobi.

    ★ 같은 패턴이 이미 리포에 있다 (`step4_dyn._amg_M`).  그 **코드**를 부르지 않은 이유는
    의존 방향이다 — STEP4 가 STEP3 격자를 소비하므로 STEP3 → STEP4 import 는 역방향이고,
    그 헬퍼는 step4 모듈 전역(GPU, MPM_S4_GPU_AMG)에 묶여 있어 STEP3 에서 부르면 STEP4 의
    GPU 스위치가 STEP3 거동을 조용히 바꾼다.  패턴만 따르고 결합은 만들지 않는다."""
    try:
        import pyamg
    except ImportError:
        LAST_BACKEND['fallback_reason'] = 'pyamg 미설치 → Jacobi'
        print('    ⚠ STEP3 AMG 요청됐으나 pyamg 미설치 → Jacobi-CG 로 진행 '
              '(`python3 -m pip install pyamg`)', flush=True)
        return None
    try:
        import time as _t
        t0 = _t.time()
        print(f'    STEP3 AMG 전처리 구축 중 (dof {L.shape[0]:,})…', flush=True)
        ml = pyamg.smoothed_aggregation_solver(sparse.csr_matrix(L), max_coarse=500)
        print(f'    STEP3 AMG 구축 완료 (levels {len(ml.levels)}, {_t.time() - t0:.0f}s) → CG',
              flush=True)
        return ml.aspreconditioner(cycle='V')
    except Exception as _e:                                # noqa: BLE001 — 전처리 실패는 치명적이지 않다
        LAST_BACKEND['fallback_reason'] = f'AMG build 실패 {type(_e).__name__}: {_e}'
        print(f'    ⚠ STEP3 AMG 구축 실패 ({type(_e).__name__}: {_e}) → Jacobi-CG', flush=True)
        return None


def _solve_cg(L, b, x0=None, rtol=None):
    """Preconditioned CG for the SPD Kirchhoff system L·φ = b.  GPU (CuPy) when GPU_SOLVE and
    the import succeeds, else scipy CPU — same matrix + same rtol (1e-8), so φ is **expected
    within solver tolerance** (backend swap only).
    ⚠⚠ 2026-08-27 (Codex R7 Q4c) — 옛 문구는 *"SAME φ"* 였다.  그것은 **선언이지 측정이
    아니다**: 이 리포는 같은 계를 CPU/GPU 양쪽에서 풀어 σ 를 비교한 적이 없다.  ⇒ 문구를
    약화하고, **CPU/GPU 팔을 섞는 cohort 는 금지**한다 (허용오차를 사전등록하기 전까지).
    실제 사용 backend 는 `LAST_BACKEND['used']` 로 봉인된다.
    CPU preconditioner = Jacobi (default) or AMG when AMG_SOLVE (SR-03, 해-불변 측정 완료).
    Returns (phi: np.ndarray, info: int).

    ★ 실제로 쓴 backend·전처리를 모듈 전역 `LAST_BACKEND` 에 남긴다 (RC6-08 / SR-03).
    ★ 2026-10-20 — x0 (초기값 · 수렴 증서 ⓒ 이어 풀기) · rtol (호출별 · None = `CG_RTOL`) — 둘 다 None 이고 CG_RTOL 기본이면
      옛 호출 그대로 (비트 같음)."""
    diag = L.diagonal()
    _rt = CG_RTOL if rtol is None else float(rtol)
    _x0k = {} if x0 is None else {'x0': np.asarray(x0, np.float64)}
    #  ★ Z3 — 반복 수 (증서 켤 때만 · 끔 = 빈 dict 라 아래 호출들이 옛 인자 그대로)
    LAST_CG['iters'] = None
    _cnt = [0]
    _cbk = {}
    if CONV_CERT:
        def _tick(_xk):
            _cnt[0] += 1
        _cbk = {'callback': _tick}
    LAST_BACKEND.update(requested=('gpu' if GPU_SOLVE else 'cpu'),
                        used=None, fallback_reason=None, precond=None)
    LAST_BACKEND.pop('rtol', None)
    if CG_RTOL != _CG_RTOL_DEFAULT:                        # 노브를 켰을 때만 기록 (끔 = 옛 키 그대로)
        LAST_BACKEND['rtol'] = float(CG_RTOL)
    if GPU_SOLVE:
        try:
            import cupy as cp
            import cupyx.scipy.sparse as cxs
            from cupyx.scipy.sparse.linalg import cg as cg_gpu
            Lg = cxs.csr_matrix(L.astype(np.float64))
            bg = cp.asarray(b, dtype=np.float64)
            Mg = cxs.diags(1.0 / cp.asarray(diag))
            _x0g = {} if x0 is None else {'x0': cp.asarray(x0, dtype=np.float64)}
            try:
                xg, info = cg_gpu(Lg, bg, tol=_rt, maxiter=CG_MAXITER, M=Mg, **_x0g, **_cbk)
            except TypeError:                              # newer CuPy renamed tol → rtol/atol
                _cnt[0] = 0
                xg, info = cg_gpu(Lg, bg, rtol=_rt, atol=0.0, maxiter=CG_MAXITER, M=Mg, **_x0g, **_cbk)
            LAST_BACKEND.update(used='gpu', precond='jacobi')   # v1: GPU 경로는 Jacobi 유지
            if _cbk:
                LAST_CG['iters'] = int(_cnt[0])
            return cp.asnumpy(xg), int(info)
        except Exception as _e:
            LAST_BACKEND['fallback_reason'] = f'{type(_e).__name__}: {_e}'
            if REQUIRE_GPU:
                #  fail-closed — 폴백 결과는 backend 봉인이 어차피 거부한다 (sr01:307).
                #  몇 시간 CPU 를 태우고 버리는 대신 **지금** 멈춘다.
                raise SystemExit(
                    f'STEP3 ABORT — GPU 솔브 실패인데 `--step3-require-gpu` 다: '
                    f'{type(_e).__name__}: {_e}\n'
                    f'     CPU 폴백은 backend 봉인(expect gpu)이 거부하므로 계산을 버리게 된다.\n'
                    f'     조치: GPU 를 비우고(nvidia-smi 로 점유 PID 확인) 같은 명령으로 재개하면 '
                    f'끝난 팔은 SKIP 되고 이 팔만 다시 돈다.')
            print(f'    STEP3 GPU solve unavailable ({type(_e).__name__}: {_e}) → CPU fallback', flush=True)
    LAST_BACKEND['used'] = 'cpu'
    Minv = _amg_M(L) if AMG_SOLVE else None                # SR-03 opt-in; None → 현행 Jacobi
    LAST_BACKEND['precond'] = 'amg' if Minv is not None else 'jacobi'
    if Minv is None:
        Minv = sparse.diags(1.0 / diag)
    _cnt[0] = 0
    #  ★ 10-24 (SELF-133) — 옛 `except TypeError → cg(tol=…)` (scipy < 1.12 의 legacy 정지) 를 뺐다 · 옛 판의 `cg` = `_cg_v112` (위)
    _r = cg(L, b, rtol=_rt, maxiter=CG_MAXITER, M=Minv, **_x0k, **_cbk)
    if _cbk:
        LAST_CG['iters'] = int(_cnt[0])
    return _r


def _ball_cells(centre_um, rad_um, lo, vox, n):
    """구 하나가 덮는 셀 — **한 판정식** (`rasterize._ball` 과 ①′ 청구자 `am_iface_ledger` 가 같이 쓴다 · 규율 ① ·
    계약 v3.1 §1 ③ "구 포함 판정 = `_ball` 과 같은 식").  → `(i0, i1, mask)` 또는 None (상자 밖).

    mask = 셀 중심 (격자 단위 ijk + ½) 이 구 안 (경계 포함 ≤).  식 · 연산 순서는 옮기기 전 `_ball` 과 같다
    (원소마다 비트 같음 — `scripts/test_rint_g2_am_iface.py` 의 옛 raster 지문 대조가 지킨다)."""
    c = (centre_um - lo) / vox; rr = rad_um / vox
    i0 = np.maximum(0, np.floor(c - rr).astype(int)); i1 = np.minimum(n - 1, np.ceil(c + rr).astype(int))
    if (i1 < i0).any():
        return None
    gx, gy, gz = np.ogrid[i0[0]:i1[0] + 1, i0[1]:i1[1] + 1, i0[2]:i1[2] + 1]
    m = ((gx + 0.5 - c[0]) ** 2 + (gy + 0.5 - c[1]) ** 2 + (gz + 0.5 - c[2]) ** 2) <= rr * rr
    return i0, i1, m


def am_bridge_pairs(am_c, am_r, tol_am_um):
    """AM–AM 접촉 브리지 **쌍 집합** — `rasterize` 와 ①′ 원장이 같이 부르는 한 함수 (규율 ① · v2 §3-3 "브리지 쌍" 행 ·
    v3.1 §1 ③).  쌍 규칙 = 표면 간극 ≤ `tol_am_um` (econn 규약).  → `[(i, j, d), …]` (i < j · 입력 행 번호 ·
    d = 중심 거리 µm).  ⚠ 순서 = 옛 루프가 `cKDTree.query_pairs` 집합을 돌던 순서 그대로 (브리지 덮어쓰기 순서가
    sid 를 정하므로 바꾸지 않는다 — 옛 raster 와 비트 같음)."""
    out = []
    if len(am_c) < 2:
        return out
    from scipy.spatial import cKDTree
    tree = cKDTree(am_c)
    for i, j in tree.query_pairs(2.0 * float(am_r.max()) + tol_am_um):
        d = float(np.linalg.norm(am_c[i] - am_c[j]))
        if d <= am_r[i] + am_r[j] + tol_am_um:
            out.append((i, j, d))
    return out


def _am_bridge_mid(am_c, am_r, i, j, d):
    """브리지 공 중심 — 두 표면 사이 구간의 중점, **(i, j) 계산 순서**대로 (옛 식 그대로 · RINTV-02: 순서를 바꾸면 끝자리가
    달라질 수 있다)."""
    return am_c[i] + (am_c[j] - am_c[i]) * (am_r[i] + 0.5 * (d - am_r[i] - am_r[j])) / max(d, 1e-12)


def _am_bridge_radius(vox, bridge_um):
    """브리지 공 반경 — 기본 `1.2·vox` (격자에 묶임) · `bridge_um` 을 주면 물리 고정 (CL-87 · CL-88)."""
    return 1.2 * vox if bridge_um is None else float(bridge_um)


def rasterize(am_c, am_r, am_t, add_pts, add_phase, box_lo, box_hi, vox, tol_am_um=0.10, se_pts=None,
              sdcp_sphere_d_um=0.0, sdcp_yield_to_vgcf=False, sdcp_bridge_um=0.0,
              add_fid=None, fid_gap_tol=2.0, add_kind=None, bridge_um=None,
              ptfe_block_um=0.0, ptfe_block_targets=(6,), ptfe_block_periodic=False):
    """Voxel σ-id grid: 0 = non-conductive, 1 = AM_S, 2 = AM_P, 3.. = additives (2,3,5 → 3,4,5).
    Also returns per-voxel AM particle index (-1 = not AM) for per-particle currents.
    am_t: 1 = AM_P, 2 = AM_S (LIGGGHTS type convention).  All coords in one frame (µm).

    AM-AM CONTACT BRIDGES: a DEM contact's Hertz neck (a ≈ √(Rδ) ~ 0.3-0.5µm) is at/below the
    voxel size, so plain rasterization randomly DROPS touching contacts (6-neighbour faces need
    shared/adjacent voxels) — the integration test showed a non-percolating AM skeleton from
    quantization alone.  Fix = stamp a 1-voxel-radius bridge at the contact midpoint of every
    AM pair with gap ≤ tol_am_um (the SAME contact rule econn uses), σ-id of the SOFTER particle
    (series-conservative).  Neck AREA is thereby quantized to ~vox² — a documented v1 limit,
    identical across compared runs (relative trust preserved)."""
    lo = np.asarray(box_lo, np.float64)
    n = np.maximum(1, np.ceil((np.asarray(box_hi) - lo) / vox).astype(int))
    sid = np.zeros(tuple(n), np.int8)
    pid = np.full(tuple(n), -1, np.int32)
    # SE (sid 6, optional): stamped FIRST = lowest priority — AM / contact bridges / additives
    # overwrite.  Enables the IONIC solve (SE+SDCP conduct; AM/carbon/PTFE ion-block) on the SAME
    # grid: the electronic table just sets σ(SE)=0.  Chunked (tens of millions of points).
    if se_pts is not None and len(se_pts):
        for c0 in range(0, len(se_pts), 8_000_000):
            ijk = np.floor((np.asarray(se_pts[c0:c0 + 8_000_000], np.float64) - lo) / vox).astype(int)
            ok = ((ijk >= 0) & (ijk < n)).all(1)
            ijk = ijk[ok]
            sid[ijk[:, 0], ijk[:, 1], ijk[:, 2]] = 6

    def _ball(centre_um, rad_um, s, particle):
        #  ①′ (10-07) — 판정식을 `_ball_cells` 로 뺐다 (청구자 원장과 **같은 식** · 규율 ①).  식 · 연산 순서 그대로.
        _hit = _ball_cells(centre_um, rad_um, lo, vox, n)
        if _hit is None:
            return
        i0, i1, m = _hit
        sub = sid[i0[0]:i1[0] + 1, i0[1]:i1[1] + 1, i0[2]:i1[2] + 1]
        sub[m] = s
        if particle >= 0:
            psub = pid[i0[0]:i1[0] + 1, i0[1]:i1[1] + 1, i0[2]:i1[2] + 1]
            psub[m] = particle

    def _ball_empty(centre_um, rad_um, s):
        """`_ball` 과 같되 **빈 셀에만** 쓴다 (브리지 전용).  pid 는 안 건드린다."""
        c = (np.asarray(centre_um, np.float64) - lo) / vox; rr = rad_um / vox
        i0 = np.maximum(0, np.floor(c - rr).astype(int))
        i1 = np.minimum(n - 1, np.ceil(c + rr).astype(int))
        if (i1 < i0).any():
            return
        gx, gy, gz = np.ogrid[i0[0]:i1[0] + 1, i0[1]:i1[1] + 1, i0[2]:i1[2] + 1]
        m = ((gx + 0.5 - c[0]) ** 2 + (gy + 0.5 - c[1]) ** 2 + (gz + 0.5 - c[2]) ** 2) <= rr * rr
        sub = sid[i0[0]:i1[0] + 1, i0[1]:i1[1] + 1, i0[2]:i1[2] + 1]
        sub[m & (sub == 0)] = s

    for i in range(len(am_c)):                             # AM spheres (few hundred): ball masks
        _ball(am_c[i], am_r[i], 2 if am_t[i] == 1 else 1, i)   # type 1 = AM_P → sid 2; 2 = AM_S → sid 1
    # AM-AM contact bridges (econn contact rule: gap ≤ tol) — NO blanket except here: silently
    # losing every bridge = the fragmented-skeleton σ-collapse the integration test exists to catch
    #  ①′ (10-07) — 쌍 집합 · 중심식 · 반경을 원장과 **같은 함수**로 (규율 ① · v3.1 §1 ③).  순서 · 식 그대로 (비트 같음).
    if len(am_c) >= 2:
        for i, j, d in am_bridge_pairs(am_c, am_r, tol_am_um):
            mid = _am_bridge_mid(am_c, am_r, i, j, d)
            soft = i if am_t[i] == 1 else j                # the LOWER-σ particle = AM_P (0.005 < AM_S 0.010)
            s = 2 if (am_t[i] == 1 or am_t[j] == 1) else 1   # mixed / P-P → AM_P id (series-conservative);
            # ★ 2026-08-13: 브리지 반경이 **격자에 묶여 있다** (1.2·vox).  격자를 조이면
            #   AM 접촉 목도 같이 얇아져 격자 수렴 시험에서 탄소 효과와 **섞인다** (CL-21).
            #   `bridge_um` 을 주면 물리 단위로 **고정**한다.  기본 None = 현행(1.2·vox) 이라
            #   기존 호출은 바이트 동일.
            _ball(mid, _am_bridge_radius(vox, bridge_um), s, soft)
    # additive points: cell-stamp (carbon overwrites AM at shared cells — the higher-σ phase wins,
    # which is the physical series-shortcut at an anchored contact)
    if add_pts is not None and len(add_pts):
        # ── ★ SR-01 (2026-08-11): 섬유 첨가제의 **점-스탬프는 6-face 연결을 깬다** ──────────
        #   점 간격이 MPM dx 에 묶여 σ-격자와 무관하게 고정돼 있어, 선이 복셀 경계를 비스듬히
        #   지나면 연속한 두 점이 **face 를 공유하지 않는 대각 셀**에 찍힌다.  솔버는 6-face
        #   conductance 를 쓰므로 그 조각들은 **전기적으로 분리**된다.
        #   실침대 실측 (킷 5침대, VGCF 1 wt%, vox 0.4): 섬유의 **68.5–86.4 % 가 평균 2.6–3.4
        #   조각**으로 끊긴다.  선분 스탬프로 바꾸면 단절이 18.4–72.5 % 로 내려가고, 남는 것은
        #   **AM 이 섬유를 끊은 물리적 단절**과 ±4 %p 안에서 일치한다
        #   (docs/data/sr01_realbed_ab.csv · scripts/sr01_realbed_ab.py).
        #   ⚠ 점 재샘플링으로는 못 고친다 (0.02·vox 로 조여도 31 % 잔존) — Codex CR-01.
        #   ⚠ 아티팩트 크기가 **AM 수에 강하게 의존**(+13.9~+50.1 %p) → 조성이 다른 침대끼리
        #     비교하면 **차등 적용**된다 = 공통모드로 상쇄되지 않는다 (Codex CR-02).
        #   ⇒ `add_fid` (섬유 id) 를 주면 **선분 스탬프**로 굽는다.  **기본은 현행 점 스탬프**
        #     (opt-in) — Δσ_e 크기를 재기 전에 default 를 바꾸지 않는다.
        if add_fid is not None and len(add_fid) == len(add_pts):
            ijk, ph = _fibre_segment_ijk(add_pts, add_phase, add_fid, lo, vox, n, fid_gap_tol,
                                         add_kind=add_kind)
        else:
            ijk = np.floor((add_pts - lo) / vox).astype(int)
            ok = ((ijk >= 0) & (ijk < n)).all(1)
            ijk, ph = ijk[ok], add_phase[ok]
        # ── SDCP 구 스탬프 셀을 **미리** 구해 둔다 (아래 루프의 제자리에서 쓴다) ──────────
        #   ⚠⚠ 실사고 2026-08-16: 처음엔 이 계산을 루프 **뒤에** 놓았다.  그러면 SDCP 가
        #     PTFE(sid 7)·SWCNT(sid 8)를 **덮어버린다** — 점 스탬프에서는 그 둘이 뒤에 와서
        #     SDCP 를 덮는다 (루프 순서가 곧 우선순위다).  PTFE 는 **절연체**라 SDCP 가 그
        #     셀을 먹으면 σ_e 가 부풀어 **가짜 이득**이 난다.  규약을 바꾸는 것이 목적이
        #     아니라 **부피만** 고치는 것이므로 우선순위는 점 스탬프와 **같아야 한다**.
        _sph_ijk = None
        if sdcp_sphere_d_um:
            _d = float(sdcp_sphere_d_um)
            _p5 = add_pts[add_phase == 5]
            #  ⚠ 게이트는 SDCP 가 **실재할 때만** 발화한다 (리뷰 ② LOW: 옛 판은 phase-5 가
            #    0개인 침대(SBE)에서도 vox 만 거칠면 막았다 — no-op 인데 막을 이유가 없다).
            if len(_p5) and _d / vox < 2.0:
                #  ★★ 2026-08-18 (심층 리뷰 ① B2) — `ValueError` 였다.  그런데 호출자
                #    `mpm_webapp_payload.py:1645` 의 blanket `except Exception` 이 그것을
                #    **삼켜** step3.status='failed' 만 적고 payload 를 정상적으로 쓰고
                #    **exit 0** 으로 끝냈다.  ⇒ 러너의 fail-fast 가 발화하지 않고,
                #    쓰레기 JSON 이 `[ -s "$OUT" ] && SKIP` 로 **영구 캐시**된다.
                #    게다가 SBE 는 `len(_p5)==0` 이라 게이트가 안 열려 **정상 완주**하므로
                #    "SBE 8팔 완주 + DBE 8팔 조용히 실패" 로 GPU 수 시간을 버린다.
                #    `SystemExit` 는 BaseException 이라 그 except 를 **통과**한다 —
                #    바로 옆 `--fibre` 실패 경로가 이미 그 규약을 쓰고 있었다 (:852, :883).
                raise SystemExit(
                    f'부피-보존 구 스탬프: d/vox = {_d / vox:.2f} < 2 거부.  '
                    f'⚠ 근거 정정(리뷰 ②): 전소실 절벽은 √3 ≈ 1.732 (실측: 1.5 에서 소실 '
                    f'1.24 %, 1.74~2.0 에서 0 %) — 2.0 을 유지하는 진짜 이유는 per-입자 '
                    f'부피 산포가 [0.48, 1.91]× 로 커서다 (배치-평균은 무편향).  '
                    f'vox ≤ {_d / 2:.3f} µm 를 쓰거나 점 스탬프로 남길 것')
            _r = _d / 2.0
            if len(_p5):
                _off = int(np.ceil(_r / vox)) + 1
                _rg = np.arange(-_off, _off + 1)
                _ax, _ay, _az = np.meshgrid(_rg, _rg, _rg, indexing='ij')
                _b = np.floor((_p5 - lo) / vox).astype(int)
                _acc = []
                for a_, b_, c_ in zip(_ax.ravel(), _ay.ravel(), _az.ravel()):
                    _q = _b + (a_, b_, c_)
                    _ok = ((_q >= 0) & (_q < n)).all(1)
                    if not _ok.any():
                        continue
                    _cc = (_q[_ok] + 0.5) * vox + lo                 # 셀 중심 (절대 좌표)
                    _in = ((_cc - _p5[_ok]) ** 2).sum(1) <= _r * _r
                    if _in.any():
                        _acc.append(_q[_ok][_in])
                if _acc:
                    _sph_ijk = np.unique(np.vstack(_acc), axis=0)
        # ── ★★★ SDCP 접촉 브리지 (2026-08-25, SELF-11 / Q-B2 판별 노브) ─────────────────
        #   왜: 이 파일 docstring 이 이미 적었듯 *"plain rasterization randomly DROPS
        #   touching contacts (6-neighbour faces need shared/adjacent voxels)"* 다.  그래서
        #   **AM–AM 은 접촉 브리지**로, **섬유는 `_fibre_segment_ijk`(6-면 보장)** 로 고쳐
        #   두었는데 **SDCP 구만 무처리**였다 — 그리고 전자 격자에서 SBE↔DBE 의 유일한
        #   차이가 SDCP 다 (CL-33 의 SBE 음성 대조 8/8 셀 단위 동일이 증인) ⇒ 이 누락은
        #   **DBE 전용 오차**라 침대 간 공통모드 상쇄가 원리적으로 없다.
        #   실측 (Ø0.30, 고정 격자, 위치·방향 무작위 200회): 생산 격자 vox 0.15(d/vox 2.00)
        #   에서 **참 접촉의 35 % 누락** · 10 % 물리적 틈의 **32.5 % 가 가짜 연결**.  두 오차는
        #   σ 에 반대 방향이고 h 수렴 속도가 달라 `R = R∞ − C·h^p`(지배 오차 하나 가정)가
        #   **원리적으로 안 맞는다** — CL-41 의 "어떤 p > 0 도 안 맞는다" 와 정합.
        #   ⇒ 이 노브는 **vox 를 안 바꾸고 접촉 검출만** 고친다.  상관을 인과로 바꾸려면
        #     노브를 vox 에서 떼어내야 한다 (CL-43 이 걸린 함정).
        #   ⚠ **기본 0.0 = off → 바이트 동일.**  생산 규약을 바꾸지 않는다 (진단 팔이다).
        #   ⚠ σ-id 는 AM–AM 과 **같은 series-conservative 규칙** — 낮은 σ 쪽을 쓴다.
        #     (SDCP–SDCP → 5 · SDCP–VGCF → 3 · SDCP–AM → 그 AM).  브리지가 없던 곳에
        #     **더 좋은 도체를 새로 깔지 않는다** = 이득을 인위로 만들지 않는다.
        _brg = []
        #  ⚠⚠ **fail-closed** (2026-08-27) — 브리지 기하는 구 반지름 r = d/2 에서 정의된다.
        #     점 스탬프(`sdcp_sphere_d_um = 0`)로 브리지를 요청하면 옛 코드는 이 블록을
        #     **조용히 건너뛰어** 처리팔이 대조팔과 **바이트 동일**해졌다 (fail-open).
        #     2026-08-27 A 트랙 4팔이 정확히 그렇게 무효화됐다 (`INVALID_TREATMENT_NOT_APPLIED`,
        #     docs/reviews/a_track_status_20260827.md) — 매니페스트는 요청값 0.08 을 적었고
        #     격자에는 브리지가 없었다.  ⇒ 이제 **거부한다**: "요청했는데 안 걸렸다" 를
        #     런이 끝난 뒤 판정기가 발견하는 게 아니라 **격자를 찍기 전에** 죽인다.
        if float(sdcp_bridge_um) > 0.0 and not sdcp_sphere_d_um:
            raise ValueError(
                "sdcp_bridge_um > 0 requires the SDCP sphere stamp (sdcp_sphere_d_um > 0): "
                "the bridge geometry is defined from the sphere radius r = d/2, so under the "
                "point stamp it would be a silent no-op.  Pass --step3-sdcp-sphere-d "
                "(kit: SDCP_SPHERE_D=0.30) together with --step3-sdcp-bridge, or set the "
                "bridge back to 0.  [fail-closed guard added 2026-08-27 after the A-track "
                "treatment arms came out bit-identical to their controls]")
        if sdcp_sphere_d_um and float(sdcp_bridge_um) > 0.0:
            _tol = float(sdcp_bridge_um)
            _rs = float(sdcp_sphere_d_um) / 2.0
            _p5b = add_pts[add_phase == 5]
            if len(_p5b):
                from scipy.spatial import cKDTree as _KD
                _t5 = _KD(_p5b)
                #  ⓐ SDCP–SDCP : 표면 간극 ≤ tol
                for _i, _j in _t5.query_pairs(2.0 * _rs + _tol):
                    _mid = 0.5 * (_p5b[_i] + _p5b[_j])
                    _brg.append((_mid, 5))
                #  ⓑ SDCP–AM : 낮은 σ 쪽(AM)의 sid 를 쓴다
                if len(am_c):
                    _ta = _KD(np.asarray(am_c, np.float64))
                    for _k, _c5 in enumerate(_p5b):
                        for _a in _ta.query_ball_point(_c5, _rs + float(np.max(am_r)) + _tol):
                            _d = float(np.linalg.norm(_c5 - am_c[_a]))
                            if _d <= _rs + float(am_r[_a]) + _tol:
                                _brg.append((0.5 * (_c5 + am_c[_a]),
                                             2 if am_t[_a] == 1 else 1))
                #  ⓒ SDCP–VGCF : 낮은 σ 쪽(VGCF, sid 3)
                _pv = add_pts[add_phase == 2]
                if len(_pv):
                    _tv = _KD(_pv)
                    for _k, _c5 in enumerate(_p5b):
                        for _v in _tv.query_ball_point(_c5, _rs + _tol):
                            _brg.append((0.5 * (_c5 + _pv[_v]), 3))
        # ── σ-치환 판별 팔 (2026-08-18, CL-43) — SDCP 가 VGCF 셀에 **양보**한다 ───────────
        #   왜: 상별 원장이 SDCP 셀의 39.8 %(vox 0.4) ~ 7.2 %(0.15) 가 **원래 VGCF 셀**임을
        #   보였다.  그 셀은 dof(도체 셀 수) 가 안 변하고 **σ 만** 11.0 → 250 (거친 격자에서
        #   22.6배) 로 올라간다 = "새 도체 부피" 가 아니라 **기존 도체의 σ 업그레이드**.
        #   dof 원장으로는 원리적으로 안 보이는 채널이라(심층 리뷰 ③) 이 팔로 **끈다**.
        #   ⚠ 이것은 **진단 전용**이다 — 생산 규약은 여전히 SDCP 가 VGCF 를 덮는 쪽이다
        #     (실물에서 SDCP 는 탄소 위에 코팅되므로 그 셀의 σ 가 오르는 것 자체는 물리다;
        #      문제는 **크기가 격자의 함수**라는 것이지 존재가 아니다).
        #   ⚠ 양보해도 그 셀은 **여전히 도체**(VGCF σ)라 연결성이 끊기지 않는다 — 그래서
        #     이 팔은 "부피" 채널을 죽이지 않고 "σ 업그레이드" 채널만 죽인다.
        _yield_vgcf = bool(sdcp_yield_to_vgcf)
        for code, s in ((2, 3), (3, 4), (5, 5), (4, 7), (6, 8)):   # phase → sid (4=PTFE: sensitivity-
            if code == 5 and _sph_ijk is not None:          #   only; 6=SWCNT sheath A14 → sid 8)
                q = _sph_ijk
                if _yield_vgcf:
                    q = q[sid[q[:, 0], q[:, 1], q[:, 2]] != 3]
                if len(q):
                    sid[q[:, 0], q[:, 1], q[:, 2]] = s      # ★ 제자리 = 같은 우선순위
                #  ★ 브리지도 **SDCP 와 같은 우선순위 자리**에서 찍는다.
                #  ⚠ **빈 셀(sid 0)에만** 채운다 — 브리지의 목적은 *빠진 목을 복원*하는
                #    것이지 이미 배정된 상을 덮는 것이 아니다.  덮게 두면 SDCP–AM 브리지가
                #    SDCP·VGCF 셀을 낮은 σ 의 AM 으로 **강등**해 인위적 손실을 만든다.
                #  ★★ 2026-08-25 실측으로 배운 것 — **판정 반경과 목 반경은 다르다.**
                #    초판은 하나로 썼다가 둘 다 틀렸다: 목이 `0.08 µm` 면 vox 0.15 에서
                #    **0.53 복셀**이라 셀을 못 만들어 참 접촉 복원이 0.717 에 그쳤고,
                #    동시에 판정 tol 0.08 이 **0.03 µm 틈**(10 %)보다 커서 가짜 연결을
                #    0.69~1.00 로 **키웠다**.  ⇒ AM–AM 과 **같은 구조**로 나눈다:
                #      · **판정** = 물리 간극 ≤ tol  (격자 무관 — 이것이 노브다)
                #      · **목 반경** = `1.2·vox`      (AM–AM 기본과 동일)
                #    목 면적이 격자에 양자화되는 것은 이 파일이 이미 적어 둔 v1 한계다
                #    (`a 1-voxel neck's area is quantized to the face area`).
                for _bc, _bs in _brg:
                    _ball_empty(_bc, 1.2 * vox, _bs)
                continue
            m = ph == code
            if m.any():
                q = ijk[m]
                if code == 5 and _yield_vgcf:
                    q = q[sid[q[:, 0], q[:, 1], q[:, 2]] != 3]
                if len(q):
                    sid[q[:, 0], q[:, 1], q[:, 2]] = s
    #  ★ G2 (D13 원장 ②) — 맨 마지막: 차단은 **완성된** PTFE 배치를 봐야 한다 (브리지·상
    #    루프가 끝난 뒤).  기본 0.0 = 바이트 동일 (함수 자체가 no-op 계약을 진다).
    #  ⚠⚠ 2026-08-31 (Codex R17 P2) — `periodic_xy` 를 **안 넘기고 있었다**.  현행 STEP B 는
    #    비주기라 무영향이지만 `periodic=True ∧ ptfe_block_um>0` 생산 팔에서는 x/y 경계
    #    너머의 PTFE 가 차단에서 빠진다 (D13 은 공유 함수를 직접 부르며 True 를 줘서 무사했다).
    apply_ptfe_blocking(sid, vox, ptfe_block_um, periodic_xy=ptfe_block_periodic,
                        targets=ptfe_block_targets)
    return sid, pid


def apply_ptfe_blocking(sid, vox, block_um, periodic_xy=False, targets=(6,)):
    """★ G2 (2026-08-25, D13 원장 ② — `sdcp_ion_calib_prereg_20260825.md`) — PTFE 표면
    피복의 이온 차단을 **스칼라 노브 1개**로 표현한다: PTFE(sid 7) 셀에서 유클리드 거리
    `block_um` 안의 **SE(sid 6) 셀만** sid 9(SE_blk) 로 바꾼다.  σ 표가 sid 9 를 이온·전자
    **양쪽 0** 으로 정의하므로 (`ionic_sigma_table`/`electronic_sigma_table`), 차단 셀은
    두 망 모두에서 죽는다 — Figure 2 의 실측이 그렇다 (PTFE 는 양쪽을 다 깎는다).

    왜 이 모양인가 — 펠릿 산술(D13)이 이미 확정했다: PTFE 9.17 vol% 의 **부피 희석만**으로는
    3.09 mS/cm 가 나와야 하는데 실측이 0.97 = 희석의 **0.31배**다.  부피가 아니라 표면
    피복(피브릴)이 깎는다 ⇒ 참 vol% 로 스탬프(그건 이미 `--ptfe-stamp`)하고, 희석 초과분을
    이 두께 하나로 보정한다.  ⚠ 노브는 **유효 표현**이지 피브릴 물리가 아니다 (prereg §7).

    계약 (돌연변이 배터리가 문다):
      · `block_um ≤ 0` → **셀 하나도 안 바꾼다** (기본 = off = 생산 바이트 동일).
      · **sid 6 만** 바꾼다 — 도체(AM·탄소·SDCP)를 강등하지 않고 pore(0)를 채우지 않는다
        (그쪽은 이온 σ 이미 0 이라 물리 효과가 없고, 부피 원장만 오염한다).
      · PTFE 가 없는 침대에는 **셀 단위 no-op** (음성 대조 규약, 브리지와 동일).
      · 거리 = 셀 중심 간 유클리드 (µm, EDT).  면-이웃이 정확히 `vox` 이므로
        `block_um < vox` 는 0 셀 = **분해능 이하 두께는 표현 불가** — 격자 양자화의 v1
        한계를 목-면적 규약과 같은 방식으로 문서화한다 (보정이 vox 를 알고 이뤄져야 한다).
    `periodic_xy=True` (펠릿 RVE 전용): EDT 를 x/y wrap 패딩 위에서 계산해 경계 너머의
    PTFE 도 차단 반경에 넣는다.  기본 False = 전극 경로 비트 동일.

    ★★★ 2026-08-31 (Codex R16 Q6 반례 2) — `targets` 신설.  **기본은 `(6,)` = 옛 거동과
      비트 동일**이다.  왜 필요한가: 옛 판은 SE 만 죽이고 **SDCP(sid 5)를 면제**했는데,
      SBE 는 PTFE 1.0 / SDCP 0 이고 DBE 는 0.5 / 0.5 라 *"PTFE 가 많은 SBE 가 더 깎인다"* 가
      **연산자에 내장**돼 있었다.  그러면 R↑ 가 나와도 표면 물리인지 연산자 선택인지
      갈리지 않는다.  ⇒ 경쟁 모델 `targets=(5, 6)` 을 **런 전에 함께 등록**해 둘 다 돌린다.
      ⚠⚠ `5` 를 넣으면 **전자 no-op 이 깨진다** — SDCP 는 σ_e = 250 인데 sid 9 는 전자도 0 이다.
        그것이 이 규약의 선언된 내용이다 (*"표면 피복은 양쪽 계면을 다 막는다"*, 위 σ 표 주석).
        숨기지 않는다 — `LAST_PTFE_BLOCK` 이 상별 셀 수를 남기고 매니페스트가 그것을 싣는다.

    반환: 바뀐 셀 **총수** (기존 계약 유지).  상별 내역은 `LAST_PTFE_BLOCK`."""
    global LAST_PTFE_BLOCK
    LAST_PTFE_BLOCK = {}
    tg = tuple(sorted({int(t) for t in targets}))
    if not tg or not set(tg) <= {5, 6}:
        raise ValueError(f'targets 는 {{5,6}} 의 부분집합이어야 한다 (받음 {targets})')
    if float(block_um) <= 0.0:
        return 0
    pt = sid == 7
    if not pt.any():
        return 0
    from scipy.ndimage import distance_transform_edt
    if periodic_xy:
        w = int(np.ceil(float(block_um) / float(vox))) + 1
        ptp = np.pad(pt, ((w, w), (w, w), (0, 0)), mode='wrap')
        d = distance_transform_edt(~ptp, sampling=float(vox))[w:-w, w:-w, :]
    else:
        d = distance_transform_edt(~pt, sampling=float(vox))
    near = d <= float(block_um)
    blk = np.zeros_like(near)
    for t in tg:
        m = near & (sid == t)
        LAST_PTFE_BLOCK[str(t)] = int(m.sum())
        blk |= m
    n = int(blk.sum())
    if n:
        sid[blk] = 9
    return n


#: ★ fid 가 **경로(폴리라인)** 를 뜻하는 상(相)만.  phase 2=VGCF · 4=PTFE · 6=SWCNT sheath.
#
#   ⚠⚠ 나머지(3=SuperP · 5=SDCP)의 fid 는 **경로가 아니다** — `additives.seed_coat` 계열이
#   `return_ids=True` 로 돌려주는 값이 **AM 구 index** 라, 한 구 표면에 흩어진 수십 점이 같은
#   fid 를 공유한다.  그것을 폴리라인으로 이어 구우면 **구 표면을 무작위 순서로 헤집는 선분**이
#   되고, 실측(구 R=3 µm·47점·vox 0.4)에서 셀이 **45 → 582 (×12.9)** 로 터지며 그중 **87 % 가
#   AM 구 내부**를 채운다 = 탄소를 활물질 안에 그리는 것.
#   ⚠ `gap_tol` 가드는 여기서 **구조적으로 발화하지 않는다** — 간격이 전부 R 스케일로 균일해
#   중앙값의 2배를 넘는 점프가 생기지 않는다 (실측 파단 0 건).
#   ★ 같은 판별이 이미 리포에 있었다: `mpm_webapp_payload` 의 뷰어 폴리라인 마스크
#   (`fib_mask = np.isin(phase, POLYLINE_PHASES) & (fid >= 0)`, 주석까지 달려 있었다).
#   두 번째로 구현하면서 그 가드를 잃은 것이 이 결함이다 → **여기가 단일 소스**이고 payload 가
#   이것을 import 한다.
#   ⚠ 보수적 선택: SuperP-ballmill 의 랜덤워크 **체인**은 진짜 경로지만, fid 만으로는
#   thinky(coat) 와 구분되지 않아 **점 스탬프로 남긴다** (틀린 연결을 만드는 것보다 덜 잇는
#   쪽이 안전).  구분하려면 시더가 per-fid 경로 플래그를 남겨야 한다 — 미착수.
POLYLINE_PHASES = (2, 4, 6)


def _fibre_segment_ijk(add_pts, add_phase, add_fid, lo, vox, n, gap_tol=2.0,
                       polyline_phases=POLYLINE_PHASES, add_kind=None):
    """섬유 점열 → **선분이 지나는 셀** (6-face 연결 보장).  → (ijk, phase)

    ★ 같은 fid 의 연속 점을 경로로 보고 Amanatides–Woo 로 굽는다.  ⚠ 시더가 **AM 안 점을
      드랍**하므로 간격이 `gap_tol·(중앙값 간격)` 을 넘으면 **끊는다** — 안 그러면 폴리라인이
      AM 을 관통해 탄소를 AM 내부에 넣는다 (실측: 셀 수 1.7배 팽창).  남는 단절은 물리다.
    ★ `polyline_phases` 밖의 상은 **점 스탬프로 남긴다** — 그 fid 는 경로가 아니다
      (위 POLYLINE_PHASES 주석 참조).
    """
    LAST_SEGSTAMP.clear()          # ★ 팔마다 새로 센다 (누적하면 원장이 거짓말한다)
    from fibre_segment_raster import segment_cells          # 같은 scripts/ 안
    P = np.asarray(add_pts, np.float64)
    F = np.asarray(add_fid)
    PH = np.asarray(add_phase)
    poly = set(int(p) for p in polyline_phases)
    # ★ 시더가 선언한 fid 의미가 있으면 **그것이 이긴다** (additives.ID_PATH/ID_GROUP).
    #   phase 화이트리스트는 옛 산출물용 폴백일 뿐 — SuperP 는 phase 로 못 가른다.
    K = np.asarray(add_kind) if add_kind is not None and len(add_kind) == len(P) else None
    out_ijk, out_ph = [], []
    for f in np.unique(F):
        m = F == f
        Q = P[m]
        if len(Q) == 0:
            continue
        ph_f = PH[m][0]
        _lg = LAST_SEGSTAMP.setdefault(int(ph_f), {'fid_total': 0, 'fid_segment': 0,
                                                   'fid_point_nonpath': 0,
                                                   'fid_point_singleton': 0,
                                                   'split_singleton_pieces': 0})
        _lg['fid_total'] += 1
        is_path = (int(K[m][0]) == 1) if K is not None else (int(ph_f) in poly)
        if not is_path:                                     # ★ 경로가 아닌 fid → 점 스탬프
            _lg['fid_point_nonpath'] += 1
            cc = np.floor((Q - lo) / vox).astype(int)
            out_ijk.append(cc); out_ph.append(np.full(len(cc), ph_f)); continue
        if len(Q) == 1:
            _lg['fid_point_singleton'] += 1                 # ★ R13 C-5: 한 점만 남은 fibril
            out_ijk.append(np.floor((Q - lo) / vox).astype(int)); out_ph.append([ph_f]); continue
        _lg['fid_segment'] += 1
        d = np.linalg.norm(np.diff(Q, axis=0), axis=1)
        med = float(np.median(d)) if len(d) else 0.0
        brk = (np.nonzero(d > gap_tol * med)[0] + 1) if med > 0 else np.array([], int)
        for R in (np.split(Q, brk) if len(brk) else [Q]):
            if len(R) == 1:
                _lg['split_singleton_pieces'] += 1          # ★ gap 분할 뒤 한 점만 남은 조각
                cc = np.floor((R - lo) / vox).astype(int)
            else:
                seg = [segment_cells(R[i] - lo, R[i + 1] - lo, vox) for i in range(len(R) - 1)]
                cc = np.vstack(seg)
            out_ijk.append(cc); out_ph.append(np.full(len(cc), ph_f))
    if not out_ijk:
        return np.zeros((0, 3), int), np.zeros(0, PH.dtype)
    ijk = np.vstack(out_ijk).astype(int)
    ph = np.concatenate(out_ph)
    ok = ((ijk >= 0) & (ijk < n)).all(1)
    return ijk[ok], ph[ok]


# ══ ①′ AM–AM 계면 막 (Rint G2 · 2026-10-07) ══════════════════════════════════════════════════════════════════════
#  정본 = 계약 v2 + v3 + v3.1 (겹치면 뒤가 이긴다): docs/reviews/contact_resistance_pipeline_draft_v2_20261006.md →
#  …_v3_20261006.md → …_v3_1_20261007.md · 판정 docs/reviews/codex_review_rint_g2_v3_20261007.md (계약 정정 둘 뒤 AM–AM ①′
#  구현 GO · 정량 채택 · 생산 HOLD) · 1저자 10-07 "다 권고야".
#  ★ 무엇: AM–AM 접점마다 막 r [Ω·cm²] 을 owner 쌍 면 S_c 에 싣는다 — CNC (contact-normalized coarse closure):
#      r_face(c) = r_type(c) · N_c^ref · h² / A(c)  (h² · A 둘 다 µm² → 비)  을 S_c^surv 에 고르게.
#    ⇒ 접점 막 총 컨덕턴스 ΣG = 1e−8·A·(N_surv/N_ref)/r [S] (RINTG-07).  N_ref = N_c^0 (`remove_area` · 기본 — 탄소가 덮은 몫의
#      막 면적이 사라진다) 또는 N_c^surv (`renormalize` · 민감도).
#  ⛔ 지위 = **기구 (mechanism) 만**: 정량 채택 · 생산 HOLD (D12-V 수치 봉인 · T2/T3 독립 검증 · CNC 적용 범위 · 물성 조건) ·
#    `PROTOCOL_FIELDS` 밖 · payload CLI 미배선 · 기본 끔 (`solve_sigma_z(iface=None)` = 옛 경로 비트 같음).
#  ⚠ 한정어 (v3 §2 · v3.1 §5): CNC 는 참 원판 위 국소 ASR 의 정확한 구현이 **아니다** (고정 support 편향 미인증) · 탄소 가림
#    2 Ω (remove_area) / 1 Ω (renormalize) = **막 소자만**의 차 · 물리적 상 · 하한 아님 · 탄소 접합 (②) · SE 입계 (③) 미표현 ·
#    `unrealized` = AM–AM 막이 남지 않음 (전체 절연 아님 — 탄소 경로가 전도할 수 있다).
#  ★ owner (I8′ · I1‴ · v3.1 §1 · §2): 셀 x 의 청구자 C(x) = 셀 중심을 품는 구 (`_ball_cells` — raster 와 같은 식) ∪ 그 셀을 품는
#    브리지 청구 영역 (= 두 계산 순서 브리지 공의 합집합 · 1저자 10-07 *"권고대로 진행"* · Codex 재확인 대기 → 기록 `iface_bridge_claim`) 의 두 입자.
#    주인 = C(x) **전체**에서 p_min · 띠 T = {p ≤ p_min + ε_p} · T 안 canonical 키 (중심 사전순) 최솟값 — 쌍별 fold 아님.
#    정확한 순열 불변은 **동결 AM 마스크 M + 동결 청구자 기하 G** 에서만 (raw raster 순열 = 진단 `am_iface_raw_perm_diag`).
#  ⚠ ε_p · power 평가 규약은 이 구현 커밋에서 시험과 함께 봉인 (v3.1 §1 "구현 때 봉인") — 바꾸려면 새 봉인.
IFACE_MODEL_VERSION = 'r2-owner-cnc'
IFACE_MODEL_LABEL = ('①′ AM–AM 막 (CNC coarse closure) — 추가 계면막 (r_int 경로 한정) · 탄소 접합 (②) · SE 입계 (③) 미표현 · '
                     '협착 부분 해상 · 상한 아님 · 정량 채택 HOLD')
IFACE_OWNER_RULE = 'claimant_power_partition_v1'
IFACE_TIE_RULE = 'global_pmin_eps_band_center_lex_v1'          # v3.1 I8′ (집합 규칙 · 쌍별 fold 아님)
IFACE_POWER_EVAL = 'cell_centre_ball_formula_grid_units_x_vox2_float64'   # p = Σ(ijk + ½ − (c − lo)/h)² − (r/h)² → × h² [µm²]
IFACE_EPS_P_UM2 = 1.0e-9                                       # ε_p [µm²] — 절대값 하나 · 봉인 (반올림 잡음 ≲ 1e−12 µm² 의 ≥ 1e3 배)
IFACE_BRIDGE_CLAIM = 'union_both_orders_v1'                    # v3.1 §2 권고 = 1저자 10-07 확인 (*"권고대로 진행"*) · 다음 Codex 검토에서 재확인
IFACE_AREA_LAW = 'contact_normalized_coarse_closure'
IFACE_AREA_SOURCE = 'scaffold_lens_geometry'                   # 덤프 (c_cpl[22]) 부류 · 면적 채택 = 미구현 · 조인 관문 (T4-2 · N5′) = 출처 증명만 (10-13)
#: 조인 관문 (T4-2 · N5′ · `rint_iface_join.am_iface_join` · 10-13) 의 계획 기록 문구 — 요청 없음 · 통과 · 실패.
IFACE_JOIN_KIND = 'am_iface_join'
IFACE_JOIN_STATUS_OFF = ('조인 요청 없음 — scaffold 재계산만 (덤프 경로 G-geo · G-frame 조인 관문 = rint_iface_join.am_iface_join · '
                         'T4-2 · N5′ · 기구만)')
IFACE_JOIN_STATUS_PASS = ('G-geo · G-frame 조인 관문 통과 (T4-2 · N5′) — 출처 증명만 · 면적 원천은 scaffold lens 그대로 '
                          '(덤프 c_cpl[22] 부류 · 면적 채택 = 미구현)')
IFACE_JOIN_STATUS_FAIL = 'G-geo · G-frame 조인 관문 실패 — 정량 거부 (join_gate_failed · join_particles_mismatch · join_record_tampered)'
IFACE_CARBON_LAWS = ('remove_area', 'renormalize')
IFACE_EXCEPTION_LAWS = ('cut', 'fused', 'reject')
IFACE_AMBIGUOUS_ARMS = ('cut', 'a_hi')
IFACE_TYPE_KEYS = ('AM_S|AM_S', 'AM_P|AM_P', 'AM_S|AM_P')      # 주인 **종류** 쌍 (면 양쪽 sid 가 아니다 · v2 §3-2)
IFACE_CONTACT_CLASSES = ('contact', 'ambiguous', 'gap_bridged')
#: 소산 분담의 ①′ 부류별 막 몫 키 (상이 아니다 · E4′ · RINT-16 — 부류 = 주인 종류 쌍).
SID_IFACE_AM = {'AM_S|AM_S': -11, 'AM_P|AM_P': -12, 'AM_S|AM_P': -13}
UM2_TO_CM2 = 1.0e-8
IFACE_STATUS = ('mechanism_only — 정량 채택 · 생산 HOLD (D12-V 수치 봉인 · T2/T3 독립 검증 · CNC 적용 범위 · 물성 조건 · '
                'Codex v3 판정 §0) · PROTOCOL_FIELDS 밖 · 검증 PASS 아님')
IFACE_QUALIFIERS = (
    'CNC = 미해상 접점의 coarse closure — 참 원판 위 국소 ASR 의 정확한 구현이 아니다 (고정 support 편향 미인증 · T2-4 · T3-B 전)',
    '탄소 가림 remove_area (2 Ω 판) ↔ renormalize (1 Ω 판) = 막 소자만의 차 — 물리적 불확실성의 상·하한이 아니다 · 탄소 접합 (②) 미식별',
    'unrealized = AM–AM 막이 남지 않음 — 전체 절연이 아니다 (탄소 경로가 전도할 수 있다)',
    'r 재료값 [미확인] — 기구 · 감도 전용 (④ 전 값 인용 금지)',
    'cut = 등록된 비접촉 support 를 제거한 복셀 절단 모델 — DEM 접촉 위상과 같다는 뜻 아님 · 미실현 진짜 접점을 복원하지 않는다 (v3 §6-2)',
    '"전체 계면저항을 보정했다" · "두 판이 상·하한이다" · "탄소 계면까지 식별됐다" 문장 금지 (v3.1 §5)',
)
#: R1 (v3 §6-6) — ①′ 을 안 쓴 해 (iface 기록 없음) 를 소비자가 표지할 때의 문구.  복셀 목의 접근 · 협착이 사라진다는 뜻 아님 ·
#  DEM 망 CONTACT_FREE 가지와 같은 뜻 아님 (CL-81 의 복셀 ↔ 망 서술은 바꾸지 않는다).
IFACE_NONE_LABEL = '추가 계면막 없음 (r_int 경로 한정)'


def _iface_type_name(t):
    """LIGGGHTS type → 이름 (1 = AM_P · 2 = AM_S — `rasterize` 와 같은 규약)."""
    return 'AM_P' if int(t) == 1 else 'AM_S'


def _iface_type_key(ta, tb):
    """주인 종류 쌍 → 표 키 (`AM_S|AM_S` · `AM_P|AM_P` · `AM_S|AM_P`)."""
    na, nb = _iface_type_name(ta), _iface_type_name(tb)
    if na == nb:
        return f'{na}|{nb}'
    return 'AM_S|AM_P'


def parse_iface_r_type(table):
    """①′ 막 표 `{'AM_S|AM_S': r, …}` [Ω·cm²] → 정규화 dict (키 순서 = IFACE_TYPE_KEYS).  `AM_P|AM_S` 는 `AM_S|AM_P` 로.
    거부: dict 아님 · 키가 문자열 아님 · AM 아닌 이름 · bool · 문자열 값 · 음수 · 비유한 · 같은 키에 다른 값."""
    if not isinstance(table, dict):
        raise TypeError('①′ r_type 은 {"AM_S|AM_S": r[Ω·cm²], …} dict 여야 한다')
    out = {}
    for k, v in table.items():
        if not isinstance(k, str):
            raise TypeError(f'①′ r_type 키는 문자열 (`AM_S|AM_P`) 이어야 한다: {k!r}')
        parts = [p.strip() for p in k.split('|')]
        if len(parts) != 2 or not set(parts) <= {'AM_S', 'AM_P'}:
            raise ValueError(f'①′ r_type 키는 AM 종류 쌍 (허용 {IFACE_TYPE_KEYS}) 이어야 한다: {k!r}')
        key = (f'{parts[0]}|{parts[1]}' if parts[0] == parts[1] else 'AM_S|AM_P')
        if isinstance(v, (bool, np.bool_)) or not isinstance(v, (int, float, np.integer, np.floating)):
            raise TypeError(f'①′ r_type 값은 실수여야 한다 (bool · 문자열 금지): {k!r} → {v!r}')
        r = float(v)
        if not (np.isfinite(r) and r >= 0.0):
            raise ValueError(f'①′ r_type 값은 유한한 0 이상 (Ω·cm²): {k!r} → {v!r}')
        if key in out and out[key] != r:
            raise ValueError(f'①′ r_type 같은 종류 쌍에 다른 값: {key}')
        out[key] = r
    return {k: out[k] for k in IFACE_TYPE_KEYS if k in out}


def _iface_input_check(am_c, am_r, am_t):
    """입력 형 (오류) + 정량 거부 (N8 정확 중복 · N8b 동심 비동일 — v3.1 §1) + canonical id.

    canonical id = 중심 (x, y, z) 사전순 **조밀** 순위 — 같은 중심은 같은 순위 (그래서 N8 · N8b 를 **먼저** 거부한다).
    행 번호 · 스탬프 순서는 키가 아니다.  → (c, r, t, rejections, rank)."""
    c = np.asarray(am_c, np.float64); r = np.asarray(am_r, np.float64); t = np.asarray(am_t)
    if c.ndim != 2 or c.shape[1] != 3 or r.shape != (len(c),) or t.shape != (len(c),):
        raise ValueError(f'①′ 입자 배열 모양이 틀렸다: c {c.shape} · r {r.shape} · t {t.shape}')
    if not (np.isfinite(c).all() and np.isfinite(r).all() and (r > 0.0).all()):
        raise ValueError('①′ 입자 중심 · 반경은 유한해야 하고 반경 > 0')
    if len(t) and not np.isin(t, (1, 2)).all():
        raise ValueError('①′ 종류는 1 (AM_P) · 2 (AM_S) 뿐 (LIGGGHTS 규약)')
    n = len(c)
    rej = []
    if n == 0:
        return c, r, t, rej, np.zeros(0, np.int64)
    order = np.lexsort((c[:, 2], c[:, 1], c[:, 0]))       # 첫 열 = x (주 키)
    cs = c[order]
    new = np.ones(n, bool)
    new[1:] = np.any(cs[1:] != cs[:-1], axis=1)           # 값 비교 (−0.0 == 0.0)
    dense = np.cumsum(new) - 1
    rank = np.empty(n, np.int64)
    rank[order] = dense
    dup, conc = [], []
    for g in np.unique(dense[~new]):                       # 둘 이상이 같은 중심인 무리
        mem = order[dense == g]
        ctr = tuple(float(x) for x in c[mem[0]])
        for ia in range(len(mem)):
            for ib in range(ia + 1, len(mem)):
                pa, pb = mem[ia], mem[ib]
                rr_ = tuple(sorted((float(r[pa]), float(r[pb]))))
                tt_ = tuple(sorted((_iface_type_name(t[pa]), _iface_type_name(t[pb]))))
                (dup if r[pa] == r[pb] else conc).append((ctr, rr_, tt_))
    if dup:
        rej.append({'code': 'exact_duplicate', 'test': 'N8', 'n': len(dup), 'detail': sorted(dup)[:8],
                    'why': '같은 중심 · 같은 반경 (종류 같음 · 다름) — canonical 키가 못 가른다 · 병합 규칙 미등록 (D20)'})
    if conc:
        rej.append({'code': 'concentric_nonidentical', 'test': 'N8b', 'n': len(conc), 'detail': sorted(conc)[:8],
                    'why': '동심 비동일 (중심 비트 같음 · 반경 다름) — ε 띠 안이든 밖이든 입력 단계 거부 (1저자 Q1 10-07)'})
    return c, r, t, rej, rank


def _iface_particles_fp(c, r, t):
    """입자 **집합** 지문 (행 순서 무관) — 중심 (x, y, z) · 반경 · 종류 사전순으로 정렬한 float64 · int64 바이트 (E5 와 같은 지문 규약).
    조인 관문 (`rint_iface_join` · T4-2) · 시험 전용 RRM 이 "원장을 만든 입자 = 조인이 인증한 입자" 인지 대조한다 (2026-10-13)."""
    c = np.asarray(c, np.float64).reshape(-1, 3); r = np.asarray(r, np.float64).ravel(); t = np.asarray(t).astype(np.int64).ravel()
    o = np.lexsort((t, r, c[:, 2], c[:, 1], c[:, 0])) if len(c) else np.zeros(0, np.int64)
    h = hashlib.blake2b(digest_size=16)
    for x in (c[o], r[o], t[o]):
        x = np.ascontiguousarray(x)
        h.update(x.dtype.str.encode()); h.update(repr(x.shape).encode()); h.update(x.data)
    return h.hexdigest()


def _cells_power_grid(ijk, cg, rr2):
    """셀 (정수 ijk [M, 3]) 에서 입자 power [격자 단위²] — `_ball_cells` 와 같은 식 · 같은 연산 순서 (원소마다 같은 값).
    cg = (c − lo)/h (항목마다) · rr2 = (r/h)·(r/h).  p ≤ 0 ⇔ 셀 중심이 구 안 (부호는 뺄셈에서 정확)."""
    return ((ijk[:, 0] + 0.5 - cg[:, 0]) ** 2 + (ijk[:, 1] + 0.5 - cg[:, 1]) ** 2
            + (ijk[:, 2] + 0.5 - cg[:, 2]) ** 2) - rr2


def _iface_owner_select(cell, rank, part, p_um2, eps_p_um2):
    """I8′ (v3.1 §1) — 셀마다 청구자 집합 C(x) **전체**에서 ① p_min ② 띠 T = {i : p_i ≤ p_min + ε_p} ③ T 안 canonical 키
    (중심 사전순 rank) 최솟값.  입력 = 청구 항목 (cell 오름차순 · (cell, part) 중복 없음).

    ★ 모든 연산이 집합 함수 (min · 개수) — 항목 순서 · 입력 행 순서와 무관.  승자의 power 를 다음 비교 기준으로 쓰는 쌍별
      fold 가 아니다 (그 fold 는 비추이 반례에서 순서마다 승자가 바뀐다 · RINTV-01).
    ⛔ fail-closed: T 안의 최소 rank 를 서로 다른 입자 둘 이상이 가지면 (같은 중심) 오류 — 반경 · 종류 · 행 번호로 가르지 않는다.
    → (cells, owner_rank, band_size, n_claim) — cells 마다 하나."""
    cell = np.asarray(cell, np.int64); rank = np.asarray(rank, np.int64)
    part = np.asarray(part, np.int64); p = np.asarray(p_um2, np.float64)
    eps = float(eps_p_um2)
    if not (np.isfinite(eps) and eps > 0.0):
        raise ValueError(f'①′ ε_p 는 유한한 양수 (µm²): {eps_p_um2!r}')
    if len(cell) == 0:
        z = np.zeros(0, np.int64)
        return z, z.copy(), z.copy(), z.copy()
    if np.any(cell[1:] < cell[:-1]):
        raise ValueError('①′ 청구 항목이 cell 순으로 정렬돼 있지 않다')
    if not np.isfinite(p).all():
        raise ValueError('①′ power 에 비유한 값')
    starts = np.flatnonzero(np.r_[True, cell[1:] != cell[:-1]])
    sizes = np.diff(np.r_[starts, len(cell)])
    grp = np.repeat(np.arange(len(starts)), sizes)
    pmin = np.minimum.reduceat(p, starts)
    band = p <= pmin[grp] + eps
    big = np.iinfo(np.int64).max
    own = np.minimum.reduceat(np.where(band, rank, big), starts)
    hit = band & (rank == own[grp])
    nhit = np.add.reduceat(hit.astype(np.int64), starts)
    if (nhit > 1).any():
        k = int(np.flatnonzero(nhit > 1)[0])
        raise ValueError(f'①′ 띠 T 안에 같은 canonical 키 (같은 중심) 입자가 둘 이상 — cell {int(cell[starts[k]])} · '
                         f'반경 · 종류 · 행 번호로 가르지 않는다 (fail-closed · N8 · N8b 입력 거부가 먼저여야 한다)')
    band_size = np.add.reduceat(band.astype(np.int64), starts)
    return cell[starts], own, band_size, sizes.astype(np.int64)


def _am_bridge_claim_mids(am_c, am_r, i, j, d):
    """①′ 브리지 청구 영역의 공 중심들 = **두 계산 순서** (i, j) · (j, i) — 그 합집합이 청구 영역 (v3.1 §2 권고 ·
    `IFACE_BRIDGE_CLAIM`).  어느 legacy 행 순서가 찍은 브리지 셀도 청구된다 (RINTV-02: 순서에 따라 공 중심이 끝자리에서
    달라져 격자 경계 셀 하나가 바뀐다).  bulk sid 는 다시 칠하지 않는다 (D21 아님)."""
    return (_am_bridge_mid(am_c, am_r, i, j, d), _am_bridge_mid(am_c, am_r, j, i, d))


def _iface_area_hi(r1, r2, delta, db):
    """모호 접점의 A_hi = δ 포괄 구간 [δ − db, δ + db] 위 교차 원판 면적의 **최대** (v3 §6-2 · Codex Q3).
    A(δ) 는 (0, 포함 경계) 에서 단봉 (극대 δ* : d² = |r1² − r2²| → π·min(r)²) — 구간 최대 = 위 끝값 또는 δ* 가 안이면 극대."""
    import math
    from lens_geometry import intersection_disc_area
    hi = delta + db
    if hi <= 0.0:
        return 0.0
    cand = intersection_disc_area(r1, r2, hi)
    if r1 != r2:
        dstar = r1 + r2 - math.sqrt(abs(r1 * r1 - r2 * r2))
        if delta - db <= dstar <= hi:
            cand = max(cand, math.pi * min(r1, r2) ** 2)
    return float(cand)


def _iface_quant(x):
    """요약 분위 (min · median · max) — 빈 배열 → None."""
    x = np.asarray(x, np.float64)
    if x.size == 0:
        return None
    return {'min': float(x.min()), 'median': float(np.median(x)), 'max': float(x.max())}


def am_iface_ledger(am_c, am_r, am_t, sid, sid_pre, box_lo, vox, *, delta_bound_um, tol_am_um=0.10,
                    bridge_um=None, eps_p_um2=IFACE_EPS_P_UM2, raster_sdcp_bridge_um=0.0):
    """①′ **접촉 원장** (기하만 — r · 법칙 무관 · v2 §3-3 · §3-6 · v3 §2 · v3.1 §1 · §2 · §5).

    sid      최종 raster (첨가제 뒤) — 동결 AM 마스크 M = sid ∈ {1, 2} (1 ↔ 2 라벨은 읽지 않는다 · I1‴)
    sid_pre  같은 입력 · 같은 순서의 **첨가제 전** raster (AM 구 + 브리지) — M0 = sid_pre ∈ {1, 2} → N_c^0 의 기준
    delta_bound_um  scaffold 반올림 폭 — |δ| ≤ 이것 = ambiguous (필수 · 기본값 없음: 조용히 0 으로 두지 않는다)
    tol_am_um · bridge_um  raster 와 **같은 값** (쌍 집합 · 브리지 청구 영역 — 다르면 M ⊄ claimed(G) 로 거부될 수 있다)
    eps_p_um2  I8′ 띠 폭 (기본 = 봉인값 `IFACE_EPS_P_UM2` · 시험 픽스처만 다른 값을 준다)
    raster_sdcp_bridge_um  raster 의 SDCP 접촉 브리지 (`sdcp_bridge_um`) — > 0 이면 정량 거부 (N7: 빈 셀에 AM sid 를 pid ·
               청구자 없이 깐다 · 실제 그런 셀은 M ⊄ claimed(G) 로도 잡힌다)

    → dict (`kind = am_iface_ledger`): owner (int32 격자 · canonical id = 중심 사전순 순위 · −1 = 주인 없음) · contacts
    (canonical 쌍 표 — 부류 contact · ambiguous · gap_bridged · A_true · A_hi · N_c^0 · N_c^surv · 3중 면 · a < h) · faces
    (owner 가 다른 이웃 쌍 면 — 면 키 = (축, 아래쪽 셀 선형 번호) · 접점 id 또는 −1 = 미등록 · surv = 최종 마스크에서도 남음) ·
    rejections (정량 모드 거부 사유 — 원장은 그래도 만든다: census 가 수를 읽는다).
    ⚠ 행렬 · 솔브 없음 (CPU raster 만).  ⚠ 정확한 순열 불변 = 같은 sid · sid_pre (동결 M) 에서만 (I1‴)."""
    from lens_geometry import intersection_disc_area
    c, r, t, rej, rank = _iface_input_check(am_c, am_r, am_t)
    sid = np.asarray(sid); sid_pre = np.asarray(sid_pre)
    if sid.ndim != 3 or sid.shape != sid_pre.shape:
        raise ValueError(f'①′ sid {sid.shape} · sid_pre {sid_pre.shape} — 같은 3-D 격자여야 한다')
    vox = float(vox)
    db = float(delta_bound_um); tol = float(tol_am_um); eps = float(eps_p_um2)
    if not (np.isfinite(vox) and vox > 0.0):
        raise ValueError(f'①′ vox 는 유한한 양수: {vox!r}')
    if not (np.isfinite(db) and db >= 0.0):
        raise ValueError(f'①′ delta_bound_um 은 유한한 0 이상: {delta_bound_um!r}')
    if not (np.isfinite(tol) and tol >= 0.0):
        raise ValueError(f'①′ tol_am_um 은 유한한 0 이상: {tol_am_um!r}')
    if not (np.isfinite(eps) and eps > 0.0):
        raise ValueError(f'①′ ε_p 는 유한한 양수 (µm²): {eps_p_um2!r}')
    rb = _am_bridge_radius(vox, bridge_um)
    shape = tuple(int(x) for x in sid.shape)
    n = np.array(shape, dtype=int)
    lo = np.asarray(box_lo, np.float64)
    M = np.isin(sid, (1, 2)); M0 = np.isin(sid_pre, (1, 2)); Mx = M | M0
    N = len(c)
    _sb = float(raster_sdcp_bridge_um)
    if not (np.isfinite(_sb) and _sb >= 0.0):
        raise ValueError(f'①′ raster_sdcp_bridge_um 은 유한한 0 이상: {raster_sdcp_bridge_um!r}')
    if _sb > 0.0:
        rej.append({'code': 'sdcp_bridge_raster', 'test': 'N7', 'n': 1,
                    'why': 'SDCP–AM 브리지 진단 팔 (sdcp_bridge_um > 0) 은 빈 셀에 AM sid 를 주인 없이 깐다 — 정량 모드와 함께 쓰지 않는다'})
    led = {'kind': 'am_iface_ledger', 'version': IFACE_MODEL_VERSION,
           'iface_owner_rule': IFACE_OWNER_RULE, 'iface_tie_rule': IFACE_TIE_RULE, 'iface_eps_p_um2': eps,
           'iface_power_eval': IFACE_POWER_EVAL, 'iface_bridge_claim': IFACE_BRIDGE_CLAIM,
           'iface_area_source': IFACE_AREA_SOURCE,
           'shape': shape, 'vox': vox, 'box_lo': tuple(float(x) for x in lo), 'bridge_um': float(rb),
           'bridge_um_requested': None if bridge_um is None else float(bridge_um), 'tol_am_um': tol,
           'delta_bound_um': db, 'n_particles': int(N), 'raster_sdcp_bridge_um': _sb,
           'fp_sid': _grid_fp(sid), 'fp_sid_pre': _grid_fp(sid_pre),
           'fp_particles': _iface_particles_fp(c, r, t),
           'n_M': int(M.sum()), 'n_M0': int(M0.sum()), 'rejections': rej}
    if any(x['code'] in ('exact_duplicate', 'concentric_nonidentical') for x in rej):
        led.update(owner=None, contacts=None, faces=None, claims=None)   # canonical 키가 없다 → owner 를 정하지 않는다
        return led
    #  ── 청구 항목 (cell, 입자) — 구 (raster 와 같은 식) ∪ 브리지 청구 영역 (두 순서 합집합) · M ∪ M0 의 셀만 ──
    Mflat = Mx.reshape(-1)
    cells_l, parts_l = [], []

    def _claim(centre, rad, parts):
        hit = _ball_cells(centre, rad, lo, vox, n)
        if hit is None:
            return
        i0, i1, m = hit
        ii, jj, kk = np.nonzero(m)
        lin = np.ravel_multi_index((ii + i0[0], jj + i0[1], kk + i0[2]), shape)
        lin = lin[Mflat[lin]]
        if len(lin):
            for p_ in parts:
                cells_l.append(lin); parts_l.append(np.full(len(lin), p_, np.int64))
    for k in range(N):
        _claim(c[k], r[k], (k,))
    pairs = am_bridge_pairs(c, r, tol) if N >= 2 else []
    for i, j, d in pairs:
        for mid in _am_bridge_claim_mids(c, r, i, j, d):
            _claim(mid, rb, (i, j))
    if cells_l:
        key = np.unique(np.concatenate(cells_l) * max(N, 1) + np.concatenate(parts_l))
        cell, part = key // max(N, 1), key % max(N, 1)
    else:
        cell = part = np.zeros(0, np.int64)
    ijk = np.stack(np.unravel_index(cell, shape), axis=1) if len(cell) else np.zeros((0, 3), np.int64)
    cg = (c - lo) / vox
    rrv = r / vox
    rr2 = rrv * rrv
    p_um2 = _cells_power_grid(ijk, cg[part], rr2[part]) * (vox * vox) if len(cell) else np.zeros(0)
    cells_u, own_rank, band_size, n_claim = _iface_owner_select(cell, rank[part] if len(part) else part, part,
                                                                 p_um2, eps)
    owner = np.full(shape, -1, np.int32)
    owner.reshape(-1)[cells_u] = own_rank.astype(np.int32)
    #  ── 불변식 M ⊆ claimed(G) (v3.1 §2) · M ⊆ M0 (S_surv ⊆ S_0 의 전제 · v3.1 §5) ──
    for code_, mask_, why_ in (
            ('mask_unclaimed', M & (owner < 0),
             'M ⊄ claimed(G) — 청구자 없는 AM 셀을 조용한 bulk 면으로 두지 않는다 (T0-1g · SDCP–AM 브리지 N7 · 다른 bridge/tol)'),
            ('mask_pre_unclaimed', M0 & (owner < 0), 'M0 ⊄ claimed(G) — N_c^0 를 셀 수 없다 (raster 와 다른 bridge/tol?)'),
            ('mask_not_subset_pre', M & ~M0, 'M ⊄ M0 — 첨가제 뒤에 AM 셀이 생겼다 (S_surv ⊆ S_0 전제 깨짐 · N7)')):
        if mask_.any():
            w = np.argwhere(mask_)
            rej.append({'code': code_, 'n': int(len(w)), 'detail': [tuple(int(v) for v in x) for x in w[:8]],
                        'why': why_})
    #  ── 면 — owner 가 다른 이웃 쌍 (면 키 = (축, 아래쪽 셀 선형 번호)) · M0 위 (S^0) · M 에서도 남음 (surv) ──
    Nr = int(rank.max()) + 1 if N else 1
    f_ax, f_lin, f_lo, f_hi, f_sv = [], [], [], [], []
    extra = 0
    for ax in range(3):
        sa = [slice(None)] * 3; sb = [slice(None)] * 3
        sa[ax] = slice(0, -1); sb[ax] = slice(1, None)
        sa, sb = tuple(sa), tuple(sb)
        oa, ob = owner[sa], owner[sb]
        diff = (oa >= 0) & (ob >= 0) & (oa != ob)
        m0 = diff & M0[sa] & M0[sb]
        ms = diff & M[sa] & M[sb]
        extra += int((ms & ~m0).sum())
        ii, jj, kk = np.nonzero(m0)
        f_lin.append(np.ravel_multi_index((ii, jj, kk), shape).astype(np.int64))
        f_ax.append(np.full(len(ii), ax, np.int8))
        f_lo.append(oa[ii, jj, kk].astype(np.int64)); f_hi.append(ob[ii, jj, kk].astype(np.int64))
        f_sv.append(ms[ii, jj, kk])
    if extra:
        rej.append({'code': 'surv_not_subset', 'n': extra,
                    'why': 'S_surv ⊄ S_0 — 같은 면 키에서 최종 마스크에만 있는 owner 쌍 면 (v3.1 §5 구현 검사)'})
    f_ax = np.concatenate(f_ax); f_lin = np.concatenate(f_lin)
    f_lo = np.concatenate(f_lo); f_hi = np.concatenate(f_hi); f_sv = np.concatenate(f_sv)
    pa_, pb_ = np.minimum(f_lo, f_hi), np.maximum(f_lo, f_hi)
    f_code = pa_ * Nr + pb_
    reg = sorted({(int(min(rank[i], rank[j])), int(max(rank[i], rank[j]))) for i, j, _d in pairs})
    reg_code = np.array([a_ * Nr + b_ for a_, b_ in reg], np.int64)
    pos = np.searchsorted(reg_code, f_code)
    okc = pos < len(reg_code)
    okc[okc] = reg_code[pos[okc]] == f_code[okc]
    f_cid = np.where(okc, pos, -1).astype(np.int64)
    #  ── 3중: 면 양쪽 셀 중 하나라도 **둘 이상의 다른 주인**과 닿으면 (짝 + 셋째) ──
    stride = np.array([shape[1] * shape[2], shape[2], 1], np.int64)
    lin_hi = f_lin + stride[f_ax.astype(np.int64)]
    if len(f_lin):
        kk_ = np.unique(np.concatenate([f_lin, lin_hi]) * Nr + np.concatenate([f_hi, f_lo]))
        ucell, ucnt = np.unique(kk_ // Nr, return_counts=True)
        f_tri = (ucnt[np.searchsorted(ucell, f_lin)] >= 2) | (ucnt[np.searchsorted(ucell, lin_hi)] >= 2)
    else:
        f_tri = np.zeros(0, bool)
    faces = {'axis': f_ax, 'lin': f_lin, 'cid': f_cid, 'o_lo': f_lo, 'o_hi': f_hi, 'surv': f_sv,
             'pair': f_code, 'triple': f_tri}
    #  ── 접점 표 (canonical 쌍 순) ──
    nC = len(reg)
    rep = np.zeros(Nr, np.int64)
    rep[rank] = np.arange(N)                                   # canonical id → 입력 행 (중복 없음이 위에서 보장)
    C = {k_: np.zeros(nC, np.float64) for k_ in ('r_a', 'r_b', 'd', 'delta', 'A_true', 'A_hi', 'a_um')}
    C['a'] = np.array([a_ for a_, _ in reg], np.int64); C['b'] = np.array([b_ for _, b_ in reg], np.int64)
    C['cls'] = np.zeros(nC, np.int8)
    tkeys = []
    for q, (ka, kb) in enumerate(reg):
        A_, B_ = int(rep[ka]), int(rep[kb])
        ra_, rb_ = float(r[A_]), float(r[B_])
        dd = float(np.linalg.norm(c[A_] - c[B_]))
        dl = (ra_ + rb_) - dd
        cl = 0 if dl > db else (2 if dl < -db else 1)
        at = intersection_disc_area(ra_, rb_, dl) if dl > 0.0 else 0.0
        ah = _iface_area_hi(ra_, rb_, dl, db) if cl == 1 else 0.0
        af = at if cl == 0 else (ah if cl == 1 else 0.0)
        C['r_a'][q], C['r_b'][q], C['d'][q], C['delta'][q] = ra_, rb_, dd, dl
        C['A_true'][q], C['A_hi'][q], C['a_um'][q] = at, ah, float(np.sqrt(af / np.pi))
        C['cls'][q] = cl
        tkeys.append(_iface_type_key(t[A_], t[B_]))
    C['type_key'] = np.array(tkeys, dtype='<U9') if nC else np.zeros(0, dtype='<U9')
    reg_face = f_cid >= 0
    C['n0'] = np.bincount(f_cid[reg_face], minlength=nC).astype(np.int64)
    C['nsurv'] = np.bincount(f_cid[reg_face & f_sv], minlength=nC).astype(np.int64)
    C['n_triple'] = np.bincount(f_cid[reg_face & f_tri], minlength=nC).astype(np.int64)
    C['a_lt_h'] = C['a_um'] < vox
    #  canonical 입자 (canonical id 순 — 접점 a · b 가 가리키는 행) — 시험 전용 RRM (근축면 원판) · 조인 대조가 읽는다 (2026-10-13)
    _rp = rep[:N]                                              # N 0 이면 빈 배열 (rep 는 길이 Nr ≥ 1)
    led['particles'] = {'c': c[_rp].copy(), 'r': r[_rp].copy(), 't': np.asarray(t)[_rp].astype(np.int64)}
    led.update(owner=owner, contacts=C, faces=faces,
               claims={'cell': cell, 'rank': rank[part] if len(part) else part.copy()},
               fp_owner=_grid_fp(owner), n_cells_claimed=int(len(cells_u)),
               n_cells_multi_claim=int((n_claim >= 3).sum()), n_cells_band_gt1=int((band_size > 1).sum()),
               n_reg_pairs=int(nC))
    return led


def _iface_empty_rows():
    z = np.zeros(0, np.int64)
    return {'lin': z, 'rface': np.zeros(0, np.float64), 'cut': np.zeros(0, bool), 'ck': z.copy(),
            'cid': z.copy(), 'olo': z.copy()}


def _iface_rows_fp(axes):
    """간선 행 지문 (E5) — 축마다 키 이름 · dtype · 모양 · 바이트."""
    h = hashlib.blake2b(digest_size=16)
    for ax in axes:
        for k in sorted(ax):
            x = np.ascontiguousarray(np.asarray(ax[k]))
            h.update(k.encode()); h.update(x.dtype.str.encode()); h.update(repr(x.shape).encode()); h.update(x.data)
    return h.hexdigest()


def iface_join_fp(join):
    """조인 기록 지문 (`fp_join` 을 뺀 전체 — dict 는 키 정렬 · 배열은 dtype · 모양 · 바이트 · 그 밖은 repr).  조인 (`rint_iface_join`) 이
    찍고 계획 (`am_iface_plan(join=…)`) 이 다시 계산해 대조한다 (만든 뒤 바뀐 조인 = 정량 거부 · E5 와 같은 부류)."""
    h = hashlib.blake2b(digest_size=16)

    def upd(x):
        if isinstance(x, dict):
            h.update(b'{')
            for k in sorted(x, key=str):
                h.update(repr(k).encode()); upd(x[k])
            h.update(b'}')
        elif isinstance(x, (list, tuple)):
            h.update(b'(' if isinstance(x, tuple) else b'[')
            for v in x:
                upd(v)
            h.update(b')')
        elif isinstance(x, np.ndarray):
            if x.dtype == object:
                raise TypeError('조인 지문: object 배열은 지문을 정할 수 없다')
            a = np.ascontiguousarray(x)
            h.update(a.dtype.str.encode()); h.update(repr(a.shape).encode()); h.update(a.data)
        else:
            h.update(repr(x).encode())
    upd({k: v for k, v in join.items() if k != 'fp_join'})
    return h.hexdigest()


def _iface_join_crosscheck(ledger, join):
    """원장 접점 부류 ↔ DEM AM–AM 접촉 (조인의 비주기 행) 대조 — **보고만** (원장 부류는 scaffold δ · δ_bound 로 정한다 · 덤프 경로 부류 채택 =
    미구현).  canonical id = 조인 입자의 중심 사전순 순위 (원장과 같은 규칙 · 입자 지문이 같을 때만 부른다)."""
    C = ledger['contacts']; D = join['dem_am_am']; c = np.asarray(join['particles']['c_um'], np.float64)
    order = np.lexsort((c[:, 2], c[:, 1], c[:, 0])) if len(c) else np.zeros(0, np.int64)
    rank = np.empty(len(c), np.int64); rank[order] = np.arange(len(c))
    ns = ~np.asarray(D['seam'], bool)
    ra, rb = rank[np.asarray(D['row_a'])[ns]], rank[np.asarray(D['row_b'])[ns]]
    dem = set(zip(np.minimum(ra, rb).tolist(), np.maximum(ra, rb).tolist()))
    reg = list(zip(C['a'].tolist(), C['b'].tolist()))
    by = {}
    for k_, nm in enumerate(IFACE_CONTACT_CLASSES):
        sel = [p for p, cl in zip(reg, C['cls'].tolist()) if cl == k_]
        by[nm] = {'n': len(sel), 'in_dem': int(sum(1 for p in sel if p in dem)), 'not_in_dem': int(sum(1 for p in sel if p not in dem))}
    return {'n_dem_am_am': int(len(D['row_a'])), 'n_dem_seam': int((~ns).sum()), 'n_dem_non_seam': len(dem),
            'n_dem_not_registered': len(dem - set(reg)), 'by_class': by,
            'meaning': ('보고만 — 원장 부류는 scaffold δ (δ_bound) 로 정한다 · 덤프 경로 부류 채택 = 미구현 · 이음매 (seam) = 비주기 raster 가 '
                        '표현 못 하는 DEM 접점 (seam_unrepresented)')}


def _iface_join_record(ledger, join, rej):
    """`am_iface_plan(join=…)` — 조인 기록 → (iface_join 요약, iface_join_status, iface_geom_reuse) · 실패 · 다른 입자 · 변조 = 거부 사유 추가.
    join None → (None, IFACE_JOIN_STATUS_OFF, None)."""
    if join is None:
        return None, IFACE_JOIN_STATUS_OFF, None
    if not isinstance(join, dict) or join.get('kind') != IFACE_JOIN_KIND:
        raise TypeError('join 은 rint_iface_join.am_iface_join 의 결과여야 한다')
    _miss = [k for k in ('version', 'status', 'rejections', 'g_geo', 'g_frame', 'geom_reuse', 'files', 'steps', 'particles',
                         'dem_am_am', 'fp_particles', 'fp_join', 'scaffold_frame_claim') if k not in join]
    if _miss:
        raise TypeError(f'join 모양이 틀렸다 (빠진 키 {_miss}) — am_iface_join 의 결과를 그대로 줄 것')
    ok = True
    if iface_join_fp(join) != join['fp_join']:
        rej.append({'code': 'join_record_tampered', 'test': 'T4-2', 'n': 1,
                    'why': '조인 기록이 만든 뒤 바뀌었다 (fp_join 불일치) — 출처 증명으로 쓸 수 없다'})
        ok = False
    if join['status'] != 'PASS' or join['rejections']:
        rej.append({'code': 'join_gate_failed', 'test': 'T4-2', 'n': max(1, len(join['rejections'])),
                    'detail': [x.get('code') for x in join['rejections']],
                    'why': 'G-geo · G-frame 조인 관문 실패 — 덤프 경로 출처를 주장할 수 없다 (N5′ · N1 포함)'})
        ok = False
    if join['fp_particles'] != ledger.get('fp_particles'):
        rej.append({'code': 'join_particles_mismatch', 'test': 'T4-2', 'n': 1,
                    'why': '원장을 만든 입자 ≠ 조인이 인증한 입자 (입자 집합 지문) — 다른 침대 · 다른 좌표 변환'})
        ok = False
    xc = _iface_join_crosscheck(ledger, join) if (ok and ledger.get('owner') is not None) else None
    rec = {'kind': join['kind'], 'version': join['version'], 'status': ('PASS' if ok else 'REJECT'),
           'gate_rejections': [x.get('code') for x in join['rejections']],
           'gates': {'g_geo': join['g_geo'], 'g_frame': join['g_frame']}, 'files': join['files'], 'steps': join['steps'],
           'scaffold_frame_claim': join['scaffold_frame_claim'], 'fp_join': join['fp_join'], 'fp_particles': join['fp_particles'],
           'ledger_crosscheck': xc}
    return rec, (IFACE_JOIN_STATUS_PASS if ok else IFACE_JOIN_STATUS_FAIL), (join['geom_reuse'] if ok else None)


def am_iface_plan(ledger, r_type, *, carbon_cover='remove_area', gap_law=None, unreg_law=None, ambiguous_arm=None, join=None):
    """①′ **막 · 절단 간선 계획** = 원장 + 막 표 + 법칙 → `solve_sigma_z(..., iface=plan)` 이 받는 것.

    r_type         {'AM_S|AM_S': r, 'AM_P|AM_P': r, 'AM_S|AM_P': r} [Ω·cm²] — 막을 진 접점의 종류 쌍이 표에 없으면 거부
    carbon_cover   'remove_area' (기본 · N_ref = N_c^0) | 'renormalize' (민감도 · N_ref = N_c^surv) — 두 법칙의 r_face 를
                   **둘 다** 계산해 기록한다 (값 보고는 두 판을 늘 함께 · 막 소자만의 차)
    gap_law        gap_bridged (−tol ≤ δ < −δ_bound) 법칙 'cut' | 'fused' | 'reject' — 그 부류가 있으면 선언 필수 (N6)
    unreg_law      미등록 owner 쌍 면 (등록 쌍이 아닌데 두 주인이 면을 공유) 법칙 — 최종 마스크에 있으면 선언 필수 (N6)
    ambiguous_arm  모호 (|δ| ≤ δ_bound) 팔 'cut' | 'a_hi' — 있으면 선언 필수 (N4) · 두 팔을 모두 보고하는 것은 소비자 몫
    join           덤프 경로 조인 관문 결과 (`rint_iface_join.am_iface_join` · T4-2 · N5′ · 10-13) — 주면 기록 `iface_join` ·
                   `iface_geom_reuse` 를 채우고, 실패 · 다른 입자 · 변조 = 정량 거부.  출처 증명만 (행 · σ 무변경 · 면적 원천 그대로).
                   None (기본) = 조인 요청 없음 (행 · σ · 다른 기록 키 그대로 — 조인 상태 문구만 "요청 없음")
    ⚠ 자동 fallback 없음 (L1 · 막 생략 = fused 로 조용히 돌아가지 않는다 · RINT-08).  cut = g 0 · 원장에 tombstone 행 (E6).
    → dict (`kind = am_iface_plan`): axes (축마다 활성 행: lin · rface · cut · ck · cid · olo) · record (v3 §6-6 이름) ·
      rejections (정량 모드 거부 사유 — 하나라도 있으면 솔브가 거부한다)."""
    if not isinstance(ledger, dict) or ledger.get('kind') != 'am_iface_ledger':
        raise TypeError('am_iface_plan: am_iface_ledger 의 결과를 줄 것')
    if carbon_cover not in IFACE_CARBON_LAWS:
        raise ValueError(f'carbon_cover 는 {IFACE_CARBON_LAWS} 중 하나: {carbon_cover!r}')
    for nm_, v_, al_ in (('gap_law', gap_law, IFACE_EXCEPTION_LAWS), ('unreg_law', unreg_law, IFACE_EXCEPTION_LAWS),
                         ('ambiguous_arm', ambiguous_arm, IFACE_AMBIGUOUS_ARMS)):
        if v_ is not None and v_ not in al_:
            raise ValueError(f'{nm_} 는 None 또는 {al_} 중 하나: {v_!r}')
    rt = parse_iface_r_type(r_type)
    rej = [dict(x) for x in ledger['rejections']]
    vox = float(ledger['vox']); h2 = vox * vox
    axes = tuple(_iface_empty_rows() for _ in range(3))
    summary = {'vox_um': vox, 'bridge_um': ledger['bridge_um'], 'tol_am_um': ledger['tol_am_um'],
               'delta_bound_um': ledger['delta_bound_um'], 'n_particles': ledger['n_particles'],
               'carbon_path_current_share': None,
               'carbon_path_current_share_status': 'not_computed — 탄소 경유 경로의 정의 미등록 (② 접합 전 · v3 R4)'}
    plan = {'kind': 'am_iface_plan', 'version': IFACE_MODEL_VERSION, 'ledger': ledger, 'fp_sid': ledger['fp_sid'],
            'vox': vox, 'shape': ledger['shape'], 'axes': axes, 'n_film_rows': 0, 'n_cut_rows': 0,
            'realized': np.zeros(0, bool), 'rface_c': np.zeros(0), 'carbon_cover': carbon_cover}
    if ledger['owner'] is not None:
        C, F = ledger['contacts'], ledger['faces']
        cls = C['cls']; nC = len(cls)
        if (cls == 1).any() and ambiguous_arm is None:
            rej.append({'code': 'ambiguous_without_arms', 'test': 'N4', 'n': int((cls == 1).sum()),
                        'why': '|δ| ≤ δ_bound 접점이 있는데 팔 (cut · a_hi) 선언이 없다 — 두 팔을 따로 풀어 구간으로 보고'})
        if (cls == 2).any():
            if gap_law is None:
                rej.append({'code': 'gap_law_undeclared', 'test': 'N6', 'n': int((cls == 2).sum()),
                            'why': 'gap_bridged 접점에 법칙 선언 없음 — 자동 fallback (L1 · fused) 없음 (RINT-08)'})
            elif gap_law == 'reject':
                rej.append({'code': 'gap_law_reject', 'n': int((cls == 2).sum()), 'why': 'gap_law = reject'})
        unreg_sv = (F['cid'] < 0) & F['surv']
        if unreg_sv.any():
            if unreg_law is None:
                rej.append({'code': 'unreg_law_undeclared', 'test': 'N6', 'n': int(unreg_sv.sum()),
                            'why': '미등록 owner 쌍 면에 법칙 선언 없음 — 자동 fallback 없음 (RINT-08)'})
            elif unreg_law == 'reject':
                rej.append({'code': 'unreg_law_reject', 'n': int(unreg_sv.sum()), 'why': 'unreg_law = reject'})
        film = (cls == 0) | ((cls == 1) & (ambiguous_arm == 'a_hi'))
        cutc = ((cls == 1) & (ambiguous_arm == 'cut')) | ((cls == 2) & (gap_law == 'cut'))
        A_f = np.where(cls == 0, C['A_true'], np.where(cls == 1, C['A_hi'], 0.0))
        zero_a = film & ~(A_f > 0.0)
        if zero_a.any():
            rej.append({'code': 'zero_true_area', 'n': int(zero_a.sum()),
                        'why': '막을 질 접점의 원판 면적 0 (포함된 구 · 퇴화) — 막 법칙이 정의되지 않는다'})
        rvec = np.array([rt.get(str(k_), np.nan) for k_ in C['type_key']], np.float64) if nC else np.zeros(0)
        miss = film & np.isnan(rvec)
        if miss.any():
            rej.append({'code': 'r_type_missing', 'n': int(miss.sum()),
                        'detail': sorted({str(k_) for k_ in C['type_key'][miss]}),
                        'why': '막을 질 접점의 종류 쌍이 r 표에 없다 (v2 §3-4 "표에 없는 종류 쌍 = 거부")'})
        n0, ns = C['n0'], C['nsurv']
        realized = film & (ns > 0) & (A_f > 0.0) & ~np.isnan(rvec)
        unreal = film & (ns == 0)
        rf_rm = np.zeros(nC); rf_rn = np.zeros(nC)
        q_ = np.flatnonzero(realized)
        rf_rm[q_] = iface_rface_ohm_cm2(rvec[q_], n0[q_], vox, A_f[q_])    # r·N_c^0·h²/A   (remove_area)
        rf_rn[q_] = iface_rface_ohm_cm2(rvec[q_], ns[q_], vox, A_f[q_])    # r·N_c^surv·h²/A (renormalize)
        rface_c = rf_rm if carbon_cover == 'remove_area' else rf_rn
        cid = F['cid']; cidc = np.maximum(cid, 0); sv = F['surv']
        reg_ = cid >= 0
        film_face = sv & reg_ & realized[cidc] if nC else np.zeros(len(cid), bool)
        act = film_face & (rface_c[cidc] > 0.0) if nC else film_face
        zero_r = film_face & ~act
        cut_face = sv & ((reg_ & (cutc[cidc] if nC else False)) | (~reg_ & (unreg_law == 'cut')))
        rows = act | cut_face
        ck_c = np.array([SID_IFACE_AM[str(k_)] for k_ in C['type_key']], np.int64) if nC else np.zeros(1, np.int64)
        out_axes = []
        for ax in range(3):
            s_ = rows & (F['axis'] == ax)
            o_ = np.argsort(F['lin'][s_], kind='stable')
            lin_ = F['lin'][s_][o_]
            cut_ = cut_face[s_][o_]
            cid_ = cid[s_][o_]
            rf_ = np.where(cut_, 0.0, rface_c[np.maximum(cid_, 0)] if nC else 0.0)
            ck_ = np.where(cut_, 0, ck_c[np.maximum(cid_, 0)] if nC else 0).astype(np.int64)
            out_axes.append({'lin': lin_.astype(np.int64), 'rface': rf_.astype(np.float64), 'cut': cut_.astype(bool),
                             'ck': ck_, 'cid': cid_.astype(np.int64), 'olo': F['o_lo'][s_][o_].astype(np.int64)})
        axes = tuple(out_axes)
        Gs = np.zeros(nC)
        Gs[q_] = UM2_TO_CM2 * A_f[q_] / np.where(rvec[q_] > 0, rvec[q_], np.inf)
        summary.update({
            'n_contacts': {nm: int((cls == k_).sum()) for k_, nm in enumerate(IFACE_CONTACT_CLASSES)},
            'n_film_contacts': int(film.sum()), 'n_realized': int(realized.sum()),
            'unrealized': {'n': int(unreal.sum()), 'carbon': int((unreal & (n0 > 0)).sum()),
                           'no_support': int((unreal & (n0 == 0)).sum()),
                           'meaning': 'AM–AM 막이 남지 않음 — 전체 절연이 아니다 (탄소 경로가 전도할 수 있다 · v3.1 §5)'},
            'unregistered': {'n_faces_pre': int((~reg_).sum()), 'n_faces_surv': int(unreg_sv.sum()),
                             'n_pairs': int(len(np.unique(F['pair'][~reg_])))},
            'n_cells_multi_claim': ledger['n_cells_multi_claim'],
            'n_faces_triple': int((F['triple'] & reg_).sum()),
            'a_lt_h': {'n': int((realized & C['a_lt_h']).sum()), 'film_current_share': None,
                       'meaning': 'a < h — CNC 편향 미인증 범위 (RRM 없음 · v3 §2-1)'},
            'A_film_sum_um2': float(A_f[realized].sum()),
            'support_over_true': {'pre': _iface_quant((n0 * h2 / np.where(A_f > 0, A_f, 1.0))[realized]),
                                  'surv': _iface_quant((ns * h2 / np.where(A_f > 0, A_f, 1.0))[realized])},
            'Nsurv_over_N0': _iface_quant((ns / np.maximum(n0, 1))[realized]),
            'Nsurv_over_N0_meaning': '격자 support 면 비율 — 실측 원판의 노출 면적 비율 아님 (v3.1 §5)',
            'carbon_cover_frac': _iface_quant((1.0 - ns / np.maximum(n0, 1))[film & (n0 > 0)]),
            'film_faces': {'pre': int(n0[film].sum()), 'surv': int(ns[film].sum()), 'active': int(act.sum()),
                           'zero_r': int(zero_r.sum())},
            'cut_faces': int(cut_face.sum()),
            'rface_ohm_cm2': {'remove_area': _iface_quant(rf_rm[realized]), 'renormalize': _iface_quant(rf_rn[realized])},
            'film_G_S_total': {'remove_area': float((Gs * ns / np.maximum(n0, 1)).sum()), 'renormalize': float(Gs.sum())},
        })
        plan.update(realized=realized, rface_c=rface_c, rface_remove=rf_rm, rface_renorm=rf_rn,
                    n_film_rows=int(act.sum()), n_cut_rows=int(cut_face.sum()))
    plan['axes'] = axes
    plan['fp_rows'] = _iface_rows_fp(axes)
    _jrec, _jstat, _jreuse = _iface_join_record(ledger, join, rej)      # 조인 (T4-2 · N5′) — 출처 증명만 · 거부 사유를 rej 에 더한다
    plan['rejections'] = rej
    plan['record'] = {
        'iface_model': IFACE_MODEL_VERSION, 'iface_model_label': IFACE_MODEL_LABEL,
        'iface_owner_rule': IFACE_OWNER_RULE, 'iface_tie_rule': IFACE_TIE_RULE,
        'iface_eps_p_um2': ledger['iface_eps_p_um2'], 'iface_power_eval': IFACE_POWER_EVAL,
        'iface_bridge_claim': IFACE_BRIDGE_CLAIM, 'iface_bridge_claim_status': '1저자 10-07 확인 (권고대로) · Codex 재확인 대기 (v3.1 §2)',
        'iface_area_law': IFACE_AREA_LAW, 'iface_carbon_cover': carbon_cover,
        'iface_area_source': IFACE_AREA_SOURCE, 'iface_join': _jrec,
        'iface_join_status': _jstat,
        'iface_geom_reuse': _jreuse,
        'iface_exception_law': {'gap': gap_law, 'unregistered': unreg_law, 'ambiguous_arm': ambiguous_arm},
        'iface_r_type_ohm_cm2': rt, 'unit': 'ohm_cm2',
        'iface_contact_ledger': summary,
        'iface_rejections': [{k_: v_ for k_, v_ in x.items() if k_ != 'detail'} for x in rej],
        'iface_status': IFACE_STATUS, 'iface_qualifiers': list(IFACE_QUALIFIERS)}
    return plan


def iface_require_quantitative(plan, sid=None, sigma_of_sid=None, rint=None, periodic_xy=False, vox=None):
    """①′ 정량 모드 관문 — 거부 입력이면 ValueError (계획 행 변조 · 막 값 r_face 비유한 · 음수 (Q7) · 원장/계획 거부 사유 ·
    r1 탐침 동시 사용 (N3) · 주기 (N2) · 다른 격자 (E5) · 다른 물리 격자 간격 (vox · RIMP-05) · 이 채널에서 AM 이 절연
    (막이 조용히 무효 — RINT-14 와 같은 부류)).
    vox  솔버의 격자 간격 [µm] (`solve_sigma_z` 가 늘 넘긴다) — 유한 양수 · 계획 vox (= 계획 원장 vox) 와 **같은 float64** 여야 한다
         (sid 바이트 지문은 물리 격자 간격을 담지 않는다: 같은 sid · 같은 계획을 h 0.4 로 풀면 막 G 가 기록의 4 배 · Codex 10-14 판정문 §6).
         None = 검사 안 함 (직접 호출 호환 — 솔버 경로는 None 이 아니다)."""
    if not isinstance(plan, dict) or plan.get('kind') != 'am_iface_plan':
        raise TypeError('iface 는 am_iface_plan 의 결과여야 한다')
    _miss = [k for k in ('axes', 'fp_rows', 'rejections', 'fp_sid', 'n_film_rows', 'n_cut_rows', 'record', 'ledger',
                         'realized') if k not in plan]
    if _miss or not (isinstance(plan['axes'], tuple) and len(plan['axes']) == 3):
        raise TypeError(f'iface 계획 모양이 틀렸다 (빠진 키 {_miss}) — am_iface_plan 의 결과를 그대로 줄 것')
    if _iface_rows_fp(plan['axes']) != plan.get('fp_rows'):
        raise ValueError('①′ 계획의 간선 행이 만든 뒤 바뀌었다 (지문 불일치 · E5)')
    #  ★ Codex 10-15 재확인 Q7 (1저자 10-20 승인) — 막 값 공통 불변량: 모든 축 행의 r_face 는 유한 · ≥ 0.  지문은 만든 뒤 바뀐 행만 잡고
    #    (지문을 다시 만든 변이는 통과) 조립은 r_face > 0 면에만 막을 건다 → NaN · 음수 = 막이 조용히 빠지고 +inf = 면 g 0.  r = 0 허용.
    for _k, _ax in enumerate(plan['axes']):
        _rf = np.asarray(_ax['rface'], np.float64)
        _fin = np.isfinite(_rf)
        _bad = ~(_fin & (_rf >= 0.0))
        if _bad.any():
            raise ValueError(f'①′ 계획 축 {_k} 의 막 값 r_face 는 유한한 0 이상 (Ω·cm²) — 어긋난 행 {int(_bad.sum())} '
                             f'(NaN {int(np.isnan(_rf).sum())} · ±inf {int(np.isinf(_rf).sum())} · 유한 음수 {int((_fin & (_rf < 0.0)).sum())}) — '
                             f'NaN · 음수 = 막이 조용히 빠지고 +inf = 면이 끊긴다 (Codex 10-15 Q7)')
    if plan['rejections']:
        raise ValueError('①′ 정량 모드 거부 — ' + ' · '.join(
            f"{x['code']}({x.get('test', '')}{'' if not x.get('test') else ' '}n={x.get('n')})" for x in plan['rejections']))
    if rint:
        raise ValueError('①′ 정량 모드에 r1 탐침 표 (--step3-rint-e/-i) 를 함께 줄 수 없다 — AM 쌍 키는 곡면 위치 · 이중 막 (N3) · '
                         'r1 은 탐침 전용 (v2 §3-2 · D14)')
    if periodic_xy:
        raise ValueError('①′ 정량 모드는 주기 경계를 거부한다 — raster 가 주기 영상 · 이음매 브리지를 만들지 않는다 (N2 · D13)')
    if sid is not None and _grid_fp(sid) != plan['fp_sid']:
        raise ValueError('①′ 계획이 다른 격자에서 만들어졌다 (sid 지문 불일치 · E5)')
    if vox is not None:
        #  ★ RIMP-05 (Codex 10-14 · 1저자 Q4 (가)) — 물리 격자 간격 결합: 조립은 솔버 vox 로 면적 h² 를 쓰고 계획의 r_face 는 계획 vox 로
        #    정규화돼 있다 → 다르면 크기를 바꾼 문제를 풀면서 옛 기하 (A · G) 를 증서로 붙인다.  조립 **전** 거부.
        _v = float(vox)
        if not (np.isfinite(_v) and _v > 0.0):
            raise ValueError(f'①′ 솔버 vox 는 유한한 양수 (µm): {vox!r}')
        _pv = float(plan.get('vox', np.nan))
        _lv = float(plan['ledger'].get('vox', np.nan)) if isinstance(plan.get('ledger'), dict) else np.nan
        if not (_pv == _lv):
            raise ValueError(f'①′ 계획 vox {plan.get("vox")!r} ≠ 계획 원장 vox {_lv!r} — 계획이 원장과 다른 격자 간격을 적었다 (RIMP-05)')
        if _v != _pv:
            raise ValueError(f'①′ 솔버 vox {_v!r} µm ≠ 계획 vox {_pv!r} µm — 같은 sid 라도 물리 격자 간격이 다르면 막 면적 · G 가 '
                             f'(vox/계획 vox)² 배 어긋난다 (RIMP-05 · 계획을 그 vox 의 원장으로 다시 만들 것)')
    if sigma_of_sid is not None and sid is not None and plan['n_film_rows'] > 0:
        a = np.asarray(sigma_of_sid, np.float64)
        sid_ = np.asarray(sid)
        bad = []
        if a.ndim == 1:
            for s_ in (1, 2):
                if (sid_ == s_).any() and not (0 <= s_ < a.shape[0] and a[s_] > 0.0):
                    bad.append(SID_NAME[s_])
        else:
            m_ = np.isin(sid_, (1, 2))
            if m_.any() and not (a[m_] > 0.0).all():
                bad.append('AM(복셀 σ 장)')
        if bad:
            raise ValueError(f'①′ 이 채널의 실제 σ 에서 AM 이 절연 ({bad}) — 막을 실을 면이 없어 요청이 조용히 무효가 된다 '
                             f'(RINT-14 와 같은 부류 · ①′ = 전자 채널 AM–AM 막)')
    return plan


def iface_rface_ohm_cm2(r_ohm_cm2, n_ref, vox, A_um2):
    """CNC 면 막 ASR [Ω·cm²] = r · N_ref · h² / A (h² · A 둘 다 µm² → 비 · v2 §3-4 · v3 §2-1).  면 하나의 막 G =
    h²·1e−8/r_face [S] → N_ref 면 합 = 1e−8·A/r (접점 막 총량).  N_ref = N_c^0 (remove_area) 이면 덮이고 남은 N_c^surv 면의
    합 = 1e−8·A·(N_surv/N_0)/r · N_ref = N_c^surv (renormalize) 이면 1e−8·A/r 유지."""
    return (np.asarray(r_ohm_cm2, np.float64) * np.asarray(n_ref, np.float64) * (float(vox) * float(vox))
            / np.asarray(A_um2, np.float64))


def iface_plan_film_G_S(plan):
    """계획의 활성 막 행 → 접점마다 물리 막 총 컨덕턴스 ΣG [S] = Σ_e h²·1e−8/r_face,e (RINTG-07 단위 사슬 · 면적 µm² → cm²)."""
    nC = len(plan['realized'])
    out = np.zeros(nC)
    h2 = float(plan['vox']) ** 2
    for ax in plan['axes']:
        f = ~ax['cut'] & (ax['rface'] > 0.0)
        if f.any():
            out += np.bincount(ax['cid'][f], weights=h2 * UM2_TO_CM2 / ax['rface'][f], minlength=nC)
    return out


def iface_code_G_S(g_code):
    """코드 면 컨덕턴스 [S/cm·µm] → 물리 G [S] (= ×1e−4 · σ·h·1e−4 cm)."""
    return 1.0e-4 * np.asarray(g_code, np.float64)


def iface_face_film_R_ohm(r_face, vox):
    """면 하나의 막 소자 저항 [Ω] = r_face / (h²·1e−8) (RINTG-03 — 코드 간선 저항으로는 r′/h², r′ 자체가 아니다)."""
    return np.asarray(r_face, np.float64) / (float(vox) ** 2 * UM2_TO_CM2)


def iface_contact_film_G_S(A_um2, r_ohm_cm2):
    """접점 막 총 컨덕턴스 [S] = 1e−8·A[µm²]/r[Ω·cm²] (RINTG-07)."""
    return UM2_TO_CM2 * np.asarray(A_um2, np.float64) / np.asarray(r_ohm_cm2, np.float64)


def iface_face_split(sa, sb, r_face, vox):
    """E4′ (v3 §3) — 막 있는 면 소산의 세 몫 (반셀 a · 반셀 b · 막) = R_a/R_t · R_b/R_t · r′/R_t,
    R_a = h/(2σa) · R_b = h/(2σb) · r′ = r_face·1e4 · R_t = R_a + R_b + r′ (코드 단위 · 단위 무관 비).
    막 몫 = −∂ln g/∂ln r′ (면 하나 · 포락선) — 간선 저항으로는 r′/h² (r′ 자체를 I² 에 곱하면 1/h² 배 틀린다 · RINTG-03)."""
    sa = np.asarray(sa, np.float64); sb = np.asarray(sb, np.float64)
    ra = vox / (2.0 * sa); rb = vox / (2.0 * sb)
    ri = np.asarray(r_face, np.float64) * RINT_OHM_CM2_TO_UM_CM_PER_S
    rt = ra + rb + ri
    return ra / rt, rb / rt, ri / rt


def _iface_label_cut(cond, cut_lin):
    """E3 — 절단 면 (g = 0) 을 뺀 **실제 간선** 그래프의 연결 성분 (6-이웃 · 비주기).  절단이 없으면 `ndimage.label(cond)` 과
    같은 성분 집합 (번호만 다를 수 있다 — 그래서 절단이 없을 때는 호출하지 않는다 · I2).  cut_lin = 축마다 아래쪽 셀 선형 번호."""
    from scipy.sparse.csgraph import connected_components
    shape = cond.shape
    flat = np.flatnonzero(cond.reshape(-1))
    gid = -np.ones(cond.size, np.int64)
    gid[flat] = np.arange(len(flat))
    rr, cc = [], []
    stride = (shape[1] * shape[2], shape[2], 1)
    for ax in range(3):
        sa = [slice(None)] * 3; sb = [slice(None)] * 3
        sa[ax] = slice(0, -1); sb[ax] = slice(1, None)
        both = cond[tuple(sa)] & cond[tuple(sb)]
        ii, jj, kk = np.nonzero(both)
        lo_ = np.ravel_multi_index((ii, jj, kk), shape).astype(np.int64)
        if len(cut_lin[ax]):
            lo_ = lo_[~np.isin(lo_, cut_lin[ax])]
        rr.append(gid[lo_]); cc.append(gid[lo_ + stride[ax]])
    rr = np.concatenate(rr); cc = np.concatenate(cc)
    A = sparse.coo_matrix((np.ones(len(rr), np.int8), (rr, cc)), shape=(len(flat), len(flat)))
    ncomp, labels = connected_components(A, directed=False)
    lab = np.zeros(shape, np.int32)
    lab.reshape(-1)[flat] = labels.astype(np.int32) + 1
    return lab, int(ncomp)


def _iface_edges_fp(axes):
    """해에 실린 ①′ 간선 원장 지문 (E5 · T0-6b)."""
    return _iface_rows_fp(axes)


def iface_ctx_from(res, sid, sigma_of_sid=None):
    """진단용 ①′ 간선 원장 (E2 — 진단은 막 면의 g 를 **원장에서** 읽는다 · `face_rint` 재호출 없음).  ①′ 을 안 쓴 해 → None.
    ⛔ 지문 (E5 · T0-6b): 진단에 넘긴 sid · σ · 해의 φ · 원장 자신이 솔브 때와 다르면 거부 (다른 원장을 끼운 해 · 사후 변조)."""
    e = res.get('_iface')
    if not e:
        return None
    if _grid_fp(sid) != e.get('fp_sid'):
        raise ValueError('①′ 원장: 진단에 넘긴 sid 가 솔브한 sid 와 다르다 (E5)')
    if sigma_of_sid is not None and _grid_fp(np.asarray(sigma_of_sid, np.float64)) != e.get('fp_sig'):
        raise ValueError('①′ 원장: 진단에 넘긴 σ 가 솔브한 σ 와 다르다 (E5)')
    if e.get('fp_phi') is not None and 'phi' in res and _grid_fp(res['phi']) != e['fp_phi']:
        raise ValueError('①′ 원장: 해의 φ 가 원장을 만든 솔브의 φ 가 아니다 (다른 원장을 끼운 해 · T0-6b)')
    if _iface_edges_fp(e.get('axes') or ()) != e.get('fp_edges'):
        raise ValueError('①′ 원장: 간선 원장이 솔브 뒤 바뀌었다 (지문 불일치 · T0-6b)')
    return e


def _iface_override_g(g, axis, ctx, scale):
    """진단의 면 g (축 `axis` 의 슬라이스 모양) 에서 원장 행이 있는 면만 원장 g × scale 로 바꾼다.  행이 없으면 g **그대로**
    (같은 객체 — 비트 같음).  scale = 1 (조립 단위 ×vox) · 1/vox (σ 단위 진단)."""
    if ctx is None:
        return g
    rows = ctx['axes'][axis]
    if not len(rows['lin']):
        return g
    g = np.array(g, np.float64, copy=True)
    ijk = np.unravel_index(rows['lin'], ctx['shape'])
    g[ijk] = rows['g'] * scale
    return g


def am_iface_raw_perm_diag(am_c, am_r, am_t, perm_a, perm_b, box_lo, box_hi, vox, *, delta_bound_um,
                           add_pts=None, add_phase=None, eps_p_um2=IFACE_EPS_P_UM2, **raster_kw):
    """RINTV-02 진단 `raw_perm_mask_diag` (v3.1 §2 · §4 T0-1d) — **raw** 행 순서 둘을 실제 `rasterize` 로 찍어 먼저 동결 마스크
    (M · M0) 와 청구자 기하 G 를 비교한다.  같으면 owner/support 동일을 판정 (`owner_equal`) · 다르면 차이 (셀 · sid 전후 ·
    청구자) 를 **기록만** 하고 owner 규칙의 통과 · 실패로 대신 판정하지 않는다 (`owner_judged = False`).
    ⚠ legacy raster 를 조용히 canonical 화하지 않는다 (그것은 D21 · 새 OFF 세대)."""
    c = np.asarray(am_c, np.float64); r = np.asarray(am_r, np.float64); t = np.asarray(am_t)
    tol = raster_kw.get('tol_am_um', 0.10); bu = raster_kw.get('bridge_um')
    runs = []
    for perm in (np.asarray(perm_a), np.asarray(perm_b)):
        cc, rr, tt = c[perm], r[perm], t[perm]
        sid, _ = rasterize(cc, rr, tt, add_pts, add_phase, box_lo, box_hi, vox, **raster_kw)
        sid_pre, _ = rasterize(cc, rr, tt, None, None, box_lo, box_hi, vox, **raster_kw)
        led = am_iface_ledger(cc, rr, tt, sid, sid_pre, box_lo, vox, delta_bound_um=delta_bound_um,
                              tol_am_um=tol, bridge_um=bu, eps_p_um2=eps_p_um2,
                              raster_sdcp_bridge_um=float(raster_kw.get('sdcp_bridge_um', 0.0) or 0.0))
        runs.append((sid, sid_pre, led))
    (sa, spa, la), (sb, spb, lb) = runs
    Ma, Mb = np.isin(sa, (1, 2)), np.isin(sb, (1, 2))
    M0a, M0b = np.isin(spa, (1, 2)), np.isin(spb, (1, 2))
    geo = lambda cc, rr, tt: sorted(zip(map(tuple, cc.tolist()), rr.tolist(), [int(x) for x in tt]))   # noqa: E731
    pairs_g = [sorted({tuple(sorted((tuple(c[p][i].tolist()), tuple(c[p][j].tolist()))))
                       for i, j, _d in am_bridge_pairs(c[p], r[p], tol)}) for p in (np.asarray(perm_a), np.asarray(perm_b))]
    claims_equal = (geo(c[np.asarray(perm_a)], r[np.asarray(perm_a)], t[np.asarray(perm_a)])
                    == geo(c[np.asarray(perm_b)], r[np.asarray(perm_b)], t[np.asarray(perm_b)])
                    and pairs_g[0] == pairs_g[1])
    masks_equal = bool(np.array_equal(Ma, Mb) and np.array_equal(M0a, M0b))
    out = {'test': 'T0-1d raw_perm_mask_diag', 'n_M': (int(Ma.sum()), int(Mb.sum())),
           'n_M0': (int(M0a.sum()), int(M0b.sum())), 'masks_equal': masks_equal, 'claims_equal': bool(claims_equal)}
    if masks_equal and claims_equal and la['owner'] is not None and lb['owner'] is not None:
        out['owner_judged'] = True
        out['owner_equal'] = bool(np.array_equal(la['owner'], lb['owner'])
                                  and all(np.array_equal(la['faces'][k], lb['faces'][k]) for k in la['faces'])
                                  and all(np.array_equal(la['contacts'][k], lb['contacts'][k]) for k in la['contacts']))
        return out
    diff = []
    for w in np.argwhere((Ma != Mb) | (M0a != M0b))[:16]:
        w = tuple(int(v) for v in w)
        lin = int(np.ravel_multi_index(w, sa.shape))
        cl = set()
        for L in (la, lb):
            if L.get('claims') is not None:
                m_ = L['claims']['cell'] == lin
                cl |= {int(x) for x in L['claims']['rank'][m_]}
        diff.append({'ijk': w, 'sid_a': int(sa[w]), 'sid_b': int(sb[w]), 'sid_pre_a': int(spa[w]),
                     'sid_pre_b': int(spb[w]), 'claimants_canonical': sorted(cl)})
    out.update(owner_judged=False, n_diff_cells=int(((Ma != Mb) | (M0a != M0b)).sum()), diff=diff,
               note='M (또는 청구자) 다름 → 차이만 기록 · owner 규칙의 통과/실패로 판정하지 않는다 (v3.1 §2)')
    return out


def _fa_refuse(res, what):
    """② S1 v0 (2026-10-20 · 설계 v1 §3-3 · E2) — 면 α 를 원장에서 안 읽는 진단 (je · 소산 분담 · |J| 점군 · Joule) 은 face_alpha
    해를 거부한다 (조화평균을 다시 계산하면 막힌 면의 전류가 과대 · fail-closed).  끈 해는 아무것도 안 한다 (비트 같음)."""
    if isinstance(res, dict) and (res.get('_face_alpha') is not None or res.get('face_alpha') is not None):
        import ptfe_face_alpha as _pfa
        _pfa.refuse_diag(res, what)


#: ★★★ **플레이트 결합 규약 판**.  이 문자열이 바뀌면 σ_e 절대값이 바뀐다 —
#   `p2` = 2026-08-25 (CDXR3-6) 가장 바깥 **점유 고체**를 먼저 정하고 그것이 도체일 때만
#   플레이트에 붙인다.  `p1` = 그 이전, `cond`(σ>0) 로 표면을 골라 절연 고체를 **관통**했다.
#   ⚠ 두 판의 산출물은 **섞으면 안 된다** (같은 침대·같은 vox 라도 σ_e 가 다르다).
#     그래서 매니페스트에 싣고 `PROTOCOL_FIELDS` 에 넣는다 — 규약 해시가 갈라진다.
PLATE_RULE_VERSION = 'p2-occupied-surface-first'


def solve_sigma_z(sid, sigma_of_sid, vox, return_field=False, z_top_um=None, plate_band_um=None,
                  z_bot_um=None, plate_band_bot_um=None, bot_allowed=None, periodic_xy=False,
                  area_um2=None, rint=None, pid=None, iface=None, face_alpha=None, cjunc=None, cjunc_graph_only=False):
    """Effective through-plane (z) σ of the voxel σ-id grid.  Finite volume, harmonic-mean face
    conductance g = (2σaσb/(σa+σb))·vox (cubic voxels: face area vox² / distance vox), collector
    plate φ=1 at the bed bottom, φ=0 plate at the bed top, lateral Neumann.

    PLATES = BAND-COUPLED CONTACT SETS (physics review F1): every conductive voxel whose centre
    lies within `band` of its plate PLANE couples with the distance-aware conductance
    g = σ·vox²/max(dist, vox/2).  A single-quantization-layer plate made σ swing ×7.7 under a
    ±0.2µm sub-voxel bed shift (2-4 AM crowns = the whole exit) — the band (default vox+0.1µm,
    capped 1.4·vox: the 0.1µm is the econn contact tol) makes the plate contact set the PHYSICAL
    crown-contact set, restoring cross-scaffold relative trust.  Top plane = z_top_um (bed
    thickness, production) else the top face of the highest AM layer; bottom plane = floor of the
    lowest occupied layer.  σ_eff uses the true plate gap L = z_plate − z_b.
    Returns dict(sigma_eff, n_dof, plate_z_um, n_plate_vox, cg_info, resid, unconverged
    [, phi, cond])."""
    nx, ny, nz = sid.shape
    sig = sigma_field(sigma_of_sid, sid)                     # 표 또는 복셀별 σ (S/cm)
    #  ① 계면 저항 (2026-10-02): `rint` = {(sid_a, sid_b): r[Ω·cm²]} · `pid` = 입자 번호 격자
    #    (같은 sid 안의 입자 경계용 · None 이면 같은 상 면은 무영향).  둘 다 None = 옛 조립 비트 동일.
    _rint = _check_rint_table(rint)
    if pid is not None:
        pid = np.asarray(pid)
        if pid.shape != tuple(sid.shape):
            raise ValueError(f'solve_sigma_z: pid 모양 {pid.shape} ≠ sid {tuple(sid.shape)} — '
                             f'다른 격자의 번호를 쓰게 된다')
    if _rint:
        #  ★ G1-2 (Codex Q4 · RINT-14) — 입구에서 거부한다 (0 면으로 조용히 무효가 되는 두 경우):
        #    ⓐ 이 채널의 실제 σ 에서 절연인 상이 낀 쌍  ⓑ 같은 상 AM 쌍 (r > 0) 인데 입자 번호 pid 가 없음
        rint_channel_check(_rint, sigma_of_sid, sid)
        _same = sorted(SID_NAME[a] for (a, b), v in _rint.items() if a == b and v > 0.0)
        if _same and pid is None:
            raise ValueError(f'solve_sigma_z: 같은 상 계면 {_same} 은 입자 번호 pid 가 있어야 한다 — 없으면 면 0 '
                             f'으로 조용히 무효 (unsupported identity · RINT-02/14)')
    #  ② S1 × S2 (Z3 10-20 · 설계 v1 §3 · §4 · 등록 R §10 꼴 `PTFE_STAMP=face_alpha` + 접합 + P0/P1) — 한 솔브에 같이 준다.
    #    조합 규칙 (설계 그대로 · 순서가 규칙이다): ① `couple()` 이 α (면 개구율) 를 **먼저** 융합 면에 곱하고 α = 0 면은 행렬에서 뺀다
    #    (`_pfa.assemble_axis` 의 `_keep` — a2 · b2 · g 를 같은 마스크로 압축) ② 그 면들을 접합 조립기가 받아 멤버십 재배선 · 발자국 절단 ·
    #    접합 간선을 넣는다 (`_cjs.add_faces` — 조립기는 dof → 셀 번호로 sid 를 다시 읽으므로 압축된 a2 · b2 · g 셋이면 일관) ③ PTFE 가
    #    접합 끝을 덮을 때는 P0/P1 법칙만 (`cjunc_plan` 의 덮임 판정 · 접합 간선은 면이 아니라 α 가 곱해지지 않는다 — 이중 계상 금지) ·
    #    접합이 끊는 면 (VV 자리 · 자기 · 미등록) 은 같은 탄소 상 면이라 α 면제 (`ptfe_face_alpha._exempt_mask`) → 두 연산이 같은 면을 겹쳐
    #    가리지 않는다.  관문 = 각자 그대로 (`require_plan` · `cjunc_require_quantitative`) · 연결성 = 접합 조립기의 실제 그래프 (α = 0 면이
    #    빠진 뒤) · face_alpha 의 사방 절단 셀 수 = 같은 기록 함수.
    #    ⚠ 2026-10-20 B6 통합 때 넣은 **임시** 동시 거부 (설계 §3 · §4 의 동시 거부 목록에 없던 것) 를 Z3 가 뺐다.  centerline + P1 거부는
    #      그대로 (`cjunc_plan` · `ca_ext_cjunc`).
    #  ② S1 (2026-10-20 · Rint ② · 설계 v1 §3 · R18 Q6) — PTFE 면 개구율 `face_alpha` = ptfe_face_alpha.build_plan(...) 의 결과.
    #    None (기본) 이면 아래 어떤 줄도 바뀌지 않는다 (옛 조립 · 연결성 · 반환 키 비트 같음).  계획 무결성 · 격자 · 지문은
    #    `require_plan` 이 조립 전에 본다 (CG 0) · r1 표 · ①′ · 주기와 동시 = 거부 (v0 미정의 조합 · seam 미지원).
    _fap = None                                              # `_pfa` (모듈) 는 _fap 가 있을 때만 쓰인다
    _fa_used, _fa_iso = {}, 0
    if face_alpha is not None:
        import ptfe_face_alpha as _pfa
        if rint is not None or iface is not None or periodic_xy:
            raise ValueError('solve_sigma_z: face_alpha 는 r1 계면 표 (rint) · ①′ iface · periodic_xy 와 함께 쓸 수 없다 '
                             '(v0 — 정의되지 않은 결합 · 주기 seam 미지원 · 설계 v1 §3-3)')
        _fap = _pfa.require_plan(face_alpha, sid, sigma_of_sid, vox, pid=pid)
    #  ①′ AM–AM 막 (2026-10-07 · Rint G2 · 기구만 · 정량 채택 HOLD) — `iface` = am_iface_plan(...) 의 결과.  None (기본) 이면
    #    아래 어떤 줄도 바뀌지 않는다 (옛 조립 · 연결성 · 반환 dict 키 비트 같음).  거부 입력 · r1 동시 · 주기 · 다른 격자 → 거부.
    _ifp = (iface_require_quantitative(iface, sid, sigma_of_sid, rint=_rint, periodic_xy=periodic_xy, vox=vox)
            if iface is not None else None)
    _ife_used = {}                                           # ①′ 조립이 실제로 쓴 간선 (축마다) — 진단이 이것을 읽는다 (E2)
    _faces = {}                                              # 계면 면 수 (상 쌍별 · 실물 증거)
    #  ② 탄소 접합 (2026-10-20 · Rint ② S2/S3 · 기구만 · `carbon_junction`) — None (기본) 이면 아래 어떤 줄도 바뀌지 않는다.
    #    거부 입력 · r1 · ①′ · 주기 · return_field · 다른 격자 · VGCF 절연 채널 → 조립 전 거부 (CG 0).
    _cjp = _cjs = None
    #  ★ 10-26 묶음 B6 (Codex 회차 ① RR1-01 · 1저자 10-26 Q2 (가)) cjunc_graph_only = 봉인 원천 다시 조립 (솔브 없음) — 같은 입력 (raster · 원장 ·
    #    계획 · 등록 절단 규칙) 으로 접합 계를 조립해 주 계 · 반사실 끝 그래프 지문만 돌려준다 (`cjunc_graphs` = {rule · main · lower · upper} ·
    #    CG · 증서 · 기록 없음 · 소비자 `ca_ext_svcf.graph_problem` 대조용).  기본 False = 아래 어떤 줄도 바뀌지 않는다.
    if cjunc_graph_only and cjunc is None:
        raise ValueError('solve_sigma_z: cjunc_graph_only 는 접합 계획 (cjunc) 이 있어야 한다 (다시 조립할 접합 계가 없다)')
    if cjunc is not None:
        import carbon_junction as _cjm
        _cjp = _cjm.cjunc_require_quantitative(cjunc, sid, vox, sigma_of_sid=sigma_of_sid, rint=_rint, iface=iface,
                                               periodic_xy=periodic_xy, return_field=return_field)

    def _iface(solved):
        #  ① 계면 원장 — **쓴 것**: 표 · pid 사용 · 실제로 걸린 면 수 · 이 해가 풀렸는가.  r 를 안 줬으면 None.
        #  ★ G1-2 (RINT-02) — 조기 반환 해에도 싣는다 (solved False): 요청 표가 이 호출에 **전달됐는지**를
        #    영수증이 해의 성패와 무관하게 알아야 배선 삭제를 잡는다.
        if _rint is None:
            return None
        return {'model': INTERFACE_MODEL_VERSION, 'unit': 'ohm_cm2',
                'table': rint_table_record(_rint), 'pid_used': pid is not None,
                'n_faces_rint': int(sum(_faces.values())),
                'faces_by_pair': dict(sorted(_faces.items())), 'solved': bool(solved)}

    def _zero_graph(reason):
        #  ★ 10-21 (RCA-13) — 조기 반환 σ 0 을 정한 그래프 (아래 연결성 분기와 같은 조건 · 증서 기록용 이름)
        head = str(reason or '').split('(', 1)[0]
        if head in ('no_conductive_voxels', 'degenerate_thin_bed', 'no_plate_contact'):
            return {'no_conductive_voxels': 'conductor_mask', 'degenerate_thin_bed': 'geometry',
                    'no_plate_contact': 'plate_mask'}[head]
        if _cjp is not None:
            return 'cjunc_assembled'
        if _ifp is not None and _ifp['n_cut_rows'] > 0:
            return 'iface_cut'
        if _fap is not None and _fap['n_cut_rows'] > 0:
            return 'face_alpha_cut'
        return 'cell6'

    def _cert_bind_kw():
        #  ★ 10-21 (사전 리뷰 PRE-impl-07 · 1저자 "권고대로 해") — 증서 ↔ 런 결합 칸 (영값 · 양의 해 같은 칸 · `step3_conv_cert.bind_record`):
        #    이 솔브의 입력 지문 — 격자 · σ 표 (`_grid_fp`) · face_alpha 계획 (`require_plan` 이 대조한 fp_plan) · 접합 원장 · 계획 행
        #    (`cjunc_require_quantitative` 가 대조한 값).  계약 (`run_contract.cert_binding_problem`) 이 매니페스트의 정본 지문 칸과 맞춘다.
        return {'fp_sid': _grid_fp(sid), 'fp_sig': _grid_fp(np.asarray(sigma_of_sid, np.float64)),
                'fp_face_plan': (_fap['fp_plan'] if _fap is not None else None),
                'fp_cjunc_registry': (_cjp['registry']['fp']['registry'] if _cjp is not None else None),
                'fp_cjunc_rows': (_cjp['fp_rows'] if _cjp is not None else None)}

    def _graph_bind():
        #  ★ 10-26 B″ (1저자 Q1 (가)) — 조립만 해의 입력 결합 (증서 결합 칸과 같은 함수 · 판 · 지문 다섯) — 봉인 원천이 "같은 입력에서 다시 조립했다" 를
        #    그 런 주 증서의 결합과 대조한다 (`rint_r_chain.RunnerGraphSource`)
        import step3_conv_cert as _ccg
        return _ccg.bind_record(**_cert_bind_kw())

    def _ret(d):
        if cjunc_graph_only:                               # ★ 10-26 묶음 B6 — 접합 조립 전 조기 반환 = 다시 조립할 계 없음 (지문 없음 · 사유만)
            return {'graph_only': True, 'cjunc_graphs': None, 'reason': d.get('reason'), 'bind': _graph_bind()}
        if CONV_CERT:
            #  ★ 10-21 (Codex RCA-13 · 1저자 Q7 일부) — 조기 반환 해의 **상태 증서** (CG 없이 낸 σ 0): 두 판을 잇는 성분이 없는 사유 =
            #    VALID_ZERO_TOPOLOGY (σ 0 = 정상 결과 · 바닥 극한 R_j = ∞ 를 증서 없음으로 멈추지 않는다) · 단락 · 얇은 침대 · 모르는 사유 =
            #    게시 불가 상태.  증서 끔 = 이 블록 없음 (옛 키 그대로).
            #    ★ 10-21 (PRE-impl-07) — 결합 칸 = 격자 · σ 표 + 계획 지문 셋 (`_cert_bind_kw` · 양의 해 증서와 같은 칸)
            import step3_conv_cert as _ccz
            d['conv_cert'] = _ccz.early_record(d, zero_graph=_zero_graph(d.get('reason')), **_cert_bind_kw())
        #  ①′ — 조기 반환 해에도 기록 (solved False) · iface 를 안 줬으면 dict 를 **그대로** 돌려준다 (옛 키 그대로).
        if _ifp is not None:
            d['iface'] = dict(_ifp['record'], solved=False)
        if _fap is not None:                               # ② S1 — 조기 반환 해에도 기록 (solved False · 영수증 = failed)
            d['face_alpha'] = _pfa.solve_record(_fap, {}, solved=False)
        if _cjp is not None:                                 # ② — 조기 반환 해에도 계획 기록 (solved False · 사유)
            d['cjunc'] = _cjm.early_record(_cjp, d.get('reason'))
            if _cjs is not None and getattr(_cjs, 'stats', None):
                d['cjunc'].update(_cjs.stats)
        return d
    cond = sig > 0
    if not cond.any():
        return _ret({'sigma_eff': 0.0, 'n_dof': 0, 'n_floating_dropped': 0, 'cg_info': 0, 'resid': 0.0,
                     'unconverged': False, 'reason': 'no_conductive_voxels',
                     'periodic_xy': bool(periodic_xy), 'interface': _iface(False)})
    occ = np.where(cond.any((0, 1)))[0]
    k_bot = int(occ[0])
    am_occ = np.where((((sid == 1) | (sid == 2)) & cond).any((0, 1)))[0]
    k_top_ref = int(am_occ[-1]) if len(am_occ) else int(occ[-1])
    # plate PLANES in CONTINUOUS µm (not voxel-snapped): production passes z_bot=0 (collector)
    # and z_top=thickness — snapping to occupied layers re-introduced sub-voxel plate luck
    # (probe: ×2.8 residual swing) because the plane then hops with the rasterization phase.
    z_b = float(z_bot_um) if z_bot_um is not None else k_bot * vox
    z_plate = float(z_top_um) if z_top_um is not None else (k_top_ref + 1) * vox
    z_plate = min(z_plate, nz * vox)
    if z_plate - z_b <= 1.5 * vox:                         # degenerate (≈1-layer bed) → no through-path
        return _ret({'sigma_eff': 0.0, 'n_dof': int(cond.sum()), 'n_floating_dropped': 0, 'cg_info': 0,
                     'resid': 0.0, 'unconverged': False, 'reason': 'degenerate_thin_bed',
                     'periodic_xy': bool(periodic_xy), 'interface': _iface(False)})
    band = plate_band_um if plate_band_um is not None else (vox + 0.10)
    # BOTTOM band override (collector GEOMETRY axis): 'wetted/primer' = default band (vox+0.1 —
    # a conformal conductive film reaches ~0.2µm gaps, + quantization half-voxel); 'bare' passes a
    # TIGHTER band (0.5·vox+0.1 = true-contact crowns only) → fewer collector contacts → the exit
    # current funnels through crown contacts and the per-AM je map redistributes near the collector
    # (the primer-paper Fig-4d red-box story).  ±half-voxel quantization blur documented.
    band_bot = plate_band_bot_um if plate_band_bot_um is not None else band
    zc = (np.arange(nz) + 0.5) * vox                       # voxel-centre heights
    # PER-COLUMN SINGLE CONTACT (review F1, final form): each lateral column couples to a plate
    # through ONE voxel — its surface voxel — iff that surface is within `band` of the plane,
    # with distance-aware g.  A layer-band coupled a column through TWO layers whenever the band
    # edge crossed a voxel centre (probe: plate-voxel count 54→278 on a +0.1µm shift, σ ×2) —
    # per-column contact makes the plate set the physical crown patch and σ vary smoothly.
    #  ★★★ 2026-08-25 (CDXR3-6, Codex 흡수 리뷰) — **표면은 도체가 아니라 고체가 정한다.**
    #    옛 판은 `cond`(= σ > 0) 로 표면 복셀을 골랐다.  그러면 **절연 고체가 표면에 있어도
    #    건너뛰고 그 아래 도체를 플레이트에 직접 붙인다** = 플레이트가 절연체를 관통한다.
    #    실측 재현 (vox 0.15, 기둥 [AM,AM,AM,PTFE]): 표면 PTFE 인 기둥의 σ_eff 가
    #    **위가 공극인 기둥과 완전히 같았다** (0.01) — PTFE 가 없는 것과 구분되지 않았다.
    #    exact-zero PTFE 규약(CDXR2-6)이 이 결함을 **노출**시켰지만 결함 자체는 그 전부터
    #    있었다 — 전자 솔브에서 **SE(sid 6)도 σ=0 인 절연 고체**이기 때문이다.
    #    ⇒ 각 기둥에서 **가장 바깥 점유 고체**(sid != 0)를 먼저 정하고, 그것이 그 수송에서
    #      **도체일 때만** 결합한다.  공극 갭은 그대로다 (band 가 담당) — 절연 **고체**를
    #      통과해 더 깊은 도체를 찾는 것만 막는다.
    occ = sid != 0
    any_c = occ.any(2)
    k_first = np.argmax(occ, axis=2)                       # column's lowest OCCUPIED voxel
    k_last = nz - 1 - np.argmax(occ[:, :, ::-1], axis=2)   # column's highest OCCUPIED voxel
    _ii, _jj = np.meshgrid(np.arange(nx), np.arange(ny), indexing='ij')
    _surf_bot_cond = cond[_ii, _jj, k_first]               # 노출면이 이 수송의 도체인가
    _surf_top_cond = cond[_ii, _jj, k_last]
    #  ★★★ 2026-08-25 (R3-CX-07 ④, Codex 3차) — **band 비교가 signed 였다.**
    #    `zc - z_b <= band` 는 셀이 판 **아래**(음수)여도 참이다.  대칭으로 top 도
    #    `z_plate - zc <= band` 라 판보다 **위**인 셀이 접촉으로 뽑혔다 (Codex 실측:
    #    물리 top plane 보다 0.825 µm 위인 셀이 band=0.25 에서 σ=0.0026667 을 냈다).
    #    슬래브 밖 셀은 접촉이 아니라 **기하가 틀린 것**이다 ⇒ 절대값으로 본다.
    bot_m = any_c & _surf_bot_cond & (np.abs(zc[k_first] - z_b) <= band_bot)
    # ANALYTIC contact mask (v3, optional): [nx,ny] bool from EXACT sphere/point z (payload computes
    # it — gap ≤ 0.1µm bare / ≤ 0.3µm film-wetted).  Voxel-centre bands cannot resolve below
    # ~half-voxel; the analytic mask removes that blur — the SELECTION is exact, only the coupling
    # conductance stays voxel-scale.
    if bot_allowed is not None:
        bot_m &= np.asarray(bot_allowed, bool)
    top_m = any_c & _surf_top_cond & (np.abs(z_plate - zc[k_last]) <= band)
    if not bot_m.any() or not top_m.any():
        return _ret({'sigma_eff': 0.0, 'n_dof': int(cond.sum()), 'n_floating_dropped': 0, 'cg_info': 0,
                     'resid': 0.0, 'unconverged': False,
                     'reason': f'no_plate_contact(bot={int(bot_m.sum())},top={int(top_m.sum())},'
                               f'z_b={z_b:.2f},z_plate={z_plate:.2f},band={band:.2f})',
                     'periodic_xy': bool(periodic_xy), 'interface': _iface(False)})
    # FLOATING ISLANDS (components touching NEITHER plate contact) = singular blocks, zero current
    # by physics → dropped (their je reads 0).
    # ★ 리뷰 B#1 caveat: 이 label 은 6-connectivity(비주기)라 periodic_xy=True 의 x/y wrap 커플링을
    #   모른다.  σ_z/thermal/pore 는 무해(plate 안 닿는 성분은 어차피 net through-flux 0=dangling).
    #   solve_reaction_current 은 seam으로만 본류에 붙은 경계 patch의 BV 반응전류를 0으로 과소계상할
    #   수 있으나, 프로덕션 조밀 베드는 본류가 bulk로 x=0 에 닿아 실질 영향 미미(경계 몇 입자).
    if _cjp is not None:
        lab, _nl = cond.astype(np.int32), 1               # ② — 셀 라벨로 가지치기하지 않는다 (실제 그래프 = 조립 뒤 · J7 · J12)
        if _fap is not None and _fap['n_cut_rows'] > 0:   # Z3 — 조합: α = 0 면은 조립기 그래프에서 빠진다 · 사방 절단 셀 수 = 같은 기록
            _fa_iso = _pfa.isolated_by_cut(cond, _pfa.cut_lin(_fap))
    elif _ifp is not None and _ifp['n_cut_rows'] > 0:
        #  ①′ E3 — 절단 면 (g = 0) 을 뺀 **실제 간선** 그래프로 떠 있는 성분을 가린다 (셀 6-연결 라벨은 절단을 모른다).
        #    절단이 없으면 위 옛 라벨 그대로 (성분 집합이 같다 → I2 비트 같음).
        lab, _nl = _iface_label_cut(cond, tuple(ax['lin'][ax['cut']] for ax in _ifp['axes']))
    elif _fap is not None and _fap['n_cut_rows'] > 0:
        #  ② S1 E3 — α = 0 면 (절단) 을 뺀 **실제 간선** 그래프 (①′ 와 같은 함수) · 사방 절단 셀 수는 기록 (가지치기 전 cond).
        lab, _nl = _iface_label_cut(cond, _pfa.cut_lin(_fap))
        _fa_iso = _pfa.isolated_by_cut(cond, _pfa.cut_lin(_fap))
    else:
        lab, _nl = ndimage.label(cond)                     # 6-connectivity = the face-coupling graph
    _ii, _jj = np.where(bot_m); _lb = lab[_ii, _jj, k_first[bot_m]]
    _ii, _jj = np.where(top_m); _lt = lab[_ii, _jj, k_last[top_m]]
    plate = np.unique(np.concatenate([_lb, _lt]))
    plate = plate[plate > 0]
    # ★ 2026-08-12 (Codex #2): `plate` 는 **합집합** = "한쪽 플레이트에라도 닿는" 성분이다.
    #   솔브에는 옳다 — 한쪽만 닿는 성분은 Dirichlet 이 걸려 특이하지 않고 net through-flux 가
    #   0 이라 σ_eff 에 기여하지 않는다.  그러나 그 n_dof 로 만든 `eps_connected_pct` 를
    #   "관통 공극률" 로 읽으면 **과대**다.  ⇒ 교집합(양쪽 다 닿음)을 **따로 세어** 병기한다.
    #   솔브 경로는 그대로 (측정만 추가).
    _sb = set(np.unique(_lb[_lb > 0]).tolist())
    _st = set(np.unique(_lt[_lt > 0]).tolist())
    _through = np.array(sorted(_sb & _st), dtype=lab.dtype)
    n_through_dof = int(np.isin(lab, _through).sum()) if len(_through) else 0
    n_float = int(cond.sum())
    cond &= np.isin(lab, plate)
    n_float -= int(cond.sum())
    n_dof = int(cond.sum())
    n_plate_reachable_dof = n_dof                          # = 합집합 (이름을 정직하게)
    if n_dof == 0:
        return _ret({'sigma_eff': 0.0, 'n_dof': 0, 'n_floating_dropped': n_float, 'cg_info': 0,
                     'resid': 0.0, 'unconverged': False, 'reason': 'all_floating_dropped',
                     'periodic_xy': bool(periodic_xy), 'interface': _iface(False)})
    #  ★★★ 2026-08-30 (Codex R13 C-4) — **관통 성분이 없으면 조기반환한다.**
    #    `plate` 는 위 주석대로 **합집합**("한쪽에라도 닿음")이라, 양쪽 판에 각각 닿지만
    #    서로 이어지지 않은 두 성분이 있으면 `n_dof > 0` 인 채 정상 솔브 경로를 탄다.
    #    그 해는 `sigma_eff = 0.0 · cg_info = 0 · unconverged = False · reason = None` 이고,
    #    payload 가 그것을 **`complete`** 로 찍는다 = **0 이 측정값으로 원장에 들어간다**
    #    (Codex 실측 재현: sid[0,0,0]=6 · sid[1,0,4]=6 → n_dof 2 · n_through_dof 0 · complete).
    #    `reason` 가드(mpm_webapp_payload)는 이것을 못 잡는다 — 여기엔 reason 이 **없기** 때문이다.
    #  ⚠ **`periodic_xy` 에서는 발동하지 않는다** — 위 :710 이 이미 적었듯 이 label 은
    #    6-connectivity **비주기**라, x/y wrap 으로 실제 이어진 두 성분을 "안 이어짐" 으로
    #    오판한다.  거기서 fail-closed 하면 **정상 펠릿 RVE 런을 죽인다.**  주기 라벨링이
    #    생기기 전까지 그 축은 열어 둔다 (모르는 것을 아는 척하지 않는다).
    if n_through_dof == 0 and not periodic_xy:
        return _ret({'sigma_eff': 0.0, 'n_dof': n_dof, 'n_through_dof': 0,
                     'n_plate_reachable_dof': n_plate_reachable_dof,
                     'n_floating_dropped': n_float, 'cg_info': 0, 'resid': 0.0,
                     'unconverged': False, 'reason': 'no_through_component',
                     'periodic_xy': bool(periodic_xy), 'interface': _iface(False)})
    sig = np.where(cond, sig, 0.0)
    idx = -np.ones(sid.shape, np.int64)
    idx[cond] = np.arange(n_dof)
    if _cjp is not None:                                   # ② — 멤버십 dof (J1) · 면 재배선 · 접합 간선 조립기
        _cjs = _cjm.CjuncAssembler(_cjp, sid, cond, idx, n_dof, sig, vox)

    rows, cols, vals = [], [], []
    diag = np.zeros(n_dof, np.float64)
    b = np.zeros(n_dof, np.float64)

    def _ifa_assemble(axis, m, sa_m, sb_m, g, a2, b2):
        #  ①′ — 계획의 활성 행 (막 r_face > 0 · 절단) 중 이 행렬에 있는 면 (양쪽 셀 다 dof) 만 바꾼다.  행이 없으면 그대로.
        ax = _ifp['axes'][axis]
        z_ = np.zeros(0, np.int64)
        _ife_used[axis] = {'lin': z_, 'g': np.zeros(0), 'rface': np.zeros(0), 'cut': np.zeros(0, bool),
                           'ck': z_.copy(), 'cid': z_.copy(), 'olo': z_.copy()}
        if not len(ax['lin']):
            return g, a2, b2
        shp = list(sid.shape); shp[axis] -= 1
        pos = np.ravel_multi_index(np.unravel_index(ax['lin'], sid.shape), tuple(shp))
        mf = np.flatnonzero(m)
        loc = np.searchsorted(mf, pos)
        ok = loc < len(mf)
        ok[ok] = mf[loc[ok]] == pos[ok]
        if not ok.any():
            return g, a2, b2
        g = np.array(g, np.float64, copy=True)
        L_ = loc[ok]; cut_ = ax['cut'][ok]
        fl_ = ~cut_
        if fl_.any():
            g[L_[fl_]] = interface_face_g(g[L_[fl_]], sa_m[L_[fl_]], sb_m[L_[fl_]], ax['rface'][ok][fl_], vox)
        if cut_.any():
            g[L_[cut_]] = 0.0                              # E6 — 절단 = g 0 (원장에는 tombstone 행으로 남는다)
        _ife_used[axis] = {'lin': ax['lin'][ok], 'g': g[L_].copy(), 'rface': ax['rface'][ok], 'cut': cut_.copy(),
                           'ck': ax['ck'][ok], 'cid': ax['cid'][ok], 'olo': ax['olo'][ok]}
        if cut_.any():
            keep = np.ones(len(g), bool); keep[L_[cut_]] = False
            g, a2, b2 = g[keep], a2[keep], b2[keep]
        return g, a2, b2

    def couple(sl_a, sl_b, axis=None):
        A, B = idx[sl_a], idx[sl_b]
        sa, sb = sig[sl_a], sig[sl_b]
        m = (A >= 0) & (B >= 0)
        if not m.any():
            return
        g = (2.0 * sa[m] * sb[m] / (sa[m] + sb[m])) * vox   # σ[S/cm]·vox[µm] — unit cancels in σ_eff
        if _rint:                                          # ① 계면 저항 — 표의 쌍 면만 (나머지 비트 동일)
            _r = face_rint(sid[sl_a][m], sid[sl_b][m], _rint,
                           None if pid is None else pid[sl_a][m],
                           None if pid is None else pid[sl_b][m])
            _mi = _r > 0.0
            if _mi.any():
                g = interface_face_g(g, sa[m], sb[m], _r, vox)
                _sl = sid[sl_a][m][_mi].astype(np.int64); _sh = sid[sl_b][m][_mi].astype(np.int64)
                _code = np.minimum(_sl, _sh) * 1000 + np.maximum(_sl, _sh)
                for _c, _n in zip(*np.unique(_code, return_counts=True)):
                    _k = f'{SID_NAME.get(int(_c) // 1000, str(int(_c) // 1000))}|' \
                         f'{SID_NAME.get(int(_c) % 1000, str(int(_c) % 1000))}'
                    _faces[_k] = _faces.get(_k, 0) + int(_n)
        a2, b2 = A[m], B[m]
        if _ifp is not None and axis is not None:          # ①′ AM–AM 막 · 절단 (원장 행만 · 나머지 면 그대로)
            g, a2, b2 = _ifa_assemble(axis, m, sa[m], sb[m], g, a2, b2)
        if _fap is not None and axis is not None:          # ② S1 — g = α·g0 (계획 행만 · α = 0 면은 행렬에서 뺀다 · 나머지 그대로)
            g, _keep = _pfa.assemble_axis(_fap, axis, m, g, _fa_used)
            if _keep is not None:
                a2, b2 = a2[_keep], b2[_keep]
        if _cjs is not None:                               # ② — 면은 탄소 접합 조립기가 받는다 (멤버십 재배선 · 절단 · 법칙)
            #    면별 배열은 a2 · b2 · g 셋뿐 (sid · pid 는 조립기가 dof → 셀 번호로 다시 읽는다) — 위 `_keep` 압축이 그대로 넘어간다.
            _cjs.add_faces(axis, a2, b2, g)
            return
        rows.append(a2); cols.append(b2); vals.append(-g)
        rows.append(b2); cols.append(a2); vals.append(-g)
        np.add.at(diag, a2, g); np.add.at(diag, b2, g)

    couple(np.s_[:-1, :, :], np.s_[1:, :, :], 0)
    couple(np.s_[:, :-1, :], np.s_[:, 1:, :], 1)
    couple(np.s_[:, :, :-1], np.s_[:, :, 1:], 2)
    if periodic_xy:                                        # ★x,y 주기 wrap (MPM RVE 'boundary p p f' 정합;
        if nx > 1:                                         #   z=plate 유지).  nx/ny=1이면 자기결합 방지 가드.
            couple(np.s_[-1:, :, :], np.s_[:1, :, :])      # x: nx-1 ↔ 0
        if ny > 1:
            couple(np.s_[:, -1:, :], np.s_[:, :1, :])      # y: ny-1 ↔ 0
    # per-column plate couplings, distance-aware: g = σ·vox²/max(dist, vox/2) (= 2σ·vox at half-cell)
    def _plate_couple(mask, ksurf, plane, phi_p):
        ii, jj = np.where(mask)
        kk2 = ksurf[mask]
        A = idx[ii, jj, kk2]; sa = sig[ii, jj, kk2]
        m = A >= 0
        if not m.any():
            return 0, None, None, None
        dist = np.maximum(np.abs(zc[kk2[m]] - plane), 0.5 * vox)
        g = sa[m] * vox * vox / dist
        if _fap is not None:                               # ② S1 v0 — 판 결합 α 미적용 (배율 1) · 판 쪽 면 가로지름 기둥 수만 기록
            g = g * _pfa.plate_coupling_factor(_fap, ii[m], jj[m], kk2[m], 'bot' if phi_p != 0.0 else 'top')
        np.add.at(diag, A[m], g)
        if phi_p != 0.0:
            np.add.at(b, A[m], g * phi_p)
        #  ★★ 2026-08-25 (CDXR2-1) — **조립이 실제로 쓴 edge 를 좌표째 돌려준다.**
        #    진단이 post-hoc 으로 재구성하면 band·bot_allowed·거리 규약이 솔버와 다시
        #    어긋난다 (Codex 경고).  ⇒ 정본은 여기이고 진단은 이것을 **소비**한다.
        return int(m.sum()), A[m], g, (ii[m], jj[m], kk2[m])
    n_pb, _Ab, _gb, _cb = _plate_couple(bot_m, k_first, z_b, 1.0)
    n_pt, _At, _gt, _ct = _plate_couple(top_m, k_last, z_plate, 0.0)
    L = sparse.coo_matrix((np.concatenate(vals + [diag]),
                           (np.concatenate(rows + [np.arange(n_dof)]),
                            np.concatenate(cols + [np.arange(n_dof)]))),
                          shape=(n_dof, n_dof)).tocsr()
    if _cjs is not None:                                   # ② — 실제 그래프 (멤버십 dof · 접합 · 축약 · 절단) · 가지치기 · 관통 · 단락
        #  ★ 10-26 묶음 B6 (RR1-01) — 주 계 정규 가중 그래프 지문 = SV 반사실을 켠 증서 런 (주 해 증서 칸) · 봉인 원천 다시 조립 (graph_only) 만
        #    (지문을 안 셀 때는 옛 호출 꼴 그대로 — 옛 접합 모듈을 끼워 대조하는 시험 (`test_carbon_junction` LEN-BIT) 이 같은 호출을 쓴다)
        _sv_on = _cjp.get('sv_counterfactual') is not None
        _cjb = (_cjs.build(_Ab, _gb, _At, _gt, _cb, _ct, graph_fp=True) if (cjunc_graph_only or (CONV_CERT and _sv_on))
                else _cjs.build(_Ab, _gb, _At, _gt, _cb, _ct))
        if cjunc_graph_only:                               # ★ 10-26 묶음 B6 — 솔브 없음: 주 계 · 반사실 끝 (SV 노브를 켠 계획만) 그래프 지문
            _cfg = _cjs.sv_graph_fps() if _sv_on else {'lower': None, 'upper': None}
            return {'graph_only': True, 'reason': _cjb.get('reason'),
                    'cjunc_graphs': {'rule': _cjm.CJUNC_GRAPH_FP_RULE, 'main': _cjs.graph_fp, 'lower': _cfg['lower'],
                                     'upper': _cfg['upper']}, 'bind': _graph_bind()}
        if _cjb.get('reason'):
            return _ret({'sigma_eff': 0.0, 'n_dof': int(_cjs.stats['n_plate_reachable_dof']),
                         'n_through_dof': int(_cjs.stats['n_through_dof']),
                         'n_floating_dropped': int(_cjs.stats['n_floating_dropped']), 'cg_info': 0, 'resid': 0.0,
                         'unconverged': False, 'reason': _cjb['reason'], 'periodic_xy': bool(periodic_xy),
                         'interface': _iface(False)})
        L, b, _Ab, _gb, _At, _gt = _cjb['L'], _cjb['b'], _cjb['Ab'], _cjb['gb'], _cjb['At'], _cjb['gt']
        _cb, _ct = _cjb['cb'], _cjb['ct']                  # 판 간선 원장 = 남은 결합만 (좌표 · g 길이 같음)
        n_dof = int(_cjb['n_dof']); n_float = int(_cjs.stats['n_floating_dropped'])
        n_through_dof = int(_cjs.stats['n_through_dof']); n_plate_reachable_dof = n_dof
    print(f'    STEP3 solve: {n_dof:,} dof, plate contacts {n_pb:,}/{n_pt:,} — CG running '
          f'({"GPU" if GPU_SOLVE else "CPU"}, 수 분 소요 가능)…', flush=True)
    LAST_CG['iters'] = None                                # Z3 — 바꿔 낀 솔버가 앞 호출의 수를 물려받지 않게
    phi, info = _solve_cg(L, b)
    _it_main = LAST_CG.get('iters')                        # Z3 — 증서 켤 때만 int (끔 = None · 결과 키에 안 싣는다)
    resid = float(np.linalg.norm(L @ phi - b) / max(np.linalg.norm(b), 1e-30))
    #  review F2: NEVER ship a silent bad σ.  ★ RGL-01 (Codex 10-05) — **비유한 잔차도 미수렴**이다.  옛 술어
    #    `bool(info) or resid > 1e-6` 는 info 0 + resid NaN 을 놓쳤다 (NaN > 1e-6 = False → 경고 없음 · unconverged False).
    unconv = bool(info) or not np.isfinite(resid) or resid > 1e-6
    if unconv:
        print(f'  ⚠ STEP3 CG not converged (info={info}, resid={resid:.1e}) — σ UNRELIABLE')
    # total current through the bottom plate: I = Σ g_b·(1 − φ)
    I = float(np.sum(_gb * (1.0 - phi[_Ab]))) if _Ab is not None else 0.0
    # σ_eff = I·L/(A·ΔV): L = plate gap (µm), A = nx·ny·vox² → σ_eff in the σ-table unit (S/cm)
    # ⚠⚠ 2026-08-16 (심층 리뷰 ①, HIGH-1): 기본 A = nx·ny·vox² 는 **격자 전체** 면적이다.
    #   origin 을 측면으로 밀면 축마다 셀이 하나 늘어 **빈 반셀 열**이 분모에 끼고 σ 가
    #   계통적으로 nx/(nx+1) 만큼 낮아진다 (균질 블록 픽스처가 36/37 을 소수 8자리로 적중;
    #   실침대 상한 −0.30 %/축, 침대 벽면 채움에 의존).
    #   ⇒ **물리 단면적을 아는 호출자는 `area_um2` 로 넘겨라.**  기본값은 종전 그대로라
    #     진행 중 캠페인의 규약은 바뀌지 않는다 (팔간 일관성 보존).
    #   ⚠ 이 편향은 같은 팔의 두 침대에 **공통 곱 인자**라 SBE/DBE **비에서는 소거**된다
    #     (보정 Δ 1.6e-6) — 절대값을 인용할 때만 문제다.
    _A = float(area_um2) if area_um2 else (nx * ny * vox * vox)
    sigma_eff = max(0.0, I * (z_plate - z_b) / _A)
    _cert = None
    if CONV_CERT:                                          # 수렴 증서 (설계 §6 · 끔 = 이 블록 없음 · 결과 키 그대로)
        import step3_conv_cert as _cc
        _rit = [None]

        def _resolve(L_, b_, x0_, rt_):                    # ⓒ 이어 풀기 — 같은 솔버 · 반복 수만 따로 받는다 (Z3)
            LAST_CG['iters'] = None
            _rr = _solve_cg(L_, b_, x0=x0_, rtol=rt_)
            _rit[0] = LAST_CG.get('iters')
            return _rr
        _cert = _cc.certify(L, b, phi, int(info) if info else 0, resid, CG_RTOL, _Ab, _gb, _At, _gt,
                            (z_plate - z_b) / _A, _resolve)
        #  ★ Z3 — 반복 수 (수렴했어도 · 숫자 탐침 칸 · 게시 조건 아님 — `run_contract.conv_cert_problem` 은 보지 않는다)
        _cert['iters'] = _it_main
        _cert['resolve_iters'] = _rit[0]
        #  ★ 10-21 (사전 리뷰 PRE-impl-07) — 증서 ↔ 런 결합 칸 (양의 해 · 행렬 그래프 영값 · 증서 못 세움 모두 · 조기 반환 증서와 같은 칸)
        _cert.update(_cc.bind_record(**_cert_bind_kw()))
        #  ★ 10-26 묶음 B6 (Codex 회차 ① RR1-01) — SV 반사실을 켠 접합 런: 주 해 증서 ↔ 그 증서가 푼 계의 정규 가중 그래프 지문 (끈 런 = 칸 없음)
        if _cjs is not None and getattr(_cjs, 'graph_fp', None) is not None:
            _cert[_cjm.CJUNC_GRAPH_KEY] = _cjs.graph_fp
        if not _cert['ok']:
            print(f"  ⚠ STEP3 수렴 증서 실패 [{_cert.get('status')}] (ⓐ {_cert['pass_a']} · ⓑ {_cert['pass_b']} 불균형 "
                  f"{_cert['imbalance']:.2e} · ⓒ {_cert['pass_c']} Δσ {_cert['dsigma_rel']:.2e} · ⓓ {_cert.get('pass_d')} "
                  f"{_cert.get('target_why') or ''}) — 미수렴 = 미게시", flush=True)
            unconv = True
    out = {'sigma_eff': float(sigma_eff), 'n_dof': n_dof, 'n_floating_dropped': n_float,
           # ★ n_dof 는 **합집합**(한쪽 플레이트에라도 닿음).  아래 둘을 병기해 이름을 정직하게.
           'n_plate_reachable_dof': n_plate_reachable_dof,      # ≡ n_dof (legacy: either_plate)
           'n_through_dof': n_through_dof,                      # 교집합 = 양 플레이트 관통
           'plate_z_um': (round(z_b, 3), round(z_plate, 3)), 'n_plate_vox': (n_pb, n_pt),
           'k_plates': (k_bot, k_top_ref), 'cg_info': int(info) if info else 0, 'resid': resid,
           # ★ 해가 자기 경계조건을 들고 다닌다 (Codex #7) — 진단이 솔버의 주기성을 추측하지
           #   않게.  `phase_current_share` 는 이 키를 읽고, 없으면 **거부**한다 (fail-closed).
           'periodic_xy': bool(periodic_xy),
           #  ★★ 2026-08-25 (CDXR2-1) — 조립이 쓴 **플레이트 edge 원장**.  진단이 σ 비례
           #    항을 하나도 빠뜨리지 않도록 정본을 넘긴다 (재구성 금지).
           #    각 항목 = (셀좌표 (i,j,k), g[S/cm·µm²/µm], φ_plate).
           'plate_edges': {'bot': (_cb, _gb, 1.0), 'top': (_ct, _gt, 0.0)},
           'vox_um': float(vox),
           #  ① 계면 저항 원장 (2026-10-02) — **쓴 것**을 적는다: 표 · pid 사용 · 실제로 걸린 면 수 · solved.
           #    r 를 안 줬으면 None (옛 결과와 구분).  `_rint` 는 진단이 같은 배율을 재현하는 맥락.
           'interface': _iface(True),
           #  ★ RINT-11 · 19 — 맥락은 **면이 실제로 걸린** 해에만 (면 0 이면 진단도 옛 경로 비트 동일) +
           #    솔브가 본 sid · pid · σ 의 지문 (진단이 다른 격자 · 바뀐 pid 로 계면 몫을 내지 않게).
           '_rint': ((_rint, pid, _grid_fp(sid), _grid_fp(pid), _grid_fp(np.asarray(sigma_of_sid, np.float64)))
                     if (_rint and sum(_faces.values()) > 0) else None),
           'unconverged': unconv}
    if _cert is not None:
        out['conv_cert'] = _cert
        out['cg_iters'] = _it_main                         # Z3 — 증서를 켠 해만 (끔 = 옛 키 그대로)
    if _cjs is not None:                                   # ② — 원장을 읽는 소산 분담 · 접합 전류 (E1 · E2 · E4′)
        _cjr = _cjs.record(phi)
        out['cjunc'] = dict(_cjm.early_record(_cjp), **_cjs.stats,
                            **{k_: v_ for k_, v_ in _cjr.items() if k_ != 'junction_current_code'})
        out['cjunc']['solved'] = True
        out['_cjunc'] = {'kind': 'cjunc_edges', 'version': _cjm.CJUNC_MODEL_VERSION, 'phi_dof': phi, 'sys': _cjs.sys,
                         'junction_inst': _cjs.junction_edge_inst, 'junction_sub': getattr(_cjs, 'junction_edge_sub', None),
                         'junction_current_code': _cjr['junction_current_code'], 'fp_sid': _grid_fp(sid)}
        if _cjp.get('sv_counterfactual') is not None:      # ★ 10-21 (Codex RCA-06 · Q4 (가)) — 선택 노브: SV 다리 끊은 판의 단자 G 비 (진단)
            if unconv:                                     #   주 해가 미수렴 · 증서 실패 = 비를 내지 않는다 (분자 G 를 믿을 수 없다)
                #  ★ 10-21 (사전 리뷰 PRE-impl-04 · Q-D) — 기록 종류 = 원장 정본 상수 (반사실 = SV 다리만 끊음 · 옛 'SV 면 전부' 와 다른 양)
                #  ★ 10-22 (PRE2-impl-01 · Q1 (다)) — 옛 칸 그대로 + 못 가른 덩어리 수 · 괄호 칸 (위 끝 = 같은 상태 · 풀이 없음) = 생산자 함수 하나
                #  ★ 10-23 (RCA2-01 · 04 · Q1 (가)) — 지위 = 증서를 켠 런이면 증서 구간 (비를 싣는 끝이 없어 증서 대조 없음) · 끈 런 = 진단
                out['cjunc']['sv_counterfactual'] = _cjm.sv_cf_unsolved_record(
                    _cjp, 'main_unconverged',
                    standing=(_cjm.SV_CF_STANDING_CERTIFIED if CONV_CERT else _cjm.SV_CF_STANDING_DIAGNOSTIC))
            else:
                #  ★ 10-21 (사전 공격 리뷰) — 반사실 솔브는 진단이다: ① 모듈 전역 출처 (`LAST_BACKEND` · `LAST_CG` — 매니페스트
                #    'backend_last_solve' 가 읽는다) 를 주 해 쪽 그대로 되돌리고 반사실 솔브의 backend 는 자기 기록에 싣는다 (노브 켬 = 주 결과
                #    출처가 노브 끔과 같다) ② 수렴 증서를 켠 런 (CONV_CERT) 은 반사실 솔브도 주 해와 **같은 증서 함수** 를 지나야 비를 낸다.
                _cf_cert = _cf_zero = None
                if CONV_CERT:
                    import step3_conv_cert as _cc
                    _cf_scale = (z_plate - z_b) / _A

                    def _cf_cert(L_, b_, phi_, info_, resid_, Ab_, gb_, At_, gt_):
                        _c = _cc.certify(L_, b_, phi_, int(info_) if info_ else 0, resid_, CG_RTOL, Ab_, gb_, At_, gt_, _cf_scale,
                                         lambda L2, b2, x02, rt2: _solve_cg(L2, b2, x0=x02, rtol=rt2))
                        #  ★ 10-23 (Codex 재검토 RCA2-04) — 끝 증서 ↔ 런 결합 칸 (주 해 증서와 같은 솔브 입력 지문 · 다른 런 증서 = 계약이 거부)
                        _c.update(_cc.bind_record(**_cert_bind_kw()))
                        return _c

                    def _cf_zero(reason_):
                        #  ★ 10-23 (Codex 재검토 RCA2-01 · Q1 (가)) — +∞ 끝 (끊은 그래프에 관통 성분 없음) 의 영값 위상 증서 (조기 반환 증서와 같은 함수 ·
                        #    같은 결합 칸) — ∞ = 위상이 증명한 0 분모만
                        return _cc.early_record({'reason': reason_, 'n_through_dof': 0, 'sigma_eff': 0.0},
                                                zero_graph=_cjm.SV_CF_ZERO_GRAPH, **_cert_bind_kw())
                _bk0, _cg0 = dict(LAST_BACKEND), dict(LAST_CG)
                try:
                    #  ★ 10-22 (Q1 (다)) — 못 가른 덩어리가 있으면 생산자가 위 끝을 한 번 더 푼다 → backend 는 끝마다 (풀이 직후 읽개 ·
                    #    옛 = 호출 뒤 한 번 · 덩어리 0 이면 같은 값)
                    #  ★ 10-23 (RCA2-01 · Q1 (가)) — 주 해 증서 (분자 G_full 의 목표량 구간) · 영값 위상 증서 함수를 넘긴다 (증서를 끈 런 = 진단 기록)
                    _svc = _cjs.sv_counterfactual(_solve_cg, I, _cjp['sv_counterfactual'], certify=_cf_cert,
                                                  backend=lambda: dict(LAST_BACKEND), main_cert=_cert, certify_zero=_cf_zero)
                finally:
                    LAST_BACKEND.clear(); LAST_BACKEND.update(_bk0)
                    LAST_CG.clear(); LAST_CG.update(_cg0)
                out['cjunc']['sv_counterfactual'] = _svc
    if return_field:
        P = np.zeros(sid.shape, np.float64); P[cond] = phi
        out['phi'] = P; out['cond'] = cond
    if _ifp is not None:
        #  ①′ 간선 원장 (E1 · E2 · E5) — 조립이 **실제로 쓴** 막 · 절단 간선 (축마다 · 아래쪽 셀 번호 · g 코드 · r_face ·
        #    부류 · 접점 · 아래쪽 셀 주인) + 지문 (sid · σ · φ · 원장).  진단은 이것을 읽는다 (face_rint 재호출 없음).
        _z = np.zeros(0, np.int64)
        _axes = tuple(_ife_used.get(a_) or {'lin': _z, 'g': np.zeros(0), 'rface': np.zeros(0), 'cut': np.zeros(0, bool),
                                            'ck': _z.copy(), 'cid': _z.copy(), 'olo': _z.copy()} for a_ in range(3))
        #  접점마다 막 순전류 (주인 a → b · a = canonical 작은 쪽) → a < h 접점의 막 전류 몫 (v3 R4)
        _C = _ifp['ledger']['contacts']
        _nC = 0 if _C is None else len(_C['a'])
        _Ic = np.zeros(_nC)
        _st = np.array([sid.shape[1] * sid.shape[2], sid.shape[2], 1], np.int64)
        for a_, ed in enumerate(_axes):
            f_ = ~ed['cut']
            if f_.any() and _nC:
                lo_ = idx.reshape(-1)[ed['lin'][f_]]; hi_ = idx.reshape(-1)[ed['lin'][f_] + _st[a_]]
                ie = ed['g'][f_] * (phi[lo_] - phi[hi_])
                sg = np.where(ed['olo'][f_] == _C['a'][ed['cid'][f_]], 1.0, -1.0)
                _Ic += np.bincount(ed['cid'][f_], weights=sg * ie, minlength=_nC)
        _real = _ifp['realized']
        _den = float(np.abs(_Ic[_real]).sum()) if _nC else 0.0
        _alh = (float(np.abs(_Ic[_real & _C['a_lt_h']]).sum()) / _den) if _den > 0 else None
        _rec = dict(_ifp['record'], solved=True)
        _cl = dict(_rec['iface_contact_ledger'])
        if 'a_lt_h' in _cl:
            _cl['a_lt_h'] = dict(_cl['a_lt_h'], film_current_share=_alh)
        _cl['n_film_rows_used'] = int(sum(int((~ed['cut']).sum()) for ed in _axes))
        _cl['n_cut_rows_used'] = int(sum(int(ed['cut'].sum()) for ed in _axes))
        _rec['iface_contact_ledger'] = _cl
        out['iface'] = _rec
        out['_iface'] = {'kind': 'am_iface_edges', 'version': IFACE_MODEL_VERSION, 'vox_um': float(vox),
                         'shape': tuple(sid.shape), 'axes': _axes, 'contact_current_code': _Ic,
                         'fp_sid': _grid_fp(sid), 'fp_sig': _grid_fp(np.asarray(sigma_of_sid, np.float64)),
                         'fp_phi': _grid_fp(out['phi']) if return_field else None, 'fp_edges': _iface_edges_fp(_axes)}
    if _fap is not None:
        #  ② S1 기록 + 간선 원장 (E1 · E5) — 조립이 **실제로 쓴** α 행 (축마다 아래 셀 번호 · α · g) + 지문 (sid · σ · φ · 원장).
        out['face_alpha'] = _pfa.solve_record(_fap, _fa_used, solved=True, n_isolated=_fa_iso)
        out['_face_alpha'] = _pfa.edges_ctx(_fap, _fa_used, sid, sigma_of_sid, out.get('phi'))
    return out


def per_particle_current(res, sid, pid, sigma_of_sid, n_am):
    """Mean |J_z| PROXY per AM particle (z-face current g·Δφ ∝ J_z·vox² — run-relative, the
    viewer percentile-normalizes; NOT vox-invariant across runs) — the slide-20 axis.

    ★ RINT-03 (Codex 10-03 · 정의 판 `PER_PARTICLE_CURRENT_DEF`) — AM 소유권 = **최종 sid ∈ {1, 2} ∧ 유효 pid
    (0 ≤ pid < n_am)**.  옛 판은 pid ≥ 0 만 봐서, 첨가제 스탬프가 sid 만 바꾸고 남긴 AM 번호를 가진 **탄소 셀**의
    전류를 AM 평균에 넣었다 (r 무관 · 합성 반례 121–127× · 순위 역전 · 08-16 심층 리뷰 §7 은 셀 수로 "무해" 라
    적었으나 전류 가중으로는 아니다).  반응 · AM 표면 patch 는 이미 AM sid 로 먼저 가려 무관."""
    _fa_refuse(res, 'per_particle_current')                # ② S1 v0 — face_alpha 해 거부 (E2 · 끈 해 = 비트 같음)
    if 'phi' not in res:                                   # early-returned solve (see res['reason'])
        return np.zeros(n_am, np.float64)
    P, cond = res['phi'], res['cond']
    sig = sigma_field(sigma_of_sid, sid)
    jz = np.zeros(sid.shape, np.float64)
    sa, sb = sig[:, :, :-1], sig[:, :, 1:]
    both = cond[:, :, :-1] & cond[:, :, 1:]
    g = np.where(both, 2.0 * sa * sb / np.maximum(sa + sb, 1e-30), 0.0)
    _ctx = rint_ctx_from(res, sid, sigma_of_sid)
    if _ctx is not None:                                   # ① 계면 면 = 조립과 같은 배율 (전류 연속)
        _sid, _tb, _pid, _vx = _ctx
        _r = np.where(both, face_rint(_sid[:, :, :-1], _sid[:, :, 1:], _tb,
                                      None if _pid is None else _pid[:, :, :-1],
                                      None if _pid is None else _pid[:, :, 1:]), 0.0)
        g = interface_face_g(g, sa, sb, _r, _vx)
    _ictx = iface_ctx_from(res, sid, sigma_of_sid)        # ①′ 막 · 절단 면 = 조립 원장의 g (E2 · σ 단위 = g/vox)
    if _ictx is not None:
        g = _iface_override_g(g, 2, _ictx, 1.0 / _ictx['vox_um'])
    dphi = P[:, :, :-1] - P[:, :, 1:]
    f = g * dphi                                           # face current ∝ σ·Δφ (per face area vox²)
    jz[:, :, :-1] += np.abs(f) * 0.5
    jz[:, :, 1:] += np.abs(f) * 0.5
    je = np.zeros(n_am, np.float64); nv = np.zeros(n_am, np.int64)
    m = (pid >= 0) & (pid < n_am) & ((sid == 1) | (sid == 2))   # RINT-03 — 최종 sid 가 AM 인 셀 · 유효 번호만
    np.add.at(je, pid[m], jz[m]); np.add.at(nv, pid[m], 1)
    return np.where(nv > 0, je / np.maximum(nv, 1), 0.0)


def phase_current_share(res, sid, sigma_of_sid, periodic_xy=None, return_total=False):
    """σ-id 별 **줄손실(J²R) 분담** — 저항-가중 반쪽 배분.

    ①′ (2026-10-07 · E4′ · RINT-16): ①′ 해 (`res['_iface']`) 면 막 면의 g 를 **조립 원장**에서 읽고 (E2) 막 몫
    r′/(R_a + R_b + r′) 를 **부류 (주인 종류 쌍) 별 버킷** `SID_IFACE_AM[…]` 에 쌓는다 → 부류 몫 s_c = −∂lnσ/∂ln r_c (부류 전체에
    공통 배율 · 포락선).  막 행이 없는 해는 옛 경로 그대로 (비트 같음).  `return_total=True` → (분담, 총 소산 [코드 단위]) —
    에너지 항등식 Σ P = I·ΔV (I7) 검사용 (기본 False = 옛 반환형 그대로).

    ⚠ 2026-08-12 (SR-01 리뷰 게이트 4): 옛 한 줄 "where the current actually flows" 는
    **오답**이다.  이 함수가 내는 것은 전류가 흐르는 곳이 아니라 **소산이 일어나는 곳**이고,
    둘은 직렬 회로에서 정반대로 갈린다 — 저저항 브릿지는 전류를 다 받으면서 소산 분담은
    작게 잡힌다 (면당 소산을 각 변의 **저항**에 비례해 나누므로 구조적으로 그렇다).
    또한 이 분담은 변분(포락선) 정리로 `w_a = ∂ln σ_eff/∂ln σ_a` 와 **같은 양**이라
    σ 스윕과 독립 증거가 아니다 (CL-11).  개명 예정(`dissipation_share`) — 호출부 정리 필요.

    ⚠ 2026-08-12 (Codex #7): 예전에는 **내부 면 3쌍만** 더했다.  주기 런에서 솔버는
    `:442-446` 에서 x/y seam 을 커플링하는데 이 진단이 그 면을 분자·분모 양쪽에서 빼면서
    **seam 을 타는 상의 분담이 통째로 사라졌다** (seam 지배 격자 실측: wrap face 소산 =
    전체의 22.9 %, 그 100 %가 VGCF).  ⇒ 주기 런이면 wrap 면쌍을 **더한다**.
    z 는 어떤 경우에도 감지 않는다 (플레이트로 막힌 축).

    `periodic_xy` 는 인자 → `res['periodic_xy']` 순으로 결정하고, **둘 다 없으면 거부**한다
    (fail-closed — 옛 res 를 조용히 비주기로 읽으면 같은 결함이 되살아난다).
    """
    _fa_refuse(res, 'phase_current_share')                 # ② S1 v0 — face_alpha 해 거부 (E2 · 끈 해 = 비트 같음)
    if 'phi' not in res:
        return ({}, 0.0) if return_total else {}
    if periodic_xy is None:
        periodic_xy = res.get('periodic_xy')
    if periodic_xy is None:
        raise ValueError('phase_current_share: 경계조건을 알 수 없다 — solve_sigma_z 의 새 '
                         'res(periodic_xy 포함)를 쓰거나 periodic_xy= 를 명시할 것.  '
                         '추측하면 주기 런에서 seam 상의 분담이 조용히 사라진다 (Codex #7)')
    P, cond = res['phi'], res['cond']
    sig = sigma_field(sigma_of_sid, sid)
    diss = np.zeros(sid.shape, np.float64)
    pairs = [(np.s_[:-1, :, :], np.s_[1:, :, :]), (np.s_[:, :-1, :], np.s_[:, 1:, :]),
             (np.s_[:, :, :-1], np.s_[:, :, 1:])]
    if periodic_xy:                       # seam 면쌍 (마지막 층 ↔ 첫 층).  z 는 넣지 않는다.
        pairs += [(np.s_[-1:, :, :], np.s_[:1, :, :]), (np.s_[:, -1:, :], np.s_[:, :1, :])]
    #  ★★★ 2026-08-25 (CDXR2-1) — **단위를 맞춘다.**  조립부의 내부 g 는
    #    `harmonic × vox` (`:549`) 인데 이 진단은 `× vox` 를 빼고 계산해 왔다.
    #    내부끼리만 정규화할 때는 공통 인자라 상쇄됐지만, **플레이트 항**
    #    (`σ·vox²/dist`) 을 더하려면 같은 단위여야 한다.
    _vox = res.get('vox_um')
    _pe = res.get('plate_edges')
    #  ★★★ 2026-08-25 (Codex 재리뷰 조건 6d) — **플레이트 원장이 없으면 거부한다.**
    #    초판은 `_use_plate = ... is not None` 로 두어, 옛 res 를 받으면 **조용히**
    #    internal-only 로 돌아갔다 = CDXR2-1 이 고친 바로 그 틀린 답(10/13)을 다시 낸다.
    #    `periodic_xy` 는 이미 fail-closed 인데 이쪽만 fail-open 이었다 (같은 함수 안에서
    #    두 규약이 갈려 있었다).  ⇒ 같은 규약으로 맞춘다.
    #  ★★★ 2026-08-25 (R3-CX-07 ③, Codex 3차) — **원장이 완비돼야 한다.**  초판은
    #    `_pe is None` 만 거부했다.  Codex 실측: `plate_edges={}` 는 옛 오답
    #    (10/13, 3/13) 를, bottom-only 는 (0.869565, 0.130435) 를 **조용히** 냈다.
    #    빈 dict 도 한쪽만 있는 dict 도 "원장이 있다" 가 아니다 — 부분 원장으로 계산한
    #    분담은 항등식을 깨고, 그것이 CDXR2-1 이 고친 바로 그 결함이다.
    #    ⇒ 두 판이 다 있고, 각각 (좌표, g, φ_plate) 3-튜플이며, 접점이 **비어 있지 않아야**
    #      한다 (σ_eff > 0 인 해는 양쪽에 접점이 있었다 — 없으면 `no_plate_contact` 다).
    if _pe is None or _vox is None:
        raise ValueError('phase_current_share: 플레이트 원장이 없다 (plate_edges/vox_um) — '
                         'solve_sigma_z 의 새 res 를 쓸 것.  없이 계산하면 소산 분담이 '
                         '내부 면만 세어 항등식 w_a = ∂ln σ_eff/∂ln σ_a 를 깬다 (CDXR2-1).  '
                         '조용히 옛 값으로 돌아가지 않는다 (fail-closed)')
    for _side in ('bot', 'top'):
        _e = _pe.get(_side)
        if not (isinstance(_e, (tuple, list)) and len(_e) == 3):
            raise ValueError(f'phase_current_share: plate_edges 에 `{_side}` 가 없거나 '
                             f'모양이 틀렸다 ({type(_e).__name__}) — **부분 원장**으로 계산한 '
                             f'분담은 항등식을 깬다 (R3-CX-07 ③).  옛 오답으로 조용히 '
                             f'돌아가지 않는다')
        _c, _g, _ = _e
        if _c is None or _g is None or len(np.asarray(_g).ravel()) == 0:
            raise ValueError(f'phase_current_share: plate_edges[{_side!r}] 의 접점이 '
                             f'비어 있다 — σ 를 낸 해라면 양쪽에 접점이 있었다 '
                             f'(없었다면 solve 가 no_plate_contact 였다)')
    _use_plate = True
    _u = float(_vox)
    _ctx = rint_ctx_from(res, sid, sigma_of_sid)           # ① 계면 항을 쓴 해인가 (None = 옛 경로 그대로)
    _ictx = iface_ctx_from(res, sid, sigma_of_sid)         # ①′ 간선 원장 (None 또는 행 없음 = 옛 경로 그대로)
    diss_int = 0.0                                         # 계면 몫 (상이 아니라 따로 센다)
    diss_cls = {}                                          # ①′ 부류별 막 몫 (E4′ · RINT-16)
    _st = (sid.shape[1] * sid.shape[2], sid.shape[2], 1)
    for _axi, (sl_a, sl_b) in enumerate(pairs):
        both = cond[sl_a] & cond[sl_b]
        sa, sb = sig[sl_a], sig[sl_b]
        g = np.where(both, 2.0 * sa * sb / np.maximum(sa + sb, 1e-30), 0.0) * _u
        _rows = None
        if _ictx is not None and _axi < 3 and len(_ictx['axes'][_axi]['lin']):
            _rows = _ictx['axes'][_axi]
            g = _iface_override_g(g, _axi, _ictx, 1.0)     # E2 — 막 · 절단 면의 g = 조립 원장 (조립 단위 ×vox)
        if _ctx is None:
            d = g * (P[sl_a] - P[sl_b]) ** 2               # per-face dissipation; split ∝ each side's
            if _rows is not None:
                #  ①′ 막 면 — 세 몫 (반셀 a · 반셀 b · 막 r′ → 부류 버킷) · 절단 면은 g 0 이라 d 0
                _f = ~_rows['cut']
                _ijk = tuple(x[_f] for x in np.unravel_index(_rows['lin'], sid.shape))
                _df = d[_ijk].copy()
                d = d.copy(); d[_ijk] = 0.0
                _wa, _wb, _wi = iface_face_split(sa[_ijk], sb[_ijk], _rows['rface'][_f], _u)
                np.add.at(diss, _ijk, _wa * _df)
                _up = np.unravel_index(_rows['lin'][_f] + _st[_axi], sid.shape)
                np.add.at(diss, _up, _wb * _df)
                for _ck in np.unique(_rows['ck'][_f]):
                    _mk = _rows['ck'][_f] == _ck
                    diss_cls[int(_ck)] = diss_cls.get(int(_ck), 0.0) + float((_wi[_mk] * _df[_mk]).sum())
            wa = np.where(both, sb / np.maximum(sa + sb, 1e-30), 0.0)   # RESISTANCE (review F4 — the old
            diss[sl_a] += wa * d; diss[sl_b] += (1.0 - wa) * d          # half-half gave carbon 50% at a
            #   1e4-contrast face where it truly dissipates ~0.01%)
            continue
        #  ① 계면 (2026-10-02) — 면 저항 R_a + R_b + r′ 에 비례해 **세 몫**으로.  r′ 몫은 어느 상도
        #    아니므로 `SID_INTERFACE` 버킷에 쌓는다.  r = 0 인 면에서는 위 두 몫과 정확히 같은 식
        #    (sb/(sa+sb) = R_a/(R_a+R_b)).
        _sid, _tb, _pid, _vx = _ctx
        _r = np.where(both, face_rint(_sid[sl_a], _sid[sl_b], _tb,
                                      None if _pid is None else _pid[sl_a],
                                      None if _pid is None else _pid[sl_b]), 0.0)
        g = interface_face_g(g, sa, sb, _r, _vx)
        d = g * (P[sl_a] - P[sl_b]) ** 2
        _ra = np.where(both, _u / (2.0 * np.maximum(sa, 1e-30)), 0.0)
        _rb = np.where(both, _u / (2.0 * np.maximum(sb, 1e-30)), 0.0)
        _ri = _r * RINT_OHM_CM2_TO_UM_CM_PER_S
        _rt = np.maximum(_ra + _rb + _ri, 1e-30)
        diss[sl_a] += (_ra / _rt) * d; diss[sl_b] += (_rb / _rt) * d
        diss_int += float(((_ri / _rt) * d).sum())
    #  ★★★ **플레이트 소산을 더한다.**  옛 판은 내부(+seam) 면만 더해 자기 docstring 의
    #    항등식 `w_a = ∂ln σ_eff/∂ln σ_a` 를 **만족하지 않았다** — 솔버의 플레이트 커플링
    #    `g = σ·vox²/dist` 도 σ 에 비례하는데 합에서 빠져 있었기 때문이다.
    #    ⚠ 이것은 **같은 결함의 2회차**다 (Codex #7 이 이미 주기 seam 누락을 잡았다).
    #    ⚠ 플레이트는 상(相)이 아니므로 반쪽 배분 없이 **접촉 셀의 상에 전액** 귀속한다.
    #    ⚠ `sum(shares)==1` 로는 이 결함을 못 잡는다 — 옛 판도 1 이었다.  판별은
    #      **centered-log 유한차분**이고 그것이 `_selftest` 의 `plate-share-identity` 다.
    if _use_plate:
        for _side in ('bot', 'top'):
            _c, _g, _phi_p = _pe.get(_side, (None, None, 0.0))
            if _c is None or _g is None or not len(_g):
                continue
            _i, _j, _k = _c
            np.add.at(diss, (_i, _j, _k), np.asarray(_g) * (P[_i, _j, _k] - _phi_p) ** 2)
    tot = diss.sum() + diss_int + sum(diss_cls.values())
    out = {}
    for s in np.unique(sid[sid > 0]):
        out[int(s)] = float(diss[sid == s].sum() / max(tot, 1e-30))
    if _ctx is not None:                                   # ① 계면 몫 — r 없는 해에는 키 자체가 없다
        out[SID_INTERFACE] = float(diss_int / max(tot, 1e-30))
    for _ck in sorted(diss_cls):                           # ①′ 부류별 막 몫 — 막 행이 없는 해에는 키 자체가 없다
        out[_ck] = float(diss_cls[_ck] / max(tot, 1e-30))
    return (out, float(tot)) if return_total else out


# ── STEP3 열전도 (σ_thermal) — 범용 Laplace 솔버(solve_sigma_z) 재사용, 多상 k 맵 ──────────────
# k 값 (W/cm·K; ×100 = W/m·K).  ★SE=문헌앵커(Ketter 2025 = LPSCl/SE 논문); AM=generic NCM 문헌-order
# (전용 인용 없음; network_conductivity.py의 uncited NCM 기본과 同값 — Ketter 아님[Ketter는 SE]),
# carbon/SDCP/PTFE/pore = ASSUMED order-of-mag (라벨 · 소체적분율이라 k_eff 영향 작음 · 스윕용).
K_AM_THERMAL = 4.0e-2    # NCM, ≈4 W/m·K  [generic NCM 문헌-order; 전용 인용 없음, NOT Ketter(=SE)]
K_SE_THERMAL = 0.7e-2    # LPSCl, ≈0.7 W/m·K  [lit: Ketter 2025 (LPSCl thermal)]
K_PTFE_THERMAL = 2.5e-3  # PTFE, ≈0.25 W/m·K  [polymer generic; 전용 인용 없음]
K_PORE_THERMAL = 0.0     # 압밀 ASSB 공극(Ar/진공, ~7% 고립) → 무시 [ASSUMED; 가스면 ~2.6e-4]


def thermal_k_table(k_am=K_AM_THERMAL, k_se=K_SE_THERMAL, k_carbon=None, k_sdcp=None,
                    k_ptfe=K_PTFE_THERMAL, k_pore=K_PORE_THERMAL):
    """sid-indexed 열전도 k 배열 (_sig3 電子표와 동일 레이아웃: 0=pore,1=AM_S,2=AM_P,3=VGCF,
    4=SuperP,5=SDCP,6=SE,7=PTFE,8=SWCNT).  ★열은 多상: σ_e(AM만)/σ_ion(SE만)과 달리 全상이 열
    통과 → SE(6)·PTFE(7)는 0 아님(pore는 기본 0=진공 가정).  carbon(VGCF/SuperP/SWCNT) 기본 =
    k_am(도체≥AM 보수적 ASSUMED, --k-carbon 상향 스윕 권장); SDCP 기본 = k_se.  반환 (k_array, prov)."""
    kc = k_am if k_carbon is None else float(k_carbon)
    ks = k_se if k_sdcp is None else float(k_sdcp)
    prov = {'AM(NCM)': f'{k_am*100:.1f} W/mK [generic NCM 문헌-order; 전용 인용 없음 — NOT Ketter(=LPSCl/SE); '
                       'network_conductivity.py uncited NCM 기본과 同값]',
            'SE(LPSCl)': f'{k_se*100:.2f} W/mK [lit Ketter2025 (LPSCl thermal)]',
            'carbon(VGCF/SuperP/SWCNT)': f'{kc * 100:.1f} W/mK [ASSUMED ~AM 하한; 소분율·--k-carbon 상향 스윕]',
            'SDCP': f'{ks * 100:.2f} W/mK [ASSUMED ~SE; ⚠전자적으론 최강도체 → k_carbon가 더 맞을 수(스윕)]',
            'PTFE': f'{k_ptfe * 100:.2f} W/mK [polymer generic; 전용 인용 없음]',
            'pore': f'{k_pore * 100:.3f} W/mK [ASSUMED 압밀ASSB≈0(진공/고립)]',
            'caveats': 'k_eff = 문헌/ASSUMED k 입력의 복셀-solve 전파값 — 열전도 실험 앵커 없음(Kapitza 계면 '
                       '열저항 무시 → 상한); network_conductivity thermal과 같은 k 앵커 공유 → 표현(복셀-field '
                       'vs 입자-graph)-일치만이지 입력·물리 검증 아님, 스케일도 다름(W/mK vs mScm-eq), 독립 아님'}
    #  sid 9 (SE_blk, G2) = 재질이 SE — 열은 k_se 그대로 (차단은 전하 계면 규약이지 열이 아니다)
    return np.array([k_pore, k_am, k_am, kc, kc, ks, k_se, k_ptfe, kc, k_se], float), prov


def solve_thermal(sid, vox, z_top_um, z_bot_um=0.0, k_table=None, field_sids=None, field_max=90000,
                  periodic_xy=False):
    """복셀 through-plane 열전도 k_eff + 상별 ΔT/열저항(병목) 몫.  solve_sigma_z 재사용(∇·(k∇T)=0, 同 격자).
    ★多상이라 압밀 베드선 全상 연결 → 보통 항상 퍼콜(유한).  반환: k_eff_W_mK(=k_eff[W/cm·K]×100, ★Kapitza
    무시 상한), temp_drop_share(상별 through-plane 온도강하/열저항 몫 — 높을수록 열 병목; ★열류 아님 —
    직렬 flux는 상별 동일), n_dof, cg_resid, reason/unconverged.
    field_sids 주면 out['_field_pts']/['_field_j'] = 열류 |k∇T| 점군(電子/이온 필드와 동일 문법, 多상=全상
    solid; payload가 p99.8 정규화·직렬화 — '_' prefix = JSON 前 임시)."""
    if k_table is None:
        k_table, _ = thermal_k_table()
    res = solve_sigma_z(sid, k_table, vox, return_field=True, z_top_um=z_top_um, z_bot_um=z_bot_um,
                        periodic_xy=periodic_xy)
    #  ★★★ 2026-08-25 (R4-CX-02, Codex 4차) — **`cg_info` 도 싣는다.**  소비자의 수렴
    #    계약은 `cg_info == 0 ∧ unconverged is False ∧ 0 ≤ resid ≤ 1e-6` 의 conjunction 인데,
    #    열 블록이 `cg_info` 를 안 실어서 그 계약을 **적용할 수 없었다** (계약이 blind).
    #    ⇒ 전자축과 같은 세 필드를 전부 남긴다.  솔버는 이미 알고 있다.
    out = {'k_eff_W_mK': None, 'reason': res.get('reason'), 'n_dof': int(res.get('n_dof', 0)),
           'cg_info': int(res.get('cg_info', 0)),
           'cg_resid': float(f"{res.get('resid', 0.0):.2g}"), 'unconverged': bool(res.get('unconverged'))}
    if not res.get('reason') and res.get('n_dof'):
        out['k_eff_W_mK'] = float(f"{res['sigma_eff'] * 100.0:.4g}")   # W/cm·K → W/m·K
        # phase_current_share = ∝ k(∇T)² 소산 functional의 상별 분담 = through-plane ΔT/열저항 몫(병목).
        # ★열류(∝ k∇T) 아님 — 정상 전도 ∇·(k∇T)=0 은 소산 0, 직렬 flux 상별 동일.
        share = phase_current_share(res, sid, k_table)
        out['temp_drop_share'] = {SID_NAME[k]: round(v, 4) for k, v in share.items()}
        # ★ T(z) 프로파일 원자료 — 전자/이온이 phi_profile 을 갖는 것과 같은 자격을 열전도에도 준다.
        #   (2026-08-04: 뷰어가 열류·Joule 모드에서 **전자 φ(z)** 를 그리고 있었다 — 열전도는 자기
        #    solve 의 정규화 온도 T(z)@ΔT=1 이 있어야 한다.)  '_' prefix = JSON 前 pop 대상.
        out['_res'] = res
        if field_sids is not None:                             # 열류 |k∇T| 점군 (多상 = 全상 solid conduct)
            fp, fj, fst = field_point_cloud(res, sid, k_table, vox, tuple(field_sids),
                                            max_points=field_max)
            if fp is not None:
                out['_field_pts'] = fp
                out['_field_j'] = fj
                out['_field_stats'] = fst                      # SELF-45: 정규화는 **전수** p99.8 로
    return out


def dia_stats_by_phase(dia_rel, phase, sel_phases=None):
    """상(phase)별 상대 Ø 통계 — **어느 상이 스프레드를 갖는지**를 재서 판정한다.

    ★ 왜 (2026-08-12 자기정정, CL-16): 나는 상대 Ø 0.23~8.48 을 **혼합 모집단**에서 읽고
      "스칼라 재척도 불가" 라고 결론냈다.  틀렸다 — `mpm3d_compaction:2225` 가
      `dia = √weight` 이고 VGCF 는 `vol_conserve=False` 라 **weight 가 균일(=1)** 이다
      (`additives.py:626` "a manufactured fibre has constant Ø").  스프레드는 **PTFE**
      (constant-volume drawing, d ∝ √(V/L)) 것이고 PTFE 는 전자망에서 **절연체**다.
      ⇒ σ_e 에 대해서는 VGCF 단일 Ø 스칼라가 **정확**하다.
      교훈: 분포를 볼 때 **어느 모집단인지 먼저 가른다**.
    """
    d = np.asarray(dia_rel, np.float64)
    ph = np.asarray(phase)
    if d.shape != ph.shape:
        raise ValueError(f'dia_stats_by_phase: dia {d.shape} != phase {ph.shape}')
    out = {}
    for p in (sorted(set(int(x) for x in np.unique(ph))) if sel_phases is None
              else list(sel_phases)):
        m = (ph == p) & np.isfinite(d) & (d > 0)
        if not m.any():
            out[int(p)] = None
            continue
        v = d[m]
        out[int(p)] = {'n': int(m.sum()), 'min': float(f'{v.min():.4g}'),
                       'med': float(f'{np.median(v):.4g}'), 'max': float(f'{v.max():.4g}'),
                       'cv': float(f'{(v.std() / v.mean() if v.mean() else 0.0):.4g}'),
                       'uniform': bool(v.max() - v.min() < 1e-6 * max(1.0, v.max()))}
    return out


def sigma_field(sigma_of_sid, sid):
    """σ 표(1-D, sid 색인) **또는** 복셀별 σ 배열(sid 와 같은 shape) → 복셀별 σ.

    ★ 2026-08-12 (게이트 ⑥): 직경-보존 재척도는 섬유마다 다른 σ 를 요구한다 —
      상대 Ø 가 0.23~8.48 로 퍼져 있어 **스칼라 하나로는 표현할 수 없다**
      (조화평균 2.96 vs 산술평균 125 S/cm = 42배 차 — 우리가 좁히려는 브래킷보다 크다).
      그래서 σ 를 표가 아니라 **장(field)** 으로도 받을 수 있게 한다.
      1-D 표를 주는 기존 호출은 **바이트 동일**하게 동작한다.
    """
    a = np.asarray(sigma_of_sid)
    if a.ndim == 1:
        return a[sid]
    if a.shape != np.shape(sid):
        raise ValueError(f'sigma_field: 복셀별 σ 배열의 shape {a.shape} 가 sid {np.shape(sid)} 와 '
                         f'다르다 — 조용히 브로드캐스트하면 다른 격자의 σ 를 쓰게 된다')
    return a


def diameter_preserving_sigma(sigma_bulk, dia_rel, d_ref_um, vox_um, mode='harmonic'):
    """게이트 ⑥ — **직경-보존 σ 재척도**.  (sigma_eff, prov) 반환.

    왜: 선분 래스터는 섬유를 **1 복셀 굵기 관**으로 굽는다.  실제 VGCF 는 Ø 0.15 µm 인데
    복셀은 0.4 µm 라 단면이 (0.4/0.15)² ≈ 7.1 배 부풀고, 그만큼 σ_e 가 과대평가된다
    (정본 §7: 선분은 접촉 ×2.67 · 점은 조각남 ÷2.9 라 1 wt% 에서 **거의 상쇄** — 즉
    직경 보정 없이 선분만 켜면 과소평가를 **더 큰 과대평가**로 바꾼다).

    보존량은 **단위길이당 컨덕턴스** G/L = σ·A.  래스터 관의 단면이 A_vox = vox² 이므로
        σ_eff = σ_bulk · A_real / A_vox = σ_bulk · π d² / (4 vox²)
    여기서 d = d_ref · dia_rel (섬유마다 다르다 — `--save-fibre-dia` 가 상대 Ø 를 준다).

    `mode`:
      'harmonic'   섬유를 따라 저항이 **직렬**로 더해지므로 A 의 조화평균이 옳다 (기본).
      'arithmetic' 섬유들이 **병렬**로 놓인 극한.  둘은 상·하한 성격이라 **병기**할 것.
      'single'     dia_rel 없이 공칭 Ø 하나만 (dia_rel=None 일 때 자동).

    ⚠ 이것은 **단면** 보정만이다.  계단식 경로의 **여분 길이** k (축정렬 1 ~ 대각 √3)는
    보정하지 않는다.
    ⚠⚠ **하한/상한 어느 쪽도 주장하지 말 것** (2026-08-13, CL-20 retired → CL-24).
    한때 여기에 "R_ras = k·R_true 이므로 이 σ 로 푼 σ_e 는 하한" 이라고 적었다 (그 전엔
    상한이라고 적었다).  **둘 다 철회한다** — 두 가지 이유로:
      ① k 를 재는 `sr01_staircase_factor.py` 가 `np.unique` 로 경로 순서·재방문을 버리고
         고유 셀 수만 세므로 **순서 있는 저항 경로 길이가 아니다** (Codex CDX-02).
         재실행값도 격자마다 다르다: 1.4855@0.4 · 1.4917@0.3 · 1.4461@0.25.
      ② 격자 실측(CL-24)이 보여주듯 계단 길이(σ_e↓)와 **가짜 상호연결**(σ_e↑)이 반대
         방향으로 경쟁하고, 후자가 관측 구간에서 더 크다.  ⇒ 부호가 정해지지 않는다.
    라벨: prov['unmodelled'] 은 이제 **미보정 축의 목록**이지 방향 주장이 아니다.
    """
    A_vox = float(vox_um) ** 2
    if dia_rel is None:
        d = np.array([float(d_ref_um)])
        mode = 'single'
    else:
        r = np.asarray(dia_rel, np.float64)
        r = r[np.isfinite(r) & (r > 0)]
        if not r.size:
            raise ValueError('diameter_preserving_sigma: 유효한 dia_rel 이 없다 (전부 0/NaN)')
        d = float(d_ref_um) * r
    A = np.pi * d * d / 4.0
    if mode == 'harmonic':
        A_eff = float(len(A) / np.sum(1.0 / A))
    else:
        A_eff = float(np.mean(A))
    f = A_eff / A_vox
    prov = {'mode': mode, 'd_ref_um': float(d_ref_um), 'vox_um': float(vox_um),
            'n_points': int(len(A)), 'A_real_eff_um2': float(f'{A_eff:.6g}'),
            'A_vox_um2': A_vox, 'factor': float(f'{f:.6g}'),
            'sigma_bulk': float(sigma_bulk), 'sigma_eff': float(f'{sigma_bulk * f:.6g}'),
            'unmodelled': ('미보정 축 (방향 주장 아님): ① 계단식 경로의 여분 길이 k '
                           '(축정렬 1 ~ 대각 √3) ② 격자가 만드는 섬유 간 가짜 상호연결 '
                           '— ①은 σ_e 를 낮추고 ②는 높여 **경쟁**하므로 이 σ 로 푼 σ_e 에 '
                           '하한/상한 어느 쪽도 붙일 수 없다'),
            'bound': None,
            'bound_reason': ('grid_nonconverged; no_valid_bound — CL-17(천장)·CL-20(하한) '
                             '모두 retired.  격자 스윕은 CL-24 참조'),
            'caveat': '단면 보존만. 접촉 저항·협착은 별개 축.'}
    return float(sigma_bulk * f), prov


#: ★ 2026-10-20 (Rint ② Z1 · 설계 v1 §1-2 #1 · #2) — VGCF bulk σ → 직경 보존 복셀 σ 의 **기준 지름 · 식 이름**.
#   러너 (`SIGMA_FIBRE_BULK` · 옛 기본 bulk 100) 와 payload (`--sigma-vgcf-bulk` 다시 계산 대조) 가 **같은 함수**
#   (`vgcf_sigma_from_bulk`) 를 쓰고, 매니페스트 · 러너 영수증은 이 이름을 기록한다 (기록만 봐도 식이 정해진다).
#   기준 지름 = `additives.VGCF_D` (침대 시더의 VGCF Ø) — 러너 옛 판의 `D_REF = 0.15` 와 같은 값 (`test_ca_ext_z1` Z1a0 가 대조).
VGCF_DIA_REF_UM = 0.15
VGCF_SIGMA_RULE = f'diameter_preserving:harmonic:phase=2:d_ref_um={VGCF_DIA_REF_UM:g}:round=6g'


def vgcf_sigma_from_bulk(sigma_bulk, dia_rel, phase, vox_um, d_ref_um=VGCF_DIA_REF_UM):
    """VGCF bulk σ [S/cm] → 직경 보존 복셀 σ_VGCF **문자열** (유효숫자 6 자리 = 러너가 payload `--sigma-vgcf` 에 넘기는 표기).

    σ_vox = σ_bulk · (π d_f²/4) / vox²  (d_f = d_ref · 상대 Ø · `diameter_preserving_sigma` harmonic · VGCF 상 2 의 점만).
    ⚠ VGCF 상대 Ø 가 균일해야 한다 (스칼라 재척도가 정확한 조건 — `dia_stats_by_phase` · CL-16) — 비균일 · VGCF 없음 ·
      길이 다름 = ValueError (러너 옛 판의 ABORT 와 같은 조건 · 조용한 강제 없음).
    손계산 (`test_ca_ext_z1` Z1a): vox 0.15 · 1e4 → 7853.98 · vox 0.4 · 100 → 11.0447 · vox 0.125 · 1e4 → 11309.7."""
    d = np.asarray(dia_rel, np.float64)
    ph = np.asarray(phase)
    st = dia_stats_by_phase(d, ph)
    v = st.get(2)
    if v is None or not v['uniform']:
        raise ValueError(f'VGCF Ø 비균일/부재: {v}')
    se, _pv = diameter_preserving_sigma(float(sigma_bulk), d[ph == 2], d_ref_um, vox_um)
    s = f'{se:.6g}'
    #  ⚠ 결과가 유한 > 0 이 아니면 (bulk nan · inf · 0 · 넘침 · 언더플로) 문자열 "inf" · "nan" · "0" 을 payload 에 넘기지 않는다 (조용한 절연 · 발산 금지)
    if not (np.isfinite(se) and se > 0.0 and np.isfinite(float(s)) and float(s) > 0.0):
        raise ValueError(f'VGCF 복셀 σ = {s} (bulk {sigma_bulk!r} · vox {vox_um!r}) — 유한 > 0 이 아니다 (넘침 · 언더플로 · nan · 0)')
    return s


def carbon_se_contact_area(sid, vox, periodic_xy=False):
    """탄소(VGCF 3·SuperP 4·SWCNT 8) ↔ SE(6) 복셀-면 접촉 면적 (µm²).
    kim2024 Fig3b: NCM–SE–carbon 3상 계면이 sulfide SE 전기화학 분해를 촉매 → 이 면적이
    STEP5 VGCF-촉매 화학열화(carbon_se_area)의 구조 입력.  phase_current_share 면-순회와 동일 규약.

    ⚠ 2026-08-12 (Codex #7): 내부 면만 세면 주기 런에서 **seam 을 가로지르는 3상 계면이
    누락**된다 (섬유는 길어 seam 을 자주 넘는다).  `periodic_xy` 면 wrap 면쌍을 더한다.
    z 는 어떤 경우에도 감지 않는다 — 플레이트로 막힌 축이다."""
    carb = np.isin(sid, (3, 4, 8)); se = (sid == 6)
    faces = 0
    pairs = [(np.s_[:-1, :, :], np.s_[1:, :, :]),
             (np.s_[:, :-1, :], np.s_[:, 1:, :]),
             (np.s_[:, :, :-1], np.s_[:, :, 1:])]
    if periodic_xy:                       # 길이 1인 축은 감지 않는다 (셀이 자기 이웃이 된다)
        if sid.shape[0] > 1:
            pairs.append((np.s_[-1:, :, :], np.s_[:1, :, :]))
        if sid.shape[1] > 1:
            pairs.append((np.s_[:, -1:, :], np.s_[:, :1, :]))
    for a, b in pairs:
        faces += int((carb[a] & se[b]).sum()) + int((se[a] & carb[b]).sum())
    return float(faces) * vox * vox


def _voxel_jmag(P, cond, sig, periodic_xy=False, rint_ctx=None, iface_ctx=None):
    """Cell-centred |J| proxy (∝ σ·Δφ, run-relative) — per_particle_current 와 동일 규약.
    각 축의 양면 전류 |g·Δφ|(g=조화평균 컨덕턴스)를 셀에 반씩 배분 → |J|=√(ΣJ축²).
    field_point_cloud·joule_hotspot 공유(단일 소스, 중복 제거).

    ⚠ 2026-08-12 (Codex #7): 주기 런에서 seam 면의 전류가 빠지면 **경계 셀의 |J| 가 과소**로
    나오고, 그것이 joule_hotspot 의 hot-spot 선정을 경계에서 체계적으로 놓치게 만든다.
    `periodic_xy` 면 x/y wrap 면을 포함한다.  z 는 감지 않는다.
    ① `rint_ctx` (= `rint_ctx_from(res, sid)`) 가 있으면 계면 면에 조립과 같은 배율을 건다 —
    없으면 옛 경로 그대로.  ①′ `iface_ctx` (= `iface_ctx_from(res, sid)`) 가 있으면 막 · 절단 면의 g 를 조립 원장에서 읽는다 (E2)."""
    jmag = np.zeros(sig.shape, np.float64)
    for axis in (0, 1, 2):
        sa_sl = [slice(None)] * 3; sb_sl = [slice(None)] * 3
        sa_sl[axis] = slice(0, -1); sb_sl[axis] = slice(1, None)
        sa_sl, sb_sl = tuple(sa_sl), tuple(sb_sl)
        comp = np.zeros(sig.shape, np.float64)

        def _accum(a, b, _comp=comp, _ax=None):
            both = cond[a] & cond[b]
            sa, sb = sig[a], sig[b]
            g = np.where(both, 2.0 * sa * sb / np.maximum(sa + sb, 1e-30), 0.0)
            if rint_ctx is not None:                        # ① 계면 면 = 조립과 같은 배율 (전류 연속)
                _sid, _tb, _pid, _vx = rint_ctx
                _r = np.where(both, face_rint(_sid[a], _sid[b], _tb,
                                              None if _pid is None else _pid[a],
                                              None if _pid is None else _pid[b]), 0.0)
                g = interface_face_g(g, sa, sb, _r, _vx)
            if iface_ctx is not None and _ax is not None:   # ①′ 막 · 절단 면 = 조립 원장 g (σ 단위 = g/vox)
                g = _iface_override_g(g, _ax, iface_ctx, 1.0 / iface_ctx['vox_um'])
            f = np.abs(g * (P[a] - P[b]))                   # face current ∝ σ·Δφ (per face area)
            _comp[a] += f * 0.5
            _comp[b] += f * 0.5
        _accum(sa_sl, sb_sl, _ax=axis)
        if periodic_xy and axis in (0, 1):                  # seam 면 (마지막 층 ↔ 첫 층)
            wa = [slice(None)] * 3; wb = [slice(None)] * 3
            wa[axis] = slice(-1, None); wb[axis] = slice(0, 1)
            _accum(tuple(wa), tuple(wb))
        jmag += comp * comp
    return np.sqrt(jmag)


def joule_hotspot(res, sid, sigma_of_sid, vox, sel_sids, box_lo=(0.0, 0.0, 0.0),
                  max_points=40000, hot_budget_frac=0.35, seed=1):
    """#29 — 복셀 Joule 발열밀도 q ∝ |J|²/σ (run-relative) 점군 = '어디서 발열이 몰리는지' hot-spot MAP.
    전류가 구속(소수 percolating neck)에 몰리고 σ 낮은 곳에서 q 최대 → 발열 hot-spot.  field_point_cloud
    와 동일 |J|(_voxel_jmag) 재사용 = 순수 readout(재솔브 없음, σ 불변).  전자망(sel_sids=AM+carbon)에 적용.
    ★한계 (정직): 절대 ΔT(K) 온도상승은 Poisson 열확산(∇·(k∇ΔT)=−q) + 실전류 스케일 + LPSCl 분해
    Arrhenius Eₐ 앵커가 필요(미보유) → v2.  이 함수는 발열 '생성' 분포(hot-spot 위치)까지만 정직 산출.
    Returns dict(pts_um [N,3], q [N], hot_frac_50, conc_ratio, n) 또는 None.  viewer가 percentile 정규화."""
    _fa_refuse(res, 'joule_hotspot')                       # ② S1 v0 — face_alpha 해 거부 (E2 · 끈 해 = 비트 같음)
    if 'phi' not in res:
        return None
    P, cond = res['phi'], res['cond']
    sig = sigma_field(sigma_of_sid, sid)
    jmag = _voxel_jmag(P, cond, sig, periodic_xy=bool(res.get('periodic_xy')),
                       rint_ctx=rint_ctx_from(res, sid, sigma_of_sid),   # ① 계면 배율 = 조립과 동일 · RINT-19 지문
                       iface_ctx=iface_ctx_from(res, sid, sigma_of_sid))   # ①′ 막 · 절단 = 조립 원장 (E2 · E5)
    q = np.where(cond, jmag * jmag / np.maximum(sig, 1e-30), 0.0)     # 발열밀도 (run-relative, W/cm³ 스케일 전)
    sel = np.isin(sid, np.asarray(list(sel_sids), np.int64)) & cond & (q > 0)
    ii, jj, kk = np.where(sel)
    if not len(ii):
        return None
    vals = q[ii, jj, kk]
    # hot-spot 집중도: q 총합의 50%를 담는 상위-복셀 분율 (작을수록 집중=hot-spot 뚜렷) + 최대/평균 비
    srt = np.sort(vals)[::-1]; cum = np.cumsum(srt); tot = float(cum[-1])
    hot_frac_50 = float((np.searchsorted(cum, 0.5 * tot) + 1) / len(vals)) if tot > 0 else 0.0
    conc_ratio = float(vals.max() / max(vals.mean(), 1e-30))
    _q_p998, _q_mean, _q_n = float(np.percentile(vals, 99.8)), float(vals.mean()), int(vals.size)
    if len(ii) > max_points:                                          # field_point_cloud 규약: 상위 hot 유지 + 균일 배경
        rng = np.random.default_rng(seed)
        order = np.argsort(vals)[::-1]
        n_hot = int(max_points * hot_budget_frac)
        pick = np.concatenate([order[:n_hot], rng.choice(order[n_hot:], size=max_points - n_hot, replace=False)])
        ii, jj, kk, vals = ii[pick], jj[pick], kk[pick], vals[pick]
    pts = np.stack([(ii + 0.5) * vox + box_lo[0], (jj + 0.5) * vox + box_lo[1],
                    (kk + 0.5) * vox + box_lo[2]], axis=1).astype(np.float32)
    return {'pts': pts, 'q': vals.astype(np.float32), 'hot_frac_50': hot_frac_50,
            'conc_ratio': conc_ratio, 'n': int(len(vals)),
            #  ★ SELF-45 잔여 (2026-09-22) — `hot_frac_50`·`conc_ratio` 는 처음부터 추출
            #    **전** 전수로 쟀는데 `q` 는 추출된 것이라, 소비자가 `q` 에 백분위를 걸면
            #    필드 정규화가 다시 예산의 함수가 된다 (전자·이온·열류는 고쳤는데 여기만
            #    남아 있었다).  ⇒ 전수 p99.8·평균을 같이 돌려준다.
            'q_p99_8': float(_q_p998), 'q_mean': float(_q_mean), 'n_total': int(_q_n),
            #  ★ 2026-10-03 (Codex r_int 1단계 RINT-04 · G1-3) — **범위를 결과가 말한다.**  이 지도는 상 셀 안의
            #    bulk J²/σ 만이다.  계면 I²R (r_int 를 켜면 소산의 대부분일 수 있다 — 두 슬래브 탐침 95 %) 과 판 결합
            #    간선은 지도 밖이다 ⇒ 총 발열 hotspot 으로 읽지 않는다.  지도 밖 계면 몫은 소산 분담이 따로 센다.
            'scope': 'bulk_only', 'included': ['bulk_cell_J2_over_sigma'],
            'excluded': ['interface_I2R', 'plate_coupling']}


def field_point_cloud(res, sid, sigma_of_sid, vox, sel_sids, box_lo=(0.0, 0.0, 0.0),
                      max_points=40000, hot_budget_frac=0.35, seed=1):
    """Per-voxel current-density MAGNITUDE sampled at the selected conducting phase(s), as a
    subsampled point cloud for a paper-style field figure (Fig-2/Fig-4 grammar).

    Reuses the SAME validated (phi, cond) the solve returned (return_field=True) — this is a pure
    READOUT, it does not re-solve or change σ.  The cell-centred |J| proxy mirrors
    per_particle_current EXACTLY: for each of the 3 axes the two bounding face currents |g·Δφ| are
    half-split onto the cell (g = 2σaσb/(σa+σb) = the SAME harmonic-mean conductance the matrix
    used — so a high-σ phase such as SDCP actually lights up), then |J| = √(Jx²+Jy²+Jz²).
    Run-relative (∝ σ·Δφ; the viewer percentile-normalises); NOT vox-invariant across runs.

    sel_sids : iterable of σ-ids to KEEP (electronic field → AM+carbon {1,2,3,4,5};
               ionic field → SE+SDCP {5,6}).  Only voxels that are BOTH sel AND conductive (in the
               plate-connected component `cond`) are emitted — floating islands already dropped.
    Returns (pts_um [N,3] float32, jmag [N] float32, stats dict) in the payload µm frame (voxel
    centres + box_lo), or (None, None, None) if the solve early-returned / nothing selected.

    Subsample keeps ALL of the hottest `hot_budget_frac` of the budget (so the conduction
    backbone survives at low point counts) + a uniform-random background for honest density.

    ★★★ 2026-09-22 (`SELF-45`, 리뷰어 A-2 가 촉발) — **점군에서 통계를 내지 말 것.**
      그래서 이 함수가 `stats` 를 **부분추출 전 전수**로 계산해 같이 돌려준다.
      옛 판은 `(pts, vals)` 만 돌려줬고 소비자(`mpm_webapp_payload`)가 **돌려받은 점군에**
      `np.percentile(vals, 99.8)` 를 걸어 `focus_top` 을 만들었다.  그런데 위 추출은
      **상위 `hot_budget_frac` 를 전수 보존**하므로 점군은 뜨거운 쪽으로 편향돼 있다 ⇒
      "p99.8" 이 장의 99.8 %가 아니라 **위에서 `0.002·max_points` 번째 셀**이었다.
      실측 (AM 협착 픽스처, N=157,889): `--field-max-points` 를 5,000 → 90,000 → 전수로
      키우면 같은 침대의 같은 양이 **×201.2 → ×71.6 → ×52.9** 로 움직인다 = 보고값이
      **그림 점 개수의 함수**였다 (장의 참값은 ×52.9, 90,000 에서 **1.35× 과대**).
      ⚠ 편향 크기는 **꼬리 모양에 걸린다** — 같은 격자에서 탄소 섬유가 있는 침대는 상위가
      고원이라 1.00× 였다.  ⇒ 침대 간 **비에서 상쇄되지 않는다** (이것이 진짜 독이다).
      ★ 규율 ⑤ 의 그 자리 — *"후보를 고르는 코드가 곧 사각지대다."*  `joule_hotspot` 은
      처음부터 `conc_ratio`·`hot_frac_50` 을 추출 **전**에 쟀다(:1284-1287); 이 함수만
      규약이 갈려 있었다.  ⇒ 둘을 같은 규약으로 맞춘다.
      ⚠ `stats` 는 **내부 jmag 단위**(= J·vox_cm)다 — 소비자가 `/vox_cm` 로 A/cm² 로 바꾼다."""
    _fa_refuse(res, 'field_point_cloud')                   # ② S1 v0 — face_alpha 해 거부 (E2 · 끈 해 = 비트 같음)
    if 'phi' not in res:
        return None, None, None
    P, cond = res['phi'], res['cond']
    sig = sigma_field(sigma_of_sid, sid)
    jmag = _voxel_jmag(P, cond, sig, periodic_xy=bool(res.get('periodic_xy')),
                       rint_ctx=rint_ctx_from(res, sid, sigma_of_sid),   # ① 계면 배율 = 조립과 동일 · RINT-19 지문
                       iface_ctx=iface_ctx_from(res, sid, sigma_of_sid))   # ①′ 막 · 절단 = 조립 원장 (E2 · E5)
    sel = np.isin(sid, np.asarray(list(sel_sids), np.int64)) & cond
    ii, jj, kk = np.where(sel)
    if not len(ii):
        return None, None, None
    vals = jmag[ii, jj, kk]
    #  ★ 전수 통계 — **부분추출 앞에서** 잰다 (위 배너).  소비자는 이것만 쓴다.
    stats = {'n_total': int(vals.size),
             'mean': float(vals.mean()),
             'p99_8': float(np.percentile(vals, 99.8)),
             'max': float(vals.max()),
             'subsampled': bool(len(ii) > max_points),
             'n_emitted': int(min(len(ii), max_points)),
             'hot_kept': int(max_points * hot_budget_frac) if len(ii) > max_points else int(vals.size)}
    if len(ii) > max_points:
        rng = np.random.default_rng(seed)
        order = np.argsort(vals)[::-1]
        n_hot = int(max_points * hot_budget_frac)
        hot = order[:n_hot]
        rest = rng.choice(order[n_hot:], size=max_points - n_hot, replace=False)
        pick = np.concatenate([hot, rest])
        ii, jj, kk, vals = ii[pick], jj[pick], kk[pick], vals[pick]
    pts = np.stack([(ii + 0.5) * vox + box_lo[0],
                    (jj + 0.5) * vox + box_lo[1],
                    (kk + 0.5) * vox + box_lo[2]], axis=1)
    return pts.astype(np.float32), vals.astype(np.float32), stats


def pore_tau(sid, vox, z_top_um, extra_solid_pts=None, box_lo=(0.0, 0.0, 0.0), periodic_xy=False):
    """A6 — PORE-phase effective-diffusion tortuosity (DiffuDict/TauFactor convention).

    Runs the SAME validated finite-volume machinery (solve_sigma_z, physics unchanged) on the
    VOID phase: σ(void)=1, σ(solid)=0, plates at z=0 / z_top → the returned sigma_eff IS the
    dimensionless D_eff/D0.  τ = ε_total / (D_eff/D0)   [tortuosity FACTOR: D_eff = D0·ε/τ].

    Conventions (honest):
      • PTFE is NOT rasterized into the e/ionic sid grid (insulator on both networks), so sid==0
        alone would read PTFE volume as open pore (ε over-count → τ under-count).  Its material
        points must be passed via extra_solid_pts (µm, grid frame) — stamped solid here, same
        single-voxel stamp convention rasterize() uses for additive points.
      • the grid is CROPPED to z ≤ z_top_um first (REQUIRED arg: without it the top plate would
        sit on the rasterization box's void padding cap and ε/D_rel measure the cap, not the
        bed).  Uncropped, every column's topmost pore voxel floats in that cap and the top
        plate loses/keeps contact by sub-voxel luck.
      • plate band = vox EXACTLY (review M1) — NOT the e-solve default vox+0.1: after the crop a
        true surface pore's centre is provably < vox from its plate plane while a pore ROOFED by
        one solid voxel is ≥ vox away, so band=vox separates open from sealed at both plates.
        The e-solve's +0.1 µm is crown-contact physics (a plate PRESSES onto crowns); for the
        pore there is no press — solid above a pore genuinely seals it.  With the default band,
        D_rel leaked through 1-voxel roofs whenever frac(z_top/vox) ∈ [0.5, 0.75) (τ<1 possible).
      • ε_total counts ALL void voxels of the cropped domain (isolated pores included —
        TauFactor convention: closed porosity RAISES τ); ε_connected (plate-reaching component)
        is reported alongside — None when the solve early-returns before the floating-island
        filter (its n_dof then counts ALL pore voxels, review m2).  D_rel below 1e-12
        (non-percolating pore) → tau=None.
      • known small biases (review m1/m4, documented not fixed): ε is measured over the cropped
        height nzc·vox while D_rel is normalised by L=z_top → one-sided τ over-read ≤ 0.5·vox/
        z_top (+0.67 % worst at 30 µm/vox 0.4, exact when frac(z_top/vox)<0.5); the AM-AM
        contact-bridge balls rasterize() stamps (1.2·vox Hertz-neck proxy) count as solid here
        (~2 % of the pore phase at ε≈15 % — a real neck does occupy that space).
      • STRUCTURAL descriptor (frame[4] cross-check / gas·liquid-infiltration axis).  ASSB Li⁺
        transport lives on the SE contact network (σ_ionic solves) — do NOT substitute this τ
        into the transport forms (CLAUDE.md audit #2 double-count trap).

    Returns dict(eps_total_pct, eps_connected_pct, D_rel, tau, n_dof, resid, unconverged
                 [, reason])."""
    if z_top_um is None or float(z_top_um) <= 0.0:
        raise ValueError('pore_tau requires z_top_um > 0 (bed thickness): without the crop the '
                         'void padding cap above the bed is measured instead of the pore network')
    s = np.asarray(sid)
    nzc = int(np.floor(float(z_top_um) / vox + 0.5))        # top-layer centre stays ≤ plate plane
    nzc = max(2, min(s.shape[2], nzc))
    s = s[:, :, :nzc].copy()
    if extra_solid_pts is not None and len(extra_solid_pts):
        ijk = np.floor((np.asarray(extra_solid_pts, np.float64) - np.asarray(box_lo, np.float64))
                       / vox).astype(int)
        ok = ((ijk >= 0) & (ijk < np.array(s.shape))).all(1)
        ijk = ijk[ok]
        s[ijk[:, 0], ijk[:, 1], ijk[:, 2]] = 7               # any non-zero id = solid to the pore solve
    pore = (s == 0)
    eps = float(pore.mean())
    if eps <= 0.0:
        return {'eps_total_pct': 0.0, 'eps_connected_pct': 0.0, 'D_rel': 0.0, 'tau': None,
                'n_dof': 0, 'cg_info': 0, 'resid': 0.0, 'unconverged': False,
                'reason': 'no_void'}
    res = solve_sigma_z(pore.astype(np.int8), np.array([0.0, 1.0]), vox,
                        z_top_um=z_top_um, z_bot_um=0.0, plate_band_um=vox, periodic_xy=periodic_xy)
    d_rel = float(res['sigma_eff'])
    out = {'eps_total_pct': round(100.0 * eps, 2),
           # on early-return paths n_dof counts ALL pore voxels (floating filter never ran) —
           # connected fraction is then UNKNOWN, not "everything" (review m2)
           # ⚠ 2026-08-12 (Codex #2): 이 값은 **either-plate**(한쪽에라도 닿음)이다.  "관통
           #   공극률" 이 아니다 — 그 뜻으로 쓰려면 아래 `eps_through_pct` 를 쓸 것.
           #   이름은 하위호환을 위해 유지하고 규약을 `eps_connected_basis` 에 적는다.
           'eps_connected_pct': (None if res.get('reason')
                                 else round(100.0 * res['n_dof'] / s.size, 2)),
           'eps_connected_basis': 'legacy:either_plate',
           'eps_through_pct': (None if res.get('reason') or res.get('n_through_dof') is None
                               else round(100.0 * res['n_through_dof'] / s.size, 2)),
           'D_rel': float(f'{d_rel:.4g}'),
           'tau': (float(f'{eps / d_rel:.4g}') if d_rel > 1e-12 else None),
           'n_dof': res['n_dof'],
           'n_plate_reachable_dof': res.get('n_plate_reachable_dof'),
           'n_through_dof': res.get('n_through_dof'),
           #  ★ 2026-08-25 (R4-CX-02) — `cg_info` 도 남긴다 (소비자 계약이 conjunction).
           'cg_info': int(res.get('cg_info', 0)),
           'resid': res['resid'], 'unconverged': res['unconverged']}
    if res.get('reason'):
        out['reason'] = res['reason']
    return out


def pore_pnm(sid, vox, z_top_um, extra_solid_pts=None, box_lo=(0.0, 0.0, 0.0),
             periodic_xy=False):
    """A13 — pore-network TOPOLOGY descriptors (nearest-seed pore-body partition; A6 확장).

    Same crop + PTFE-stamp preamble as pore_tau (conventions inherited), then:
      • EDT(pore) → plateau maxima (3³ max-filter, dist>1 voxel) = pore-body seeds →
        `ndimage.watershed_ift` basin partition (solid = background).
      • per-body: volume → equivalent radius r_eq = (3V/4π)^⅓ [µm].
      • throats: face-adjacent voxel pairs with different body labels → pore-CN (degree),
        n_throats, throat equivalent radius √(A_face/π) (voxel-resolution floor = vox).
      • closed_from_top_pct: pore volume in components NOT reaching the top layer
        (separator side = the open exterior; the bottom is the collector plate = sealed).
        This is the gas/liquid-infiltration closure axis (#286 yoo2026) — DIFFERENT from
        A6 eps_connected (both-plate percolation for the D_eff solve).

    Honest limits: EDT-plateau seeding over-segments long ridges (fine-grained bodies —
    distributions are the robust readout, single n_pores is marker-sensitive); throat area
    is a voxel face count (0.4 µm floor, sub-voxel constriction unresolved — same caveat
    as STEP3 σ).  Thin-pore fallback (no seed with dist>1): connected components become the
    bodies (n_throats=0, flagged).  STRUCTURAL descriptor only — NOT a transport input
    (same audit-#2 non-substitution rule as pore_tau)."""
    if z_top_um is None or float(z_top_um) <= 0.0:
        raise ValueError('pore_pnm requires z_top_um > 0 (same crop rule as pore_tau)')
    s = np.asarray(sid)
    nzc = int(np.floor(float(z_top_um) / vox + 0.5))
    nzc = max(2, min(s.shape[2], nzc))
    s = s[:, :, :nzc].copy()
    if extra_solid_pts is not None and len(extra_solid_pts):
        ijk = np.floor((np.asarray(extra_solid_pts, np.float64) - np.asarray(box_lo, np.float64))
                       / vox).astype(int)
        ok = ((ijk >= 0) & (ijk < np.array(s.shape))).all(1)
        ijk = ijk[ok]
        s[ijk[:, 0], ijk[:, 1], ijk[:, 2]] = 7
    pore = (s == 0)
    if not pore.any():
        return {'reason': 'no_void', 'n_pores': 0}

    # closed-from-top (component level — watershed 무관, 먼저 계산)
    lab_c, _n_c = ndimage.label(pore)                       # 6-conn = face graph
    top_ids = np.unique(lab_c[:, :, nzc - 1])
    top_ids = top_ids[top_ids > 0]
    v_all = float(pore.sum())
    v_open = float(np.isin(lab_c, top_ids).sum()) if len(top_ids) else 0.0
    closed_pct = 100.0 * (1.0 - v_open / max(v_all, 1.0))

    dist = ndimage.distance_transform_edt(pore)
    mx = ndimage.maximum_filter(dist, size=3)
    peaks = pore & (dist >= mx) & (dist > 1.0)              # >1 voxel: 1-voxel skin/line은 seed 아님
    mark, n_seed = ndimage.label(peaks)
    fallback = n_seed == 0
    if fallback:                                            # ultra-thin pore망: 성분=바디로
        lab = lab_c
        n_bodies = int(lab.max())
    else:
        # 최근접-seed 파티션 (SNOW-lite): pore 복셀을 유클리드-최근접 seed에 귀속.
        # ⚠ scipy watershed_ift는 이 용도에 부적합 확인(selftest dumbbell 734/7 오분할 —
        # IFT plateau/큐-순서 quirk) → 결정적 nearest-seed로 교체 (371/370, r_eq 2.23µm 정답).
        # 한계(정직): 직선-거리 metric이라 오목 기공에서 seed-Voronoi 경계가 벽을 가로질러
        # 그릴 수 있음 — throat 집계는 pore-내부 면만 세므로 가짜 인접은 제한적, 분포 판독 권장.
        _, idx = ndimage.distance_transform_edt(mark == 0, return_indices=True)
        lab = np.where(pore, mark[idx[0], idx[1], idx[2]], 0)
        n_bodies = int(len(np.unique(lab)) - (1 if (lab == 0).any() else 0))
    cnt = np.bincount(lab.ravel().astype(np.int64))
    if cnt.size:
        cnt[0] = 0
    ids = np.nonzero(cnt)[0]
    vol_um3 = cnt[ids] * (vox ** 3)
    r_eq = (3.0 * vol_um3 / (4.0 * np.pi)) ** (1.0 / 3.0)

    pairs = {}
    if not fallback:
        W = int(lab.max()) + 1
        for ax in range(3):
            sa = [slice(None)] * 3
            sb = [slice(None)] * 3
            sa[ax] = slice(0, -1)
            sb[ax] = slice(1, None)
            la = lab[tuple(sa)].ravel()
            lb = lab[tuple(sb)].ravel()
            m = (la > 0) & (lb > 0) & (la != lb)
            if m.any():
                lo = np.minimum(la[m], lb[m]).astype(np.int64)
                hi = np.maximum(la[m], lb[m]).astype(np.int64)
                key, c = np.unique(lo * W + hi, return_counts=True)
                for k, cc in zip(key, c):
                    pairs[int(k)] = pairs.get(int(k), 0) + int(cc)
        deg = np.zeros(W, np.int32)
        for k in pairs:
            deg[k // W] += 1
            deg[k % W] += 1
        cn = deg[ids]
    else:
        cn = np.zeros(len(ids), np.int32)
    throat_r = (np.sqrt(np.array(list(pairs.values()), float) * vox * vox / np.pi)
                if pairs else np.array([]))

    def _st(v, f=3):
        return {} if not len(v) else {
            'mean': float(f'{np.mean(v):.{f}g}'), 'med': float(f'{np.median(v):.{f}g}'),
            'p90': float(f'{np.percentile(v, 90):.{f}g}'), 'max': float(f'{np.max(v):.{f}g}')}
    out = {'n_pores': int(n_bodies), 'n_throats': int(len(pairs)),
           'r_eq_um': _st(r_eq), 'pore_cn': _st(cn.astype(float), 3),
           'closed_from_top_pct': round(closed_pct, 2),
           'trust': 'STRUCTURAL PNM (nearest-seed partition, EDT-plateau seed) — 분포가 robust 판독; '
                    'n_pores는 marker-민감, throat=face-count(vox 하한).  수송 폼 대입 금지(A6 동일)'}
    if len(throat_r):
        out['throat_r_eq_um'] = _st(throat_r)
    if fallback:
        out['fallback'] = 'components (no EDT>1 seed — ultra-thin pore)'
    # ★ 2026-08-12 (Codex #7): 이 함수는 EDT · maximum_filter · watershed_ift · 6-conn label 을
    #   전부 **비주기**로 돈다.  주기 런에서 그 넷을 주기화하려면 x/y 로 한 주기 타일링이
    #   필요해 (메모리 ×9) 여기서는 하지 않는다.  대신 **값을 지어내지 않고 한계를 기계
    #   판독 가능하게 표시**한다 (§F1) — 소비자가 주기 런의 PNM 을 비주기 근사로 읽게.
    out['boundary'] = 'nonperiodic'
    if periodic_xy:
        out['boundary'] = 'nonperiodic_approximation_of_periodic_solve'
        out['periodic_caveat'] = ('솔버는 x/y seam 을 커플링했으나 PNM 은 비주기로 분할했다 — '
                                  'seam 을 가로지르는 공극체가 **둘로 쪼개져** n_pores 는 과대, '
                                  'r_eq/pore_cn 은 경계 근방에서 과소.  seam 근방 통계 인용 금지.')
    return out


def solve_reaction_current(sid, sig_e_of_sid, sig_i_of_sid, pid, n_am, vox, gct_code,
                           z_top_um=None, z_bot_um=None, periodic_xy=False):
    """STEP4-v1 — 저율·균일-SOC 갈바노스타틱 **반응전류 분포** (랩 slide-20 물리, 선형화 BV).

    같은 복셀 격자 위 TWO networks를 반응 계면에서만 결합한 단일 SPD Kirchhoff 시스템:
      · electronic net (σ_e table: AM+carbon+SDCP) ← 집전체 plate (bottom, φ_e=1 소스)
      · ionic net      (σ_i table: SE+SDCP+SWCNT-sheath-if-transparent) ← 분리막 plate (top, φ_i=0 싱크)
      · BV faces: AM(sid 1,2) ↔ ion-conductor(sid 5,6,8-투명시; σ_i>0 게이트) 인접 면마다 선형화 Butler-Volmer
        컨덕턴스 g_ct = (i0·F/RT)·A_face.  Li는 이 면으로만 두 망을 건넌다 — 반응 면적이
        rasterized 접촉(=coverage)에서 자연히 나온다.
    가정(정직): 저율 선형화(과전압≪RT/F), 균일 SOC(OCV 상수 소거 — linear라 총전류로 스케일),
    충·방전은 부호만 반전.  SDCP는 혼성전도라 두 망 모두에 노드를 갖지만 자기-BV는 없음
    (인터칼레이션 전극이 아님) — 기여는 이온/전자 '배달'로만 (STEP3 서사와 연속).
    Returns dict(i_am[n_am] — 입자별 반응전류(code units, RELATIVE: caller가 정규화),
    I_tot, kcl_err, resid, unconverged, n_dof_e/i, n_bv_faces [, reason])."""
    nx, ny, nz = sid.shape
    sig_e = sig_e_of_sid[sid]
    sig_i = sig_i_of_sid[sid]
    cond_e = sig_e > 0
    cond_i = sig_i > 0
    out0 = {'i_am': np.zeros(n_am), 'I_tot': 0.0, 'kcl_err': 0.0, 'resid': 0.0,
            'unconverged': False, 'n_dof_e': int(cond_e.sum()), 'n_dof_i': int(cond_i.sum()),
            'n_bv_faces': 0}
    if not cond_e.any() or not cond_i.any():
        return {**out0, 'reason': 'missing_network'}
    z_b = float(z_bot_um) if z_bot_um is not None else 0.0
    z_plate = min(float(z_top_um) if z_top_um is not None else nz * vox, nz * vox)
    band = vox + 0.10
    zc = (np.arange(nz) + 0.5) * vox
    #  ★★ 2026-08-25 (CDXR3-6) — **반응 솔버도 같은 결함이었다.**  `solve_sigma_z` 와
    #    똑같이 `cond_*` 로 표면을 골라 절연 고체를 관통했다.  같은 규약으로 맞춘다:
    #    가장 바깥 **점유 고체**를 먼저 정하고, 그것이 그 망의 도체일 때만 결합한다.
    _occ_r = sid != 0
    _any_o = _occ_r.any(2)
    _kf = np.argmax(_occ_r, axis=2)
    _kl = nz - 1 - np.argmax(_occ_r[:, :, ::-1], axis=2)
    _iir, _jjr = np.meshgrid(np.arange(nx), np.arange(ny), indexing='ij')
    any_e, k_first_e = _any_o, _kf
    #  ★ R3-CX-07 ④ — 반응 솔버도 **절대값** band (슬래브 밖 셀은 접촉이 아니다)
    bot_e = _any_o & cond_e[_iir, _jjr, _kf] & (np.abs(zc[_kf] - z_b) <= band)   # 집전체 접점
    any_i, k_last_i = _any_o, _kl
    top_i = _any_o & cond_i[_iir, _jjr, _kl] & (np.abs(z_plate - zc[_kl]) <= band)  # 분리막 접점
    if not bot_e.any() or not top_i.any():
        return {**out0, 'reason': f'no_plate_contact(bot_e={int(bot_e.sum())},top_i={int(top_i.sum())})'}
    # anchored-component filter: 결합 그래프(전자·이온·BV 인접 = 모두 6-이웃 face)를 union 마스크
    # 라벨로 근사 — 어느 plate에도 안 닿는 섬은 전류 0이므로 제거 (특이 블록 방지).  union 인접이
    # 실제 엣지가 아닌 희귀 케이스(SE|carbon 면)는 아래 ε-diag 가드가 받친다.
    uni = cond_e | cond_i
    lab, _nl = ndimage.label(uni)
    _ii, _jj = np.where(bot_e)
    anch = set(lab[_ii, _jj, k_first_e[bot_e]].tolist())
    _ii, _jj = np.where(top_i)
    anch |= set(lab[_ii, _jj, k_last_i[top_i]].tolist())
    anch.discard(0)
    keep = np.isin(lab, list(anch))
    cond_e &= keep
    cond_i &= keep
    n_e = int(cond_e.sum())
    n_i = int(cond_i.sum())
    if n_e == 0 or n_i == 0:
        return {**out0, 'reason': 'all_floating_dropped'}
    idx_e = -np.ones(sid.shape, np.int64); idx_e[cond_e] = np.arange(n_e)
    idx_i = -np.ones(sid.shape, np.int64); idx_i[cond_i] = np.arange(n_i)
    sig_e = np.where(cond_e, sig_e, 0.0)
    sig_i = np.where(cond_i, sig_i, 0.0)
    N = n_e + n_i
    rows, cols, vals = [], [], []
    diag = np.zeros(N, np.float64)
    b = np.zeros(N, np.float64)

    def _net_couple(idxN, sigN, off, sl_a, sl_b):
        A, B = idxN[sl_a], idxN[sl_b]
        sa, sb = sigN[sl_a], sigN[sl_b]
        m = (A >= 0) & (B >= 0)
        if not m.any():
            return
        g = (2.0 * sa[m] * sb[m] / (sa[m] + sb[m])) * vox
        a2, b2 = A[m] + off, B[m] + off
        rows.append(a2); cols.append(b2); vals.append(-g)
        rows.append(b2); cols.append(a2); vals.append(-g)
        np.add.at(diag, a2, g); np.add.at(diag, b2, g)

    # 방향 목록 (전도·BV가 공유 → 주기성 일관 보장).  periodic_xy면 x,y wrap 추가 (z=plate 유지).
    _dirs = [(np.s_[:-1, :, :], np.s_[1:, :, :]), (np.s_[:, :-1, :], np.s_[:, 1:, :]),
             (np.s_[:, :, :-1], np.s_[:, :, 1:])]
    if periodic_xy:                                        # ★RVE 'boundary p p f' 정합 (σ-solve와 동일 규약)
        if sid.shape[0] > 1:
            _dirs.append((np.s_[-1:, :, :], np.s_[:1, :, :]))   # x: nx-1 ↔ 0
        if sid.shape[1] > 1:
            _dirs.append((np.s_[:, -1:, :], np.s_[:, :1, :]))   # y: ny-1 ↔ 0
    for sl_a, sl_b in _dirs:
        _net_couple(idx_e, sig_e, 0, sl_a, sl_b)
        _net_couple(idx_i, sig_i, n_e, sl_a, sl_b)
    # BV 계면 결합 + per-face 기록 (입자별 합산용) — 전도와 동일 _dirs(주기 wrap 포함)로 계면도 일관 주기
    am_m = (sid == 1) | (sid == 2)
    # ★MED-2(감사): 반응 계면 = AM↔이온공급상.  이온상 = SDCP(5)·SE(6)·SWCNT-sheath(8, 투명할 때만).
    #   sid 8 누락 시 σ_ion 솔브(sheath 투명=σ_i[8]>0)와 STEP4 반응(8 제외)이 모순 → wrap_frac↑ AM
    #   표면이 반응서 사라져 STEP4가 --swcnt-ion-block인 것처럼 반응전류 과소.  cond_i(σ_i>0)로 게이트
    #   하여 --swcnt-ion-block(σ_i[8]=0)이면 sid 8 자동 제외 = 솔브와 계면 일관.  기본 bimodal 무영향.
    ion_m = ((sid == 5) | (sid == 6) | (sid == 8)) & cond_i
    bv_e, bv_i, bv_pid = [], [], []
    gct = float(gct_code)
    for sl_a, sl_b in _dirs:
        for am_first in (True, False):
            slA, slB = (sl_a, sl_b) if am_first else (sl_b, sl_a)
            m = am_m[slA] & ion_m[slB]
            Ae = idx_e[slA]; Bi = idx_i[slB]
            m &= (Ae >= 0) & (Bi >= 0)
            if not m.any():
                continue
            a2 = Ae[m]; b2 = Bi[m] + n_e
            g = np.full(len(a2), gct)
            rows.append(a2); cols.append(b2); vals.append(-g)
            rows.append(b2); cols.append(a2); vals.append(-g)
            np.add.at(diag, a2, g); np.add.at(diag, b2, g)
            bv_e.append(a2); bv_i.append(b2); bv_pid.append(pid[slA][m])
    n_bv = int(sum(len(x) for x in bv_e))
    if n_bv == 0:
        return {**out0, 'n_dof_e': n_e, 'n_dof_i': n_i, 'reason': 'no_reaction_interface'}
    # plates: 전자망 bottom(φ=1 소스), 이온망 top(φ=0)
    def _plate(idxN, sigN, off, mask, ksurf, plane, phi_p):
        ii, jj = np.where(mask)
        kk2 = ksurf[mask]
        A = idxN[ii, jj, kk2]
        sa = sigN[ii, jj, kk2]
        m = A >= 0
        dist = np.maximum(np.abs(zc[kk2[m]] - plane), 0.5 * vox)
        g = sa[m] * vox * vox / dist
        np.add.at(diag, A[m] + off, g)
        if phi_p != 0.0:
            np.add.at(b, A[m] + off, g * phi_p)
        return A[m] + off, g
    eb_nodes, eb_g = _plate(idx_e, sig_e, 0, bot_e, k_first_e, z_b, 1.0)
    _plate(idx_i, sig_i, n_e, top_i, k_last_i, z_plate, 0.0)
    # degree-0 노드(엣지 전무)만 ε-고정.  union-라벨이 false-adjacency로 남길 수 있는 "고립
    # 서브그래프"(예: SE에 싸인 carbon 섬)는 특이 블록이지만 b=0 + CG(x0=0)에서 φ≡0으로 정확히
    # 유지된다(구조적 블록대각 + Krylov가 0-블록을 못 건드림) — 리뷰 프로브로 ΔI ~1e-15 확인.
    # ⚠ 이 안전성은 CG+x0=0 전제: 직접분해(spsolve)나 블록혼합 preconditioner로 바꾸면
    # 컴포넌트-그래프 anchoring(BV 엣지 기반 union-find)으로 교체할 것.
    diag[diag == 0.0] = 1.0
    L = sparse.coo_matrix((np.concatenate(vals + [diag]),
                           (np.concatenate(rows + [np.arange(N)]),
                            np.concatenate(cols + [np.arange(N)]))), shape=(N, N)).tocsr()
    print(f'    STEP4 rxn solve: e {n_e:,} + i {n_i:,} dof, BV faces {n_bv:,} — CG '
          f'({"GPU" if GPU_SOLVE else "CPU"})…', flush=True)
    phi, info = _solve_cg(L, b)
    resid = float(np.linalg.norm(L @ phi - b) / max(np.linalg.norm(b), 1e-30))
    unconv = bool(info) or not np.isfinite(resid) or resid > 1e-6   # ★ RGL-01 — 비유한 잔차 = 미수렴 (위 σ 솔브와 같은 술어)
    I_tot = float(np.sum(eb_g * (1.0 - phi[eb_nodes])))
    i_am = np.zeros(n_am, np.float64)
    I_bv = 0.0
    for a2, b2, pd in zip(bv_e, bv_i, bv_pid):
        f = gct * (phi[a2] - phi[b2])                        # +: e-net → i-net (한 방향, linear)
        I_bv += float(f.sum())
        mm2 = pd >= 0
        np.add.at(i_am, pd[mm2], f[mm2])
    kcl = abs(I_tot - I_bv) / max(abs(I_tot), 1e-30)         # KCL: plate 유입 = BV 총 통과
    return {'i_am': i_am, 'I_tot': I_tot, 'kcl_err': float(kcl), 'resid': resid,
            'unconverged': unconv, 'n_dof_e': n_e, 'n_dof_i': n_i, 'n_bv_faces': n_bv}


def _selftest_rxn():
    """STEP4 sandwich analytic: 하반 AM slab / 상반 SE slab, 계면 BV — 직렬저항 I와 균일 i_n."""
    vox = 0.5
    nxy, nz = 6, 12
    sid = np.zeros((nxy, nxy, nz), np.int8)
    sid[:, :, :6] = 1                                        # AM (전자망)
    sid[:, :, 6:] = 6                                        # SE (이온망)
    pid = np.full(sid.shape, -1, np.int32)
    pid[:, :, :6] = 0                                        # 입자 1개로 합산
    sig_e = np.array([0.0, 1.0, 0.0, 0.0, 0.0, 0.0, 0.0])
    sig_i = np.array([0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 2.0])
    gct = 0.05                                               # 면당 (code units)
    r = solve_reaction_current(sid, sig_e, sig_i, pid, 1, vox, gct,
                               z_top_um=nz * vox, z_bot_um=0.0)
    # 직렬 해석해 (µm-code 단위 일관, 코드 규약대로 직접 합산):
    #   per-column R = 1/g_plate,e + 5/(σe·vox) + 1/g_ct + 5/(σi·vox) + 1/g_plate,i
    ge_plate = 1.0 * vox * vox / (0.5 * vox)
    gi_plate = 2.0 * vox * vox / (0.5 * vox)
    R_col = 1.0 / ge_plate + 5 * (1.0 / (1.0 * vox)) + 1.0 / gct + 5 * (1.0 / (2.0 * vox)) + 1.0 / gi_plate
    I_exp = nxy * nxy / R_col
    okI = abs(r['I_tot'] - I_exp) / I_exp < 1e-3
    okK = r['kcl_err'] < 1e-6
    okU = abs(r['i_am'][0] - r['I_tot']) / r['I_tot'] < 1e-6   # 입자 1개 = 총전류 (CG rtol 1e-8 여유)
    print(f"rxn sandwich: I={r['I_tot']:.6f} (expect {I_exp:.6f})  {'OK' if okI else 'FAIL'}")
    print(f"rxn KCL: plate vs ΣBV err={r['kcl_err']:.2e}  {'OK' if okK else 'FAIL'}")
    print(f"rxn per-particle sum == I_tot  {'OK' if okU else 'FAIL'}")
    # 방향 대칭 — 좌/우 미러 배치가 같은 I·face 수 (am_first 양쪽 분기 고정; 물리 리뷰 프로브 영구화)
    sidL = np.zeros((6, 6, 12), np.int8); sidL[:3] = 1; sidL[3:] = 6
    sidR = np.zeros((6, 6, 12), np.int8); sidR[3:] = 1; sidR[:3] = 6
    pidL = np.where(sidL == 1, 0, -1).astype(np.int32)
    pidR = np.where(sidR == 1, 0, -1).astype(np.int32)
    rL = solve_reaction_current(sidL, sig_e, sig_i, pidL, 1, vox, gct, z_top_um=nz * vox, z_bot_um=0.0)
    rR = solve_reaction_current(sidR, sig_e, sig_i, pidR, 1, vox, gct, z_top_um=nz * vox, z_bot_um=0.0)
    okM = (rL['n_bv_faces'] == rR['n_bv_faces']
           and abs(rL['I_tot'] - rR['I_tot']) / max(abs(rL['I_tot']), 1e-30) < 1e-6)
    print(f"rxn mirror(lateral BV): I_L={rL['I_tot']:.6f} I_R={rR['I_tot']:.6f} "
          f"faces {rL['n_bv_faces']}/{rR['n_bv_faces']}  {'OK' if okM else 'FAIL'}")
    # ★ RGL-01 (Codex 10-05 g1_review) — 같은 술어 결함: info 0 + 비유한 잔차를 미수렴으로 적는가 (프로세스 안 주입).
    global _solve_cg
    _cg0 = _solve_cg
    try:
        _solve_cg = lambda L, b: (np.full(len(b), np.nan), 0)      # noqa: E731
        rN = solve_reaction_current(sid, sig_e, sig_i, pid, 1, vox, gct, z_top_um=nz * vox, z_bot_um=0.0)
    finally:
        _solve_cg = _cg0
    okN = rN['unconverged'] is True and not np.isfinite(rN['resid'])
    print(f"rxn nonfinite-resid: info 0 + NaN 해 → unconverged={rN['unconverged']}  {'OK' if okN else 'FAIL'}")
    ok = okI and okK and okU and okM and okN
    print('RXN SELFTEST', 'PASS' if ok else 'FAIL')
    return 0 if ok else 1


def _selftest():
    """Analytic checks that pin assembly + BC signs."""
    ok = True
    sig_tab = np.array([0.0, 1.0, 4.0])
    # 1) uniform block σ=1 → σ_eff = 1
    sid = np.ones((6, 6, 10), np.int8)
    r = solve_sigma_z(sid, sig_tab, 0.5)
    ok &= abs(r['sigma_eff'] - 1.0) < 1e-6
    print(f"uniform:  σ_eff={r['sigma_eff']:.6f}  (expect 1.0)  {'OK' if ok else 'FAIL'}")
    # 2) series laminate (z-stacked σ=1 / σ=4, half-half) → harmonic mean 1.6
    sid = np.ones((6, 6, 10), np.int8); sid[:, :, 5:] = 2
    r = solve_sigma_z(sid, sig_tab, 0.5)
    e = abs(r['sigma_eff'] - 1.6) < 1e-3
    ok &= e; print(f"series:   σ_eff={r['sigma_eff']:.6f}  (expect 1.6 harmonic)  {'OK' if e else 'FAIL'}")
    # 2b) ★★ 2026-08-30 (Codex R13 C-4) — **관통 성분이 없으면 reason 을 돌려준다.**
    #     양쪽 판에 각각 닿지만 서로 안 이어진 두 성분: 옛 판은 `reason=None · n_dof=2` 로
    #     정상 솔브를 타 σ=0 을 냈고 payload 가 그것을 `complete` 로 찍었다 (0 이 측정값이 된다).
    #     ⚠ 음성 대조 둘을 같이 건다 — `periodic_xy` 에서는 **발동하면 안 되고**(비주기 라벨,
    #       :710 caveat), 정상 관통 침대는 **영향이 없어야** 한다.
    _d = np.zeros((2, 1, 5), np.int8); _d[0, 0, 0] = 1; _d[1, 0, 4] = 1
    _rd = solve_sigma_z(_d, sig_tab, 1.0, z_bot_um=0, z_top_um=5)
    _rp = solve_sigma_z(_d, sig_tab, 1.0, z_bot_um=0, z_top_um=5, periodic_xy=True)
    _ru = solve_sigma_z(np.ones((4, 4, 6), np.int8), sig_tab, 0.5)
    e = (_rd.get('reason') == 'no_through_component' and _rd['n_dof'] == 2
         and _rd['n_through_dof'] == 0
         and _rp.get('reason') is None                      # 주기: 발동 금지
         and _ru.get('reason') is None and abs(_ru['sigma_eff'] - 1.0) < 1e-6)
    ok &= e
    print(f"no-through: reason={_rd.get('reason')} · periodic={_rp.get('reason')} · "
          f"uniform σ={_ru['sigma_eff']:.6f}  {'OK' if e else 'FAIL'}")
    # 3) parallel laminate (x-split) → arithmetic mean 2.5
    sid = np.ones((6, 6, 10), np.int8); sid[3:, :, :] = 2
    r = solve_sigma_z(sid, sig_tab, 0.5)
    e = abs(r['sigma_eff'] - 2.5) < 1e-3
    ok &= e; print(f"parallel: σ_eff={r['sigma_eff']:.6f}  (expect 2.5 arithmetic)  {'OK' if e else 'FAIL'}")
    # 4) disconnected (air gap layer) → σ_eff = 0
    sid = np.ones((6, 6, 10), np.int8); sid[:, :, 5] = 0
    r = solve_sigma_z(sid, sig_tab, 0.5)
    e = r['sigma_eff'] < 1e-12
    ok &= e; print(f"gap:      σ_eff={r['sigma_eff']:.2e}  (expect 0)  {'OK' if e else 'FAIL'}")
    # 5) thin conductive column (1/36 of area) → σ_eff = 1/36 of column σ
    sid = np.zeros((6, 6, 10), np.int8); sid[0, 0, :] = 1
    r = solve_sigma_z(sid, sig_tab, 0.5)
    e = abs(r['sigma_eff'] - 1.0 / 36.0) < 1e-6
    ok &= e; print(f"column:   σ_eff={r['sigma_eff']:.6f}  (expect {1/36:.6f})  {'OK' if e else 'FAIL'}")
    # 5b) ★ RGL-01 (Codex 10-05 g1_review) — **비유한 잔차는 미수렴이다.**  옛 술어 `bool(info) or resid > 1e-6` 은
    #     info 0 + resid NaN 을 놓쳤다 (NaN > 1e-6 = False → 경고 없음 · unconverged False).  CG 가 NaN 해를 info 0
    #     으로 돌려주는 상황을 프로세스 안에서 주입한다 (과거 실침대 런에 NaN 이 있었다는 증거가 아니다).
    #     전부 NaN · 한 성분만 NaN (σ 는 유한할 수도 있는 쪽) 둘 다 · 정상 해는 그대로 (대조).
    global _solve_cg
    import contextlib as _ctx
    import io as _io
    _cg0 = _solve_cg

    def _one_nan(L, b):
        _x = np.array(_cg0(L, b)[0], np.float64)
        _x[-1] = np.nan
        return _x, 0
    sid = np.ones((4, 4, 6), np.int8)
    for _lbl, _fake in (('all-NaN', lambda L, b: (np.full(len(b), np.nan), 0)), ('one-NaN', _one_nan)):
        _buf = _io.StringIO()
        try:
            _solve_cg = _fake
            with _ctx.redirect_stdout(_buf):
                rN = solve_sigma_z(sid, sig_tab, 0.5)
        finally:
            _solve_cg = _cg0
        e = (rN['unconverged'] is True and rN['cg_info'] == 0 and not np.isfinite(rN['resid'])
             and 'STEP3 CG not converged' in _buf.getvalue())
        ok &= e; print(f"nonfinite-resid ({_lbl}): info 0 · resid {rN['resid']} → unconverged={rN['unconverged']} · "
                       f"경고 {'있음' if 'not converged' in _buf.getvalue() else '없음'}  {'OK' if e else 'FAIL'}")
    rC = solve_sigma_z(sid, sig_tab, 0.5)
    e = rC['unconverged'] is False and np.isfinite(rC['resid']) and abs(rC['sigma_eff'] - 1.0) < 1e-6
    ok &= e; print(f"nonfinite-resid (대조): 정상 해 unconverged={rC['unconverged']} resid={rC['resid']:.1e}  "
                   f"{'OK' if e else 'FAIL'}")
    # 6) SR-03 AMG — 기본 OFF 이고, 켜도 **같은 σ** 를 내며, 실제로 쓴 전처리가 도장된다.
    #    고대비(σ 1 : 1e4) 격자로 — 전처리가 갈릴 여지가 있는 조건에서 봐야 뜻이 있다.
    global AMG_SOLVE
    hi = np.array([0.0, 1.0, 1.0e4])
    sid = np.ones((8, 8, 12), np.int8); sid[2:6, 2:6, :] = 2       # 고대비 관통 채널
    e = (AMG_SOLVE is False)
    ok &= e; print(f"amg-off:  기본 AMG_SOLVE={AMG_SOLVE}  (expect False = 현행 경로)  "
                   f"{'OK' if e else 'FAIL'}")
    sj = solve_sigma_z(sid, hi, 0.5)['sigma_eff']; pj = LAST_BACKEND['precond']
    AMG_SOLVE = True
    try:
        sa = solve_sigma_z(sid, hi, 0.5)['sigma_eff']; pa = LAST_BACKEND['precond']
    finally:
        AMG_SOLVE = False
    d = abs(sa - sj) / max(sj, 1e-30)
    #   pyamg 부재 환경에서는 폴백해 precond='jacobi' 가 되고 σ 는 당연히 같다 — 그때도 통과.
    e = d < 1e-6 and pj == 'jacobi' and pa in ('amg', 'jacobi')
    ok &= e; print(f"amg-inv:  σ_eff {sj:.8g} → {sa:.8g}  Δ={d:.1e}  precond {pj}→{pa}  "
                   f"(expect Δ<1e-6, 해-불변)  {'OK' if e else 'FAIL'}")
    # ★★ Codex #7 — 주기 런에서 phase_current_share 가 seam 면을 세는가.
    #    기하: x 로 4셀, 두 기둥이 **seam 을 통해서만** 이어진다.
    #      i=0 기둥(SE, sid 6) = 바닥에서 k=3 까지 · i=3 기둥(VGCF, sid 3) = k=3 에서 천장까지
    #    → 비주기면 관통 경로가 없고, 주기면 i=3↔i=0 seam 면 하나로 회로가 닫힌다.
    #    같은 해(res)에 진단만 두 규약으로 돌려 **진단 자체의 결함**을 격리한다.
    sid_p = np.zeros((4, 1, 6), np.int8)
    sid_p[0, 0, 0:4] = 6                                  # SE 기둥 (바닥 쪽)
    sid_p[3, 0, 3:6] = 3                                  # VGCF 기둥 (천장 쪽)
    sig_tab = np.zeros(9, np.float64); sig_tab[6] = 1.0; sig_tab[3] = 100.0
    r_np = solve_sigma_z(sid_p, sig_tab, 0.5, z_top_um=3.0, return_field=True, periodic_xy=False)
    r_pp = solve_sigma_z(sid_p, sig_tab, 0.5, z_top_um=3.0, return_field=True, periodic_xy=True)
    e = r_np['sigma_eff'] < 1e-9 and r_pp['sigma_eff'] > 1e-3
    ok &= e; print(f"seam-geom: 비주기 σ={r_np['sigma_eff']:.2e} (관통 없음) · 주기 σ={r_pp['sigma_eff']:.4g}"
                   f"  (seam 으로만 닫히는 회로)  {'OK' if e else 'FAIL'}")
    e = r_pp.get('periodic_xy') is True and r_np.get('periodic_xy') is False
    ok &= e; print(f"seam-tag:  해가 자기 경계조건을 들고 다닌다  {'OK' if e else 'FAIL'}")
    sh_on = phase_current_share(r_pp, sid_p, sig_tab)                    # res 에서 True 를 읽는다
    sh_off = phase_current_share(r_pp, sid_p, sig_tab, periodic_xy=False)  # 옛 규약 재현
    # seam 면이 유일한 연결이므로 그것을 빼면 분담이 **달라져야** 한다 (가능도비 ≠ 1)
    e = sh_on != sh_off and abs(sh_on.get(3, 0.0) - sh_off.get(3, 0.0)) > 1e-6
    ok &= e; print(f"seam-share: VGCF 분담 주기 {sh_on.get(3, 0):.4f} vs 옛규약 {sh_off.get(3, 0):.4f} "
                   f"(seam 면을 빼면 달라져야 한다)  {'OK' if e else 'FAIL'}")
    e = abs(sum(sh_on.values()) - 1.0) < 1e-9
    ok &= e; print(f"seam-norm:  주기 분담 합 = {sum(sh_on.values()):.9f}  {'OK' if e else 'FAIL'}")
    try:
        phase_current_share({'phi': r_pp['phi'], 'cond': r_pp['cond']}, sid_p, sig_tab)
        e = False
    except ValueError:
        e = True
    ok &= e; print(f"seam-fail-closed: 경계조건 없는 res 는 **거부**한다  {'OK' if e else 'FAIL'}")
    # ★★ 게이트 ⑥ — 복셀별 σ 장(field) 경로.  표 경로와 **같은 답**을 내야 하고(회귀 0),
    #    장을 바꾸면 **답이 바뀌어야** 한다(실효 확인).
    _sidu = np.ones((4, 4, 8), np.int8)
    _tab = np.array([0.0, 2.0])
    _a = solve_sigma_z(_sidu, _tab, 0.5, z_top_um=4.0)['sigma_eff']
    _b = solve_sigma_z(_sidu, np.full(_sidu.shape, 2.0), 0.5, z_top_um=4.0)['sigma_eff']
    e = abs(_a - _b) < 1e-12 * max(1.0, abs(_a))
    ok &= e; print(f"field-eq:  표 {_a:.8g} == 장 {_b:.8g}  (기존 호출 바이트 동일)  {'OK' if e else 'FAIL'}")
    _f = np.full(_sidu.shape, 2.0); _f[:, :, 3] = 0.5          # 한 층만 저전도 → 직렬 병목
    _c = solve_sigma_z(_sidu, _f, 0.5, z_top_um=4.0)['sigma_eff']
    e = _c < _b * 0.9
    ok &= e; print(f"field-eff: 장을 바꾸면 답이 바뀐다 {_b:.6g} → {_c:.6g}  {'OK' if e else 'FAIL'}")
    try:
        solve_sigma_z(_sidu, np.zeros((2, 2, 2)), 0.5, z_top_um=4.0)
        e = False
    except ValueError:
        e = True
    ok &= e; print(f"field-shape: shape 불일치는 **거부**한다 (조용한 브로드캐스트 금지)  {'OK' if e else 'FAIL'}")
    # 직경-보존 재척도 — 공칭 Ø 와 분포 Ø
    _se, _pv = diameter_preserving_sigma(100.0, None, 0.15, 0.4)
    e = abs(_se - 100.0 * np.pi * 0.15 ** 2 / 4 / 0.16) < 1e-9 and _pv['mode'] == 'single'
    ok &= e; print(f"dia-nominal: σ 100 → {_se:.4g} S/cm (Ø0.15 · vox0.4)  {'OK' if e else 'FAIL'}")
    _rel = np.array([0.23, 0.5, 1.0, 1.0, 1.0, 2.0, 8.48])
    _h = diameter_preserving_sigma(100.0, _rel, 0.15, 0.4, mode='harmonic')[0]
    _ar = diameter_preserving_sigma(100.0, _rel, 0.15, 0.4, mode='arithmetic')[0]
    e = _h < _ar and _ar / _h > 10.0
    ok &= e; print(f"dia-spread: 혼합 모집단이면 조화 {_h:.4g} vs 산술 {_ar:.4g} = {_ar/_h:.0f}배 "
                   f"(평균 규약이 지배)  {'OK' if e else 'FAIL'}")
    # ★ 자기정정 (CL-16): 그 스프레드는 **PTFE** 것이다.  상별로 가르면 VGCF 는 균일하다.
    _dia = np.concatenate([np.ones(50), np.array([0.23, 0.5, 2.0, 8.48] * 5)])
    _ph = np.concatenate([np.full(50, 2), np.full(20, 4)])          # 2=VGCF · 4=PTFE
    _st = dia_stats_by_phase(_dia, _ph)
    e = _st[2]['uniform'] is True and _st[4]['uniform'] is False and _st[2]['cv'] == 0.0
    ok &= e; print(f"dia-phase: VGCF 균일={_st[2]['uniform']} (cv {_st[2]['cv']}) · "
                   f"PTFE 균일={_st[4]['uniform']} (cv {_st[4]['cv']}) ⇒ **상을 먼저 가른다**"
                   f"  {'OK' if e else 'FAIL'}")
    _v = diameter_preserving_sigma(100.0, _dia[_ph == 2], 0.15, 0.4, mode='harmonic')[0]
    _v2 = diameter_preserving_sigma(100.0, _dia[_ph == 2], 0.15, 0.4, mode='arithmetic')[0]
    e = abs(_v - _v2) < 1e-9 and abs(_v - 11.0447) < 1e-3
    ok &= e; print(f"dia-vgcf:  VGCF 만 쓰면 두 평균이 **같다** ({_v:.4g} == {_v2:.4g}) "
                   f"⇒ 전자망에는 스칼라가 정확하다  {'OK' if e else 'FAIL'}")
    try:
        diameter_preserving_sigma(100.0, np.zeros(5), 0.15, 0.4)
        e = False
    except ValueError:
        e = True
    ok &= e; print(f"dia-empty: 유효 Ø 가 없으면 **거부** (0 을 만들지 않는다)  {'OK' if e else 'FAIL'}")

    # ★ Codex #7 (나머지 3종) — 주기 인자가 **실제로 답을 바꾸는가**.
    #    seam 을 사이에 둔 탄소↔SE 쌍 / seam 이웃이 SE 인 AM 을 각각 배치한다.
    sid_s = np.zeros((4, 1, 4), np.int8)
    sid_s[0, 0, 1] = 3; sid_s[3, 0, 1] = 6            # VGCF | ... | SE — seam 으로만 인접
    a_np = carbon_se_contact_area(sid_s, 0.4, periodic_xy=False)
    a_pp = carbon_se_contact_area(sid_s, 0.4, periodic_xy=True)
    e = a_np == 0.0 and a_pp > 0.0
    ok &= e; print(f"seam-csa:  탄소-SE 면적 비주기 {a_np:.4g} → 주기 {a_pp:.4g} µm² "
                   f"(seam 3상 계면)  {'OK' if e else 'FAIL'}")
    sid_a = np.zeros((4, 3, 4), np.int8)
    sid_a[0, 1, 1] = 1; sid_a[3, 1, 1] = 6            # AM_S | ... | SE — seam 으로만 인접
    pid_a = -np.ones(sid_a.shape, np.int64); pid_a[0, 1, 1] = 0
    p_np = am_surface_patches(sid_a, pid_a, 1, periodic_xy=False)
    p_pp = am_surface_patches(sid_a, pid_a, 1, periodic_xy=True)
    e = p_np['f_reaction'][0] == 0.0 and p_pp['f_reaction'][0] > 0.0 \
        and p_pp['f_void'][0] < p_np['f_void'][0]
    ok &= e; print(f"seam-patch: AM f_reaction 비주기 {p_np['f_reaction'][0]:.3f} → 주기 "
                   f"{p_pp['f_reaction'][0]:.3f} (f_void {p_np['f_void'][0]:.3f}→"
                   f"{p_pp['f_void'][0]:.3f})  {'OK' if e else 'FAIL'}")
    e = p_np['n_face'][0] == p_pp['n_face'][0]
    ok &= e; print(f"seam-patch-den: 총 face 수는 불변 {p_np['n_face'][0]} == {p_pp['n_face'][0]} "
                   f"(분류만 바뀐다)  {'OK' if e else 'FAIL'}")
    # z 는 주기여도 감지 않는다 (플레이트 축) — 위·아래 끝에 놓은 쌍은 어느 규약에서도 0
    sid_z = np.zeros((2, 1, 4), np.int8); sid_z[0, 0, 0] = 3; sid_z[0, 0, 3] = 6
    e = carbon_se_contact_area(sid_z, 0.4, periodic_xy=True) == 0.0
    ok &= e; print(f"seam-z:    z 는 주기여도 안 감는다  {'OK' if e else 'FAIL'}")
    _sp = np.ones((6, 6, 8), np.int8) * 6; _sp[2:4, 2:4, :] = 0     # 진짜 공극이 있어야 PNM 이 돈다
    _pnm_n = pore_pnm(_sp, 0.5, z_top_um=4.0, periodic_xy=False)
    _pnm_p = pore_pnm(_sp, 0.5, z_top_um=4.0, periodic_xy=True)
    e = (_pnm_n.get('reason') is None and _pnm_n.get('n_pores', 0) > 0            # 공허하지 않다
         and _pnm_n['boundary'] == 'nonperiodic'
         and _pnm_p['boundary'] == 'nonperiodic_approximation_of_periodic_solve'
         and 'periodic_caveat' in _pnm_p and 'periodic_caveat' not in _pnm_n)
    ok &= e; print(f"seam-pnm:  PNM(n_pores={_pnm_n.get('n_pores')}) 은 주기화 못 하는 것을 "
                   f"**표시**한다: {_pnm_n.get('boundary')} → {_pnm_p.get('boundary')}"
                   f"  {'OK' if e else 'FAIL'}")
    # ── SDCP 구 스탬프 (2026-08-16) — **우선순위가 점 스탬프와 같아야** 한다 ──────────
    #   실사고: 처음 판은 구 스탬프를 상 루프 **뒤에** 놓아 SDCP 가 PTFE(sid 7, 절연체)와
    #   SWCNT(sid 8)를 덮었다.  점 스탬프에서는 그 둘이 루프 뒤에 와서 SDCP 를 덮는다
    #   (루프 순서가 곧 우선순위다).  PTFE 셀을 도체로 바꾸면 σ_e 가 부풀어 **가짜 이득**이
    #   난다 — 규약을 바꾸는 것이 목적이 아니라 **부피만** 고치는 것이므로 우선순위는 같아야 한다.
    _pr = True
    for _oph in (4, 6, 2):
        _C1 = np.array([[1.0, 1.0, 1.0]])
        _pp = np.vstack([_C1, _C1]); _ph2 = np.array([5, _oph], np.int8)
        _s1, _ = rasterize(np.zeros((0, 3)), np.zeros(0), None, _pp, _ph2,
                           (0, 0, 0), (3., 3., 3.), 0.15)
        _s2, _ = rasterize(np.zeros((0, 3)), np.zeros(0), None, _pp, _ph2,
                           (0, 0, 0), (3., 3., 3.), 0.15, sdcp_sphere_d_um=0.30)
        _i = tuple((np.array([1., 1., 1.]) / 0.15).astype(int))
        _pr &= (_s1[_i] == _s2[_i])
    ok &= _pr
    print(f"sdcp-prio: 구 스탬프 우선순위 == 점 스탬프  {'OK' if _pr else 'FAIL'}")
    _rf = _rf_exc = False
    try:
        rasterize(np.zeros((0, 3)), np.zeros(0), None, np.array([[1., 1., 1.]]),
                  np.array([5], np.int8), (0, 0, 0), (3., 3., 3.), 0.4, sdcp_sphere_d_um=0.30)
    except SystemExit:
        _rf = True
    except Exception:                                   # noqa: BLE001 — 이것이 곧 회귀다
        _rf_exc = True
    ok &= _rf
    print(f"sdcp-gate: d/vox < 2 는 거부한다  {'OK' if _rf else 'FAIL'}")
    #  ★ 회귀 (리뷰 ① B2): 거부가 **`Exception` 계열이면 안 된다** — 호출자의 blanket
    #    `except Exception` 이 삼켜 fail-open 이 된다.  BaseException(SystemExit)이어야 한다.
    ok &= not _rf_exc
    print(f"sdcp-gate-fail-closed: 거부가 Exception 이 아니다 (blanket except 통과)  "
          f"{'OK' if not _rf_exc else 'FAIL — 호출자가 삼킨다'}")
    # ── ★★★ SDCP 접촉 브리지 (SELF-11 / Q-B2 판별 노브, 2026-08-25) ──────────────────
    #   `step3_sigma` docstring 이 이미 적은 결함 — *"plain rasterization randomly DROPS
    #   touching contacts"* — 이 **SDCP 구에만 안 고쳐져 있었다** (AM–AM 은 브리지,
    #   섬유는 6-면 보장).  그리고 전자 격자에서 SBE↔DBE 의 유일한 차이가 SDCP 다.
    #   ⇒ 네 가지를 못박는다: ⓐ 기본 off 는 **바이트 동일** ⓑ 실제로 끊긴 접촉을 **잇는다**
    #     ⓒ 이미 배정된 상을 **강등하지 않는다** ⓓ SDCP 없는 침대(SBE)에 **no-op**.
    _bx = np.zeros((0, 3)); _br0 = np.zeros(0)
    #  ⓐ 기본값 off = 바이트 동일 (생산 규약 불변)
    #  ⚠ 좌표는 **찾아서** 넣은 것이다 — 임의의 접촉쌍은 대개 그냥 이어져서 ⓑ 가 거저
    #    통과한다 (초판이 그랬다: 성분 1 → 1).  이 둘은 **정확히 접하는데**(중심거리 =
    #    직경 0.30) 평범한 래스터가 **끊는** 실제 배치다 = 측정한 35 % 누락의 한 표본.
    _pB = np.array([[1.543747, 1.664973, 1.512001],
                    [1.395702, 1.407554, 1.554648]])
    _phB = np.array([5, 5], np.int8)
    _s_off, _ = rasterize(_bx, _br0, None, _pB, _phB, (0, 0, 0), (3., 3., 3.), 0.15,
                          sdcp_sphere_d_um=0.30)
    _s_off2, _ = rasterize(_bx, _br0, None, _pB, _phB, (0, 0, 0), (3., 3., 3.), 0.15,
                           sdcp_sphere_d_um=0.30, sdcp_bridge_um=0.0)
    _e1 = bool((_s_off == _s_off2).all())
    ok &= _e1
    print(f"sdcp-bridge-off: 기본 0.0 은 **바이트 동일** (생산 규약 불변)  {'OK' if _e1 else 'FAIL'}")
    #  ★★★ 2026-08-25 (배터리가 잡음) — 위 시험은 **약하다**: `기본` 과 `명시 0.0` 은
    #    **같은 값**이라, 가드 `> 0.0` 을 `>= 0.0` 으로 바꿔 브리지가 0.0 에서도 돌게 해도
    #    두 팔이 똑같이 돌아 **차이가 안 난다** (실측 `★놓침★`).  즉 그 시험은
    #    "기본값이 0.0 이다" 를 볼 뿐 **"0.0 은 곧 off 다"** 를 안 본다.
    #  ⚠ 그리고 그것은 시험만의 문제가 아니었다 — tol=0.0 이어도 `query_pairs(2r+0)` 은
    #    **겹치는 쌍**(중심거리 < 직경)을 잡는다.  즉 0.0 을 off 로 만드는 것은 오직
    #    저 가드 한 줄이고, 그 줄을 지키는 시험이 없었다.
    #  ⇒ 코드 경로가 아니라 **불변식**을 본다: tol = 0.0 이면 SDCP 셀은 두 구의
    #    center-in-sphere 합집합과 **정확히 같아야 한다** (브리지 셀이 하나도 없다).
    #    픽스처는 일부러 **겹치는** 쌍이다 — 안 겹치면 변이판도 아무것도 안 찍어 또 못 본다.
    #  ⚠⚠ 좌표는 **찾아서** 넣은 것이다.  깊게 겹친 쌍(중심거리 0.28)으로 먼저 짰다가
    #    변이판에서도 차이가 **0 셀**이었다 — 목 반경 `1.2·vox` 볼이 이미 두 구가 덮은
    #    셀만 덮어서다 (`_brg` 는 1개로 잡히는데 `_ball_empty` 가 빈 셀을 못 찾는다).
    #    ⇒ **아슬아슬하게 겹치는** 쌍(0.2995)이어야 목이 비어 있어 변이가 보인다.
    #    3,000 회 무작위 탐색으로 찾은 배치이고, 변이판과 **4 셀** 차이가 난다.
    _oc0 = np.array([1.540768, 1.556228, 1.614936])
    _oc1 = np.array([1.347803, 1.443555, 1.415513])
    _s_ov, _ = rasterize(_bx, _br0, None, np.vstack([_oc0, _oc1]),
                         np.array([5, 5], np.int8), (0, 0, 0), (3., 3., 3.), 0.15,
                         sdcp_sphere_d_um=0.30, sdcp_bridge_um=0.0)
    _ns = _s_ov.shape
    _axs = [(np.arange(_k) + 0.5) * 0.15 for _k in _ns]
    _gx, _gy, _gz = np.meshgrid(*_axs, indexing='ij')
    _ccv = np.stack([_gx, _gy, _gz], -1)
    _pure = ((((_ccv - _oc0) ** 2).sum(-1) <= 0.15 ** 2)
             | (((_ccv - _oc1) ** 2).sum(-1) <= 0.15 ** 2))
    _e1b = bool(((_s_ov == 5) == _pure).all())
    ok &= _e1b
    print(f"sdcp-bridge-zero-is-off: tol 0 이면 **겹치는 쌍에도** 브리지 셀 0 "
          f"(구 합집합과 정확히 일치)  {'OK' if _e1b else 'FAIL'}")

    #  ⓑ 끊긴 두 구를 잇는다 — 6-면 인접 성분 수가 2 → 1
    def _ncomp(sid_, want):
        """6-면 인접 기준 연결성분 수 (want 인 셀만)."""
        m = (sid_ == want)
        seen = np.zeros_like(m); nc = 0
        idx = list(zip(*np.nonzero(m)))
        pos = set(idx)
        for st in idx:
            if seen[st]:
                continue
            nc += 1; stack = [st]; seen[st] = True
            while stack:
                a, b, c = stack.pop()
                for da, db, dc in ((1,0,0),(-1,0,0),(0,1,0),(0,-1,0),(0,0,1),(0,0,-1)):
                    q = (a+da, b+db, c+dc)
                    if q in pos and not seen[q]:
                        seen[q] = True; stack.append(q)
        return nc
    _s_on, _ = rasterize(_bx, _br0, None, _pB, _phB, (0, 0, 0), (3., 3., 3.), 0.15,
                         sdcp_sphere_d_um=0.30, sdcp_bridge_um=0.08)
    _n_off, _n_on = _ncomp(_s_off, 5), _ncomp(_s_on, 5)
    _e2 = (_n_off > _n_on) and (_n_on == 1)
    ok &= _e2
    print(f"sdcp-bridge-connect: 끊긴 접촉을 잇는다 (성분 {_n_off} → {_n_on})  "
          f"{'OK' if _e2 else 'FAIL'}")

    #  ⓒ 이미 배정된 상을 **강등하지 않는다** — 브리지는 빈 셀에만 들어간다
    #     (SDCP–AM 브리지의 sid 는 series-conservative 로 AM 인데, 그것이 SDCP·VGCF 셀을
    #      덮으면 인위적 손실이 된다.)
    _amc = np.array([[1.60, 1.00, 1.00]]); _amr = np.array([0.25]); _amt = np.array([2], np.int8)
    _pC = np.array([[1.20, 1.00, 1.00]]); _phC = np.array([5], np.int8)
    _s_n, _ = rasterize(_amc, _amr, _amt, _pC, _phC, (0, 0, 0), (3., 3., 3.), 0.15,
                        sdcp_sphere_d_um=0.30)
    _s_b, _ = rasterize(_amc, _amr, _amt, _pC, _phC, (0, 0, 0), (3., 3., 3.), 0.15,
                        sdcp_sphere_d_um=0.30, sdcp_bridge_um=0.08)
    _lost = int(((_s_n != 0) & (_s_b != _s_n)).sum())
    _e3 = (_lost == 0)
    ok &= _e3
    print(f"sdcp-bridge-no-downgrade: 배정된 셀을 안 덮는다 (덮은 셀 {_lost})  "
          f"{'OK' if _e3 else 'FAIL'}")

    #  ⓓ SDCP 가 없는 침대(SBE)에는 **no-op** — CL-33 음성 대조와 같은 증인
    _pD = np.array([[1.0, 1.0, 1.0], [1.2, 1.0, 1.0]]); _phD = np.array([2, 3], np.int8)
    _d0, _ = rasterize(_bx, _br0, None, _pD, _phD, (0, 0, 0), (3., 3., 3.), 0.15,
                       sdcp_sphere_d_um=0.30)
    _d1, _ = rasterize(_bx, _br0, None, _pD, _phD, (0, 0, 0), (3., 3., 3.), 0.15,
                       sdcp_sphere_d_um=0.30, sdcp_bridge_um=0.08)
    _e4 = bool((_d0 == _d1).all())
    ok &= _e4
    print(f"sdcp-bridge-sbe-noop: SDCP 없는 침대에 셀 단위 no-op  {'OK' if _e4 else 'FAIL'}")

    #  ⓔ ★ **fail-closed** — 점 스탬프 + 브리지 요청은 **거부**한다 (2026-08-27).
    #     이 검사가 없어서 A 트랙 4팔이 무효가 됐다: 킷이 `SDCP_SPHERE_D` 를 안 넘겨
    #     구 스탬프가 꺼진 채로 `--step3-sdcp-bridge 0.08` 만 걸렸고, 옛 가드가
    #     `if sdcp_sphere_d_um and ...` 였던 탓에 **처리팔 = 대조팔**이 나왔다.
    #     세 갈래를 다 문다 — 거부 · 기본값 무해 · 정상 조합 통과.
    def _raises(**kw):
        try:
            rasterize(_bx, _br0, None, _pD, _phD, (0, 0, 0), (3., 3., 3.), 0.15, **kw)
            return False
        except ValueError:
            return True
    _e5a = _raises(sdcp_bridge_um=0.08)                              # 점 스탬프 + 브리지 → 거부
    _e5b = not _raises(sdcp_bridge_um=0.0)                           # 기본 off → 통과 (바이트 동일 보존)
    _e5c = not _raises(sdcp_sphere_d_um=0.30, sdcp_bridge_um=0.08)   # 정상 조합 → 통과
    _e5 = _e5a and _e5b and _e5c
    ok &= _e5
    print(f"sdcp-bridge-failclosed: 점 스탬프+브리지 거부 (거부 {_e5a} · 기본 {_e5b} · 정상 {_e5c})  "
          f"{'OK' if _e5 else 'FAIL'}")

    # ── ★ G2 (D13 원장 ②) — PTFE 이온 차단 노브 `ptfe_block_um` ──────────────────────
    #   계약 7개: ⓐ 기본 off = 바이트 동일 ⓑ 0.0 = off (변환 0 셀) ⓒ 반경이 셀 수를
    #   정확히 정한다 (face 6 / +edge 18) ⓓ **SE(6)만** 바꾼다 ⓔ PTFE 없는 침대 no-op
    #   ⓕ σ/k 표의 sid 9 규약 ⓖ end-to-end: 차단이 실제 이온 솔브 σ 를 낮춘다.
    #   픽스처: 5×5×5 SE 블록(셀 중심점) 가운데에 PTFE 점 1개 (vox 0.15).
    _seA = np.stack(np.meshgrid(*[(np.arange(8, 13) + 0.5) * 0.15] * 3,
                                indexing='ij'), -1).reshape(-1, 3)
    _pP = np.array([[(10 + 0.5) * 0.15] * 3]); _phP = np.array([4], np.int8)   # phase 4 = PTFE
    _g_na, _ = rasterize(_bx, _br0, None, _pP, _phP, (0, 0, 0), (3., 3., 3.), 0.15,
                         se_pts=_seA)                                   # 인자 자체를 안 준다
    _g_0, _ = rasterize(_bx, _br0, None, _pP, _phP, (0, 0, 0), (3., 3., 3.), 0.15,
                        se_pts=_seA, ptfe_block_um=0.0)
    _e5a = bool((_g_na == _g_0).all()) and int((_g_0 == 9).sum()) == 0
    ok &= _e5a
    print(f"ptfe-block-off: 기본 = 명시 0.0 = 바이트 동일 · sid9 셀 0  {'OK' if _e5a else 'FAIL'}")
    #  ⓑ+ⓒ 반경 → 셀 수 (셀 중심 유클리드: face 0.15 · edge-diag 0.2121 · corner 0.2598)
    _g_f, _ = rasterize(_bx, _br0, None, _pP, _phP, (0, 0, 0), (3., 3., 3.), 0.15,
                        se_pts=_seA, ptfe_block_um=0.16)
    _g_e, _ = rasterize(_bx, _br0, None, _pP, _phP, (0, 0, 0), (3., 3., 3.), 0.15,
                        se_pts=_seA, ptfe_block_um=0.22)
    _n_f = int((_g_f == 9).sum()); _n_e = int((_g_e == 9).sum())
    _e5b = (_n_f == 6) and (_n_e == 18)
    ok &= _e5b
    print(f"ptfe-block-radius: 0.16µm→face 6 셀 (실측 {_n_f}) · 0.22µm→+edge 18 셀 "
          f"(실측 {_n_e})  {'OK' if _e5b else 'FAIL'}")
    #  ⓓ SE 만 바꾼다 — PTFE 점 주위에 VGCF·SDCP 점과 AM 구를 붙여도 그 셀은 불변.
    #    (변환 전 sid ∈ {6} ∧ 변환 후 sid ∈ {9} 를 **차집합으로** 단언한다.)
    _pM = np.vstack([_pP, [[(11 + 0.5) * 0.15, (10 + 0.5) * 0.15, (10 + 0.5) * 0.15]],
                     [[(10 + 0.5) * 0.15, (11 + 0.5) * 0.15, (10 + 0.5) * 0.15]]])
    _phM = np.array([4, 2, 5], np.int8)                     # PTFE + VGCF + SDCP 이웃
    _amcM = np.array([[(10 + 0.5) * 0.15, (10 + 0.5) * 0.15, (9 + 0.5) * 0.15]])
    _amrM = np.array([0.07]); _amtM = np.array([2], np.int8)
    _m_off, _ = rasterize(_amcM, _amrM, _amtM, _pM, _phM, (0, 0, 0), (3., 3., 3.), 0.15,
                          se_pts=_seA)
    _m_blk, _ = rasterize(_amcM, _amrM, _amtM, _pM, _phM, (0, 0, 0), (3., 3., 3.), 0.15,
                          se_pts=_seA, ptfe_block_um=0.16)
    _chg = _m_off != _m_blk
    _e5c = (_chg.any() and set(np.unique(_m_off[_chg])) == {6}
            and set(np.unique(_m_blk[_chg])) == {9})
    ok &= _e5c
    print(f"ptfe-block-se-only: 바뀐 셀 {int(_chg.sum())} 개 전부 6→9 (도체·pore 불변)  "
          f"{'OK' if _e5c else 'FAIL'}")
    #  ⓔ PTFE 없는 침대 → 셀 단위 no-op (음성 대조)
    _q0, _ = rasterize(_bx, _br0, None, np.zeros((0, 3)), np.zeros(0, np.int8),
                       (0, 0, 0), (3., 3., 3.), 0.15, se_pts=_seA)
    _q1, _ = rasterize(_bx, _br0, None, np.zeros((0, 3)), np.zeros(0, np.int8),
                       (0, 0, 0), (3., 3., 3.), 0.15, se_pts=_seA, ptfe_block_um=0.5)
    _e5d = bool((_q0 == _q1).all())
    ok &= _e5d
    print(f"ptfe-block-noop-no-ptfe: PTFE 없는 침대에 no-op  {'OK' if _e5d else 'FAIL'}")
    #  ⓕ 표 규약 — sid 9 는 이온·전자 **양쪽 0** (감도 훅 sigma_ptfe 를 줘도), 열은 SE.
    _ti = ionic_sigma_table(1.0, 2.0)
    _te = electronic_sigma_table(1., 2., 3., 4., 5., sigma_ptfe=123.0, sigma_swcnt=6.,
                                 sigma_se=7.0)
    _te0 = electronic_sigma_table(1., 2., 3., 4., 5.)
    _tk, _ = thermal_k_table()
    _e5e = (len(_ti) == 10 and _ti[9] == 0.0
            and len(_te) == 10 and _te[9] == 0.0 and _te[6] == 7.0
            and _te0[6] == 0.0                               # 생산 기본: SE 전자 절연 불변
            and len(_tk) == 10 and _tk[9] == _tk[6]
            and SID_NAME.get(9) == 'SE_blk')
    ok &= _e5e
    print(f"ptfe-block-tables: sid9 σ_ion={_ti[9]:g} σ_e={_te[9]:g} (sigma_ptfe=123 에도) · "
          f"k=k_SE · 기본 σ_e(SE)=0  {'OK' if _e5e else 'FAIL'}")
    #  ⓖ end-to-end — SE 기둥 가운데 PTFE 점: 차단을 켜면 이온 σ_eff 가 **엄격히** 준다.
    _seC = np.stack(np.meshgrid((np.arange(5) + 0.5) * 0.15, (np.arange(5) + 0.5) * 0.15,
                                (np.arange(20) + 0.5) * 0.15, indexing='ij'),
                    -1).reshape(-1, 3)
    _pQ = np.array([[(2 + 0.5) * 0.15, (2 + 0.5) * 0.15, (10 + 0.5) * 0.15]])
    _cQ, _ = rasterize(_bx, _br0, None, _pQ, np.array([4], np.int8),
                       (0, 0, 0), (0.75, 0.75, 3.0), 0.15, se_pts=_seC)
    _cB, _ = rasterize(_bx, _br0, None, _pQ, np.array([4], np.int8),
                       (0, 0, 0), (0.75, 0.75, 3.0), 0.15, se_pts=_seC, ptfe_block_um=0.16)
    _tio = ionic_sigma_table(0.0, 1.0)
    _rQ = solve_sigma_z(_cQ, _tio, 0.15, z_top_um=3.0)
    _rB = solve_sigma_z(_cB, _tio, 0.15, z_top_um=3.0)
    _e5f = (_rQ['sigma_eff'] > _rB['sigma_eff'] > 0.0)
    ok &= _e5f
    print(f"ptfe-block-ion-drop: σ_ion {_rQ['sigma_eff']:.4f} → {_rB['sigma_eff']:.4f} "
          f"(차단이 솔브까지 관통)  {'OK' if _e5f else 'FAIL'}")
    #  ── ★ GPU 폴백 fail-closed (`REQUIRE_GPU`, 2026-08-26) ─────────────────────────
    #  ⚠⚠ **2026-08-27 — 옛 판은 GPU 의 "부재"를 전제로 썼고 그래서 공허했다.**
    #    옛 주석: "이 환경엔 CuPy 가 없으므로 GPU_SOLVE=True 면 import 가 실패한다."
    #    그 전제가 참인 곳(CPU 전용 컨테이너)에서는 초록이었지만, **정작 이 가드가 지켜야 할
    #    GPU 기계(kgy)에서는 GPU 로 그냥 풀려서 `_e6a`·`_e6b` 가 둘 다 False = FAIL** 이었다
    #    (실측 2026-08-27, W4 착수 전 예행에서 잡힘).  검사가 필요한 자리에서만 안 도는 것은
    #    false-green 의 환경판이다 (CDXIJ-4/9 가 매체에서 겪은 것과 같은 부류).
    #    ⇒ **부재에 기대지 않는다.**  `sys.modules['cupy'] = None` 로 import 를 강제로 실패시켜
    #      GPU 유무와 무관하게 **같은 경로**를 타게 한다.  (`import cupy as cp` 가 GPU 분기의
    #      첫 줄이므로 이 하나로 충분하다.)
    #    ⚠ **잔여 한계 (원리적)**: 주입을 지워도 CPU 전용 기계에서는 여전히 초록이다 —
    #      거기선 cupy 가 원래 없어서 "주입이 작동함" 과 "cupy 가 없음" 을 구분할 수 없다.
    #      ⇒ 이 시험의 **비공허성은 GPU 기계에서만 검증된다**.  W4 급 런 전 예행에
    #      `~/dem-venv/bin/python3 …/step3_sigma.py --selftest` 를 GPU 호스트에서 돌리는 것이
    #      그 검증이고, 2026-08-27 에 실제로 그 자리에서 결함이 잡혔다.
    global GPU_SOLVE, REQUIRE_GPU
    _g0, _r0 = GPU_SOLVE, REQUIRE_GPU
    _La = sparse.diags([2.0, 2.0]).tocsr(); _ba = np.array([1.0, 1.0])
    import sys as _sys
    _ABSENT = object()
    _cupy_saved = _sys.modules.get('cupy', _ABSENT)
    _sys.modules['cupy'] = None                     # → `import cupy` 가 ImportError (결정적)
    try:
        GPU_SOLVE, REQUIRE_GPU = True, False
        _x, _i = _solve_cg(_La, _ba)                    # 폴백 허용 → CPU 로 푼다
        _e6a = (LAST_BACKEND['used'] == 'cpu' and LAST_BACKEND['fallback_reason'] is not None
                and np.allclose(_x, 0.5))
        GPU_SOLVE, REQUIRE_GPU = True, True
        try:
            _solve_cg(_La, _ba)                         # 폴백 금지 → 즉시 중단해야 한다
            _e6b = False
        except SystemExit as _se:
            _e6b = 'require-gpu' in str(_se) or 'GPU' in str(_se)
        GPU_SOLVE, REQUIRE_GPU = False, True
        _x2, _ = _solve_cg(_La, _ba)                    # GPU 미요청이면 가드가 안 문다
        _e6c = np.allclose(_x2, 0.5)
    finally:
        GPU_SOLVE, REQUIRE_GPU = _g0, _r0
        #  cupy 를 원래대로 — 막아 둔 채 두면 **이후 모든 GPU 솔브가 조용히 CPU 로 떨어진다**
        #  (이 함수가 프로덕션 프로세스 안에서 불릴 수 있다).  부재였으면 부재로 되돌린다.
        if _cupy_saved is _ABSENT:
            _sys.modules.pop('cupy', None)
        else:
            _sys.modules['cupy'] = _cupy_saved
    #  ★★ 기본값 계약 — 세 하위시험이 값을 **명시로** 덮으므로 기본값 경로를 안 지난다
    #    (브리지 `sdcp-bridge-zero-is-off` 와 같은 부류: 배터리가 잡았다).  ⇒ 직접 단언한다.
    #    `_r0` 는 selftest 진입 시점 값 = 모듈 기본값 (그 전에 아무도 안 바꾼다).
    _e6d = (_r0 is False)
    _all6 = _e6a and _e6b and _e6c and _e6d
    ok &= _all6
    print(f"require-gpu: 폴백 허용 시 CPU 로 푼다 ({_e6a}) · **금지 시 즉시 중단** ({_e6b}) · "
          f"GPU 미요청이면 무해 ({_e6c}) · **기본 = 폴백 허용** ({_e6d}, 웹앱·CPU 환경 불변)  "
          f"{'OK' if _all6 else 'FAIL'}")

    #  ⓗ 주기 wrap (펠릿 RVE 전용) — x 경계의 PTFE 가 **반대편 끝** SE 를 wrap 거리로
    #    차단한다.  비주기에서는 같은 배치가 (실거리 > 반경이라) 아무것도 안 바꾼다.
    _wp = np.full((8, 4, 4), 6, np.int8); _wp[0, 1, 1] = 7
    _wq = _wp.copy()
    _nw = apply_ptfe_blocking(_wp, 0.15, 0.16, periodic_xy=True)     # x wrap: 7↔끝 셀 거리 0.15
    _nn = apply_ptfe_blocking(_wq, 0.15, 0.16, periodic_xy=False)
    _e5g = (_wp[7, 1, 1] == 9) and (_wq[7, 1, 1] == 6) and _nw > _nn
    ok &= _e5g
    print(f"ptfe-block-periodic: x-wrap 반대편 셀 차단 (주기 {_nw} > 비주기 {_nn} 셀)  "
          f"{'OK' if _e5g else 'FAIL'}")

    # ── σ-치환 판별 팔 (CL-43) — `sdcp_yield_to_vgcf` ────────────────────────────────
    #   ① VGCF 와 겹친 SDCP 셀은 sid 3 으로 남고, ② 안 겹친 SDCP 셀은 그대로 sid 5 이며,
    #   ③ 기본값(False)은 **비트 단위로 옛 거동**이어야 한다 (생산 규약 불변).
    _C1 = np.array([[1.0, 1.0, 1.0]]); _C2 = np.array([[2.0, 2.0, 2.0]])
    _pp = np.vstack([_C1, _C1, _C2]); _phy = np.array([2, 5, 5], np.int8)   # 2=VGCF, 5=SDCP
    _i1 = tuple((np.array([1., 1., 1.]) / 0.15).astype(int))
    _i2 = tuple((np.array([2., 2., 2.]) / 0.15).astype(int))
    for _sd in (0.0, 0.30):                                    # 점 스탬프 · 구 스탬프 둘 다
        _sA, _ = rasterize(np.zeros((0, 3)), np.zeros(0), None, _pp, _phy,
                           (0, 0, 0), (3., 3., 3.), 0.15, sdcp_sphere_d_um=_sd)
        _sB, _ = rasterize(np.zeros((0, 3)), np.zeros(0), None, _pp, _phy,
                           (0, 0, 0), (3., 3., 3.), 0.15, sdcp_sphere_d_um=_sd,
                           sdcp_yield_to_vgcf=True)
        _e1 = (_sA[_i1] == 5) and (_sB[_i1] == 3)              # ① 겹친 셀: 덮음 → 양보
        _e2 = (_sA[_i2] == 5) and (_sB[_i2] == 5)              # ② 안 겹친 셀: 둘 다 SDCP
        _e3 = int((_sB == 5).sum()) < int((_sA == 5).sum())    # SDCP 셀이 실제로 줄었다
        ok &= (_e1 and _e2 and _e3)
        print(f"sdcp-yield-vgcf ({'구' if _sd else '점'}): 겹친 셀만 VGCF 로 남는다  "
              f"{'OK' if (_e1 and _e2 and _e3) else 'FAIL'}")
    #  ★ 기본값 회귀 — 이 인자를 안 주면 배열이 **완전히 동일**해야 한다
    _sD1, _ = rasterize(np.zeros((0, 3)), np.zeros(0), None, _pp, _phy,
                        (0, 0, 0), (3., 3., 3.), 0.15, sdcp_sphere_d_um=0.30)
    _sD2, _ = rasterize(np.zeros((0, 3)), np.zeros(0), None, _pp, _phy,
                        (0, 0, 0), (3., 3., 3.), 0.15, sdcp_sphere_d_um=0.30,
                        sdcp_yield_to_vgcf=False)
    _ed = bool((_sD1 == _sD2).all())
    ok &= _ed
    print(f"sdcp-yield-default: 기본값은 옛 거동과 셀 단위 동일  {'OK' if _ed else 'FAIL'}")
    #  ── ★★★ CDXR3-6 (2026-08-25) — **플레이트가 절연 고체를 관통하지 않는다** ──────────
    #    옛 판은 `cond`(σ>0) 로 표면 복셀을 골라, 표면에 절연 **고체**가 있어도 건너뛰고
    #    그 아래 도체를 플레이트에 직접 붙였다.  실측 재현: 표면 PTFE 기둥의 σ_eff 가
    #    **위가 공극인 기둥과 완전히 같았다** — 절연체가 없는 것과 구분되지 않았다.
    #    ⇒ 가장 바깥 **점유 고체**를 먼저 정하고 그것이 도체일 때만 결합한다.
    #    ⚠ 공극 갭은 그대로다 (band 담당).  절연 **고체** 통과만 막는다.
    _pv, _psig = 0.15, np.zeros(9)
    _psig[1] = 0.010
    def _pcol(top_sid):
        _a = np.zeros((3, 3, 4), np.int8)
        _a[:, :, 0:3] = 1
        if top_sid:
            _a[:, :, 3] = top_sid
        return solve_sigma_z(_a, _psig, _pv, z_top_um=4 * _pv, z_bot_um=0.0)['sigma_eff']
    _blk_ptfe = _pcol(7)            # 표면 PTFE (절연 고체)
    _blk_se = _pcol(6)              # 표면 SE — 전자 솔브에서 σ=0 = 역시 절연 고체
    _open_pore = _pcol(0)           # 위가 공극 (양성 대조 — 막히면 안 된다)
    _all_cond = _pcol(1)            # 전부 도체 (양성 대조)
    _p1 = _blk_ptfe == 0.0
    ok &= _p1
    print(f"plate-blocker(PTFE): 표면 절연 고체는 플레이트 접촉을 **막는다** "
          f"(σ={_blk_ptfe:g})  {'OK' if _p1 else 'FAIL'}")
    _p2 = _blk_se == 0.0
    ok &= _p2
    print(f"plate-blocker(SE): 전자 솔브에서 SE 도 절연 고체다 (σ={_blk_se:g})  "
          f"{'OK' if _p2 else 'FAIL'}")
    _p3 = _open_pore > 0 and abs(_open_pore - _all_cond) < 1e-12
    ok &= _p3
    print(f"plate-poregap: 공극 갭은 **막지 않는다** (양성 대조: {_open_pore:g} == "
          f"{_all_cond:g})  {'OK' if _p3 else 'FAIL'}")
    #  ★ 단조성 — 절연 표면을 씌우면 σ 는 **오를 수 없다** (Rayleigh).  옛 판은 이것이
    #    깨져 있었다 (씌워도 같았다 = 절연체가 무시됐다).
    _p4 = _blk_ptfe <= _all_cond and _blk_se <= _all_cond
    ok &= _p4
    print(f"plate-monotone: 절연 표면이 σ 를 올리지 않는다  {'OK' if _p4 else 'FAIL'}")

    #  ── ★★★ CDXR2-1 (2026-08-25) — **소산 분담이 자기 항등식을 만족한다** ──────────────
    #    `phase_current_share` docstring 은 이 분담이 변분 정리로
    #    `w_a = ∂ln σ_eff/∂ln σ_a` 와 **같은 양**이라고 단언한다.  그러려면 σ_a 에
    #    비례하는 **모든** conductance 가 합에 들어가야 하는데, 솔버의 플레이트 커플링
    #    (`g = σ·vox²/dist`) 이 빠져 있었다 = 항등식 불성립.
    #    ⚠ **같은 결함의 2회차** — Codex #7 이 이미 주기 seam 누락을 잡았다.
    #    ⚠ `sum(shares) == 1` 로는 **못 잡는다** (옛 판도 1 이었다).  판별은 centered-log
    #      유한차분이고, 그것이 이 검사다.
    _cid = np.zeros((1, 1, 3), np.int8)
    _cid[0, 0, 0] = 1
    _cid[0, 0, 1] = 2
    _cid[0, 0, 2] = 2

    def _cs(_sa, _sb):
        _sg = np.zeros(9)
        _sg[1], _sg[2] = _sa, _sb
        return _sg

    def _sigeff(_sa, _sb):
        return solve_sigma_z(_cid, _cs(_sa, _sb), 1.0, z_top_um=3.0, z_bot_um=0.0)['sigma_eff']

    _r3 = solve_sigma_z(_cid, _cs(1.0, 10.0), 1.0, return_field=True,
                        z_top_um=3.0, z_bot_um=0.0)
    _sh3 = phase_current_share(_r3, _cid, _cs(1.0, 10.0), periodic_xy=False)
    #  해석해 (Codex 반례): 직렬 1 + 2 개의 10 → plate 포함 로그미분 share = (5/6, 1/6).
    #  옛 internal-only 판은 (10/13, 3/13) 을 냈고 **합은 양쪽 다 1** 이었다.
    _i1 = abs(_sh3.get(1, 0) - 5.0 / 6.0) < 1e-6 and abs(_sh3.get(2, 0) - 1.0 / 6.0) < 1e-6
    ok &= _i1
    print(f"plate-share-analytic: 3-cell 직렬 반례가 해석해 (5/6, 1/6) 과 일치 "
          f"(A={_sh3.get(1, 0):.6f} B={_sh3.get(2, 0):.6f})  {'OK' if _i1 else 'FAIL'}")
    #  ★ 옛 값과 **구분되는가** — 이 검사가 판별력을 갖는지 자기증명.
    _i2 = abs(_sh3.get(1, 0) - 10.0 / 13.0) > 1e-3
    ok &= _i2
    print(f"plate-share-discriminates: 옛 internal-only 값(10/13)과 구분된다  "
          f"{'OK' if _i2 else 'FAIL'}")
    #  ★★ centered-log 유한차분 항등식 (σ 비례 항이 **하나라도** 빠지면 깨진다)
    import math
    _h = 1e-4
    _fdA = (math.log(_sigeff(math.exp(_h), 10.0)) - math.log(_sigeff(math.exp(-_h), 10.0))) / (2 * _h)
    _fdB = (math.log(_sigeff(1.0, 10.0 * math.exp(_h))) - math.log(_sigeff(1.0, 10.0 * math.exp(-_h)))) / (2 * _h)
    _i3 = abs(_fdA - _sh3.get(1, 0)) < 1e-5 and abs(_fdB - _sh3.get(2, 0)) < 1e-5
    ok &= _i3
    print(f"plate-share-identity: w_a = d ln σ_eff/d ln σ_a 유한차분과 일치 "
          f"(A {_fdA:.6f} B {_fdB:.6f})  {'OK' if _i3 else 'FAIL'}")

    #  ── ★★★ Codex 재리뷰 조건 6 (2026-08-25) — plate 회귀 4종 ────────────────────────
    #    초판 회귀는 **윗판만·vox=1 만·`solve_sigma_z` 만** 봤다.  아래 넷은 각각
    #    그 사각지대다 (Codex: "아래판 분기 · 반응 솔버 · 비단위 vox FD · 원장 부재").

    #  ⓐ **아래판** 분기 — 위와 대칭인 코드가 따로 있어 따로 깨질 수 있다.
    def _pcol_bot(bot_sid):
        _a = np.zeros((3, 3, 4), np.int8)
        _a[:, :, 1:4] = 1
        if bot_sid:
            _a[:, :, 0] = bot_sid
        return solve_sigma_z(_a, _psig, _pv, z_top_um=4 * _pv, z_bot_um=0.0)['sigma_eff']
    _b_ptfe, _b_se, _b_pore = _pcol_bot(7), _pcol_bot(6), _pcol_bot(0)
    _q1 = _b_ptfe == 0.0 and _b_se == 0.0
    ok &= _q1
    print(f"plate-blocker-bottom: **아래판** 표면 절연 고체도 막는다 "
          f"(PTFE {_b_ptfe:g} · SE {_b_se:g})  {'OK' if _q1 else 'FAIL'}")
    _q2 = _b_pore > 0 and abs(_b_pore - _all_cond) < 1e-12
    ok &= _q2
    print(f"plate-poregap-bottom: 아래 공극 갭은 막지 않는다 (양성 대조 {_b_pore:g})  "
          f"{'OK' if _q2 else 'FAIL'}")

    #  ⓑ **반응 솔버** — 같은 규약이 두 번째 자리에도 걸려 있는가.
    #     전자망 아래판이 절연 고체로 막히면 접점이 없어 `no_plate_contact` 여야 한다.
    def _rxn_bot(bot_sid):
        _a = np.zeros((3, 3, 5), np.int8)
        _a[:, :, 1:4] = 1               # AM (전자 도체)
        _a[:, :, 4] = 6                 # 위는 SE (이온 도체)
        if bot_sid:
            _a[:, :, 0] = bot_sid
        _se = np.zeros(9); _se[1] = 0.010          # 전자: AM 만
        _si = np.zeros(9); _si[6] = 0.001          # 이온: SE 만
        _pid = np.where(_a == 1, 0, -1).astype(np.int32)   # 규약: AM 은 입자 0, 나머지 -1
        return solve_reaction_current(_a, _se, _si, _pid, 1, _pv, 1,
                                      z_top_um=5 * _pv, z_bot_um=0.0)
    _rx_blk = _rxn_bot(7)               # 아래 표면 PTFE = 절연 고체
    _rx_open = _rxn_bot(0)              # 아래가 공극 (양성 대조)
    _q3 = 'no_plate_contact' in str(_rx_blk.get('reason') or '')
    ok &= _q3
    print(f"plate-blocker-rxn: **반응 솔버**도 절연 고체를 관통하지 않는다 "
          f"(reason={_rx_blk.get('reason')})  {'OK' if _q3 else 'FAIL'}")
    _q4 = not str(_rx_open.get('reason') or '').startswith('no_plate_contact')
    ok &= _q4
    print(f"plate-rxn-poregap: 아래 공극은 반응 솔버에서 막지 않는다 (양성 대조) "
          f"{'OK' if _q4 else 'FAIL'}")

    #  ⓒ **비단위 vox** FD 항등식 — 플레이트 g 는 `σ·vox²/dist` 라 vox 인자를 빠뜨려도
    #     vox=1 에서는 **안 보인다**.  초판 회귀가 정확히 vox=1 뿐이었다.
    _vv = 0.15
    def _sigeff_v(_sa, _sb):
        return solve_sigma_z(_cid, _cs(_sa, _sb), _vv,
                             z_top_um=3 * _vv, z_bot_um=0.0)['sigma_eff']
    _r3v = solve_sigma_z(_cid, _cs(1.0, 10.0), _vv, return_field=True,
                         z_top_um=3 * _vv, z_bot_um=0.0)
    _sh3v = phase_current_share(_r3v, _cid, _cs(1.0, 10.0), periodic_xy=False)
    _fdAv = (math.log(_sigeff_v(math.exp(_h), 10.0))
             - math.log(_sigeff_v(math.exp(-_h), 10.0))) / (2 * _h)
    _fdBv = (math.log(_sigeff_v(1.0, 10.0 * math.exp(_h)))
             - math.log(_sigeff_v(1.0, 10.0 * math.exp(-_h)))) / (2 * _h)
    _q5 = abs(_fdAv - _sh3v.get(1, 0)) < 1e-5 and abs(_fdBv - _sh3v.get(2, 0)) < 1e-5
    ok &= _q5
    print(f"plate-share-identity-vox: **vox={_vv}** 에서도 항등식이 성립한다 "
          f"(A {_fdAv:.6f}/{_sh3v.get(1, 0):.6f} B {_fdBv:.6f}/{_sh3v.get(2, 0):.6f})  "
          f"{'OK' if _q5 else 'FAIL'}")

    #  ── ★★★ R3-CX-07 (Codex 3차) — **sid × 면 × 솔버 매개변수화** ────────────────────
    #    초판 회귀는 top-PTFE·bottom-PTFE 두 점뿐이었다.  Codex 가 남은 구멍 셋을 냈다:
    #      · 반응 솔버의 **ionic-top** 만 옛 규약으로 되돌려도 통과 (내 fixture 는
    #        bottom-electronic 만 봤다) — top PTFE 가 pore 와 **같은 I** 로 관통했다.
    #      · occupied surface 에서 **sid 5(SDCP)** 만 제외해도 통과 (균일 SDCP column 이
    #        σ 0.01 → 0, AM|SDCP 반응이 I 7.71e-4 → 0 이 되는데 아무도 안 본다).
    #      · 슬래브 **밖** 셀이 signed band 로 접촉이 됐다.
    #    ⇒ 상(相) × 면 × 두 솔버를 표로 돌린다.  새 상이 생기면 여기 한 줄이다.
    _PHASE_SIG = {1: 0.010, 2: 0.0, 3: 100.0, 4: 5.0, 5: 250.0, 6: 0.0, 7: 0.0, 8: 0.0,
                  9: 0.0}                                  # 9 = SE_blk (G2, 양망 절연)
    #   상 이름 (진단 메시지용) — 전자 솔브 기준 도체/절연.  ★ SID_NAME(단일 소스)에서
    #   유도한다: 지역 사본이 sid 9 신설 때 뒤처져 **위반 보고 중** KeyError 로 죽었다
    #   (2026-08-25 배터리 CX-07① HARNESS_ERROR — 시험이 잡고도 보고에서 넘어진 사례).
    _PHASE_NM = {_s: (_n if _PHASE_SIG.get(_s, 0.0) > 0 else f'{_n}(σ=0)')
                 for _s, _n in SID_NAME.items()}

    def _col_side(surf_sid, side, vox=0.15):
        """도체 기둥의 `side` 표면에 `surf_sid` 를 얹고 σ_eff.  0 이면 pore(갭)."""
        _a = np.zeros((3, 3, 5), np.int8)
        _a[:, :, 1:4] = 1
        if surf_sid:
            _a[:, :, 4 if side == 'top' else 0] = surf_sid
        _sg = np.zeros(1 + max(_PHASE_SIG))            # 표 길이 = 상 등재의 함수 (sid 9 포함)
        for _k, _v in _PHASE_SIG.items():
            _sg[_k] = _v
        return solve_sigma_z(_a, _sg, vox, z_top_um=5 * vox, z_bot_um=0.0)['sigma_eff']

    #  ★ **균일 기둥** — 상 하나만으로 된 기둥이 그 상의 도체성대로 도는가.
    #    Codex R3-CX-07 ②: occupied surface 에서 `sid 5`(SDCP) 만 제외해도 위 표는
    #    통과한다 (표면 아래에 AM 이 있어 `k_last` 가 그리로 내려간다).  **균일 기둥**은
    #    내려갈 곳이 없어 σ 0.01 → 0 이 되고, 그것이 이 결함의 유일한 증인이다.
    def _col_uniform(sd, vox=0.15):
        _a = np.full((3, 3, 5), sd, np.int8)
        _sg = np.zeros(1 + max(_PHASE_SIG))            # 표 길이 = 상 등재의 함수 (sid 9 포함)
        for _k, _v in _PHASE_SIG.items():
            _sg[_k] = _v
        return solve_sigma_z(_a, _sg, vox, z_top_um=5 * vox, z_bot_um=0.0)['sigma_eff']
    _uni_bad = [f'{_PHASE_NM[_sd]}: σ={_col_uniform(_sd):g}' for _sd in sorted(_PHASE_SIG)
                if (_PHASE_SIG[_sd] > 0) != (_col_uniform(_sd) > 0)]
    ok &= not _uni_bad
    print(f"plate-uniform-column: 상 {len(_PHASE_SIG)} 개의 **균일 기둥**이 각자의 "
          f"도체성대로 돈다 (occupied surface 에서 한 상만 빠져도 여기서 걸린다)  "
          f"{'OK' if not _uni_bad else 'FAIL ' + str(_uni_bad)}")

    _open = _col_side(0, 'top')                 # 양성 대조 = 갭
    _pgrid_bad = []
    for _sd in sorted(_PHASE_SIG):
        _is_cond = _PHASE_SIG[_sd] > 0
        for _side in ('top', 'bot'):
            _sv = _col_side(_sd, _side)
            #  도체 표면 → 접촉해야 한다 (σ > 0) · 절연 표면 → 막아야 한다 (σ == 0)
            if _is_cond and not _sv > 0:
                _pgrid_bad.append(f'{_PHASE_NM[_sd]}/{_side}: 도체인데 σ={_sv:g} (막혔다)')
            if (not _is_cond) and _sv != 0.0:
                _pgrid_bad.append(f'{_PHASE_NM[_sd]}/{_side}: 절연인데 σ={_sv:g} (관통했다)')
    ok &= not _pgrid_bad
    print(f"plate-phase-grid: 상 {len(_PHASE_SIG)} × 면 2 = {2 * len(_PHASE_SIG)} 조합이 "
          f"도체/절연 규약을 지킨다 (갭 대조 σ={_open:g})  "
          f"{'OK' if not _pgrid_bad else 'FAIL ' + str(_pgrid_bad[:3])}")

    #  ★ 반응 솔버: **두 면 다** — 전자망은 아래판, 이온망은 위판.
    def _rxn_side(surf_sid, side, vox=0.15):
        _a = np.zeros((3, 3, 6), np.int8)
        _a[:, :, 1:4] = 1                       # AM (전자망)
        _a[:, :, 4] = 6                         # SE (이온망)
        _a[:, :, 5 if side == 'top' else 0] = surf_sid
        _se = np.zeros(9); _se[1] = 0.010
        _si = np.zeros(9); _si[6] = 0.001
        _pid = np.where(_a == 1, 0, -1).astype(np.int32)
        return solve_reaction_current(_a, _se, _si, _pid, 1, vox, 1,
                                      z_top_um=6 * vox, z_bot_um=0.0)

    _rgrid_bad = []
    for _side, _lbl in (('bot', '전자망 아래판'), ('top', '이온망 위판')):
        _blk = _rxn_side(7, _side)              # PTFE = 두 망 모두 절연
        _opn = _rxn_side(0, _side)              # 갭
        if 'no_plate_contact' not in str(_blk.get('reason') or ''):
            _rgrid_bad.append(f'{_lbl}: 절연 표면이 막지 않았다 (I={_blk.get("I_tot")!r})')
        if str(_opn.get('reason') or '').startswith('no_plate_contact'):
            _rgrid_bad.append(f'{_lbl}: 갭이 막혔다 (과잉차단)')
    ok &= not _rgrid_bad
    print(f"plate-rxn-grid: 반응 솔버가 **두 면 다** 절연 고체를 막는다 (갭은 통과)  "
          f"{'OK' if not _rgrid_bad else 'FAIL ' + str(_rgrid_bad)}")

    #  ── ★★★ R4-CX-07 (Codex 4차) — **반응 솔버도 상×면 격자로 본다** ──────────────────
    #    3차의 `plate-rxn-grid` 는 PTFE 와 pore 만 봤다.  그래서 Codex 가 둘을 통과시켰다:
    #      ① reaction 만 `_occ_r=(sid!=0)&(sid!=5)` 로 바꿔 노출 SDCP 를 surface 에서 제거
    #      ② reaction 의 양면 absolute band 만 signed 로 되돌림
    #    상 시험은 `solve_sigma_z` 만 부르고, outside-slab 음성 대조도 `solve_sigma_z`
    #    뿐이라 **반응 분기가 회귀 봉인 밖**이었다 (구현은 옳은데 증인이 없다).
    #    ⇒ 두 망의 도체성이 다르므로 **망별 기대**를 따로 준다.
    #      전자망 도체 = AM(1,2)·carbon(3,4)·SDCP(5) · 이온망 도체 = SE(6)·SDCP(5)
    #  ★★★ 2026-08-25 (R5-CX-09) — 표를 **생산 함수에서** 만든다.  옛 판은 여기서 다시
    #    하드코딩했고, 그래서 sid 8(SWCNT)을 전자·이온 **둘 다 0** 으로 적어 두었다 —
    #    생산 규약은 SWCNT 를 **전자 도체 · 기본 ion-transparent** 로 둔다.  두 곳이 따로
    #    참이면 producer 의 SWCNT 분기가 퇴행해도 이 회귀가 못 잡는다 (Codex 지적).
    #  ⚠ idx 0 은 **기공**이라 상이 아니다 (스탬프 대상이 아니므로 표에서 뺀다).
    _RX_E = {i: v for i, v in enumerate(
        electronic_sigma_table(0.010, 0.010, 100.0, 5.0, 250.0, 0.0, 100.0)) if i}
    _RX_I = {i: v for i, v in enumerate(
        ionic_sigma_table(0.001, 0.001, swcnt_ion_block=False)) if i}
    #  ★ R5-CX-09 — 표가 **생산 규약을 말하는지** 직접 단언한다.  이 두 줄이 없으면
    #    위가 공용 함수를 부르기만 하고 그 함수가 퇴행해도 조용하다.
    _q_sw = (_RX_E[8] > 0 and _RX_I[8] > 0
             and ionic_sigma_table(0.001, 0.001, swcnt_ion_block=True)[8] == 0.0
             and _RX_E[6] == 0.0)
    ok &= _q_sw
    print(f"rxn-table-production: SWCNT(8) 전자도체 σ={_RX_E[8]:g} · 기본 ion-transparent "
          f"σ={_RX_I[8]:g} · `--swcnt-ion-block` 이 끈다 · SE(6) 전자절연  "
          f"{'OK' if _q_sw else 'FAIL'}  (옛 fixture 는 sid 8 을 둘 다 0 으로 하드코딩했다)")

    def _rxn_face(surf_sid, side, vox=0.15):
        """전자 slab(아래) + 이온 slab(위) 사이에 BV.  `side` 표면에 `surf_sid` 를 얹는다."""
        _a = np.zeros((3, 3, 7), np.int8)
        _a[:, :, 1:4] = 1                       # AM (전자망)
        _a[:, :, 4:6] = 6                       # SE (이온망)
        _a[:, :, 6 if side == 'top' else 0] = surf_sid
        _se = np.zeros(1 + max(_RX_E)); _si = np.zeros(1 + max(_RX_I))   # 표 길이 = 생산 함수 소관
        for _k, _v in _RX_E.items():
            _se[_k] = _v
        for _k, _v in _RX_I.items():
            _si[_k] = _v
        _pid = np.where(_a == 1, 0, -1).astype(np.int32)
        return solve_reaction_current(_a, _se, _si, _pid, 1, vox, 1,
                                      z_top_um=7 * vox, z_bot_um=0.0)

    _rxg_bad = []
    for _sd in sorted(_RX_E):
        for _side, _tab, _net in (('bot', _RX_E, '전자망'), ('top', _RX_I, '이온망')):
            _r = _rxn_face(_sd, _side)
            _blocked = 'no_plate_contact' in str(_r.get('reason') or '')
            _is_cond = _tab[_sd] > 0
            if _is_cond and _blocked:
                _rxg_bad.append(f'{_PHASE_NM[_sd]}/{_side}({_net}): 도체인데 막혔다')
            if (not _is_cond) and not _blocked:
                _rxg_bad.append(f'{_PHASE_NM[_sd]}/{_side}({_net}): 절연인데 관통했다 '
                                f'(I={_r.get("I_tot")!r})')
    ok &= not _rxg_bad
    print(f"plate-rxn-phase-grid: 반응 솔버 상 {len(_RX_E)} × 면 2 = {2 * len(_RX_E)} 조합이 "
          f"**망별** 도체/절연 규약을 지킨다  "
          f"{'OK' if not _rxg_bad else 'FAIL ' + str(_rxg_bad[:3])}")

    #  ★★★ R4-CX-07 A — **AM|SDCP 노출면 증인**.  표면에 얹는 시험만으로는 이 부류를
    #    못 잡는다: `_occ_r` 에서 sid5 를 빼도 바로 아래가 AM 이면 `k_first` 가 그리로
    #    내려가 여전히 접촉이다.  ⇒ **판에서 한 셀 멀어지면 band 를 벗어나는** 기하로
    #    짓는다 (vox 0.25 · band = vox+0.10 = 0.35 · zc[1] = 0.375 > band).
    #    그러면 sid5 를 occupancy 에서 빼는 순간 접촉이 사라지고 I 가 0 이 된다.
    #  ⚠ 반응 계면은 `am_m = (sid==1)|(sid==2)` 라 **AM 만** BV 를 만든다 (탄소는 안 만든다,
    #    `solve_reaction_current` §BV).  그래서 증인은 "SDCP 노출 + AM 본체" 여야 한다 —
    #    탄소 균일 slab 은 I=0 이 **정상**이고 그것으로는 이 mutant 를 못 가른다.
    def _rxn_sdcp_face(vox=0.25, occ_sdcp=True):
        _a = np.zeros((3, 3, 8), np.int8)
        _a[:, :, 0] = 5                         # 노출면 = SDCP (전자·이온 양쪽 도체)
        _a[:, :, 1:4] = 1                       # AM 본체 (BV 를 만드는 유일한 상)
        _a[:, :, 4:8] = 6                       # SE (이온망)
        _se = np.zeros(1 + max(_RX_E)); _si = np.zeros(1 + max(_RX_I))   # 표 길이 = 생산 함수 소관
        for _k, _v in _RX_E.items():
            _se[_k] = _v
        for _k, _v in _RX_I.items():
            _si[_k] = _v
        _pid = np.where(_a == 1, 0, -1).astype(np.int32)
        return solve_reaction_current(_a, _se, _si, _pid, 1, vox, 1,
                                      z_top_um=8 * vox, z_bot_um=0.0)
    _rI = (_rxn_sdcp_face().get('I_tot') or 0.0)
    _rA = _rI > 0
    ok &= _rA
    print(f"plate-rxn-sdcp-face: **노출 SDCP** 가 전자망 접점이 된다 (I={_rI:.6g}) — "
          f"occupancy 에서 상 하나만 빼면 이 접점이 사라진다  {'OK' if _rA else 'FAIL'}")

    #  ★ 반응 솔버의 **슬래브 밖** 음성 대조 (양면).  3차에는 `solve_sigma_z` 뿐이었다.
    def _rxn_outside(which, vox=0.25):
        _a = np.zeros((1, 1, 8), np.int8)
        _a[0, 0, 0:4] = 1                       # 전자망 아래
        _a[0, 0, 4:8] = 6                       # 이온망 위
        _se = np.zeros(9); _se[1] = 0.010
        _si = np.zeros(9); _si[6] = 0.001
        _pid = np.where(_a == 1, 0, -1).astype(np.int32)
        #  top: 물리 판을 기둥 한복판에 → 최상단 이온 셀이 판보다 위
        #  bot: 바닥 판을 위로 올려 → 최하단 전자 셀이 판보다 아래
        _zt, _zb = (1.0, 0.0) if which == 'top' else (8 * vox, 1.0)
        return solve_reaction_current(_a, _se, _si, _pid, 1, vox, 1,
                                      z_top_um=_zt, z_bot_um=_zb)
    _rxo_bad = [w for w in ('top', 'bot')
                if 'no_plate_contact' not in str(_rxn_outside(w).get('reason') or '')]
    ok &= not _rxo_bad
    print(f"plate-rxn-outside-slab: 반응 솔버도 물리 판 **밖** 셀을 접촉으로 세지 않는다 "
          f"(위반: {_rxo_bad or '없음'})  {'OK' if not _rxo_bad else 'FAIL'}")

    #  ★ 슬래브 **밖** 셀은 접촉이 아니다 (signed band 결함).
    #    ⚠ 아래판은 정상이고 **위판만** 밖이어야 signed↔abs 가 갈린다 (양쪽 다 밖이면
    #      어느 규약이든 `no_plate_contact` 라 판별력이 없다 — 초판이 그랬다).
    _ta = np.zeros((1, 1, 8), np.int8)
    _ta[0, 0, :] = 1                            # 바닥부터 꽉 찬 도체 기둥
    _tsg = np.zeros(9); _tsg[1] = 0.010
    #    물리 top plane 을 기둥 **한복판**에 둔다 → 최상단 셀은 판보다 한참 위다.
    _tv = solve_sigma_z(_ta, _tsg, 0.25, z_top_um=1.0, z_bot_um=0.0)
    _q7b = (_tv['sigma_eff'] == 0.0) and 'no_plate_contact' in str(_tv.get('reason') or '')
    ok &= _q7b
    print(f"plate-top-above-plane: 물리 top plane 보다 **위**인 최상단 셀은 접촉이 아니다 "
          f"(σ={_tv['sigma_eff']:g})  {'OK' if _q7b else 'FAIL'}")
    #  ★ 대칭 — 물리 bottom plane 보다 **아래**인 최하단 셀도 접촉이 아니다.
    #    (위판만 시험하면 아래판 분기의 signed→abs 되돌림을 못 잡는다.)
    _ba = np.zeros((1, 1, 8), np.int8)
    _ba[0, 0, :] = 1
    _bv = solve_sigma_z(_ba, _tsg, 0.25, z_top_um=2.0, z_bot_um=1.0)
    _q7c = (_bv['sigma_eff'] == 0.0) and 'no_plate_contact' in str(_bv.get('reason') or '')
    ok &= _q7c
    print(f"plate-bot-below-plane: 물리 bottom plane 보다 **아래**인 최하단 셀은 접촉이 "
          f"아니다 (σ={_bv['sigma_eff']:g})  {'OK' if _q7c else 'FAIL'}")

    _oa = np.zeros((1, 1, 6), np.int8)
    _oa[0, 0, 3:6] = 1                          # 도체가 위쪽에만
    _osg = np.zeros(9); _osg[1] = 0.010
    #  물리 판을 도체보다 **아래**에 둔다 → 위판 접점이 있으면 안 된다
    _ov = solve_sigma_z(_oa, _osg, 0.25, z_top_um=0.55, z_bot_um=0.0)
    _q7 = (_ov['sigma_eff'] == 0.0) and 'no_plate_contact' in str(_ov.get('reason') or '')
    ok &= _q7
    print(f"plate-outside-slab: 물리 판보다 **위**인 셀은 접촉이 아니다 "
          f"(σ={_ov['sigma_eff']:g} reason={str(_ov.get('reason'))[:38]})  "
          f"{'OK' if _q7 else 'FAIL'}")

    #  ★ 부분 원장 = 거부 (R3-CX-07 ③): `{}` · 한쪽만 · 빈 접점
    _ledger_bad = []
    for _lbl, _pe in (('{}', {}),
                      ('bottom-only', {'bot': _r3['plate_edges']['bot']}),
                      ('top-only', {'top': _r3['plate_edges']['top']}),
                      ('빈 접점', {'bot': ((np.array([], int),) * 3, np.array([]), 1.0),
                                   'top': _r3['plate_edges']['top']})):
        try:
            phase_current_share(dict(_r3, plate_edges=_pe), _cid, _cs(1.0, 10.0),
                                periodic_xy=False)
            _ledger_bad.append(_lbl)
        except ValueError:
            pass
    ok &= not _ledger_bad
    print(f"plate-ledger-complete: 부분 원장 4종을 전부 거부한다 "
          f"(통과해 버린 것: {_ledger_bad or '없음'})  "
          f"{'OK' if not _ledger_bad else 'FAIL'}")

    #  ⓓ **원장 부재 = 거부**.  초판은 조용히 internal-only 로 돌아가 CDXR2-1 이 고친
    #     틀린 답(10/13)을 다시 냈다.  `periodic_xy` 는 이미 fail-closed 였는데 이쪽만
    #     fail-open 이라 같은 함수 안에서 두 규약이 갈려 있었다.
    try:
        phase_current_share({'phi': _r3['phi'], 'cond': _r3['cond'], 'periodic_xy': False},
                            _cid, _cs(1.0, 10.0))
        _q6 = False
    except ValueError as _e6:
        _q6 = 'plate_edges' in str(_e6)
    ok &= _q6
    print(f"plate-share-failclosed: 플레이트 원장 없는 res 는 **거부**한다  "
          f"{'OK' if _q6 else 'FAIL'}")

    # ── ★★ `SELF-45` (2026-09-22) — **필드 통계가 그림 예산에 불변인가** ──────────────
    #   재현 시험 먼저 (규율 ②).  옛 판은 소비자가 **돌려받은 점군**에 백분위를 걸었고,
    #   그 점군은 상위 35 % 를 전수 보존하는 hot-biased 추출이라 보고값이
    #   `--field-max-points` 의 함수였다 (실측 ×201.2 → ×71.6 → ×52.9).
    #   ⇒ 같은 solve 에서 예산만 바꿔 `stats` 가 **비트 단위로 같은지** 단언한다.
    #   ⚠ 꼬리가 평평한 침대(균일 도선)는 편향이 0 이라 **이 픽스처는 꼬리가 가파라야**
    #     공허하지 않다 — 그래서 목이 좁은 AM 협착 침대를 쓴다 (탄소 도선 없음).
    _NB = 34                                                 # 상자 한 변 (구슬 사슬 3×3)
    _NZ45 = 34
    _fs = np.full((_NB, _NB, _NZ45), 2, np.int8)             # 절연 바탕 (전 셀 '점유' = 표면 규약 작동)
    _ax = np.arange(_NB); _az = np.arange(_NZ45)
    _gx, _gy, _gz = np.meshgrid(_ax, _ax, _az, indexing='ij')
    _tab45 = np.array([0.0, 1.0, 0.0])                       # sid 1 만 도체 (sid 2 = 절연)
    #  ⚠ 목 굵기를 사슬마다·층마다 **다르게** 준다.  똑같은 사슬 9 개를 놓으면 상위 9 개
    #    값이 완전히 같아져 "옛 규약이 움직인다" 는 비공허 단언이 대칭 때문에 통과해 버린다
    #    (실제로 첫 판이 그렇게 FAIL 했다 — 픽스처가 시험을 무력화한 자리).
    for _ci, _cx in enumerate((8.0, 17.0, 26.0)):            # 사슬 9 개
        for _cj, _cy in enumerate((8.0, 17.0, 26.0)):
            for _n, _cz in enumerate(range(0, _NZ45, 3)):    # z 로 겹친 구슬 = 좁은 목
                _big = _n % 2 == 0
                _rr = 2.4 if _big else 1.25 + 0.07 * (((_ci * 3 + _cj) * 5 + _n) % 11)
                #  ★ 목마다 **가로 오프셋**도 준다.  안 주면 목 안의 셀이 4겹 대칭이라
                #    상위 값이 4 개씩 같아져 꼬리가 계단이 된다 (같은 이유로 첫 판이 FAIL).
                _ox = 0.0 if _big else 0.37 * (((_n + _ci) % 3) - 1)
                _oy = 0.0 if _big else 0.41 * (((_n + _cj) % 3) - 1)
                _fs[((_gx - _cx - _ox) ** 2 + (_gy - _cy - _oy) ** 2
                     + (_gz - _cz) ** 2) <= _rr * _rr] = 1
    _r45 = solve_sigma_z(_fs, _tab45, 0.5, return_field=True,
                         z_bot_um=0.0, z_top_um=_NZ45 * 0.5)
    _ok45 = 'phi' in _r45 and _r45['sigma_eff'] > 0
    ok &= _ok45
    print(f"field-stats-fixture: 구슬 사슬이 관통한다 (σ_eff={_r45.get('sigma_eff', 0):.4g}, "
          f"dof {_r45.get('n_dof', 0):,})  {'OK' if _ok45 else 'FAIL'}")
    _st45 = []
    for _mp in (200, 1200, 10 ** 9):
        _, _v45, _s45 = field_point_cloud(_r45, _fs, _tab45, 0.5, (1,), max_points=_mp)
        _st45.append((_s45, float(np.percentile(_v45, 99.8))))
    _inv = all(abs(s['p99_8'] - _st45[0][0]['p99_8']) <= 1e-12 * max(abs(_st45[0][0]['p99_8']), 1e-30)
               and abs(s['mean'] - _st45[0][0]['mean']) <= 1e-12 * max(abs(_st45[0][0]['mean']), 1e-30)
               and s['n_total'] == _st45[0][0]['n_total'] for s, _ in _st45)
    ok &= _inv
    print(f"field-stats-budget-invariant: p99.8/mean/N 이 max_points 에 불변  "
          f"{'OK' if _inv else 'FAIL'}")
    #  ★ **공허하지 않음의 증거** — 옛 규약(점군 백분위)은 같은 solve 에서 실제로 움직인다.
    #    이 단언이 깨지면 픽스처의 꼬리가 평평해진 것이므로 위 시험도 무의미하다.
    _naive = [c for _, c in _st45]
    _nonvac = max(_naive) > min(_naive) * 1.05
    ok &= _nonvac
    print(f"field-stats-nonvacuous: 옛 규약(점군 백분위)은 예산에 따라 움직인다 "
          f"({min(_naive):.4g} → {max(_naive):.4g}, {max(_naive)/max(min(_naive), 1e-30):.2f}×)  "
          f"{'OK' if _nonvac else 'FAIL'}")
    #  ★ Markov — 같은 모집단의 비는 **정의상** ≤ 500 이어야 한다 (리뷰어 A-2 의 부등식).
    _s0 = _st45[0][0]
    _mk = _s0['p99_8'] <= 500.0 * _s0['mean'] + 1e-12
    ok &= _mk
    print(f"field-stats-markov: p99.8 ≤ 500·⟨|J|⟩ (같은 모집단)  "
          f"{_s0['p99_8'] / max(_s0['mean'], 1e-30):.1f} ≤ 500  {'OK' if _mk else 'FAIL'}")
    #  ★ 네 번째 필드 — Joule.  `q` 는 추출된 것이므로 소비자가 거기에 백분위를 걸면
    #    색 스케일이 다시 예산의 함수가 된다.  전수 통계가 예산에 불변인지 같이 문다.
    _jq45 = [joule_hotspot(_r45, _fs, _tab45, 0.5, (1,), max_points=_mp)
             for _mp in (200, 1200, 10 ** 9)]
    _jinv = (all(j is not None for j in _jq45)
             and all(abs(j['q_p99_8'] - _jq45[0]['q_p99_8'])
                     <= 1e-12 * max(abs(_jq45[0]['q_p99_8']), 1e-30)
                     and j['n_total'] == _jq45[0]['n_total'] for j in _jq45))
    ok &= _jinv
    print(f"joule-stats-budget-invariant: q 의 전수 p99.8·N 이 max_points 에 불변  "
          f"{'OK' if _jinv else 'FAIL'}")

    print('SELFTEST', 'PASS' if ok else 'FAIL')
    return 0 if ok else 1


def _selftest_pore():
    """A6 pore-τ analytic checks — crop, PTFE stamping, TauFactor convention."""
    ok = True
    # 1) all-void box → ε=100%, D_rel=1, τ=1 exactly
    sid = np.zeros((6, 6, 10), np.int8)
    r = pore_tau(sid, 0.5, z_top_um=5.0)
    e = abs(r['tau'] - 1.0) < 1e-6 and abs(r['eps_total_pct'] - 100.0) < 1e-9
    ok &= e; print(f"all-void: τ={r['tau']}  ε={r['eps_total_pct']}%  (expect 1, 100)  {'OK' if e else 'FAIL'}")
    # 2) straight 2×2 channel through solid → D_rel = area share EXACT (plate half-cell convention),
    #    τ = 1 exactly (straight pore has no tortuosity)
    sid = np.ones((6, 6, 10), np.int8); sid[2:4, 2:4, :] = 0
    r = pore_tau(sid, 0.5, z_top_um=5.0)
    e = abs(r['tau'] - 1.0) < 1e-6 and abs(r['D_rel'] - 4.0 / 36.0) < 5e-4   # D_rel ships %.4g-rounded
    ok &= e; print(f"channel:  τ={r['tau']}  D_rel={r['D_rel']:.4f}  (expect 1, {4/36:.4f})  {'OK' if e else 'FAIL'}")
    # 3) void padding cap ABOVE the bed (raster box taller than the pressed thickness) — uncropped,
    #    every column's topmost pore voxel floats in the cap and the top plate decouples; the crop
    #    must restore the exact channel answer
    sid = np.ones((6, 6, 14), np.int8); sid[2:4, 2:4, :] = 0; sid[:, :, 10:] = 0
    r = pore_tau(sid, 0.5, z_top_um=5.0)
    e = abs(r['tau'] - 1.0) < 1e-6
    ok &= e; print(f"crop:     τ={r['tau']}  (expect 1 — padding cap cropped)  {'OK' if e else 'FAIL'}")
    # 4) extra_solid_pts stamping (the PTFE path): plug the channel with 4 stamped points → the pore
    #    no longer percolates → D_rel ~ 0, τ = None
    sid = np.ones((6, 6, 10), np.int8); sid[2:4, 2:4, :] = 0
    plug = np.array([[1.25, 1.25, 2.25], [1.75, 1.25, 2.25], [1.25, 1.75, 2.25], [1.75, 1.75, 2.25]])
    r = pore_tau(sid, 0.5, z_top_um=5.0, extra_solid_pts=plug)
    e = (r['tau'] is None) and r['D_rel'] < 1e-9
    ok &= e; print(f"stamp:    τ={r['tau']}  D_rel={r['D_rel']:.1e}  (expect None, ~0 — plugged)  {'OK' if e else 'FAIL'}")
    # 5) isolated-pore honesty: a sealed 2-voxel pocket raises ε_total but not ε_connected;
    #    τ uses ε_total (TauFactor) → closed porosity reads as τ > 1
    sid = np.ones((6, 6, 10), np.int8); sid[2:4, 2:4, :] = 0; sid[0, 0, 4:6] = 0
    r = pore_tau(sid, 0.5, z_top_um=5.0)
    e = r['eps_total_pct'] > r['eps_connected_pct'] and r['tau'] is not None and r['tau'] > 1.0
    ok &= e; print(f"isolated: ε_tot={r['eps_total_pct']}% > ε_conn={r['eps_connected_pct']}%  τ={r['tau']}"
                   f"  (expect τ>1: closed porosity penalised)  {'OK' if e else 'FAIL'}")
    # 6) review M1 — 1-voxel solid ROOF must SEAL the channel even when frac(z_top/vox) puts the
    #    roofed pore centre inside the e-solve's default band (vox+0.1): vox=0.4, z_top=2.68
    #    (frac 0.7) → roofed pore dist 0.48 < 0.5 leaked with the old band; band=vox seals it
    sid = np.ones((6, 6, 8), np.int8); sid[2:4, 2:4, 0:6] = 0    # channel k=0..5, solid roof k=6
    r = pore_tau(sid, 0.4, z_top_um=2.68)
    e = r['tau'] is None and r['D_rel'] < 1e-9 and bool(r.get('reason'))
    ok &= e; print(f"roof:     τ={r['tau']}  D_rel={r['D_rel']:.1e}  reason={r.get('reason')}"
                   f"  (expect sealed — old band read τ<1 through the roof)  {'OK' if e else 'FAIL'}")
    # 7) ★ Codex #2 — `eps_connected_pct` 는 either-plate 다.  **한쪽 플레이트에만 닿는 막다른
    #    공극**(dead-end)을 넣으면 두 계수가 갈려야 한다.  갈리지 않으면 이 시험은 가능도비 1
    #    이고 결함을 영원히 통과시킨다 → 여기서 **차이를 강제로 요구**한다.
    sid = np.ones((6, 6, 10), np.int8)
    sid[2:4, 2:4, :] = 0                                    # 관통 채널 (양 플레이트)
    sid[0, 0, 0:5] = 0                                      # 바닥에만 닿는 막다른 공극
    r = pore_tau(sid, 0.5, z_top_um=5.0)
    e = (r['n_through_dof'] is not None
         and r['n_plate_reachable_dof'] == r['n_dof']
         and r['n_through_dof'] < r['n_plate_reachable_dof']      # ★ 판별력: 갈려야 한다
         and r['n_plate_reachable_dof'] - r['n_through_dof'] == 5  # 막다른 5 복셀 정확히
         and r['eps_through_pct'] < r['eps_connected_pct']
         and r['eps_connected_basis'] == 'legacy:either_plate')
    ok &= e; print(f"deadend:  reachable={r['n_plate_reachable_dof']} through={r['n_through_dof']} "
                   f"(expect Δ=5: 바닥만 닿는 공극) ε_conn={r['eps_connected_pct']}% > "
                   f"ε_through={r['eps_through_pct']}%  {'OK' if e else 'FAIL'}")
    # 8) 관통만 있으면 둘이 같아야 한다 (위 시험이 항상 갈리는 것은 아님을 보이는 대조군)
    sid = np.ones((6, 6, 10), np.int8); sid[2:4, 2:4, :] = 0
    r = pore_tau(sid, 0.5, z_top_um=5.0)
    e = r['n_through_dof'] == r['n_plate_reachable_dof'] and \
        r['eps_through_pct'] == r['eps_connected_pct']
    ok &= e; print(f"control:  reachable={r['n_plate_reachable_dof']} == through={r['n_through_dof']}"
                   f"  (막다른 공극 없으면 동일)  {'OK' if e else 'FAIL'}")
    print('PORE SELFTEST', 'PASS' if ok else 'FAIL')
    return 0 if ok else 1


def _selftest_segstamp():
    """SR-01 opt-in 선분 스탬프 — 기본 경로 불변 + 연결 보장 + AM 관통 방지."""
    from fibre_segment_raster import n_components_6face
    ok = fail = 0

    def chk(m, c):
        nonlocal ok, fail
        print(('  PASS  ' if c else '  FAIL  ') + m)
        ok, fail = ok + (1 if c else 0), fail + (0 if c else 1)

    vox = 0.4
    lo, hi = np.zeros(3), np.array([20.0, 20.0, 20.0])
    rng = np.random.default_rng(3)
    step = 0.7 * 0.141                       # production 점 간격 규약
    pts, fid, ph = [], [], []
    for k in range(3):
        d = rng.normal(size=3); d /= np.linalg.norm(d)
        P = rng.uniform(4, 14, 3) + np.arange(int(10 / step))[:, None] * step * d
        pts.append(P); fid += [k] * len(P); ph += [2] * len(P)     # phase 2 = VGCF
    pts = np.vstack(pts); fid = np.array(fid); ph = np.array(ph)
    z3 = (np.zeros((0, 3)), np.zeros(0), np.zeros(0, int))

    sid_pt, _ = rasterize(*z3, pts, ph, lo, hi, vox)
    sid_sg, _ = rasterize(*z3, pts, ph, lo, hi, vox, add_fid=fid)
    cpt = np.argwhere(sid_pt == 3); csg = np.argwhere(sid_sg == 3)
    chk(f'1) ★ 결함 재현: 점-스탬프 성분 {n_components_6face(cpt)} > 섬유 3개',
        n_components_6face(cpt) > 3)
    chk(f'2) ★ add_fid → 선분: 성분 {n_components_6face(csg)} = 섬유 3',
        n_components_6face(csg) == 3)
    chk(f'3) 셀 증가 {len(csg) / max(len(cpt), 1):.2f}배 < 1.6', len(csg) / max(len(cpt), 1) < 1.6)
    sid_b, _ = rasterize(*z3, pts, ph, lo, hi, vox, add_fid=None)
    chk('4) ★ add_fid=None 은 기존과 bitwise 동일 (opt-in 이 기본을 안 건드린다)',
        np.array_equal(sid_pt, sid_b))
    # AM 드랍으로 생긴 큰 간격은 **끊어야** 한다 (안 그러면 폴리라인이 AM 을 관통)
    A = np.arange(0, 4, step)[:, None] * np.array([1, 0.3, 0.2])
    P2 = np.vstack([A + np.array([2, 2, 2]), A + np.array([9, 4, 3.4])])
    sid_g, _ = rasterize(*z3, P2, np.full(len(P2), 2), lo, hi, vox,
                         add_fid=np.zeros(len(P2), int))
    chk(f'5) ★ 큰 간격은 끊어 굽는다 (성분 {n_components_6face(np.argwhere(sid_g == 3))} = 2)',
        n_components_6face(np.argwhere(sid_g == 3)) == 2)
    # σ 로 읽었을 때의 크기 — 점 스탬프가 퍼콜을 잃는다
    sg = np.zeros(9); sg[3] = 100.0
    ra = solve_sigma_z(sid_pt, sg, vox); rb = solve_sigma_z(sid_sg, sg, vox)
    chk(f"6) ★ σ_z 점={ra['sigma_eff']:.4g} < 선분={rb['sigma_eff']:.4g} "
        f"(floating 버림 {ra['n_floating_dropped']} → {rb['n_floating_dropped']})",
        rb['sigma_eff'] > ra['sigma_eff'])
    # ★ 배선 확인 — 구현만 하고 payload 가 안 넘기면 무의미하다 (이 리포의 반복 교훈)
    import os as _os
    _pp = _os.path.join(_os.path.dirname(_os.path.abspath(__file__)), 'mpm_webapp_payload.py')
    try:
        _src = open(_pp, encoding='utf-8').read()
        chk('7) ★ payload 가 rasterize 에 add_fid 를 넘긴다 (배선)',
            'add_fid=_afid' in _src)
        chk('8) ★ payload CLI 에 --step3-fibre-stamp 가 있고 기본이 point 다',
            "'--step3-fibre-stamp'" in _src and "default='point'" in _src)
        #  ★★ 2026-09-01 — 이 검사는 `'fibre_stamp': a.step3_fibre_stamp` 라는 **철자**를
        #    찾고 있었다.  그 사이 payload 가 **더 좋아져서** 요청값과 적용값을 갈라 적게
        #    됐고 (`fibre_stamp` = 실제 적용, `fibre_stamp_requested` = 요청), 검사만
        #    빨간불이 됐다.  이 selftest 가 어느 레인에도 없어 그대로 남아 있었다 (R19 Q6).
        #  ⇒ 철자가 아니라 **계약**을 본다: 세 칸이 다 있고, 적용값이 요청값의 **복사가
        #    아닐 것** — 요청을 실제인 양 적는 것이 RC6-08 이 잡은 바로 그 결함이다.
        import ast as _ast
        _keys, _applied_is_copy = set(), False
        for _n in _ast.walk(_ast.parse(_src)):
            if not isinstance(_n, _ast.Dict):
                continue
            for _k, _v in zip(_n.keys, _n.values):
                if not (isinstance(_k, _ast.Constant) and isinstance(_k.value, str)):
                    continue
                if _k.value.startswith('fibre_stamp'):
                    _keys.add(_k.value)
                    if (_k.value == 'fibre_stamp' and isinstance(_v, _ast.Attribute)
                            and _v.attr == 'step3_fibre_stamp'):
                        _applied_is_copy = True
        chk('9) ★ manifest 가 요청·적용을 갈라 적는다 (어느 방식으로 **돌았는지** 추적)',
            {'fibre_stamp', 'fibre_stamp_requested', 'fibre_stamp_applied'} <= _keys
            and not _applied_is_copy)
    except OSError as _e:
        chk(f'7-9) ⚠ payload 배선 확인 생략 ({_e})', True)

    # ── ★★ 회귀 10-12: **경로가 아닌 fid** (coat id = AM 구 index) ──────────────────────
    #   적대리뷰(코드 렌즈, 2026-08-12)가 재현: `additives.seed_coat(return_ids=True)` 는
    #   **AM 구 index** 를 fid 로 준다 (SDCP thinky·SuperP thinky).  한 구 표면에 흩어진
    #   수십 점이 같은 fid 를 공유하므로 폴리라인으로 이으면 구 표면을 헤집는 선분이 되고,
    #   실측 셀 45 → 582 (×12.9), 그중 87 % 가 **AM 구 내부**.  gap_tol 은 간격이 균일해
    #   **발화하지 않는다**(파단 0 건).  → POLYLINE_PHASES 화이트리스트로 막는다.
    rng = np.random.default_rng(0)
    u = rng.normal(size=(47, 3)); u /= np.linalg.norm(u, axis=1)[:, None]
    coat = np.array([10.0, 10.0, 10.0]) + 3.0 * u             # 구 표면 산포 47점, 1 fid
    lo3 = np.array([0.0, 0.0, 0.0]); n3 = np.array([64, 64, 64])
    fid1 = np.zeros(len(coat), np.int32)
    for ph_code, name, is_poly in ((5, 'SDCP', False), (3, 'SuperP', False), (2, 'VGCF', True)):
        ijk_s, _ = _fibre_segment_ijk(coat, np.full(len(coat), ph_code, np.int8), fid1,
                                      lo3, 0.4, n3)
        n_pt = len(np.unique(np.floor((coat - lo3) / 0.4).astype(int), axis=0))
        ratio = len(np.unique(ijk_s, axis=0)) / max(n_pt, 1)
        if not is_poly:
            chk(f'10-{ph_code}) ★ {name}(coat id)는 경로가 아니다 → 점 스탬프 유지 '
                f'(셀 비 {ratio:.2f}× ≤ 1.0)', ratio <= 1.0 + 1e-9)
        else:
            chk(f'10-{ph_code}) 대조: {name}는 폴리라인이라 선분이 걸린다 (셀 비 {ratio:.1f}×)',
                ratio > 1.6)
    # 화이트리스트가 뷰어 가드와 **같은 소스**인가 (두 번째 구현이 이 결함의 원인이었다)
    try:
        _src2 = open(_pp, encoding='utf-8').read()
        chk('11) ★ payload 뷰어 폴리라인 마스크가 step3 의 POLYLINE_PHASES 를 쓴다 (단일 소스)',
            'POLYLINE_PHASES' in _src2)
    except OSError:
        pass
    chk('12) POLYLINE_PHASES = (2,4,6) — VGCF·PTFE·SWCNT 만 경로',
        tuple(POLYLINE_PHASES) == (2, 4, 6))

    # ── ② fid 의미 계약: 시더 선언이 phase 추측을 **이긴다** (Codex E-01) ────────────────
    #   SuperP(phase 3) 는 mixing 에 따라 경로(ballmill)도 그룹(thinky)도 된다 — phase 로는
    #   원리적으로 못 가른다.
    import additives as _adt
    chk('13) SuperP ballmill = 경로 (체인)', _adt.id_kind_of('cblack') == _adt.ID_PATH)
    chk('14) ★ SuperP thinky = 그룹 — 같은 phase 인데 반대라 phase 로는 못 가른다',
        _adt.id_kind_of('cblack', 'coat_block') == _adt.ID_GROUP)
    chk('15) 미등록 시더는 안전측(GROUP)', _adt.id_kind_of('nope') == _adt.ID_GROUP)
    #   ★ **대각선**이어야 점 스탬프가 끊긴다 (축정렬 선은 점으로도 face 를 공유한다 —
    #     이것이 리포 selftest 가 4개월간 이 결함을 통과시킨 이유이기도 하다).
    _s0 = np.array([2.0, 2.0, 2.0]); _d1 = np.array([6.0, 6.0, 6.0])
    _ln = _s0 + np.linspace(0, 1, 40)[:, None] * _d1[None, :]
    _f0 = np.zeros(len(_ln), np.int32); _n3 = np.array([64, 64, 64]); _lo3 = np.zeros(3)
    _ph3 = np.full(len(_ln), 3, np.int8)
    _ijp, _ = _fibre_segment_ijk(_ln, _ph3, _f0, _lo3, 0.4, _n3,
                                 add_kind=np.full(len(_ln), _adt.ID_PATH, np.int8))
    _ijg, _ = _fibre_segment_ijk(_ln, _ph3, _f0, _lo3, 0.4, _n3,
                                 add_kind=np.full(len(_ln), _adt.ID_GROUP, np.int8))
    chk('16) ★ 같은 phase·같은 점열이라도 kind=PATH 는 잇고 GROUP 은 안 잇는다',
        n_components_6face(np.unique(_ijp, axis=0)) == 1
        and n_components_6face(np.unique(_ijg, axis=0)) > 1)
    _ijf, _ = _fibre_segment_ijk(_ln, _ph3, _f0, _lo3, 0.4, _n3)
    chk('17) kind 없으면 phase 폴백 (3 ∉ POLYLINE_PHASES → 점) = 옛 산출물 호환',
        np.array_equal(np.unique(_ijf, axis=0), np.unique(_ijg, axis=0)))

    # ── ③ segment_cells 음방향 + **정확한 복셀 경계** 끝점 (Codex E-06) ─────────────────
    #   기존 음방향 사례는 끝점이 경계에 정확히 놓이지 않아 이 경로를 안 탔다.
    from fibre_segment_raster import segment_cells as _sc
    for _nm, _p0, _p1 in (('음방향-경계끝', np.array([2.0, .2, .2]), np.array([0.8, .2, .2])),
                          ('양방향-경계끝', np.array([0.8, .2, .2]), np.array([2.0, .2, .2])),
                          ('음방향-경계시작', np.array([1.6, .2, .2]), np.array([0.5, .2, .2]))):
        _cc = np.unique(_sc(_p0, _p1, 0.4), axis=0)
        _sp = int(abs(np.floor(_p1[0] / 0.4) - np.floor(_p0[0] / 0.4))) + 1
        chk(f'18-{_nm}) 1성분 · 셀 {len(_cc)} = 기대 {_sp} (여분/backtrack 없음)',
            n_components_6face(_cc) == 1 and len(_cc) == _sp)

    # ── ④ point legacy parity — 계약 도입이 점 경로를 안 건드린다 ─────────────────────
    _amc = np.array([[5.0, 5.0, 5.0]]); _amr = np.array([1.5]); _amt = np.array([1])
    _hi3 = _lo3 + 64 * 0.4
    _sa, _ = rasterize(_amc, _amr, _amt, _ln, np.full(len(_ln), 2, np.int8), _lo3, _hi3, 0.4)
    _sb, _ = rasterize(_amc, _amr, _amt, _ln, np.full(len(_ln), 2, np.int8), _lo3, _hi3, 0.4,
                       add_kind=np.full(len(_ln), _adt.ID_PATH, np.int8))
    chk('19) ★ add_fid 없이는 add_kind 를 줘도 점 경로 bitwise 동일 (legacy parity)',
        np.array_equal(_sa, _sb))

    print(f'\nstep3 segment-stamp selftest: {ok}/{ok + fail} PASS')
    return 0 if not fail else 1


def _selftest_swcnt():
    """A14 — phase-6(SWCNT sheath) rasterize 스탬프 + 전자-도체/이온-투명 배선 검증.
    리뷰 CRITICAL 재발 방지: phase→sid 맵 누락 시 점이 무음 drop되어 σ_e 효과가 0이 되는 버그."""
    ok = True
    am_c = np.array([[5.0, 5.0, 5.0]]); am_r = np.array([2.0]); am_t = np.array([1])
    pts = np.array([[5.0, 5.0, 7.3], [1.0, 1.0, 1.0]])       # sheath skin점 + 원거리 VGCF 대조점
    ph = np.array([6, 2], np.int8)
    se = np.array([[8.0, 8.0, 8.0]])
    sid, _ = rasterize(am_c, am_r, am_t, pts, ph, (0, 0, 0), (10.0, 10.0, 10.0), 0.4, se_pts=se)
    v6 = sid[int(5.0 / .4), int(5.0 / .4), int(7.3 / .4)]
    v2 = sid[int(1.0 / .4), int(1.0 / .4), int(1.0 / .4)]
    e = (v6 == 8) and (v2 == 3)
    ok &= e; print(f'stamp:     phase6→sid {v6} (expect 8), phase2→sid {v2} (expect 3)  {"OK" if e else "FAIL"}')
    # 전자 테이블: idx8 도체 / 이온 테이블: 기본 SE-투명(σ>0) vs 차단(0) — payload 테이블 모양 재현
    sig_e = np.array([0, .01, .005, 100, 10, 250, 0, 0, 100.0])
    sig_i_t = np.array([0, 0, 0, 0, 0, .0006, .003, 0, .003])
    sig_i_b = np.array([0, 0, 0, 0, 0, .0006, .003, 0, 0.0])
    e = sig_e[v6] > 0 and sig_i_t[v6] > 0 and sig_i_b[v6] == 0.0
    ok &= e; print(f'tables:    σ_e[8]={sig_e[8]} σ_i_transparent[8]={sig_i_t[8]} σ_i_blockUB[8]={sig_i_b[8]}  '
                   f'{"OK" if e else "FAIL"}')
    # SID_NAME 완결성 (phase_current_share KeyError 방지)
    e = SID_NAME.get(8) == 'SWCNT'
    ok &= e; print(f'sid-name:  SID_NAME[8]={SID_NAME.get(8)}  {"OK" if e else "FAIL"}')
    print('SWCNT-STAMP SELFTEST', 'PASS' if ok else 'FAIL')
    return 0 if ok else 1


def _selftest_pnm():
    """A13 pore-PNM analytic checks — dumbbell 2-body/1-throat, sealed closure, thin fallback."""
    ok = True
    # 1) dumbbell: 두 구형 기공(r=4.4vox) + 1-voxel 목(neck) — 밀봉 박스 → n_pores=2, n_throats=1,
    #    CN mean=1, closed_from_top=100%
    n = (40, 20, 20)
    sid = np.ones(n, np.int8)
    zz = np.indices(n).astype(float)
    for cx in (10.0, 30.0):
        m = ((zz[0] - cx) ** 2 + (zz[1] - 10.0) ** 2 + (zz[2] - 10.0) ** 2) <= 4.4 ** 2
        sid[m] = 0
    sid[10:31, 10, 10] = 0                                   # 1-voxel neck (dist=1 → seed 아님)
    r = pore_pnm(sid, 0.5, z_top_um=10.0)
    e = (r['n_pores'] == 2 and r['n_throats'] == 1
         and abs(r['pore_cn']['mean'] - 1.0) < 1e-9 and r['closed_from_top_pct'] == 100.0)
    ok &= e
    print(f"dumbbell: n_pores={r['n_pores']} throats={r['n_throats']} CN={r['pore_cn'].get('mean')} "
          f"closed={r['closed_from_top_pct']}%  (expect 2/1/1.0/100)  {'OK' if e else 'FAIL'}")
    # r_eq sanity: 구 r=4.4vox=2.2µm에 목 절반씩 → 등가반경 ≈2.2µm ±20%
    e = abs(r['r_eq_um']['med'] - 2.2) / 2.2 < 0.2
    ok &= e
    print(f"r_eq:     med={r['r_eq_um']['med']}µm  (expect ≈2.2 ±20%)  {'OK' if e else 'FAIL'}")
    # 2) 위-열린 직선 채널 (2×2, 전체 관통) — ultra-thin → fallback=components, closed 0%
    sid = np.ones((6, 6, 10), np.int8)
    sid[2:4, 2:4, :] = 0
    r = pore_pnm(sid, 0.5, z_top_um=5.0)
    e = r['n_pores'] == 1 and r['closed_from_top_pct'] == 0.0 and 'fallback' in r
    ok &= e
    print(f"channel:  n_pores={r['n_pores']} closed={r['closed_from_top_pct']}% fallback={'Y' if 'fallback' in r else 'N'}"
          f"  (expect 1/0/Y)  {'OK' if e else 'FAIL'}")
    # 3) 열린 채널 + 밀봉 구 공존 → closed% = 구 부피 몫 (0<closed<100)
    sid = np.ones((20, 20, 12), np.int8)
    sid[2:4, 2:4, :] = 0
    m = ((zz[0][:20, :20, :12] - 12.0) ** 2 + (zz[1][:20, :20, :12] - 12.0) ** 2
         + (zz[2][:20, :20, :12] - 5.0) ** 2) <= 3.4 ** 2
    sid[m] = 0
    r = pore_pnm(sid, 0.5, z_top_um=6.0)
    e = 0.0 < r['closed_from_top_pct'] < 100.0
    ok &= e
    print(f"mixed:    closed={r['closed_from_top_pct']}%  (expect 0<x<100)  {'OK' if e else 'FAIL'}")
    # 4) no void → reason
    r = pore_pnm(np.ones((4, 4, 6), np.int8), 0.5, z_top_um=3.0)
    e = r.get('reason') == 'no_void'
    ok &= e
    print(f"no-void:  reason={r.get('reason')}  {'OK' if e else 'FAIL'}")
    print('PNM SELFTEST', 'PASS' if ok else 'FAIL')
    return 0 if ok else 1


# ── Track-B (COMSOL 하이브리드) 파라미터 헬퍼 ───────────────────────────────────────────
#    설계: AM 구 = 해상 기하 / SE = 연속체 / VGCF = 1D Edge / AM-AM 넥 = DEM δ (소성 미미).
#    아래 셋은 payload → comsol_pkg 익스포트의 순수 계산 조각이다.

def tau_from_solve(phi_cond, sigma_bulk, sigma_eff):
    """복셀 Laplace 해 → 굴곡도.  **선형 관례** σ_eff = σ_bulk·φ/τ ⇒ τ = φ·σ_bulk/σ_eff.

    ⚠ 관례 지뢰: build_tau_regime_db._tau_from_sigma 는 √(φ·σ/σ_eff) = **τ² 관례**다.
    같은 구조가 선형 τ=4 ↔ √ 관례 2 로 두 배 다르게 읽힌다.  COMSOL 의 tortuosity 입력은
    통상 선형(σ_eff = σ·ε/τ) → Track-B export 는 전부 이 함수로 통일하고 관례를 함께 적는다.
    """
    if not (phi_cond and sigma_bulk and sigma_eff) or min(phi_cond, sigma_bulk, sigma_eff) <= 0:
        return None
    return float(phi_cond) * float(sigma_bulk) / float(sigma_eff)


def kdom_calibration(phi_full, tau_full, phi_geo, tau_geo):
    """Track-B SE 연속체의 국소 전도도 배율 κ_dom/σ_bulk — ★ 이중계상 가드.

    하이브리드 COMSOL 은 AM 구를 **기하로 해상**하므로 AM-장애물 굴곡도는 모델이 스스로
    만든다.  측정 τ_full(전체 미세구조)을 그대로 SE 도메인 σ 에 먹이면 AM 몫이 **두 번**
    걸린다.  모델이 측정 σ_eff 를 재현할 조건:
        κ_dom·(φ_geo/τ_geo) = σ_bulk·(φ_full/τ_full)
        ⇒ κ_dom/σ_bulk = (φ_full/τ_full) / (φ_geo/τ_geo)
    φ_geo/τ_geo = "AM 여집합을 꽉 찬 SE 로 이상화" 한 같은 복셀 Laplace 해(한 번 더 푼 값).
    반환은 대체로 (0,1]: 1 = AM 기하가 굴곡을 전부 설명(SE 내부 몫 0), 작을수록 SE
    내부(넥·공극·입계) 몫이 크다.  >1 이면 규약/입력 불일치 신호이므로 호출부가 경고할 것.
    ⚠ 한계 (심화리뷰 2026-08-05): 이 배율은 z-관통 유효전도 **스칼라 하나**로만 맞춘다 —
    일축 압밀 미세구조의 in-plane↔z 이방성, 구 주변 국소 spreading, graded-z 불균질은
    검증 밖.  B1(총량 σ) 성립 / B2(BV 국소 분포)는 균질화 오차 상속 → B2 전 τ_x/τ_y
    병기 솔브로 이방성 정량 (TODO(trackb)).  복셀 계단 편향(+13~16% @vox0.4)은
    소비자 측 geo-probe 2-런 재규격으로 소거 (comsol_pkg conventions §7).
    """
    if None in (phi_full, tau_full, phi_geo, tau_geo):
        return None
    if min(phi_full, tau_full, phi_geo, tau_geo) <= 0:
        return None
    return (float(phi_full) / float(tau_full)) / (float(phi_geo) / float(tau_geo))


def am_surface_patches(sid, pid, n_am, reaction_sids=(5, 6), carbon_sids=(3, 4, 8),
                       block_sids=(7,), periodic_xy=False):
    """AM 표면 face walk — 입자별 이웃-상 분류 (Track-B per-particle coverage 벡터).

    표면 face = AM 복셀(sid 1·2)과 비-AM 복셀이 맞닿는 격자면.  face 단위로 이웃 상을 세어
    입자별 f_cov = 반응상 face / 전체 face 를 만든다.  기본 반응상 = SE(6)+SDCP(5) —
    step4 의 BV 접촉면 규약(AM|SE·AM|SDCP)과 동일.  carbon 기본 = VGCF(3)+SuperP(4)+
    SWCNT(8) = 전자 접점.  block 기본 = PTFE(7) — **개재 차단**: PTFE 가 AM|SE 사이에
    끼면 점군 coverage(순수 거리)는 못 보지만 이 walk 는 이웃 sid 로 직접 잡는다.

    ★ 점군 coverage 와 분업: 이 walk 는 위치·개재를 보고, 절대면적은 점군이 정확하다
      (복셀 표면은 계단으로 ~1.5× 과대; **비율** f_cov 에선 분자·분모 상쇄).
    ★ n_am 은 필수 인자 — pid.max()+1 추정은 마지막 입자가 표면에 안 잡히면 벡터가
      짧아진다 (SuperP `_fid.max()+1` 전역 오프셋 버그 회귀 방지).  도메인 밖은 void.

    Returns dict of [n_am] arrays: n_face, f_reaction, f_carbon, f_void, f_block.
    """
    sid = np.asarray(sid); pid = np.asarray(pid)
    am = (sid == 1) | (sid == 2)
    n_face = np.zeros(n_am, np.int64)
    c_rxn = np.zeros(n_am, np.int64); c_carb = np.zeros(n_am, np.int64)
    c_void = np.zeros(n_am, np.int64); c_blk = np.zeros(n_am, np.int64)
    rxn, carb, blk = list(reaction_sids), list(carbon_sids), list(block_sids)
    for ax in range(3):
        for sgn in (+1, -1):
            # ★ 2026-08-12 (Codex #7): 주기 런에서 x/y seam 이웃을 **0(void)** 으로 채우면
            #   경계 AM 의 f_void 가 과대, f_reaction/f_carbon 이 과소로 나온다 (반응면적
            #   과소계상 → STEP4 로 전파).  주기면 wrap 한 이웃을 쓴다.
            #   z 는 절대 wrap 하지 않는다 — 도메인 밖이 플레이트인 축이다 (기존 0 채우기 유지;
            #   "플레이트를 void 로 세는" 규약 자체는 별건이라 여기서 바꾸지 않는다).
            if periodic_xy and ax in (0, 1) and sid.shape[ax] > 1:
                nb = np.roll(sid, -sgn, ax)
            else:
                nb = np.zeros_like(sid)                   # 채우기 0 = 도메인 밖 → void
                dst = [slice(None)] * 3; src = [slice(None)] * 3
                if sgn > 0:
                    dst[ax], src[ax] = slice(0, -1), slice(1, None)
                else:
                    dst[ax], src[ax] = slice(1, None), slice(0, -1)
                nb[tuple(dst)] = sid[tuple(src)]
            m = am & ~((nb == 1) | (nb == 2))             # AM 복셀의 비-AM 이웃 face
            p, s = pid[m], nb[m]
            ok = (p >= 0) & (p < n_am)
            p, s = p[ok], s[ok]
            np.add.at(n_face, p, 1)
            np.add.at(c_rxn, p, np.isin(s, rxn).astype(np.int64))
            np.add.at(c_carb, p, np.isin(s, carb).astype(np.int64))
            np.add.at(c_void, p, (s == 0).astype(np.int64))
            np.add.at(c_blk, p, np.isin(s, blk).astype(np.int64))
    den = np.maximum(n_face, 1).astype(np.float64)
    return {'n_face': n_face,
            'f_reaction': c_rxn / den, 'f_carbon': c_carb / den,
            'f_void': c_void / den, 'f_block': c_blk / den}


def _selftest_trackb():
    """Track-B 헬퍼 검증 — 관례·이중계상 가드·face walk (개재 차단 포함)."""
    ok = True

    def chk(name, cond, extra=''):
        nonlocal ok
        ok &= bool(cond)
        print(f"  {'PASS' if cond else 'FAIL'}  {name}{(' — ' + extra) if extra else ''}")

    # 선형 관례: 곧은 도체 φ=0.5, σ_eff=0.5σ → τ=1 정확
    chk('τ 선형 관례: 직선 도체 τ=1', abs(tau_from_solve(0.5, 2.0, 1.0) - 1.0) < 1e-12)
    t_lin = tau_from_solve(0.5, 1.0, 0.125)
    chk('★ 관례 지뢰가 실재: 같은 해가 선형 τ=4 vs √ 관례 2', abs(t_lin - 4.0) < 1e-12
        and abs(np.sqrt(0.5 * 1.0 / 0.125) - 2.0) < 1e-12)
    chk('τ None-가드 (σ_eff=0 → 발산 대신 None)', tau_from_solve(0.5, 1.0, 0.0) is None)

    # 이중계상 가드: AM 기하가 전부 설명하면 κ_dom = σ_bulk (배율 1)
    chk('κ_dom: τ_full=τ_geo·φ 동일 → 배율 1', abs(kdom_calibration(0.4, 2.0, 0.4, 2.0) - 1.0) < 1e-12)
    r = kdom_calibration(0.30, 3.0, 0.45, 1.5)            # SE 내부 몫이 남는 정상 케이스
    chk('κ_dom < 1 (SE 내부 넥/공극 몫)', r is not None and 0 < r < 1, f'{r:.4f}')
    chk('재현 항등식: κ_dom·(φg/τg) == σ·(φf/τf)',
        abs(r * (0.45 / 1.5) - 1.0 * (0.30 / 3.0)) < 1e-15)
    chk('κ_dom None-가드', kdom_calibration(None, 2.0, 0.4, 2.0) is None)

    # face walk: 고립 AM 1복셀 = 6 face 전부 void
    sid = np.zeros((5, 5, 5), np.int8); pid = np.full((5, 5, 5), -1, np.int32)
    sid[2, 2, 2] = 1; pid[2, 2, 2] = 0
    P = am_surface_patches(sid, pid, n_am=3)
    chk('고립 AM 1복셀 → 6 face 전부 void', P['n_face'][0] == 6 and P['f_void'][0] == 1.0)
    chk('★ n_am 명시 → 표면에 없는 입자도 벡터에 (SuperP 오프셋 회귀)',
        len(P['n_face']) == 3 and P['n_face'][1] == 0 and P['n_face'][2] == 0)

    # SE 가 한 면에 붙으면 f_reaction = 1/6;  SDCP(5) 도 반응상 (step4 규약)
    sid2 = sid.copy(); sid2[3, 2, 2] = 6
    chk('SE 인접 face → f_reaction 1/6',
        abs(am_surface_patches(sid2, pid, 3)['f_reaction'][0] - 1 / 6) < 1e-12)
    sid2[1, 2, 2] = 5
    chk('SDCP 도 반응상 (AM|SDCP BV 규약)',
        abs(am_surface_patches(sid2, pid, 3)['f_reaction'][0] - 2 / 6) < 1e-12)

    # ★ PTFE 개재: AM|PTFE|SE 면 그 face 는 block 이지 reaction 이 아니다 (점군은 못 보는 것)
    sid3 = sid.copy(); sid3[3, 2, 2] = 7; sid3[4, 2, 2] = 6
    P3 = am_surface_patches(sid3, pid, 3)
    chk('★ PTFE 개재 → block=1/6, reaction=0', abs(P3['f_block'][0] - 1 / 6) < 1e-12
        and P3['f_reaction'][0] == 0.0)

    # carbon face (VGCF sid3) + 도메인 경계 = void
    sid4 = np.zeros((3, 3, 3), np.int8); pid4 = np.full((3, 3, 3), -1, np.int32)
    sid4[0, 1, 1] = 2; pid4[0, 1, 1] = 1                  # 경계 위 AM_P, 입자 1
    sid4[1, 1, 1] = 3                                      # VGCF 이웃
    P4 = am_surface_patches(sid4, pid4, 3)
    chk('경계 face = void · VGCF face = carbon (입자별 분리)',
        P4['n_face'][1] == 6 and abs(P4['f_carbon'][1] - 1 / 6) < 1e-12
        and abs(P4['f_void'][1] - 5 / 6) < 1e-12 and P4['n_face'][0] == 0)

    # 두 입자 face 가 섞이지 않는다
    sid5 = np.zeros((7, 3, 3), np.int8); pid5 = np.full((7, 3, 3), -1, np.int32)
    sid5[1, 1, 1] = 1; pid5[1, 1, 1] = 0
    sid5[5, 1, 1] = 2; pid5[5, 1, 1] = 2
    sid5[2, 1, 1] = 6                                      # 입자 0 만 SE 접촉
    P5 = am_surface_patches(sid5, pid5, 3)
    chk('입자별 독립 집계', abs(P5['f_reaction'][0] - 1 / 6) < 1e-12
        and P5['f_reaction'][2] == 0.0 and P5['n_face'][2] == 6)

    print('TRACK-B SELFTEST', 'PASS' if ok else 'FAIL')
    return 0 if ok else 1


def _selftest_temp():
    """σ_ion(T) 규약 — STEP3 표면에서 se_material 위임이 실제로 성립하는지 (bitwise + 배수표)."""
    ok = True

    def chk(name, cond, extra=''):
        nonlocal ok
        ok &= bool(cond)
        print(f"  {'PASS' if cond else 'FAIL'}  {name}{(' — ' + extra) if extra else ''}")

    chk('SIGMA_ION_SE_S_CM_25C is bitwise 3.0e-3 (= the old bare 0.003 literal)',
        float(SIGMA_ION_SE_S_CM_25C).hex() == (0.003).hex(), float(SIGMA_ION_SE_S_CM_25C).hex())
    chk('sigma_ion_se_S_cm() with no T is bitwise 3.0e-3',
        float(sigma_ion_se_S_cm()).hex() == (0.003).hex())
    chk('sigma_ion_se_S_cm(25) is bitwise 3.0e-3 (T_ref identity)',
        float(sigma_ion_se_S_cm(25.0)).hex() == (0.003).hex())
    for t_c, want in ((30.0, 1.28), (45.0, 2.56), (60.0, 4.79)):   # docs table, T_ref 25, Ea 0.41
        r = sigma_ion_se_S_cm(t_c) / SIGMA_ION_SE_S_CM_25C
        chk(f'{t_c:.0f} °C → x{want} (docs/temp_pressure_capability.md T1-b)',
            abs(round(r, 2) - want) < 5e-3, f'got x{r:.4f}')
    p_off, p_on = temperature_provenance(), temperature_provenance(60.0)
    chk('provenance OFF = NOT_MODELLED', p_off['T_dependence'] == 'NOT_MODELLED'
        and p_off['T_C'] is None and p_off['T_ref_C'] == 25.0)
    chk('provenance ON = ARRHENIUS + Ea 0.41', p_on['T_dependence'] == 'ARRHENIUS'
        and p_on['Ea_ion_eV'] == 0.41)
    chk('σ_e stays T-independent (Reisacher ohmic; solver convention)',
        p_on['sigma_e_T_dependence'] == 'NOT_MODELLED')
    # the electronic/thermal tables must NOT have moved
    chk('SIGMA_DEFAULT electronic table untouched',
        SIGMA_DEFAULT == {'AM_S': 0.010, 'AM_P': 0.005, 'VGCF': 100.0, 'SuperP': 10.0,
                          'SDCP': 250.0, 'SWCNT': 100.0})
    chk('thermal k table untouched', (K_AM_THERMAL, K_SE_THERMAL) == (4.0e-2, 0.7e-2))

    # ── the σ_ion solve is LINEAR in the SE phase σ, so σ_eff(T)/σ_eff(T_ref) == the
    #    Arrhenius factor exactly.  This is what mpm_webapp_payload's --temp-c actually does
    #    (it scales the sig_i table entry for SE before solve_sigma_z).
    sid = np.zeros((4, 4, 6), np.int8); sid[:] = 6          # all-SE block (sid 6 = SE)
    def _sig_i(T=None):
        t = np.zeros(9); t[6] = sigma_ion_se_S_cm(T); return t
    r_ref = solve_sigma_z(sid, _sig_i(), 0.4, z_top_um=6 * 0.4, z_bot_um=0.0)['sigma_eff']
    r_60 = solve_sigma_z(sid, _sig_i(60.0), 0.4, z_top_um=6 * 0.4, z_bot_um=0.0)['sigma_eff']
    chk('σ_eff is exactly linear in σ_SE **when the grid is all-SE** → σ_eff(60 °C)/σ_eff(25 °C) == x4.785  (⚠ 혼합상은 아래 η 검사 참조)',
        abs(r_60 / r_ref - se_material.arrhenius_sigma_factor(60.0)) < 1e-9,
        f'{r_ref:.6g} → {r_60:.6g}  (x{r_60/r_ref:.4f})')
    chk('σ_eff(no T) == σ_eff(25 °C) bitwise',
        float(r_ref).hex() == float(solve_sigma_z(sid, _sig_i(25.0), 0.4, z_top_um=6 * 0.4,
                                                  z_bot_um=0.0)['sigma_eff']).hex())

    # ── ⚠⚠ 위 검사의 **적용 범위**를 못 박는다 (2026-08-20, Codex CDX-IJ-03) ─────────────
    #   위 두 줄은 격자가 **전부 sid 6(SE)** 일 때만 성립한다.  유한체적 라플라스는 상별 σ 에
    #   1차 동차이므로 **모든 상을 같은 배수로** 곱해야 σ_eff 가 그 배수로 움직인다.
    #   ⚠ 그런데 실제 DBE 이온망은 **SE(도핑으로 변함) + SDCP(고정)** 가 함께 전도한다.
    #     한 상만 올리면 응답은 topology 에 따라 **감쇠**된다.
    #   실사고: 도핑 트랙 사전등록 초안(§D-2)이 이 selftest 의 라벨("exactly linear in σ_SE")을
    #     보고 "h0 = σ_ion_eff 비가 정확히 ×1.53" 을 등록하려 했다.  **DBE 에서 거짓**이다.
    #   ⇒ 감쇠계수 η ≡ (σ_eff 비 − 1)/(f − 1) 로 읽는다: all-SE 는 1, 혼합상은 < 1.
    _F = 1.53

    def _sig_mix(f=1.0):
        t = np.zeros(9)
        t[6] = sigma_ion_se_S_cm() * f          # SE — 도핑 팔에서만 변한다
        t[5] = 1.0e-3                           # SDCP — 고정 (mpm_webapp_payload 기본)
        return t

    def _eta(sid_):
        _kw = dict(z_top_um=sid_.shape[2] * 0.4, z_bot_um=0.0)
        _a = solve_sigma_z(sid_, _sig_mix(1.0), 0.4, **_kw)['sigma_eff']
        _b = solve_sigma_z(sid_, _sig_mix(_F), 0.4, **_kw)['sigma_eff']
        return (_b / _a - 1.0) / (_F - 1.0)

    _n = 6
    _all = np.full((_n, _n, _n), 6, np.int8)
    _ser = np.full((_n, _n, _n), 6, np.int8); _ser[:, :, _n // 2:] = 5   # 직렬 (z 적층)
    _par = np.full((_n, _n, _n), 6, np.int8); _par[_n // 2:, :, :] = 5   # 병렬 (x 분할)
    _e_all, _e_ser, _e_par = _eta(_all), _eta(_ser), _eta(_par)
    chk('★ all-SE 에서만 η = 1 (= "정확히 선형" 의 적용 범위)',
        abs(_e_all - 1.0) < 1e-9, f'η = {_e_all:.6f}')
    chk('★★ SE/SDCP 혼합에서는 η < 1 — **한 상만 올리면 감쇠한다** (CDX-IJ-03)',
        _e_ser < 0.5 and _e_par < 0.95,
        f'직렬 η = {_e_ser:.3f} · 병렬 η = {_e_par:.3f}  (all-SE 1.000)')
    chk('★ 감쇠는 topology 에 의존한다 (직렬 ≪ 병렬) — 단일 배수로 접을 수 없다',
        _e_ser < _e_par - 0.3, f'{_e_ser:.3f} < {_e_par:.3f}')
    print('TEMP SELFTEST', 'PASS' if ok else 'FAIL')
    return 0 if ok else 1


def _selftest_rint():
    """① 상 경계 계면 저항 (2026-10-02, CL-81 `CONTACT_FREE` 결손의 첫 단계) — **반례 먼저**.

    옛 조립은 모든 면을 조화평균 `g = 2σaσb/(σa+σb)·vox` 로 이어 **계면 저항 항이 정확히 0**
    이었다 (`docs/voxel_contact_free_gap.md`).  여기서 닫는 것:
      ⓐ 표 파서 (이름 쌍 → sid 쌍 · 거부 목록 · 매니페스트 기록 왕복)
      ⓑ 면 전도도 공식 `g = g₀·R_half/(R_half + r′)`, r′ = r[Ω·cm²]·1e4 [µm·cm/S]
      ⓒ 두 블록 직렬 해석해 σ_eff = L/(L_a/σ_a + L_b/σ_b + r′)
      ⓓ r 를 주지 않거나 0 이거나 격자에 없는 쌍이면 **비트 동일** (σ_eff · φ)
      ⓔ 같은 상인데 입자 번호(pid)가 다른 면 (②·③ 이 쓸 경로) · pid 없으면 무영향
      ⓕ 전류와 나란한 계면(병렬 기둥) 은 σ_eff 를 안 바꾼다 · ⓖ 주기 wrap 면도 계면
      ⓗ 소산 분담이 계면 몫을 **따로** 센다 (합 = 1 · r 없으면 옛 결과 그대로)
      ⓘ 전류 진단 (|J| 점군 · 입자별 J_z) 이 조립과 **같은** 면 전도도를 쓴다 — 계면 면에서
         전류 연속이 지켜진다 (옛 조화평균 재계산은 계면 면 전류를 과대로 낸다)
    """
    ok = True

    def chk(name, cond, extra=''):
        nonlocal ok
        ok &= bool(cond)
        print(f"  {'OK  ' if cond else 'FAIL'} {name}{(' — ' + extra) if extra else ''}")

    # ── ⓐ 파서 · 기록 ──────────────────────────────────────────────────────────
    t = parse_rint_table(['AM_S|VGCF=1e-3', 'SDCP|SE=2.5e-2'])
    chk('ⓐ1 parse: 이름 쌍 → 정렬된 sid 쌍 · float', t == {(1, 3): 1e-3, (5, 6): 2.5e-2}, repr(t))
    chk('ⓐ2 parse: 순서 바뀐 쌍은 같은 키', parse_rint_table(['VGCF|AM_S=1e-3']) == {(1, 3): 1e-3})
    chk('ⓐ3 parse: 같은 상 쌍 허용 (pid 로 가른다)', parse_rint_table(['AM_S|AM_S=1e-4']) == {(1, 1): 1e-4})
    chk('ⓐ4 parse: 빈 입력 → None', parse_rint_table(None) is None and parse_rint_table([]) is None)
    for bad in (['AM_X|VGCF=1'], ['pore|VGCF=1'], ['AM_S|VGCF=-1'], ['AM_S|VGCF=nan'], ['AM_S|VGCF'],
                ['AM_S|VGCF=1', 'VGCF|AM_S=2'], ['AM_S|VGCF=1e-3=2'], ['AM_S=1']):
        try:
            parse_rint_table(bad)
            _rej = False
        except ValueError:
            _rej = True
        chk(f'ⓐ5 parse 거부 {bad}', _rej)
    rec = rint_table_record(t)
    chk('ⓐ6 record: {"AM_S|VGCF": …} 정렬 · JSON 형', list(rec) == ['AM_S|VGCF', 'SDCP|SE']
        and rec['AM_S|VGCF'] == 1e-3 and rec['SDCP|SE'] == 2.5e-2, repr(rec))
    chk('ⓐ7 record 왕복', rint_table_from_record(rec) == t)
    chk('ⓐ8 단위 상수 1 Ω·cm² = 1e4 µm·cm/S', RINT_OHM_CM2_TO_UM_CM_PER_S == 1.0e4)

    # ── ⓑ 면 전도도 공식 ───────────────────────────────────────────────────────
    sa, sb = np.array([1.0]), np.array([4.0])
    g0 = (2.0 * sa * sb / (sa + sb)) * 0.5                                  # 0.8  (vox 0.5)
    f = interface_face_factor(sa, sb, np.array([1e-4]), 0.5)
    chk('ⓑ1 factor = R_half/(R_half+r′) = 0.3125/1.3125', abs(f[0] - 0.3125 / 1.3125) < 1e-12, f'{f[0]:.6f}')
    chk('ⓑ2 g = vox²/(R_half + r′) = 0.25/1.3125', abs(g0[0] * f[0] - 0.25 / 1.3125) < 1e-12)
    chk('ⓑ3 r=0 면은 factor 정확히 1.0',
        interface_face_factor(sa, sb, np.array([0.0]), 0.5)[0].hex() == (1.0).hex())
    gi = interface_face_g(g0, sa, sb, np.array([0.0]), 0.5)
    chk('ⓑ4 r=0 → g 비트 동일', gi[0].hex() == g0[0].hex())

    # ── ⓒ 두 블록 직렬 해석해 ──────────────────────────────────────────────────
    sig = np.array([0.0, 1.0, 0.0, 4.0])                   # sid 1 σ=1 · sid 3 σ=4 (S/cm)
    sid = np.ones((6, 6, 10), np.int8); sid[:, :, 5:] = 3
    kw = dict(z_bot_um=0.0, z_top_um=5.0)
    r0 = solve_sigma_z(sid, sig, 0.5, return_field=True, **kw)
    r1 = solve_sigma_z(sid, sig, 0.5, return_field=True, rint={(1, 3): 1e-4}, **kw)
    exp = 5.0 / (2.5 + 0.625 + 1.0)                        # r′ = 1e-4·1e4 = 1 µm·cm/S
    chk(f'ⓒ1 직렬 σ_eff = L/(L_a/σ_a + L_b/σ_b + r′) = {exp:.6f}',
        abs(r1['sigma_eff'] - exp) < 2e-4 * exp, f"{r1['sigma_eff']:.6f}")
    chk('ⓒ2 r 없음 → 옛 조화평균 1.6', abs(r0['sigma_eff'] - 1.6) < 1e-3)
    chk('ⓒ3 계면 원장: 36 면 · AM_S|VGCF · 모델 표지',
        r1['interface']['n_faces_rint'] == 36 and r1['interface']['faces_by_pair'] == {'AM_S|VGCF': 36}
        and r1['interface']['model'] == INTERFACE_MODEL_VERSION and r1['interface']['unit'] == 'ohm_cm2'
        and r1['interface']['table'] == {'AM_S|VGCF': 1e-4}, repr(r1.get('interface')))
    chk('ⓒ4 r 없음 → interface None', r0.get('interface') is None)
    chk('ⓒ5 계면 항은 σ 를 **내린다** (상한 가지에서 내려온다)', r1['sigma_eff'] < r0['sigma_eff'])

    # ── ⓓ 비트 동일 ────────────────────────────────────────────────────────────
    #  ⚠ 2026-10-03 (G1-2) — '격자에 없는 쌍' 은 **σ 표에서 그 상이 전도체**여야 한다 (RINT-14 채널 검사:
    #    표가 σ=0 이라 적은 상은 '없음' 이 아니라 '절연' 이다 → 거부 · ⓚ1).  sid 2 에 σ>0 를 준 표로 바꾼다
    #    (격자에 sid 2 가 없으므로 σ 격자 · 해는 r0 와 같다).  '같은 상 쌍 · pid 없음' 은 이제 거부 (ⓚ3).
    sig_abs = np.array([0.0, 1.0, 2.0, 4.0])
    for lbl, tb, sg in (('{}', {}, sig), ('r=0', {(1, 3): 0.0}, sig), ('격자에 없는 쌍', {(1, 2): 1e-3}, sig_abs),
                        ('같은 상 쌍 · r=0 · pid 없음', {(1, 1): 0.0}, sig)):
        rr = solve_sigma_z(sid, sg, 0.5, return_field=True, rint=tb, **kw)
        chk(f'ⓓ {lbl}: σ_eff 비트 동일 · φ 동일 · 계면 면 0',
            rr['sigma_eff'].hex() == r0['sigma_eff'].hex() and np.array_equal(rr['phi'], r0['phi'])
            and (rr.get('interface') or {}).get('n_faces_rint', 0) == 0)

    # ── ⓔ 같은 상 · 다른 입자 번호 (pid) ───────────────────────────────────────
    sid1 = np.ones((6, 6, 10), np.int8); sig1 = np.array([0.0, 1.0])
    pid = np.zeros(sid1.shape, np.int32); pid[:, :, 5:] = 1
    rb = solve_sigma_z(sid1, sig1, 0.5, return_field=True, **kw)
    rp = solve_sigma_z(sid1, sig1, 0.5, return_field=True, rint={(1, 1): 1e-4}, pid=pid, **kw)
    chk('ⓔ1 pid 경계 직렬: 5/(5 + 1) = 0.8333', abs(rp['sigma_eff'] - 5.0 / 6.0) < 2e-4, f"{rp['sigma_eff']:.6f}")
    chk('ⓔ2 원장: AM_S|AM_S 36 면 · pid_used', rp['interface']['faces_by_pair'] == {'AM_S|AM_S': 36}
        and rp['interface']['pid_used'] is True and r1['interface']['pid_used'] is False)
    rp0 = solve_sigma_z(sid1, sig1, 0.5, return_field=True, rint={(1, 1): 1e-4},
                        pid=np.zeros(sid1.shape, np.int32), **kw)
    chk('ⓔ3 pid 전부 같음 → 비트 동일', rp0['sigma_eff'].hex() == rb['sigma_eff'].hex()
        and np.array_equal(rp0['phi'], rb['phi']))
    rpn = solve_sigma_z(sid1, sig1, 0.5, return_field=True, rint={(1, 1): 1e-4},
                        pid=np.full(sid1.shape, -1, np.int32), **kw)
    chk('ⓔ4 pid −1 (입자 아님) 는 경계가 아니다 → 비트 동일', rpn['sigma_eff'].hex() == rb['sigma_eff'].hex())
    chk('ⓔ5 pid 모양 불일치는 거부', _raises(lambda: solve_sigma_z(sid1, sig1, 0.5, rint={(1, 1): 1e-4},
                                                                pid=np.zeros((2, 2, 2), np.int32), **kw)))
    chk('ⓔ6 표가 dict 가 아니면 거부 (문자열 목록은 parse_rint_table 로)',
        _raises(lambda: solve_sigma_z(sid1, sig1, 0.5, rint=['AM_S|AM_S=1e-4'], **kw)))

    # ── ⓕ 병렬 기둥 사이 계면 (전류와 나란함) · ⓖ 주기 wrap ───────────────────
    sidp = np.ones((6, 6, 10), np.int8); sidp[3:, :, :] = 3
    rpar0 = solve_sigma_z(sidp, sig, 0.5, **kw)
    rpar1 = solve_sigma_z(sidp, sig, 0.5, rint={(1, 3): 1e-2}, **kw)
    chk('ⓕ1 병렬 기둥 사이 계면 → σ_eff 불변 (산술평균 2.5)',
        abs(rpar1['sigma_eff'] - rpar0['sigma_eff']) < 1e-6 and abs(rpar0['sigma_eff'] - 2.5) < 1e-3,
        f"{rpar0['sigma_eff']:.6f} → {rpar1['sigma_eff']:.6f}")
    chk('ⓕ2 계면 면 수 = 한 평면 6×10 = 60', rpar1['interface']['n_faces_rint'] == 60)
    rper = solve_sigma_z(sidp, sig, 0.5, rint={(1, 3): 1e-2}, periodic_xy=True, **kw)
    chk('ⓖ 주기 x wrap 면 (5↔0) 도 계면 → 120', rper['interface']['n_faces_rint'] == 120)

    # ── ⓗ 소산 분담 ────────────────────────────────────────────────────────────
    sh = phase_current_share(r1, sid, sig)
    tot = 2.5 + 0.625 + 1.0
    chk('ⓗ1 분담: AM_S 2.5/4.125 · VGCF 0.625/4.125 · 계면 1/4.125',
        abs(sh[1] - 2.5 / tot) < 2e-3 and abs(sh[3] - 0.625 / tot) < 2e-3
        and abs(sh[SID_INTERFACE] - 1.0 / tot) < 2e-3,
        ' · '.join(f'{k}:{v:.4f}' for k, v in sh.items()))
    chk('ⓗ2 합 = 1', abs(sum(sh.values()) - 1.0) < 1e-9)
    sh0 = phase_current_share(r0, sid, sig)
    chk('ⓗ3 r 없음 → 계면 키 없음 · 옛 분담 (AM_S 0.8 · VGCF 0.2)',
        SID_INTERFACE not in sh0 and abs(sh0[1] - 0.8) < 2e-3 and abs(sh0[3] - 0.2) < 2e-3)
    chk('ⓗ4 share_label', share_label(SID_INTERFACE) == 'interface' and share_label(3) == 'VGCF')

    # ── ⓘ 전류 진단의 일관성 (계면 면 전류 연속) ──────────────────────────────
    #  진단의 g 는 조립과 달리 ×vox 가 없다 (`_voxel_jmag` docstring) → 면 전류 = σ_eff·vox/L [S/cm]
    i_col = r1['sigma_eff'] * 0.5 / 5.0
    sigf = sigma_field(sig, sid)
    jm_new = _voxel_jmag(r1['phi'], r1['cond'], sigf, rint_ctx=rint_ctx_from(r1, sid))
    jm_old = _voxel_jmag(r1['phi'], r1['cond'], sigf)      # 옛 재계산 (계면 모름)
    chk('ⓘ1 |J| 내부 셀 전부 = 기둥 전류 (계면 면 포함, 1e-6)',
        np.allclose(jm_new[:, :, 1:9], i_col, rtol=1e-6, atol=0.0),
        f'min {jm_new[:, :, 1:9].min():.6g} max {jm_new[:, :, 1:9].max():.6g} vs {i_col:.6g}')
    chk('ⓘ2 옛 재계산은 계면 양옆 셀에서 **과대** (수정이 필요했던 이유)',
        not np.allclose(jm_old[:, :, 1:9], i_col, rtol=1e-6, atol=0.0)
        and jm_old[:, :, 4:6].max() > i_col * 1.1)
    je = per_particle_current(r1, sid, np.zeros(sid.shape, np.int32), sig, 1)[0]
    chk('ⓘ3 입자별 J_z (한 입자) = 0.9·기둥 전류 (양 끝 셀은 면 하나)', abs(je - 0.9 * i_col) < 1e-6 * i_col,
        f'{je:.6g} vs {0.9 * i_col:.6g}')
    _, _, st = field_point_cloud(r1, sid, sig, 0.5, (1, 3))
    chk('ⓘ4 field_point_cloud 전수 평균 = 0.9·기둥 전류', abs(st['mean'] - 0.9 * i_col) < 1e-6 * i_col)
    jh = joule_hotspot(r1, sid, sig, 0.5, (1, 3))
    chk('ⓘ5 joule_hotspot 도 같은 |J| (내부 셀 q = J²/σ 두 값뿐)', jh is not None and jh['n'] == 360)
    chk('ⓘ6 r 없는 res 의 rint_ctx 는 None (옛 경로 그대로)', rint_ctx_from(r0, sid) is None)

    # ── ⓙ G1 (Codex 1단계 판정 10-03 · 1저자 비준) — 반례를 먼저 옮긴 것 ──────────────
    #  ⓙ1 RINT-01: 같은 상 계면은 **pid 가 입자 번호인 상 (AM)** 에서만.  첨가제 스탬프는 sid 만
    #     바꾸고 pid (= 밑의 AM 번호) 를 남기므로, VGCF|VGCF 등을 pid 로 가르면 한 가닥 안에 가짜 면.
    for bad in (['VGCF|VGCF=1e-4'], ['SE|SE=1e-2'], ['SDCP|SDCP=1'], ['SuperP|SuperP=1'],
                ['SWCNT|SWCNT=1'], ['PTFE|PTFE=1'], ['SE_blk|SE_blk=1']):
        chk(f'ⓙ1 parse 거부 (같은 상 · AM 아님) {bad}', _raises(lambda b=bad: parse_rint_table(b)))
    chk('ⓙ1 parse 허용 AM_S|AM_S · AM_P|AM_P',
        parse_rint_table(['AM_S|AM_S=1e-4', 'AM_P|AM_P=2e-4']) == {(1, 1): 1e-4, (2, 2): 2e-4})
    #  ⓙ2 RINT-12: 솔버 API 입구 — 같은 상 비-AM · 조용한 형 변환 · 모르는 sid · bool · 문자열
    for lbl, tb in (('VGCF|VGCF', {(3, 3): 1e-4}), ('SE|SE', {(6, 6): 1e-2}),
                    ('float sid (1.7,3)', {(1.7, 3): 1e-3}), ('bool sid', {(True, 3): 1e-3}),
                    ('bool 값', {(1, 3): True}), ('모르는 sid 0 (pore)', {(0, 3): 1e-3}),
                    ('모르는 sid 42', {(1, 42): 1e-3}), ('문자열 값', {(1, 3): '1e-3'})):
        chk(f'ⓙ2 API 거부 {lbl}', _raises(lambda t=tb: _check_rint_table(t)))
    chk('ⓙ2 API 허용: numpy 정수 키 · numpy 실수 값',
        _check_rint_table({(np.int64(3), np.int8(1)): np.float32(1e-3)}) == {(1, 3): float(np.float32(1e-3))})
    #  ⓙ3 면 규칙 자체도 거부 (입구 검사를 우회한 표)
    chk('ⓙ3 face_rint 가 같은 상 비-AM 표를 거부',
        _raises(lambda: face_rint(np.array([3]), np.array([3]), {(3, 3): 1e-4}, np.array([0]), np.array([1]))))
    #  ⓙ4 RINT-01 원 반례 (한 가닥 VGCF 에 AM pid 0/1/2) → 솔브 입구에서 거부 · AM 두 입자 막은 그대로
    sidv = np.full((4, 4, 10), 3, np.int8); sigv = np.array([0.0, 1.0, 0.0, 100.0])
    pidv = np.zeros(sidv.shape, np.int32); pidv[:, :, 4:7] = 1; pidv[:, :, 7:] = 2
    chk('ⓙ4 VGCF|VGCF + AM pid 침대 → 솔브 거부 (옛: 가짜 면 · σ 붕괴)',
        _raises(lambda: solve_sigma_z(sidv, sigv, 0.5, rint={(3, 3): 1e-4}, pid=pidv, **kw)))
    rp2 = solve_sigma_z(sid1, sig1, 0.5, return_field=True, rint={(1, 1): 1e-4}, pid=pid, **kw)
    chk('ⓙ4 서로 다른 두 AM 입자 사이 막은 남는다 (5/6)', abs(rp2['sigma_eff'] - 5.0 / 6.0) < 2e-4)
    #  ⓙ5 RINT-03: 입자별 AM 전류 = **최종 sid 가 AM 인 셀**만.  탄소 셀이 AM pid 를 물려받아도 안 센다
    sidj = np.ones((6, 6, 10), np.int8); sidj[0:2, :, :] = 3           # x 0–1 = VGCF (σ 100) · 나머지 AM_S (σ 1)
    sigj = np.array([0.0, 1.0, 0.0, 100.0])
    pidj = np.zeros(sidj.shape, np.int32)                             # 전 셀이 입자 0 의 번호를 가진 상황
    rj = solve_sigma_z(sidj, sigj, 0.5, return_field=True, **kw)
    sgj = sigma_field(sigj, sidj); Pj, cj = rj['phi'], rj['cond']
    bj = cj[:, :, :-1] & cj[:, :, 1:]
    gj = np.where(bj, 2.0 * sgj[:, :, :-1] * sgj[:, :, 1:] / np.maximum(sgj[:, :, :-1] + sgj[:, :, 1:], 1e-30), 0.0)
    fj = gj * (Pj[:, :, :-1] - Pj[:, :, 1:])
    jzj = np.zeros(sidj.shape); jzj[:, :, :-1] += np.abs(fj) * 0.5; jzj[:, :, 1:] += np.abs(fj) * 0.5
    exp_am, exp_all = float(jzj[sidj == 1].mean()), float(jzj.mean())
    je_j = per_particle_current(rj, sidj, pidj, sigj, 1)[0]
    chk('ⓙ5 je = AM 셀만의 |J_z| 평균', abs(je_j - exp_am) <= 1e-12 * max(exp_am, 1e-30),
        f'{je_j:.6g} vs AM {exp_am:.6g} · 전 셀 {exp_all:.6g}')
    chk('ⓙ5 (판별력) 탄소 셀을 넣은 옛 집계는 크게 다르다 (> 5×)', exp_all > 5.0 * exp_am)
    pidx = pidj.copy(); pidx[3, 3, 3] = 7                             # n_am=1 밖 번호 — 옛 코드는 IndexError
    try:
        je_x = per_particle_current(rj, sidj, pidx, sigj, 1)[0]
        chk('ⓙ5 유효 pid 마스크 (n_am 밖 번호는 셈에서 빠진다)', np.isfinite(je_x))
    except IndexError:
        chk('ⓙ5 유효 pid 마스크 (n_am 밖 번호는 셈에서 빠진다)', False, 'IndexError')
    #  ⓙ6 RINT-11: r 표는 있는데 걸린 면이 0 이면 진단도 옛 경로 그대로 (분담 키 · 값 비트 동일)
    sh_off = phase_current_share(r0, sid, sig)
    for lbl, tb, sg in (('r=0', {(1, 3): 0.0}, sig), ('격자에 없는 쌍', {(1, 2): 1e-3}, sig_abs)):
        rr = solve_sigma_z(sid, sg, 0.5, return_field=True, rint=tb, **kw)
        shz = phase_current_share(rr, sid, sg)
        chk(f'ⓙ6 {lbl}: 면 0 → 진단 맥락 없음 · 분담 키 · 값 비트 동일 · 원장은 남음',
            rint_ctx_from(rr, sid) is None and set(shz) == set(sh_off)
            and all(float(shz[k]).hex() == float(sh_off[k]).hex() for k in sh_off)
            and rr.get('interface') is not None and rr['interface']['n_faces_rint'] == 0)
    #  ⓙ7 RINT-19: 진단 맥락 무결성 — 다른 sid · 다른 σ · 솔브 뒤 바뀐 pid 로는 진단하지 않는다
    chk('ⓙ7 다른 sid (같은 모양) 로 맥락 요청 → 거부',
        _raises(lambda: rint_ctx_from(r1, np.where(sid == 3, 1, 3).astype(sid.dtype))))
    chk('ⓙ7 다른 σ 표로 분담 → 거부', _raises(lambda: phase_current_share(r1, sid, np.array([0.0, 1.0, 0.0, 8.0]))))
    pidm = np.zeros(sid1.shape, np.int32); pidm[:, :, 5:] = 1
    rpm = solve_sigma_z(sid1, sig1, 0.5, return_field=True, rint={(1, 1): 1e-4}, pid=pidm, **kw)
    chk('ⓙ7 솔브 직후 진단 = 계면 몫 > 0', phase_current_share(rpm, sid1, sig1).get(SID_INTERFACE, 0.0) > 0.0)
    pidm[...] = 0                                                     # 호출자가 솔브 뒤 배열을 바꾼다
    chk('ⓙ7 솔브 뒤 pid 가 바뀌면 → 거부 (옛: 저장 면은 그대로인데 계면 몫 0)',
        _raises(lambda: phase_current_share(rpm, sid1, sig1)))

    # ── ⓚ G1-2 (Codex Q4 · RINT-02 · 14) — 반례를 먼저 옮긴 것 ─────────────────────────
    #  ⓚ1 채널 검사 = **이 채널의 실제 σ 표** (override · 온도가 끝난 것) — 절연 상이 낀 쌍은 어떤 면도 못
    #     만들어 요청이 조용히 무효 ("면 0" 하나로 덮임) → 거부.  기본 이름 허용목록으로 판정하지 않는다.
    _te = electronic_sigma_table(0.010, 0.005, 100.0, 10.0, 250.0)
    _ti = ionic_sigma_table(1e-3, 3e-3)
    chk('ⓚ1 전자 표에서 AM_S|SE (SE σ_e = 0) → 거부',
        _raises(lambda: solve_sigma_z(sid, _te, 0.5, rint={(1, 6): 1e-3}, **kw)))
    chk('ⓚ1 이온 표에서 AM_S|SE (AM σ_ion = 0) → 거부',
        _raises(lambda: solve_sigma_z(sid, _ti, 0.5, rint={(1, 6): 1e-3}, **kw)))
    chk('ⓚ1 override 로 절연이 된 상 (σ_VGCF = 0) 의 쌍 → 거부 (이름이 아니라 실제 표)',
        _raises(lambda: solve_sigma_z(sid, electronic_sigma_table(0.010, 0.005, 0.0, 10.0, 250.0), 0.5,
                                      rint={(1, 3): 1e-3}, **kw)))
    _rk = solve_sigma_z(sid, _ti, 0.5, rint={(5, 6): 1e-3}, **kw)
    chk('ⓚ1 이온 표의 SDCP|SE (둘 다 전도 · 격자에 없음) → 허용 · 면 0',
        (_rk.get('interface') or {}).get('n_faces_rint') == 0, repr(_rk.get('interface')))
    chk('ⓚ1 공개 함수: 표 밖 sid → 거부', _raises(lambda: rint_channel_check({(1, 12): 1e-3}, _te)))
    #  ⓚ2 복셀별 σ 장 — 그 상이 격자에 **있으면** 셀 값으로 본다 (없으면 면 0 = 영수증 absent_geometry 소관)
    _fz = sigma_field(sig, sid).copy(); _fz[sid == 3] = 0.0
    chk('ⓚ2 복셀 σ 장: 있는 상의 셀이 전부 0 → 거부', _raises(lambda: rint_channel_check({(1, 3): 1e-3}, _fz, sid)))
    chk('ⓚ2 복셀 σ 장: 격자에 없는 상은 판정 안 함 (허용)',
        not _raises(lambda: rint_channel_check({(1, 2): 1e-3}, sigma_field(sig, sid), sid)))
    #  ⓚ3 unsupported identity — 같은 상 AM 쌍 (r > 0) 인데 pid 없음 → 거부 (옛: 면 0 으로 조용히 무효)
    chk('ⓚ3 AM_S|AM_S r>0 · pid 없음 → 거부', _raises(lambda: solve_sigma_z(sid1, sig1, 0.5, rint={(1, 1): 1e-4}, **kw)))
    #  ⓚ4 조기 반환 해도 계면 기록을 싣는다 (solved False) — 요청 표가 이 호출에 **전달됐는지** 영수증이 안다
    _rd = solve_sigma_z(sid, sig, 0.5, rint={(1, 3): 1e-4}, z_bot_um=0.0, z_top_um=0.5)
    _ri = _rd.get('interface') or {}
    chk('ⓚ4 조기 반환 (degenerate_thin_bed) 에도 interface 기록 · solved False · 표 · 면 0',
        _rd.get('reason') == 'degenerate_thin_bed' and _ri.get('solved') is False
        and _ri.get('table') == {'AM_S|VGCF': 1e-4} and _ri.get('n_faces_rint') == 0, repr(_rd))
    chk('ⓚ4 r 없는 조기 반환 → interface None',
        solve_sigma_z(sid, sig, 0.5, z_bot_um=0.0, z_top_um=0.5).get('interface', 'absent') is None)
    chk('ⓚ5 정상 해의 기록은 solved True', r1['interface'].get('solved') is True)

    # ── ⓛ G1-3 (Codex RINT-04) — Joule 지도는 **bulk 셀 J²/σ 만** 이다: 범위 · 포함 · 제외를 결과가 말한다 ──
    #  두 슬래브 + r 에서 계면 소산이 대부분인데 지도 ON/OFF 가 거의 같다 (Codex 탐침: 최대 차 2.03e−6 · hot_frac_50
    #  둘 다 0.425) — bulk 소산으로는 맞고, **총 발열 hotspot 으로 읽는 것**이 틀린 것.
    _jh = joule_hotspot(r1, sid, sig, 0.5, (1, 3)) or {}
    chk('ⓛ1 joule_hotspot 결과에 scope = bulk_only', _jh.get('scope') == 'bulk_only', repr(_jh.get('scope')))
    chk('ⓛ2 제외 항목 = 계면 I²R · 판 결합 간선 (지도 밖)',
        set(_jh.get('excluded') or ()) >= {'interface_I2R', 'plate_coupling'}, repr(_jh.get('excluded')))
    chk('ⓛ3 포함 항목 = bulk 셀 J²/σ', _jh.get('included') == ['bulk_cell_J2_over_sigma'], repr(_jh.get('included')))
    print('STEP3 RINT SELFTEST', 'PASS' if ok else 'FAIL')
    return 0 if ok else 1


def _raises(fn):
    try:
        fn()
    except (ValueError, TypeError):
        return True
    return False


if __name__ == '__main__':
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument('--selftest', action='store_true', help='run the analytic laminate/percolation checks')
    ap.add_argument('--selftest-rint', action='store_true',
                    help='① 상 경계 계면 저항 r_int 검증 (파서 · 직렬 해석해 · 비트 동일 · pid 경계 · '
                         '소산 분담 · 전류 진단 일관성)')
    ap.add_argument('--selftest-rxn', action='store_true',
                    help='STEP4 sandwich analytic (series-R total current + uniform per-particle i + KCL)')
    ap.add_argument('--selftest-pore', action='store_true',
                    help='A6 pore-τ analytic checks (crop / PTFE stamp / TauFactor convention)')
    ap.add_argument('--selftest-pnm', action='store_true',
                    help='A13 pore-PNM checks (dumbbell 2-body/1-throat / closure / thin fallback)')
    ap.add_argument('--selftest-swcnt', action='store_true',
                    help='A14 SWCNT sheath 스탬프 검증 (phase6→sid8, 전자-도체/이온-투명 테이블)')
    ap.add_argument('--selftest-segstamp', action='store_true',
                    help='SR-01 opt-in 선분 스탬프 (기본 불변 + 연결 보장 + AM 관통 방지)')
    ap.add_argument('--integration', action='store_true',
                    help='run the committed real14 integration probe (AM-only vs +300 synthetic VGCF, '
                         'seed 0, vox 0.4) — reproduces the review-anchored numbers + monotonicity')
    ap.add_argument('--selftest-temp', action='store_true',
                    help='σ_ion(T) 규약 검증 (se_material 위임: T=None bitwise / 25 °C / 문서 배수표)')
    ap.add_argument('--selftest-trackb', action='store_true',
                    help='Track-B 헬퍼 검증 (τ 선형 관례 · κ_dom 이중계상 가드 · AM face walk)')
    se_material.temperature_argparse(ap)   # --temp-c / --ea-ion-ev (both default None)
    a = ap.parse_args()
    if a.selftest_temp:
        sys.exit(_selftest_temp())
    if a.selftest_trackb:
        sys.exit(_selftest_trackb())
    if a.temp_c is not None:               # resolve + report the SE ionic σ this run would use
        _p = temperature_provenance(a.temp_c, a.ea_ion_ev)
        print(f"σ_ion(SE) @ {a.temp_c:.1f} °C = {sigma_ion_se_S_cm(a.temp_c, a.ea_ion_ev):.6g} S/cm "
              f"(T_ref={_p['T_ref_C']:.0f} °C, Ea={_p['Ea_ion_eV']} eV, {_p['convention']})")
        se_material.warn_band(a.temp_c, a.ea_ion_ev)
        print('  ⇒ pass the same --temp-c to mpm_webapp_payload (which builds the sig_i table).')
        sys.exit(0)
    if a.selftest:
        sys.exit(_selftest())
    if a.selftest_rint:
        sys.exit(_selftest_rint())
    if a.selftest_rxn:
        sys.exit(_selftest_rxn())
    if a.selftest_pore:
        sys.exit(_selftest_pore())
    if a.selftest_pnm:
        sys.exit(_selftest_pnm())
    if a.selftest_swcnt:
        sys.exit(_selftest_swcnt())
    if a.selftest_segstamp:
        sys.exit(_selftest_segstamp())
    if a.integration:
        import os
        _csv = os.path.join(os.path.dirname(__file__), '..', 'docs/data/real14_am_scaffold.csv')
        am = np.loadtxt(_csv, delimiter=',', comments='#')
        t, c, r = am[:, 0].astype(int), am[:, 1:4] * 1000.0, am[:, 4] * 1000.0
        c[:, 2] -= (c[:, 2] - r).min()
        hi = (50.0, 50.0, float((c[:, 2] + r).max()))
        rng = np.random.default_rng(0)
        pts = []
        for _ in range(300):
            p0 = rng.uniform([0, 0, 0], hi); d = rng.normal(size=3); d /= np.linalg.norm(d)
            pts.append(p0 + np.outer(np.arange(0, 10, 0.2), d))
        pts = np.concatenate(pts); ph = np.full(len(pts), 2)
        inb = ((pts >= 0) & (pts < hi)).all(1); pts, ph = pts[inb], ph[inb]
        sig = np.array([0.0, 0.010, 0.005, 100.0, 10.0, 150.0, 0.0])
        out = {}
        for label, ap_, aph in (('AM-only', None, None), ('AM+VGCF', pts, ph)):
            sid, pid = rasterize(c, r, t, ap_, aph, (0, 0, 0), hi, 0.4)
            res = solve_sigma_z(sid, sig, 0.4, z_top_um=hi[2], z_bot_um=0.0)
            out[label] = res['sigma_eff']
            print(f"[{label:8s}] σ_eff={res['sigma_eff']:.4g} S/cm  dof={res['n_dof']:,} "
                  f"plate_vox={res['n_plate_vox']} resid={res['resid']:.1e}")
        boost = out['AM+VGCF'] / max(out['AM-only'], 1e-30)
        print(f"carbon boost ×{boost:.2f}  → {'PASS (monotone)' if boost > 1.0 else 'FAIL'}")
        sys.exit(0 if boost > 1.0 else 1)
    ap.print_help()

# ordinary cwd file

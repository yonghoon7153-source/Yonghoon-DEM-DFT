"""Check saved fixed-pin source responses; do not execute fetched source."""
import hashlib
import json
from pathlib import Path

ROOT=Path(__file__).resolve().parent.parent
P=ROOT/'package'
PIN='fe90b0bd0212da6fba8dffd56991a0b2bbea9615'
raw=json.loads((ROOT/'evidence/remote_fetched_sources.json').read_text(encoding='utf8'))
texts={(r['pin'],r['path']):r['response']['structuredContent']['content'].encode('utf8') for r in raw}
def sha(b): return hashlib.sha256(b).hexdigest()
def blob(b): return hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
commit=json.loads((ROOT/'evidence/github_commit_metadata.json').read_text(encoding='utf8'))
added={f['filename']:f['sha'] for f in commit['files']}
manifest=json.loads((P/'SNAPSHOT_MANIFEST.json').read_text(encoding='utf8'))
snapshot=[]
for e in manifest['entries']:
    if e['path'] in added:
        actual=added[e['path']]; via='fixed_commit_blob'
    else:
        data=texts[PIN,e['path']]
        assert data==(P/e['path']).read_bytes()
        actual=blob(data); via='fixed_pin_raw_content'
    assert actual==e['git_blob']
    snapshot.append({'path':e['path'],'match':True,'via':via})
source_inventory=json.loads((P/'docs/reviews/lhs_pressure_n_dependence_draft_20261106/source_inventory.json').read_text(encoding='utf8'))
source_hashes=[]
for e in source_inventory['sources']:
    digest=sha(texts[PIN,e['path']])
    assert digest==e['sha256'], e['path']
    source_hashes.append({'path':e['path'],'sha256_match':True})
preserved=[]
for (pin,path), data in texts.items():
    if pin != PIN:
        assert data==texts[PIN,path], (pin,path)
        preserved.append({'path':path,'baseline_pin':pin,'bytes_unchanged':True})
    dest=ROOT/'evidence/remote_sources'/pin/path
    dest.parent.mkdir(parents=True,exist_ok=True)
    dest.write_bytes(data)
result={'pin':PIN,'snapshot':snapshot,'source_inventory_hashes':source_hashes,'additional_baseline_comparisons':preserved,
        'remote_source_tools_executed':False,'archive_or_research_result_opened':False}
print(json.dumps(result,indent=2))

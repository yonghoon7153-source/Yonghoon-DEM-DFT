# wishlist 원문 오류 · 낡은 칸 목록 (적기만 · 고치지 않음)

만든 날 2026-11-16 · 대상 = 정본 가지 `litdb/_curation/wishlist.md` (커밋 `e958f2571` · 408 줄).  L = 그 파일의 줄 번호 · bNN = 배치 절 · W = `wishlist_table.md` 의 번호.
고칠지 · 어떻게 고칠지는 1저자 (또는 wishlist 를 관리하는 세션) 가 정한다.  이 문서는 wishlist · status.tsv 를 한 글자도 바꾸지 않았다.

## 1. 지금은 카드 · 후보 표가 있는데 줄은 '카드 없음' 인 것 (6 편 · 7 줄)

그때 확인은 맞았고 그 뒤 카드가 생겼다.  표의 상태 칸은 지금 기준으로 적었다.

| W | wishlist 줄 | 그 줄의 확인 칸 | 지금 | 같은 논문 근거 (카드 머리) |
|---|---|---|---|---|
| W021 Choi 2018 | L40 (b50) | 카드 없음 (PDF 가 inbox 에 이미 있다: `…-14.…`) | 카드 `choi2018_fibsem_3d_composite_cathode_microstructure_tpb_pore_decomposition` (= 후보 표 N-14) | ACS Appl. Mater. Interfaces 10 (2018) 23740–23747 · 저자 같음 |
| W030 Meyer 2018 | L54 (b64) | 카드 없음 | 카드 `meyer2018_calendering_process_model_active_material_mass_loading` (= N-61) | DOI 10.1016/j.est.2018.05.018 · J. Energy Storage 18, 371–379 |
| W034 Sonzogni 2024 | L61 (`[대피 · 11-12]`) | 후보 표 N-68 | 카드 `sonzogni2024_dem_rotating_roll_calendering_binder_coated_nmc811` | DOI 10.1016/j.powtec.2024.119891 |
| W112 Sulsky 1994 | L194 (b58) · (참고 줄 L190 b57 · L296 b79 · L305 b78 은 'N-40 에 이미 있다') | sulsky* 없음 → 카드 없음 | 카드 `sulsky1994_mpm_particle_method_history_dependent_materials` (= N-40) | CMAME 118 (1994) 179–196 |
| W144 Ge 2022 | L242 (b69) | `ge2022*` 없음 · DOI grep 0 건 → 카드 없음 | 카드 `ge2022_xct_initial_structure_dem_calendering_nmc333` (= N-67) | DOI 10.1016/j.powtec.2022.117366 |
| W011 Bielefeld 2022 | L25 (b46) · L64 (b101) | 카드 없음 | 후보 표 N-89 (PDF 받음 · status.tsv '차례 기다림') | queue.json N-89 = J. Electrochem. Soc. 169 (2022) 020539 |

## 2. 같은 논문을 다르게 적은 줄 · 두 번 올린 줄

| W | 줄 | 다른 점 |
|---|---|---|
| W013 Perrenot 2023 AFM | L27 (b46) ↔ L47 (b61) | L27 = "Adv. Funct. Mater. 2023, 34, 2310739" (제목 없음) · L47 = 제목 있음 · "Adv. Funct. Mater. n/a (n.d.) 2310739" — 해 · 권이 두 줄에서 다르다.  L26 (b46) Perrenot ACS Energy Lett. 2023, 8, 4531 (W012) 은 다른 논문. |
| W114 Sulsky & Schreyer 1996 | L196 (b58) ↔ L275 (b74) | L275 = "Schreyer HK" (L196 은 H. L.) · "Axisymnmetric" 철자 — L275 은 '원문 인쇄 그대로' 이고 스스로 'L196 에 이미 있음' 표시 |
| W109 Love & Sulsky | L188 (b57) ↔ 참고 줄 L288 (b77) · L305 (b78) | L188 = "2005; 65:1608–1638" · 참고 줄 = "(2006) IJNME 65 (10), 1608–1638" — 같은 권 · 쪽에 해만 다름 (L305 스스로 '그 줄 연도 2005' 표시) |
| W106 Steffen, Kirby, Berzins 2008 IJNME | L185 (b57) · L284 (b77) · L301 (b78) | 세 줄 · L284 는 권 · 쪽 없이 DOI 만 · L301 스스로 '같은 서지 이미 있음' |
| W107 Wallstedt & Guilkey 2008 JCP | L186 (b57) · L283 (b77) · L302 (b78) | 세 줄 · L283 = "To Appear In Journal of Computational Physics" (권 · 쪽 없음) · L283 · L302 스스로 표시 |
| W170 Nairn 2006 Wood Fiber Sci. | L287 (b77) ↔ L304 (b78) | 같은 서지 두 줄 (표시 없음) |
| W076 Lee 2020 Nat. Energy | L130 (b121) ↔ L138 (b116) | 저자 철자 두 곳: "Yashiro, N." ↔ "N. YAHIRO" · "Ku, J. H." ↔ "L. H. KU" |
| W062 Song 2023 Appl. Energy | L107 (b105) ↔ L238 (b69) | L238 스스로 'L107 에 이미 있음' |
| W121 Zhou 1999 Physica A | L208 (b62) ↔ L392 (b90) · 참고 줄 L264 (b72) · L354 (b85) | L392 스스로 'L208 에 이미 있음 (새로 올리지 않음)' 인데 `[n]` 줄로 올라 있음 |
| W122 Iwashita & Oda 1998 | L209 (b62) ↔ L393 (b90) | L209 = "J. Eng. Mech. Asce" · L393 스스로 'L209 에 이미 있음 (새로 올리지 않음)' 인데 `[n]` 줄로 올라 있음 |
| W011 Bielefeld 2022 | L25 (b46) ↔ L64 (b101) · 참고 줄 L339 (b83) | L25 는 제목 없음 (서지 일부만) |
| W100 Märker | L174 (b54) ↔ 참고 줄 L220 (b63) | L174 = "Chem. Mater., 31, 2545 (2017)" · L220 = "Märker 2019 Chem. Mater. 31, 2545" — 같은 권 · 쪽에 해만 다름 (L174 스스로 '연도 표기 원문 그대로 · 확인 [미확인]') |
| W145 Martin, Bouvard, Shima 2003 | L245 (b70) ↔ 참고 줄 L235 (b68) | L235 = 학술지 이름 없는 판 (L245 스스로 표시) |
| W067 Froboese 2017 | L115 (b107) ↔ 참고 줄 L86 (b104) | L86 = "Mater. Charact. (accepted · 권 · 쪽 원문에 없음)" |
| W168 Tran, Kim, Berzins | L285 (b77) ↔ 참고 줄 L305 (b78) | L285 = 2007 기술 보고서 · L305 = IJNMF 2009 판이라 적고 'wishlist 에 2007 기술 보고서 판' 으로 같다고 봄 — 보고서 ↔ 학술지 판 **[같은지 미확인]** · L305 가 옮긴 인쇄 DOI 10.1002/nme.2360 은 Steffen 2008 (W106) 의 DOI (L305 스스로 '오기로 보임') |
| W044 Heckel 1961 | L81 (b104) | 학술지 약칭 "Transa. Metall. Soc. AIME" (Trans. 로 보임 · 인쇄 그대로인지 표시 없음) |

## 3. '원문 인쇄 그대로' 라 적힌 이상한 서지 (원문 확인 거리 · 대부분 줄이 스스로 표시)

| W | 줄 | 내용 |
|---|---|---|
| W054 · W055 Scott | L97 (b106) | 한 줄에 두 편 (Scott 1960 Nature 188, 908 + Scott & Kilgor 1969 Br. J. Appl. Phys. D 2, 863 · 제목 둘 다 없음 · 'Kilgor' 원문 철자) → 표에서 둘로 나눔 |
| W019 Dixit 2018 | L35 (b48) | 학술지 이름 없음 ("11, 2018, pp. 2022–2030") · DOI 10.1021/acsami.8b16536 — 줄 스스로 '학술지 이름 누락' |
| W083 Futami 2008 | L146 (b44) | "T. Futamia" (표에는 원문 그대로) |
| W095 Carneiro 1949 | L167 (b53) | "CARNIERO F. L. L. B." |
| W204 Cundall & Strack 1979 | L352 (b85) | "Stack" — 줄 스스로 'Stack 은 원문 표기' |
| W186 Benson 1992 | L320 (b81) | "D.J. Bensen" — 줄 스스로 '본문은 Benson' |
| W066 Hesabi 2007 | L114 (b107) | "Mater. Sci. Eng. A 454–455 (454–455)" 권 중복 — 줄 스스로 표시 |
| W016 Lei 2018 | L32 (b48) | 쪽 "17–619" — 줄 스스로 '쪽 인쇄 그대로' |
| W175 Matthies & Strang 1979 | L295 (b79) | 참고 번호 17 인데 '본문은 [16] 으로 오기' — 줄 스스로 표시 |
| W187 Harlow | L321 (b81) | "Vol. 3 (1964)" ↔ 가리킨 카드 L278 의 'Harlow 1963' — 줄 스스로 '다른 Harlow 문헌인지 확인' |

## 4. 낡은 'litdb 확인' 칸 (결론은 그대로 · 문장만 낡음)

| W | 줄 | 그 줄의 확인 칸 | 지금 |
|---|---|---|---|
| W126 Heenan 2020 Adv. Sci. 7, 2000362 | L215 (b63) | "papers/ 목록에 heenan* 없음 · '2000362' grep 0 건" | `heenan2020_nmc811_calendering_defects_cycling_cracking_multiscale_xct` (같은 배치가 만든 카드 · Adv. Energy Mater. 2002655 = 다른 논문) 가 생겼고 그 카드가 2000362 을 인용 — 이 논문 카드는 여전히 없음 |
| W089 Kalnaus 2021 J. Mater. Res. | L155 (b47) | "ls 'kalnaus' = 없음 (이 카드 넣기 전)" | `kalnaus2023_ssb_critical_role_of_mechanics_stress_relief_review` (같은 배치 카드 · Science 리뷰 = 다른 논문) 가 생김 — 이 논문 카드는 여전히 없음 |

1 절의 7 줄도 같은 부류다 (그때는 맞았고 지금은 카드 · 후보 표가 있다).

## 5. 꼴

- L3 이 정한 꼴은 `- [세션 · 날짜] 서지 — 왜 — 가리킨 카드 · 줄 — 중복 확인` 인데 `- [n]` 248 줄은 전부 `서지 | 왜 | litdb 확인` 세 칸이다 — **'가리킨 카드 · 줄' 칸이 없다** (L3 꼴을 따른 줄은 L61 `[대피 · 11-12]` 하나).  가리킨 카드는 배치 절 머리와 status.tsv '정독 NN' 으로만 짐작할 수 있고, 본 세션 배치 7 개 (43 · 45 · 46 · 48 · 50 · 61 · 64) 는 그 대응 기록도 없다.
- 한 줄에 두 논문: L97 (3 절).
- `[n]` 줄인데 스스로 '새로 올리지 않음' 이라 적은 줄: L392 · L393 (2 절).

## 6. 곁 — status.tsv (wishlist 밖 · 알림만)

status.tsv 가 '차례 기다림' 인데 정본 `papers/` 에 이미 카드가 있는 줄 (카드 머리의 학술지 · 해 · 권쪽 · DOI 가 status.tsv 메모와 같음):

| status.tsv 줄 | 메모 | 정본 카드 |
|---|---|---|
| N-65 | Swinkels 1983 Acta metall 31 1829 | `swinkels1983_hip_densification_plastic_yield_creep_mechanisms` |
| N-66 | Ebner 2013 Adv Energy Mater 3 845 | `ebner2013_srxtm_nmc_cathode_microstructure_open_dataset_segmentation` |
| N-67 | Ge 2022 Powder Technol 403 117366 | `ge2022_xct_initial_structure_dem_calendering_nmc333` |
| N-68 | Sonzogni 2024 Powder Technol 442 119891 | `sonzogni2024_dem_rotating_roll_calendering_binder_coated_nmc811` |
| N-69 | Stershic 2015 J Power Sources 297 540 | `stershic2015_fabric_tensor_calendering_nmc_xct_dem` |
| N-70 | Xu 2023 Batteries & Supercaps e202300371 | `xu2023_dem_bonded_particle_fracture_calendering` (DOI 10.1002/batt.202300371) |
| N-71 | Silbert 2001 PRE 64 051302 | `silbert2001_chute_flow_bagnold_spring_dashpot_hertz_dem` |
| N-72 둘째 | Walton 1993 Mech Mater 16 239 | `walton1993_chute_flow_hysteretic_normal_3d_tangential_contact_dem` |
| N-73 | Chouchane–Franco 2021 Batteries & Supercaps 4 1451 | `chouchane2021_innov_webapp_stochastic_generation_meshing` |
| N-74 | German 2014 Powder Technol 253 368 | `german2014_coordination_number_powder_densification` |
| N-75 | Mullikin–Verbeek 1993 Bioimaging 1 6 | `mullikin1993_surface_area_estimation_digitized_planes` |
| 후보 밖 (68 번 파일) | Kashkooli 2016 J Power Sources 307 496 | `kashkooli2016_nanoxct_lfp_multiscale_rev_tortuosity` |
| 보강 (68-1 번 파일) | zhang2026 카드 보강 | 카드에 '[보강 2026-11-16 …]' 표지가 이미 있음 |

## 7. 11-12 첫 판 (`scratchpad/wishlist_table.tsv` · `tools/wishlist_table.py`) 의 틀린 맞춤

첫 판은 그때의 wishlist (배치 24 · 열쇠 109) 를 '제1 저자 성 + 해' 열쇠로 묶고, 카드는 파일 이름 앞머리 (성 + 해) 로, 후보 표는 '성 · 해 낱말이 queue.json 글자 어딘가에 있음' 으로 맞췄다.  제목 · DOI 대조가 없어서 아래처럼 틀렸다.

**맞춤 21 가운데 17 이 틀림** (카드 있음 7 중 5 · 후보 표 14 중 12).

| 첫 판 열쇠 | 첫 판 판정 | 실제 |
|---|---|---|
| kim2023 | 카드 있음 (`kim2023_chemomech_failure_highstrain_anode` · `kim2023_mechanofusion_ncm811_lpscl_core_shell_intimate_contact`) | 줄 = Kim S. Y. 2023 ACS Energy Lett. 8, 521 · 카드 둘 = ENSM (10.1016/j.ensm.2023.103049) · AFM (10.1002/adfm.202211355) — 다른 논문 → PDF 필요 (W023) |
| lu2020 | 카드 있음 (`lu2020_insitu_nanoct_calendering_microstructural_evolution`) | 줄 = Lu 2020 Nat. Commun. 11, 2079 · 카드 = Joule (10.1016/j.joule.2020.10.010) → PDF 필요 (W040) |
| sakuda2013 | 카드 있음 (`sakuda2013_sulfide_mechanical_property`) | 줄 = J. Ceram. Soc. Japan 121, 946 · 카드 = Sci. Rep. (10.1038/srep02261) → PDF 필요 (W006) |
| wang2018 | 카드 있음 (`wang2018_lco_nmc_electronic_ionic_conductivity_vs_ni`) | 줄 = Adv. Energy Mater. 8, 1702578 · 카드 = J. Power Sources (10.1016/j.jpowsour.2018.05.005) → PDF 필요 (W093) |
| zhang2023 | 카드 있음 (`zhang2023_pfib_multiscale_imaging_4d_thick_cathode`) | 줄 = Zhang F. 2023 eTransportation 15, 100220 · 카드 = Joule (10.1016/j.joule.2022.12.001) → PDF 필요 (W038) |
| a2017 (Kondrakov) | 후보 표 N-54 · N-55 · N-78 · N-102 · N-122 · N-48 | 머리글자 'a' + '2017' 낱말 맞춤 — 다른 논문 → PDF 필요 (W088) |
| c2022 (Athanasiou) | 후보 표 N-67 · N-63 · N-81 · N-87 · N-89 · N-127 · N-12 | 같은 이유 → PDF 필요 (W085) |
| j2016 (de Bono) | 후보 표 X-68 · N-76 · N-104 · N-122 · N-2 | 같은 이유 → PDF 필요 (W063) |
| r2017 (Koerver) | 후보 표 N-54 · N-55 · N-78 · N-102 · N-122 · N-48 | 같은 이유 → PDF 필요 (W087) |
| y2017 (Wang & Cheng) | 후보 표 N-54 · N-55 · N-78 · N-122 · N-48 | 같은 이유 → PDF 필요 (W092) |
| y2020 (Bi) | 후보 표 N-101 · N-109 · N-125 · N-20 | 같은 이유 → PDF 필요 (W096) |
| y2022 (Morino) | 후보 표 N-67 · N-63 · N-81 · N-87 · N-89 · N-127 · N-12 | 같은 이유 → PDF 필요 (W081) |
| ott2013 | 후보 표 N-62 | N-62 = Cottrino ('ott' 가 성 안에) → PDF 필요 (W048) |
| paul2014 | 후보 표 N-54 | N-54 = Paulick → PDF 필요 (W051) |
| song2023 | 후보 표 N-93 | N-93 = Kwon … T. Song 2024 Small Sci. (LFP 후막) → PDF 필요 (W062) |
| tan2018 | 후보 표 N-2 | N-2 = Kawaguchi 2018 → PDF 필요 (W020) |
| zhang2009 | 후보 표 N-66 | N-66 = Ebner (X-ray tomography) → PDF 필요 (W065) |

맞은 4: choi2018 · meyer2018 (카드) · bielefeld2022 → N-89 · sonzogni2024 → N-68 (지금은 카드).

묶음 오류 2 (지금 항목에 첫 판 열쇠를 다시 매겨 확인 · `first_draft_check.py`):
- 합친 오류 1: 열쇠 `perrenot2023` 이 다른 두 논문 (ACS Energy Lett. 8, 4531 = W012 · Adv. Funct. Mater. 2310739 = W013) 을 하나로.
- 나눈 오류 1: 같은 논문 Perrenot AFM 의 두 줄 (L27 · L47) 이 `perrenot2023` 과 `?P. Perrenot…` 두 열쇠로 — 그래서 첫 판 '두 배치 이상 2' (lee2020 · bielefeld2022) 가 Perrenot AFM (b46 · b61) 을 놓쳤다.

성을 못 읽은 열쇠 20 / 109: `?` 로 시작 3 (AKAZAWA · CARNIERO · P. Perrenot) · 머리글자 + 해 12 (a1968 · a1988 · a2017 · c2022 · d1987 · e1985 · j2016 · r2017 · v2000 · y2017 · y2020 · y2022) · 참고 번호 + 해 5 (262015 · 292011 · 302016 · 312017 · 62017 = '(26) Zielke' 등 앞 번호를 성으로 읽음).

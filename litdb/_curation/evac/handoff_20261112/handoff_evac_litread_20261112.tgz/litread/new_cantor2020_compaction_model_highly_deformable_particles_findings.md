# new_cantor2020_compaction_model_highly_deformable_particles 정독 근거 (새 카드 1 장 · 원문 PDF 6 쪽 전문 + 카드 890 줄 · 2026-11-10)

카드: `cantor2020_compaction_model_highly_deformable_particles` (정본 커밋 `f1e600645`) — Cantor, Cárdenas-Barrantes, Preechawuttipong,
Renouf & Azéma, "Compaction Model for Highly Deformable Particle Assemblies", Phys. Rev. Lett. 124, 208003 (2020), DOI 10.1103/PhysRevLett.124.208003.

적는 법: 위치의 `L숫자` = 카드 줄 번호 (커밋 `f1e600645` 기준) · 논문 쪽 `p. N` = 208003-N · 표지는 카드에 적힌 그대로 (`본문` = 인쇄된 값 ·
`[판독]` = 그림에서 읽음 · `[판독 맞춤]` = 그림의 선을 읽어 식에 맞춤 · `[카드 산술]` · `[카드 추론]` · `[카드 풀이]` · `[미확인]`).
재료 = **비압축 neo-Hookean 초탄성 원판 모델 소재 · 2D (평면변형률)** — LPSCl · NCM 아님.  보충 자료 (Supplemental Material) 는 받지 못했다
(본문 · 참고문헌에 언급 없음).

형식: `- [글자] slug | 내용 (값 · 단위) | 위치 | 표지 | 한계`

## a. 순수 SE (LPSCl · 황화물) 의 압력별 기공 곡선 · 진밀도 · 질량 기준 · 누른 채 / 뺀 뒤

- [a] cantor2020_compaction_model_highly_deformable_particles | 해당 없음 — 황화물 · 실험 곡선이 아니다.  있는 것은 초탄성 원판 모델 소재의 무차원 압밀 곡선 (누른 채 · 마찰 0): φ = 0.808 (P/E 10⁻⁴) · 0.826 (5 × 10⁻³) · 0.840 (10⁻²) · 0.864 (2.5 × 10⁻²) · 0.887 (5 × 10⁻²) · 0.914 (0.1) · 0.966 (0.25) · 0.985 (0.5); 마찰 0.8 은 0.795 → 0.973 | 카드 §3-3 (a) L161–182 · 논문 그림 2 · 6 | [판독] ±0.001–0.002 | 2D 원판 · 초탄성 · P/E 무차원 (E 미기재) · 진밀도 · 질량 개념 없음 — 카드: 절대값 전이 0 건 (L6–11)

## b. 압력을 뺄 때 되돌아오는 양과 잰 방법

- [b] cantor2020_compaction_model_highly_deformable_particles | 없음 — 하중 단계만 계산했다 (*"A set of loading steps were then undertaken targeting stable values of applied pressure and solid fraction"*).  입자가 초탄성이라 뺀 뒤 형상이 남는 현상 자체가 모델에 없다 | 카드 §0-1 (iv) L55 · §3-5 L322 · §12-A L805 · 논문 p. 2 | 원문 인용 + 카드 판정 | 탈압 근거로 쓸 수 없음

## c. 항복 · 경도 · 크리프 값과 정의 · 일축 항복 세기 환산

- [c] cantor2020_compaction_model_highly_deformable_particles | 항복 · 경도 · 크리프 값 없음 (초탄성 재료 · E 값도 미기재).  닿는 것 하나: 거시 체적 변형 ln(φ/φ0) ≈ 0.20 (P/E 0.5) 까지 탄성으로 버티는 재료라는 점 | 카드 §3-4 L310 · §8-2 L621 | [카드 산술] (φ 는 [판독]) | 분말 재료는 그 전에 항복한다 — P/E 축을 옮기지 않는 이유 (카드 해석)
- [c] cantor2020_compaction_model_highly_deformable_particles | 기존 압밀 식의 "상수" 에 대한 저자 평: Heckel 의 두 상수 (K · B) 는 *"not clearly related to physical or mechanical properties"* · Kim–Carroll 은 상수 셋 (Y0 · μ · γ) 을 실험 · 맞춤으로 정해야 한다 | 카드 §4-2 L352–361 · §11 L766–767 · 논문 p. 1 | 원문 인용 | Heckel 항복압을 물성으로 읽지 말라는 근거 — 값은 없음

## d. 단단한 입자 + 무른 입자를 섞어 누를 때 단단한 입자의 하중 몫 · 재밍

- [d] cantor2020_compaction_model_highly_deformable_particles | 해당 없음 — 무른 원판만 (강체 없음).  재밍 값만: jammed φ0 = 0.808 (μ 0) · 0.800 (0.2) · 0.797 (0.4) · 0.794 (0.6) · 0.795 (0.8) — 본문에는 숫자가 없고 그림에서 읽은 값 | 카드 §3-3 (a) L165 · L177–178 · 논문 그림 2 · 6 | [판독] | 2D · 벽 상자 · 원판 1500 개
- [d] cantor2020_compaction_model_highly_deformable_particles | jammed 배위수 Z0 ≈ 3.9 (μ 0) · ≈ 3.75 (μ 0.8) — 본문 미기재, 그림 4 의 이론선을 식 (2) · (7) 에 맞춰 역산 (뒤 값은 b 가 두 마찰에서 같다는 가정 위) | 카드 §3-3 (c) L215–228 | [판독 맞춤] | 형제 학회판 표의 값 (무른 입자만 · μ 0: 3.4) 과 다르다 — 같은 계산인지 [미확인] (L647–649).  강체 + 무른 혼합은 형제 카드 `cardenasbarrantes2020_rigid_deformable_mixture_compaction_nscd`

## e. 점접촉 법칙이 큰 변형에서 깨지는 범위와 대안 · 대안마다 맞춘 값 개수

- [e] cantor2020_compaction_model_highly_deformable_particles | 접촉 변형만으로 닫은 체적탄성률 K1 (식 2 — 작은 변형 · Hertz–Mindlin / 유효 매질류와 같은 부류) 이 입자별 FE 계산의 측정 K 와 갈리는 정도 (마찰 0): K1 ÷ 측정 = 1.8 (φ 0.808 · jammed) · 2.1 (0.826) · 1.7 (0.839) · 0.9 (0.863) · 0.8 (0.886) · 0.64 (0.913) · 0.23 (0.966) · 0.06 (0.986).  K1 은 0.51E → 1.34E 로 거의 평평하고 측정은 0.28E → 21E | 카드 §3-3 (d) L230–251 · 논문 그림 4 · p. 3 | 측정 = [판독 ±10 %] · K1 = [판독 맞춤] 한 식의 값 | 2D · 초탄성 · 등방 · K1 은 DEM 계산이 아니라 해석 닫음.  저자는 문턱 숫자를 적지 않았다
- [e] cantor2020_compaction_model_highly_deformable_particles | 저자의 대안 = 국소 변형을 접촉 변형이 아니라 입자를 감싼 칸 (Voronoi) 의 부피 변화로 정의 → "네 강체 벽 사이의 입자 하나" 의 압축 법칙 Pp/E = −b ln[(φp,max − φp)/(φp,max − φp,0)] 을 P ≡ (Zφ/2π)Pp 로 척도화 | 카드 §4-5 L401–415 · §5-4 L483–495 · 논문 p. 3–4 | 본문 | 식 (3) · (4) 는 유도가 아니라 그림에 붙인 척도화 (L407–409)
- [e] cantor2020_compaction_model_highly_deformable_particles | 그 대안에서 맞춘 값: 압밀 곡선에 φmax 하나 (마찰마다 · 본문 0.998 / 0.968) + 같은 계산의 보조 자료에 b (단일 입자 · 본문 ≃ 0.12) · k (Z–φ · 본문 ≃ 5.1) · α ≃ 0.5 는 문헌값 · Z0 · φ0 는 잰 값 (미기재) | 카드 §4-5 L417–430 · 논문 p. 3–4 | 본문 (분류는 카드 정리) | 초록의 "free from ad hoc parameters" 와 나란히 읽을 것.  multi-contact · MDR · EEPA · Thornton–Ning · Storåkers 는 이 논문에 없음
- [e] cantor2020_compaction_model_highly_deformable_particles | 그 대안의 정확도 (마찰 0): 식 (7) K2 ÷ 측정 = 1.15–1.35 (φ ≤ 0.84) · 0.74–0.81 (φ 0.86–0.97) · 0.56 (φ 0.986) — 본문 표현은 "perfectly reproducing" | 카드 §3-3 (d) L246–248 · §12-B L823 | [판독 ±10 %] | —

## f. MPM 의 접촉 · 다물체 · 강체 결합 방법 · 해상도 규칙 (지름당 셀 수) · 수치 오차 추정

- [f] cantor2020_compaction_model_highly_deformable_particles | MPM 아님 (입자별 FE).  해상도: 다입자 계산은 원판당 삼각형 92 개 · 단일 입자 상자 시험에서 92 (하중 방식 둘) · 116 · 174 · 272 · 572 · 968 개를 견줌 | 카드 §3-1 L124 · §4-3 L363–373 · 논문 p. 2 · 4 · 그림 5 | 본문 | 요소 ≠ MPM 셀 — 시험 설계만 옮긴다
- [f] cantor2020_compaction_model_highly_deformable_particles | 수치 오차 추정법 = 네 강체 벽 사이의 입자 하나를 다입자 계와 같은 변형 증분으로 눌러 메시끼리 견줌 (해석해 대조 없음).  판독: 메시 사이의 φp 차 0.009–0.023 (Pp/E 0.05–0.5) · 가장 고운 968 이 가장 무른 쪽 · 92 요소는 968 보다 치밀화량 (φp − φp,0) 이 28 % (Pp/E 0.032) · 7 % (0.1) · 8 % (0.32) 적다 · 같은 92 요소라도 하중 방식 (E 를 바꿈 ↔ Pp 를 바꿈) 에 따라 Pp/E 0.32 에서 0.978 ↔ 0.955 | 카드 §3-3 (e) L253–275 · §3-4 L311 | [판독 ±0.002–0.003] + [카드 산술] · 본문 표현은 "has no major effect" | 다입자 계에서의 메시 시험은 없음 · 반복 · 오차막대 없음

## g. 2D 결과를 3D 로 옮길 때의 경고 · 증거

- [g] cantor2020_compaction_model_highly_deformable_particles | 2D 계산 (p. 1 *"two-dimensional highly deformable particles"* · p. 2 *"plane strain conditions"*) 이고 **3D 에 대한 말은 없다** — 확장 과제로 든 것은 다른 재료 모델 · oedometric 하중 · 입자 모양 · 탄성 성질이 다른 물체의 혼합 · 전단 | 카드 §0-1 (iii) L54 · §5-6 L516–521 · 논문 p. 1 · 2 · 5 | 원문 인용 + 카드 판정 | —
- [g] cantor2020_compaction_model_highly_deformable_particles | 원전의 식 안에 있는 차원 의존: 단일 입자 법칙 (식 5) 은 jammed 에서 유한한 기울기 Kp/E = b·φp,0/(φp,max − φp,0) ≈ 0.44 (b 0.12) – 0.55 (b 0.15) 를 갖는다 = 원판 접촉이 거의 선형이라는 2D 의 성질 → 3D (Hertz 3/2 제곱) 에서는 이 꼴이 안 되어 3D 판이 √(φ − φ0) 인자를 넣었다 | 카드 §3-4 L305 · §9-4 L697–700 | [카드 산술] + [카드 추론] (3D 쪽은 형제 카드 `cardenasbarrantes2022_soft_spheres_3d_compaction_nscd` §5-4) | 논문 주장 아님 (카드 해석)
- [g] cantor2020_compaction_model_highly_deformable_particles | 원전 ↔ 후속판의 같은 양 비교: 원판 1500 × 삼각형 92 (2D) ↔ 구 50 · 100 × 사면체 808 (3D) · Z 계수 5.1 ↔ 8.5 · 닫음 = 단일 입자 상자 법칙 ↔ Hertz + 연속 조건 · φ0 0.81 ↔ 0.50 (벽 상자) · 가장 조밀한 2D 배위수 Zmax ≈ 6.1 (면을 채운 다각형의 평균 이웃 수 6 근처) | 카드 §8-3 L628–649 · §3-4 L309 | 2D 값은 본문 · [판독] · [카드 산술] · 3D 값은 형제 카드 | k · b · φ0 · Zmax 는 차원에 묶인 수

## h. DEM 에서 FE · MPM 으로 넘긴 선례와 넘긴 시점

- [h] cantor2020_compaction_model_highly_deformable_particles | 넘김 없음 — 처음부터 같은 코드 (LMGC90) 에서 FE 원판을 기하 규칙 침적 알고리즘으로 상자에 쌓고 ("relatively dense configuration, yet not in contact") 마찰을 지정한 뒤 하중 단계를 건다.  P/E → 0 의 상태를 강체 집합의 jammed 상태 (첨자 0) 로 삼는다 | 카드 §4-4 L375–381 · 논문 p. 2 | 본문 | 출발 상태의 φ0 · Z0 숫자는 미기재

## i. 복합 양극 (AM + SE) 의 압력별 기공

- [i] cantor2020_compaction_model_highly_deformable_particles | 없음 (모델 소재 · 무른 원판만) | 카드 머리 L6–11 | — | —

## j. 카드가 스스로 "아직 못 한다 · 한계" 라고 적은 것 가운데 가압 · 탈압 계산과 닿는 것

- [j] cantor2020_compaction_model_highly_deformable_particles | 저자가 적은 범위의 한정 (p. 5): *"Although our compaction model is deduced in the frame of the neo-Hookean material model, our purpose is also to present a methodical and micromechanically based approach…"* · 소성 등 다른 재료 모델 · oedometric 하중은 **확장 과제**이고 그때는 *"distinct functional forms, other than logarithmic"* 이 될 수 있다 | 카드 §5-6 L514–518 · §11 L785–788 | 원문 인용 | 계산은 하지 않았다
- [j] cantor2020_compaction_model_highly_deformable_particles | 카드가 적은 한계: 탈압 없음 · 초탄성 · 2D · 무른 원판만 · 등방 · 실험 대조 없음 · 계산 비용 미기재 · 식의 입력 Z0 · φ0 미기재 (식을 글만으로 다시 계산할 수 없음) · 본문 상수 (b 0.12 · φmax 0.968) 가 그림의 선 (0.15 · 0.978–0.981) 과 다름 | 카드 §12-A L798–806 · §12-B L808–834 · §3-3 (b) (c) L184–228 | 카드 판정 ([판독 맞춤] + [카드 산술]) | 판독에 기댄 판정 — 원인 [미확인]
- [j] cantor2020_compaction_model_highly_deformable_particles | 검증이 닫힌 고리: 식의 상수를 정한 계산과 식을 검증한 계산이 같다 · 저자 스스로 척도화의 근거를 *"supports, a posteriori, the validity of our analysis"* 라고 적는다 | 카드 §5-5 L505–506 · §12-B L830–831 · 논문 p. 4 | 원문 인용 + 카드 판정 | 실험 대조는 같은 그룹 2022 실험판 (형제 카드)

## k. DEM 의 한계 — 논문 (카드) 이 직접 말한 문장 · 수치

- [k] cantor2020_compaction_model_highly_deformable_particles (Cantor, Cárdenas-Barrantes, Preechawuttipong, Renouf & Azéma 2020 · Phys. Rev. Lett. 124, 208003 · DOI 10.1103/PhysRevLett.124.208003) | 서론 (p. 1): *"Such body distortions are often dismissed or simplified by considering either the rigid body kinematics as the primary source of deformation or standing on the small-strain framework. However, explicitly describing the particles' large strains is essential for the development of technological applications…"* — 강체 운동학 · 작은 변형 틀로 입자 변형을 단순화하는 관행에 대한 지적 | 카드 §0-1 (i) L52 · §11 L763–765 | 원문 인용 | DEM 이라는 낱말로 지목한 문장은 아니다
- [k] 같은 카드 (같은 서지) | ★ 결과 (p. 3): *"This equation is reminiscent of those given in Refs. [44–51] deduced upon a small-strain framework (i.e., Hertz-Mindlin contact law) and the effective medium theory. … As also noted in previous studies, fair predictions of bulk modulus result for the small-strain domain when standing on the equivalent medium approach. Yet, we observe an increasing mismatch as the solid fraction tends to unity since the assembly of grains starts to behave as a nondeformable solid (i.e., the corresponding bulk modulus diverges). This observation suggests that defining local strains only by means of the contact deflections (i.e., σl = Eεv,ℓ) should be reconsidered."* | 카드 §0-1 (i) L52 · §5-3 L472–481 · §11 L776–779 · 논문 그림 4 | 원문 인용 | 대상은 해석 닫음 K1 (식 2) — DEM 을 직접 돌려 견준 것은 아니다 (그 대조는 3D 판 Soft Matter 18, 312).  2D · 초탄성
- [k] 같은 카드 (같은 서지) | 그 그림에서 읽은 한계 수치: 접촉 변형 닫음 K1 ÷ 측정 K = 1.8 (jammed · φ 0.808) → 0.9 (φ 0.863) → 0.23 (φ 0.966) → 0.06 (φ 0.986) — **오차의 부호가 바뀐다** (낮은 밀도에서 과대 · 조밀 영역에서 과소) | 카드 §3-3 (d) L230–245 · §9-2 L691–693 | 측정 [판독 ±10 %] · K1 [판독 맞춤] · 배수는 [카드 산술] | 저자가 적은 숫자가 아니라 카드 판독
- [k] 같은 카드 (같은 서지) | 접촉 정칙화에 대한 말 (p. 2): *"Note that the NSCD approach does not introduce regularization coefficients for the contact laws as other discrete element approaches do, making this numerical scheme robust and stable."* — 통상 DEM 의 접촉 법칙은 정칙화 계수 (접촉 강성류) 를 들인다는 대비 | 카드 §4-1 L335–337 · §11 L772–773 | 원문 인용 | 정칙화가 결과를 얼마나 바꾸는지의 수치는 없음
- [k] 같은 카드 (같은 서지) | 우리 DEM 의 자리 (논문 주장 아님): 300 MPa ÷ E = 0.013 (실제 E 22–24 GPa · 이 논문 곡선의 φ ≈ 0.85 · K1 이 ≈ 1.4 배 과대인 구간) ↔ 0.22 (연화 E 1.35 GPa · φ ≈ 0.96 · K1 이 1/4 쯤으로 과소인 구간) ⇒ 영률을 한 배수로 고쳐서는 양 끝을 함께 못 맞춘다 | 카드 §8-5 L664–675 · §3-4 L312–313 | [카드 산술] + [카드 추론] | 2D · 초탄성 · 해석 닫음 · 우리 접촉은 hooke/hysteresis · AM 차폐 — 카드: 방향 해석일 뿐

## l. 소성변형이 왜 어려운가 — 논문의 설명 · 택한 우회 · 맞춘 값 · 검증 범위 · 계산 비용

- [l] cantor2020_compaction_model_highly_deformable_particles (Cantor, Cárdenas-Barrantes, Preechawuttipong, Renouf & Azéma 2020 · Phys. Rev. Lett. 124, 208003 · DOI 10.1103/PhysRevLett.124.208003) | 어려운 이유 (저자의 진단 · 초록): *"The compaction behavior of deformable grain assemblies beyond jamming remains bewildering, and existing models that seek to find the relationship between the confining pressure P and solid fraction φ end up settling for empirical strategies or fitting parameters."* · (p. 1) *"We can summarize the limitations of current models by the use of nonphysical parameters, the lack of accuracy at extreme pressures, and the missing physical derivation of the compaction equations."* · *"…such a venture should admittedly rely on a proper description of the compaction process while taking into account the multicontact nature of the assembly and the particles' deformability."* | 카드 §0-1 (ii) L53 · §11 L760–771 | 원문 인용 | 이 논문은 소성이 아니라 "큰 변형" 일반을 말한다
- [l] 같은 카드 (같은 서지) | 택한 우회 = **소성을 넣지 않음** (비압축 neo-Hookean 초탄성 · 평면변형률) + 입자별 FE 로 형상 변화를 직접 풂 (NSCD · LMGC90 · 접촉은 비관통 + 건조 마찰 · 접촉 매개변수는 μ 하나) | 카드 §4-1 L329–342 · §4-6 L432–445 · 논문 p. 2 | 본문 | 소성은 결론의 확장 과제 — 그때는 식의 꼴이 로그가 아닐 수 있다고 저자가 적음 (L516–518)
- [l] 같은 카드 (같은 서지) | 우회의 값 — 규모: 원판 1500 개 × 삼각형 92 개 = 요소 138,000 개 · 마찰 다섯 수준 · 하중 11 수준 | 카드 §3-1 L122–130 · §3-4 L298 · 논문 p. 2 | 입자 · 요소 수는 본문 · 총 요소 수는 [카드 산술] · 하중 수준은 [판독] | 계산 시간 · 코어 수 · 병렬 여부 [미확인] (감사의 글에 HPC 플랫폼 MESO@LR 이름만 · L97)
- [l] 같은 카드 (같은 서지) | 맞춘 값: 압밀 곡선에 φmax (본문 0.998 μ 0 · 0.968 μ 0.8 — *"Simple fitting of Eq. (6)"*) · 단일 입자 시험에 b (본문 ≃ 0.12) · Z–φ 자료에 k (≃ 5.1) · α ≃ 0.5 는 문헌값 | 카드 §4-5 L417–430 · 논문 p. 3–4 | 본문 | 그림의 선은 b ≈ 0.15 · φmax (μ 0.8) 0.978–0.981 로 읽힌다 ([판독 맞춤] · L215–228) — 본문 값과 다름
- [l] 같은 카드 (같은 서지) | 검증 범위: 같은 계산의 자료뿐 (그림 4 · 6) — 실험 · 다른 코드 대조 없음.  판독으로 본 식 (6) 선 ↔ 자료 차: μ 0 은 φ 로 ≤ 0.006 · μ 0.8 은 P/E 0.005–0.05 에서 선이 0.004–0.012 낮음; 본문 상수 (b 0.12) 로 식 (6) 을 계산하면 μ 0 자료보다 P/E 0.075–0.5 에서 0.010–0.015 높음 | 카드 §3-3 (b) L184–213 · §12-B L830–831 | [판독] + [카드 산술] | Z0 · φ0 를 그림에서 역산해 넣은 계산 (본문 미기재)
- [l] 같은 카드 (같은 서지) | 단일 입자 로그 법칙의 한계: 자료가 요구하는 b 가 압력에 따라 0.11–0.14 (Pp/E 0.05) → 0.18–0.22 (0.5) 로 움직인다 · 본문 0.12 ↔ 그림의 선 0.15 ↔ 후속 PRE 2020 판 본문 0.14 | 카드 §3-3 (e) L273–275 · §9-3 L694–696 | [카드 산술] ([판독] 값에서) | b 는 물성이 아니라 맞춤 양 (카드 해석)

## m. 받아들일 통찰 — 바로 가져다 쓸 수 있는 것

- [m] cantor2020_compaction_model_highly_deformable_particles | **단위 시험 U1 은 해상도 검사이자 그 모델의 "국소 법칙" 을 재는 시험이다.**  이 계열의 압밀 식은 P ≡ (Zφ/2π)·Pp (연결성 × 입자 하나의 압축 곡선) 이고 재료가 바뀌면 바꿔 끼울 것은 Pp(φp) 하나 — 저자: 소성이면 로그가 아닌 꼴이 될 수 있다 | 우리 쪽: U1 (입자 하나를 강체 벽 상자에서 다입자 계와 같은 변형 증분으로 누름 · φp–Pp 곡선을 기록) · 후보끼리 견주는 공통 형식 (결과 전 대조 항목의 형식) | 근거: 카드 §9-1 L688–690 · §4-3 L363–373 · 논문 p. 4 · 5 | 본문 + 카드 정리 | 식 (3) · (4) 는 그림에 붙인 척도화이고 판독으로는 0.45–1.35 배 안에서만 맞는다 (L494–495 · L821–822); 소성 입자는 Pp 가 φp 만의 함수가 아니다
- [m] cantor2020_compaction_model_highly_deformable_particles | **해상도 검사를 "큰 영향 없음" 으로 닫지 말고 수치로 적는다.**  92 ↔ 968 요소의 치밀화량 차 7–28 % · 방향 일정 (거칠수록 뻣뻣) · 같은 메시 · 다른 하중 방식의 차 0.023 — 이 차가 상수 b 의 0.12 ↔ 0.15 흔들림과 같은 크기 | 우리 쪽: U1 · U6 (통과 기준 = 해상도 사이 치밀화량 차의 % + 단조 수렴 · 하중 방식 둘) | 근거: 카드 §3-3 (e) L268–272 · §9-6 L704–706 · §10-3 3 번 L747–748 | [판독] + [카드 산술] | 요소 ≠ MPM 셀
- [m] cantor2020_compaction_model_highly_deformable_particles | **출발 상태 (φ0 · Z0) 를 결과 전에 적어 둔다.**  이 논문은 식의 입력인 φ0 · Z0 를 인쇄하지 않아 자기 식을 글만으로 다시 계산할 수 없다 (반면교사).  마찰이 곡선에 주는 효과도 출발 상태의 평행 이동 (φ0 · 포화값 0.012–0.013) 이라 출발 패킹을 안 맞추면 접촉 표현의 차이와 섞인다 | 우리 쪽: 단계 0 (기록 형식) · 단계 3 (접촉 표현 비교 전에 출발 패킹을 맞추거나 기록) | 근거: 카드 §3-5 L317 · §9-7 L707–708 · §10-2 L732 | 카드 판정 | —
- [m] cantor2020_compaction_model_highly_deformable_particles | **새 런 없이 잴 관측량: K(φ) = φ dP/dφ 와 Z − Z0 ∝ (φ − φ0)^α.**  접촉 법칙이 포화 근처의 강성 발산을 내는지가 정보 (이 논문에서 접촉 변형 닫음은 0.5E → 1.3E 로 평평 · 측정은 0.3E → 21E) | 우리 쪽: 후보 D0 (기존 LIGGGHTS 압축 궤적) · 후보 C · C′ 를 볼 때의 판정 관측량 — 2D 값 k 5.1 은 기대값으로 쓰지 않는다 | 근거: 카드 §10-3 2 번 L745–746 · §3-3 (d) L244–245 | [판독] | 2D · 초탄성
- [m] cantor2020_compaction_model_highly_deformable_particles | 흐름 밖: 보고 · 원고의 DEM 한계 서술 — **접촉 변형 닫음의 강성 오차는 부호가 바뀐다 (낮은 밀도 과대 · 조밀 과소) → 한 압력에 맞춘 연화 영률은 그 압력의 대리일 뿐**이라는 설명의 2D 근거 (3D 판의 Hertz DEM 대조 그림과 짝) | 우리 쪽: 흐름 밖 — DEM 지배방정식 보고 · 원고의 한계 절 · 순수 SE 압밀 곡선을 φ0 · φmax 를 남긴 로그 꼴로 다시 적합하는 일 (후보 M0) | 근거: 카드 §8-5 L664–675 · §8-4 L651–662 | [카드 산술] + [카드 추론] | 한정어 필수 (2D · 초탄성 · 해석 닫음 · 우리 접촉은 hooke/hysteresis)

## 카드 문제

없음 (새 카드 · 작성자 자기 점검).  읽는 쪽이 알아 둘 것 넷:
① 표 3-3 의 값은 전부 그림 판독이다 (그림 2–6 은 PDF 안에서 벡터 → 1200 dpi 로 그려 눈금 선으로 축을 잡음 · 표식 ±0.001–0.002 · K 는 ±10 %) — 원저자 수치 파일이 아니다.
② "본문의 b 0.12 · φmax (μ 0.8) 0.968 이 그림의 선 (0.15 · 0.978–0.981) 과 다르다" 는 그 판독에 기댄 카드 판정이고 원인은 [미확인] 이다 (그림 4 · 5 의 선은 해당 식에 0.2 % · 5 × 10⁻⁵ 로 맞아 판독 자체는 확인됨).
③ Z0 ≈ 3.9 · φ0 ≈ 0.81 은 본문 값이 아니라 그림의 이론선에서 역산한 값이다.
④ 형제 카드와의 차이 (형제 카드는 고치지 않음): `cardenasbarrantes2022_soft_spheres_3d_compaction_nscd` §8-3 표가 "단일 입자 상자 법칙 (b ≃ 0.14 · PRL/PRE 2020)" 이라 적었는데 PRL 의 인쇄값은 0.12 다 (0.14 는 PRE 2020 판) · 같은 표의 2D "φmax 0.96–0.99" 는 PRL 인쇄값 0.998 (μ 0) 을 못 덮는다 (카드 §14 L873–876).

"""Call a SCRATCH tree's own scripts/mixer_precal_prepare.validate_case on its first8 planned
assets (deck + deck_meta) — the same check the observer makes after a run (observer
validate_case -> preparation.validate_case).  Read-only; no files written.
Usage: python3 -I -B validate_planned.py <tree_root> [case ...]   (default = all eight)"""
import json, sys
from pathlib import Path
tree = Path(sys.argv[1]).resolve()
sys.dont_write_bytecode = True
sys.path.insert(0, str(tree / 'scripts'))
import mixer_precal_prepare as prep
F8 = tree / 'docs/reviews/mixer_first8_launch_preparation_20261106/planned_assets'
for cid in (sys.argv[2:] or prep.CASE_IDS):
    deck = (F8 / cid / 'in.mixer').read_bytes()
    meta = json.loads((F8 / cid / 'deck_meta.json').read_bytes())
    try:
        prep.validate_case(cid, deck, meta)
        print('VALIDATE', cid, 'OK')
    except ValueError as e:
        print('VALIDATE', cid, 'REFUSED', e)

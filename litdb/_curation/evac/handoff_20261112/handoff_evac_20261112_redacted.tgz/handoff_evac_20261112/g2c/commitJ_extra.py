import json, sys, os
R = sys.argv[1]
# 1) ledger SELF-166 (open · claimed_fixed = next commit after push)
p = os.path.join(R, 'docs/reviews/findings.json')
d = json.load(open(p, encoding='utf-8'))
assert not any(x.get('id') == 'SELF-166' for x in d['findings'])
d['findings'].append({
  "id": "SELF-166",
  "severity": "P2",
  "status": "open",
  "owner": "claude",
  "found_by": "ibb 건식 (N = 200) job 358667 (11-12 · 1저자 실행 · 생산 lmp_mpi 를 mpirun 없이 1 프로세스 · 덱 묶음 = 핀 11a794674) — 실행기 실행 전 멈춤 rc 3 'LMP -h rc 1' · 배너 = 3d5c00f 정상",
  "opened_in": "docs/reviews/p1_g2c_sandbox_20261104/run_g2cp.sh",
  "title": "G2c′ 샌드박스 실행기 (run_g2cp.sh) 가 -h 머리 줄 확인에서 rc 0 을 요구했다 — LIGGGHTS 3d5c00f 의 -h 는 help() 뒤 error->done() = MPI_Finalize(); exit(1) (lammps.cpp 543–545 · error.cpp 369–379) 라 진짜 실행 파일은 늘 rc 1 → 실행기가 어떤 진짜 LIGGGHTS 로도 팔 하나 돌기 전에 멈춘다 · 시험의 가짜 lmp 도 -h 에 rc 0 을 내서 41 시험 · 내부 반박 리뷰 세 회차가 못 잡았다 (가짜가 진짜 꼴을 옮기지 않음 · SELF-115 와 같은 부류)",
  "note": "결과 무관 (실행 전 멈춤 · 팔 0 · 예측 · 숫자 기준 · 판정 식 · 허용폭 · 대조기 무변경) · 고침 = 받는 rc 0 → 1 + 도움말 줄 'Command line options:' 요구 (오류 끝 error->all 도 rc 1 이라 가른다 · 거부 쪽) + 가짜 lmp 를 3d5c00f 꼴로 (배너 → 도움말 줄 → rc 1 · 소스 줄을 주석에) · t22 사례 셋 (-h rc 0 · rc 2 · 오류 끝 = rc 1 인데 도움말 없음) · t26 lmp_h_rc 1 기록 · 고치기 전 실행기 29/41 (fail 12 = 실행기 시험 11 이 job 358667 과 같은 멈춤 + t22 = rc 0 을 받아 버림 · 오류 끝 사례의 멈춤 이유가 다름) → 41/41 · 변이 6 중 6 잡음 · 고침 커밋 = 이 항목을 올린 커밋 · claimed_fixed = push 뒤 다음 커밋 · 남은 것 = 이 판 덱 묶음으로 ibb 건식 다시 (진짜 실행 파일 통과는 그때 확인) · 같은 꼴을 막는 법 = 가짜 실행 파일의 꼴 (rc · 화면) 을 소스 줄로 근거 대기"
})
open(p, 'w', encoding='utf-8').write(json.dumps(d, indent=2, ensure_ascii=False) + '\n')
# 2) progress log
p = os.path.join(R, 'docs/session_20260923_progress.md')
s = open(p, encoding='utf-8').read()
assert s.endswith('\n')
s += ("- **[DEM 우선 Ⓐ] 11-12 — G2c′ ibb 건식 (1저자 *\"g2c'는 … ibb 로 가서 cpu 60 활용해서 진행\"*)** — 시도 1 · 2 = 빌드 잡 실패 (내 ibb 도구 결함 · 실행용 conda 환경 줄을 빌드 잡에 넣음) → 1저자 지적 *\"이미 lmp 관련해서 빌드되어 있는데\"* = 생산 `lmp_mpi` 를 `mpirun` 없이 1 프로세스로 (09-28 믹서 영수증 선례) → 시도 3 = job 358667 = 실행기 실행 전 멈춤 rc 3 (팔 0) \"LMP -h rc 1\" = 실행기 결함 `SELF-166` (3d5c00f 의 `-h` = rc 1 · 가짜 lmp 는 rc 0) → 고침 (시험 먼저 29/41 → 41/41 · 변이 6/6 · 받는 rc 1 + 도움말 줄) · 메모 `docs/reviews/p1_g2c_compare_definition_20261105.md` §0 머리 11-12 줄 (실행 자리 ibb · 실행 파일 `lmp_mpi` · 예측 가 = 해당 없음) · `docs/reviews/p1_g2c_sandbox_20261104/README_g2cp.md` ibb 절 → 다음 = 이 판 덱 묶음으로 건식 다시 → 대조기 (문법만) → 샌드박스 N = 40,000 = 1저자 GO.\n"
      "- **[Rint ②] 11-12 — siteq 현장 블록 예행 (kgy · gabia × 짧은 꼴 · nohup 꼴 · 핀 `11a794674`)** — 블록 rc 0 넷 · PASS · INFO kgy 25 · 8 · gabia 24 · 9 (WARN · FAIL · ERROR 0) · 두 기계 pin · env unit · code_key SAME · 짧은 ↔ nohup 33 칸 같음 · 11-09 ↔ 11-12 33 칸 같음 · nohup 꼴 SIGHUP 무시 yes · 반입 `docs/data/rint2_siteq_20261112_rehearsal/` (예행 · 본 현장 확인 = 단일 개정 커밋 핀 · 계획 §0-2 Q1).\n"
      "- **[litdb] 11-12 — 본문 글 크롭 (1저자 질문 *\"의도적으로 하는거야? 용량적으로 괜찮으면 난 좋은데\"*)** — 지시서에 없던 것 (10-13 부터 카드들이 넣음 · 29 장 · 401 개 · 87 MB = litdb 그림 4.2 GB 의 2 %) → 규칙화 (카드가 인용한 문장만 · 카드당 20 개까지 · 전체 쪽 그림 안 만듦 · 정본 `73c26568e`) · 쉬는 litdb 작업 폴더 2 를 치움 (그림 4.1 GB · PDF 32 개는 스크래치 사본) → 디스크 여유 5.4 → 11 GB.\n")
open(p, 'w', encoding='utf-8').write(s)
# 3) CLAUDE.md G2c line
p = os.path.join(R, 'CLAUDE.md')
s = open(p, encoding='utf-8').read()
old = '→ ⬜ 빌드 → 건식 (N 200) → 샌드박스 (N 40,000) = 단계마다 1저자 GO (게이트가 안 도는 때)'
new = old + ' → 11-12 1저자 = ibb cpu-60 · 빌드 없이 생산 `lmp_mpi` 1 프로세스 · 건식 job 358667 = 실행기 `-h` rc 결함 `SELF-166` (팔 0) → 고침 (시험 먼저) → 건식 다시'
assert s.count(old) == 1
open(p, 'w', encoding='utf-8').write(s.replace(old, new))
print('extra ok')

# mixer_e0_queryb.sh — 믹서 E0 자격 pilot 한 팔 · 등록 초안 13-1 봉인 전 보충 조회 q9b · q2b · q7b (ibb 읽기 전용 · 초안 2026-11-12 · 형식 mixer_e0_queryb/1)
#   승인 범위: 1저자 11-12 밤 오버나잇 "권고대로" = 등록 초안 18 절 2 회차 표 Q-F′ (q9b) · Q-G′ (q7b) · Q-K (q2b).
#   q9b: DEV E0 다섯 로그 (+ 있으면 dev-bo 둘 · dev-u 둘) 의 thermo 표 (머리 Step ~ "Loop time of") 안에서 숫자 줄이 아닌 줄마다
#        로그 번호 · 표 번호 · 표 안 차례 · 그 앞 숫자 행 수 · 앞 공백 (빈칸 · 탭) 수 · 가린 첫 낱말만 (숫자 → # · 경로 꼴 → <PATHLIKE> · 24 자).
#        표마다 머리 칸 수 · 숫자 행 · 칸 수 분포 · 비유한 행 · 비-행 · 빈 줄 · 닫힘 (13 절 q9 와 같은 센 수).  숫자 값 · 본문은 옮기지 않는다.
#   q2b: DEV E0 r1 프레임 셋 (처음 · 가운데 · 끝 — 이름의 step 으로만 고름) 마다 끝 바이트 개행 여부 · 개행 수 · 머리 4 째 줄 (원자 수) ·
#        머리 1 · 3 째 줄 꼴 · 머리 2 째 줄 = 이름의 step 인가 (꼴만 · 그 값은 안 옮김).  읽은 머리는 셸 변수에만 · 파일에 안 씀.
#   q7b: 사용자 conda 환경 꾸러미 일곱 (openmpi · ucx · ucc · libfabric · libfabric1 · libpmix · libhwloc) 의 conda-meta JSON 이 적은 파일마다
#        번호 · 종류 · 크기 · 수정 시각 · sha256 + JSON sha256 + 꾸러미 다이제스트 (읽기만 · 실행 없음 · 경로 문자열은 옮기지 않는다).
#   붙여넣기 블록 (query_block_b.txt) 이 md5 를 대조한 뒤에만 bash -c 로 돈다.  쓰는 곳 = 새 폴더 ~/mixer_e0_queryb_<UTC>/ 하나뿐.
#   하지 않는 것: 제출 · 취소 · 잡 제어 · 예약 · git · 지우기 · 옮기기 · 복사 (cp) · conda / module 바꾸기 · 계산 · 프로그램 실행
#   (sinfo = 노드 이름 목록 → 가림에만 · 옮기지 않음) · 덤프 · 로그 · conda 파일 · JSON 내용 복사 (센 수 · 꼴 · 해시만).
#   외부 명령은 전부 timeout 안 · 명령 없으면 MISSING · 대상 없으면 ABSENT · 권한 거부면 DENIED · 실패면 FAIL · 시간 초과면 TIMEOUT · 넘침이면 TRUNC.
#   조회 전체 상한 MIX_BUDGET 초 (기본 600) — 넘으면 남은 조회 SKIPPED_BUDGET · 묶음 만들기는 늘 한다 (묶음 상한 +300 초).
#   Ctrl-C = 지금 도는 명령 하나가 끝난 뒤 (그 명령의 timeout 안) 남은 조회를 SKIPPED_INTERRUPT 로 건너뛰고 묶음을 만든다.
#   켜고 끄기 (붙여넣기 전에 export): MIX_Q='q9b q2b q7b' (돌릴 조회 · 기본 셋 다 · 쉼표도 됨) · MIX_BUDGET=<초>
#   결과: out/ (가린 사본) 을 묶은 tgz 하나 + sha256 (화면).  raw/ (가리지 않은 원문) · work/ (중간 파일 · 경로 목록) 은 ibb 에 남긴다.
export LC_ALL=C PAGER=cat
umask 077
FORMAT='mixer_e0_queryb/1'
BLOCK_ID='mixer_e0_queryb_block draft 2026-11-12'
LOGS9='E0_ref_s32452843 E0_ref_s49979687 E0_ref_s67867967 E0_ref2_s32452843 E0_ref_dthalf_s32452843 LHx10_ref_r2_s32452843 LHx30_ref_r2_s32452843 LU212_ref_r2_s32452843 LU637_ref_r2_s32452843'
ONE_RUN='E0_ref_s32452843'
PKG7='openmpi ucx ucc libfabric libfabric1 libpmix libhwloc'
CAP=4194304
MAXF7=15000
MAXB7=1073741824
CH7=400
BUDGET=${MIX_BUDGET:-600}
case "$BUDGET" in ''|*[^0-9]*) BUDGET=600;; esac
HARD=$((BUDGET + 300))
QSEL=${MIX_Q:-'q9b q2b q7b'}
QSEL=${QSEL//,/ }
SELF_TEXT=${1-}
say() { printf '%s\n' "$*"; }

# ── 가림 함수 (awk) — 11-12 조회 블록과 같은 규칙 (홈 · 실제 홈 · 호스트 · 계정 (낱말 경계) · /home/<다른 사용자> · IPv4 · uid/gid · compiled … by ·
#    CANCELLED by · host:<이름>:<포트>) + 노드 이름 (sinfo · 낱말 경계) + 도메인 (호스트 FQDN 의 뒤쪽).  토큰 = 환경 MIX_TN · MIX_T<k> · MIX_R<k> · MIX_W<k> (길이 긴 것 먼저)
AWK_REDLIB='
function isw(c) { return (c ~ /[A-Za-z0-9_]/) }
function rlit(s, a, b,   i, o) { o = ""; while ((i = index(s, a)) > 0) { o = o substr(s, 1, i - 1) b; s = substr(s, i + length(a)) } return o s }
function rword(s, a, b,   i, o, pr, po) {
  o = ""
  while ((i = index(s, a)) > 0) {
    if (i > 1) pr = substr(s, i - 1, 1); else if (length(o) > 0) pr = substr(o, length(o), 1); else pr = ""
    po = substr(s, i + length(a), 1)
    if ((pr == "" || isw(pr) == 0) && (po == "" || isw(po) == 0)) o = o substr(s, 1, i - 1) b
    else o = o substr(s, 1, i - 1 + length(a))
    s = substr(s, i + length(a))
  }
  return o s
}
function buser(s,   i, j, r, k) {
  i = index(s, "compiled "); if (i == 0) return s
  j = index(substr(s, i), " by "); if (j == 0) return s
  j = i + j + 3; r = substr(s, j); k = match(r, /[ ,)]/)
  if (k == 0) return substr(s, 1, j - 1) "<BUILD_USER>"
  return substr(s, 1, j - 1) "<BUILD_USER>" substr(r, k)
}
function loadtok(   k, m, v) {
  NT = 0; m = ENVIRON["MIX_TN"] + 0; if (m > 5000) m = 5000
  for (k = 1; k <= m; k++) { v = ENVIRON["MIX_T" k]; if (length(v) > 0) { NT++; TT[NT] = v; TR[NT] = ENVIRON["MIX_R" k]; TW[NT] = ENVIRON["MIX_W" k] } }
}
function red(s,   k) {
  for (k = 1; k <= NT; k++) { if (TW[k] == "1") s = rword(s, TT[k], TR[k]); else s = rlit(s, TT[k], TR[k]) }
  gsub(/\/home\/[A-Za-z0-9._-]+/, "/home/<OTHER_USER>", s)
  gsub(/[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+/, "<IPV4>", s); gsub(/<IPV4>:[0-9]+/, "<IPV4>:<PORT>", s)
  gsub(/host:[^: ]+:[0-9]+/, "host:<HOST>:<PORT>", s)
  gsub(/uid[ =]?[0-9]+/, "uid <UID>", s); gsub(/gid[ =]?[0-9]+/, "gid <GID>", s)
  gsub(/CANCELLED by [0-9]+/, "CANCELLED by <UID>", s)
  return buser(s)
}
function redall(s,   k) { for (k = 1; k <= NT; k++) if (length(TT[k]) >= 4) s = rlit(s, TT[k], TR[k]); return s }
'
AWK_RED="$AWK_REDLIB"'
BEGIN { loadtok() }
{ print red($0) }'
# ── q9b: thermo 표 안 비-행 줄마다 표 번호 · 차례 · 앞 숫자 행 수 · 앞 공백 · 가린 첫 낱말 (첫 낱말은 줄 가림 + 4 자 이상 토큰 글자 그대로 가림 뒤 숫자 → #)
AWK_Q9B_MAIN='
function isnum(t) { return (t ~ /^[-+]?([0-9]+[.]?[0-9]*|[.][0-9]+)([eE][-+]?[0-9]+)?$/) }
function isnf(t,   u) { u = tolower(t); return (u ~ /^[-+]?(nan|inf|infinity)$/) }
function fw(t,   u) {
  if (index(t, "/") > 0) return "<PATHLIKE>"
  u = t; gsub(/[0-9]/, "#", u); gsub(/[^A-Za-z#:._<>-]/, "?", u)
  if (length(u) > 24) u = substr(u, 1, 24) "~"
  if (u == "") u = "<EMPTY>"
  return u
}
BEGIN { loadtok(); capn = 300; capt = 2000; em = 0; sup = 0; tot = 0; ncr = 0; nl = 0; b = 0; inb = 0; mc = 0 }
{ nl++; if (sub(/\r$/, "")) ncr++ }
$1 == "Step" { b++; inb = 1; hc[b] = NF; rows[b] = 0; nfr[b] = 0; nr[b] = 0; bl[b] = 0; cl[b] = "no"; next }
inb == 1 && index($0, "Loop time of") == 1 { cl[b] = "yes"; inb = 0; next }
inb == 1 {
  if (NF == 0) { bl[b]++; next }
  num = 1; nonf = 0
  for (i = 1; i <= NF; i++) { if (isnum($i)) continue; if (isnf($i)) { nonf = 1; continue } num = 0; break }
  if (num == 1) { rows[b]++; rc[b "|" NF]++; if (NF > mc) mc = NF; if (nonf == 1) nfr[b]++; next }
  nr[b]++; tot++
  if (em >= capn) { sup++; next }
  match($0, /^[ \t]*/); lw = substr($0, 1, RLENGTH); ntab = gsub(/\t/, "", lw); nsp = RLENGTH - ntab
  s = red($0); n = split(s, a, " "); w = (n > 0) ? fw(redall(a[1])) : "<EMPTY>"
  em++; E[em] = "nr|" li "|" b "|" nr[b] "|rows_before=" rows[b] "|sp=" nsp "|tab=" ntab "|word=" w
  next
}
END {
  ts = (b > capt) ? b - capt : 0
  printf "log|%d|lines=%d|tables=%d|nonrow=%d|emitted=%d|suppressed=%d|tables_suppressed=%d|cr=%d\n", li, nl, b, tot, em, sup, ts, ncr
  for (k = 1; k <= b && k <= capt; k++) {
    s = ""
    for (c = 1; c <= mc; c++) { key = k "|" c; if (key in rc) s = s (s == "" ? "" : ",") c ":" rc[key] }
    printf "table|%d|%d|header_cols=%d|rows=%d|rows_nonfinite=%d|row_cols=%s|nonrow=%d|blank=%d|closed=%s\n", li, k, hc[k], rows[k], nfr[k], (s == "" ? "-" : s), nr[k], bl[k], cl[k]
  }
  for (j = 1; j <= em; j++) print E[j]
}'
AWK_Q9B="$AWK_REDLIB$AWK_Q9B_MAIN"
# ── q2b: 이름 mix_<step>.liggghts 에서 step 만 · 고르기 (처음 · 가운데 = (n+1)/2 번째 · 끝 — 11-12 q2 와 같은 자리)
AWK_Q2B_STEPS='/^mix_[0-9]+[.]liggghts$/ { s = $0; sub(/^mix_/, "", s); sub(/[.]liggghts$/, "", s); print s }'
AWK_Q2B_PICK='
FILENAME == f1 { n++; a[n] = $0; next }
$0 ~ /^mix_/ { tot++; if ($0 ~ /^mix_[0-9]+[.]liggghts$/) mt++; else oth++; next }
{ noise++ }
END {
  printf "q2b|run=%s|files=%d|matched=%d|sorted=%d|other=%d|noise=%d\n", run, tot, mt, n, oth, noise
  if (n >= 1) { m = int((n + 1) / 2); printf "sel|first|%s\nsel|mid|%s\nsel|last|%s\n", a[1], a[m], a[n] }
}'
# ── q7b: conda-meta JSON 의 맨 위 "files" 배열만 (문자열 안 괄호 · 따옴표 · 중첩 "files" 무시 · \" \\ \/ 만 풀고 그 밖 이스케이프는 E 로 셈)
AWK_JSONFILES='
function tok(s, e) {
  if (d == 1 && ty[1] == "{" && expk == 1) { expk = 0; pend = (s == "files") ? 1 : 0; return }
  if (d == 2 && inf == 1) { nel++; if (e == 1) { nesc++; print "E|" } else print "P|" s; return }
  pend = 0
}
BEGIN { d = 0; ins = 0; bad = 0; fk = 0; nel = 0; nesc = 0; inf = 0; pend = 0; expk = 0 }
{
  line = $0; L = length(line)
  for (i = 1; i <= L; i++) {
    c = substr(line, i, 1)
    if (ins == 1) {
      if (c == "\\") { i++; e2 = substr(line, i, 1); if (e2 == "\"" || e2 == "\\" || e2 == "/") { if (keep == 1) buf = buf e2 } else { esc = 1; if (e2 == "u") i += 4 } continue }
      if (c == "\"") { ins = 0; if (keep == 1) tok(buf, esc); else pend = 0; continue }
      if (keep == 1) buf = buf c
      continue
    }
    if (c == "\"") { ins = 1; buf = ""; esc = 0; keep = ((d == 1 && expk == 1) || (d == 2 && inf == 1)) ? 1 : 0; continue }
    if (c == "{" || c == "[") { d++; ty[d] = c; if (d == 2 && c == "[" && pend == 1) { inf = 1; fk++ } pend = 0; if (d == 1 && c == "{") expk = 1; continue }
    if (c == "}" || c == "]") { if (d == 2 && inf == 1) inf = 0; d--; if (d < 0) { bad = 1; d = 0 } continue }
    if (c == ",") { if (d == 1 && ty[1] == "{") expk = 1; continue }
  }
  if (ins == 1) bad = 1
}
END { printf "S|elements=%d|escaped=%d|files_keys=%d|depth_end=%d|instr_end=%d|bad=%d\n", nel, nesc, fk, d, ins, bad }'
# ── q7b: 해석된 목록 → 절대 경로 (상한까지 · 이스케이프 · 위험 경로 (절대 · ..) 는 뺌)
AWK_Q7B_LIST='
function unsafe(r) { return (r == "" || substr(r, 1, 1) == "/" || r == ".." || r ~ /^[.][.]\// || r ~ /\/[.][.]\// || r ~ /\/[.][.]$/) }
$0 ~ /^[PE][|]/ { i++; if (i > maxf) next; if (substr($0, 1, 1) == "E") next; r = substr($0, 3); if (unsafe(r)) next; print pre r }'
# ── q7b: 묶음 stat (링크 따라가기 전 · 뒤) · sha256 · 해시 뒤 stat 를 이어 파일마다 한 줄 (경로는 쓰지 않는다 · 번호로만) + 다이제스트 입력 + 요약
AWK_Q7B_COMBINE='
function code(t) { if (t == "regular file") return "f"; if (t == "regular empty file") return "e"; if (t == "symbolic link") return "l"; if (t == "directory") return "d"; return "o" }
function pth(s,   p) { p = s; sub(/^[^|]*[|][^|]*[|][^|]*[|][^|]*[|]/, "", p); return p }
function out(i, a, b, c, d2, e, f) {
  print "f|" i "|" a "|" b "|" c "|" d2 "|" e "|" f
  print i "|" a "|" c "|" d2 "|" f > digf
  if (length(f) == 64 && f ~ /^[0-9a-f]+$/) nh2++; else RC7[f]++
}
function unsafe(r) { return (r == "" || substr(r, 1, 1) == "/" || r == ".." || r ~ /^[.][.]\// || r ~ /\/[.][.]\// || r ~ /\/[.][.]$/) }
BEGIN { printf "" > digf; na = 0; nhl = 0; i = 0; over = 0; nh2 = 0; nb = 0; nlk = 0 }
FILENAME == fA { na++; if (na <= dl) aL[$0] = 1; if (na <= dt) aT[$0] = 1; next }
FILENAME == fL { if ($1 == "L") { p = pth($0); LT[p] = code($2); LM[p] = $4 } next }
FILENAME == fT { if ($1 == "T") { p = pth($0); TY[p] = code($2); TS[p] = $3; TM[p] = $4 } next }
FILENAME == fH { nhl++; if (nhl <= dh) aH[$0] = 1; if (nhl <= dt2) aT2[$0] = 1; next }
FILENAME == fS { if (length($0) > 66 && substr($0, 65, 2) == "  " && substr($0, 1, 64) ~ /^[0-9a-f]+$/) SH[substr($0, 67)] = substr($0, 1, 64); next }
FILENAME == fT2 { if ($1 == "T") { p = pth($0); T2[p] = code($2) "|" $3 "|" $4 } next }
$0 ~ /^[PE][|]/ {
  i++
  if (i > maxf) { over++; next }
  if (substr($0, 1, 1) == "E") { out(i, "-", "-", "-", "-", "-", "ESCAPED"); next }
  r = substr($0, 3)
  if (unsafe(r)) { out(i, "-", "-", "-", "-", "-", "UNSAFE_PATH"); next }
  p = pre r
  if ((p in LT) == 0) { out(i, "-", "-", "-", "-", "-", (p in aL) ? "NO_LSTAT" : "STOPPED"); next }
  lt = LT[p]; lm = LM[p]; if (lt == "l") nlk++
  if ((p in TY) == 0) { out(i, lt, lm, "-", "-", "-", (p in aT) ? "BROKEN" : "STOPPED"); next }
  tt = TY[p]; ts = TS[p]; tm = TM[p]
  if (tt == "f" || tt == "e") { } else { out(i, lt, lm, tt, ts, tm, "NOT_REGULAR"); next }
  if (ts + 0 > maxb + 0) { out(i, lt, lm, tt, ts, tm, "TOO_BIG"); next }
  if ((p in SH) == 0) { out(i, lt, lm, tt, ts, tm, (p in aH) ? "HASH_FAIL" : "STOPPED"); next }
  if ((p in T2) == 0) { out(i, lt, lm, tt, ts, tm, (p in aT2) ? "CHANGED_DURING_HASH" : "STOPPED"); next }
  if (T2[p] == (tt "|" ts "|" tm)) { out(i, lt, lm, tt, ts, tm, SH[p]); nb += ts } else out(i, lt, lm, tt, ts, tm, "CHANGED_DURING_HASH")
  next
}
END {
  nc = split("BROKEN CHANGED_DURING_HASH ESCAPED HASH_FAIL NOT_REGULAR NO_LSTAT STOPPED TOO_BIG UNSAFE_PATH", CO, " "); rs = ""
  for (c = 1; c <= nc; c++) if (CO[c] in RC7) rs = rs (rs == "" ? "" : ";") CO[c] ":" RC7[CO[c]]
  printf "sum|%s|listed=%d|in_list=%d|over_cap=%d|hashed=%d|bytes_hashed=%.0f|links=%d|reasons=%s\n", kk, i, (i > maxf ? maxf : i), over, nh2, nb, nlk, (rs == "" ? "-" : rs) >> sumf
}'

# ── 시작 관문 (하나라도 안 되면 폴더도 만들지 않고 끝)
command -v timeout >/dev/null 2>&1 || { say "timeout 이 없음 — 아무것도 안 함 (폴더도 안 만듦)"; exit 3; }
TK=''
timeout -k 2 5 true </dev/null >/dev/null 2>&1 && TK='-k 5'
case "${HOME-}" in /?*) ;; *) say "HOME 이 절대경로가 아님 — 아무것도 안 함"; exit 3;; esac
[ "${#HOME}" -ge 4 ] || { say "HOME 이 너무 짧음 — 아무것도 안 함"; exit 3; }
STAMP=$(timeout 5 date -u +%Y%m%dT%H%M%SZ </dev/null 2>/dev/null)
case "$STAMP" in [0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9]T[0-9][0-9][0-9][0-9][0-9][0-9]Z) ;; *) say "UTC 시각을 못 읽음 — 아무것도 안 함"; exit 3;; esac
D=''; NAME=''
for sfx in '' _2 _3 _4 _5; do
  if timeout 10 mkdir -- "$HOME/mixer_e0_queryb_$STAMP$sfx" </dev/null 2>/dev/null; then NAME="mixer_e0_queryb_$STAMP$sfx"; D="$HOME/$NAME"; break; fi
done
[ -n "$D" ] || { say "새 폴더를 못 만듦 (이미 있음 · 권한 · 디스크) — 아무것도 안 함"; exit 3; }
timeout 10 mkdir -- "$D/raw" "$D/out" "$D/work" "$D/work/tmp" </dev/null 2>/dev/null || { say "하위 폴더를 못 만듦 — 멈춤 (만든 폴더 ~/$NAME)"; exit 3; }
cd -- "$D/work" 2>/dev/null || { say "작업 폴더로 못 들어감 — 멈춤 (만든 폴더 ~/$NAME)"; exit 3; }
export TMPDIR="$D/work/tmp"
FR="$D/raw/fields.txt"; PR="$D/raw/probes.txt"
: > "$FR"; : > "$PR"
printf '%s' "$SELF_TEXT" > "$D/raw/query_script.sh"
say "── 믹서 E0 보충 조회 q9b · q2b · q7b 시작 · 폴더 ~/$NAME · 조회 상한 $BUDGET 초 · 읽기 전용 (제출 · 취소 · 지우기 없음)"

# ── 도우미
put() { local v=${2-}; v=${v//$'\n'/ }; v=${v//$'\r'/ }; printf '%s=%s\n' "$1" "$v" >> "$FR"; }
INTR=0
trap 'INTR=1' INT
over() { [ "$INTR" = 1 ] || [ "$SECONDS" -ge "$BUDGET" ]; }
why() { if [ "$INTR" = 1 ]; then printf SKIPPED_INTERRUPT; else printf SKIPPED_BUDGET; fi; }
want() { case " $QSEL " in *" $1 "*) return 0;; esac; return 1; }
probe() {  # probe <이름> <초> <출력 파일> <명령...> → 출력 파일 (stdout+stderr · 상한 CAP) · raw/probes.txt 한 줄 · 반환 = 명령 rc
  local name=$1 secs=$2 f=$3 t0 rc st by
  shift 3
  if over; then printf '%s|%s|-|0|0|%s\n' "$name" "$(why)" "${1##*/}" >> "$PR"; : > "$f"; return 200; fi
  command -v -- "$1" >/dev/null 2>&1 || { printf '%s|MISSING|-|0|0|%s\n' "$name" "${1##*/}" >> "$PR"; : > "$f"; return 127; }
  t0=$SECONDS
  timeout $TK "$secs" "$@" </dev/null 2>&1 | timeout 900 head -c "$CAP" > "$f"
  rc=${PIPESTATUS[0]}
  by=$(timeout 10 wc -c < "$f" 2>/dev/null); by=${by//[^0-9]/}
  case "$rc" in 0) st=OK;; 124|137) st=TIMEOUT;; 126|127) st=MISSING;; 141) st=TRUNC;; *) st=FAIL;; esac
  [ "$st" = OK ] && [ "${by:-0}" -ge "$CAP" ] && st=TRUNC
  printf '%s|%s|%s|%s|%s|%s\n' "$name" "$st" "$rc" "$((SECONDS - t0))" "${by:-0}" "${1##*/}" >> "$PR"
  return "$rc"
}
stl() {  # stl <이름> <rc> <초> <바이트> <명령> → 상태 줄 하나 (rc → 상태)
  local s
  case "$2" in 0) s=OK;; 124|137) s=TIMEOUT;; 126|127) s=MISSING;; *) s=FAIL;; esac
  printf '%s|%s|%s|%s|%s|%s\n' "$1" "$s" "$2" "$3" "$4" "$5" >> "$PR"
}
ftype() {  # ftype <경로> → "f|크기|mtime" (정규) · e (빈 정규) · l (링크 · 따라가지 않음) · d · o 또는 "ABSENT||" · "DENIED||" · "STATFAIL||"
  local s e c
  s=$(timeout 10 stat -c '%F|%s|%Y' -- "$1" </dev/null 2>"$D/work/stat_err.txt") || {
    e=$(timeout 5 head -c 400 -- "$D/work/stat_err.txt" 2>/dev/null)
    case "$e" in *'ermission denied'*) printf 'DENIED||';; *'o such file'*|*'ot a directory'*) printf 'ABSENT||';; *) printf 'STATFAIL||';; esac
    return 1; }
  case "${s%%|*}" in 'regular file') c=f;; 'regular empty file') c=e;; 'symbolic link') c=l;; directory) c=d;; *) c=o;; esac
  printf '%s|%s' "$c" "${s#*|}"
}
hashline() {  # hashline <경로> <최대 바이트> → "sha256|바이트|mtime" 또는 "사유|바이트|mtime" (해시 전후 stat 이 같아야 sha256)
  local p=$1 max=$2 s t sz mt h a rc
  s=$(timeout 10 stat -c '%F|%s|%Y' -- "$p" </dev/null 2>/dev/null) || { printf 'ABSENT||'; return 1; }
  t=${s%%|*}; s=${s#*|}; sz=${s%%|*}; mt=${s#*|}
  case "$t" in 'regular file'|'regular empty file') ;; *) printf 'NOT_REGULAR|%s|%s' "$sz" "$mt"; return 1;; esac
  [ "$sz" -le "$max" ] 2>/dev/null || { printf 'TOO_BIG|%s|%s' "$sz" "$mt"; return 1; }
  h=$(timeout $TK 120 sha256sum -- "$p" </dev/null 2>/dev/null); rc=$?; h=${h%% *}
  case "$rc" in 124|137) printf 'HASH_TIMEOUT|%s|%s' "$sz" "$mt"; return 1;; esac
  case "$h" in ''|*[^0-9a-f]*) printf 'HASH_FAIL|%s|%s' "$sz" "$mt"; return 1;; esac
  [ "${#h}" -eq 64 ] || { printf 'HASH_FAIL|%s|%s' "$sz" "$mt"; return 1; }
  a=$(timeout 10 stat -c '%F|%s|%Y' -- "$p" </dev/null 2>/dev/null)
  [ "$a" = "$t|$sz|$mt" ] || { printf 'CHANGED_DURING_HASH|%s|%s' "$sz" "$mt"; return 1; }
  printf '%s|%s|%s' "$h" "$sz" "$mt"
}
DONE=0
batch() {  # batch <이름> <초> <출력> <명령…> — 전역 배열 BATCH 를 CH7 개씩 잘라 명령 뒤에 붙인다 · 상태 줄 하나 · DONE = 끝까지 돈 묶음까지의 항목 수
  local name=$1 secs=$2 f=$3 i=0 rc w=0 t0=$SECONDS nb=${#BATCH[@]} s
  shift 3
  : > "$f"; : > "$f.err"; DONE=0
  while [ "$i" -lt "$nb" ]; do
    if over; then printf '%s|%s|-|%s|%s|%s\n' "$name" "$(why)" "$((SECONDS - t0))" "$i" "${1##*/}" >> "$PR"; return 0; fi
    timeout $TK "$secs" "$@" "${BATCH[@]:i:CH7}" </dev/null >> "$f" 2>> "$f.err"; rc=$?
    case "$rc" in 0) ;; 124|137) w=124; break;; 126|127) w=127; break;; *) [ "$w" = 0 ] && w=$rc;; esac
    i=$((i + CH7)); DONE=$i
  done
  [ "$DONE" -gt "$nb" ] && DONE=$nb
  case "$w" in 0) s=OK;; 124) s=TIMEOUT;; 127) s=MISSING;; *) s=FAIL;; esac
  printf '%s|%s|%s|%s|%s|%s\n' "$name" "$s" "$w" "$((SECONDS - t0))" "$nb" "${1##*/}" >> "$PR"
}
red_file() {  # red_file <raw> <out> — 가린 사본을 work/ 에 먼저 쓰고 awk 가 성공할 때만 out/ 로 옮겨 적는다 (실패면 out/ 에 아무것도 안 생김)
  local tmp="$D/work/red_${2##*/}"
  MIX_RED=1 timeout 30 awk "$AWK_RED" "$1" > "$tmp" 2>/dev/null || return 1
  timeout 30 cat -- "$tmp" > "$2" 2>/dev/null
}

# ── 신원 (원문은 raw/private_* 에만 — out/ 로 복사하지 않는다 · 해시 목록에도 없다) · 가림 토큰
MYUID=$(timeout 5 id -u </dev/null 2>/dev/null); MYGID=$(timeout 5 id -g </dev/null 2>/dev/null)
IDN=$(timeout 5 id -un </dev/null 2>/dev/null)
ME=${USER-}; [ -n "$ME" ] || ME=$IDN
HOST_F=$(timeout 10 hostname -f </dev/null 2>/dev/null); HOST_S=$(timeout 10 hostname -s </dev/null 2>/dev/null)
[ -n "$HOST_S" ] || HOST_S=$(timeout 5 uname -n </dev/null 2>/dev/null)
HOME_REAL=$(cd -P -- "$HOME" 2>/dev/null && pwd -P)
printf 'user=%s\nid_un=%s\nuid=%s\ngid=%s\nhost_f=%s\nhost_s=%s\nhome=%s\nhome_real=%s\n' "$ME" "$IDN" "$MYUID" "$MYGID" "$HOST_F" "$HOST_S" "$HOME" "$HOME_REAL" > "$D/raw/private_identity.txt"
probe nodes_sinfo 30 "$D/raw/private_nodes.txt" sinfo -h -N -o '%N'; RCN=$?
TOKF="$D/raw/private_tokens.txt"; : > "$TOKF"
tok() { [ "${#1}" -ge 2 ] || return 0; printf '%s|%s|%s\n' "$3" "$2" "$1" >> "$TOKF"; }
tok "$HOME" '<HOME>' 0
[ "$HOME_REAL" = "$HOME" ] || tok "$HOME_REAL" '<HOME_REAL>' 0
tok "$HOST_F" '<HOST>' 1; tok "$HOST_S" '<HOST>' 1; tok "$ME" '<USER>' 1; tok "$IDN" '<USER>' 1
case "$HOST_F" in *.*) DOM=${HOST_F#*.}; case "$DOM" in *.*) [ "${#DOM}" -ge 6 ] && tok "$DOM" '<DOMAIN>' 0;; esac;; esac
NN=0
if [ "$RCN" = 0 ]; then
  NODES=$(timeout 10 awk 'length($0) <= 64 && $0 ~ /^[A-Za-z0-9][A-Za-z0-9._-]+$/ { if (s[$0]++ == 0) print }' "$D/raw/private_nodes.txt" 2>/dev/null)
  for x in $NODES; do tok "$x" '<NODE>' 1; NN=$((NN + 1)); done
fi
TOKV=(); ti=0; : > "$D/raw/private_tok_plain.txt"; : > "$D/raw/private_tok_word.txt"
while IFS='|' read -r tl tw tr tv; do
  ti=$((ti + 1)); export "MIX_T$ti=$tv" "MIX_R$ti=$tr" "MIX_W$ti=$tw"; TOKV+=("$tv")
  case "$tv" in *[^0-9a-f]*) if [ "${#tv}" -ge 6 ]; then printf '%s\n' "$tv" >> "$D/raw/private_tok_plain.txt"; continue; fi;; esac
  printf '%s\n' "$tv" >> "$D/raw/private_tok_word.txt"
done < <(timeout 10 awk -F'|' '{ v = $0; sub(/^[^|]*[|][^|]*[|]/, "", v); if (seen[v]++ == 0) printf "%d|%s\n", length(v), $0 }' "$TOKF" 2>/dev/null | timeout 10 sort -t'|' -k1,1nr 2>/dev/null)
export MIX_TN=$ti

# ── 실행 메타
T_START=$(timeout 5 date -u +%Y-%m-%dT%H:%M:%SZ </dev/null 2>/dev/null)
put format "$FORMAT"; put block_id "$BLOCK_ID"; put target_alias ibb; put folder "~/$NAME"
put captured_start_utc "$T_START"; put bash_version "$BASH_VERSION"
put timeout_kill_after "${TK:-unsupported}"; put budget_seconds "$BUDGET"; put pack_deadline_seconds "$HARD"
put switch.MIX_Q "$QSEL"; put redaction_tokens "$ti"; put redaction.node_tokens "$NN"
for q in $QSEL; do case "$q" in q9b|q2b|q7b) ;; *) put qsel.unknown_token "$q";; esac; done
x=$(timeout 10 md5sum -- "$D/raw/query_script.sh" </dev/null 2>/dev/null); put script_md5 "${x%% *}"
x=$(timeout 10 sha256sum -- "$D/raw/query_script.sh" </dev/null 2>/dev/null); put script_sha256 "${x%% *}"
put script_bytes "${#SELF_TEXT}"
for t in stat readlink find sort awk head tail wc cat grep sha256sum md5sum tar gzip sinfo hostname id date; do
  command -v "$t" >/dev/null 2>&1 && put "tool.$t" present || put "tool.$t" MISSING
done
ALLOC=no; [ -n "${SLURM_JOB_ID-}" ] && ALLOC=yes; put inside_slurm_allocation "$ALLOC"
x=$(timeout 5 awk -W version </dev/null 2>/dev/null | timeout 5 head -n 1); [ -n "$x" ] || x=$(timeout 5 awk --version </dev/null 2>/dev/null | timeout 5 head -n 1)
put awk_version "$x"
BASE="$HOME/mixer_dev7_20260930_v26"
put base "$BASE"; put base.stat "$(ftype "$BASE")"
ENV7="$HOME/.conda/envs/myenv"
put q7b.max_files "$MAXF7"; put q7b.max_file_bytes "$MAXB7"; put q7b.chunk "$CH7"; put q9b.max_nonrow_lines "300"

# ── q9b DEV 삽입 런 로그의 thermo 표 안 비-행 줄 — 차례 · 표 안 자리 · 앞 공백 · 가린 첫 낱말
capchk() {  # capchk <q9b 출력> <이름> → log 줄의 suppressed · tables_suppressed 가 0 이 아니면 TRUNC 줄
  local x
  x=$(timeout 10 awk -F'|' '$1 == "log" { s = 0; for (i = 3; i <= NF; i++) if ($i ~ /^(suppressed|tables_suppressed)=/) { v = $i; sub(/^[a-z_]*=/, "", v); s += v } print s; exit }' "$1" 2>/dev/null)
  case "$x" in ''|0) ;; *) printf '%s|TRUNC|-|0|%s|awk\n' "$2" "$x" >> "$PR";; esac
}
q9b() {
  local i=0 run L t ty
  if over; then printf 'q9b|%s|-|0|0|-\n' "$(why)" >> "$PR"; return 0; fi
  for run in $LOGS9; do
    i=$((i + 1)); L="$BASE/$run/log.liggghts"
    put "q9b.l$i.run" "$run"
    if over; then printf 'q9b_l%d|%s|-|0|0|stat\n' "$i" "$(why)" >> "$PR"; continue; fi
    t=$(ftype "$L"); put "q9b.l$i.stat" "$t"; ty=${t%%|*}
    case "$ty" in
      f|e) probe "q9b_l$i" 60 "$D/raw/q9b_l$i.txt" awk -v li="$i" "$AWK_Q9B" "$L"
           capchk "$D/raw/q9b_l$i.txt" "q9b_l${i}_cap";;
      ABSENT|DENIED) printf 'q9b_l%d|%s|-|0|0|stat\n' "$i" "$ty" >> "$PR";;
      *) printf 'q9b_l%d|FAIL|-|0|0|stat\n' "$i" >> "$PR";;
    esac
  done
}
# ── q2b DEV 덤프 프레임의 줄 끝 꼴 (처음 · 가운데 · 끝 — 이름만 고름) — 머리는 셸 변수로만 읽는다 (파일에 안 씀)
frame_check() {  # frame_check <자리> <step> <경로>
  local pos=$1 step=$2 f=$3 t ty sz t0 h rc lb rc2 n rc3 k r e1=- nl=- l1=- ts=- e3=- at=- eq=-
  local -a HL=()
  t=$(ftype "$f"); ty=${t%%|*}; sz=${t#*|}; sz=${sz%%|*}
  case "$ty" in
    f|e) ;;
    *) case "$ty" in ABSENT|DENIED) r=$ty;; *) r=FAIL;; esac
       printf 'q2b_%s_stat|%s|-|0|0|stat\n' "$pos" "$r" >> "$PR"
       printf 'frame|pos=%s|step=%s|type=%s|bytes=%s|end_nl=-|newlines=-|l1_timestep=-|tstep=-|l3_natoms=-|atoms=-|nl_eq_9_plus_atoms=-\n' "$pos" "$step" "$ty" "${sz:--}" >> "$D/raw/q2b_frames.txt"
       return 0;;
  esac
  if over; then printf 'q2b_%s_head|%s|-|0|0|head\n' "$pos" "$(why)" >> "$PR"
  else
    t0=$SECONDS
    h=$(timeout $TK 30 head -c 4096 -- "$f" 2>/dev/null; printf 'x%s' "$?")
    rc=${h##*x}; h=${h%x*}
    stl "q2b_${pos}_head" "$rc" "$((SECONDS - t0))" "${#h}" head
    if [ "$rc" = 0 ]; then
      k=0; r=$h
      while [ "$k" -lt 4 ]; do
        case "$r" in *$'\n'*) ;; *) break;; esac
        k=$((k + 1)); HL[k]=${r%%$'\n'*}; r=${r#*$'\n'}
      done
      if [ "${HL[1]-}" = 'ITEM: TIMESTEP' ]; then l1=yes; else l1=no; fi
      if [ "$k" -lt 2 ]; then ts=missing
      else
        case "${HL[2]}" in
          ''|*[^0-9]*) ts=nonint;;
          *) if [ "${HL[2]}" = "$step" ]; then ts=same
             elif [ "${#HL[2]}" -le 18 ] && [ "${#step}" -le 18 ] && [ "$((10#${HL[2]}))" = "$((10#$step))" ]; then ts=num
             else ts=differ; fi;;
        esac
      fi
      if [ "${HL[3]-}" = 'ITEM: NUMBER OF ATOMS' ]; then e3=yes; else e3=no; fi
      if [ "$k" -lt 4 ]; then at=missing
      else case "${HL[4]}" in ''|*[^0-9]*) at=NONINT;; *) if [ "${#HL[4]}" -le 18 ]; then at=$((10#${HL[4]})); else at=TOOLONG; fi;; esac; fi
    fi
    h=''; r=''; HL=()
  fi
  if over; then printf 'q2b_%s_tail|%s|-|0|0|tail\n' "$pos" "$(why)" >> "$PR"
  else
    t0=$SECONDS
    lb=$(timeout $TK 30 tail -c 1 -- "$f" 2>/dev/null; printf 'x%s' "$?")
    rc2=${lb##*x}; lb=${lb%x*}
    stl "q2b_${pos}_tail" "$rc2" "$((SECONDS - t0))" "${#lb}" tail
    if [ "$rc2" = 0 ]; then if [ "$lb" = $'\n' ]; then e1=yes; else e1=no; fi; fi
    lb=''
  fi
  if over; then printf 'q2b_%s_wc|%s|-|0|0|wc\n' "$pos" "$(why)" >> "$PR"
  else
    t0=$SECONDS
    n=$(timeout $TK 120 wc -l -- "$f" 2>/dev/null); rc3=$?
    n=${n%% *}
    stl "q2b_${pos}_wc" "$rc3" "$((SECONDS - t0))" 0 wc
    if [ "$rc3" = 0 ]; then case "$n" in ''|*[^0-9]*) ;; *) nl=$n;; esac; fi
  fi
  case "$nl" in ''|*[^0-9]*) eq=-;; *) case "$at" in ''|*[^0-9]*) eq=-;; *) if [ "$nl" = "$((at + 9))" ]; then eq=yes; else eq=no; fi;; esac;; esac
  printf 'frame|pos=%s|step=%s|type=%s|bytes=%s|end_nl=%s|newlines=%s|l1_timestep=%s|tstep=%s|l3_natoms=%s|atoms=%s|nl_eq_9_plus_atoms=%s\n' \
    "$pos" "$step" "$ty" "$sz" "$e1" "$nl" "$l1" "$ts" "$e3" "$at" "$eq" >> "$D/raw/q2b_frames.txt"
}
q2b() {
  local P="$BASE/$ONE_RUN/post" tg pos step
  if over; then printf 'q2b|%s|-|0|0|-\n' "$(why)" >> "$PR"; return 0; fi
  put q2b.run "$ONE_RUN"
  probe q2b_names 120 "$D/work/q2b_names.txt" find "$P" -mindepth 1 -maxdepth 1 -type f -name 'mix_*.liggghts' -printf '%f\n'
  probe q2b_steps 30 "$D/work/q2b_steps.txt" awk "$AWK_Q2B_STEPS" "$D/work/q2b_names.txt"
  probe q2b_sort 60 "$D/work/q2b_sorted.txt" sort -n -- "$D/work/q2b_steps.txt"
  probe q2b_pick 30 "$D/raw/q2b_pick.txt" awk -v run="$ONE_RUN" -v f1="$D/work/q2b_sorted.txt" "$AWK_Q2B_PICK" "$D/work/q2b_sorted.txt" "$D/work/q2b_names.txt"
  : > "$D/raw/q2b_frames.txt"
  while IFS='|' read -r tg pos step; do
    [ "$tg" = sel ] || continue
    case "$step" in ''|*[^0-9]*) continue;; esac
    case "$pos" in first|mid|last) ;; *) continue;; esac
    frame_check "$pos" "$step" "$P/mix_$step.liggghts"
  done < "$D/raw/q2b_pick.txt"
}
# ── q7b Open MPI 런타임 부품의 설치 신원 (conda-meta JSON 의 파일 목록 → 파일마다 sha256 · 번호로만)
q7b_pkg() {  # q7b_pkg <번호> <꾸러미 이름> <환경 실제 경로>
  local k=$1 p=$2 ER=$3 S="$D/raw/q7b_p$1_sum.txt" FL="$D/raw/q7b_p$1_files.txt" W7="$D/work/q7b_p$1" jn m x J h po DL DT DH DT2 nd sl
  if over; then printf 'q7b_p%s|%s|-|0|0|-\n' "$k" "$(why)" >> "$PR"; return 0; fi
  jn=$(timeout 10 awk -v want="$p" '{ n = $0; sub(/[.]json$/, "", n); sub(/-[^-]*-[^-]*$/, "", n); if (n == want) print $0 }' "$D/work/q7b_meta_ls.txt" 2>/dev/null)
  m=$(printf '%s' "$jn" | timeout 10 awk 'END { print NR }' 2>/dev/null); m=${m//[^0-9]/}; m=${m:-0}
  if [ "$m" = 0 ]; then printf 'pkg|%s|name=%s|json=-|matches=0\n' "$k" "$p" > "$S"; printf 'q7b_p%s_json|ABSENT|-|0|0|find\n' "$k" >> "$PR"; return 0; fi
  if [ "$m" -gt 1 ]; then printf 'pkg|%s|name=%s|json=-|matches=%s\n' "$k" "$p" "$m" > "$S"; printf 'q7b_p%s_json|FAIL|-|0|0|find\n' "$k" >> "$PR"; return 0; fi
  J="$ER/conda-meta/$jn"
  printf 'pkg|%s|name=%s|json=%s|matches=1\n' "$k" "$p" "$jn" > "$S"
  printf 'q7b_p%s_json|OK|-|0|0|find\n' "$k" >> "$PR"
  h=$(hashline "$J" 67108864) && x=OK || x=FAIL
  printf 'json|%s|%s\n' "$k" "$h" >> "$S"
  printf 'q7b_p%s_jsonhash|%s|-|0|0|sha256sum\n' "$k" "$x" >> "$PR"
  probe "q7b_p${k}_parse" 60 "${W7}_parse.txt" awk "$AWK_JSONFILES" "$J"
  po=$(timeout 10 awk -F'|' '$1 == "S" { print substr($0, 3) }' "${W7}_parse.txt" 2>/dev/null)
  printf 'parse|%s|%s\n' "$k" "${po:--}" >> "$S"
  case "$po" in elements=*'|files_keys=1|depth_end=0|instr_end=0|bad=0') printf 'q7b_p%s_parse_ok|OK|-|0|0|awk\n' "$k" >> "$PR";;
    *) printf 'q7b_p%s_parse_ok|FAIL|-|0|0|awk\n' "$k" >> "$PR"; return 0;; esac
  probe "q7b_p${k}_list" 30 "${W7}_abs.txt" awk -v pre="$ER/" -v maxf="$MAXF7" "$AWK_Q7B_LIST" "${W7}_parse.txt"
  BATCH=(); mapfile -t BATCH < "${W7}_abs.txt"
  batch "q7b_p${k}_lstat" 60 "${W7}_lstat.txt" stat -c 'L|%F|%s|%Y|%n' --; DL=$DONE
  batch "q7b_p${k}_tstat" 60 "${W7}_tstat.txt" stat -L -c 'T|%F|%s|%Y|%n' --; DT=$DONE
  probe "q7b_p${k}_sel" 30 "${W7}_tohash.txt" awk -F'|' -v maxb="$MAXB7" '$1 == "T" && ($2 == "regular file" || $2 == "regular empty file") && $3 + 0 <= maxb + 0 { p = $0; sub(/^[^|]*[|][^|]*[|][^|]*[|][^|]*[|]/, "", p); print p }' "${W7}_tstat.txt"
  BATCH=(); mapfile -t BATCH < "${W7}_tohash.txt"
  batch "q7b_p${k}_hash" 120 "${W7}_sha.txt" sha256sum --; DH=$DONE
  batch "q7b_p${k}_tstat2" 60 "${W7}_tstat2.txt" stat -L -c 'T|%F|%s|%Y|%n' --; DT2=$DONE
  BATCH=()
  probe "q7b_p${k}_combine" 60 "$FL" awk -F'|' -v pre="$ER/" -v maxf="$MAXF7" -v maxb="$MAXB7" -v dl="$DL" -v dt="$DT" -v dh="$DH" -v dt2="$DT2" \
    -v fA="${W7}_abs.txt" -v fL="${W7}_lstat.txt" -v fT="${W7}_tstat.txt" -v fH="${W7}_tohash.txt" -v fS="${W7}_sha.txt" -v fT2="${W7}_tstat2.txt" \
    -v sumf="$S" -v digf="${W7}_dig.txt" -v kk="$k" "$AWK_Q7B_COMBINE" \
    "${W7}_abs.txt" "${W7}_lstat.txt" "${W7}_tstat.txt" "${W7}_tohash.txt" "${W7}_sha.txt" "${W7}_tstat2.txt" "${W7}_parse.txt"
  x=$(timeout 60 sha256sum -- "${W7}_dig.txt" </dev/null 2>/dev/null); x=${x%% *}
  nd=$(timeout 10 wc -l < "${W7}_dig.txt" 2>/dev/null); nd=${nd//[^0-9]/}
  case "$x" in ''|*[^0-9a-f]*) printf 'q7b_p%s_digest|FAIL|-|0|0|sha256sum\n' "$k" >> "$PR";;
    *) printf 'digest|%s|%s|lines=%s\n' "$k" "$x" "${nd:-0}" >> "$S"; printf 'q7b_p%s_digest|OK|-|0|0|sha256sum\n' "$k" >> "$PR";; esac
  sl=$(timeout 10 awk -F'|' '$1 == "sum" { o = 0; r = "?"; for (i = 3; i <= NF; i++) { if ($i ~ /^over_cap=/) o = substr($i, 10); if ($i ~ /^reasons=/) r = substr($i, 9) } print o "|" r }' "$S" 2>/dev/null)
  case "$sl" in *'|-') printf 'q7b_p%s_files|OK|-|0|0|awk\n' "$k" >> "$PR";; *) printf 'q7b_p%s_files|FAIL|-|0|0|awk\n' "$k" >> "$PR";; esac
  case "${sl%%|*}" in ''|0) ;; *) printf 'q7b_p%s_cap|TRUNC|-|0|%s|awk\n' "$k" "${sl%%|*}" >> "$PR";; esac
}
q7b() {
  local ER k=0 p
  if over; then printf 'q7b|%s|-|0|0|-\n' "$(why)" >> "$PR"; return 0; fi
  ER=$(timeout 10 readlink -e -- "$ENV7" </dev/null 2>/dev/null) || ER=''
  put q7b.env "$ENV7"; put q7b.env_real "${ER:-UNRESOLVED}"
  if [ -z "$ER" ]; then printf 'q7b_env|ABSENT|-|0|0|readlink\n' >> "$PR"; return 0; fi
  printf 'q7b_env|OK|-|0|0|readlink\n' >> "$PR"
  probe q7b_meta_ls 60 "$D/work/q7b_meta_ls.txt" find "$ER/conda-meta" -mindepth 1 -maxdepth 1 -type f -name '*.json' -printf '%f\n'
  for p in $PKG7; do
    k=$((k + 1))
    q7b_pkg "$k" "$p" "$ER"
  done
}

for q in q9b q2b q7b; do
  if want "$q"; then "$q"; else printf '%s|SKIPPED_SWITCH|-|0|0|-\n' "$q" >> "$PR"; fi
done

# ── 끝: 기록 → 가린 사본 out/ → 남은 문자열 확인 → SHA256SUMS → tgz
T_END=$(timeout 5 date -u +%Y-%m-%dT%H:%M:%SZ </dev/null 2>/dev/null)
put captured_end_utc "$T_END"; put elapsed_seconds "$SECONDS"; put interrupted "$INTR"
put probe_status_counts "$(timeout 10 awk -F'|' '{ c[$2]++ } END { for (s in c) printf "%s=%d ", s, c[s] }' "$PR")"
RED_OK=0; command -v awk >/dev/null 2>&1 && RED_OK=1
RAWL=(); NRF=0
for f in "$D"/raw/*; do
  b=${f##*/}
  case "$b" in private_*) continue;; esac
  RAWL+=("$b")
  [ "$b" = query_script.sh ] && continue
  if [ "$SECONDS" -ge "$HARD" ]; then printf 'redact_skipped_deadline=%s\n' "$b" >> "$D/out/fields_post.txt"; NRF=$((NRF + 1)); continue; fi
  if [ "$RED_OK" = 1 ]; then red_file "$f" "$D/out/$b" || { printf 'redact_fail=%s\n' "$b" >> "$D/out/fields_post.txt"; NRF=$((NRF + 1)); }
  else printf 'redact_fail=%s\n' "$b" >> "$D/out/fields_post.txt"; NRF=$((NRF + 1)); fi
done
printf '%s' "$SELF_TEXT" > "$D/out/query_script.sh"
RES=0
if [ -s "$D/raw/private_tok_plain.txt" ]; then
  c=$(timeout 30 grep -r -F -c -f "$D/raw/private_tok_plain.txt" --exclude=query_script.sh -- "$D/out" 2>/dev/null | timeout 10 awk -F: '{ s += $NF } END { print s + 0 }')
  RES=$((RES + ${c:-0}))
fi
if [ -s "$D/raw/private_tok_word.txt" ]; then
  c=$(timeout 30 grep -r -w -F -c -f "$D/raw/private_tok_word.txt" --exclude=query_script.sh -- "$D/out" 2>/dev/null | timeout 10 awk -F: '{ s += $NF } END { print s + 0 }')
  RES=$((RES + ${c:-0}))
fi
printf 'redaction.available=%s\nredaction.residual_token_hits=%s\nredaction.files_not_redacted=%s\n' "$RED_OK" "$RES" "$NRF" >> "$D/out/fields_post.txt"
( cd "$D/raw" && timeout 60 sha256sum -- "${RAWL[@]}" ) > "$D/out/RAW_SHA256SUMS" 2>/dev/null
OUTL=(); for f in "$D"/out/*; do b=${f##*/}; [ "$b" = SHA256SUMS ] || OUTL+=("$b"); done
( cd "$D/out" && timeout 60 sha256sum -- "${OUTL[@]}" ) > "$D/out/SHA256SUMS" 2>/dev/null
TGZ="$D/$NAME.tgz"; TGZ_SHA=''; TGZ_BYTES=''
if timeout 120 tar --owner=0 --group=0 --numeric-owner -czf "$TGZ" -C "$D" out </dev/null 2>"$D/work/tar_err.txt"; then
  x=$(timeout 60 sha256sum -- "$TGZ" </dev/null 2>/dev/null); TGZ_SHA=${x%% *}
  TGZ_BYTES=$(timeout 10 stat -c %s -- "$TGZ" </dev/null 2>/dev/null)
  printf '%s  %s\n' "$TGZ_SHA" "$NAME.tgz" > "$D/$NAME.tgz.sha256"
fi

# ── 화면 (조회별 상태 · 묶음 · 경로는 ~/ 로만)
[ "$INTR" = 1 ] && say "⚠ Ctrl-C 로 멈춤 — 남은 조회는 SKIPPED_INTERRUPT · 묶음은 만들었다 (넘길지는 1저자)"
say "── 끝 · $SECONDS 초 · 조회 $(timeout 10 awk -F'|' '{ c[$2]++ } END { for (s in c) printf "%s %d  ", s, c[s] }' "$PR")"
for q in q9b q2b q7b; do
  say "$q  $(timeout 10 awk -F'|' -v q="$q" '$1 == q || index($1, q "_") == 1 { c[$2]++ } END { for (s in c) printf "%s %d  ", s, c[s] }' "$PR")"
done
if [ "$RES" = 0 ] && [ "$NRF" = 0 ]; then say "가림 확인  out/ 에 남은 계정 · 호스트 · 노드 · 경로 문자열 0 곳 · 가린 파일 전부 (노드 이름 $NN 개 가림 목록)"
else
  [ "$RES" = 0 ] || say "가림 확인  ⚠ out/ 에 남은 계정 · 호스트 · 노드 · 경로 문자열 $RES 곳 — tgz 를 넘기지 말 것 (out/ 을 확인)"
  [ "$NRF" = 0 ] || say "가림 확인  ⚠ 가림 못 한 파일 $NRF 개 (out/ 에 빠짐) — 넘기지 말 것"
fi
[ "$NN" = 0 ] && say "노드 이름  ⚠ 가림 목록 0 개 (sinfo 노드 목록을 못 받음) — 출력에 노드 이름이 들어갈 자리는 없게 짰지만 넘기기 전에 out/ 을 한 번 볼 것"
if [ -n "$TGZ_SHA" ]; then
  say "가져올 파일 ~/$NAME/$NAME.tgz  ($TGZ_BYTES 바이트 · out/ 만 · 가린 사본)"
  say "sha256     $TGZ_SHA"
else say "⚠ tgz 를 못 만듦 (tar) — ~/$NAME/out/ 폴더를 그대로 가져올 것"; fi
say "raw/ (가리지 않은 원문) · work/ 는 ~/$NAME/ 에 남김 — 가져오지 않는다"

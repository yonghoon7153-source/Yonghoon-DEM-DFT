"""Apply one reseal edit to the first8 launch folder of a SCRATCH tree (never the repository).
Usage:
  python3 -I -B apply_reseal.py <tree> seal --pin <commit> --files <seal_candidate.json>
      F8/source_seal.json: source_pin + the 12 file rows (scope kept)            [order step 1]
  python3 -I -B apply_reseal.py <tree> manifest --candidate <cand_dir> --cases E0|all8 [--source-pin <sha>] [--meta-pin <sha>]
      F8/static_asset_manifest.json: deck_meta rows (sha256 + bytes) from the candidate;
      --source-pin replaces the header source_pin; --meta-pin adds metadata_generation_source_pin   [step 3]
  python3 -I -B apply_reseal.py <tree> planned --candidate <cand_dir> --cases E0|all8
      F8/planned_assets/<case>/deck_meta.json bytes + the SHA256SUMS lines                       [step 4]
Prints before -> after sha256 (first 12) of every file it changes."""
import argparse, hashlib, json
from pathlib import Path
F8 = 'docs/reviews/mixer_first8_launch_preparation_20261106'
ALL8 = tuple('PRECAL_R1_B%d_%s' % (b, r) for b in (1, 2, 3) for r in ('U', 'C')) + ('PRECAL_N0', 'PRECAL_E0')
def sha(raw): return hashlib.sha256(raw).hexdigest()
def dump(v): return (json.dumps(v, indent=2, ensure_ascii=False) + '\n').encode('utf-8')
def write(p, raw):
    old = sha(p.read_bytes()) if p.exists() else None
    p.write_bytes(raw)
    print('changed', p.as_posix().split(F8 + '/')[-1], (old or '-')[:12], '->', sha(raw)[:12])
ap = argparse.ArgumentParser()
ap.add_argument('tree'); ap.add_argument('step', choices=('seal', 'manifest', 'planned'))
ap.add_argument('--pin'); ap.add_argument('--files'); ap.add_argument('--candidate')
ap.add_argument('--cases', choices=('E0', 'all8')); ap.add_argument('--source-pin'); ap.add_argument('--meta-pin')
a = ap.parse_args()
f8 = Path(a.tree) / F8
cases = ('PRECAL_E0',) if a.cases == 'E0' else ALL8
if a.step == 'seal':
    seal = json.loads((f8 / 'source_seal.json').read_bytes())
    cand = json.loads(Path(a.files).read_bytes())
    assert [r['path'] for r in cand['files']] == [r['path'] for r in seal['files']]
    seal['source_pin'] = a.pin
    seal['files'] = [dict(path=r['path'], sha256=r['sha256']) for r in cand['files']]
    write(f8 / 'source_seal.json', dump(seal))
elif a.step == 'manifest':
    m = json.loads((f8 / 'static_asset_manifest.json').read_bytes())
    for cid in cases:
        raw = (Path(a.candidate) / 'candidate_assets' / cid / 'deck_meta.json').read_bytes()
        row = [r for r in m['files'] if r['path'] == 'planned_assets/%s/deck_meta.json' % cid]
        assert len(row) == 1
        row[0].update(bytes=len(raw), sha256=sha(raw))
    if a.source_pin:
        m['source_pin'] = a.source_pin
    if a.meta_pin:
        items = list(m.items())
        i = [k for k, _ in items].index('source_pin') + 1
        m = dict(items[:i] + [('metadata_generation_source_pin', a.meta_pin)] + items[i:])
    write(f8 / 'static_asset_manifest.json', dump(m))
else:
    sums = (f8 / 'planned_assets' / 'SHA256SUMS').read_text(encoding='utf-8').splitlines(keepends=True)
    for cid in cases:
        raw = (Path(a.candidate) / 'candidate_assets' / cid / 'deck_meta.json').read_bytes()
        write(f8 / 'planned_assets' / cid / 'deck_meta.json', raw)
        hit = [i for i, line in enumerate(sums) if line.rstrip('\n').endswith('  %s/deck_meta.json' % cid)]
        assert len(hit) == 1
        sums[hit[0]] = '%s  %s/deck_meta.json\n' % (sha(raw), cid)
    write(f8 / 'planned_assets' / 'SHA256SUMS', ''.join(sums).encode('utf-8'))

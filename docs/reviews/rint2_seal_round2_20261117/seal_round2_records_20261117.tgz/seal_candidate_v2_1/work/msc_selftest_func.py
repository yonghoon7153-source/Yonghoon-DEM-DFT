def selftest(chain):
    """자기 시험 — ①–③ = v2 의 17 개 그대로 · ④ = v2.1 (11-17 · 내부 반박 리뷰 P2-2 · P3-4 · P3-12 반례 · 고치기 전 판에서 먼저 돌려 빠뜨림을 보았다).
    고정물 = 짧은 가짜 원본 · 조각 · 계획 (시험 값 · 등록 숫자 아님) · S0 고정물 = 두 계획 대조 칸만 (사슬 상수 L_par · r_port · r_f · tol = 계획 tol_ff)."""
    global FRAG_SETS, ALLOWED_PH
    td = tempfile.mkdtemp(prefix='msc_selftest_')
    ok, bad = 0, []
    saved_g = {k: globals().get(k) for k in ('FRAG_SETS', 'ALLOWED_PH')}

    def chk(name, cond):
        nonlocal ok
        if cond:
            ok += 1
        else:
            bad.append(name)

    try:
        R = load_chain(chain)
        pin = '\n'.join(['# 등록 R 초안 — 시험', '', '| 문턱 | 식 | 숫자 |', '|---|---|---|', '| u (위치 불확도) | 식 | ⬜ |',
                         '| 계획 해시 | 계획 | ⬜ |', '| S0 계획 해시 | S0 | ⬜ |', '',
                         '- **(10-28 · 묶음 C1a) 계획 숫자 블록 = 이 줄 바로 아래 (봉인 커밋 때)** 자리', '', '## 10. 명령', '- 끝 줄', '']) + ''
        cmdpin = '\n'.join(['# 명령', '', '```bash', '# 머리', 'python3 x.py --a 1', '```', '', '## 4. 쟁점', '']) + ''
        plan = {'calib_rj_ratio_max': 'none', 'exec_policy': {'adoption': 'first_not_pre_result_v1', 'allowed_machines': ['kgy'],
                                                              'attempt_dir': 'attempt_<n>', 'env_unit': {'numpy': '1.24.4', 'python_minor': '3.8',
                                                                                                         'scipy': '1.10.1'},
                                                              'max_attempts': 8, 'max_hours': 168, 'retry_rule': 'pre_result_only_v1',
                                                              'same_config': 'plan_code_bed_env_v1'},
                'len_law': 'len_scaled_v0', 'max_ladder_points': 12, 'p2_extra': '--step3-maxiter 5000000', 's_min_um': 0.0,
                'schema': 'rint-r-plan-v3', 'step3_rtol': 1e-12, 'sv_cf_scope': 'R_j0', 'sv_cf_threshold': 2.0, 'tol_ff_um': 0.07, 'unreg_law': 'cut'}
        reg_ins = '\n'.join([
            '# 머리', '', '## R-MARK · 표지', '', '@op after 1 # 등록 R 초안 — 시험', '', '====',
            '> 표지 (<봉인 날짜>) 봉인본 `<봉인본>` · 봉인 커밋 = 그 파일을 넣은 커밋', '====', '',
            '## R-00 · 머리', '', '@op after 1 # 등록 R 초안 — 시험', '', '====', '', '> 봉인본 <봉인 날짜> · 원본 그대로 + 조각', '====', '',
            '## R-01 · u', '', '@op last 5 | u (위치 불확도) |', '', '====', '~~⬜~~ → **0.07 µm**', '====', '',
            '## R-05 · 계획 해시', '', '@op mid+last 6 | 계획 해시 |', '', '====', ' · 계획 = `docs/data/rint2_r_plan_<봉인 날짜>/ca1_plan.json`', '====',
            '', '====', '`<봉인 계획 sha256>`', '====', '',
            '## R-06 · S0', '', '@op mid+last 7 | S0 계획 해시 |', '', '====', ' · S0', '====', '', '====', '`<S0SHA>`', '====', '',
            '## R-07 · 블록', '', '@op after 9 - **(10-28 · 묶음 C1a)', '', '====', '', PH_BLOCK, '', '====', '',
            '## R-10 · 절', '', '@op after 11 ## 10. 명령', '', '====', '', '```sh', 'python3 ~/dem-ca1/scripts/rint_r_chain.py --registration ~/dem-ca1/<봉인본>',
            '```', '====', ''])
        cmd_ins = '\n'.join(['# 머리', '', '## K-01 · 주석', '', '@op after 4 # 머리', '', '====', '# ★ 봉인 <봉인 날짜> · <봉인 가지>', '====', '',
                             '## K-03 · 절', '', '@op before 8 ## 4. 쟁점', '', '====', '## 3-1b. 실제 줄 <봉인 날짜>', '', '```sh', 'echo <봉인 커밋>',
                             '```', '', '====', ''])
        # ④ 고정물 (v2.1): 조각 이름 집합 · 남은 자리표 허용 목록 = 이 고정물의 것
        FRAG_SETS = (frozenset({'R-MARK', 'R-00', 'R-01', 'R-05', 'R-06', 'R-07', 'R-10'}), frozenset({'K-01', 'K-03'}))
        ALLOWED_PH = frozenset({'<봉인 가지>', '<봉인 커밋>'})
        p = {}
        for k, t in (('reg', pin), ('cmd', cmdpin)):
            p[k] = os.path.join(td, k + '.md')
            open(p[k], 'w', encoding='utf-8').write(t)

        def wplan(name, obj, text=None):
            q = os.path.join(td, name)
            open(q, 'w', encoding='ascii').write(text if text is not None else json.dumps(obj, indent=1, sort_keys=True))
            return q
        p['plan'] = wplan('plan.json', plan)
        p['s0'] = os.path.join(td, 's0.json')
        s0obj = {'values_um': {'L_par': R.L_PAR_UM, 'r_f': R.VGCF_D_UM / 2.0, 'r_port': R.R_PORT_UM, 'tol_P': 0.07, 'tol_ff': 0.07, 'tol_sj': 0.07}}
        open(p['s0'], 'w', encoding='ascii').write(json.dumps(s0obj, sort_keys=True))
        s0sha = sha(open(p['s0'], 'rb').read())

        def args(reg_text=reg_ins, cmd_text=cmd_ins, date='20261120', branch=None, tag='a', plan_path=None, s0_path=None, final=False):
            ri, ci = os.path.join(td, f'ri_{tag}.md'), os.path.join(td, f'ci_{tag}.md')
            s0p = s0_path or p['s0']
            open(ri, 'w', encoding='utf-8').write(reg_text.replace('<S0SHA>', sha(open(s0p, 'rb').read())))
            open(ci, 'w', encoding='utf-8').write(cmd_text)
            return argparse.Namespace(pin_reg=p['reg'], pin_cmd=p['cmd'], reg_insert=ri, cmd_insert=ci, plan=plan_path or p['plan'], s0_plan=s0p,
                                      chain=chain, seal_date=date, seal_branch=branch, out=None, final=final)

        def fails(a, why, expect=None):
            try:
                build(a, expect=expect)
            except Fail as e:
                return why in str(e)
            return False
        outs1, man1 = build(args(tag='a'), expect=None)
        outs2, man2 = build(args(tag='b'), expect=None)
        sealed = outs1['docs/reviews/rint2_seal_20261120/registration_R_sealed.md'].decode('utf-8')
        marked = outs1[REG_REL].decode('utf-8')
        cmdo = outs1[CMD_REL].decode('utf-8')
        chk('① 같은 입력 = 같은 출력 바이트', outs1 == outs2)
        chk('① 사슬 대조 전부 참', all(man1['checks'].values()) and len(man1['checks']) == 11)
        chk('② 봉인본 블록 = plan-doc 출력 · 해시 = 계획 sha256', sha(open(p['plan'], 'rb').read()) in sealed and sealed.count('rint-r-plan-doc:begin') == 1)
        chk('② 원본 자리 = 원본 + 한 줄 · 해시 칸 ⬜', marked.split('\n')[1].startswith('> 표지 (20261120)') and len(marked.split('\n')) == len(pin.split('\n')) + 1
            and '| 계획 해시 | 계획 | ⬜ |' in marked)
        chk('② 명령 문서 bash 주석만 · 남은 자리표 = <봉인 가지> · <봉인 커밋>', '# ★ 봉인 20261120 · <봉인 가지>' in cmdo
            and man1['remaining_placeholders_in_fragments'] == ['<봉인 가지>', '<봉인 커밋>'])
        chk('② --seal-branch 를 주면 채운다', '# ★ 봉인 20261120 · seal-x' in build(args(branch='seal-x', tag='c'), expect=None)[0][CMD_REL].decode('utf-8'))
        chk('③ 핀 sha256 다르면 거부', fails(args(tag='d'), '≠ 핀 blob', expect={'reg': '0' * 64}))
        chk('③ 머리 글자 줄 둘이면 거부', fails(args(reg_text=reg_ins.replace('@op last 5 | u (위치 불확도) |', '@op last 5 |'), tag='e'), '개 (하나여야)'))
        chk('③ 줄 번호 다르면 거부', fails(args(reg_text=reg_ins.replace('@op last 5 |', '@op last 4 |'), tag='f'), '≠ 적은 4 줄'))
        chk('③ 조각에 블록 표지 글자 = 거부', fails(args(reg_text=reg_ins.replace('~~⬜~~ → **0.07 µm**', '~~⬜~~ <!-- rint-r-plan-doc:end -->'), tag='g'), '블록 표지'))
        chk('③ 조각이 해시 줄 머리 줄을 넣으면 거부', fails(args(reg_text=reg_ins.replace('> 봉인본 <봉인 날짜> · 원본 그대로 + 조각',
                                                                                       '| 계획 해시 | 둘째 | ⬜ |'), tag='h'), '해시 줄 머리'))
        chk('③ 표지 두 줄이면 거부', fails(args(reg_text=reg_ins.replace('봉인 커밋 = 그 파일을 넣은 커밋', '봉인 커밋\n> 둘째'), tag='i'), 'R-MARK = 한 줄'))
        chk('③ 표지가 봉인본을 안 가리키면 거부', fails(args(reg_text=reg_ins.replace('봉인본 `<봉인본>` · ', ''), tag='j'), '가리키지 않는다'))
        chk('③ 날짜 꼴 거부', fails(args(date='2026-11-20', tag='k'), '--seal-date'))
        chk('③ 명령 문서 bash 인자를 바꾸면 거부', fails(args(cmd_text=cmd_ins.replace('# ★ 봉인 <봉인 날짜> · <봉인 가지>', 'python3 y.py --b 2'), tag='l'),
                                                    'bash 블록'))
        chk('③ 블록 자리표 둘이면 거부', fails(args(reg_text=reg_ins.replace('~~⬜~~ → **0.07 µm**', '~~⬜~~ ' + PH_BLOCK), tag='m'), 'R-07 에만'))
        chk('③ S0 해시 칸이 S0 계획과 다르면 거부', fails(args(reg_text=reg_ins.replace('`<S0SHA>`', '`' + '1' * 64 + '`'), tag='n'), '사슬 함수'))
        # ④ v2.1 반례 (리뷰 P2-2 · P3-4 · P3-12) — 계획 꼴 (Q3) · 두 계획 대조 · --final · 조각 꼴 · 자리표 · 날짜 · 가지 · 출력 이름 무관
        raw_plan = open(p['plan'], encoding='ascii').read()
        chk('④ A22 계획 끝 줄바꿈 = 거부 (Q3 꼴)', fails(args(plan_path=wplan('p22.json', None, raw_plan + '\n'), tag='o'), 'Q3 꼴'))
        chk('④ A23 계획 indent 2 = 거부 (Q3 꼴)', fails(args(plan_path=wplan('p23.json', None, json.dumps(plan, indent=2, sort_keys=True)), tag='p'), 'Q3 꼴'))
        chk('④ 계획 칸 차례 (sort_keys 아님) = 거부 (Q3 꼴)', fails(args(plan_path=wplan('p23b.json', None, json.dumps(dict(sorted(plan.items(), reverse=True)),
                                                                                                            indent=1)), tag='p2'), 'Q3 꼴'))
        chk('④ A24 계획 tol_ff ≠ S0 = 거부 (두 계획 대조)', fails(args(plan_path=wplan('p24.json', dict(plan, tol_ff_um=0.0738)), tag='q'), '두 계획 대조'))
        chk('④ A25 계획 len_law 틀림 = 거부 (두 계획 대조)', fails(args(plan_path=wplan('p25.json', dict(plan, len_law='len_scaled_v9')), tag='r'), '두 계획 대조'))
        s0bad = os.path.join(td, 's0_bad.json')
        open(s0bad, 'w', encoding='ascii').write(json.dumps({'values_um': dict(s0obj['values_um'], tol_P=0.08)}, sort_keys=True))
        chk('④ S0 tol_P ≠ tol_ff = 거부 (두 계획 대조)', fails(args(s0_path=s0bad, tag='s'), '두 계획 대조'))
        null4 = dict(plan, max_ladder_points=None, calib_rj_ratio_max=None, sv_cf_threshold=None, sv_cf_scope=None)
        pn = wplan('pnull.json', null4)
        chk('④ --final + 넷 null = 거부 (PLAN_NUMBER_UNREGISTERED)', fails(args(plan_path=pn, tag='t', final=True), 'PLAN_NUMBER_UNREGISTERED'))
        o_c, m_c = build(args(plan_path=pn, tag='u'), expect=None)
        chk('④ --final 없이 넷 null = 만든다 · manifest = 후보 · 봉인 값 아님', '후보 · 봉인 값 아님' in str(m_c.get('seal_status')))
        o_f, m_f = build(args(tag='v', final=True), expect=None)
        chk('④ --final + 넷 채움 = 만든다 · manifest = final', str(m_f.get('seal_status', '')).startswith('final'))
        chk('④ 같은 입력 바이트 · 다른 파일 이름 = manifest 도 같은 바이트 (입력 이름 안 넣음)',
            json.dumps(man1, sort_keys=True, ensure_ascii=False) == json.dumps(man2, sort_keys=True, ensure_ascii=False))
        chk('④ A02 빈 after 블록 = 거부', fails(args(reg_text=reg_ins.replace('====\n\n> 봉인본 <봉인 날짜> · 원본 그대로 + 조각\n====', '====\n===='), tag='w'), '빈 블록'))
        chk('④ A10 끝 칸 글에 줄바꿈 + 표 줄 = 거부', fails(args(reg_text=reg_ins.replace('~~⬜~~ → **0.07 µm**', '~~⬜~~ → **0.07 µm**\n| 계획 해시X | 넣음 | 줄 |'),
                                                            tag='x'), '표 칸 글'))
        chk('④ A11 끝 칸 글에 | = 거부', fails(args(reg_text=reg_ins.replace('~~⬜~~ → **0.07 µm**', '~~⬜~~ → **0.07 µm** | 덧 칸'), tag='y'), '표 칸 글'))
        chk('④ A15 조각 하나 빠짐 (R-10) = 거부', fails(args(reg_text=reg_ins.split('## R-10 · 절')[0], tag='z'), '조각 이름'))
        chk('④ 모르는 조각 이름 (R-16) = 거부', fails(args(reg_text=reg_ins + '\n## R-16 · 덧\n\n@op after 12 - 끝 줄\n\n====\n- 덧 줄\n====\n', tag='z2'),
                                                 '조각 이름'))
        chk('④ A17 모르는 자리표 <봉인본X> = 거부', fails(args(reg_text=reg_ins.replace('--registration ~/dem-ca1/<봉인본>', '--registration ~/dem-ca1/<봉인본X>'),
                                                          tag='z3'), '자리표'))
        chk('④ A30 날짜 20261320 = 거부', fails(args(date='20261320', tag='z4'), '--seal-date'))
        chk('④ A34 가지 seal.lock = 거부', fails(args(branch='seal.lock', tag='z5'), '--seal-branch'))
    finally:
        for k, v in saved_g.items():
            globals()[k] = v
        shutil.rmtree(td, ignore_errors=True)
    print(f'make_sealed_copy selftest: {ok}/{ok + len(bad)} PASS' + (f'   FAILED: {bad}' if bad else ''))
    return 0 if not bad else 1

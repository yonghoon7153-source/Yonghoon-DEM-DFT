# 검토 전용 전달 — lhs-pressure-inventory (전체 게이트 HOLD)

- 가지: `codex/lhs-v13-1104`
- 리뷰 핀: `c8a55c8ae1021ec80634ee8c6533deeebc67ce61` (루트 PIN.txt)
- 요청서: `docs/reviews/lhs_pressure_inventory_20261104/review_request.md`
- 범위: 고정 ibb184/WSL30 로그의 존재·판정 줄 수·재개 흔적을 값 비출력·무쓰기로 읽는 명령의 준비·검토만. 실제 호스트 실행, A/C 규칙, 복사·전송·압력 기록·등록·단계A·배포 GO 제외.
- 발송: 1저자. 작성 측의 자체 종결 판정은 없다.

SNAPSHOT_MANIFEST.json에 적힌 파일은 해당 핀의 Git blob 그대로다. PIN.txt, SNAPSHOT_MANIFEST.json, 이 전달 설명, PACKAGE_SHA256SUMS는 포장 메타데이터다. DELIVERY_VALIDATION/은 구현 측 실행 증거이며 Git blob 목록에 포함하지 않는다. 선택 파일 ZIP이며 완전한 Git checkout이나 실행 환경은 아니다.

실제 DEM/WSL/ibb 실행 권한은 이 묶음에 없다.

전체 게이트 상태는 HOLD다. 초기 LHS rc=1, mixer rc=1; LHS 격리 시도는 E13d 실패를 보존한 뒤 범위 결정으로 중단했다(rc=143). mixer 격리 재실행은 수행하지 않았다. 최소 인계 검사와 직접 시험의 통과를 전체 게이트 GO로 승격하지 않는다. 검토용 게시이며 Claude 통합·실행 GO가 아니다. 최종 핀은 인계 검사 snapshot과 결합하며, 중단된 candidate와 최종 tree의 동일성을 주장하지 않는다.

공용 게이트의 결과와 직접 시험을 합산하지 않는다. 초기 실패·소스 진화·감독 복구·격리 중단 기록을 원문대로 동봉했다. LHS 재고 명령의 직접20시험은 공용 게이트의 새 그룹이 아니며 별도 증거다.

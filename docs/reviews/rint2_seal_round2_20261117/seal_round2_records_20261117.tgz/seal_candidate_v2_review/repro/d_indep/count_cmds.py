"""독립 대조 (argparse 없이 · 글자만): 두 문서의 모든 울타리 블록에서 사슬 · S0 부름 (python 어떤 꼴이든) 을 찾아
--registration / --r-doc 값을 센다.  울타리 종류별로 따로 센다."""
import re, sys
SEAL = 'docs/reviews/rint2_seal_20261120/registration_R_sealed.md'
for path in sys.argv[1:]:
    text = open(path, encoding='utf-8').read().split('\n')
    fence, buf, start = None, '', 0
    stats = {}
    for i, ln in enumerate(text, 1):
        s = ln.strip()
        if s.startswith('```'):
            fence = None if fence else (s[3:] or 'plain')
            buf = ''
            continue
        if fence is None:
            continue
        if not buf and (not s or s.startswith('#')):
            continue
        if not buf:
            start = i
        cont = s.endswith('\\')
        buf += ' ' + (s[:-1] if cont else s)
        if cont:
            continue
        cmd, buf = buf, ''
        for tool in ('rint_r_chain.py', 'ca_s0_census.py'):
            for seg in re.split(r'&&|\|\||;|\|', cmd):
                if tool in seg and re.search(r'python', seg) and '-c ' not in seg:
                    want = '--registration' if tool.startswith('rint') else '--r-doc'
                    m = re.findall(want + r'[ =](\S+)', seg)
                    key = (fence, tool, tuple(m))
                    stats.setdefault(key, []).append(start)
    print('#', path.split('/')[-1])
    for (fence, tool, vals), lns in sorted(stats.items()):
        print(f'  fence={fence:6s} {tool:16s} n={len(lns):2d} {"--registration" if tool.startswith("rint") else "--r-doc"}={list(vals) or "없음"} lines={lns[:20]}')

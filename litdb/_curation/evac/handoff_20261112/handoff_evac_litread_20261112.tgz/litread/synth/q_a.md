# 질문 a — 배치별 근거 묶음 (원문 줄 그대로 · 파일 41 개)

### [batch_01] a. 순수 SE (LPSCl · 황화물) 의 압력별 기공 곡선 · 진밀도 · 질량 기준 · 누른 채 / 뺀 뒤

이 배치에 **실험 곡선은 없음**. 닿는 것은 아래 넷뿐.

- [a] bardenhagen2000_mpm_granular_multibody_frictional_contact | 곡선 없음 — 카드가 우리 쪽 보정 표적만 적음: 실험실 표준 기공률 10–13 % · 진밀도 1.64 g/cm³ · 질량 기준 | §8-3 (L320) · §10 행동 6 (L361) | 카드 표기 "1저자 11-09" · 그 밖 표지 없음 | 논문 값 아님 (우리 쪽 기록) · 압력 · 누른 채 / 뺀 뒤 여부는 카드에 없음
- [a] klar2016_dp_sand_animation | 실험 곡선 없음 — 카드가 우리 계산 기록만 인용: 입자를 푸는 순수 SE MPM (캡 없음 · E 1.53 GPa) 300 MPa → 11 % · 캡을 넣으면 0.8 % · E 24 GPa + 캡은 100 MPa → 26–35 %; 균질화 캡 모델 (입자를 풀지 않음) 100 / 300 / 600 MPa → 13.9 / 10.0 / 8.3 % (φ0 = 0.5 · φ_min = 0.03 · b = 2.5) | §7-(1) (L219–221 · L227–229) | 표지 없음 (카드가 든 출처 = `docs/data/mpm_dpc_heckel_sweep.csv` · `scripts/cap_compaction_heckel.py`) | 실험값 아님 (우리 모델 출력) · 진밀도 · 질량 기준 · 누른 채 / 뺀 뒤는 카드에 없음 · 카드가 붙인 "Minnmann 300→10 앵커" 는 아래 카드 문제 1 번
- [a] klar2016_dp_sand_animation | LPSCl 밀도 참고 한 줄 "LPSCl SE bulk ≈ 1640–2000" (kg/m³ · 모래 밀도 행의 비고) | §3 표 (L46) | 표지 없음 ("참고") | 출처 · 측정 조건 카드에 없음
- [a] choi2024_digital_twin_review_echem · nam2026_dpe_microstructure_review · lim2025_virtual_calendering_framework | 순수 SE 곡선 없음 — 세 카드 모두 "LPSCl 기공 앵커는 다른 카드 담당" 이라고만 적음 | choi L18–19 · nam L28–29 · lim L29 | — | 값 없음


### [batch_02] a. 순수 SE (LPSCl · 황화물) 의 압력별 기공 곡선 · 진밀도 · 질량 기준 · 누른 채 / 뺀 뒤

이 배치에 **실험 곡선 없음**. 닿는 것은 아래 넷 (전부 우리 쪽 기록 또는 대입값).

- [a] nezamabadi2022_mpm_cd_plastic_particle_compaction | 곡선 없음 — 카드가 우리 쪽 보정 표적만 적음: "보정은 여전히 실험 (기공 10–13 % @ 진밀도 1.64 g/cm³) 에만" | §9 행동 1 (L436) · §11 (L494) | 표지 없음 (카드 표기 "제안 — 1저자 비준 전") | 논문 값 아님 (우리 쪽 기록) · 압력 · 질량 기준 · 누른 채 / 뺀 뒤 여부는 카드에 없음
- [a] pycompact2025_dem_mpfem_workflow | 곡선 없음 — 우리 쪽 값만: 순수 SE 상대밀도 90 % (기공 10 %) @ 300 MPa; 그리고 "우리 실험 앵커 (Minnmann pure-SE 10 %, Cronau overlap) 가 가압 중 측정인지 해압 후 측정인지 — 문헌 재확인 필요 (미해결)" | §10 표 (L456–457) · §15.5 (L694–696) · §20 P-5 (L799) | 표지 없음 ("열린 질문" · "미해결 질문") | 논문 값 아님 · 진밀도 · 질량 기준은 카드에 없음 · 이 앵커의 지위는 아래 카드 문제 A-1
- [a] alabdali2023_cgmd_wet_manufacturing_ssb_cathode | 곡선 없음 — 조성 환산에 LPSCl ≈ 1.64 g/cm³ (NMC622 ≈ 4.7) 를 대입: "밀도는 논문에 없다 (우리가 문헌값 대입)" | §3-1 마지막 행 (L130) | derived(ours) | 그 밀도의 출처 서지는 카드에 없음 · 압력별 기공 아님 · 같은 카드가 "pure-SE 10 % @ 300 MPa = Minnmann 앵커" 를 우리 쪽 값으로 적음 (§A-1 L435 · §A-6 L492 · 표지 없음)
- [a] stomakhin2013_mpm_snow_elastoplastic | 곡선 없음 — 참고 한 줄 "LPSCl SE bulk ≈ 1640–2000 kg/m³" | §3 표 ρ₀ 행 비고 (L40) | 표지 없음 | 출처 없음 · 범위값 · 눈 논문의 값 아님
- 참고 (SE 아님 · LPSCl 로 옮기지 않음): pycompact2025 의 Fe–Si–Al–P 3D 기공–압력 하중 가지 = φ₀ ≈ 41.5 (Coarse) / 43 % (Fine) → 500 MPa ≈ 33 / 31 → 1000 ≈ 22 / 20 → 1500 ≈ 12 / 10.5 → 2000 ≈ 4.5 / 3.5 % (§9.5 L412–413 · Fig 4b · digitized · 누른 채) · nezamabadi2022 의 2D 면적 분율 Φ–σ (§3.3 L132–134 · digitized).


### [batch_03] a. 순수 SE (LPSCl · 황화물) 의 압력별 기공 곡선 · 진밀도 · 질량 기준 · 누른 채 / 뺀 뒤

LPSCl · 황화물의 **실험 곡선은 이 배치에 없음**. 닿는 것은 아래뿐.

- [a] arzt1982_particle_coordination_densification_spheres | 실험 곡선 아님 — 해석 기준선: Arzt 등방 냉간 압밀 평형 (식 9 + 19–21 · 가공경화 없음 · 단분산) 에 H = 0.85 GPa 를 넣으면 p = 0.1 / 0.2 / 0.3 / 0.6 GPa 에서 D_eq = 0.723 / 0.786 / 0.836 / 0.938 (ε 27.7 / 21.4 / 16.4 / 6.2 %) | §8 ⑥ (L278) · §L-3 표 (L319 — 300 MPa → 0.836 · 그때 총 접촉면적 = 0.42 × 4πR²) | "우리 재계산" | 논문 값 아님 (소재 무관 이론에 "지시문 기준 우리 코드 값" H 를 대입 · L268 · L436) · 단분산 · 등방 · 재배열 없음 · 밀도 규약 D = 1 − ε_sphere (식 2 · L124 · L259) · 진밀도 · 질량 기준 · 누른 채 / 뺀 뒤 해당 없음 · 카드 스스로 "해석 기준선일 뿐"
- [a] cardenasbarrantes2020_rigid_deformable_mixture_compaction_nscd | 순수 SE 아님 — 순수 무른 원판 (κ = 1) 의 2D 곡선: 마지막 자료점 φ ≈ 0.97 (μ 0 · P/E ≈ 0.25) · Secondi / Zhang 적합 (A1, φmax) ≃ (0.05E, 0.97) [μs 0] · (0.079E, 0.96) [μs 0.8] | §3-2 (L117–118 · L130) · 그림 3 | digitized (자료점) · stated (적합값) | 초탄성 neo-Hookean 원판 · 2D · 등방 · P/E 무차원 (E 절대값 미기재) · 하중 중 값 · φ = Vp/V (L216 — Vp 갱신 여부 [미확인] L390)
- [a] cardenasbarrantes2020_rigid_deformable_mixture_compaction_nscd | 카드가 적은 우리 쪽 기준: 보정 표적 "랩 기공률 10–13 % · 진밀도 1.64 g/cm³ 질량 기준 — 1저자 11-09 결정" · 우리 DEM Heckel (순수 SE · E 1.35 · 4 압력 · R² 0.965 · P_y 138 MPa) 은 φmax = 1 고정판 | §8-7 (L478–479) · §8-4 (L450–451) | 표지 없음 (우리 쪽 기록 · CLAUDE.md 인용) | 논문 값 아님 · 압력별 실험 곡선 · 누른 채 / 뺀 뒤 여부는 카드에 없음
- [a] cardenasbarrantes2022_soft_hard_grains_compaction_experiment_dic | 순수 SE 아님 — 순수 무른 계 (κ = 1 · 실리콘) φmax 0.97 ("close to 1") · 그림 2b 끝점 ≈ (27 kPa, φ − φJ 0.083) | §3-2 (L106) · §3-3 (L120) | stated (φmax) · digitized (끝점) | 실리콘 초탄성 · 2D · kPa · 누른 채 (1 min 이완 뒤 스캔 L89) · φ 는 영상의 입자 경계에서 직접 (영상 기반 — 카드가 우리 질량 기반 기공률과 대비 · L161 · L267)


### [batch_04] a. 순수 SE (LPSCl · 황화물) 의 압력별 기공 곡선 · 진밀도 · 질량 기준 · 누른 채 / 뺀 뒤

이 배치에 **실험 곡선 없음** (순수 SE 를 눌러 기공을 잰 카드가 없다). 닿는 것만 적는다.

- [a] coetzee2017_dem_calibration_review | 곡선 없음 — 리뷰에 Heckel 0 회 · porosity 9 회는 전부 전단 / 삼축의 dilatancy 대리 · 응용 응력의 수치 명시 없음. 카드가 우리 쪽 보정 표적만 적음: "실험 앵커는 Minnmann pure-SE ~10 %" · "target: pure-SE porosity 10 % @ 300 MPa" | §3 범위 상자 (L48 · L51) · §5-Q7 (L492–495) · §10.1 (L761–764) · §10.3-W6 (L839–841) | 낱말 세기 = 표지 없음 (카드 판정) · 표적 = 표지 없음 (우리 쪽 기록) | 논문 값 아님 · 진밀도 · 질량 기준 · 누른 채 / 뺀 뒤는 카드에 없음 · Minnmann 표기는 카드 문제 C-1
- [a] giannis2021_stress_based_multicontact_dem | 곡선 없음 — "porosity·상대밀도는 논문 어디에도 없다". 우리 쪽 참고 열에 LPSCl 밀도 1640 kg/m³ (Bazzoun) · 보정 앵커 "Minnmann pure-SE porosity ~10 % @300 MPa" | §3.3 (L94) · §3.1 표 (L53) · §7-5 표 (L420) | 표지 없음 ("(참고)" · 우리 쪽 기록) | 그 밀도가 진밀도인지 · 측정 조건은 카드에 없음
- [a] electromechanical_contact_model_particulate_systems | 곡선 없음 — "porosity/σ_ionic/Heckel/coverage 류 battery 데이터가 없다". 우리 쪽 한 줄 "MPM pure-SE 10%" | §3 (L42–43) · §C(6) (L283–284) | 표지 없음 (우리 쪽 기록) | 논문 값 아님 · 압력 · 기공 정의 없음
- [a] coetzee2017_dem_calibration_review · deng2021_mechanical_surface_energy_tester_bond_number | 밀도 재는 법만 (SE 값 없음): 리뷰의 직접 측정 목록 "밀도 = 피크노미터 (수중)" · Deng 의 고체 밀도 = 질소 비중병 | coetzee 카드 §6 의 "§6 Direct measuring" 요약 (L649 · p.133–135) · deng §3-1 (L64 · p.49) | coetzee = 표지 없음 (카드 요약) · deng = [인쇄 p.49] | 광물 · 곡물 / 의약 · 광물 분말 — LPSCl 아님
- [a] dmt1975_adhesion_contact_deformation | 압밀 · 기공 자료 없음 ("n/a") | §3 (L30–31 · L46) | — | —


### [batch_05] a. 순수 SE (LPSCl · 황화물) 의 압력별 기공 곡선 · 진밀도 · 질량 기준 · 누른 채 / 뺀 뒤

LPSCl 의 곡선은 **이 배치에 없음**. 황화물 순수 SE 곡선은 heck (β-Li₃PS₄) 한 장.

- [a] heck2026_densification_sulfide_se_binder_scalable | β-Li₃PS₄ (NEI · d50 ≈ 7 µm · 다공 입자) 분말의 금형 안 (in-die) 밀도 (g/cm³) vs 적층압 (GPa): 0.01 → 0.81 · 0.05 → ≈ 1.04 · 0.1 → ≈ 1.20 · 0.2 → 1.41 · 0.3 → 1.55 · 0.5 → 1.74 · 0.8 → 1.88 · 1.0 → 1.94 · 1.5 → 1.98 (감압 시작 2.01); 감압 ↓0.5 → 1.95 · ↓0.3 → 1.93 · ↓0.2 → 1.92 · ↓0.1 → 1.91 · ↓0.01 → 1.88. **누른 채** (빈 셀 기준 모터 위치를 압력 단계마다 뺀 in situ 두께) · 단계마다 15 분 휴지 · 25 °C · 분말 ≈ 100 mg 이하 · WC 피스톤 Ø6 mm | §3-7 표 (L130–132) · Fig 10 (p.13) · 조건 §3-1 (L61) | 밀도 = [판독, ±0.02 g/cm³] · 조건 = [인쇄] p.4 | LPSCl 아님 (β-LPS · 압축 소결) · 최대 1.5 GPa · 0.8 GPa 이상에서 진밀도 초과 (아래)
- [a] heck2026_densification_sulfide_se_binder_scalable | 진밀도: LPS 1.88 g/cm³ (ref 34 — **유리질** Li₂S–P₂S₅) · HNBR 0.96 · 혼합 ρ_M 1.83 (3 wt%) · 1.81 (4.3 wt%) (균일 · 무반응 가정); 카드 재계산 β-Li₃PS₄ 결정밀도 1.867 g/cm³ (SI Table S2 격자 · 1.88 과 0.7 % 차). 밀도는 두께 · 질량에서 구함 (**질량 기준**) | §3-1 (L54–55) · p.3 · p.13 · §6 (L220) | [인쇄] · 결정밀도 = [우리 산술] / [재계산] | 진밀도 출처가 유리질 LPS (카드 §10-2 L279) · 원문 FTIR 모사는 1.85 사용
- [a] heck2026_densification_sulfide_se_binder_scalable | 위 판독의 상대밀도 D = ρ/1.88: 0.3 GPa 0.823 (ε ≈ 18 %) · 0.8 GPa 1.00 · 1.5 GPa 1.05–1.07 (> 1) · 감압 0.01 GPa 1.00 (ε ≈ 0 %) | §3-7 (L141) · §0 표 ② (L25) | [우리 산술 — 판독값] | 절대 D · ε 은 ±3 %p 체계 불확도와 함께 (카드 §10-1 L278) · 카드: "다른 재료라 CL-94 후보 아님"
- [a] heck2026_densification_sulfide_se_binder_scalable | 곡선 맞춤: Meyer 지수식 ρ = ρ_max − (ρ_max − ρ₀)·exp(−P/γ_c) (in-die · Table S7) 분말 ρ₀ 0.84 ± 0.02 · ρ_c,max 1.99 ± 0.01 g/cm³ · γ_c 0.32 ± 0.02 GPa (3 wt% 0.99 / 1.68 / 0.42 · 4.3 wt% 1.09 / 1.69 / 0.45). 카드의 Heckel 재맞춤 (분말 가압 가지 · 0.1–0.5 GPa): K 3.83 GPa⁻¹ · R² 0.998 → P_y ≈ 260 MPa (창에 따라 235–272) | §3-7 (L135–139) · SI p.7–8 · §0 표 ④ (L27) | Meyer = [인쇄] · Heckel = [판독 → 우리 산술] | in-die Heckel 에는 탄성 변형이 섞임 (카드 §4-3 L185)
- [a] heck2026_densification_sulfide_se_binder_scalable | (순수 SE 아님 — 바인더 시트 참고) LPS + 3 wt% HNBR 의 **뺀 뒤** (out-of-die · 다이얼 게이지) 밀도: 308 µm 시트 300 MPa ≈ 1.38–1.40 · 131 µm ≈ 1.15–1.17 · 비압축 ≈ 0.47 g/cm³ → D ≈ 0.76 (ε ≈ 24 %) · 0.63 (ε ≈ 37 %) · 비압축 ε ≈ 74 % (본문 76 ± 4 %); 금형 안 시트 0.3 GPa 1.36 (3 wt%) · 1.39 (4.3 wt%) | §3-6 (L124) · Fig 9b · §3-7 (L133–134) · §3-1 (L58) | [판독, ±0.04] → [우리 산술] · 76 ± 4 % = [인쇄] p.10 | HNBR 바인더 시트 · 2 분 압축 · 40 / 100 °C
- [a] heck2026_densification_sulfide_se_binder_scalable | LPSCl: 밀도 자료 없음 (σ 만). LPSCl 시트 비압축 공극 37 ± 2 % (전작 ref 15); 본문 인용 "순수 LPS 분말 270 MPa 에서 상대밀도 98 %" (ref 34) | §0 표 ② (L25) · §3-1 (L58) · §3-6 (L127) | [인쇄] p.10 · p.12 | 37 % 는 바인더 시트 · 98 % 는 유리질 LPS 문헌값 (카드 §10-2)
- [a] heck2026_densification_sulfide_se_binder_scalable | 이웃 카드에서 옮겨 적은 값: LPSCl 금형 안 공극 lee2025 ≈ 15 % @300 MPa · faka2026 입경별 13–26 % @0.3 GPa → 카드의 묶음 문장 "순수 황화물 SE in-die 300 MPa ≈ 13–26 %" | §7-3 (L248) | "둘 다 판독" (카드 표기) | 원값은 그 두 카드에서 확인할 것
- 그 밖 여섯 장: 순수 SE 기공 곡선 없음.


### [batch_06] a. 순수 SE (LPSCl · 황화물) 의 압력별 기공 곡선 · 진밀도 · 질량 기준 · 누른 채 / 뺀 뒤

이 배치에 **순수 황화물 SE 의 압력별 기공 곡선은 없음**. 닿는 것은 진밀도 값과 한 압력의 값뿐.

- [a] oh2026_bimodal_composite_cathode | 순수 SE 곡선 없음. 진밀도: He 진밀도 S-LPSCl1.5 (Li₅.₅PS₄.₅Cl₁.₅) 1.75 g/cc (Table S6) — 같은 카드의 시뮬 입력 밀도는 1.64 g/cc (Table S14). 기공 정의 = (1 − V_true/V_apparent) × 100 · V_true = He 피크노미터 · V_apparent = 펠릿 높이 (식 6) · 370 MPa 냉간압축 펠릿 | §2.2 (L140–142) · §4.1 (L217) · §4.5 (L366–367) | 표지 없음 | 순수 SE 가 아니라 복합 양극의 측정 · Li₆PS₅Cl 아님 · 누른 채 / 뺀 뒤 · 질량 기준 여부는 카드에 명시 없음
- [a] kim2023_mechanofusion_ncm811_lpscl_core_shell_intimate_contact | 순수 SE 곡선 없음. 껍질 두께 계산 (SI 식 2) 에 쓴 밀도 ρ_LPSCl 1.64 · ρ_NCM 4.8 g/cm³ | §3-3 (L90) · SI p.12 | [인쇄] | 계산 입력값 (측정이라는 말은 카드에 없음)
- [a] kissel2026_mechanofusion_derived_cathode_composite_microstructures_scalable | 황화물 아님 (할라이드 Li₃InCl₆ = LIC). AM 없는 CB–LIC 매트릭스 펠릿 380 MPa · 3 min: 공극률 2.7 % (CB 1 wt%) · 4.0 (2.5) · 4.4 (5) · 23.9 (10) · 28.9 % (15) · 벌크 밀도 2.51 → 1.76 g/cm³. 밀도: LIC 2.59 · CB 1.96 · NCM 진밀도 4.75 g/cm³ | §3-9 (L251–259) · §3-1 (L61–64) | [원자료 FigureS17a] · 밀도는 [인쇄 p.3 · p.15] | 한 압력 (곡선 아님) · 순 LIC (CB 0) 값 없음 · 누른 채 / 뺀 뒤 명시 없음 · 순 원료의 3.45 MPa 공극률은 "측정했다고 썼으나 값 없음" (L470)
- [a] liao2025_interfacial_adhesion_li_plating_carbon_interlayer | Li₆PS₅Cl (MSE Supplies · 평균 10 µm) 펠릿을 200 MPa 로 냉간압착 (green pellet) · 대조군은 "400 MPa 로 미리 치밀화한 SE" — 기공 값 없음 | §3.3 (L87–88) · §4.2 (L122) | 표지 없음 | 기공 · 밀도 숫자 없음


### [batch_07] a. 순수 SE (LPSCl · 황화물) 의 압력별 기공 곡선 · 진밀도 · 질량 기준 · 누른 채 / 뺀 뒤

LPSCl 곡선은 **이 배치에 없음**. 황화물 SE 로는 LPS 의 DEM 곡선 하나.

- [a] so2022_dem_contact_model_assb_compaction_sintering | 순수 황화물 SE = LPS (Li₂S–P₂S₅ · LPSCl 아님) 의 DEM 상대밀도–몰드압 곡선: mono (SE 1,846 입자 · c_area 2) ~0.72 @100 MPa → ~0.9 @400 → ~1.0 @600+ MPa · 곡선은 ~700 MPa 까지 · 꺾이는 곳 ~150–200 MPa 부근 | §3 표 (L44 · L49) · §4.9 (L184) · Fig 8 | digitized (추세만 · L270) | LPS · 3D 구 DEM · 같은 그림의 Sakuda 실험점 수치는 카드에 없음 ("~200 MPa 위 잘 일치 · 저압 과치밀" 만) · 진밀도 값 · 질량 기준 여부 · 누른 채 / 뺀 뒤 여부 모두 카드에 없음 (press 프로파일은 200 MPa 까지 올린 뒤 release · L184)
- [a] so2022_dem_contact_model_assb_compaction_sintering | 같은 계산의 상자 치수: mono 14.8 (@50 MPa) → 13.8 (@100) → 11.2 µm (@400) · 측방 10 × 10 µm | §3 표 (L47) · Fig 6 행 (L196) | stated | 어느 방향 치수인지 카드에 명시 없음 · 기공으로 환산한 값 없음
- [a] pasha2014_linear_elastoplastic_adhesive_contact · paulick2015_elastic_particle_properties_dem_review · roessler2019_dem_cohesive_aor_cylinder_lift_calibration · schreiner2020_dem_calendering_lib · sharma2023_nmc_single_crystal_anisotropic_nanoindentation | 순수 SE 압력별 기공 곡선 없음 (Pasha 는 "절대 porosity 안 줌" L92 — 일반 1 mm 구의 초기 고체 분율 0.48–0.52 뿐 L93) | — | — | —


### [batch_08] a. 순수 SE (LPSCl · 황화물) 의 압력별 기공 곡선 · 진밀도 · 질량 기준 · 누른 채 / 뺀 뒤

LPSCl 실험 곡선 둘 (상태 · 측정량이 서로 다름) + 할라이드 DEM 곡선 하나.

- [a] thompson2026_high_pressure_densification_lps_lpscl_xrd_tomography | LPSCl (NEI 상용 · 추정 입경 5 µm) 흡수 (거시) 밀도 — 가압 334 / 479 / 822 / 1154 / 1461 / 2554 / 3770 MPa = 1.562 / 1.828 / 1.917 / 1.985 / 2.028 / 2.095 / 2.089 g/cm³ · 감압 3120 / 1931 / 1144 MPa = 2.034 / 1.944 / 1.862 · 66 · 135 MPa 점은 결측 | §3-2 (L64–69) · 논문 Fig 1 (p.2) | [판독] (결측 · "최대 2.10 g/cm³ = 이론밀도의 ≈110–120 %" 문장은 [인쇄] p.2–3) | 준등방 PE 프레스 (일축 다이 아님) · 누른 채 (하중 아래) · 질량 / 두께가 아니라 X-선 흡수 (Beer–Lambert) 밀도 = 공극 + 격자 압축이 섞인 값 (저자 명시 · L57) · 공극 % 는 논문이 안 냄 · ≥ 800 MPa 에서 결정밀도보다 커 "절대값 인용 금지 · 경향만" (L77 · L211) · 반복 수 [미확인]
- [a] thompson2026_high_pressure_densification_lps_lpscl_xrd_tomography | 같은 실험의 결정 (격자) 밀도 — 67 / 136 / 331 / 480 / 822 / 1155 / 1461 / 2552 / 3122 / 3770 MPa = 1.864 / 1.856 / 1.861 / 1.868 / 1.879 / 1.896 / 1.898 / 1.946 / 1.978 / 2.008 g/cm³ · 감압 1931 / 1143 MPa = 1.938 / 1.925 | §3-3 (L72–76) · SI Fig S2 · Note S1 (SI p.2) | [판독] (최대 2.01 은 [인쇄]) | ED-XRD Le Bail = 공극과 무관한 고체 밀도 · 저압 변화가 NPD 격자 변화보다 훨씬 작다는 어긋남을 카드가 표시 (L78)
- [a] thompson2026_high_pressure_densification_lps_lpscl_xrd_tomography | 진밀도: 문헌 이론밀도 LPSCl 1.77–1.88 g/cm³ · LPS 1.85–1.93 (결정 LPS 기준) — 저자가 Sakuda 2013 의 LPS 이론밀도를 의심 | §3-1 (L62) · p.3 | [인쇄] | 논문 자신의 측정이 아니라 문헌 범위
- [a] thompson2026_high_pressure_densification_lps_lpscl_xrd_tomography | 공극 환산 (카드): ≈331–334 MPa 에서 흡수 1.562 ÷ 결정 1.861 → ≈16 % · 문헌 이론밀도로는 12–17 % | §0 ② (L26) · §7-3 (L185) | [우리 산술] | 카드 스스로 "CL-94 후보로 쓰지 않는다" (준등방 · 흡수 밀도 절대 보정 문제 · 다른 분말)
- [a] thompson2026_high_pressure_densification_lps_lpscl_xrd_tomography | LPS (비정질 Li₃PS₄) 흡수 밀도: 67–333 MPa ≈1.14 (변화 없음) → 480 MPa 1.45 → 820 MPa 1.80 → ≈1150 MPa 2.05–2.10 → 3772 MPa 2.24 g/cm³ | §3-2 (L68) · Fig 1 | [판독] | LPS (LPSCl 아님) · 같은 한정
- [a] wang2024_hot_pressed_lpscl_pressure_invariant_conductivity | LPSCl (MSE Supplies 상용) 냉간 (20 °C) 겉보기 밀도 150 / 300 / 450 MPa = 1.325 / 1.418 / 1.50 g/cm³ (450 MPa 의 그림 판독값은 1.505) | §3-2 (L108 · L113–114) · §3-3 (L125) · SI Fig S4b (SI p.S3) · Table 3 (p.4) | 150 · 300 MPa = [판독] ±0.005 · 450 MPa = [인쇄] | 일축 다이 ⌀12.7 mm · 질량 기준 (질량 / (다이 면적 1.27 cm² × 두께) · L79 · L182) · 다이에서 꺼낸 뒤 무하중 마이크로미터 두께 (L80) · 유지 시간 · 시료 수 없음 · 오차 막대 ρ ≈ ±0.02 (정의 [미확인] · L129)
- [a] wang2024_hot_pressed_lpscl_pressure_invariant_conductivity | 그 공극 환산: 1.64 기준 19.2 / 13.5 / 8.5 % · 1.86 기준 28.8 / 23.8 / 19.4 % (150 / 300 / 450 MPa) | §0 #5 (L32) · §3-2 표 (L108 · L113–114) | [우리 산술] | 기준 밀도가 ≈10–12 %p 를 정함 (L229 ②) · 다이 밖이라 회복 포함 (L229 ③)
- [a] wang2024_hot_pressed_lpscl_pressure_invariant_conductivity | 진밀도: 논문은 "theoretical density of LPSCl (1.64 g cm−3)" 한 곳뿐 — 인용 번호 · 산출 근거 없음 · 자기 펠릿 1.66 · 1.69 가 그 값을 넘음 (101 · 103 %); 결정학 밀도 1.860 (a = 9.85910 Å · Z = 4) · 피크노미터 (다른 로트) 1.874 · 이 논문 ref [35] Doux 2020 은 TD 1.860 을 씀 | §0 #1 · #1′ (L27–28) · p.2–4 · p.10 | 1.64 = [인쇄] · 1.860 = [우리 산술] (격자상수는 [정본 카드] ohno2020) · 1.874 · Doux = [정본 카드] | 격자상수 · 피크노미터는 이 논문에 없음 — 다른 카드 값
- [a] wang2024_hot_pressed_lpscl_pressure_invariant_conductivity | 열간 가압 (참고): 150 °C · 150 / 300 / 450 MPa = 1.42 / 1.64 / 1.66 g/cm³ (Table 2) · 450 MPa · 20 / 100 / 150 / 175 / 200 °C = 1.50 / 1.56 / 1.60 / 1.66 / 1.69 (Table 3) · 200 °C · 150 / 300 MPa = 1.569 / 1.625 (S4b) | §3-2 (L93–94 · L115–116) | Table = [인쇄] · S4b = [판독] | 다이 밖 · 가열 뒤 60 °C 아래까지 압력 유지 (L74) · 냉간 가압 계획과 온도 다름
- [a] wang2024_hot_pressed_lpscl_pressure_invariant_conductivity | 교차 실험실: Doux 2020 (NEI LPSCl · ⌀13 mm · 200 mg · 370 MPa 냉간 · 다이 밖) 실측 1.522 g/cm³ → TD 1.860 기준 18 % — Wang 냉간 450 MPa 1.50 과 겉보기 밀도 자체가 맞고 갈리는 것은 기준 밀도뿐 | §3-2 (L119) | [정본 카드 doux2020] · 비교는 [우리 산술] | 이 배치 밖 카드의 값
- [a] varkey2026_multicontact_elastoplastic_dem | 황화물 아님 — 할라이드 Li₃YBrCl₆ 분리막 (SBR + CB 바인더 결합 포함) DEM 기공 45 / 35 / 31 / 25 / 21 % @ 0 / 100 / 200 / 300 / 350 MPa · 두께 계산 188.2 / 170.3 / 152.7 / 143.5 vs 실험 186 / 171 / 154 / 145 µm (100–350 MPa) | §3 표 (L18–19) · Fig 10 · Fig 9 | 기공 = digitized (Fig 10) · 두께 = stated (Fig 9) | 할라이드 (E 10.58 GPa) · 기공 정의 ε = 1 − m/(ρ_eff·t·A) (eq20 · 질량 기준 · L54) · ρ_eff 값과 누른 채 / 뺀 뒤 여부는 카드에 없음 · 실험 쪽은 두께만 (실험 기공 값은 카드에 없음)
- [a] stallard2022 · storakers1997 · thakur2014 · thorntonning1998 · tovar2026 · vanlew2015 | 순수 황화물 SE 의 압력별 기공 곡선 없음 (Thakur 의 석회석 충전 기공 41 % · 압밀 기공 ~35–47 % 는 재료 · 응력 16–96 kPa 가 다름 · L68–70) | — | — | —


### [batch_09] a. 순수 SE (LPSCl · 황화물) 의 압력별 기공 곡선 · 진밀도 · 질량 기준 · 누른 채 / 뺀 뒤

**이 배치에 없음.** 아래는 "없다" 의 근거와, 섞어 쓰면 안 되는 이웃 값이다.

- [a] zunker2025_dem_large_deformation_compaction | 기공 · 상대밀도는 연작 세 편 어디에도 보고되지 않음 (검증 대상이 σ_axial(ε) · σ_radial(ε)) · 확실한 것은 die 부피비 0.6103 (높이 5.85 → 3.57 mm) 뿐 | §3-1 (L58–59 · L67) · §3-4 (L108–116) | stated (높이) · DERIVED (부피비) | Avicel PH102 (미결정 셀룰로오스) — SE 아님 · 카드의 최종 상대밀도 0.90–0.98 (기공 2–10 %) 은 "가정 기반 추정 — 논문 수치 아님, 인용 금지" (L113–115)
- [a] zunker2025_dem_large_deformation_compaction | 재료밀도 1560 kg/m³ (Avicel PH102) | §3-1 (L57) · Table 1 (L75) | stated | 황화물 아님 · 질량 기준 기공 환산은 카드에 없음
- [a] zunker2025_dem_large_deformation_compaction | 카드의 우리 쪽 제안 (논문 내용 아님): 순수 LPSCl 을 이 코드로 100 / 200 / 300 / 600 MPa die 압밀 · 결과 전 판정선 h0 "300 MPa 에서 porosity ≤ 12 %" · h1 "≥ 18 %" · 기공은 ΣV_o/V_box 로 직접 계산 · 1,000 입자 소형으로 먼저 | §12 ① (L393–409) | 표지 없음 (제안) | 판정선의 근거 값 ("Minnmann 10 % @300 MPa" · "Doux LPSCl 실측 floor 근처") 에 출처 위치 · 표지 없음 (카드 문제 16)
- [a] xu2017_nmc532_nanoindentation_modulus_hardness_toughness | 순수 SE 없음. 이웃 값: 상용 NMC532 전극 (NMC 94.2 : CB 3.0 : PVDF 2.8 wt% · 두께 45 ± 6 µm · 로딩 121 g/m²) 밀도 ≈ 2.7 g/cm³ → 기공 ≈ 35–38 % | §3-6 (L153–154) | stated (조성 · 두께 · 로딩) · DERIVED (가정 포함 — 진밀도 NMC 4.75 · CB 2.0 · PVDF 1.78 가정) | 액체계 전극 · SE 없음 · 압력 곡선 아님 · 압연 조건 없음
- [a] zunker2024_mdr_contact_model_partI · zunker2024_bulk_elastic_partII | 기공 · 상대밀도 값 없음 (접촉 한 개의 F · A_C · p̄ 와 입자 부피 V/V_o 만) | Part I §7-3 (L317–319) | — | —


### [batch_10] a. 순수 SE (LPSCl · 황화물) 의 압력별 기공 곡선 · 진밀도 · 질량 기준 · 누른 채 / 뺀 뒤

순수 Li₆PS₅Cl 의 압력별 기공 곡선이 있는 카드 = **2** (faka2026 · lee2025). **둘 다 누른 채 (in-die)** 이고 고체 자체의 탄성 압축을 빼지 않았으며 뺀 뒤 (out-of-die) 밀도는 없다. 2차 인용 1 (lei2026). **LPSCl 진밀도가 카드마다 1.64 와 1.87 g/cm³ 두 무리**로 갈린다 (카드 문제 1).

- [a] faka2026_particle_size_consolidation_strain_lpscl | 누른 채 상대밀도 (%) — 압력 ≈ 0.01 / 0.1 / 0.2 / 0.3 / 0.4 / 0.5 / 0.75 / 1.0 / 1.5 GPa: D50 40 µm 64.9 / 77.8 / 83.2 / 87.1 / 90.2 / 92.6 / 97.2 / 100.0 / — · 20 µm 62.0 / 75.0 / 81.0 / 84.0 / 87.0 / 90.0 / 95.0 / 98.0 / (1.2 GPa 에 100.0) · 11 µm 57.4 / 69.2 / 74.0 / 77.5 / 80.3 / 82.8 / (그 뒤 4 µm 와 겹침) · 4 µm 47.5 / 61.9 / 68.5 / 73.7 / 77.6 / 80.7 / 86.4 / 90.1 / 94.6 → **300 MPa 기공 12.9 / 16.0 / 22.5 / 26.3 %** (40 → 4 µm) | §3-3 (L78–85) · §0 표 ② (L26) · 논문 SI p.S2 Fig S2 · 본문 p.4 | [판독] (캡션 문장과 100 % 도달 압력 1 GPa · 1.2 GPa 는 [인쇄]) | 순수 Li₆PS₅Cl (AMG) · ⌀6 mm · 100 mg · 298 K · 누른 채 (압력을 0.5 % 로 유지) · "3 회 반복 · 표준편차가 표지보다 작다" 는 σ 에 대해서만 서술 (L56 · L201)
- [a] faka2026_particle_size_consolidation_strain_lpscl | 밀도 정의 = 실험 밀도 ÷ 결정밀도 (압밀 시료의 Rietveld) · 실험 밀도 = CompreDrive 모터 이동으로 계산한 피스톤 이동 (시료 100 mg). 결정밀도 **값** 과 장치 순응도 보정은 [미확인]. DEM 입력 밀도는 1.87 g/cm³ | §3-1 (L58–59) · §0 표 ③ (L27) · §3-6 (L110) · 논문 p.10 · SI Table S5 | [인쇄] · [미확인] | "질량 기준" 이라는 낱말은 카드에 없음 (질량 100 mg ÷ 피스톤 이동 부피로 읽힘) · 뺀 뒤 밀도 없음 (L24 · L176)
- [a] faka2026_particle_size_consolidation_strain_lpscl | 고체 자체의 탄성 압축 몫: 격자상수 (Table S3) 로 0.3 GPa 에서 고체 부피 ≈ −1 % → 하중 아래 참 기공은 위 값보다 ≈ +0.8–0.9 %p · 1 GPa 에서 ≈ −3 % → "100 %" 는 참 기공 ≈ 3 % 일 수 있음 | §3-3 (L86) · §10-1 (L234) | [우리 산술] | 장치 순응도는 별도 · 미확인
- [a] lee2025_heckel_argyrodite_powder_densification_nanoindentation | 누른 채 기공 (상용 Li₆PS₅Cl · ε = exp(−y)) — 10 / 50 / 100 / 150 / 200 / 250 / 300 / 350 / 400 / 500 / 600 / 650 MPa = 47 / 35 / 29 / 24 / 21 / 18 / **14.9** / 12.6 / 10.3 / 6.4 / 3.3 / 1.6 %. 같은 분말의 Fig 2a 는 300 MPa 에서 그대로 16.1 % · 볼밀 14.8 %; Fig 2b 300 MPa 합성 Li₆PS₅Cl 17.7 % · Li₆PS₅Br 18.8 % · BH₄ 치환 10.5 / 12.0 % | §3-3 (L84–91) · 논문 Fig 1d · 2a · 2b (p.6343–6344) | [판독] | ⌀8 mm 다이 · 치밀 기준 높이 5 mm · 연속 가압 1 mm/min · 온도 카드에 없음 · 상용 분말 입경 · 반복 수 [미확인]
- [a] lee2025_heckel_argyrodite_powder_densification_nanoindentation | 진밀도: 원문 인쇄 이론밀도 Li₆PS₅Cl **1.64** · Li₆PS₅Br 1.90 g/cm³ ("calculated" · 계산법 미기재) ↔ 카드 계산 결정학 밀도 **1.860** · 2.095 g/cm³ (인쇄값이 12 % · 9 % 낮음). 펠릿 밀도 = 분말 질량 ÷ 펠릿 부피 (L56) 이고 그 질량을 이론밀도 × 면적 × 5 mm 로 정했으므로 상대밀도 = 5 mm / h (이론밀도가 약분됨). 1.64 를 글자 그대로 썼다면 300 MPa 14.9 % 는 결정 기준 ≈ 25 % 가 되는데, 같은 논문의 치밀 펠릿 단면 공극 2.5 % 와 양립하지 않음 → 원문만으로 가를 수 없음 | §3-4 (L94–97) · §7-3 표 (L191–196) · 논문 SI p.3 | 1.64 · 1.90 = [인쇄] · 1.860 · ≈ 25 % = [우리 산술] · 판정 [미확인] | 카드 결론 = 저자 확인 전에는 "앵커가 아니라 후보 (기준 미확인)" (L211)
- [a] lee2025_heckel_argyrodite_powder_densification_nanoindentation | 누른 채 값의 계통 편향: 펀치 탄성 (σL/E · L 40 mm · E ≈ 180 GPa) 은 뺐으나 고체 탄성 압축 (≈ p/K) 은 안 뺌 → 기공이 300 MPa 에서 ≈ 1.2 %p · 600 MPa ≈ 2.3 %p · 900 MPa ≈ 3.5 %p 작게 읽힘. 97 % 이론밀도 도달 압력 650 (상용) / 570 (볼밀) / 675 (합성) MPa | §3-4 (L98) · §3-1 (L55) · §3-2 (L69–71) | 편향 = [우리 산술] (K = 26.23 GPa 가정) · 압력값 [인쇄] | 뺀 뒤 밀도 없음 (L127)
- [a] lei2026_se_particle_size_effects_review | 2차 인용 (Lin · ref 157): 순수 LPSCl 층, 보통 3–5 µm ↔ 미세 ≈ 1 µm, 성형 100 · 300 · 500 MPa → Fig 4b 판독 기공 미세 6.1 · 7.6 · 9.6 % · 보통 13.9 · 15.4 · 17.9 % | §3-5 (L106) · 리뷰 Fig 4b | [2차 · ref 157] · [판독] | 기공값과 압력의 짝이 카드에 명시되지 않음 · 측정 상태 · 진밀도 없음 · 원 논문 미확인 · 작은 쪽이 더 치밀 (faka2026 과 반대 방향 — 카드 §9-10 · L241 이 지적)
- [a] bazzoun2025_dem_parameter_sensitivity_assb_cathode · bazzoun2026_dem_fem_rnm_ionic | 순수 SE 기공 곡선 없음. 모의 입력 ρ_SE **1.64 g/cm³** · 펠릿은 σ 만 (350 MPa: SE45 2.9 · SE19 1.0 mS/cm / 400 MPa: 1.02 mS/cm) | bazzoun2025 §3 (L48 · L50) · bazzoun2026 §3 · §4 (L19 · L30) | stated | 펠릿 기공 · 측정 상태는 카드에 없음
- [a] frankenberg2025_milling_dry_processed_sulfide_cathode_microstructure · kim2024_optimal_cathode_composite_mechanical_mixing_se_coverage · minnmann2021_jes_charge_transport_bottlenecks | 곡선 없음 — LPSCl 밀도 **1.87 g/cm³** 만: NEI "fine" 진밀도 (frankenberg L61) · DEM 물성 표 S2 (kim2024 L115) · vol% ↔ wt% 환산용 (minnmann2021 L134) | 왼쪽 괄호 | frankenberg · kim2024 = [인쇄] · minnmann2021 = 표지 없음 | 측정법 카드에 없음
- [a] minnmann2021_jes_charge_transport_bottlenecks | 순수 SE 기공을 재지 않았다는 확인: "이 논문은 pure-SE porosity를 별도 측정하지 않는다 — 14 %는 *복합 양극* 값" · SI §3 은 순수 시료에도 기공이 *"있다고 가정해야 한다"* 고만 쓰고 값이 없음 · "300 MPa" 라는 압력은 본문 · SI 어디에도 없음 · 순수 시료의 압밀압 · 두께 · 기공률 [미확인] | §0 (L85–95) · §3 (L193–194) · §15 (L699–700) | ⟦10-03 PDF 대조⟧ · [미확인] | NCM-622 + LPSCl 복합 논문 — 순수 SE 300 MPa 표적의 근거로 못 씀
- [a] minnmann2024_microstructure_porosity_visualization · lin2025_submicron_lpscl_cathode_li_kinetics | 곡선 없음. minnmann2024 는 Li₃PS₄–0.5LiI 단상 σ 만 (2.0 / 1.7 / 1.6 mS/cm · 380 MPa) · lin2025 는 LPSCl 펠릿 σ 만 (4.96 / 1.51 mS/cm · 성형압 미기재) | minnmann2024 §3 (L35) · lin2025 §3b (L81) · §4c (L206) | stated | —


### [batch_11] a. 순수 SE (LPSCl · 황화물) 의 압력별 기공 곡선 · 진밀도 · 질량 기준 · 누른 채 / 뺀 뒤

순수 **LPSCl** 의 압력별 기공 곡선은 이 배치에 없다. 순수 황화물 SE 의 압력–밀도 곡선이 있는 카드 = 1 (schneider2023 · 재료가 t-Li₇SiPS₈ 이고 카드에는 곡선의 수치 표 없이 범위만). LPSCl 은 한 점 값 (Zhou 2025 · FIB-SEM · 조건 불명) 과 밀도 입력값뿐이다.

- [a] schneider2023_particle_size_pressure_transport | 순수 SE 펠릿 (t-Li₇SiPS₈ · <50 µm / >50 µm 두 체 분율) 의 상대밀도–압력 (Fig 2e) 과 "in die" Heckel (Fig 2f) · 0.01 → ≈1.7 GPa. 카드에 적힌 값은 범위뿐: regime III (>~1 GPa) 에서 상대밀도 90–95 % (기공 5–10 %) · 저압에서는 <50 µm 쪽이 더 치밀 | §3 (L58 · L60) · §5 Fig 2 (L106) · §6 (L118–120) | stated | LPSCl 아님 (정방정 LGPS 계 · glass-ceramic) · 압력별 수치 표 없음 · **진밀도 값 · 밀도를 잰 법 (질량 기준인지) 은 카드에 없음** · 본문 Heckel 은 누른 채 ("in die") · 뺀 뒤 ("out of die") 는 SI Fig S9 인데 카드가 SI 를 읽지 않음 (L112–114)
- [a] tailored_cathode_microstructure_low_pressure_assb | Li₆PS₅Cl FIB-SEM 기공 coarse (~20 µm) 11.3 % / fine (~1 µm) 4.4 % · 상대밀도 fine ~90 % (Fig S8) | §3 (L39–40) · §5.2 (L83) · 논문 p968 · Fig S7 · S8 | stated | 압력별 곡선 아님 (한 상태) · **제조압 미기재** (L70 · L289) · FIB-SEM 단면 기공 분할 (질량 · 두께 기준 아님 · L56) · 누른 채 / 뺀 뒤 카드에 없음 · 진밀도 없음 · 시료가 전해질 펠릿인지 복합체인지 카드 안에서 갈림 (카드 문제 2)
- [a] schlautmann2023_se_particle_size_composite_transport | 순수 SE 기공 곡선 없음. 밀도 **LPSCl 1.87 · NCM811 4.78 g/cm³** (복합 공극 계산에 쓴 값 · "calculated as Minnmann et al. reported via density measurements") · 순수 LPSCl 펠릿은 σ 만 (2.2 mS/cm · L 분율만 2.8) | §3a (L70 · L72) · §3b (L80) · SI Table S1 | stated | 밀도의 측정법 · 순수 펠릿의 기공 · 성형압은 카드에 없음
- [a] otani2025_dem_se_dispersion_aggregation_compression | 순수 SE 곡선 없음 (복합만). DEM 입력 SE 밀도 **1.8 g/cm³** (ref [5] = Otani 2023) · AM 4.75 g/cm³ | §3.1 Table 1 (L80 · L89) | stated | 입력값일 뿐 (측정법 카드에 없음) · schlautmann 의 1.87 과 다름 (카드 문제 11)
- [a] shi2019_high_am_loading_particle_size_assb | 곡선 없음. DEM 입력 밀도 LPS **유리** 1.87 g/cm³ ([3] PAULING FILE) · NMC532 4.85 g/cm³ | §3 (L120) · §S.1 (L339) · SI "Table 1" | SI-stated | LPS 유리 (LPSCl 아님) · 원전 [미확인]
- [a] stavola2023_thick_nmc111_lpscl_lithiation_gradient_tortuosity | 곡선 없음. 순수 SE 행 (CAM 0 wt%) 의 LPSC 86 vol% 는 "calculated assuming 14% void" — 측정 아님 | §3-1 (L61) · §3-5 (L102 · L104) · SI p.23 | [인쇄] | 공극 14 % 는 다른 문헌에서 빌린 가정
- [a] park2020_dimension_controlled_se_percolation_contact_area | 이 카드에 없음 (산화물 · 압력 축 없음) | — | — | —


### [batch_12] a. 순수 SE (LPSCl · 황화물) 의 압력별 기공 곡선 · 진밀도 · 질량 기준 · 누른 채 / 뺀 뒤

순수 황화물 SE 의 압력별 **곡선** 은 so2021 (LPS · DEM · 그림 판독) 하나뿐. **LPSCl 은 한 압력 점만** 있다: larson2025 (300 MPa · 뺀 뒤 · 원 측정값 표 있음) · yadav2021 (3 t · 정의 미기재). LPSCl 진밀도가 카드마다 다르다 (카드 문제 1).

- [a] larson2025_hot_pressing_argyrodite_low_stack_pressure_conductivity | 순수 Li₆PS₅Cl · 성형 300 MPa 한 점 (곡선 아님). SI Table S2 원 측정 (질량 0.24 g · 다이 ⌀12.7 mm · 두께): 냉간 20 °C 네 펠릿 두께 1.162 / 1.195 / 1.209 / 1.171 mm → 밀도 1.63 / 1.59 / 1.57 / 1.62 g/cm³ · 상대밀도 (÷1.83) 89.1 / 86.7 / 85.7 / 88.5 %; 열간 150 °C 세 펠릿 1.084 / 1.185 / 1.2 mm → 1.75 / 1.60 / 1.58 g/cm³ · 95.6 / 87.4 / 86.3 %. 본문 평균 ∼88 ± 1.57 % (n = 4) · ∼90 ± 5.05 % (n = 3) | §3-2 (L66–79) · §0 ② (L24) · 논문 SI p.S-2 · p.3758 | [인쇄] | 질량 기준 (질량 ÷ [다이 지름의 원 × 두께]) · **뺀 뒤** (다이 밖 · 하중 제거 · 작동압 사다리 ~6 h · 최대 8 MPa 뒤 · Cu 박 제거 · L62) · 두께 기구 표기가 마이크로미터 ↔ 캘리퍼스로 불일치 · 질량 2 자리라 공극 ±2 %p 는 잡음 (L84 · [우리 산술]) · 다이 안 두께 없음
- [a] larson2025_hot_pressing_argyrodite_low_stack_pressure_conductivity | 같은 펠릿의 기공률을 진밀도 셋으로 다시 계산: 냉간 (n = 4) 1.64 기준 2.4 % (0.6–4.4) · 1.83 기준 12.6 % (10.9–14.4) · 1.86 기준 14.0 % (12.3–15.7); 열간 (n = 3) −0.1 % (−6.6–3.7) · 10.3 % (4.5–13.7) · 11.7 % (6.0–15.1). 열간 펠릿 #5 는 1.64 기준 −6.6 % (결정보다 조밀 = 불가능) | §3-2 표 (L69–79 · L83) · §0 ② (L25) | [우리 산술] | 진밀도 선택만으로 같은 펠릿이 11.6 %p 갈림 (L232) · 열간 평균을 올린 것은 #5 한 개 (중앙값은 두 조건이 1.602 ↔ 1.599 g/cm³ · L82)
- [a] larson2025_hot_pressing_argyrodite_low_stack_pressure_conductivity | 진밀도의 정체: 논문이 쓴 값 1.83 g/cm³ — *"a density of crystalline Li6PS5Cl as determined by XRD of 1.83 g cm−3.43"* · SI *"Theoretical density was calculated from XRD derived lattice parameters."* (격자상수 숫자 없음). 카드 대조: 인용원 (ref 43 = Ohno 2020) SI Table S1 은 a 9.85910(10) Å · 1.86 g/cm³ · 이 논문 SI S1 의 XRD 피크 16 개 판독은 a ≈ 9.858 Å → 1.861 g/cm³. 1.63 에 대한 저자 문장: *"We note that some authors use a crystallographic density of 1.63 g cm−3 for Li6PS5Cl; this value comes from DFT calculations rather than XRD experiments."* · *"If we used 1.63 g cm−3 … we would obtain average relative densities of 98 to 100%, which are not consistent with the SEM images in Figure 4"* | §3-3 (L87–96) · §3-2 (L83) · §0 ① (L23) · 논문 p.3758 · SI p.S-2 | 1.83 · 인용문 = [인쇄] · Ohno 1.86 = [인쇄] (정본 카드 크롭) · 1.861 = [판독 · 우리 산술] · 1.83 의 계산 근거 · 1.63 의 DFT 출처 = [미확인] | Ohno 카드는 SI 만 digest (본문에 1.83 이 있는지 미확인 · L90 · L291)
- [a] yadav2021_lpscl_sieved_psd_impedance_tortuosity | 순수 Li₆PS₅Cl 체 분급 세 등급 · 3 t 한 점 (곡선 아님): compacity ~83.24 / ~84.39 / ~89.21 % (<20 / 20–50 / 50–150 µm) → 기공 16.8 / 15.6 / 10.8 % · σ ~3.96 × 10⁻⁴ / ~1.19 × 10⁻³ / ~1.46 × 10⁻³ S/cm | §3b (L73–77) · 논문 그림 3 아래 표 · p.41 | compacity · σ = [인쇄] ("~" 근사 표지) · 기공 = [우리 산술] (100 − compacity) | compacity 의 정의 · 측정법 · 진밀도 · 질량 기준 여부 · 누른 채 / 뺀 뒤 모두 미기재 (L82) · 금형 지름 미기재라 ≈ 375 MPa 는 ⌀10 mm 가정의 [우리 산술 · 가정] (L81) · 크기 등급 ≥ 20 µm 급 (작은 등급만 0.5 µm 미분 포함)
- [a] yadav2021_lpscl_sieved_psd_impedance_tortuosity | 저자의 "포화 압력이 낮다" 는 압력 계열 측정이 아님 — 3 t 한 점에서 *"it could be deduced that the saturation pressure … will be lower"* (p.41) 로 추론 | §6 Q1 (L204–205) · §10-1 (L278) | [인쇄] (인용문) | 압력별 자료 없음
- [a] so2021_dem_mold_pressure_assb_coldpress | 순수 SE (LPS = Li₂S–P₂S₅ · LPSCl 아님) 3D DEM 의 상대밀도 vs 몰드압: 초기 ~0.30 → ~0.85 @ ~300 MPa → ~0.98 @ 600 MPa · SE 층 두께 80.0 µm (초기) → 33.6 (@100 MPa) → 26.5 µm (@400 MPa). 카드: Sakuda 실험과 잘 일치 (Fig 4b 다이아) | §3 (L27 · L29) · 논문 Fig 4b/c · Fig 2 라벨 | 상대밀도 = digitized · 두께 = stated | 재료 LPS · 진밀도 값은 카드에 없음 · 밀도 = 입자 → 3D 격자 매핑 (문턱 거리 반복 보정 · L60 · L82) · 누른 채인지 뺀 뒤인지 카드에 명시 없음 · 계산 압력은 50 / 100 / 200 / 400 (일부 25 · 600) 이라 "~300 MPa" 값은 곡선 판독 (L66)
- [a] yano2026_se_psd_width_ionic_tortuosity_dem | 순수 LPSCl 펠릿은 σ 만 (원 분말 4.03 × 10⁻³ · 볼밀 1.45 × 10⁻³ S/cm) — 기공 곡선 없음. 상대밀도 계산용 진밀도 LPSCl 1.5 g/cm³ (본문) · DEM 입력 1.540 g/cm³ (표 2) · NCM 4.8 / 4.750 g/cm³ | §3a (L71) · §3b (L78) · §4d (L188–189) · 논문 p.2 · p.3 · 표 2 | [인쇄] | 카드: 다른 정본 카드의 1.87 g/cm³ 보다 낮아 상대밀도가 부풀 수 있음 (§10-2 · L367) · 펠릿 치수 [미확인] (L81)
- [a] benhadjali2026_wip_vs_cup_pressing_assb_cathode_dem | 순수 SE 기공 곡선 없음 — 셀용 LPSCl 100 mg 펠릿을 2 t (~250 MPa) 로 눌렀다는 것뿐 · LPSCl 입도 [미확인] · 성분 밀도 [미확인] | §3-2 (L81) · §3-1 (L61) · §3-3 (L95) | [인쇄] · [미확인] | —
- [a] demirtas2021_mpfem_hollow_sphere_die_compaction · diener2022_roll_gap_springback_calendering · sangros2019_dem_calendering_lib_electrode · sangros2020_lib_electrode_dem_mech_elec_ionic | 황화물 SE 없음 (고분자 중공 입자 / LIB 양극) | — | — | —


### [batch_13] a. 순수 SE (LPSCl · 황화물) 의 압력별 기공 곡선 · 진밀도 · 질량 기준 · 누른 채 / 뺀 뒤

순수 황화물 SE 의 압력별 기공 곡선이 있는 카드 = **1** (miss2026_insitu). 다만 조성이 Li₆PS₅Cl 이 아니라 **Li₅.₅PS₄.₅Cl₁.₅** 이고, 세 상태 (누른 채 · 같은 다이 안에서 110 kPa 로 놓은 뒤 · 400 MPa 뒤 다이 밖 한 점) 를 준다. 기준 밀도는 결정밀도 **1.87 g/cm³** · 질량 80.2 mg 을 두께 × 단면으로 나눈 값. 300 MPa 기공은 본문에 인쇄되지 않았고 카드가 표 S2 로 다시 계산했다 (누른 채 7.1–7.6 % — 인쇄된 식의 부호 그대로면 6.7 % · 놓은 뒤 8.6 %). 나머지 다섯 장 가운데 넷은 SE 가 없는 LIB 전극 (NMC + 탄소 – 바인더) 이고 하나 (miss2026_pressure) 는 유리 SE 의 전도도만 준다.

- [a] miss2026_insitu_conductivity_porosity_pressure_compaction | **순수 황화물 SE (µc-Li₅.₅PS₄.₅Cl₁.₅) 의 누른 채 기공** — 10 / 100 / 150 / 200 / 250 / 300 / 350 / 400 MPa: 그림 규약 (d + |Δd|) 0.2989 / 0.1579 / 0.1221 / 0.0992 / 0.0819 / **0.0755** / 0.0564 / 0.0426 · 탄성 보정 없음 0.2988 / 0.1567 / 0.1201 / 0.0965 / 0.0784 / **0.0713** / 0.0514 / 0.0367 · 인쇄된 식 2 그대로 0.2987 / 0.1554 / 0.1181 / 0.0937 / 0.0749 / **0.0671** / 0.0463 / 0.0308 · Fig 4a 판독 0.3016 / 0.1581 / 0.1234 / 0.0999 / 0.0826 / 0.0764 / 0.0579 / 0.0430. 본문이 인쇄한 수는 *"from about 0.30 at 10 MPa to about 0.04 at 400 MPa"* 뿐 | §3-3 (L118–136) · §7-3 (L282–291) · 논문 Fig 4a · p.32833 · SI Table S2 | 세 규약 값 = [재계산] · 그림 값 = [판독] · 본문 문장 = [인쇄] | Li₆PS₅Cl 이 아니라 Cl 많은 Li₅.₅PS₄.₅Cl₁.₅ · 단계마다 놓았다 다시 누른 이력 (300 MPa 전 10 회) · 시료 1 개 · 300 MPa 값은 본문에 인쇄되지 않음 · 20–70 MPa 단계의 기공은 카드 표에 없음 (두께는 Table S2 전수)
- [a] miss2026_insitu_conductivity_porosity_pressure_compaction | 같은 시료의 **놓은 뒤 (같은 다이 안 · 최소압 110 kPa)** 기공 10 / 100 / 150 / 200 / 250 / 300 / 350 / 400 MPa = 0.2982 / 0.1726 / 0.1392 / 0.1157 / 0.0946 / **0.0861** / 0.0715 / 0.0626 (판독 □ 0.1396 / 0.1161 / 0.0960 / 0.0874 / 0.0729 / 0.0629 @150–400) · **다이 밖** (400 MPa 뒤 밀어낸 펠릿 한 번) 0.095 (두께 0.6036 mm) | §3-3 (L122–131) · §3-4 (L139–146) | [재계산] · [판독] (다이 밖 두께는 [판독] · 인쇄 두께로 축 보정 · 잔차 ≤ 0.5 µm) | 300 MPa 의 다이 밖 값은 없음 (400 MPa 뒤 하나뿐)
- [a] miss2026_insitu_conductivity_porosity_pressure_compaction | 기공 식 · 진밀도 · 질량 기준: ε = 1 − m / (π r² (d_sample(p) + Δd_elastic(p)) ρ₀) (식 2) · Δd_elastic = −d_0.11 MPa · p/E (식 3–4) · **ρ₀ = 결정밀도 1.87 g/cm³** (SE · Adeli 2019) · 4.48 g/cm³ (NMC622 · Hua 2020) · m = 80.2 · 80.0 mg · E 67 GPa (SE · DFT 인용) · 180 GPa (NMC) · d_sample = 마이크로미터 값 − 시료 없이 잰 피스톤 길이 (식 1). 카드 계산 결정밀도: Li₅.₅PS₄.₅Cl₁.₅ 1.878 · Li₆PS₅Cl 1.860 g/cm³ | §0 표 ① ② (L28–29) · §3-1 (L68–78) · §4-2 (L191–193) · §4-4 (L201–206) · 논문 p.32832–32833 · SI Table S1 | [인쇄] · 결정밀도 계산 = [우리 산술] | 식 2 의 인쇄 부호 (d + Δd · Δd < 0) 와 Fig 4a (d + |Δd|) 가 반대 · Table S1 의 "Diameter 0.5 cm" 는 반지름이어야 재현 (카드 문제 절 참조) · 피스톤 교정값 · 하우징 반경 순응 · 벽 마찰 · 측정 온도 [미확인]
- [a] miss2026_insitu_conductivity_porosity_pressure_compaction | 카드가 다른 카드 (Cronau 2021 SI S3) 의 다이 밖 펠릿 밀도를 결정밀도로 바꿔 엮은 값: µC-**Li₆PS₅Cl** 1.47 · 1.54 g/cm³ (195 · 292 MPa 제작) → 기공 0.21 · 0.17 (ρ₀ 1.860) ; µC-Li₅.₅PS₄.₅Cl₁.₅ 1.59 · 1.63 · 1.66 g/cm³ (195 · 389 · 487 MPa 제작 · 판독) → 15.0 · 12.8 · 11.2 % (ρ₀ 1.87) — 이 논문의 단계 가압 다이 밖 9.5 % 보다 1.7–3.3 %p 성김 | §7-5 (L302 · L305) | [우리 산술] (cronau2021 카드 판독값 + 다른 출처 결정밀도) | 카드 스스로 "다른 출처 결정밀도를 끌어오면 우리 산수" · 장비 · 시료 · 판독기 · 프로토콜이 달라 원인 미분리 · 한 번 가압 뒤 다이 밖 값
- [a] miss2026_pressure_tortuosity_composite_cathode_coating | 순수 SE 의 기공 곡선 없음 — 기공 · 밀도 · 두께 – 압력 자료 0 건이고 SE 도 LPSCl 이 아닌 비정질 0.67Li₃PS₄–0.33LiI. 순수 SE 펠릿은 전도도만: 8.8 / 52 / 97 / 145 / 194 / 243 / 292 / 389 / 486 / 584 / 663 MPa = 0.098 / 0.33 / 0.49 / 0.63 / 0.73 / 0.81 / 0.86 / 0.93 / 0.98 / 1.00 / 1.00 mS/cm (누른 채 · 25 ℃) | §0 표 ② ③ (L26–27) · §3-2 (L68–76) · 논문 Fig 1 · p.3 · p.7 | [판독] (195 MPa 0.73 은 [인쇄]) | σ 계산에 쓴 두께가 가압 중 값인지 [미확인] · 진밀도 값 없음
- [a] ngandjong2021_dem_calendering_digital_twin | 순수 SE 곡선 없음 — SE 상이 아예 없는 LIB 전극 (NMC111 96 wt% + CBD 4 wt% · 액체전해질). 밀도 입력만: NMC 4.653 · carbon black 1.834 · PVdF 1.791 g/cm³ · 치밀 CB+PVdF 평균 1.81 · 모델의 압축 CBD 입자 0.95 g/cm³ (내부 나노공극 ≈ 47 %) | §2 (L59) · §3 (L100) | stated | 카드가 "우리 앵커" 로 "Minnmann pure-SE ε ≈ 10 % @ 300 MPa" 를 적어 둠 (§3-B L216) — 논문 값이 아니고 우리 쪽 기록 (카드 문제 절 참조)
- [a] lyu2025_3d_dem_drying_calendering_lib | 순수 SE 곡선 없음 — SE 가 없는 LIB 전극 (NCM811 + CBD 94:6 wt · 액체전해질). 밀도 입력 ρ_AM 4.74 · ρ_CBD 2.2 g/cm³ | §2 (L20) · §3 (L40) · 논문 Table 1 | stated | —
- [a] xu2023_realistic_am_shape_cgmd_calendering | 순수 SE 곡선 없음 — SE 가 없는 LIB 전극 (NMC111 + CBD). 밀도: CBD 0.95 g/cm³ (나노공극 50 %) · ρ_AM 은 미기재 (입자 수 검산으로 ≈ 4.68 g/cm³). 실험 기공 = 식 (1) φ = (1 − (m/V)·Σ x_i/ρ_i) × 100 % · 지름 13 mm 디스크 (질량 / 부피법) | §3 (L122–123) · §6 (L555) | 0.95 = stated · 4.68 = derived(ours) | 실험 기공이 압연기에서 나온 뒤 (뺀 뒤) 값이라는 낱말은 카드에 없음 (디스크를 펀칭해 잼)
- [a] zhang2026_xct_dem_cathode_calendering_peel_calibration | 순수 SE 곡선 없음 — SE 가 없는 LIB 전극 (NMC + CBD). 밀도 입력 NMC 4750 kg/m³ · Al 2700 kg/m³ · 기공의 정의식 없음 (겹침 부피 처리 관례 [미확인]) | §3.1 (L123) · §3.2 (L138) · §6 (L368) | stated · [미확인] | —


### [batch_14] a. 순수 SE (LPSCl · 황화물) 의 압력별 기공 곡선 · 진밀도 · 질량 기준 · 누른 채 / 뺀 뒤

순수 황화물 SE 의 압력별 곡선이 있는 카드 = **1** (sakuda2013 — 단 Li₃PS₄ 조성 **유리** 이고, 본문에 적힌 값은 한 점 · 나머지는 그림 판독). LPSCl 을 잰 카드 = **1** (doux2020 — 370 MPa **한 점** · 곡선 아님). 두 장 모두 밀도를 누른 채 쟀는지 뺀 뒤 쟀는지와 밀도 측정법이 카드에 없다.

- [a] sakuda2013_sulfide_mechanical_property | 순수 황화물 유리 (75Li₂S·25P₂S₅ = Li₃PS₄ 조성 유리) 의 상대밀도 – 몰딩 압력 (Fig 2a) 에서 본문이 적은 값은 하나: *"The relative density … exceeds 90 % when the 75Li₂S·25P₂S₅ glass powder is compressed by a pressure of over 350 MPa."* → 기공 < 10 % @ > 350 MPa | §3 L51 · §11-A L163–164 · 논문 p.2 | stated (본문) | LPSCl 아님 (유리) · 300 MPa 는 본문에 특정값으로 나오지 않음 (본문 명시 압력 = 70 · 74 · 350 · 360 MPa · L169)
- [a] sakuda2013_sulfide_mechanical_property | 같은 곡선의 그림 판독: ≈ 30 % (저압) → ≈ 50 % (≈ 30 MPa) → ≈ 60–65 % (≈ 75) → ≈ 75 % (≈ 150) → ≈ 80 % (≈ 200) → **≈ 85–88 % (≈ 300 · "≈ 87 %" → 기공 ≈ 12–15 %)** → ≈ 90 % (≈ 350) → ≈ 93–95 % (≈ 450) | §3 L52–53 · §5 L94 · §11-A L165–166 · Fig 2a | digitized (Fig 2a) · "추세만 · ± 몇 %p" | 카드: "stated 정밀값으로 인용 금지" · 판독값이 L53 과 L94 에서 조금 다름 (카드 문제 18) · 2026-10-21 원문 대조 때 다시 읽지 않음 (L213)
- [a] sakuda2013_sulfide_mechanical_property | 진밀도 (분모) · 질량 · 상태: 상대밀도 = ρ_coldpress ÷ ρ_hotpress · 분모 = 75Li₂S·25P₂S₅ 를 약 200 ℃ (Tg 근처) 로 열간 프레스한 **투명 유리 펠릿 1.88 g/cm³** (결정 밀도 아님) — *"The total relative density was determined using 75Li₂S·25P₂S₅ transparent glass prepared by hot pressing at about 200 °C (see Fig. 3b and Ref. 9); the density of the glass was 1.88 g cm⁻³."* · *"The density of hot press glass was almost the same as that estimated from the density of the crystal."* · 시료 = 10 mm 몰드 · 500 mg · 상온 단축 냉간 프레스 | §3 L54 · §4 L74–76 · §13-1 L216–221 · 논문 p.2 · p.5 | stated (p.2 · 원문 확인 2026-10-21) · 인용문 = verbatim | 밀도 측정법 (아르키메데스 · 치수 · 기체 치환) 미기재 · 누른 채 / 뺀 뒤 미기재 · 어느 결정상인지와 그 값 미기재 · 열간 프레스 펠릿의 남은 공극 몫 미상 (카드: 참 유리 밀도 ≥ 1.88) · 재료가 달라 랩 표준 (LPSCl 1.64 g/cm³) 과 견줄 값이 아님
- [a] doux2020_stack_pressure_assb | **순수 Li₆PS₅Cl (NEI 구매품 그대로) 펠릿 · 370 MPa 냉간 가압 한 점**: 펠릿 4 개의 상대밀도 80.3 / 84.9 / 80.3 / 83.0 % → 평균 82.1 % → 기공 ≈ 18 % · 이론밀도 1.860 g/cm³ 기준 · 실측 1.522 g/cm³ · 본문 *"A porosity of 18% within the electrolyte provides connecting pathways"* | §6 L202–204 · §9 L277 · SI Table S2 | 표지 없음 (Table S2 · 인용문은 카드가 "본문도 … 라 명시") | **랩 표준과 다른 문헌 값** (기공 18 % ↔ 10–13 % · 기준 밀도 1.860 ↔ 1.64 g/cm³) · 압력 한 점 (곡선 아님) · 밀도 측정법과 누른 채 / 뺀 뒤가 카드에 없음 · 내 검산: 1.522 ÷ 1.860 = 81.8 % (평균 82.1 % 와 0.3 %p 차 · 카드 문제 13) · 펠릿 = 분말 200 mg · 13 mm PEEK 다이 · 두께 ≈ 1 mm (L85–86 — 내 산술로 200 mg ÷ (13 mm 단면 × 1 mm) ≈ 1.51 g/cm³ 이라 실측값과 같은 자릿수)
- [a] doux2020_stack_pressure_assb | 같은 펠릿의 이온전도도 σ_ion = 2–2.5 mS/cm (EIS) | §2.1 L85–87 | 표지 없음 | 한 조건 (압력별 σ 아님)
- [a] so2022_dem_compaction_coated_particles_assb | 순수 SE 곡선 없음 — 복합 (LPS + NCM) 만. 카드: "relative-density 곡선은 MethodsX/So2021; 이 논문 본문엔 porosity-vs-P 풀곡선 없음" | §3.2 L72 | — | —
- [a] lee2024_multiphysics_dem_fem_initial_pressure_assb | 순수 SE 기공 곡선 없음 — SE 혼합 (LGPS + LLZO · LLZO 0 / 33 / 41 / 58 / 66 / 100 wt%) 의 punch 응력 곡선만 (LGPS 압축성 ≫ LLZO) 이고 기공 값은 카드에 없음. 밀도 입력 LGPS 2000 · LLZO 5500 kg/m³ | §3 L67 · §5 L205 · Fig 2 | 밀도 = stated | LGPS · LLZO (LPSCl 아님) · 모의
- [a] nisar2024_dem_effective_electrical_conductivity_sps | 해당 없음 (NiAl). 기공 정의만: 1 − ρ/ρ₀ (Archimedes) · ρ₀ 5910 kg/m³ | §3 L35 · L38 | stated | 금속
- [a] kakar1967_deformation_theory_hot_pressing | 해당 없음 (납 · 사파이어). 밀도 정의만: 압분체 무게 / 부피 ÷ 비중병 진밀도 — 하중을 걷고 꺼낸 뒤 | §0 L25 · §4-4 L165 · 논문 p.3227 | stated | 다른 재료
- [a] deysher2022_transport_mechanical_aspects_assb_review | 순수 SE 압력별 기공 자료 없음 (리뷰) | §3 L103–104 | — | —
- [a] kang2026_intertwined_electrochemo_mechanical_sulfide_assb_review | 순수 SE 압력별 기공 자료 없음 (리뷰). 인용만: "370 MPa 고압에서도 3D tomography 로 비-무시 불규칙 공동 확인" (Doux et al., ref 100) | §5.1 L126 · §9 L262 | 2 차 인용 | 값 없음 · ref 100 이 doux2020 카드와 같은 논문인지 카드에 없음 (카드 문제 40)


### [batch_15] a. 순수 SE (LPSCl · 황화물) 의 압력별 기공 곡선 · 진밀도 · 질량 기준 · 누른 채 / 뺀 뒤

압력별 곡선이 있는 카드 = **0**. 순수 LPSCl 을 잰 카드 = **1** (beutl2024 — 360 MPa **한 점** · 질량 ÷ 기하 부피 · 다이에서 **꺼낸 뒤**).

- [a] beutl2024_round_robin_coin_cell_sulfide_assb | 순수 Li₆PS₅Cl (NEI "LPSCl fine") 펠릿 100 mg · ⌀10 mm · 예압 50 MPa → 360 MPa 한 점: 겉보기 밀도 *"1.6–1.50 g cm−3"* (p.5) / *"at least 1.49 g cm−3"* (p.9) · 상대밀도 RC1 > 91 · RC2 > 94 · RC3 > 93 · RC4 > 93 % | §3-2 L78–87 · §3-4 Table 2 L121–126 · 논문 p.4–5 · p.9 | [인쇄] | 압력 한 점 (곡선 아님) · 4 기관 각 한 값 (n · SD 없음) · 범위 하한이 1.50 ↔ 1.49 로 본문 안 불일치 · 예압 50 MPa 의 밀도 미보고
- [a] beutl2024_round_robin_coin_cell_sulfide_assb | 진밀도 (분모) · 질량 기준 · 상태: 분모 = *"crystallographic density of Li6PS5Cl is 1.64 g cm−3"* [10,37] (p.9 · p.5 는 [37]) — 이 논문이 재거나 계산한 값이 아님 (격자상수 정련 · 비중병 없음) · 밀도 = 질량 ÷ 기하 부피 (*"use the weight and geometric volume of the sample to calculate its apparent density and further compare it with the reported crystallographic one"*) · 두께는 압력을 뺀 뒤 (*"After removing the sample from the die set a free-standing pellet with a thickness of approximately 0.8 mm is obtained."*) | §3-2 L83–85 · §3-3 L102–103 · 논문 p.4 · p.5 · p.9 | [인쇄] (인용문은 텍스트 층에서 그대로 · L376) | 분모 1.64 는 랩 표준과 같은 값 · 그 값의 출처 ([37] Zhou 2019 ACS Energy Lett. 4, 265 · [10] Tron 2023 Nanomaterials 13, 327) 는 원문 미확보 [미확인] · 두께 측정 도구 · 오차 [미확인]
- [a] beutl2024_round_robin_coin_cell_sulfide_assb | 같은 펠릿을 공극으로 읽은 값 (카드 계산): ε = 2.4–9.1 % (진밀도 1.64) ↔ 14.0–19.9 % (진밀도 1.86) · 함축 두께 0.796–0.855 mm · ln(1/(1 − D)) = 2.39–3.71 (1.64) / 1.61–1.97 (1.86) @360 MPa | §3-2 L89–99 · §7-2 ⑤ L309 | [우리 산술] | 1.86 (결정학 산술 · Z = 4 · a ≈ 9.86 Å) · 1.874 (Ohno 2020 비중병 · 카드 인용) · 1.87 (Frankenberg 2025 같은 이름 분말 · 카드 인용) 은 **랩 표준과 다른 문헌 값** · 1.64 기준 2.4–9.1 % 는 360 MPa · 다이 밖이라 랩 기준 (10–13 %) 과 압력 · 상태가 같은 점이 아님
- [a] beutl2024_round_robin_coin_cell_sulfide_assb | 카드가 300 MPa 로 옮긴 어림: 같은 계열 ρ ≈ 1.41–1.54 g/cm³ (ε × e^(K·60) · K ≈ 32 × 10⁻⁴ MPa⁻¹) — 랩 기준 창을 1.64 로 정의한 밀도 1.427–1.476 g/cm³ (0.1 g · ⌀10 mm 면 두께 0.892–0.863 mm) 이 그 안에 듦 | §7-2 ⑤ L300–307 | [우리 산술 · 어림] (K 는 다른 카드 lee2025_heckel 의 다른 분말 · 다이 안 값) | 300 MPa · 다이 밖 실측은 없음 (카드: "확인은 아님") · 인용 불가
- [a] beutl2024_round_robin_coin_cell_sulfide_assb | 순수 SE 펠릿의 σ_ion (25 °C · 측정 중 ≈ 0.2 MPa (인용값) · 두께 ≈ 0.8 mm): SS|SE|SS 0.3 · 0.4 · 0.3 · 0.3 mS/cm (RC1–4) · Al/C|SE|Al/C 0.4 · 0.4 · 0.3 (RC2–4) · Al/C 를 360 MPa · 3 min 함께 누른 셀 1.8 (RC3 · Table 2) ↔ 본문 *"1 × 10−3 S cm−1"* | §3-4 L119–134 · Table 2 · 논문 p.9 | [인쇄] | 표 1.8 ↔ 본문 1 불일치 · 한 자리 유효숫자 · 압력 · 온도 계열 없음
- [a] cronk2026_lis_positive_electrode_geometry_fem | 순수 SE 압력별 기공 없음. 닿는 값: FEM 입력 ρ_SE = 1.6 g/cm³ (Table S6) · 비에너지 계산의 가정 "SSE 상대밀도 85 %" (Table S8) · 분리막 = 3 ton (375 MPa) · 3 min → 450–500 µm (질량 없음 → 밀도 못 냄) · LPSCl 촉매전해질 σ = 2 mS/cm (Ti|composite|Ti · 75 MPa · 25 °C · Fig S8a) | §2 L58 · §4.2 L221 · §6.1 L401 · §6.7 L510–526 · §10-11 L661–663 | stated (Table S6 · S8) · σ 는 표지 없음 | ρ_SE 1.6 은 **랩 표준과 다른 문헌 값** (출처 표기 없는 FEM 입력) · 85 % 는 가정치 (카드: "측정도, 양극 미세구조 값도 아니다")
- [a] asano2017_ncm111_li3ps4_composite_electronic_ionic_conductivity | 순수 SE (Li₃PS₄ 유리) 의 기공 – 압력 자료 없음. 카드가 옮긴 다른 논문 값만: 같은 그룹 [13] (Sakuda 2013) 의 같은 조성 유리 "상대밀도 > 90 % @ > 350 MPa · 냉간 360 MPa 펠릿 σ 3.1 × 10⁻⁴ · 열간 프레스 3.4 × 10⁻⁴ S/cm" | §3-1 L69 | "sakuda2013 카드 (stated)" | 이 논문의 값이 아님 · 유리 (LPSCl 아님) · 이 논문의 순수 SE σ₀ 4 × 10⁻⁴ S/cm @25 °C 는 측정 셀 · 압밀 · 밀도 미기재 (L67)
- [a] bielefeld2019 · bielefeld2020 · chen2011 · cooper2017 | 해당 없음 — 기공은 입력이거나 (bielefeld 5 / 10 / 15 / 20 % · chen 30 %) 없음 (cooper) | — | — | —


### [batch_16] a. 순수 SE (LPSCl · 황화물) 의 압력별 기공 곡선 · 진밀도 · 질량 기준 · 누른 채 / 뺀 뒤

압력별 곡선이 있는 카드 = **0**. 순수 SE 를 눌러 기공을 잰 카드 = **1** (froboese2019 — **고분자** SE · 732 MPa 한 점). 황화물 순수 SE 펠릿은 hlushkou2018 (LPSI 유리 · σ₀ 측정용) 에 나오지만 밀도 · 기공 값이 없다. LPSCl 의 진밀도를 적은 카드는 없다.

- [a] froboese2019_microstructure_ionic_conductivity_assb_electrode | 순수 고분자 SE (PEO : LiTFSI : SiO₂) 펠릿 · ⌀16 mm · 732 MPa 한 점: 기공 4.36 % · σ 6.19 × 10⁻⁴ S/cm @80 °C (같은 과립 · 같은 프레스 · 같은 어닐 · 코인셀 3 개) | §0 L29 · §3-2 L90 · §3-3 L127 · 논문 A321–A323 | stated | 황화물이 아님 (고분자 · 80 °C 72 h 어닐 뒤 80 °C 측정) — LPSCl 기준 (10–13 %) 과 견줄 수 없는 다른 재료의 값 · 압력 한 점 · 압분 온도 [미확인] · 카드도 "LPSCl 순수 SE 기공 앵커로 쓰지 않는다" (L370)
- [a] froboese2019_microstructure_ionic_conductivity_assb_electrode | 기준 밀도 · 질량 기준 · 상태: SE 이론 밀도 1.442 g/cm³ = 성분 진밀도 (PEO 1.24 · LiTFSI 2.16 · SiO₂ 2.0 g/cm³ · 가스 피크노미터) 의 질량분율 조화합 (Eq 4–7) · 기공률 ε = 1 − ρ_측정/ρ_이론 (Eq 11 · 질량 수지) · ρ_측정 = 질량 ÷ (두께 × 지름² × π/4) — 질량 소수 5 자리 · 세 점 두께 (Mitutoyo ID-C112AXB) | §3-1 L65–66 · L75 · §4-1 L188–193 · 논문 A319–A320 | stated (1.442 는 카드 재계산 1.4427 과 일치 · derived) | 누른 채인지 뺀 뒤인지 카드에 표기 없음 (게이지로 잰 펠릿 치수) · 1.442 는 고분자 SE 값 — 랩 표준 (LPSCl 1.64) 과 재료가 다른 문헌 값
- [a] hlushkou2018_void_space_ion_transport_assb_cathode | 순수 LPSI 유리 (Li₂S–P₂S₅–LiI) 펠릿 ⌀6 mm · 276 MPa · 30 min · 실온 — σ₀ 0.7 mS/cm @25 °C 측정용 · **펠릿 밀도 · 기공률 · SE 입경은 원문에 없음** | §0 L29 · §3-A L69–73 · 논문 p.365 | stated (조건 · σ₀) · [미확인] (밀도 · 기공) | 기공 값 0 건 · LPSCl 아님 · Table 1 의 SE 밀도 2.2 g/cm³ (L72 · stated) 는 LPSI 유리 값 — 랩 표준과 다른 (재료가 다른) 문헌 값
- [a] islam2026_microstructure_resolved_impedance_lpscl_symmetric_cell | 순수 LPSCl 층 (2D phase-field) 의 기공률 ~12 % · ~20 % 는 **초기 입자 수로 정한 입력** (압력 축 · 진밀도 없음). 기공 → SE 옴 저항 (고주파 절편) 22.0 (치밀) → 32.5 → 38.0 Ω·cm² | §3 L28–30 · §4-2 L60 | stated (기공 설정) · digitized (절편) | 2D · 계산 입력 — 눌러서 얻은 기공이 아님 · 랩 기준과 견줄 측정값 아님
- [a] hamann2026_llzo_bilayer_porosity_asr_dendrite_ccd | 순수 SE 기공 자료 없음 (소결 LLZO · 기공률은 기공 형성제 · 템플릿으로 정함). 지나가는 한 줄: LPSCl K_Ic 값의 출처 시료가 "다공 13 % 펠릿 · 거시 시험" (song2025 카드 인용) | §9 I-7 L344 | 표지 없음 (다른 카드 인용) | 압력 · 진밀도 · 상태 없음
- [a] duquesnoy2020 · galvezaranda2024 · holzer2013 | 해당 없음 (SE 없음 — LIB · 액체 격막) | — | — | —


### [batch_17] a. 순수 SE (LPSCl · 황화물) 의 압력별 기공 곡선 · 진밀도 · 질량 기준 · 누른 채 / 뺀 뒤

압력별 곡선이 있는 카드 = **0**. 순수 황화물 SE 를 눌러 밀도 · 기공을 잰 카드 = **1** (ketter2025 — LPSCl · 한 점). 밀도 값만 있는 카드 = 2 (kim2024 — Archimedes · kato2018 — 표의 명목 밀도).

- [a] ketter2025_resistor_network_models_predict_transport_properties | 순수 Li₆PS₅Cl 펠릿 (열확산 LFA 용): 370 MPa 3 min 선압 → 등방 500 MPa 60 min · ρ_geo 1.634 ± 0.012 g/cm³ · ρ_theo 1.86 g/cm³ · 상대밀도 87.87 ± 0.64 % → 기공 12.13 % (3 회) | §0 L14 · §3-1 L74 · §3-3 L102 · SI §S7 · SD `FigS18a` | 측정 (stated + SD) | 한 압력 (곡선 아님) · 등방압 60 min (일축 300 MPa 아님) · 하중을 뺀 뒤의 기하 밀도 (카드 L25 "등방 500 MPa 성형 후 무하중 LFA") · ρ_theo 1.86 은 랩 표준 (1.64) 과 다른 문헌 값 — 기공 12.13 % 는 그 1.86 기준 값 · 도메인 ≈ 20 µm · 소프트 밀링 (15 Hz 15 min) 을 거친 분말
- [a] ketter2025_resistor_network_models_predict_transport_properties | 진밀도의 출처 · 기준: 부피비 계산에 쓴 밀도 LPSCl 1.86 · NCM83 4.78 g/cm³ (refs Deiseroth 2008 · Woo 2009) · 상대밀도 = ρ_geo/ρ_theo (기하 밀도를 어떻게 쟀는지의 식은 카드에 없음) | §4-5 L186 · §3-1 L74 | stated (밀도) · 표지 없음 (식) | 피크노미터 실측이 아니라 문헌의 결정 밀도 (카드 표기 "ρ_theo") · 랩 표준과 다른 문헌 값
- [a] ketter2025_resistor_network_models_predict_transport_properties | 전기 셀의 순수 LPSCl (100 mg): 370 MPa 3 min 성형 → 50 MPa 누른 채 EIS → σ_ion 2.33 mS/cm @25 °C · 셀 지름 · 두께 · 성형 뒤 밀도는 n/a | §3-1 L68 · §4-5 L188 | 측정 → 입력 (stated + SD) · n/a (밀도) | 기공 값 0 — 같은 논문의 LFA 펠릿 (등방 500 MPa) 과 압밀 상태가 다름
- [a] ketter2025_resistor_network_models_predict_transport_properties | (인용 사례) Böger 2023 의 다공 LPSCl: 상대밀도 75.4–90.9 % 의 실측점 6 개 (열전도 0.269–0.498 W/m·K) — 밀도 축만 있고 압력 · 누른 방법은 카드에 없음 | §0 L17 · §3-5 L136 | stated (입력) · SD · "Böger 원문 미확인" | 열전도용 자료 · 압력 축 없음
- [a] kim2024_carbon_volumetric_occupation_se_domain | SE (Li₆PS₅Cl₀.₅Br₀.₅ · 카드 표기 LPSCl) 밀도 1.86 g/cm³ — Archimedes (이소프로판올) · 탄소 SC 0.67 g/cm³ | §3 L50–51 · §6 L127 | stated | 기공 · 압력 곡선 없음 (카드 L64 n/a) · Br 이 든 조성 · 무엇의 밀도인지 (분말 · 펠릿) 는 카드에 없음 ("치밀한 황화물 SE" 라고만) · 1.86 은 랩 표준과 다른 문헌 값
- [a] kato2018_thick_electrode_assb_cycle_tortuosity | 순수 SE 냉간 압분 펠릿 (σ₀ 용): 알루미나 실린더 420 MPa · 25 °C · Ar — Li₁₀GeP₂S₁₂ 3.2 · 75Li₂S–25P₂S₅ 유리 0.28 · LiI 유리 1.2 mS/cm · 펠릿 두께 · 상대밀도 · 측정 중 가압 = [미확인] · 조성 표의 SE 밀도는 세 SE 모두 2.00 g/cm³ | §3-1 L74–78 · §3-2 L88 · L92 · SI p.4–6 · Table 2 | stated (σ · 조건 · 2.00) · [미확인] (밀도 · 가압) | LGPS · 황화물 유리 — LPSCl 아님 · 기공 값 0 · 2.00 은 재료가 다른 문헌 값
- [a] kato2018_thick_electrode_assb_cycle_tortuosity | 같은 LGPS 분말의 냉간 펠릿 3.2 ↔ 소결 펠릿 8.3 mS/cm (× 2.6) · 유리 75Li₂S–25P₂S₅ 는 냉간 0.31 @ 360 MPa ↔ 열간 0.34 mS/cm (sakuda2013 카드 값) — 결정 SE 와 유리 SE 의 "냉간 ↔ 치밀" 차가 다름 | §3-1 L74–80 · SI p.4 | stated (3.2 · 8.3) · 우리 산술 (× 2.6) · 타 카드 · 교차 산술 | 전도도로 본 치밀화 차이지 기공 측정이 아님 · LPSCl 아님
- [a] jung2023 · kim2026_a3d · kim2026_pregranulation · landesfeind2016 | 해당 없음 — 순수 SE 를 다루지 않음 (jung2023 은 SE 분리막 100 mg 을 437 MPa 로 눌렀다는 것뿐 · 밀도 없음 L48) | — | — | —


### [batch_18] a. 순수 SE (LPSCl · 황화물) 의 압력별 기공 곡선 · 진밀도 · 질량 기준 · 누른 채 / 뺀 뒤

압력별 곡선이 있는 카드 = **0**. 순수 황화물 SE 를 눌러 밀도 · 기공을 잰 카드 = **0**. 닿는 것은 부피 계산에 쓴 밀도 한 줄 (lee2026) 과 순수 SE 펠릿의 전도도 (nakamura2020) 뿐이다.

- [a] lee2026_unveiling_ptfe_dry_electrode_digital_twin | Li₆PS₅Cl 의 상 밀도 1.86 g/cm³ (부피분율 · 상대밀도 계산용 — NCM 4.44 · VGCF 2.10 · PTFE 2.06 g/cm³ 과 함께) | §3-1 L68 · SI p.17 | [인쇄] | 순수 SE 펠릿의 기공 · 압력 곡선 없음 · 1.86 은 랩 표준 (1.64) 과 다른 문헌 값 — 이 카드의 밀도 기반 기공 (15.4 · 12.6 %) 과 상대밀도 (82.5–87.4 %) 는 모두 그 1.86 기준 · 실측 밀도인지 결정 밀도인지는 카드에 없음
- [a] lee2026_unveiling_ptfe_dry_electrode_digital_twin | SE 분리막층 = LPSCl 150 mg (D50 5 µm) 을 ⌀13 mm PEEK 몰드에서 70 MPa 펠릿 → 전극을 올려 370 MPa 5 min → 적층압 50 MPa 로 시험. 펠릿 밀도 · 두께 없음 · 순수 LPSCl 펠릿의 σ₀ 측정도 없음 (복셀 계산의 σ_LPSCl 입력 0.1 S/m = 1.0 mS/cm 는 출처 미기재) | §3-1 L69 · §0 L30 · L33 · §4-4 L253 · §10-7 L436 | [인쇄] (조건) · [미확인] (밀도 · σ₀ 출처) | 기공 값 0
- [a] nakamura2020_dry_coating_ncm_li3ps4_core_shell | 순수 SE (glassy Li₃PS₄ · 75Li₂S·25P₂S₅) 는 전도도만: 합성 직후 3 × 10⁻⁴ S/cm @ 298 K · 습식 분쇄 (개수 D50 0.49 µm) 뒤 압분 펠릿 0.84 × 10⁻⁴ S/cm @ 298 K. 펠릿 성형압 · 밀도 · 기공은 카드에 없음. 반쪽셀의 SE 층 = 분쇄 안 한 LPS 80 mg 을 양극 10 mg 과 함께 360 MPa 로 누름 (밀도 없음) | §3-1 L61–62 · §3-4 L92 · p.3 · p.4 · p.6 | [인쇄] | Li₃PS₄ 유리 — LPSCl 아님 · 기공 값 0 · 압력 곡선 없음
- [a] landesfeind2018 · malifarge2017 · matthews2024 · morasch2018 · nguyen2020 | 해당 없음 — 액체 전해질 LIB (SE 없음) | — | — | —


### [batch_19] a. 순수 SE (LPSCl · 황화물) 압력별 기공 곡선 · 진밀도

- [a] song2025_porous_argyrodite_modulus_fracture_toughness | 순수 LPSCl 펠릿 **한 점**: 다공도 13 ± 2 % (겉보기/이론 밀도) @ 360 MPa 단축 압착 + 60 °C 2 h, 입경 ≈1 µm — 압력별 곡선 없음 (한 조건뿐) | §3.1 L51 · §3.3 L67 · L12 · §10 L188 | stated | 뺀 뒤 (압착 해제 · 열처리 뒤) 시편 · 이론 밀도 값과 기공 계산식은 카드에 없음 · 랩 표준 범위와 겹침
- [a] song2025_porous_argyrodite_modulus_fracture_toughness | 논문 서론 서술 "LPSCl 은 ≈10 % 다공" (국소–벌크 차가 특히 큰 이유로) | §11 L200 | 표지 없음 (카드의 서론 요약) | 출처 · 압력 · 조건 카드에 없음 — 측정값 아님
- [a] song2025_porous_argyrodite_modulus_fracture_toughness | 다공도–영률 자료는 **다른 황화물** (Li₃PS₄, Baranowski 2016) 2차 인용뿐: 밀도 58 / 67 / 80 % → 초음파 E 3.49 / 5.01 / 9.80 · 나노압입 4.53 / 8.74 / 12.07 GPa | §3.4 L87–88 · L12 | 2차 인용 (원문 미확인) | Li₃PS₄ — LPSCl 아님 · 압력 축 아님
- [a] reisacher2023_percolation_sulfide_carbon_matrix | 기공 · 상대밀도 n/a (미측정). 분리막 375 MPa 압밀 · 매트릭스 셀 안 2.07 MPa. 밀도 LPSCl 1.83 · C65 1.60 g/cm³ (wt% → vol% 환산에 씀) | §3 L88 · L123 · L92 | stated | LPSCl 1.83 g/cm³ 은 랩 표준과 다른 문헌 값 · 카드 Table 1 vol% 는 1.83 과 맞지 않음 (카드 문제 1)
- 나머지 다섯 장 (pouraghajan · sangros · taufactor · thorat · tjaden): 해당 없음 (SE 압밀 없음 · 액체 LIB 전극 다공도는 압력별이 아님).


### [batch_20] a. 순수 SE (LPSCl · 황화물) 압력별 기공 곡선 · 진밀도

이 배치에 없음.
- [a] vijay2025_hybrid_cgmd_dl_slurry_microstructure | (참고 · 같은 양 아님) ASSB 슬러리 밀도 1.415 g/cm³ (외삽 1.400 · %diff 1.06) = CGMD 슬러리 상자 밀도 — 이 논문에서 ASSB 로 내려간 유일한 물성 | Table 6 · L116 · §10-A L539 | stated | NMC-622 + argyrodite + CBSA 슬러리 · 압축 없음 · SE 진밀도가 아니므로 랩 표준과 견줄 양이 아님


### [batch_21] a. 순수 SE (LPSCl · 황화물) 압력별 기공 곡선 · 진밀도

이 배치에 없음 (순수 SE 의 압력별 기공 곡선을 가진 카드 없음). 관련만:
- [a] zhou2026_gyroid_structural_electrolyte_stiffness_ionic_tradeoff | (다른 카드 값의 포인터) 냉간압착 LPSCl 펠릿 공극 13 ± 2 % · E 4.7 GPa = 조밀 결정 22.1 GPa 의 ≈21 % — `song2025_porous_argyrodite_modulus_fracture_toughness` 에서 가져옴 | §7-5 L244 | [우리 산술 · 추정] | 이 카드의 측정 아님 · 압력 · 진밀도 · 질량 기준 · 누른 채 여부 이 카드에 없음 · 랩 표준과 다른 문헌 값 (범위 일부 겹침)
- [a] cho2024_conflicting_roles_conductive_additive | wt% → vol% 환산용 LPSCl 밀도 ~1.64 g/cm³ (NCM ~4.77) | §12 L497 | 표지 없음 (논문 값인지 카드 가정인지 표시 없음) | 랩 표준 진밀도 1.64 와 같은 값 · 이 카드에 기공 곡선 없음
- [a] cho2024_conflicting_roles_conductive_additive | LPSCl σ_ion 4.8 mS/cm (RT) — 기공이 아닌 전도도 | §3 L109 · Fig S1 | stated | 같은 랩 Kim 2025 는 1.6 (L138–140) · 카드: 절대 직접대조 금지, 범위로만


### [batch_22] a. 순수 SE (LPSCl · 황화물) 의 압력별 기공 곡선 · 진밀도 · 질량 기준 · 누른 채 / 뺀 뒤

이 배치에 없음 (순수 SE 의 압력별 기공 곡선을 가진 카드 없음). 관련만:
- [a] hippauf2019_dry_film_ptfe_sulfide_cathode_sheet | 순수 SE 펠릿 (100.0 mg) σ 3.1 mS/cm 의 펠릿 밀도 = 본문 1.8 · 그림 범례 1.7 g/cm³ · 펠릿 성형 압력은 카드에 없음 | §3-4 L100 · §10-1 L258 · Fig 5A | [인쇄] | 기공 곡선 아님 · 밀도 두 값 (카드가 이미 표시)
- [a] hippauf2019_dry_film_ptfe_sulfide_cathode_sheet | 이론 밀도 식 (SI 식 S1 · 질량 분율 기준) ρ_comp = 1 / Σ(m_i / (100·ρ_i)) · (1 − P/100) 의 SE 진밀도 ρ_SE 1.9 g/cm³ (ρ_AM 4.8 · ρ_CA 2.26 · ρ_B 2.2) | §3-2 L83 | [인쇄] SI p.1 | 랩 표준과 다른 문헌 값 (LPSCl 1.64)
- [a] hong2026_sulfide_cathode_binder_digitaltwin | 디지털트윈의 LPSCl 밀도 1.86 g/cm³ (NCM 5 · Super C 1.6 g/cm³) | §2.4 L116–119 | 표지 없음 | 랩 표준과 다른 문헌 값 · 재구성 입력값이지 측정 곡선 아님
- [a] hong2026_sulfide_cathode_binder_digitaltwin | pristine LPSCl σ 1.87 → butyl butyrate 노출 뒤 0.53 mS/cm (AC 임피던스 · XRD 결정 변화 없음) · 셀 조립용 SE 펠릿 80 MPa | §4.1 L192–194 · §2.2 L98 · Fig S6 · S7 | 표지 없음 | 기공 · 밀도 값 없음
- [a] jadidi2023_dem_batch_solid_mixers_review | ρ_SE 1.64 g/cm³ (ρ_CAM 4.77 · bazzoun2026 카드에서 가져온 값 · "우리 덱의 실제 입력 밀도는 별도 확인 필요") | §4.9.3 L346 | 카드 인용 | 랩 표준과 같은 값 · 기공 곡선 아님
- galvezaranda2025 · han2025 · hare2026: 순수 SE 없음.


### [batch_23] a. 순수 SE (LPSCl · 황화물) 의 압력별 기공 곡선 · 진밀도 · 질량 기준 · 누른 채 / 뺀 뒤

이 배치에 없음 (순수 SE 의 압력별 기공 곡선 · LPSCl 진밀도를 준 카드 없음). 관련만:
- [a] jun2026_ppma_econductive_binder_si_lowpressure_assb | 상용 LPSCl (POSCO JK · σ 4.2 mS/cm @30 °C · Ti / SE / Ti AC) 150 mg → ~700 µm 펠릿 70 MPa (13 mm PEEK 몰드) → 전극 · 음극을 얹어 전체 370 MPa 압착 — 펠릿 밀도 · 기공은 카드에 기록 없음 | §6 L98 · §5 L89 | 표지 없음 | 곡선 아님 · 370 MPa 뒤 두께 없음 · 진밀도 없음
- [a] kawaguchi2023_doe_electrode_fabrication_dry_coated_ncm_lps | Li₃PS₄ 분리막 80 mg (다이 10.1 mm) 를 40 MPa · 5 s 예비 압축 → 복합 양극과 함께 P 180 / 360 MPa · 300 s 로 다시 압축 — 두께 · 기공 측정 없음 · 카드 어림 (밀도 1.9 g/cm³ · 완전 치밀 가정) ≈0.53 mm | §3-2 L73 · §8-5 L260 · §10-3 L270 | [추정] (가정 포함) | Li₃PS₄ (LPSCl 아님) · 1.9 g/cm³ 는 카드 가정 (원문에 밀도 없음) · 측정값 아님
- [a] kawaguchi2017_dry_coating_parametric_na2so4_model_se | 'room-temperature pressure sintering' = 황화물 SE 가 상온에서 눌리기만 해도 변형 · 합체해 입계 · 공극이 거의 사라지는 성질 (ref 16 Sakuda 2013 을 근거로 듦) · 값 없음 | §4-3 L140 · §3-1 L62 | 카드 용어집 (ref 16) | 정성 · 모델 물질 선정 근거로 쓰인 서술
- jeong2025 · kang2025 · kang2026 · kim2026: SE 없음 (액체 LIB · SiO₂ 모형).


### [batch_24] a. 순수 SE (LPSCl · 황화물) 의 압력별 기공 곡선 · 진밀도 · 질량 기준 · 누른 채 / 뺀 뒤

곡선은 이 배치에 없음. 한 점과 관련만:
- [a] lee2024_shear_force_dry_process_cathode_coverage | 순수 LPSCl 펠릿 한 점: 32 mg · ⌀6 mm PEEK · 1 TON 3 min (= 347 MPa) · 두께 725.0 µm · R 304.9 Ω · σ 0.8 mS/cm (25 °C) → 밀도 1.56 g/cm³ (질량 ÷ 기하 부피 = 질량 기준) · 결정밀도 1.86 g/cm³ (이 논문 밖 값 = 다른 카드 `lee2026_unveiling_ptfe_dry_electrode_digital_twin` 의 SI p.17 값) 기준 상대밀도 ≈84 % (공극 ≈16 %) | §3-9 L204–206 · §3-10 L213 · SI S12 · 본문 p.8 식 1 | [인쇄] (질량 · 두께 · 저항 · σ) · [우리 산술] (압력 · 밀도 · 상대밀도) | 한 압력 한 점 · 두께는 "EIS 뒤 측정" (누른 채 / 뺀 뒤 명시 없음) · 1 TON = 1000 kgf 가정 · **랩 표준과 다른 문헌 값** (진밀도 1.86 ↔ 랩 1.64 g/cm³ · 공극 ≈16 % ↔ 랩 10–13 %)
- [a] lee2025_corolling_dryprocess_lpscl_ptfe | 순수 LPSCl 펠릿 σ_ion pristine 2.19 → 볼밀 1.64 mS/cm · σ_e 5.0×10⁻⁴ → 3.3×10⁻⁴ mS/cm — 펠릿 성형 압력 · 밀도 · 기공은 카드에 없음 | §3 L38–39 · Supp Fig 4e,f | stated | 기공값 없음 · 성형 조건 카드에 없음
- koo2025 · koo2026 · lee2025_dual · lee2026: SE 없음 (액체 LIB).


### [batch_25] a. 순수 SE (LPSCl · 황화물) 의 압력별 기공 곡선 · 진밀도 · 질량 기준 · 누른 채 / 뺀 뒤

이 배치에 없음 (순수 SE 의 압력별 기공 곡선 · LPSCl 진밀도를 준 카드 없음). 관련만:
- [a] mun2025_dry_electrode_technology_assb_review | 황화물 SE 막 기공률 습식 (슬러리) 22.0 % → 건식 (dry-shearing) 10.2 % — 압력 · 막 조성 · 진밀도 카드에 없음 · 측정법 = 단면 SEM 문턱 분할 (질량 기준 아님) · 누른 채 / 뺀 뒤 카드에 없음 · 22.0 % 는 랩 표준과 다른 문헌 값 | §3a L41 · §6 L141 · Fig 4f · 원전 ref [59] | 리뷰 인용 stated (2 차) | 압력 곡선 아님 · SE 막 (복합 양극 압밀 아님 L246) · 원전 [59] 확인 전
- [a] liu2025_dry_processing_high_energy_li_batteries_review | 산화물 LLZAO 62 MPa · 900 / 1000 / 1100 °C 소결 → 상대밀도 86 / 97 / 99 % · 리뷰 서술 "황화물은 냉간가압만으로 치밀화" (값 없음) | §3 (라) L86 | 2 차 인용 · 표지 없음 | 산화물 · 고온 소결 (황화물 SE 아님) · 압력 곡선 아님
- [a] liu2025_dry_processing_high_energy_li_batteries_review | ASSB SE 막 Table 2 = 두께 · σ 만 (기공 없음): LPSCl PTFE 0.5 % · 15–20 µm · PTFE 0.2 % · 40 µm 등 | §3 (가) L41–50 | 2 차 인용 stated | 기공 값 없음
- lippke2023 · lischka2025 · meng2026: SE 없음.


### [batch_26] a. 순수 SE 압력별 기공 곡선 · 진밀도

이 배치에 없음.
- (가까운 것) [a] park2026_thiolene_sbr_binder_assb | 순수 LPSCl 분리층 펠릿을 370 MPa 로 성형 · Li⁺ 차단 대칭셀 σ 측정 조건도 370 MPa (기공률 · 진밀도 값 없음) | §2.4 줄 156 · 159 (p.9–10) | 표지 없음 | 기공 곡선 아님 · 압력 한 점


### [batch_27] a. 순수 SE 압력별 기공 곡선 · 진밀도

이 배치에 없음 — 순수 SE (LPSCl · 황화물) 의 압력별 기공 곡선을 가진 카드가 없다.  참고 (곡선 아님 · 카드가 쓴 밀도 값):
- [a] schmitt2026_chemomech_stability_dry_cathode_separator_sheets | 순수 LPSCl 분리막은 σ_ion 만 (2.35 · 2.04 · 1.82 mS/cm @200 MPa · PTFE 0 · 0.5 · 1 wt%) · 기공 · 밀도 측정 없음; 카드 부피 환산은 ρ_SE 1.9 g/cm³ (Hippauf 2019 SI 식 S1 값) 를 주로, 1.64 를 대안으로 씀 | §3-1 줄 69 · §3-3 줄 86–95 · p.2 · p.7 | [인쇄] · [우리 산술] | 1.9 = 랩 표준과 다른 문헌 값 · 기공 곡선 아님
- [a] wang2026_dryprocess_thick_cathode_failure_ncm94 | 분리막 펠릿 (Li₅.₄PS₄.₄Cl₁.₆ 60 mg · 0.5 t ≈62 MPa) 기공 측정 없음 · 분리막 σ_ion ≈4.3–5.4 mS/cm 는 펠릿 밀도 1.5–1.9 g/cm³ 가정으로 R_s 에서 유도 · 복합막 ε 유도에 ρ_SE 1.64–2.0 범위 사용 | §2.2 줄 89 · §2.3 줄 116 · 125 | DERIVED(ours) · ASSUMED | Cl-rich (LPSCl 아님) · 곡선 아님
- [a] wolf2026_extruder_vs_batch_mixing_core_shell_dry_sulfide_cathode | 카드 산술이 LPSCl 1.86 g/cm³ (가정) 로 이론밀도 ≈3.70 g/cm³ · φ_SE 고체 기준 ≈31 vol% 를 냄 · 껍질 두께 산술은 1.64–1.86 범위 | §2 줄 54 · §3-3 줄 104 | [우리 산술] · 가정 | 1.86 = 랩 표준 (1.64) 과 다른 값 · 순수 SE 측정 없음
- [a] bucci2017_chemomech_failure_assb_cycling_czm | Table 1 문헌 survey: Li₂S–P₂S₅ 냉간 압축 (소결 180–360 MPa · RT) E 14–17 GPa · 열간 (360 MPa · 20–190 °C) 18–25 GPa — 처리 압력별 영률이지 기공 아님 | §3.2 줄 100–101 | stated (ref 15) | 유리 황화물 · 기공 · 밀도 값 없음


### [batch_28] a. 순수 SE 압력별 기공 곡선 · 진밀도

이 배치에 없음 (순수 SE 압력별 기공 곡선 · 진밀도 값 0 건 — 7 장 전수 검색).
- (가까운 것) [a] interfacial_impedance_formulation_assb_cathode | 순수 SE 펠릿 (300 MPa) 은 이온 저항만: r_i,bulk 178 · r_i,gb 631 Ω·cm · E_a 0.33 eV (기공 값 없음) | §3 줄 83–86 (Fig 2a–d) | stated | Cl-rich Li₅.₇₅PS₄.₇₅Cl₁.₂₅ · 압력 한 점
- (가까운 것) [a] interfacial_impedance_formulation_assb_cathode | SE 부피분율 ε_i = 1.0 셀의 eps_pore 0.16 · 정의 = (펠릿 부피 − 성분 부피)/펠릿 부피 (FIB 단면 · 뺀 뒤) — 카드는 '복합셀' 로 표기 · 그 스윕의 성형 압력 카드에 없음 · 진밀도 값 없음 · 순수 SE 라면 랩 표준 (10–13 %) 과 다른 문헌 값 | §3 줄 94 · §5.2 줄 205 · §7 줄 281 | stated | 순수 SE 인지 카드에서 분명하지 않음 · 같은 ε_i 의 r_i 가 카드 안에서 두 값 (카드 문제)


### [batch_29] a. 순수 SE (LPSCl · 황화물) 의 압력별 기공 곡선 · 진밀도 · 질량 기준 · 누른 채 / 뺀 뒤

- [a] so2021_dem_fabrication_degradation_ductile_particles | LPS 유리 (75Li₂S·25P₂S₅ · 아지로다이트 아님) SE-only 2D DEM 상대밀도 곡선: 초기 ≈0.30 → 0.62 (50 MPa) → 0.70 (74) → 0.74 (100) → 0.83 (200) → 0.90 (360) → 0.95 (500) · α = 0.65 · Sakuda 2013 실험점 (open circle) 과 200–500 MPa 에서 일치 · <200 MPa 에서 모델 > 실험 (과치밀) | §3.2 L77–78 · Fig 4a · §5.4 L194 | digitized (곡선) · stated (일치 · 과치밀 서술) | 재료 다름 · 2D (z 두께 = 평균 SE 지름 · 국소 부피 = 2D Voronoi L244) · 진밀도 값 · 질량 기준 여부 · 누른 채인지 뺀 뒤인지 카드에 없음 (제하 springback 은 Fig 3b 에 따로) · Sakuda 실험점의 측정 상태 카드에 없음
- [a] tron2023_lpscl_ccd_ambient_pressure | NEI "fine" Li₆PS₅Cl 순수 펠릿 한 점: ≈100 mg · ⌀10 mm 경화강 다이 · ≈50 MPa 수 초 → 360 MPa 2 분 → 1.55–1.60 g/cm³ · 두께 "around 0.80 mm" (p.4) · "0.85–0.80 mm" (p.6) · 공극은 저자가 계산하지 않음 | §0 ② L27 · §3-1 L54–58 · PDF p.3 · p.4 · p.6 | [인쇄] | 밀도 측정법 (질량/부피? 몇 개?) [미확인] L56 · 두께를 잰 상태 (다이 안 / 놓은 뒤 / 꺼낸 뒤) [미확인] L27 · L58 · 온도 미기재 · 분말 입경 [미확인] · 다압력 없음 L254 · SI 미입수
- [a] tron2023_lpscl_ccd_ambient_pressure | 공극 (카드 산술): 1.64 (랩 표준) 기준 2.4 % (ρ 1.600) · 5.5 % (1.550) · 두께 역산 3.0–8.7 % — **360 MPa 값이라 랩 표준 (300 MPa · 10–13 %) 과 다른 문헌 값** · 1.86 (랩 표준과 다른 문헌 진밀도) 기준 14.0–16.7 % · 두께 역산 14.4–19.5 % · 두 기준 차 11.2–11.5 %p | §3-3 L87–98 | [우리 산술] | 식 ε = 1 − ρ/ρ_s = 질량 보존 연산자 (L87 · L243) · 질량 ±5 mg 감도 (L95)
- [a] tron2023_lpscl_ccd_ambient_pressure | 진밀도: 논문 p.3 의 "결정학 밀도" 문장 (ref 22 = Doux 2020 하나에 기댐 · 측정도 계산도 아님) 은 카드 L84 에서 **진밀도 근거로 인용 금지 표지** (값은 랩 표준 진밀도와 같은 수 · 숫자 옮기지 않음). 카드가 적은 다른 값 = **랩 표준과 다른 문헌 값**: 인용 문헌 Doux 2020 의 이론밀도 1.860 · 결정학 계산 1.860 (a 9.8591 Å, Z 4) · 피크노미터 1.874 (Ohno 랩 D) · 같은 상품명 NEI "fine" 진밀도 인쇄값 1.87 (Frankenberg 2025) | §0 ① L26 · §3-2 L64–84 | [정본 카드] · [우리 산술] · [인쇄] | Doux 원문 PDF 는 카드 작업에서 미대조 (L32 ②) · 로트가 다를 수 있음 (L79) · 1.64 의 출처는 [미확인] (L82)
- [a] tron2023_lpscl_ccd_ambient_pressure | 같은 압력대 다른 순수 LPSCl 펠릿 (정본 카드 경유): Doux 2020 (같은 NEI 분말 · 200 mg · ⌀13 mm · 370 MPa) 1.492–1.579 g/cm³ (이론 1.860 기준 상대밀도 80.3–84.9 %) · Ohno 랩 B (다른 분말 · 375 MPa · ⌀10 · 100 mg · 0.795 mm) 1.60 g/cm³ · Ohno 랩 C 1.77 (370 MPa) · G 1.70 (441 MPa) · D 1.655 (720 MPa) | §3-2 L67 · L80 · §3-3 L101 | [정본 카드] | 이 카드에서 원문 미대조 · 측정 상태 카드에 없음 · 다른 분말
- [a] li2026_electrochemomechanical_coupling_asslmb_review | 순수 LPSCl 펠릿 한 점 (리뷰 표 3 의 LPSCl 행이 song2025 값과 같다는 카드 대조): 기공 13 % · 360 MPa 냉간 · ⌀≈1 µm 입자 · mm 시편 | §3-2 L61 | [우리 대조] | 리뷰는 다공 · 측정 부류를 표시하지 않음 · 진밀도 기준 · 누른 채 / 뺀 뒤 카드에 없음 · 2 차 인용
- 나머지 여섯 카드 (kim2025 · lee2026 · sedlatschek2026 · siroma2015 · spencerjolly2023 · tabakovic2026): 순수 SE 기공 없음 (예: kim2025 L88–92 "porosity · 상대밀도 n/a").


### [batch_30] a — 순수 SE 압력별 기공 곡선 · 진밀도

- [a] 이 배치에 없음 — 순수 SE 의 압력별 기공 곡선을 가진 카드는 없다.
- [a] yun2023_deciphering_degradation_halide_vs_sulfide | 순수 SE 펠릿 (LPSCl · LIC) 을 250 MPa 로 누른 채 240 h 동안 σ 만 잼 — 기공 · 상대밀도 · Heckel 은 n/a | §3.2 · §3.5 (줄 141–150 · 176–183) · Fig 4a,b | stated | 기공 곡선 아님
- [a] lee2023_sicspe_digitaltwin_assb | LPSCl 밀도 2.07 g/cm³ (GeoDict 구조 생성 입력) — 랩 표준과 다른 문헌 값 | §2.3 (줄 99) | 표지 없음 | 입력값 · 곡선 없음
- [a] park2020_digitaltwin_assb_foundational | LPSCl 재료 밀도 2.07 g/cm³ — 랩 표준과 다른 문헌 값 | §2 (줄 186 · 논문 p.8) | 표지 없음 | 곡선 · 압력 sweep 없음


### [batch_31] a — 순수 SE 압력별 기공 곡선 · 진밀도

- [a] 이 배치에 없음 — 순수 SE (LPSCl · 황화물) 의 압력별 기공 곡선을 가진 카드는 없다.
- [a] aminchiang2016_nmc_electronic_ionic_transport_vs_li | (참고 · SE 아님) NMC333 · NMC532 분말을 340 MPa 로 눌러 900 °C 12 h 소결한 펠릿 상대밀도 96–98 % — 소결 뒤 값 · 압력별 곡선 아님 | §4-1 (줄 185–188) | 표지 없음 (카드 서술) | AM 단상 · 소결 (냉간 압밀 아님)
- [a] chandratilleke2012_particle_scale_mixing_index | 카드 §3-9 ⑥ 의 질량비 계산에 쓴 SE 밀도 2.0 (우리 믹서 덱 생성기 `DENS` 값 · 단위 카드에 없음) — 랩 표준 (LPSCl 진밀도 1.64 g/cm³) 과 다른 값 | §3-9 ⑥ (줄 178) | [우리 산술] | 기공 곡선 아님 · 믹서 질량비 산술용


### [batch_32] a — 순수 SE 압력별 기공 곡선 · 진밀도

- [a] 이 배치에 없음 — 순수 SE (LPSCl · 황화물) 의 압력별 기공 곡선을 가진 카드는 없다.
- [a] endo2001_vgcf_basic_properties_battery_applications | (SE 아님) 흑연화 VGCF 순수 압분체의 부피밀도 0.13–2.0 g/cm³ (진밀도 2.1 의 0.06–0.94) 별 저항률 곡선만 · 진밀도 흑연화 2.1 · 탄화 1.9 g/cm³ (pycnometer) | Table 1 (p.1289) · Fig. 8 · 카드 §3-2 · §3-3 (줄 119–133 · 145–157) | stated (진밀도) · figure-read ≈ (곡선) | 섬유 · 압력값 없음 · 기공 곡선 아님
- [a] huang2025_dem_lbm_heat_conduction_composite_cathode | (산화물 SE) LLZO 밀도 5.11 · LCO 5.06 g/cm³ (Table 1) — 순수 SE 압축 곡선 없음 | §3 (줄 29–30) | stated | 산화물 · LPSCl 아님
- [a] grey1969_hausner_ratio_metal_powders | (SE 아님) 구리 분말 겉보기 · 탭 부피 (예: 9.2 → 7.3 cc · 탭 250 회) 만 | Table 1 (p.324 · 줄 97–108) | [인쇄] | 탭 다짐 · 압축 아님 · 시료 질량 미기재


### [batch_33] a — 순수 SE 압력별 기공 곡선

이 배치에 없음.  참고 두 줄:

- [a] kaiser2018 | 순수 SE 펠릿은 σ₀ 측정용 한 압력뿐: Li₇P₂S₈I 유리 6 mm 펠릿 276 MPa · 30 min · RT 압축 · 25 °C 측정 · 기공 · 밀도 미보고 | §3-1 · p.178 | stated · 측정 시 압력 [미확인] | LPSI 유리 ≠ LPSCl
- [a] jung2019 | 진밀도: 7:2 w/w → vol% 환산에 다른 카드의 LPSCl 밀도 1.87 (Minnmann 카드) · 2.07 g/cm³ (Park 2020 카드) 를 넣어 SE 41.5 · 38.0 vol% (고체 기준) = 랩 표준과 다른 문헌 값 | §3-1 (카드 줄 78) · §10 (줄 405) | 파생 | 그 논문 재료의 밀도는 미기재 · 기공 곡선 아님


### [batch_34] a — 순수 SE 압력별 기공 곡선

- [a] minnmann2022_designing_cathodes_solidstate | 곡선 없음 (설계 Perspective · 기공 수치 0 개). 카드가 출처 정정 맥락에서 남의 값 둘을 적음: ① Sakuda 2013 의 75Li₂S-25P₂S₅ 유리 cold-press 밀도 87 % @ 300 MPa (= 기공 13 %) · σ 회복 91 % ② "순수 SE ~10 % @ 300 MPa" = 우리 MPM/DEM 보정 수렴값 → 10-03 정정에서 출처 [미확인] · 외부 앵커 없음 | §0 L49–55 · §6 L294–295 · L434 | 표지 없음 (출처 정정표) · L434 = 10-03 정정 표지 | 2 차 인용 · 곡선 · 진밀도 · 질량 기준 여부 · 누른 채인지 뺀 뒤인지 모두 카드에 없음 · ①은 유리 (LPSCl 아님 · 정본 카드 sakuda2013_sulfide_mechanical_property 있음) · ②는 실험값 아님 (카드 문제 2 · 3)


### [batch_35] a — 순수 SE 압력별 기공 곡선

- [a] otani2023_ionic_conductivity_path_resistance_separation_model | 순수 LPSCl 층 공극–σ 곡선 (공극 3.0–41 % · 예 3.0 % 1.71 · 19.1 % 0.92 · 29.0 % 0.46 · 40.8–41.0 % 0.24–0.28 ×10⁻³ S/cm) — 같은 층을 0.4 → 6.0 tf/cm² (≈39–588 MPa) 로 재가압한 열이지만 **압력 ↔ 공극 짝은 카드에 없음**.  진밀도 = 공급처 재료 밀도 1.8 g/cm³ (랩 표준과 다른 문헌 값) · 공극률 = 두께 + 재료 밀도 (질량 언급은 카드에 없음) · 두께 = 구속 상태 (누른 채) | §3-1 (줄 58 · 60 · 61) · §3-3 (줄 80) · p.2 · p.4 · Fig 4 | [인쇄] (방법 · 밀도) · [판독] (점) · [우리 산술] (MPa 환산) | Mitsui LPSCl x≈1 · D50 0.7 µm · 측정 압력 · 온도 [미확인] · 압력 열과 공극이 함께 변함 · 데이터 기밀
- 그 밖 여섯 장: 이 배치에 없음 (oh2026 의 500 MPa·90 s 펠릿은 SiOx 분말 접촉각용 · 기공 미보고).


### [batch_36] a — 순수 SE 압력별 기공 곡선

이 배치에 없음.

- (참고) wang2018 의 SPS 치밀화 (800 °C · 일축 40 MPa · 5 min → 상대밀도 > 98 % · 줄 33 · 103 · 178) 는 산화물 AM 단상 소결 한 조건이다 — SE 냉간 압밀 곡선이 아니다.
- (참고) zhang2023 줄 413 이 "Minnmann pure-SE porosity 10 %@300 MPa" 를 우리 쪽 외부 앵커로 적었다 — 철회된 출처라 근거로 옮기지 않는다 (카드 문제 3).


### [batch_37] a — 순수 SE 압력별 기공 곡선

압력별 곡선 = 0.  한 상태의 점만 있다.

- [a] cao2026_dual_binder_18um_sulfide_electrolyte_film | (순수 SE 가루가 아니라 LPSCl + 바인더 건식막) MIP 겉보기 기공률: LPSCl-PTFE 1 wt% 전구막 (100 °C 롤압) 34.99 % · D50 630.0 nm → 이중 바인더 USF (전구막 : LiTFSI-PMEMA = 96:4 · 접기 + 100 °C 열압연 40 회 · 18 µm) 14.36 % · D50 150.0 nm · 거대기공 (≥500 nm) 비율 ≈56 → ≈15 %.  롤 압력 값 없음 → 압력–기공 짝 없음.  잰 상태 = 뺀 뒤 (자립막 ⌀10 mm 원판 총 ≈1.5 g · 대기 노출 <1 min).  진밀도: 논문 값 없음 — 카드의 부피 산수는 LPSCl 1.86 g/cm³ 를 가정 (랩 표준과 다른 문헌 값) · 질량 기준 아님 (Hg 침투량) | §3a 줄 69–79 · §4e 줄 175 · 본문 p.4 · Fig. 1e,f · Fig. S8 | 본문 값 (표지 없음) · figure-read (거대기공 비율) · (우리 산수) (부피) | 바인더 막 · 저자 명명 *"apparent Hg-accessible porosity"* · 연성막은 Hg 압력에 눌려 겉보기 값이 됨 (카드 §15 줄 529) · 순수 LPSCl 펠릿 (80 mg · 100 MPa 1 min · §4d 줄 172) 의 기공 · 두께는 없음
- [a] calpa2019_small_li7p3s11_liquid_phase_composite_cathode | 순수 Li₇P₃S₁₁ (LPSCl 아님) 펠릿 80 mg · ⌀10 mm · 360 MPa 실온 한 점 — 두께 · 밀도는 논문에 없음.  카드 산술: Nyquist 절편 비 R_LP/R_BM ≈3.1–3.2 ↔ σ 비 1.9 → 두께 비 L_LP/L_BM ≈1.6–1.7 (L ≈ σ·R·A: BM ≈0.054 cm · LP ≈0.090 cm) → 액상법 소립 (≈500 nm) 펠릿의 겉보기 밀도가 볼밀 대립 (>10 µm) 의 ≈0.6 배 | §3b 줄 71–77 · p.474–475 · Fig. 3 | stated (조건 · σ) · 판독 ≈ (절편 · 500 dpi) · 우리 산수 · [추정] (밀도 함의) | 다른 재료 · 판독 의존 · 누른 채 / 뺀 뒤 미기재 · 진밀도 · 질량 기준 여부 카드에 없음 · 카드는 "순수 SE 는 작을수록 덜 치밀할 수 있다 (faka2026)" 의 보조 단서로만 쓰라고 적음 (§7b 줄 198)
- [a] famprikis2019_fundamentals_inorganic_sse | 곡선 · 수치 없음.  정성 문장만: *"For both oxide⁵⁵ and sulfides⁵⁸, a decrease in porosity has been correlated with increased conductivity as a result of stronger grain–grain or particle–particle contact."* (ref 58 = Sakuda 2013 — litdb 카드 있음) | §5.2(c) 줄 203 · §4.4 줄 128 | 소환값 (2차 인용 · 정성) | 카드: 기공률 · 상대밀도 · 성형압 · 입경 수치 0 건 (줄 135)
- [a] cronk2026_lis_cathode_interphase_chemistry | 새로 더할 것 하나: 같은 프로토콜 펠릿들의 역산 두께 0.39–0.55 mm (L = σ·R·A · A 0.785 cm²) — 질량이 없어 밀도 · 기공은 못 냄 (분리막 375 MPa 3 min → 450–500 µm 는 배치 15 에 있음) | §7 줄 136–143 · §3 줄 79 | digest 계산 | Li–S 복합체 · σ 측정은 Ti|SSE|Ti 75 MPa 아래 (누른 채)
- alharbi2026: 무관.


### [batch_38] a — 순수 SE 압력별 기공 곡선

압력별 기공 곡선 = 0.  순수 LPSCl 펠릿 한 점씩 둘 (둘 다 밀도 · 기공을 저자가 보고하지 않음).

- [a] tron2023_rational_cathode_composite_optimization_lpscl | 순수 Li₆PS₅Cl 두 분말 (lp = NEI 수십 µm 응집체 · sp = Solvay 수 µm 이하 · 입도 수치 없음) 펠릿: ⌀16 mm · ≈350 mg · 300 MPa → ≈1000 µm · EIS 를 0 → 300 MPa 로 올리며 측정 (Fig. S2 — SI 미수령) · σ 둘 다 ≈2 × 10⁻³ S/cm (*"similar"*).  기공 · 밀도 값 없음 (카드도 이 조수도 계산하지 않음) · 진밀도 · 질량 기준 여부 카드에 없음 · σ 는 가압 중 측정이고 두께 ≈1000 µm 가 누른 채인지 뺀 뒤인지는 미기재.  전해질 필름 (NBR 바인더) 은 300 MPa 압착 뒤 ≈100 µm · σ ≈1 × 10⁻³ S/cm | §3b 줄 71–75 · §3c 줄 82 · p.2 · p.4–5 | stated | 값이 모두 "≈" · 압력별 σ 곡선은 SI (못 봄) · 볼밀 lp 의 σ 는 미보고 · 쓰려면 질량 ÷ 부피가 랩 표준 진밀도 아래인지부터 확인 (카드 문제 3)
- [a] liu2024_sc_ni90_sulfur_coating_sulfide_assb | 순수 LPSC (자체 합성 · 볼밀 50 h → 550 °C 10 h) 펠릿 80 mg · 두께 0.05 cm · 0.785 cm² · 14.5 Ω → 4.4 mS/cm (RT).  카드 산술: 80 mg / (0.785 × 0.05 cm³) = 2.04 g/cm³ > 문헌 결정밀도 1.860 (랩 표준과 다른 문헌 값) → 두께 0.05 cm 는 반올림값 (80 mg 이면 ≥0.0548 cm · 그 두께면 σ ≥4.8 mS/cm).  성형압: 셀 조립은 SE 80 mg @ 250 MPa → 전극 얹고 1000 MPa 2 min (σ 펠릿의 성형압 · 측정 상태는 카드에 따로 없음) | §3-1 줄 57–62 · §10-5 줄 244 · p.7 · SI Fig. S3 | [인쇄] (값) · [우리 산술] (밀도 · 두께 하한) | 한 점 · 압력별 곡선 아님 · 밀도 기록이 물리 한계를 넘는 사례 (기공 값으로 쓸 수 없음)
- kim2012 · yuan2026: 없음.  he2018 · kim2026: 무관.


### [batch_39] a. 순수 SE (LPSCl · 황화물) 압력별 기공 곡선 · 진밀도

이 배치에 없음 (기공 · 밀도 · 압력 값이 카드에 없음). 관련만:
- [a] choi2026_bzox_dry_zro2x_nmc_shell_coating | "사이클 전엔 3 종 모두 저저항 (냉압 접촉 양호)" — 냉간 가압으로 셀을 만들었다는 흔적 한 줄뿐 | §3.4 L61 | 표지 없음 (카드 풀이) | 압력 값 · 누른 채 / 뺀 뒤 · 진밀도 카드에 없음


### [batch_40] a — 순수 SE 압력별 기공 곡선

이 배치에 없음 (황화물 · 기공 · 압력 하중이 논문에 없음).


### [layer3] a. 순수 SE (LPSCl · 황화물) 압력별 기공 곡선 · 진밀도

비교 문서가 주는 순수 SE 자료는 "한 압력의 한 점" 이 대부분이고 압력별 곡선은 카드 쪽에 있는 것으로 보인다 (비교 문서가 Miss 의 Table S2 전 범위 · Faka 의 입경별 값 · Lee 2025 의 Heckel 적합 · Thompson · Sakuda Fig 2a 곡선을 언급). 비교 문서가 덧붙이는 것은 진밀도 · 다이 안 / 밖 규약에 따라 같은 펠릿의 공극이 얼마나 달라지는가이다.

- [a] miss2026_insitu_conductivity_porosity_pressure_compaction | 순수 SE (µc-Li₅.₅PS₄.₅Cl₁.₅ 단일상 펠릿) 300 MPa 공극 = 가압 중 7.1–7.6 % · 같은 다이에서 놓은 뒤 8.6 % | §A L111 (장치 L106) | "재계산 — 본문 미인쇄" | Li₅.₅PS₄.₅Cl₁.₅ ≠ Li₆PS₅Cl · 단계 하중 (매 단계 110 kPa 로 놓았다 다시) · 피스톤 압축만 교정 · 다이 반경 순응 · 벽 마찰 [미확인] · 진밀도 · 질량 기준 여부 이 줄에 없음 · 랩 표준 (10–13 %) 과 다른 문헌 값 · 비교 문서는 원장 CL-94 의 빈 외부 앵커 "후보" 라고만 적음 (원장 미수정)
- [a] miss2026_insitu_conductivity_porosity_pressure_compaction | (ps45 실험 공극 계산의 손잡이) SE 진밀도 2.0 → 1.87 로 바꾸면 공극이 −1.7…−1.9 %p 따로 움직인다 → 스프링백과 함께 "미측정 손잡이 둘 = 비식별" | §A L110 | 표지 없음 (stoic-knuth 판정문 §3 을 가리킴) | 두 진밀도 값이 어느 재료 · 어느 출처인지 이 줄에 없음 · 랩 표준 진밀도 (1.64) 와 다른 값
- [a] ohno2020_interlab_ionic_conductivity_argyrodite | 같은 배치 Li₆PS₅Cl 을 6 랩이 성형압 275–441 MPa 로 → 상대밀도 81–95 % (86.7 ± 5.3 %) = 공극 13.3 ± 5.3 % · 성형압과 단조 아님 (C 370 MPa → 95 % · D 720 → 89 % · H 1000–2000 → 79–83 %) · 기하밀도 오차 사례 (C 의 시료 4 = 101 %) | §A L349–353 (카드 §3.8) | "DERIVED" (평균 ± 폭) · 상대밀도 = SI 의 blue 값 (주관 그룹 계산) | SI 만 digest · 성형 유지시간 · 금형 등 프로토콜 미보고 · n = 6 · 누른 채 / 뺀 뒤 구분 이 줄에 없음 · 랩 표준과 다른 문헌 값 (폭은 겹침) · 비교 문서: 순수 SE 앵커를 점이 아니라 ± 5 %p 밴드로 다룰 근거
- [a] doux2020_stack_pressure_assb | LPSCl 펠릿 공극 18 % (상대밀도 82.1 % · Table S2 80.3–84.9 %) @ 370 MPa 냉간가압 | §A L386–390 | 표지 없음 | 한 압력 점 (곡선 아님) · 진밀도 · 누른 채 여부 이 줄에 없음 · 랩 표준과 다른 문헌 값 · 비교 문서는 이 값을 "강체 구 ~20 % floor 확증" 으로 읽음 (같은 문서 L349–353 의 Ohno 폭 81–95 % 와 나란히 보면 한 랩의 한 점)
- [a] sakuda2013_sulfide_mechanical_property | 75Li₂S·25P₂S₅ 유리 냉간가압: 본문 stated = ">90 % @ over 350 MPa" (공극 < 10 %) 뿐 · "87 % @ 300 MPa (공극 13 %)" 는 Fig 2a 곡선의 digitized 추세값 (본문에 300 MPa 정밀값 없음) | §A L426–429 | stated / digitized (TREND) | 유리 (≠ LPSCl) · 누른 채 / 뺀 뒤 · 진밀도 이 줄에 없음
- [a] sakuda2013_sulfide_mechanical_property + minnmann2021_jes_charge_transport_bottlenecks + doux2020_stack_pressure_assb | (묶음) "three-way agreement" 재서술: DEM (LPSCl 300 MPa ~10 / 15.6 %) ↔ Minnmann 2021 (NCM622 + LPSCl 복합 · 380 MPa · 13–17 %) ↔ Sakuda (유리 · stated > 90 % @ > 350 MPa) = "황화물-유리계가 수백 MPa 냉간가압에서 porosity ~10–17 % 로 치밀화" 라는 거동 (추세) 의 정합이지 같은 소재 · 같은 압력의 일치가 아님 · 절대 porosity 정밀값은 "LPSCl 쪽 Minnmann / Doux / 우리 DEM 소유" | §A L433–436 | 표지 없음 | Minnmann 값은 복합 양극 (L339–340 이 스스로 "pure-SE 아님") · 순수 SE 곡선은 이 묶음 어디에도 없음
- [a] famprikis2019_fundamentals_inorganic_sse + sakuda2013_sulfide_mechanical_property | (묶음) 황화물 · 보로하이드라이드는 연질이라 상온 가압만으로 치밀화 (Sakuda: room-temperature pressure sintering · Fig 2b → d 입계 소멸 · Fig 3 입자 유합) · 산화물은 1000 ℃+ 소결 필요 — 기공률 · 상대밀도 · 성형압 수치는 Famprikis 리뷰에 없음 | §A L302 · L308 · L422–425 | 표지 없음 | 정성 (곡선 아님)
- [a] tron2023_lpscl_ccd_ambient_pressure + beutl2024_round_robin_coin_cell_sulfide_assb + wang2024_hot_pressed_lpscl_pressure_invariant_conductivity + larson2025_hot_pressing_argyrodite_low_stack_pressure_conductivity | (묶음 "LPSCl 진밀도 1.64 계보") 비교 문서 판정: 1.64 는 결정학 밀도가 아니다 — 결정학 산술 (Z = 4 · a ≈ 9.86 Å) 은 1.86 · Tron 2023 은 "crystallographic density of 1.64" 를 Doux 2020 에 귀속 (Doux 카드의 TD 는 1.860) · Beutl 2024 는 1.64 를 Zhou 2019 · Tron 2023 에 귀속 (측정 없음) · Wang 2024 는 인용 없이 쓰고 자기 펠릿 1.66 · 1.69 가 그 값을 넘음 (101–103 %) · Larson 2025 는 1.83 (XRD 계산 주장 · 인용원 Ohno SI 와 자기 XRD 판독은 1.86) 을 쓰고 문헌의 1.63 을 "DFT 유래 · SEM 잔류 공극과 안 맞음" 으로 지목 (그 펠릿에 1.64 를 대면 공극 −6.6 %) | §A L936–937 | 1.86 = [우리 산술] · 나머지 표지 없음 (카드 인용) | 랩 표준 진밀도 1.64 는 고정 — 1.86 · 1.83 · 1.63 은 "랩 표준과 다른 문헌 값" · 네 편 모두 다압력 점 없음 (성형압 하나)
- [a] larson2025_hot_pressing_argyrodite_low_stack_pressure_conductivity + wang2024_hot_pressed_lpscl_pressure_invariant_conductivity + beutl2024_round_robin_coin_cell_sulfide_assb + tron2023_lpscl_ccd_ambient_pressure | (묶음) 같은 조건 외부 점 (300–360 MPa · 냉간 · 다이 밖) 의 순수 LPSCl 공극, 1.64 기준 → 1.86 기준: Larson 300 MPa 2.4 → 14.0 % · Wang 300 MPa 13.5 → 23.8 % · Beutl 360 MPa 2.4–9.1 → 14.0–19.9 % · Tron 360 MPa ≈ 2–9 → 14–20 % · 진밀도 선택이 공극을 ≈ 11 %p 옮김 (표적 창 10–13 % 폭 3 %p 의 ≈ 4 배) · 1.64 기준 10–13 % = 겉보기 밀도 1.43–1.48 g/cm³ = 결정학 기준 21–23 % | §A L938 | [카드 산술] | 뺀 뒤 (다이 밖) 값 · 압력별 곡선 아님 (한 점씩) · 랩 표준 (10–13 % · 1.64) 은 고정 — 1.86 기준 값은 "랩 표준과 다른 문헌 값" · 비교 문서: CL-94 는 "후보 보류 그대로 · 이 묶음은 분모의 근거이지 표적 값을 새로 정하지 않는다" (L939)
- [a] faka2026_particle_size_consolidation_strain_lpscl + lee2025_heckel_argyrodite_powder_densification_nanoindentation | (묶음) 순수 황화물 SE 가압 중 (in-die) 300 MPa 공극 ≈ 13–26 % — Faka: 입경 40 → 4 µm 에서 12.9 → 26.3 % · Lee 2025 LPSCl ≈ 15 % | §A L925 | [판독 · 재료 · TD 표지 필수] | 누른 채 값 · 진밀도는 편마다 다름 (Lee 2025 인쇄 TD 1.64 = 결정학 밀도보다 12 % 낮다고 비교 문서가 적음 · L924) · 랩 표준과 다른 문헌 값 (Faka 위 끝)
- [a] faka2026_particle_size_consolidation_strain_lpscl + heck2026_densification_sulfide_se_binder_scalable + diener2022_roll_gap_springback_calendering + lee2025_heckel_argyrodite_powder_densification_nanoindentation + thompson2026_high_pressure_densification_lps_lpscl_xrd_tomography | (묶음) 실험 밀도 · 두께는 가압 중 (in-die) / 놓은 뒤 (out-of-die) 를 병기 (정의 = Faka 2026 p.10 · Heck 2026 p.13) · 회복값은 진밀도로 먼저 점검 — Diener 고하중 SB 는 간극 안 밀도 > 진밀도 (상한 ≈ 20–24 %) · Lee 2025 인쇄 TD 1.64 는 결정학 밀도보다 12 % 낮음 · Thompson 흡수 밀도 > 결정 밀도 (≥ 800 MPa) | §A L923–924 | 표지 없음 | 편마다 재료 다름 (Diener = 롤 간극 압연 · 재료는 이 줄에 없음 · Heck = LPS + HNBR · Thompson = slug 로는 LPS / LPSCl)
- [a] zunker2024_mdr_contact_model_partI + zunker2024_bulk_elastic_partII + zunker2025_dem_large_deformation_compaction | 순수 SE 기공 곡선 없음 — 세 편 어디에도 porosity / 상대밀도 수치가 0 개 (검증 표적이 σ_axial(ε) · σ_radial(ε)) · 비교 문서: "연화 없이 실험 porosity 도달은 아무도 보이지 않았다" | §A L662–664 | 표지 없음 | 소재 = 제약 부형제 MCC (Avicel PH102)
- [a] zhou2026_gyroid_structural_electrolyte_stiffness_ionic_tradeoff + song2025_porous_argyrodite_modulus_fracture_toughness + li2026_electrochemomechanical_coupling_asslmb_review | (묶음 · 곡선 아님) 냉간압착 LPSCl 펠릿 공극 13 % 한 점이 두 카드에 걸쳐 쓰임 — E/E_dense ≈ 0.21 (Song 2025) · 리뷰 표 3 의 "LPSCl E 4.7 GPa" 는 그 13 % 다공 펠릿의 벌크값 | §C L2659 · L2665 | 표지 없음 / [추정] | 압력 · 진밀도 · 누른 채 여부 이 줄에 없음 · 랩 표준 (10–13 %) 범위 끝과 같은 값
- [a] alabdali2023_cgmd_wet_manufacturing_ssb_cathode | (진밀도만) 비교 문서가 wt% ↔ vol% 검산에 대입한 밀도 NMC622 ≈ 4.7 · LPSCl ≈ 1.64 g cm⁻³ — "논문 미제공, 우리가 대입" · 환산 AM : SE = 46.6 : 53.4 vol% ↔ Fig 3b 판독 48.8 : 51.2 (± 3 %p 안) | §E L2855–2857 | 대입값 · 판독 | 기공 곡선 아님 · 랩 표준 진밀도와 같은 값
- [a] paulick2015_elastic_particle_properties_dem_review | (순수 SE 실험 곡선의 빈칸) "LPSCl 분말 오이도미터 제하–재하 계수가 리포에 없다 (n/a · 문헌 탐색 필요)" · "다중압력 Heckel (LPSCl powder) 실측 — 우리 직접앵커 부족" | §F L3452 · L3529 | 표지 없음 | 값 없음 (빈칸 표시)
- [a] pycompact2025_dem_mpfem_workflow | 기준 실험값이 가압 중 측정인지 해압 후 측정인지가 "미해결 질문" 으로 적힘 (PyCompact 는 상대밀도를 제하 중 5 MPa 도달 시점에 잼) | §F L3719–3731 | 표지 없음 | 그 줄이 든 기준값 (순수 SE 10 % @ 300 MPa 를 Minnmann 에 귀속 · Cronau 겹침 11–12 %) 은 비교 문서 문제 절 참조



"""Read-only candidate inventory and extraction; never imports candidate code or runs tests."""
from pathlib import Path
import ast, hashlib, json, re, datetime
R=Path(__file__).resolve().parent
C=R/'received/candidate'
def put(p,obj):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(obj,f,ensure_ascii=False,indent=2,allow_nan=False)
def ident(p):
    b=p.read_bytes();return dict(path=p.resolve().as_posix(),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
manifest=ident(C/'CODE_MANIFEST.json')
assert manifest['bytes']==1050 and manifest['sha256']=='4cdca2e6bf7d073f813d97be73825b8cd2043c2fc44e285f4a190bc6fb97cf25'
pins=json.loads((C/'CODE_MANIFEST.json').read_bytes())['files']
checks=[]
for pin in pins:
    got=ident(C/pin['file']);assert all(got[k]==pin[k] for k in ('bytes','sha256'))
    checks.append(got)
plan=json.loads((R/'received/LIMITED_VALIDATION_PLAN.json').read_bytes())
case_map=[]
for group in plan['groups']:
    for case in group['cases']:
        inputs=case.get('input_expectations',[{'input':case['fixture'],'expected':case['expected']}])
        assert len(inputs)==case['inputs']
        for i,v in enumerate(inputs,1):
            case_map.append({'id':case['id'],'input_index':i,'engine':group['engine'],'target':group['actual_target'],'fixture_specification':v['input'],'expected':v['expected'],'status':'NOT_RUN','fixture_created':False,'actual_call_bound':False})
assert len(case_map)==77 and len({v['id'] for v in case_map})==62
put(R/'INPUT_CASE_MAP.json',case_map)
cfg=json.loads((C/'CONTRACT.json').read_bytes())
previous=R.parent/'normal30_limited_validation_R1_20260928'
commands=json.loads((previous/'COMMANDS.json').read_bytes())
old_engines=json.loads((previous/'PRE_TEST_SEAL.json').read_bytes())['engine_identities']
engine_checks=[]
for name,pin in [('Python',cfg['python'])]+[(x,old_engines[x]) for x in ('Java_compile','Java_stub','PS51')]:
    got=ident(Path(pin['path']));assert all(got[k]==pin[k] for k in ('bytes','sha256'))
    if name in ('Java_compile','Java_stub'):assert got['path'].lower()==Path(commands[name]['argv'][0]).resolve().as_posix().lower()
    engine_checks.append({'name':name,'observed':got,'expected':pin,'match':True,'version_process_invoked':False})
parent=(C/'PARENT_COMMAND.ps1').read_bytes()
assert old_engines['PS51']['sha256'].encode() in parent
ex=R/'extracted';ex.mkdir()
spans=[]
def extract(source,name,start,end,suffix):
    raw=source.read_bytes();piece=raw[start:end];out=ex/(name+suffix)
    with out.open('xb') as f:f.write(piece)
    spans.append({'name':name,'source':ident(source),'byte_start_inclusive':start,'byte_end_exclusive':end,'line_start_1based':raw[:start].count(b'\n')+1,'line_end_1based':raw[:end].count(b'\n')+1,'sha256':hashlib.sha256(piece).hexdigest(),'extracted':ident(out),'normalization':'NONE; exact raw byte slice'})
    return piece
for filename in ('diagnostic_consumer.py','candidate_entry.py'):
    p=C/'src'/filename;raw=p.read_bytes();lines=raw.splitlines(keepends=True);offset=[0]
    for line in lines:offset.append(offset[-1]+len(line))
    for node in ast.parse(raw).body:
        if isinstance(node,(ast.FunctionDef,ast.AsyncFunctionDef)):
            extract(p,filename[:-3]+'__'+node.name,offset[node.lineno-1],offset[node.end_lineno],'.py.txt')
for name in ('GDecision','GNativeAxis','GFields'):
    start=parent.index(('function '+name+'(').encode())
    end=parent.index(b'\n}\n',start)+2
    extract(C/'PARENT_COMMAND.ps1',name,start,end,'.ps1.txt')
java=C/'src/Bmin640Candidate.java';raw=java.read_bytes()
start=raw.index(b'    static void checkShape(');end=raw.index(b'\n    }',start)+6
method=extract(java,'checkShape',start,end,'.java.txt')
start=raw.index(b'    static double[] TIMES=');end=raw.index(b'\n',start)
times=extract(java,'TIMES',start,end,'.java.txt')
harness=b'import java.util.Arrays;\npublic class ShapeHarness {\n'+times+b'\n'+method+b'\n    public static void main(String[] args) {\n        TIMES=null; checkShape("JV01-01",new double[][]{{0,75,150}},1);\n        System.out.println("JV01-01|PASS|accepted");\n        TIMES=null;\n        try { checkShape("JV01-02",new double[][]{{0,75,150.0001}},1); throw new AssertionError("EXPECTED_REJECTION"); }\n        catch (IllegalStateException e) { if (!e.getMessage().equals("TIME_ORDER:JV01-02")) throw e; System.out.println("JV01-02|PASS|TIME_ORDER"); }\n    }\n}\n'
hdir=R/'harness';hdir.mkdir()
with (hdir/'ShapeHarness.java').open('xb') as f:f.write(harness)
put(R/'EXTRACTION_MAP.json',spans)
put(R/'ENGINE_IDENTITIES.json',engine_checks)
put(R/'SOURCE_IDENTITIES_BEFORE.json',checks)
put(R/'PRESEAL_PROGRESS.json',{'status':'INCOMPLETE_NOT_A_TEST_RELEASE','manifest':manifest,'production_files':5,'package_files':17,'inputs':77,'unique_ids':62,'source_extraction_complete':True,'python_harness_complete':False,'powershell_harness_complete':False,'java_helper_written_not_compiled':ident(hdir/'ShapeHarness.java'),'fixtures_materialized':False,'tests_started':False,'utc':datetime.datetime.now(datetime.timezone.utc).isoformat()})
print(json.dumps({'status':'PRESEAL_INCOMPLETE','source_files':5,'input_specifications':77,'extracted_spans':len(spans),'tests_started':False}))

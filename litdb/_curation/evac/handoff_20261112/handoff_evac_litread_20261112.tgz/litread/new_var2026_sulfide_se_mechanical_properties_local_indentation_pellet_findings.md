# new_var2026_sulfide_se_mechanical_properties_local_indentation_pellet 정독 근거 (새 카드 · 원문 PDF 7 쪽 + SI 8 쪽 전문 + 카드 395 줄 · 2026-11-10)

카드: `var2026_sulfide_se_mechanical_properties_local_indentation_pellet` — K. Var, E. Barthel, S. Maiza, D. Sicsic, D. Bregiroux & C. Laberty-Robert,
"The mechanical properties of solid sulfur electrolytes: a local approach for a multiscale design", Journal of Power Sources 668 (2026) 239292,
DOI 10.1016/j.jpowsour.2026.239292 (CC BY) + Supplementary information (Appendix 1–8 · 8 쪽).  정본 커밋 `a444d8853`.

적는 법: 위치의 `L숫자` = 카드 줄 번호 (395 줄 판) · `p.n` = 논문 쪽 · `SI p.n` = 보충 자료 쪽.  표지는 카드에 적힌 그대로
(`[인쇄]` = 본문 · SI · 그림 안 숫자 · `[판독]` = 그림에서 읽음 (digitized.csv) · `[카드 산술]` · `[카드 해석]` · `[정본 카드]` = 다른 정본 카드 값 · `[미확인]`).
재료 = **Li₆PS₅Cl 순수 SE 분말 (~10 µm · 1 µm · < 1 µm) · 3D 실물 펠릿** — 같은 재료다.  단 밀도 자료는 ~10 µm 뿐이고 분모가 1.87 g/cm³ (랩 표준 1.64 와 다른 문헌 값) 이다.
대조 재료 (Li₃YBr₂Cl₄ · LATP) 값은 우리 재료 값이 아니다.  계산 모델 (DEM · FEM · MPM) 은 이 논문에 없다.

형식: `- [글자] slug | 내용 (값 · 단위) | 위치 | 표지 | 한계`

## a. 순수 SE (LPSCl · 황화물) 의 압력별 기공 곡선 · 진밀도 · 질량 기준 · 누른 채 / 뺀 뒤

- [a] var2026_sulfide_se_mechanical_properties_local_indentation_pellet | ~10 µm Li₆PS₅Cl 펠릿 상대밀도 0.68 · 0.73 · 0.78 @ 100 · 220 · 400 MPa (원문 "final relative density") → 기공 32 · 27 · 22 % (1 − d) | §3-2 L77–85 · 논문 p.3 · SI p.8 (Appendix 8) | d = [인쇄] · 기공 = [카드 산술] | 3 점 · ~10 µm 분말만 (1 µm · < 1 µm 의 밀도 없음 L93) · 가운데 압력은 본문 220 ↔ 그림 200 MPa (L340) · d 의 ± · 펠릿 수 [미확인]
- [a] var2026_sulfide_se_mechanical_properties_local_indentation_pellet | **진밀도 1.87 g/cm³** (원문 "ρLPSCl = 1,87 g.cm-3" · 출처 · 측정 여부 미기재) = 랩 표준 1.64 와 다른 문헌 값.  **질량 기준**: 200 mg ÷ (π·(6.5 mm)²·두께) · 두께 = 디지털 캘리퍼 (±0.01 mm) 5 점 평균 (빈 몰드 깊이 − 펠릿 든 깊이) | §3-2 L87–90 · §3-3 L95–98 · SI p.8 | [인쇄] | 캘리퍼 분해능만으로 d ±0.006–0.008 [카드 산술]
- [a] var2026_sulfide_se_mechanical_properties_local_indentation_pellet | **상태 = 하중 뺀 뒤 · 몰드 안 (탈형 안 함)** — 누른 채 (가압 중) 도 다이 밖도 아니다.  원문: "The pellet is formed and stored within the mold to avoid microcrack formation that could occur during demolding process." | §3-1 L72 · §3-2 L88 · 논문 p.2 | 문장 = [인쇄] · 상태 판정 = [카드 해석] (캘리퍼로 몰드째 잼) | 유지 시간 · 온도 · 프레스 · 가압 속도 [미확인] (L74)
- [a] var2026_sulfide_se_mechanical_properties_local_indentation_pellet | 분모와 무관한 벌크 밀도 1.272 · 1.365 · 1.459 g/cm³ (d × 1.87) · 300 MPa 선형 보간 ≈1.41 g/cm³ · 랩 표준 1.64 로 다시 읽으면 d 0.775 · 0.832 · 0.889 = 기공 22.5 · 16.8 · 11.1 % (300 보간 ≈13.9–14.2 %) | §3-2 L80–85 | [카드 산술 — 원문 값 아님] | 보간은 두 점 사이 직선 · 가운데 점이 200 인지 220 인지에 따라 0.3 %p 차
- [a] var2026_sulfide_se_mechanical_properties_local_indentation_pellet | 다른 정본 카드와 벌크 밀도로 나란히 (300 MPa 근처): 이 논문 ≈1.41 · wang2024 냉간 다이 밖 1.42 · lee2025 가압 중 1.40 (그 분모 1.64 를 글자 그대로 쓸 때) · larson2025 ≈1.60 · thompson2026 1.56 (준등방) · miss2026 놓은 뒤 ≈1.71 (다른 조성) → 카드에 따라 1.40–1.71 g/cm³ | §7-2 L273–285 | [정본 카드] 값 + [카드 산술] | 분말 · 입경 · 상태 · 조성이 다 다름 — 한 곡선으로 합치지 않는다
- [a] var2026_sulfide_se_mechanical_properties_local_indentation_pellet | 같은 재료 · 가장 가까운 입경 (faka2026 AMG 11 µm · 가압 중 69.2 · 74.0 · 77.5 · 80.3 % @ 0.1–0.4 GPa) 과 1–2.3 %p 안 | §7-2 L286 | [정본 카드] + [카드 산술] | 분말이 달라 일치의 증거로 쓰지 않는다 (카드 문장)
- [a] var2026_sulfide_se_mechanical_properties_local_indentation_pellet | (다른 재료) Li₃YBr₂Cl₄ 400 MPa → 상대밀도 ≈0.85 | §3-2 L92 · 논문 p.3 | [인쇄] | LPSCl 아님 · 그 재료의 진밀도 [미확인]

## b. 압력을 뺄 때 되돌아오는 양과 잰 방법

- [b] var2026_sulfide_se_mechanical_properties_local_indentation_pellet | **재지 않았다** — 펠릿은 하중 뺀 뒤 한 상태만 쟀고 가압 중 값이 없어 회복량을 낼 수 없다 | §0 L32 · §4-3 (4) L217 | 카드 판정 (원문에 없음) | —
- [b] var2026_sulfide_se_mechanical_properties_local_indentation_pellet | 간접 ①: 압입 제하 때의 깊이 회복 — 2 mN (30 s 유지) 415 → 330 nm (20 %) · 2 mN (120 s) 482 → 407 nm (16 %) · 10 mN 4038 → 2900 nm (28 %) | §3-5 L143–146 · §3-6 L153 · Fig. 4a · SI p.4 | [판독] (10 mN 은 벡터 경로) | Berkovich 압입의 국부 회복 — 펠릿 치수 회복이 아니다 · 크리프 포함
- [b] var2026_sulfide_se_mechanical_properties_local_indentation_pellet | 간접 ②: 하중 뺀 펠릿의 σ 는 측정압을 탄다 — 성형압 360 MPa 에서 측정압 10 → 150 MPa 에 0.46 → 1.43 mS/cm (3.1 배) | §3-8 L182–192 · SI p.7 (Appendix 7) | [판독 ±0.01] + [카드 산술] | 접촉이 느슨해진다는 정황일 뿐 치수 회복 값이 아니다 [카드 해석] · 분말 · 셀 · 절차 [미확인]

## c. 항복 · 경도 · 크리프 값과 정의 · 일축 항복 세기 환산

- [c] var2026_sulfide_se_mechanical_properties_local_indentation_pellet | 입자 경도 (XPM · Berkovich · 1 mN · 부하 0.5 s · 유지 없음 · k-means 높은 군집 평균) ~10 µm: 545 MPa (성형압 100) · ≈530 (220, 판독) · 665 MPa (400) · 입경별 (400 MPa) 1 µm 780 · < 1 µm 870 MPa · 대표값 H ≈ 600 MPa | §3-4 L113–133 · §3-7 L157 · 논문 p.3–4 · Fig. 3a · 3b | [인쇄] (≈530 은 [판독]) | ± 의 뜻 미기재 · 시료 간 H 0.40–0.94 GPa (400 MPa 15 시료, [판독]) · 간격 1 µm < 압흔 ≈1.9 µm [카드 산술] · 1 µm 급 분말은 압흔 > 입자 (L136)
- [c] var2026_sulfide_se_mechanical_properties_local_indentation_pellet | 환산 탄성률 E_r: 15.3 ± 0.5 · 19.7 ± 0.2 · 24.0 ± 1.0 GPa (성형압 100 · 220 · 400) · 1 µm 25.6 ± 0.4 · < 1 µm 28.6 ± 1.4 GPa · 대표값 ≈25 GPa — 저자는 최고 압밀의 24.0 을 입자 값으로 본다 | §3-4 L117–125 · 논문 p.3 | [인쇄] | E_r → E 환산은 원문에 없음 (카드 산술: ν 0.37 가정 시 E ≈ 21–22 GPa L125)
- [c] var2026_sulfide_se_mechanical_properties_local_indentation_pellet | 크리프: 10 µm 펠릿 꼭대기 · 2 mN · 유지 30 / 120 s — 원문 "An initial indentation depth of ~350 nm increases to ~425 nm after 30 s and nearly 500 nm after 120 s."  판독: 유지 끝 415 nm (30 s) · 482 nm (120 s) · 120 s 끝에서도 ≈0.4 nm/s · 10 mN 유지 20 s 에 +376 nm (+10 %) | §3-5 L138–149 · §3-6 L153 · 논문 p.4 · Fig. 4a · SI p.4 | [인쇄] + [판독] | 곡선 두 개 (반복 [미확인]) · 크리프 지수 · 속도 민감도 분석 없음 · 펠릿 성형압 [미확인]
- [c] var2026_sulfide_se_mechanical_properties_local_indentation_pellet | **일축 항복 세기 환산: 원문에 없다** (σ_y 값 · H/3 식 없음).  H 는 식 (1) 의 P/H 와 소성 지수 I_p = 3E_r a/(HR) 에만 쓰임 — 그 '3' 은 H ≈ 3σ_y 를 넣은 꼴로 읽힌다 | §0 L31 · §3-7 L160 · §4-3 L214 | 원문에 없음 · '3' 의 해석은 [카드 해석] | 카드도 환산하지 않았다 (지시)
- [c] var2026_sulfide_se_mechanical_properties_local_indentation_pellet | Li₆PS₅Cl 경도가 정본 카드에 따라 0.55–1.41 GPa (2.6 배): 이 논문 0.545–0.665 (1 mN · 0.5 s · 냉간 펠릿) · larson2025 0.72 / 0.78 (100 mN) · jung2026 1.34 · lee2025 1.41 ± 0.24 (8 mN · 4 s + 2 s 유지 · 치밀 펠릿) · lee2026 은 σ_ys 92 MPa (다른 정의) | §7-2 L289–301 | [정본 카드] | 하중 · 시간 · 시료 밀도 · 조성이 함께 달라 시간 척도 하나로 정리되지 않는다 (카드 지적 L301)

## d. 단단한 입자와 무른 입자를 섞어 누를 때 단단한 입자의 하중 몫 · 재밍

- [d] var2026_sulfide_se_mechanical_properties_local_indentation_pellet | 해당 없음 — 순수 SE 분말만 (CAM 없음).  해석식의 출발 충전밀도 d₀ ≃ 0.64 는 가정값 (잰 것 아님) | §2 L50 · §3-7 L158 | [인쇄] | 초기 충전밀도 [미확인]

## e. 점접촉 법칙이 큰 변형에서 깨지는 범위와 대안 · 대안마다 맞춘 값 개수

- [e] var2026_sulfide_se_mechanical_properties_local_indentation_pellet | 완전 소성 접촉 압밀 식 P/H = d²(d − d₀)/(1 − d₀) (Baumard & Coupelle 1994 로 인용 · d₀ 0.64 · H 600 MPa) 가 주는 압력 31 · 80 · 142 MPa ↔ 실제 100 · 200 · 400 MPa — 자료 ÷ 식 = 3.24 · 2.50 · 2.82 | §3-7 L164–172 · 논문 p.4 · Fig. 4b | 식 = [인쇄] · 비 = [판독 + 카드 산술] | 3 점 · 하중 뺀 뒤 밀도 · 가운데 점 220 이면 2.75
- [e] var2026_sulfide_se_mechanical_properties_local_indentation_pellet | 저자의 영역 판정: 소성 지수 I_p = 3E_r a/(HR) · 완전 소성은 I_p > ~100 · 압밀 끝 (d ≈ 0.8) 에서 a/R ≃ 0.1 · 3E/H ≃ 125 → I_p ≃ 12 = 탄성과 완전 소성 사이 | §3-7 L160 · 논문 p.4 | [인쇄] | 카드 산술: 기하 접촉 반지름으로는 a/R ≈ 0.38–0.44 → I_p ≈ 48–55 (L173) · 원문 기준으로 완전 소성은 a/R ≈ 0.8 (L174)
- [e] var2026_sulfide_se_mechanical_properties_local_indentation_pellet | 대안 (우회) = 접촉 압력에 배수 3 — **맞춘 값 1 개** · 맞춘 대상 = 자기 자료 3 점 · 검증 없음 · 저자 "only a crude approximation" | §3-7 L161 · §4-3 (2) L215 · 논문 p.4–5 | [인쇄] | 그림 범례 "2/3" 곡선은 2 배 곡선 (L172) · p_m 을 식에 넣은 방식 [미확인] (L175)
- [e] var2026_sulfide_se_mechanical_properties_local_indentation_pellet | 정본 mesarovicfleck2000 카드의 경계 (Hertz 상한 2.5 · 완전 소성 진입 ≳ 50–100 · 유한 변형 진입 a/R₀ ≳ 0.06–0.16) 로 보면 원문의 I_p ≈ 12 는 탄소성 천이 구간이고 a/R = 0.1 (a/R₀ = 0.2) 은 유한 변형 진입선을 넘는다 | §4-3 (1) L214 | [카드 산술 — 정본 카드와 엮음] | 원문의 말이 아니다 (카드 대조)
- [e] var2026_sulfide_se_mechanical_properties_local_indentation_pellet | 식 (1) 은 정본 arzt1982 카드의 냉간 압밀 한계 (f/a = 3σ_f · a = 3(D − D₀) · Z = 7.3 + 9.5(D − D₀)) 와 3–5 % 안에서 같은 수 (0.050 · 0.128 · 0.225 ↔ 0.051 · 0.133 · 0.237) | §3-7 L177 | [카드 산술] | multi-contact · MDR · EEPA · Thornton–Ning · Storåkers 는 이 논문에 없음

## f. MPM 의 접촉 · 다물체 · 강체 결합 방법 · 해상도 규칙 (지름당 셀 수) · 수치 오차 추정

- [f] var2026_sulfide_se_mechanical_properties_local_indentation_pellet | 해당 없음 — 실험 논문 (MPM · FEM · DEM 없음) | §0 L23 · L35 | 카드 판정 | —

## g. 2D 결과를 3D 로 옮길 때의 경고 · 증거

- [g] var2026_sulfide_se_mechanical_properties_local_indentation_pellet | 말 없음 — 실험은 3D 실물 · 해석식은 3D 구 무작위 충전 · 2D 계산도 2D → 3D 전이에 대한 문장도 없다 | §0 L34 · §4-3 (3) L216 | 카드 판정 (원문에 없음) | —

## h. DEM 에서 FE · MPM 으로 넘긴 선례와 넘긴 시점

- [h] var2026_sulfide_se_mechanical_properties_local_indentation_pellet | 해당 없음 — "multiscale design" 은 입자 값 (H · E_r) 을 해석 압밀 식에 한 번 넣는 것까지이고 수치 모델은 쓰지 않는다.  뒤 일 = "correlate these local mechanical insights with electrochemical performance" | §0 L35 · 논문 p.6 | [인쇄] | —

## i. 복합 양극 (AM + SE) 의 압력별 기공

- [i] var2026_sulfide_se_mechanical_properties_local_indentation_pellet | 없음 (순수 SE 만) | §2 L50 | 카드 판정 | —

## j. 카드가 스스로 "아직 못 한다 · 한계" 라고 적은 것 가운데 가압 · 탈압 계산과 닿는 것

- [j] var2026_sulfide_se_mechanical_properties_local_indentation_pellet | 저자: 압밀 식 — "It is not clear how Baumard's model can be quantitatively adapted to this intermediate case" · "only a crude approximation and quantitative interpretations should be made with caution" | §10 L333 · 논문 p.4–5 | [인쇄] | —
- [j] var2026_sulfide_se_mechanical_properties_local_indentation_pellet | 저자: 입자 뭉치에 박힌 입자의 압입 — "While a comprehensive theoretical model for such granular systems is still lacking, we consider the modulus measured at the highest compaction density (24.0 ± 1.0 GPa) to be a reasonable approximation of Ep." | §10 L332 · 논문 p.3 | [인쇄] | —
- [j] var2026_sulfide_se_mechanical_properties_local_indentation_pellet | 카드: 가압 중 높이 · 다이 밖 밀도 · 탈압 회복 · 초기 충전밀도 · 유지 시간 영향 · σ_y 환산 · 모든 수치 모사 = 하지 않음 | §4-1 L205 · §12 L367–379 | 카드 판정 | —
- [j] var2026_sulfide_se_mechanical_properties_local_indentation_pellet | 카드: 초록의 "smaller or softer particles achieve higher density" 는 Li₆PS₅Cl 입경별 밀도 자료 없이 쓴 문장 — 같은 재료의 가압 중 자료 (faka2026) 는 반대 순서 (300 MPa 에서 40 µm 87.1 % > 4 µm 73.7 %) | §7-2 L287 · §10 L342 | [정본 카드] 대조 | 두 값을 그대로 둠

## k. DEM 의 한계

- [k] var2026_sulfide_se_mechanical_properties_local_indentation_pellet (Var, Barthel, Maiza, Sicsic, Bregiroux & Laberty-Robert, J. Power Sources 668, 239292, 2026) | **말 없음** — 본문 7 쪽 + SI 8 쪽에 'DEM' · 'discrete element' · 'simulation' 0 회.  DEM 을 쓰지도 말하지도 않는 실험 논문 | §0 L33 · §4-3 (1) L213 | 카드 확인 (글자 층 전문 검색) | —
- [k] var2026_sulfide_se_mechanical_properties_local_indentation_pellet (같은 서지 · DEM 이 아니라 **완전 소성 접촉 가정** 의 한계 — 항복 캡 접촉 법칙 (후보 C′) · Stage-E 의 F/H 면적에 닿는 인용처) | "This compaction curve … qualitatively follows the trend of our experimental data, though it significantly underestimates the pressure required for a given density. This discrepancy arises from a key assumption in Baumard's model: that interparticle contacts are fully plastic." (p.4) · "fully plastic contacts are expected only when the plasticity index Ip exceeds ~100. … when approaching maximum compaction, the plasticity index Ip ≃ 12, well below the threshold for fully plastic contacts." (p.4) | §3-7 L159–160 | [인쇄] (카드가 따옴표로 옮김) | 실험 3 점 · 하중 뺀 뒤 밀도 · 원인을 접촉 영역 하나로 돌린 것은 저자 해석 (d₀ 가정 · 재배열 · 회복 · 시간이 섞임 — 카드 §7-3 L306)
- [k] var2026_sulfide_se_mechanical_properties_local_indentation_pellet (같은 서지 · 숫자) | 입자 경도 · 탄성률을 넣은 완전 소성 접촉식이 필요한 압력을 2.5–3.2 배 낮게 준다 (d 0.68–0.78) | §3-7 L166–170 · Fig. 4b | [판독 + 카드 산술] | ~10 µm Li₆PS₅Cl · H 600 MPa (1 mN 빠른 압입 값) 로 정규화

## l. 소성변형이 왜 어려운가

- [l] var2026_sulfide_se_mechanical_properties_local_indentation_pellet (Var, Barthel, Maiza, Sicsic, Bregiroux & Laberty-Robert, J. Power Sources 668, 239292, 2026) | 이유 ① 접촉이 탄성도 완전 소성도 아닌 사이 영역이라 해석식을 고칠 방법이 없다: "It is not clear how Baumard's model can be quantitatively adapted to this intermediate case but qualitatively, a reasonable match to the experimental data is obtained by scaling the contact pressure pm by a factor of three (Fig. 4b dotted line). Although this adjustment is only a crude approximation and quantitative interpretations should be made with caution, …" (p.4–5) | §3-7 L161 · §4-3 (2) L215 | [인쇄] | 해석 모델 한정 (수치 모사 없음)
- [l] var2026_sulfide_se_mechanical_properties_local_indentation_pellet (같은 서지) | 이유 ② 재료가 점소성이라 경도 (= 항복의 대리) 가 측정 시간에 따라 달라진다: "These simple tests clearly demonstrate the pronounced viscoplastic behavior of sulfide-based solid electrolytes." · "such materials tend to show lower hardness in conventional microindentation experiments, which involve longer loading times, compared to fast nanoindentation measurements." (p.4) — 2 mN 유지 120 s 에 깊이 ≈350 → 482 nm | §3-5 L140–149 | [인쇄] + [판독] | 곡선 두 개 · 정량 크리프 법칙 없음 · 정본 lee2025 (더 느린 시험) 의 H 가 더 높아 시간 척도 하나로는 안 맞는다 (L301)
- [l] var2026_sulfide_se_mechanical_properties_local_indentation_pellet (같은 서지) | 이유 ③ 무른 입자 뭉치에 박힌 입자는 탄성 응답이 주변에 좌우된다: "it is well established that indenting a stiff particle (modulus Ep) embedded in a softer surrounding medium (modulus Es < Ep) yields a reduced effective indentation modulus. In contrast, hardness, being governed by more localized plastic deformation, is much less influenced" · "a comprehensive theoretical model for such granular systems is still lacking" (p.3) — E_r 15.3 → 24.0 GPa (성형압 100 → 400 MPa) 인데 H 는 545 → 665 MPa | §3-4 L121–123 | [인쇄] | 압입 해석의 문제 (압밀 계산 아님)
- [l] var2026_sulfide_se_mechanical_properties_local_indentation_pellet (같은 서지) | 우회의 값: 접촉 압력에 배수 3 — 맞춘 값 1 개 · 맞춘 대상 = 자기 d–P 자료 3 점 (~10 µm · 100 · 220 · 400 MPa) · 검증 = 없음 (같은 3 점) · 계산 비용 = 해석식 (0) · 입자 수 해당 없음 | §4-3 (2) L215 · §3-7 L164–176 | [인쇄] + 카드 판정 | 배수 3 을 식에 넣은 방식 [미확인] · 범례 "2/3" 곡선은 2 배 (L172)

## m. 받아들일 통찰

- [m] var2026_sulfide_se_mechanical_properties_local_indentation_pellet | **밀도 상태 칸에 "하중 뺀 뒤 · 다이 안" 을 따로 두고 유지 시간 · 분모 · 두께 재는 법을 같이 적는다** — 이 논문의 0.68 · 0.73 · 0.78 은 가압 중도 다이 밖도 아닌 셋째 상태이고 유지 시간이 없어 다른 자료와 바로 못 겹친다 · 캘리퍼 ±0.01 mm 가 ≈1 mm 펠릿에서 d ±0.007 | 단계 0 (기공률 연산자 · 판정 기준) · 결과 전 대조 항목 | §3-2 L88–90 · §8 L317 | [카드 해석] + [카드 산술] | 원문은 "final" 이라고만 씀
- [m] var2026_sulfide_se_mechanical_properties_local_indentation_pellet | **경도 ↔ 항복 세기 환산 규칙을 등록할 때 경도 값마다 하중 · 부하 / 유지 시간 · 시료 밀도를 같이 적는다** — 같은 Li₆PS₅Cl 이 0.55 GPa (1 mN · 0.5 s · 냉간 펠릿) 에서 1.41 GPa (8 mN · 치밀 펠릿) 까지고, 2 mN 을 120 s 유지하면 깊이가 +38 % 다 | 단계 4 (항복 세기 하나를 맞추는 일) · 조건 R5 | §7-2 L289–301 · §3-5 L148 · §8 L318 | [정본 카드] + [판독] | 이 논문은 환산식을 주지 않는다
- [m] var2026_sulfide_se_mechanical_properties_local_indentation_pellet | **항복 캡 = 경도 로 둔 접촉 법칙은 d 0.68–0.78 에서 압밀 압력을 ≈3 배 낮게 낼 수 있다** (완전 소성 접촉식 + 측정 H · E_r 의 실험 대조) → 후보 C′ 를 돌릴 때 캡 값을 H 로 고정하지 말고 이 3 점을 결과 전 대조 항목으로 둔다 · 속도 무관 모델 결과에는 "점소성 (유지 중 치밀화) 미포함" 한정어 | 후보 C′ · 후보 D0 (Stage-E 의 F/H 면적) · 단계 4 | §3-7 L164–177 · §7-3 L304–307 · §8 L316 · L319 | [판독 + 카드 산술] | 원인이 접촉 영역 하나인지는 미분리 (L306)
- [m] var2026_sulfide_se_mechanical_properties_local_indentation_pellet | **하중 뺀 펠릿의 σ 는 측정압 10 → 150 MPa 에 3.1 배 움직인다** (성형압 이득은 측정압 ≥ 75 MPa 에서만 +14–20 %) → 접촉망 σ (다이 안 접촉) 를 저압 EIS 와 직접 견주지 않는다 · 우리 시료 원측정에는 광유 보호 + 1 mN 고속 매핑 + 군집으로 꼭대기만 평균하는 방법을 쓸 수 있다 (간격 ≥ 압흔 · 입자 ≥ 압흔 확인 뒤) | 흐름 밖: 접촉망 수송 계산 ↔ 실험 대조 조건 · 실험 방법 | §3-8 L182–193 · §8 L321–322 | [판독] | 전도도 자료의 분말 · 셀 · 절차 [미확인]

## 카드 문제

없음 (카드 안 값끼리의 모순은 못 찾음).  원문 안의 어긋남은 카드 §10 L338–348 에 모아 둠: 가운데 압력 220 ↔ 200 MPa · 400 MPa 경도 665 ↔ 670 MPa · 부록 번호 8 ↔ 7 · "Ai et al. [39]" ↔ 목록 [36] · DFT 24.7 GPa ↔ 정본 Deng 카드 22.1 GPa · Fig. 3d 캡션 ↔ 색 막대 · Fig. S5d 군집 표의 색 이름 · Appendix 7 본문 "regardless" ↔ 그림 · Fig. 4b 범례 "2/3" ↔ 2 배 곡선.

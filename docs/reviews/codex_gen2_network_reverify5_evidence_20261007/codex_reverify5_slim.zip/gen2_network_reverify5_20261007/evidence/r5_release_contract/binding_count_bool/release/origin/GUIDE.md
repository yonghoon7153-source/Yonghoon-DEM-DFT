# Origin 가이드 — v1.3 porosity–σ–CN 재적합 (#5)

- 가져오기: CSV 를 Origin 에 끌어 놓기 → Header Lines: **Long Name = 1 줄 · Units = 2 줄** · Data Start = 3 줄 (utf-8 · BOM).
- `v13_refit_porosity_f.csv` — 가로 Porosity (%) · 세로 f (log) · 색 = SE–SE CN · 모양 = Dataset · Percolating = 0 행은 f = 0 (로그 축에 못 그린다 — 따로 표시하거나 뺀다 · 지우지 않는다).
- `v13_refit_collapse.csv` — 가로 φ_eff^0.5·CN^2 · 세로 f (log–log) · 등록식 (locked) 선 = f (locked fit) 열.
- `v13_refit_parity.csv` — 가로 f (DEM network) · 세로 f (free fit) · 1:1 선 (log–log).
- 서식 = 랩 BML 표준 (`docs/report_making_principles.md` — 레이어 12 × 9 cm · Aptos · 테두리) · 미리보기 `../previews/` 는 Liberation Sans.
- 식 · 상수 · 한정어 = 요약 JSON (`../lhs_v13_refit_porosity_sigma_cn_summary.json`) — 모델 내부 관계 · 지수를 물리 상수로 인용하지 않는다.

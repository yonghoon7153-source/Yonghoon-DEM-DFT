#!/usr/bin/env python3
"""S6_2 의 '왜 (근거 위치)' 칸 가운데 묶음 줄 (synth2/q_m2.md) 에 그 글이 없는 칸을 센다 (읽기 전용)."""
import re, sys, json
LR = '/tmp/claude-0/-home-user-Yonghoon-DEM-DFT/d26d1e75-209f-540f-83a8-c0e1957edc2f/scratchpad/handoff_litread_20261112/litread'
doc = open(LR + '/synth/out/S6_2_insights.md', encoding='utf-8').read().split('\n')
bund = open(LR + '/synth2/q_m2.md', encoding='utf-8').read().split('\n')
# 배치별 묶음 줄
cur = None
by_batch = {}
for l in bund:
    m = re.match(r'^### \[batch_(\d+)\]', l)
    if m:
        cur = int(m.group(1)); by_batch[cur] = []; continue
    if cur is not None and l.strip():
        by_batch[cur].append(l)
def norm(s):
    return re.sub(r'[\s*_`]+', '', s)
allb = {b: norm('\n'.join(ls)) for b, ls in by_batch.items()}
rows = []
for ln, l in enumerate(doc, 1):
    if not re.match(r'^\| MB-\d+ \|', l):
        continue
    cells = [c.strip() for c in re.split(r'(?<!\\)\|', l)[1:-1]]
    if len(cells) != 7:
        continue   # 17 절 표 (칸 3) 등
    num = cells[0]; why = cells[3]; tail = cells[6]
    bs = sorted(set(int(x) for x in re.findall(r'\[b(\d+) ·', tail)))
    found = any(norm(why) in allb.get(b, '') for b in bs)
    rows.append(dict(num=num, ln=ln, why=why, batches=bs, found=found))
miss = [r for r in rows if not r['found']]
print('MB 항목 줄', len(rows), '· 왜 칸이 묶음 (같은 배치) 에 글자 그대로 없는 것', len(miss))
from collections import Counter
print('배치별:', sorted(Counter(tuple(r['batches']) for r in miss).items()))
if '-v' in sys.argv:
    for r in miss:
        print(r['num'], r['batches'], '|', r['why'][:110])
json.dump(miss, open(sys.argv[1], 'w', encoding='utf-8'), ensure_ascii=False, indent=0) if len(sys.argv) > 1 and not sys.argv[1].startswith('-') else None

#!/usr/bin/env python3
"""recheck2 RCP2-06 반례 — **반드시 `unshare -pf --mount-proc --kill-child` 안에서** · 이 스크립트가 작업 폴더에 만든 일회용 저장소만 가리킨다
(피해 저장소 V · 바깥 저장소 O · 가짜 HOME).  적대 env 는 자식 프로세스에만 넘긴다 (이 프로세스 env 는 그대로).
  A  test_ca_s0_census.make_plan_repo (게이트 단계 'ca_s0_census' · kgy R 경로 S0 묶음) — 적대 셋에서 V 가 바뀌는가 (G6 일곱 밖 같은 부류)
  B  check_review_findings --selftest (게이트 단계 'check_review_findings --selftest' · 묶음 밖) — commit-tree 가 V 에 객체를 쓰는가
  C  GIT_CEILING_DIRECTORIES — 바깥 저장소 O 안의 git 아닌 사본 (O/kit/scripts) 에서 payload `_code_sha` (고친 판 = GIT_ 전부 지움) ↔ 고치기 전 판
     (0ac6edf3c · env 물려받음) — 부르는 쪽이 천장을 두면 옛 판 = None (출처 없음) · 새 판 = O 의 HEAD 를 적는가
  D  HOME · XDG_CONFIG_HOME 전역 설정 — (i) core.hooksPath (pre-commit · post-commit 이 표지 파일을 쓴다) 가 run_contract --selftest 의 임시 commit 에서
     도는가 (ii) 전역 core.worktree = V 가 임시 commit 을 V 로 돌리는가
사용: python3 ce06_git.py <트리 scripts> <작업 폴더> <옛 payload 파일 (0ac6edf3c)>"""
import hashlib
import json
import os
import shutil
import subprocess
import sys

scripts, wd, old_payload = sys.argv[1:4]
assert os.getpid() < 100, f'PID 이름공간 밖에서 돌리지 않는다 (pid {os.getpid()})'
CLEAN = {k: v for k, v in os.environ.items() if not k.startswith('GIT_')}
CFG = ['-c', 'user.email=t@t', '-c', 'user.name=t', '-c', 'commit.gpgsign=false', '-c', 'init.defaultBranch=main']
os.makedirs(wd, exist_ok=True)
N = [0]


def g(repo, *a, env=None, check=True):
    r = subprocess.run(['git', '-C', repo, *CFG, *a], capture_output=True, text=True, env=env or CLEAN, stdin=subprocess.DEVNULL)
    if check and r.returncode:
        raise RuntimeError(f'git {a[:2]} rc {r.returncode} {r.stderr[:200]}')
    return r.stdout


def mk_repo(name, files):
    N[0] += 1
    p = os.path.join(wd, f'{name}_{N[0]}')
    os.makedirs(p)
    g(p, 'init', '-q')
    for rel, t in files.items():
        q = os.path.join(p, rel)
        os.makedirs(os.path.dirname(q), exist_ok=True)
        open(q, 'w').write(t)
    g(p, 'add', '-A')
    g(p, 'commit', '-qm', 'fx')
    return p


def state(v):
    gd = os.path.join(v, '.git')

    def fh(rel):
        q = os.path.join(gd, rel)
        return hashlib.sha256(open(q, 'rb').read()).hexdigest()[:12] if os.path.isfile(q) else None
    objs = sorted(os.path.relpath(os.path.join(r, f), gd) for r, _d, fs in os.walk(os.path.join(gd, 'objects')) for f in fs)
    return {'head': g(v, 'rev-parse', 'HEAD').strip()[:12], 'refs': hashlib.sha256(g(v, 'for-each-ref').encode()).hexdigest()[:12],
            'index': fh('index'), 'config': fh('config'), 'reflog': fh('logs/HEAD'), 'n_obj': len(objs),
            'branches': g(v, 'branch', '--list').split()}


def hostile(v):
    gd = os.path.join(v, '.git')
    base = dict(CLEAN, TMPDIR=wd)
    return {'GIT_DIR': dict(base, GIT_DIR=gd),
            'DIR+WT+INDEX': dict(base, GIT_DIR=gd, GIT_WORK_TREE=v, GIT_INDEX_FILE=os.path.join(gd, 'index')),
            'OBJ+COMMON': dict(base, GIT_OBJECT_DIRECTORY=os.path.join(gd, 'objects'), GIT_COMMON_DIR=gd)}


def py(code, args, env, cwd=None):
    r = subprocess.run([sys.executable, '-c', code, *args], capture_output=True, text=True, env=env, cwd=cwd or wd, timeout=600,
                       stdin=subprocess.DEVNULL)
    return r.returncode, r.stdout, r.stderr


out = {}
# ── A ──
A_CODE = r'''
import os, sys, json
sys.path.insert(0, sys.argv[1])
import test_ca_s0_census as T
left = sorted(k for k in os.environ if k.startswith('GIT_'))
d = sys.argv[2]
os.makedirs(d, exist_ok=True)
try:
    repo, sha, prel, rrel = T.make_plan_repo(d, b'{}', '0' * 64)
    print('A ' + json.dumps({'ok': True, 'sha': sha[:12], 'left': left}))
except Exception as e:
    print('A ' + json.dumps({'ok': False, 'err': type(e).__name__ + ': ' + str(e)[:160], 'left': left}))
'''
resA = {}
for nm in ('GIT_DIR', 'DIR+WT+INDEX', 'OBJ+COMMON'):
    v = mk_repo('victimA', {'v.txt': 'victim\n'})
    s0 = state(v)
    rc, so, se = py(A_CODE, [scripts, os.path.join(wd, f'a_fx_{nm.replace("+", "_")}')], hostile(v)[nm])
    s1 = state(v)
    line = [ln for ln in so.splitlines() if ln.startswith('A ')]
    resA[nm] = {'v_changed': sorted(k for k in s0 if s0[k] != s1[k]), 'child': json.loads(line[-1][2:]) if line else (rc, se[-300:]),
                'v_branches_after': s1['branches'], 'v_n_obj': (s0['n_obj'], s1['n_obj'])}
vA = mk_repo('victimA_clean', {'v.txt': 'victim\n'})
s0 = state(vA)
rc, so, se = py(A_CODE, [scripts, os.path.join(wd, 'a_fx_clean')], dict(CLEAN, TMPDIR=wd))
resA['clean (기준)'] = {'v_changed': sorted(k for k in s0 if s0[k] != state(vA)[k]),
                       'child': [ln for ln in so.splitlines() if ln.startswith('A ')][-1:]}
out['A_test_ca_s0_census'] = resA
print('A', json.dumps(resA, ensure_ascii=False)[:1500], flush=True)

# ── B ──
resB = {}
for nm in ('GIT_DIR',):
    v = mk_repo('victimB', {'v.txt': 'victim\n'})
    s0 = state(v)
    r = subprocess.run([sys.executable, os.path.join(scripts, 'check_review_findings.py'), '--selftest'], capture_output=True, text=True,
                       env=hostile(v)[nm], cwd=wd, timeout=600, stdin=subprocess.DEVNULL)
    s1 = state(v)
    resB[nm] = {'v_changed': sorted(k for k in s0 if s0[k] != s1[k]), 'n_obj': (s0['n_obj'], s1['n_obj']), 'rc': r.returncode}
out['B_check_review_findings_selftest'] = resB
print('B', json.dumps(resB, ensure_ascii=False), flush=True)

# ── C ──
O = mk_repo('outerO', {'README': 'outer\n'})
kit = os.path.join(O, 'kit', 'scripts')
os.makedirs(kit)
open(os.path.join(kit, 'm.py'), 'w').write('A = 1\n')
C_CODE = r'''
import sys, json, importlib.util
sys.path.insert(0, sys.argv[1])
which, path, sd = sys.argv[2], sys.argv[3], sys.argv[4]
if which == 'new':
    import mpm_webapp_payload as P
else:
    spec = importlib.util.spec_from_file_location('old_payload_0ac6', path)
    P = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(P)
print('C ' + json.dumps({'code_sha': P._code_sha(sd)}))
'''
o_head = g(O, 'rev-parse', '--short', 'HEAD').strip()
resC = {'outer_head': o_head}
for ceil in (None, O):
    env = dict(CLEAN, TMPDIR=wd)
    if ceil:
        env['GIT_CEILING_DIRECTORIES'] = ceil
    for which in ('old', 'new'):
        rc, so, se = py(C_CODE, [scripts, which, old_payload, kit], env)
        ln = [x for x in so.splitlines() if x.startswith('C ')]
        resC[f'ceiling={"O" if ceil else "없음"} · {which}'] = json.loads(ln[-1][2:])['code_sha'] if ln else ('rc', rc, se[-200:])
out['C_ceiling'] = resC
print('C', json.dumps(resC, ensure_ascii=False), flush=True)

# ── D ──
resD = {}
mark = os.path.join(wd, 'hook_marks')
os.makedirs(mark, exist_ok=True)
hooks = os.path.join(wd, 'hooks_global')
os.makedirs(hooks, exist_ok=True)
for hk in ('pre-commit', 'post-commit'):
    p = os.path.join(hooks, hk)
    open(p, 'w').write(f'#!/bin/sh\necho "$PWD" >> "{mark}/{hk}"\nexit 0\n')
    os.chmod(p, 0o755)
for label, var in (('HOME', 'HOME'), ('XDG_CONFIG_HOME', 'XDG_CONFIG_HOME')):
    for m in os.listdir(mark):
        os.unlink(os.path.join(mark, m))
    fh = os.path.join(wd, f'fake_{label}')
    os.makedirs(fh, exist_ok=True)
    cfgp = os.path.join(fh, '.gitconfig') if var == 'HOME' else os.path.join(fh, 'git', 'config')
    os.makedirs(os.path.dirname(cfgp), exist_ok=True)
    open(cfgp, 'w').write(f'[core]\n\thooksPath = {hooks}\n')
    env = dict(CLEAN, TMPDIR=wd)
    env[var] = fh
    r = subprocess.run([sys.executable, os.path.join(scripts, 'run_contract.py'), '--selftest'], capture_output=True, text=True, env=env,
                       cwd=wd, timeout=600, stdin=subprocess.DEVNULL)
    fired = {m: len(open(os.path.join(mark, m)).read().splitlines()) for m in os.listdir(mark)}
    resD[f'{label} core.hooksPath'] = {'rc': r.returncode, 'hooks_fired': fired, 'tail': r.stdout.strip().splitlines()[-1:]}
# (ii) 전역 core.worktree = V
v = mk_repo('victimD', {'v.txt': 'victim\n'})
s0 = state(v)
fh = os.path.join(wd, 'fake_HOME_wt')
os.makedirs(fh, exist_ok=True)
open(os.path.join(fh, '.gitconfig'), 'w').write(f'[core]\n\tworktree = {v}\n')
env = dict(CLEAN, TMPDIR=wd, HOME=fh)
r = subprocess.run([sys.executable, os.path.join(scripts, 'run_contract.py'), '--selftest'], capture_output=True, text=True, env=env,
                   cwd=wd, timeout=600, stdin=subprocess.DEVNULL)
s1 = state(v)
resD['HOME core.worktree=V'] = {'rc': r.returncode, 'v_changed': sorted(k for k in s0 if s0[k] != s1[k]),
                                'rcpt': [ln.strip()[:60] for ln in r.stdout.splitlines() if 'RCPT-sha' in ln]}
out['D_global_config'] = resD
print('D', json.dumps(resD, ensure_ascii=False), flush=True)
json.dump(out, open(os.path.join(wd, 'ce06_results.json'), 'w'), ensure_ascii=False, indent=1)

import json, os, sys, glob, hashlib
stage = sys.argv[1]
man = json.load(open("MANIFEST.json"))
mh = hashlib.sha256(open("MANIFEST.json", "rb").read()).hexdigest()
bad = []
# 🔴🔴 회신 BE P0-3 (2026-09-03) — 시험 마커는 **MANIFEST 가 선언한 픽스처에서만** 허용된다.
#   루트 `.SELFTEST_FIXTURE` 하나로 run_staged.sh 가 거버넌스를 건너뛰었고, census 는
#   그 예상 밖 파일을 거부하지 않았다 (리뷰어 재현). 여기서 닫는다 — 실물엔 그 파일이 없다.
_fixture_declared = man.get("selftest_fixture") is True
_markers = ([".SELFTEST_FIXTURE"] if os.path.isfile(".SELFTEST_FIXTURE") else []) + sorted(
    glob.glob("*/*/.SELFTEST_FIXTURE"))
if _markers and not _fixture_declared:
    bad.append("시험 마커가 있는데 MANIFEST 가 selftest_fixture 를 선언하지 않았다 %s — "
               "production 번들에 시험 장치가 섞였다 (BE P0-3)" % _markers[:3])
# ⛔⛔ 회신 AS 해제조건 7 (2026-08-31) — ZIP 안의 해시는 **자기 자신을 증명하지
#   못한다**. 우리가 ZIP 밖(메일 본문)에 고정한 digest 를 현장이 붙여넣어야
#   비로소 "우리가 보낸 그 물건" 이 확인된다. **선택이 아니라 필수**로 만든다.
_HEX = "0123456789abcdef"
def _need_hex(name):
    v = os.environ.get(name, "").strip().lower()
    if not v:
        bad.append("%s 가 없다 — 우리가 보낸 정본 메시지의 digest 를 넣어야 "
                   "이 번들이 그 배포본인지 확인할 수 있다" % name)
        return None
    if len(v) != 64 or any(c not in _HEX for c in v):
        bad.append("%s 가 64자리 hex 가 아니다" % name)
        return None
    return v
exp = _need_hex("EXPECT_MANIFEST_SHA256")
if exp and exp != mh:
    bad.append("MANIFEST sha256 %s ≠ EXPECT_MANIFEST_SHA256 %s" % (mh[:12], exp[:12]))
expz = _need_hex("EXPECT_ZIP_SHA256")
_zt_env = os.environ.get("BUNDLE_ZIP_SHA256", "").strip().lower()
if expz and _zt_env and expz != _zt_env:
    bad.append("받은 ZIP 해시 %s ≠ EXPECT_ZIP_SHA256 %s — 우리가 보낸 배포본이 "
               "아니다" % (_zt_env[:12], expz[:12]))
# ⛔ 회신 AR 해제조건 7 — 봉인을 **모든 실행에서 필수화**한다
# ⛔⛔ 회신 BA P0-1 (2026-09-02) — 이 census 는 이제 **SEAL 보다 먼저** 돈다.
#   그래서 첫 실행에는 봉인이 아직 없다 — 그때는 봉인 검사를 **건너뛰고**,
#   SEAL 직후 두 번째 census(`RECHECK_SEAL=1`)가 그 몫을 진다.
#   ⚠ 건너뛰는 것은 봉인 검사뿐이다. 파일 무결성·EXPECT·잡 집합은 **여기서** 끝난다.
_seal_required = os.environ.get("RECHECK_SEAL") == "1"
try:
    seal = json.load(open("POTCAR_ROOT_SEAL.json"))
except Exception as e:
    seal = {}
    if _seal_required:
        bad.append("POTCAR_ROOT_SEAL.json 을 읽을 수 없다 (%r) — 봉인 없이 돌리지 않는다" % e)
    else:
        print("  (봉인 검사는 SEAL 뒤 두 번째 census 로 미룬다 — 회신 BA P0-1)")
_need_seal = ("schema", "source_sha256", "allowlist_sha256", "manifest_sha256",
              "bundle_zip_sha256", "vasp_executable", "vasp_executable_sha256",
              "vasp_version_banner", "sealed_at_utc", "assembled_sha256_by_job",
              "sealed_before_production", "sealed_before_production_evidence")
if seal:
    _sm = [k for k in _need_seal if not seal.get(k)]
    if _sm:
        bad.append("봉인에 %s 가 없다 — 반쪽 봉인으로 돌리지 않는다" % _sm)
    # 🔴 회신 BH P0-1 — 배너가 **버전 토큰을 담고 있는지** 여기서 본다. 종전엔
    #   "비어 있지 않은가" 만 봤고, ` running on 1 total cores` 같은 첫 줄이 통과했다.
    #   그 봉인으로 1단계를 다 태우면 ROOT_SEAL_VASP_MISMATCH 로 전건이 막힌다.
    import re as _re_v
    # 🔴 렌즈1′ P1-1 (2026-09-03) — 행 앵커. `…/vasp.6.4.3/bin/vasp_std` 같은 **경로 에코**가
    #   봉인에 박혀 있으면 그것도 "버전이 아닌 줄" 이다 (VASP 가 안 돌았다는 뜻이다).
    if seal.get("vasp_version_banner") and not _re_v.search(
            r"(?m)^[ \t]*vasp\.[0-9][A-Za-z0-9._-]*",
            str(seal["vasp_version_banner"])):
        bad.append("봉인의 vasp_version_banner 에 행두 'vasp.<버전>' 토큰이 없다 (%r) — "
                   "봉인이 VASP 버전이 아닌 줄(또는 설치 경로)을 담았다. SEAL 을 다시 "
                   "돌리십시오 (회신 BH P0-1 · 렌즈1′ P1-1)"
                   % str(seal["vasp_version_banner"])[:60])
    if seal.get("manifest_sha256") and seal["manifest_sha256"] != mh:
        bad.append("봉인이 다른 MANIFEST 에 대한 것이다 (%s ≠ %s)"
                   % (seal["manifest_sha256"][:12], mh[:12]))
    _zt = ""
    try:
        _zt = open("ZIP_SHA256.txt").read().split()[0].strip().lower()
    except Exception:
        bad.append("ZIP_SHA256.txt 가 없다 — 받은 ZIP 과의 결박을 확인할 수 없다")
    if _zt and seal.get("bundle_zip_sha256") and seal["bundle_zip_sha256"] != _zt:
        bad.append("봉인의 ZIP 해시가 ZIP_SHA256.txt 와 다르다")
# ⛔⛔ 회신 AS 해제조건 6 — 실행 전에 **배포 파일 전수**를 해시 대조한다.
#   종전엔 잡 집합만 셌다. INCAR 한 줄이 바뀌어도 census 는 통과했다.
_fh = man.get("files_sha256") or {}
if not _fh:
    bad.append("MANIFEST 에 files_sha256 이 없다 — 입력 무결성을 확인할 수 없다")
else:
    _chg, _mis = [], []
    for _rel, _want in sorted(_fh.items()):
        _pth = os.path.join(*_rel.split("/"))
        if not os.path.isfile(_pth):
            _mis.append(_rel); continue
        _h = hashlib.sha256(open(_pth, "rb").read()).hexdigest()
        if _h != _want:
            _chg.append(_rel)
    if _mis:
        bad.append("배포 파일이 없다 %d건: %s" % (len(_mis), _mis[:3]))
    if _chg:
        bad.append("배포 파일이 바뀌었다 %d건: %s (입력을 고치면 그 잡은 "
                   "거부됩니다)" % (len(_chg), _chg[:3]))
    print("  ✓ 입력 무결성 %d 파일" % len(_fh))
cen = man.get("run_census") or {}
if not cen.get("job_keys") or not cen.get("stage_of"):
    bad.append("MANIFEST 에 run_census 가 없다 — 이 번들로는 census 를 확인할 수 "
               "없다 (구판 번들이면 재생성하십시오)")
else:
    want = set(cen["job_keys"])
    have = {os.path.dirname(p).replace(os.sep, "/") for p in glob.glob("*/*/job.json")}
    dirs = {d.rstrip("/").replace(os.sep, "/") for d in glob.glob("*/*/")}
    if have != want:
        bad.append("job.json 집합이 계획과 다르다 — 없음 %s · 계획 밖 %s"
                   % (sorted(want - have)[:4], sorted(have - want)[:4]))
    if dirs != want:
        bad.append("잡 폴더 집합이 계획과 다르다 — 없음 %s · 계획 밖 %s"
                   % (sorted(want - dirs)[:4], sorted(dirs - want)[:4]))
    # 단계 분류를 **디스크의 job.json 으로 다시 계산**해 선언과 대조한다
    got = {}
    for jp in sorted(glob.glob("*/*/job.json")):
        m = json.load(open(jp))
        d = os.path.dirname(jp).replace(os.sep, "/")
        kind, role, vac = m.get("kind"), m.get("role"), m.get("vacconv")
        if kind is None:
            bad.append("job.json 에 kind 가 없다: " + jp); continue
        if kind == "mol_ref":
            got[d] = "1"
        elif kind == "clean_ref":
            # 2026-09-04 — 러너·추정기와 **같은 규칙** (셋이 갈리면 2단계가 안 열린다)
            got[d] = "1" if (vac or m.get("seed") == "afm2424_pm1") else "2"
        elif kind == "prospective_pose" and role == "primary":
            got[d] = "1" if (vac or m.get("seed") == "afm2424_pm1") else "2"
        else:
            got[d] = "2"
    diff = sorted(k for k in set(got) | set(cen["stage_of"])
                  if got.get(k) != cen["stage_of"].get(k))
    if diff:
        bad.append("단계 분류가 선언과 다르다: %s" % diff[:4])
    cnt = {st: sum(1 for v in got.values() if v == st) for st in ("1", "2")}
    if cnt != cen.get("stage_counts"):
        bad.append("단계 개수가 선언과 다르다: 실물 %s ≠ 선언 %s"
                   % (cnt, cen.get("stage_counts")))
if bad:
    print("⛔ 실행 전 census:")
    for b in bad:
        print("   · " + b)
    sys.exit(1)
print("✓ census: MANIFEST %s · 잡 %d · 단계 %s"
      % (mh[:12], len(cen["job_keys"]), cen["stage_counts"]))
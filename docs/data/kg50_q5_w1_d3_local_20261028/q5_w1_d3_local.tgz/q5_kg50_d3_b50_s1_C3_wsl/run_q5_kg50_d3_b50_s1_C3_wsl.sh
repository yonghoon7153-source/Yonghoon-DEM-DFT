#!/bin/bash
# 50kg Q5 가지 C3 — 로컬 WSL · 직렬 LIGGGHTS 1 코어 · MPI 실행기 없음 · NP 1 (Q5) · 등록 §12-3 이탈 (등록 = hit) · scripts/kg50_q5_branches.py 생성 (손으로 고치지 말 것)
# 바이너리 = 환경 변수 LMP_SERIAL · 없으면 $HOME/src/LIGGGHTS-PUBLIC/src/lmp_serial · 그것도 없으면 PATH 의 lmp_serial · MPI 빌드 (ldd 에 libmpi) = 거부
# 검사 하나라도 실패 = 실행 안 함 (rc 2): 폴더 SHA256SUMS · ckpt_sha256.txt 두 줄 = 등록 Q1 sha256 · 체크포인트 sha256 · log.liggghts 없음 · 바이너리
set -u
cd "$HOME/q5_local/q5_kg50_d3_b50_s1_C3_wsl" || { echo "⛔ 가지 폴더 없음 — 실행 안 함"; exit 2; }
sha256sum -c --quiet SHA256SUMS || { echo "⛔ SHA256SUMS 다름 — 실행 안 함"; exit 2; }
Q1=1bf24069bb3876089adb6c7521d46c27f162de4e57ab6379d042913339607ea8
[ -f ckpt_sha256.txt ] && [ "$(wc -l < ckpt_sha256.txt)" = 2 ] && [ "$(cut -d" " -f1 ckpt_sha256.txt | sort -u)" = "$Q1" ] || { echo "⛔ ckpt_sha256.txt 가 두 줄 · 같은 값 · 등록 Q1 sha256 이 아니다 — 실행 안 함"; exit 2; }
[ "$(sha256sum restart_kg50_d3_b50_s1/restart_after_settling.bin 2>/dev/null | cut -d" " -f1)" = "$Q1" ] || { echo "⛔ 체크포인트 restart_kg50_d3_b50_s1/restart_after_settling.bin sha256 ≠ 등록 Q1 — 실행 안 함"; exit 2; }
[ ! -e log.liggghts ] || { echo "⛔ log.liggghts 이미 있음 (덮어쓰지 않는다) — 실행 안 함"; exit 2; }
if [ -n "${LMP_SERIAL:-}" ]; then L="$LMP_SERIAL"; elif [ -x "$HOME/src/LIGGGHTS-PUBLIC/src/lmp_serial" ]; then L="$HOME/src/LIGGGHTS-PUBLIC/src/lmp_serial"; else L=lmp_serial; fi
B=$(command -v "$L") || { echo "⛔ 직렬 바이너리 없음 ($L) — 실행 안 함"; exit 2; }
! ldd "$B" 2>/dev/null | grep -q libmpi || { echo "⛔ $B = MPI 빌드 (libmpi) — 로컬은 직렬만 (등록 §12-3) · 실행 안 함"; exit 2; }
printf "mode serial\nnp 1\nbinary %s\nsha256 %s\nlibmpi none\nhost %s\n" "$B" "$(sha256sum "$B" | cut -d" " -f1)" "$(uname -n)" > q5_binary.txt
setsid nohup "$B" -in input_q5_kg50_d3_b50_s1_C3_wsl.liggghts > log_q5_kg50_d3_b50_s1_C3_wsl_v1.out 2>&1 < /dev/null &
echo "▶ q5_kg50_d3_b50_s1_C3_wsl: $B (pid $!) · log.liggghts · log_q5_kg50_d3_b50_s1_C3_wsl_v1.out · q5_binary.txt"

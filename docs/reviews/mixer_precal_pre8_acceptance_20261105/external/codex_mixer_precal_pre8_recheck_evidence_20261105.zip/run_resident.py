import os,sys,pathlib,tempfile,runpy,json,platform
ROOT=pathlib.Path(__file__).resolve().parent
for key in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS'):os.environ[key]='1'
scratch=ROOT/'resident_scratch';scratch.mkdir(exist_ok=True)
tempfile.tempdir=str(scratch)
os.environ['TMP']=str(scratch);os.environ['TEMP']=str(scratch)
sys.path.insert(0,str(ROOT/'input/scripts'))
import numpy,scipy
print(json.dumps(dict(python=sys.version,platform=platform.platform(),numpy=numpy.__version__,scipy=scipy.__version__,scope='resident observe only; no prepare/fullgate',source_unmodified=True)),flush=True)
target=ROOT/'input/scripts/test_mixer_precal_observe.py'
sys.argv=[str(target),'-v']
runpy.run_path(str(target),run_name='__main__')

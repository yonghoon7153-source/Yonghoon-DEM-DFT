"""Read-only arithmetic and source-selection audit; NOT a COMSOL evaluator.

Only arithmetic parameter expressions reached by this audit are interpreted.
Material selection is reported from XML, not from generated equations.
"""
from __future__ import annotations

import ast
import hashlib
import io
import json
import operator
from pathlib import Path
import re
import sys
import zipfile
import xml.etree.ElementTree as ET

SOURCE = Path('C:/Users/Administrator/Documents/카카오톡 받은 파일/ICA_degradation mode.zip')
OUT = Path(__file__).with_name('mph_v2_physics_evidence.json')
UNITS = {'um': 1e-6, 'cm^2': 1e-4, 'mol/m^3': 1.0,
         'Ah': 3600.0, 'C/mol': 1.0}
OPS = {ast.Add: operator.add, ast.Sub: operator.sub,
       ast.Mult: operator.mul, ast.Div: operator.truediv}


def evaluator(params):
    def expr(text, stack=()):
        text = re.sub(r'\[([^\]]+)\]', lambda m: '*(' + repr(UNITS[m[1]]) + ')', text)

        def node(n):
            if isinstance(n, ast.Constant) and type(n.value) in (int, float):
                return n.value
            if isinstance(n, ast.Name):
                if n.id in stack:
                    raise ValueError('parameter cycle')
                return expr(params[n.id], stack + (n.id,))
            if isinstance(n, ast.BinOp) and type(n.op) in OPS:
                return OPS[type(n.op)](node(n.left), node(n.right))
            if isinstance(n, ast.UnaryOp) and isinstance(n.op, (ast.USub, ast.UAdd)):
                return -node(n.operand) if isinstance(n.op, ast.USub) else node(n.operand)
            raise ValueError('not an audited arithmetic expression: ' + ast.dump(n))
        return node(ast.parse(text, mode='eval').body)
    return expr


def scalar(raw):
    m = re.fullmatch(r"1\|1,'([^']*)'", raw)
    return m[1] if m else raw


def view(root):
    pars = {e.get('name'): e.get('expr') for e in root.findall('./ModelParam/expressions')}
    ev = evaluator(pars)
    pins = {}
    for tag, material in [('pce1', 'mat1'), ('pce2', 'mat5')]:
        feature = root.find(f".//Physics[@tag='liion']/PhysicsFeatureList/PhysicsFeature[@tag='{tag}']/PhysicsFeatureList/PhysicsFeature[@tag='pin1']")
        assert feature is not None
        pp = {e.get('param'): scalar(e.get('value')) for e in feature.findall('./param')}
        mat = root.find(f".//Material[@tag='{material}']")
        props = {e.get('param'): scalar(e.get('value')) for e in mat.findall("./MaterialModelList/MaterialModel[@tag='ElectrodePotential']/param")}
        max_expr = mat.find("./MaterialModelList/MaterialModel[@tag='def']/param[@param='csmax']").get('value')
        assert props['cEeqref'] == 'def.csmax'
        material_max = ev(scalar(max_expr))
        selected_max = material_max if pp['cEeqref_mat'] == 'from_mat' else ev(pp['cEeqref'])
        try:
            initial_concentration = ev(pp['csinit'])
            initial_note = 'arithmetic expression evaluated'
        except ValueError as exc:
            initial_concentration = None
            initial_note = str(exc)
        pins[tag] = {'stored_cEeqref': pp['cEeqref'], 'selector': pp['cEeqref_mat'],
                     'particle_material': pp['ParticleMaterial'], 'material': material,
                     'material_cEeqref': props['cEeqref'], 'material_csmax': scalar(max_expr),
                     'material_soc': props['soc'], 'stored_csinit': pp['csinit'],
                     'selected_max_concentration_mol_m3': selected_max,
                     'initial_evaluation_note': initial_note,
                     'arithmetic_csinit_over_selected_max': None if initial_concentration is None else initial_concentration / selected_max,
                     'arithmetic_csinit_over_stored_user_max': None if initial_concentration is None else initial_concentration / ev(pp['cEeqref'])}
    keys = ['epss_el', 'epss_pos', 'x_NCM_init', 'x_Gr_init', 'C_rate', 'sigma_short']
    return {'expressions': {k: pars[k] for k in keys}, 'pins': pins}, pars


def main():
    sys.stdout.reconfigure(encoding='utf-8')
    outer_data = SOURCE.read_bytes()
    with zipfile.ZipFile(io.BytesIO(outer_data)) as outer:
        names = [n for n in outer.namelist() if n.lower().endswith('.mph')]
        assert len(names) == 1
        mph_data = outer.read(names[0])
    with zipfile.ZipFile(io.BytesIO(mph_data)) as mph:
        current_data = mph.read('dmodel.xml')
        with zipfile.ZipFile(io.BytesIO(mph.read('savepoint6/model.zip'))) as saved:
            xmls = [n for n in saved.namelist() if n.endswith('.xml')]
            assert len(xmls) == 1, xmls
            saved_data = saved.read(xmls[0])
    current, params = view(ET.fromstring(current_data))
    snapshot, _ = view(ET.fromstring(saved_data))
    ev = evaluator(params)
    numbers = {k: ev(k) for k in ['nLi_0', 'dLi_LLI', 'nLi_target', 'x_NCM_init', 'x_Gr_init']}
    doubled_area = dict(params, A_cell='3.07876[cm^2]')
    numbers['x_NCM_init_if_A_cell_doubled'] = evaluator(doubled_area)('x_NCM_init')
    numbers['x_NCM_init_area_change'] = numbers['x_NCM_init_if_A_cell_doubled'] - numbers['x_NCM_init']
    assert all(p['selector'] == 'from_mat' for p in current['pins'].values())
    assert all(p['selector'] == 'userdef' for p in snapshot['pins'].values())
    assert abs(current['pins']['pce2']['arithmetic_csinit_over_selected_max'] - numbers['x_NCM_init']) < 1e-12
    assert abs(snapshot['pins']['pce2']['arithmetic_csinit_over_selected_max'] - 0.9189896) < 1e-12
    assert numbers['x_NCM_init_area_change'] > 0.01
    result = {'scope': 'XML-selected expressions and arithmetic only; no COMSOL run or generated-equation claim',
              'source': str(SOURCE), 'mph_sha256': hashlib.sha256(mph_data).hexdigest(),
              'dmodel_sha256': hashlib.sha256(current_data).hexdigest(),
              'savepoint6_model_xml_sha256': hashlib.sha256(saved_data).hexdigest(),
              'current': current, 'saved_sol1_snapshot': snapshot, 'independent_arithmetic': numbers,
              'assertions': 'PASS'}
    OUT.write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()

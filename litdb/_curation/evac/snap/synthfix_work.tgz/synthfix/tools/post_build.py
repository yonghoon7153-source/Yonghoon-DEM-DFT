#!/usr/bin/env python3
"""묶음 뒤 손질 — 합친 통찰 문서 (insights_merged.md) 머리에 세 몫의 한정 줄을 옮긴다.

build_package.py 는 S6_1 · S6_2 · S6_3 의 첫 '## ' 머리 앞 글 (제목 · 한정 줄 · 입력 설명) 을 합치지 않는다.
한정 줄 글자는 세 몫 문서의 3 번째 줄에서 그대로 가져온다. 두 번 넣지 않는다.
"""
import os
import sys

W = '/tmp/claude-0/-home-user-Yonghoon-DEM-DFT/d26d1e75-209f-540f-83a8-c0e1957edc2f/scratchpad/handoff_litread_20261112/litread/synth/out'
P = '/tmp/claude-0/-home-user-Yonghoon-DEM-DFT/d26d1e75-209f-540f-83a8-c0e1957edc2f/scratchpad/synthfix/package/insights_merged.md'
HEAD = '한정 (2026-11-12): '
MARK = '한정 (2026-11-12 · 세 몫 문서의 머리에 있던 한정 줄'

L = open(P, encoding='utf-8').read().split('\n')
if any(l.startswith(MARK) for l in L):
    sys.exit('이미 넣음')
assert L[0].startswith('# 받아들일 통찰') and L[1] == '' and L[2].startswith('몫 1 = ') and L[3] == '' and L[4].startswith('## '), L[:5]
block = [MARK + ' — build_package 가 첫 머리 앞의 글을 합치지 않아 묶음을 만든 뒤 옮겼다 · 기록 = evidence/APPLIED.md 7 절):', '']
for i in (1, 2, 3):
    fn = 'S6_%d_insights.md' % i
    src = open(os.path.join(W, fn), encoding='utf-8').read().split('\n')
    assert src[2].startswith(HEAD), (fn, src[2][:40])
    block.append('- 몫 %d (%s): %s' % (i, fn, src[2][len(HEAD):]))
block.append('')
L[4:4] = block
open(P, 'w', encoding='utf-8').write('\n'.join(L))
print('넣은 줄', len(block))

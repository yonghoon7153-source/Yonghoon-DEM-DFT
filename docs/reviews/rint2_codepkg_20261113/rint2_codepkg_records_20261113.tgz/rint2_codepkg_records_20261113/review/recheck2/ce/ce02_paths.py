#!/usr/bin/env python3
"""recheck2 RCP2-02 — 경로 정규화 (1) 차등: `run_contract.normal_path_problem` ↔ 러너 CJUNC_STORE 셸 판정 (러너 파일에서 그 줄들을 그대로 떼어 bash 함수로)
— 만든 글 모둠 전수 (성분 {a, L, ., .., …, '', .a, a.} 의 1–4 개 · 끝 빗금 0–2 · 앞 '/' 1–2) · (2) 실제 폴더: 링크 L → D 의 여러 꼴을 Store · 사슬
`cjunc_store_dir_problem` 에 (거부 / 받음 · 받으면 실경로가 링크 너머인가) · (3) 유니코드 · 대소문자 · 전각 점 꼴.
사용: python3 ce02_paths.py <트리 scripts> <작업 폴더>"""
import itertools
import json
import os
import re
import subprocess
import sys
import unicodedata

scripts, wd = sys.argv[1:3]
sys.path.insert(0, scripts)
import run_contract as RC  # noqa: E402

runner = open(os.path.join(scripts, 'sdcp_gain_vox015_8arm.sh'), encoding='utf-8').read().splitlines()
i0 = next(i for i, ln in enumerate(runner) if ln.strip().startswith('_CJS_LAST="$CJUNC_STORE"'))
i1 = next(i for i in range(i0, len(runner)) if runner[i].strip().startswith('if [ -L "$_CJS_LAST" ]'))
body = '\n'.join(runner[i0:i1])
body = body.replace('exit 2', 'return 2')
SH = 'chk() { CJUNC_STORE="$1"\n' + body + '\nreturn 0; }\nwhile IFS= read -r -d "" p; do chk "$p" >/dev/null; echo "$?"; done\n'

comps = ['a', 'L', '.', '..', '...', '', '.a', 'a.']
corpus = set()
for n in range(1, 5):
    for cs in itertools.product(comps, repeat=n):
        for lead in ('/', '//'):
            for tail in ('', '/', '//'):
                corpus.add(lead + '/'.join(cs) + tail)
corpus |= {'/', '//', '///', '/.', '/..', '/./', '/../', '/a/b', '/a/b/', '/a/b//', '/a//b', '/a/./b', '/a/../b'}
corpus = sorted(corpus)
r = subprocess.run(['bash', '-c', SH], input=''.join(p + '\0' for p in corpus), capture_output=True, text=True)
sh = [ln.strip() for ln in r.stdout.splitlines()]
assert len(sh) == len(corpus), (len(sh), len(corpus), r.stderr[-300:])
diff = []
for p, s in zip(corpus, sh):
    py_ok = RC.normal_path_problem(p) is None
    sh_ok = s == '0'
    if py_ok != sh_ok:
        diff.append((p, py_ok, sh_ok))
#  같은 규칙의 기준 (독립): 끝 빗금을 걷은 뒤 os.path.normpath 와 같다 (단 앞 '//' 는 POSIX 정의 꼴 — 따로 둔다)
ref_diff = []
for p in corpus:
    q = p.rstrip('/') or '/'
    ref_ok = (q == '/') or (os.path.normpath(q) == q and not q.startswith('//'))
    if ref_ok != (RC.normal_path_problem(p) is None):
        ref_diff.append(p)
print(f'(1) 글 모둠 {len(corpus)} 개 — 파이썬 ↔ 러너 셸 다름 {len(diff)} · 파이썬 ↔ 독립 기준 (normpath) 다름 {len(ref_diff)}')
for x in diff[:10]:
    print('   다름', x)
for x in ref_diff[:10]:
    print('   기준 다름', repr(x))

# (2) 실제 폴더
import cjunc_store as CS  # noqa: E402
import rint_r_chain as RR  # noqa: E402
base = os.path.join(wd, 'p')
D = os.path.join(base, 'D')
os.makedirs(os.path.join(D, 'sub'), exist_ok=True)
os.makedirs(os.path.join(base, 'E'), exist_ok=True)
for x in (base, D, os.path.join(D, 'sub'), os.path.join(base, 'E')):
    os.chmod(x, 0o755)
L = os.path.join(base, 'L')
if not os.path.lexists(L):
    os.symlink(D, L)
LL = os.path.join(base, 'LL')                       # 링크 → 링크
if not os.path.lexists(LL):
    os.symlink(L, LL)
cases = [L, L + '/', L + '//', L + '/.', L + '/./', L + '/.//', L + '//.', L + '/..' + '/L', base + '/./L', base + '//L', base + '/E/../L',
         LL, LL + '/', LL + '/.', L + '/sub', L + '/sub/', D, D + '/', D + '/.', base + '/./D', D + '/sub']
rows = []
for p in cases:
    try:
        CS.Store(p)
        st = '받음'
    except ValueError as e:
        st = '거부 · ' + str(e).split('—')[0][:40]
    ch = RR.cjunc_store_dir_problem(p)
    through = os.path.realpath(p) != os.path.abspath(p.rstrip('/') or '/')
    rows.append((p.replace(base, '<B>'), st, ch is None, through))
print('(2) 실제 폴더 (B = 작업 폴더 · L → D · LL → L):')
for p, st, chok, through in rows:
    print(f'   {p:22s} Store={st:34s} 사슬={"받음" if chok else "거부"} · 링크 너머로 감={through}')

# (3) 유니코드 · 대소문자 · 전각 점
uni = ['/x/．', '/x/․', '/x/.​', '/x/é', '/x/é', '/X/A', '/x/．．']
print('(3) 유니코드 · 대소문자:', [(repr(p), RC.normal_path_problem(p) is None, RR.cjunc_store_dir_problem(p) is None or 'charset')
                               for p in uni])
nfc_nfd = (unicodedata.normalize('NFC', '/x/é') == unicodedata.normalize('NFD', '/x/é'))
print('    NFC == NFD (같은 글로 보나):', nfc_nfd, '— 리눅스 ext4 = 바이트 이름 · 정규화 없음 (다른 이름 = 다른 항목)')
json.dump({'n_corpus': len(corpus), 'diff': diff, 'ref_diff': ref_diff, 'rows': rows}, open(os.path.join(wd, 'ce02_results.json'), 'w'),
          ensure_ascii=False, indent=1)

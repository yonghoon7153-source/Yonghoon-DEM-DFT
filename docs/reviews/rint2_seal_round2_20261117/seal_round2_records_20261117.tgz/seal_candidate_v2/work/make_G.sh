#!/bin/bash
# G = F + 11-17 현장 반영 (조각 둘 → 도구로 봉인본 · 명령 문서 다시 · README 현장 절) 를 64e4d213e 위 한 커밋으로 (scratch 사본 안 git 만)
set -euo pipefail
V=/tmp/claude-0/-home-user-Yonghoon-DEM-DFT/81c0ad95-542f-503b-9cf7-2f6a678a4b5b/scratchpad/rint/seal_candidate_v2
W=$V/work; C=$W/sealclone; B=$V/build_20261120; O=$W/evG; E=$V/evidence
PIN=64e4d213e8267bafaf3ae5af00a42996cefd3f33
S0=$C/docs/data/rint2_s0_sbe_20261116/files/ca1_s0_sbe_20261116T004809Z_q14final/cjunc_plan.json
SED="s#$W#<scratch>#g;s#$V#<후보>#g"
mkdir -p $O
cd $V
echo "make_sealed_copy.py sha256 $(sha256sum make_sealed_copy.py | cut -c1-64)"
# 1) 본 빌드 (후보 계획 · 넷 null)
rm -rf $B
python3 -I make_sealed_copy.py --pin-reg $W/pin_reg.md --pin-cmd $W/pin_cmd.md --reg-insert registration_R_insert.md --cmd-insert commands_doc_insert.md \
  --plan plan_candidate.json --s0-plan $S0 --chain $C/scripts/rint_r_chain.py --seal-date 20261120 --out $B > $O/build_main.txt 2>&1
echo "main build rc=$?"; cut -c1-300 $O/build_main.txt
# 2) e11 = 자기 시험 + 같은 입력 두 번
{ echo "# make_sealed_copy.py sha256 $(sha256sum make_sealed_copy.py | cut -c1-64) · $(python3 -V) · 조각 = 11-17 현장 반영 판 (G)"
  echo "\$ python3 -I make_sealed_copy.py --selftest --chain <사본>/scripts/rint_r_chain.py"
  python3 -I make_sealed_copy.py --selftest --chain $C/scripts/rint_r_chain.py; echo "rc=$?"; echo
  echo "\$ python3 -I make_sealed_copy.py --pin-reg pin_reg.md --pin-cmd pin_cmd.md --reg-insert registration_R_insert.md --cmd-insert commands_doc_insert.md --plan plan_candidate.json --s0-plan <11-16 cjunc_plan.json> --chain <사본>/scripts/rint_r_chain.py --seal-date 20261120 --out <빈 폴더>  (두 번)"
  for k in 1 2; do rm -rf $W/bt$k; python3 -I make_sealed_copy.py --pin-reg $W/pin_reg.md --pin-cmd $W/pin_cmd.md --reg-insert registration_R_insert.md --cmd-insert commands_doc_insert.md --plan plan_candidate.json --s0-plan $S0 --chain $C/scripts/rint_r_chain.py --seal-date 20261120 --out $W/bt$k | cut -c1-300; echo "rc=$?"; done
  diff -r $W/bt1 $W/bt2 > /dev/null && echo "두 번 출력 = 전 파일 바이트 같음 ($(find $W/bt1 -type f | wc -l) 파일 · _manifest.json 포함)"
  diff -r $W/bt1 $B > /dev/null && echo "= build_20261120 과도 같음"
  (cd $W/bt1 && find . -type f | sort | xargs sha256sum); rm -rf $W/bt1 $W/bt2; } 2>&1 | sed "$SED" > $E/raw/e11_make_sealed_copy.txt
grep -E "selftest|rc=|같음" $E/raw/e11_make_sealed_copy.txt
# 3) 고정물 빌드 (시험 값 · 등록 숫자 아님 · ⑤ 둘째 사본용)
rm -rf $W/build_fixture_20261120
python3 -I make_sealed_copy.py --pin-reg $W/pin_reg.md --pin-cmd $W/pin_cmd.md --reg-insert registration_R_insert.md --cmd-insert commands_doc_insert.md \
  --plan $W/plan_fixture_values_SCRATCH_ONLY.json --s0-plan $S0 --chain $C/scripts/rint_r_chain.py --seal-date 20261120 --out $W/build_fixture_20261120 2>&1 | sed "$SED" > $E/raw/e5_fixture_build.txt
echo "fixture build rc=${PIPESTATUS[0]}"; cut -c1-200 $E/raw/e5_fixture_build.txt
# 4) 사본에 넣고 G 커밋 (부모 = 핀)
F=$(git -C $C rev-parse HEAD)
cd $C
for rel in docs/reviews/rint2_seal_20261120/registration_R_sealed.md docs/reviews/rint_carbon_additive_registration_R_draft_20261020.md docs/reviews/rint2_kgy_commands_20261020.md docs/data/rint2_r_plan_20261120/ca1_plan.json; do cp "$B/$rel" "$rel"; done
cp $V/make_sealed_copy.py $V/registration_R_insert.md $V/commands_doc_insert.md docs/reviews/rint2_seal_20261120/tools/
cp $V/README.md docs/reviews/rint2_seal_20261120/README.md
git status --porcelain
git add -A
git -c user.name=scratch -c user.email=scratch@invalid -c commit.gpgsign=false commit -q -m "scratch G prep"
T=$(git rev-parse 'HEAD^{tree}')
G=$(git -c user.name=scratch -c user.email=scratch@invalid commit-tree "$T" -p $PIN -m "scratch seal-form commit G (seal candidate v2 · 11-17 field facts · one commit on 64e4d213e · candidate plan four nulls · NOT for push)")
git update-ref refs/heads/seal-form-scratch "$G"
{ echo "# F = $F → G = $G (부모 $(git rev-parse "$G^"))"; git diff --stat "$F" "$G" | tail -12; } > $O/G_diff.txt
cat $O/G_diff.txt; git status --porcelain | wc -l
echo "G=$G"

"""v2 README → v2.1 README (줄 머리 대조 뒤 바꿈 · 새 절 넣음) — argv: <v2 README> <출력>.  자리표 @@…@@ 는 측정 뒤 fill 로 채운다."""
import sys

src, out = sys.argv[1:3]
L = open(src, encoding='utf-8').read().split('\n')
SCRV = '/tmp/claude-0/-home-user-Yonghoon-DEM-DFT/81c0ad95-542f-503b-9cf7-2f6a678a4b5b/scratchpad'


def at(n, prefix, new):
    assert L[n - 1].startswith(prefix), (n, L[n - 1][:80])
    L[n - 1] = new


def sub(n, old, new):
    assert old in L[n - 1], (n, old[:60], L[n - 1][:100])
    L[n - 1] = L[n - 1].replace(old, new)


at(1, '# Rint ② 봉인 후보 v2 (', '# Rint ② 봉인 후보 v2.1 (11-17 · 조수 초안 · 문서 · scratch 만 · 결과 0 건 · 실행 0 · σ 열람 0)')
at(3, '- **지위** = 봉인 후보 v2 ', '- **지위** = 봉인 후보 v2.1 — 봉인 커밋 (Rint 고정 가지 끝 `64e4d213e` 위 문서 커밋) 의 글 · 파일 목록 · 만드는 도구 · 다시 잰 증거.  봉인 자체 = Codex 2/2 GO 뒤 · 결과 전 등록 넷 = Codex 회신 뒤 · S0 단계 2 전 1저자.  v1 (`<scratch>/rint/seal_candidate/`) · v2 (`<scratch>/rint/seal_candidate_v2/`) · 내부 반박 리뷰 (`<scratch>/rint/seal_candidate_v2_review/`) 는 고치지 않았다 (`<scratch>` = 이 세션의 scratch 폴더 · 리포 밖).\n- **v2 → v2.1** = 내부 반박 리뷰 (11-17 · **Codex 아님** · P1 0 · P2 2 · P3 12 · 권고 = 봉인 보류 안 함) 반영 — 증거 ③ 도구 · `make_sealed_copy.py` 의 지킴 범위 고침 (자기 시험 먼저 · 고치기 전 판에서 빠뜨림 확인 뒤) · 명령 문서 (2) · (2b) · (5) · (6) · 봉인본 §10-7 ① 글 · 증거 도구 날짜 인자 · 작은 글 → 표 = 절 "v2 → v2.1".  **봉인 값 (u · tol_ff · tol_P · tol_sj · S0 해시 · 계획 칸 · maxiter · 168 h · 8 · 기계 · env_unit) 은 바뀌지 않았다** — 계획 바이트 · 원본 자리 바이트 = v2 와 같다 [실측 sha256 f09b3efb… · 1cf4a7b4…].')
at(5, '- **읽은 판** = ', '- **읽은 판** = 코드 핀 `64e4d213e` (`git show` · 봉인 꼴 사본의 HEAD 조상) · **11-17 06:56 UTC 측정 값**: 본 리포 HEAD `b3481336c` (= 그때 원격 stoic 끝) · stoic-next (가지 tmp-stoic-next) 끝 `5645b86c8` — 읽기만 (git show · log · ls-tree · archive · `clone --shared`).  v2 의 "본 리포 HEAD 5a04acd15 · stoic-next b3481336c" 는 v2 측정 때 값이다 (리뷰 P3-1 · 그 뒤 바뀜).  리포 · 작업 트리 쓰기 0 · σ 열람 0 · 코드 실행 = scratch 사본에서 `python3 -I` (Python 3.11.18).')
sub(8, '(scratch 후보 폴더 `' + SCRV + '/rint/seal_candidate_v2/`', '(scratch 후보 폴더 `<scratch>/rint/seal_candidate_v2_1/`')
at(12, '| `make_sealed_copy.py` ', '| `make_sealed_copy.py` (커밋 자리 `docs/reviews/rint2_seal_20261120/tools/make_sealed_copy.py`) | 핀 판 원본 등록 R + 조각 + 계획 파일 → 봉인본 · 원본 자리 (표지 한 줄) · 명령 문서 · 계획 사본 바이트 · `_manifest.json` (같은 입력 바이트 = 같은 바이트 · 입력 파일 이름은 넣지 않는다 [실측 두 번 · 전 파일 같음]) · v2.1 = 계획 Q3 꼴 · 두 계획 대조 · `--final` (봉인 때 필수 · 결과 전 넷) · 조각 이름 집합 · 빈 블록 · 표 칸 글 · 자리표 허용 목록 · 달력 날짜 · git 가지 이름 규칙 · 자기 시험 **35/35** (v2 17 그대로 + v2.1 18 · 고치기 전 판 = 17/35) [실측] |')
at(17, '| `evidence/` |', '| `evidence/` | 다시 잰 증거 (봉인 꼴 사본) + 시험 도구 (`evidence/tools/` · v2.1 = `check_sh_commands.py` 고침 + `--selftest` **19/19** (고치기 전 판 = 6/19) · `check_chain_functions.py` · `check_s0_stage2_gate.py` = 날짜 인자) — 봉인 꼴 커밋에서는 `docs/reviews/rint2_seal_20261120/evidence/` · 원장 넘김 흉내 도구 = scratch `work/check_relay_block.py` (봉인 커밋 밖 · 파일 구성을 G′ 와 같게 두려고) |')
sub(24, '+ 그 줄 전부 argparse 대조 (Q2 · 증거 ③)', '+ 그 줄 전부 argparse 대조 (Q2 · 증거 ③ · v2.1 = 도구가 꼴이 다른 줄 · 울타리 · 셈 · 한 문서에만 있는 종류 · `--cjunc-store` 값 (Q4) · 사다리 기계 (Q6) 를 지킨다 · 기대 셈 13 + 1 · 14 + 1 = 독립 셈과 같음)')
sub(26, '봉인 꼴 사본에서 사슬 시험 전체 506/506 · E17 1/1 [실측]', '봉인 꼴 사본에서 사슬 시험 전체 @@E1@@ · E17 1/1 [실측 · G″a]')
sub(27, '→ `scripts/check_doc_refs.py` rc 0 [실측 · §마-4]', '→ `scripts/check_doc_refs.py` rc 0 [실측 · §마-4 · G″ = @@E9@@]')
L.insert(29, '| v2.1 — 내부 반박 리뷰 (Codex 아님) P2 둘 고침 (시험 먼저) · P3 12 = 고침 7 · 한정 5 (절 "v2 → v2.1") | 그 리뷰가 닫지 않은 것 (사슬 시험 전체 · 리포 게이트 전체 · 현장 · 결과 전 넷 · 두 기계 실제 전송) 은 이 판도 닫지 않는다 (사슬 시험 전체 = 이 판이 G″a 에서 다시 돌림) |')
at(32, '## 증거 한눈에', '## 증거 한눈에 (봉인 꼴 사본 = `git clone --shared` · 원격 추적 ref = 본 리포 `refs/remotes/origin/*` 와 이름 · 객체 같음 — 처음 153 개 · 참조 검사 직전 @@REFN@@ 개로 다시 받음 [실측])')
at(34, '- 봉인 꼴 커밋 = scratch 사본의 scratch 가지', L[33] + '\n- **v2.1** = 같은 scratch 가지 이름 `seal-form-scratch`: **G″a** `@@G2A@@` (G′ 나무 + 고친 도구 · 조각 · 그 도구로 다시 만든 봉인본 · 명령 문서 + 증거 도구 · `64e4d213e` 위 한 커밋 · README · `evidence/` 결과 파일 = v2 그대로) → **G″** `@@G2@@` (G″a 나무 + 이 README · G″a 결과로 고친 `evidence/` · `64e4d213e` 위 한 커밋 · G″a ↔ G″ 차이 = 봉인 기록 폴더의 README · `evidence/` 결과 파일뿐 [실측 git diff · @@G2DIFF@@]).  무거운 시험 (사슬 시험 전체 · 게이트 셋 · 규율 검사 · K01 묶음 · E17) = G″a · 참조 · 철회값 · 경계 · ③ · ④ · ⑤ = G″ 에서도 다시 · 사슬 · 게이트 시험 · 규율 검사는 봉인 기록 폴더의 README · `evidence/` 를 읽지 않는다 (`rint2_seal` 0 건 [코드 grep · 핀 판]).  G′ ↔ G″ 파일 구성 같음 (바뀐 바이트만 · @@G2VSGP@@).')
# 증거 표 (옛 37–52 줄 = 지금 +1 · 줄 머리로 찾음)
i0 = next(i for i, x in enumerate(L) if x.startswith('| # | 무엇 | 결과 [실측] | 파일 |'))
i1 = next(i for i in range(i0, len(L)) if L[i].startswith('| v1 표 |'))
L[i0:i1 + 1] = '''| # | 무엇 | 결과 [실측] (v2.1 · G″a / G″) | 파일 |
|---|---|---|---|
| ① | `scripts/test_rint_r_chain.py` 전체 (핀 판 · G″a) | **@@E1@@** (v2: G 506/506 · 552.8 s · F 543.1 s · B 530.0 s · A 498.5 s) · 이 시험은 `claims.json` · 봉인 기록 폴더를 읽지 않는다 [코드 grep] | `evidence/e1_test_rint_r_chain_full_G.txt` (= G″a 결과 · 파일 이름은 v2 그대로) · `…_F.txt` · `…_B.txt` · `…_A.txt` (v2 중간 커밋 · 그대로) |
| ② | `scripts/test_rint_r_chain_e2e.py --only E17` | 1 PASS · 0 FAIL (G″a) | `evidence/e2_e2e_E17.txt` |
| ②′ | `--only K01,PC18,PC20,EP06` (명령 문서 · 원본 자리를 읽는다) | 4/4 PASS (G″a) | `evidence/e13_seal_doc_tests.txt` |
| ③ | 증거 ③ 도구 v2.1 (`--selftest` · 실제 대조 · 독립 셈) | 자기 시험 **19/19** (리뷰 변이 D1–D10 + 새 반례 D11–D16 · D2b · 고치기 전 판 = 6/19 · D2 · D3 · D4 · D8b · D10 = rc 0 로 빠뜨림 그대로 재현) · 실제 대조 (G″) = 봉인본 sh 사슬 13 + S0 1 · 명령 문서 14 + 1 = 기대 셈 · 계약 꼴 (bash) 봉인본 7 + 2 · 명령 문서 13 + 3 · 원본 자리 7 + 2 · 못 읽은 줄 0 · 그 밖 울타리 0 · 도구 이름이 인자로만 나온 줄 3 (명령 문서 `ls` 1 · `git diff` 2) · `--registration` = 봉인본 하나 · `--r-doc` = 봉인본 · 한 문서에만 = `ladder_dry` (허용) · 문제 0 · 독립 셈 (리뷰 `d_indep/count_cmds.py` 그대로) = sh 13 + 1 · 14 + 1 같음 · bash S0 명령 문서 4 ↔ 도구 3 = 독립 셈은 `test_ca_s0_census.py` 줄을 글자 포함으로 센다 | `evidence/e3_sh_argparse.txt` |
| ④ | `--stage plan-doc --check-doc --registration <봉인본>` · 기본 (원본 자리) | rc 0 `PLAN_DOC_SAME` · 기본 = rc 3 `PLAN_DOC_MISMATCH` · 화면 sha256 24ad274f… · 블록 0a62a8b5… (v2 와 같음) (G″a · G″) | `evidence/e4_plan_doc_check.txt` |
| ④′ | 사슬 함수 (봉인본 · 원본 자리 · 계획 · S0 계획) | v2 와 같은 판정 (해시 줄 둘 = 계획 · S0 sha256 · 원본 자리 = 둘 다 `…_UNREGISTERED` · `plans_cross_problems` [] · `require_plan_numbers` = 넷뿐 멈춤) · 날짜 = 인자 (P3-9) | `evidence/e4b_chain_functions.txt` |
| ⑤ | S0 단계 2 관문 `ca_s0_census.verify_plan_commit` + v2.1 도구의 빌드 거부 | 후보 커밋 (r_doc = 봉인본) = 거부 · 사유 = 넷뿐 · 기본 r_doc = 거부 · 고정물 값 커밋 (도구 `--final` 로 다시 만든 봉인본) = **통과** (G″a) · 리뷰 `e_s0gate` 의 틀린 계획 다섯 (tol_ff · len_law · env_unit) = v2 도구는 봉인본을 만들었지만 **v2.1 도구는 만들기 전에 rc 2 (두 계획 대조) · 출력 폴더 없음** | `evidence/e5_s0_stage2_gate.txt` · `evidence/e5_fixture_build.txt` |
| ⑥ | 철회값 등록부 (`docs/reviews/claims.json` `quotation_ban` · 게이트 함수 `ban_sweep` · 바뀐 파일 전부) | G″ = @@E6@@ | `evidence/e6_ban_new_text.txt` · `…_B2.txt` · `…_pin_claims.txt` (v2 그대로) |
| ⑦ | 핀 판 `scripts/check_method_discipline.py` (G″a · 최종 등록부 = stoic 바이트) | **0 오류 · rc 0 (경고 17)** · @@E7S@@ | `evidence/e7_check_method_discipline.txt` · `…_B_pin_claims.txt` (v2 그대로) |
| 참조 | 핀 판 `scripts/check_doc_refs.py` (G″ · 원격 추적 ref = 본 리포 지금 판) | **@@E9@@** | `evidence/e9_check_doc_refs.txt` (v2 절 + G″ 절) |
| 경계 | 바뀐 파일마다 다섯 경로 · CODE_FILES 20 · S0 일곱 · 규율 검사 입력 | G″ = @@E10@@ | `evidence/e10_seal_files.txt` · `evidence/e10_seal_files_B2.txt` |
| 게이트 셋 | 원본 자리 · 원장을 읽는 게이트 시험 셋 (핀 판 · G″a) | `test_probe6_read.py` @@E14P@@ · `test_ca_ext_z3.py` @@E14Z@@ · `test_ca_s0_census.py` @@E14C@@ | `evidence/e14_gate_tests_docs.txt` |
| 도구 | `make_sealed_copy.py --selftest` · 같은 입력 두 번 · 리뷰 변이 34 | **35/35** (고치기 전 판 17/35) · 두 번 출력 전 파일 같음 (`_manifest.json` 포함) · 리뷰 변이 34 = 거부 **30** · 통과 4 (A12 · A13 = 표지 안 글자 · A16 = sh 인자 = ③ 몫 · A28 = 정책 값 — 설계대로) (v2 = 거부 19 · 통과 15) | `evidence/e11_make_sealed_copy.txt` · `evidence/make_sealed_copy_manifest.json` |
| 넘김 | 명령 문서 §3-1b (5) sh 블록 그대로 (scratch `work/check_relay_block.py` · 가짜 홈 둘 · 봉인 커밋 밖) | ① 정상 A→B→A = 받는 쪽마다 `RECV_OK` · 원장 역사 문제 None ② 받는 동안 그 기계 사슬의 덧붙임 = 원장 자리 없음 → 못 씀 · 그 뒤 `RECV_OK` (v2 꼴의 창 닫힘) ③ 갈라진 세워 둔 자리 = `pull --ff-only` 실패 · 되살림 없음 · `RECV_OK` 없음 (멈춤) — 결과 OK (G″a · git 2.43.0 · flock 2.39.3) | `evidence/e13_seal_doc_tests.txt` 끝 절 (원 출력 = scratch `evidence/raw/v21_relay_block.txt`) |
| stoic | stoic 가리킴 다시 (§사) | @@E12@@ | `evidence/e12_stoic_refs.txt` |
| v1 표 | v1 (가) 표가 적은 줄 번호 65 개 | 65/65 맞음 (핀 판 · v2 그대로) | `evidence/e8_v1_table_lines.txt` |'''.split('\n')
open(out, 'w', encoding='utf-8').write('\n'.join(L))
print('ok', len(L))

"""Package local review evidence, without original workbooks or MPH."""
import hashlib
import json
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED

OUT = Path(__file__).resolve().parent
FILES = ['MICROSHORT_MPH_V2_CODEX_REVIEW.md',
         'mph_v2_extractor_report.md', 'mph_v2_solver_scope_review.md',
         'mph_v2_workbooks_review.md', 'mph_v2_extractor_check.py',
         'mph_v2_solver_scope_inspect.py', 'mph_v2_workbooks_audit.py',
         'mph_v2_physics_checks.py', 'mph_v2_replay.py', 'mph_v2_package.py',
         'mph_v2_extractor_evidence.json', 'mph_v2_solver_scope_evidence.json',
         'mph_v2_workbooks_evidence.json', 'mph_v2_physics_evidence.json',
         'mph_v2_replay_log.json', 'mph_v2_target_hashes.json']


def main():
    identities = {name: {'bytes': (OUT / name).stat().st_size,
                         'sha256': hashlib.sha256((OUT / name).read_bytes()).hexdigest()}
                  for name in FILES}
    manifest = {'scope': 'Local review package. No original MPH or XLSX, but evidence contains measured values and model settings; not uploaded.',
                'files': identities}
    manifest_path = OUT / 'MICROSHORT_MPH_V2_MANIFEST.json'
    manifest_path.write_text(json.dumps(manifest, indent=2) + '\n', encoding='utf-8')
    package_path = OUT / 'MICROSHORT_MPH_V2_REVIEW_PACKAGE.zip'
    with ZipFile(package_path, 'w', compression=ZIP_DEFLATED) as archive:
        for name in [*FILES, manifest_path.name]:
            archive.write(OUT / name, arcname=name)
    with ZipFile(package_path) as archive:
        assert archive.testzip() is None
        for name, record in identities.items():
            assert hashlib.sha256(archive.read(name)).hexdigest() == record['sha256']
    print(json.dumps({'path': str(package_path), 'members': len(FILES)+1,
                      'bytes': package_path.stat().st_size,
                      'sha256': hashlib.sha256(package_path.read_bytes()).hexdigest(),
                      'integrity': 'PASS'}, indent=2))


if __name__ == '__main__':
    main()

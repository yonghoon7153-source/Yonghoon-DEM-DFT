# Saved-model scope review — d72e735f

The actual archive supplies two decisive corrections to the v2 review: the current particle nodes select material maximum concentrations, and the remembered plot selection links to a materially different model snapshot. The proposed two-value SOC check therefore does not identify the current implementation unless its dataset and model state are fixed first. No live COMSOL display was inspected.

Read-only review; no COMSOL execution, source changes, or solution-binary decoding. Exact ownership paths, serialized values, source-member names, and 1-based XML start lines are in `mph_v2_solver_scope_evidence.json`. COMSOL `1|1,'…'` wrappers are omitted below for readability. Current-model line numbers refer to the MPH member `dmodel.xml`; snapshot line numbers explicitly name their other member.

## 1. M1: the omitted particle source selector changes the inference

The two current particle nodes contain both a source selector and a retained user-expression field:

| Setting | Negative electrode `liion/pce1/pin1` | Positive electrode `liion/pce2/pin1` |
|---|---|---|
| `ParticleMaterial` | `mat1` (1368) | `dommat` (2510) |
| `cEeqref_mat` | **`from_mat` (1369)** | **`from_mat` (2511)** |
| Retained `cEeqref` | `cs_Gr_max*dm_fNE` (1370) | `cs_NCM_max*dm_fPE` (2512) |
| `csinit` | `x_Gr_init*cs_Gr_max` (1378) | `x_NCM_init*cs_NCM_max` (2520) |

The selected material path has no `dm` factor. `mat1/def.csmax = 31507[mol/m^3]` (5999); `mat5/def.csmax = cs_NCM_max` (7559). Each material's `ElectrodePotential.cEeqref = def.csmax` (6137, 7609), and each material's `soc = c/cEeqref` (6140, 7612). `mat5` has the same domain-selection encoding as `pce2`, `entities="4,3"` (7502 versus 2392); `mat1` and `pce1` likewise share `4,1`.

Thus the ordinary interpretation of the explicit source selectors gives initial particle ratios `x_Gr_init` and `x_NCM_init`, approximately **0.011721 and 0.924064** using the document's current-input arithmetic. It does not give `x_init/dm` merely because that text is retained in a nonselected field. Generated COMSOL expressions and numerical SOC values were not evaluated here; that remaining limit does not rescue the document's inference from the retained field.

`docs/MICROSHORT_MPH_REVIEW.md:205`–221 and `reviews/MPH_R1_RESPONSE.md:55`–66 should be revised around this missing selector, rather than describing four observations as strong support for `x/dm`. Equal default-looking reaction fields also do not prove that nobody ever edited them. The relevant evidence is the selected source and resolved material property.

## 2. M8: the saved plot selection links to a different LAM implementation

The saved UI metadata remembers study `std1` and plot `pg19` (`guimodel.xml`), but also records `guiView=GEOM`; it does not prove a result plot was on screen. The explicit reference chain is:

`pg19 → dset1 → sol1 → soldata/sol19, savepoint6`

The respective current-XML lines are 16339, 12098, 9602, and 9606. `value="none"` on the dataset reference is accompanied by `Reference="/sol/sol1"` and `CompositeIndex="1"`; reading only its `value` attribute would lose the reference.

The linked member `savepoint6/model.zip!/dmodel.xml` records a different model:

| Setting | Current `dmodel.xml` | Linked `savepoint6/model.zip!/dmodel.xml` |
|---|---|---|
| `epss_el` | `epss_el_0*(1-LAM_NE)` (287) | `epss_el_0` (37) |
| `epss_pos` | `epss_pos_0*(1-LAM_PE)` (316) | `epss_pos_0` (66) |
| `x_NCM_init` | Li-inventory expression (333) | **`0.9189896` (83)** |
| Both `pin1.cEeqref_mat` | `from_mat` (1369, 2511) | **`userdef` (1109, 2253)** |
| Both `pin1.csinit` | `x_init*cs_max` (1378, 2520) | **`x_init*cs_max*dm` (1118, 2262)** |
| Both retained `pin1.cEeqref` | `cs_max*dm` | `cs_max*dm` |

In the linked snapshot the `dm` factors cancel in `csinit/cEeqref`; its positive initial particle ratio is **0.9189896**, a third value absent from the document's proposed `0.924064` versus `0.952290` check. This is saved-configuration algebra, not a decoded numerical solution. Nevertheless, the different source selector, initial concentration, volume fraction, and initial stoichiometry are direct evidence that evaluating the existing `dset1` does not by itself validate the present editable model.

The old sweep is also directly verified, beyond solution names:

| Solution | `paramNames` | `paramVals` | Savepoint |
|---|---|---|---|
| `sol1` | Empty (9610) | Empty (9612) | 6; embedded model has `C_rate=0.1`, `sigma_short=1e-20[S/m]` |
| `sol3` | `C_rate,sigma_short` (11768) | `0.05,1.0E-20` (11770) | 4 |
| `sol4` | Same (11846) | `0.05,1.4E-6` (11848) | 1 |
| `sol5` | Same (11918) | `0.05,4.67E-6` (11920) | 3 |
| `sol6` | Same (11990) | `0.05,1.4E-5` (11992) | 5 |

`dset2 → sol2` (12132), and `sol2` groups the four old stored solutions. The parametric study feature is explicitly `DISABLED`. The latest saved metadata says COMSOL 6.4.0.293 and 8.314 s, but timestamps alone do not establish that current editable inputs produced the linked solution. M8 should identify both stored families and the changed LAM implementation, rather than saying simply “the stored solution is 0.05C.”

## 3. Area is an input to initialization, not only postprocessing

The claim at `MICROSHORT_MPH_REVIEW.md:61` is contradicted by current expressions:

`A_cell → dLi_LLI = C_lit0_ref1*LLI/F_const/A_cell → nLi_target → x_NCM_init → pce2/pin1.csinit`

The corresponding current-XML lines are 360, 361, 363, 333, and 2520. The 1D current boundary may use a 1 m² normalization, but the actual cell area also converts cell lithium inventory to areal inventory **before solving**. Changing `A_cell` with cell-level inventory inputs fixed changes initialization.

## 4. Study scope, Events, initialization and Stop Condition

- Current `Physics ev` has its own `DISABLED` flag (3420); its event children inherit that state. `std1/time` separately retains an activation table containing `ev,on`, along with `liion,c,ge,ge2,on` (9445). These are different scopes and should both be recorded. The linked `savepoint6/savepoint.xml` lists active physics `liion`, `c`, `ge`, and `ge2`, but no `ev`, which supports the disabled-event interpretation for that saved snapshot.
- Current solver `sol1/v1` retains components `comp1.Cap` and `comp1.E_lith,comp1.E_delith`; no own or ancestor `DISABLED` flag is present. The linked snapshot marks `ge` and `ge2` active. Their declared equations and zero initial values agree with M6/M7. That establishes stored definitions and solver membership, not the time history of their numerical values.
- The current study has `initstudy=zero`, `initsol=current` (9461, 9463). The attached solver's dependent-variable node is explicitly under `control=user` (9743), with `initsol=zero` and `notsol=zero` (9745, 9755). `initmethod` appears only in `NodeDefaultValues` (9772). The string `current` in a study property with no explicit solution reference does not establish initialization from an old result. A resolved COMSOL initialization report would be needed to close that runtime question.
- `sol1/t1/st1` is a **StopCondition** node without an own or inherited disabled flag. It has `updateEventSettings=on`, `storestopcondsol=stepbefore`, `stopcondwarn=off` (11547–11551). `stopcondarr`, `stopcondActive`, `eventstopActive`, and `eventstopName` appear only in `NodeDefaultValues` (11552), not as explicit saved values. Static data therefore closes the existence and own-state question, but it does **not** show an explicitly empty expression array or establish that every event-stop path is absent.

## 5. M2: selected scope and correction mode; exponent remains unresolved here

`pcb1` explicitly selects the domain-2 encoding `entities="4,2"` (1084), while `pce1`/`pce2` select encodings `4,1`/`4,3`. Ground and cycling select boundary encodings `-4,-1,1` and `-4,-1,4` (2802, 2902). These raw encodings are preserved rather than interpreted as literal lists of geometric entity numbers.

`pcb1.sigma_mat=userdef` and its diagonal conductivity is `sigma_short` (1102–1103); `epss=epsl=epsl_sep` (1110, 1112), and `ElectricCorrModel=Bruggeman` (1116). No explicit binder exponent property was found in its saved direct parameters. `b_PE` belongs to the positive electrode's **user-defined** correction expressions `fl=fs=fDl=epsl_pos^b_PE` (2424–2428); it must not be assigned to the binder.

`sep1` has default-selection flags and an explicit-selection element with no entity list; its retained `epss=0.4` is not enough to establish that this fraction is added to `pcb1.epss` in the same generated equations. Static XML establishes the selected binder mode and domain, but COMSOL's feature precedence and generated correction expression remain the proper evidence for summation and the effective exponent.

## Evidence identity

- Supplied outer ZIP SHA-256: `e0f2720e9e08d58b7769b21e963ce6250bcf58031eff73f2c59a57952a8eefc6`
- Inner `ICA_degradation mode.mph`: `8b2e71506ba2a5ebad1ce27e268417b0e74b28cbaa9a81d1a6c32c58573557a9`
- Current `dmodel.xml` (2,622,953 bytes): `6aa8ebdad37da698dfd8c1cbe65451292dbdfd5f7ece60a9a33cabe8e3b0cfa6`

The companion evidence JSON includes individual snapshot XML hashes. Reproduction uses the bundled Python runtime with `mph_v2_solver_scope_inspect.py --build` followed by `--finalize`; ZIP layers are inspected in memory, and only generated review evidence is written.

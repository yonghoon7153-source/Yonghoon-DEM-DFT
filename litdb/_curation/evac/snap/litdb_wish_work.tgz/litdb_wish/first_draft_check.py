#!/usr/bin/env python3
"""11-12 첫 판 (tools/wishlist_table.py) 의 열쇠 (성 + 해) 를 지금 항목에 다시 매겨 묶음 오류를 센다 (읽기만).
python3 -I first_draft_check.py <items.tsv> <first_draft.tsv>"""
import os, re, sys, unicodedata
from collections import defaultdict
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from keys import K
items_p, fd_p = sys.argv[1:3]
def fold(s):
    return "".join(c for c in unicodedata.normalize("NFKD", s) if not unicodedata.combining(c)).lower()
def first_author(bib):
    b = re.sub(r"^\s*(\[[^\]]*\]\s*)+", "", bib).strip()
    tok = re.split(r"[,;]", b)[0].strip()
    words = [w for w in re.split(r"\s+", tok) if w]
    if not words:
        return ""
    if re.fullmatch(r"([A-Z]\.(-?[A-Z]\.)?\s*)+", " ".join(words[:-1]) + " ") or all(re.fullmatch(r"[A-Z]\.(-[A-Z]\.)?", w) for w in words[:-1]):
        name = words[-1]
    else:
        name = words[0]
    return fold(re.sub(r"[^\w\-]", "", name)).split("-")[0]
def year(bib):
    m = re.findall(r"\b(19[5-9]\d|20[0-2]\d)\b", bib)
    return m[0] if m else ""
fd = [l.rstrip("\n").split("\t") for l in open(fd_p, encoding="utf-8")][2:]
fd_batches = set()
for r in fd:
    for s in r[4].split(";"):
        fd_batches.add(s.split(" ")[0])
fd_keys = {r[0] for r in fd}
rows = [l.rstrip("\n").split("\t") for l in open(items_p, encoding="utf-8")][1:]
m = defaultdict(set); back = defaultdict(set); ex = defaultdict(list)
n_in = 0
for idx, line, batch, bib, why, check in rows:
    if batch not in fd_batches:
        continue
    n_in += 1
    k = first_author(bib); y = year(bib)
    fk = f"{k}{y}" if k and y else ("?" + bib[:30])
    m[fk].add(K[int(idx)][0]); back[K[int(idx)][0]].add(fk); ex[fk].append((int(idx), bib[:70]))
print("첫 판 배치", len(fd_batches), "· 그 배치의 지금 항목", n_in, "· 첫 판 열쇠 재현", len(m), "/ 첫 판 TSV 열쇠", len(fd_keys))
print("재현 안 된 TSV 열쇠", sorted(fd_keys - set(m))[:20])
print("== 첫 판 한 열쇠에 다른 논문 둘 이상 (합친 오류) ==")
for fk, ks in m.items():
    if len(ks) > 1:
        print(fk, sorted(ks), [e[0] for e in ex[fk]])
print("== 같은 논문이 첫 판 열쇠 둘 이상 (나눈 오류) ==")
for k, fks in back.items():
    if len(fks) > 1:
        print(k, sorted(fks))
print("== 성을 못 읽은 열쇠 (머리글자 · ? ) ==")
bad = [fk for fk in m if fk.startswith("?") or re.match(r"^[a-z]\d{4}$", fk)]
print(len(bad), sorted(bad))

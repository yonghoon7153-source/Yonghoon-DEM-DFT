# LHS214 사전 점검 SHA 형식 수정 재확인 요청 — 2026-10-24 KST

> 현재 canonical 전체 gate: **PASS, 155/0, rc 0**. [완료 기록](lhs214_pin_syntax_fix_evidence_20261024/completion.md)을 따른다. 아래 작성자/초기 반입 시점의 예정·대기 문구는 원 스냅샷의 범위이며 현재 상태를 대신하지 않는다.


이번 확인 대상은 `git.sha = 승인된 40자리 + LF`를 사전 점검 P7·P10이 받아들이던 P3 형식 결함의 수정이다. 1저자의 현재 **“다 비준이야”**로 후속 수정·준비의 비준을 기록했다. 실제 WSL 측정·외부 GO·생산 발사 사실을 비준으로 대신하지 않는다.

기준 리뷰 핀은 `ffbd438e7522d58eb069561fe58020f4086707ac`이며, 수정 전달 가지는 `codex/lhs214-relaunch`다. 최종 리뷰 핀·전체 gate 영수증은 canonical 반입과 검증을 마친 root가 지정한다. 현재 문서는 아직 그 핀의 외부 판정문이 아니다.

## 수정과 경계

발견 근거는 [10-23 독립 검토](codex_review_lhs214_preflight_20261023.md) §3이다. `scripts/run_network_194_parallel.py:2049`와 `:2082` 두 곳의 `_HEX40.match(gsha)`를 `.fullmatch(gsha)`로 바꿨다. `_HEX40` 정의, 다른 호출자 `launch_eligibility`, 승인 SHA의 기존 7–40자리 규약, 등록 기대값, 원장, 봉인 32 파일은 바꾸지 않았다. runner 자체는 봉인 32 목록에 없으며 그 해시는 영수증에 기록된다.

이전 증거에서 마지막 hex를 바꾸면 P10이 이미 거부했다. 이번 수정은 같은 승인 40자리 뒤 LF가 붙은 JSON 형식을 거부하는 범위다. 수치 결과나 실제 생산기가 LF를 생성한다는 증거, 다른 승인 커밋 우회를 주장하지 않는다.

## 실제 검증

[증거 폴더](lhs214_pin_syntax_fix_evidence_20261024/README.md)에 전체 로그·명령·SHA-256을 보존했다.

| 검증 | 수정 전 | 수정 뒤 |
| --- | --- | --- |
| 여섯 SHA 경계 assertion | LF 꼬리 하나로 rc 1 | 6/6 기대 일치, rc 0 |
| 기존 receipt 자체시험 | 123/123, rc 0 | 123/123, rc 0 |
| 정상 preflight·합성 194/20 launch | 통과 | 통과 |
| 봉인 32 전체 바이트 | 기준 핀 | 32/32 동일 |
| 활성 code_fp | `2149f8738bb20b6a311b3c5b344b9745271a3f1324cabfb4582c175c3983c3eb` | 동일 |

검증은 로컬 Git archive 사본에서 진행했다. 전체 repository gate·canonical commit 검증·독립 재공격 결과는 root가 별도 반입한다. WSL 실자료와 외부 발사 확인 판정은 아직 수령되지 않았다.

## 확인 요청

1. P7/P10 두 호출의 전체 문자열 검사가 LF 반례를 막고 정상 핀·다른 hex 거부·승인 SHA 기존 동작을 유지하는가.
2. 새 경계 시험이 실제 생산 검사기를 사용하며, 기존 정상 preflight·합성 launch 회귀와 S0b를 약화시키지 않는가.
3. 수정이 봉인 32·등록 지문·다른 SHA 사용처·물리 값에 닿지 않는가.
4. [WSL 실제 입력·영수증 체크리스트](lhs214_wsl_receipt_checklist_20261024.md)가 기존 패키지를 중복하거나 합성 증거를 실제 측정으로 승격하지 않는가.

P3 수정 확인과 실제 LHS214 발사 범위 GO는 별개다. 기존 [발사 요청서](codex_lhs214_relaunch_check_request_20261020.md)의 B7 PIN·새 ROOT 둘·WSL 영수증·손 대조 빈칸은 실제 자료를 반입한 뒤 채운다. S3·v1.3 HOLD와 `L214R-S03`·`L214R-S05` 한정은 유지한다.

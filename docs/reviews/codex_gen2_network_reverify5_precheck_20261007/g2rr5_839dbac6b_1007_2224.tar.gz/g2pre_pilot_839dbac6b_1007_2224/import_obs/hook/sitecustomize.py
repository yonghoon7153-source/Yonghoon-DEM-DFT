# np194 import 관측 훅 (sitecustomize) — run_network_194_parallel.IMPORT_OBS_HOOK 이 쓴다 · 값에 닿지 않는다 · 예외를 밖으로 내지 않는다
import atexit, json, os, sys
_L, _R = os.environ.get("NP194_IMPORT_LOG"), os.environ.get("NP194_IMPORT_ROOT")
_P = set()
_PID = os.getpid()
_TOK = None
_ID = None
_MAIN0 = None


def _np194_write(path, text):
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as fh:
        fh.write(text)
    os.replace(tmp, path)


def _np194_dump():
    try:
        if _TOK is None or os.getpid() != _PID:
            return
        mf = getattr(sys.modules.get("__main__"), "__file__", None)
        main = _MAIN0 or (os.path.realpath(mf) if mf else None)
        fs = {os.path.realpath(getattr(m, "__file__", None) or "") for m in list(sys.modules.values())} | _P | ({main} if main else set())
        fs.discard(os.path.realpath(""))
        mods = sorted(f for f in fs if f.startswith(_R + os.sep))
        head = dict(schema="np194_import_obs/log/v1", proc=_TOK, pid=_PID, identity=_ID, complete=True, n=len(mods), main=main)
        _np194_write(os.path.join(_L, _TOK + ".txt"), json.dumps(head, sort_keys=True) + "\n" + "".join(f + "\n" for f in mods))
    except Exception:
        pass


if _L and _R:
    try:
        import importlib.util as _u
        _sf = _u.spec_from_file_location

        def _spec(name, location=None, *a, **k):
            if location is not None:
                _P.add(os.path.realpath(str(location)))
            return _sf(name, location, *a, **k)
        _u.spec_from_file_location = _spec
        _ID = {k: os.environ.get(e) for k, e in (("run_id", "NP194_OBS_RUN_ID"), ("run_no", "NP194_OBS_RUN_NO"),
                                                  ("case", "NP194_OBS_CASE"), ("attempt", "NP194_OBS_ATTEMPT"))}
        _a0 = (list(getattr(sys, "argv", None) or []) or [""])[0]
        _MAIN0 = os.path.realpath(_a0) if _a0 and _a0 not in ("-c", "-m") and os.path.isfile(_a0) else None
        _TOK = "%d-%s" % (_PID, os.urandom(4).hex())
        _np194_write(os.path.join(_L, _TOK + ".start.json"),
                     json.dumps(dict(schema="np194_import_obs/start/v1", proc=_TOK, pid=_PID, ppid=os.getppid(), identity=_ID, main=_MAIN0,
                                     argv=list(getattr(sys, "argv", None) or []), orig_argv=list(getattr(sys, "orig_argv", None) or [])),
                                sort_keys=True))
        atexit.register(_np194_dump)
    except Exception:
        _TOK = None

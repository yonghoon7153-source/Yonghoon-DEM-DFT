# 내부 반박 리뷰 재확인 (Codex 아님) · 대상 2f97617ef..0ac6edf3c · 11-12

- 대상 = 작업 트리 (rint-codepkg) 의 `4557a30c2` 시험 먼저 · `94765bed3` 고침 · `0ac6edf3c` 게이트 배선 — **고친 곳만**.  판정 아님 · 지적 목록 (Codex verified 로 올리지 않는다).
- 실험 자리 = `review/work2/` (`git archive 0ac6edf3c` 일부 = scripts · webapp · docs/data · docs 꼭대기 · docs/reviews 꼭대기 + 하위 폴더 여섯 → `new` · 바탕 af3cce37b 판 = `base` · 고치기 전 판 (2f97617ef 코드 + 4557a30c2 시험) = `before` · 하드링크 사본).  기록 = `work2/logs/` · 반례 = `work2/ce/` · 변이 = `work2/tools/` · `work2/mut2_results.json` · 끔 경로 = `work2/ovb/`.
- 차례 = diff + 1 회차 리뷰 → 시험 · 반례 · 변이 → 맨 끝에 notes · amend_drafts 로 주장 대조.  킷 풀이 · GPU · σ 열람 없음 (끔 경로는 잎 대조만).

> ⚠⚠ **사고 (이 리뷰 · 내 잘못)** — archive 사본 (git 저장소 아님) 에서 `git show 11a794674:…` 를 쓰려고 `GIT_DIR=<본 리포>/.git` 를 줬다.  명령 앞 덧붙임
> (precond 시험 = `git show` 만) 에서 시작해 ⓐ 변이 하네스 (변이 21 시험 전부의 env) ⓑ 게이트 범위 118–119 (`bash scripts/check_all.sh` 앞 덧붙임 → 자식 전부 ·
> 저장본 시험 전체 포함) ⓒ 빠른 묶음 (`export` → run_contract selftest · ca_ext_b6 · ca_ext_runner · 규율 selftest) 까지 넘겼다.  ⓒ 의 run_contract selftest 임시 폴더
> `git init · add -A · commit -qm i` 가 `-C 임시 폴더` 대신 본 리포에 써서 가지에 쓰레기 커밋 `ff61079c2` (트리 = scripts/x.py) 을 만들었다 (조정자 보고 · 본 세션이
> `bfd9b3bbd` 로 되돌림 · push 없음).  나는 그 selftest 의 122/124 (RCPT-sha-clean · RCPT-sha-untracked 실패) 를 "환경 산물" 로만 읽고 GIT_DIR 없이 다시 돌려 124/124 를
> 적었다 — **쓰기 부작용을 보지 못했다.**  확인한 범위 = **없음** (멈춤 지시 뒤 명령을 돌리지 않았다).  추정 · 본 세션이 볼 것: ① 커밋 트리가 scripts/x.py 하나 ⇒
> `add -A` 가 본 리포 **index** 를 임시 트리로 바꿨다 (되돌림이 `--soft` · `update-ref` 였다면 index 가 아직 그 꼴) ② 가지 reflog — `bfd9b3bbd` 가 내 첫 GIT_DIR 실행
> (ⓐ 변이 하네스) **앞**의 끝인가 · ⓐ ⓑ (저장본 시험의 P · R · C · 러너 시험 · 규율 selftest) 가 다른 커밋 · ref · worktree 등록 · stash 를 만들었는지 ③ `.git/config`
> (시험이 `git config user.*` 를 썼다면 본 리포 작성자 신원이 바뀐다).
> **표지**: ⚠사고뒤 = 사고 뒤에 돈 결과 → **믿지 않는다** · ⚠GIT_DIR = 사고 전이나 GIT_DIR 를 넘긴 채 돈 결과 (다시 확인 권고) · (git show) = GIT_DIR 덧붙임이나 시험이
> 부르는 git 은 `git show` 하나 (읽기) · 표지 없음 = GIT_DIR 없이 · 사고 전.
> 사본 (`work2/new · base · before · ceA/tree · gate_mut` · 하드링크 · 약 330 MB) 은 멈춤 지시로 지우지 않았다.

## 1. RCP 별 닫힘 — 닫힘 7 · 일부 3 · 안 닫힘 1

| RCP | 1 회차 | 판정 | 근거 (행 = 0ac6edf3c · 시험) |
|---|---|---|---|
| 01 저장본 열쇠 코드 칸 | P1 | **닫힘** (지적 범위 = CE1 부류) | `cjunc_store.py:66` 넷 (+ `fibre_segment_raster`) · `:393–406` `code_file` = find_spec (불러오지 않음) · `:480–483` · 고치기 전 판 T14a–d 실패 (사유 = fsr 열쇠 밖 · CE1 hit) → 뒤 54/54 (3.11 · 3.8) · CE1 다시 = 원판 열쇠 4fe10b2e1655 ↔ 변이판 7d086d11b8e1 · built_written · 원장 202eb91e965d (1,911 위치 · 옛 = 같은 열쇠 hit f24cbd6245dc · 833) · 변이 N1 · N2 · N20 · N21 잡힘 ⚠GIT_DIR.  원장 모듈 import = 표준 · numpy · scipy · 넷뿐 · 동적 import 없음 · 모듈 전역 바꿈 없음 (코드 읽기).  남은 틈 = **RCP2-01** (같은 결과 · 다른 길) · RCP2-05 |
| 02 게이트 배선 | P2 | **닫힘** | `check_all.sh:329 · 330 · 332` (단계 118 · 119 · 120 · 목록 183 → 186) · `check_kgy_py38.sh:62–64` + 끝 줄 16 · 세 시험 main = 실패 시 rc 1 · `run` = 실패면 FAIL=1 (코드 읽기) · 변이 나무 (N1 + N18) 범위 118–119 = 둘 다 ✗ · rc 1 ⚠GIT_DIR · CI = Rint 줄 없음 (처분 그대로) |
| 03 독립 대조 범위 | P2 | **일부** | 문장 한정 (`cjunc_store.py` 머리 · 시험 머리 · T7 보고 줄 = "SV 모서리 팔만") ✓ · (가) S0 단계 2 원장 지문 ↔ DBE arm 0 대조 = 미구현 (1저자 Q-A) → 비 SV 팔은 낡은 원장 (CE1 · RCP2-01 꼴) 을 멈춤 없이 받는다 그대로 |
| 04 실침대 저장 재기 | P2 | **일부** | 블록 ✓: md5 둘 (329fc738… · ff385531…) = 블록 속 heredoc · 멈춤 다섯 (PIN 자리표 · PROBE=2 · TAG 빈칸 · BASE 비 git · 끝 표지 없는 앞 로그 폴더) 모두 rc 2 · 새 폴더 0 (가짜 HOME) · 쓰기 = 새 폴더 셋 + 핀 작업 트리 + tgz · S0 쓰기 = `--out` · 임시 폴더 (킷 · 11-08 산출 안 건드림 · 코드 읽기).  ✗ 문턱 T1–T3 · 기대 E1–E4 = 스크래치 초안 (amend 4 판 2-b · [제안]) 에만 → **RCP2-04** |
| 05 실행 자리 지문 | P3 | **닫힘** (한정 둘 명시) | `cjunc_store.py:408–415` · `:484` · T4 (venv · numpy · scipy 자리 셋 · 경로 글 없음) · 변이 N3 · N4 잡힘.  남음 = 같은 자리 재설치 · 복제 machine-id (docstring 한정) · 파이썬 = 부 판 글자만 |
| 06 소유자 · 모드 · 심볼릭 | P3 | **일부** | 파일 `:712–715` · 뿌리 Store `:465–471` · 사슬 `rint_r_chain.py:5619–5624` · 러너 `sdcp_gain_vox015_8arm.sh:606–609` ✓ · 중간 성분 링크 (정직한 "홈이 다른 자리") = 세 겹 다 받음 ⚠사고뒤 (git 안 씀) · T7 · T7c · T11 · R1 · C1 · 변이 N5–N8 · N10–N13 잡힘.  남음 = `링크/.` 우회 **RCP2-02** · 그룹 쓰기만 놓치는 변이 N9 안 잡힘 **RCP2-03** · lstat ↔ open · 뿌리 검사 ↔ 사용 바꿔치기 = 한정 (경로 기준 · fd 아님) |
| 07 tmp · 사슬 기록 | P3 | **안 닫힘** | 코드 무변경 · 처분 = 한정 (amend 0-c · 본 세션 결정) |
| 08 no_linop | P3 | **닫힘** | `step3_sigma.py:565–578` · `:600–608` (사유별 조치 글 · 자원 낱말 없음 → 사슬 자동 재시도 아님) · G6b 둘 · G6 글 전체 같음 · 19/19 (3.11 · 3.8) (git show) · 고치기 전 18/19 · 변이 N17 · N18 잡힘 |
| 09 G4 공허 | P3 | **닫힘** | G4a = A ↔ C 적용 바이트 차이가 정확히 (C = −0 ∧ A = +0) 칸 (−0 · 음의 비정규 입력) = 판별 · G4b = 생산 꼴 b 8 풀이 r 에 −0 없음 · 반복마다 A = C · G4c 관찰로 낮춤 (코드 읽기 + 19/19) |
| 10 예외 · rasterize-only | P3 | **닫힘** | `mpm_webapp_payload.py:935–938` · `:943` · `:2490` · P1 (여섯) · P1b (입구 · 본 길) · 변이 N14–N16 잡힘 |
| 11 머리 호스트 이름 | P3 | **닫힘** | `cjunc_store.py:575` writer = pid · utc · build_seconds · socket 뺌 · T5i · 변이 N19 잡힘 |

## 2. 새 지적 — P1 0 · P2 2 · P3 4

| 번호 | 등급 | 어디 | 반례 · 근거 | 고칠 방향 |
|---|---|---|---|---|
| RCP2-01 | **P2** (조건부) | `cjunc_store.py:480–483` (코드 칸 = Store() 때 디스크 해시) · `:636–692` `get_or_build` (발행 전 코드 칸 다시 안 봄) | **CE-A** (`work2/ce/ceA.py` · `ceA_out.txt` · 표지 없음): fsr 를 원판으로 불러온 뒤 같은 자리를 CE1 변이판으로 바꾸고 Store → 열쇠 7d086d11b8e1 (= 변이판 열쇠) 에 **원판 원장** f24cbd6245dc (833) 발행 → 새 프로세스 (디스크 = 변이판 · 정직한 런) = **hit** · f24cbd6245dc 받음 (그 코드로 지으면 202eb91e965d · 1,911) · 머리 · 엄격 · registry_fp · sid 대조 다 지남.  방아쇠 = 런 도중 코드 바뀜 (불러온 뒤 ~ Store 전 · 또는 Store 뒤 ~ 늦게 불리는 모듈) = ⑤ 정직한 흐름 밖 → P1 아님 · 그러나 어긋난 기록이 **멈춤 없이 뒤 런에 지속** = ⑤ 둘째 갈래 (멈춤 확인) 미충족.  docstring 한정 "코드 칸 = 그때의 디스크" 는 이 지속을 적지 않는다 | (가) 발행 직전 코드 칸 다시 셈 ≠ Store() 값 → 발행 안 함 (나) Store() 때 이미 불린 CODE_MODULES 파일의 mtime_ns > 프로세스 시작 (또는 `cjunc_store` import 시각) → 그 런 저장본 끔 (다) 운영 = 저장본 폴더를 봉인 핀마다 새로 · 한정 문장에 "런 도중 코드 바뀜 → 뒤 런 적중" |
| RCP2-02 | P3 | `cjunc_store.py:418–420` `root_last` · `:465–471` · `rint_r_chain.py:5619–5624` · `sdcp_gain_vox015_8arm.sh:606–609` | 뿌리 심볼릭 거부 = 마지막 **글자** 성분만 → `<링크>/.` · `<링크>/./` · `<링크>/../<링크>/.` 를 Store · 사슬 둘 다 받음 (`work2/sym_probe.py`) · 러너 같은 꼴 (빗금만 걷고 `[ -L ]` = 거짓) · 사슬 글자 규칙이 `.` 허용 (`<링크>` · `<링크>/` · `<디렉터리>/../<링크>` 는 거부) | `.` · `..` · 빈 성분 거부 (`os.path.normpath(p) == (p.rstrip('/') or '/')` · 러너 `case`) · 문서 범위 "마지막 성분 · 중간 링크는 따른다" |
| RCP2-03 | P3 | `test_cjunc_store.py` t7 갈래 표 (`'파일 모드 0666'` 하나 · 1030 행 부근) | 변이 N9 (`_read_members` 모드 검사 0o022 → 0o002 = 그룹 쓰기 놓침) **안 잡힘** ⚠GIT_DIR — 0666 은 남 쓰기도 있어 둘을 못 가른다 | 0464 · 0664 (그룹만) · 0446 · 0646 (남만) 갈래 · 뿌리 (T11) 에도 |
| RCP2-04 | P3 | `s0probe/s0_rerun_probe_block.txt:1–8` · amend 4 판 2-b | (a) 결과 전 기대 E1–E4 · 문턱 T1–T3 [제안] 이 블록에도 리포에도 없다 (스크래치만) → 결과가 오기 전 등록을 확인할 자리가 없다 (b) 머리 "Writes only …" 에 BASE 의 `git fetch` (FETCH_HEAD · 원격 추적 ref) · `git worktree add` 관리 자리 빠짐 | 블록 보내기 전 E · T 를 리포 문서에 커밋 (또는 블록 머리) · 머리 문장 고침 |
| RCP2-05 | P3 | `test_cjunc_store.py` T14 절 (1544 행 뒤) `ran_files` (scripts/ 안 파일만) · `project_imports` (`scripts/<이름>.py` 있는 것만) | 원장 코드가 scripts/ 밖 모듈이나 numpy · scipy 밖 제3자 패키지 (판이 열쇠 밖) 를 부르기 시작하면 T14a · b 가 거른다 (부분집합 필터 · 규율 ⑤) — 지금 원장 import 는 표준 · numpy · scipy · 넷뿐 (코드 읽기) | T14b 허용 = 표준 ∪ {numpy, scipy} ∪ CODE_MODULES · 그 밖 import = 실패 |
| RCP2-06 | **P2** (제안) | `scripts/run_contract.py` `--selftest` RCPT-sha-clean · RCPT-sha-untracked (임시 폴더 `git init · add -A · commit -qm i` · 행 [미확인 — 멈춤 지시 뒤 읽지 않음]) · 읽기 쪽 같은 꼴 = `mpm_webapp_payload.py:639` (`_exec_env` `git -C script_dir ls-files`) · `_code_sha` · `test_step3_gpu_precond.py:69` (`git -C ROOT show`) · 전수 = 미확인 | git 을 부를 때 GIT_DIR · GIT_WORK_TREE · GIT_INDEX_FILE · GIT_COMMON_DIR · GIT_OBJECT_DIRECTORY 등을 지우지 않는다 → 부르는 쪽 환경이 새면 `-C 임시 폴더` 를 무시하고 **남의 리포에 쓴다** — 실제로 일어났다 (위 사고 · `ff61079c2`) · 정직한 흐름에서도 들어온다 (git 훅 pre-commit · pre-push 안에서 게이트를 돌리면 git 이 이 변수들을 넣는다) · selftest 는 쓴 **뒤에야** FAIL 로 드러낸다 · 읽기 쪽은 남의 리포의 code_sha · untracked 를 기록 | 쓰는 selftest 의 subprocess env 에서 `GIT_*` 저장소 변수 지움 (+ `GIT_CEILING_DIRECTORIES`) · 쓰기 전 `git rev-parse --show-toplevel` = 임시 폴더 확인 · 읽기 쪽도 같은 도우미 (규율 ① = 한 곳) · 게이트 시작 때 `GIT_DIR` 등이 있으면 경고 |

## 3. 변이 (리뷰어 것 · 21 · 잡힘 20 · 안 잡힘 1) — 전부 ⚠GIT_DIR (하네스 env)

도구 `work2/tools/mut2.py` · 정의 `work2/tools/muts2.json` · 결과 `work2/mut2_results.json` · 기록 `work2/mut2_run.log` (잡힌 까닭 = 기대한 검사 이름이 실패 줄에 있음 · 다시 확인 권고).

| 변이 | 무엇 (되돌림) | 결과 |
|---|---|---|
| N1 · N20 | 코드 칸 셋으로 · 코드 칸이 엉뚱한 파일 해시 | 잡힘 (T14a · b · c · d) |
| N2 | find_spec → import_module | 잡힘 (T14d) |
| N21 | 원장 모듈이 열쇠 밖 프로젝트 모듈을 새로 부름 | 잡힘 (T14b) |
| N3 · N4 | 자리 지문에서 venv 뺌 · 자리 지문 없음 | 잡힘 (T4) |
| N5 · N6 | Store 뿌리 심볼릭 거부 끔 · 끝 빗금 안 걷음 | 잡힘 (T11) |
| N7 · N8 | 파일 소유자 끔 · 파일 모드 끔 | 잡힘 (T7c · T7) |
| **N9** | 파일 모드 0o022 → 0o002 (그룹 쓰기 놓침) | **안 잡힘** (RCP2-03) |
| N10 · N11 | 사슬 심볼릭 끔 · 끝 빗금 안 걷음 | 잡힘 (C1) |
| N12 · N13 | 러너 심볼릭 ABORT 끔 · 끝 빗금 안 걷음 | 잡힘 (R1) |
| N14 · N15 · N16 | 입구 · 본 길 `except ValueError` · rasterize-only 거부 끔 | 잡힘 (P1b · P1b · P1) |
| N17 · N18 | no_linop 표지 안 붙임 · 한 줄로 불러옴 | 잡힘 (G6b) |
| N19 | 머리에 호스트 이름 | 잡힘 (T5i) |

## 4. 끔 경로 · 숫자 · 전칭 대조

| 주장 | 대조 | 결과 |
|---|---|---|
| 끔 경로 = 바탕 af3cce37b 와 비트 같음 (σ 같음 · 다른 칸 = 코드 신원뿐) | b6 픽스처 payload (CPU) 바탕 ↔ 새 · 잎 대조 (`work2/ovb/`) | **섬** — 접합 끔 1 잎 (`exec_env.project_module_digest`) · 접합 켬 · 저장본 끔 2 잎 (`loaded_project_modules` 8 → 9 · digest) · 그 밖 잎 같음 (사본이 git 아님 → code_sha 둘 다 None · 실제는 그 칸도 다름) |
| store 40 PASS · 14 FAIL → 54/54 · Q11 18/19 → 19/19 | `before` · `new` (3.11) · kgy 판 3.8.20 · 1.24.4 · 1.10.1 | 같음 (store 표지 없음 · 3.8 = 65 s ≈ "64 s" · Q11 = (git show)) · 고치기 전 실패 14 = 새 검사뿐 · 옳은 사유 |
| 단계 183 → 186 · kgy 13 → 16 | `CHECK_ALL_LIST` · diff | 같음 |
| GPU 블록 4 판: PIN · 모듈 sha256 · 하네스 md5 | 작업 트리 git show (정상 · 읽기) · heredoc 추출 | 같음 — PIN = 0ac6edf3c 40 자리 · 옛 8d428ff5… = 11a794674 = af3cce37b · 새 859310da… = 94765bed3 = 0ac6edf3c (f17ea8c6b · 2f97617ef = 45d645a2… = 3 판 값) · md5 acfeb4b4… · 탭 · CR · 느낌표 0 · CPU 흐름 (numpy · n 20) 다섯 짝 같음 |
| run_contract 124 · ca_ext_b6 502 · ca_ext_runner 151 · 규율 selftest 128 | 내 실행 | 값은 주장과 같았다 — **⚠사고뒤 · 믿지 않음** (run_contract 첫 실행 = 122/124 = 사고 그 자체) |
| e2e 6/6 (452 s) · 변이 89 · 107 · 110 | — | 확인 안 함 |
| precond 요약 줄 "(판 = 고침 뒤)" | 시험 코드 | 표기 — Q11 C 꼴 판별 (`LinearOperator` 글자) 이라 RCP-08 고치기 전 판에도 "고침 뒤" 로 찍힘 |

## 5. 확인 못 한 것

- 본 리포 상태 (사고 범위 — index · reflog · config · ref · worktree · stash) · 멈춤 지시 뒤 명령 없음.
- `test_cjunc_store_e2e.py` (7–10 분) · GPU 실기계 (블록) · 실침대 저장 · 읽기 (S0 블록 미실행) · 구현 쪽 변이 110 · 1 회차 변이 31 재실행.
- 같은 machine-id 에서 CPU 경로 (AVX-512 ↔ AVX2) 가 바뀌는 경우 — 열쇠 밖 · 원장 = 축 노름 · 3 원소 einsum · sum · cumsum 위주 (코드 읽기) 라 갈림 가능성 낮음 · 미확인.
- `.pyc` 신선도 (소스 mtime 초 · 크기) — 같은 초 · 같은 크기 편집이면 옛 바이트코드가 돈다 (코드 칸 = 소스 해시 · 한정 · CE1 변이는 같은 크기).
- RCP2-06 의 run_contract 행 번호 · 같은 꼴 git 호출 전수.

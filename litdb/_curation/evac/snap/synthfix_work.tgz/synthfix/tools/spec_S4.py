# V_S4.md 문제 1–10 → S4_dem_limits.md
V = 'V_S4'
D = 'S4'
PYC = 'pycompact2025_dem_mpfem_workflow'

K5_NEW = ('하중 중 상대밀도 ≈95.6 % (Coarse) · ≈96.7 % (Fine) (기공 4.4 / 3.3 % · digitized Fig 4b · 11-11 재판독) · '
          '제하 뒤 5 MPa 규약 13–15 % (stated RD 85.4 % · ≈87 %) · P ≈ 0 끝 ≈17 % (digitized)')

K156_OLD_ROW = ('| K-156 | Paulick · Morgeneyer · Kwade · 2015 · Powder Technology 283, 66–76 | "reasonable enough" | '
                '논문 쪽은 묶음 줄에 없음 (Nakamura [66] 에 대한 말) | 형4 | '
                '[layer3 · paulick2015_elastic_particle_properties_dem_review · §A L797–801] |\n')
K153_END = ('[b34 · nase2001_granular_bond_collision_number_wet_cohesion · §3-1 L58 (p.215) · §4-1 L108–110 · §8-4 L171 · Fig 5 · §10-9 L192] |\n'
            '| K-165 | Zunker · Kamrin · 2024 · J. Mech. Phys. Solids 183, 105493 · DOI 10.1016/j.jmps.2023.105493 | ')
K156_NEW_ROW = ('| K-156 | Paulick · Morgeneyer · Kwade · 2015 · Powder Technology 283, 66–76 | '
                '충분 (Nakamura [66] ÷475–4,750 에 대한 저자 판정 · 카드 L461) | '
                '논문 쪽 [미확인] · 영어 \'reasonable enough\' 는 비교 문서 §A (L797–801) 의 옮김 — 원문 확인 필요 | 형4 | '
                '[layer3 · paulick2015_elastic_particle_properties_dem_review · §A L797–801] |\n')

Q_K6 = '저자 §1 은 형상 변형을 다루는 방법 (MPM · MPFEM · FEM-DEM) 이 많은 입자 수에서 계산 비용에 막힌다고 정리'
Q_K8 = '접촉부에서 소성 흐름으로 운반된 물질은 무시 → 입자는 접촉부에서 단순 절단된 (truncated) 구'
Q_K54 = ('① 소성 흐름으로 접촉점에서 재료가 밀려나 실제 접촉 면적이 구 겹침 예측보다 크다 (pile-up) ② 입자 형상이 변하며 2 차 접촉 (secondary contacts) 이 생기는데 '
         '구 겹침으로는 안 잡힌다 ③ 고변형에서 "주어진 변위 → 힘" 의존이 더 이상 유효하지 않다 (force underestimated) → 접촉 면적과 스프링 상수를 과소평가')
Q_K165 = ('Harthong 2009 의 Voronoï 셀 = 비용이 커 대규모 불가 + 강소성 한정 / Frenning = 삼축 한 가지 하중만 / Garner 2018 = 전면 경험적 · 재료마다 재보정 · 배위수 고정 / '
          'Giannis 2021a = 재보정 필요')
Q_K209 = '탄소성 변형 = future work (Discussion) · 표면 거칠기로 실접촉 면적 < 공칭 = future work'
SUF = ' (묶음 줄의 풀이 · 카드 글자 아님)'

EDITS = [
    # ── 문제 1 · K-5 (1-1 · 3-2)
    dict(doc=D, v=V, num=1, item='K-5 (1-1 무엇을 말했나)', kind='값 다름 (카드 11-11 보강)', line=r'^\| K-5 \| \(논문 문장 아님\)',
         old='하중 중 상대밀도 95–96 % (기공 4–5 %) 까지 가는데',
         new='하중 중 상대밀도 ≈95.6 · 96.7 % (기공 4.4 / 3.3 %) 까지 가는데',
         note='카드 대조: pycompact2025 §6 4. L440–441 맞음'),
    dict(doc=D, v=V, num=1, item='K-5 (1-1 한정)', kind='값 다름 (카드 11-11 보강)', line=r'^\| K-5 \| \(논문 문장 아님\)',
         old='제하하면 13–17 % 로 되돌아옴',
         new='제하하면 5 MPa 규약 13–15 % (P ≈ 0 끝 ≈17 %) 로 되돌아옴',
         note='카드 대조: pycompact2025 §10 L653–654 · L657–659 맞음'),
    dict(doc=D, v=V, num=1, item='K-5 (1-1 수치)', kind='값 다름 (카드 11-11 보강)', line=r'^\| K-5 \| \(논문 문장 아님\)',
         old='| 하중 중 상대밀도 95–96 % (digitized) · 제하 뒤 13–17 % |',
         new='| ' + K5_NEW + ' |',
         note='같은 카드 줄'),
    dict(doc=D, v=V, num=1, item='K-5 (3-2 값)', kind='값 다름 (카드 11-11 보강)', line=r'^\| K-5 \| 형상 소성이 있을 때',
         old='| 95–96 % (기공 4–5 % · digitized) · 제하하면 13–17 % 로 되돌아옴 |',
         new='| ' + K5_NEW + ' |',
         note='검증: "3-2 값 칸도 같은 글"'),
    # ── 문제 2 · K-196 (1-7 · 3-6)
    dict(doc=D, v=V, num=2, item='K-196 (1-7 무엇을 말했나)', kind='조건 빠짐 ("초과")', line=r'^\| K-196 \| Lischka[^|]*\| coarse-grain 상한',
         old='coarse-grain 상한: 입자 지름이 일정 크기보다 크거나 Coarse-Grain-Factor 가 일정 값이면 쓸 수 없다고 적음.',
         new='coarse-grain 상한: 입자 지름이 2 mm 보다 크거나 Coarse-Grain-Factor 가 200 을 넘으면 쓸 수 없다고 적음 (기준 모델이 CGF 200 · d 2.0 mm · CGF 100–200 은 일치 · 카드 L104 · L208).',
         note='카드 대조: lischka2025 L104 · L205 · L208 맞음'),
    dict(doc=D, v=V, num=2, item='K-196 (1-7 수치)', kind='조건 빠짐 ("초과")', line=r'^\| K-196 \| Lischka[^|]*\| coarse-grain 상한',
         old='| 입자 지름 2 mm 초과 또는 Coarse-Grain-Factor 200 |',
         new='| 입자 지름 2 mm 초과 · Coarse-Grain-Factor 200 초과 (400 · 800 어긋남) |',
         note=''),
    dict(doc=D, v=V, num=2, item='K-196 (3-6 값)', kind='조건 빠짐 ("초과")', line=r'^\| K-196 \| coarse-grain 상한',
         old='입자 지름 2 mm 초과 또는 Coarse-Grain-Factor 200 에서는 쓸 수 없음 (stated)',
         new='입자 지름 2 mm 초과 · Coarse-Grain-Factor 200 초과에서는 쓸 수 없음 (stated · CGF 200 = 기준 모델)',
         note=''),
    # ── 문제 3 · K-46 (1-2 · 3-1)
    dict(doc=D, v=V, num=3, item='K-46 (1-2 · 3-1 수치 칸 끝)', kind='표지 빠짐 (정정된 배수)', count=2,
         old='(Paulick 기준의 ~22×)',
         new='(Paulick 기준을 반지름의 1 % 로 읽으면 ~22× · 원문 기준 지름의 1 % 이면 11–12× — 비교 문서 §F 정정 · 어긋남 1)',
         note='카드 대조: paulick2015 L14 "오버랩 ≤ 입자 지름의 1 %" · 문서 안 어긋남 1 과 맞음'),
    # ── 문제 4 · 5 절 문장 4 · K-99 머리
    dict(doc=D, v=V, num=4, item='5 절 문장 4 (앞 절)', kind='넓게 말함',
         old='4. DEM 의 입력값은 물성이 아니라 벌크 거동에 맞춘 조정값이고, 맞춘 조합이 유일하지 않아 다른 응용에서의 정확도가 보장되지 않는다고 보정 리뷰가 적었다 (Coetzee 2017 · Powder Technol. — 저응력 벌크 핸들링).',
         new='4. 벌크 보정 접근에서는 DEM 입력값을 물성과 강하게 잇지 않고 벌크 거동에 맞춘 조정값으로 다루며, 맞춘 조합이 유일하지 않아 한 응용에 맞춘 값이 다른 응용에서 정확하다는 보장이 없다고 보정 리뷰가 적었다 (Coetzee 2017 · Powder Technol. — 저응력 벌크 핸들링).',
         note='문서 안 K-100 원문 (2-1) 과 맞음'),
    dict(doc=D, v=V, num=4, item='K-99 (머리)', kind='넓게 말함', line=r'^\| K-99 \| Coetzee · 2017 · Powder Technology 310, 104–142 \| DEM 입력은',
         old='| DEM 입력은 물성이 아니라 수치 모델 매개변수: 물성',
         new='| 물성과 수치 모델 매개변수를 구별해야 함: 물성',
         note=''),
    # ── 문제 5 · K-156 (2-1 → 2-2) + 개수
    dict(doc=D, v=V, num=5, item='K-156 (2-1 에서 뺌)', kind='카드에 없음', multiline=True, cells_change=True,
         old=K156_OLD_ROW, new='',
         note='카드 대조: paulick2015 카드에 영어 "reasonable enough" 0 회 (한국어 "충분" L461 · L797 뿐) · 비교 문서에만 있음'),
    dict(doc=D, v=V, num=5, item='K-156 (2-2 에 넣음)', kind='카드에 없음', multiline=True, cells_change=True,
         old=K153_END,
         new=K153_END.replace('|\n| K-165', '|\n' + K156_NEW_ROW + '| K-165'),
         note='검증이 준 두 칸 그대로 · 원문 위치 칸의 "비교 문서 §A L798" 은 꼬리 범위 "(L797–801)" 로 적음 (정본 c5f78c6 에서는 L799 — 한 줄 밀림) · 유형 · 꼬리는 옮긴 줄 그대로'),
    dict(doc=D, v=V, num=5, item='2-1 머리 개수', kind='카드에 없음',
         old='### 2-1. 묶음 줄이 따옴표로 옮긴 원문 문장 (글자 그대로 · 226 개)',
         new='### 2-1. 묶음 줄이 따옴표로 옮긴 원문 문장 (글자 그대로 · 225 개)',
         note='K-156 한 줄을 옮겨 개수를 맞춤'),
    dict(doc=D, v=V, num=5, item='2-2 머리 개수', kind='카드에 없음',
         old='### 2-2. 원문 문장이 카드에 없음 · 원문 확인 필요 (80 개)',
         new='### 2-2. 원문 문장이 카드에 없음 · 원문 확인 필요 (81 개)',
         note='K-156 한 줄을 옮겨 개수를 맞춤'),
    dict(doc=D, v=V, num=5, item='요지 (인용 주의 개수)', kind='카드에 없음',
         old='- 인용 주의: 원문 따옴표 226 개 (2-1) · 카드의 옮김 등 80 개 (2-2 · 원문 확인 필요).',
         new='- 인용 주의: 원문 따옴표 225 개 (2-1) · 카드의 옮김 등 81 개 (2-2 · 원문 확인 필요).',
         note='개수 맞춤'),
    dict(doc=D, v=V, num=5, item='읽은 범위와 셈 (2 절 개수)', kind='카드에 없음',
         old='- 2 절: 원문 문장 226 개 · 원문 확인 필요 80 개.',
         new='- 2 절: 원문 문장 225 개 · 원문 확인 필요 81 개 (K-156 한 줄을 검증 뒤 2-1 에서 2-2 로 옮김).',
         note='개수 맞춤'),
    # ── 문제 6 · K-318
    dict(doc=D, v=V, num=6, item='K-318 (2-1 문장 · 원문 위치)', kind='따옴표 다름', line=r'^\| K-318 \| Landesfeind',
         old='| "the most likely cause" | A472 · A474–A475 |',
         new='| "most likely cause" | A474–A475 · 카드 L32 |',
         note='카드 대조: landesfeind2018 L32 "most likely cause" (A474–A475) 맞음'),
    # ── 문제 7 · 2-2 다섯 줄 (따옴표 뗌)
    dict(doc=D, v=V, num=7, item='K-6 (2-2)', kind='따옴표 다름 (규칙 6)', line=r'^\| K-6 \| Giannis 외[^|]*\| "저자 §1',
         old='| "' + Q_K6 + '" |', new='| ' + Q_K6 + SUF + ' |', note='따옴표만 떼고 표지를 붙임 (카드 글자로 바꾸지는 않음)'),
    dict(doc=D, v=V, num=7, item='K-8 (2-2)', kind='따옴표 다름 (규칙 6)', line=r'^\| K-8 \| Martin & Bouvard[^|]*\| "접촉부에서',
         old='| "' + Q_K8 + '" |', new='| ' + Q_K8 + SUF + ' |', note=''),
    dict(doc=D, v=V, num=7, item='K-54 (2-2)', kind='따옴표 다름 (규칙 6)', line=r'^\| K-54 \| So · Inoue[^|]*\| "① 소성',
         old='| "' + Q_K54 + '" |', new='| ' + Q_K54 + SUF + ' |', note='바깥 따옴표만 뗌 (안쪽 "주어진 변위 → 힘" 은 그대로)'),
    dict(doc=D, v=V, num=7, item='K-165 (2-2)', kind='따옴표 다름 (규칙 6)', line=r'^\| K-165 \| Zunker · Kamrin · 2024 · J. Mech. Phys. Solids 183, 105493 · DOI 10.1016/j.jmps.2023.105493 \| "Harthong',
         old='| "' + Q_K165 + '" |', new='| ' + Q_K165 + SUF + ' |', note=''),
    dict(doc=D, v=V, num=7, item='K-209 (2-2)', kind='따옴표 다름 (규칙 6)', line=r'^\| K-209 \| Zhang 외 · 2024 · Powder Technology 440, 119759 \| "탄소성',
         old='| "' + Q_K209 + '" |', new='| ' + Q_K209 + SUF + ' |', note=''),
    # ── 문제 8 · pycompact2025 꼬리 줄 번호
    dict(doc=D, v=V, num=8, item='K-182 (꼬리)', kind='위치 틀림 (카드 줄 이동)', line=r'^\| K-182 \|',
         old='카드 §5-(a) (L229–232)]', new='카드 §5-(a) (L387–389)]',
         note='카드 §5 (a) = L387–389 맞음'),
    dict(doc=D, v=V, num=8, item='K-4 (꼬리 · 1-1 L31 · 2-1 세 줄)', kind='위치 틀림 (카드 줄 이동)', count=4,
         old='카드 §5-(a) (L229–232)]', new='카드 §5-(a) (L387–389) · (b) (L392–395)]',
         note='카드 §5 (a) L387–389 · (b) L392–395 맞음 (2-1 의 둘째 · 셋째 문장이 (b) 의 글)'),
    dict(doc=D, v=V, num=8, item='K-204 (꼬리 · 1-8 · 2-1 두 줄)', kind='위치 틀림 (카드 줄 이동)', count=3,
         old='카드 §5-(c) · (e) (L240–252)]', new='카드 §5-(c) · (e) (L398–401 · L408–409)]',
         note='카드 §5 (c) L398–401 · (e) L408–409 맞음'),
    dict(doc=D, v=V, num=8, item='K-5 (꼬리 · 1-1 · 3-2)', kind='위치 틀림 (카드 줄 이동)', count=2,
         old='카드 §6-4 (L273) · §10 (L458–463)]', new='카드 §6 4. (L440–441) · §10 (L653–659)]',
         note='카드 §6 4. L440–441 · §10 L653–659 맞음'),
    # ── 문제 9 · 요지 형4 줄
    dict(doc=D, v=V, num=9, item='요지 형4 줄', kind='표지 빠짐',
         old='· 1/463 (K-152) · 1/900 (K-117) ·',
         new='· 1/463 (K-152 · [우리 산술]) · 1/900 (K-117 · [우리 산술]) ·',
         note=''),
    # ── 문제 10 · 5 절 문장 7
    dict(doc=D, v=V, num=10, item='5 절 문장 7', kind='넓게 말함 (받치는 항목 밖)',
         old='7. 실제 크기 · 실제 입자 수의 DEM 은 계산 부하 때문에 입자를 키우거나 영률을 낮춰 계산한다는 서술이 있다 (Hare 외 2026 · Powder Technol. — 카드 옮김; Yano 외 2026; Jadidi 외 2023 · Rev. Chem. Eng.). (K-192 · K-130 · K-193) (종합 · 조수 판단)',
         new='7. 실제 크기 · 실제 입자 수의 DEM 은 계산 부하 때문에 입자를 키우거나 영률을 낮춰 계산한다는 서술이 있다 (Hare 외 2026 · Powder Technol. — 카드 옮김; Yano 외 2026 · J. Energy Storage). 산업 규모 (수억–수십억 입자) 는 현 하드웨어로 풀 수 없다는 리뷰 서술도 있다 (Jadidi 외 2023 · Rev. Chem. Eng. — mm 급 자유유동 분말). (K-192 · K-130 · K-193 · K-253) (종합 · 조수 판단)',
         note='문서 안 K-130 · K-192 · K-193 · K-253 과 맞음'),
    # ── 머리 한정 줄
    dict(doc=D, v=V, num='머리', item='한정 줄', kind='한정 (지시서)', multiline=True,
         old='# DEM 의 한계 (정독 종합 · 질문 k)\n\n',
         new='# DEM 의 한계 (정독 종합 · 질문 k)\n\n'
             '한정 (2026-11-12): 검증 = 표본 (다섯에 하나 + 따옴표 · 서지 전부) · 문제 비율 = 문제 10 / 손 대조 = 1 절 83 항목 (다섯에 하나 53 + 더 연 30 · 1 절 263 항목) · 3 절 33 줄 (136 줄 가운데) · 2-2 8 줄 (80 줄 가운데) · 4 절 16 줄 (129 줄 가운데) · 전체 항목 K-1–K-392 · 그 밖은 기계 대조 (숫자 = V_S4.md 셈) · 손 대조 밖 항목의 문장 뜻은 보지 않았다 · 이 판은 검증 표의 "고칠 글" 을 적용한 뒤다 (기록 = APPLIED.md).\n\n',
         note='숫자는 V_S4.md 셈 절에서만 (이 문서의 표본 꼴은 다섯에 하나)'),
]

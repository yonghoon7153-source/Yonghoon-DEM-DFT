import json, sys
def walk(a, b, p, out):
    if type(a) != type(b):
        out.append((p, repr(a)[:60], repr(b)[:60])); return
    if isinstance(a, dict):
        for k in sorted(set(a) | set(b)):
            if k not in a or k not in b: out.append((p + '.' + str(k), 'MISSING' if k not in a else '…', 'MISSING' if k not in b else '…'))
            else: walk(a[k], b[k], p + '.' + str(k), out)
    elif isinstance(a, list):
        if len(a) != len(b): out.append((p, f'len {len(a)}', f'len {len(b)}')); return
        for i, (x, y) in enumerate(zip(a, b)): walk(x, y, f'{p}[{i}]', out)
    elif a != b: out.append((p, repr(a)[:60], repr(b)[:60]))
a, b = json.load(open(sys.argv[1])), json.load(open(sys.argv[2]))
out = []; walk(a, b, '$', out)
print(sys.argv[1].split('/')[-1], 'vs', sys.argv[2].split('/')[-1], ':', len(out), 'leaf diffs')
for x in out[:20]: print('  ', x)

"""Read-only check: extract _need and _log_contract source text from the observer
(path given as argv[1]) via AST and run it on synthetic logs built from the line
forms seen in same-build LIGGGHTS logs that are committed in the repo.
Writes nothing.  Run with: python3 -I -B check_log_contract.py <observer.py>"""
import ast, hashlib, math, re, sys

src_path = sys.argv[1]
raw = open(src_path, 'rb').read()
print('observer sha256', hashlib.sha256(raw).hexdigest())
tree = ast.parse(raw.decode('utf-8'))
want = {'_need', '_log_contract'}
nodes = [n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name in want]
assert {n.name for n in nodes} == want, 'functions not found'
for n in nodes:
    print('found', n.name, 'lines', n.lineno, '-', n.end_lineno)

class Tech(ValueError):
    pass

ns = {'re': re, 'math': math, 'Tech': Tech}
mod = ast.Module(body=nodes, type_ignores=[])
exec(compile(mod, src_path, 'exec'), ns)
log_contract = ns['_log_contract']

RUNS = [1, 560606, 560606, 0]   # PRECAL_E0 deck: run 1 / run 560606 / run 560606 / run 0
REAL_HDR = '    Step    Atoms         KinEng            rke         Volume '
TEST_HDR = 'Step Atoms KinEng c_rke Volume'
def row(step, atoms=100000):
    return '%8d %8d  3.2685651e-12  1.0960987e-10  2.7589053e-05 ' % (step, atoms)
def loop(nsteps, real):
    s = 'Loop time of 5.19e-07 on 20 procs for %d steps with 100000 atoms' % nsteps
    return s + (', finish time Tue Oct  6 19:30:09 2026' if real else '')
INFO = ['INFO: Particle insertion ins: inserted 100000 particle templates (mass 1.0e-01) at step 1',
        ' - a total of 100000 particle templates (mass 1.0e-01) inserted so far.']

def build(real_hdr, real_loop, info_in_table):
    out, cum = ['LIGGGHTS (Version LIGGGHTS-PUBLIC 3.8.0, compiled <DATE> by <BUILD_USER>, git commit <GIT>)'], 0
    for k, n in enumerate(RUNS):
        out += ['Setting up run at <DATE>', '', 'Memory usage per processor = 102.09 Mbytes',
                REAL_HDR if real_hdr else TEST_HDR]
        start = cum
        if k == 0:
            out.append(row(start, 0))
            if info_in_table:
                out += INFO
        else:
            out.append(row(start))
        cum += n
        for s in range((start // 5000 + 1) * 5000, cum, 5000):
            out.append(row(s))
        if n > 0:
            out.append(row(cum))
        out.append(loop(n, real_loop))
        out += ['', '', 'Pair  time (%) = 0 (0)']
    out.append('Total wall time: 4:12:00')
    return ('\n'.join(out) + '\n').encode('utf-8')

cases = [
    ('A real header + real Loop (+INFO, as same-build insertion log)', True, True, True),
    ('B real header + real Loop (no INFO)', True, True, False),
    ('C test header + real Loop (no INFO)', False, True, False),
    ('D real header + test Loop (no INFO)', True, False, False),
    ('E test header + test Loop (no INFO)', False, False, False),
    ('F test header + test Loop + INFO lines in run-1 table', False, False, True),
]
for name, h, l, i in cases:
    try:
        r = log_contract(build(h, l, i), RUNS)
        print(name, '->', r['status'], r['loop_steps'], 'last', r['last_thermo_step'])
    except Tech as e:
        print(name, '-> TECH:', e)

# G: otherwise-MATCH log (case E) plus the deck's own comment line 34 echoed into the log
deck_comment = '#   (`ERROR: youngsModulus <= 1e9 required for SI units`, global_properties.cpp:371).'
body = build(False, False, False).decode('utf-8').split('\n')
body.insert(1, deck_comment)
try:
    r = log_contract('\n'.join(body).encode('utf-8'), RUNS)
    print('G test header + test Loop + echoed deck comment with ERROR ->', r['status'])
except Tech as e:
    print('G test header + test Loop + echoed deck comment with ERROR -> TECH:', e)

# H: all four real-form features together (what an unmodified real PRECAL_E0 log.liggghts is expected to look like)
body = build(True, True, True).decode('utf-8').split('\n')
body.insert(1, deck_comment)
try:
    r = log_contract('\n'.join(body).encode('utf-8'), RUNS)
    print('H real header + real Loop + INFO + echoed ERROR comment ->', r['status'])
except Tech as e:
    print('H real header + real Loop + INFO + echoed ERROR comment -> TECH:', e)

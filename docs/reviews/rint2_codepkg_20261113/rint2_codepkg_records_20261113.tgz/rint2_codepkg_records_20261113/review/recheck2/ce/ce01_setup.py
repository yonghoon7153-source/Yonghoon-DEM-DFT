#!/usr/bin/env python3
"""recheck2 RCP2-01 반례 준비 — 시험 모듈의 도우미 (조밀 침대 입력 · CE1 변이 fsr · 기계 id 파일) 를 그대로 써서 고정물을 만든다 (시험 함수는 부르지 않는다).
사용: python3 ce01_setup.py <트리 scripts> <작업 폴더> → JSON (입력 npz · 변이 fsr · 기계 파일)"""
import json
import os
import sys

scripts, wd = sys.argv[1:3]
sys.path.insert(0, scripts)
import test_cjunc_store as T  # noqa: E402 — 도우미만 (main 을 부르지 않는다)

os.makedirs(os.path.join(wd, 'drv'), exist_ok=True)
T.TD = wd
inp = T.t15_inputs_file()
mut_src, n = T.t15_mutant_text()
assert n == 1
mut = os.path.join(wd, 'drv', 'mut_fsr.py')
with open(mut, 'w', encoding='utf-8') as f:
    f.write(mut_src)
mfile = T.machine_file('A', ('%032x' % (abs(hash('A')) % (16 ** 32))))
print(json.dumps({'inp': inp, 'mut': mut, 'mfile': mfile}))

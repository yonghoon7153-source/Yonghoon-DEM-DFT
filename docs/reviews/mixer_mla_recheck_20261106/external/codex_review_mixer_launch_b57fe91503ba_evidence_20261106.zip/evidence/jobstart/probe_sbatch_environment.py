"""Full submission-guard replay; all subprocesses replaced before imports.

Only platform adaptation: canonical_runner validates POSIX binding strings. For
this Windows-only replay the same generation code is used with the leading-slash
check removed from a separately compiled function. All approval, source, asset,
runner equality and exclusive-claim guards run unmodified. No sbatch executes.
"""
import contextlib
import hashlib
import io
import json
import os
import pathlib
import runpy
import subprocess
import sys
import tempfile
import time
import types
from unittest.mock import patch

OUT = pathlib.Path(__file__).resolve().parent
BASE = OUT.parents[1]
PACKAGE = BASE / 'package'
REVIEW = PACKAGE / 'docs/reviews/mixer_first8_launch_preparation_20261106'

def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()

def replay():
    seen = []
    def fake_sbatch(argv, **kwargs):
        effective_env = os.environ if kwargs.get('env') is None else kwargs['env']
        seen.append({'argv':argv, 'env_argument_present':'env' in kwargs,
                     'effective_scheduler_overrides':{k:effective_env[k] for k in overrides if k in effective_env}})
        return types.SimpleNamespace(returncode=0, stdout='12345\n', stderr='')
    overrides = {'SBATCH_ARRAY_INX':'0-7', 'SBATCH_QOS':'unapproved-qos',
                 'SBATCH_PARTITION':'unapproved-partition', 'SBATCH_TIMELIMIT':'00:01:00',
                 'SBATCH_OUTPUT':'/unapproved/out', 'SBATCH_ERROR':'/unapproved/err'}
    with patch.object(subprocess, 'run', side_effect=fake_sbatch), tempfile.TemporaryDirectory(dir=OUT) as td:
        ns = runpy.run_path(str(REVIEW / 'submit_one.py.txt'))
        # Exactly one platform precondition removed, function body otherwise unchanged.
        original = (REVIEW/'submit_one.py.txt').read_text()
        function_text = original[original.index('def canonical_runner('):original.index('\nCASES =')]
        assert function_text.count(' and spec[k].startswith("/")') == 1
        function_text = function_text.replace(' and spec[k].startswith("/")', '')
        exec(compile(function_text, '<Windows-only canonical_runner adapter>', 'exec'), ns['main'].__globals__)
        canon = ns['main'].__globals__['canonical_runner']
        p=pathlib.Path(td); case=p/'case'; case.mkdir(); files=[]
        def seal(name,data):
            q=p/name; q.parent.mkdir(parents=True,exist_ok=True);q.write_text(data)
            return {'path':str(q),'sha256':sha(q)}
        c={'schema':'mixer_first8_execution_approval/1','execution_authorized':True,
           'gate':'QUALIFICATION_PILOT_GO','case':'PRECAL_E0','np':20,
           'author_choices_confirmed':True,'approved_concurrency':1,
           'wave_release':['PRECAL_E0'],'case_dir':str(case),
           'runner_reviewed':True,'walltime_approved':True}
        for k in ('author_go','qualification','mxd2r_disposition','binary','mpi_launcher'):
            c[k]=seal(k,'SYNTHETIC LOCAL REVIEW RECEIPT; NOT EXECUTABLE')
        c['policy']=seal('policy',json.dumps({'execution_authorized':True,'policy_id':'SYNTHETIC','allowed_to_submit':['PRECAL_E0']}))
        live={'observed_unix':time.time(),'qos':'cpu-60','partition':'cpu','reserved_cpus':0,'running_first8':0}
        for k in ('qos_verified','disk_budget_verified','inode_budget_verified','d07_finished','qualification_accepted','paths_verified'): live[k]=True
        c['live_preflight']=seal('live',json.dumps(live))
        for name in ('in.mixer','deck_meta.json','Drum.stl','Front.stl','Back.stl'):
            q=case/name;q.write_bytes((REVIEW/'planned_assets/PRECAL_E0'/name).read_bytes())
            files.append({'path':str(q),'sha256':sha(q)})
        source_root=p/'source';source_root.mkdir();seal_doc=json.loads((REVIEW/'source_seal.json').read_text())
        c['source_pin']=seal_doc['source_pin'];c['source_root']=str(source_root)
        for a in seal_doc['files']:
            q=source_root/a['path'];q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes((PACKAGE/a['path']).read_bytes())
            files.append({'path':str(q),'sha256':a['sha256']})
        c['runner_bindings']={'python':str(p/'python'),'job_start':str(p/'job_start'),
                             'stdout':str(p/'out'),'stderr':str(p/'err'),'walltime':'1-00:00:00'}
        files.append(seal('python','SYNTHETIC INTERPRETER; NOT EXECUTABLE'))
        q=p/'job_start';q.write_bytes((REVIEW/'job_start.py.txt').read_bytes())
        files.append({'path':str(q),'sha256':sha(q)})
        ap=p/'approval.json'
        c['runner']=seal('runner',canon(c,str(ap)))
        c['source_manifest']=seal('manifest',json.dumps({'files':files}))
        ap.write_text(json.dumps(c))
        with patch.dict(os.environ, overrides), contextlib.redirect_stdout(io.StringIO()):
            ns['main'](str(ap))
        receipt=json.loads((case/'submission.receipt.json').read_text())
        return {'mock_calls':len(seen),'calls':seen,'receipt_state':receipt['state'],
                'approved_runner_directives':[line for line in pathlib.Path(c['runner']['path']).read_text().splitlines() if line.startswith('#SBATCH')],
                'platform_adapter':'Only canonical_runner spec[k].startswith("/") removed for Windows temp files',
                'source_files_changed':False,'actual_scheduler_calls':0,'actual_mpi_calls':0}

if __name__=='__main__':
    result=replay()
    (OUT/'probe_sbatch_environment_results.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))

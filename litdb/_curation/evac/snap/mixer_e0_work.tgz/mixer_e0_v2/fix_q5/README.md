# 믹서 E0 자격 pilot · Q5 — 관측기 로그 계약 고침 (시험 먼저) + 재봉인 후보 (2026-11-12)

**지위: scratch 산출물 · 리포 쓰기 0 · 실행 · 제출 · 원격 접속 0 · 운영 봉인 · 운영 정책 · launch 파일 · 비활성 후보 무변경 · 재봉인 = 후보만 · 발사 GO 아님 · 전체 HOLD 그대로.**
근거 = 등록 초안 (`../e0_pilot_registration_draft.md`) 7-4 · 18 절 Q5 · Q7 (1저자 11-12 "다 권고대로").

## 0. 한 줄

봉인된 관측기 (`scripts/mixer_precal_observe.py` sha256 `df22dcf0…`) 의 로그 계약이 같은 빌드 (LIGGGHTS-PUBLIC 3.8.0 · git 3d5c00f) 실제 로그 꼴 넷과 어긋나 **정상 완주 런도 관측 TECH** 였다 → 시험으로 먼저 재현 (커밋 1) → 그 넷만 허용하고 진짜 오류는 그대로 · 더 엄격히 TECH 로 고침 (커밋 2, 관측기 sha256 `bb2f3229…`).

## 1. 산출물

| 경로 (이 폴더 기준) | 무엇 | sha256 (앞 16) |
|---|---|---|
| `patches/0001-E0-pilot-Q5-LIGGGHTS-TECH.patch` | 커밋 1 · 시험만 (재현 6 · 지금 관측기로 전부 실패) | d569e465e652da5e |
| `patches/0002-E0-pilot-Q5-TECH.patch` | 커밋 2 · 관측기 고침 + 옛 fixture 꼴 이전 + 반례 묶음 | 058abc66a7faedfd |
| `seal_candidate/source_seal.candidate.json` | 재봉인 후보 (source_seal 꼴 · `source_pin` 키 없음 = 일부러) | 46e8bdcc27008ecb |
| `seal_candidate/seal_candidate_changes.json` | 12 파일 × (운영 봉인 · 비활성 후보 · 후보 · 패치 트리 실제) 대조표 | 364c6a071a0aa18a |
| `seal_candidate/make_and_check_seal_candidate.py` | 후보 만들기 · 다시 대조 (`--check-only`) · 읽기만 | c97d66f0f9d33546 |
| `evidence/` | 시험 원 출력 · 변이 결과 · 반례 전후 표 · 실제 로그 표 훑기 · first8 묶음 시험 · 비활성 검증기 | `SHA256SUMS` |
| `tools/` | 변이 · 전후 대조 · 하위 시험 세기 · 로그 표 훑기 스크립트 | `SHA256SUMS` |
| `tree/` | scratch git (1.6 GB) · 태그 `pre-q5` (= HEAD `ef68eb7da` 트리 그대로 · tree `099a0725…` 일치) · `q5-tests` (`c965307c`) · `q5-fix` (`56ad288b` · tree `4f293308…`) | — |

- 두 패치를 `pre-q5` 위에 `git am` 하면 tree `4f293308e49dbe1ad07a329101130c4d4ae7ee6e` 가 그대로 나온다 (scratch 에서 확인 · 리포 HEAD 는 지금도 `ef68eb7da`).
- ⚠ **0001 단독 적용은 게이트 '믹서 보정 전 관측 연결' 단계를 실패시킨다** (시험 먼저의 뜻) — 둘을 함께 적용한 끝에서 게이트.
- 바뀐 리포 파일 = 둘: `scripts/mixer_precal_observe.py` (봉인 12 안) · `scripts/test_mixer_precal_observe.py` (봉인 밖).
- 커밋 작성자 = Claude (noreply) · 메시지 끝 Co-Authored-By · Claude-Session 줄 — 반입 때 본 세션 꼴로 바꿔도 된다.
- 로그 · 증거에 scratch 절대 경로가 들어 있다 — 리포 반입 시 가린 사본 규칙대로.

## 2. 고친 어긋남 넷 (등록 7-4 · 근거 = 리포의 같은 빌드 로그)

| # | 옛 계약 (df22dcf0) | 같은 빌드 실제 꼴 | 새 계약 (bb2f3229) | 근거 |
|---|---|---|---|---|
| ① | thermo 머리 토큰 = `Step Atoms KinEng c_rke Volume` | `Step Atoms KinEng rke Volume` (c_ 를 뗀다) | 실제 꼴만 (ASCII 공백 · 탭) · 옛 `c_rke` 꼴은 이제 거부 | `docs/data/mixer_highbo_devu_prelim_20261006/exact_runs/exact_LU212_settled/log.exact` L65 (덱과 같은 thermo_style) |
| ② | Loop 줄 = `… steps with N atoms` 로 끝 | `…, finish time Tue Oct  6 19:30:09 2026` | 정확한 ctime 꼴 필수 · "Loop time of" 로 시작하는 다른 줄 = TECH (옛 판은 표 밖이면 조용히 무시) | 같은 파일 L67 · kg50 로그 전부 |
| ③ | 표 안 비-행 줄 = 전부 TECH | 삽입 런 표 안 `INFO: Particle insertion <id>: inserted N …` + ` - a total of N …` | 그 두 줄만 · 아래 조건 전부일 때 | `docs/data/kg50_d07_end_20261105/kg50_d07_b50_log_ins1.liggghts` L116–121 · LIGGGHTS `fix_insert.cpp` print_stats_during (리포 증거 사본) |
| ④ | 로그 어디든 낱말 `ERROR` = TECH | 덱 주석 L34 (`` #   (`ERROR: youngsModulus …` ``) 가 입력 메아리로 찍힘 | 그 런의 **덱 전체줄 주석과 바이트 같은 줄** 만 예외 · 덱에 나온 횟수까지 | 덱 L34 (N0 L34 · 층상 L50) · kg50 로그의 `#` 줄 48–54 |

③ 의 조건: 보고 fix id = 덱의 `fix <id> … insert/pack` (덱 읽기 = 프레임 계획과 같은 `read_deck`) · fix 하나당 한 번 · 그 fix 선언 다음 run 의 표 · 표의 첫 (setup) 행 **바로 뒤** · 보고 step = setup step + 1 · 넣은 수 = 누계 > 0 · 두 줄의 mass 같음 · 다음 행 Atoms = setup 행 + 넣은 수 · 선언된 insert/pack fix 가 보고 없이 끝나면 TECH.
같은 빌드 로그 열한 개의 표 안 비-행 줄을 전부 훑었다 — 보이는 것은 ③ 의 두 줄뿐 (`evidence/real_log_table_scan.txt` · 단 모두 1 프로세스 런).

## 3. 거부 쪽 — 그대로 + 새로 (등록 6 절 S6 의 셋 포함)

- 그대로: `RESUME_STEP` · `read_restart` · 네 run 의 누적 끝 step · 비유한 thermo (nan · -nan · inf · 1e999) · 표 없는 Loop · 열 부족 · 네 run 미완 (잘림).
- ERROR: 낱말 `ERROR` 와 **줄 첫머리 `ERROR…`** (S6 ① · 옛 판은 `ERRORS` 같은 머리를 못 잡았다) 둘 다 TECH · 예외는 ④ 뿐.
- 새로: thermo **Atoms 감소** = TECH (S6 ③ · 이어지는 두 행 기준 · 표 경계 포함) · 열린 표 안 머리 · Loop 원자 수 ≠ 끝 행 · 표 안 ASCII 아닌 줄 (유니코드 숫자 · NBSP · 전각) · 숫자 꼴 밖 값 (`1_000` · `abc` · `\x1f` 구분) · 공백 · 탭이 아닌 공백 줄.
- 덱 정보 없이 부르면 (`_log_contract(raw, runs)` · facts=None) 메아리 · 보고를 **하나도** 허용하지 않는다 (가장 엄격).
- API: `_log_contract(raw, runs, facts=None)` (옛 호출 그대로 됨) · 새 `_deck_log_facts(deck)` · `_load` 한 줄. 출력 completion_log 에 `loop_procs` · `insertion_reports` · `deck_comment_echo_error_lines` 추가 (SCHEMA 문자열은 `mixer_precal_observe/1` 그대로).

## 4. 시험 숫자 (고치기 전 → 뒤)

| 시험 | HEAD (`pre-q5`) | 커밋 1 (`q5-tests`) | 커밋 2 (`q5-fix`) |
|---|---|---|---|
| `scripts/test_mixer_precal_observe.py` (Python 3.11.18) | 28/28 | 34 중 28 통과 · **새 6 전부 실패** (사유 = 관측기 TECH: "error/resume log is not fresh completion evidence" 3 · "log fresh four-run completion mismatch" 3) | **43/43** (하위 시험 88 = 반례 묶음 68 · DiskContract 13 · Qualification 7 · 실패 0) |
| 같은 파일 (Python 3.8.20 · numpy 1.24.4) | — | — | 43/43 |
| `scripts/test_mixer_precal_prepare.py` | 14/14 | — | 14/14 (3.11) · 14/14 (3.8) |
| 게이트 믹서 단계 나머지 (관측기를 import 하지 않음 · grep) | — | — | D2 34/34 · seed 10/10 · D3 28/28 · launcher 136 PASS / 0 FAIL · devlog 9/9 · bed_view 56/56 |

- 원 출력: `evidence/base_*.log` · `evidence/c1_observe.log` · `evidence/final_observe_py311.log` · `evidence/final_observe_py38.log` · `evidence/after_*.log`. 게이트 단계는 `check_all.sh` 가 아니라 그 단계 명령을 scratch 트리에서 하나씩 돌렸다.

## 5. 거부가 약해지지 않았다는 근거

- **반례 62** (실제 꼴 전체 길이 PRECAL_E0 로그에 결함 하나씩 — 진짜 ERROR 줄 9 · 잘림 6 · 행 손상 15 · 입자 소실 4 · 삽입 보고 17 · 표 구조 11) + UTF-8 잘림 1 + 끝-끝 (analyse_run) 4: 옛 관측기 62/62 TECH · 새 관측기 62/62 TECH (예상 사유) · 같은 정상 로그는 옛 TECH → 새 MATCH (`evidence/before_after_counterexamples.md`). 끝-끝 결함 4 = status TECH · contact · mixing · counts 모두 null.
- **단일 가드 변이 25** (가드 하나씩 끄거나 넓힘 · scratch 사본) → 25 모두 시험 실패로 잡힘 · 생존 0 · 변이 없는 대조 43/43 (`evidence/mutation_results.json` · 관측기 bb2f3229 · 시험 3e19ba2b 에 고정).
- **옛 시험 파일 그대로** (fixture 이전 전) + 새 관측기: 28 중 18 통과 · 실패 10 은 전부 **양성 기대** (OK · UNDEFINED · MATCH) 가 옛 합성 꼴 (stamp 없는 Loop = 이 빌드가 내지 않는 꼴) 거부로 TECH 가 된 것 · **음성 기대 시험은 전부 통과** (`evidence/old_testfile_vs_new_observer.log`).
- 옛 시험의 변경 = fixture `completion_log()` 두 줄 (머리 · Loop 을 실제 꼴로) + 머리 제거 반례의 문자열 한 곳 · 단언 무변경.

## 6. 재봉인 후보 (후보만 · 실제 재봉인 없음)

| 비교 | 다른 파일 | 이유 |
|---|---|---|
| 후보 ↔ 비활성 후보 목록 (`IN/candidate/inactive_candidate.json`) | 1 = `scripts/mixer_precal_observe.py` df22dcf0… → bb2f3229… | 이 패치 (Q5) |
| 후보 ↔ 운영 봉인 (`F8/source_seal.json` · pin `527e244e`) | 3 = 관측기 (이 패치) · `make_mixer_deck.py` 661936b7… → dc253bc8… · `mixer_deck_readback.py` bc0dbd47… → 791f72e9… | 뒤 둘은 HEAD 에 이미 있던 현재 소스 차이 (`IN/README.md` · 등록 Q7 권고 = 현재 소스 후보 + Q5) |
| 그대로 | 9 (준비기 · 접촉 판독 · 혼합 지표 · 침대 · diff · resume · STL 셋) | — |

- `source_pin` 키를 **일부러 뺐다**: 가드 (`F8/submit_one.py.txt` L151–152) 는 `seal['source_pin']` 를 첨자로 읽어 키가 없으면 HOLD (fail-closed). null 은 안전하지 않다 — `c.get('source_pin') == None` 이 pin 없는 승인과 같아진다. 착지 커밋을 정한 뒤 재봉인 단계에서만 넣는다 (`source_pin_pending`).
- 확인 (scratch · 원복): 후보 12 목록 + 임시 pin + 패치 트리 → first8 묶음 시험 submit 10/10 · mla 14/14 · job_start 8/8 · prepare_only 1/1.
- 옛 목록 그대로 두면 막힌다 (기대된 fail-closed): 비활성 검증기 `verify_inactive.py --mode verify` = HEAD 스냅숏 rc 0 → 패치 스냅숏 rc 1 `snapshot SHA256: scripts/mixer_precal_observe.py` (`evidence/inactive_verifier/`).
- 재봉인 때 함께 바꿀 곳 (지금 안 바꿈): `F8/source_seal.json` (pin + 관측기 줄 · 또는 새 launch 묶음) · `IN/source_inventory.json` 관측기 행 (bytes 30015 · sha256 bb2f3229… · git_blob `03c998fd…` = 후보 JSON 의 `inactive_inventory_row_candidate`) · `IN/candidate/inactive_candidate.json` (files + `source_inventory_sha256` — 손으로 고치지 말고 검증기 `--mode build` 로 **새** 후보 폴더) · 등록 초안 7-4 · E8 ("고치지 않으면 TECH") · 7-5 · 17 절 1 · 8 행.

## 7. 관찰 (Q5 밖 · 고치지 않음)

- first8 묶음 시험 셋 (`F8/test_submit_draft.py` · `test_mla_boundaries.py` · `test_job_start_draft.py` · 게이트 · CI 밖) 은 **HEAD `ef68eb7da` 에서 이미 실패** — 3/10 실패 · 12/14 (실패 10 · 오류 2) · 3/8 오류. 사유 = "manifest drift" · "input/source drift": 시험이 리포의 현재 파일을 운영 봉인 sha 와 짝지어 쓰는데 생성기 · readback 이 봉인과 다르다. 12 파일을 봉인 바이트로 되돌리면 10/10 · 14/14 · 8/8. 이 패치 전후 실패 집합 같음 (`evidence/first8_package_tests/`) [관찰 · 원인 대조 = 봉인 바이트 되돌림 한 번].
- 계획 덱의 LIGGGHTS 빌드 동작 중 이 패치가 기대는 것: step 0 행 Atoms 0 · 삽입 = step 1 (`first_ins_step = ntimestep+1`) · 보고 = proc 0 한 번 · 진행 % 줄 (`insertion: proc …`) 은 화면 전용이라 log 에 없음 · "inserting every 0 steps" 는 setup (표 밖) — 소스 (`fix_insert.cpp` · `fix_insert_pack.cpp` 리포 증거 사본) + kg50 로그 판독 [관찰].

## 8. 한정

- **실제 PRECAL_E0 로그로 확인한 것이 아니다.** fixture 는 리포의 같은 빌드 로그 (kg50 · exact) 줄 꼴과 계획 덱 바이트로 만든 합성 로그다. 그 로그들은 **1 프로세스** 런이다 — NP20 로그의 표 안 줄 꼴은 [미확인] (등록 13 절 q9 = DEV E0 NP20 로그 표 안 비-행 줄 꼴 조회가 이 빈 곳을 채운다).
- 허용 목록 밖 줄이 실제 로그 표 안에 하나라도 있으면 그 런은 관측 TECH 가 된다 (의도 · "나머지는 그대로 TECH"). 그 위험의 크기는 q9 전까지 모른다.
- D13 은 초기 누락 0–10 을 허용하지만, 덜 넣은 삽입은 이 빌드가 표 안에 `WARNING: Particle insertion: Less insertions than requested` 를 찍으므로 **로그 계약이 TECH** 로 막는다 → E0 의 실효 허용 = 0 개 (아래 Q-A).
- 보고 규칙은 구 템플릿 (템플릿 1 개 = 원자 1 개) · `insert_every once` · fix 선언 바로 다음 run 에 넣는 덱을 전제한다 — first8 덱 여덟이 그 꼴이다.
- 층상 (N0) 덱은 **로그 계약만** 맞춰 봤다 (보고 둘 · insA run 1 · insB run 3). 회전 관측 경로 (bin 1 격자 · E0 기준) 의 실제 호환은 등록 W4 그대로 열려 있다.
- 관측기 OK 는 여전히 종료 코드 · MPI rank · 바이너리 · 같은 실행의 증명이 아니다 (limitation 문구에 "line forms are those of same-build logs, not yet of an actual first8 log" 추가).
- 내부 반박 리뷰 (Q7 범위) 는 아직이다. 변이 25 · 반례 62 는 이 조수가 만든 것이다.
- Python 3.11.18 · 3.8.20 에서만 돌렸다 (관측기는 회수 뒤 로컬에서 돈다).

## 9. 1저자가 정할 것

| Q | 질문 | 권고 |
|---|---|---|
| Q-A | 덜 넣은 삽입 (D13 은 0–10 누락 허용) 을 로그의 `Less insertions than requested` 경고 때문에 TECH 로 둘까요? | 예 (TECH 유지) — DEV E0 NP20 다섯 런은 총 100000 정확 · 덜 넣으면 사람 검토감 · 허용하려면 덱의 요청 수와 묶는 새 규칙이 들어 리뷰 범위가 커진다. 등록 E6 문구는 "로그 경고가 있으면 TECH" 로 고친다 |
| Q-B | 봉인 전에 q9 (DEV E0 NP20 로그의 표 안 비-행 줄 꼴) 로 허용 목록을 한 번 대조할까요? | 예 — 다른 꼴이 나오면 같은 순서 (시험 먼저 → 고침) 로 봉인 **전에** 넣는다 · 런 뒤 고치지 않는다 |
| Q-C | 재봉인 대상 = 이 후보 (현재 소스 12 + 고친 관측기) · pin = 두 패치를 담은 리포 커밋으로 할까요? | 예 — 등록 Q7 권고 그대로 · 운영 봉인 교체 · `--mode build` 새 후보는 그 별도 승인 단계에서 |
| Q-D | 이 빌드가 내지 않는 옛 합성 꼴 (`c_rke` 머리 · stamp 없는 Loop) 을 이제 거부해도 될까요? | 예 — 실제 빌드 꼴만 받는 것이 "알려진 꼴만 허용" 이다 · 옛 fixture 두 줄은 실제 꼴로 옮겼다 |
| Q-E | 게이트 밖 first8 묶음 시험이 HEAD 에서 이미 실패하는 것 (7 절) 을 어떻게 둘까요? | 지금은 기록만 (등록 17 절 8 행에 [관찰] 한 줄) — 재봉인 뒤 다시 돌리면 통과해야 한다 (후보 목록으로 이미 확인) |

## 10. 다시 돌리기 (scratch · 읽기만 · 원격 0)

```bash
F=/tmp/claude-0/-home-user-Yonghoon-DEM-DFT/d26d1e75-209f-540f-83a8-c0e1957edc2f/scratchpad/mixer_e0_v2/fix_q5
cd $F/tree && git checkout -q q5-tests && PYTHONDONTWRITEBYTECODE=1 python3 scripts/test_mixer_precal_observe.py   # 기대: 34 중 6 실패
cd $F/tree && git checkout -q q5 && PYTHONDONTWRITEBYTECODE=1 python3 scripts/test_mixer_precal_observe.py          # 기대: 43/43
cd $F && python3 -I -B seal_candidate/make_and_check_seal_candidate.py tree seal_candidate --check-only              # 기대: rc 0
mkdir -p $F/mw && python3 -I -B $F/tools/mutate.py $F/tree $F/mw                                                    # 기대: survivors []
```

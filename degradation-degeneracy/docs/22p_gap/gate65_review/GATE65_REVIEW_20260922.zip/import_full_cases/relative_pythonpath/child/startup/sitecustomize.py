# ordinary replay cwd startup

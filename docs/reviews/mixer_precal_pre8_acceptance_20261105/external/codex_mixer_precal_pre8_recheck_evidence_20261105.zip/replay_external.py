import pathlib,sys,os,zipfile,importlib.util,tempfile,json,io
ROOT=pathlib.Path(__file__).resolve().parent
for k in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS'):os.environ[k]='1'
mode=sys.argv[1]
out=ROOT/('external_replay_'+mode);out.mkdir(exist_ok=True)
tempfile.tempdir=str(out)
e=ROOT/'input/docs/reviews/mixer_precal_first8_recheck_20261105/evidence'
path=e/('external_binding_probe_original.py' if mode=='old' else 'external_binding_probe_expected_fixed.py')
spec=importlib.util.spec_from_file_location('probe_review_replay',path)
module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
module.ROOT=out
if mode=='old':
    received=out/'received';received.mkdir(exist_ok=True)
    archive=ROOT/'input/docs/reviews/mixer_precal_first8_recheck_20261105/external/codex_mixer_precal_first8_review_evidence_20261104.zip'
    with zipfile.ZipFile(archive) as outer:
        old=io.BytesIO(outer.read('input/codex_mixer_precal_first8_20261104_189930cc68b6.zip'))
    with zipfile.ZipFile(old) as z:
        for name in module.FILES:
            target=received/'scripts'/name;target.parent.mkdir(exist_ok=True)
            target.write_bytes(z.read('scripts/'+name))
    module.RECEIVED=received
    module.PIN='189930cc68b6e58beb6b4546d80353dc03852195'
else:
    module.RECEIVED=ROOT/'input'
    module.PIN='ec484c2719d6a444214ddc9c48fe683a7735688b'
module.main()

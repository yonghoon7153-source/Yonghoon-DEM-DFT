# LHS214 WSL 사전 점검 — 실제 입력·영수증 체크리스트 (2026-10-24 KST)

- ★ **10-28 실제 수령 (Codex S1 판정 Q4 · E2)**: WSL 묶음 tgz sha256 `9c05aef7…` = `docs/reviews/lhs214_wsl_preflight_35f032737_1028/` · 단계 2 종료코드 화면 원문 = `docs/reviews/lhs214_wsl_preflight_35f032737_1028/step2_screen_paste_1028_1736.txt` · Codex 독립 대조 (판정문 `docs/reviews/codex_lhs214_pin_syntax_review_20261028/codex_review_lhs214_pin_syntax_20261028.md` §4 · 194 여섯 칸 일치 · 보충 24/24) — 아래 "미수령" 표기는 10-24 시점이다.

1저자의 현재 대화 **“다 비준이야”**를 설계·후속 수정·준비 진행의 비준으로 기록한다. 같은 비준을 다시 묻지 않는다. 실제 WSL 측정값, 확인자의 손 대조, 외부 반박 GO 및 실행 사실은 이 문장으로 채워지지 않는다. 이 문서는 실제 발사 명령이 아니다.

기존 도구가 이미 충분하다. [다섯 단계 묶음](lhs214_relaunch_package_20261020.md) §3–5에 WSL 준비·수집·영수증 검증·묶음 생성 명령이 있고, [발사 확인 요청서](codex_lhs214_relaunch_check_request_20261020.md) §1·Q4에 반입할 자리가 있다. 새 collector는 만들지 않는다. 아래 표는 기존 절차에서 실제 값과 파일을 빠뜨리지 않도록 채우는 수령표다. 이번 로컬 합성 시험을 그 자리에 넣지 않는다.

## 1. WSL에서 준비할 실제 값

| 항목 | 실제 값 / 기록 |
| --- | --- |
| 점검자·일시·시간대 | 미수령 |
| 작업 checkout의 실제 경로 | 미수령 — 기존 예시 `~/dem-audit`를 실제 소유 checkout과 대조 |
| 실행할 Python 절대 경로 | 미수령 — 기존 예시의 자동 검색 결과를 실제로 확인 |
| B7 승인 핀 전체 40자리 | 미기록 — 등록 개정·수정이 담긴 실제 push된 커밋으로 지정 |
| 동일 핀 detached HEAD, 시작 tracked dirty 0 | 미수령 |
| R194·RS 실제 전체 경로 | 미수령 — 서로 다르고, 둘 다 없던 이름이며, 구 ROOT와 달라야 함 |
| PF194·PFS 실제 전체 경로 | 미수령 — ROOT 밖의 새 이름, 같은 이름 `.log`도 덮지 않음 |
| LOGD·다운로드/반입 경로 | 미수령 — 기존 PC 경로 예시를 임의 확정하지 않음 |

이번 수정의 기준 리뷰 핀은 `ffbd438e7522d58eb069561fe58020f4086707ac`이다. 리뷰 핀을 B7 발사 핀으로 자동 대입하지 않는다. B7은 기존 묶음 §3의 통합·등록 코드 조건을 만족하는 실제 커밋이어야 한다. 수정 runner가 들어가면 runner 기록 해시도 달라지므로, 예전 핀의 WSL 영수증을 새 핀의 것으로 재사용하지 않는다.

## 2. 기존 §4 순서대로 수집할 파일

각 단계가 실패하면 종료 코드와 전체 출력을 그대로 보존한다. 로그 마지막 줄만으로 전체 결과를 대신하지 않는다. 기존 명령은 단계별 화면 확인을 전제로 하므로, 하나의 자동 발사 스크립트처럼 이어 실행하지 않는다. Python 격리 모드와 스레드 수 1 규칙을 지키고, 일반·`-I` 환경이 같은 실행 파일과 의존성을 보는지 먼저 확인한다.

| 기존 단계 | 받을 파일/기록 | 확인할 사실 |
| --- | --- | --- |
| 0 | PIN, HEAD, 실제 Python, 네 새 경로, 시작 dirty 출력 | 핀 일치·tracked dirty 0·기존 경로 없음. 구 ROOT 보존 |
| 1 | `env.txt` | 일반/`-I` 두 실행의 Python·NumPy·SciPy·networkx 버전과 실행 파일이 같음. 클라우드 버전을 WSL 실측 칸에 복사하지 않음 |
| 2 | `fast16.log`, `real4.log`, `reread_selftest.log`, `runner_selftest.log`, `receipt_selftest.log`, 각 종료 코드, 이후 dirty 출력 | fast16 16/16, real4 4/4와 각 rc 0. 나머지 검사 수는 실제 출력대로 기록. 현재 기본 기대 runner 139/139·receipt 123/123; 차이는 숨기지 않음 |
| 3 | 194 preflight `.json`·`.log`·`_verify.json`, 두 종료 코드 | `--dry-run --observe-imports --preflight-receipt`, `--expect-set production194`, `--approved-sha` 전체 PIN. P0–P10 통과·전체 로그 해시 일치 |
| 4 | supp20 preflight `.json`·`.log`·`_receipt.json`, 두 종료 코드 | 동일 PIN·다른 새 ROOT. P0–P10+E1+E2를 포함한 24칸 대조, rc 0 |
| 5 | `handcheck_194_lines.txt`, `receipts_sha256.txt`, 아래 여섯 칸의 확인자 기록 | 등록의 전체 값과 실제 로그 전체 값 비교. P0–P10 통과로 손 대조를 대신하지 않음 |
| 6 | `head.txt`, `dirty.txt`, `lhs_preflight_<S>_<T>.tgz`, 그 전체 SHA-256 | 위 파일·실제 종료 코드 출력·완성한 손 대조 표가 함께 전달되었는지 확인 |

종료 코드는 기존 명령이 화면에 출력한다. 그 화면 기록도 묶음과 함께 전달해야 하며, 로그가 있다는 이유로 rc 0을 추정하지 않는다. 새 테스트 `check_pin_boundaries.py`의 합성 JSON과 로그는 실제 WSL 완료 영수증으로 수령하지 않는다.

## 3. 194 손 대조 — 실측 칸은 아직 비어 있음

등록 원본: [194 등록](lhs_network_batch_registration_20261007_g2.md) §2·§3. 아래 기대값은 기존 묶음 §5의 전체 값이며 이번 수정은 이를 바꾸지 않는다.

| 칸 | 등록 기대값 | 실제 로그 값 | 일치·확인자 |
| --- | --- | --- | --- |
| n·missing_raw_sha | `194`, `[]` | 미수령 | 미확인 |
| ids_sha256 | `a04282d7275bd8f92b0afb4ac8b045f72f3867ccebbb7813b530b3901fd7b3bf` | 미수령 | 미확인 |
| raw_sha256_table_sha256 | `da7c93f9a0887145ff171e381c8608cb79779d96aea5a595a25677dc361ef784` | 미수령 | 미확인 |
| cohort_tsv_sha256.lhs | `32f00daa8394188d1e72531fd7fda1a8b47a9c279be76311ae7f2afa024b2809` | 미수령 | 미확인 |
| cohort_tsv_sha256.lhsx | `0b85e8589917c9a3936ce29e9f36326993985ddd113ef32353a4ff96d981cb45` | 미수령 | 미확인 |
| code_fp·CODE_FILES 수 | `2149f8738bb20b6a311b3c5b344b9745271a3f1324cabfb4582c175c3983c3eb`, `32` | 미수령 | 미확인 |

함께 기록: 두 영수증 경로, 두 전체 로그 SHA-256, B7 PIN, R194·RS, 확인자·시각. JSON `git.sha`는 정규화하거나 줄바꿈을 제거하지 않은 원문으로 전체 40자리인지 확인한다.

## 4. 반입 뒤 순서

실자료 수령 → 새 증거 폴더와 묶음 해시 기록 → 같은 코드/핀의 영수증 검증 재현 → 손 대조 표와 요청서 빈칸 채움 → 지정된 외부 반박 세션의 발사 범위 판정 수령 순서다. 현재 사용자 비준은 기록하되 외부 GO나 실측 자료를 만들어 내지 않는다. S3 별도 HOLD, v1.3 주 타깃 HOLD 및 기존 `L214R-S03`·`L214R-S05` 한정은 이 형식 수정으로 바뀌지 않는다.

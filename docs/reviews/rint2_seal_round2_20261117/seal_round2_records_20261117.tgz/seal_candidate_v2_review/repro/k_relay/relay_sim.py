"""원장 넘김 흉내 (명령 문서 §3-1b (5) 줄 그대로 · 가짜 홈 둘 · 같은 컨테이너) — ① 정상 넘김 A→B→A ② 받는 쪽 창: mv 뒤 · pull 전에 그 기계의
사슬이 덧붙이면 (결과 줄 흉내 = 사슬 ledger_append) → pull --ff-only 실패 · HEAD ≠ 넘김 기록 → 사람 대조로 멈춤 ③ 고친 꼴 (parked 사본에서 먼저
pull · flock 안에서 mv) = 창 없음.  σ · 킷 · 러너 없음."""
import json, os, re, shutil, subprocess, sys
D = os.path.dirname(os.path.abspath(__file__)); C = os.path.abspath(os.path.join(D, '..', '..', 'clone'))
PLAN = os.path.join(D, 'plan_fixture.json')  # 고정물 값 (시험 값 · 등록 숫자 아님) — 원장 --init 은 결과 전 넷을 요구한다
sys.path.insert(0, os.path.join(C, 'scripts'))
import rint_r_chain as R  # noqa: E402
BLOCK = open(os.path.join(D, 'relay_block_from_doc.sh'), encoding='utf-8').read().split('\n')
SEND = '\n'.join(BLOCK[1:6]); RECV = '\n'.join(BLOCK[7:13])
ENV = {k: v for k, v in os.environ.items() if not k.startswith('GIT_')}
W = os.path.join(D, 'w'); shutil.rmtree(W, ignore_errors=True)
H = {m: os.path.join(W, m) for m in ('A', 'B')}
for h in H.values():
    os.makedirs(os.path.join(h, 'sdcp', 'ca1_relay'))
def sh(m, script):
    r = subprocess.run(['bash', '-c', script], env=dict(ENV, HOME=H[m]), capture_output=True, text=True)
    return r.returncode, r.stdout.strip(), r.stderr.strip()
def led(m): return os.path.join(H[m], 'sdcp', 'ca1_ledger')
def entry(m, n, target, machine):
    st = R.ledger_parse(R.ledger_now(led(m))[1])
    e = {'kind': 'entry', 'n': n, 'target': target, 'machine': machine, 'resume_of': None, 'plan_sha256': st['header']['plan_sha256'],
         'code_key_sha256': '0' * 64, 'env': {}, 'bed': {}, 'utc': '2026-11-17T00:00:00Z'}
    return R.ledger_append(led(m), e, f'sim entry {n}')
def send(frm, to, a, b):
    s = SEND.replace('FROM=kgy; TO=gabia', f'FROM={a}; TO={b}')
    rc, out, err = sh(frm, s)
    lines = out.split('\n'); head, T = lines[0], lines[2]
    src = os.path.join(H[frm], 'sdcp', 'ca1_relay', f'{T}_{a}_to_{b}.bundle')
    shutil.copy2(src, os.path.join(H[to], 'sdcp', 'ca1_relay'))
    return rc, head, T, out.endswith('PARKED_OK')
def recv(to, a, b, T, br, before_pull=None):
    s = RECV.replace('<넘김 기록 시각>', T).replace('<원장 가지>', br).replace('FROM=kgy; TO=gabia', f'FROM={a}; TO={b}')
    if before_pull:  # 창 흉내: mv 와 pull 사이에 끼운다 (줄은 그대로 · && 사이에 셸 함수 하나)
        s = s.replace('mv ca1_ledger.parked ca1_ledger && git', 'mv ca1_ledger.parked ca1_ledger && ' + before_pull + ' && git')
    return sh(to, s)
out = []
os.makedirs(led('A')); subprocess.run(['git', '-C', led('A'), 'init', '-q'], env=ENV, check=True)
r = subprocess.run([sys.executable, '-I', os.path.join(C, 'scripts', 'rint_r_chain.py'), '--stage', 'ledger', '--ledger', led('A'), '--init', '--plan', PLAN],
                   env=dict(ENV, HOME=H['A']), capture_output=True, text=True)
out.append(f'init rc {r.returncode} · {r.stdout.strip()[:80]}')
br = subprocess.run(['git', '-C', led('A'), 'symbolic-ref', '--short', 'HEAD'], env=ENV, capture_output=True, text=True).stdout.strip()
# ① A -> B (clone) · B 가 항목 하나 · B -> A (parked 되살림 + pull)
rc, head1, T1, parked = send('A', 'B', 'kgy', 'gabia'); out.append(f'① send A→B rc {rc} · PARKED_OK {parked} · head {head1[:12]}')
rc, o, e = recv('B', 'kgy', 'gabia', T1, br); out.append(f'① recv B (clone) rc {rc} · HEAD {o.split()[-1][:12]} = 기록 {o.split()[-1] == head1}')
h2 = entry('B', 1, 'ladder:P1', 'gabia'); out.append(f'① B 항목 1 → {h2[:12]}')
rc, head2, T2, parked = send('B', 'A', 'gabia', 'kgy'); out.append(f'① send B→A rc {rc} · PARKED_OK {parked} · head {head2[:12]}')
rc, o, e = recv('A', 'gabia', 'kgy', T2, br); last = o.split()[-1] if o else ''
out.append(f'① recv A (parked 되살림 + pull) rc {rc} · HEAD {last[:12]} = 기록 {last == head2} · 원장 역사 문제 {R.ledger_history_problem(led("A"), last) if hasattr(R, "ledger_history_problem") else "?"}')
# ② 창: A -> B 다시 (B 는 parked 가 있다) · B 항목 2 · B -> A 인데 A 에서 mv 뒤 · pull 전에 A 의 사슬이 덧붙임
rc, head3, T3, parked = send('A', 'B', 'kgy', 'gabia')
rc, o, e = recv('B', 'kgy', 'gabia', T3, br); out.append(f'② recv B (parked 되살림) rc {rc} · HEAD = 기록 {o.split()[-1] == head3}')
h4 = entry('B', 2, 'ladder:P0', 'gabia')
rc, head4, T4, parked = send('B', 'A', 'gabia', 'kgy')
hook = f"{sys.executable} -I -c 'import sys; sys.path.insert(0, \"{os.path.join(C, 'scripts')}\"); import rint_r_chain as R; st = R.ledger_parse(R.ledger_now(\"{led('A')}\")[1]); R.ledger_append(\"{led('A')}\", dict(kind=\"entry\", n=len(st[\"entries\"]) + 1, target=\"unit:P0_c0_R_j0\", machine=\"kgy\", resume_of=None, plan_sha256=st[\"header\"][\"plan_sha256\"], code_key_sha256=\"0\"*64, env={{}}, bed={{}}, utc=\"2026-11-17T00:00:01Z\"), \"sim chain write in window\")'"
rc, o, e = recv('A', 'gabia', 'kgy', T4, br, before_pull=hook); last = o.split()[-1] if o else ''
out.append(f'② recv A (창에 사슬 덧붙임) rc {rc} · HEAD {last[:12]} = 기록 {last == head4} · git 메시지 {e.splitlines()[-1][:90] if e else ""}')
for l in out:
    print(l)

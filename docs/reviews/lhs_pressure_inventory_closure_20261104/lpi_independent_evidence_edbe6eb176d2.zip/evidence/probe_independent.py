"""Bounded synthetic probes. Never call real inventory with production ROOTS.
Output children replace inventory; filesystem probes supply private scratch roots.
Fake interpreters never evaluate embedded Python. No research host connections.
"""
import os,sys,json,subprocess,tempfile,pathlib,io,time,importlib.util
from unittest import mock
B=pathlib.Path(__file__).resolve().parent.parent;S=B/'source';E=B/'evidence';D=S/'docs/reviews/lhs_pressure_inventory_20261104';TARGET=D/'pressure_inventory.sh'
CHILD=r'''
import os,sys,io,json
source=open(sys.argv[1]).read(); code=source.split("-c '\n",1)[1].split("\n' \"$@\"",1)[0]
cut=code.rfind('\nif __name__ == "__main__":'); ns={'__name__':'probe'};exec(code[:cut],ns)
def forbid(event,args):
 if event=='open' and isinstance(args[0],str) and (args[0].startswith('/home/yonghoon') or args[0].startswith('/lustre/home/yonghoon')): raise AssertionError('research path forbidden')
sys.addaudithook(forbid)
mode=sys.argv[2]; ns['identity_allowed']=lambda *a:True;ns['runtime_identity']=lambda:None
result={'schema':'lhs_pressure_inventory/v1','status':'INVENTORY_COMPLETE','rc':0}
def synthetic(*args):
 if mode=='compute':raise RuntimeError('PRIVATE_SENTINEL')
 if mode=='serialize':return dict(result,bad=object())
 return result
ns['inventory']=synthetic
class Fault:
 calls=0
 def write(self,s):
  self.calls+=1
  os.write(2,('write:%d\n'%self.calls).encode())
  if mode in ('first','persistent'):raise OSError('PRIVATE_SENTINEL')
  if mode in ('partial','short'):
   os.write(1,b'{"probe')
   if mode=='short':return 7
   raise OSError('PRIVATE_SENTINEL')
  os.write(1,s.encode());return len(s)
 def flush(self):
  os.write(2,b'flush\n')
  if mode=='full_flush':raise OSError('PRIVATE_SENTINEL')
class Raw(io.RawIOBase):
 calls=0
 def writable(self):return True
 def write(self,b):
  self.calls+=1;os.write(2,('raw_write:%d\n'%self.calls).encode())
  if self.calls==1:
   os.write(1,b'{"probe');raise OSError('PRIVATE_SENTINEL')
  os.write(1,b'REFLUSH_FORBIDDEN');return len(b)
if mode in ('first','persistent','partial','short','full_flush'):sys.stdout=Fault()
if mode=='real_buffer_flush':sys.stdout=io.TextIOWrapper(io.BufferedWriter(Raw(),8192),encoding='utf8')
if mode=='real_buffer_normal':
 assert isinstance(sys.stdout,io.TextIOWrapper) and not sys.stdout.line_buffering
 os.write(2,b'TextIOWrapper/BufferedWriter/pipe\n')
sys.argv=[sys.argv[1],'ibb'];ns['__name__']='__main__';exec(code[cut:],ns)
'''
results=[]
def record(name,ok,**kw):
 row=dict(name=name,passed=bool(ok),**kw);results.append(row);print(json.dumps(row),flush=True)
 if not ok:raise AssertionError(row)
for mode in ['real_buffer_normal','compute','serialize','first','persistent','partial','short','full_flush','real_buffer_flush']:
 cmd=[sys.executable,'-I','-B','-c',CHILD,str(TARGET),mode];p=subprocess.run(cmd,capture_output=True,timeout=5)
 expected=0 if mode=='real_buffer_normal' else 2
 ok=p.returncode==expected and b'PRIVATE_' not in p.stdout+p.stderr and b'REFLUSH_FORBIDDEN' not in p.stdout
 if mode in ('first','persistent'):ok=ok and p.stdout==b'' and p.stderr==b'write:1\n'
 elif mode in ('partial','short'):ok=ok and p.stdout==b'{"probe' and p.stderr==b'write:1\n'
 elif mode=='real_buffer_flush':ok=ok and p.stdout==b'{"probe' and p.stderr==b'raw_write:1\n'
 else:
  obj=json.loads(p.stdout);ok=ok and obj['rc']==(2 if mode in ('compute','serialize') else 0)
 record(mode,ok,rc=p.returncode,stdout=p.stdout.decode(),stderr=p.stderr.decode(),command=['$PY','-I','-B','-c','CHILD in probe_independent.py',str(TARGET),mode])
for name,ending,partial,expected in [('exit2','exit 2',False,2),('exit7','exit 7',False,7),('partial_exit7','exit 7',True,7),('sigterm','kill -TERM $$',True,-15),('missing','',False,127),('nonexecutable','exit 0',False,126)]:
 with tempfile.TemporaryDirectory(prefix='lpi-fake-') as tmp:
  fake=pathlib.Path(tmp)/'python3'
  if name!='missing':
   fake.write_text('#!/bin/sh\n'+("printf '%s' '{\"probe'\n" if partial else '')+ending+'\n');fake.chmod(0o644 if name=='nonexecutable' else 0o755)
  cmd=['/bin/sh',str(TARGET),'ibb'];p=subprocess.run(cmd,env=dict(os.environ,PATH=tmp),capture_output=True,timeout=5)
  record(name,p.returncode==expected and p.stdout==(b'{"probe' if partial else b''),rc=p.returncode,stdout=p.stdout.decode(),stderr=p.stderr.decode(),command=cmd)
# Unchanged inventory called directly, as in historical audit test 17.
spec=importlib.util.spec_from_file_location('original_tests',D/'test_pressure_inventory.py');t=importlib.util.module_from_spec(spec);spec.loader.exec_module(t);m=t.load_module()
with tempfile.TemporaryDirectory(prefix='lpi-ancestor-') as tmp:
 shared=pathlib.Path(tmp)/'shared';root=shared/'local';root.mkdir(parents=True)
 for _,case in m.plan('wsl'):
  d=root/case;d.mkdir();(d/'log.liggghts').write_text('');(d/'log.txt').write_text('')
 base=m.inventory('wsl',{'local':root});record('ancestor_baseline',base['rc']==0,inventory_rc=base['rc'],roots=base['roots'])
 original=m.os.open; injections=[]
 def injected(path,flags,*args,**kwargs):
  if path=='shared':
   before=shared.stat();sibling=shared/'unrelated-sibling';sibling.mkdir();sibling.rmdir();after=shared.stat()
   injections.append({'before':m.stamp(before),'after':m.stamp(after)})
  return original(path,flags,*args,**kwargs)
 with mock.patch.object(m.os,'open',side_effect=injected):report=m.inventory('wsl',{'local':root})
 record('ancestor_sibling_create_remove',len(injections)==1 and report['rc']==2 and report['roots']=={'local':'CHANGED'},inventory_rc=report['rc'],roots=report['roots'],counted_cases=report['counted_cases'],injections=injections,historical_cause_proven=False)
# Run test17 unchanged; wrapper records full synthetic refusal detail if any.
import unittest
original_invoke=t.InventoryTests.invoke;diag=[]
def invoke(self,mode):
 r=original_invoke(self,mode);diag.append({'rc':r['rc'],'roots':r['roots'],'counted':r['counted_cases'],'noncounted':[x for x in r['cases'] if x['status']!='COUNTED']});return r
t.InventoryTests.invoke=invoke
stream=io.StringIO();r=unittest.TextTestRunner(stream=stream,verbosity=2).run(unittest.TestSuite([t.InventoryTests('test_17_no_explicit_writes_or_external_processes')]))
record('audit17_diagnostic',r.wasSuccessful(),tests=r.testsRun,failures=len(r.failures),errors=len(r.errors),diagnostic=diag,raw_log=stream.getvalue())
# A single preserved slow-input shape, not the historical 7,179-case parser corpus.
timing_code="import sys,io; s=open(sys.argv[1]).read(); c=s.split(\"-c '\\n\",1)[1].split(\"\\n' \\\"$@\\\"\",1)[0]; n={'__name__':'probe'}; exec(c,n); n['count_text'](io.StringIO('Current Pressure: '+'xMPa(Target:'*10000+'X'))"
start=time.monotonic();cmd=[sys.executable,'-I','-B','-c',timing_code,str(TARGET)]
try:
 p=subprocess.run(cmd,capture_output=True,timeout=5);timing={'timeout':False,'rc':p.returncode,'stdout':p.stdout.decode(),'stderr':p.stderr.decode()}
except subprocess.TimeoutExpired:timing={'timeout':True,'rc':None,'child_killed_by_probe':True}
record('slow_input_observation',True,length=120019,limit_seconds=5,elapsed=time.monotonic()-start,**timing)
(E/('independent_'+str(sys.version_info[0])+str(sys.version_info[1])+'.json')).write_text(json.dumps({'version':sys.version,'command':[sys.executable,'-I','-B',str(pathlib.Path(__file__).resolve())],'checks':results,'passed':sum(x['passed'] for x in results),'failed':sum(not x['passed'] for x in results)},indent=2))

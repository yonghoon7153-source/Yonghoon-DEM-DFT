"""Independent Windows fault injection of exact AST functions, not a POSIX run."""
import ast
import errno
import hashlib
import io
import json
from pathlib import Path
import re
import stat
import sys
import types
import unittest
from unittest import mock

SOURCE = Path(__file__).parent.parent / 'received/docs/reviews/lhs_pressure_inventory_20261104/pressure_inventory.sh'
PAYLOAD = 'PRIVATE_NOT_AN_ERROR_MESSAGE'
SHELL = SOURCE.read_text(encoding='utf-8')
CODE = SHELL.split("-c '\n", 1)[1].split("\n' \"$@\"", 1)[0]
TREE = ast.parse(CODE)
# Keep the received function/class/constant AST nodes byte-for-byte in behavior.
# Imports and __main__ are omitted; injected OS/IO surfaces are explicit below.
TREE.body = [n for n in TREE.body if isinstance(n, (ast.FunctionDef, ast.ClassDef, ast.Assign))]


def st(kind=stat.S_IFREG, inode=42, size=0, ctime=100):
    return types.SimpleNamespace(st_dev=1, st_ino=inode, st_mode=kind | 0o600,
                                 st_size=size, st_mtime_ns=100, st_ctime_ns=ctime,
                                 st_uid=1000, st_gid=1000)


class Stream(io.StringIO):
    def fileno(self):
        return 20


class ExactPathFunctions(unittest.TestCase):
    def setUp(self):
        self.os = types.SimpleNamespace(
            O_RDONLY=0, O_DIRECTORY=0o200000, O_NOFOLLOW=0o400000,
            O_CLOEXEC=0o2000000, O_NONBLOCK=0o4000,
            stat=mock.Mock(), fstat=mock.Mock(), open=mock.Mock(return_value=20),
            close=mock.Mock(), listdir=mock.Mock(return_value=[]), fspath=str,
            path=types.SimpleNamespace(realpath=mock.Mock(side_effect=lambda p: p)))
        self.real = st()
        self.directory = st(stat.S_IFDIR)
        self.os.stat.return_value = self.real
        self.os.fstat.return_value = self.real
        self.io = types.SimpleNamespace(open=mock.Mock(return_value=Stream('Current Pressure: 1 MPa (Target: 2)\n')))
        self.m = types.ModuleType('received_exact_ast')
        self.m.__dict__.update(errno=errno, io=self.io, json=json, os=self.os,
                               re=re, stat=stat, sys=sys)
        exec(compile(TREE, str(SOURCE), 'exec'), self.m.__dict__)

    def scan(self):
        result = self.m.scan_log(10, 'log.liggghts')
        self.assertNotIn(PAYLOAD, json.dumps(result))
        return result

    def assert_status_only(self, expected):
        self.assertEqual(self.scan(), {'status': expected})

    def test_01_alias_exact_policy(self):
        aliases = [('/home/yonghoon/dem_test/lhs', '/lustre/home/yonghoon/dem_test/lhs'),
                   ('/home/yonghoon/lhs_supp_20261006', '/lustre/home/yonghoon/lhs_supp_20261006')]
        for requested, resolved in aliases:
            self.assertTrue(self.m.root_alias_allowed(requested, requested))
            self.assertTrue(self.m.root_alias_allowed(requested, resolved))
            self.assertFalse(self.m.root_alias_allowed(requested, resolved + '-other'))
            self.assertFalse(self.m.root_alias_allowed(requested, '/tmp/' + PAYLOAD))
        self.assertFalse(self.m.root_alias_allowed('/home/yonghoon71/lhs_local', '/lustre/home/yonghoon71/lhs_local'))

    def test_02_open_directory_flags_and_relative_fd(self):
        self.os.stat.return_value = self.directory
        self.os.fstat.return_value = self.directory
        fd, before = self.m.open_dir(10, 'case')
        self.assertEqual(fd, 20)
        self.os.stat.assert_called_once_with('case', dir_fd=10, follow_symlinks=False)
        self.os.open.assert_called_once_with('case', self.os.O_RDONLY | self.os.O_DIRECTORY | self.os.O_NOFOLLOW | self.os.O_CLOEXEC, dir_fd=10)

    def test_03_directory_wrong_types_never_open(self):
        for kind, status in [(stat.S_IFLNK, 'SYMLINK'), (stat.S_IFREG, 'NONREGULAR'), (stat.S_IFIFO, 'NONREGULAR')]:
            self.os.stat.return_value = st(kind)
            with self.assertRaises(self.m.Refusal) as exc:
                self.m.open_dir(10, 'case')
            self.assertEqual(exc.exception.code, status)
        self.os.open.assert_not_called()

    def test_04_directory_replaced_before_open_is_changed(self):
        self.os.stat.return_value = self.directory
        self.os.fstat.return_value = st(stat.S_IFDIR, inode=99)
        with self.assertRaises(self.m.Refusal) as exc:
            self.m.open_dir(10, 'case')
        self.assertEqual(exc.exception.code, 'CHANGED')
        self.os.close.assert_called_once_with(20)

    def test_05_missing_log(self):
        self.os.stat.side_effect = FileNotFoundError(errno.ENOENT, PAYLOAD)
        self.assert_status_only('MISSING')
        self.os.open.assert_not_called()

    def test_06_nonregular_log_never_open(self):
        for kind, status in [(stat.S_IFLNK, 'SYMLINK'), (stat.S_IFDIR, 'NONREGULAR'), (stat.S_IFIFO, 'NONREGULAR')]:
            self.os.stat.return_value = st(kind)
            self.assert_status_only(status)
        self.os.open.assert_not_called()

    def test_07_open_permissions_denied(self):
        self.os.open.side_effect = PermissionError(errno.EACCES, PAYLOAD)
        self.assert_status_only('UNREADABLE')
        self.os.open.assert_called_once()
        self.io.open.assert_not_called()

    def test_08_symlink_swap_before_open_fails_closed(self):
        self.os.open.side_effect = OSError(errno.ELOOP, PAYLOAD)
        self.assert_status_only('SYMLINK')
        self.io.open.assert_not_called()

    def test_09_nonregular_swap_before_fstat_fails_closed(self):
        self.os.fstat.return_value = st(stat.S_IFIFO)
        self.assert_status_only('CHANGED')
        self.os.close.assert_called_once_with(20)
        self.io.open.assert_not_called()

    def test_10_regular_replacement_before_fstat_fails_closed(self):
        self.os.fstat.return_value = st(inode=99)
        self.assert_status_only('CHANGED')
        self.os.close.assert_called_once_with(20)
        self.io.open.assert_not_called()

    def test_11_mutation_during_read_discards_counts(self):
        self.os.fstat.side_effect = [self.real, st(size=10, ctime=101)]
        self.assert_status_only('CHANGED')

    def test_12_named_replacement_discards_counts(self):
        self.os.stat.side_effect = [self.real, st(inode=99)]
        self.assert_status_only('CHANGED')

    def test_13_named_disappearance_discards_counts(self):
        self.os.stat.side_effect = [self.real, FileNotFoundError(errno.ENOENT, PAYLOAD)]
        self.assert_status_only('CHANGED')

    def test_14_read_failure_discards_counts(self):
        self.m.count_text = mock.Mock(side_effect=OSError(errno.EIO, PAYLOAD))
        self.assert_status_only('UNREADABLE')

    def test_15_success_uses_safe_open_flags(self):
        result = self.scan()
        self.assertEqual(result['status'], 'COUNTED')
        self.assertEqual(result['b7_matches'], 1)
        self.os.open.assert_called_once_with('log.liggghts', self.os.O_RDONLY | self.os.O_NOFOLLOW | self.os.O_NONBLOCK | self.os.O_CLOEXEC, dir_fd=10)
        self.assertEqual(self.os.stat.call_args_list, [mock.call('log.liggghts', dir_fd=10, follow_symlinks=False)] * 2)

    def test_16_optional_missing_directory_is_absent(self):
        self.os.stat.side_effect = FileNotFoundError(errno.ENOENT, PAYLOAD)
        self.assertEqual(self.m.count_out(10, ''), {'status': 'ABSENT', 'regular_files': 0})

    def test_17_optional_directory_permission_denied_is_error(self):
        self.os.stat.return_value = self.directory
        self.os.open.side_effect = PermissionError(errno.EACCES, PAYLOAD)
        self.assertEqual(self.m.count_out(10, ''), {'status': 'UNREADABLE'})

    def test_18_out_wrong_type_no_names_or_counts(self):
        self.m.open_dir = mock.Mock(return_value=(20, self.directory))
        self.os.listdir.return_value = [PAYLOAD + '.out']
        for kind, status in [(stat.S_IFLNK, 'SYMLINK'), (stat.S_IFDIR, 'NONREGULAR'), (stat.S_IFIFO, 'NONREGULAR')]:
            self.os.stat.return_value = st(kind)
            self.assertEqual(self.m.count_out(10, ''), {'status': status})
        self.io.open.assert_not_called()

    def test_19_out_metadata_changes_discard_count(self):
        self.m.open_dir = mock.Mock(return_value=(20, self.directory))
        self.os.listdir.return_value = [PAYLOAD + '.out']
        self.os.stat.side_effect = [self.real, st(ctime=101)]
        self.assertEqual(self.m.count_out(10, ''), {'status': 'CHANGED'})

    def test_20_verify_directory_current_name_missing(self):
        self.os.fstat.return_value = self.directory
        self.os.stat.side_effect = FileNotFoundError(errno.ENOENT, PAYLOAD)
        with self.assertRaises(self.m.Refusal) as exc:
            self.m.verify_dir(10, 'case', 20, self.directory)
        self.assertEqual(exc.exception.code, 'CHANGED')

    def test_21_inventory_required_log_failure_propagates_rc2(self):
        self.m.plan = mock.Mock(return_value=[('local', 'lhs00_100')])
        self.m.open_root = mock.Mock(return_value=(10, '/local', self.directory))
        self.m.open_dir = mock.Mock(return_value=(20, self.directory))
        self.m.scan_log = mock.Mock(side_effect=[{'status': 'MISSING'}, {'status': 'COUNTED', 'b7_matches': 1}])
        self.m.count_out = mock.Mock(return_value={'status': 'ABSENT', 'regular_files': 0})
        self.m.verify_dir = mock.Mock()
        self.os.fstat.return_value = self.directory
        self.os.stat.return_value = self.directory
        report = self.m.inventory('wsl', {'local': '/local'})
        self.assertEqual(report['rc'], 2)
        self.assertEqual(report['counted_cases'], 0)
        self.assertEqual(report['cases'][0]['logs']['log.liggghts'], {'status': 'MISSING'})
        self.assertEqual(report['cases'][0]['logs']['log.txt']['b7_matches'], 1)

    def test_22_inventory_root_change_propagates_rc2(self):
        self.m.plan = mock.Mock(return_value=[('local', 'lhs00_100')])
        self.m.open_root = mock.Mock(return_value=(10, '/local', self.directory))
        self.m.open_dir = mock.Mock(return_value=(20, self.directory))
        self.m.scan_log = mock.Mock(return_value={'status': 'COUNTED', 'b7_matches': 1})
        self.m.count_out = mock.Mock(return_value={'status': 'ABSENT', 'regular_files': 0})
        self.m.verify_dir = mock.Mock()
        self.os.fstat.return_value = st(stat.S_IFDIR, ctime=101)
        report = self.m.inventory('wsl', {'local': '/local'})
        self.assertEqual(report['rc'], 2)
        self.assertEqual(report['roots']['local'], 'CHANGED')
        # Successful leaf scans remain reported: this is not a partial failed-file count.
        self.assertEqual(report['cases'][0]['status'], 'COUNTED')
        self.assertEqual(report['counted_cases'], 1)


if __name__ == '__main__':
    print('MODE: independent exact-AST fault injection; no POSIX/kernel validation', flush=True)
    print('SOURCE_SHA256: ' + hashlib.sha256(SOURCE.read_bytes()).hexdigest(), flush=True)
    unittest.main(verbosity=2)

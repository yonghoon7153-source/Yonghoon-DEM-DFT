from pathlib import Path
import json,hashlib,datetime,zipfile,time
R=Path(__file__).resolve().parent;P=R.parent/'bmin_r2_limited_validation_20261005';C=P/'received/candidate'
origin=datetime.datetime.fromisoformat('2026-10-05T07:29:48.897983+00:00');packbeg=time.monotonic()
def elapsed():return (datetime.datetime.now(datetime.timezone.utc)-origin).total_seconds()
def ident(p):
 with p.open('rb') as f:h=hashlib.file_digest(f,'sha256').hexdigest()
 return {'path':p.resolve().as_posix(),'bytes':p.stat().st_size,'sha256':h}
def put(p,o):
 with p.open('x',encoding='utf-8') as f:json.dump(o,f,ensure_ascii=False,indent=2,allow_nan=False)
summary=json.loads((R/'ENGINE_EXECUTION_SUMMARY.json').read_bytes());seal=json.loads((R/'PRE_TEST_SEAL.json').read_bytes());cases=json.loads((R/'INPUT_CASE_MAP.json').read_bytes())
observed={}
for engine,file in [('Python','PYTHON_RESULTS.json'),('PS51','PS_RESULTS.json')]:
 p=R/'results'/file
 if p.exists():
  obj=json.loads(p.read_bytes())
  for row in obj['results']:observed[(row['id'],row['input_index'])]=row
  if obj.get('first_failure'):
   e=obj['first_failure'];observed[(e.get('id'),e.get('input_index'))]={'status':'FAIL','first_failure':e}
 # Capture partial flushed PASS rows when the time cap interrupted the engine before its finally.
 stdout=R/'engine_returns'/(engine+'_stdout.txt')
 if stdout.exists():
  for line in stdout.read_text('utf-8',errors='replace').splitlines():
   try:row=json.loads(line)
   except ValueError:continue
   if isinstance(row,dict) and row.get('id') and 'input_index' in row:observed.setdefault((row['id'],row['input_index']),row)
java=R/'engine_returns/Java_stub_stdout.txt'
if java.exists():
 for line in java.read_text().splitlines():
  fields=line.split('|')
  if len(fields)==3:observed[(fields[0],1)]={'status':fields[1],'reason':fields[2]}
account=[]
for c in cases:
 row=observed.get((c['id'],c['input_index']));status=row.get('status','FAIL') if row else ('INTERRUPTED_NO_RESULT' if (R/'fixtures'/(c['id']+'_'+str(c['input_index']))/'run_fixture').exists() else 'NOT_RUN')
 account.append(dict(c,status=status,observed=row))
put(R/'FINAL_INPUT_ACCOUNTING.json',account)
preserve=[]
for pin in json.loads((C/'CODE_MANIFEST.json').read_bytes())['files']:
 got=ident(C/pin['file']);assert got['sha256']==pin['sha256'] and got['bytes']==pin['bytes'];preserve.append(got)
put(R/'SOURCE_PRESERVATION_AFTER.json',preserve)
counts={v:sum(x['status']==v for x in account) for v in sorted({x['status'] for x in account})}
if summary['status']=='PASS':assert counts=={'PASS':77} and len({x['id'] for x in account})==62,'INCOMPLETE_CASE_SET'
seal_preservation=[];inode_cache={}
for pin in seal['files']:
 p=Path(pin['path']);st=p.stat();key=(st.st_dev,st.st_ino,st.st_size,st.st_mtime_ns)
 if key not in inode_cache:inode_cache[key]=ident(p)
 now=inode_cache[key];assert now['sha256']==pin['sha256'] and now['bytes']==pin['bytes'],'SEALED_INPUT_CHANGED'
 seal_preservation.append({'path':pin['path'],'bytes':pin['bytes'],'sha256':pin['sha256'],'unchanged':True})
put(R/'SEALED_INPUTS_PRESERVATION_AFTER.json',seal_preservation)
put(R/'CLOSEOUT.json',{'status':summary['status'],'counts':counts,'engine_summary':summary,'source_unchanged':True,'original_failure_preserved':ident(P/'FIRST_ERROR.json'),'preparation_s':seal['preparation_elapsed_s'],'preparation_limit_s':600,'overall_snapshot_before_package_s':elapsed(),'overall_limit_s':1660,'native_calls':0,'new_approval_runtime_token':False,'recipient':None,'large_fixture_CSVs':'Not repackaged. Exact paths/bytes/SHA and generation source are sealed in PRE_TEST_SEAL; local files preserved unchanged. Input contracts/specifications included.','timestamp_scope':'UTC wall snapshots; engine durations use monotonic clocks.'})
report=f'''B-min R2 제한 검증 재개 결과
판정: {summary['status']}
입력 상태: {counts}
준비 및 사전 봉인: {seal['preparation_elapsed_s']:.3f}/600초.
실제 엔진 반환은 ENGINE_EXECUTION_SUMMARY.json 및 engine_returns 원문을 따릅니다.
생산 5개 파일 SHA/크기는 불변입니다. 이전 CRLF 추출 실패 기록도 별도 원본으로 보존했습니다.
이번 시도는 첫 예상 밖 실패/시간 초과에서 후속 엔진을 중지하는 제어를 유지했습니다. 시도 중 자동 수정/재시험은 하지 않았습니다.
실제 consumer/entry와 고정 함수 바이트를 대상으로 했으며 native/table transport만 inert입니다. 성공한 원 reader 결과의 캐시는 파일 전체 SHA/시각/좌표/domain 결속으로만 재사용하도록 작성했습니다. 모사 PowerShell 판정으로 대체하지 않았습니다.
원시 대형 fixture CSV는 재포장하지 않았습니다. 생성기 및 모든 입력의 사전 크기/SHA/경로 봉인과 입력 계약을 포함하며 현지 파일은 보존합니다. 원시 CSV를 수신자가 재계산한 증거는 아닙니다.
통과 입력은 {counts.get('PASS',0)}/77입니다. 입력 시작 파일이 있으나 결과가 없는 입력은 INTERRUPTED_NO_RESULT, 시작 증거가 없는 입력은 NOT_RUN으로 구분합니다. 이전 시도 결과를 이번 실행 횟수에 합산하지 않습니다.
실제 COMSOL/모델 compile/load/solve/실제 gate/정책 변경 및 native 승인 생성은 0회입니다. 제한 Java helper 실행 여부는 엔진 반환에 따릅니다. 전체 Python/PowerShell 프로세스가 0회라는 주장은 하지 않습니다.
전체/정상 gate INCOMPLETE, native 150초 미승인 상태를 유지합니다.
'''
with (R/'RESULT_KO.txt').open('x',encoding='utf-8') as f:f.write(report)
payload={}
for p in R.rglob('*'):
 if not p.is_file():continue
 rel=p.relative_to(R)
 if rel.parts[0]=='fixtures':
  if p.name not in ('contract_fixture.json','INPUT_EXPECTATION.json'):continue
 payload[rel.as_posix()]=p
for p in (P/'received').rglob('*'):
 if p.is_file():payload['fixed_received/'+p.relative_to(P/'received').as_posix()]=p
for name in ('FIRST_ERROR.json','FIRST_ERROR_RAW.txt','RESULT_KO.txt','COMMIT_PACKAGE_COMPARISON.json','APPROVAL_SPEC_SECTION57.txt','prepare_inventory.py'):
 payload['prior_preseal_failure/'+name]=P/name
for dirname,names in [('bmin_r2_limited_validation_resume_20261005',('TIMEOUT_OBSERVATION.json','FINAL_PACKAGE_TOOL_RETURN.json','build_fixtures.py','python_cases.py')),('bmin_r2_limited_validation_retry2_20261005',('STOP_RECORD.json','FINAL_PACKAGE_TOOL_RETURN.json','HARNESS_COST_DIFF.patch','PROPOSED_NEXT_FIX.txt'))]:
 for name in names:payload['prior_attempts/'+dirname+'/'+name]=R.parent/dirname/name
manifest={'status':summary['status'],'files':[dict(file=n,bytes=p.stat().st_size,sha256=ident(p)['sha256']) for n,p in sorted(payload.items())]}
put(R/'PACKAGE_MANIFEST.json',manifest);payload['PACKAGE_MANIFEST.json']=R/'PACKAGE_MANIFEST.json'
z=R/'BMIN_R2_LIMITED_VALIDATION_RETRY3_RESULT_20261005.zip'
with zipfile.ZipFile(z,'x',zipfile.ZIP_DEFLATED,compresslevel=6) as f:
 for name,p in sorted(payload.items()):f.write(p,name)
with zipfile.ZipFile(z) as f:
 assert f.testzip() is None;assert set(f.namelist())==set(payload);assert len(f.namelist())==len(set(n.lower() for n in f.namelist()))
 for item in manifest['files']:
  raw=f.read(item['file']);assert len(raw)==item['bytes'] and hashlib.sha256(raw).hexdigest()==item['sha256']
receipt={'zip':ident(z),'status':summary['status'],'counts':counts,'manifest':ident(R/'PACKAGE_MANIFEST.json'),'payload':len(manifest['files']),'CRC':'PASS','packaging_elapsed_s':time.monotonic()-packbeg,'packaging_limit_s':300,'overall_snapshot_after_zip_before_receipt_s':elapsed(),'overall_limit_s':1660,'recipient':None}
put(R/'DELIVERY_RECEIPT.json',receipt)
print(json.dumps(dict(receipt,receipt=ident(R/'DELIVERY_RECEIPT.json'),final_snapshot_before_tool_return_s=elapsed()),ensure_ascii=False))

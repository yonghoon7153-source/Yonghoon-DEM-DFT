# 믹서 E0 자격 pilot 한 팔 — 1 단계: ibb 읽기 전용 메타 수집 블록 (초안 2026-11-10)

**초안 · ibb 실행 0 · 현장 결과 0 · 계산 · 제출 · 예약 해제 0 · 리포 쓰기 0 · 자격 판정 아님.**
1저자가 블록을 보고 대상 · 읽기 범위 · 시간 예산을 확인한 뒤에만 붙인다 (`docs/reviews/nonrint_first_link_20261109/mixer_ibb_fixed_qualification_plan.md` §4-1).
주소 · 포트 · 계정은 이 폴더의 어느 파일에도 없다 (블록 안은 `$HOME` · `$USER` 뿐).

## 0. 만든 파일

| 파일 | 뭐 |
|---|---|
| `meta_block.txt` | **1저자가 ibb 셸 (bash) 에 붙일 블록 하나** — 541 줄 · 33,445 바이트 · 스크립트 md5 `4e01c25f8f3a1cebc9daee51e2999cc4` · 최장 줄 207 바이트 |
| `src/meta_script.sh` | 블록 본문 원본 (537 줄) — 고칠 때는 이것을 고치고 `src/build_block.sh` 로 블록을 다시 만든다 |
| `src/build_block.sh` | 검사 (`bash -n` · 느낌표 · 탭 · CR · 줄 첫 `^` · 구분자 줄 · 끝 개행) + md5 게이트 블록 생성 (DEM1 `make_block.sh` 검사 그대로) |
| `read_meta_bundle.py` | 받은 tgz 를 빈 새 폴더에 안전하게 풀고 대조 · 요약 (`python3 -I`) — §5 |
| `test/run_tests.sh` · `test/check_run.py` | 컨테이너 시험 (PID 1 이 아니면 거부 — `unshare -pf --mount-proc` 안에서만) |
| `test/run_20261110T143614Z/` · `test/last_run.txt` | 마지막 시험 (170/170 PASS · `check_result.json`) — 앞 두 run 폴더는 고치기 전 판 |

## 1. (a) 계획의 E0 pilot 단계와 이 블록의 자리

근거: M-2 `mixer_qualification_plan_20261110.md` §2–3 (시험 트리) · 고정 자격 계획 빈틀 §4 · 영수증 계획 §4–5 · first8 README `Qualification release is scoped:` · 1저자 11-10 운영 결정 (E0 한 팔만 내부 반박 리뷰가 Codex GO 를 대신).

| 단계 | 하는 일 | 지금 |
|---|---|---|
| ① 메타 수집 | 1저자 확인 → 블록 붙임 → tgz 한 개 수령 (관측 메타만) | **이 블록 = 여기 (초안 · 실행 전)** |
| ② 기준 고정 | 받은 메타를 R0–R6 칸에 연결 (빈칸 = UNKNOWN / PROBE_NEEDED) · E0 pilot 결과 전 표 (목적 · 최소 입력 · 합격/거부 · STOP · 회수 · 확대 — M-2 §3) 를 한 판으로 | 미착수 |
| ③ 봉인 | source · 덱 · meta · STL · runner · job_start · 정책 · binary/MPI · 환경 digest 한 묶음 (first8 `Future GO must name`) · 운영 봉인 교체 = 1저자 별도 승인 (Q2) | 미착수 |
| ④ 내부 반박 리뷰 | 이 한 팔만 Codex GO 대신 (Codex verified 로 올리지 않음) | 미착수 |
| ⑤ 1저자 GO | `QUALIFICATION_PILOT_GO` = E0 한 팔 · 실제 100k 결과를 선행 사실로 요구하지 않음 · 그 뒤 `MAP_CASE_GO` 는 자격 수용 뒤 따로 | 미착수 |

## 2. (b) 블록이 모으는 칸 ↔ 계획 요구 칸

한 번 실행에 조회 47–60 개 (가짜 시험 t1 · t2) · 칸 139–160 줄 (서로 다른 칸 이름 103–114) · 해시 31–33 · 조상 경로 59–101 줄.  계획 칸 기준으로는 **8 묶음**을 채운다 (아래 표 왼쪽 8 줄 · 마지막 3 줄은 블록 몫이 아님).

| 계획 칸 (근거) | 블록이 모으는 것 (out/ 파일 · 칸) | 블록으로 못 모음 · 1저자 확인 |
|---|---|---|
| R0 대상 · 범위 (영수증 R0 · first8 preflight 1) | 수집 UTC 시작/끝 · 스크립트 md5/sha256 · `target_alias=ibb` · `uname -srm` · os-release · glibc · bash 판 · 도구 유무 31 종 · SLURM 할당 안인지 (호스트 · 계정 원문 = raw/private 에만) | 설치 실체 인증 · 운영자 · 허용 동작 · 반환 범위 · 승인 참조 |
| 한 설치의 링크 · OS/namespace (M-2 행 1 · 3 · R1) | 핵심 경로 (HOME · 바이너리 · mpirun · 믹서 폴더 · 체크아웃) 조상마다 종류 · 모드 · 소유 (self/root/other) · 그룹/타인 쓰기 · symlink 대상 (`walk.txt`) · HOME 실제 경로 관계 · FS 종류 · 마운트 옵션 (`findmnt_home`) | 링크 거부 자격 (실제 링크 fixture · 경합) · bind mount · 공유 FS 정책 |
| 권한 / 동시 변경 (M-2 행 2 · R2) | 모드 · 소유 등급 · ACL 이름 붙은 항목 수 (`getfacl -n` 원문은 private) · 해시 전후 stat 비교 (`CHANGED_DURING_HASH`) | 승인된 작성자 · 다른 writer · 불변 창 · 변경 통제 |
| binary / MPI (M-2 행 4 · R3 · preflight 2) | LIGGGHTS 후보 (`$LMP` · PATH · `~/LIGGGHTS-PUBLIC/src` · `/lustre/home/$USER/…` · 봉인의 `lmp_path` · `lmp_realpath` · `path_prefix`) → 실제 경로 · stat · sha256 · **09-28 영수증 바이너리 `ee2d7726…` 와 같은지** · `file` · 정적 배너 (실행 없이 grep) · ldd + 라이브러리마다 sha256 · `-h` 머리 (스위치) · mpirun 후보 → sha256 · `--version` · conda-meta 꾸러미 목록 · python3 판 · numpy · scipy | 빌드 출처 영수증 · MPI 런타임 · rank 동작 · 덤프 / 로그 형식 호환 (실제 pilot 의 몫) · job 안 재확인 (preflight 2) |
| 자원 / 회수 (M-2 행 5 · R5 · preflight 5) | `df -PB1` · `df -Pi` (HOME · 믹서 폴더) · `df -h` · `quota -s` · `lfs quota` (Lustre 일 때만) · 믹서 폴더 `du -sk` (맨 뒤) | dump / restart / 회수 예산 · STOP 문턱 · walltime (preflight 6) |
| wave / 예약 (M-2 행 7 · R4 · preflight 4) | `sinfo -V` · 파티션 · 요약 · `sacctmgr show qos` · 내 association (QOS · 한도 · Account 열은 일부러 뺌) · `squeue -u 나` (상태 · CPU 합 · qos 별) — 실패 · 없음을 빈 큐로 안 읽음 | 실제 예약 상태 · 해제 승인 · cpu-60 합산 판정 (시점 값) · D0.7 상태 |
| 비활성 → 운영 전환 (M-2 행 6 · R6 · preflight 3) | 체크아웃 HEAD · branch (실패 = detached) · 마지막 커밋 시각 · status (읽기) · 핵심 17 파일 sha256 · DEV OUT (`mixer_dev7_20260930` · `_v26`) · 런마다 덱 · STL · 러너 · jobid · 봉인 · job_start sha256 + 봉인 칸 (`lmp_sha256` · `git_head` · NP · flags · qos · policy) · E0 진단 기록 sha256 (schema · verdict 만) · `.stage_gate` JSON sha256 | 최종 운영 묶음 · 재봉인 승인 (Q2) |
| E0 pilot / first8 (M-2 행 8 · §3) | first8 후보 root (`$HOME/mixer_precal_first8_20261106`) 유무 · `cases/PRECAL_E0/in.mixer` 가 정적 해시 `8b588b24…` 와 같은지 | pilot 목적 · 합격/거부 문턱 · STOP · 회수 · 확대 (결과 전 등록) |
| 최종 증거 ZIP (M-2 행 9) | — (이 tgz 는 그것이 아님) | 1저자 Q4 대로 최종 발사 검토 때 |
| 실행 GO (M-2 행 10) | — | 1저자 GO |
| commands.txt PRE-FLIGHT | hostname (private) · `date -u` · `readlink` · 바이너리 · launcher sha256 · squeue · sacctmgr assoc · qos · df 둘 · quota | `sha256sum -c <승인된 입력 manifest>` — 승인 manifest 가 아직 없다 |

⚠ Codex 초안 (`mixer_ibb_metadata_command_draft.md`) 보다 **넓다**: 그 초안은 바이너리 실행 (`-h`) · SLURM 조회 · 링크 라이브러리 확인을 "별도 판단" 으로 뺐다.  이 블록은 지시서 후보대로 넣고 스위치 (`MIX_BIN_HELP=0` · `MIX_SLURM=0`) 로 끌 수 있게 했다 → §6 Q2 · Q3.

## 3. 블록 설계 (안전)

- **붙여넣기 꼴** — DEM1 `make_block.sh` 의 검사 그대로 + 한 가지 차이: `cat > ~/X.sh` 대신 본문을 **셸 변수**에 담는다 (`IFS= read -r -d '' … <<'MIX_E0_META_EOF'`).  마지막 줄이 md5 를 대조하고 맞을 때만 `bash -c` 로 돈다 · 다르면 디스크에 아무것도 안 쓴다 (`~/X.sh` 도 안 생김).
- **쓰는 곳** = `~/mixer_e0_meta_<UTC>/` 하나 (umask 077 · `raw/` `out/` `work/` · `<이름>.tgz` · `.tgz.sha256`).  `TMPDIR` = 그 폴더 `work/tmp` (here-string · 임시 파일 · MPI 세션 폴더도 거기) · `-h` 는 `work/` 에서 `-log none` 으로.
- **안 부르는 명령** — sbatch · scancel · scontrol · rm · mv · git 쓰기 (pull · checkout · fetch …) · conda · module load · sudo.  git = rev-parse · symbolic-ref · log · `status --no-optional-locks` (안 되는 옛 판이면 색인을 쓰지 않는 `diff-index` · `ls-files -o` 로 대신) 뿐.  python = `-I -B` (사용자 경로 무시 · .pyc 안 씀).
- **시간** — 외부 명령은 전부 `timeout` 안 (가능하면 `-k 5`) · 전체 예산 900 초 (`MIX_BUDGET`) · 넘으면 남은 조회 `SKIPPED_BUDGET` · 무거운 `du` 는 맨 뒤 · 묶음 만들기는 늘 한다.
- **상태 어휘** — OK · FAIL · MISSING · TIMEOUT · TRUNC (2 MB 상한) · SKIPPED_BUDGET · SKIPPED_SWITCH · SKIPPED_NOT_LUSTRE.  어느 것도 멈추지 않는다 (시작 관문 — timeout · HOME · UTC 시각 · 새 폴더 — 만 예외: 그때는 폴더도 안 만들고 끝).
- **가림** — `raw/` (원문 · ibb 에 남김) ↔ `out/` (가린 사본 · 가져옴): HOME · 실제 HOME · 호스트 · 계정 (낱말 경계) · `/home/<다른 사용자>` · IPv4 · uid/gid 숫자 · 빌드 사용자 (`compiled … by`) · 원격 FS 이름 (df · findmnt · quota).  `private_*` (신원 · HOME 목록 · ACL 원문) 은 out/ 에도 해시 목록에도 없다 · 끝에 out/ 에 남은 토큰 수를 세어 화면에 · tar 소유자 이름 없음 (uid/gid 0).  화면 출력도 가린 값 · 경로는 `~/` 로만.
- **맹검** — 덤프 (`post/`) · 로그 본문 · 숨은 금고 (`.e0_diag` · `.smoke_blind`) 는 열지 않는다 (개수만) · 로그는 첫 배너 줄 (앞 8 KB) 만 · E0 진단 기록은 schema · verdict 만.

## 4. 시험 (컨테이너 · `unshare -pf --mount-proc` 안 · 가짜 HOME · 가짜 명령) — 170/170 PASS

| 시험 | 넣은 것 | 결과 |
|---|---|---|
| **t1 (지시서)** | SLURM · LIGGGHTS · mpirun · module 없음 + 가짜 quota (멈춤) · 가짜 getfacl (실패) · 금지 명령 감시 · git 감시 | rc 0 · 31 초 · OK 33 · **MISSING 7** (sinfo · sacctmgr · squeue 6 + module) · **TIMEOUT 1** (quota 30 초) · **FAIL 5** (getfacl × 경로 5) · SKIPPED_NOT_LUSTRE 1 · LIGGGHTS · mpirun 후보 0 → 화면 "후보를 못 찾음" · SLURM "UNKNOWN (squeue rc 127 …)" |
| 만든 파일 (t1) | | 홈에 새 폴더 1 개뿐: `out/` (41 파일) · `raw/` (+ private 7) · `work/` (`tar_err.txt` · `tmp/`) · `.tgz` 21,927 바이트 · `.tgz.sha256` |
| 쓰기 범위 (t1–t5) | 실행 전후 스냅숏 (가짜 체크아웃 `.git` · 바깥 TMPDIR 포함) | 새 폴더 밖 추가 · 삭제 · 변경 0 · 금지 명령 호출 0 · git 부속 명령 = 읽기 7 종 안 |
| 가림 (t1–t5) | 가짜 계정 · HOME · 호스트 · 봉인 속 호스트 · 빌드 사용자 · 금고 · 덤프 문자열 | 화면 · out/ 에 0 · raw/ 에도 금고 · 덤프 내용 0 · 남은 토큰 0 · tgz 소유자 이름 없음 |
| t2 (보조 · 있는 경로) | 가짜 lmp_mpi · mpirun→orterun · sinfo · squeue · sacctmgr · getfacl · quota · module 함수 · first8 E0 덱 · 다른 사용자 PATH | rc 0 · OK 58 · FAIL 1 (가짜 lmp 가 스크립트라 ldd 실패 — 정상) · squeue 요약 jobs=2 · `-h` 가 log 를 안 남김 · `by <BUILD_USER>` · `/home/<OTHER_USER>` · first8 덱 different |
| t3 md5 게이트 | (a) 한 글자 (`1 단계` → `2 단계`) (b) CRLF (c) 대화형 `bash -i` (d) CRLF 를 DEM1 `sed -i 's/\r$//'` | (a) rc 0 · "아무것도 안 함" · 새 폴더 0 (b) 구분자 줄이 안 맞아 본문이 끝까지 안 닫힘 → 게이트 줄도 본문으로 삼켜짐 · rc 127 (`true\r`) · 새 폴더 0 (c) 정상 (d) 원본과 바이트 같음 |
| t4 스위치 · 옛 git | `MIX_BIN_HELP=0` · `MIX_SLURM=0` · `--no-optional-locks` 를 모르는 git | SKIPPED_SWITCH 둘 · status FAIL → diff-index · ls-files OK (색인 안 씀) |
| t5 예산 | `MIX_BUDGET=1` | SKIPPED_BUDGET 21 · 묶음은 만듦 · rc 0 |
| 읽기 도구 | t1 · t2 묶음 | rc 0 (빈 폴더 · SHA256SUMS · md5 · 화면 sha256 대조) |

시험 한계: 진짜 SLURM · LIGGGHTS · OpenMPI · Lustre 가 없어 그 경로는 **가짜로만** 돌았다 (실제 출력 형식 · MPI singleton 동작 미확인).  bash 4.2 · coreutils 8.22 류 (CentOS 7) 에서 안 돌렸다 — 쓴 문법은 그 판에 있는 것만 (문법 기준 · 실행 미확인).  bash 말고 dash · zsh 에 붙이면 md5 가 안 맞아 아무것도 안 할 것 — **추정** (시험은 bash 만).

## 5. (c) 받은 묶음을 본 세션이 읽는 법

1. 1저자가 화면의 sha256 과 tgz 하나를 준다 (경로 · 주소는 1저자).
2. tgz 는 scratch 의 새 폴더에, 풀 곳은 **다른 빈 새 폴더** (읽기 도구도 그 밖에):
   `python3 -I <scratch>/mixer_e0/read_meta_bundle.py <tgz> <빈 새 폴더> --expect-md5 4e01c25f8f3a1cebc9daee51e2999cc4 --expect-sha256 <화면 값>`
3. 도구가 하는 일: 묶음 sha256 → 멤버 검사 (절대경로 · `..` · 링크 · 장치 · out/ 밖 · 크기 · 소유자 이름 = 거부) → 정규 파일만 직접 씀 (extractall 안 씀) → `out/SHA256SUMS` 전수 → `meta_script.sh` md5 = 블록 md5 → 요약.  rc 0 = 구조 정상일 뿐 **자격 아님**.
4. 그 뒤 `out/fields.txt` · `probes.txt` · `hashes.txt` · `walk.txt` · `seal_extract.txt` 를 §2 칸에 연결 (② 기준 고정).  리포 반입은 가린 out/ 만 · 그래도 경로 문자열을 다시 본다 · raw/ 는 ibb 에.

## 6. (d) 다음 단계 (기준 고정 · 봉인) 에 필요한 결정 — 권고 한 줄씩

| Q | 결정 | 권고 |
|---|---|---|
| Q1 | 블록 실행 승인 범위 (ibb 로그인 셸 · §2 읽기 범위 · 900 초 · 조회당 2 MB) | 이 범위 그대로 승인 (Codex 초안보다 넓음을 알고) |
| Q2 | `lmp_mpi -h` 실행 (로그인 노드 MPI singleton · 30 초) | 켬 — 기능 목록 = binary/MPI 행 · log 없음 · 꺼도 정적 배너는 남는다 |
| Q3 | SLURM 읽기 조회 (sinfo · sacctmgr show · squeue -u 나) | 켬 — cpu-60 합산 근거 · 타인 자료 없음 · scontrol 안 씀 |
| Q4 | E0 pilot 기준 바이너리 | 09-28 영수증 `ee2d7726…` 과 같으면 그것 · 다르면 멈추고 재빌드 여부 1저자 |
| Q5 | E0 pilot 런 폴더 (first8 제안 root 를 새로 만들지) | 메타 (존재 · df · quota) 를 보고 정함 · 지금 만들지 않음 |
| Q6 | E0 walltime · 디스크 문턱 · STOP 수치 | 메타 + DEV E0 덤프 크기로 결과 전에 등록 (default 로 채우지 않음) |
| Q7 | 내부 반박 리뷰 범위 | 이 블록 + 기준 고정 표 + 봉인 묶음을 한 번에 (실행 전) |
| Q8 | 받은 out/ 리포 반입 | 가린 사본만 · 새 증거 폴더 · raw/ 반입 안 함 |

## 7. (e) 미확인 · 추정

- **미확인**: ibb 의 bash · coreutils · git · tar · python 판 (블록이 잰다) · 실제 `lmp_mpi -h` 출력 · 로그인 노드 MPI 실행 정책 · 실제 sinfo / sacctmgr / squeue / `lfs quota` 형식 · 체크아웃 `~/Yonghoon-DEM-DFT` · DEV OUT 두 폴더 · first8 root 의 현재 존재 (문서 기록 기준).
- **추정**: OpenMPI singleton 이 helper daemon 을 띄워도 앱이 끝나면 같이 끝난다 (판 의존) · bash 4.x 는 heredoc 을 `/tmp` 임시 파일로 잠깐 만들고 바로 지운다 (블록 바깥 쓰기는 아니지만 "폴더 밖 쓰기 0" 의 한정) · 대화형 셸의 기록 파일 (`~/.bash_history`) 은 셸이 쓴다 (블록 몫 아님).
- **가림 한계**: 낱말 경계 방식이라 계정 · 호스트가 다른 글자에 붙어 있으면 (예: 이름+숫자) 안 가려진다 → 남은 토큰 수로 화면 경고 · 그 밖의 식별자 (Slurm account 이름은 안 모음 · 다른 서버 이름) 는 IPv4 · 원격 FS · `/home/<다른 사용자>` 만 가린다 → 리포 반입 전에 다시 본다.
- **한정 (계획 문서 그대로)**: sha256 은 내용 신원이지 작동 · 호환 · 승인 인증이 아니다 · `-h` 는 기능 목록이지 물리 · 로그 호환 자격이 아니다 · `UNKNOWN` · `MISSING` 은 0 · 빈 큐 · 무제한 quota 가 아니다 · 이 묶음은 자격 수행 · 운영 승인 · GO 가 아니다 (전체 HOLD 그대로).

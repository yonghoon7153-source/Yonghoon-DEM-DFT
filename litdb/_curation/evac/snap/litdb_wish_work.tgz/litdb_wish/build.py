#!/usr/bin/env python3
"""wishlist_table.md · pick_list.md · queue3_rank.md 를 만든다 (읽기만 · 쓰기는 이 폴더).

python3 -I build.py <items.tsv> <S8.md> <queue.json> <out_dir>
손으로 정한 값은 아래 사전에 근거와 함께 적었다.
"""
import json
import os
import re
import sys
from collections import OrderedDict, Counter

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from keys import K  # noqa: E402
from rules import classify, letters, ORDER  # noqa: E402

items_p, s8_p, q_p, out = sys.argv[1:5]

# ── 상태 (카드 머리의 제목 · DOI · 권쪽을 사람이 대조해 확정) ──
CARD = {
    "choi2018_acsami": "choi2018_fibsem_3d_composite_cathode_microstructure_tpb_pore_decomposition",  # 카드 L67 · L82: ACS AMI 10 (2018) 23740–23747 · 저자 같음 (N-14)
    "meyer2018_jes": "meyer2018_calendering_process_model_active_material_mass_loading",  # DOI 10.1016/j.est.2018.05.018 · J. Energy Storage 18, 371–379 (N-61)
    "sonzogni2024_powtec": "sonzogni2024_dem_rotating_roll_calendering_binder_coated_nmc811",  # DOI 10.1016/j.powtec.2024.119891 (N-68)
    "sulsky1994_cmame": "sulsky1994_mpm_particle_method_history_dependent_materials",  # CMAME 118 (1994) 179–196 · 카드 L81 '같다' (N-40)
    "ge2022_powtec": "ge2022_xct_initial_structure_dem_calendering_nmc333",  # DOI 10.1016/j.powtec.2022.117366 (N-67)
}
QUEUE = {"bielefeld2022_jes": "N-89"}  # queue.json N-89 bib = JES 169 (2022) 020539 · status.tsv '차례 기다림'

# ── 판정 덮어쓰기 (자동 규칙의 'c 방법' 이 '원전' 낱말에 걸렸지만 왜 칸은 현상 · 자료의 출처) ──
CLASS_OVERRIDE = {
    "bi2020_science": ("C", ["배경: c 값"]),        # 왜: '사이클 슬립의 원전 (A10)' = 관측 · 값의 출처
    "marker2019_chemmater": ("C", ["배경: c 값"]),  # 왜: 'Fig. 1b 의 원전' = 격자 상수 자료
}

# ── 묶음에서 서지를 보일 줄 (가장 온전한 줄) ──
BIB_PICK = {"bielefeld2022_jes": 36, "perrenot2023_afm": 26, "lee2020_natenergy": 77, "song2023_apenergy": 63,
            "zhou1999_physicaa": 123, "iwashita1998_jem": 239, "sulsky1996_cmame": 116, "steffen2008_ijnme": 183,
            "wallstedt2008_jcp": 184, "nairn2006_wfs": 176}

# ── 고른 줄에 빠진 해 · 권을 같은 논문 다른 줄에서 (wishlist 글자 그대로) ──
BIB_ALSO = {"perrenot2023_afm": "[다른 줄 L27 (b46): Adv. Funct. Mater. 2023, 34, 2310739.]"}

# ── '참고 · 후보로 세지 않음' 줄 · 다른 줄의 확인 칸이 같은 논문을 다시 가리킨 곳 (X 셈에는 넣지 않음) ──
REF_EXTRA = {
    "heckel1961_aime": ["b107"], "schilcher2016_entech": ["b107"], "ott2013_ams": ["b107"],
    "daemi2019_mh": ["b105"], "gunther2020_entech": ["b102"], "martin2003_jmps": ["b68"],
    "cheng2017_jecs": ["b68"], "baranowski2016_acsami": ["b68"], "qu2012_aem": ["b47"],
    "lundkvist2024_powtec": ["b59", "b82", "b83"], "naik2023_ensm": ["b59"], "naik2024_aem": ["b59"],
    "sakuda2013_jcsj": ["b83"], "sun2017_jpcc": ["b83"], "schmidt2023_cmame": ["b83"],
    "yamamoto2020_jps": ["b83"], "bielefeld2022_jes": ["b83"], "zhang2022_powtec": ["b82", "b124"],
    "zhou1999_physicaa": ["b72", "b85"], "zhou2004_ces": ["b85"], "bardenhagen2002_jcp": ["b77", "b78"],
    "love2005_ijnme": ["b77", "b78"], "sulsky1995_cpc": ["b74", "b79", "b80", "b81"],
    "sulsky1996_cmame": ["b80"], "brackbill1988_jcp": ["b80"], "bardenhagen2000_pre": ["b80"],
    "bardenhagen1998_jap": ["b80"], "tran2007_report": ["b78 (IJNMF 2009 판 · [같은지 미확인])"], "froboese2017_matchar": ["b104"],
    "meyer2018_jes": ["b102", "b104"], "sulsky1994_cmame": ["b57", "b74", "b77", "b78", "b79", "b80"],
    "ge2022_powtec": ["b105"], "marker2019_chemmater": ["b63 (2019 표기)"],
}

# ── 배치 → 정독한 카드 (status.tsv 메모의 '정독 NN' = 배치 번호 · 카드 본문 표기 대조) ──
BCARD = {
    44: "kawaguchi2018", 47: "kalnaus2023", 52: "dang2019", 53: "hiramatsu1966", 54: "stallard2022_nmc811",
    56: "choi2018", 57: "sadeghirad2011", 58: "bardenhagen2004", 59: "benhadjali2026_fully", 62: "ai2011",
    63: "heenan2020", 67: "devasconcelos2019", 68: "yano2023", 69: "du2025", 70: "harthong2009",
    71: "brodu2015", 72: "chandratilleke2010", 73: "thorntonyin1991", 74: "nairn2015", 77: "steffen2008",
    78: "steffen2010", 79: "guilkey2003", 80: "cummins2002", 81: "sulsky1994", 82: "lyu2026",
    83: "benhadjali2026_oneway", 84: "chouchane2019", 85: "stewart2001", 86: "greenwood1966", 87: "lommen2014",
    88: "haervig2017", 89: "morenoatanasio2007", 90: "wensrich2012", 91: "clemmer2024", 101: "taghikhani2025",
    102: "lu2020_insitu", 103: "paulick2015_contact", 104: "meyer2017", 105: "song2025_insitu", 106: "onoda1990",
    107: "meyer2018", 108: "cottrino2013", 116: "hayashi2025", 121: "dixit2022", 124: "lyu2025",
}
HONBATCH = {43, 45, 46, 48, 50, 61, 64}

TRIG_NAME = {"R": "Rint ②", "U": "언로딩", "D": "D3 · 응집", "S": "순수 SE", "P": "단계 0–3", "X": "두 배치+"}


def bshort(b):
    if not b.startswith("batch_"):
        return "대피 11-12 머리 줄"
    n = int(b.split("_")[1])
    if n in BCARD:
        return f"b{n} ({BCARD[n]})"
    if n in HONBATCH:
        return f"b{n} (본)"
    return f"b{n}"


def doi_in(s):
    return [d.rstrip(".") for d in re.findall(r"10\.\d{4,9}/[^\s,;)\]]+", s)]


def strip_tail_notes(s):
    """끝의 괄호 메모 (한글 · 'L숫자' 가 든 괄호) 를 걷어 낸다.  메모 안 DOI · '서지 일부만' 표지는 살린다."""
    s = s.strip()
    keep_doi, partial = [], False
    for _ in range(6):
        s = s.rstrip(" .")
        if not s.endswith(")"):
            break
        depth, i = 0, len(s) - 1
        while i >= 0:
            if s[i] == ")":
                depth += 1
            elif s[i] == "(":
                depth -= 1
                if depth == 0:
                    break
            i -= 1
        if i < 0:
            break
        inner = s[i + 1:-1]
        if re.search(r"[가-힣]|\bL\d", inner):
            keep_doi += [d for d in doi_in(inner) if d not in s[:i]]
            if re.search(r"서지 일부|제목 없음|학술지 이름 누락|제목은 (이 논문 )?목록에 없음|제목 원문 목록에 없음", inner):
                partial = True
            s = s[:i].rstrip()
        else:
            break
    s = s.rstrip(" .") + "."
    if keep_doi:
        s += " DOI " + " · ".join(dict.fromkeys(keep_doi)) + "."
    if partial:
        s += " [서지 일부만]"
    return s


def clean_bib(b):
    b = re.sub(r"^\s*(\(\d+\)|\[\d+\]|\d+\.)\s+", "", b.strip())
    return strip_tail_notes(b)


def short_why(w, n=125):
    w = w.replace("`", "").replace("**", "").replace("*", "")
    w = re.split(r"\s*[·(]\s*카드 §|\s*·\s*§\d", w)[0]
    w = re.sub(r"\s+", " ", w).strip(" ·")
    if len(w) > n:
        cut = w[:n]
        j = max(cut.rfind(" · "), cut.rfind(" — "), cut.rfind(", "))
        w = (cut[:j] if j > n * 0.5 else cut).rstrip(" ·,—") + " …"
    return w


def md(s):
    return s.replace("|", "／").replace("\n", " ")


# ───────────────── wishlist ─────────────────
rows = [l.rstrip("\n").split("\t") for l in open(items_p, encoding="utf-8")][1:]
G = OrderedDict()
for idx, line, batch, bib, why, check in rows:
    idx = int(idx)
    key = K[idx][0]
    g = G.setdefault(key, {"items": [], "batches": []})
    g["items"].append({"idx": idx, "line": int(line), "batch": batch, "bib": bib, "why": why})
    if batch not in g["batches"]:
        g["batches"].append(batch)

papers = []  # 표 한 줄 = 한 논문
for key, g in G.items():
    whys = [it["why"] for it in g["items"]]
    lets = set()
    for w in whys:
        lets |= letters(w)
    nb = len(g["batches"])
    joined = " ‖ ".join(whys)
    cls, trig, _ = classify(joined, nb)
    # 질문 글자 합집합으로 다시 (묶음의 둘째 줄 글자 반영)
    if cls != "A":
        pass
    if "b" in lets and cls == "A" and "U" not in trig:
        trig.insert(0, "U")
    if "b" in lets and cls != "A":
        cls, trig = "A", ["U"]
    if "a" in lets and not re.search(r"SE 아님|목재|폭약", joined) and "S" not in trig:
        if cls != "A":
            cls, trig = "A", []
        trig.append("S")
    if cls == "A":
        trig = [t for t in ORDER if t in trig]
    if key in CLASS_OVERRIDE:
        cls, trig = CLASS_OVERRIDE[key]
    pick = BIB_PICK.get(key)
    it0 = next(it for it in g["items"] if it["idx"] == pick) if pick else max(
        g["items"], key=lambda it: len(it["bib"]) + (60 if doi_in(it["bib"]) else 0))
    bib = clean_bib(it0["bib"])
    if key in BIB_ALSO:
        bib += " " + BIB_ALSO[key]
    status = "PDF 필요"
    if key in CARD:
        status = f"카드 있음 · {CARD[key]}"
    elif key in QUEUE:
        status = f"후보 표 {QUEUE[key]} (PDF 받음 · 차례 기다림)"
    why_s = short_why(g["items"][0]["why"])
    if len(g["items"]) > 1:
        others = sorted({''.join(sorted(letters(it["why"]))) for it in g["items"][1:]} - {""})
        why_s += f" ‖ 같은 논문 다른 줄 {len(g['items']) - 1}"
    papers.append({"key": key, "items": g["items"], "batches": g["batches"], "cls": cls, "trig": trig,
                   "lets": lets, "bib": bib, "status": status, "why": why_s, "first": g["items"][0]["idx"]})

# item 56 = 원문 ref 3 한 줄에 두 편 → 둘로 나눈다
i56 = next(p for p in papers if p["key"] == "scott1960_nature")
i56["bib"] = "G. D. Scott, Nature (London) 188, 908 (1960). [서지 일부만 — 제목 없음 · 원문 ref 3 앞쪽]"
p69 = dict(i56)
p69 = {**i56, "key": "scott1969_bjapd",
       "bib": "G. D. Scott and D. M. Kilgor, Br. J. Appl. Phys. D 2, 863 (1969). [서지 일부만 — 제목 없음 · 원문 ref 3 뒤쪽 · 'Kilgor' 원문 철자]"}
papers.insert(papers.index(i56) + 1, p69)

for n, p in enumerate(papers, 1):
    p["W"] = f"W{n:03d}"


def prio_label(p):
    if p["cls"] == "A":
        return "A (" + " · ".join(TRIG_NAME[t] for t in p["trig"]) + ")"
    if p["cls"] == "B":
        return "B (" + " · ".join(p["trig"]) + ")"
    return "C (" + " · ".join(p["trig"]) + ")"


def batch_cell(p):
    if p.get("key") == "b42":
        return "b42 (pycompact2025 보강 · S8 '보탬' 절 · wishlist 밖)"
    s = " · ".join(bshort(b) for b in p["batches"])
    ex = REF_EXTRA.get(p["key"])
    if ex:
        s += " ／ 참고 줄: " + " · ".join(ex)
    return s


# ── b42 보탬 (S8 '보탬' 절의 [n] 다섯 줄 — wishlist 밖) ──
s8 = open(s8_p, encoding="utf-8").read().splitlines()
b42 = [l for l in s8 if l.startswith("- [n] ") and "[b42]" in l]
supp = []
for l in b42:
    body = l[6:]
    parts = body.split(" | ")
    bib, why, check = parts[0], parts[1], parts[2] if len(parts) > 2 else ""
    cls, trig, lets = classify(why, 1)
    supp.append({"bib": bib.strip(), "why": short_why(why), "cls": cls, "trig": trig, "status": "PDF 필요",
                 "batches": ["b42 (pycompact2025 보강)"], "key": "b42"})
for n, p in enumerate(supp, len(papers) + 1):
    p["W"] = f"W{n:03d}"

json.dump({"papers": [{k: v for k, v in p.items() if k not in ("items", "lets")} for p in papers],
           "supp": supp}, open(os.path.join(out, "_built.json"), "w", encoding="utf-8"), ensure_ascii=False, indent=1)

# ── 셈 ──
st_n = Counter("카드 있음" if p["status"].startswith("카드") else ("후보 표" if p["status"].startswith("후보") else "PDF 필요") for p in papers)
pr_n = Counter(p["cls"] for p in papers)
cross = Counter((p["cls"], "카드 있음" if p["status"].startswith("카드") else ("후보 표" if p["status"].startswith("후보") else "PDF 필요")) for p in papers)
grp_n = Counter(p["trig"][0] for p in papers if p["cls"] == "A")
print("고유", len(papers), "상태", dict(st_n), "우선", dict(pr_n))
print("교차", dict(cross))
print("A 무리(첫 트리거)", dict(grp_n))
print("보탬", [(p["W"], p["cls"], p["trig"]) for p in supp])


# ═════════════════ md 쓰기 (2026-11-16) ═════════════════
WL_PATH = sys.argv[5] if len(sys.argv) > 5 else os.path.join(out, "..", "wishlist_now.md")
TIP_PATH = sys.argv[6] if len(sys.argv) > 6 else os.path.join(out, "_papers_tip.txt")
WL = open(WL_PATH, encoding="utf-8").read().splitlines()
n_wl_lines = len(WL)
n_batch_sec = sum(1 for l in WL if re.match(r"^### batch_\d+", l))
n_item_n = sum(1 for l in WL if l.startswith("- [n]"))
n_item_e = sum(1 for l in WL if l.startswith("- [대피"))
n_ref = sum(1 for l in WL if l.startswith("- (참고"))
tip = [l.strip() for l in open(TIP_PATH, encoding="utf-8") if l.strip()]
n_cards = sum(1 for l in tip if l.endswith(".md") and not os.path.basename(l).startswith("_"))
GROUP_TITLE = {"R": "Rint ② — SE–SE · 입계 · 계면 저항 · 탄소 접합 · PTFE 막", "U": "[DEM 우선] Ⓐ 언로딩 — 탈압 · 되돌아옴 · 단계 6 · U3 · U4",
               "D": "[DEM 우선] Ⓒ 믹서 D3 · 응집 — SE 유동성 · 점착 · Bo", "S": "[DEM 우선 (수영)] 순수 SE 기준 — 질문 a · 진밀도",
               "P": "[DEM 우선 (수영)] 단계 0–3 · 단위 시험 U0 · U1 · U2 · U5 · U6", "X": "두 배치 이상이 요청 (위 다섯 무리에 안 걸린 것)"}


def st_kind(p):
    return "카드 있음" if p["status"].startswith("카드") else ("후보 표" if p["status"].startswith("후보") else "PDF 필요")


def a_group(p):
    return p["trig"][0]


def sort_key(p):
    rank = {"A": 0, "B": 1, "C": 2}[p["cls"]]
    g = ORDER.index(a_group(p)) if p["cls"] == "A" else 0
    return (rank, g, p["W"])


def row(p):
    return f"| {p['W']} | {md(prio_label(p))} | {md(p['status'])} | {md(p['bib'])} | {md(batch_cell(p))} | {md(p['why'])} |"


HEAD = "| W | 우선 | 상태 | 서지 (원문 그대로) | 요청한 배치 · 카드 | 왜 (짧게) |\n|---|---|---|---|---|---|"

# ───── wishlist_table.md ─────
cr = Counter((p["cls"], st_kind(p)) for p in papers)
o = []
o.append("# litdb 추가 필요 논문 — 고르기 표 (wishlist 정리)\n")
o.append("만든 날 2026-11-16 · 조수가 만든 문서 (계산 · 커밋 없음) · 지시서 `litdb_wish/BRIEF_wishlist_table.md` + 덧붙임 `BRIEF_addendum_20261116.md` (덧붙임이 앞선다).  "
         "고를 것만 보려면 `pick_list.md` (PDF 필요 · A) · 이미 받은 PDF 의 차례는 `queue3_rank.md` · 원문 오류 목록은 `fixes.md`.\n")
o.append("## 입력\n")
o.append("| 입력 | 판 | 셈 |\n|---|---|---|")
o.append(f"| wishlist | 정본 가지 `origin/claude/friendly-meitner-lldvar` 의 `litdb/_curation/wishlist.md` · 커밋 `e958f2571` (가지 끝 `1a676bc1b` 에서도 같은 파일) | {n_wl_lines} 줄 · 배치 절 {n_batch_sec} · 항목 줄 {n_item_n + n_item_e} (`- [n]` {n_item_n} + `- [대피 · 11-12]` {n_item_e}) · 세지 않은 줄 = `(참고 · 후보로 세지 않음)` {n_ref} · `(n 밖 …)` 1 · 괄호 문단 1 |")
o.append(f"| 정본 카드 | 가지 끝 `1a676bc1b` 의 `litdb/papers/` (ls-tree) | {n_cards} 장 (+ `_TEMPLATE.md`) |")
o.append("| 대기열 | 같은 가지의 `litdb/_curation/evac/tools/queue.json` · `status.tsv` · `S8_candidates.md` (사본 해시 = 가지 끝과 같음) | queue.json 113 칸 |")
o.append("| 배치 ↔ 카드 | `status.tsv` 메모의 '정독 NN' ↔ wishlist `batch_NN` (카드 본문 표기와 대조) | 본 세션 배치 43 · 45 · 46 · 48 · 50 · 61 · 64 는 대응 기록이 없어 '(본)' 으로만 적음 |\n")
o.append("## 세는 법\n")
o.append(f"- 한 줄 = 한 논문.  같은 논문 = DOI 가 같거나, 제1 저자 성 + 해 + 학술지 · 권 · 쪽이 같을 때만.  성 + 해만 같으면 따로 둔다 (예: Perrenot 2023 ACS Energy Lett. ↔ Adv. Funct. Mater. = 둘).")
o.append(f"- 항목 {n_item_n + n_item_e} 줄 → 고유 {len(papers)} 편: 같은 논문을 둘 이상 적은 무리 10 (줄 22 → 10 편) · 한 줄에 두 편이 든 줄 1 (L97 원문 ref 3 = Scott 1960 + Scott & Kilgor 1969 → 둘로 나눔).  같은지 애매한 쌍 1 = Tran 2007 보고서 (L285) ↔ L305 참고 줄의 IJNMF 2009 판 — 참고 줄이라 셈에 영향 없음 · 칸에 [같은지 미확인] (`fixes.md` 2 절).")
o.append("- 상태 (제목 · DOI 로만):  **카드 있음** = 정본 카드 머리 (제목 · DOI · 학술지 · 권쪽) 를 열어 같은 논문 확인 · **후보 표 N-xx** = queue.json 의 bib 또는 pdf 이름이 같은 논문 · 나머지 = **PDF 필요**.  "
         "성 + 해만 맞는 카드 (sakuda2013 = Sci Rep · kim2023 둘 = ENSM · AFM · zhang2023 = Joule · lu2020 = Joule · wang2018 = JPS · steffen2008 = CMES · bardenhagen2000 = CMAME · heenan2020 = AEM · brodu2015 = PRE · he2018 · stewart2001 · sangros2019 · silbert2001 = PRE 64 051302 …) 는 머리를 열어 다른 논문임을 보고 PDF 필요로 두었다.")
o.append("- '요청한 배치 · 카드' = 그 줄이 나온 wishlist 배치 절 (괄호 = 그 배치가 정독한 카드) · '참고 줄' = 같은 논문을 `(참고 · 후보로 세지 않음)` 줄이 다시 가리킨 배치 (두 배치 셈에 넣지 않음).")
o.append("- 서지 = wishlist 줄 그대로 (앞 번호 · 끝의 한글 괄호 메모만 뺌 · 메모 안 DOI 는 살림 · 메모가 '서지 일부만 · 제목 없음' 이면 `[서지 일부만]`).  같은 논문 여러 줄이면 가장 온전한 줄.  빠진 제목 · DOI 는 채우지 않았다.\n")
o.append("## 우선 규칙 (적힌 그대로 적용 · 근거 = 그 논문 줄들의 '왜' 칸 글자뿐)\n")
o.append("판정 순서: ① A 조건 하나라도 → **A**  ② 아니면 왜 칸에 '흐름 밖' → **C**  ③ 아니면 방법 원전 → **B**  ④ 나머지 → **C** (배경).  같은 논문 여러 줄은 왜 칸을 합쳐 본다.\n")
o.append("| A 표지 (덧붙임 트랙 순서) | 왜 칸에서 찾은 것 |\n|---|---|")
o.append("| Rint ② | Rint · SE–SE 계면 · 입계 · 계면 저항 · σ₀ · 탄소 접합 · SDCP · PTFE 막 개구 · 절연 · 피복 |")
o.append("| 언로딩 ([DEM 우선] Ⓐ) | 질문 b · 단계 6 (5 · 6 · 5–6) · 단위 시험 U3 · U4 · 조건 R4 · 탈압 · 되돌아옴 |")
o.append("| D3 · 응집 ([DEM 우선] Ⓒ) | D3 · 유동성 · Bo · SE–SE 접착 · 점착 · (믹서 · 믹싱 · 혼합 · 이종기술 맥락 ∧ 응집 · 점착 · 접착) |")
o.append("| 순수 SE ([DEM 우선 (수영)]) | 질문 a (왜 칸이 재료를 'SE 아님' · 목재 · 폭약으로 적은 줄은 뺌) · 순수 SE · 진밀도 · 1.64 |")
o.append("| 단계 0–3 ([DEM 우선 (수영)]) | 단계 0 · 1 · 2 · 3 · 단위 시험 U0 · U1 · U2 · U5 · U6 (READING_BRIEF 3 절: 단위 시험 = 단계 2 의 일) |")
o.append("| 두 배치+ | wishlist 항목 줄을 낸 배치가 둘 이상 |\n")
o.append("- **B** = 질문 e (접촉 법칙 대안) · f (MPM 접촉 · 해상도 · 오차) · g (2D → 3D) · h (DEM → FE · MPM 넘김) · k (DEM 한계) · l (소성이 왜 어려운가) · 후보 이름 (D0 · A′-0 · A · A′ · B · C · C′ · M0) · 질문 c 가운데 왜 칸이 방법 · 식 · 장치 · 정의 · 측정법의 원전이라 적은 것.  B 칸 괄호 = 걸린 글자.")
o.append("- **C** = '흐름 밖' 표지 · 그 밖 (질문 c 값 출처 · i · j · m 만).")
o.append("- 손으로 바꾼 것 2: W096 Bi 2020 Science · W100 Märker Chem. Mater. — 규칙의 'c 원전' 낱말에 걸렸지만 왜 칸이 관측 · 자료값의 출처 → C (배경: c 값).")
o.append("- ⚠ 덧붙임의 Ⓑ (DEM → MPM · FAM · 소성 · 입자 형태 · 피복) 은 지시서 A 목록에 없어 f · h 로 B 가 됐다 (끝 '규칙 경계' 절).\n")
o.append("## 셈\n")
o.append("| 상태 \\ 우선 | A | B | C | 합 |\n|---|---|---|---|---|")
for s in ["카드 있음", "후보 표", "PDF 필요"]:
    a, b, c = cr[("A", s)], cr[("B", s)], cr[("C", s)]
    o.append(f"| {s} | {a} | {b} | {c} | {a + b + c} |")
o.append(f"| 합 | {pr_n['A']} | {pr_n['B']} | {pr_n['C']} | {len(papers)} |\n")
ga = Counter(a_group(p) for p in papers if p["cls"] == "A")
o.append("A 무리 (첫 표지 기준): " + " · ".join(f"{TRIG_NAME[g]} {ga[g]}" for g in ORDER) + ".  ")
sa = Counter(p["cls"] for p in supp)
o.append(f"보탬 (wishlist 밖 · S8 '보탬' 절 b42 의 `[n]` {len(supp)} 줄 · W{len(papers) + 1:03d}–W{len(papers) + len(supp):03d}) = 전부 PDF 필요 · A {sa['A']} · B {sa['B']} · C {sa['C']} — 표 끝에 따로.\n")

o.append("## 표 — A (트랙 순서 · 같은 무리 안 W 순)\n")
pa = sorted([p for p in papers if p["cls"] == "A"], key=sort_key)
for g in ORDER:
    sub = [p for p in pa if a_group(p) == g]
    if not sub:
        continue
    o.append(f"### A · {GROUP_TITLE[g]} ({len(sub)})\n")
    o.append(HEAD)
    o += [row(p) for p in sub]
    o.append("")
for cls, title in (("B", "B — 방법 원전 (W 순)"), ("C", "C — 흐름 밖 · 배경 (W 순)")):
    sub = sorted([p for p in papers if p["cls"] == cls], key=sort_key)
    o.append(f"## 표 — {title} ({len(sub)})\n")
    o.append(HEAD)
    o += [row(p) for p in sub]
    o.append("")
o.append(f"## 보탬 — wishlist 밖 (S8 '보탬' 절 · b42 pycompact2025 보강 · {len(supp)})\n")
o.append(HEAD)
o += [row(p) for p in supp]
o.append("")

# 규칙 경계
fo_A = []
for p in papers:
    if p["cls"] == "A" and any("흐름 밖" in it["why"] for it in p["items"]):
        fo_A.append(p["W"])
bfh = [p["W"] for p in papers if p["cls"] == "B" and any(t in ("f", "h") for t in p["trig"])]
o.append("## 규칙 경계 — 1저자가 줄마다 바꿀 수 있는 곳\n")
o.append(f"- A 인데 왜 칸이 스스로 '흐름 밖' 이라 적은 것 {len(fo_A)} 편 ({' · '.join(fo_A)}) — 규칙 순서 (A 조건 먼저) 그대로 A.  "
         "가운데 W165 Nairn 2013 은 '흐름 밖 (계면 저항)' 낱말로 Rint ② 에 걸렸지만 내용은 MPM 계면 견인 (역학) 이다 — 내려도 된다.")
o.append("- 약한 A: W149 Martin 2004 (질문 b · R4 이지만 왜 칸이 '[제목 근거 · 미열람]') · W108 Bardenhagen 2002 (MPM 에너지 오차 → '단계 6 의 수치 소산 점검').")
o.append("- B · C 인데 A 트랙에 닿을 수 있는 것: W206 · W207 Holm 1929 · 1958 (협착 식 원전 · k → B · Rint ② 접촉 저항 식 계열) · "
         "W132 · W133 Kendall 1987 · Rumpf 1974 (응집체 탄성 · 인장 강도 · k → B) · W216 · W217 Gu 2016 · Kobayashi 2013 (응집력 축척 · 응집체 경고 · k → B) · "
         "W160 Savkoor 1977 · W220 Parteli 2014 (접착 · e → B) · W157 Kristensen 1973 ('흐름 밖 (믹서)' → C · 믹서 무작위 기준) · W048 Ott 2013 ('흐름 밖 (접촉망 수송)' → C) — "
         "믹서 쪽은 지시서 A 가 'D3 · 응집' 만이라 응집 · 접착 낱말이 믹서 맥락과 함께 있을 때만 A 로 셌다.")
o.append(f"- Ⓑ (DEM → MPM) 을 A 로 올리면 대상이 되는 B (질문 f · h) {len(bfh)} 편: {' · '.join(bfh)}.\n")
open(os.path.join(out, "wishlist_table.md"), "w", encoding="utf-8").write("\n".join(o) + "\n")

# ───── 대기열 3 순위 ─────
Qj = json.load(open(q_p, encoding="utf-8"))


def s8_rows(head, stop):
    st = next(i for i, l in enumerate(s8) if l.startswith(head))
    en = next(i for i, l in enumerate(s8) if i > st and l.startswith(stop))
    r = {}
    for l in s8[st:en]:
        if l.startswith("| N-"):
            c = [x.strip() for x in l.strip().strip("|").split(" | ")]
            r[c[0]] = c
    return r


S8_3 = s8_rows("## 3. 우선순위 3", "## 4.")
S8_42 = s8_rows("### 4-2", "### 4-3")


def qnum(k):
    m = re.match(r"N-(\d+)(?:-(\d+))?$", k)
    return (int(m.group(1)), int(m.group(2) or 0)) if m else (10 ** 6, 0)


QKEYS = sorted([k for k in Qj if k.startswith("N-") and (76 <= qnum(k)[0] <= 129 or qnum(k)[0] in (148, 149))], key=qnum)
# 사람이 쓴 queue.json bib (메모만 뺀 줄임 — 글자는 queue.json 그대로)
QBIB_HUMAN = {
    "N-112-1": 'Hongming Li, J. J. McCarthy, "Controlling Cohesive Particle Mixing and Segregation", Physical Review Letters 90, 184301 (2003), DOI 10.1103/PhysRevLett.90.184301.',
    "N-112-2": 'Hongming Li, J. J. McCarthy, "Phase diagrams for cohesive particle mixing and segregation", Physical Review E 71, 021305 (2005), DOI 10.1103/PhysRevE.71.021305.',
    "N-114": "① W. J. Thiel, Felix Lai, J. A. Hersey, \"Comments on 'Suggestions on the Nomenclature of Powder Mixtures'\" (Letter to the Editor), Powder Technology 28 (1981) 117–118 (PII 0032-5910(81)87021-0) ＋ "
             "② H. Egermann, \"Suggestions on the Nomenclature of Powder Mixtures\" (Short Communication), Powder Technology 26 (1980) 235–237 (PII 0032-5910(80)85069-8) — ② = 114-2 파일 · 후보 밖 (queue.json 표기).",
    "N-127": 'D. Hou, J. Han, C. Geng, Z. Xu, M. M. AlMarzooqi, J. Zhang, Z. Yang, J. Min, X. Xiao, O. Borkiewicz, K. Wiaderek, Y. Liu, K. Zhao, F. Lin, "Surface coating by mechanofusion modulates bulk charging pathways and battery performance of Ni-rich layered cathodes", PNAS 2022, Vol. 119, No. 49, e2212802119, https://doi.org/10.1073/pnas.2212802119.',
    "N-128": 'Chuanlai Liu, Franz Roters, Dierk Raabe, "Role of grain-level chemo-mechanics in composite cathode degradation of solid-state lithium batteries", Nature Communications (2024) 15:7970, https://doi.org/10.1038/s41467-024-52123-w.',
    "N-129": 'Yoo Jung Choi, Sungbin Jang, Hongjun Chang, Youjin Kim, Suji Kim, …, "A black zirconia cathode coating layer enabling facile charge diffusion and surface lattice stabilization for lithium-ion batteries", J. Mater. Chem. A, 2024, 12, 30667–30675, DOI 10.1039/D4TA05179C. [공저자 일부만 — queue.json \'공저자 전부는 첫 쪽에서\']',
    "N-148": 'Artur Tron, Raad Hamid, Ningxin Zhang, Alexander Beutl, "Rational Optimization of Cathode Composites for Sulfide-Based All-Solid-State Batteries" 의 Supplementary Information — 본문 = Nanomaterials 2023, 13, 327 · DOI 10.3390/nano13020327 (기존 카드 tron2023_rational_cathode_composite_optimization_lpscl 보강).',
    "N-149": 'Thorben Böger, Tim Bernges, Yuheng Li, Pieremanuele Canepa, Wolfgang G. Zeier, "Thermal Conductivities of Lithium-Ion-Conducting Solid Electrolytes", ACS Appl. Energy Mater. 2023, 6, 10704–10712, https://doi.org/10.1021/acsaem.3c01977 (기존 카드 boger2023_thermal_conductivity_argyrodite_lgps 에 본문 보강).',
}
Q_OVERRIDE = {"N-107": ("C", ["흐름 밖 · 손으로 바꿈"])}
Q_FROM_WISH = {v: k for k, v in QUEUE.items()}  # N-89 → bielefeld2022_jes


def drop_notes(s):
    """괄호 메모 (한글 · 'L숫자' 가 든 균형 괄호) 를 어디 있든 뺀다."""
    for _ in range(12):
        hit = None
        depth = 0
        for i, ch in enumerate(s):
            if ch == "(":
                if depth == 0:
                    st = i
                depth += 1
            elif ch == ")" and depth:
                depth -= 1
                if depth == 0:
                    inner = s[st + 1:i]
                    if re.search(r"[가-힣]|\bL\d", inner):
                        hit = (st, i)
                        break
        if not hit:
            break
        s = (s[:hit[0]].rstrip() + " " + s[hit[1] + 1:].lstrip()).strip()
    s = re.sub(r"\s+([,.;:])", r"\1", s)
    s = re.sub(r"\s{2,}", " ", s).strip(" ·")
    return s.rstrip(".") + "."


def pdf_title(name):
    t = re.sub(r"^[0-9a-f]{8}-[0-9\-]+\._", "", name)
    t = re.sub(r"\.pdf$", "", t)
    return t.replace("_", " ").strip()


qrows = []
for k in QKEYS:
    v = Qj[k]
    if k in S8_42:
        c = S8_42[k]
        s8bib, why, s8state, flow = c[1], c[3], "", ("흐름 밖" in c[3])
    else:
        sk = "N-112" if k.startswith("N-112-") else k
        c = S8_3[sk]
        s8bib, why, s8state, flow = c[1], c[2], c[4], True
    nb = len(G[Q_FROM_WISH[k]]["batches"]) if k in Q_FROM_WISH else 1
    cls, trig, _ = classify(why, nb, flow_out_override=flow)
    if cls == "A":
        trig = [t for t in ORDER if t in trig]
    if k in Q_OVERRIDE:
        cls, trig = Q_OVERRIDE[k]
    qb = v.get("bib", "")
    if k in QBIB_HUMAN:
        bib = QBIB_HUMAN[k]
    else:
        bib = drop_notes(s8bib)
        m = re.search(r"DOI: (10\.\S+?)(?: ·|$)", qb)
        if m and m.group(1).lower() not in bib.lower():
            bib += f" DOI {m.group(1)}."
        if s8state.startswith("일부만"):
            bib += f" [서지 일부만 — S8 '{s8state}'] [PDF 파일 이름: {pdf_title(v.get('pdf', ''))}]"
    wx = " (wishlist " + " · ".join(bshort(b) for b in G[Q_FROM_WISH[k]]["batches"]) + " 도 요청)" if k in Q_FROM_WISH else ""
    qrows.append({"N": k, "cls": cls, "trig": trig, "bib": bib, "why": short_why(why, 170) + wx})


def qprio(r):
    if r["cls"] == "A":
        return "A (" + " · ".join(TRIG_NAME[t] for t in r["trig"]) + ")"
    return f"{r['cls']} (" + " · ".join(r["trig"]) + ")"


qc = Counter(r["cls"] for r in qrows)
q = []
q.append("# 대기열 3 순위 (N-76 – N-129) + 보강 N-148 · N-149 — 차례 표\n")
q.append("만든 날 2026-11-16 · 조수가 만든 문서 (계산 · 커밋 없음) · 이 칸들은 전부 PDF 를 이미 받아 `status.tsv` '차례 기다림' 이다 — 이 표는 읽을 차례만 정한다.\n")
q.append("## 만든 법\n")
q.append(f"- 범위 = queue.json 의 {len(qrows)} 칸: N-76 … N-111 (36) · N-112-1 · N-112-2 (S8 의 N-112 한 행 = 두 편) · N-113 · N-114 (Thiel 1981 + Egermann 1980 두 파일 · 한 칸) · N-115 … N-129 (15) · N-148 · N-149 (S8 4-2 절 '같은 카드 보강').")
q.append("- 서지: queue.json bib 이 사람이 쓴 서지인 8 칸 (N-112-1 · N-112-2 · N-114 · N-127 · N-128 · N-129 · N-148 · N-149) 은 그 글자를 줄임 (한글 메모만 뺌).  "
         f"queue.json bib 이 첫 쪽 자동 추출 (PDF 문서 정보 · 제목 · DOI 뿐) 인 {len(qrows) - 8} 칸은 S8 서지 칸 (출처 괄호만 뺌) + queue.json 의 DOI.  "
         "S8 서지 상태가 '일부만' 이면 `[서지 일부만]` 과 queue.json 의 PDF 파일 이름을 붙였다 (제목을 짓지 않음).")
q.append("- 왜 = S8 왜 칸 그대로 (길면 … 로 자름 · N-148 · N-149 는 4-2 절 왜 칸).")
q.append("- 우선 = `wishlist_table.md` 와 같은 규칙.  S8 3 절은 전부 '흐름 밖' 이라 A 조건이 없으면 C (B 는 나올 수 없다).  "
         "N-89 = wishlist 두 배치 (b46 · b101) 가 같은 논문을 요청 → A (두 배치+).  손으로 바꾼 것 1: N-107 (왜 칸의 '탈압' 은 '가압 · 탈압과 거리가 있어 다섯에 넣지 않았다' 는 부정 → C).  "
         "경계: N-101 은 '열화 (단계 6 과 간접)' 라 규칙대로 A (언로딩) 지만 '간접' 이라 적혀 있다.\n")
q.append("## 셈\n")
q.append(f"A {qc['A']} · B {qc['B']} · C {qc['C']} (합 {len(qrows)}).  A 무리: " + " · ".join(
    f"{TRIG_NAME[g]} {sum(1 for r in qrows if r['cls'] == 'A' and r['trig'][0] == g)}" for g in ORDER if any(r['cls'] == 'A' and r['trig'][0] == g for r in qrows)) + ".\n")
q.append("## 표 (A → C · A 는 트랙 순서 · 같은 무리 안 N 순)\n")
q.append("| N | 우선 | 서지 | 왜 (S8 왜 칸) |\n|---|---|---|---|")
qs = sorted(qrows, key=lambda r: ({"A": 0, "B": 1, "C": 2}[r["cls"]], ORDER.index(r["trig"][0]) if r["cls"] == "A" else 0, qnum(r["N"])))
for r in qs:
    q.append(f"| {r['N']} | {md(qprio(r))} | {md(r['bib'])} | {md(r['why'])} |")
q.append("")
q.append("## 규칙 경계 — C 가운데 트랙에 닿을 수 있는 것\n")
mixC = [r["N"] for r in sorted(qrows, key=lambda r: qnum(r["N"])) if r["cls"] == "C" and re.search(r"믹싱|믹서|혼합|코팅 활물질", r["why"])]
q.append(f"- 믹서 · 혼합 · 코팅 활물질이지만 응집 · 점착 · Bo · D3 낱말이 없어 C 인 것 {len(mixC)} 칸: " + " · ".join(mixC) + " — 덧붙임 Ⓒ '코팅 활물질 믹싱' 전체를 A 로 볼지는 1저자 (지시서 A 목록은 '믹서 D3' 만).")
q.append("- N-85 (건식막 · PTFE 함량 ↔ 이온 전도) — PTFE 지만 '막 개구 · 절연 · 피복' 이 아니라 C · N-106 ('탄소–SE 계면이 반응성' 의 원전) — '탄소 접합' 이 아니라 분해 계면이라 C · N-126 (VGCF 강성 입력 출처) — C.\n")
open(os.path.join(out, "queue3_rank.md"), "w", encoding="utf-8").write("\n".join(q) + "\n")

# ───── pick_list.md ─────
pick = sorted([p for p in papers + supp if p["cls"] == "A" and p["status"] == "PDF 필요"], key=sort_key)
nA_w = sum(1 for p in papers if p["cls"] == "A" and p["status"] == "PDF 필요")
nB_w = sum(1 for p in papers if p["cls"] == "B" and p["status"] == "PDF 필요")
nA_s = sum(1 for p in supp if p["cls"] == "A")
nB_s = sum(1 for p in supp if p["cls"] == "B")
pl = []
pl.append(f"PDF 필요 A {nA_w + nA_s} 편 · B {nB_w + nB_s} 편 / 대기열 A {qc['A']} 편\n")
pl.append("# 받을 PDF — A 전부 (A 가 10 을 넘어 B 는 싣지 않음)\n")
pl.append(f"만든 날 2026-11-16 · A = wishlist {nA_w} + 보탬 (b42) {nA_s} · B = wishlist {nB_w} + 보탬 {nB_s} (B 목록은 `wishlist_table.md`) · "
          f"대기열 A {qc['A']} 편은 PDF 를 이미 받았다 (`queue3_rank.md`).  한 줄 = W 번호 · 서지 — 왜 · 트랙 순서 = 덧붙임 11-16.\n")
for g in ORDER:
    sub = [p for p in pick if a_group(p) == g]
    if not sub:
        continue
    pl.append(f"## {GROUP_TITLE[g]} ({len(sub)})\n")
    for p in sub:
        extra = f" [다른 표지: {' · '.join(TRIG_NAME[t] for t in p['trig'][1:])}]" if len(p["trig"]) > 1 else ""
        pl.append(f"- {p['W']} · {p['bib']} — {p['why']}{extra}")
    pl.append("")
open(os.path.join(out, "pick_list.md"), "w", encoding="utf-8").write("\n".join(pl) + "\n")
print("md:", "wishlist_table.md", "queue3_rank.md", "pick_list.md", "· pick", len(pick), "· 대기열", dict(qc))

"""
DEM Analysis Web Application
- Single mode: Upload one case → full analysis pipeline → figures + MD report
- Group mode: Upload multiple cases → comparison plots + summary report
"""
import os
import sys
import re
import csv
import json
import uuid
import shutil
import subprocess
import glob as globmod
import threading
from datetime import datetime
from pathlib import Path

# Network solver serialization → pipeline_service.network_lock() (파일 lock).
# ⚠ 옛 `_network_solver_lock = threading.Semaphore(1)` 은 제거했다 (코드리뷰 F-03):
#   프로세스 로컬이라 Gunicorn workers=2 에서 서로를 모르는데다, **정상 경로의 solver
#   호출은 애초에 그 lock 밖**이었다 (run_pipeline 안에서 돌았고, wrapper 의 lock 블록은
#   solver 가 파일을 못 썼을 때만 도달하는 사실상 죽은 코드였다).  남겨두면 "직렬화되고
#   있다"는 잘못된 안심을 준다.  이제 세 호출부(run_pipeline · retry · batch)가 모두
#   같은 파일 lock 을 잡는다.  ⚠ 파일 lock 은 **한 호스트 안에서만** 유효하다 —
#   다중 호스트로 가면 Redis/DB lease 가 필요하다.

try:
    from . import pipeline_service as _ps          # package import
except ImportError:                                # gunicorn 은 webapp/ 안에서 app:app 로 뜬다
    import pipeline_service as _ps

# ★ PD-01 (Codex): 이 import 가 **빠진 채로 푸시됐다** — _inject_input_params 가
#   _press_units 를 호출해 NameError 였고, 내 회귀는 `import app` 만 해서 함수 본문을
#   타지 않아 못 잡았다.  아래 R-PD1 회귀가 실제로 그 함수를 호출한다.
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'scripts'))
import press_units as _press_units                 # noqa: E402  (압력 단위 규약 — F-11)
import type_map_resolve as _type_map_resolve      # noqa: E402  (atom-type ↔ 상 매핑 — 덱이 선언한 것을 읽는다)

#: network_conductivity.json → full_metrics.json 으로 옮기는 σ 키들.
#: ⚠ 이 목록은 원래 analyze() **지역 변수**였는데 run_pipeline 이 그것을 참조해
#:   (2912/3020/3030) 매 실행마다 NameError 로 죽고 있었다 — bimodal 쪽은
#:   `except Exception: pass` 가 통째로 삼켜 무증상이었다.  즉 run_pipeline 의 머지는
#:   한 번도 동작한 적이 없고 σ 는 오직 wrapper 의 Step 5 로만 들어갔다.  모듈 전역으로
#:   올려 양쪽이 같은 목록을 쓰게 한다.
# ★ RC6-Q7: 정의는 pipeline_service 한 곳에 있다 (사본을 두면 스캐너와 drift 한다).
_NET_MERGE_KEYS = list(_ps.NET_MERGE_KEYS)

# Load .env file if exists (for local development)
_env_path = os.path.join(os.path.dirname(__file__), '.env')
if os.path.exists(_env_path):
    with open(_env_path) as _f:
        for _line in _f:
            _line = _line.strip()
            if _line and not _line.startswith('#') and '=' in _line:
                _k, _v = _line.split('=', 1)
                os.environ.setdefault(_k.strip(), _v.strip())

from flask import (
    Flask, render_template, request, jsonify, send_from_directory,
    redirect, url_for, send_file, make_response, abort, Response,
)
import storage_sync
import predictor_engine
import structure_predictor
import mpm_lab_register           # MPM payload 등록 훅과 meta 스키마 공유 (single source of truth)
#  v3 (2026-09-09): 상태 문장을 손으로 적지 않고 **원장에서 렌더**한다.
#  전수 감사 실측 — 웹앱 8 영역 전부에서 기계는 최신인데 라벨이 3~15 개월 뒤였고,
#  `webapp/` 어디에서도 claims.json 을 읽은 적이 없었다 (문자열로 언급만).
import ledger_view

app = Flask(__name__)
app.config['MAX_CONTENT_LENGTH'] = 2 * 1024 * 1024 * 1024  # 2GB max
# Disable browser caching of static assets — viewer3d.js evolves often and
# stale caches were masking server-side fixes (e.g. fracture classifier
# update reaching server but not the rendered view).
app.config['SEND_FILE_MAX_AGE_DEFAULT'] = 0

# Server start time — exposed to templates as a cache-busting version stamp
# so `?v={{ asset_version }}` on script/asset URLs invalidates on every
# Flask restart even if the browser ignored Cache-Control.
_ASSET_VERSION = str(int(datetime.now().timestamp()))


@app.context_processor
def _inject_asset_version():
    # ★ sigma_grain / sigma_grain_note 는 **함수**로 주입한다 (값이 아니라).  값을 route 마다
    #   render_template(..., sigma_grain=...) 로 넘기는 방식이면 새 route 가 하나 생길 때
    #   조용히 빠지고 템플릿은 그대로 옛 bare 3.0 을 쓰게 된다 — 실제로 single.html 이
    #   그 상태였다(2026-07-28 재검증 HIGH-e: app.py 는 깨끗한데 템플릿에 3.0 이 살아있음).
    #   전역 함수면 어떤 route 로 렌더되든 템플릿이 스스로 정본을 호출한다.
    return {'asset_version': _ASSET_VERSION,
            'sigma_grain': lambda m=None: _sigma_grain_context(m)[0],
            'sigma_grain_note': lambda m=None: _sigma_grain_context(m)[1]}


# ── Trust-card self-report (validation_flags → 5 LED dots) ────────────
# `validation_flags` is written into full_metrics.json by Stage E
# (`run_network_full_corrections._compute_validation_flags`).
# Five gates: within_bielefeld_range, fracture_distribution_realistic,
# solver_input_intact, stage_e_le_baseline_sigma_e, bruggeman_fallback_fired_any.
# This helper returns a render-ready dict for the trust-card template.
#
# Each LED definition (key) carries the rich tooltip metadata:
#   label      — text inside the LED chip
#   value_key  — which validation_flags entry holds the *measured value*
#                so the tooltip can show "ASR = 42.3 Ω·cm²" not just pass/fail
#   value_fmt  — printf-style format ('{:.2f}', or callable)
#   value_unit — appended to the formatted value
#   criterion  — pass criterion in plain English (Bielefeld envelope etc.)
#   desc_kr    — Korean one-liner explaining the gate's purpose
#   na_reason  — Korean explanation of why a gate is N/A when data is missing
#   pass_kr    — Korean explanation when gate passes
#   fail_kr    — Korean explanation when gate fails
#   ref        — paper section / reference for the gate definition
#   polarity   — 'positive' = True is pass, 'negative' = True is fail (Brugg)
_TRUST_LEDS = [
    {
        'key':       'within_bielefeld_range',
        'label':     'ASR',
        'value_key': 'asr_ionic_Ohm_cm2',
        'value_fmt': '{:.2f}',
        'value_unit': ' Ω·cm²',
        'criterion': '10 ≤ ASR ≤ 200 Ω·cm² (literature envelope)',
        'desc_kr':   'Cathode ASR가 sulfide ASSB 문헌 (Bielefeld 2022 / '
                     'Lee 2020 / Minnmann 2021) 범위 안에 있는지. '
                     'Stage E σ_ionic 의 first-line sanity check.',
        'pass_kr':   '✓ 측정값이 문헌 envelope 안에 있음 — '
                     'σ_ionic 계산이 비현실적 값으로 빠지지 않았다는 뜻.',
        'fail_kr':   '✗ ASR이 문헌 범위를 벗어남. Stage E factor가 너무 '
                     '많이 깎아냈거나 baseline σ가 비정상일 수 있음.',
        'na_reason': '두께 또는 σ_ionic 정보가 full_metrics에 없어서 '
                     'ASR 계산 불가 (대부분 baseline-only 케이스).',
        'ref':       'paper §5.2 · Bielefeld 2022 / Lee 2020 / Minnmann 2021',
        'polarity':  'positive',
    },
    {
        'key':       'fracture_distribution_realistic',
        'label':     'Frac',
        'value_key': 'fracture_severe_pct',
        'value_fmt': '{:.1f}',
        'value_unit': '% severe',
        'criterion': 'severe % ≤ 50 & ≥1 Lawn stage populated',
        'desc_kr':   '심한 fracture (fragmentation + pulverization) 비율이 '
                     '50%를 넘으면 classifier가 한 bucket으로 몰린 거. '
                     '1 GPa 압축 실험에서도 보통 40% 안 넘음.',
        'pass_kr':   '✓ Lawn 1998 cone-crack envelope 안에 있음 — '
                     'fracture classifier가 정상 분포 출력.',
        'fail_kr':   '✗ Severe fracture 비율 비정상. classifier threshold '
                     '검토 또는 contact force unit 변환 (sim → real) 확인 필요.',
        'na_reason': 'fracture_stage_counts가 비어있음 — '
                     'fracture 분석이 아직 안 돌았거나 contact 없음.',
        'ref':       'paper §5.2 · Lawn 1998',
        'polarity':  'positive',
    },
    {
        'key':       'solver_input_intact',
        'label':     'Solver',
        'value_key': 'edge_drop_ratio_e',
        'value_fmt': '{:.2%}',
        'value_unit': ' edges dropped',
        'criterion': 'edge_drop_ratio_e ≤ 0.5',
        'desc_kr':   'Stage E factor가 5% cutoff (MIN_FACTOR_CUTOFF) '
                     '아래로 떨어진 AM-AM electronic edge를 얼마나 버렸나. '
                     '절반 넘게 버리면 direct solver 대신 Bruggeman '
                     'fallback이 거의 다 하고 있다는 뜻.',
        'pass_kr':   '✓ Direct Laplacian solver가 conductance의 대부분을 '
                     '실제로 계산 — Stage E 결과 신뢰 가능.',
        'fail_kr':   '✗ Edge 절반 이상이 cutoff 아래로 깎여나감. '
                     'Bruggeman fallback이 over-active. fracture index '
                     '재검토 또는 Stage E factor 분포 조사 필요.',
        'na_reason': 'n_dropped_e 또는 n_am_am_total 메트릭 없음 — '
                     'Stage E 완전히 안 돌아간 케이스.',
        'ref':       'paper §6 · MIN_FACTOR_CUTOFF = 0.05',
        'polarity':  'positive',
    },
    {
        'key':       'stage_e_le_baseline_sigma_e',
        'label':     'σ ≤ base',
        'value_key': None,
        'value_fmt': None,
        'value_unit': '',
        'criterion': 'σ_e^(Stage E) ≤ 1.05 × σ_e^(baseline)',
        'desc_kr':   'Stage E factor가 1 이하라는 invariant (factor는 '
                     'conductance를 절대 늘릴 수 없다)가 지켜졌나. '
                     'Bruggeman fallback은 by construction 보장하지만 '
                     'direct solver 경로는 수치 오차로 약간 넘을 수 있음.',
        'pass_kr':   '✓ Factor-≤-1 invariant 유지됨 — Stage E σ가 baseline을 '
                     '넘지 않음. paper §6 Bruggeman bound 증명과 일관.',
        'fail_kr':   '✗ Stage E σ_e > baseline σ_e. 수치 불안정성 또는 '
                     'high-contrast Laplacian 발산. 7-layer 방어선 재검토.',
        'na_reason': 'Stage E σ_e 또는 baseline σ_e가 없음 — '
                     '비교 불가.',
        'ref':       'paper §6 · Bruggeman bound proof',
        'polarity':  'positive',
    },
    {
        'key':       'bruggeman_fallback_fired_any',
        'label':     'Brugg',
        'value_key': None,
        'value_fmt': None,
        'value_unit': '',
        'criterion': 'no channel fell back to EMT',
        'desc_kr':   'σ_ionic / σ_e / κ 세 channel 중 하나라도 Bruggeman '
                     'EMT fallback으로 풀렸나. Fallback은 정답을 보장하지만 '
                     'high-contrast 케이스에서 conservative한 upper-bound. '
                     'orange = EMT가 일부 채널 운반.',
        'pass_kr':   '✓ 세 channel 모두 direct Laplacian solver로 수렴 — '
                     'EMT 보정 필요 없었음.',
        'fail_kr':   '⚠ 적어도 한 channel이 Bruggeman으로 fallback. 결과는 '
                     '안전한 upper-bound이지만 direct solver 결과는 아님. '
                     'paper §6 self-report로 명시 권장.',
        'na_reason': 'stage_e_source 메트릭 없음 — Stage E 안 돌아간 케이스.',
        'ref':       'paper §6 · 7-layer defence Layer 6',
        'polarity':  'negative',  # True = fired = fail (orange)
    },
]


def _format_led_value(led_def: dict, flags: dict) -> str | None:
    """Pull the measured value for an LED's tooltip. Returns formatted
    string or None if no value tracked / data missing."""
    vk = led_def.get('value_key')
    if not vk:
        return None
    raw = flags.get(vk)
    if raw is None:
        return None
    try:
        fmt = led_def.get('value_fmt') or '{}'
        return fmt.format(raw) + led_def.get('value_unit', '')
    except (TypeError, ValueError):
        return str(raw)


def _build_trust_card(metrics: dict) -> dict | None:
    """Translate metrics['validation_flags'] into the LED + verdict
    structure consumed by the single.html template. Returns None when
    the flags block is absent so the card simply isn't rendered.

    Each LED carries a rich tooltip payload (value + criterion + Korean
    description + pass/fail one-liners + reference) so the hover surface
    on the page header is a self-contained explanation of the gate."""
    flags = (metrics or {}).get('validation_flags')
    if not isinstance(flags, dict):
        return None

    leds = []
    n_pass = n_fail = n_na = 0
    for led_def in _TRUST_LEDS:
        v = flags.get(led_def['key'])
        polarity = led_def.get('polarity', 'positive')
        if v is None:
            cls, state_kr = 'na', 'N/A · 측정 불가'
            n_na += 1
        elif (v if polarity == 'positive' else not v):
            cls, state_kr = 'pass', led_def['pass_kr']
            n_pass += 1
        else:
            cls, state_kr = 'fail', led_def['fail_kr']
            n_fail += 1

        value_str = _format_led_value(led_def, flags)
        # Build the rich tooltip payload.  Template renders this as a
        # styled <div class="trust-tip"> child of each <span class="trust-led">.
        leds.append({
            'label':     led_def['label'],
            'cls':       cls,
            'value':     value_str or '—',
            'criterion': led_def['criterion'],
            'desc_kr':   led_def['desc_kr'],
            'state_kr':  state_kr if cls != 'na' else led_def['na_reason'],
            'ref':       led_def['ref'],
        })

    # Verdict: 4 gates excluding the Bruggeman warning indicator.  Trust
    # requires all assessable gates pass; any fail flips to warn/fail.
    core_keys = ['within_bielefeld_range',
                 'fracture_distribution_realistic',
                 'solver_input_intact',
                 'stage_e_le_baseline_sigma_e']
    core_vals = [flags.get(k) for k in core_keys]
    core_fail = sum(1 for v in core_vals if v is False)
    core_assess = sum(1 for v in core_vals if v is not None)
    if core_assess == 0:
        verdict, verdict_cls = 'N/A', 'na'
        verdict_kr = ('이 케이스는 Stage E가 돌지 않아 trust gate를 평가할 '
                       '수 없습니다. Stage E를 실행하면 5-LED 카드가 활성화됩니다.')
    elif core_fail == 0:
        verdict, verdict_cls = '✓ Trust', 'trust'
        verdict_kr = (f'{core_assess}/{core_assess} core gate 통과 — '
                       'paper §5.2 trustworthy 케이스로 분류 가능.')
    elif core_fail <= 1:
        verdict, verdict_cls = '~ Warn', 'warn'
        verdict_kr = (f'{core_assess - core_fail}/{core_assess} core gate 통과 — '
                       '1개 gate 실패. 결과 사용 시 caveat 명시 권장.')
    else:
        verdict, verdict_cls = '✗ Untrust', 'fail'
        verdict_kr = (f'{core_fail}/{core_assess} core gate 실패 — '
                       '결과 신뢰 곤란. paper §5.2 audit에서 제외 권장 케이스.')

    return {
        'leds': leds,
        'verdict': verdict,
        'verdict_cls': verdict_cls,
        'verdict_kr': verdict_kr,
        'verdict_summary': (f'{core_assess - core_fail}/{core_assess} core '
                             f'gates passed'),
    }

_here = os.path.dirname(__file__)
# Data folders are env-overridable so a SECOND checkout (e.g. a git-worktree
# webapp runner) can point at a SHARED data dir WITHOUT symlinking results/ —
# symlinking webapp/results breaks `git pull` because the repo tracks
# webapp/results/reports/*.md ("beyond a symbolic link").  Set WEBAPP_*_FOLDER
# (env or .env) to the shared absolute path; defaults stay in-tree.
app.config['UPLOAD_FOLDER'] = os.environ.get('WEBAPP_UPLOAD_FOLDER') or os.path.join(_here, 'uploads')
app.config['RESULTS_FOLDER'] = os.environ.get('WEBAPP_RESULTS_FOLDER') or os.path.join(_here, 'results')
app.config['SCRIPTS_FOLDER'] = os.path.join(os.path.dirname(_here), 'scripts')
app.config['ARCHIVE_FOLDER'] = os.environ.get('WEBAPP_ARCHIVE_FOLDER') or os.path.join(_here, 'archive')
# standalone MPM/도전재 payload viewer — independent of the DEM case list (upload mpm_payload.json,
# view in 3D, keep an accumulating saved list).  Each saved payload = a subfolder with payload.json + meta.json.
app.config['MPM_LAB_FOLDER'] = os.environ.get('WEBAPP_MPM_LAB_FOLDER') or os.path.join(_here, 'mpm_lab')

os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)
os.makedirs(app.config['RESULTS_FOLDER'], exist_ok=True)
os.makedirs(app.config['ARCHIVE_FOLDER'], exist_ok=True)
os.makedirs(app.config['MPM_LAB_FOLDER'], exist_ok=True)

@app.errorhandler(413)
def request_entity_too_large(error):
    return jsonify({'error': '파일 크기가 너무 큽니다. 최대 2GB까지 업로드 가능합니다.'}), 413

# ─── Supabase Storage: restore in background (don't block server start) ───
storage_sync.init()

def _bg_restore():
    storage_sync.restore_all(
        app.config['UPLOAD_FOLDER'],
        app.config['RESULTS_FOLDER'],
        app.config['ARCHIVE_FOLDER'],
    )

_restore_thread = threading.Thread(target=_bg_restore, daemon=True)
_restore_thread.start()

# ─── Helpers ────────────────────────────────────────────────────────────────

def _contained_join(base, sub):
    """Join `sub` under `base` and REJECT path-traversal escapes (defense-in-depth for
    user-supplied case_id).  Legit ids (timestamp_uuid, 'archive:a/b') stay inside base →
    allowed; anything resolving outside base (e.g. '../etc') → 400.  Checked BEFORE makedirs
    so a traversal id cannot even create a stray directory tree."""
    base_r = os.path.realpath(base)
    d = os.path.realpath(os.path.join(base_r, str(sub)))
    if d != base_r and not d.startswith(base_r + os.sep):
        abort(400, 'invalid case id')
    return d

def _archive_join(rel, *, must_exist=False):
    """archive 루트 **안으로만** 해석한다.  벗어나면 400 (코드리뷰 F-06).

    ★ 왜 필요한가: `_safe_path()` 는 archive CRUD 에만 쓰였고, group 계열
    (`/group/archive-cases` 의 `folder`, `archive:<rel>` case id) 은 사용자 입력을
    `os.path.join(archive_root, ...)` 으로 **직접** 붙여 `archive:../../...` 로 루트
    밖의 `full_metrics.json` 을 읽을 수 있었다.  모든 archive 입력이 이 함수를 지난다.

    `_contained_join` 과 달리 **디렉터리를 만들지 않는다** — 조회가 유령 디렉터리를
    만드는 F-16 을 여기서 되풀이하지 않기 위해서다.
    """
    base = os.path.realpath(app.config['ARCHIVE_FOLDER'])
    target = os.path.realpath(os.path.join(base, str(rel)))
    if target != base and not target.startswith(base + os.sep):
        abort(400, 'invalid archive path')
    if must_exist and not os.path.exists(target):
        abort(404, 'archive path not found')
    return target


def _slugify_case_name(name, fallback='case'):
    """표시 이름 → **저장 경로용 slug** (F-06).

    옛 코드는 사용자가 정한 `meta['name']` 을 그대로 `os.path.join(dst, name)` 에 썼다.
    이름에는 경로 문자 검증이 없어(업로드·rename 어디에도) archive 저장 위치가 루트를
    벗어날 수 있었다.  표시 이름은 meta 에만 두고 **경로에는 이 slug 만** 쓴다.
    """
    import re as _re
    s = _re.sub(r'[^0-9A-Za-z가-힣._-]+', '_', str(name or '')).strip('._-')
    s = _re.sub(r'_{2,}', '_', s)
    # '.' / '..' / 빈 문자열은 경로로 쓸 수 없다
    return s[:120] if s and s not in ('.', '..') else fallback


def get_case_dir(case_id):
    d = _contained_join(app.config['UPLOAD_FOLDER'], case_id)
    os.makedirs(d, exist_ok=True)
    return d

def get_results_dir(case_id):
    d = _contained_join(app.config['RESULTS_FOLDER'], case_id)
    os.makedirs(d, exist_ok=True)
    return d

def detect_mode(case_dir):
    """Detect if bimodal (3 types) or standard (2 types) from atom file type count."""
    # Count unique atom types from atom dump file (most reliable)
    for f in sorted(os.listdir(case_dir)):
        if f.startswith('atom') and f.endswith('.liggghts'):
            with open(os.path.join(case_dir, f)) as fh:
                lines = fh.readlines()
                types = set()
                in_data = False
                for line in lines:
                    stripped = line.strip()
                    if stripped.startswith('ITEM: ATOMS'):
                        in_data = True
                        continue
                    if stripped.startswith('ITEM:'):
                        in_data = False
                        continue
                    if in_data:
                        parts = stripped.split()
                        if len(parts) >= 2:
                            try:
                                t = int(parts[1])
                                types.add(t)
                            except ValueError:
                                continue
                # 3 types = bimodal (AM_P + AM_S + SE)
                # 2 types = standard (AM + SE)
                if len(types) >= 3:
                    return 'bimodal'
                return 'standard'
    return 'standard'

def list_cases():
    """List all uploaded cases with metadata."""
    cases = []
    upload_dir = app.config['UPLOAD_FOLDER']
    if not os.path.exists(upload_dir):
        return cases
    for case_id in sorted(os.listdir(upload_dir), reverse=True):
        case_dir = os.path.join(upload_dir, case_id)
        if not os.path.isdir(case_dir):
            continue
        meta_file = os.path.join(case_dir, 'meta.json')
        if os.path.exists(meta_file):
            try:
                with open(meta_file) as f:
                    meta = json.load(f)
                if not isinstance(meta, dict):
                    raise ValueError('meta.json is not an object')
            except (ValueError, OSError) as _e:
                # ★ 2026-09-26 — WSL 이 죽을 때 0 B · 반쪽이 된 meta.json 하나가 목록 전체(/)를 500 으로 만들었다.
                #   건너뛰고 기본값 + 표지로 보인다 (파일은 건드리지 않는다 — 복구는 사람이).  webapp/test_meta_json_robust.py
                print(f'[list_cases] ⚠ 깨진 meta.json — 기본값으로 표시: {meta_file} ({type(_e).__name__}: {_e})')
                meta = {'name': case_id, 'created': '', 'mode': 'unknown', 'status': 'meta_broken',
                        'meta_error': f'{type(_e).__name__}: {_e}'}
        else:
            meta = {'name': case_id, 'created': '', 'mode': 'unknown', 'status': 'uploaded'}
        meta['id'] = case_id
        # Check for results
        results_dir = os.path.join(app.config['RESULTS_FOLDER'], case_id)
        meta['has_results'] = os.path.isdir(results_dir) and len(os.listdir(results_dir)) > 0
        figures_dir = os.path.join(results_dir, 'figures')
        meta['has_figures'] = os.path.isdir(figures_dir) and len(globmod.glob(os.path.join(figures_dir, '*.png'))) > 0
        report_file = os.path.join(results_dir, 'report.md')
        meta['has_report'] = os.path.exists(report_file)
        meta['has_mpm'] = os.path.exists(os.path.join(results_dir, 'mpm_payload.json'))  # MPM result uploaded?
        meta['mpm_regime'] = ''   # filled below (cross-validated / SE-rich / SE-poor) when DEM+MPM porosity both exist
        # Check for warnings
        metrics_file = os.path.join(results_dir, 'full_metrics.json')
        if os.path.exists(metrics_file):
            with open(metrics_file) as f:
                m = json.load(f)
            #  ★ 10-05 RGLR2-02 — 목록의 망 상태 · 종합 등급도 확정되지 않은 망 세대의 값을 쓰지 않는다 (network_solver_status 'invalid' · σ None)
            _network_generation_guard(results_dir, m)
            meta['warning_count'] = m.get('warning_count', 0)
            meta['warning_msgs'] = [w['msg'] for w in m.get('warnings', [])]
            meta['network_solver_status'] = m.get('network_solver_status', meta.get('network_solver_status', ''))
            # Physics solver state — three explicit values for UI badges:
            #   'mikic' / 'maxwell+film' → upgraded (PHYS ✓, green)
            #   'maxwell' or any legacy tag → PHYS legacy (orange)
            #   missing physics σ → PHYS ∅ (gray)
            phys_model = m.get('physics_resistance_model')
            if phys_model in ('mikic', 'maxwell+film'):
                pass  # upgraded state — keep as-is
            elif phys_model == 'maxwell' or 'sigma_full_mScm_physics' in m:
                phys_model = 'maxwell'
            else:
                phys_model = 'no_physics'
            meta['physics_resistance_model'] = phys_model
            meta['physics_solver_at'] = m.get('physics_solver_at', '')

            # Stage E completion — for the 3 channels.  Missing Stage E means
            # network_solver ran but run_network_full_corrections.py post-
            # processing didn't fill in *_stage_e_physics keys.  Common for
            # cases analyzed before /analyze was wired to run Stage E, or
            # when Stage E physics-mode failed silently.
            #
            # Distinguish:
            #   - Has Hertz Stage E but missing Physics → backfill possible (orange ⚠)
            #   - No Stage E at all → needs full re-analysis (no badge — covered by
            #     NET ✗ / PHYS ∅ already)
            #   - All 3 Physics channels present → green ✓
            _has_i_h = bool(m.get('sigma_full_mScm_stage_e'))
            _has_e_h = bool(m.get('electronic_sigma_full_mScm_stage_e'))
            _has_k_h = bool(m.get('thermal_sigma_full_mScm_stage_e'))
            _any_hertz_se = _has_i_h or _has_e_h or _has_k_h
            _has_i_p = bool(m.get('sigma_full_mScm_stage_e_physics'))
            _has_e_p = bool(m.get('electronic_sigma_full_mScm_stage_e_physics'))
            _has_k_p = bool(m.get('thermal_sigma_full_mScm_stage_e_physics'))
            meta['stage_e_physics_complete'] = (_has_i_p and _has_e_p and _has_k_p)
            # Only flag ⚠ if BOTH (a) the case has Hertz Stage E AND
            # (b) some Physics channels missing.  Otherwise the case either
            # needs full re-analysis (already covered by NET/PHYS badges) or
            # is fully complete.
            meta['stage_e_physics_missing'] = []
            if _any_hertz_se and not (_has_i_p and _has_e_p and _has_k_p):
                if not _has_i_p: meta['stage_e_physics_missing'].append('σ_ionic')
                if not _has_e_p: meta['stage_e_physics_missing'].append('σ_e')
                if not _has_k_p: meta['stage_e_physics_missing'].append('κ')

            # MPM regime — DEM↔MPM porosity cross-check (gap = DEM − MPM).  Splits the binary
            # "MPM ✓" badge into 3 intuitive states + tells which porosity value to trust:
            #   gap > +4  → SE-poor (out-of-envelope): MPM over-compresses → use DEM   (orange ⚠)
            #   gap < −4  → SE-rich: DEM ε_sphere over-compresses          → use MPM   (blue)
            #   |gap| ≤ 4 → cross-validated (in-envelope)                  → use MPM   (green ✓)
            # docs/data/mpm_dem_porosity_reliability.csv + troubleshooting §16/§17.
            #  ⚠⚠ 2026-08-25 — 게이트가 **틀린 것을 보고 있었다**.  `has_mpm` 은
            #    `mpm_payload.json`(3D 점군, 수백 MB) 존재 여부인데, 아래 계산에 필요한 것은
            #    `mpm_metrics.json` 의 `porosity_mpm_pct` **하나**다.  payload 없이 metrics 만
            #    있는 케이스(복원분 146건)에서 regime(SE-rich/SE-poor/cross-validated)이
            #    통째로 안 떴다.  ⇒ **필요한 것의 존재**로 연다.
            #    ★ `has_mpm`(3D 버튼·배지)은 그대로 payload 기준이다 — 그건 진짜로 없다.
            _mm_exists = os.path.exists(os.path.join(results_dir, 'mpm_metrics.json'))
            if meta.get('has_mpm') or _mm_exists:
                _dem_por = m.get('porosity_spheresum')
                if _dem_por is None:
                    _dem_por = m.get('porosity')
                _mpm_por = None
                _mmf = os.path.join(results_dir, 'mpm_metrics.json')
                if os.path.exists(_mmf):
                    try:
                        with open(_mmf) as _mf:
                            _mpm_por = (json.load(_mf) or {}).get('porosity_mpm_pct')
                    except Exception:
                        _mpm_por = None
                if _dem_por is not None and _mpm_por is not None:
                    _gap = float(_dem_por) - float(_mpm_por)
                    meta['mpm_dem_porosity'] = round(float(_dem_por), 1)
                    meta['mpm_porosity'] = round(float(_mpm_por), 1)
                    meta['mpm_gap'] = round(_gap, 1)
                    if _gap > 4.0:
                        meta['mpm_regime'] = 'SE-poor';        meta['mpm_use_source'] = 'DEM'
                    elif _gap < -4.0:
                        meta['mpm_regime'] = 'SE-rich';        meta['mpm_use_source'] = 'MPM'
                    else:
                        meta['mpm_regime'] = 'cross-validated'; meta['mpm_use_source'] = 'MPM'

            # Composite score (overall grade) — used for the 랭킹 filter.
            # Cheap to compute (no SE-aux dependency at the list level;
            # corpus-relative axes drop to N/A here, which is fine).
            try:
                import sys as _sys
                scripts_dir = os.path.join(os.path.dirname(__file__), '..', 'scripts')
                if scripts_dir not in _sys.path:
                    _sys.path.insert(0, scripts_dir)
                from grade_engine import build_overall_grade
                aux_path = os.path.join(results_dir, 'viewer_aux.json')
                se_aux = None
                if os.path.exists(aux_path):
                    try:
                        with open(aux_path) as af:
                            _aux = json.load(af)
                        se_aux = {
                            'n_percolating':         _aux.get('se_n_percolating'),
                            'articulation_points':   _aux.get('se_articulation_points', []),
                            'n_bn_below_threshold':  _aux.get('se_n_bn_below_threshold'),
                            'n_perc_edges':          _aux.get('se_n_perc_edges'),
                            'bn_median_norm':        _aux.get('se_bn_median_norm'),
                        }
                    except (OSError, ValueError):
                        pass
                corpus_csv = os.path.join(os.path.dirname(__file__), '..',
                                          'docs', 'data', 'se_diagnostics_82.csv')
                if not os.path.exists(corpus_csv):
                    corpus_csv = None
                _gres = build_overall_grade(
                    _inject_input_params(m, results_dir),
                    corpus_csv, se_aux, case_id=case_id)
                meta['overall_score']    = _gres['composite']['score']
                meta['overall_grade']    = _gres['composite']['grade']
                meta['overall_n_axes']   = _gres['composite']['n_axes']
                meta['is_unit_cell']     = _gres['composite'].get('is_unit_cell', False)
                meta['rve_area_um2']     = _gres['composite'].get('rve_area_um2')
                meta['base_case']        = _gres['composite'].get('base_case')
            except Exception:
                meta['overall_score']    = None
                meta['overall_grade']    = '—'
                meta['overall_n_axes']   = 0
                meta['is_unit_cell']     = False
                meta['rve_area_um2']     = None
                meta['base_case']        = None

            # Porosity for the list view (prefer recomputed sphere-sum; fall
            # back to legacy 'porosity').  union + overlap shown in the row
            # tooltip.  (Inside the metrics-exist guard so `m` is always defined;
            # cases with no full_metrics.json simply have no porosity keys.)
            meta['porosity'] = (m.get('porosity_spheresum')
                                if m.get('porosity_spheresum') is not None
                                else m.get('porosity'))
            meta['porosity_union']        = m.get('porosity_union')
            meta['overlap_fraction_pct']  = m.get('overlap_fraction_pct')
        #  ★ 10-05 WEB-03 Q2b — 한 실패 어휘: 위 network_solver_status 는 **활성 세대**의 투영 상태다 (실패 시도는 이제 full_metrics 를 건드리지
        #    않는다).  최근 시도는 이름이 다른 칸으로 싣는다 — 소비자가 같은 이름을 두 뜻으로 추측하지 않게 (`_ps.network_status_view`).
        if meta.get('has_results'):
            try:
                _nv = _ps.network_status_view(results_dir)
                meta['network_active_status'] = _nv['active_status']
                meta['network_generation_problem'] = _nv.get('active_problem') or ''      # ★ RGLR2-02 — 무효 사유 (확정이면 '')
                meta['network_latest_attempt_status'] = _nv['latest_attempt_status']
                meta['network_latest_attempt_failure_kind'] = _nv['failure_kind']
                meta['network_stale_after_failed_attempt'] = _nv['stale']
            except Exception:                                          # noqa: BLE001 — 목록 표시용 (한 케이스가 목록을 깨지 않게)
                pass
        cases.append(meta)
    return cases

# Keys mirrored from the physics-mode solution for dual-column display.
# When the dual JSON is present, these are copied with a '_physics' suffix.
_NET_PHYSICS_MIRROR_KEYS = list(_ps.NET_PHYSICS_MIRROR_KEYS)   # 정의는 pipeline_service


def _pct_delta(h, p):
    """Format Δ% between Hertzian and physics values. '+X.X%' / '-X.X%' / '0%'."""
    try:
        if h is None or p is None or float(h) == 0:
            return '0%'
        d = (float(p) / float(h) - 1.0) * 100.0
        if abs(d) < 0.05:
            return '0%'
        sign = '+' if d >= 0 else ''
        return f"{sign}{d:.1f}%"
    except Exception:
        return '0%'


#  ★ 10-15 L214-03 (Codex LHS214 판정 §2 · 수정 계획 §1 · CLAUDE.md "코드 → 웹앱 순차 반영" — 같은 묶음) — 모드별 값 · 비 · 차이의 **strict missing**.
#    옛 `_dual_row` 는 Physics 값이 없으면 Hertz 값을 Physics 칸에 복사하고 Δ 0 % 를 냈다 (σ_ionic · σ_brug/σ_ionic · CF/FULL · 전자 — Codex AST 탐침:
#    Hertz 0.6 · Physics None 인데 0.6 · 0.6 · 0 %).  FULL 모형 한계 (physics q > 1.5 · 값 미제공) 가 게시되면서 그 칸이 새로 보이게 됐다 → 없는 모드의 칸 · Δ = '—'
#    (+ 사유: 그 채널 · 모드의 생산자 사유가 모형 한계면 그 이름) · 0 · Hertz · H12 로 대체하지 않는다.
MODEL_LIMIT_REASON = 'full_over_conduction'                      # = tau_flux.MODEL_LIMIT_REASON · network_conductivity.FULL_OVER_CONDUCTION_REASON
MODEL_LIMIT_CELL = '— (모형 한계 · full_over_conduction — FULL q > 1.5 출력 상한 · 수치 인증 통과 · 값 미제공)'
_MISSING_REASON_KEY = {'ionic': 'sigma_full_reason', 'electronic': 'electronic_sigma_full_reason', 'thermal': 'thermal_sigma_full_reason'}


def _mode_missing_text(metrics, chan='ionic', mode='physics'):
    """없는 모드 칸의 문구 — 그 채널 · 모드의 생산자 사유 (full_metrics 투영 · physics = `_physics` 꼬리) 가 FULL 모형 한계면 그 이름 · 그 밖 '—'."""
    key = _MISSING_REASON_KEY.get(chan, 'sigma_full_reason') + ('_physics' if mode == 'physics' else '')
    return MODEL_LIMIT_CELL if (metrics or {}).get(key) == MODEL_LIMIT_REASON else '—'


def _dual_row(label, h_val, p_val, fmt=None, p_missing='—', h_missing='—'):
    """[label, Hertzian, Physics, Δ%] row — ★ 10-15 L214-03 strict: 한쪽 값이 없으면 그 칸 = p_missing · h_missing ('—' 또는 사유) · Δ = '—'
    (옛: Physics 없으면 Physics = Hertz 복사 · Δ 0 %)."""
    if fmt is None:
        fmt = lambda x: x
    h_disp = fmt(h_val) if h_val is not None else h_missing
    p_disp = fmt(p_val) if p_val is not None else p_missing
    delta = _pct_delta(h_val, p_val) if (h_val is not None and p_val is not None) else '—'
    return [label, h_disp, p_disp, delta]


#: ★ 10-15 L214-03 — 기존 network_summary.csv (analyze_contacts — Hertz 한 열로 쓴 망 절) 의 **모드별** 행 → (Hertz 키, Physics 키, 채널, 표시 식, 값 변환).
#:   transform 의 Step 1 이 이 행들을 넓힐 때 Physics 칸을 Hertz 복사가 아니라 metrics 의 Physics 값으로 (없으면 '—' + 사유) · Δ 는 두 값이 다 있을 때만.
_MODE_DEP_CSV_ROWS = {
    'σ_ionic (mS/cm)': ('sigma_full_mScm', 'sigma_full_mScm_physics', 'ionic', lambda x: round(x, 4), None),
    'R_brug (과대추정 배수)': ('R_brug_over_full', 'R_brug_over_full_physics', 'ionic', lambda x: f'{x:.1f}×', None),
    'Constriction 비율(%)': ('bulk_resistance_fraction', 'bulk_resistance_fraction_physics', 'ionic', lambda x: round(x, 1),
                            lambda b: (1 - b) * 100),
    'σ_electronic (mS/cm)': ('electronic_sigma_full_mScm', 'electronic_sigma_full_mScm_physics', 'electronic', lambda x: round(x, 2), None),
    'σ_thermal (mS/cm equiv)': ('thermal_sigma_full_mScm', 'thermal_sigma_full_mScm_physics', 'thermal', lambda x: round(x, 3), None),
}


def _csv_mode_row(label, h_cell, spec, metrics):
    """기존 CSV 망 절의 모드별 두 열 행 → 네 열 (Hertz 칸 = CSV 값 그대로 · Physics = metrics · strict missing · Δ = 둘 다 있을 때만)."""
    hk, pk, chan, fmt, conv = spec
    m = metrics or {}

    def _v(k):
        x = m.get(k)
        if not isinstance(x, (int, float)) or isinstance(x, bool) or x != x:
            return None
        return conv(x) if conv else x
    hv, pv = _v(hk), _v(pk)
    p_disp = fmt(pv) if pv is not None else _mode_missing_text(m, chan)
    return [label, h_cell, p_disp, _pct_delta(hv, pv) if (hv is not None and pv is not None) else '—']


#  ★ 10-16 L214R-03 (Codex LHS214 재검증 판정문 §4 · 수정 계획 lhs214r_fix_plan_20261016 Q3 = 1저자 비준 "화면만" — 분석기 CSV · 계산 무변경) —
#    최종 병합 뒤 **현재 모드별 망 상태가 이긴다**.  network 게시는 contact 단계의 network_summary.csv 를 갱신하지 않는다 → 옛 CSV 숫자가 split 병합 (Pass A) ·
#    두 열 Hertz 칸 · 네 열 그대로 경로로 모형 한계 · σ 미채택 모드에 다시 채워졌다 (같은 화면의 상태 행 = 모형 한계 · τ 행 = NOT_COMPUTED 와 모순).
#    채택 = 생산자 상태 키 없음 (옛 세대) 또는 computed + 유한 σ > 0 · 그 밖 (not_computed · valid_zero · unknown · 값 없음 · 비유한) = 칸 '—' (+ 사유) · Δ '—'.
#    채택된 모드의 칸은 건드리지 않는다 (★ 10-16 WEB-09 — 그 칸은 바로 앞 단계 `_refresh_accepted_ion_modes` 가 현재 metrics 로 다시 쓴다).
#    Constriction 비율 (접촉별 비가중 평균 — 생산자가 모형 한계에도 싣는다) · 전자 · 열 (Pass D 가 metrics 로 다시 씀) 은 밖.
_ION_MODE_ROWS = ('σ_ionic (mS/cm)', 'R_brug (과대추정 배수)', 'Contact-free / Full', 'σ_brug / σ_ionic')   # 모드별 칸 = 이온 FULL σ · FULL 유도비
_ION_RATIO_ROW = 'σ_ionic ratio (physics/Hertzian)'       # Plastic amplification = σ_P / σ_H — 두 모드 다 채택일 때만 정의


def _ion_mode_accepted(metrics, mode):
    """그 모드 ('hertz' · 'physics') 의 이온 FULL σ 가 채택됐나 — 생산자 상태 (sigma_full_status[_physics]) 가 없거나 (옛 세대) computed 이고
    σ (sigma_full_mScm[_physics]) 가 유한 양수."""
    sx = '_physics' if mode == 'physics' else ''
    m = metrics or {}
    v = m.get('sigma_full_mScm' + sx)
    return m.get('sigma_full_status' + sx) in (None, 'computed') and _v2_num(v) and float(v) > 0


def _ion_cell_blank(c):
    """값 없는 칸 — '' · '-' · '—' · 'nan' · 'None' · '—' 로 시작 (모형 한계 사유 문구 포함).  Pass G 두 단계가 같이 쓴다."""
    s = '' if c is None else str(c).strip()
    return s in ('', '-', '—', 'nan', 'None') or s.startswith('—')


#  ★ 10-16 WEB-09 (1저자 10-16 Q1 "권고대로" = 화면만 — 분석기 CSV · 계산 무변경) — 이온 행을 metrics 로 만드는 식 **한 곳**.
#    새 표 경로 (CSV 망 절이 없을 때: transform Step 4 · 4b · normalize Pass E) 와 최종 화면의 채택 모드 갱신 (Pass G) 이 같이 부른다 — 정의 · 꼴 · Δ 가 둘로 갈리지 않게.
#    식은 옮기기 전 그대로 (새 표 렌더 무변경).  부르는 조건 (σ_H 가 있어야 행을 낸다 등) 은 각 자리에 그대로 둔다.
def _ion_sigma_row(metrics):
    """σ_ionic — round(σ, 4) · Physics 없으면 '—' (+ 모형 한계 사유) · Δ = 둘 다 있을 때 _pct_delta (transform Step 4)."""
    m = metrics or {}
    return _dual_row('σ_ionic (mS/cm)', m.get('sigma_full_mScm'), m.get('sigma_full_mScm_physics'),
                     fmt=lambda x: round(x, 4), p_missing=_mode_missing_text(m, 'ionic'))


def _ion_cf_full_row(metrics):
    """Contact-free / Full = R_brug_over_full[_physics] (σ_Bruggeman 은 모드 무관 · σ_ionic 이 모드마다 달라 비가 바뀐다) — transform Step 4 · 4b.
    ★ L214-03 — Physics 칸 = Physics 값 (옛: Hertz 를 대신 썼다)."""
    m = metrics or {}
    return _dual_row('Contact-free / Full', m.get('R_brug_over_full'), m.get('R_brug_over_full_physics'),
                     fmt=lambda x: f"{x:.1f}×", p_missing=_mode_missing_text(m, 'ionic'))


def _ion_brug_over_sigma_row(metrics):
    """σ_brug / σ_ionic = σ_grain · sigma_ratio / σ_full — transform Step 4 · 4b · sigma_ratio 가 없으면 None (그 행을 만들 수 없다).
    ★ L214-03 — Physics σ 가 없으면 Physics 칸 '—' (옛: `or sig_ion_h` · `else ratio_h` 로 Hertz 대체).  Hertz σ 가 없으면 Hertz 칸 '—' (갱신이 Physics 칸만 쓸 때)."""
    m = metrics or {}
    if not m.get('sigma_ratio'):
        return None
    sig_brug = _sigma_grain_mS_cm(m) * m['sigma_ratio']
    sig_ion_h = m.get('sigma_full_mScm')
    sig_ion_p = m.get('sigma_full_mScm_physics')
    ratio_h = (sig_brug / sig_ion_h if sig_ion_h > 0 else 0) if sig_ion_h is not None else None
    ratio_p = sig_brug / sig_ion_p if (sig_ion_p is not None and sig_ion_p > 0) else None
    return _dual_row('σ_brug / σ_ionic', ratio_h, ratio_p, fmt=lambda x: f"{x:.1f}×", p_missing=_mode_missing_text(m, 'ionic'))


def _ion_r_brug_row(metrics):
    """R_brug (과대추정 배수) — normalize Pass E (늘 내는 행).  ★ L214-03 — Physics 칸 = Physics 의 CF/FULL (옛: Hertz 값 복사 · Δ 0 %) · 없으면 '—' (+ 사유)."""
    m = metrics or {}
    rb = m.get('R_brug_over_full')
    rb_str = f'{rb:.1f}×' if isinstance(rb, (int, float)) and rb else '—'
    rbp = m.get('R_brug_over_full_physics')
    rbp_ok = isinstance(rbp, (int, float)) and not isinstance(rbp, bool) and bool(rbp)
    rb_ok = isinstance(rb, (int, float)) and not isinstance(rb, bool) and bool(rb)
    rbp_str = f'{rbp:.1f}×' if rbp_ok else _mode_missing_text(m, 'ionic')
    return ['R_brug (과대추정 배수)', rb_str, rbp_str, _pct_delta(rb, rbp) if (rb_ok and rbp_ok) else '—']


def _ion_plastic_amp_row(metrics):
    """σ_ionic ratio (physics/Hertzian) = Plastic amplification σ_P / σ_H — 한 값을 두 칸에 · Δ '0%' (normalize Pass E)."""
    m = metrics or {}
    sh, sp = m.get('sigma_full_mScm'), m.get('sigma_full_mScm_physics')
    ratio_str = f'{sp / sh:.2f}×' if (sh and sp) else '—'
    return [_ION_RATIO_ROW, ratio_str, ratio_str, '0%']


_ION_ROW_BUILDERS = {'σ_ionic (mS/cm)': _ion_sigma_row, 'R_brug (과대추정 배수)': _ion_r_brug_row,
                     'Contact-free / Full': _ion_cf_full_row, 'σ_brug / σ_ionic': _ion_brug_over_sigma_row}   # = _ION_MODE_ROWS 넷


def _refresh_accepted_ion_modes(data, metrics):
    """normalize Pass G 앞 단계 (★ 10-16 WEB-09) — **채택** 모드의 이온 σ · FULL 유도비 칸 = 새 표 식 (`_ION_ROW_BUILDERS`) 이 현재 metrics 로 내는 값.
    contact 단계가 쓴 network_summary.csv 는 network 게시가 갱신하지 않는다 → 망을 다시 분석하면 채택 칸에 옛 CSV 숫자가 남고 Δ 만 현재 값이었다.
    그 식이 그 칸을 못 만들면 (필요한 metric 없음 → '—' · 행 없음) 기존 칸 그대로 (지어내지 않는다) · Δ = 두 칸이 다 현재 값이면 새 표 Δ · 그 밖 '—'
    (★ 10-18 L214R-R02 — 한 칸만 · 둘 다 아님 · 새 표 행 없음 모두: 옛 칸 둘의 옛 Δ 를 현재 비교처럼 남기지 않는다 · 옛 칸 값 보존은 그대로).
    Plastic amplification = 두 모드 다 채택이면 새 표 행 그대로.  미채택 모드 칸은 건드리지 않는다 (뒤의 `_mask_unaccepted_ion_modes` 몫)."""
    ok = {mode: _ion_mode_accepted(metrics, mode) for mode in ('hertz', 'physics')}
    if not (ok['hertz'] or ok['physics']):
        return
    for r in data:
        if not (isinstance(r, list) and len(r) >= 4 and isinstance(r[0], str)):
            continue
        lab = r[0].strip()
        if lab == _ION_RATIO_ROW:
            if ok['hertz'] and ok['physics']:
                ref = _ion_plastic_amp_row(metrics)
                r[1], r[2], r[3] = ref[1], ref[2], ref[3]
            continue
        if lab not in _ION_ROW_BUILDERS:
            continue
        try:
            ref = _ION_ROW_BUILDERS[lab](metrics)
        except (TypeError, ValueError, OverflowError):      # 미채택 모드 칸의 값이 수가 아니면 — 그 행은 기존 칸 그대로 (화면이 죽지 않게 · 뒤 단계가 가린다)
            ref = None
        #  ★ 10-18 L214R-R02 (Codex 재확인 판정 §2 · 표기 L214RR-02 · 1저자 10-18 Q2) — Δ 는 freshness 로만: 두 칸이 다 현재 값 = 새 표 Δ · 그 밖 (한 칸만 ·
        #    둘 다 아님 · 새 표 행 없음 ref None) = '—'.  옛 판은 ref None · fresh [] 에서 Δ 를 건드리지 않아, 두 유도값이 모두 현재 값 없는 옛 CSV 행
        #    (31.0× / 37.0× +19.4% 등) 의 옛 Δ 가 현재 비교처럼 남았다.  칸 값은 그대로 (옛 값 보존 정책 · 지어내지 않는다).
        fresh = [] if ref is None else [i for i, mode in ((1, 'hertz'), (2, 'physics')) if ok[mode] and not _ion_cell_blank(ref[i])]
        for i in fresh:
            r[i] = ref[i]
        r[3] = ref[3] if len(fresh) == 2 else '—'


def _mask_unaccepted_ion_modes(data, metrics):
    """normalize 의 마지막 (Pass G) — 미채택 모드의 이온 σ · FULL 유도비 칸 = `_mode_missing_text` ('—' 또는 모형 한계 사유) · Plastic amplification 은
    두 모드 다 채택이 아니면 '— / —' · 이 행들에서 한 칸이라도 값이 없으면 Δ '—' (비 미제공 '— / — / 0%' 포함).  CSV 꼴 (split · 두 열 · 네 열 · 새 표) 무관."""
    ok = {mode: _ion_mode_accepted(metrics, mode) for mode in ('hertz', 'physics')}
    for r in data:
        if not (isinstance(r, list) and len(r) >= 4 and isinstance(r[0], str)):
            continue
        lab = r[0].strip()
        if lab in _ION_MODE_ROWS:
            for i, mode in ((1, 'hertz'), (2, 'physics')):
                if not ok[mode]:
                    r[i] = _mode_missing_text(metrics, 'ionic', mode)
        elif lab == _ION_RATIO_ROW:
            if not (ok['hertz'] and ok['physics']):
                r[1] = r[2] = '—'
        else:
            continue
        if _ion_cell_blank(r[1]) or _ion_cell_blank(r[2]):
            r[3] = '—'


def _same_row(label, val):
    """[label, val, val, '0%'] — metric not affected by contact mode."""
    return [label, val, val, '0%']


#  ★ 10-04 τ 명명 규약 (CLAUDE.md ★★ τ 블록 · 결정 16 실행 2단계 ① · TAU-01 · 21 · 08 라벨) — 케이스 τ 블록 행 이름.
#    tau2 = φ_SE·σ₀/σ_full = tortuosity factor (Tjaden κ = Landesfeind τ = COMSOL τ_F 꼴) · τ_Lap,eff = √tau2.
#    ⚠ 'COMSOL 입력' 표지는 배터리 Porous Electrode 노드의 GUI Equation 확인 뒤 (결정 5) — 그 전에는 꼴만 말한다.
TAU_SECTION_LABEL = '── τ 비교 (Dijkstra vs Laplace · tau2 = tortuosity factor) ──'
TAU2_ROW_LABEL = 'tau2 = φ·σ₀/σ_full (tortuosity factor · 협착 포함)'
TAU_SQRT_ROW_LABEL = 'τ_Lap,eff = √tau2 (Laplace · 협착 포함)'
TAU_RATIO_ROW_LABEL = 'τ_Lap,eff / τ_Dij (정의가 다른 두 τ 의 비)'


def _dual_row_strict(label, h_val, p_val, fmt):
    """[label, Hertz, Physics, Δ%] — physics 값이 없으면 physics 칸 '—' (Hertz 값을 복사하지 않는다 · TAU-21)."""
    h_disp = fmt(h_val) if h_val is not None else '—'
    p_disp = fmt(p_val) if p_val is not None else '—'
    delta = _pct_delta(h_val, p_val) if (h_val is not None and p_val is not None) else ''
    return [label, h_disp, p_disp, delta]


def _tau_block_rows(phi_se, sigma0, sig_full_h, sig_full_p, sig_bulk, tau_dij, tau_dij_all):
    """케이스 τ 블록 (Step 4 · Step 4b 공용 — 두 경로가 같은 행을 낸다).  값 규칙은 옛 판과 같고 tau2 행만 더했다.
      tau2 = φ_SE·σ₀/σ_full (σ₀ = 그 런의 σ_grain · σ_full 과 같은 T) · τ_Lap,eff = √tau2 · τ_Lap_geom = √(φ_SE·σ₀/σ_bulk_net)
      physics σ 가 없으면 physics 칸 '—' (TAU-21 — 옛 판은 Hertz 값을 조용히 복사했다).
      비율 τ_Lap,eff / τ_Dij 는 정의가 다른 두 τ 의 비라 협착 배수로 부르지 않는다 (CLAUDE.md τ 블록 · TAU-08)."""
    import math as _m
    _tf = _tau_flux()       # ★ TAU-03 (10-04) — 등급 τ 축 · COMSOL 2D · regime DB 와 같은 도우미 (`tau_flux.tau2_value`)

    def _t2(s):
        return _tf.tau2_value(phi_se, sigma0, s)
    t2_h, t2_p = _t2(sig_full_h), _t2(sig_full_p)
    sq_h = _m.sqrt(t2_h) if t2_h is not None else None
    sq_p = _m.sqrt(t2_p) if t2_p is not None else None
    t2_geom = _t2(sig_bulk)
    t_geom = _m.sqrt(t2_geom) if t2_geom is not None else None
    rows = [[TAU_SECTION_LABEL, '', '', '']]
    if tau_dij:
        rows.append(_same_row('τ_Dij (Dijkstra, 기하만)', round(tau_dij, 2)))
    if tau_dij_all:                                  # 기하 τ 전체판 (10-02) — 바닥 관통 SE 전부 · 표본 아님
        rows.append(_same_row('τ_Dij,all (Dijkstra 전체, 기하만)', round(tau_dij_all, 2)))
    if t_geom:
        rows.append(_same_row('τ_Lap_geom (Laplace, GB 제외)', round(t_geom, 2)))
    rows.append(_dual_row_strict(TAU2_ROW_LABEL, t2_h, t2_p, fmt=lambda x: round(x, 3)))
    rows.append(_dual_row_strict(TAU_SQRT_ROW_LABEL, sq_h, sq_p, fmt=lambda x: round(x, 2)))
    if tau_dij and tau_dij > 0:
        rows.append(_dual_row_strict(TAU_RATIO_ROW_LABEL,
                                     sq_h / tau_dij if sq_h is not None else None,
                                     sq_p / tau_dij if sq_p is not None else None,
                                     fmt=lambda x: f"{x:.2f}×"))
    return rows


#  ★ 10-04 τ 결정 16 ② (1저자 비준 *"권고대로"*) — 이온 인계 열의 **상태** 두 행.  계산 = `scripts/tau_flux.py` (v2 §5-1 열 · §5-2 게이트
#    G1–G6 · 상태/메타 모드 꼬리) — 웹앱은 표시만 한다 (같은 정의 · 이름 · 한정어, J20-l).  값 행 (tau2 · √ · 비율) 은 ① 그대로.
ION_HANDOVER_STATUS_LABEL = 'tau2 인계 상태 (게이트 G1–G6 · v2 §5-2)'
ION_HANDOVER_BAND_LABEL = '띠 규칙 · 띠 폭/판 간격 (G1 · TAU-24)'
#  ★ 10-06 밤 (G2R-01 · 02 웹앱 짝 · J20-l) — 망 세대 행: 도우미 세대 칸 (`tau_flux` ion_net_generation — 공용 세대 계약 `network_generation_contract`) 을
#    같은 이름으로 (g2 · inferred_legacy (옛 세대 **추론**) · invalid (세대 계약 위반)) — 옛 세대 추론이 화면에서 보인다.
#  ★ 10-06 밤 G2RR-02 웹앱 짝 (J20-l) — 같은 계약이 수치 증서 결합 (가지 · 역할 · 채널 · 봉인 기하 · 발행값 재구성) 까지 본다 → 값 문구 · 툴팁 (single.html)
#    한정어를 맞췄다 (숫자만 바꾼 레코드는 이제 잡힌다 · 전면 위조 · 전자 · 열 채널은 밖).  라벨은 그대로 (논문 라벨 · 역맵 · test_tau_handover_status T12c).
ION_HANDOVER_GEN_LABEL = '망 세대 (세대 계약 · G2R-01 · 02)'
ION_HANDOVER_GEN_TEXT = {
    'g2': ('g2 — 세대 2 계약 통과 (주 Hertz = H0 Maxwell + 원기둥 · physics = ψ 곱 + physics_g2 · H12 민감도 · 전극 dirichlet_exact · '
           '수치 증서 결합 — 가지 · 역할 · 발행값 재구성 · G2RR-02)'),
    'inferred_legacy': ('inferred_legacy — 세대 2 표기가 하나도 없는 옛 산출물 (옛 세대로 추론: virtual_source_legacy · physics_g1 · 원기둥 · '
                        'ψ 분모 — 레코드에 적힌 값이 아니다)'),
    'invalid': 'invalid — 세대 계약 위반 (역할 · 표기 · 수치 증서 결합 — 값 인용 금지 · 사유 = 위 상태 칸) — 기술적 실패',
    '': '— (망 레코드 없음)',
}
#  ★ 10-06 밤 (G2RR-01 웹앱 짝 · J20-l) — 망 세대 행에 도장 ↔ 레코드 대조가 어긋날 때만 붙는 표지 (판정 = 인계 생성기 P4 와 같은 함수
#    `_ps.provenance_generation_problem` — g2 = 도장 네 세대 값 = 레코드에서 유도한 기대값 · inferred_legacy = 확인된 역사 도장 스키마).  일치하면
#    아무것도 붙지 않는다 (보통 화면 그대로) · 값 · 상태 칸은 바꾸지 않는다 (표시 — 그 폴더를 인계할 수 없다는 표지).
ION_HANDOVER_STAMP_BAD = '⚠ 도장 ↔ 레코드 불일치 — 인계 거부 (G2RR-01)'


def _ion_handover_stamp(results_dir, ih):
    """케이스 폴더의 활성 도장 ↔ 망 레코드 세대 대조 → '' (일치 · 대조할 세대가 아님 · 도우미 결과 없음 · 읽을 도장 없음) | 표지 문구
    (`ION_HANDOVER_STAMP_BAD`: 첫 사유).  세대 = 도우미 세대 칸 (`ion_net_generation` — 같은 dual 의 공용 세대 계약) · 대조 =
    `_ps.provenance_generation_problem` (인계 P4 와 같은 함수).  도장이 없거나 (도장 이전 옛 케이스 — 인계는 P0 이 거부) 못 읽으면 (망 활성 세대 무효
    행 — RGLR2-02 — 이 답한다) 여기서는 붙이지 않는다 (읽은 도장이 레코드와 어긋날 때만)."""
    gen = ih.get('ion_net_generation') if isinstance(ih, dict) else None
    if gen not in (_ps.NETWORK_GEN_G2, _ps.NETWORK_GEN_LEGACY) or not results_dir:
        return ''
    prov = _ps.read_network_provenance(results_dir)
    if prov.get('provenance_state') != 'valid':
        return ''
    try:
        with open(os.path.join(results_dir, 'network_conductivity_dual.json'), encoding='utf-8') as _fh:
            dual = json.load(_fh)
    except (OSError, ValueError, TypeError):
        return ''                                        # 세대 칸이 있는데 dual 을 못 읽음 — 세대 행 자체가 답한다 (여기서 짐작하지 않는다)
    probs = _ps.provenance_generation_problem(prov, dual, gen)
    if not probs:
        return ''
    why = str(probs[0]).replace('\n', ' ')
    why = why if len(why) <= 200 else why[:197] + '…'
    return f'{ION_HANDOVER_STAMP_BAD}: {why}' + (f' 외 {len(probs) - 1}' if len(probs) > 1 else '')


def _ion_handover(results_dir, metrics):
    """그 케이스의 `tau_flux.ion_columns` — dual 파일 (`network_conductivity_dual.json`) + full_metrics 장부 (L_gap · L_mc · φ_mc ·
    percolation_pct).  파일이 없거나 깨지면 도우미가 NOT_COMPUTED (missing_input) 로 답한다 (조용히 빠지지 않는다).
    도우미 자체를 못 불러오면 None (→ 화면 "미계산")."""
    try:
        import tau_flux as _tf
    except Exception:                                    # noqa: BLE001 — 표시용: 도우미 없음 = 미계산
        return None
    dual = None
    try:
        with open(os.path.join(results_dir, 'network_conductivity_dual.json'), encoding='utf-8') as _fh:
            dual = json.load(_fh)
    except (OSError, ValueError, TypeError):
        dual = None
    m = metrics if isinstance(metrics, dict) else {}
    #  ★ 10-05 RGLR2-02 — 망 활성 세대가 확정되지 않았으면 (케이스 페이지 가드의 표지 · 또는 폴더 판정) 두 모드 NOT_COMPUTED (generation_invalid)
    #    — dual 만 읽어 옛 세대 τ 를 싣지 않는다 (도우미 `tau_flux.case_row` 와 같은 덮기).
    _gp = m.get(_tf.GENERATION_PROBLEM_KEY) or _tf.network_generation_problem(results_dir, m)
    return _tf.generation_override(_tf.ion_columns(dual, m, m.get('percolation_pct')), _gp)


#  ★ 10-05 RGLR2-02 (Codex 3차 재검증 §2 · J20-l) — 읽는 쪽 fail-closed.  망 활성 세대가 **확정되지 않았으면** (`_ps.network_generation_problem` —
#    full_metrics ↔ 도장 불일치 · 되돌림 실패 기록 · 중단된 게시 흔적 · 도장 손상 — 최근 시도 기록을 못 썼어도 디스크로 가른다) full_metrics 의 망
#    소유 값 (σ · 상태 · 협착 몫 · σ₀ · 온도 — `_ps.NET_MERGE_KEYS`) 과 Stage E 값 (`_ps.is_stage_e_key`) 을 화면 · 등급 · τ 에 쓰지 않는다 (None) —
#    어느 세대의 값인지 증명할 수 없으므로 "이전 세대 값" 으로도 인용하지 않는다.  확정된 케이스는 아무것도 바꾸지 않는다 (보통 화면 그대로).
NET_GEN_PROBLEM_KEY = 'network_generation_problem'      # = tau_flux.GENERATION_PROBLEM_KEY (등급 τ getter 가 본다)


def _network_generation_guard(results_dir, metrics):
    """→ 사유 ('' = 확정 · 또는 대조할 것 없음).  사유가 있으면 metrics (제자리) 의 망 소유 · Stage E 키를 None · network_solver_status 'invalid' ·
    표지 `network_generation_problem` = 사유."""
    if not isinstance(metrics, dict) or not results_dir:
        return ''
    try:
        prob = _ps.network_generation_problem(results_dir, fm=metrics)
    except Exception as e:                                         # noqa: BLE001 — 검사 실패 = 확인 불가 = 무효 (fail-closed)
        prob = f'세대 검사 실패 ({type(e).__name__}: {e})'
    if prob:
        for k in list(metrics):
            if k in _ps.NET_MERGE_KEYS or _ps.is_stage_e_key(k):
                metrics[k] = None
        metrics['network_solver_status'] = 'invalid'
        metrics[NET_GEN_PROBLEM_KEY] = prob
    return prob


#  ★ 10-05 RGL-02 웹앱 짝 (J20-l) — 생산자 상태 valid_zero + no_through_path 의 화면 이름.  망 상태 행 · τ 인계 상태 행 (NOT_PERCOLATING) 이
#    **같은 이름**을 쓴다 (한 사건 = 한 이름).
ION_NET_NO_THROUGH_TEXT = '비관통 (관통 경로 없음)'
#  ★ 10-05 RGL-02 · 04 웹앱 짝 — 망 상태 · 세대 두 행 (생산자 · 시도 기록의 이름 그대로).
ION_NET_STATE_LABEL = 'σ_ionic 망 상태 (생산자 sigma_full_status)'
NET_ATTEMPT_LABEL = '망 최근 시도 (network_attempt — 활성 세대와 다를 때)'
#  ★ 10-05 WEB-03 Q2 웹앱 짝 (J20-l) — 최근 시도 행: 활성 세대가 있으면 "최근 재계산 실패 (사유)" · 실패 종류 (`_ps.NETWORK_FAILURE_KINDS`) 의 화면 이름
NET_RECALC_FAILED_TEXT = '최근 재계산 실패'
NET_FAILURE_KIND_TEXT = {'solver': '솔버 · 내용 검증 실패', 'lock': 'lock 미획득 (솔버 미실행)',
                         'candidate_rejected': '승격 전 검사 거부', 'publish_exception': '게시 중 예외 (되돌림)',
                         #  ★ 10-05 RGLR2-02 (Codex 3차 재검증) — 되돌림 자체가 실패 (값 무효) · 중단된 게시 흔적 격리 (재실행 필요)
                         'rollback_failed': '게시 중 예외 · 되돌림 실패 (값 무효)',
                         'interrupted_publish': '중단된 게시 흔적 격리 (재실행 필요)'}
#  ★ 10-05 RGLR2-02 웹앱 짝 (J20-l) — 망 활성 세대가 **확정되지 않았을 때만** 서는 행 (정의 = `tau_flux.network_generation_problem` · 읽는 쪽 fail-closed:
#    full_metrics ↔ 도장 불일치 · 되돌림 실패 기록 · 중단된 게시 흔적 · 도장 손상).  보통 케이스 화면은 그대로 (행 없음).
NET_GEN_INVALID_LABEL = '망 활성 세대 무효 (full_metrics ↔ 도장 · 되돌림 실패 · 중단된 게시)'
NET_GEN_INVALID_TEXT = '활성 세대 무효'
#  ★ 10-05 RGLR-01 웹앱 짝 (J20-l) — τ 인계 상태의 두 부류 (도우미 `tau_flux` 의 상태 부류 · 같은 이름)
ION_HANDOVER_TECH_TEXT = '기술적 실패'     # NOT_COMPUTED — 입력 결손 · 무효 · 솔버 관문 · 온도 짝 · 관통 불일치 · 세대 무효 (RGLR2-02) (값 없음)
ION_HANDOVER_HOLD_TEXT = '과학적 HOLD'     # BAND_FALLBACK · NOT_PERCOLATING · MODEL_BELOW_CONTINUUM_BOUND — 입력은 유효 · 등록된 규칙대로
#  ★ 10-15 L214 웹앱 짝 (J20-l) — 셋째 부류 FULL 모형 한계 (tau_flux `is_model_limit_status` — NOT_COMPUTED + 사유 정확히 full_over_conduction · 공용 판정 통과 레코드만)
ION_HANDOVER_MODEL_LIMIT_TEXT = '모형 한계'   # 기술 실패 아님 — 수치 인증 통과 · FULL q > 1.5 (사전 고정 출력 상한) · 값 미제공 · 거부된 q 와 증서 = 레코드의 증서
ION_NET_MODEL_LIMIT_TEXT = ('미계산 — FULL 모형 한계 (full_over_conduction · 수치 인증 통과 · q > 1.5 출력 상한 · 값 미제공 · 기술 실패 아님 — '
                            '거부된 q 와 증서 = 레코드 증서)')


def _ion_net_state_text(status, reason):
    """생산자 이온 σ 상태 · 사유 (`network_conductivity._net_sigma_status`) → 화면 문구 (같은 이름 · 같은 정의 — 사유 코드는 괄호에 그대로)."""
    if status == 'computed':
        return '계산됨'
    if status == 'valid_zero':
        return ION_NET_NO_THROUGH_TEXT if reason == 'no_through_path' else f'0 (valid_zero · {reason or "사유 없음"})'
    if status == 'not_computed':
        if reason == MODEL_LIMIT_REASON:              # ★ 10-15 L214 — 수치 인증 통과 · 출력 채택 거부 (기술 실패 아님)
            return ION_NET_MODEL_LIMIT_TEXT
        return ('미계산 — 관통인데 풀지 못함 (solve_failed)' if reason == 'solve_failed'
                else f'미계산 (not_computed · {reason or "사유 없음"})')
    return '—' if status is None else str(status)


def _network_generation(results_dir):
    """망 세대 표시용 — 활성 세대 (`network_provenance.json` · 성공했을 때만 갱신) + 최근 시도 (`network_attempt.json` · 성공 · 실패 모두).
    ★ 10-05 RGL-04: 승격 전 검사 (채널 · σ₀ 짝 · 망 정지 계약) 에 실패한 후보는 활성 세대를 차지하지 않는다 — 그 사실은 최근 시도에만 남는다.
    ★ 10-05 WEB-03 Q2b: 한 실패 어휘 (`_ps.network_status_view`) — active_status · latest_attempt_status · failure_kind · stale (최근 재계산이
      실패했는데 활성 세대가 있다 = 화면 값은 이전 성공 세대).  솔버 실패 · 승격 전 검사 거부 · 게시 중 예외 셋 다 같은 이름으로 읽는다.
    → {'active_run_id', 'active_status', 'attempt': dict | None, 'latest_attempt_status', 'failure_kind', 'stale'}"""
    v = _ps.network_status_view(results_dir)
    prov = _ps.read_network_provenance(results_dir)
    #  ★ 10-05 RGLR2-02 — 활성 세대가 확정되지 않았으면 (`v['active_problem']` — full_metrics ↔ 도장 불일치 · 되돌림 실패 · 중단된 게시 흔적)
    #    active_status = 'invalid' (도장의 solver_status 'success' 를 그대로 옮기지 않는다) · 사유를 함께 싣는다.
    return {'active_run_id': prov.get('network_run_id'),
            'active_status': ('invalid' if v.get('active_status') == 'invalid' else prov.get('solver_status')),
            'active_problem': v.get('active_problem') or '',
            'attempt': _ps.read_network_attempt(results_dir),
            'latest_attempt_status': v['latest_attempt_status'], 'failure_kind': v['failure_kind'], 'stale': v['stale']}


def _network_state_rows(metrics):
    """망 Solver 절의 행 (RGL-02 · 04 · RGLR2-02 웹앱 짝).
      ① 망 상태 — full_metrics 에 머지된 생산자 상태 · 사유 (hertz = sigma_full_status · physics = _physics 꼬리).  옛 세대 (상태 키 없음) = 행 없음.
      ② 최근 시도 — 라우트가 붙인 `_network_generation` 에서 최근 시도가 failed 일 때만: 'failed — <사유> · 활성 세대 <id | 없음>'.
      ③ ★ 10-05 RGLR2-02 — 활성 세대 무효 (세대 `active_problem` · 또는 케이스 페이지 가드의 표지 `network_generation_problem`) 일 때만:
         사유 · 값 인용 금지 · 재실행 필요.  그때는 ① 이 "계산됨" 이라고 · ② 가 "이전 성공 세대 그대로" 라고 말하지 않는다."""
    rows = []
    m = metrics if isinstance(metrics, dict) else {}
    gen = m.get('_network_generation')
    gen = gen if isinstance(gen, dict) else {}
    invalid = str(gen.get('active_problem') or m.get('network_generation_problem') or '').replace('\n', ' ').strip()
    if not invalid and gen.get('active_status') == 'invalid':
        invalid = '활성 세대를 확인할 수 없다 (도장 손상 · 되돌림 실패)'
    inv_short = invalid if len(invalid) <= 240 else invalid[:237] + '…'
    if m.get('sigma_full_status') is not None or m.get('sigma_full_status_physics') is not None:
        if invalid:
            _c = f'{NET_GEN_INVALID_TEXT} — 생산자 상태 인용 금지 (아래 행)'
            rows.append([ION_NET_STATE_LABEL, _c, _c, ''])
        else:
            rows.append([ION_NET_STATE_LABEL,
                         _ion_net_state_text(m.get('sigma_full_status'), m.get('sigma_full_reason')),
                         _ion_net_state_text(m.get('sigma_full_status_physics'), m.get('sigma_full_reason_physics')), ''])
    att = gen.get('attempt')
    if isinstance(att, dict) and att.get('latest_attempt_status', att.get('solver_status')) == 'failed':
        why = str(att.get('reason') or att.get('stage') or '사유 없음').replace('\n', ' ').strip()
        why = why if len(why) <= 240 else why[:237] + '…'
        act = gen.get('active_run_id')
        _k = gen.get('failure_kind') or att.get('failure_kind') or 'solver'    # 시도 기록 v1 은 `_ps.network_status_view` 가 단계로 추정
        kind = NET_FAILURE_KIND_TEXT.get(_k, str(_k))
        #  ★ 10-05 WEB-03 Q2 (J20-l) — 활성 세대가 있으면 화면 값은 **이전 성공 세대** 의 것 + "최근 재계산 실패 (사유)" · 첫 실행이면 보일 값이 없다
        #  ★ 10-05 RGLR2-02 — 단 활성 세대가 확정되지 않았으면 (되돌림 실패 · 세대 불일치) "이전 성공 세대 그대로" 라고 말하지 않는다
        if invalid:
            cell = (f"{NET_RECALC_FAILED_TEXT} ({why}) · {kind} · 시도 {att.get('network_attempt_run_id') or '?'} · "
                    f'{NET_GEN_INVALID_TEXT} (도장 {act or "없음"} · 디스크의 망 파일이 한 세대를 가리키지 않는다 — 값 인용 금지 · 재실행 필요)')
        elif act:
            cell = (f"{NET_RECALC_FAILED_TEXT} ({why}) · {kind} · 시도 {att.get('network_attempt_run_id') or '?'} · "
                    f'활성 세대 {act} 의 값 (이전 성공 세대 그대로)')
        else:
            cell = (f"재계산 실패 ({why}) · {kind} · 시도 {att.get('network_attempt_run_id') or '?'} · "
                    '활성 세대 없음 (첫 실행 실패 — 게시된 망 결과 없음)')
        rows.append([NET_ATTEMPT_LABEL, cell, cell, ''])
    if invalid:
        cell = (f'{NET_GEN_INVALID_TEXT} — {inv_short} · 망 값 (σ · 상태 · τ · Stage E) 인용 금지 · 재실행 필요 '
                '(복구 자료 = .publish_backup_* · .network_recovery/)')
        rows.append([NET_GEN_INVALID_LABEL, cell, cell, ''])
    return rows


def _ion_handover_rows(ih, stamp=''):
    """케이스 τ 블록 뒤 세 행 — [상태 (사유)] · [띠 규칙 · 띠 폭/판 간격] · [망 세대 (세대 계약)].  ih = `_ion_handover` 결과 (None = 도우미 미계산).
    stamp = `_ion_handover_stamp` 결과 (★ 10-06 밤 G2RR-01 — 도장 ↔ 레코드가 어긋날 때만 비지 않는다 · 세대 행 끝에 붙인다)."""
    if not isinstance(ih, dict):
        return [_same_row(ION_HANDOVER_STATUS_LABEL, '미계산 (도우미 결과 없음)')]

    def _st(m):
        s = ih.get(f'ion_net_status_{m}') or '—'
        r = str(ih.get(f'ion_net_status_reason_{m}') or '')
        r = r if len(r) <= 160 else r[:157] + '…'
        #  ★ 10-05 RGLR-01 (J20-l) — 기술적 실패 (NOT_COMPUTED) ↔ 등록된 과학적 HOLD (입력 유효) 를 화면에서 가른다
        if s == 'NOT_PERCOLATING':                 # ★ RGL-02 — 망 상태 행과 같은 이름 (생산자 valid_zero + no_through_path)
            return f'{s} — {ION_NET_NO_THROUGH_TEXT} · {ION_HANDOVER_HOLD_TEXT}'
        if s == 'BAND_FALLBACK':
            return f'{s} — {ION_HANDOVER_HOLD_TEXT} (입력 유효 · 띠 규칙 L0 아님 · 값 빈칸)'
        if s == 'MODEL_BELOW_CONTINUUM_BOUND':
            return f'{s} — {ION_HANDOVER_HOLD_TEXT} (입력 유효 · T < 1 · 값 유지)'
        if s == 'NOT_COMPUTED' and ih.get(f'ion_net_status_reason_{m}') == MODEL_LIMIT_REASON:     # ★ L214 — 기술 실패 문구가 아니다
            return (f'{s} ({MODEL_LIMIT_REASON}) — {ION_HANDOVER_MODEL_LIMIT_TEXT} (수치 인증 통과 · FULL q > 1.5 출력 상한 · 값 빈칸 · '
                    '기술 실패 아님)')
        if s == 'NOT_COMPUTED':
            return f'{s} ({r}) — {ION_HANDOVER_TECH_TEXT}' if r else f'{s} — {ION_HANDOVER_TECH_TEXT}'
        return f'{s} ({r})' if r else s

    def _band(m):
        r = ih.get(f'ion_net_band_rule_{m}') or ''
        f = ih.get(f'ion_net_band_frac_{m}')
        if not r:
            return '기록 없음 (안 A 전 산출물 — 망 재계산 뒤 생긴다)'
        return f'{r} · {f:.3f}' if isinstance(f, (int, float)) and not isinstance(f, bool) else r
    #  ★ 10-06 밤 (G2R-01 · 02) — 세대는 케이스 하나에 하나 (세 모드 공통) → H · P 같은 값
    g = ih.get('ion_net_generation')
    gtxt = '미계산 (세대 칸 없는 도우미 결과)' if g is None else ION_HANDOVER_GEN_TEXT.get(str(g), f'{g} — 모르는 세대 값 (기술적 실패)')
    if stamp:
        gtxt = f'{gtxt} · {stamp}'
    return [[ION_HANDOVER_STATUS_LABEL, _st('hertz'), _st('physics'), ''],
            [ION_HANDOVER_BAND_LABEL, _band('hertz'), _band('physics'), ''],
            [ION_HANDOVER_GEN_LABEL, gtxt, gtxt, '']]


def _inject_input_params(metrics, results_dir):
    """Pull am_se_ratio (and other input-side parameters needed by the
    grade engine) from input_params.json when not already in metrics.

    Also pulls box_x / box_y so the grade engine can compute the RVE
    cross-section area (μm²) — used as a finite-size noise indicator
    in the dashboard so cases that differ ONLY in RVE size (e.g.
    *_real_x  vs *_real40_x) can be grouped or filtered."""
    if not results_dir:
        return metrics
    ip_path = os.path.join(results_dir, 'input_params.json')
    if not os.path.exists(ip_path):
        return metrics
    try:
        with open(ip_path) as f:
            ip = json.load(f)
    except (OSError, ValueError):
        return metrics
    inj = {}
    ratio = ip.get('am_se_ratio') or ip.get('AM_SE_ratio')
    if ratio:
        inj['_input_am_se_ratio'] = str(ratio)
    # Box dimensions — stored in sim units; convert to μm via scale (default 1000).
    bx = ip.get('box_x'); by = ip.get('box_y')
    scale = ip.get('scale') or 1000
    try:
        if bx is not None and by is not None:
            inj['_input_box_x'] = float(bx) * float(scale)
            inj['_input_box_y'] = float(by) * float(scale)
    except (TypeError, ValueError):
        pass
    # Particle radii (sim units) — convert to μm using scale.  Used by
    # grade_engine's r_SE / λ_eff design axes.
    for k_src, k_dst in (('r_SE', '_input_r_SE_um'),
                          ('r_AM_P', '_input_r_AM_P_um'),
                          ('r_AM_S', '_input_r_AM_S_um')):
        v = ip.get(k_src) or ip.get(k_src + '_sim')
        try:
            if v is not None:
                inj[k_dst] = float(v) * float(scale)
        except (TypeError, ValueError):
            continue
    # 제작(소결) 목표압 → MPa.  ★ F-11: 필드 이름이 단위를 정한다 — 값 크기로 추정하던
    #   옛 heuristic(`< 10 이면 ×1000`)은 target_pressure_MPa 에 10 미만을 넣으면 1000 배로
    #   파손했고, 그 구간이 하필 ASSB 운전 스택압(0.2~5 MPa)이다.  scripts/press_units.py 참조.
    _tp = _press_units.target_pressure_mpa(ip)
    if _tp is not None:
        inj['_input_target_press_MPa'] = _tp
    # Mode + ps_ratio from meta.json (for bimodal vs standard detection)
    meta_path = os.path.join(os.path.dirname(results_dir),
                              os.path.basename(results_dir).replace('webapp/results','webapp/uploads')
                              if 'results' in results_dir else os.path.basename(results_dir),
                              'meta.json')
    # Cleaner: look for meta.json near results_dir
    for mp in (os.path.join(results_dir, 'meta.json'),
               os.path.join(os.path.dirname(results_dir), 'meta.json')):
        if os.path.exists(mp):
            try:
                with open(mp) as mf:
                    md = json.load(mf)
                if 'mode' in md:    inj['_meta_mode']     = md['mode']
                if 'ps_ratio' in md: inj['_meta_ps_ratio'] = md['ps_ratio']
                break
            except (OSError, ValueError):
                pass
    if not inj:
        return metrics
    return {**metrics, **inj}


def _se_aux_to_corpus_row(aux):
    """Derive a grade-corpus row (cut_fraction / bn_below_frac / bn_median_norm
    / n_percolating) from a case's viewer_aux.json — same formulas the grade
    engine uses for the case's own value (grade_engine._derived_value)."""
    n_perc = aux.get('se_n_percolating') or aux.get('n_percolating')
    apts = aux.get('se_articulation_points') or aux.get('articulation_points')
    n_cut = aux.get('se_n_articulation_points')
    if n_cut is None and isinstance(apts, list):
        n_cut = len(apts)
    nb = aux.get('se_n_bn_below_threshold')
    ne = aux.get('se_n_perc_edges')
    bmn = aux.get('se_bn_median_norm')
    if not n_perc:
        return None
    row = {'n_percolating': n_perc}
    if n_cut is not None:
        row['cut_fraction'] = n_cut / n_perc
    if nb is not None and ne:
        row['bn_below_frac'] = nb / ne
    if bmn is not None:
        row['bn_median_norm'] = bmn
    return row


_DYN_CORPUS_CACHE = {'rows': None, 'ts': 0.0}
_DYN_CORPUS_TTL = 120  # seconds — re-scan live cases at most this often


def _build_dynamic_corpus_rows(static_csv):
    """Corpus for percentile-ranked grade axes = static baseline (paper's
    se_diagnostics_82.csv) ∪ every live case's SE-diagnostics (viewer_aux.json
    under results/ + archive/).  This makes corpus-relative grades reflect the
    growing dataset and lets sparse columns (e.g. bn_below_frac) become
    scorable once ≥5 cases have them.  Cached for _DYN_CORPUS_TTL seconds."""
    import time
    now = time.time()
    if (_DYN_CORPUS_CACHE['rows'] is not None
            and now - _DYN_CORPUS_CACHE['ts'] < _DYN_CORPUS_TTL):
        return _DYN_CORPUS_CACHE['rows']

    rows = []
    if static_csv and os.path.exists(static_csv):
        try:
            with open(static_csv, newline='') as f:
                rows.extend(list(csv.DictReader(f)))
        except OSError:
            pass

    seen = set()  # dedup live cases by case-dir basename (results preferred)
    for root in (app.config.get('RESULTS_FOLDER'), app.config.get('ARCHIVE_FOLDER')):
        if not root or not os.path.isdir(root):
            continue
        for aux_path in globmod.glob(os.path.join(root, '**', 'viewer_aux.json'),
                                     recursive=True):
            cid = os.path.basename(os.path.dirname(aux_path))
            if cid in seen:
                continue
            try:
                with open(aux_path) as f:
                    aux = json.load(f)
            except (OSError, ValueError):
                continue
            r = _se_aux_to_corpus_row(aux)
            if r:
                rows.append(r)
                seen.add(cid)

    _DYN_CORPUS_CACHE['rows'] = rows
    _DYN_CORPUS_CACHE['ts'] = now
    return rows


def _grade_engine_result(metrics, results_dir=None, carbon_wt_pct=None):
    """Run scripts/grade_engine.build_overall_grade with a DYNAMIC corpus
    (static baseline ∪ live cases) + SE-diagnostics aux wired in (shared by
    the 종합 등급 table and the grade guide).  Returns the result dict or None."""
    if not metrics:
        return None
    try:
        import sys as _sys
        scripts_dir = os.path.join(os.path.dirname(__file__), '..', 'scripts')
        if scripts_dir not in _sys.path:
            _sys.path.insert(0, scripts_dir)
        from grade_engine import build_overall_grade
    except ImportError:
        return None

    static_csv = os.path.join(os.path.dirname(__file__), '..',
                              'docs', 'data', 'se_diagnostics_82.csv')
    corpus_rows = _build_dynamic_corpus_rows(static_csv)

    # Pull SE diag aux from viewer_aux.json cache if present (avoids
    # recomputing here — the 3D viewer endpoint already populated it).
    se_aux = None
    if results_dir:
        aux_path = os.path.join(results_dir, 'viewer_aux.json')
        if os.path.exists(aux_path):
            try:
                with open(aux_path) as f:
                    _aux = json.load(f)
                se_aux = {
                    'n_percolating':         _aux.get('se_n_percolating'),
                    'articulation_points':   _aux.get('se_articulation_points', []),
                    'n_bn_below_threshold':  _aux.get('se_n_bn_below_threshold'),
                    'n_perc_edges':          _aux.get('se_n_perc_edges'),
                    'bn_median_norm':        _aux.get('se_bn_median_norm'),
                }
            except (OSError, ValueError):
                pass

    #  ★ 10-05 RGLR2-02 — 등급 (τ getter 포함) 도 확정되지 않은 망 세대의 값을 쓰지 않는다 (사본에 가드 — 호출자의 metrics 는 그대로)
    if results_dir:
        metrics = dict(metrics)
        _network_generation_guard(results_dir, metrics)
    metrics = _inject_input_params(metrics, results_dir)
    return build_overall_grade(metrics, se_aux=se_aux,
                               carbon_wt_pct=carbon_wt_pct,
                               corpus_rows=corpus_rows)


def build_overall_grade_table(metrics, results_dir=None, carbon_wt_pct=None):
    """Build a 'overall_grade' table by calling scripts/grade_engine.

    Layout (4 columns) matches the other analysis-summary tabs:
        지표  |  값  |  등급  |  근거
    The 'category' label of each axis becomes a section header row
    (prefix '── … ──') so the template renders as a separator.

    When `carbon_wt_pct` is set (>0), the grade engine applies the
    What-if carbon-additive model so σ_e + ASR_electronic axes use
    the hypothetical σ_e_new.  This is what powers the live ON/OFF
    toggle in the 종합 등급 tab.

    Returns None if metrics is empty or the engine couldn't score any axis.
    """
    if not metrics:
        return None
    try:
        import sys as _sys
        scripts_dir = os.path.join(os.path.dirname(__file__), '..', 'scripts')
        if scripts_dir not in _sys.path:
            _sys.path.insert(0, scripts_dir)
        from grade_engine import GRADE_COLOR
    except ImportError:
        return None

    result = _grade_engine_result(metrics, results_dir, carbon_wt_pct)
    if result is None:
        return None

    rows = []
    last_cat = None
    for ax in result['axes']:
        if ax['category'] != last_cat:
            rows.append([f"── {ax['category']} ──"])
            last_cat = ax['category']
        v = ax['value']
        if v is None:
            val_str = '—'
        elif abs(v) >= 100:
            val_str = f"{v:.1f}"
        elif abs(v) >= 1:
            val_str = f"{v:.3g}"
        else:
            val_str = f"{v:.4g}"
        score = ax['score']
        score_str = f"{score:.0f}" if score is not None else '—'
        # 등급 cell carries colour + composite hover info via inline span
        color = GRADE_COLOR.get(ax['grade'], '#6b7280')
        grade_html = (f'<span class="grade-badge" '
                      f'style="background:{color}1f;color:{color};'
                      f'border:1px solid {color}55;border-radius:4px;'
                      f'padding:1px 6px;font-weight:600;'
                      f'font-family:ui-monospace,Menlo,monospace">'
                      f'{ax["grade"]}'
                      f'<span style="opacity:.7;font-weight:400;font-size:.85em;'
                      f'margin-left:4px">({score_str})</span></span>')
        # Hover-only basis: tooltip span — same tooltip-row mechanism in
        # single.html picks up data-tip on .metric-label.
        tip = (
            f"<b>{ax['label']}</b><br>"
            f"<span style='color:#9ca3af'>category:</span> {ax['category']}<br>"
            f"<span style='color:#9ca3af'>direction:</span> "
            f"{'higher = better' if ax['direction'] == 'higher' else 'lower = better' if ax['direction'] == 'lower' else ax['direction']}<br>"
            f"<span style='color:#9ca3af'>formula:</span> {ax['formula']}<br>"
            f"<span style='color:#9ca3af'>basis:</span> {ax['basis']}<br>"
            f"<span style='color:#9ca3af'>meaning:</span> {ax['meaning']}"
        )
        rows.append([ax['label'], val_str, grade_html, tip])

    # Composite at the bottom
    comp = result['composite']
    color = GRADE_COLOR.get(comp['grade'], '#6b7280')
    rows.append(['── 종합 ──'])
    rows.append([
        '<b>Overall (가중평균)</b>',
        f"<b>{comp['score']} / 100</b>",
        f'<span class="grade-badge" '
        f'style="background:{color}1f;color:{color};border:2px solid {color};'
        f'border-radius:5px;padding:2px 10px;font-weight:700;font-size:1.05em;'
        f'font-family:ui-monospace,Menlo,monospace">{comp["grade"]}</span>',
        f"<b>{comp['n_axes']} / {comp['n_total']} axes scored</b><br>"
        f"<span style='color:#9ca3af;font-size:.92em'>"
        f"GPA-equivalent: {comp['gpa']} / 4.3 — "
        f"axes carry weights {{1.5 (σ_ionic), 1.4 (ASR_ionic), "
        f"1.2 (활성도/percolation), 0.3 (κ)}} etc.</span>"
    ])

    # Category summary section
    rows.append(['── 카테고리 평균 ──'])
    for cat, score in result['category_scores'].items():
        from grade_engine import score_to_grade  # re-import in-scope
        g = score_to_grade(score)
        c = GRADE_COLOR.get(g, '#6b7280')
        rows.append([cat, f'{score:.1f}',
                      f'<span class="grade-badge" '
                      f'style="background:{c}1f;color:{c};border:1px solid {c}55;'
                      f'border-radius:4px;padding:1px 6px;font-weight:600;'
                      f'font-family:ui-monospace,Menlo,monospace">{g}</span>',
                      ''])

    return {
        'columns': ['지표', '값', '등급', '근거 (hover)'],
        'data':    rows,
        '_composite': comp,
        '_category_scores': result['category_scores'],
    }


def build_fracture_summary_table(metrics):
    """Build a 'fracture_summary' table from full_metrics.json keys.

    Returns a {columns, data} dict in the same format as the CSV-derived
    tables, ready to be injected into the analysis-summary tabs in
    single.html. Section-header rows start with '──' so the template
    renders them as full-width separators.

    Two-classifier display: each metric shown in both δ-based (Hertzian-
    equivalent) and force-based (Hooke-correct, model-agnostic) columns.
    Returns None if the case has no AM-AM contacts (empty metrics).
    """
    if not metrics:
        return None
    n_total = metrics.get('n_total_AM_AM') or 0
    n_total_force = metrics.get('n_total_AM_AM_force') or 0
    if n_total == 0 and n_total_force == 0:
        return None

    def f(v, prec=2):
        if v is None or v == '': return '-'
        try:
            return round(float(v), prec)
        except (TypeError, ValueError):
            return v

    rows = []

    # ── Stage distribution (%) ──
    # Older b2_b4_diagnostic.py emitted only the four damage-stage shares
    # and omitted intact (which is the implicit complement). When we backfill
    # those cases, frac_intact_pct is missing → recover as 100 minus the
    # sum of the four explicit stages so the UI shows a complete distribution.
    other_d = sum(metrics.get(f'frac_{s}_pct') or 0
                  for s in ('microcrack', 'multicrack',
                            'fragmentation', 'pulverization'))
    other_f = sum(metrics.get(f'frac_{s}_force_pct') or 0
                  for s in ('microcrack', 'multicrack',
                            'fragmentation', 'pulverization'))
    # When no damage stage fraction is positive we still want to say
    # "100 % intact" *if* the case has any AM-AM contacts at all —
    # previously the UI fell back to "-" which read as missing data.
    intact_d = (metrics.get('frac_intact_pct')
                if metrics.get('frac_intact_pct') is not None
                else (round(100.0 - other_d, 2) if other_d > 0
                      else (100.0 if (n_total or 0) > 0 else None)))
    intact_f = (metrics.get('frac_intact_force_pct')
                if metrics.get('frac_intact_force_pct') is not None
                else (round(100.0 - other_f, 2) if other_f > 0
                      else (100.0 if (n_total_force or 0) > 0 else None)))

    rows.append(['── 단계별 분포 (%) ──'])
    rows.append(['  Intact', f(intact_d), f(intact_f)])
    for stage, label in [('microcrack',    'Microcrack'),
                          ('multicrack',    'Multi-crack'),
                          ('fragmentation', 'Fragmentation'),
                          ('pulverization', 'Pulverization')]:
        d = metrics.get(f'frac_{stage}_pct')
        ff = metrics.get(f'frac_{stage}_force_pct')
        rows.append([f'  {label}', f(d), f(ff)])

    # ── Severe summary ──
    rows.append(['── Severe (frag + pulv) ──'])
    sev_d = ((metrics.get('frac_fragmentation_pct') or 0)
             + (metrics.get('frac_pulverization_pct') or 0))
    sev_f = ((metrics.get('frac_fragmentation_force_pct') or 0)
             + (metrics.get('frac_pulverization_force_pct') or 0))
    rows.append(['  Severe %',                       f(sev_d), f(sev_f)])
    rows.append(['  fracture_index (severe/total)',
                 f(metrics.get('fracture_index'),       4),
                 f(metrics.get('fracture_index_force'), 4)])

    # ── Per-pair-type severe % ──
    rows.append(['── Pair-type Severe % ──'])
    for pt in ('AM_P-AM_P', 'AM_P-AM_S', 'AM_S-AM_S'):
        n_pt = metrics.get(f'n_total_{pt}') or 0
        n_pt_force = metrics.get(f'n_total_force_{pt}') or 0
        d_sev = ((metrics.get(f'frac_fragmentation_{pt}_pct') or 0)
                 + (metrics.get(f'frac_pulverization_{pt}_pct') or 0))
        f_sev = ((metrics.get(f'frac_fragmentation_force_{pt}_pct') or 0)
                 + (metrics.get(f'frac_pulverization_force_{pt}_pct') or 0))
        if n_pt == 0 and n_pt_force == 0:
            continue
        rows.append([f'  {pt}', f(d_sev), f(f_sev)])

    # ── Per-pair-type full stage distribution (%) ──
    # b2_b4_diagnostic writes frac_{stage}_{pair}_pct and the force variant
    # frac_{stage}_force_{pair}_pct; intact% isn't stored explicitly so
    # recover it as 100 − Σ(damage stages) when at least one damage % is
    # known.  Skip pair types absent from the case (e.g. P:S = 0:10 cases
    # have no AM_P-AM_P or AM_P-AM_S contacts).
    rows.append(['── Pair-type 단계별 분포 (%) ──'])
    for pt in ('AM_P-AM_P', 'AM_P-AM_S', 'AM_S-AM_S'):
        n_pt       = metrics.get(f'n_total_{pt}')       or 0
        n_pt_force = metrics.get(f'n_total_force_{pt}') or 0
        if n_pt == 0 and n_pt_force == 0:
            continue
        rows.append([f'  [{pt}]'])
        sum_d = sum(metrics.get(f'frac_{s}_{pt}_pct') or 0
                    for s in ('microcrack', 'multicrack',
                               'fragmentation', 'pulverization'))
        sum_f = sum(metrics.get(f'frac_{s}_force_{pt}_pct') or 0
                    for s in ('microcrack', 'multicrack',
                               'fragmentation', 'pulverization'))
        intact_pt_d = (round(100.0 - sum_d, 2) if sum_d > 0 else
                        (100.0 if n_pt else None))
        intact_pt_f = (round(100.0 - sum_f, 2) if sum_f > 0 else
                        (100.0 if n_pt_force else None))
        rows.append(['    Intact',        f(intact_pt_d), f(intact_pt_f)])
        for stage, label in [('microcrack',    'Microcrack'),
                              ('multicrack',    'Multi-crack'),
                              ('fragmentation', 'Fragmentation'),
                              ('pulverization', 'Pulverization')]:
            d  = metrics.get(f'frac_{stage}_{pt}_pct')
            ff = metrics.get(f'frac_{stage}_force_{pt}_pct')
            rows.append([f'    {label}', f(d), f(ff)])

    # ── Auerbach P_c (mN) — material physics, single value per pair ──
    rows.append(['── Auerbach P_c (mN) ──'])
    for pt in ('AM_P-AM_P', 'AM_S-AM_S', 'AM_P-AM_S'):
        v = metrics.get(f'P_c_mN_median_{pt}')
        if v is None: continue
        rows.append([f'  {pt}', f(v, 3), '-'])

    # ── F_DEM medians (mN, real units) ──
    rows.append(['── F_DEM (mN, real units) ──'])
    for pt in ('AM_P-AM_P', 'AM_S-AM_S', 'AM_P-AM_S'):
        v = metrics.get(f'F_mN_median_{pt}')
        if v is None: continue
        rows.append([f'  {pt}', f(v, 3), '-'])

    # ── F / P_c ratios (key indicator) ──
    rows.append(['── F / P_c ratio ──'])
    for pt in ('AM_P-AM_P', 'AM_S-AM_S', 'AM_P-AM_S'):
        v = metrics.get(f'F_over_Pc_median_{pt}')
        if v is None: continue
        rows.append([f'  {pt}', f(v, 3), '-'])

    # ── Counts ──
    rows.append(['── Contact counts ──'])
    rows.append(['  Total AM-AM contacts',
                 int(n_total)       if n_total       else '-',
                 int(n_total_force) if n_total_force else '-'])

    return {'columns': ['지표', 'δ-based', 'Force-based ★'], 'data': rows}


def inject_tier1_patch_rows(tables, metrics):
    """Append a 'Tier 1 patches' section to network_summary listing the new
    keys added by the post-Auerbach analysis pipeline. ALWAYS emits the
    section + all 7 rows (— placeholder for cases predating the Tier-1
    pipeline) so every case has identical layout.

      Coverage  rough (B3 shape factor)        coverage_AM_*_mean_physics_rough
      SE-SE CN  perc-only         (F2)         se_se_cn_perc
      SE-SE CN  area-weighted     (F2)         se_se_cn_eff_area
      SE-SE CN  perc + area-w     (F2)         se_se_cn_eff_area_perc
      SE-SE CN  plastic-aug       (F1)         se_se_cn_aug (+ n_extra)
    """
    if 'network_summary' not in tables:
        return
    data = tables['network_summary']['data']
    if not isinstance(data, list):
        return

    section_label = '── Tier 1 patches (post-Auerbach refinements) ──'
    if any(isinstance(r, list) and r and r[0] == section_label for r in data):
        return  # already injected on a prior call

    metrics = metrics or {}

    def _fmt_num(v, prec):
        if v is None: return '—'
        try: return round(float(v), prec)
        except (TypeError, ValueError): return '—'

    rows: list = [[section_label, '', '', '']]

    # Rough coverage (B3 shape factor) — always emit all 3
    for label, key in [
        ('Coverage AM rough(%)   ⭐ [B3]',   'coverage_AM_mean_physics_rough'),
        ('Coverage AM_P rough(%) ⭐ [B3]', 'coverage_AM_P_mean_physics_rough'),
        ('Coverage AM_S rough(%) ⭐ [B3]', 'coverage_AM_S_mean_physics_rough'),
    ]:
        rows.append([label, '-', _fmt_num(metrics.get(key), 2), ''])

    # F2 / F1 CN variants — always emit all 4 + the F1 extras count
    cn_specs = [
        ('SE-SE CN (perc-only)        [F2]', 'se_se_cn_perc',          4),
        ('SE-SE CN (area-weighted)    [F2]', 'se_se_cn_eff_area',      4),
        ('SE-SE CN (perc area-w)      [F2]', 'se_se_cn_eff_area_perc', 4),
        ('SE-SE CN (plastic-augmented) [F1]', 'se_se_cn_aug',          3),
    ]
    for label, key, prec in cn_specs:
        rows.append([label, _fmt_num(metrics.get(key), prec), '-', ''])
    n_extra = metrics.get('se_se_cn_aug_n_extra')
    extra_str = int(n_extra) if (n_extra is not None
                                 and not isinstance(n_extra, bool)) else '—'
    rows.append(['  (F1 extra near-contact pairs)', extra_str, '-', ''])

    # Place after the existing AM-AM / 응력 section if present, else at the end
    anchor_idx = len(data)
    for i, r in enumerate(data):
        if (isinstance(r, list) and r and isinstance(r[0], str)
                and ('AM-AM' in r[0] or '응력' in r[0])):
            anchor_idx = i
            break
    for j, nr in enumerate(rows):
            data.insert(anchor_idx + j, nr)


def inject_stage_e_rows(tables, metrics):
    """Append a 'Stage E (literature-grounded grain corrections)' section
    showing the per-channel σ_grain factors applied + corrected σ values.

    Three orthogonal corrections (old labels "Cronau 2022 / Trevisanello 2021 / Wang 2022" were never
    checked against an original — model assumptions, SELF-51):
      σ_ionic : SE r_SE-dependent (size-invariant ≥ 0.3 μm in our range)
      σ_e     : AM crystallinity (AM_S=1.0, AM_P=0.65)
      κ       : AM crystallinity (AM_S=1.0, AM_P=0.50), SE size-invariant

    Cases predating Stage E auto-pipeline leave the keys missing → silently
    skipped. Newly analyzed cases (post-Stage-E auto-integration) populate.
    """
    if 'network_summary' not in tables or not metrics:
        return
    data = tables['network_summary']['data']
    if not isinstance(data, list):
        return

    section_label = '── Stage E (literature-grounded σ_grain corrections) ──'
    if any(isinstance(r, list) and r and r[0] == section_label for r in data):
        return  # already injected

    factors = metrics.get('stage_e_factors_used') or {}
    # Hertzian-baseline Stage E (existing)
    sigma_i_e    = metrics.get('sigma_full_mScm_stage_e')
    sigma_e_e    = metrics.get('electronic_sigma_full_mScm_stage_e')
    sigma_th_e   = metrics.get('thermal_sigma_full_mScm_stage_e')
    # Physics-baseline Stage E
    sigma_i_e_p  = metrics.get('sigma_full_mScm_stage_e_physics')
    sigma_e_e_p  = metrics.get('electronic_sigma_full_mScm_stage_e_physics')
    sigma_th_e_p = metrics.get('thermal_sigma_full_mScm_stage_e_physics')
    # ── PHANTOM σ_e SUPPRESSION (2026-05-28, v2 with fallback-aware) ────
    # If the network-solver electronic pathway didn't actually run, Stage E
    # σ_e is a Bruggeman/Trevisanello phantom fallback (e.g. 1mAh_100_2/_3
    # showed 54-68 mS/cm).  Two phantom flavors:
    #   1. raw electronic_sigma_full_mScm = missing/0  → solver didn't run
    #   2. stage_e_source['sigma_e' / 'sigma_e_physics'] = 'fallback_weighted_factor'
    #      → solver ran but Stage E filled in via Bruggeman fallback
    # Suppress BOTH so the case-detail page reads '—' for the phantom cells.
    # Same for thermal κ pathway.  Ionic σ untouched (ionic pathway hasn't
    # silently failed in the corpus).
    src_fb = metrics.get('stage_e_source') or {}
    raw_e   = metrics.get('electronic_sigma_full_mScm')
    raw_e_p = metrics.get('electronic_sigma_full_mScm_physics')
    e_hertz_phantom = (
        not (isinstance(raw_e, (int, float)) and raw_e and raw_e > 0)
        or src_fb.get('sigma_e') == 'fallback_weighted_factor'
    )
    e_phys_phantom = (
        not (isinstance(raw_e_p, (int, float)) and raw_e_p and raw_e_p > 0)
        or src_fb.get('sigma_e_physics') == 'fallback_weighted_factor'
    )
    if e_hertz_phantom:
        sigma_e_e = None
    if e_phys_phantom:
        sigma_e_e_p = None
    raw_th   = metrics.get('thermal_sigma_full_mScm')
    raw_th_p = metrics.get('thermal_sigma_full_mScm_physics')
    # ★ RC6-04: Stage E 는 더 이상 network 소유 raw 키를 덮어쓰지 않는다.  network 가
    #   baseline 을 못 냈을 때의 역산 **추정치**는 별도 키에 있고, 화면은 그것을
    #   **유도값이라고 표시하고** 쓴다 (옛 동작은 추정치를 raw 자리에 넣어 network
    #   측정값처럼 보이게 했다).  추정치조차 없으면 종전대로 '—'.
    _th_est   = metrics.get('thermal_sigma_full_mScm_stage_e_estimate')
    _th_est_p = metrics.get('thermal_sigma_full_mScm_physics_stage_e_estimate')
    th_from_estimate = False
    if not (isinstance(raw_th, (int, float)) and raw_th and raw_th > 0) and \
            isinstance(_th_est, (int, float)) and _th_est > 0:
        raw_th, th_from_estimate = _th_est, True
    if not (isinstance(raw_th_p, (int, float)) and raw_th_p and raw_th_p > 0) and \
            isinstance(_th_est_p, (int, float)) and _th_est_p > 0:
        raw_th_p, th_from_estimate = _th_est_p, True
    th_hertz_phantom = (
        not (isinstance(raw_th, (int, float)) and raw_th and raw_th > 0)
        or src_fb.get('sigma_thermal') == 'fallback_weighted_factor'
    )
    th_phys_phantom = (
        not (isinstance(raw_th_p, (int, float)) and raw_th_p and raw_th_p > 0)
        or src_fb.get('sigma_thermal_physics') == 'fallback_weighted_factor'
    )
    if th_hertz_phantom:
        sigma_th_e = None
    if th_phys_phantom:
        sigma_th_e_p = None
    if not (factors or sigma_i_e is not None or sigma_e_e is not None):
        return  # no Stage E data on this case

    src = metrics.get('stage_e_source') or {}
    src_i  = src.get('sigma_ionic',   'solver')
    src_e  = src.get('sigma_e',       'solver')
    src_th = src.get('sigma_thermal', 'solver')
    # Physics-baseline source flags (cases analyzed before Physics-Stage E
    # was added will silently default to 'solver' — UI shows '—' Physics
    # column for those, no fallback tag)
    src_i_p  = src.get('sigma_ionic_physics',   'solver')
    src_e_p  = src.get('sigma_e_physics',       'solver')
    src_th_p = src.get('sigma_thermal_physics', 'solver')
    def _src_tag(s):
        if s == 'fallback_weighted_factor':
            return ' [⚡Bruggeman fallback]'
        return ''

    rows: list = [[section_label, '', '', '']]

    # Applied factors header — size-dependent breakdown (stable labels so
    # tooltips can match; dynamic per-channel values go in value column)
    r_se = factors.get('r_SE_um')
    r_am_p = factors.get('r_AM_P_um')
    r_am_s = factors.get('r_AM_S_um')
    f_se_ionic = factors.get('f_SE_ionic')
    am_factors = factors.get('AM_factors') or {}
    kappa_factors = factors.get('kappa_factors') or {}

    if r_se is not None and f_se_ionic is not None:
        rows.append([
            '  σ_ionic — SE size factor',
            '',
            f'r_SE={r_se:.2f}μm   ×{f_se_ionic:.2f}',
            'size-invariant ≥0.5μm (model assumption)' if f_se_ionic >= 0.99
            else f'sub-μm amorphization (model assumption)'
        ])

    # σ_e correction — always emit (— placeholder for missing factors)
    am_s = am_factors.get('AM_S') if am_factors else None
    am_p = am_factors.get('AM_P') if am_factors else None
    am_s_lbl = (f'AM_S(r={r_am_s:.1f}μm)×{am_s:.2f}'
                 if am_s is not None and r_am_s else 'AM_S — n/a')
    am_p_lbl = (f'AM_P(r={r_am_p:.1f}μm)×{am_p:.2f}'
                 if am_p is not None and r_am_p else 'AM_P — n/a')
    rows.append([
        '  σ_e — AM crystal × size', '',
        f'{am_s_lbl} / {am_p_lbl}',
        'Trevisanello 2021 + size-dependent internal-GB density'
    ])

    # κ correction — always emit (— placeholder when kappa_factors missing)
    k_s  = kappa_factors.get('AM_S') if kappa_factors else None
    k_p  = kappa_factors.get('AM_P') if kappa_factors else None
    k_se = kappa_factors.get('SE')   if kappa_factors else None
    k_s_lbl  = (f'AM_S(r={r_am_s:.1f}μm)×{k_s:.2f}'
                if k_s is not None and r_am_s else 'AM_S — n/a')
    k_p_lbl  = (f'AM_P(r={r_am_p:.1f}μm)×{k_p:.2f}'
                if k_p is not None and r_am_p else 'AM_P — n/a')
    k_se_lbl = (f'SE×{k_se:.2f}' if k_se is not None else 'SE — n/a')
    rows.append([
        '  κ — AM crystal × size + SE', '',
        f'{k_s_lbl} / {k_p_lbl} / {k_se_lbl}',
        'Wang 2022 + phonon GB scatter (∝ AM secondary R)'
    ])

    # Corrected σ values — 4-col format (Hertzian | Physics | Δ%) mirroring
    # the Network Solver section. Stage E factor (Lawn × Cronau / Trev /
    # Wang) is grain-level and applies equally to both Hertzian and
    # Tabor-plastic-film baselines, so we report both side-by-side.
    def _stage_e_row(label, val_h, val_p, base_h_key, base_p_key,
                     src_h, src_p, fmt='%.4f', unit='mS/cm'):
        baseline_h = metrics.get(base_h_key)
        baseline_p = metrics.get(base_p_key)
        # Hertzian column — show value or '—' if missing
        if val_h is None:
            h_str = '—'
        else:
            h_str = f'{val_h:{fmt[1:]}}'
        # Physics column
        if val_p is None:
            p_str = '—'
        else:
            p_str = f'{val_p:{fmt[1:]}}'
        # Δ% column — Physics vs Hertzian (mode contrast, not loss-vs-baseline)
        if val_h is not None and val_p is not None and val_h:
            delta_pp = (val_p - val_h) / val_h * 100
            d_str = f'{delta_pp:+.1f}%'
        else:
            d_str = '—'
        # Source tags appended (e.g. '⚡ H-fb' if Hertzian fallback fired).
        # 2026-05-28: skip the badge when the value itself was suppressed
        # (val_h/val_p = None) — phantom indicator alongside '—' is redundant.
        tag_parts = []
        if val_h is not None and src_h == 'fallback_weighted_factor':
            tag_parts.append('H:⚡')
        if val_p is not None and src_p == 'fallback_weighted_factor':
            tag_parts.append('P:⚡')
        if tag_parts:
            d_str += '  [' + ' '.join(tag_parts) + ']'
        return [f'  {label}', h_str, p_str, d_str + f'  {unit}']

    rows.append(_stage_e_row('σ_ionic (Stage E corrected)',
                             sigma_i_e,  sigma_i_e_p,
                             'sigma_full_mScm', 'sigma_full_mScm_physics',
                             src_i,  src_i_p,
                             fmt='%.4f', unit='mS/cm'))
    rows.append(_stage_e_row('σ_electronic (Stage E corrected)',
                             sigma_e_e,  sigma_e_e_p,
                             'electronic_sigma_full_mScm',
                             'electronic_sigma_full_mScm_physics',
                             src_e, src_e_p,
                             fmt='%.3f', unit='mS/cm'))
    rows.append(_stage_e_row('σ_thermal (Stage E corrected)'
                             + (' ⚠baseline=유도추정' if th_from_estimate else ''),
                             sigma_th_e, sigma_th_e_p,
                             'thermal_sigma_full_mScm',
                             'thermal_sigma_full_mScm_physics',
                             src_th, src_th_p,
                             fmt='%.3f', unit='mS/cm equiv'))

    # Stage counts (audit trail)
    sc = metrics.get('stage_e_fracture_stage_counts')
    if sc and isinstance(sc, dict):
        n_intact = int(sc.get('intact', 0))
        n_mc     = int(sc.get('microcrack', 0))
        n_mu     = int(sc.get('multicrack', 0))
        n_fr     = int(sc.get('fragmentation', 0))
        n_pu     = int(sc.get('pulverization', 0))
        n_total  = n_intact + n_mc + n_mu + n_fr + n_pu
        if n_total:
            rows.append([
                '  Fracture stage counts (intact/MC/Multi/Frag/Pulv)',
                '',
                f'{n_intact}/{n_mc}/{n_mu}/{n_fr}/{n_pu}',
                f'Lawn 1998 force multipliers (1/3/11/32)'
            ])

    # 7-Layer solver defence summary — visible audit trail of which (channel,
    # mode) pairs used the Bruggeman fallback. Format: '(σ_ionic, σ_e) on
    # Hertzian; (κ) on Physics' for clear scope.
    fb_h = []
    fb_p = []
    if src_i  == 'fallback_weighted_factor': fb_h.append('σ_ionic')
    if src_e  == 'fallback_weighted_factor': fb_h.append('σ_e')
    if src_th == 'fallback_weighted_factor': fb_h.append('κ')
    if src_i_p  == 'fallback_weighted_factor': fb_p.append('σ_ionic')
    if src_e_p  == 'fallback_weighted_factor': fb_p.append('σ_e')
    if src_th_p == 'fallback_weighted_factor': fb_p.append('κ')
    parts = []
    if fb_h: parts.append(f"Hertzian: ({', '.join(fb_h)})")
    if fb_p: parts.append(f"Physics: ({', '.join(fb_p)})")
    if parts:
        rows.append([
            '  7-Layer solver status', '',
            'Bruggeman fallback fired — ' + '  ·  '.join(parts),
            'Paper §6 Layer-6 (commit 7a11682) — σ ≈ σ_baseline·Σ(g·f)/Σg'
        ])
    else:
        rows.append([
            '  7-Layer solver status', '',
            'Direct solver (all channels + both modes valid)',
            'Paper §6 Layer-1~4 passed all sanity checks'
        ])

    if len(rows) <= 1:
        return  # only header — nothing to add

    # Anchor at end of network_summary (after Tier 1 patches if present)
    data.extend(rows)


def inject_cell_asr_rows(tables, metrics, input_params):
    """Append a 'Cell-level ASR (Area-Specific Resistance)' section showing
    the cell-scale impedance derived from intrinsic σ via Ohm's-law slab:

        R_cathode = L_cathode / σ
        G_cathode = σ · A_RVE / L_cathode
        ASR       = L_cathode / σ        [Ω·cm²]      (per unit area)

    L_cathode (μm) comes from metrics['thickness_um'] (DEM compaction-
    measured cathode thickness — mesh-z reference).
    A_RVE (μm²) comes from input_params box_x × box_y × scale².

    For each transport channel (σ_ionic, σ_e, κ) we compute ASR for all
    three solver modes that exist in metrics:
        Hertzian (DEM-native)
        Physics (Tabor + volume conservation)
        Stage E (literature-grounded σ_grain corrections — if present)

    Reviewer-grade context: Bielefeld 2022 / Minnmann 2021 / Lee 2020 all
    report cathode-ASR (not σ alone) because experimental EIS gives R·A
    directly. Adding this row makes the σ → ASR conversion transparent
    in the same table and lets reviewers cross-check against literature
    values (typical sulfide cathode ASR_ionic ≈ 10–100 Ω·cm² @ 1 mAh/cm²
    loading, depending on σ_eff and L).
    """
    if 'network_summary' not in tables or not metrics:
        return
    data = tables['network_summary']['data']
    if not isinstance(data, list):
        return

    section_label = '── Cell-level ASR (Ohm slab: R = L_cathode / σ) ──'
    if any(isinstance(r, list) and r and r[0] == section_label for r in data):
        return

    L_um = metrics.get('thickness_um')
    if not L_um or L_um <= 0:
        return  # no cathode thickness — can't compute slab resistance

    # RVE cross-section: box_x × box_y × scale² → μm². scale comes from
    # case.scale (used elsewhere as input_params.box_x × scale to get μm).
    scale = input_params.get('scale') or 1
    box_x_um = (input_params.get('box_x') or 0) * scale
    box_y_um = (input_params.get('box_y') or 0) * scale
    A_um2 = box_x_um * box_y_um if (box_x_um and box_y_um) else None

    # Conversion factor: σ (mS/cm) → ASR (Ω·cm²)
    #   σ [mS/cm] × 1e-3 = σ [S/cm];  ASR = L [cm] / σ [S/cm]  →  Ω·cm²
    #   With L in μm: ASR_Ωcm2 = (L_um × 1e-4) / (σ_mScm × 1e-3) = L_um × 0.1 / σ_mScm
    def _asr_ohm_cm2(sigma_mScm):
        if sigma_mScm is None or sigma_mScm <= 0:
            return None
        return L_um * 0.1 / sigma_mScm   # Ω·cm² (or K·cm²/W for thermal)

    rows = [[section_label, '', '', '']]
    geom_str = (f'L_cathode = {L_um:.1f} μm   (DEM thickness)'
                + (f',   A_RVE = {A_um2:.0f} μm²' if A_um2 else ''))
    rows.append([
        '  Cathode geometry (L, A)', '', geom_str,
        'L = thickness_um (mesh-z), A = box_x × box_y × scale²',
    ])

    # Phantom σ suppression mirror — must match inject_stage_e_into_metrics
    # 2026-05-28: if the network-solver pathway didn't run OR Stage E used
    # the Bruggeman fallback, suppress the corresponding ASR Stage E cell
    # so the dashboard doesn't report ASR derived from phantom σ.
    _src_fb = metrics.get('stage_e_source') or {}
    def _is_phantom_h(raw_key, src_key):
        rv = metrics.get(raw_key)
        if not (isinstance(rv, (int, float)) and rv and rv > 0):
            return True
        return _src_fb.get(src_key) == 'fallback_weighted_factor'
    _phantom = {
        'electronic_sigma_full_mScm_stage_e':
            _is_phantom_h('electronic_sigma_full_mScm', 'sigma_e'),
        'electronic_sigma_full_mScm_stage_e_physics':
            _is_phantom_h('electronic_sigma_full_mScm_physics', 'sigma_e_physics'),
        'thermal_sigma_full_mScm_stage_e':
            _is_phantom_h('thermal_sigma_full_mScm', 'sigma_thermal'),
        'thermal_sigma_full_mScm_stage_e_physics':
            _is_phantom_h('thermal_sigma_full_mScm_physics', 'sigma_thermal_physics'),
    }

    def _row_for(label, k_h, k_p, k_eh, k_ep, unit='Ω·cm²'):
        """Hertzian / Physics + their Stage E counterparts.
        4-col layout: ASR_H | ASR_P | Δ% (Physics-vs-Hertzian, with Stage E
        side-info). Stage E ASRs (Hertzian + Physics) are reported in the
        Δ-column text so reviewers can read the full picture in one row."""
        asr_h  = _asr_ohm_cm2(metrics.get(k_h))
        asr_p  = _asr_ohm_cm2(metrics.get(k_p) if k_p else None)
        # Stage E ASRs: skip if phantom (mirrors σ-suppression upstream)
        _eh_val = None if (k_eh and _phantom.get(k_eh)) else (metrics.get(k_eh) if k_eh else None)
        _ep_val = None if (k_ep and _phantom.get(k_ep)) else (metrics.get(k_ep) if k_ep else None)
        asr_eh = _asr_ohm_cm2(_eh_val)
        asr_ep = _asr_ohm_cm2(_ep_val)
        h_str = f'{asr_h:.2f}' if asr_h is not None else '—'
        p_str = f'{asr_p:.2f}' if asr_p is not None else '—'
        # Δ% (Physics-vs-Hertzian baseline, mirrors Network Solver section)
        if asr_h and asr_p:
            d_pp = (asr_p - asr_h) / asr_h * 100
            d_str = f'{d_pp:+.1f}%'
        else:
            d_str = '—'
        # Stage E inline summary (both modes when available)
        eh_str = f'{asr_eh:.2f}' if asr_eh is not None else '—'
        ep_str = f'{asr_ep:.2f}' if asr_ep is not None else '—'
        d_str += f'   |  Stage E: H={eh_str}, P={ep_str} ({unit})'
        return [f'  {label}', h_str, p_str, d_str]

    rows.append(_row_for('ASR_ionic (Ω·cm²)',
                 'sigma_full_mScm',
                 'sigma_full_mScm_physics',
                 'sigma_full_mScm_stage_e',
                 'sigma_full_mScm_stage_e_physics',
                 unit='Ω·cm²'))
    rows.append(_row_for('ASR_electronic (Ω·cm²)',
                 'electronic_sigma_full_mScm',
                 'electronic_sigma_full_mScm_physics',
                 'electronic_sigma_full_mScm_stage_e',
                 'electronic_sigma_full_mScm_stage_e_physics',
                 unit='Ω·cm²'))
    rows.append(_row_for('ASR_thermal (K·cm²/W equiv)',
                 'thermal_sigma_full_mScm',
                 'thermal_sigma_full_mScm_physics',
                 'thermal_sigma_full_mScm_stage_e',
                 'thermal_sigma_full_mScm_stage_e_physics',
                 unit='K·cm²/W equiv'))

    if len(rows) <= 2:
        return  # nothing meaningful

    data.extend(rows)


def _suppress_phantom_sigma_rows(data, metrics, debug=False):
    """In-place suppression of σ_e / κ phantom row values.
    Called after layout normalization merges Hertz + Physics rows.
    If stage_e_source flags fallback OR raw network solver output is
    missing, replace the value cells with '—' so dashboard never shows
    Bruggeman-fallback values as if they were real solver output."""
    if debug:
        print(f"[phantom_suppress] called, data has {len(data)} rows")
        print(f"[phantom_suppress] src_fb={metrics.get('stage_e_source')}")
        print(f"[phantom_suppress] raw_e_p={metrics.get('electronic_sigma_full_mScm_physics')}")
        # show σ_e/κ-like rows
        for i, r in enumerate(data):
            if r and len(r) >= 1 and isinstance(r[0], str):
                lbl = r[0]
                if ('σ_e' in lbl or 'σ_electronic' in lbl or
                    'κ' in lbl or 'σ_thermal' in lbl or 'electronic' in lbl):
                    print(f"[phantom_suppress] row {i}: {r}")
    src_fb = metrics.get('stage_e_source') or {}
    p_e_h = (src_fb.get('sigma_e') == 'fallback_weighted_factor'
             or not metrics.get('electronic_sigma_full_mScm'))
    p_e_p = (src_fb.get('sigma_e_physics') == 'fallback_weighted_factor'
             or not metrics.get('electronic_sigma_full_mScm_physics'))
    p_th_h = (src_fb.get('sigma_thermal') == 'fallback_weighted_factor'
              or not metrics.get('thermal_sigma_full_mScm'))
    p_th_p = (src_fb.get('sigma_thermal_physics') == 'fallback_weighted_factor'
              or not metrics.get('thermal_sigma_full_mScm_physics'))
    LABEL_PHANTOM = {
        'σ_electronic (mS/cm)':                              (p_e_h, p_e_p, 'electronic'),
        'σ_e — electronic conductivity (mS/cm)':             (p_e_h, p_e_p, 'electronic'),
        'σ_electronic [physics] (mS/cm)':                    (p_e_h, p_e_p, 'electronic'),
        'σ_e^physics — Tabor plastic film (mS/cm)':          (p_e_h, p_e_p, 'electronic'),
        'σ_thermal (mS/cm equiv)':                           (p_th_h, p_th_p, 'thermal'),
        'κ — thermal conductivity (mS/cm equiv)':            (p_th_h, p_th_p, 'thermal'),
        'σ_thermal [physics] (mS/cm equiv)':                 (p_th_h, p_th_p, 'thermal'),
        'κ^physics — Tabor plastic film (mS/cm equiv)':      (p_th_h, p_th_p, 'thermal'),
    }
    for r in data:
        if not r or not isinstance(r, list) or len(r) < 2: continue
        lbl = str(r[0]).strip() if r[0] else ''
        if lbl not in LABEL_PHANTOM: continue
        h_phantom, p_phantom, _chan = LABEL_PHANTOM[lbl]
        if len(r) >= 2 and h_phantom: r[1] = _mode_missing_text(metrics, _chan, 'hertz')
        #  ★ 10-15 L214-03 — Physics 칸의 '—' 에 사유 (그 채널 Physics FULL 모형 한계면 그 이름 · 그 밖 '—' 그대로)
        if len(r) >= 3 and p_phantom: r[2] = _mode_missing_text(metrics, _chan)
        if len(r) >= 4 and (h_phantom or p_phantom): r[3] = '—'


def normalize_network_summary_layout(tables, metrics):
    """Final structural normalizer — guarantees every case has identical
    row placement regardless of network_summary.csv vintage. Different
    analyze_contacts.py versions produced different CSV layouts:

      • Old format: SPLIT '── Network Solver (Hertzian) ──' AND
        '── Physics (Plastic film, Tabor+volume) ──' as two sections.
        Each row only fills col 2 OR col 3 — wastes the Δ% column.
      • New format: COMBINED '── Network Solver (DEM-native vs
        Tabor+volume physics) ──' single section with proper 4-col
        Hertzian | Physics | Δ% layout.
      • Some old cases also have σ_e missing, κ in wrong section,
        σ_Bruggeman duplicated, etc.

    This pass runs AFTER all injectors, BEFORE paper-label rename:
      Pass A: merge split Hertzian + Physics sections into one combined
              section (4-col format: Hertzian | Physics | Δ%).
      Pass B: relocate σ_electronic / σ_thermal rows that ended up under
              '── τ 비교 ──' back to network solver section.
      Pass C: de-duplicate σ_Bruggeman.
      Pass D: insert σ_e baseline row if missing (using metrics value or 0).
      Pass G (★ 10-16 L214R-03): after the merge / always-emit rows / sort — the current per-mode network
              status wins: an unaccepted mode (FULL model limit · no σ · not_computed · valid_zero) shows
              '—' (+ reason) in the ionic σ and FULL-derived ratio rows, Δ '—' (old CSV numbers never return).
              (★ 10-16 WEB-09) before that, an accepted mode's cells in those rows are rewritten from the
              current metrics with the new-table builders (_ion_*_row) — old CSV numbers never stay either.
    """
    if 'network_summary' not in tables:
        return
    data = tables['network_summary']['data']
    if not isinstance(data, list) or not data:
        return

    SIGMA_LABELS = {
        'σ_electronic (mS/cm)',
        'σ_thermal (mS/cm equiv)',
        'σ_electronic [physics] (mS/cm)',
        'σ_thermal [physics] (mS/cm equiv)',
    }

    def _is_section_hdr(label):
        return isinstance(label, str) and label.strip().startswith('──')

    def _section_of(idx):
        for j in range(idx - 1, -1, -1):
            r = data[j]
            if r and isinstance(r[0], str) and _is_section_hdr(r[0]):
                return r[0].strip()
        return None

    # ── Pass A: merge split Hertzian + Physics sections into combined ──
    # Pre-rename headers we look for:
    HERT_HDR = '── Network Solver (Hertzian DEM-native) ──'
    PHYS_HDR = '── Physics (Plastic film, Tabor+volume) ──'
    COMBINED_HDR = '── Network Solver (DEM-native vs Tabor+volume physics) ──'

    hert_idx = phys_idx = None
    for i, r in enumerate(data):
        if not r or not isinstance(r[0], str): continue
        lbl = r[0].strip()
        if lbl == HERT_HDR and hert_idx is None: hert_idx = i
        elif lbl == PHYS_HDR and phys_idx is None: phys_idx = i

    if hert_idx is not None and phys_idx is not None and phys_idx > hert_idx:
        # Find Physics section end (next section header or end-of-data)
        phys_end = len(data)
        for j in range(phys_idx + 1, len(data)):
            rr = data[j]
            if rr and isinstance(rr[0], str) and _is_section_hdr(rr[0]):
                phys_end = j
                break
        physics_rows = data[phys_idx + 1:phys_end]

        # Pair (Physics-row → Hertzian-row) labels for value merging
        PAIRS = {
            'σ_ionic [physics] (mS/cm)':                   'σ_ionic (mS/cm)',
            'σ_electronic [physics] (mS/cm)':              'σ_electronic (mS/cm)',
            'σ_thermal [physics] (mS/cm equiv)':           'σ_thermal (mS/cm equiv)',
        }
        pair_values = {}     # {hert_label: physics_value_str}
        standalone_rows = [] # rows in Physics section that are dual-mode (e.g. plastic amp)
        for r in physics_rows:
            if not r or not isinstance(r[0], str): continue
            lbl = r[0].strip()
            if lbl in PAIRS:
                phys_v = r[2] if len(r) > 2 and r[2] not in ('', '-') else r[1]
                pair_values[PAIRS[lbl]] = phys_v
            else:
                standalone_rows.append(r)

        # Update Hertzian-section rows: set Physics col + Δ%
        # (Hertzian section spans hert_idx+1 to phys_idx)
        for hi in range(hert_idx + 1, phys_idx):
            r = data[hi]
            if not r or not isinstance(r[0], str): continue
            lbl = r[0].strip()
            if lbl not in pair_values: continue
            phys_v = pair_values[lbl]
            try:
                h = float(str(r[1]).replace(',', ''))
                p = float(str(phys_v).replace(',', ''))
                r[2] = phys_v
                r[3] = f'{(p - h) / h * 100:+.1f}%' if h else '0%'
            except (ValueError, TypeError):
                r[2] = phys_v

        # Move standalone Physics rows (plastic amp, contact-free, etc.)
        # to the end of the Hertzian section (i.e., right before phys_idx)
        # while still preserving their Hertzian-vs-Physics 4-col content.
        # Insert at phys_idx (which is now the end-of-Hertzian boundary).
        for sr in standalone_rows:
            data.insert(phys_idx, sr)
            phys_idx += 1

        # Now delete the entire Physics section (header + remaining rows)
        # — but recompute phys_idx since we just inserted standalone rows.
        for i, r in enumerate(data):
            if r and isinstance(r[0], str) and r[0].strip() == PHYS_HDR:
                # Find end of physics section
                pe = len(data)
                for j in range(i + 1, len(data)):
                    rr = data[j]
                    if rr and isinstance(rr[0], str) and _is_section_hdr(rr[0]):
                        pe = j; break
                del data[i:pe]
                break

        # Rename Hertzian header to combined header
        for i, r in enumerate(data):
            if r and isinstance(r[0], str) and r[0].strip() == HERT_HDR:
                r[0] = COMBINED_HDR
                break

    # ── Phantom σ_e / κ suppression (v6 final, 2026-05-28) ──
    # Run AFTER Hertz+Physics merge so we suppress in the unified row.
    # Catches phantom values written from Bruggeman fallback into the raw
    # network solver keys (e.g. 1mAh_100_2 σ_e=61.83).
    _suppress_phantom_sigma_rows(data, metrics)

    # ── Pass B: relocate σ rows wrongly stuck in τ section ──
    misplaced = []
    for i, r in enumerate(data):
        if not r or not isinstance(r, list): continue
        lbl = r[0] if r else None
        if not isinstance(lbl, str): continue
        if lbl.strip() not in SIGMA_LABELS: continue
        sec = _section_of(i)
        if sec and ('τ 비교' in sec or 'Tortuosity comparison' in sec
                    or 'Dijkstra vs Laplace' in sec):
            misplaced.append(i)

    if misplaced:
        moved_rows = [data[i] for i in misplaced]
        for i in reversed(misplaced):
            data.pop(i)
        tau_idx = None
        for i, r in enumerate(data):
            if r and isinstance(r[0], str) and (
                'τ 비교' in r[0] or 'Tortuosity comparison' in r[0]
                or 'Dijkstra vs Laplace' in r[0]):
                tau_idx = i; break
        if tau_idx is not None:
            for m in reversed(moved_rows):
                data.insert(tau_idx, m)

    # ── Pass C: de-duplicate σ_Bruggeman ──
    seen_bruggeman = False
    drop_indices = []
    for i, r in enumerate(data):
        if not r or not isinstance(r, list): continue
        lbl = r[0] if r else None
        if not isinstance(lbl, str): continue
        if lbl.strip() == 'σ_Bruggeman (mS/cm)':
            if seen_bruggeman:
                drop_indices.append(i)
            else:
                seen_bruggeman = True
    for i in reversed(drop_indices):
        data.pop(i)

    # ── Pass E: insert placeholder rows for layout consistency ──
    # Some rows are bimodal-only (AM-SE CN sub-rows, AM Vulnerable sub-rows),
    # particle-type-specific (Coverage AM_P/AM_S, von-Mises stress ratios),
    # or path-dependent (R_brug, Plastic amplification). Insert — placeholders
    # so all 160 cases have the same row count + order.
    def _label_at(idx):
        r = data[idx] if 0 <= idx < len(data) else None
        if r and isinstance(r[0], str): return r[0].strip()
        return ''

    def _find_row(label):
        for i, r in enumerate(data):
            if r and isinstance(r[0], str) and r[0].strip() == label:
                return i
        return None

    def _insert_after(anchor_label, new_row):
        ai = _find_row(anchor_label)
        if ai is None: return False
        # Skip past any existing children (rows starting with ├ or └)
        j = ai + 1
        while j < len(data):
            r = data[j]
            if not r or not isinstance(r[0], str): break
            stripped = r[0].lstrip()
            if not (stripped.startswith('├') or stripped.startswith('└')):
                break
            if stripped == new_row[0].lstrip():
                return True  # already present — nothing to do
            j += 1
        data.insert(j, new_row)
        return True

    # AM-SE CN sub-rows (always emit ├ AM_P-SE / ├ AM_S-SE / └ surface-weighted)
    for child_label in ('  ├ AM_P-SE CN mean',
                        '  ├ AM_S-SE CN mean',
                        '  └ AM-SE CN (surface-weighted)'):
        if _find_row(child_label) is None:
            _insert_after('AM-SE CN mean', [child_label, '—', '—', '0%'])

    # AM Vulnerable sub-rows (├ AM_P Vulnerable / └ AM_S Vulnerable)
    for child_label in ('  ├ AM_P Vulnerable(%)',
                        '  └ AM_S Vulnerable(%)'):
        if _find_row(child_label) is None:
            _insert_after('AM Vulnerable(%)', [child_label, '—', '—', '0%'])

    # v1.1 ①② (1저자 비준 10-01 · J20-l) — 경로 기준 고립 = 100 − 활성 · 그 분해.  옛 세대 CSV 는 줄이 없다:
    #   부모는 metrics 의 am_ionic_isolated_pct (없으면 100 − ionic_active_pct) · 분해 두 줄은 키가 있을 때만 값, 없으면 — (0 으로 안 채움)
    if _find_row('Ionic Isolated AM(%)') is None and _find_row('Ionic Active AM(%)') is not None:
        _iso = metrics.get('am_ionic_isolated_pct') if metrics else None
        if not isinstance(_iso, (int, float)):
            _act = metrics.get('ionic_active_pct') if metrics else None
            _iso = (100.0 - _act) if isinstance(_act, (int, float)) else None
        _v = f'{_iso:.1f}' if isinstance(_iso, (int, float)) else '—'
        _insert_after('Ionic Active AM(%)', ['Ionic Isolated AM(%)', _v, _v, '0%'])
    for child_label, _key in (('  ├ Isolated: SE not linked(%)', 'ionic_dead_pct'),
                              ('  └ Isolated: no SE contact(%)', 'ionic_no_se_pct')):
        if _find_row(child_label) is None and _find_row('Ionic Isolated AM(%)') is not None:
            _x = metrics.get(_key) if metrics else None
            _v = f'{_x:.1f}' if isinstance(_x, (int, float)) else '—'
            _insert_after('Ionic Isolated AM(%)', [child_label, _v, _v, '0%'])

    # Coverage AM_P / AM_S — always emit even when particle type absent
    if _find_row('Coverage AM_P(%)') is None:
        _insert_after('SE-SE Total(μm²)',
                      ['Coverage AM_P(%)', '—', '—', '0%'])
    if _find_row('Coverage AM_S(%)') is None:
        # Insert after Coverage AM_P (or after SE-SE Total if AM_P just added)
        anchor = 'Coverage AM_P(%)' if _find_row('Coverage AM_P(%)') else 'SE-SE Total(μm²)'
        _insert_after(anchor, ['Coverage AM_S(%)', '—', '—', '0%'])

    # von-Mises stress ratio rows — always emit AM_P / AM_S / SE
    #   (옛 네 줄 = LIGGGHTS stress/atom 접촉 virial 50/50 분할 · 대각 성분 — 값 그대로 · 이름표는 _PAPER_LABEL_MAP · LHS-29)
    for label in ('σ_AM_P/σ_mean', 'σ_AM_S/σ_mean', 'σ_SE/σ_mean'):
        if _find_row(label) is None:
            _insert_after('Stress CV(%)', [label, '—', '—', '0%'])
    #  ★ LHS-33 (좁은 개정 · 1저자 비준 10-05 · Codex Q7 · J20-l) — 옛 네 줄이 무효 · 미정의 (stress_cv_status ≠ computed) 면 값 '—' +
    #    상태 줄 (상태 — 사유) · None · 0 으로 보이지 않게.  옛 세대 (상태 키 없음) · computed 는 그대로.  철자 · 사유 = metrics_json 한 곳.
    from metrics_json import stress_cv_reason as _scv_reason, STRESS_CV_STATUS_ROW as _SCV_ROW
    _scv = _scv_reason(metrics) if metrics else None
    if _scv is not None and (_find_row('Stress CV(%)') is not None or _insert_after('── 응력 ──', ['Stress CV(%)', '—', '—', ''])):
        for _lab in ('σ_SE/σ_mean', 'σ_AM_S/σ_mean', 'σ_AM_P/σ_mean', 'Stress CV(%)'):
            _j = _find_row(_lab)
            if _j is None:
                _insert_after('Stress CV(%)', [_lab, '—', '—', ''])
            else:
                data[_j] = [data[_j][0], '—', '—', '']
        _j = _find_row(_SCV_ROW)
        if _j is None:
            _insert_after('σ_SE/σ_mean', [_SCV_ROW, _scv, _scv, ''])
        else:
            data[_j] = [data[_j][0], _scv, _scv, '']

    # ④a (J20-s · 1저자 비준 10-04 · LHS-30) — 협착 두 행.  두 경로 (Step 4 · 4b) 가 다 지나는 여기서 한 번만.
    #   ① 옛 행 'Constriction 비율(%)' (조회 키 그대로 · 값 정의 그대로 = 1 − 접촉별 R_bulk/R_total 비가중 평균 · L2-08):
    #      CSV 세대 (Step 4b) 는 physics 칸에 Hertz 값이 복사돼 있었다 → metrics 로 두 칸을 다시 쓴다 · physics 없으면 '—' (TAU-21 규칙).
    #   ② 새 행 'Constriction 전력 몫 (I²R · %)' = 같은 FULL 해의 Σ I²R_c / Σ I²R_total × 100 (관통 간선) · 값 없으면 '—'.
    def _num_or_none(x):
        return float(x) if isinstance(x, (int, float)) and not isinstance(x, bool) and x == x else None
    _ri = _find_row('Constriction 비율(%)')
    if _ri is not None and metrics:
        _bfh = _num_or_none(metrics.get('bulk_resistance_fraction'))
        _bfp = _num_or_none(metrics.get('bulk_resistance_fraction_physics'))
        _ch = round((1 - _bfh) * 100, 1) if _bfh is not None else data[_ri][1]
        _cp = round((1 - _bfp) * 100, 1) if _bfp is not None else '—'
        data[_ri] = [data[_ri][0], _ch, _cp,
                     _pct_delta((1 - _bfh) * 100 if _bfh is not None else None, (1 - _bfp) * 100 if _bfp is not None else None)
                     if _bfp is not None else '']
    if _ri is not None and _find_row('Constriction 전력 몫 (I²R · %)') is None:
        _cph = _num_or_none(metrics.get('constriction_power_share_ion_hertz')) if metrics else None
        _cpp = _num_or_none(metrics.get('constriction_power_share_ion_physics')) if metrics else None
        _insert_after('Constriction 비율(%)', [
            'Constriction 전력 몫 (I²R · %)',
            round(100 * _cph, 1) if _cph is not None else '—',
            round(100 * _cpp, 1) if _cpp is not None else '—',
            _pct_delta(_cph, _cpp) if (_cph is not None and _cpp is not None) else ''])

    # ④b Love–Weber 줄 (J20-s · 1저자 비준 10-04) — 항상 낸다 (모든 케이스 같은 줄 · 값 없으면 '—' · 0 으로 안 채움).
    #   새 세대 CSV (analyze_contacts) 는 상태 OK 일 때 값 줄을 이미 쓴다 → 없는 줄만 metrics 에서 채운다.
    #   상태 줄이 '—' 의 이유를 말한다 (재분석 전 · 열 없음 · FAILED 사유).  자리는 Pass F 정렬 표가 옛 줄 뒤로 잡는다.
    if _find_row('Stress CV(%)') is not None or _find_row('── 응력 ──') is not None:
        _lw_ok = bool(metrics) and metrics.get('stress_lw_status') == 'OK'

        def _lw_num(key, nd):
            x = metrics.get(key) if (metrics and _lw_ok) else None
            return f'{x:.{nd}f}' if isinstance(x, (int, float)) and not isinstance(x, bool) and x == x else '—'
        _lw_rows = [('Stress CV — Love–Weber (%)', _lw_num('stress_cv_lw', 1))]
        _lw_rows += [(f'σ_{p}/σ_mean — Love–Weber', _lw_num(f'stress_ratio_{p}_lw', 3)) for p in ('AM_P', 'AM_S', 'SE')]
        _lw_rows += [('Stress CV — Love–Weber · 벽 접촉 제외 (%)', _lw_num('stress_cv_lw_nowall', 1))]
        _lw_rows += [(f'σ_{p}/σ_mean — Love–Weber · 벽 접촉 제외', _lw_num(f'stress_ratio_{p}_lw_nowall', 3))
                     for p in ('AM_P', 'AM_S', 'SE')]
        _fr = []
        for p in ('AM_P', 'AM_S', 'SE'):
            x = metrics.get(f'stress_lw_wall_frac_{p}') if (metrics and _lw_ok) else None
            if isinstance(x, (int, float)) and not isinstance(x, bool) and x == x:
                _fr.append(f'{p} {100 * x:.1f}')
        _lw_rows.append(('벽 접촉 입자 (%) — 바닥 · 판', ' · '.join(_fr) if _fr else '—'))
        _st = metrics.get('stress_lw_status') if metrics else None
        #  RGL-06 (10-05) — 계약 v2 표지 (stress_lw_contract) 가 없는 OK = 입력 검증 전 세대 (10-04 판): 반경 NaN · 판 높이 NaN ·
        #  무하중이 거짓 OK · 거짓 0 일 수 있었다 → 값은 그대로 보여 주되 상태 줄이 말한다.  UNDEFINED (무하중) 는 사유 그대로.
        if _st == 'OK' and not metrics.get('stress_lw_contract'):
            _st = 'OK — 입력 검증 전 세대 (계약 v1 · RGL-06 이전 — 입력 무효 · 무하중이 거짓 OK 일 수 있었다) · 재분석 권장'
        _nws = metrics.get('stress_lw_nowall_status') if metrics else None
        if _lw_ok and _nws and _nws != 'OK':              # 벽 제외 줄이 '—' 인 이유 (선별 모집단 비었음 · 평균 VM 0 · mesh 판 없음)
            _st = f'{_st} · 벽 제외: {_nws}'
        _lw_rows.append(('Love–Weber 상태 (④b · LHS-29)',
                         str(_st) if _st else 'NOT_COMPUTED (재분석 전 케이스 — 접촉 단계 재실행 필요)'))
        _anchor = next((a for a in ('σ_SE/σ_mean', 'σ_AM_S/σ_mean', 'σ_AM_P/σ_mean', 'Stress CV(%)', '── 응력 ──')
                        if _find_row(a) is not None), None)
        for _lab, _val in _lw_rows:
            if _find_row(_lab) is None and _anchor is not None:
                _txt = _lab in ('벽 접촉 입자 (%) — 바닥 · 판', 'Love–Weber 상태 (④b · LHS-29)')
                _insert_after(_anchor, [_lab, _val, _val, '' if _txt else '0%'])
                _anchor = _lab

    # R_brug + Plastic amplification — always emit
    #  ★ 10-15 L214-03 — R_brug Physics 칸 = Physics 의 CF/FULL (옛: Hertz 값 복사 · Δ 0 %) · 없으면 '—' (+ 모형 한계 사유)
    #  ★ 10-16 WEB-09 — 두 행의 식 = `_ion_r_brug_row` · `_ion_plastic_amp_row` (Pass G 의 채택 모드 갱신과 한 곳 · 식 그대로 옮김)
    if _find_row('R_brug (과대추정 배수)') is None:
        _insert_after('σ_ionic (mS/cm)', _ion_r_brug_row(metrics))
    if _find_row('σ_ionic ratio (physics/Hertzian)') is None:
        _insert_after('σ_ionic (mS/cm)', _ion_plastic_amp_row(metrics))

    # ── Pass D: ensure σ_e and κ baseline rows exist ──
    # Some legacy/freshly-analysed cases write σ_e or κ as None when the
    # respective channel was numerically zero. We still want a placeholder
    # row for layout uniformity (audit-ui = 1 variant goal).
    def _ensure_baseline_row(label, h_key, p_key, fmt='%.2f', chan='electronic'):
        # full_metrics.json is the source of truth for these baseline σ values.
        # Render None (solver returned no value — didn't converge / didn't
        # percolate) as '—' so "not computed" is visually distinct from a
        # genuine ~0.  Refresh any pre-existing (possibly stale) CSV row from
        # metrics rather than leaving a misleading '0.00'.
        h_val = metrics.get(h_key) if metrics else None
        p_val = metrics.get(p_key) if metrics else None
        h_str = f'{h_val:{fmt[1:]}}' if h_val else '—'
        if p_val is not None:
            p_str = f'{p_val:{fmt[1:]}}'
            d_str = f'{(p_val - h_val) / h_val * 100:+.1f}%' if h_val else '0%'
        else:
            #  ★ 10-15 L214-03 — Physics 값이 없으면 Physics 칸 '—' (+ 모형 한계 사유) · Δ '—' (옛: Hertz 값 복사 · Δ 0 %)
            p_str = _mode_missing_text(metrics, chan)
            d_str = '—'
        new_cells = [h_str, p_str, d_str]
        for r in data:
            if (isinstance(r, list) and r and isinstance(r[0], str)
                    and r[0].strip() == label and len(r) >= 4):
                r[1], r[2], r[3] = new_cells
                return
        new_row = [label, *new_cells]
        tau_idx = None
        for i, r in enumerate(data):
            if r and isinstance(r[0], str) and (
                'τ 비교' in r[0] or 'Tortuosity comparison' in r[0]
                or 'Dijkstra vs Laplace' in r[0]):
                tau_idx = i; break
        if tau_idx is not None:
            data.insert(tau_idx, new_row)
        else:
            data.append(new_row)

    _ensure_baseline_row('σ_electronic (mS/cm)',
                         'electronic_sigma_full_mScm',
                         'electronic_sigma_full_mScm_physics', fmt='%.2f', chan='electronic')
    _ensure_baseline_row('σ_thermal (mS/cm equiv)',
                         'thermal_sigma_full_mScm',
                         'thermal_sigma_full_mScm_physics', fmt='%.3f', chan='thermal')

    # ── Pass F: sort rows within each section by canonical order ──
    # All 160 cases now have identical row CONTENT after passes A-E, but
    # different injection paths leave them in inconsistent ORDER. This
    # final pass enforces a single canonical ordering.
    _CANONICAL_ROW_ORDER = [
        # 구조
        'Porosity(%)', '전극두께(μm)',
        # 계면
        'AM-SE Total(μm²)', 'SE-SE Total(μm²)',
        'Binding % — AM-SE (H/L/T/V/G)', 'Binding % — Total (H/L/T/V/G)',
        'Coverage AM_P(%)', 'Coverage AM_S(%)',
        # 이온경로 · 연결성
        'SE-SE CN mean', 'SE-SE CN std', 'SE Cluster 수',
        'SE Percolation(%)', 'Top Reachable(%)',
        # 이온경로 · 경로 효율
        'Tortuosity mean', 'Tortuosity median', 'Tortuosity std',
        'GB Density(hops/μm)',
        # 이온경로 · 경로 품질
        'Path Hop Area mean(μm²)', 'Path Bottleneck(μm²)', 'Path Conductance(μm²)',
        # 활성도
        'AM-SE CN mean',
        '├ AM_P-SE CN mean', '├ AM_S-SE CN mean',
        '└ AM-SE CN (surface-weighted)',
        'Ionic Active AM(%)',
        'Ionic Isolated AM(%)', '├ Isolated: SE not linked(%)', '└ Isolated: no SE contact(%)',   # v1.1 ①②
        'AM Vulnerable(%)',
        '├ AM_P Vulnerable(%)', '└ AM_S Vulnerable(%)',
        # 이온전도 (Bruggeman EMT)
        'SE Volume Fraction', 'σ_Bruggeman (mS/cm)',
        'σ_brug/σ_grain (Bruggeman)',
        # Network Solver — combined Hertzian vs Physics
        'σ_ionic (mS/cm)',
        'σ_ionic 망 상태 (생산자 sigma_full_status)',            # 10-05 RGL-02 — 증명된 비관통 · 관통인데 못 풂 · 계산됨
        '망 최근 시도 (network_attempt — 활성 세대와 다를 때)',   # 10-05 RGL-04 — 승격 전 검사 실패 후보 (활성 아님)
        '망 활성 세대 무효 (full_metrics ↔ 도장 · 되돌림 실패 · 중단된 게시)',   # 10-05 RGLR2-02 — 확정되지 않은 세대일 때만
        'R_brug (과대추정 배수)',
        'σ_ionic ratio (physics/Hertzian)',
        'Constriction 비율(%)',
        'Constriction 전력 몫 (I²R · %)',       # ④a 10-04 — 같은 FULL 해의 Σ I²R_c / Σ I²R_total
        'σ_electronic (mS/cm)',
        'σ_thermal (mS/cm equiv)',
        'Contact-free / Full',
        'σ_brug / σ_ionic',
        # τ 비교
        'τ_Dij (Dijkstra, 기하만)',
        'τ_Dij,all (Dijkstra 전체, 기하만)',
        'τ_Lap_geom (Laplace, GB 제외)',
        'tau2 = φ·σ₀/σ_full (tortuosity factor · 협착 포함)',
        'τ_Lap,eff = √tau2 (Laplace · 협착 포함)',
        'τ_Lap,eff / τ_Dij (정의가 다른 두 τ 의 비)',
        'tau2 인계 상태 (게이트 G1–G6 · v2 §5-2)',
        '띠 규칙 · 띠 폭/판 간격 (G1 · TAU-24)',
        '망 세대 (세대 계약 · G2R-01 · 02)',
        'AM Percolation (%)',
        'Electronic Active AM (%)',
        # Tier-1
        'Coverage AM rough(%)   ⭐ [B3]',
        'Coverage AM_P rough(%) ⭐ [B3]',
        'Coverage AM_S rough(%) ⭐ [B3]',
        'SE-SE CN (perc-only)        [F2]',
        'SE-SE CN (area-weighted)    [F2]',
        'SE-SE CN (perc area-w)      [F2]',
        'SE-SE CN (plastic-augmented) [F1]',
        '(F1 extra near-contact pairs)',
        # AM-AM
        'AM-AM CN mean', 'AM-AM 접촉 수',
        '접촉 반경(µm)', '침투 깊이 δ(µm)', '법선력(µN)',
        '접촉 압력(MPa)', 'Hop 거리(µm)',
        # 응력 — 옛 네 줄 (stress/atom 50/50 · 대각) → ④b Love–Weber (10-04)
        'Stress CV(%)',
        'σ_AM_P/σ_mean', 'σ_AM_S/σ_mean', 'σ_SE/σ_mean',
        'Stress CV 상태 (50/50 · LHS-33)',      # 10-05 LHS-33 — 옛 네 줄이 무효 · 미정의일 때만 (상태 — 사유)
        'Stress CV — Love–Weber (%)',
        'σ_AM_P/σ_mean — Love–Weber', 'σ_AM_S/σ_mean — Love–Weber', 'σ_SE/σ_mean — Love–Weber',
        'Stress CV — Love–Weber · 벽 접촉 제외 (%)',
        'σ_AM_P/σ_mean — Love–Weber · 벽 접촉 제외', 'σ_AM_S/σ_mean — Love–Weber · 벽 접촉 제외',
        'σ_SE/σ_mean — Love–Weber · 벽 접촉 제외',
        '벽 접촉 입자 (%) — 바닥 · 판',
        'Love–Weber 상태 (④b · LHS-29)',
        # Stage E
        'σ_ionic — SE size factor',
        'σ_e — AM crystal × size',
        'κ — AM crystal × size + SE',
        'σ_ionic (Stage E corrected)',
        'σ_electronic (Stage E corrected)',
        'σ_thermal (Stage E corrected)',
        'Fracture stage counts (intact/MC/Multi/Frag/Pulv)',
        '7-Layer solver status',
        # Cell-level ASR
        'Cathode geometry (L, A)',
        'ASR_ionic (Ω·cm²)',
        'ASR_electronic (Ω·cm²)',
        'ASR_thermal (K·cm²/W equiv)',
    ]
    _canon_idx = {lbl: i for i, lbl in enumerate(_CANONICAL_ROW_ORDER)}

    def _sort_key(row):
        if not row or not isinstance(row[0], str): return (1, 0)
        lbl = row[0].strip()
        i = _canon_idx.get(lbl)
        if i is None:
            return (1, 0)  # unknown labels go to end (preserve relative order via stable sort)
        return (0, i)

    # Group rows by section
    sections = []   # list of [header_idx, [row_indices...]]
    current = None
    for i, r in enumerate(data):
        if r and isinstance(r[0], str) and r[0].strip().startswith('──'):
            if current is not None:
                sections.append(current)
            current = [i, []]
        elif current is not None:
            current[1].append(i)
    if current is not None:
        sections.append(current)

    # Stable-sort each section's rows by canonical index
    for _hdr_idx, row_idxs in sections:
        if len(row_idxs) <= 1: continue
        rows_in_section = [data[ri] for ri in row_idxs]
        sorted_rows = sorted(rows_in_section, key=_sort_key)
        for offset, sr in enumerate(sorted_rows):
            data[row_idxs[0] + offset] = sr

    # ── Pass G (★ 10-16 L214R-03): 최종 병합 (Pass A) · 늘 내는 행 · 정렬 뒤 — 현재 모드별 망 상태가 이긴다 ──
    #    ★ 10-16 WEB-09 — 먼저 채택 모드 (computed · 옛 세대 + 유한 σ > 0) 칸 = 새 표 식이 현재 metrics 로 내는 값 · Δ 도 새 표 식 (옛 CSV 숫자 · 옛 Δ 남김 차단)
    #    미채택 모드 (모형 한계 · σ 없음 · not_computed · valid_zero) 의 이온 σ · FULL 유도비 = '—' (+ 사유) · Δ '—' — 옛 CSV 숫자 복원 차단 (split · 두 열 · 네 열)
    _refresh_accepted_ion_modes(data, metrics)
    _mask_unaccepted_ion_modes(data, metrics)


# ──────────────────────────────────────────────────────────────────────────
#  Paper-style label renaming (advisor feedback — formal academic language)
#
#  Both analyze_contacts.py CSV outputs and webapp injectors use mixed
#  Korean/informal labels (e.g., '── 이온경로: 연결성 ──', 'σ_brug/σ_grain
#  (Bruggeman)'). Paper / reviewer-facing UI needs proper academic notation
#  (LaTeX-friendly symbols, English section headers, explicit units).
#
#  We rename at render time (not in CSV) so:
#    - Historical CSVs in archive/ keep their original labels on disk
#    - Tooltips still match via the LABEL_ALIASES reverse map (single.html JS)
#    - One-line revert if reviewers want different terminology
# ──────────────────────────────────────────────────────────────────────────
_PAPER_SECTION_MAP = {
    '── 구조 ──': '── 구조 (Structure — DEM compaction state) ──',
    '── 계면 ──':
        '── 계면 (Interfacial contact area — AM-SE / SE-SE) ──',
    '── 이온경로: 연결성 ──':
        '── 이온 전달 · 연결성 (Ionic transport — Network connectivity) ──',
    '── 이온경로: 경로 효율 ──':
        '── 이온 전달 · 경로 효율 (Ionic transport — Geodesic tortuosity) ──',
    '── 이온경로: 경로 품질 ──':
        '── 이온 전달 · 경로 품질 (Ionic transport — Path quality, bottleneck & conductance) ──',
    '── 활성도 ──':
        '── 활성도 (Electrochemically-active surface) ──',
    '── 이온전도 ──':
        '── 이온 전도 (Ionic conductivity — Bruggeman EMT estimate) ──',
    #  ★ 09-30 (웹앱 ① · J20-l) — "Hertzian" 은 이름만이다: 그 열의 면적은 LIGGGHTS 가 덤프하는
    #    기하 교차 원판 c_cpl[22] (parse_liggghts L1-04 · 작은 겹침에서 Hertz πR*δ 의 약 2 배 ·
    #    docs/area_contract_20260913.md) 이고 검증된 수송 면적이 아니다 (AREA-08).  두 계열로 부른다.
    '── Network Solver (Hertzian DEM-native) ──':
        '── 네트워크 솔버 · Hertz 계열 (Network solver — LIGGGHTS c_cpl[22] intersection-disc area) ──',
    '── Network Solver (DEM-native vs Tabor+volume physics) ──':
        '── 네트워크 솔버 · Hertz 계열 vs Physics 계열 (Network solver — c_cpl[22] disc area vs Tabor + volume caps) ──',
    '── Physics (Plastic film, Tabor+volume) ──':
        '── 네트워크 솔버 · Physics 계열 v1 (Network solver — Tabor plastic film + volume conservation) ──',
    #  ★ 10-04 τ 명명 규약 (CLAUDE.md · 결정 16 · TAU-01) — 입력 칸의 꼴은 tau2 (√ 값이 아니다) · 'COMSOL 입력' 표지는 GUI 확인 뒤.
    '── τ 비교 (Dijkstra vs Laplace · tau2 = tortuosity factor) ──':
        '── 굴곡도 비교 (Tortuosity — Dijkstra vs Laplacian; tau2 = φ·σ₀/σ_full = tortuosity factor) ──',
    '── Tier 1 patches (post-Auerbach refinements) ──':
        '── Tier-1 보정 (Tier-1 corrections — post-Auerbach refinements) ──',
    '── AM-AM 접촉 역학 ──':
        '── AM-AM 접촉 역학 (AM-AM contact mechanics) ──',
    '── 응력 ──':
        '── 응력 분포 (Particle stress — von Mises · two conventions: LIGGGHTS stress/atom 50/50 split vs '
        'Love–Weber particle-contact-force symmetric stress) ──',
    '── Stage E (literature-grounded σ_grain corrections) ──':
        '── Stage E · σ_grain 보정 (Stage E — σ_grain corrections; model assumptions, not literature values) ──',
    '── Cell-level ASR (Ohm slab: R = L_cathode / σ) ──':
        '── 셀 단위 ASR · 두께·전도도 슬랩 (Cell-level area-specific resistance — Ohm slab: R = L_cathode / σ) ──',
}

_PAPER_LABEL_MAP = {
    # Structure
    #  ★ 09-30 (웹앱 ① · J20-l) — 정의를 라벨에: ε_sphere = 구 부피 합 (생산 · 보정 앵커 규약 ·
    #    겹친 부피 이중계상) · 두께 = 판 간격 (get_plate_z — 입자 윗면 포락선이 아니다).
    #    ⚠ 라벨을 바꾸면 single.html PAPER_TO_ORIG 역맵도 같이 (test_closed_param_labels T1 이 전수 강제).
    'Porosity(%)':                 'Porosity ε_sphere — sphere-volume sum, production (%)',
    '전극두께(μm)':                 'Electrode thickness T — plate gap (μm)',
    # Interface
    'AM-SE Total(μm²)':            'Total AM-SE contact area, A_AM-SE (μm²)',
    'SE-SE Total(μm²)':            'Total SE-SE contact area, A_SE-SE (μm²)',
    'Binding % — AM-SE (H/L/T/V/G)':
        'Binding regime share — AM-SE (Hertz / LIGGGHTS / Tabor / Volume / Geom)',
    'Binding % — Total (H/L/T/V/G)':
        'Binding regime share — All contacts (Hertz / LIGGGHTS / Tabor / Volume / Geom)',
    #  ★ 10-06 (C2-⑥ · LHS-25 · J20-l) — Physics 열 = 합집합 cap 피복 (coverage_*_mean_physics_union) · 옛 합-클립은 바로 아래 legacy 줄
    #    (inject_physics_union_coverage_rows) · ⚠ 라벨을 바꾸면 single.html PAPER_TO_ORIG 도 같이 (test_closed_param_labels T1)
    'Coverage AM_P(%)':            'Coverage of AM_P by SE, cov_AM_P (%) · Physics 열 = 합집합 cap (겹침 한 번 · AM–AM 가림 제외 · 세대 2 면적)',
    'Coverage AM_S(%)':            'Coverage of AM_S by SE, cov_AM_S (%) · Physics 열 = 합집합 cap (겹침 한 번 · AM–AM 가림 제외 · 세대 2 면적)',
    'Coverage AM(%)':              'Coverage of AM by SE, cov_AM (%) · Physics 열 = 합집합 cap (겹침 한 번 · AM–AM 가림 제외 · 세대 2 면적)',
    # Connectivity
    'SE-SE CN mean':               'SE-SE coordination number ⟨z_SE-SE⟩',
    'SE-SE CN std':                'SE-SE coordination number σ(z_SE-SE)',
    'SE Cluster 수':               'SE clusters, n≥10 / all (isolated SE count as clusters)',   # 전체 성분 · 외톨이 포함 (LHS-19 · ②)
    'SE Percolation(%)':           'SE percolation, top↔bottom (%)',
    'Top Reachable(%)':            'Separator-side SE connectivity, f_SE^sep (%)',
    # Tortuosity
    'Tortuosity mean':             'Tortuosity ⟨τ_Dijkstra⟩ (geodesic)',
    'Tortuosity median':           'Tortuosity median(τ_Dijkstra)',
    'Tortuosity std':              'Tortuosity σ(τ_Dijkstra)',
    'GB Density(hops/μm)':         'Grain-boundary density (hops/μm)',
    # Path quality
    'Path Hop Area mean(μm²)':     'Mean per-hop contact area, ⟨A_hop⟩ (μm²)',
    'Path Bottleneck(μm²)':        'Path bottleneck min(A_contact) (μm²)',
    'Path Conductance(μm²)':       'Effective path conductance Σ(A/ℓ) (μm²)',
    # Active surface
    'AM-SE CN mean':               'AM-SE coordination number ⟨z_AM-SE⟩',
    '  ├ AM_P-SE CN mean':         '  ├ AM_P-SE coordination number ⟨z_AM_P-SE⟩',
    '  ├ AM_S-SE CN mean':         '  ├ AM_S-SE coordination number ⟨z_AM_S-SE⟩',
    '  └ AM-SE CN (surface-weighted)':
        '  └ AM-SE coordination number (surface-area weighted)',
    'Ionic Active AM(%)':          'Ionically-active AM, touching top-reachable SE (%)',   # 위 띠 SE 와의 접촉 (LHS-20 · ②)
    #  v1.1 ①② (1저자 비준 10-01) — 경로 기준 고립 = 100 − 활성 = 단절 + 무접촉 · 고립 위험 (AM Vulnerable · 접촉 0–1 개) 과 다른 양
    'Ionic Isolated AM(%)':        'Ionically-isolated AM, path-based = 100 − active (%)',
    '  ├ Isolated: SE not linked(%)': '  ├ isolated — touches SE, none linked to the separator side (%)',
    '  └ Isolated: no SE contact(%)': '  └ isolated — no SE contact (%)',
    'AM Vulnerable(%)':            'Ionically-vulnerable AM, 0–1 SE contacts (%)',   # 접촉 개수 기준 · coverage 아님 (LHS-23 · 7c)
    '  ├ AM_P Vulnerable(%)':      '  ├ AM_P ionically-vulnerable (%)',
    '  └ AM_S Vulnerable(%)':      '  └ AM_S ionically-vulnerable (%)',
    # Bruggeman EMT
    'SE Volume Fraction':          'SE volume fraction φ_SE — sphere volume / plate gap',
    'σ_Bruggeman (mS/cm)':         'σ_Bruggeman — EMT estimate (mS/cm)',
    'σ_brug/σ_grain (Bruggeman)':  'Bruggeman coefficient, σ_Bruggeman / σ_grain',
    # Network solver — Hertzian
    'σ_ionic (mS/cm)':             'σ_ionic — full network solver (mS/cm)',
    'R_brug (과대추정 배수)':       'Bruggeman overestimation, R_brug = σ_Bruggeman / σ_ionic',
    'Constriction 비율(%)':         'Constriction R fraction — per-edge unweighted mean, not a power share (L2-08) (%)',
    'Constriction 전력 몫 (I²R · %)': 'Constriction power share Σ I²R_c / Σ I²R_total — same FULL solution, percolating edges (%)',
    'σ_electronic (mS/cm)':        'σ_e — electronic conductivity (mS/cm)',
    'σ_thermal (mS/cm equiv)':     'κ — thermal conductivity (mS/cm equiv)',
    # Physics (Tabor)
    'σ_ionic [physics] (mS/cm)':
        'σ_ionic^physics — Tabor plastic film (mS/cm)',
    'σ_ionic ratio (physics/Hertzian)':
        'Plastic amplification, σ_ionic^physics / σ_ionic^Hertzian',
    'σ_electronic [physics] (mS/cm)':
        'σ_e^physics — Tabor plastic film (mS/cm)',
    'σ_thermal [physics] (mS/cm equiv)':
        'κ^physics — Tabor plastic film (mS/cm equiv)',
    'Contact-free / Full':
        'σ_contact-free / σ_full — constriction overestimation',
    'σ_brug / σ_ionic':
        'σ_Bruggeman / σ_ionic — EMT vs Network solver',
    # Tortuosity comparison
    'τ_Dij (Dijkstra, 기하만)':
        'τ_Dijkstra — geodesic-only (geometric)',
    'τ_Dij,all (Dijkstra 전체, 기하만)':
        'τ_Dijkstra,all — every bottom SE, shortest path to top (geometric)',
    'τ_Lap_geom (Laplace, GB 제외)':
        'τ_Laplace,bulk — Laplacian without constriction',
    'tau2 = φ·σ₀/σ_full (tortuosity factor · 협착 포함)':
        'tau2 — tortuosity factor φ·σ₀/σ_full (network model · 1st-gen constriction)',
    'τ_Lap,eff = √tau2 (Laplace · 협착 포함)':
        'τ_Laplace,eff = √tau2 — Laplacian + constriction',
    'τ_Lap,eff / τ_Dij (정의가 다른 두 τ 의 비)':
        'τ_Laplace,eff / τ_Dijkstra — ratio of two differently defined τ (not a constriction factor)',
    'tau2 인계 상태 (게이트 G1–G6 · v2 §5-2)':
        'tau2 handover status — gates G1–G6 (τ judgment v2 §5-2 · scripts/tau_flux.py)',
    '띠 규칙 · 띠 폭/판 간격 (G1 · TAU-24)':
        'Boundary band rule · band width / plate gap (G1 · TAU-24)',
    #  ★ 10-06 밤 G2R-01 · 02 웹앱 짝 — ⚠ 바꾸면 single.html PAPER_TO_ORIG 역맵도 같이 (test_closed_param_labels T1)
    '망 세대 (세대 계약 · G2R-01 · 02)':
        'Network generation contract — g2 · inferred_legacy (historical, inferred) · invalid (G2R-01 · 02)',
    #  ★ 10-05 RGL-02 · 04 웹앱 짝 — ⚠ 바꾸면 single.html PAPER_TO_ORIG 역맵도 같이 (test_closed_param_labels T1)
    'σ_ionic 망 상태 (생산자 sigma_full_status)':
        'σ_ionic network state — producer sigma_full_status (valid_zero = proven no through path · not_computed = solve failed or FULL model limit)',
    '망 최근 시도 (network_attempt — 활성 세대와 다를 때)':
        'Latest network attempt — failed candidate not promoted (network_attempt.json · active generation kept)',
    #  ★ 10-05 RGLR2-02 웹앱 짝 — ⚠ 바꾸면 single.html PAPER_TO_ORIG 역맵도 같이
    '망 활성 세대 무효 (full_metrics ↔ 도장 · 되돌림 실패 · 중단된 게시)':
        'Network active generation invalid — full_metrics ↔ provenance mismatch · rollback failed · interrupted publish (values not citable)',
    'AM Percolation (%)':          'AM percolation, top↔bottom (%)',
    'Electronic Active AM (%)':    'Current-collector-connected AM, f_AM^cc (%)',
    # Tier-1 corrections
    'Coverage AM rough(%)   ⭐ [B3]':
        'Coverage of AM, shape-corrected ⭐ (B3)',
    'Coverage AM_P rough(%) ⭐ [B3]':
        'Coverage of AM_P, shape-corrected ⭐ (B3)',
    'Coverage AM_S rough(%) ⭐ [B3]':
        'Coverage of AM_S, shape-corrected ⭐ (B3)',
    'SE-SE CN (perc-only)        [F2]':
        'SE-SE ⟨z⟩ — percolating-only (F2)',
    'SE-SE CN (area-weighted)    [F2]':
        'SE-SE ⟨z⟩ — surface-area weighted (F2)',
    'SE-SE CN (perc area-w)      [F2]':
        'SE-SE ⟨z⟩ — percolating + area-weighted (F2)',
    'SE-SE CN (plastic-augmented) [F1]':
        'SE-SE ⟨z⟩ — plastic-augmented (F1)',
    '(F1 extra near-contact pairs)':
        'F1 near-contact pairs (gap < 10 nm)',
    # AM-AM mechanics
    'AM-AM CN mean':               'AM-AM coordination number ⟨z_AM-AM⟩',
    'AM-AM CN std':                'AM-AM coordination number σ(z_AM-AM)',
    'AM-AM 접촉 수':                'AM-AM contact count',
    '접촉 반경(µm)':                'Mean Hertzian contact radius, ⟨a⟩ (μm)',
    '침투 깊이 δ(µm)':              'Mean overlap depth, ⟨δ⟩ (μm)',
    '법선력(µN)':                   'Mean normal force, ⟨F_n⟩ (μN)',
    '접촉 압력(MPa)':               'Mean contact pressure, ⟨p⟩ (MPa)',
    'Hop 거리(µm)':                 'Mean inter-particle hop distance (μm)',
    # Stress — 옛 네 줄 = LIGGGHTS stress/atom (접촉 virial 50/50 분할) · 대각 성분 (값 그대로 · 이름표 정정 · LHS-29) · ④b Love–Weber 줄
    'Stress CV(%)':
        'Particle-stress CV(σ_VM) — LIGGGHTS stress/atom, 50/50 pair split, diagonal only (%)',
    'σ_AM_P/σ_mean':
        '⟨σ_VM⟩_AM_P / ⟨σ_VM⟩_all — stress/atom 50/50 split, diagonal only (size-biased)',
    'σ_AM_S/σ_mean':
        '⟨σ_VM⟩_AM_S / ⟨σ_VM⟩_all — stress/atom 50/50 split, diagonal only (size-biased)',
    'σ_SE/σ_mean':
        '⟨σ_VM⟩_SE / ⟨σ_VM⟩_all — stress/atom 50/50 split, diagonal only (size-biased)',
    'Stress CV 상태 (50/50 · LHS-33)':
        'Particle-stress CV status — stress/atom 50/50 (LHS-33: invalid/undefined input → blank, not 0; not graded)',
    #  RGL-06 (10-05 · Codex Q3) — 이름 한정: 입자 접촉력 기반 대칭 응력의 VM (kinetic · 벽 · couple 미포함 — 전체 동적 응력 아님) ·
    #  벽 제외 = 선별 모집단 (결측 벽 힘 복원 아님) · 전역 virial = 부호/척도 검사 (프레임 대응 증명 아님).  옛 'full tensor' 표기는 뺐다.
    'Stress CV — Love–Weber (%)':
        'Particle-stress CV(σ_VM) — Love–Weber symmetric particle-contact-force stress (no kinetic · wall · couple terms) (%)',
    'σ_AM_P/σ_mean — Love–Weber':
        '⟨σ_VM⟩_AM_P / ⟨σ_VM⟩_all — Love–Weber (particle-contact forces only)',
    'σ_AM_S/σ_mean — Love–Weber':
        '⟨σ_VM⟩_AM_S / ⟨σ_VM⟩_all — Love–Weber (particle-contact forces only)',
    'σ_SE/σ_mean — Love–Weber':
        '⟨σ_VM⟩_SE / ⟨σ_VM⟩_all — Love–Weber (particle-contact forces only)',
    'Stress CV — Love–Weber · 벽 접촉 제외 (%)':
        'Particle-stress CV(σ_VM) — Love–Weber, selected population: wall-contact particles excluded (wall forces not restored) (%)',
    'σ_AM_P/σ_mean — Love–Weber · 벽 접촉 제외':
        '⟨σ_VM⟩_AM_P / ⟨σ_VM⟩_all — Love–Weber, selected population: wall-contact particles excluded',
    'σ_AM_S/σ_mean — Love–Weber · 벽 접촉 제외':
        '⟨σ_VM⟩_AM_S / ⟨σ_VM⟩_all — Love–Weber, selected population: wall-contact particles excluded',
    'σ_SE/σ_mean — Love–Weber · 벽 접촉 제외':
        '⟨σ_VM⟩_SE / ⟨σ_VM⟩_all — Love–Weber, selected population: wall-contact particles excluded',
    '벽 접촉 입자 (%) — 바닥 · 판':
        'Wall-contact particles per phase (%) — floor · platen (wall forces absent from both conventions; '
        'deck geometry assumed, not verified)',
    'Love–Weber 상태 (④b · LHS-29)':
        'Love–Weber stress status (input checks · F = Fn + Ft · contact point · global virial sign/scale vs c_strs — '
        'not a frame-correspondence proof)',
    # Stage E (already paper-style; tightened wording only)
    'σ_ionic — SE size factor':
        'σ_ionic correction — SE-size factor (model assumption)',
    'σ_e — AM crystal × size':
        'σ_e correction — AM-crystallinity × size factor (Trevisanello 2021)',
    'κ — AM crystal × size + SE':
        'κ correction — AM-crystallinity + SE factor (Wang 2022)',
    'σ_ionic (Stage E corrected)':
        '⭐ σ_ionic — Stage E final (full literature-grounded corrections, mS/cm)',
    'σ_electronic (Stage E corrected)':
        '⭐ σ_e — Stage E final (fracture × AM-crystallinity, mS/cm)',
    'σ_thermal (Stage E corrected)':
        '⭐ κ — Stage E final (Wang grain corrections, mS/cm equiv)',
    'Fracture stage counts (intact/MC/Multi/Frag/Pulv)':
        'Per-contact fracture-stage distribution (intact / micro / multi / frag / pulv)',
    '7-Layer solver status':
        '7-Layer solver defence — channel status',
}


def apply_paper_labels(tables):
    """Replace informal/Korean labels with formal academic notation. Acts on
    network_summary table in-place. Preserves leading whitespace (used for
    indentation under section headers) and updates tooltip data-metric via
    JS LABEL_ALIASES (single.html) so existing tooltip definitions still
    match without requiring 90-key rename across the JS dict.

    Called from /single/<case_id> and /archive/view/<folder> routes after
    all section injectors finish."""
    if 'network_summary' not in tables:
        return
    tbl = tables['network_summary']
    data = tbl.get('data')
    if not isinstance(data, list):
        return
    for row in data:
        if not row or not isinstance(row, list):
            continue
        label = row[0] if row else None
        if not isinstance(label, str):
            continue
        stripped = label.lstrip()
        prefix = label[: len(label) - len(stripped)]
        if stripped.startswith('──'):
            new = _PAPER_SECTION_MAP.get(stripped)
        else:
            new = _PAPER_LABEL_MAP.get(stripped)
        if new and new != stripped:
            row[0] = prefix + new


def inject_dual_porosity_rows(tables, metrics):
    """Insert ε_union + overlap rows directly under the Porosity row of the
    network_summary structure section.  Values = porosity_union, overlap_fraction_pct —
    ★ 2026-09-30 (웹앱 ② · LHS-24 (d)) analyze_contacts 가 ε_sphere 와 같은 판 · 상자로 **직접** 저장한다
    (옛 케이스는 파이프라인 2e = recompute_porosity_dual.py 가 채운 값 — 원 공극률 고정식이라 같은 값).
    Porosity is contact-model-independent → both columns carry the same value, Δ = 0%.  No-op until the
    dual-porosity fields exist (re-analyze, or run recompute_porosity_dual.py for old cases).
    Called LAST (after apply_paper_labels) so layout/relabel passes do not move
    the rows; matches the renamed 'Porosity ε_sphere …' label via startswith.

    ★ 09-30 (웹앱 ① · J20-l) — 이 ε_union 은 **쌍 렌즈** union 이다 (calc_porosity_dual:
      겹친 쌍마다 렌즈 부피를 한 번 뺀다 · 세 입자 겹침 · 벽 밖 (z < 0 · 판 위) 구 부피는
      그대로).  LHS 인계표의 몬테카를로 정확 union (porosity_union_exact_pct) 과 **다른 양**이고
      실측으로 그보다 낮다 — 194/194 건 · 중앙 −0.64 %p (130) · −0.75 %p (lhsx 64)
      (docs/data/lhs_union_20260927/ · 벽 밖을 빼면 차 중앙 0.001 %p).  그래서 라벨에
      "overlap-corrected · literature" 도 "상한" 도 쓰지 않는다.  ε_sphere 와 나란히 (강등 없음)."""
    if 'network_summary' not in tables:
        return
    data = tables['network_summary'].get('data')
    if not isinstance(data, list):
        return
    eps_u = metrics.get('porosity_union')
    ov = metrics.get('overlap_fraction_pct')
    eps_x = metrics.get('porosity_union_exact_pct')                  # ③ 정확 union (MC · 같은 판 · 상자 · 벽 밖 제외)
    if eps_u is None and ov is None and eps_x is None:
        return
    ncol = len(tables['network_summary'].get('columns') or []) or 4
    for i, row in enumerate(data):
        if (isinstance(row, list) and row and isinstance(row[0], str)
                and row[0].lstrip().startswith('Porosity')):
            prefix = row[0][: len(row[0]) - len(row[0].lstrip())]
            ins = []
            if eps_u is not None:
                u = f'{eps_u:.1f}'
                ins.append([prefix + 'Porosity ε_union — pair-lens, wall overhang not removed (%)', u, u, '0%'])
            if ov is not None:
                o = f'{ov:.2f}'
                ins.append([prefix + 'Overlap fraction — pair-lens volume / sphere volume (%)', o, o, '0%'])
            if eps_x is not None:
                se = metrics.get('porosity_union_exact_se_pct')
                x = f'{eps_x:.2f}' + (f' ± {se:.2f}' if isinstance(se, (int, float)) else '')
                ins.append([prefix + 'Porosity ε_union exact — Monte Carlo, wall overhang removed · handover convention (%)',
                            x, x, '0%'])
            for _k, _lab, _fmt in (('thickness_mass_conserving_um', 'Thickness mass-conserving — plate gap × (1−ε_sphere)/(1−ε_exact) (μm)', '{:.2f}'),
                                   ('phi_se_mass_conserving', 'φ_SE mass-conserving — (1−ε_exact) × SE/solid', '{:.4f}'),
                                   ('phi_am_mass_conserving', 'φ_AM mass-conserving — (1−ε_exact) × AM/solid', '{:.4f}')):
                _v = metrics.get(_k)
                if isinstance(_v, (int, float)):
                    ins.append([prefix + _lab, _fmt.format(_v), _fmt.format(_v), '0%'])
            ins = [r[:ncol] + [''] * (ncol - len(r)) for r in ins]
            for k, nr in enumerate(ins):
                data.insert(i + 1 + k, nr)
            break


#: ⑥ 합집합 cap 피복 (C2-⑥ · 1저자 비준 10-06 · LHS-25 · J20-l) — 케이스 망 요약의 Coverage 행 (원 라벨 · 합집합 키 · legacy 키).
#:   생산자 = scripts/coverage_physics_vs_hertzian.union_coverage_bed (값은 셋째 자리 · 표는 첫째 자리).
_UNION_COVERAGE_ROWS = (
    ('Coverage AM_P(%)', 'coverage_AM_P_mean_physics_union', ('coverage_AM_P_mean_physics', 'am_p_se_coverage_physics_pct')),
    ('Coverage AM_S(%)', 'coverage_AM_S_mean_physics_union', ('coverage_AM_S_mean_physics', 'am_s_se_coverage_physics_pct')),
    ('Coverage AM(%)', 'coverage_AM_mean_physics_union', ('coverage_AM_mean_physics', 'am_se_coverage_physics_pct')),
)
UNION_LEGACY_ROW_LABEL = '└ Physics legacy 합-클립 — 접촉 면적 합 ÷ 자유 표면 · 100 % 포화 (LHS-25) (%)'
UNION_STATUS_ROW_LABEL = '⚠ Physics 합집합 상태 — 빈칸 사유 (값 없음 · 0 아님)'


def _union_num(v):
    """유한 실수만 (bool · 문자열 숫자 아님 · None · NaN → None)."""
    import math as _m
    if isinstance(v, bool) or not isinstance(v, (int, float)):
        return None
    return float(v) if _m.isfinite(float(v)) else None


def inject_physics_union_coverage_rows(tables, metrics):
    """⑥ 합집합 cap 피복 — 케이스 망 요약의 Coverage 행 (AM_P · AM_S · mono AM) 의 **Physics 열 = 합집합 값**
    (`coverage_<상>_mean_physics_union` · 겹침 한 번 · AM–AM 가림 제외 · 세대 2 표면 면적 · 행 이름이 그 정의를 적는다 — _PAPER_LABEL_MAP) ·
    바로 아래 **legacy 합-클립** 줄 (옛 Physics v1 값 = 접촉 면적 합 ÷ 자유 표면 · 100 % 포화 · LHS-25 · 등급 축이 아직 이 값) ·
    합집합 키가 없는 옛 케이스 = '—' (0 · legacy · Hertz 복사 아님 — 재분석하면 채워진다) · 빈칸 침대 = '—' + 상태 줄 (사유) 하나.
    Δ 열 = Hertz 열 ↔ 합집합 (반올림 전 값 · 옛 cov_map 과 같은 규칙).  apply_paper_labels 뒤에 부른다 (행 순서가 안 움직이게)."""
    if 'network_summary' not in tables:
        return
    data = tables['network_summary'].get('data')
    if not isinstance(data, list):
        return
    metrics = metrics or {}
    ncol = len(tables['network_summary'].get('columns') or []) or 4
    st = metrics.get('coverage_status_physics_union')
    blank = isinstance(st, str) and st.startswith('blank')
    last = None
    for orig, ukey, lkeys in _UNION_COVERAGE_ROWS:
        names = {orig, _PAPER_LABEL_MAP.get(orig, orig)}
        idx = next((i for i, r in enumerate(data) if isinstance(r, list) and r and isinstance(r[0], str)
                    and r[0].strip() in names), None)
        if idx is None:
            continue
        row = data[idx]
        while len(row) < ncol:
            row.append('')
        u = _union_num(metrics.get(ukey))
        try:
            h = float(row[1])
        except (TypeError, ValueError):
            h = None
        if ncol >= 3:
            row[2] = f'{u:.1f}' if u is not None else '—'
        if ncol >= 4:
            row[3] = _pct_delta(h, u) if (u is not None and h is not None) else ''
        leg = next((x for x in (_union_num(metrics.get(k)) for k in lkeys) if x is not None), None)
        prefix = row[0][: len(row[0]) - len(row[0].lstrip())]
        nr = [prefix + '  ' + UNION_LEGACY_ROW_LABEL, '—', (f'{leg:.1f}' if leg is not None else '—'), '']
        data.insert(idx + 1, nr[:ncol] + [''] * (ncol - len(nr)))
        last = idx + 1
    if blank and last is not None:
        sr = ['  ' + UNION_STATUS_ROW_LABEL, '—', st, '']
        data.insert(last + 1, sr[:ncol] + [''] * (ncol - len(sr)))


def inject_physics_v2_rows(tables, metrics):
    """physics v2 피복률 (`coverage_*_mean_physics_v2`) 을 망 요약 끝에 **후보 · 미검증** 표지와 함께 붙인다 —
    1저자 비준 09-30 밤 J20-l (나) · LHSC-10 (미검증 후보 · 등급 · ML 제외 · 웹앱 ③).  값이 하나도 없으면 아무것도 안 한다.
    값은 Physics 열에만 (Hertz 열은 '—') — v1 과 같은 줄에 섞지 않는다."""
    if 'network_summary' not in tables:
        return
    data = tables['network_summary'].get('data')
    if not isinstance(data, list):
        return
    rows = []
    for key, lab in (('coverage_AM_mean_physics_v2', 'Coverage AM'),
                     ('coverage_AM_P_mean_physics_v2', 'Coverage AM_P'),
                     ('coverage_AM_S_mean_physics_v2', 'Coverage AM_S')):
        v = metrics.get(key)
        if isinstance(v, (int, float)) and not isinstance(v, bool):
            rows.append([f'  {lab} physics v2 — 후보 · 미검증 (%)', '—', f'{v:.1f}', ''])
    if not rows:
        return
    ncol = len(tables['network_summary'].get('columns') or []) or 4
    hdr = ['── Physics v2 — 후보 · 미검증 · 포화 · 인계 제외 (LHSC-10 · LHS-25 · J20-m · 등급 · ML 제외) ──']
    for r in [hdr] + rows:
        data.append(r[:ncol] + [''] * (ncol - len(r)))


def transform_network_summary_4col(tables, metrics, meta):
    """Convert network_summary table to 4-column (지표 | Hertzian | Physics | Δ%)
    and inject Network Solver + AM-AM sections from full_metrics.json.

    Shared helper for /single/<case_id> and /archive/view/<folder> routes."""
    if 'network_summary' not in tables:
        return
    tbl = tables['network_summary']

    # Step 1: expand existing rows to 4 cols (default Physics = Hertzian, Δ = 0%)
    #  ★ 09-30 (웹앱 ① · J20-l) — 두 열 = 두 면적 계열.  "Hertzian" 은 이름만이다 (c_cpl[22] 기하
    #    교차 원판 · AREA-08 legacy).  physics v2 (*_physics_v2) 는 미검증 후보라 여기에 없다 (LHSC-10 · ③).
    tbl['columns'] = ['지표 (Metric)', 'Hertz 계열 (LIGGGHTS c_cpl[22] 기하 교차 원판)',
                      'Physics 계열 v1 (Tabor · 부피 · 기하 cap)', 'Δ (%)']
    def _is_section_header(label):
        if not isinstance(label, str):
            return False
        s = label.strip()
        return s.startswith('──') or (s.startswith('─') and s.endswith('─'))

    # Rows produced by older analyze_contacts.py runs that we no longer want
    # to render (header + binding format have been redesigned, area rows
    # superseded by per-contact selection % distribution).
    _drop_labels = {
        '─ AM-SE 5-case (Tabor/volume/geom decomposition) ─',
        '── AM-SE 5-case (Tabor/volume/geom decomposition) ──',
        'A_binding (Tabor / vol / geom %)',
        'A_5case ÷ A_final (H / L / T / V / G)',
        'AM-SE A_Hertzian(μm²)',
        'AM-SE A_LIGGGHTS(μm²)',
        'AM-SE A_Tabor(μm²)',
        'AM-SE A_volume(μm²)',
        'AM-SE A_geom(μm²)',
        'AM-SE A_final(μm²)',
    }

    # ── Phantom σ_e/κ row suppression (2026-05-28, v5 — handles rows
    # built earlier by analyze_contacts.py and saved to disk).
    # If stage_e_source flags fallback, the σ_e / κ row values stored
    # in the pre-built tables were also written from fallback — replace
    # with '—' here so Network Solver row shows '—' consistently.
    _src_fb_n = metrics.get('stage_e_source') or {}
    _phantom_e_h = (_src_fb_n.get('sigma_e') == 'fallback_weighted_factor'
                    or not metrics.get('electronic_sigma_full_mScm'))
    _phantom_e_p = (_src_fb_n.get('sigma_e_physics') == 'fallback_weighted_factor'
                    or not metrics.get('electronic_sigma_full_mScm_physics'))
    _phantom_th_h = (_src_fb_n.get('sigma_thermal') == 'fallback_weighted_factor'
                     or not metrics.get('thermal_sigma_full_mScm'))
    _phantom_th_p = (_src_fb_n.get('sigma_thermal_physics') == 'fallback_weighted_factor'
                     or not metrics.get('thermal_sigma_full_mScm_physics'))
    _e_label_keys = {
        'σ_electronic (mS/cm)':        ('e', 'h'),
        'σ_e — electronic conductivity (mS/cm)': ('e', 'h'),
        'σ_electronic [physics] (mS/cm)': ('e', 'p'),
        'σ_e^physics — Tabor plastic film (mS/cm)': ('e', 'p'),
        'σ_thermal (mS/cm equiv)':     ('th', 'h'),
        'κ — thermal conductivity (mS/cm equiv)': ('th', 'h'),
        'σ_thermal [physics] (mS/cm equiv)': ('th', 'p'),
        'κ^physics — Tabor plastic film (mS/cm equiv)': ('th', 'p'),
    }
    expanded = []
    for row in tbl['data']:
        if not row:
            continue
        label = row[0] if len(row) > 0 else ''
        if isinstance(label, str) and label.strip() in _drop_labels:
            continue
        # Suppress phantom σ_e / κ row VALUES (label stays for layout)
        label_clean = str(label).strip() if label else ''
        if label_clean in _e_label_keys:
            kind, mode = _e_label_keys[label_clean]
            is_phantom = ((kind == 'e' and mode == 'h' and _phantom_e_h)
                          or (kind == 'e' and mode == 'p' and _phantom_e_p)
                          or (kind == 'th' and mode == 'h' and _phantom_th_h)
                          or (kind == 'th' and mode == 'p' and _phantom_th_p))
            if is_phantom:
                # zero out value column(s)
                if len(row) >= 4:
                    row = [row[0], '—', '—', '—']
                else:
                    row = [row[0], '—']
        if _is_section_header(label):
            expanded.append([label, '', '', ''])
        elif len(row) >= 4:
            expanded.append(list(row))  # already 4-col
        elif label_clean in _MODE_DEP_CSV_ROWS:
            #  ★ 10-15 L214-03 — 기존 CSV 망 절 (analyze_contacts — Hertz 한 열) 의 모드별 행: Physics 칸 = metrics 의 Physics 값 (없으면 '—' + 사유) ·
            #    Hertz 를 복사하지 않는다 (옛: [Hertz, Hertz, 0 %] — Codex "Existing two-column CSV rows are expanded by copying values too")
            expanded.append(_csv_mode_row(label, row[1] if len(row) > 1 else '', _MODE_DEP_CSV_ROWS[label_clean], metrics))
        else:
            value = row[1] if len(row) > 1 else ''
            expanded.append([label, value, value, '0%'])
    tbl['data'] = expanded
    data = tbl['data']

    # Step 2: section headers if missing
    has_headers = any(isinstance(r[0], str) and r[0].startswith('──') for r in data)
    if not has_headers:
        section_map = {
            'Porosity(%)': '── 구조 ──',
            'AM-SE Total(μm²)': '── 계면 ──',
            'SE-SE CN mean': '── 이온경로: 연결성 ──',
            'Tortuosity mean': '── 이온경로: 경로 효율 ──',
            'Path Hop Area mean(μm²)': '── 이온경로: 경로 품질 ──',
            'Ionic Active AM(%)': '── 활성도 ──',
            'Stress CV(%)': '── 응력 ──',
        }
        new_data = []
        for r in data:
            lbl = str(r[0])
            if lbl in section_map:
                new_data.append([section_map[lbl], '', '', ''])
            new_data.append(r)
        tbl['data'] = new_data
        data = tbl['data']

    # Step 3: populate Physics values for metrics where data exists
    # (coverage metrics get populated by merge_coverage_into_metrics in pipeline)
    def _find_row(label_match):
        for r in data:
            if str(r[0]) == label_match:
                return r
        return None

    if metrics:
        # Interface-area rows that have dual Hertzian/Physics values — both
        # coverage percentages (per AM type) and total contact areas.
        # Each entry maps the UI row label to (hertzian_keys, physics_keys);
        # each key is a tuple of fallbacks so old and new schemas coexist.
        # Physics values are written by scripts/coverage_physics_vs_hertzian.py.
        cov_map = {
            # Coverage (% of AM surface covered by SE contacts)
            'Coverage AM(%)':   (('coverage_AM_mean',   'am_se_coverage_elastic_pct'),
                                 ('coverage_AM_mean_physics',   'am_se_coverage_physics_pct')),
            'Coverage AM_P(%)': (('coverage_AM_P_mean', 'am_p_se_coverage_elastic_pct'),
                                 ('coverage_AM_P_mean_physics', 'am_p_se_coverage_physics_pct')),
            'Coverage AM_S(%)': (('coverage_AM_S_mean', 'am_s_se_coverage_elastic_pct'),
                                 ('coverage_AM_S_mean_physics', 'am_s_se_coverage_physics_pct')),
            # Global interface-area totals (μm²) — linear in A so large Δ
            'AM-SE Total(μm²)': (('area_AM전체_SE_total',),
                                 ('area_AM전체_SE_total_physics',)),
            'SE-SE Total(μm²)': (('area_SE_SE_total',),
                                 ('area_SE_SE_total_physics',)),
            # Percolation-path hop metrics (SE-SE area-dependent)
            'Path Hop Area mean(μm²)': (('path_hop_area_mean',),
                                        ('path_hop_area_mean_physics',)),
            'Path Bottleneck(μm²)':    (('path_hop_area_min_mean',),
                                        ('path_hop_area_min_mean_physics',)),
            'Path Conductance(μm²)':   (('path_conductance_mean',),
                                        ('path_conductance_mean_physics',)),
        }
        def _first_present(keys):
            for k in keys:
                if metrics.get(k) is not None:
                    return metrics.get(k)
            return None
        for row_label, (h_keys, p_keys) in cov_map.items():
            r = _find_row(row_label)
            if r is None:
                continue
            h_val = _first_present(h_keys)
            if h_val is None:
                h_val = r[1]  # keep whatever analyze_contacts already wrote
            p_val = _first_present(p_keys)
            if p_val is not None:
                try:
                    h_num = float(h_val) if not isinstance(h_val, (int, float)) else h_val
                    p_num = float(p_val)
                    # Preserve original Hertzian cell formatting (analyze_contacts
                    # already wrote it with case-appropriate precision). Only
                    # inject the Physics value + Δ% columns. For totals this
                    # keeps 2-decimal precision; for percentages the rounding
                    # tolerance is wide enough.
                    if 'Path Conductance' in row_label:
                        decimals = 5
                    elif 'Path' in row_label:
                        decimals = 4
                    elif '총' in row_label or 'Total' in row_label:
                        decimals = 2
                    else:
                        decimals = 1
                    r[2] = round(p_num, decimals)
                    r[3] = _pct_delta(h_num, p_num)
                except Exception:
                    pass

        # ── Per-contact 5-case binding distribution rows ──
        # film_area_from_overlap labels each contact with the case (one of:
        # hertzian, liggghts, tabor, volume, geom, elastic) that supplied the
        # selected area. coverage_physics_vs_hertzian.py aggregates those
        # labels into A_binding_share_AM_SE_pct (AM-SE only) and
        # A_binding_share_total_pct (every contact pair). We render each as
        # a single row: 'H/L/T/V/G %' formatted string in the Physics column.
        def _fmt_share(share_dict):
            if not isinstance(share_dict, dict):
                return None
            parts = [
                share_dict.get('hertzian', 0.0),
                share_dict.get('liggghts', 0.0),
                share_dict.get('tabor',    0.0),
                share_dict.get('volume',   0.0),
                share_dict.get('geom',     0.0),
            ]
            return ' / '.join(f"{float(p):.1f}" for p in parts)

        def _ensure_row(label, anchor_label, value):
            """Update or insert a row by label, anchored after another row."""
            r = _find_row(label)
            if r is not None:
                r[1] = '-'
                r[2] = value
                r[3] = ''
                return
            anchor_idx = None
            for i, row in enumerate(data):
                if isinstance(row, list) and row and row[0] == anchor_label:
                    anchor_idx = i + 1
                    break
            new_row = [label, '-', value, '']
            if anchor_idx is not None:
                data.insert(anchor_idx, new_row)
            else:
                data.append(new_row)

        amse_share = metrics.get('A_binding_share_AM_SE_pct') if metrics else None
        total_share = metrics.get('A_binding_share_total_pct') if metrics else None
        amse_str  = _fmt_share(amse_share)
        total_str = _fmt_share(total_share)
        # Anchor the binding rows after the SE-SE Total row so they sit at
        # the bottom of the 계면 section — same place the legacy area rows
        # appeared.
        if amse_str is not None:
            _ensure_row('Binding % — AM-SE (H/L/T/V/G)',
                        'SE-SE Total(μm²)', amse_str)
        if total_str is not None:
            _ensure_row('Binding % — Total (H/L/T/V/G)',
                        'Binding % — AM-SE (H/L/T/V/G)', total_str)

    # Step 4: inject Network Solver section (σ rows with physics)
    has_net_section = any(isinstance(r[0], str) and r[0].startswith('── Network Solver') for r in data)
    if not has_net_section:
        insert_idx = len(data)
        for idx, r in enumerate(data):
            if isinstance(r[0], str) and r[0].startswith('── 응력'):
                insert_idx = idx
                break
        net_rows = [['── Network Solver (DEM-native vs Tabor+volume physics) ──', '', '', '']]
        if metrics and metrics.get('sigma_full_mScm'):
            #  ★ 10-15 L214-03 — Physics 값이 없으면 Physics 칸 · Δ = '—' (+ 모형 한계 사유) · Hertz 복사 · 0 % 없음 (아래 모드별 행 전부 같은 규칙)
            #  ★ 10-16 WEB-09 — 이온 행 식 = `_ion_*_row` 한 곳 (최종 화면의 채택 모드 갱신과 같은 식 · 값 · 꼴 그대로 옮김)
            net_rows.append(_ion_sigma_row(metrics))
            if metrics.get('sigma_bruggeman_mScm'):
                v = round(metrics['sigma_bruggeman_mScm'], 4)
                net_rows.append(_same_row('σ_Bruggeman (mS/cm)', v))
            if metrics.get('R_brug_over_full'):
                # R_brug/R_full = σ_Bruggeman / σ_ionic. σ_Bruggeman is mode-
                # agnostic but σ_ionic changes with Physics, so the ratio changes.
                net_rows.append(_ion_cf_full_row(metrics))
            if metrics.get('bulk_resistance_fraction') is not None:
                # Constriction % = (1 − bulk_fraction) × 100 · bulk_fraction = 접촉별 R_bulk/R_total 의 **비가중 평균** (L2-08 —
                # 전력 몫 아님).  Physics 모드에서 달라지는 이유 = 간선마다 **접촉 면적 → R_c** 가 바뀌어서다 (R_bulk 는 그대로) ·
                # 전력 몫은 '협착 전력 몫' 행 (④a · constriction_power_share_ion_*).  ⚠ 옛 주석 ("σ_ionic 이 움직여서") 은 틀렸다.
                bf_h = metrics.get('bulk_resistance_fraction')
                bf_p = metrics.get('bulk_resistance_fraction_physics')          # ★ L214-03 — 옛: (…, bf_h) 로 Hertz 를 대신 썼다
                cstr_h = (1 - bf_h) * 100 if bf_h is not None else None
                cstr_p = (1 - bf_p) * 100 if bf_p is not None else None
                #  ★ L2-08 — 이 행 이름은 **조회 키**다 (app.py:1909·:2077 ·
                #    templates/single.html:1966·:2543 가 같은 문자열로 찾는다) → 바꾸지
                #    않는다.  설명은 single.html 의 해설 항목에서 실제 계산과 맞췄다.
                net_rows.append(_dual_row('Constriction 비율(%)',
                                          cstr_h, cstr_p,
                                          fmt=lambda x: round(x, 1)))
            if metrics.get('sigma_ratio') and metrics.get('sigma_full_mScm'):
                net_rows.append(_ion_brug_over_sigma_row(metrics))

            # ── τ 3종 비교 (Dijkstra vs Laplace geom vs Laplace eff) ──
            # Derivation only, no re-analysis needed; σ_grain 은 se_material 단일 출처 +
            # 이 런의 온도 provenance 를 따른다 (σ_full 과 같은 T 여야 τ 가 옳다 — _sigma_grain_mS_cm 참조).
            phi_se = metrics.get('phi_se')
            sig_full = metrics.get('sigma_full_mScm')
            sig_bulk = metrics.get('sigma_bulk_net_mScm')
            tau_dij = metrics.get('tortuosity_mean')
            SIGMA_GRAIN_MS, _sg_note = _sigma_grain_context(metrics)  # [mS/cm] @ 이 런의 T + 혼합경고
            if _sg_note:                                  # ★ S-8: 경고가 표에도 도달해야 한다
                net_rows.append(_dual_row('⚠ σ_grain 온도 정합', _sg_note, _sg_note,
                                          fmt=lambda x: x))
            if phi_se and sig_full and sig_full > 0:
                # tau2 = φ_SE × σ₀ / σ_full (tortuosity factor) · τ_Lap,eff = √tau2 — 공용 `_tau_block_rows` (Step 4b 와 같은 행).
                # σ_full IS mode-dependent → physics σ 가 없으면 physics 칸 '—' (TAU-21).  τ_Lap_geom = σ_bulk_net (mode-agnostic).
                net_rows.extend(_tau_block_rows(phi_se, SIGMA_GRAIN_MS, sig_full,
                                                metrics.get('sigma_full_mScm_physics'), sig_bulk,
                                                tau_dij, metrics.get('tortuosity_all_mean')))

            if metrics.get('electronic_sigma_full_mScm'):
                net_rows.append(_dual_row('σ_electronic (mS/cm)',
                                          metrics.get('electronic_sigma_full_mScm'),
                                          metrics.get('electronic_sigma_full_mScm_physics'),
                                          fmt=lambda x: round(x, 2), p_missing=_mode_missing_text(metrics, 'electronic')))
            if metrics.get('electronic_percolating_fraction') is not None:
                v = f"{metrics['electronic_percolating_fraction']*100:.1f}"
                net_rows.append(_same_row('AM Percolation (%)', v))
            if metrics.get('electronic_active_fraction') is not None:
                v = f"{metrics['electronic_active_fraction']*100:.1f}"
                net_rows.append(_same_row('Electronic Active AM (%)', v))
            if metrics.get('thermal_sigma_full_mScm'):
                net_rows.append(_dual_row('σ_thermal (mS/cm equiv)',
                                          metrics.get('thermal_sigma_full_mScm'),
                                          metrics.get('thermal_sigma_full_mScm_physics'),
                                          fmt=lambda x: round(x, 3), p_missing=_mode_missing_text(metrics, 'thermal')))
        else:
            ns = (meta or {}).get('network_solver_status', 'unknown')
            ns_err = (meta or {}).get('network_solver_error', '')
            if ns in ('failed', 'error', 'timeout', 'no_input', 'no_output'):
                net_rows.append(_same_row('상태', f"❌ {ns}"))
                if ns_err:
                    net_rows.append(_same_row('에러', ns_err[:200]))
            elif ns == 'running':
                net_rows.append(_same_row('상태', '⏳ 실행중...'))
            elif ns == 'waiting':
                net_rows.append(_same_row('상태', '⏳ 대기중'))
            elif ns == 'not_run':
                net_rows.append(_same_row('상태', '미실행'))
            else:
                ms = metrics.get('network_solver_status', '') if metrics else ''
                net_rows.append(_same_row('상태', f"{ms or ns or '결과 없음'}"))
        for i, r in enumerate(net_rows):
            data.insert(insert_idx + i, r)

    # Step 4b: τ_Lap + supplementary rows that analyze_contacts.py does NOT write
    # to the CSV (σ_Bruggeman, Contact-free/Full, σ_brug/σ_ionic, τ-comparison,
    # AM Percolation, Electronic Active AM). When analyze_contacts wrote its own
    # "── Network Solver (Hertzian DEM-native) ──" header to the CSV, Step 4
    # above is skipped (has_net_section=True) — so we ALWAYS run this second
    # pass that adds only the rows missing from the CSV-written section.
    # Each row uses _has_label() to avoid duplicates.
    if metrics:
        def _has_label(lbl):
            for r in data:
                if isinstance(r, list) and r and str(r[0]).strip() == lbl.strip():
                    return True
            return False

        # Anchor: insert after the existing Network Solver section header
        net_anchor = None
        for i, r in enumerate(data):
            if (isinstance(r, list) and r
                    and isinstance(r[0], str)
                    and r[0].startswith('── Network Solver')):
                net_anchor = i
                break

        # Find anchor for the *END* of Network Solver section (= start of next section)
        net_end = len(data)
        if net_anchor is not None:
            for i in range(net_anchor + 1, len(data)):
                r = data[i]
                if (isinstance(r, list) and r
                        and isinstance(r[0], str)
                        and r[0].startswith('──')
                        and not r[0].startswith('── Network Solver')
                        and not r[0].startswith('── Physics')):
                    net_end = i
                    break

        new_rows: list = []

        # σ_Bruggeman (mS/cm)
        if (not _has_label('σ_Bruggeman (mS/cm)')
                and metrics.get('sigma_bruggeman_mScm')):
            new_rows.append(_same_row('σ_Bruggeman (mS/cm)',
                                       round(metrics['sigma_bruggeman_mScm'], 4)))

        # Contact-free / Full  (★ 10-16 WEB-09 — Step 4 와 같은 식 `_ion_cf_full_row` 한 곳)
        if (not _has_label('Contact-free / Full')
                and metrics.get('R_brug_over_full')):
            new_rows.append(_ion_cf_full_row(metrics))

        # σ_brug / σ_ionic  (★ 10-16 WEB-09 — Step 4 와 같은 식 `_ion_brug_over_sigma_row` 한 곳)
        if (not _has_label('σ_brug / σ_ionic')
                and metrics.get('sigma_ratio') and metrics.get('sigma_full_mScm')):
            new_rows.append(_ion_brug_over_sigma_row(metrics))

        # ── τ 3종 비교 ── (always-inject if absent)
        phi_se   = metrics.get('phi_se')
        sig_full = metrics.get('sigma_full_mScm')
        sig_bulk = metrics.get('sigma_bulk_net_mScm')
        tau_dij  = metrics.get('tortuosity_mean')
        SIGMA_GRAIN_MS = _sigma_grain_mS_cm(metrics)   # se_material 단일 출처 + 런의 T provenance
        if (not _has_label(TAU_SECTION_LABEL)
                and phi_se and sig_full and sig_full > 0):
            new_rows.extend(_tau_block_rows(phi_se, SIGMA_GRAIN_MS, sig_full,
                                            metrics.get('sigma_full_mScm_physics'), sig_bulk,
                                            tau_dij, metrics.get('tortuosity_all_mean')))
        # ── τ 인계 상태 (τ 결정 16 ② · scripts/tau_flux.py) — 라우트가 `_ion_handover` 를 붙였을 때만 · 비관통 케이스도 상태가 보이게
        #    τ 블록 조건 (σ > 0) 과 따로 둔다.  자리는 `_CANONICAL_ROW_ORDER` 가 비율 행 뒤로 잡는다.
        if '_ion_handover' in metrics and not _has_label(ION_HANDOVER_STATUS_LABEL):
            new_rows.extend(_ion_handover_rows(metrics.get('_ion_handover'), metrics.get('_ion_handover_stamp') or ''))
        # ── 망 상태 · 최근 시도 (10-05 RGL-02 · 04 웹앱 짝) — σ 가 없는 비관통 케이스도 보이게 τ 블록 조건과 따로 · 자리는 정렬 표가 잡는다
        if (not _has_label(ION_NET_STATE_LABEL) and not _has_label(NET_ATTEMPT_LABEL)
                and not _has_label(NET_GEN_INVALID_LABEL)):           # ★ RGLR2-02 — 세대 무효 행도 같은 묶음
            new_rows.extend(_network_state_rows(metrics))

        # AM Percolation (electronic)
        if (not _has_label('AM Percolation (%)')
                and metrics.get('electronic_percolating_fraction') is not None):
            v = f"{metrics['electronic_percolating_fraction']*100:.1f}"
            new_rows.append(_same_row('AM Percolation (%)', v))

        # Electronic Active AM
        if (not _has_label('Electronic Active AM (%)')
                and metrics.get('electronic_active_fraction') is not None):
            v = f"{metrics['electronic_active_fraction']*100:.1f}"
            new_rows.append(_same_row('Electronic Active AM (%)', v))

        # Insert at the end of the Network Solver section
        if new_rows:
            for j, nr in enumerate(new_rows):
                data.insert(net_end + j, nr)

    # Step 5: inject AM-AM contact mechanics section (invariant under contact_mode)
    has_am_am = any(isinstance(r[0], str) and r[0].startswith('── AM-AM 접촉 역학') for r in data)
    if not has_am_am and metrics:
        am_insert_idx = len(data)
        for idx, r in enumerate(data):
            if isinstance(r[0], str) and r[0].startswith('── 응력'):
                am_insert_idx = idx
                break
        am_rows = [['── AM-AM 접촉 역학 ──', '', '', '']]
        if metrics.get('am_am_cn') is not None:
            am_rows.append(_same_row('AM-AM CN mean', round(metrics['am_am_cn'], 2)))
        #  ★ 09-30 (웹앱 ① · J20-j) — 인계표 AM–AM CN 세 열 중 std 만 화면에 없었다 (모집단 σ · calc_am_am_cn)
        if metrics.get('am_am_cn_std') is not None:
            am_rows.append(_same_row('AM-AM CN std', round(metrics['am_am_cn_std'], 2)))
        if metrics.get('am_am_n_contacts') is not None:
            am_rows.append(_same_row('AM-AM 접촉 수', metrics['am_am_n_contacts']))
        if metrics.get('am_am_mean_contact_radius') is not None:
            am_rows.append(_same_row('접촉 반경(µm)', round(metrics['am_am_mean_contact_radius'], 4)))
        if metrics.get('am_am_mean_delta') is not None:
            am_rows.append(_same_row('침투 깊이 δ(µm)', round(metrics['am_am_mean_delta'], 4)))
        if metrics.get('am_am_mean_force') is not None:
            am_rows.append(_same_row('법선력(µN)', round(metrics['am_am_mean_force'], 2)))
        if metrics.get('am_am_mean_pressure') is not None:
            am_rows.append(_same_row('접촉 압력(MPa)', round(metrics['am_am_mean_pressure'], 1)))
        if metrics.get('am_am_mean_hop') is not None:
            am_rows.append(_same_row('Hop 거리(µm)', round(metrics['am_am_mean_hop'], 2)))
        if len(am_rows) > 1:
            for i, r in enumerate(am_rows):
                data.insert(am_insert_idx + i, r)


def _merge_dual_into_metrics(results_dir, met_data):
    """If network_conductivity_dual.json exists (contact-mode=both run),
    copy physics-mode fields into met_data with '_physics' suffix, plus
    a compact nested 'network_dual' block for webapp display."""
    dual_path = os.path.join(results_dir, 'network_conductivity_dual.json')
    if not os.path.exists(dual_path):
        return met_data
    try:
        with open(dual_path) as _df:
            dual = json.load(_df)
    except Exception:
        return met_data
    rH = dual.get('hertzian') or {}
    rP = dual.get('physics') or {}
    ratio = dual.get('ratio_physics_over_hertzian') or {}
    for k in _NET_PHYSICS_MIRROR_KEYS:
        if rP.get(k) is not None:
            met_data[f'{k}_physics'] = rP[k]
    #  ★ 10-04 ④a — 이미 모드 꼬리가 붙은 키는 이름 그대로 (협착 전력 몫 physics · 상태)
    for k in _ps.NET_PHYSICS_TAILED_KEYS:
        if rP.get(k) is not None:
            met_data[k] = rP[k]
    met_data['network_dual'] = {
        'hertzian': {k: rH.get(k) for k in _NET_PHYSICS_MIRROR_KEYS},
        'physics':  {k: rP.get(k) for k in _NET_PHYSICS_MIRROR_KEYS},
        'ratio_physics_over_hertzian': ratio,
    }
    # Stamp the Physics resistance model + timestamp so every caller (batch,
    # per-case retry, archive reanalyze) propagates the same state to the UI.
    #  ★ 10-06 (`L2-01` 세대 2 · 1저자 개정) — 저항 모델 이름 ('mikic') 만으로는 ψ 배치 세대 (세대 1 분모 · 세대 2 곱셈) 를 못 가른다.
    #    세대 표기 = `psi_placement_physics` — 위 미러 루프가 dual physics 의 `psi_placement` 에서 채운다 (솔버 출력 그대로 · 망 소유 키라
    #    세대마다 걷어내고 다시 채운다 = 옛 표기가 새 σ 밑에 남지 않는다).  활성 도장 (network_provenance.json) 에도 같은 이름으로 남는다.
    phys_model = rP.get('resistance_model')
    if phys_model:
        met_data['physics_resistance_model'] = phys_model
        met_data['physics_solver_at'] = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    return met_data


def _refresh_post_network_warnings(met_data):
    """Refresh metrics['warnings'] for checks that depend on fields populated
    by the network solver (electronic_active_fraction etc.). Called AFTER
    network_conductivity.json is merged into full_metrics.json.

    Preserves any existing warnings that were emitted by analyze_contacts.py
    (keyed by 'type' to avoid duplicates) and appends network-dependent ones.

    Respects met_data.disabled_warnings — entries whose type is in that list
    are filtered out.
    """
    existing = list(met_data.get('warnings') or [])
    known_types = {w.get('type') for w in existing if isinstance(w, dict)}
    disabled = set(met_data.get('disabled_warnings') or [])

    new_warnings = []

    def _add(tag, severity, msg):
        if tag not in known_types:
            new_warnings.append({'type': tag, 'severity': severity, 'msg': msg})

    # ─── Electronic Active AM (AM-AM percolation, from network solver) ───
    el_active = met_data.get('electronic_active_fraction')
    if el_active is not None:
        el_pct = el_active * 100
        if el_pct < 10:
            _add('electronic_dead', 'critical',
                 f"Electronic Active AM={el_pct:.0f}% (<10%): 도전재 필수! AM-AM percolation 없음")
        elif el_pct < 50:
            _add('electronic_low', 'critical',
                 f"Electronic Active AM={el_pct:.0f}% (<50%): 대량 dead AM, 도전재 강력 권장")
        elif el_pct < 80:
            _add('electronic_marginal', 'warning',
                 f"Electronic Active AM={el_pct:.0f}% (<80%): 일부 dead AM, 도전재 권장")

    # ─── σ_ionic (ionic conductivity from network solver) ───
    sig = met_data.get('sigma_full_mScm')
    if sig is not None:
        if sig < 0.005:
            _add('sigma_ionic_too_low', 'critical',
                 f"σ_ionic={sig*1000:.2f} μS/cm (<5 μS/cm): 네트워크 거의 비전도 — 병목 극단 또는 솔버 이상")
        elif sig < 0.03:
            _add('sigma_ionic_low', 'warning',
                 f"σ_ionic={sig:.3f} mS/cm (<0.03): 낮은 이온전도도 — bottleneck regime 의심")

    # ─── τ_Lap_eff (effective tortuosity from network solver) ───
    tau_le = met_data.get('tortuosity_lap_eff') or met_data.get('tau_lap_eff')
    if tau_le is not None:
        if tau_le > 15:
            _add('tau_lap_eff_extreme', 'critical',
                 f"τ_Lap_eff={tau_le:.1f} (>15): 극단 bottleneck regime, Wang 70% CAM 레짐 상당")
        elif tau_le > 8:
            _add('tau_lap_eff_high', 'warning',
                 f"τ_Lap_eff={tau_le:.1f} (>8): bottleneck regime, scaling law ±20% 범위 밖 가능성")

    # ─── Constriction dominance ───
    cstr = met_data.get('constriction_pct') or met_data.get('constriction_fraction_pct')
    if cstr is not None:
        if cstr > 90:
            _add('constriction_dominant', 'warning',
                 f"Constriction 비율={cstr:.0f}% (>90%): 접촉 저항이 bulk 저항을 10배 이상 지배")

    # ─── τ_Lap_eff / τ_Dij gap (geometric vs effective divergence) ───
    tau_dij = met_data.get('tortuosity_mean') or met_data.get('tau_dij')
    if tau_le is not None and tau_dij is not None and tau_dij > 0:
        ratio = tau_le / tau_dij
        if ratio > 10:
            _add('tau_ratio_extreme', 'warning',
                 f"τ_Lap_eff/τ_Dij={ratio:.1f}× (>10×): 기하 경로와 실제 전도도 경로 완전 분리")

    # ─── Physics vs Hertzian divergence (sensitivity sanity) ───
    sig_h = met_data.get('sigma_full_mScm')
    sig_p = met_data.get('sigma_full_mScm_physics')
    if sig_h and sig_p and sig_h > 0:
        rel = abs(sig_p - sig_h) / sig_h
        if rel > 0.5:
            _add('physics_hertzian_divergence', 'warning',
                 f"Physics σ / Hertzian σ = {sig_p/sig_h:.2f}× (|Δ|>50%): "
                 "접촉 모델 민감도 큼 — upper bound 해석 권장")

    # ─── Porosity range (post-compaction physicality) ───
    poro = met_data.get('porosity')
    if poro is not None:
        if poro < 8:
            _add('porosity_too_low', 'critical',
                 f"Porosity={poro:.1f}% (<8%): 과압축 — 물리적 한계 근접")
        elif poro > 30:
            _add('porosity_too_high', 'warning',
                 f"Porosity={poro:.1f}% (>30%): 압축 미완료 — DEM settling 재확인")

    merged = [w for w in (existing + new_warnings) if w.get('type') not in disabled]
    if merged:
        met_data['warnings'] = merged
        met_data['warning_count'] = len(merged)
    else:
        met_data['warnings'] = []
        met_data['warning_count'] = 0
    return met_data


def _network_projection(results_dir, run_id):
    """망 세대 (legacy · dual JSON) → full_metrics 투영을 **메모리에서만** 만든다 — 쓰지 않는다 (승격 여부는 호출부가 정한다).

    ★ 10-05 RGL-04 (Codex · 1저자 비준 "권고대로"): 옛 흐름은 머지를 **먼저 게시**하고 (full_metrics · success 도장 · 옛 stash 삭제)
      새 필수 관문 (망 정지 계약) 을 그 **뒤에** 돌려, 관문이 실패해도 실패 후보가 활성 성공 세대로 남았다 (다른 소비자가 읽는 활성 결과 ·
      성공 증서가 실패 후보로 바뀌었다).  이제 투영은 메모리에서 만들고, 호출부가 채널 판정 · σ₀ 짝 · 정지 계약까지 **전부 통과한 뒤
      한 번에** 승격한다 (네 망 JSON + full_metrics + active provenance).  실패면 후보를 치우고 옛 세대를 되돌린다.

    머지 규칙은 옛 판 그대로 — ★ RC5-03 (Codex 5회차): 옛 merge 는 **새 JSON 에 있는 키만** 덮어써서, 새 solver 가 thermal 을 못 내면
      **옛 세대의 thermal 값이 새 network_run_id · 새 Stage E parent 아래 그대로 남았다** (실측: 111.125/222.25).  값과 도장이 다른 세대를
      가리키는 것은 network/Stage E 세대 분리 작업 전체가 막으려던 바로 그 상태다 ⇒ network 소유 projection (`NET_MERGE_KEYS`) 을
      **전부 걷어내고** 새 세대로만 채운다.  ⚠ 이것은 "thermal 누락 = network 실패" 판정과는 **별개**다 — 누락을 옛 값으로 메우지
      않을 뿐이고, 누락된 키는 기록한다.
    ★ 10-05 RGL-07: σ₀ · 온도 (`NET_SIGMA0_KEYS`) 도 소유 키다 — 옛 온도 factor 가 새 σ 밑에 남지 않는다 · 두 모드 짝 대조는
      `network_sigma0_problem` (어긋나면 승격 거부).
    ★ RC5-03 근본수정 · RC7-02: solver 가 채널 상태를 **항상** 남기므로 세 채널을 각각 판정해 기록하고 하나라도 fail 이면 실패다.
      옛 세대 산출물은 상태 필드가 없어 'unknown' 인데, **소급 실패로 만들지 않는다**.

    → dict(fm=투영 | None, chv={채널: (판정, 사유)}, failed=[실패 채널], dropped=[옛 값을 비운 키], pair='' | σ₀ 짝 사유, error='' | 예외)
      fm None (error 없음) = 투영할 자리가 없다 (full_metrics.json 또는 legacy JSON 없음 — 옛 동작: 머지 생략).
    """
    out = {'fm': None, 'chv': {}, 'failed': [], 'dropped': [], 'pair': '', 'error': ''}
    net_json = os.path.join(results_dir, 'network_conductivity.json')
    fm_json = os.path.join(results_dir, 'full_metrics.json')
    if not (os.path.exists(net_json) and os.path.exists(fm_json)):
        return out
    try:
        with open(net_json) as _f:
            net_data = json.load(_f)
        with open(fm_json) as _f:
            fm_data = json.load(_f)
        _had_keys = {k for k in _NET_MERGE_KEYS if fm_data.get(k) is not None}
        for k in _NET_MERGE_KEYS:
            fm_data.pop(k, None)
        for k in _NET_MERGE_KEYS:
            if k in net_data and net_data[k] is not None:
                fm_data[k] = net_data[k]
        fm_data = _merge_dual_into_metrics(results_dir, fm_data)
        _dropped = sorted(k for k in _had_keys if fm_data.get(k) is None)
        if _dropped:
            fm_data['network_projection_dropped'] = _dropped
        else:
            fm_data.pop('network_projection_dropped', None)
        try:
            with open(os.path.join(results_dir, 'network_conductivity_dual.json')) as _f:
                _dual = json.load(_f)
        except (OSError, ValueError):
            _dual = None
        _pair = _ps.network_sigma0_problem(_dual, net_data, fm_data)
        _chv = {ch: _ps.channel_verdict(net_data, ch, mode='hertz') for ch in _ps.NETWORK_CHANNELS}   # ★ L214 — legacy = 주 Hertz 자리
        for _ch, (_v, _why) in _chv.items():
            fm_data[f'{_ch}_channel_verdict'] = _v
            fm_data[f'{_ch}_channel_reason'] = _why
        _failed_ch = [c for c, (v, _) in _chv.items() if v == 'fail']
        fm_data = _refresh_post_network_warnings(fm_data)
        fm_data['network_solver_status'] = (
            (_failed_ch[0] + '_failed') if _failed_ch else 'success')
        fm_data['failed_channels'] = _failed_ch or None
        fm_data['network_run_id'] = run_id                     # 하위호환
        fm_data['active_network_run_id'] = run_id              # RR2-01
        #  ★ 10-05 WEB-03 Q2b — 최근 시도는 활성 세대 (full_metrics) 의 필드가 아니다 → `network_attempt.json` 에만 (한 실패 어휘).  옛 판이 쓰던
        #    last_network_attempt_run_id · stale_after_failed_retry 는 실패 시도 뒤 활성 파일 안에서 거짓이 되므로 (실패 시도는 이제 full_metrics 를
        #    건드리지 않는다) 새 세대에서 걷어낸다.  읽는 소비자는 없었다 (grep) — 화면 · 목록은 `_ps.network_status_view`.
        fm_data.pop('last_network_attempt_run_id', None)
        fm_data.pop('stale_after_failed_retry', None)
        out.update(fm=fm_data, chv=_chv, failed=_failed_ch, dropped=_dropped, pair=_pair)
    except Exception as _e:                                        # noqa: BLE001
        out['error'] = f'{type(_e).__name__}: {_e}'
    return out


def _network_channel_stage(chv, failed):
    """채널 판정을 **단계로** 올린다 (RC7-02 — ionic · electronic · thermal 같은 자격).  "퍼콜 미형성 (정상)" 과 "솔버 예외 (실패)" 가
    상태로 구분되므로 실패만 실패로 본다 · 옛 세대 ('unknown') 는 소급 실패시키지 않는다."""
    return _ps.StageOutcome(
        step='Network channel verdict (ionic/electronic/thermal)',
        stdout='; '.join(f'{c}={v} ({w})' for c, (v, w) in chv.items()),
        stderr=('실패 채널: ' + ', '.join(failed)) if failed else '',
        rc=(1 if failed else 0), ok=(not failed), required=True,
        missing_outputs=[], stale_outputs=[], verify_failed=False)


def _network_merge_log(log, proj):
    """승격 (또는 보존 경로의 재투영) 뒤의 머지 로그 — 옛 값으로 메우지 않고 비운 키 · 키 수."""
    _dropped = proj.get('dropped') or []
    if _dropped:
        log.append({'step': 'Network Merge', 'rc': 0, 'stderr': '',
                    'stdout': f'⚠ 새 세대가 못 낸 채널 {len(_dropped)}개를 옛 값으로 '
                              f'메우지 않고 비웠다: ' + ', '.join(_dropped[:8])})
    log.append({'step': 'Network Merge', 'stdout': f'{len(_NET_MERGE_KEYS)} σ-keys',
                'stderr': '', 'rc': 0})


#: ★ 10-05 WEB-03 Q2a — 승격 (게시) 단계 이름 (필수 · 실패면 되돌린 뒤 failed) — 정본은 pipeline_service (시도 기록 단계와 한 이름).
NETWORK_PUBLISH_STEP = _ps.NETWORK_PUBLISH_STEP


def _network_candidate_checks(results_dir, run_id, proj, stop_before_stage_e):
    """★ 10-05 RGL-04 — 승격 **전** 후보 검사: 투영 → 채널 판정 → σ₀ · 온도 짝 (RGL-07) → (정지 경로면) 망 정지 계약 (RGL-02 · 08) →
    ★ 10-05 RGLR2-01 공용 기술 검사 (`_ps.network_record_verdict` = `tau_flux.ion_record_problem` · 일반 · 정지 경로 **둘 다** — 일반 경로는 이것이
    Stage E 앞의 마지막 문 · 정지 경로는 계약 ③ 이 같은 함수를 이미 불렀으므로 통과 확인).  정지 계약의 과학적 HOLD 조건은 일반 경로로 옮기지 않는다.
    → (단계들, (실패 단계 이름 | '', 사유)).  통과한 단계도 기록한다 (정지 계약 통과 = 'ok').  하나라도 실패면 호출부가 후보를 버린다."""
    _ss = []
    if proj.get('error'):
        _st = _ps.StageOutcome(step='Network projection (승격 전 투영)', stdout='',
                               stderr='★ 투영 실패 (게시 전 차단): ' + proj['error'], rc=1, ok=False, required=True,
                               missing_outputs=[], stale_outputs=[], verify_failed=True)
        return [_st], (_st['step'], _st['stderr'])
    if proj.get('fm') is not None:
        _tst = _network_channel_stage(proj['chv'], proj['failed'])
        _ss.append(_tst)
        if proj['failed']:
            return _ss, (_tst['step'], _tst['stderr'])
    if proj.get('pair'):
        _st = _ps.StageOutcome(step='Network σ₀ · 온도 짝 (승격 전 · RGL-07)', stdout='',
                               stderr='★ ' + proj['pair'], rc=1, ok=False, required=True,
                               missing_outputs=[], stale_outputs=[], verify_failed=True)
        _ss.append(_st)
        return _ss, (_st['step'], _st['stderr'])
    if stop_before_stage_e:
        _ok_stop, _why_stop = _ps.network_stop_verdict(results_dir, run_id, fm=proj.get('fm'))
        _sst = _ps.StageOutcome(
            step='Network stop contract (stop_after=network)', stdout=(_why_stop if _ok_stop else ''),
            stderr=('' if _ok_stop else '★ 망 정지 계약 실패: ' + _why_stop), rc=(0 if _ok_stop else 1), ok=_ok_stop,
            required=True, missing_outputs=[], stale_outputs=[], verify_failed=(not _ok_stop))
        _ss.append(_sst)
        if not _ok_stop:
            return _ss, (_sst['step'], _sst['stderr'])
    #  ★ 10-05 RGLR2-01 (Codex 3차 재검증 · Q1) — 일반 · 정지 경로 공통의 승격 전 기술 검사.  옛 판은 정지 경로만 (계약 ③) 이 함수를 불러, 일반
    #    경로에서는 σ_ratio 만 ×4 · 띠 L1 의 σ_ratio None 이 done 으로 게시되고 Stage E 까지 갔다 (Codex general_ratio_times4 · general_band_ratio_missing).
    _ok_rec, _why_rec = _ps.network_record_verdict(results_dir)
    _rst = _ps.StageOutcome(
        step=_ps.NETWORK_RECORD_CHECK_STEP, stdout=(_why_rec if _ok_rec else ''),
        stderr=('' if _ok_rec else '★ 공용 기술 검사 실패 (승격 전 · 게시 안 함): ' + _why_rec), rc=(0 if _ok_rec else 1), ok=_ok_rec,
        required=True, missing_outputs=[], stale_outputs=[], verify_failed=(not _ok_rec))
    _ss.append(_rst)
    if not _ok_rec:
        return _ss, (_rst['step'], _rst['stderr'])
    return _ss, ('', '')


def _network_and_stage_e(results_dir, scripts, atoms_csv, contacts_csv, type_map, scale,
                         log, preserve_network=False, network_snapshot=None,
                         runner=None, stop_before_stage_e=False):
    """network baseline → (복원) → Stage E 를 **한 곳에서** 수행한다.

    코드리뷰 F-02 / F-03 / F-17 대응.  옛 구조의 문제:
      • bimodal 과 standard 두 분기가 같은 순서를 각자 구현해 drift 가 생겼다.
      • "network 보존" 재분석이 실제로는 solver 를 **돌린 뒤** 그 결과로 Stage E 를 만들고,
        그 다음에야 옛 network 파일을 덮어써서 baseline 과 Stage E 의 **세대가 섞였다**.
      • solver 호출이 어떤 lock 밖에 있었다.

    여기서 고정하는 순서:
      preserve=True  → **solver 호출 0회**, 스냅샷을 먼저 복원 → 그 baseline 으로 Stage E.
      preserve=False → 파일 lock 을 잡고 옛 산출물을 치운 **빈 자리**에 solver 1회 → 내용 검증 → 메모리 투영 → 채널 판정 → σ₀ 짝 →
                       (stop_before_stage_e 면) 망 정지 계약 → **전부 통과해야 한 번에 승격** (provenance 도장 · 최근 시도 success ·
                       full_metrics 쓰기 · 옛 stash 버림) → 그것으로 Stage E.
                       ★ 10-05 RGL-04: 하나라도 실패하면 후보를 치우고 (`discard_network_candidate` — 첫 실행이면 빈 자리) 옛 세대
                       (네 JSON · provenance) 를 되돌리고 full_metrics 는 쓰지 않는다 · 최근 시도 (`network_attempt.json`) 만 failed + 사유.
                       ★ 10-05 WEB-03 Q2: 승격 쓰기는 한 거래 (`_ps.publish_network_candidate`) — 도중 동기 예외면 되돌린 뒤 필수 단계
                       'Network publication' failed (예외로 새지 않는다).  솔버 · lock 실패도 full_metrics 를 건드리지 않는다 (한 실패 어휘 —
                       최근 시도의 failure_kind = solver · lock · candidate_rejected · publish_exception).
                       ★ 10-05 WEB-03 Q1: 관통 풀이 실패 채널은 생산자가 failed 로 신고 → 내용 검증 (솔버 단계) 이 일반 · 정지 경로 모두에서 막는다.
                       ★ 10-05 RGLR2-01: 승격 전 공용 기술 검사 (`_ps.network_record_verdict` = `tau_flux.ion_record_problem`) 가 일반 · 정지 경로
                       둘 다에 선다 (과학적 HOLD 조건은 옮기지 않는다).  ★ RGLR2-02: lock 안 · stash 전에 중단된 게시 흔적을 격리하고
                       (`_ps.quarantine_network_leftovers` · 재사용 안 함) · 게시의 되돌림 결과를 검산한다 (실패면 rollback_failed · 활성 무효 ·
                       run id 를 돌려주지 않는다).
    어느 쪽이든 Stage E 는 **화면에 실제로 남을 baseline** 을 본다.

    stop_before_stage_e=True (`run_pipeline(stop_after='network')`) — 승격 전 검사의 마지막이 망 정지 계약 (`_ps.network_stop_verdict` ·
      required · 이번 실행 run_id · 후보 투영) — 어기면 failed 이고 활성 세대는 옛 것 그대로다.  Stage E 앞에서 멈춘다.

    → (stages, network_run_id)  — 실패면 network_run_id = 되돌린 옛 활성 세대 (없으면 None)
    """
    stages = []
    attempt_failed = False
    fm_json = os.path.join(results_dir, 'full_metrics.json')

    if preserve_network:
        n = _ps.restore_network(network_snapshot, results_dir)
        prov = _ps.read_network_provenance(results_dir)
        stages.append(_ps.StageOutcome(
            step='Network (PRESERVED — solver not called)',
            stdout=f'restored {n} artefact(s); network_run_id={prov.get("network_run_id")}',
            stderr='', rc=0, ok=True, required=False, missing_outputs=[]))
        log.append(stages[-1])
        # 보존 경로 — 새 후보가 없다 (승격할 것 없음).  복원한 옛 세대의 투영을 다시 쓴다 (옛 동작 그대로 · 실패는 기록만).
        _proj = _network_projection(results_dir, prov.get('network_run_id'))
        if _proj['error'] or _proj['pair']:
            log.append({'step': 'Network Merge', 'stdout': '', 'rc': 1,
                        'stderr': _proj['error'] or _proj['pair']})
        if _proj['fm'] is not None:
            _ps.atomic_write_json(fm_json, _proj['fm'])
            _network_merge_log(log, _proj)
            _tst = _network_channel_stage(_proj['chv'], _proj['failed'])
            stages.append(_tst)
            log.append(_tst)
            _failed_ch = _proj['failed']
            if _failed_ch:
                return stages, prov.get('network_run_id')   # Stage E 를 돌리지 않는다
        if stop_before_stage_e:
            #  보존 (solver 미호출) 경로는 run_pipeline 이 미리 거부한다 — 여기 와도 이번 실행 run_id 가 없어 계약이 실패한다.
            _ok_stop, _why_stop = _ps.network_stop_verdict(results_dir, None)
            _sst = _ps.StageOutcome(
                step='Network stop contract (stop_after=network)', stdout=(_why_stop if _ok_stop else ''),
                stderr=('' if _ok_stop else '★ 망 정지 계약 실패: ' + _why_stop), rc=(0 if _ok_stop else 1), ok=_ok_stop,
                required=True, missing_outputs=[], stale_outputs=[], verify_failed=(not _ok_stop))
            stages.append(_sst)
            log.append(_sst)
            return stages, prov.get('network_run_id')
    else:
        inputs = {os.path.basename(p): _ps.file_digest(p) for p in (atoms_csv, contacts_csv)}
        run_id = _ps.new_run_id()
        cmd = [sys.executable, os.path.join(scripts, 'network_conductivity.py'),
               atoms_csv, contacts_csv, '-o', results_dir,
               '-t', type_map, '-s', str(scale), '--contact-mode', 'both']
        _argv = {'type_map': type_map, 'scale': scale, 'contact_mode': 'both'}
        _proj, _cand_stages, _reject, promoted, _rolled_back, _pub_kind = None, [], ('', ''), False, False, ''
        # ★ CB-03: lock 을 못 잡으면 solver 를 **돌리지 않는다**.  옛 코드는 got=False 여도
        #   그대로 실행해(fail-open) OOM 방지라는 목적 자체가 무너졌다.
        try:
            with _ps.network_lock():
                # ★ 10-05 RGLR2-02 · Codex Q2 ③ 회수 규약 — 중단된 게시 · 풀이의 흔적 (사본 · 망 stash) 이 남은 폴더를 유효 세대로 재사용하지 않는다:
                #   최근 시도에 interrupted_publish (활성 무효 · 재실행 필요) 를 먼저 남기고 흔적을 `.network_recovery/<run_id>/` 로 격리한 뒤
                #   (복구 자료 · recovery_note.json 에 왜) 새로 푼다.  격리 자체가 실패하면 솔버를 돌리지 않는다 (흔적이 남아 읽는 쪽은 계속 무효).
                try:
                    _q = _ps.quarantine_network_leftovers(results_dir, run_id, argv=_argv, inputs=inputs)
                    if _q:
                        log.append({'step': _ps.NETWORK_RECOVERY_STEP, 'rc': 0, 'stderr': '',
                                    'stdout': f'중단된 게시 흔적 {_q} → {_ps.NETWORK_RECOVERY_DIR}/ 격리 (재사용 안 함 · 복구 자료 보존) — '
                                              '이 실행이 승격에 성공해야 활성 세대가 다시 유효'})
                except Exception as _qe:                       # noqa: BLE001
                    raise _ps.NetworkRecoveryFailed(f'흔적 격리 실패 — 솔버 미실행 ({type(_qe).__name__}: {_qe})') from _qe
                # ★ RR2-02 (Codex 2회차): stat 지문(fresh)은 인과 증거가 아니다 —
                #   metadata-only touch 만으로 통과하고, 결정론적 solver 가 byte-identical
                #   결과를 다시 써도 stale 로 거부한다.  해시도 단독으로는 같은 이유로 부족.
                #   → 판정을 **인과**로 바꾼다: 기존 산출물을 lock 안에서 치우고 **빈 자리**에
                #     실행시키면, 실행 후 파일이 존재한다는 사실 자체가 "이번 실행이 만들었다".
                #     실패하면 되돌려 **이전 성공 세대를 그대로 보존**한다.
                _stash = _ps.stash_network(results_dir)
                # ★ RR3-02 (Codex): 성공 계약이 legacy 한 파일뿐이라, solver 가 그것만
                #   쓰고 rc=0 이면 stash 전체를 버려 **완전한 옛 세대를 잃고 부분 세대를
                #   게시**했다.  --contact-mode both 는 네 JSON 을 다 만들어야 완전하다
                #   (소스 주석도 '하나라도 빠지면 Physics 컬럼이 사라진다' 고 적고 있다).
                # ★ RC6-02/03 (Codex 6회차): 옛 게이트는 **파일 존재**만 보고 stash 를
                #   버렸고 thermal 판정은 그 뒤에 했다 → required 실패인데 active 는
                #   success 이고 옛 완전 세대는 이미 사라진 상태가 실측됐다.
                #   내용 검증을 verify 로 **게이트 안에** 넣는다: 실패하면 아래
                #   discard_network_candidate 가 옛 세대를 그대로 되살린다.  두 mode 를 각각 본다
                #   (legacy 하나만 보면 Physics 실패가 H 성공에 가린다).
                _content_reason = ['']

                def _verify_content(rd, _r=_content_reason):
                    ok_, why = _ps.network_content_verdict(rd, strict=True)
                    _r[0] = why
                    return ok_

                st = _ps.run_stage('Network Solver (both modes)', cmd, required=True,
                                   expects=('network_conductivity.json',
                                            'network_conductivity_hertzian.json',
                                            'network_conductivity_physics.json',
                                            'network_conductivity_dual.json'),
                                   results_dir=results_dir, runner=runner,
                                   verify=_verify_content)
                if not st.ok and st.get('verify_failed'):
                    st['stderr'] = ((st.get('stderr') or '') +
                                    '\n★ 내용 검증 실패 (게시 전 차단): ' + _content_reason[0])
                if st.ok:
                    # ★ 10-05 RGL-04 — 승격 **전**에 후보를 전부 검사한다 (투영 · 채널 · σ₀ 짝 · 정지 계약).  옛 흐름은 여기서 stash 를
                    #   버리고 success 도장 · full_metrics 게시를 먼저 한 뒤 정지 계약을 돌렸다.
                    _proj = _network_projection(results_dir, run_id)
                    _cand_stages, _reject = _network_candidate_checks(results_dir, run_id, _proj, stop_before_stage_e)
                    if not _reject[0]:
                        # ── 승격 (한 번에) ──  ★ RR2-01: active 도장은 **성공했을 때만** 갱신한다.
                        #   ★ RR3-05: attempt 는 '가장 최근 시도 (성공 · 실패 모두)' 이므로 성공에도 갱신한다.
                        #   ★ 10-05 WEB-03 Q2a: 승격 쓰기 (도장 · full_metrics · 최근 시도) 를 한 거래로 — 도중 동기 예외면 full_metrics 를 사본에서
                        #     되돌리고 (실패한 쓰기 함수를 다시 부르지 않는다) 후보를 치워 옛 세대를 복원한 뒤 failed (예외로 새지 않는다 ·
                        #     옛 판: 새 provenance + 옛 full_metrics 의 섞인 세대가 남고 예외가 올라갔다).
                        #   ★ 10-05 RGLR2-02: 되돌림 결과를 검산한다 — 되돌림 자체가 실패했거나 결과가 승격 전과 다르면 'rollback_failed' (활성 무효 ·
                        #     "옛 세대 그대로" 라고 말하지 않는다 · 사본은 복구 자료로 남는다).
                        _ok_pub, _why_pub, _pub_kind = _ps.publish_network_candidate(results_dir, _stash, run_id, fm=_proj['fm'],
                                                                                     inputs=inputs, argv=_argv)
                        if _ok_pub:
                            promoted = True
                        else:
                            _rolled_back = True                # 되돌림 · 시도 기록은 거래가 이미 했다 (두 번 치우면 되돌린 옛 세대를 지운다)
                            _pst = _ps.StageOutcome(
                                step=NETWORK_PUBLISH_STEP, stdout='',
                                stderr=(('★ 게시 중 예외 → 되돌림 실패 — 활성 세대 무효 (값 인용 금지 · 재실행 필요 · 사본 = 복구 자료): '
                                         if _pub_kind == 'rollback_failed' else
                                         '★ 게시 중 예외 → 되돌림 (검산 통과 · 활성 = 옛 세대 그대로 · 첫 실행이면 활성 세대 없음): ')
                                        + _why_pub)[:2000],
                                rc=1, ok=False, required=True, missing_outputs=[], stale_outputs=[], verify_failed=True)
                            _cand_stages.append(_pst)
                            _reject = (_pst['step'], _pst['stderr'])
                else:
                    _reject = (st.get('step', ''), (st.get('stderr') or '')[-300:])
                if not promoted and not _rolled_back:
                    # 후보를 치우고 옛 성공 세대 (네 JSON · provenance) 를 되돌린다 — 첫 실행이면 빈 자리 (활성 세대 없음).
                    _ps.discard_network_candidate(results_dir, _stash)
                    # 실패 시도는 **분리된 파일**에 남긴다 — active baseline ID 를 차지하면
                    #   게시된 것은 옛 성공 세대인데 ID 는 실패 시도를 가리키는 모순이 된다.
                    #   ★ 10-05 WEB-03 Q2b — 실패 종류를 이름으로 (솔버 · 승격 전 검사 거부) · 입력 id 와 함께 (한 실패 어휘).
                    _ps.record_network_attempt(results_dir, run_id, 'failed',
                                               reason=(f'{_reject[0]}: {_reject[1]}' if st.ok else _reject[1])[:2000],
                                               argv=_argv, stage=_reject[0],
                                               failure_kind=('candidate_rejected' if st.ok else 'solver'), inputs=inputs)
        except _ps.LockUnavailable as _lk:
            st = _ps.StageOutcome(step='Network Solver (LOCK 미획득 — 미실행)', stdout='',
                                  stderr=str(_lk), rc=1, ok=False, required=True,
                                  missing_outputs=['network lock'])
            _ps.record_network_attempt(results_dir, run_id, 'failed', reason=str(_lk)[-300:],
                                       argv=_argv, stage=st['step'], failure_kind='lock', inputs=inputs)
        except _ps.NetworkRecoveryFailed as _rf:
            #  ★ 10-05 RGLR2-02 — 흔적 격리가 실패했다 → 솔버 미실행 · 흔적은 그대로 (읽는 쪽 무효 · 재실행 필요)
            st = _ps.StageOutcome(step=_ps.NETWORK_RECOVERY_STEP, stdout='', stderr='★ ' + str(_rf), rc=1, ok=False, required=True,
                                  missing_outputs=['network recovery'])
            try:
                _ps.record_network_attempt(results_dir, run_id, 'failed', reason=str(_rf)[-300:], argv=_argv, stage=st['step'],
                                           failure_kind='interrupted_publish', inputs=inputs)
            except Exception:                                  # noqa: BLE001 — 기록을 못 써도 흔적이 남아 읽는 쪽은 무효로 본다
                pass
        stages.append(st)
        log.append(st)
        for _s in _cand_stages:
            stages.append(_s)
            log.append(_s)
        if promoted:
            prov = {'network_run_id': run_id}
            if _proj['fm'] is not None:
                _network_merge_log(log, _proj)
            if stop_before_stage_e:
                return stages, run_id                              # 정지 계약 통과 단계는 _cand_stages 에 있다
        elif st.ok:
            # 후보 거부 (투영 · 채널 · σ₀ 짝 · 정지 계약 · 공용 기술 검사) 또는 게시 중 예외 (되돌림) — 최근 시도만 failed.
            #  ★ 10-05 RGLR2-02 — "이전 세대 유지" 는 활성 세대가 **확정되어 있을 때만** 말한다 (되돌림 실패 · 세대 불일치 · 중단된 게시 흔적이면
            #    활성 무효 · run id 를 돌려주지 않는다).
            _gp = _ps.network_generation_problem(results_dir)
            prov = _ps.read_network_provenance(results_dir)
            log.append({'step': 'Network Merge / Stage E', 'rc': 1, 'stdout': '',
                        'stderr': f'{"게시 중 예외 → 되돌림" if _rolled_back else "승격 전 검사 실패"} ({_reject[0]}) → 후보 폐기 · '
                                  'merge·Stage E 미실행 ' + (f'(활성 세대 무효 — {_gp[:300]} · 값 인용 금지 · 재실행 필요)' if _gp else
                                                             '(게시본은 이전 세대 유지 — 첫 실행이면 활성 세대 없음)')})
            return stages, (None if (_gp or _pub_kind == 'rollback_failed') else prov.get('network_run_id'))
        else:
            prov = _ps.read_network_provenance(results_dir)     # 복구된 옛 세대(있으면)
            _gp_fail = _ps.network_generation_problem(results_dir)
            if _gp_fail:
                prov = {}                                      # ★ RGLR2-02 — 확정되지 않은 세대의 run id 를 활성으로 돌려주지 않는다
            attempt_failed = True

    # ★ RR2-01: network 필수 단계가 실패했으면 **merge 도 Stage E 도 하지 않는다**.
    #   옛 코드는 실패 후에도 옛 baseline 을 머지하고 full_metrics 에 success 를 쓴 뒤
    #   Stage E 까지 돌려, 실패 시도 ID 가 parent/active 로 기록됐다.
    #   ★ 10-05 WEB-03 Q2b (Codex 재검증 Q2 · 1저자 비준) — 한 실패 어휘: 솔버 실패도 활성 세대 (full_metrics 포함) 를 **건드리지 않는다**.
    #     옛 판은 여기서만 full_metrics 에 network_solver_status=failed · last_network_attempt_run_id · stale_after_failed_retry 를 써서, 같은 "최근 시도
    #     실패" 가 솔버 실패면 full_metrics 에 · 승격 전 검사 거부면 시도 기록에만 남았다 (소비자가 종류마다 다른 곳을 추측).  이제 최근 시도는 늘
    #     `network_attempt.json` (latest_attempt_status · failure_kind) 에 있고, 화면 · 목록은 `_ps.network_status_view` 로 읽는다.
    if attempt_failed:
        log.append({'step': 'Network Merge / Stage E', 'rc': 1, 'stdout': '',
                    'stderr': 'network 실패 → merge·Stage E 미실행 ' + (
                        f'(활성 세대 무효 — {_gp_fail[:300]} · 값 인용 금지 · 재실행 필요 · 최근 시도 = network_attempt.json)' if _gp_fail else
                        '(게시본은 이전 세대 유지 · full_metrics 는 건드리지 않는다 — 최근 시도 = network_attempt.json)')})
        return stages, prov.get('network_run_id')

    # ── Stage E — 위에서 확정된 baseline 위에서만 돈다 ──
    #   ★ RV-01 (Codex 재검증): 옛 호출은 expects/results_dir 이 없어 **rc=0 이고 아무것도
    #     안 써도 성공**이었다.  앱이 subprocess 뒤에 직접 쓰는 stage_e_run_id 는 solver 가
    #     산출물을 만들었다는 증거가 아니라 오히려 무산출 실행을 성공처럼 도장한다.
    #     → full_metrics.json 이 이 단계에서 **실제로 바뀌었는지**(fresh) + stage_e 키가
    #       실제로 있는지(verify) 를 둘 다 요구한다.
    #   ★ RC5-01 (Codex 5회차): 옛 판정은 `any('_stage_e' in k)` 라 **이름에 _stage_e 가
    #     든 임의 키 하나 + null 값**만으로 success 도장이 찍혔다 (garbage_stage_e: null 로
    #     재현됨).  이제 run_one 이 무조건 쓰는 11-키 exact schema 를 요구한다
    #     (pipeline_service.STAGE_E_REQUIRED_KEYS; None 은 없는 것으로 센다).
    def _stage_e_wrote(rd):
        try:
            with open(os.path.join(rd, 'full_metrics.json')) as _f:
                miss = _ps.stage_e_missing_keys(json.load(_f))
            if miss:
                log.append({'step': 'Stage E Verify', 'rc': 1,
                            'stdout': f'partial Stage E — 필수 키 {len(miss)}개 없음/None: '
                                      + ', '.join(miss[:6]) + ('…' if len(miss) > 6 else '')})
            return not miss
        except Exception:                                          # noqa: BLE001
            return False

    # ★ RR3-01 (Codex): verify 가 '_stage_e 키가 **하나라도** 있으면 참' 이라, 옛 키가
    #   남아 있으면 rc=0·무산출 실행도 성공으로 도장됐다 (RV-01 재발).  network 와 같은
    #   **인과 판정**을 쓴다: 실행 전에 옛 Stage E 키를 걷어내고, 실행 후 다시 생겼는지 본다.
    #   실패하면 걷어낸 키를 되돌려 이전 세대를 보존한다.
    #   ⚠ 최종형은 Stage E 스크립트 자신이 per-run manifest 를 쓰는 것 — 키 집합이 늘면
    #     이 격리도 drift 한다.  그것은 스크립트 인터페이스 변경이라 별도 작업이다.
    # ★★ RC6-04b (Codex 6회차, 실측 재현) — **active 를 먼저 purge 하지 않는다** ★★
    #   옛 흐름은 subprocess 전에 **active 위치의** full_metrics 에서 Stage E 키를 지워
    #   게시했다.  그래서 (a) 정상 실행 중에도 reader 가 중간 상태를 보고 (b) 부모가
    #   purge 와 복원 사이에 죽으면 **그 상태가 영구 active** 가 됐다.  child 실패
    #   rollback 은 parent crash 를 복구하지 못한다 (RR3-03 과 같은 뿌리).
    #   → candidate 에서 돌리고 **검증을 통과한 것만** 원자 게시한다.  실패·크래시면
    #     active 는 처음부터 안 건드렸으므로 그대로다.
    _ps.sweep_stale_candidates(results_dir)          # 죽은 부모가 남긴 것 청소 (위생일 뿐)
    _se_saved, _raw_saved, _had_active = {}, {}, False
    with _ps.stage_e_candidate(results_dir) as _cand:
        try:
            with open(os.path.join(_cand.dir, 'full_metrics.json')) as _f:
                _fmd = json.load(_f)
            # ★ RC4-02: '_stage_e' 문자열 포함이 아니라 **관리 키 전부**를 격리한다.
            _se_saved = {k: v for k, v in _fmd.items() if _ps.is_stage_e_key(k)}
            _had_active = bool(_se_saved)
            # ★ RC5-02: raw thermal 은 격리하지 않되(baseline 입력) rollback 대상에는 넣는다.
            _raw_saved = _ps.snapshot_keys(_fmd, _ps.RAW_THERMAL_KEYS)
            _cand.purge_stage_e()                    # ← candidate 안에서만
        except Exception:                            # noqa: BLE001
            _se_saved, _raw_saved, _had_active = {}, {}, False

        st = _ps.run_stage('Stage E (literature-grounded grain corrections)',
                           [sys.executable,
                            os.path.join(scripts, 'run_network_full_corrections.py'),
                            '--case-dir', _cand.dir, '--quiet'],
                           required=False, runner=runner, results_dir=_cand.dir,
                           expects=('full_metrics.json',), verify=_stage_e_wrote)
        if st.ok:
            _cand.publish()                          # ← 통과했을 때만 active 교체
    stages.append(st)
    log.append(st)

    # ★ Stage E 가 어느 baseline 세대를 봤는지 새긴다 — 나중에 둘이 어긋나면 바로 보인다.
    try:
        if os.path.exists(fm_json):
            with open(fm_json) as _f:
                fm_data = json.load(_f)
            if not st.ok:
                # ★ RC4-01: 실패 시에는 값만 되돌리는 게 아니라 **wrapper provenance 도**
                #   옛 것을 유지한다.  옛 코드는 값은 옛 세대인데 parent/run/code 를 새
                #   시도로 바꿔, 게시된 값과 도장이 다른 세대를 가리켰다.
                # ★ RC5-02 (Codex 5회차): 옛 복원은 `_se_saved` 를 **overlay 만** 해서
                #   실패 후보가 **새로 만든** 관리 키가 그대로 남았다 (실측: 실패 실행이
                #   쓴 `future_metric_stage_e = 999` 가 잔존).  "실패 전 상태의 정확한
                #   복원" 이 아니었다.  순서를 Codex 권고대로 바로잡는다:
                #     ① 현재 관리 키 **전수 제거**  ② 이전 active overlay
                #     ③ raw thermal `{present, value}` rollback
                #     ④ 이전 active 가 없으면 상태명을 달리  ⑤ 시도는 별도 파일
                for _k in [k for k in fm_data if _ps.is_stage_e_key(k)]:
                    fm_data.pop(_k, None)                                  # ①
                fm_data.update(_se_saved)                                  # ②
                _ps.restore_keys(fm_data, _raw_saved)                      # ③
                # ④ 이전 세대가 애초에 없었으면 '이전 것으로 복원했다' 는 거짓이다.
                fm_data['stage_e_status'] = ('failed_restored_previous' if _had_active
                                             else 'failed_no_active_generation')
                _ps.atomic_write_json(fm_json, fm_data)
                # ⑤ 실패 시도는 active 필드가 아니라 별도 record 로 (network 와 같은 규약)
                _ps.record_stage_e_attempt(results_dir, prov.get('network_run_id'),
                                           reason='stage_e_verify_failed',
                                           restored=_had_active)
                return stages, prov.get('network_run_id')   # st 는 위에서 stages 에 들어갔다
            fm_data['stage_e_parent_network_run_id'] = prov.get('network_run_id')
            fm_data['stage_e_status'] = 'success'
            # ★ CB-07: "어느 Stage E 코드가 그 baseline 을 변환했는가" 를 복원할 수 있게
            #   Stage E 자신의 세대도 새긴다 (preserve 경로는 옛 baseline 위에서 **현재**
            #   Stage E 코드를 돌리므로 parent id 만으로는 부족하다).
            fm_data['stage_e_run_id'] = _ps.new_run_id()
            fm_data['stage_e_code_sha'] = _ps.code_sha()
            _ps.atomic_write_json(fm_json, fm_data)
    except Exception:                                              # noqa: BLE001
        pass
    return stages, prov.get('network_run_id')


#: `run_pipeline(stop_after=…)` 이 받는 값 — 이 밖의 값은 ValueError (조용히 전체를 돌지 않는다).
#:   'contact'  = 접촉 분석까지 (LHS ① 접촉 위상 — 1저자 09-29 밤 "단독적으로 하나씩")
#:   'coverage' = 접촉 → 피복 (Hertz 명명 · legacy Physics · physics v2) 까지 — network · Stage E 없음
#:                (1저자 09-29 밤 cap (physics) coverage 새 판 병기 — "① + cap coverage 한 번에")
#:   'network'  = 접촉 → 피복 → network solver → 머지 · 채널 판정 → 망 정지 계약 — Stage E · 이중 공극률 · 고급 분석 · 그림 없음
#:                (τ 인계 tau2 · f 와 ④a 협착 전력 몫 · Codex 요청서 §5-2 · 1저자 10-05 "먼저 구현하고 같이 요청서로")
PIPELINE_STOP_AFTER = (None, 'contact', 'coverage', 'network')


def _stopped_after(stages, log, where, network_run_id=None):
    """`run_pipeline(stop_after=where)` 의 반환 — 지금까지의 단계로 상태를 판정한다 (끝의 판정과 같은 `_ps.summarize`).
    network_run_id = 'network' 정지에서 이번 실행의 망 세대 (contact · coverage 는 망을 안 푼다 → None)."""
    status, failed_stages = _ps.summarize(stages)
    return {'success': status != 'failed', 'status': status, 'log': log, 'network_run_id': network_run_id,
            'failed_stages': [s.get('step') for s in failed_stages], 'stopped_after': where}


def _atoms_only_porosity_written(results_dir):
    """공극률 단계의 내용 계약 — 이번 실행이 full_metrics.json 에 `porosity_status` (판정 · 사유) 를 적었는가.
    atoms-only 분기가 바로 앞에서 그 키가 없는 새 full_metrics (mode_note · has_contacts) 를 쓰므로, 있으면 이번 실행이 쓴 것이다."""
    try:
        with open(os.path.join(results_dir, 'full_metrics.json'), encoding='utf-8') as _f:
            return isinstance(json.load(_f).get('porosity_status'), str)
    except Exception:                                              # noqa: BLE001
        return False


def _atoms_only_porosity(results_dir, scale, atom_files, log):
    """★ 10-07 (1저자 보고 그림) — atom 덤프 + 판 메시만 올린 케이스 (접촉 덤프 없음) 의 공극률 · 두께 (판 간격).
    `scripts/atoms_only_porosity.py` = 접촉 분석과 **같은 함수** (calc_porosity · calc_porosity_union_exact · get_plate_z · 같은 원자 읽기) —
    새 식 없음 · 판 메시가 없으면 계산하지 않고 사유만 적는다 · 판이 입자 윗면보다 위면 입자 윗면 기준 값도 따로.
    viewer 전용 성공 계약은 그대로 — 이 단계가 실패해도 success 이고 사유를 full_metrics 에 남긴다 (optional 단계).
    stop_after 가 있는 호출은 여기 오지 않는다 (`_atoms_only_refused` · LHSC-02 · 계산 · 러너 호출 없음 그대로)."""
    cmd = [sys.executable, os.path.join(app.config['SCRIPTS_FOLDER'], 'atoms_only_porosity.py'), results_dir,
           '--scale', str(scale)]
    if atom_files:
        cmd += ['--atom-dump'] + list(atom_files)
    _st = _ps.run_stage('Porosity (atoms only)', cmd, required=False, expects=('full_metrics.json',),
                        results_dir=results_dir, verify=_atoms_only_porosity_written)
    log.append(_st)
    if _st.ok:
        return
    try:                                                           # 단계가 사유를 못 적고 죽었다 — 사유를 대신 적는다 (옛 값을 남기지 않는다)
        fm_path = os.path.join(results_dir, 'full_metrics.json')
        with open(fm_path, encoding='utf-8') as _f:
            fm = json.load(_f)
        if not isinstance(fm.get('porosity_status'), str):
            tail = [ln for ln in (_st.get('stderr') or '').strip().splitlines() if ln.strip()]
            fm['porosity_status'] = 'failed: ' + (tail[-1][:300] if tail else f"공극률 단계 실패 (rc {_st.get('rc')})")
            fm.setdefault('porosity_source', 'atoms_only')
            _ps.atomic_write_json(fm_path, fm)
    except Exception:                                              # noqa: BLE001 — viewer 전용 성공은 지킨다
        pass


def _atoms_only_refused(stop_after, why, log):
    """★ Codex `LHSC-02` (09-30 · P1 · 1저자 비준): 분석 단계를 명시적으로 요청했는데 (`stop_after`) 접촉 파일이 없다 —
    viewer 전용 atoms-only 조기 반환으로 **success 를 내지 않는다**.  계산 · 도장 · 러너 호출 없이 failed 로 돌려준다
    (배치 `lhs_webapp_batch` 의 상태식 `status or ('done' if success else 'failed')` 도 failed · 재개 때 다시 돈다).
    `stop_after=None` (웹앱 viewer) 은 이 함수를 거치지 않는다 — 옛 동작 그대로 (test_pipeline_provenance T11h).
    """
    return {'success': False, 'status': 'failed', 'error': why, 'network_run_id': None,
            'log': list(log) + [{'step': f'Atoms-only refused (stop_after={stop_after})', 'stdout': '',
                                 'stderr': why, 'rc': 1}],
            'failed_stages': ['contact files missing'], 'stopped_after': stop_after, 'atoms_only': True}


#: `stop_after='coverage'` 의 내용 계약 (★ Codex `LHSC-03` · 09-30) — `coverage_status_physics_v2` 가 'ok' 면 반드시 **값이 있어야**
#:   하는 v2 키 (None 불가 · `cap_conflict_frac_*` 는 접촉 0 인 침대에서 None 이 정상이라 여기서 빼고 `_v2_frac_ok` 가 분모와 함께 본다 · R3), 'blank: <사유>' 면 있어야 하는
#:   진단 키 (값은 None 가능).  생산자 = `scripts/coverage_physics_vs_hertzian.py` `_PhysicsV2Book.keys` 와 compute_case 의 내부
#:   오류 경로 — 키를 바꾸면 여기와 test_pipeline_provenance T11i · T11j 를 같이 바꾼다.
COVERAGE_V2_OK_KEYS = ('area_AM전체_SE_total_physics_v2', 'area_SE_SE_total_physics_v2', 'area_AM전체_AM_total_physics_v2',
                       'n_contacts_physics_v2', 'n_cap_branch_physics_v2', 'cap_conflict_n_physics_v2',
                       'cap_conflict_n_by_pair_physics_v2', 'A_binding_counts_total_physics_v2',
                       'A_binding_counts_AM_SE_physics_v2', 'am_denominator_physics_v2',
                       'n_contacts_unknown_id_physics_v2', 'n_contact_failures_physics_v2', 'rule_physics_v2',
                       'h_film_sim_physics_v2')
COVERAGE_V2_DIAG_KEYS = ('n_contacts_unknown_id_physics_v2', 'n_contact_failures_physics_v2', 'rule_physics_v2',
                         'am_denominator_physics_v2')
#: LHSC-03 R2 (Codex 09-30 밤) — 값 검사의 분류 (생산자 = `coverage_physics_vs_hertzian._PhysicsV2Book.keys`)
COVERAGE_V2_AREA_KEYS = ('area_AM전체_SE_total_physics_v2', 'area_SE_SE_total_physics_v2', 'area_AM전체_AM_total_physics_v2')
COVERAGE_V2_COUNT_DICT_KEYS = ('cap_conflict_n_by_pair_physics_v2', 'A_binding_counts_total_physics_v2',
                               'A_binding_counts_AM_SE_physics_v2')
COVERAGE_V2_DENOM_KEYS = ('n_am', 'n_free_surface_nonpositive', 'n_coverage_clipped_100', 'n_radius_invalid')
#: LHSC-03 R3 (Codex 재검증 2 · 09-30 밤 · 1저자 비준) — 개수 dict 의 필수 분류 집합 · 분율 반올림 규약 = 생산자 `_PhysicsV2Book.PAIRS` ·
#:   `BINDINGS` · `round(n_conf / n, 6)` 와 같아야 한다 (test_pipeline_provenance T11p 가 생산자 상수와 대조한다 — 여기만 바꾸면 거짓 실패).
COVERAGE_V2_PAIR_KEYS = ('AM_SE', 'SE_SE', 'AM_AM', 'other')
COVERAGE_V2_BINDING_KEYS = ('elastic', 'tabor', 'volume', 'geom', 'none')
COVERAGE_V2_FRAC_ROUND = 6
#: LHSC-03-R4 (Codex 재검증 3 · 1저자 비준) — 피복률은 round(…, 3) 로 실린다 (생산자 `keys`) → 비교 여유 = 반올림 반폭
COVERAGE_V2_COV_TOL = 0.0005
#: blank 판정에서 값이 있어도 되는 키 (진단 · 규약) — 그 밖의 `*_physics_v2` 는 None (또는 없음) 이어야 한다 (물리 값 잔재 금지)
COVERAGE_V2_BLANK_ALLOWED = ('coverage_status_physics_v2', 'rule_physics_v2', 'h_film_sim_physics_v2', 'am_denominator_physics_v2',
                             'n_contacts_unknown_id_physics_v2', 'n_contact_failures_physics_v2')


def _v2_int(v, lo=0):
    """명시적 정수 (bool 제외 · 실수 1.0 · NaN · 문자열 아님) 이고 lo 이상."""
    return isinstance(v, int) and not isinstance(v, bool) and v >= lo


def _v2_num(v):
    """유한 실수 (bool · 문자열 · NaN · ±inf 아님).  10**400 같은 큰 정수는 예외 없이 False (LHSC-03 R3)."""
    import math as _math
    if isinstance(v, bool) or not isinstance(v, (int, float)):
        return False
    try:
        return _math.isfinite(float(v))
    except OverflowError:
        return False


def _v2_count_dict(d, keys):
    """개수 원장 — 생산자의 분류 집합과 **정확히** 같은 키 · 값은 명시적 비음수 정수 (빈 dict · 모르는 분류 · 실수 개수는 거부 · LHSC-03 R3)."""
    return isinstance(d, dict) and set(d) == set(keys) and all(_v2_int(v) for v in d.values())


def _v2_frac_ok(v, num, den):
    """분율 = 생산자 규약 `round(num / den, 6)` (분모 0 이면 None 만) — 값 · 분모의 공존을 본다 (재계산이 아니라 장부 대조 · LHSC-03 R3)."""
    if den == 0:
        return v is None
    return _v2_num(v) and float(v) == round(num / den, COVERAGE_V2_FRAC_ROUND)


def _v2_denom_ok(diag, ok):
    """`am_denominator_physics_v2` — n_am 은 **명시적** 비음수 정수 (누락을 0 으로 채우지 않는다 · LHSC-03 R2).
    ok: 네 개수가 다 있고 무효 분모 둘 = 0 · 클립 수 ≤ n_am.  blank: None (생산자 내부 오류 경로) 또는 있는 개수가 정수 · ≤ n_am."""
    if diag is None:
        return not ok
    if not isinstance(diag, dict) or not _v2_int(diag.get('n_am')):
        return False
    if not all(_v2_int(diag[k]) for k in COVERAGE_V2_DENOM_KEYS if k in diag):
        return False
    n_am = diag['n_am']
    if ok:
        return (all(k in diag for k in COVERAGE_V2_DENOM_KEYS) and diag['n_free_surface_nonpositive'] == 0
                and diag['n_radius_invalid'] == 0 and diag['n_coverage_clipped_100'] <= n_am)
    return all(diag.get(k, 0) <= n_am for k in COVERAGE_V2_DENOM_KEYS[1:])


def _v2_ok_record(fm):
    """status 'ok' 레코드의 값 계약 (LHSC-03 R2) — 계산을 복제하지 않고 **타입 · 범위 · 공존**만 본다."""
    if any(fm.get(k) is None for k in COVERAGE_V2_OK_KEYS):
        return False
    diag = fm.get('am_denominator_physics_v2')
    if not _v2_denom_ok(diag, ok=True):
        return False
    if not all(_v2_num(fm[k]) and float(fm[k]) >= 0.0 for k in COVERAGE_V2_AREA_KEYS):
        return False
    n, ncap, nconf = (fm.get('n_contacts_physics_v2'), fm.get('n_cap_branch_physics_v2'), fm.get('cap_conflict_n_physics_v2'))
    if not (_v2_int(n) and _v2_int(ncap) and _v2_int(nconf) and ncap <= n and nconf <= ncap):
        return False
    if not (_v2_int(fm.get('n_contacts_unknown_id_physics_v2')) and fm.get('n_contact_failures_physics_v2') == 0
            and _v2_int(fm.get('n_contact_failures_physics_v2'))):       # 접촉 실패와 ok 는 공존하지 않는다
        return False
    #  LHSC-03 R3 — 개수 원장 · 분율 · 집계 항등식 (물성 · 피복식 재계산이 아니다 — 생산자 장부의 **구조**만 본다)
    pairs = fm.get('cap_conflict_n_by_pair_physics_v2')
    bt, bam = fm.get('A_binding_counts_total_physics_v2'), fm.get('A_binding_counts_AM_SE_physics_v2')
    if not (_v2_count_dict(pairs, COVERAGE_V2_PAIR_KEYS) and _v2_count_dict(bt, COVERAGE_V2_BINDING_KEYS)
            and _v2_count_dict(bam, COVERAGE_V2_BINDING_KEYS)):
        return False
    if sum(pairs.values()) != nconf or sum(bt.values()) != n or any(bam[b] > bt[b] for b in COVERAGE_V2_BINDING_KEYS):
        return False                                               # Σ 쌍별 충돌 = nconf · Σ 결속 = n · AM–SE 결속 ≤ 총 결속 (분류마다)
    for k, den in (('cap_conflict_frac_physics_v2', n), ('cap_conflict_frac_cap_branch_physics_v2', ncap)):
        if k not in fm or not _v2_frac_ok(fm[k], nconf, den):       # 키 필수 · 분모 > 0 이면 round(비, 6) · 분모 0 이면 None
            return False
    a_amse, a_sese, a_amam = (float(fm[k]) for k in COVERAGE_V2_AREA_KEYS)
    n_amse = sum(bam.values())
    if n == 0 and (a_amse > 0.0 or a_sese > 0.0 or a_amam > 0.0):
        return False                                               # 접촉 0 인데 양수 총 면적
    if a_amse > 0.0 and n_amse == 0:
        return False                                               # AM–SE 면적은 AM–SE 접촉에서만 쌓인다
    if n_amse + int(a_sese > 0.0) + int(a_amam > 0.0) > n:
        return False                                               # 쌍 종류는 서로소 — 양수 면적마다 그 종류의 접촉이 하나는 있어야
    if diag['n_am'] == 0 and (a_amse > 0.0 or a_amam > 0.0 or n_amse > 0 or pairs['AM_SE'] > 0 or pairs['AM_AM'] > 0):
        return False                                               # AM 이 없으면 AM 이 낀 면적 · 결속 · 충돌이 있을 수 없다 (SE-only 의 정상 0 과 구별)
    if not (isinstance(fm.get('rule_physics_v2'), str) and fm['rule_physics_v2'].strip()):
        return False
    if not (_v2_num(fm.get('h_film_sim_physics_v2')) and float(fm['h_film_sim_physics_v2']) > 0.0):
        return False
    cov = {k: v for k, v in fm.items() if k.startswith('coverage_') and k.endswith('_physics_v2')
           and k != 'coverage_status_physics_v2'}
    if not all(v is not None and _v2_num(v) and 0.0 <= float(v) <= 100.0 for v in cov.values()):
        return False
    #  LHSC-03-R4 — 피복률 · 장부 공존 (Codex 최소 해제 그대로 · 피복식 재계산이 아니다)
    if ncap != bt['tabor'] + bt['volume'] + bt['geom']:
        return False                                               # cap 가지 = binding tabor · volume · geom (elastic · none 은 cap 가지가 아니다)
    tol = COVERAGE_V2_COV_TOL
    if any(float(v) > 50.0 + tol for k, v in cov.items() if k.endswith('_std_physics_v2')):
        return False                                               # [0, 100] 값의 population std 는 최대 50 %p
    n_am, n_clip = diag['n_am'], diag['n_coverage_clipped_100']
    if n_am > 0:                                                   # AM 이 있으면 전체 피복률이 있어야 한다
        if 'coverage_AM_mean_physics_v2' not in cov:
            return False
        if n_amse == 0 and (n_clip != 0 or any(float(v) != 0.0 for v in cov.values())):
            return False                                           # AM–SE 접촉 (결속) 0 → 분자 0 → 평균 · std · 클립 0 (총 면적 반올림으로 역추론하지 않는다)
        if float(cov['coverage_AM_mean_physics_v2']) + tol < 100.0 * n_clip / n_am:
            return False                                           # 클립 입자는 100 — 입자 수 가중 평균 ≥ 100·n_clip/n_am (n_clip = n_am 이면 100)
        #  LHSC-03-R5 (Codex 재검증 4) — 전체 클립 끝점: n_clip = n_am 이면 생산자가 저장한 모든 AM 값이 **정확히 100** (raw > 100 → min(raw, 100))
        #  이라 비어 있지 않은 어떤 부분집합 (상) 도 평균 100 · population std 0 이다.  존재하는 키만 본다 (없는 상의 키를 요구하지 않는다) ·
        #  부분 클립 (n_clip < n_am) 의 std 는 제한하지 않는다 (일반 분산 상한이 아니다) · 반올림 계약 = 생산자 셋째 자리 (tol 0.0005).
        if n_clip == n_am:
            if any(abs(float(v) - 100.0) > tol for k, v in cov.items() if k.endswith('_mean_physics_v2')):
                return False                                       # 존재하는 상별 · 전체 평균 = 100
            if any(float(v) > tol for k, v in cov.items() if k.endswith('_std_physics_v2')):
                return False                                       # 존재하는 상별 std = 0
        return True
    return not cov                                                 # AM 0 개 = 피복률 키 없음 (연산 완료 · 적용 대상 없음)


def _v2_blank_record(fm):
    """status 'blank: 사유' 레코드 — 사유 · 진단 키가 있고 물리 값 잔재가 없다 (LHSC-03 R2).  진단 일부 None 은 생산자 내부 오류
    경로 (`coverage_physics_vs_hertzian` 의 except) 라 그대로 받는다."""
    if not all(k in fm for k in COVERAGE_V2_DIAG_KEYS):
        return False
    for k in ('n_contacts_unknown_id_physics_v2', 'n_contact_failures_physics_v2'):
        if fm[k] is not None and not _v2_int(fm[k]):
            return False
    if not _v2_denom_ok(fm['am_denominator_physics_v2'], ok=False):
        return False
    _rule = fm['rule_physics_v2']                                   # 규약 문자열 — 진단이라 None 도 받는다 (값이 있으면 문자열)
    if _rule is not None and not (isinstance(_rule, str) and _rule.strip()):
        return False
    _hf = fm.get('h_film_sim_physics_v2')                          # 막 두께 — 내부 오류 경로는 키가 없고 · 있으면 None 또는 유한 양수 (R3 · P3)
    if _hf is not None and not (_v2_num(_hf) and float(_hf) > 0.0):
        return False
    return all(v is None for k, v in fm.items() if k.endswith('_physics_v2') and k not in COVERAGE_V2_BLANK_ALLOWED)


def _coverage_v2_written(results_dir):
    """`stop_after='coverage'` 의 내용 계약 — 이번 피복 단계가 이 침대의 physics v2 **판정**을 full_metrics.json 에 썼는가.

    접촉 단계는 causal (옛 full_metrics 를 치우고 빈 자리에서 새로 쓴다) 이라, 그 뒤에 `coverage_status_physics_v2` 가 있으면
    이번 피복 단계가 쓴 것이다.  ★ 옛 피복 스크립트는 데이터 폴더가 코드 밖이면 (worktree 런처 · LHS 배치) "[skip]" 을 찍고
    **rc 0 으로 아무것도 안 썼다** — 그것을 done 으로 받지 않는다.
    ★ `LHSC-03` (Codex 09-30): 문자열이면 다 받던 첫 판은 `''` · `'not_run'` · 사유 없는 `'blank: '` · 값 키 없는 `'ok'` 도
    통과시켰다.  ★★ `LHSC-03` R2 (Codex 09-30 밤): 둘째 판은 n_am 누락을 0 으로 읽고 (`(diag.get('n_am') or 0) > 0`) 값은 None 만
    봐서, 실제 생산자 출력에서 출발한 변이 10 종 (n_am 삭제 · 음수 · NaN · 면적 NaN · 문자열 · 음수 · 피복률 음수 · ok 인데 무효 분모 ·
    ok 인데 접촉 실패 · blank 인데 양수 값) 을 다 받았다 — 둘은 필수 단계까지 done.  이제 = `_v2_ok_record` (타입 · 범위 · 공존) 또는
    `_v2_blank_record` (사유 · 진단 · 잔재 없음).  'blank: …' 도 이 침대에 대한 v2 의 판정이다 (사유가 행에 남는다).
    """
    try:
        with open(os.path.join(results_dir, 'full_metrics.json'), encoding='utf-8') as _f:
            _fm = json.load(_f)
    except Exception:                                              # noqa: BLE001 — 못 읽으면 판정 없음 = 실패
        return False
    if not isinstance(_fm, dict):
        return False
    st = _fm.get('coverage_status_physics_v2')
    if not isinstance(st, str):
        return False
    if st == 'ok':
        return _v2_ok_record(_fm)
    if st.startswith('blank:') and st[len('blank:'):].strip():
        return _v2_blank_record(_fm)
    return False


def _coverage_stage(cmd, results_dir, stop_after):
    """피복 단계 (`coverage_physics_vs_hertzian.py`).  명령은 두 모드에서 **같다** (test_pipeline_provenance T11b).

    전체 실행: optional · 산출물 계약 없음 (옛 계약 그대로).
    stop_after='coverage': 이 모드의 산출물이 곧 피복 단계라 **required + 내용 검증** (`_coverage_v2_written`) —
    실패하면 status 가 failed 가 되어 배치가 재개 때 다시 돈다 (partial 은 건너뛴다).
    """
    if stop_after == 'coverage':
        return _ps.run_stage('Coverage Physics vs Hertzian', cmd, required=True,
                             expects=('full_metrics.json',), results_dir=results_dir,
                             verify=_coverage_v2_written)
    return _ps.run_stage('Coverage Physics vs Hertzian', cmd, required=False,
                         expects=(), results_dir=results_dir)


def run_pipeline(case_id, mode, type_map, scale=1000,
                 preserve_network=False, network_snapshot=None, *,
                 figures=True, auto_db=True, stop_after=None):
    """Run the DEM analysis pipeline for a case.

    preserve_network : True 면 network solver 를 **호출하지 않고** network_snapshot 을
                       복원해 그 baseline 으로 Stage E 를 만든다 (코드리뷰 F-02).
    network_snapshot : pipeline_service.snapshot_network() 가 만든 임시 디렉터리.
    figures          : False 면 그림 단계 (generate_*figures*) 만 건너뛴다 — 계산 단계는 그대로.
    auto_db          : False 면 끝의 자동 DB 재구축 (build_metrics_db.py 백그라운드) 을 건너뛴다.
                       ★ 두 키워드는 LHS 일괄 배치 (`scripts/lhs_webapp_batch.py`, 2026-09-28) 용이다 — 130 건에
                         그림 수백 장과 동시 DB 재구축 130 번은 필요 없다.  기본값 = 웹앱 동작 그대로
                         (test_pipeline_provenance T9: 뺀 것은 그림 · DB 뿐이고 계산 단계 순서가 같다).
    stop_after       : None (기본 · 전 단계) · 'contact' · 'coverage' · 'network' (`PIPELINE_STOP_AFTER`).
                       'contact'  — 접촉 분석 단계 (`analyze_contacts[_bimodal].py`) 가 성공하면 거기서 멈춘다
                                    (network · Stage E · 고급 분석 없음).  ★ LHS 묶음별 채우기
                                    (1저자 2026-09-29 밤 "단독적으로 하나씩") 용.
                       'coverage' — 접촉 → 피복 (`coverage_physics_vs_hertzian.py` — legacy Physics + physics v2)
                                    에서 멈춘다 (network · Stage E 없음).  ★ cap (physics) coverage 새 판 인계
                                    (1저자 09-29 밤).  이 모드에서는 피복 단계가 **required + 내용 검증**이다
                                    (`_coverage_stage` — rc 0 인데 판정을 안 쓴 실행은 failed).
                       'network'  — 접촉 → 피복 → network solver → 머지 · 채널 판정 → **망 정지 계약**
                                    (`_ps.network_stop_verdict` · required) 에서 멈춘다 (Stage E · 이중 공극률 · 고급 분석 없음).
                                    ★ τ 인계 (tau2 · f) · ④a 협착 전력 몫 (Codex 요청서 §5-2 · 1저자 10-05).  피복 단계는
                                    전체 실행과 같은 optional 계약 · preserve_network 와 함께 주면 ValueError (test T12).
                       멈추기 전 명령은 전체 실행과 **인자까지 같다** (test_pipeline_provenance T10 · T11 · T12).
                       다른 값은 ValueError (조용히 전체를 돌지 않는다).
                       ★ 접촉 파일이 없는 atoms-only 입력 (raw atom-only · CSV-only) 은 stop_after 가 있으면 **failed**
                         (`_atoms_only_refused` · Codex `LHSC-02` — 옛 판은 viewer 전용 조기 반환으로 계산 없이 success/done) ·
                         None 이면 viewer 전용 성공 그대로 (T11g · T11h).
    """
    if stop_after not in PIPELINE_STOP_AFTER:
        raise ValueError(f"stop_after={stop_after!r} — None · 'contact' · 'coverage' · 'network' 만 허용")
    if stop_after == 'network' and preserve_network:
        raise ValueError("stop_after='network' 은 망을 새로 푸는 정지점이다 — preserve_network (solver 미호출 · 옛 세대 복원) 와 섞지 않는다")
    # Clear pyc cache to ensure latest code runs
    import glob as globmod
    scripts_dir = os.path.join(os.path.dirname(__file__), '..', 'scripts')
    for pyc in globmod.glob(os.path.join(scripts_dir, '__pycache__', '*.pyc')):
        os.remove(pyc)

    case_dir = get_case_dir(case_id)
    results_dir = get_results_dir(case_id)
    figures_dir = os.path.join(results_dir, 'figures')
    os.makedirs(figures_dir, exist_ok=True)
    scripts = app.config['SCRIPTS_FOLDER']

    # Find atom, contact, mesh, and input files
    atom_files = sorted(globmod.glob(os.path.join(case_dir, 'atom_*.liggghts')))
    contact_files = sorted(globmod.glob(os.path.join(case_dir, 'contact_*.liggghts')))
    mesh_files = sorted(globmod.glob(os.path.join(case_dir, '*.stl')))
    input_files = sorted(globmod.glob(os.path.join(case_dir, 'input*.liggghts')))

    # Pre-parsed CSV fallback: webapp/uploads may have only atoms.csv/contacts.csv
    # (archive-migrated cases retain CSVs but not original LIGGGHTS dumps).
    pre_atoms_csv = os.path.join(case_dir, 'atoms.csv')
    pre_contacts_csv = os.path.join(case_dir, 'contacts.csv')
    pre_mesh_info = os.path.join(case_dir, 'mesh_info.json')
    has_pre_parsed = os.path.exists(pre_atoms_csv) and os.path.exists(pre_contacts_csv)
    has_pre_atoms_only = os.path.exists(pre_atoms_csv) and not os.path.exists(pre_contacts_csv)

    # HYBRID mode: atoms.csv (no atom_*.liggghts) + contact_*.liggghts.
    # User lost the atom dump but still has the pre-parsed atoms.csv and
    # raw contact dump. Copy atoms.csv in first so parse_liggghts knows to
    # skip atom parsing, then proceed to the normal full pipeline below.
    if (has_pre_atoms_only and contact_files) and not atom_files:
        import shutil as _sh
        _sh.copy2(pre_atoms_csv, os.path.join(results_dir, 'atoms.csv'))
        print(f"  [Hybrid] Copied pre-existing atoms.csv; will parse contacts from LIGGGHTS")

    if not atom_files or not contact_files:
        if not has_pre_parsed:
            # ATOMS-ONLY mode: if atom_*.liggghts exists but no contacts,
            # parse atoms alone and return — webapp will still serve 3D viewer.
            if atom_files and not contact_files:
                if stop_after is not None:                         # ★ LHSC-02 — 분석 단계 요청인데 접촉 파일이 없다: viewer 성공 금지
                    return _atoms_only_refused(stop_after, 'atom_*.liggghts 만 있고 contact_*.liggghts 가 없다 — '
                                               f'stop_after={stop_after!r} 는 접촉 분석이 필요하다 (atoms-only viewer 모드 아님)', [])
                log = []
                cmd = [sys.executable, os.path.join(scripts, 'parse_liggghts.py')]
                cmd += atom_files + mesh_files + input_files + ['-o', results_dir]
                result = subprocess.run(cmd, capture_output=True, text=True, timeout=None)
                log.append({'step': 'Parse (atoms only)', 'stdout': result.stdout,
                            'stderr': result.stderr, 'rc': result.returncode})
                if result.returncode != 0:
                    return {'error': f'Atoms parse failed: {result.stderr}', 'log': log}
                # Minimal full_metrics so UI doesn't explode
                atoms_only_meta = {
                    'mode_note': 'atoms_only — 3D viewer enabled, contact-based metrics skipped',
                    'has_contacts': False,
                }
                fm_path = os.path.join(results_dir, 'full_metrics.json')
                with open(fm_path, 'w') as f:
                    json.dump(atoms_only_meta, f, indent=2)
                # ★ 10-07 — 판 메시가 있으면 공극률 · 두께 (판 간격) — 접촉이 필요 없는 정의만 · 접촉 분석과 같은 함수
                _atoms_only_porosity(results_dir, scale, atom_files, log)
                return {'success': True, 'log': log, 'atoms_only': True}
            # Hybrid mode falls through to the full pipeline below — atoms.csv
            # is already in results_dir, and parse_liggghts will skip atom parsing.
            if has_pre_atoms_only and contact_files:
                pass
            # ATOMS-ONLY CSV mode: user uploaded atoms.csv only (LIGGGHTS dump
            # was deleted). Copy CSV into results_dir so 3D viewer works.
            elif has_pre_atoms_only:
                if stop_after is not None:                         # ★ LHSC-02 — CSV-only 도 같은 계약 (Codex 반례 `atoms_only`)
                    return _atoms_only_refused(stop_after, 'atoms.csv 만 있고 contacts.csv · contact_*.liggghts 가 없다 — '
                                               f'stop_after={stop_after!r} 는 접촉 분석이 필요하다 (atoms-only viewer 모드 아님)', [])
                import shutil as _sh
                log = []
                _sh.copy2(pre_atoms_csv, os.path.join(results_dir, 'atoms.csv'))
                if os.path.exists(pre_mesh_info):
                    _sh.copy2(pre_mesh_info, os.path.join(results_dir, 'mesh_info.json'))
                log.append({'step': 'Parse (atoms.csv only)', 'stdout':
                            'atoms.csv copied from case_dir (no contacts)',
                            'stderr': '', 'rc': 0})
                atoms_only_meta = {
                    'mode_note': 'atoms_only_csv — 3D viewer enabled, contact-based metrics skipped',
                    'has_contacts': False,
                }
                fm_path = os.path.join(results_dir, 'full_metrics.json')
                with open(fm_path, 'w') as f:
                    json.dump(atoms_only_meta, f, indent=2)
                _atoms_only_porosity(results_dir, scale, [], log)   # ★ 10-07 — mesh_info.json 이 있으면 공극률 · 두께 (같은 함수)
                return {'success': True, 'log': log, 'atoms_only': True}
            else:
                return {'error': 'atom_*.liggghts 또는 contact_*.liggghts 파일을 찾을 수 없습니다 (CSV fallback도 없음).'}

    log = []
    #: 단계 계약 수집 — 필수 단계가 실패하면 status='failed' 로 내린다 (코드리뷰 F-05).
    #: 옛 코드는 parse 만 검사하고 나머지 rc 는 로그에만 넣은 뒤 무조건 success 를 반환해,
    #: full_metrics 가 없어도 케이스가 'done' 이 됐다.
    stages = []

    # Step 1: Parse (atom + contact + mesh) — skip if CSV already exists
    atoms_csv = os.path.join(results_dir, 'atoms.csv')
    contacts_csv = os.path.join(results_dir, 'contacts.csv')

    if atom_files and contact_files:
        # Normal path: parse LIGGGHTS dumps
        cmd = [sys.executable, os.path.join(scripts, 'parse_liggghts.py')]
        cmd += atom_files + contact_files + mesh_files + input_files + ['-o', results_dir]
        _st = _ps.run_stage('Parse', cmd, required=True,
                            expects=('atoms.csv', 'contacts.csv', ), results_dir=results_dir)
        stages.append(_st); log.append(_st)
        if not _st.ok:
            return {'error': f'Parse failed: {_st["stderr"]}', 'success': False,
                    'status': 'failed', 'log': log,
                    'failed_stages': [_st['step']]}
    elif has_pre_atoms_only and contact_files:
        # Hybrid: atoms.csv (pre-copied into results_dir above) + contact_*.liggghts.
        # parse_liggghts detects the existing atoms.csv and skips atom parsing.
        cmd = [sys.executable, os.path.join(scripts, 'parse_liggghts.py')]
        cmd += contact_files + mesh_files + input_files + ['-o', results_dir]
        _st = _ps.run_stage('Parse (hybrid: atoms.csv + contact LIGGGHTS)', cmd, required=True,
                            expects=('atoms.csv', 'contacts.csv', ), results_dir=results_dir)
        stages.append(_st); log.append(_st)
        if not _st.ok:
            return {'error': f'Hybrid parse failed: {_st["stderr"]}', 'success': False, 'status': 'failed',
                    'log': log, 'failed_stages': [_st['step']]}
    else:
        # CSV fallback: copy pre-parsed CSVs into results_dir
        import shutil as _sh
        _sh.copy2(pre_atoms_csv, atoms_csv)
        _sh.copy2(pre_contacts_csv, contacts_csv)
        if os.path.exists(pre_mesh_info):
            _sh.copy2(pre_mesh_info, os.path.join(results_dir, 'mesh_info.json'))
        log.append({'step': 'Parse (CSV fallback)', 'stdout': 'CSVs copied from case_dir', 'stderr': '', 'rc': 0})

    if mode == 'bimodal':
        # Step 2: Bimodal contact analysis
        cmd = [sys.executable, os.path.join(scripts, 'analyze_contacts_bimodal.py'),
               atoms_csv, contacts_csv, '-o', results_dir,
               '-t', type_map, '-s', str(scale)]
        _st = _ps.run_stage('Bimodal Contact Analysis', cmd, required=True,
                            # ★ RC7-03 (Codex 7회차): fresh 지문은 metadata-only touch 로
                            #   통과한다 = 인과 증거가 아니다.  causal 은 실행 전에 계약
                            #   산출물을 치워 **빈 자리**에서 돌리므로, 실행 후 존재 자체가
                            #   증거다.  실패하면 옛 성공 세대가 그대로 되돌아온다.
                            causal=True,
                            expects=('full_metrics.json', 'atoms_analyzed.csv', 'contacts_analyzed.csv',
                                     'network_summary.csv'), results_dir=results_dir)
        stages.append(_st); log.append(_st)
        # ★ RC7-07: batch·archive 는 contact 실패 시 아래를 건너뛰는데 **main 두 경로만
        #   그냥 통과**했다 → 실패로 되돌아온 옛 full_metrics 위에 network·Stage E 가
        #   돌아 세대가 섞였다.  세 경로의 계약을 같게 맞춘다.
        if not _st.ok:
            return {'error': f'Contact analysis failed: {_st["stderr"][-300:]}',
                    'success': False, 'status': 'failed', 'log': log, 'failed_stages': [_st['step']]}
        if stop_after == 'contact':
            return _stopped_after(stages, log, 'contact')

        # Step 2b: Dual-mode coverage + AM-SE/SE-SE totals (Hertzian vs Physics).
        # Writes coverage_AM_*_mean_physics, area_AM전체_SE_total_physics,
        # area_SE_SE_total_physics into full_metrics.json + coverage_per_am.csv.
        # (+ physics v2 `*_physics_v2` 키 — legacy 옆에, 2026-09-29)
        cmd = [sys.executable, os.path.join(scripts, 'coverage_physics_vs_hertzian.py'), case_id]
        _st = _coverage_stage(cmd, results_dir, stop_after)
        stages.append(_st); log.append(_st)
        if stop_after == 'coverage':
            return _stopped_after(stages, log, 'coverage')

        # Step 2c-2d: Network baseline (또는 보존 복원) → Stage E.
        #   ★ 한 곳(_network_and_stage_e)에서만 수행한다 — 옛 구조는 bimodal 과 standard 가
        #     같은 순서를 각자 구현했고, "보존" 재분석이 solver 를 돌린 뒤 그 결과로 Stage E 를
        #     만들고서야 옛 network 를 덮어써 baseline/Stage E 세대가 섞였다 (F-02/F-17).
        _net_stages, _net_run_id = _network_and_stage_e(
            results_dir, scripts, atoms_csv, contacts_csv, type_map, scale, log,
            preserve_network=preserve_network, network_snapshot=network_snapshot,
            stop_before_stage_e=(stop_after == 'network'))
        stages.extend(_net_stages)
        if stop_after == 'network':
            return _stopped_after(stages, log, 'network', network_run_id=_net_run_id)

        # Step 2e: Dual porosity (sphere-sum + union + overlap%) — auto-compute
        # so the UI shows ε_sphere / ε_union / overlap without a manual rerun.
        try:
            dual_cmd = [sys.executable,
                        os.path.join(scripts, 'recompute_porosity_dual.py'),
                        '--dir', results_dir]
            _st = _ps.run_stage('Dual porosity (sphere-sum / union / overlap)', dual_cmd, required=False,
                                expects=(), results_dir=results_dir)
            stages.append(_st); log.append(_st)
        except Exception as _e:
            log.append({'step': 'Dual porosity (sphere-sum / union / overlap)',
                        'stdout': '', 'stderr': str(_e), 'rc': 1})

        if figures:
            # Step 3: Basic figures
            cmd = [sys.executable, os.path.join(scripts, 'generate_figures_bimodal.py'),
                   results_dir, '-o', figures_dir, '-s', str(scale)]
            _st = _ps.run_stage('Basic Figures', cmd, required=False,
                                expects=(), results_dir=results_dir)
            stages.append(_st); log.append(_st)

        # Step 4: Advanced
        atoms_analyzed = os.path.join(results_dir, 'atoms_analyzed.csv')
        contacts_analyzed = os.path.join(results_dir, 'contacts_analyzed.csv')
        cmd = [sys.executable, os.path.join(scripts, 'advanced_analysis_bimodal.py'),
               atoms_analyzed, contacts_analyzed, '-o', results_dir, '-s', str(scale)]
        _st = _ps.run_stage('Advanced Analysis', cmd, required=False,
                            expects=(), results_dir=results_dir)
        stages.append(_st); log.append(_st)

        if figures:
            cmd = [sys.executable, os.path.join(scripts, 'generate_advanced_figures_bimodal.py'),
                   results_dir, '-o', figures_dir, '-s', str(scale)]
            _st = _ps.run_stage('Advanced Figures', cmd, required=False,
                                expects=(), results_dir=results_dir)
            stages.append(_st); log.append(_st)

        # Step 5: Bimodal specific
        cmd = [sys.executable, os.path.join(scripts, 'bimodal_specific_analysis.py'),
               atoms_analyzed, contacts_analyzed, '-o', results_dir, '-s', str(scale)]
        _st = _ps.run_stage('Bimodal Specific', cmd, required=False,
                            expects=(), results_dir=results_dir)
        stages.append(_st); log.append(_st)

    else:
        # Standard mode
        cmd = [sys.executable, os.path.join(scripts, 'analyze_contacts.py'),
               atoms_csv, contacts_csv, '-o', results_dir,
               '-t', type_map, '-s', str(scale)]
        _st = _ps.run_stage('Contact Analysis', cmd, required=True,
                            # ★ RC7-03: 위 bimodal 과 같은 인과 계약 (fresh → causal).
                            causal=True,
                            expects=('full_metrics.json', 'atoms_analyzed.csv', 'contacts_analyzed.csv',
                                     'network_summary.csv'), results_dir=results_dir)
        stages.append(_st); log.append(_st)
        # ★ RC7-07: main 경로도 batch·archive 와 같게 — 실패하면 여기서 멈춘다.
        if not _st.ok:
            return {'error': f'Contact analysis failed: {_st["stderr"][-300:]}',
                    'success': False, 'status': 'failed', 'log': log, 'failed_stages': [_st['step']]}
        if stop_after == 'contact':
            return _stopped_after(stages, log, 'contact')

        # Dual-mode coverage + AM-SE/SE-SE totals (Hertzian vs Physics).
        # Populates *_mean_physics and area_*_total_physics keys in
        # full_metrics.json + coverage_per_am.csv (COMSOL-ready).
        # (+ physics v2 `*_physics_v2` 키 — legacy 옆에, 2026-09-29)
        cmd = [sys.executable, os.path.join(scripts, 'coverage_physics_vs_hertzian.py'), case_id]
        _st = _coverage_stage(cmd, results_dir, stop_after)
        stages.append(_st); log.append(_st)
        if stop_after == 'coverage':
            return _stopped_after(stages, log, 'coverage')

        # Network baseline (또는 보존 복원) → Stage E — bimodal 과 **같은 함수**를 쓴다.
        _net_stages, _net_run_id = _network_and_stage_e(
            results_dir, scripts, atoms_csv, contacts_csv, type_map, scale, log,
            preserve_network=preserve_network, network_snapshot=network_snapshot,
            stop_before_stage_e=(stop_after == 'network'))
        stages.extend(_net_stages)
        if stop_after == 'network':
            return _stopped_after(stages, log, 'network', network_run_id=_net_run_id)

        # Step 2e: Dual porosity (sphere-sum + union + overlap%) — auto-compute
        # so the UI shows ε_sphere / ε_union / overlap without a manual rerun.
        try:
            dual_cmd = [sys.executable,
                        os.path.join(scripts, 'recompute_porosity_dual.py'),
                        '--dir', results_dir]
            _st = _ps.run_stage('Dual porosity (sphere-sum / union / overlap)', dual_cmd, required=False,
                                expects=(), results_dir=results_dir)
            stages.append(_st); log.append(_st)
        except Exception as _e:
            log.append({'step': 'Dual porosity (sphere-sum / union / overlap)',
                        'stdout': '', 'stderr': str(_e), 'rc': 1})

        if figures:
            cmd = [sys.executable, os.path.join(scripts, 'generate_figures.py'),
                   results_dir, '-o', figures_dir, '-s', str(scale)]
            _st = _ps.run_stage('Basic Figures', cmd, required=False,
                                expects=(), results_dir=results_dir)
            stages.append(_st); log.append(_st)

        atoms_analyzed = os.path.join(results_dir, 'atoms_analyzed.csv')
        contacts_analyzed = os.path.join(results_dir, 'contacts_analyzed.csv')

        cmd = [sys.executable, os.path.join(scripts, 'advanced_analysis.py'),
               atoms_analyzed, contacts_analyzed, '-o', results_dir, '-s', str(scale)]
        _st = _ps.run_stage('Advanced Analysis', cmd, required=False,
                            expects=(), results_dir=results_dir)
        stages.append(_st); log.append(_st)

        if figures:
            cmd = [sys.executable, os.path.join(scripts, 'generate_advanced_figures.py'),
                   results_dir, '-o', figures_dir, '-s', str(scale)]
            _st = _ps.run_stage('Advanced Figures', cmd, required=False,
                                expects=(), results_dir=results_dir)
            stages.append(_st); log.append(_st)

    # ── Auto-DB hook ─────────────────────────────────────────────────────
    # Trigger an incremental rebuild of docs/db/metrics_master.csv so the
    # new case (and its fracture-stage data emitted by analyze_contacts.py
    # under the 'fracture' results block) lands in the master table without
    # any manual run. Background Popen — does not block the upload UI.
    # Incremental mode reuses unchanged cases via the mtime cache, so the
    # actual work is bounded by the new/changed full_metrics.json files
    # (typically a few seconds for one case).
    if auto_db:
        try:
            subprocess.Popen(
                [sys.executable, os.path.join(scripts, 'build_metrics_db.py')],
                cwd=os.path.dirname(scripts),
                stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
            )
            log.append({'step': 'Auto-DB Rebuild (background)',
                        'stdout': 'incremental build_metrics_db dispatched',
                        'stderr': '', 'rc': 0})
        except Exception as e:
            log.append({'step': 'Auto-DB Rebuild (background)',
                        'stdout': '', 'stderr': str(e), 'rc': 1})

    # ── 단계 계약 판정 (F-05) ───────────────────────────────────────────────
    #   done    = 필수 단계 전부 성공
    #   partial = 선택 단계만 실패 (예: Stage E 실패 — baseline 은 살아 있다)
    #   failed  = 필수 단계 실패 (network 미산출 등) → 케이스를 done 으로 올리지 않는다
    status, failed_stages = _ps.summarize(stages)
    return {'success': status != 'failed', 'status': status, 'log': log,
            'network_run_id': locals().get('_net_run_id'),
            'failed_stages': [s.get('step') for s in failed_stages]}

def generate_report(case_id, case_name='', notes=''):
    """Generate markdown report from analysis results."""
    results_dir = get_results_dir(case_id)
    figures_dir = os.path.join(results_dir, 'figures')

    now = datetime.now().strftime('%y%m%d')
    title = case_name or case_id

    lines = []
    lines.append(f'# {now}_{title}_DEM_Analysis\n')
    lines.append(f'> **날짜**: {datetime.now().strftime("%Y-%m-%d")}')
    lines.append(f'> **케이스**: {title}')
    if notes:
        lines.append(f'> **메모**: {notes}')
    lines.append('')
    lines.append('---\n')

    # Load summary CSV if exists
    summary_file = os.path.join(results_dir, 'contact_summary.csv')
    if os.path.exists(summary_file):
        import pandas as pd
        df = pd.read_csv(summary_file)
        lines.append('## 1. Contact Summary\n')
        lines.append(df.to_markdown(index=False))
        lines.append('')

    # Load atom stats
    atom_stats = os.path.join(results_dir, 'atom_statistics.csv')
    if os.path.exists(atom_stats):
        import pandas as pd
        df = pd.read_csv(atom_stats)
        lines.append('## 2. Particle Statistics\n')
        lines.append(df.to_markdown(index=False))
        lines.append('')

    # Figures
    if os.path.isdir(figures_dir):
        pngs = sorted(globmod.glob(os.path.join(figures_dir, '*.png')))
        if pngs:
            lines.append('## 3. Generated Figures\n')
            for png in pngs:
                fname = os.path.basename(png)
                lines.append(f'### {fname}\n')
                lines.append(f'![{fname}](figures/{fname})\n')

    # Tags
    lines.append('---\n')
    lines.append('#DEM #analysis #ASSB #composite-cathode\n')

    report = '\n'.join(lines)
    report_path = os.path.join(results_dir, 'report.md')
    with open(report_path, 'w') as f:
        f.write(report)
    return report

# ─── Claude AI Analysis ────────────────────────────────────────────────────

def _generate_ai_analysis(all_metrics, case_names, title, notes):
    """Use Claude API to generate deep analysis of comparison data."""
    api_key = os.environ.get('ANTHROPIC_API_KEY', '')
    if not api_key:
        return None

    try:
        import anthropic
        client = anthropic.Anthropic(api_key=api_key)
    except ImportError:
        return None
    except Exception:
        return None

    # Build data summary for Claude
    import pandas as pd
    #  ★ 09-30 (웹앱 ① · J20-l) — 화면과 같은 한정어 (AI 가 쌍 렌즈 union 을 문헌 union 으로 읽지 않게)
    display_keys = [
        ('P:S', 'ps_ratio'), ('Porosity ε_sphere(%)', 'porosity'),
        ('Porosity ε_union pair-lens(%)', 'porosity_union'),
        ('Overlap pair-lens(%)', 'overlap_fraction_pct'),
        ('Porosity ε_union exact MC(%)', 'porosity_union_exact_pct'),
        ('Thickness plate gap(μm)', 'thickness_um'),
        ('AM-SE Total(μm²)', 'area_AM전체_SE_total'),
        ('SE-SE Total(μm²)', 'area_SE_SE_total'),
        ('SE-SE N', 'area_SE_SE_n'),
        ('SE-SE Mean Area(μm²)', 'area_SE_SE_mean'),
        ('SE-SE CN', 'se_se_cn'),
        ('SE-SE CN std', 'se_se_cn_std'),
        ('SE Cluster', 'n_components'),
        ('Percolation(%)', 'percolation_pct'),
        ('Top Reachable(%)', 'top_reachable_pct'),
        ('Tortuosity', 'tortuosity_mean'),
        ('Tortuosity all-SE (geometric)', 'tortuosity_all_mean'),   # 기하 τ 전체판 (10-02) — 표본 200 쌍 아님
        ('Ionic Active AM(%)', 'ionic_active_pct'),
        ('Coverage AM_P Hertz-family(%)', 'coverage_AM_P_mean'),
        ('Coverage AM_S Hertz-family(%)', 'coverage_AM_S_mean'),
        #  ⑥ 10-06 (C2-⑥ · LHS-25) — Physics = 합집합 cap (겹침 한 번 · AM–AM 가림 제외 · 세대 2 면적) · 옛 합-클립 (100 % 포화) 이 아니다
        ('Coverage AM_P Physics union-of-caps g2(%)', 'coverage_AM_P_mean_physics_union'),
        ('Coverage AM_S Physics union-of-caps g2(%)', 'coverage_AM_S_mean_physics_union'),
    ]
    rows = []
    for i, name in enumerate(case_names):
        row = {'Case': name}
        for label, key in display_keys:
            val = all_metrics[i].get(key, '-')
            if val is None:                                  # 빈칸 (None) 을 'None' 으로 보이지 않게 — 없는 키와 같은 '-'
                val = '-'
            if isinstance(val, float):
                val = round(val, 2)
            row[label] = val
        rows.append(row)
    df = pd.DataFrame(rows)
    data_table = df.to_markdown(index=False)

    prompt = f"""당신은 고체전지 복합양극 DEM 시뮬레이션 전문가입니다.
아래는 bimodal AM (AM_P: 대립자 6μm, AM_S: 소립자 2μm) + SE (고체전해질) 복합 양극의 DEM 분석 비교 데이터입니다.

제목: {title}
{f'메모: {notes}' if notes else ''}

## 데이터

{data_table}

정의: Porosity ε_sphere = 구 부피 합 (겹친 부피 이중계상 · 생산 규약) · ε_union pair-lens = 쌍 렌즈만 되돌림 (벽 밖 부피 미제거 → 정확 union 보다 낮게 나옴) · ε_union exact MC = 몬테카를로 정확 union (세 입자 겹침 · 벽 밖 부피까지 · 인계 규약) · Thickness = 판 간격 · AM-SE/SE-SE 면적과 Coverage = LIGGGHTS c_cpl[22] 기하 교차 원판 (Hertz 계열 · 이름만 Hertz · legacy 지표).

## 분석 원칙 (반드시 준수)

1. **자의적 가중치 사용 금지**: "종합 점수"를 만들 때 근거 없는 가중치(예: 0.4/0.6)를 부여하지 마세요.
2. **물리적 근거 기반 판단**: 각 주장에는 반드시 물리적 메커니즘 설명이 필요합니다.
3. **Percolation 포화 효과**: 95% 이상에서는 diminishing return. 93%→97% 차이보다 tortuosity 차이가 실제 성능에 더 큰 영향.
4. **병목 결정 원칙**: 고체전지에서는 일반적으로 ionic transport이 charge transfer보다 훨씬 큰 저항. AM-SE 계면이 "충분"하면 SE 네트워크 효율(tortuosity↓)이 핵심.
5. **데이터에 없는 값을 추정하지 마세요**: 주어진 수치만으로 분석.
6. **핵심 지표 우선순위**: Tortuosity > SE-SE Total Area > Percolation > Porosity > AM-SE Total (ionic transport limited 시스템 기준)

## 분석 내용 (한국어)

### 1. 핵심 발견
- AM_P 비율 변화에 따른 주요 경향 3-5개
- 각 경향의 물리적 원인 (입자 크기, 공간 배치 관점)

### 2. SE Contact Network Trade-off
- SE-SE 접촉 개수 vs 평균 면적의 trade-off 관계
- Total Area = N × Mean → 최적점 분석
- 직관적 비유 활용

### 3. AM-SE vs SE-SE 상위 Trade-off
- AM-SE 계면 (charge transfer) vs SE 네트워크 (ionic transport)
- 어느 쪽이 실제 병목인지 데이터 기반으로 판단
- 최적 P:S 비율 제안 (근거 명시)

### 4. 결론 및 제언
- 종합 최적 조건과 그 이유
- 주의사항, 추가 검증 필요 사항

마크다운 형식으로, 표/수치를 적극 활용하되 근거 없는 수치 생성은 금지."""

    try:
        message = client.messages.create(
            model="claude-sonnet-4-20250514",
            max_tokens=3000,
            messages=[{"role": "user", "content": prompt}]
        )
        return message.content[0].text
    except Exception as e:
        return f"*AI 분석 생성 실패: {str(e)}*"


# ─── Routes ─────────────────────────────────────────────────────────────────

@app.route('/api/se_corpus.json')
def api_se_corpus():
    """Return docs/data/se_diagnostics_82.csv parsed as JSON for the viewer.

    Used by SE Diagnostics export buttons (PNG stats card) to embed
    corpus-percentile context per case.  Cached in-memory so repeated
    viewer hits don't re-parse.
    """
    csv_path = os.path.join(os.path.dirname(__file__), '..',
                             'docs', 'data', 'se_diagnostics_82.csv')
    if not os.path.exists(csv_path):
        return jsonify({'error': 'corpus CSV not found — run '
                                  'scripts/extract_se_network_diagnostics.py first.',
                        'rows': []}), 200
    # Tiny in-process cache keyed on mtime
    global _se_corpus_cache
    try:
        _se_corpus_cache
    except NameError:
        _se_corpus_cache = {'mtime': 0, 'rows': []}
    mt = os.path.getmtime(csv_path)
    if _se_corpus_cache['mtime'] != mt:
        with open(csv_path, newline='') as f:
            _se_corpus_cache = {'mtime': mt,
                                 'rows': list(csv.DictReader(f))}
    return jsonify({'rows': _se_corpus_cache['rows']})


@app.route('/api/all-grades')
def api_all_grades():
    """Batch grade re-computation for every uploaded case at a given
    carbon wt%.  Used by the index-page 🏆 랭킹 toggle so the ranking
    re-sorts itself when the user flips the What-if switch.

    Returns:
      { 'carbon_wt_pct': N,
        'cases': [ {case_id, score, grade, n_axes}, … ] }
    """
    try:
        carbon_wt = float(request.args.get('carbon_wt', 0))
    except ValueError:
        carbon_wt = 0.0
    carbon_wt = max(0.0, min(10.0, carbon_wt))

    try:
        import sys as _sys
        scripts_dir = os.path.join(os.path.dirname(__file__), '..', 'scripts')
        if scripts_dir not in _sys.path:
            _sys.path.insert(0, scripts_dir)
        from grade_engine import build_overall_grade
    except ImportError:
        return jsonify({'error': 'grade_engine import failed'}), 500

    corpus_csv = os.path.join(os.path.dirname(__file__), '..',
                              'docs', 'data', 'se_diagnostics_82.csv')
    if not os.path.exists(corpus_csv):
        corpus_csv = None

    rows = []
    upload_dir = app.config['UPLOAD_FOLDER']
    if not os.path.exists(upload_dir):
        return jsonify({'carbon_wt_pct': carbon_wt, 'cases': []})

    for case_id in os.listdir(upload_dir):
        results_dir = os.path.join(app.config['RESULTS_FOLDER'], case_id)
        metrics_path = os.path.join(results_dir, 'full_metrics.json')
        if not os.path.exists(metrics_path):
            continue
        try:
            with open(metrics_path) as f:
                metrics = json.load(f)
        except (OSError, ValueError):
            continue
        # Reuse cached SE aux if present
        se_aux = None
        aux_path = os.path.join(results_dir, 'viewer_aux.json')
        if os.path.exists(aux_path):
            try:
                with open(aux_path) as af:
                    _aux = json.load(af)
                se_aux = {
                    'n_percolating':         _aux.get('se_n_percolating'),
                    'articulation_points':   _aux.get('se_articulation_points', []),
                    'n_bn_below_threshold':  _aux.get('se_n_bn_below_threshold'),
                    'n_perc_edges':          _aux.get('se_n_perc_edges'),
                }
            except (OSError, ValueError):
                pass
        try:
            r = build_overall_grade(
                _inject_input_params(metrics, results_dir),
                corpus_csv, se_aux,
                carbon_wt_pct=carbon_wt if carbon_wt > 0 else None,
                case_id=case_id)
            rows.append({
                'case_id':      case_id,
                'score':        r['composite']['score'],
                'grade':        r['composite']['grade'],
                'n_axes':       r['composite']['n_axes'],
                'is_unit_cell': r['composite'].get('is_unit_cell', False),
                'rve_area_um2': r['composite'].get('rve_area_um2'),
                'base_case':    r['composite'].get('base_case'),
            })
        except Exception:
            continue
    return jsonify({'carbon_wt_pct': carbon_wt, 'cases': rows})


@app.route('/case/<path:case_id>/grade')
def case_grade_json(case_id):
    """Return the full overall-grade structure as JSON, with optional
    `carbon_wt` query parameter (default 0 → no override).  Used by the
    What-if ON/OFF toggle in the 종합 등급 tab to re-render the table
    without a page reload."""
    try:
        carbon_wt = float(request.args.get('carbon_wt', 0))
    except ValueError:
        carbon_wt = 0.0
    carbon_wt = max(0.0, min(10.0, carbon_wt))

    # Resolve metrics + results_dir (dashboard vs archive)
    if case_id.startswith('archive:'):
        rel = case_id[len('archive:'):]
        target = _safe_path(rel)
        if not target:
            return jsonify({'error': 'archive path not allowed'}), 400
        results_dir = target
    else:
        results_dir = get_results_dir(case_id)
    metrics_path = os.path.join(results_dir, 'full_metrics.json')
    if not os.path.exists(metrics_path):
        return jsonify({'error': 'metrics not found'}), 404
    with open(metrics_path) as f:
        metrics = json.load(f)

    try:
        import sys as _sys
        scripts_dir = os.path.join(os.path.dirname(__file__), '..', 'scripts')
        if scripts_dir not in _sys.path:
            _sys.path.insert(0, scripts_dir)
        from grade_engine import build_overall_grade, GRADE_COLOR
    except ImportError:
        return jsonify({'error': 'grade_engine import failed'}), 500

    corpus_csv = os.path.join(os.path.dirname(__file__), '..',
                              'docs', 'data', 'se_diagnostics_82.csv')
    if not os.path.exists(corpus_csv):
        corpus_csv = None

    # SE diag aux (same as the build_overall_grade_table path)
    se_aux = None
    aux_path = os.path.join(results_dir, 'viewer_aux.json')
    if os.path.exists(aux_path):
        try:
            with open(aux_path) as af:
                _aux = json.load(af)
            se_aux = {
                'n_percolating':         _aux.get('se_n_percolating'),
                'articulation_points':   _aux.get('se_articulation_points', []),
                'n_bn_below_threshold':  _aux.get('se_n_bn_below_threshold'),
                'n_perc_edges':          _aux.get('se_n_perc_edges'),
            }
        except (OSError, ValueError):
            pass

    result = build_overall_grade(
        _inject_input_params(metrics, results_dir),
        corpus_csv, se_aux,
        carbon_wt_pct=carbon_wt if carbon_wt > 0 else None,
        case_id=case_id)

    # Attach the grade-colour map so the client doesn't need its own copy.
    return jsonify({
        'carbon_wt_pct': carbon_wt,
        'grade_colors':  GRADE_COLOR,
        **result,
    })


@app.route('/case/<path:case_id>/whatif-carbon')
def case_whatif_carbon(case_id):
    """Return σ_e / ASR_e estimate for a hypothetical carbon-additive
    cathode at wt% (default 1.0).  Backs the What-if panel in the
    종합 등급 tab.  Supports both dashboard cases ('<id>') and archive
    cases ('archive:<folder>')."""
    try:
        wt = float(request.args.get('wt', 1.0))
    except ValueError:
        wt = 1.0
    wt = max(0.0, min(10.0, wt))

    # Resolve metrics path (dashboard vs archive)
    if case_id.startswith('archive:'):
        rel = case_id[len('archive:'):]
        target = _safe_path(rel)
        metrics_path = os.path.join(target, 'full_metrics.json') if target else None
    else:
        metrics_path = os.path.join(get_results_dir(case_id), 'full_metrics.json')

    if not metrics_path or not os.path.exists(metrics_path):
        return jsonify({'available': False,
                        'reason': 'full_metrics.json not found'}), 200
    with open(metrics_path) as f:
        metrics = json.load(f)

    try:
        import sys as _sys
        scripts_dir = os.path.join(os.path.dirname(__file__), '..', 'scripts')
        if scripts_dir not in _sys.path:
            _sys.path.insert(0, scripts_dir)
        from grade_engine import whatif_carbon_additive
        out = whatif_carbon_additive(metrics, wt_pct=wt)
    except Exception as e:
        return jsonify({'available': False,
                        'reason': f'{type(e).__name__}: {e}'}), 200
    return jsonify(out)


def _add_recipe_str(vgcf, superp, ptfe, sdcp=0.0):
    """Serialize chosen additive wt% into an --add-recipe string for
    additives.parse_recipe (only the additive wt% are load-bearing downstream;
    AM:SE are ignored by additive_wt).  Returns '' if no additive selected."""
    parts = [(k, v) for k, v in (('VGCF', vgcf), ('SuperP', superp), ('PTFE', ptfe),
                                 ('SDCP', sdcp)) if v and v > 0]
    if not parts:
        return ''
    keys = ':'.join(k for k, _ in parts)
    vals = ':'.join(f'{v:g}' for _, v in parts)
    return f'{keys}={vals}'


@app.route('/case/<path:case_id>/whatif-additives')
def case_whatif_additives(case_id):
    """Literature-anchored with/without estimate of σ_e / σ_ion / porosity for
    VGCF / Super P / PTFE at a mixing protocol.  Backs the 첨가제 적용 section.
    Query: ?vgcf=&superp=&ptfe= (wt%, 0–10) &mixing=ballmill|thinky|handmix."""
    def _f(name):
        try:
            return max(0.0, min(10.0, float(request.args.get(name, 0.0))))
        except ValueError:
            return 0.0
    vgcf, superp, ptfe = _f('vgcf'), _f('superp'), _f('ptfe')
    mixing = request.args.get('mixing', 'ballmill')
    if mixing not in ('ballmill', 'thinky', 'handmix'):
        mixing = 'ballmill'

    if case_id.startswith('archive:'):
        target = _safe_path(case_id[len('archive:'):])
        metrics_path = os.path.join(target, 'full_metrics.json') if target else None
    else:
        metrics_path = os.path.join(get_results_dir(case_id), 'full_metrics.json')
    if not metrics_path or not os.path.exists(metrics_path):
        return jsonify({'available': False, 'reason': 'full_metrics.json not found'}), 200
    with open(metrics_path) as f:
        metrics = json.load(f)
    try:
        import sys as _sys
        scripts_dir = os.path.join(os.path.dirname(__file__), '..', 'scripts')
        if scripts_dir not in _sys.path:
            _sys.path.insert(0, scripts_dir)
        from grade_engine import whatif_additives
        out = whatif_additives(metrics, vgcf_wt=vgcf, superp_wt=superp,
                               ptfe_wt=ptfe, mixing=mixing)
    except Exception as e:
        return jsonify({'available': False, 'reason': f'{type(e).__name__}: {e}'}), 200
    out['recipe'] = _add_recipe_str(vgcf, superp, ptfe)
    return jsonify(out)


@app.route('/step5')
def step5():
    """STEP5 사이클 열화 fade(N) 인터랙티브 패널 — 총 R_int(N) 정직 분해
    (접촉 ledger 하한 + 화학 CEI[√N Park2023] + OTHER 모델밖).  ASSUMED-shape 라벨 상시 노출."""
    return render_template('step5.html', lv=_page_lv('step5'))


@app.route('/api/step5/fade')
def api_step5_fade():
    """fade(N) 궤적 계산 — b1_chem_fade.trajectory_scalar (단일 소스, CLI와 동일 코어).
    Query: rint0, exp_x, n_exp, r_contact0, ledger_end_x, shape=sqrt|linear, chem_x(빈값=bare 나머지)."""
    import math as _math

    def _f(name, default, lo, hi):
        # ★리뷰 MAJOR: non-finite(inf/nan) 차단 + 상한(finite) — 아니면 jsonify가 NaN/Infinity 방출 →
        #   브라우저 JSON.parse 거부 → 패널이 잘못된 'fetch 실패'로 죽음.
        try:
            v = float(request.args.get(name, default))
        except (ValueError, TypeError):
            return default
        if not _math.isfinite(v):
            return default
        return min(hi, max(lo, v))
    rint0 = _f('rint0', 18.0, 0.1, 1e6)
    exp_x = _f('exp_x', 6.1, 1.0, 1e6)
    n_exp = int(_f('n_exp', 1000, 1, 100000))
    r_contact0 = _f('r_contact0', 2.0, 0.0, 1e6)
    ledger_end_x = _f('ledger_end_x', 1.1, 1.0, 1e4)
    chem_p = _f('chem_p', 1.5, 0.2, 6.0)
    shape = request.args.get('shape', 'sqrt')
    if shape not in ('sqrt', 'linear', 'power'):
        shape = 'sqrt'
    chem_x_raw = (request.args.get('chem_x', '') or '').strip().lower()
    chem_x = None
    if chem_x_raw not in ('', 'none', 'auto', 'bare'):
        try:
            cx = float(chem_x_raw)
            chem_x = min(1e6, max(1.0, cx)) if _math.isfinite(cx) else None
        except ValueError:
            chem_x = None
    try:
        import sys as _sys
        scripts_dir = os.path.join(os.path.dirname(__file__), '..', 'scripts')
        if scripts_dir not in _sys.path:
            _sys.path.insert(0, scripts_dir)
        import b1_chem_fade
        # #33 이종기술: 코팅 프리셋 → bare chem_x 에 CEI 억제 적용 (coating_presets, 크기=앵커·shape=ASSUMED)
        coating = (request.args.get('coating', 'none') or 'none').strip()
        coat_info = None
        if coating.lower() != 'none' and chem_x is not None:
            import coating_presets as _cp
            _p = _cp.get_preset(coating)
            _eff = _cp.coated_chem_x(coating, chem_x)
            coat_info = {'coating': coating, 'chem_x_bare': chem_x, 'chem_x_coated': round(_eff, 4),
                         'cei_suppress': _p.get('cei_suppress'), 'anchor': _p['anchor'], 'shape': _p['shape']}
            chem_x = _eff
        out = b1_chem_fade.trajectory_scalar(rint0, exp_x, n_exp, r_contact0, shape,
                                             chem_x=chem_x, ledger_end_x=ledger_end_x, chem_p=chem_p)
        if coat_info:
            out['coating_info'] = coat_info
    except Exception as e:
        return jsonify({'available': False, 'reason': f'{type(e).__name__}: {e}'}), 200
    out['available'] = True
    return jsonify(out)


# ─────────────────────────── litdb (논문 에이전트 digest) ───────────────────────────
# 2026-07-28: digest 가 세 서랍(정본 브랜치 litdb/papers · 작업 브랜치 docs/lit_* · 이 브랜치 동결
#   스냅샷)에 흩어져 "이용민 논문이 없다"는 오진을 낳았다.  litdb_sync 가 git plumbing 으로 전
#   브랜치를 체크아웃 없이 읽어 캐시+인덱스를 만들고, 여기서 그걸 서빙한다 (읽기 전용 — 정본은
#   여전히 각 브랜치의 원본; 캐시는 재생성 가능하므로 gitignore).
def _litdb_mod():
    import importlib
    import sys as _sys
    _sp = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'scripts')
    if _sp not in _sys.path:
        _sys.path.insert(0, _sp)
    return importlib.import_module('litdb_sync')


# ══════════════════════ 연구 세미나 (대본 · 용어집 · 덱) ══════════════════════
#  발표 준비물을 리포에서 바로 읽는다.  파일이 정본이고 웹앱은 뷰어일 뿐이라,
#  대본을 고치면 새로고침만으로 반영된다 (별도 DB·복사본 없음 = 어긋날 여지 없음).
_SEMINAR_DOCS = {
    'script':   ('docs/seminar_20260806_script.md',   '슬라이드 대본 + Defense Q&A'),
    'glossary': ('docs/seminar_20260806_glossary.md', '용어·기호 규약 + 레퍼런스'),
    'guide':    ('docs/pipeline_step1_to_step5_guide.md', 'STEP1–5 파이프라인 가이드'),
}
_SEMINAR_DECK = 'docs/seminar/seminar_20260806_DEM_MPM_SDCP_section.pptx'

#: 덱에서 뽑아 둔 구조화 JSON (scripts/seminar_deck_extract.py 가 만든다).
#: ★ 요청마다 pptx 를 파싱하지 않는다 — python-pptx 를 런타임 의존으로 만들지 않고,
#:   발표 중 파싱 오류로 페이지가 죽지 않게.  덱이 바뀌면 추출기를 다시 돌린다.
_SEMINAR_SLIDES = 'docs/seminar/seminar_deck.json'

#: 출처 칩에서 열 수 있는 파일 — **화이트리스트 접두어**로만 (경로탈출은 _repo_path 가 막고,
#: 여기서 다시 확장자·접두어를 좁힌다.  임의 파일 열람 창구가 되면 안 된다).
_SEMINAR_SRC_PREFIX = ('docs/', 'scripts/', 'webapp/')
_SEMINAR_SRC_EXT = ('.md', '.py', '.csv', '.json', '.html', '.sh', '.txt')

#: 철회 게이트가 **가리키는 근거**.  거부 사유가 산문으로만 있으면 그 주장을 확인할
#: 자리가 없다 (R19 Q1b) — 응답이 리포 안의 등록부를 지목하고, 회귀가 그 파일의 실재와
#: 이 SDCP 항목의 등재를 함께 본다.
#: ⚠ 정본은 `claims.json` 이다.  `mpm_platen_kinematic_stop_defect.md` 는 스스로 rev6
#:   에서 멈췄다고 적고 있어 **이 철회의 근거가 아니다** (다른 트랙의 문서다).
_SEMINAR_EVIDENCE = 'docs/reviews/claims.json'
_SEMINAR_EVIDENCE_CLAIM = 'CL-24'

#: 문서 창구용 철회 안내.  ⚠ **여기에 값을 적지 않는다** — 슬라이드 쪽 `_RETR` 은 무엇이
#: 철회됐는지 보이려고 값을 인용하는데(줄-근처 표지로 면제된다), 이 문구는 **거부 응답**이라
#: 값을 실으면 막으려던 것을 그대로 내보내게 된다.  등록부 id 로만 가리킨다.
_RETR_DOC = ('⛔ 이 문서는 인용 금지 등록부(`docs/reviews/claims.json` 의 `quotation_ban`)에 '
             '오른 값을 담고 있습니다.  발표 당시 기록이라 원문을 보존하되 기본 열람은 '
             '막습니다.  현재 유효한 판정은 원장이 정본이며, 충돌하면 원장이 이깁니다.')


def _repo_path(rel):
    """리포 루트 기준 경로 (webapp/ 의 부모).  경로 탈출은 거부한다."""
    root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    full = os.path.normpath(os.path.join(root, rel))
    if not full.startswith(root + os.sep):
        raise ValueError('경로 탈출 거부: ' + rel)
    return full


@app.route('/seminar')
def seminar_page():
    """연구 세미나 — 대본·용어집·덱을 한 화면에서."""
    return render_template('seminar.html', active='seminar')


#: ★★ 이종기술 — **실험 라인**이다 (DEM/MPM 과 분리, 2026-09-17 사용자 지시).
#:   `/eis` 는 **모델** 화면(물리 EIS/DRT)이고 이종기술 데이터를 오버레이로만 쓴다.
#:   이 화면은 그 공백 — **프로젝트 자체**의 읽기 전용 면이다.
#:   ⚠ `eis/fits/` · `eis_catalog.csv` 는 커밋 `b22bdb3c2` 가 **추적을 뗀 재생성 산출물**이라
#:   리포에 없을 수 있다.  `/eis` 가 이미 그 부재를 우아하게 처리하므로(eis.html) 같은 규약을 쓴다:
#:   **있으면 읽고, 없으면 "로컬 재생성 산출물 — 리포에 없음" 으로 표기한다.**
#:   ⛔ 부재를 숨기고 숫자를 박지 않는다 (원장 감사 `이종기술/README.md:38-42` 지적).
HETERO_ROOT = Path(__file__).resolve().parent.parent / '이종기술'


def _hetero_inventory():
    """아카이브의 **실제** 상태를 센다 — README 산문이 아니라 디스크를 본다.

    ⚠ README 는 `raw 24 · tidy 12 · fits + catalog` 라고 적는데 2026-09-17 실측은
      `raw 27 · tidy 15 · fits 없음 · catalog 없음` 이다.  산문과 디스크가 어긋나므로
      화면은 **디스크를 정본으로** 쓰고 어긋남 자체를 표시한다.
    """
    eis = HETERO_ROOT / 'eis'
    raw = sorted(pp.name for pp in (eis / 'raw').glob('*')) if (eis / 'raw').is_dir() else []
    ext = sorted(pp.name for pp in (eis / 'extracted').glob('*.csv')) if (eis / 'extracted').is_dir() else []
    fits_dir = eis / 'fits'
    means = fits_dir / 'summary_means.csv'
    return {
        'root_exists': HETERO_ROOT.is_dir(),
        'n_raw': len(raw), 'n_tidy': len(ext), 'tidy': ext,
        'has_fits': fits_dir.is_dir(),
        'has_means': means.is_file(),
        'has_catalog': (eis / 'eis_catalog.csv').is_file(),
        # README 가 주장하는 값 — 디스크와 대조해 보이기 위해 같이 넘긴다
        'readme_raw': 24, 'readme_tidy': 12,
    }


#: 이종기술 논지 정본 — 1저자 비준 10-05 (*"이거 비준이고"* · *"중간에 이게 흔들리면 전체가 흔들려버리니까"*).
#:   화면은 이 파일의 **비준 블록** (`<!-- THESIS:BEGIN ratified=<날짜> -->` … `<!-- THESIS:END -->`) 만 읽는다.
#:   ⛔ 고정 문장 · 비준 날짜를 템플릿 · 코드에 베끼지 않는다 — 정본을 고쳐도 화면이 옛 문장을 보이게 된다 (규율 ④).
HETERO_THESIS_MD = Path(__file__).resolve().parent.parent / 'docs' / 'hetero_thesis.md'
_THESIS_BLOCK = re.compile(r'<!-- THESIS:BEGIN ratified=(\d{4}-\d{2}-\d{2}) -->\r?\n(.*?)\r?\n<!-- THESIS:END -->', re.S)
_THESIS_ANY_BEGIN = re.compile(r'<!-- THESIS:BEGIN\b')


def _hetero_thesis():
    """논지 정본의 비준 블록 → {'ok', 'html', 'date', 'error', 'redacted'}.

    fail-closed — 파일 없음 · 표지 없음 · 날짜 없는 표지 · 표지 둘 이상 · 빈 블록이면 `ok=False` 와 **무엇이 깨졌는지**를
    낸다 (조용히 비우거나 옛 문장을 보이지 않는다).  `/worklog` · `/mixer` 와 같은 관문: markdown 변환 **전에** redact.
    """
    out = {'ok': False, 'html': '', 'date': '', 'error': '', 'redacted': False}
    try:
        src = HETERO_THESIS_MD.read_text(encoding='utf-8')
    except OSError as e:
        out['error'] = f'{HETERO_THESIS_MD.name} 을 읽지 못했다 ({type(e).__name__})'
        return out
    hits = _THESIS_BLOCK.findall(src)
    n_begin = len(_THESIS_ANY_BEGIN.findall(src))
    if len(hits) != 1 or n_begin != 1:
        out['error'] = (f'비준 블록 표지가 {len(hits)} 쌍 (BEGIN 표지 {n_begin} 개) — '
                        '날짜가 붙은 표지 (ratified=YYYY-MM-DD) 가 정확히 한 쌍이어야 한다')
        return out
    date, raw = hits[0]
    block = ledger_view.redact(raw).strip()
    if not block:
        out['error'] = '비준 블록이 비어 있다'
        return out
    out['redacted'] = block != raw.strip()
    try:
        import markdown
        out['html'] = markdown.markdown(block)
    except ImportError:
        out['html'] = '<pre>' + block.replace('&', '&amp;').replace('<', '&lt;') + '</pre>'
    out.update(ok=True, date=date)
    return out


@app.route('/hetero')
def hetero_page():
    """이종기술 — 소립 SC-NCM 실험 라인의 프로젝트 면 (읽기 전용) · 맨 위 = 논지 정본의 비준 블록."""
    return render_template('hetero.html', active='hetero',
                           inv=_hetero_inventory(), thesis=_hetero_thesis(), lv=_page_lv('hetero'))


_HT_DATA = Path(__file__).resolve().parent.parent / 'docs' / 'data'
#: 이종기술 회의록 해체본 등록부 — 키 = 회의 날짜 8 자리 (`?m=`).  등록부 밖 키는 404 — 조용히 다른 회의를 보이지 않는다.
#:   10-02 회의 (음성 336) = 1저자 10-05 *"녹음 관련해서도 낱낱이 정리해서 이종기술 관련 원장에"* (09-19 비준 (가) 전수 규약 승계).
HETERO_TRANSCRIPTS = {
    '20260918': {'json': _HT_DATA / 'hetero_transcript_20260918.json', 'raw': _HT_DATA / 'hetero_meeting_20260918_raw.txt',
                 'label': '2026-09-18', 'length': '20분 02초', 'ratified': '비준 2026-09-19'},
    '20261002': {'json': _HT_DATA / 'hetero_transcript_20261002.json', 'raw': _HT_DATA / 'hetero_meeting_20261002_raw.txt',
                 'label': '2026-10-02', 'length': '18분 41초', 'ratified': '09-19 규약 승계 · 1저자 10-05'},
}
TRANSCRIPT_JSON = HETERO_TRANSCRIPTS['20260918']['json']     # 하위호환 — 옛 단일 회의 상수
TRANSCRIPT_RAW = HETERO_TRANSCRIPTS['20260918']['raw']


def _transcript_load(key=None):
    """회의록 해체본 + **렌더 시점 계약 검증**.

    ★ 이 앱의 `_hetero_inventory` 와 같은 사고 — 산문이 아니라 **실물을 본다**.
    계약이 깨져 있으면 *"통과"* 라고 적지 않고 **무엇이 깨졌는지**를 화면에 낸다.
    ⚠ 계약① (원문 무손실) 은 `raw` 파일이 있어야 검사된다.  없으면 *검사되지 않았다* 고
      적는다 — '통과' 와 '검사 안 함' 을 같은 초록으로 칠하면 그게 false-green 이다.
    """
    ent = HETERO_TRANSCRIPTS[key or max(HETERO_TRANSCRIPTS)]
    tj, tr = ent['json'], ent['raw']
    out = {'exists': tj.is_file(), 'raw_exists': tr.is_file(),
           'doc': None, 'report': None, 'error': ''}
    if not out['exists']:
        out['error'] = f'{tj.name} 이 없다'
        return out
    try:
        import hetero_transcript as HT
        doc = json.loads(tj.read_text(encoding='utf-8'))
        out['doc'] = doc
        out['report'] = HT.check(doc, raw_path=(str(tr)
                                                if out['raw_exists'] else None))
    except Exception as e:                                        # noqa: BLE001
        out['error'] = f'{type(e).__name__}: {e}'
    return out


#: 주장 지위 — 화면 라벨과 **한 줄 설명**.  라벨만 두면 `FACT_STATED` 가 '검증된 사실'
#: 로 읽힌다 (그 오해가 이 원장이 반복해서 데인 자리다).
CLAIM_STATUS_HELP = [
    ('FACT_STATED', '회의에서 사실로 진술됨 — ⚠ 우리가 검증했다는 뜻이 아니다'),
    ('PLAN', '하기로 한 것'),
    ('REQUEST', '요청·지시'),
    ('QUESTION', '물음'),
    ('OPINION', '판단·의견'),
    ('NO_CLAIM', '주장 없음 (끊긴 말·인사·추임새)'),
    ('UNCERTAIN', '원문만으로 확정 불가 — 왜 못 하는지를 같이 적는다'),
]


#: 분석자 칸(`decoded`·`claim`·`why_uncertain`)의 **최소 마크다운**.
#  ⛔ `raw` 에는 쓰지 않는다 — 원문은 변형하지 않는다 (해체 계약①의 정신: 원문을 이으면
#     바이트가 같아야 한다.  화면에서 굵게 만드는 것도 원문을 고치는 쪽으로 새는 길이다).
#  ★ 리포에 `markdown` 라이브러리가 있지만(`worklog_view`·`_generate_pdf_report`) 그쪽은
#    **문서 전체**용이라 `<p>` 로 감싸고 **raw HTML 을 그대로 통과**시킨다.  여기는 한 문단짜리
#    데이터 칸이라 (a) 래퍼가 없어야 하고 (b) 데이터가 HTML 을 실행하면 안 된다.
#    ⇒ **먼저 전부 이스케이프하고 그 다음 화이트리스트만 되살린다** = 구조적으로 XSS 불가.
_MDI_CODE = re.compile(r'`([^`\n]+)`')
_MDI_BOLD = re.compile(r'\*\*([^*\n]+?)\*\*')
_MDI_ITAL = re.compile(r'(?<![\w*])\*([^*\n]+?)\*(?![\w*])')


def md_inline(s):
    """최소 마크다운 → HTML.  `**굵게**` · `` `코드` `` · `*기울임*` · 줄바꿈만."""
    from markupsafe import Markup, escape
    t = str(escape('' if s is None else s))
    t = _MDI_CODE.sub(r'<code>\1</code>', t)     # 코드 먼저 — 그 안의 * 를 안 건드린다
    t = _MDI_BOLD.sub(r'<b>\1</b>', t)
    t = _MDI_ITAL.sub(r'<i>\1</i>', t)
    return Markup(t.replace('\n', '<br>'))


app.jinja_env.filters['mdi'] = md_inline


@app.route('/hetero/transcript')
def hetero_transcript_page():
    """이종기술 회의록 **해체 분석** — 원문 · 해독 · 주장 세 층 (`?m=<8 자리 날짜>` · 없으면 최신 회의).

    비준 (가) = 발화 **전수** (09-18 61 · 10-02 90).  선택 해독은 *"무엇을 안 골랐나"* 가 안 남는다.
    """
    key = request.args.get('m') or max(HETERO_TRANSCRIPTS)
    if key not in HETERO_TRANSCRIPTS:
        abort(404)
    t = _transcript_load(key)
    doc = t['doc'] or {}
    ana = doc.get('analysis') or {}
    return render_template(
        'hetero_transcript.html', active='hetero', t=t, doc=doc,
        mkey=key, ment=HETERO_TRANSCRIPTS[key],
        meetings=[(k, v['label'], v['length']) for k, v in sorted(HETERO_TRANSCRIPTS.items())],
        synth=ana.get('synthesis') or [], caveats=ana.get('caveats') or [],
        utt=doc.get('utterances') or [],
        status_help=CLAIM_STATUS_HELP,
        speakers=sorted({u.get('speaker') or '미상' for u in (doc.get('utterances') or [])}),
        lv=_page_lv('hetero'))


@app.route('/api/seminar/doc/<key>')
def api_seminar_doc(key):
    """대본/용어집/가이드 원문 (markdown 그대로 — 프런트에서 렌더)."""
    ent = _SEMINAR_DOCS.get(key)
    if not ent:
        return jsonify({'ok': False, 'error': f'알 수 없는 문서: {key}',
                        'known': sorted(_SEMINAR_DOCS)}), 200
    rel, label = ent
    try:
        path = _repo_path(rel)
        with open(path, encoding='utf-8') as f:
            text = f.read()
    except FileNotFoundError:
        return jsonify({'ok': False, 'error': f'{rel} 없음',
                        'hint': 'git pull 후 다시 시도'}), 200
    except Exception as e:
        return jsonify({'ok': False, 'error': f'{type(e).__name__}: {e}'}), 200

    #  ⛔⛔ **게이트 신설 2026-09-14 (webapp 감사 A-1/A-2).**
    #    같은 세미나의 산출물 셋 중 **이 창구에만 게이트가 없었다**:
    #        /api/seminar/slides  → ?historical=1 로 fail-closed
    #        /api/seminar/deck    → ?historical=1 로 fail-closed
    #        /api/seminar/doc/…   → **없음** ⇒ 75 KB 원문이 그대로 나갔고 그 안에
    #                                인용 금지 등록부의 패턴이 여러 건 들어 있었다.
    #    스윕이 못 본 이유가 두 겹이다: ⓐ 그 파일 머리의 철회 배너가 `_has_banner` 로
    #    **파일 전체를 면제**시킨다 ⓑ 값의 꼬리 자릿수가 잘려 리터럴에 안 걸린다.
    #    ⇒ 배너가 파일을 면제해도 **창구는 면제되지 않는다**.
    #  ★ 게이트를 **경로가 아니라 내용**에 건다 — 새 문서를 `_SEMINAR_DOCS` 에 얹어도
    #    자동으로 걸린다.  경로 목록은 잊으면 새지만 내용 검사는 안 잊는다
    #    (규율 ⑤: "후보를 고르는 코드가 곧 사각지대다").
    if ledger_view.redact(text) != text and (request.args.get('historical') or '') != '1':
        return jsonify({'ok': False, 'retracted': True, 'error': _RETR_DOC,
                        'key': key, 'label': label, 'path': rel,
                        'evidence_ref': _SEMINAR_EVIDENCE,
                        'evidence_claim': _SEMINAR_EVIDENCE_CLAIM,
                        'hint': '이 문서는 인용 금지 등록부의 값을 담고 있다.  '
                                '이력으로 열람하려면 ?historical=1 (재발표 금지)'}), 200
    return jsonify({'ok': True, 'key': key, 'label': label, 'path': rel,
                    'bytes': len(text.encode('utf-8')), 'text': text})


@app.route('/api/seminar/slides')
def api_seminar_slides():
    """덱 구조화 JSON — 슬라이드별 kicker/제목/리드/표/차트/대본/출처."""
    try:
        path = _repo_path(_SEMINAR_SLIDES)
        with open(path, encoding='utf-8') as f:
            data = json.load(f)
    except FileNotFoundError:
        return jsonify({'ok': False, 'error': f'{_SEMINAR_SLIDES} 없음',
                        'hint': 'python3 scripts/seminar_deck_extract.py 로 생성'}), 200
    except Exception as e:                                     # noqa: BLE001
        return jsonify({'ok': False, 'error': f'{type(e).__name__}: {e}'}), 200
    #  ⚠⚠⚠ 2026-08-20 (Codex 재검증 NEW-DEFECT P1) — 이 덱의 SDCP 수치(+52.0 % · +5.6 % ·
    #    +18 % · σ_e 3.002 S/cm)는 **2026-08-13 적대 리뷰로 철회**됐다 (claims.json CL-24).
    #    JSON 안에 `_RETRACTED` 배너를 넣었지만 **UI 가 그것을 렌더하지 않아** 화면에는
    #    여전히 현행 결론처럼 보였다 = 배너가 파일에만 있고 사용자에겐 안 보이는 상태.
    #    ⇒ **fail-closed**: 명시적으로 이력 열람을 요청하지 않으면 데이터를 주지 않는다.
    #      (`?historical=1`).  프런트가 그 파라미터를 안 보내면 화면에 철회 안내가 뜬다.
    _RETR = ('⛔ 이 덱은 2026-08-06 발표 기록이고, 안의 SDCP 수치(+52.0 % · +5.6 % · +18 % · '
             'σ_e 3.002 S/cm)는 2026-08-13 적대 리뷰로 **철회**됐습니다.  전부 vox 0.4 µm '
             '점-스탬프 격자의 산물이고, 격자를 조이면 σ_e 이득은 +42.15 → +8.49 % 로 '
             '내려가며 σ_ion 이득은 부호가 뒤집힙니다.  현재 말할 수 있는 것은 구-스탬프 '
             '규약의 측정 서술뿐이고, 그 **값 자체도 p1 plate rule 산물이라 인용 금지**입니다 '
             '(원장 CL-33 · CL-41, 둘 다 status hold).  세 격자에서 이득이 단조 증가하며 '
             '멈추지 않고, 어떤 p > 0 도 안 맞아 Richardson 외삽이 성립하지 않습니다 — '
             '어느 격자의 값도 헤드라인이 아닙니다.  '
             '정본: CLAUDE.md SR-01 · docs/reviews/claims.json.')
    #  ⚠⚠ 2026-09-09 (전수 감사 P0) — 이 배너가 한 세트를 철회하면서 **같은 문장에서 다른
    #    금지 세트**(CL-33/CL-41 의 p1 plate-rule 비)를 현행 결론으로 적고 있었다.  스윕은
    #    두 겹으로 못 봤다: ⓐ `webapp/*.py` 가 글롭 밖 ⓑ 값이 반올림돼 등록부의 리터럴
    #    패턴에 안 걸림.  ⓐ 는 BAN_SCAN_GLOBS 에 넣어 닫았다 (check_review_findings.py).
    if (request.args.get('historical') or '') != '1':
        return jsonify({'ok': False, 'retracted': True, 'error': _RETR,
                        'evidence_ref': _SEMINAR_EVIDENCE,
                        'evidence_claim': _SEMINAR_EVIDENCE_CLAIM,
                        'hint': '이력으로 열람하려면 ?historical=1 (재발표 금지)'}), 200
    data['ok'] = True
    data['retracted'] = True
    data['retracted_banner'] = _RETR
    data['evidence_ref'] = _SEMINAR_EVIDENCE
    data['evidence_claim'] = _SEMINAR_EVIDENCE_CLAIM
    return jsonify(data)


@app.route('/api/seminar/file')
def api_seminar_file():
    """출처 칩 → 리포 원문 (평문).  화이트리스트 밖은 거부한다."""
    raw = (request.args.get('p') or '').strip().replace('\\', '/')
    # ★ 접두어 검사는 **정규화한 뒤에** 한다.  옛 코드는 원문 문자열로 검사해서
    #   `docs/../CLAUDE.md` 가 통과했다 — 정규화하면 리포 루트라 _repo_path 도 막지 못하고
    #   화이트리스트 밖 파일이 열렸다 (회귀 9 가 잡았다).  `..` 를 없앤 결과가 여전히
    #   docs/·scripts/·webapp/ 아래여야 한다.
    rel = os.path.normpath(raw).replace(os.sep, '/').lstrip('/')
    if not rel.startswith(_SEMINAR_SRC_PREFIX) or not rel.endswith(_SEMINAR_SRC_EXT):
        return Response('허용되지 않은 경로입니다: ' + raw, mimetype='text/plain; charset=utf-8',
                        status=400)
    try:
        path = _repo_path(rel)
    except ValueError:
        # ★ 경로탈출은 '없음' 이 아니다 — 구분해서 보고해야 로그에서 시도가 보인다.
        return Response('경로 탈출 거부: ' + raw, mimetype='text/plain; charset=utf-8', status=400)
    try:
        with open(path, encoding='utf-8', errors='replace') as f:
            text = f.read()
    except (FileNotFoundError, IsADirectoryError):
        return Response(f'{rel} 없음 (git pull 후 다시 시도)',
                        mimetype='text/plain; charset=utf-8', status=404)
    return Response(text, mimetype='text/plain; charset=utf-8')


@app.route('/api/seminar/deck')
def api_seminar_deck():
    """생성된 pptx 내려받기.  없으면 만드는 법을 안내한다 (조용한 404 금지).

    ⚠⚠ 2026-08-20 — 이 pptx 는 **철회된 수치**를 담고 있고 파일 안에는 표지가 없다
      (Codex 재검증 NEW-DEFECT).  ⇒ 같은 fail-closed 규약: `?historical=1` 없이는 안 준다.
    """
    if (request.args.get('historical') or '') != '1':
        #  ⚠ 거부를 **JSON 으로** 준다 (2026-09-01).  평문 403 이면 화면의 내려받기
        #    핸들러가 content-type 만 보고 `window.location` 으로 그 주소에 **이동**해
        #    버려 사용자는 맥락 없는 403 본문을 보게 된다 — 거부가 안내가 아니라 사고로
        #    보인다.  기계도 사람도 읽을 수 있는 형태로 준다.
        return jsonify({
            'ok': False, 'retracted': True,
            'error': '⛔ 이 덱(2026-08-06)의 SDCP 수치는 2026-08-13 적대 리뷰로 철회됐고, '
                     'pptx 파일 안에는 그 표지가 없습니다.  재발표 금지.',
            'evidence_ref': _SEMINAR_EVIDENCE,
            'evidence_claim': _SEMINAR_EVIDENCE_CLAIM,
            'hint': '이력으로 받으려면 ?historical=1 를 붙이세요.  '
                    '정본: CLAUDE.md SR-01 · docs/reviews/claims.json (CL-24).',
        }), 403
    try:
        path = _repo_path(_SEMINAR_DECK)
    except ValueError as e:
        return jsonify({'ok': False, 'error': str(e)}), 200
    if not os.path.exists(path):
        return jsonify({'ok': False, 'error': f'{_SEMINAR_DECK} 없음',
                        'hint': 'node scripts/seminar_deck/build.js 로 생성'}), 200
    return send_file(path, as_attachment=True,
                     download_name=os.path.basename(_SEMINAR_DECK))


# ─────────────────────────  작업일지 (worklog / 주간보고)  ─────────────────────────
#  주 단위 진행 슬라이드텍스트(docs/seminar/weekly_YYYYMMDD_slide_text.md)를 링크로 모아
#  HTML 로 렌더한다.  ⚠ 인용 금지값 누수는 scripts/check_review_findings.py --ban-sweep
#  (docs/**/*.md 포함)가 CI 에서 막는다 — 이 창구는 그 통과분만 렌더한다.
#  출처 둘 — **리치 주간 리포트가 있으면 그것을**, 없으면 발표용 슬라이드 문구를 렌더한다.
_WORKLOG_SOURCES = (
    ('docs/worklog', 'weekly_{key}.md', '주간 리포트'),
    ('docs/seminar', 'weekly_{key}_slide_text.md', '슬라이드 문구'),
)


def _worklog_scan():
    """{key: (path, kind)} — 앞선 출처가 이긴다 (같은 주차면 리포트 우선)."""
    import os as _os
    import re as _re
    found = {}
    for sub, tmpl, kind in _WORKLOG_SOURCES:
        pat = _re.escape(tmpl).replace(r'\{key\}', r'(\d{8})')
        try:
            names = _os.listdir(_repo_path(sub))
        except OSError:
            continue
        for fn in names:
            m = _re.fullmatch(pat, fn)
            if m and m.group(1) not in found:
                found[m.group(1)] = (_os.path.join(_repo_path(sub), fn), kind)
    return found


def _worklog_entries():
    """주간 기록 목록 (최신순) → [{key,date,title,kind}]."""
    ents = []
    for key, (path, kind) in _worklog_scan().items():
        title = ''
        try:
            with open(path, encoding='utf-8') as f:
                for line in f:
                    if line.startswith('# '):
                        title = line[2:].strip()
                        break
        except OSError:
            pass
        ents.append({'key': key, 'date': f'{key[:4]}-{key[4:6]}-{key[6:8]}',
                     'title': title or f'주간 기록 {key}', 'kind': kind})
    ents.sort(key=lambda e: e['key'], reverse=True)
    return ents


@app.route('/worklog')
def worklog_index():
    """작업일지 — 주간 기록을 링크로 모아 본다."""
    return render_template('worklog.html', active='worklog',
                           entries=_worklog_entries())


@app.route('/worklog/<key>')
def worklog_view(key):
    """주간 기록 한 편을 HTML 로 렌더 (8자리 날짜 키만 — 경로탈출 차단)."""
    import re as _re
    if not _re.fullmatch(r'\d{8}', key or ''):
        abort(404)
    hit = _worklog_scan().get(key)
    if not hit:
        abort(404)
    path, kind = hit
    with open(path, encoding='utf-8') as f:
        md_text = f.read()

    #  ⛔ **이 창구에는 redaction 이 없었다** (원장 `GAP3-DOC` ㉕, 2026-09-18).
    #    디스크 → markdown → `{{ body|safe }}` 까지 관문이 **0 개**였다.  같은 웹앱에
    #    이미 두 처방이 있는데(`/ledger` 는 `ledger_view.redact`, `/api/seminar/doc` 는
    #    내용 기반 fail-closed 게이트) `/worklog` 만 둘 다 없었다.
    #  ⚠ 실측 누수는 **0 건**이었다 (등록 22 패턴 × 서빙 3 파일) — 이것은 **예방**이지
    #    사고 수습이 아니다.  그러나 구멍은 실재했다: 서빙 후보 중 하나
    #    (`docs/seminar/weekly_20260914_slide_text.md`) 는 머리 배너로 **스윕에서 파일째
    #    면제**인데 이 창구는 배너를 보지 않는다.  앞선 출처가 이겨서 지금 안 보일 뿐,
    #    그 리포트가 사라지면 면제 파일이 그대로 렌더된다
    #    (= `app.py` 의 seminar 게이트 주석이 적은 A-1/A-2 함정의 미차단 재현).
    #  ★ `/ledger` 쪽 처방을 고른다 — worklog 는 **읽는 면**이지 재발표 대상이 아니므로
    #    문서를 거절하기보다 **자리를 남기고 보여 주는** 것이 맞다.
    #  ⚠ markdown **변환 전**에 건다 — 변환 후 HTML 에 걸면 태그 안을 때릴 수 있다.
    _raw = md_text
    md_text = ledger_view.redact(md_text)
    redacted = (md_text != _raw)

    try:
        import markdown
        body = markdown.markdown(md_text, extensions=['tables', 'fenced_code'])
    except ImportError:
        body = '<pre>' + md_text.replace('&', '&amp;').replace('<', '&lt;') + '</pre>'
    title = ''
    for line in md_text.splitlines():
        if line.startswith('# '):
            title = line[2:].strip()
            break
    return render_template('worklog_view.html', active='worklog', body=body,
                           title=title or f'주간 기록 {key}', kind=kind, redacted=redacted,
                           date=f'{key[:4]}-{key[4:6]}-{key[6:8]}', key=key)


# ─────────────────────────  믹서 개발 이력 (/mixer)  ─────────────────────────
#  §24 믹싱 모델의 발전을 **버전 누적**으로 한 페이지에 보인다 (1저자 요청 2026-09-20:
#  "쉬운 버전/자세한 버전으로 version 업데이트 느낌으로 사진 첨부, 계속 누적").
#  출처: docs/mixer_devlog/vNN_YYYYMMDD.md — 한 파일 = 한 버전.  `## 쉬운 판` / `## 자세한 판`
#  두 절로 나뉘고 그림은 /static/mixer/*.png.  키는 정규식으로 완전히 결정 → 경로탈출 없음.
#  ⚠ /worklog 과 같은 관문: 렌더 직전에 ledger_view.redact 를 markdown 변환 **전에** 건다.
_MIXER_DEVLOG_DIR = 'docs/mixer_devlog'
_MIXER_DEVLOG_RE = r'v(\d{2})_(\d{8})\.md'


def _mixer_devlog_entries():
    """[{ver, date, title, blurb, easy_html, detail_html, redacted}] — 최신 버전이 앞."""
    import re as _re
    try:
        import markdown as _md
    except ImportError:
        _md = None
    try:
        names = os.listdir(_repo_path(_MIXER_DEVLOG_DIR))
    except OSError:
        return []
    ents = []
    for fn in sorted(names):
        m = _re.fullmatch(_MIXER_DEVLOG_RE, fn)
        if not m:
            continue
        with open(os.path.join(_repo_path(_MIXER_DEVLOG_DIR), fn), encoding='utf-8') as f:
            raw = f.read()
        txt = ledger_view.redact(raw)
        title, blurb = '', ''
        for line in txt.splitlines():
            if not title and line.startswith('# '):
                title = line[2:].strip()
            elif not blurb and line.startswith('> '):
                blurb = line[2:].strip()
            if title and blurb:
                break
        #  두 절로 나눈다 — 없으면 전체를 자세한 판으로 (빈 화면을 만들지 않는다)
        i_e = txt.find('\n## 쉬운 판')
        i_d = txt.find('\n## 자세한 판')
        if i_e >= 0 and i_d > i_e:
            easy, detail = txt[i_e + len('\n## 쉬운 판'):i_d], txt[i_d + len('\n## 자세한 판'):]
        else:
            easy, detail = '', txt

        def _render(t):
            if _md:
                return _md.markdown(t, extensions=['tables', 'fenced_code'])
            return '<pre>' + t.replace('&', '&amp;').replace('<', '&lt;') + '</pre>'
        key, date = m.group(1), m.group(2)
        ents.append({'ver': f'v0.{int(key)}', 'key': key,
                     'date': f'{date[:4]}-{date[4:6]}-{date[6:8]}',
                     'title': title or fn, 'blurb': blurb,
                     'easy_html': _render(easy), 'detail_html': _render(detail),
                     'redacted': txt != raw})
    ents.sort(key=lambda e: e['key'], reverse=True)
    return ents


@app.route('/mixer')
def mixer_devlog():
    """믹서 개발 이력 — 버전 누적, 쉬운/자세한 토글 + "침대 보기" 탭 (덤프 원자료 보기 전용)."""
    return render_template('mixer.html', active='mixer', entries=_mixer_devlog_entries())


#  "침대 보기" 탭 (1저자 비준 2026-09-30) — 보기 전용 · 판정은 3D 칸 M 으로만.  경로 · 맹검 잠금 · 덤프 관문은
#  webapp/mixer_bed.py 한 곳에 있다 (회귀 webapp/test_mixer_bed_view.py).  읽기만 하고 subprocess 는 없다.
@app.route('/api/mixer/runs')
def api_mixer_runs():
    import mixer_bed
    return jsonify(mixer_bed.list_runs())


@app.route('/api/mixer/frame')
def api_mixer_frame():
    import mixer_bed
    try:
        return jsonify(mixer_bed.frame_payload(request.args))
    except mixer_bed.Refuse as e:
        return jsonify(e.payload()), e.status


@app.route('/litdb')
def litdb_page():
    """논문 digest 통합 검색 — 전 브랜치의 litdb 카드 + 작업노트를 한 화면에서."""
    return render_template('litdb.html')


@app.route('/api/litdb/index')
def api_litdb_index():
    """인덱스 메타 + 서랍별 통계 (본문 제외 — 가벼움)."""
    try:
        m = _litdb_mod()
        idx = m.load_index()
    except SystemExit as e:
        return jsonify({'ok': False, 'error': str(e),
                        'hint': 'python3 scripts/litdb_sync.py --sync 를 먼저 실행'}), 200
    except Exception as e:
        return jsonify({'ok': False, 'error': f'{type(e).__name__}: {e}'}), 200
    by = {}
    for rec in idx['entries']:
        by[rec['drawer']] = by.get(rec['drawer'], 0) + 1
        for a in rec['also_in']:
            by[a['drawer']] = by.get(a['drawer'], 0) + 1
    return jsonify({'ok': True, 'n_slugs': idx['n_slugs'], 'n_files': idx['n_files'],
                    'drawers': idx['drawers'], 'by_drawer': by,
                    'context_docs': idx['context_docs'],
                    'missing_branches': idx.get('missing_branches', []),
                    'entries': [{k: r[k] for k in ('slug', 'title', 'drawer', 'branch', 'lines')}
                                | {'also_in': [a['drawer'] for a in r['also_in']]}
                                for r in idx['entries']]})


@app.route('/api/litdb/search')
def api_litdb_search():
    """전문 검색 (토큰 AND).  &q= · &limit="""
    q = (request.args.get('q', '') or '').strip()
    if not q:
        return jsonify({'ok': True, 'q': '', 'results': []})
    try:
        limit = max(1, min(int(request.args.get('limit', 20)), 100))
    except (TypeError, ValueError):
        limit = 20
    try:
        m = _litdb_mod()
        res = m.search(q, limit=limit)
    except SystemExit as e:
        return jsonify({'ok': False, 'error': str(e)}), 200
    except Exception as e:
        return jsonify({'ok': False, 'error': f'{type(e).__name__}: {e}'}), 200
    return jsonify({'ok': True, 'q': q, 'n': len(res), 'results': res})


@app.route('/api/litdb/card/<slug>')
def api_litdb_card(slug):
    """카드 본문 (마크다운 원문).  &drawer= 로 특정 서랍 판본 선택."""
    try:
        m = _litdb_mod()
        c = m.get_card(slug, drawer=(request.args.get('drawer') or None))
    except SystemExit as e:
        return jsonify({'ok': False, 'error': str(e)}), 200
    except Exception as e:
        return jsonify({'ok': False, 'error': f'{type(e).__name__}: {e}'}), 200
    if not c:
        return jsonify({'ok': False, 'error': f'슬러그 없음: {slug}'}), 404
    return jsonify({'ok': True, 'card': {k: v for k, v in c.items() if k != 'rank'}})


@app.route('/eis')
def eis_page():
    """v3-1 EIS/DRT 인터랙티브 패널 — 물리-기반 Randles(우리 σ·i0·D_s 유도) Nyquist + DRT.
    실험 EIS(eis_fit R0-p(R1,CPE1)-Wo1)와 같은 회로 = frame[4] 대조."""
    return render_template('eis.html', lv=_page_lv('eis'))


@app.route('/api/eis')
def api_eis():
    """물리-EIS Z(ω) + DRT.  Query: sigma_e, sigma_ion, thickness_um, r_int, i0, d_s, r_p_um,
    c_dl_uf, coverage.  eis_drt_ica.physics_eis + drt (단일 소스, CLI와 동일 코어).
    ★C_dl 은 앵커(§F1) — 사용자 입력(실험 EIS CPE 또는 문헌 1-10 µF/cm²)."""
    import math as _math
    import numpy as _np

    def _f(name, default, lo, hi):
        try:
            v = float(request.args.get(name, default))
        except (TypeError, ValueError):
            return default
        if not _math.isfinite(v):
            return default
        return min(hi, max(lo, v))
    try:
        import sys as _sys
        _sd = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'scripts')
        if _sd not in _sys.path:                              # 리뷰 LOW: 매 요청 중복 insert 방지
            _sys.path.insert(0, _sd)
        import eis_drt_ica as _eis
    except Exception as e:
        return jsonify({'error': f'eis_drt_ica import 실패: {type(e).__name__}: {e}'}), 200
    kw = dict(sigma_e_S_cm=_f('sigma_e', 2.0, 1e-6, 1e3), sigma_ion_S_cm=_f('sigma_ion', 2e-4, 1e-9, 1e2),
              thickness_um=_f('thickness_um', 72.0, 1.0, 1000.0), r_int_ohm_cm2=_f('r_int', 50.0, 0.0, 1e4),
              i0_A_m2=_f('i0', 2.0, 1e-3, 1e3), d_s_m2_s=_f('d_s', 3e-14, 1e-18, 1e-10),
              r_p_um=_f('r_p_um', 3.0, 0.1, 50.0), c_dl_uF_cm2=_f('c_dl_uf', 10.0, 0.01, 1000.0),
              coverage_frac=_f('coverage', 0.5, 0.01, 1.0), porosity=_f('porosity', 8.0, 0.1, 60.0))
    # ── 케이스 자동로드 (&case=): STEP3 미세구조(σ-triad·두께·porosity)만 로드.  R_int(실험앵커)·
    #    i0/D_s(스윕)·C_dl(앵커)은 UI 유지 — 케이스의 R_geom 은 µΩ급 기하값이라 실험 R_int 아님. ──
    case_loaded = None
    _case = (request.args.get('case') or '').strip()
    if _case:
        def _apply(_p):                                       # STEP3 σ-triad·두께·porosity 만 override
            # 리뷰 LOW: is not None (σ=0 비퍼콜 케이스도 로드; 클램프 floor 가 처리) — truthiness 스킵 안 함
            if _p.get('sigma_e_S_cm') is not None:
                kw['sigma_e_S_cm'] = min(1e3, max(1e-6, float(_p['sigma_e_S_cm'])))
            if _p.get('sigma_ion_S_cm') is not None:
                kw['sigma_ion_S_cm'] = min(1e2, max(1e-9, float(_p['sigma_ion_S_cm'])))
            if _p.get('thickness_um') is not None:
                kw['thickness_um'] = min(1000.0, max(1.0, float(_p['thickness_um'])))
            if _p.get('porosity') is not None:
                kw['porosity'] = min(60.0, max(0.1, float(_p['porosity'])))
        try:                                                  # 1) DEM 케이스 (results/<case>/*metrics.json)
            _rd = _contained_join(app.config['RESULTS_FOLDER'], _case)   # 리뷰 LOW: makedirs 안 함(GET 부작용 방지)
            for _mf in ('mpm_metrics.json', 'full_metrics.json'):
                _mp = os.path.join(_rd, _mf)
                if os.path.exists(_mp):
                    _apply(_eis._load_step3_params(_mp)); case_loaded = _case; break
        except Exception:
            pass
        if not case_loaded:                                   # 2) mpm_lab 저장 payload (mpm_lab/<pid>/meta.json → mpm_metrics)
            try:
                import json as _json
                _mj = os.path.join(_contained_join(app.config['MPM_LAB_FOLDER'], _case), 'meta.json')
                if os.path.exists(_mj):
                    _mm = (_json.loads(open(_mj).read()).get('mpm_metrics')) or {}
                    if _mm:
                        _apply(_eis._step3_params_from_metrics(_mm)); case_loaded = _case
            except Exception:
                pass
    # ── 실험앵커 (&expanchor=1): eis_fit CPE→Brug C_dl + Wo1_R → physics_eis 앵커 (frame[4]) ──
    exp_anchor = None
    if (request.args.get('expanchor') or '').strip() in ('1', 'true', 'yes', 'on'):
        try:
            exp_anchor = _eis.load_experimental_anchors()
        except Exception:
            exp_anchor = None
        if exp_anchor:
            kw['c_dl_areal_uF_cm2'] = exp_anchor['c_dl_areal_uF_cm2']
            if exp_anchor.get('r_w_ohm_cm2') is not None:
                kw['r_w_ohm_cm2'] = exp_anchor['r_w_ohm_cm2']
    try:
        freqs = _eis.lab_freq_grid()   # 랩 EC-Lab PEIS: 7 MHz→10 mHz, 10 pts/dec (full/sym .mps 정합)
        Z, el = _eis.physics_eis(freqs, **kw)
        tau, g, R0f, Zr = _eis.drt(freqs, Z)
        peaks = _eis.drt_peaks(tau, g)
    except Exception as e:
        return jsonify({'error': f'EIS 계산 실패: {type(e).__name__}: {e}'}), 200
    # jsonify NaN/Inf 방출 방지 — finite 만
    def _cl(x):
        return float(x) if _math.isfinite(float(x)) else None
    try:                                                      # 리뷰 LOW: 직렬화 예외도 500 대신 JSON error
        return jsonify({
            'nyquist': [{'f': _cl(fr), 'zre': _cl(z.real), 'zim': _cl(-z.imag)} for fr, z in zip(freqs, Z)],
            'drt': [{'tau': _cl(t), 'gamma': _cl(gg)} for t, gg in zip(tau, g)],
            'elements': {k: _cl(v) for k, v in el.items() if isinstance(v, (int, float))},
            'peaks': [{'f_Hz': _cl(p['f_Hz']), 'tau_s': _cl(p['tau_s']), 'R': _cl(p['R_ohm_cm2']),
                       **_eis.assign_drt_peak(p['tau_s'], el)} for p in peaks],
            'bands': _eis.drt_band_map(el),   # τ-대역 물리지도 (hover-anywhere, 전고체 복합양극)
            'provenance': el.get('provenance', {}),
            'params': {k: kw[k] for k in kw},
            'case_loaded': case_loaded,
            'exp_anchor': exp_anchor,
        })
    except Exception as e:
        return jsonify({'error': f'직렬화 실패: {type(e).__name__}: {e}'}), 200


@app.route('/api/ica', methods=['POST'])
def api_ica():
    """ICA(dQ/dV): 방전(또는 충전) 곡선 V,Q → dQ/dV(V) + OCP 상전이 피크.  eis_drt_ica.ica_dqdv.
    POST JSON {v:[...], q:[...]} 또는 {csv:'V,Q\\n…'}.  기존 STEP4 방전곡선 후처리 = 공짜."""
    import math as _math
    try:
        import sys as _sys
        _sd = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'scripts')
        if _sd not in _sys.path:
            _sys.path.insert(0, _sd)
        import eis_drt_ica as _eis
        import numpy as _np
    except Exception as e:
        return jsonify({'error': f'import 실패: {type(e).__name__}: {e}'}), 200
    body = request.get_json(silent=True) or {}
    _cs = body.get('csv')
    if isinstance(_cs, str) and len(_cs) > 5_000_000:         # 리뷰 MED: body cap (~5MB≈25만행) — 방전곡선은 수천점
        return jsonify({'error': f'CSV 너무 큼 ({len(_cs) // 1000}KB > 5MB)'}), 200
    v, q = body.get('v'), body.get('q')
    if isinstance(v, list) and len(v) > 500_000:
        return jsonify({'error': f'점 과다 ({len(v)} > 50만) — 방전곡선은 수천 점'}), 200
    if (not v or not q) and _cs:                              # CSV 텍스트 폴백 (헤더/구분자 관대)
        vv, qq = [], []
        for line in str(_cs).strip().splitlines():
            parts = [p for p in line.replace(',', ' ').replace('\t', ' ').split() if p]
            try:                                              # ★리뷰 MED: 양쪽 파싱 성공 후 append (desync 방지)
                a = float(parts[0]); b = float(parts[1])
            except (ValueError, IndexError):
                continue                                      # 헤더/빈줄/결측셀 스킵 (행 통째로)
            vv.append(a); qq.append(b)
        v, q = vv, qq
    try:
        v = _np.asarray(v, float); q = _np.asarray(q, float)
        m = _np.isfinite(v) & _np.isfinite(q)
        if int(m.sum()) < 4:
            return jsonify({'error': f'유효 (V,Q) 점 부족(<4): {int(m.sum())}'}), 200
        vg, dq, peaks = _eis.ica_dqdv(v[m], q[m])
    except Exception as e:
        return jsonify({'error': f'ICA 계산 실패: {type(e).__name__}: {e}'}), 200

    def _cl(x):
        return float(x) if _math.isfinite(float(x)) else None
    try:
        return jsonify({
            'ica': [{'v': _cl(a), 'dqdv': _cl(b)} for a, b in zip(vg, dq)],
            'peaks': [{'v': _cl(p['V']), 'dqdv': _cl(p['dQdV'])} for p in peaks],
            'n_in': int(m.sum()),
        })
    except Exception as e:
        return jsonify({'error': f'직렬화 실패: {type(e).__name__}: {e}'}), 200


@app.route('/api/ica_case')
def api_ica_case():
    """케이스의 저장된 STEP4 방전곡선(st4_viz.json)에서 V_terminal·용량을 뽑아 dQ/dV 자동 산출 —
    붙여넣기 없이 &case=<pid> 로 ICA.  V = V_terminal(측정 전압) 우선.  용량 = |Δx_mean|/|x100−x0|×100
    (정규화 %, §F1: 면적/질량 앵커가 viz 에 없어 절대 mAh/cm² 못 만듦 → 정규화 진행률만 = 정직)."""
    import math as _math
    import glob as _glob
    _case = (request.args.get('case') or '').strip()
    if not _case:
        return jsonify({'available': False, 'error': 'case 파라미터 없음'}), 200
    # st4_viz.json 위치: mpm_lab/<pid>/(뷰어 st4 자동저장) 우선 → results/<case>/ → step4_viz*.json glob
    _paths = []
    for _base_key in ('MPM_LAB_FOLDER', 'RESULTS_FOLDER'):
        _base = app.config.get(_base_key)
        if not _base:
            continue
        try:
            _d = _contained_join(_base, _case)                # 경로탈출 거부 (GET 부작용 없음: makedirs 안 함)
        except Exception:
            continue
        _paths.append(os.path.join(_d, 'st4_viz.json'))
        try:
            _paths += sorted(_glob.glob(os.path.join(_d, 'step4_viz*.json')))
        except Exception:
            pass
    _viz = None
    for _p in _paths:
        if os.path.isfile(_p):
            try:
                _cand = json.loads(open(_p).read())
            except Exception:
                continue
            if isinstance(_cand, dict) and _cand.get('kind') == 'step4_viz':
                _viz = _cand
                break
    if not _viz:
        return jsonify({'available': False,
                        'hint': '이 케이스엔 저장된 STEP4 방전곡선이 없음 — 뷰어 STEP4-v2 모드에서 📂로 '
                                '한 번 열면 자동 저장됨 (또는 아래에 V,Q 직접 붙여넣기)'}), 200
    cu = _viz.get('curve') or {}
    Vt = cu.get('V_terminal') or cu.get('V') or []
    xm = cu.get('x_mean') or []
    if not Vt or not xm or len(Vt) != len(xm) or len(Vt) < 4:
        return jsonify({'available': False,
                        'hint': f'방전곡선 점 부족({len(Vt)}) — 최신 step4_dyn(--viz-out)로 재생성 필요'}), 200
    try:
        import sys as _sys
        _sd = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'scripts')
        if _sd not in _sys.path:
            _sys.path.insert(0, _sd)
        import eis_drt_ica as _eis
        import numpy as _np
    except Exception as e:
        return jsonify({'available': False, 'error': f'import 실패: {type(e).__name__}: {e}'}), 200
    v = _np.asarray(Vt, float); x = _np.asarray(xm, float)
    m = _np.isfinite(v) & _np.isfinite(x)
    v, x = v[m], x[m]
    if len(v) < 4:
        return jsonify({'available': False, 'error': f'유효 (V,x) 점 부족(<4): {len(v)}'}), 200
    x0, x100 = _viz.get('x0'), _viz.get('x100')                # 용량 진행률 정규화 창
    _win = (abs(float(x100) - float(x0)) if (x0 is not None and x100 is not None) else 0.0)
    if not (_win and _math.isfinite(_win) and _win > 1e-6):
        _win = max(abs(float(x.max() - x.min())), 1e-6)        # 폴백: 관측 x 스팬
    q = _np.abs(x - x[0]) / _win * 100.0                       # 전달 용량 % (0→진행)
    try:
        vg, dq, peaks = _eis.ica_dqdv(v, q)
    except Exception as e:
        return jsonify({'available': False, 'error': f'ICA 계산 실패: {type(e).__name__}: {e}'}), 200

    def _cl(z):
        return float(z) if _math.isfinite(float(z)) else None
    try:
        return jsonify({
            'available': True, 'case': _case, 'q_unit': '용량 % (정규화)',
            'v': [_cl(a) for a in v], 'q': [round(float(b), 3) for b in q],
            'ica': [{'v': _cl(a), 'dqdv': _cl(b)} for a, b in zip(vg, dq)],
            'peaks': [{'v': _cl(p['V']), 'dqdv': _cl(p['dQdV'])} for p in peaks],
            'n_in': int(len(v)),
            'meta': {'c_rate': _viz.get('c_rate'), 'charge': bool(_viz.get('charge')),
                     'end_reason': _viz.get('end_reason'),
                     'v_span': [round(float(v.min()), 3), round(float(v.max()), 3)]},
        })
    except Exception as e:
        return jsonify({'available': False, 'error': f'직렬화 실패: {type(e).__name__}: {e}'}), 200


@app.route('/api/eis_cycle')
def api_eis_cycle():
    """사이클-N EIS/DRT 궤적 (열화 기전 진단, D5).  base σ-triad + R_int 끝점(r0→rc@ntot) → 각 N 의
    Nyquist+DRT (성장 ΔR 을 R_ct/R0/R_w 분배, ASSUMED §F1).  eis_drt_ica.cycle_eis_trajectory 단일소스."""
    import math as _math

    def _f(name, default, lo, hi):
        try:
            v = float(request.args.get(name, default))
        except (TypeError, ValueError):
            return default
        return default if not _math.isfinite(v) else min(hi, max(lo, v))
    try:
        import sys as _sys
        _sd = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'scripts')
        if _sd not in _sys.path:
            _sys.path.insert(0, _sd)
        import eis_drt_ica as _eis
        import numpy as _np
    except Exception as e:
        return jsonify({'error': f'eis_drt_ica import 실패: {type(e).__name__}: {e}'}), 200
    kw = dict(sigma_e_S_cm=_f('sigma_e', 2.0, 1e-6, 1e3), sigma_ion_S_cm=_f('sigma_ion', 2e-4, 1e-9, 1e2),
              thickness_um=_f('thickness_um', 72.0, 1.0, 1000.0), r_int_ohm_cm2=_f('r_int', 50.0, 0.0, 1e4),
              i0_A_m2=_f('i0', 2.0, 1e-3, 1e3), d_s_m2_s=_f('d_s', 3e-14, 1e-18, 1e-10),
              r_p_um=_f('r_p_um', 3.0, 0.1, 50.0), c_dl_uF_cm2=_f('c_dl_uf', 10.0, 0.01, 1000.0),
              coverage_frac=_f('coverage', 0.5, 0.01, 1.0), porosity=_f('porosity', 8.0, 0.1, 60.0))
    if (request.args.get('expanchor') or '').strip() in ('1', 'true', 'yes', 'on'):
        try:
            _anc = _eis.load_experimental_anchors()
        except Exception:
            _anc = None
        if _anc:
            kw['c_dl_areal_uF_cm2'] = _anc['c_dl_areal_uF_cm2']
            if _anc.get('r_w_ohm_cm2') is not None:
                kw['r_w_ohm_cm2'] = _anc['r_w_ohm_cm2']
    r0c, rcc = _f('cycle_r0', 50.0, 1e-3, 1e4), _f('cycle_rc', 125.0, 1e-3, 1e4)
    ntot = int(_f('cycle_ntot', 1000, 1, 1e6))
    shape = 'linear' if (request.args.get('cycle_shape') == 'linear') else 'sqrt'
    jump = _f('cycle_jump', 0.5, 0.0, 1.0)
    try:
        ns = [int(float(x)) for x in (request.args.get('cycle_ns') or '0,100,300,500,1000').split(',') if x.strip()][:24]
        sh = [float(x) for x in (request.args.get('cycle_shares') or '0.7,0.2,0.1').split(',')][:3]
        while len(sh) < 3:
            sh.append(0.0)
    except Exception:
        ns, sh = [0, 100, 300, 500, 1000], [0.7, 0.2, 0.1]
    if not ns:
        ns = [0, ntot]
    try:
        freqs = _eis.lab_freq_grid()   # 랩 EC-Lab PEIS 주파수축 (frame[4] 정합)
        _Z, el = _eis.physics_eis(freqs, **kw)
        mult = _eis.rint_growth_mult(ns, r0c, rcc, ntot, shape, jump)
        traj = _eis.cycle_eis_trajectory(freqs, el, ns, mult, rct_share=sh[0], r0_share=sh[1], rw_share=sh[2])
    except Exception as e:
        return jsonify({'error': f'궤적 계산 실패: {type(e).__name__}: {e}'}), 200

    def _cl(x):
        return float(x) if _math.isfinite(float(x)) else None
    try:
        series = [{
            'N': t['N'], 'mult': round(t['mult'], 3),
            'R0': round(t['R0_ohm_cm2'], 2), 'R_ct': round(t['R_ct_ohm_cm2'], 2),
            'R_int': round(t.get('R_int_ohm_cm2', 0.0), 2),
            'R_w': round(t['R_w_ohm_cm2'], 2), 'R_dc': round(t['R_dc_ohm_cm2'], 2), 'f_ct_Hz': _cl(t['f_ct_Hz']),
            'nyquist': [{'zre': _cl(z.real), 'zim': _cl(-z.imag)} for z in t['Z']],
            'drt': [{'tau': _cl(tt), 'gamma': _cl(gg)} for tt, gg in zip(t['tau'], t['gamma'])],
            'peaks': [{'f_Hz': _cl(p['f_Hz']), 'R': _cl(p['R_ohm_cm2'])} for p in t['peaks']],
        } for t in traj]
        return jsonify({'series': series, 'shares': {'R_ct': sh[0], 'R0': sh[1], 'R_w': sh[2]},
                        'cycle': {'r0': r0c, 'rc': rcc, 'ntot': ntot, 'shape': shape, 'jump': jump},
                        'note': 'ΔR_int(N) 분배(R_ct/R0/R_w)=ASSUMED §F1; R_int 끝점=측정, 사이=assumed-form'})
    except Exception as e:
        return jsonify({'error': f'직렬화 실패: {type(e).__name__}: {e}'}), 200


@app.route('/api/eis_fig')
def api_eis_fig():
    """발표/논문용 EIS 그림 다운로드 (matplotlib png/svg, 흰 배경 ASCII 라벨).  kind=eis(Nyquist+DRT) |
    cycle(사이클 오버레이 + R(N) 성장).  /api/eis 와 동일 σ 파라미터 + kind·fmt·cycle_*.
    eis_drt_ica.save_eis_figures 단일소스 (CLI --fig 와 동일 코어) = 랩 규약 svg/png/csv 동시."""
    import math as _math
    import shutil as _sh
    import tempfile as _tf

    def _f(name, default, lo, hi):
        try:
            v = float(request.args.get(name, default))
        except (TypeError, ValueError):
            return default
        return default if not _math.isfinite(v) else min(hi, max(lo, v))
    try:
        import sys as _sys
        _sd = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'scripts')
        if _sd not in _sys.path:
            _sys.path.insert(0, _sd)
        import eis_drt_ica as _eis
        import numpy as _np
    except Exception as e:
        return jsonify({'error': f'eis_drt_ica import 실패: {type(e).__name__}: {e}'}), 200
    kw = dict(sigma_e_S_cm=_f('sigma_e', 2.0, 1e-6, 1e3), sigma_ion_S_cm=_f('sigma_ion', 2e-4, 1e-9, 1e2),
              thickness_um=_f('thickness_um', 72.0, 1.0, 1000.0), r_int_ohm_cm2=_f('r_int', 50.0, 0.0, 1e4),
              i0_A_m2=_f('i0', 2.0, 1e-3, 1e3), d_s_m2_s=_f('d_s', 3e-14, 1e-18, 1e-10),
              r_p_um=_f('r_p_um', 3.0, 0.1, 50.0), c_dl_uF_cm2=_f('c_dl_uf', 10.0, 0.01, 1000.0),
              coverage_frac=_f('coverage', 0.5, 0.01, 1.0), porosity=_f('porosity', 8.0, 0.1, 60.0))
    if (request.args.get('expanchor') or '').strip() in ('1', 'true', 'yes', 'on'):
        try:
            _anc = _eis.load_experimental_anchors()
        except Exception:
            _anc = None
        if _anc:
            kw['c_dl_areal_uF_cm2'] = _anc['c_dl_areal_uF_cm2']
            if _anc.get('r_w_ohm_cm2') is not None:
                kw['r_w_ohm_cm2'] = _anc['r_w_ohm_cm2']
    kind = 'cycle' if request.args.get('kind') == 'cycle' else 'eis'
    fmt = 'svg' if request.args.get('fmt') == 'svg' else 'png'
    tmp = _tf.mkdtemp()
    try:
        freqs = _eis.lab_freq_grid()   # 랩 EC-Lab PEIS 주파수축 (frame[4] 정합)
        Z, el = _eis.physics_eis(freqs, **kw)
        tau, g, _r0, _zr = _eis.drt(freqs, Z)
        traj = None
        if kind == 'cycle':
            r0c, rcc = _f('cycle_r0', 50.0, 1e-3, 1e4), _f('cycle_rc', 125.0, 1e-3, 1e4)
            ntot = int(_f('cycle_ntot', 1000, 1, 1e6))
            shape = 'linear' if request.args.get('cycle_shape') == 'linear' else 'sqrt'
            jump = _f('cycle_jump', 0.5, 0.0, 1.0)
            ns = [int(float(x)) for x in (request.args.get('cycle_ns') or '0,100,300,500,1000').split(',')
                  if x.strip()][:24] or [0, ntot]
            sh = [float(x) for x in (request.args.get('cycle_shares') or '0.7,0.2,0.1').split(',')][:3]
            while len(sh) < 3:
                sh.append(0.0)
            mult = _eis.rint_growth_mult(ns, r0c, rcc, ntot, shape, jump)
            traj = _eis.cycle_eis_trajectory(freqs, el, ns, mult, rct_share=sh[0], r0_share=sh[1], rw_share=sh[2])
        prefix = os.path.join(tmp, 'eis')
        _eis.save_eis_figures(prefix, freqs, Z, el, tau, g, _eis.drt_peaks(tau, g), traj=traj, fmt=(fmt,))
        path = f'{prefix}_{kind}.{fmt}'
        if not os.path.isfile(path):
            return jsonify({'error': f'그림 생성 실패 ({kind}.{fmt})'}), 200
        with open(path, 'rb') as fh:
            data = fh.read()
    except Exception as e:
        return jsonify({'error': f'그림 생성 실패: {type(e).__name__}: {e}'}), 200
    finally:
        _sh.rmtree(tmp, ignore_errors=True)
    return app.response_class(data, mimetype=('image/svg+xml' if fmt == 'svg' else 'image/png'),
                              headers={'Content-Disposition': f'attachment; filename="eis_{kind}.{fmt}"'})


@app.route('/api/eis_exp')
def api_eis_exp():
    """실험 EIS Nyquist (이종기술/eis/extracted) → Ω·cm² 정규화 = physics-EIS 위 오버레이(frame[4]).
    ★files=<stem1,stem2,…> 지정 시 그 측정만(표 체크박스 선택), 없으면 cell=full|sym 전체.
    Z(Ω)×area = ASR(eis_fit 규약; area 는 파일명 sym/full 로 파일별 결정).  데이터 부재 시 available:false."""
    import csv as _csv
    import glob as _glob
    import math as _math
    cell = 'sym' if request.args.get('cell') == 'sym' else 'full'
    _files = set(x.strip() for x in (request.args.get('files') or '').split(',') if x.strip())
    _want_drt = (request.args.get('drt') or '1') not in ('0', 'false', 'no')   # 실험 DRT 계산(기본 on)
    root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    exdir = os.path.join(root, '이종기술', 'eis', 'extracted')
    if not os.path.isdir(exdir):
        return jsonify({'available': False, 'hint': '실험 EIS 추출본 없음 (이종기술/eis/extracted) — 랩 데이터'}), 200
    try:
        import sys as _sys
        _sd = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'scripts')
        if _sd not in _sys.path:
            _sys.path.insert(0, _sd)
        import eis_drt_ica as _eis
        import numpy as _np
    except Exception:
        _eis, _np, _want_drt = None, None, False
    curves = []
    for p in sorted(_glob.glob(os.path.join(exdir, '*.csv'))):
        name = os.path.basename(p)[:-4]
        if _files:                                            # 선택 측정만 (셀타입 무관, 파일별 area)
            if name not in _files:
                continue
        elif ('sym' in name) != (cell == 'sym'):              # 선택 없으면 full/sym 전체
            continue
        area = 0.7854 if ('sym' in name) else 1.3273          # 파일별 AREA (10π sym / 13π full)
        fs, zr_l, zi_l = [], [], []
        try:
            for row in _csv.DictReader(open(p)):
                try:
                    fv = float(row['freq_Hz']); zr = float(row['ReZ_ohm']) * area; zi = float(row['negImZ_ohm']) * area
                except (KeyError, ValueError, TypeError):
                    continue
                if all(_math.isfinite(v) for v in (fv, zr, zi)) and fv > 0 and abs(zr) < 1e6 and abs(zi) < 1e6:
                    fs.append(fv); zr_l.append(zr); zi_l.append(zi)
        except Exception:
            continue
        if len(fs) < 4:
            continue
        pts = [{'zre': round(a, 3), 'zim': round(b, 3)} for a, b in zip(zr_l, zi_l)]
        if len(pts) > 80:
            pts = pts[::(len(pts) // 80 + 1)]
        cobj = {'name': name, 'pts': pts}
        if _want_drt and _eis is not None:                    # 실험 DRT (분포 = 눌린 Nyquist 보다 프로세스 명확)
            try:
                # DRT 안정화: 선두 인덕턴스(zim<0=Im(Z)>0) crop → 첫 용량성부터.  Z=Re+jIm, Im=-zim.
                _fa, _Za = _np.asarray(fs, float), _np.asarray(zr_l, float) - 1j * _np.asarray(zi_l, float)
                _cap = _np.asarray(zi_l, float) > 0
                if _cap.any():
                    _k0 = int(_np.argmax(_cap))
                    _fa, _Za = _fa[_k0:], _Za[_k0:]
                if len(_fa) >= 6:
                    _tau, _g, _r0, _zr = _eis.drt(_fa, _Za, n_tau=60, lam=1e-2)
                    _dpts = list(zip(_tau, _g))
                    if len(_dpts) > 70:
                        _dpts = _dpts[::(len(_dpts) // 70 + 1)]
                    cobj['drt'] = [{'tau': float(t), 'gamma': (float(gg) if _math.isfinite(float(gg)) else 0.0)}
                                   for t, gg in _dpts]
            except Exception:
                pass
        curves.append(cobj)
    if not curves:
        return jsonify({'available': False, 'hint': ('선택 측정 추출본 없음' if _files else f'{cell} 셀 추출본 없음')}), 200
    return jsonify({'available': True, 'cell': cell, 'selected': bool(_files), 'curves': curves,
                    'note': 'Z(Ω)×area→Ω·cm²(ASR, eis_fit 규약); 방울=실측 Nyquist, physics-EIS 선과 겹치면 frame[4] '
                            '(반쪽셀 모델 vs primer-SUS 풀셀 = 배치 다름, 자릿수-대조)'})


def _eis_archive_paths():
    """이종기술/eis 아카이브 경로 (raw/extracted/catalog/fits).

    ★ WEBAPP_EIS_FOLDER 로 override 가능 (2026-08-03).  이 경로는 다른 폴더들과 달리
      env 를 안 봐서 **리포 안 실제 측정 아카이브로 고정**돼 있었다 — 그 결과 이 라우트를
      부르는 테스트가 WEBAPP_* 를 tmp 로 다 돌려놔도 **진짜 fits CSV·두께 override 를
      덮어썼다** (실제로 발생: eis_fit_results.csv 12행 → 테스트 1행으로 소실.
      extracted/*.csv 는 git tracked 라 무손상이었고 eis_fit.py 재실행으로 전량 복구).
      derived 산출물은 재생성되지만 테스트가 실데이터를 만지는 구조 자체가 결함이다.
    """
    _root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    a = os.environ.get('WEBAPP_EIS_FOLDER') or os.path.join(_root, '이종기술', 'eis')
    return {'root': _root, 'archive': a, 'raw': os.path.join(a, 'raw'),
            'extracted': os.path.join(a, 'extracted'), 'catalog': os.path.join(a, 'eis_catalog.csv'),
            'fits': os.path.join(a, 'fits', 'eis_fit_results.csv')}


def _eis_exp_table():
    """실험 EIS 측정 목록 = eis_catalog.csv(메타) ⋈ eis_fit_results.csv(도출값) by filename.
    반환 {rows:[...], n, fitted, summary}.  파일 없으면 빈 리스트 (graceful)."""
    import csv as _csv
    import json as _json
    P = _eis_archive_paths()
    try:                                                  # 사용자가 L 을 명시 지정한 stem 집합
        _ovr = set(_json.load(open(os.path.join(P['archive'], 'thickness_overrides.json'))))
    except Exception:
        _ovr = set()
    cat = {}
    if os.path.isfile(P['catalog']):
        try:
            for r in _csv.DictReader(open(P['catalog'])):
                cat[r.get('filename', '')] = r
        except Exception:
            pass
    fit = {}
    if os.path.isfile(P['fits']):
        try:
            for r in _csv.DictReader(open(P['fits'])):
                fit[r.get('filename', '')] = r
        except Exception:
            pass

    def _num(d, k):
        try:
            v = d.get(k, '')
            return round(float(v), 4) if v not in ('', None) else None
        except (TypeError, ValueError):
            return None
    rows = []
    for fn in sorted(set(cat) | set(fit)):
        c, f = cat.get(fn, {}), fit.get(fn, {})
        rows.append({
            'filename': fn, 'date': c.get('date', ''), 'cell_type': c.get('cell_type', '') or f.get('cell_type', ''),
            'blend': c.get('blend', ''), 'state': c.get('state', ''), 'Ewe_V': _num(c, 'Ewe_V'),
            'n_points': _num(c, 'n_points'), 'f_max_Hz': _num(c, 'f_max_Hz'), 'f_min_Hz': _num(c, 'f_min_Hz'),
            # 파일명이 알려주는 두께(예 '70um') — ⚠집전체(SUS/c-SUS ~15-20µm) 포함 총두께라 σ_e 에
            # 그대로 쓰면 안 됨(eis_fit.py:32-36).  σ_e 용 L 은 합제만(기본 45).  표에 병기해 오입력 방지.
            'filename_thickness_um': _num(c, 'thickness_um'),
            # L 이 사용자 지정인지(override JSON 에 키 존재) — ⚠경고는 '지정했을 때만' 띄워야 한다.
            # 기본 45 와 파일명 45um 이 우연히 같아도 경고가 뜨던 오탐 차단 (감사 L1).
            'L_is_user_set': fn in _ovr,
            'R_s_ohmcm2': _num(f, 'R_s_ohmcm2'), 'R_int_ohmcm2': _num(f, 'R1_ohmcm2'),
            'R_w_ohmcm2': _num(f, 'R_w_ohmcm2'), 'C_dl_uF_cm2': _num(f, 'C_dl_uF_cm2'),
            'sigma_e_mScm': _num(f, 'sigma_e_mScm'), 'L_composite_um': _num(f, 'L_composite_um'),
            'rmse_pct': _num(f, 'rmse_pct'),
            'circuit': f.get('circuit', ''), 'fitted': bool(f.get('R1_ohm')),
            'area_cm2': _num(c, 'area_cm2') or _num(f, 'area_cm2'), 'note': c.get('note', '') or f.get('note', ''),
        })
    fitted = sum(1 for r in rows if r['fitted'])
    # 대표값 (frame[4] 앵커) — load_experimental_anchors 와 동일 소스
    summ = None
    try:
        import sys as _sys
        _sd = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'scripts')
        if _sd not in _sys.path:
            _sys.path.insert(0, _sd)
        import eis_drt_ica as _eis
        summ = _eis.load_experimental_anchors()
    except Exception:
        summ = None
    return {'rows': rows, 'n': len(rows), 'fitted': fitted, 'anchor': summ}


@app.route('/api/eis_exp_list')
def api_eis_exp_list():
    """이미 먹인 + 업로드된 실험 EIS 측정 목록(표) + 도출값 + frame[4] 대표앵커."""
    try:
        return jsonify(_eis_exp_table())
    except Exception as e:
        return jsonify({'error': f'목록 실패: {type(e).__name__}: {e}', 'rows': []}), 200


@app.route('/api/eis_exp_thickness', methods=['POST'])
def api_eis_exp_thickness():
    """대칭셀 σ_e 두께 설정 (site 두께 입력) → thickness_overrides.json 저장 + σ_e 즉시 재계산
    (σ_e = L/R1, R1 은 이미 fit된 값 재사용 → CNLS 재fit 불필요, 즉답).  기본 45µm."""
    import csv as _csv
    import json as _json
    P = _eis_archive_paths()
    body = request.get_json(silent=True) or {}
    fn = (body.get('filename') or '').strip()
    if not fn:
        return jsonify({'error': 'filename 없음'}), 200
    try:
        thick = float(body.get('thickness_um'))
    except (TypeError, ValueError):
        return jsonify({'error': '두께 숫자 아님'}), 200
    if not (0.5 <= thick <= 300):
        return jsonify({'error': f'두께 범위 벗어남 ({thick} — 0.5~300µm)'}), 200
    # ★대상 검증 (2026-07-27 감사 M3/M4): 예전엔 존재하지 않는 filename 도, σ_e 에 두께를 안 쓰는
    #   full-cell 도 무조건 ok:true 를 돌려줘 UI 가 "✓ σ_e 재계산됨" 초록 메시지를 띄웠다 —
    #   실제론 아무것도 안 바뀌고 override JSON 만 오염.  존재·셀타입을 먼저 확인한다.
    _rows = {r['filename']: r for r in (_eis_exp_table().get('rows') or [])}
    _row = _rows.get(fn)
    if _row is None:
        return jsonify({'error': f'그런 측정 없음: {fn}'}), 200
    # ★ 2026-08-03 정정: 예전엔 full 셀을 **거부**했다.  σ_e=L/R1 이 대칭셀 전용인 것은 맞지만,
    #   "full 셀은 두께가 필요없다" 는 과한 진술이었다 — full 셀의 R_s(HF 절편)에는 이온 TL 저항
    #   ∝ L/σ_ion 이 들어있고, R_int(Ω·cm²geo) 도 1/(a_spec·L) 로 스케일한다.  즉 **두께가 다른
    #   full 셀끼리 R_int 를 비교하려면 L 이 필요**하고, physics-EIS 대조도 같은 L 에서만 의미가 있다.
    #   ⇒ 거부하지 말고 **기록**한다.  단 σ_e 는 계산하지 않고 '—' 로 둔다 (정의되지 않으므로).
    _is_sym = (_row.get('cell_type') or '') == 'symmetric'
    ov_path = os.path.join(P['archive'], 'thickness_overrides.json')
    try:                                                      # override JSON 갱신
        ov = _json.load(open(ov_path)) if os.path.isfile(ov_path) else {}
    except Exception:
        ov = {}
    ov[fn] = round(thick, 2)
    try:
        with open(ov_path, 'w') as fh:
            _json.dump(ov, fh, ensure_ascii=False, indent=1)
    except Exception as e:
        return jsonify({'error': f'override 저장 실패: {e}'}), 200
    # fits CSV 의 해당 대칭셀 행 σ_e 즉시 재계산 (R1 재사용)
    fits = P['fits']
    if os.path.isfile(fits):
        try:
            with open(fits, newline='') as fh:
                rd = _csv.DictReader(fh); cols = rd.fieldnames; rows = list(rd)
            for r in rows:
                if r.get('filename') == fn and not _is_sym:
                    r['L_composite_um'] = round(thick, 2)     # 메타데이터 (σ_e 엔 안 씀)
                    r['note'] = ((r.get('note') or '') + f'  · L={thick:g}µm 기록(σ_e 미사용 — '
                                 f'full 셀 R1=R_int 는 계면 ASR)').strip()
                if r.get('filename') == fn and _is_sym:
                    try:
                        r1 = float(r.get('R1_ohmcm2', ''))
                        if r1 > 0:
                            r['L_composite_um'] = round(thick, 2)
                            r['sigma_e_mScm'] = round(thick * 1e-4 / r1 * 1e3, 4)
                            _lo = round(max(thick - 2, 0.1) * 1e-4 / r1 * 1e3, 4)
                            _hi = round((thick + 2) * 1e-4 / r1 * 1e3, 4)
                            r['sigma_e_range_mScm'] = f'{_lo}-{_hi}'
                            r['note'] = f'SUS ion-blocking → R1=R_e; σ_e=L/R1 (L={thick:g}µm 지정)'
                    except (TypeError, ValueError):
                        pass
            with open(fits, 'w', newline='') as fh:
                w = _csv.DictWriter(fh, fieldnames=cols); w.writeheader(); w.writerows(rows)
        except Exception as e:
            return jsonify({'error': f'σ_e 재계산 실패: {e}', **_eis_exp_table()}), 200
    return jsonify({'ok': True, 'filename': fn, 'thickness_um': round(thick, 2),
                    'sigma_e_recomputed': _is_sym,
                    'note': ('σ_e=L/R1 재계산됨' if _is_sym else
                             'L 기록됨 — σ_e 는 full 셀에서 정의되지 않아 계산하지 않음 '
                             '(R1=R_int 는 계면 ASR).  두께가 다른 full 셀 비교·physics-EIS '
                             '대조에 쓰입니다'),
                    **_eis_exp_table()})


@app.route('/api/eis_exp_upload', methods=['POST'])
def api_eis_exp_upload():
    """실험 EIS 파일 업로드 → 아카이브 → 추출(.mpr=galvani/WSL) → CNLS fit(eis_fit) → 값도출.
    허용: .mpr(BioLogic 바이너리)·.mps(설정)·.csv(우리 tidy: freq_Hz,ReZ_ohm,negImZ_ohm).
    galvani 부재(클라우드) 시 .mpr 은 raw 저장+파싱대기(WSL), .csv 는 즉시 fit."""
    import csv as _csv
    import subprocess as _sp
    P = _eis_archive_paths()
    os.makedirs(P['raw'], exist_ok=True); os.makedirs(P['extracted'], exist_ok=True)
    files = request.files.getlist('files')
    if not files:
        return jsonify({'error': '파일 없음'}), 200
    saved, notes = [], []
    for fs in files:
        raw_name = (fs.filename or '').strip()
        if not raw_name:
            continue
        base = os.path.basename(raw_name).replace('\\', '_').replace('/', '_')
        stem, ext = os.path.splitext(base); ext = ext.lower()
        base = stem + ext          # ★확장자 소문자로 정규화 (감사 L2): 대문자 .CSV 는 저장은 되지만
        #                            eis_archive/eis_fit 의 endswith('.csv')(대소문자 구분)에 안 걸려
        #                            표에 영영 안 나타나는데 업로드 응답은 성공을 알렸다.
        if ext not in ('.mpr', '.mps', '.csv'):
            notes.append(f'{base}: 확장자 미지원 (.mpr/.mps/.csv)'); continue
        # 셀타입 미상시 파일명으로 추정 (sym/full) — 없으면 사용자 접두어 권장
        if ext == '.csv':
            dst = _contained_join(P['extracted'], base)
            fs.save(dst)
            # tidy 검증 (필수 열)
            try:
                hdr = next(_csv.reader(open(dst)), [])
                if not ({'freq_Hz', 'ReZ_ohm', 'negImZ_ohm'} <= set(h.strip() for h in hdr)):
                    notes.append(f'{base}: CSV 열 부족 (freq_Hz,ReZ_ohm,negImZ_ohm 필요) — 저장은 됨')
            except Exception:
                pass
            saved.append(base)
        else:                                                 # .mpr / .mps → raw
            dst = _contained_join(P['raw'], base)
            fs.save(dst)
            saved.append(base)
    if not saved:
        return jsonify({'error': '저장된 파일 없음', 'notes': notes, **_eis_exp_table()}), 200
    # 업로드 시 두께 지정(선택) → fit 실행 전에 thickness_overrides.json 기록 (stem 키 = eis_fit 규약)
    # ⇒ 같은 pass 의 CNLS fit 이 바로 이 L 로 σ_e=L/R1 계산 (사후 /api/eis_exp_thickness 재계산 불필요)
    import json as _json
    try:
        _th = float(request.form.get('thickness_um') or '')
    except (TypeError, ValueError):
        _th = None
    if _th is not None and 0.5 <= _th <= 300:
        ov_path = os.path.join(P['archive'], 'thickness_overrides.json')
        try:
            ov = _json.load(open(ov_path)) if os.path.isfile(ov_path) else {}
        except Exception:
            ov = {}
        for b in saved:
            ov[os.path.splitext(b)[0]] = round(_th, 2)
        try:
            with open(ov_path, 'w') as fh:
                _json.dump(ov, fh, ensure_ascii=False, indent=1)
            notes.append(f'L={_th:g}µm 지정 → 대칭셀 σ_e=L/R1 이 이 두께로 즉시 계산됨')
        except Exception as e:
            notes.append(f'두께 저장 실패: {e}')
    elif _th is not None:
        # ★기존 override 가 있으면 45 가 아니라 그게 쓰인다 — "기본 45µm 로 fit" 은 거짓이었음 (감사 M6)
        try:
            _ov0 = _json.load(open(os.path.join(P['archive'], 'thickness_overrides.json')))
        except Exception:
            _ov0 = {}
        _kept = {os.path.splitext(b)[0]: _ov0[os.path.splitext(b)[0]]
                 for b in saved if os.path.splitext(b)[0] in _ov0}
        notes.append(f'두께 {_th}µm 범위 밖(0.5~300) — 무시.  '
                     + (f'기존 지정 L={"/".join(f"{v:g}" for v in _kept.values())}µm 유지'
                        if _kept else '기본 45µm 로 fit'))
    # 추출(.mpr, galvani 있으면) + 카탈로그 재생성
    # 두 스크립트는 **다른 패키지**를 요구한다 (archive=galvani[.mpr 파싱], fit=impedance[CNLS])
    # → 각자 그 패키지를 가진 인터프리터로 돌린다.  둘이 서로 다른 venv 에 있어도 동작.
    arch_msg = ''
    try:
        r = _sp.run([_eis_python('galvani'), os.path.join(P['root'], 'scripts', 'eis_archive.py')],
                    capture_output=True, text=True, timeout=180, cwd=P['root'])
        arch_msg = _subproc_msg(r, 'archive(추출)')
        arch_ok = (r.returncode == 0)
    except Exception as e:
        arch_msg, arch_ok = f'⛔ archive 실행 실패: {e}', False
    # CNLS fit (impedance 있으면) → 값도출
    fit_msg = ''
    try:
        r = _sp.run([_eis_python('impedance'), os.path.join(P['root'], 'scripts', 'eis_fit.py')],
                    capture_output=True, text=True, timeout=300, cwd=P['root'])
        fit_msg = _subproc_msg(r, 'fit(CNLS)')
        fit_ok = (r.returncode == 0)
    except Exception as e:
        fit_msg, fit_ok = f'⛔ fit 실행 실패: {e}', False
    tab = _eis_exp_table()
    # ★ 2026-08-03: 옛 코드는 fit 이 죽어도 ok:True 를 돌려줘 UI 가 초록 ✓ 를 띄웠고, 표는 **옛
    #   결과**를 그대로 그렸다 — 사용자에겐 "저장은 됐는데 값이 안 뜬다 / L 지정이 안 먹는다" 로
    #   보인다 (실제 신고).  실패를 실패로 돌려준다.
    return jsonify({'ok': bool(fit_ok and arch_ok), 'saved': saved, 'notes': notes,
                    'archive': arch_msg, 'fit': fit_msg,
                    'stale_table': not fit_ok,       # True = 아래 표는 이번 업로드 반영 전 값
                    **tab})


_EIS_PY_CACHE = {}


def _eis_python(need_mod=None):
    """EIS 하위 스크립트를 돌릴 인터프리터 — `need_mod` 를 **실제로 import 할 수 있는** 것을 고른다.

    ★ 왜 (2026-08-03): 옛 코드는 `os.environ.get('PYTHON','python3')` 였다.  그런데 webapp 이
      venv 로 뜨면 그 안의 python3 가 잡히는데, 사용자가 셸에서 `python3 scripts/eis_fit.py` 를
      돌리면 **시스템 python3**(~/.local 사이트패키지 포함)가 잡힌다.  실제로 셸에서는 fit 15/15
      로 성공하는데 webapp 에서는 `No module named 'impedance'` 로 죽는 상황이 나왔다 — 같은
      기계, 같은 스크립트, 다른 인터프리터.  사람이 "어느 pip 이냐"를 추적하게 두지 않는다.

    순서: $PYTHON → 이 프로세스(sys.executable) → PATH 의 python3 → 흔한 사용자 venv.
    전부 실패하면 첫 후보를 돌려주고 (오류 메시지는 _subproc_msg 가 설치법까지 안내한다).
    """
    key = need_mod or ''
    if key in _EIS_PY_CACHE:
        return _EIS_PY_CACHE[key]
    import subprocess as _sp
    cands = [os.environ.get('PYTHON'), sys.executable, 'python3',
             os.path.expanduser('~/.venv/bin/python3'),
             os.path.expanduser('~/venv/bin/python3')]
    cands = [c for i, c in enumerate(cands) if c and c not in cands[:i]]
    chosen = cands[0]
    if need_mod:
        for c in cands:
            try:
                if _sp.run([c, '-c', f'import {need_mod}'], capture_output=True,
                           timeout=25).returncode == 0:
                    chosen = c
                    break
            except Exception:                                 # 없는 실행파일·타임아웃 → 다음 후보
                continue
    _EIS_PY_CACHE[key] = chosen
    return chosen


def _subproc_msg(r, label):
    """서브프로세스 결과 → 사람이 고칠 수 있는 한 줄.  (2026-08-03)

    ★ 왜 필요한가: 옛 코드는 `(r.stderr or '').strip()[:200]` = traceback 의 **앞** 200자를
      보여줬다.  파이썬 traceback 의 앞부분은 `Traceback… File "…", line 261, in <module>`
      이고 **정작 원인인 마지막 줄**(`ModuleNotFoundError: No module named 'impedance'`)이
      잘려나간다.  실제로 화면에 `…line 142, in main from i` 까지만 떠서 원인 판독이
      불가능했다.  게다가 returncode 를 안 봐서 실패인데 ok:True + 초록 ✓ 가 떴다.
    """
    if r.returncode == 0:
        _out = (r.stdout or '').strip().splitlines()
        return _out[-1] if _out else ''
    err = (r.stderr or '').strip()
    lines = [l for l in err.splitlines() if l.strip()]
    last = lines[-1] if lines else f'(stderr 없음, exit {r.returncode})'
    m = re.search(r"No module named '([^']+)'", err)          # 가장 흔한 원인 → 처방까지
    if m:
        return (f'⛔ {label} 실패 — 파이썬 패키지 **{m.group(1)}** 미설치.  '
                f'설치: pip install {m.group(1)}   (webapp 이 쓰는 인터프리터에: '
                f'$PYTHON -m pip install {m.group(1)})')
    return f'⛔ {label} 실패 (exit {r.returncode}): {last[:300]}'


@app.route('/api/eis_exp_rename', methods=['POST'])
def api_eis_exp_rename():
    """실험 EIS 측정 **이름 변경** — raw/extracted 파일 + fits CSV 행 + 두께 override 를 함께 옮긴다.

    부분 개명은 데이터를 잃는다: 파일만 바꾸고 fits 행을 안 옮기면 표에서 사라지고,
    override 만 남으면 다음 재fit 이 **남의 두께**를 상속한다 (삭제 경로가 이미 겪은 문제,
    2026-07-27 감사 M5).  ⇒ 네 곳을 한 번에, 실패하면 아무것도 안 바꾼다.
    POST JSON {filename, new_name}.  확장자는 유지 (사용자가 줘도 무시).
    """
    import csv as _csv
    import json as _json
    P = _eis_archive_paths()
    body = request.get_json(silent=True) or {}
    fn = (body.get('filename') or '').strip()
    new = (body.get('new_name') or '').strip()
    if not fn or not new:
        return jsonify({'error': 'filename / new_name 필요'}), 200
    stem, ext = os.path.splitext(fn)
    new_stem = os.path.splitext(new)[0].strip()
    # 파일명 안전성: 경로구분자·상위참조 거부 (표시용 이름이 곧 파일명이라 여기서 막는다)
    if not new_stem or not re.fullmatch(r'[A-Za-z0-9가-힣 ._+#()\-]{1,120}', new_stem):
        return jsonify({'error': '이름은 영문/숫자/한글/공백/._+#()- 만, 1~120자 '
                                 '(경로구분자·상위참조 금지)'}), 200
    if new_stem == stem:
        return jsonify({'error': '같은 이름입니다', **_eis_exp_table()}), 200
    new_fn = new_stem + ext
    # 대상 존재 확인 + 중복 거부 (덮어쓰면 남의 측정을 조용히 파괴한다)
    _rows = {r['filename']: r for r in (_eis_exp_table().get('rows') or [])}
    if fn not in _rows:
        return jsonify({'error': f'그런 측정 없음: {fn}'}), 200
    if new_fn in _rows:
        return jsonify({'error': f'이미 있는 이름: {new_fn}'}), 200
    moved = []
    try:
        for folder in ('raw', 'extracted'):
            for _e in ({ext, '.csv', '.mpr', '.mps'} if folder == 'raw' else {'.csv'}):
                src = _contained_join(P[folder], stem + _e)
                if os.path.isfile(src):
                    dst = _contained_join(P[folder], new_stem + _e)
                    if os.path.exists(dst):
                        raise RuntimeError(f'대상이 이미 있음: {os.path.basename(dst)}')
                    os.rename(src, dst)
                    moved.append((dst, src))                  # 되돌리기용 (dst→src)
    except Exception as e:
        for dst, src in reversed(moved):                      # 부분 개명 롤백
            try:
                os.rename(dst, src)
            except Exception:
                pass
        return jsonify({'error': f'파일 이름변경 실패(되돌림): {e}'}), 200
    # 두께 override 이관 (남기면 다음 재fit 이 남의 두께를 상속)
    ov_path = os.path.join(P['archive'], 'thickness_overrides.json')
    try:
        ov = _json.load(open(ov_path)) if os.path.isfile(ov_path) else {}
        for _k in (stem, fn):
            if _k in ov:
                ov[new_stem] = ov.pop(_k)
        with open(ov_path, 'w') as fh:
            _json.dump(ov, fh, ensure_ascii=False, indent=1)
    except Exception:
        pass
    # fits CSV 행 이관 (안 옮기면 표에서 사라진다 = 값 손실로 보임)
    fits = P['fits']
    if os.path.isfile(fits):
        try:
            with open(fits, newline='') as fh:
                rd = _csv.DictReader(fh); cols = rd.fieldnames; rows = list(rd)
            for r in rows:
                if r.get('filename') in (fn, stem):
                    r['filename'] = new_fn
                if r.get('stem') == stem:
                    r['stem'] = new_stem
            with open(fits, 'w', newline='') as fh:
                w = _csv.DictWriter(fh, fieldnames=cols); w.writeheader(); w.writerows(rows)
        except Exception as e:
            return jsonify({'error': f'파일은 바뀌었으나 fit 기록 이관 실패: {e}',
                            **_eis_exp_table()}), 200
    return jsonify({'ok': True, 'filename': fn, 'new_filename': new_fn, **_eis_exp_table()})


@app.route('/api/eis_exp_delete', methods=['POST'])
def api_eis_exp_delete():
    """실험 EIS 측정 파일 삭제 — 원본·추출·fit 기록 제거.
    POST JSON {filename: 'name.csv'}."""
    import csv as _csv
    P = _eis_archive_paths()
    body = request.get_json(silent=True) or {}
    fn = (body.get('filename') or '').strip()
    if not fn:
        return jsonify({'error': 'filename 없음'}), 200
    # path traversal 방지
    try:
        safe_fn = _contained_join(P['archive'], fn)
        if not safe_fn.startswith(P['archive']):
            return jsonify({'error': 'invalid path'}), 403
    except Exception:
        return jsonify({'error': 'path error'}), 400
    # 1) 원본/추출 파일 삭제
    deleted = []
    for folder in ['raw', 'extracted']:
        path = _contained_join(P[folder], fn)
        if os.path.isfile(path):
            try:
                os.remove(path)
                deleted.append(folder)
            except Exception:
                pass
    # 1-b) 두께 override 도 제거 (2026-07-27 감사 M5): 안 지우면 같은 셀을 다시 재서 업로드할 때
    #      옛 L 을 조용히 상속해 σ_e=L/R1 이 틀린 두께로 산출된다 (재측정 워크플로에서 실제로 발생).
    import json as _json
    _ovp = os.path.join(P['archive'], 'thickness_overrides.json')
    if os.path.isfile(_ovp):
        try:
            _ov = _json.load(open(_ovp))
            if _ov.pop(os.path.splitext(fn)[0], None) is not None:
                with open(_ovp, 'w') as _fh:
                    _json.dump(_ov, _fh, ensure_ascii=False, indent=1)
                deleted.append('thickness_override')
        except Exception:
            pass
    # 2) fit 기록에서 행 제거
    fits = P['fits']
    if os.path.isfile(fits):
        try:
            with open(fits, newline='') as fh:
                rd = _csv.DictReader(fh)
                cols = rd.fieldnames
                rows = [r for r in rd if r.get('filename') != fn]
            with open(fits, 'w', newline='') as fh:
                w = _csv.DictWriter(fh, fieldnames=cols)
                w.writeheader()
                w.writerows(rows)
            deleted.append('fit_record')
        except Exception:
            pass
    # 3) 카탈로그에서 행 제거
    cat = P['catalog']
    if os.path.isfile(cat):
        try:
            with open(cat, newline='') as fh:
                rd = _csv.DictReader(fh)
                cols = rd.fieldnames
                rows = [r for r in rd if r.get('filename') != fn]
            with open(cat, 'w', newline='') as fh:
                w = _csv.DictWriter(fh, fieldnames=cols)
                w.writeheader()
                w.writerows(rows)
            deleted.append('catalog')
        except Exception:
            pass
    return jsonify({'ok': True, 'filename': fn, 'deleted': deleted, **_eis_exp_table()})


@app.route('/')
def index():
    cases = list_cases()
    #  v3: 상태 패널은 원장에서 렌더한다 (손으로 적은 산문은 원장을 안 따라간다).
    return render_template('index.html', cases=cases, lv=ledger_view.context())

@app.route('/upload', methods=['POST'])
def upload():
    """Upload files for a new case."""
    case_name = request.form.get('case_name', '').strip()
    mode = request.form.get('mode', 'auto')
    type_map = request.form.get('type_map', '')
    ps_ratio = request.form.get('ps_ratio', '').strip()
    scale = request.form.get('scale', '1000')

    case_id = datetime.now().strftime('%y%m%d_%H%M%S') + '_' + str(uuid.uuid4())[:6]
    case_dir = get_case_dir(case_id)

    files = request.files.getlist('files')
    if not files:
        return jsonify({'error': '파일을 선택해주세요.'}), 400

    filenames = []
    for f in files:
        if f.filename:
            safe_name = f.filename.replace('/', '_').replace('\\', '_')
            f.save(os.path.join(case_dir, safe_name))
            filenames.append(safe_name)

    # Detect mode
    if mode == 'auto':
        mode = detect_mode(case_dir)

    # ── type_map ────────────────────────────────────────────────────────────
    # ★★ 2026-09-22 (케이스 260922_092001_0853b1).  옛 판은 standard 모드에서
    #   `f'1:{am_type_name},2:SE'` 로 **SE 를 type 2 에 박아** 있었다.  덤프를 열어
    #   반지름까지 읽어 놓고 type 1 만 보고 AM_P/AM_S 를 정한 뒤, SE 는 확인조차
    #   안 했다 — 정보를 손에 쥐고 버린 것이다.
    #   `ps_sweep` 세대 덱은 `create_box 3` 에 **1:AM_P · 2:AM_S · 3:SE** 라
    #   P:S=10:0 을 올리면 SE(type 3, 원자의 **99.75 %**)가 아무 상에도 안 붙어
    #   `?` 가 되고, 그 상태로 40분을 돌아 마지막 CSV 에서 터졌다.
    #   ⇒ 이제 **덱이 선언한 것을 읽는다**.  덱은 매번 같이 업로드되고 그 안의
    #     `particletemplate/sphere … atom_type N … radius constant ${r_SE}` 가
    #     타입↔상을 글자로 적어 놓았다 — 추정이 아니라 선언이다.
    #   ⚠ 업로드는 **fail-open** 이다 (덱 없이 올릴 수도 있고, 여기서 막으면
    #     올리지도 못한다).  틀린 map 을 실제로 막는 fail-closed 게이트는
    #     `analyze_contacts.py` 에 있다 — 거기서 계산 **전에** 거부한다.
    _tm_resolved, _tm_notes = '', []
    _tm_deck = _tm_dump = None
    for f in sorted(os.listdir(case_dir)):
        if not f.endswith('.liggghts'):
            continue
        if f.startswith('atom'):
            _tm_dump = _tm_dump or os.path.join(case_dir, f)
        elif not f.startswith('contact') and _tm_deck is None:
            _tm_deck = os.path.join(case_dir, f)
    if _tm_deck and _tm_dump:
        try:
            _m, _n, _e = _type_map_resolve.resolve_from_files(_tm_deck, _tm_dump)
            _tm_notes = list(_n) + list(_e)
            if _m and not _e:
                _tm_resolved = _type_map_resolve.format_map(_m)
        except Exception as _exc:                         # noqa: BLE001
            _tm_notes = [f'type_map 자동판독 실패 ({_exc}) — 기존 규칙으로 되돌린다']

    if not type_map:
        if _tm_resolved:
            type_map = _tm_resolved
        elif mode == 'bimodal':
            type_map = '1:AM_P,2:AM_S,3:SE'
        else:
            # 되돌림 경로 — 덱을 못 읽었을 때만.  ⚠ 기존 코퍼스(170여 케이스)의
            # 상 라벨이 이 반지름 규칙에 걸려 있으므로 **그대로** 둔다.
            am_type_name = 'AM_S'  # default: small AM
            for f in sorted(os.listdir(case_dir)):
                if f.startswith('atom') and f.endswith('.liggghts'):
                    with open(os.path.join(case_dir, f)) as fh:
                        in_data = False
                        for line in fh:
                            stripped = line.strip()
                            if stripped.startswith('ITEM: ATOMS'):
                                in_data = True
                                continue
                            if stripped.startswith('ITEM:'):
                                in_data = False
                                continue
                            if in_data:
                                parts = stripped.split()
                                if len(parts) >= 6:
                                    try:
                                        t = int(parts[1])
                                        r = float(parts[5])
                                        if t == 1:
                                            # sim r > AM_P_RADIUS_CUT_SIM → AM_P (6µm), else AM_S (2µm)
                                            #  ⚠ 문턱의 정본은 `type_map_resolve` 다 — 여기에
                                            #    리터럴로 다시 적지 않는다.  이 되돌림 경로에
                                            #    170여 케이스 코퍼스의 상 라벨이 걸려 있어
                                            #    두 곳이 조용히 갈리는 것이 가장 비싸다
                                            #    (selftest ⑩ 이 리터럴 재등장을 거부한다).
                                            am_type_name = (
                                                'AM_P'
                                                if r > _type_map_resolve.AM_P_RADIUS_CUT_SIM
                                                else 'AM_S')
                                            break
                                    except (ValueError, IndexError):
                                        continue
                    break
            type_map = f'1:{am_type_name},2:SE'
            _tm_notes.append('⚠ 덱을 못 읽어 반지름 규칙으로 되돌렸다 — '
                             '세 타입 덱이면 이 값이 틀릴 수 있다')
    elif _tm_resolved and type_map.strip() != _tm_resolved:
        # 사용자가 직접 적은 값이 이긴다 (의도적인 경우가 있다).  다만 **기록**한다.
        _tm_notes.append(f'⚠ 사용자 입력 type_map({type_map.strip()}) 과 '
                         f'덱 판독({_tm_resolved})이 다르다')

    meta = {
        'name': case_name or case_id,
        'created': datetime.now().isoformat(),
        'mode': mode,
        'type_map': type_map,
        'type_map_resolved': _tm_resolved,      # 덱에서 읽은 값 (빈 문자열 = 판독 실패)
        'type_map_notes': _tm_notes,            # 판독 근거·경고 (UI/로그에서 볼 수 있게)
        'ps_ratio': ps_ratio,
        'scale': int(scale),
        'files': filenames,
        'status': 'uploaded'
    }
    _ps.atomic_write_json(os.path.join(case_dir, 'meta.json'), meta)   # ★ 09-26 원자적 쓰기 (temp→fsync→replace) — 제자리 'w' 는 크래시 때 반쪽을 남겼다

    # Sync to Supabase
    storage_sync.sync_dir_to_remote(case_dir, f'uploads/{case_id}')

    # Return the auto-DETECTED mode so the frontend can show a confirm popup
    # ("감지된 모드: bimodal — 실행할까요?") and the user can verify bimodal vs standard
    # BEFORE committing the run.  The run itself is then triggered by that confirm → POST
    # /analyze, which spawns the SAME daemon-thread full pipeline (incl. Step 7 Stage E) that
    # survives a tab close — so a confirmed run still always gets Stage E.  If the user cancels,
    # the case stays status 'uploaded' (대기중) and is runnable any time from the list via
    # '재분석' (so a cancel is recoverable, not a silently-broken case).
    return jsonify({'case_id': case_id, 'mode': mode, 'files': filenames, 'analyzing': False})

@app.route('/analyze/<case_id>', methods=['POST'])
def analyze(case_id):
    """Run analysis pipeline for a case (background thread).

    Optional POST body: {"force_network": true}  → skips the network-result
    backup/restore dance, forcing the solver to re-run from scratch. Use
    this after solver algorithm updates (e.g. 3-stage CG/ILU/spsolve fix)
    to refresh σ values on cases that were previously solved with the old
    code path.
    """
    case_dir = get_case_dir(case_id)
    meta_file = os.path.join(case_dir, 'meta.json')
    if not os.path.exists(meta_file):
        return jsonify({'error': '케이스를 찾을 수 없습니다.'}), 404

    _req = request.get_json(silent=True) or {}
    force_network = bool(_req.get('force_network', False))

    with open(meta_file) as f:
        meta = json.load(f)

    meta['status'] = 'running'
    _ps.atomic_write_json(meta_file, meta)   # ★ 09-26 원자적 쓰기 (temp→fsync→replace) — 제자리 'w' 는 크래시 때 반쪽을 남겼다
    # (σ 키 목록은 모듈 전역 _NET_MERGE_KEYS 로 승격 — run_pipeline 이 지역 사본을
    #  참조해 NameError 로 죽던 문제를 없앤다)

    def _run():
        results_dir = get_results_dir(case_id)
        net_json_path = os.path.join(results_dir, 'network_conductivity.json')

        # ── Step 1: network 산출물 스냅샷 (results_dir 를 지우기 **전에**) ──
        #   ★ 코드리뷰 F-02.  옛 흐름은 백업 → 삭제 → run_pipeline(solver 재실행 + 그
        #     결과로 Stage E) → 옛 network 복원 순서라, full_metrics 안에서 baseline 은
        #     옛 세대, Stage E 는 방금 푼 새 세대가 됐다.  이제 스냅샷을 run_pipeline
        #     **안으로** 넘겨 Stage E 보다 먼저 복원시키고, solver 는 아예 호출하지 않는다.
        preserve = not force_network
        #  ★ 10-05 RGLR2-02 · Codex Q2 ③ — 확정되지 않은 망 세대 (full_metrics ↔ 도장 불일치 · 되돌림 실패 · 중단된 게시 흔적) 는 보존 (재사용)
        #    하지 않는다 (`snapshot_network` 가 거부) → solver 재실행 · 왜를 meta 에 남긴다 (results_dir 는 아래에서 지워지므로 meta 에).
        _gen_refused = _ps.network_generation_problem(results_dir) if (preserve and os.path.isdir(results_dir)) else ''
        snap = _ps.snapshot_network(results_dir, case_id) if preserve else None
        if _gen_refused:
            meta['network_preserve_refused'] = _gen_refused
        else:
            meta.pop('network_preserve_refused', None)          # 보통 재분석 = meta 그대로 (옛 사유가 남지 않게)
        if force_network:
            print(f"  [Reanalysis] force_network=True → solver 재실행 ({case_id})")
        elif snap:
            print(f"  [Reanalysis] network 보존 — solver 호출 안 함 ({case_id})")
        elif _gen_refused:
            print(f"  [Reanalysis] network 보존 거부 — 확정되지 않은 세대 ({_gen_refused[:200]}) → solver 재실행 ({case_id})")
        else:
            print(f"  [Reanalysis] 보존할 network 없음 → solver 최초 실행 ({case_id})")

        # ── Step 2: results_dir 재생성 후 파이프라인 (network/Stage E 포함) ──
        if os.path.exists(results_dir):
            shutil.rmtree(results_dir)
        os.makedirs(results_dir, exist_ok=True)
        try:
            result = run_pipeline(case_id, meta['mode'], meta['type_map'],
                                  meta.get('scale', 1000),
                                  preserve_network=bool(preserve and snap),
                                  network_snapshot=snap)
        finally:
            if snap:
                shutil.rmtree(snap, ignore_errors=True)

        # ── Step 3: 단계 계약대로 상태 확정 (F-05) ──
        #   옛 코드는 parse 만 검사하고 나머지는 무조건 success → full_metrics 가 없어도
        #   케이스가 'done' 이 됐다.  이제 failed/partial/done 을 구분해 올린다.
        status = result.get('status') or ('done' if result.get('success') else 'failed')
        meta['pipeline_status'] = status
        meta['failed_stages'] = result.get('failed_stages', [])
        meta['analysis_log'] = result.get('log', [])
        meta['network_run_id'] = result.get('network_run_id')
        meta['network_solver_status'] = (
            'preserved' if (preserve and snap)
            else ('success' if os.path.exists(net_json_path) else 'not_run'))
        meta['status'] = 'error' if status == 'failed' else 'done'
        _ps.atomic_write_json(meta_file, meta)
        if status == 'failed':
            print(f"  [Reanalysis] FAILED — 필수 단계 실패: {meta['failed_stages']} ({case_id})")
            return
        if status == 'partial':
            print(f"  [Reanalysis] PARTIAL — 선택 단계 실패: {meta['failed_stages']} ({case_id})")

        generate_report(case_id, meta.get('name', ''))

        # ── Step 4: publish 후 점검 ──
        #   network/Stage E 자체는 run_pipeline 이 이미 **한 번만** 수행했다.  옛 Step 6-7 은
        #   같은 일을 두 번째로 하던 중복이라 제거했다 (리뷰 F-17) — 남기면 force 경로에서
        #   solver 가 두 번 돈다.
        scripts_dir = app.config['SCRIPTS_FOLDER']
        try:
            fm_path = os.path.join(results_dir, 'full_metrics.json')
            if os.path.exists(fm_path):
                with open(fm_path) as _f:
                    _fm = json.load(_f)
                # ⚠ 0 과 missing 을 구별한다 (리뷰 F-12): 물리적 0 은 유효한 값이다.
                _missing = [_k.replace('_stage_e_physics', '').replace('_full_mScm', '')
                            for _k in ('sigma_full_mScm_stage_e_physics',
                                       'electronic_sigma_full_mScm_stage_e_physics',
                                       'thermal_sigma_full_mScm_stage_e_physics')
                            if _fm.get(_k) is None]
                if _missing:
                    print(f"  [Stage E] ⚠ Physics-mode incomplete: {', '.join(_missing)} "
                          f"({case_id}) — 케이스 목록에 'Stage-E-P ⚠' 배지")
                # baseline 과 Stage E 의 세대가 어긋나면 즉시 드러나게 한다 (F-02 회귀 감시).
                if (_fm.get('network_run_id')
                        and _fm.get('stage_e_parent_network_run_id') != _fm.get('network_run_id')):
                    print(f"  [Stage E] ★ provenance 불일치 — baseline "
                          f"{_fm.get('network_run_id')} vs Stage E parent "
                          f"{_fm.get('stage_e_parent_network_run_id')} ({case_id})")
        except Exception as _exc:
            print(f"  [Stage E post-check] {type(_exc).__name__}: {_exc}")
        try:
            subprocess.run([sys.executable,
                            os.path.join(scripts_dir, 'backfill_validation_flags.py'),
                            os.path.basename(results_dir)],
                           capture_output=True, text=True, timeout=None)
        except Exception:
            pass   # backfill is best-effort

        # Sync results + updated meta to Supabase
        storage_sync.sync_dir_to_remote(case_dir, f'uploads/{case_id}')
        storage_sync.sync_dir_to_remote(results_dir, f'results/{case_id}')

    def _run_guarded():
        # Without this, any uncaught error in _run kills the daemon thread and
        # the case is stuck at status 'running' forever (no failure shown).
        try:
            _run()
        except Exception as _e:
            import traceback
            traceback.print_exc()
            try:
                meta['status'] = 'error'
                meta['analysis_error'] = f'{type(_e).__name__}: {_e}'
                _ps.atomic_write_json(meta_file, meta)   # ★ 09-26 원자적 쓰기 (temp→fsync→replace) — 제자리 'w' 는 크래시 때 반쪽을 남겼다
            except Exception:
                pass

    thread = threading.Thread(target=_run_guarded, daemon=True)
    thread.start()
    return jsonify({'success': True, 'status': 'running'})

@app.route('/analyze-status/<case_id>')
def analyze_status(case_id):
    """Check if analysis is still running."""
    meta_file = os.path.join(get_case_dir(case_id), 'meta.json')
    if os.path.exists(meta_file):
        with open(meta_file) as f:
            meta = json.load(f)
        # ★ CB-08: partial 은 meta 에만 있고 API 로는 안 나가서 UI 가 done 과 구별하지
        #   못했다.  실패 단계까지 함께 돌려준다.
        return jsonify({'status': meta.get('status', 'unknown'),
                        'pipeline_status': meta.get('pipeline_status'),
                        'failed_stages': meta.get('failed_stages', []),
                        'network_run_id': meta.get('network_run_id')})
    return jsonify({'status': 'unknown'})

@app.route('/analyze-cancel/<case_id>', methods=['POST'])
def analyze_cancel(case_id):
    """⚠ 계산을 **멈추지 않는다** — 목록 표시만 '대기 해제' 로 바꾼다 (코드리뷰 F-04).

    실제로는 daemon thread 와 subprocess 가 계속 돌고, 끝나면 결과·meta 를 덮어쓰고
    Supabase 까지 동기화한다.  옛 구현은 status 를 'done' 으로 적어 **완료처럼** 보이게
    했는데, 그러면 (a) 사용자가 취소됐다고 믿고 (b) 나중에 진짜 결과가 덮어써서 상태가
    말없이 바뀐다.  진짜 취소를 넣기 전까지는 이름과 상태를 사실에 맞춘다:
    별도 상태 'detached' 로 적어 '아직 돌고 있다' 를 숨기지 않는다.
    (진짜 취소 = job ID + subprocess process group + 단계 경계마다 cancel 플래그 확인.)
    """
    meta_file = os.path.join(get_case_dir(case_id), 'meta.json')
    if os.path.exists(meta_file):
        with open(meta_file) as f:
            meta = json.load(f)
        if meta.get('status') in ('running', 'network_solving'):
            meta['status'] = 'detached'
            meta['detached_note'] = ('사용자가 대기를 해제했습니다. 계산은 백그라운드에서 '
                                     '계속되며, 끝나면 결과가 갱신됩니다.')
            _ps.atomic_write_json(meta_file, meta)
            return jsonify({'ok': True, 'stopped': False, 'status': 'detached',
                            'msg': '대기만 해제했습니다 — 계산은 계속 진행됩니다.'})
    return jsonify({'ok': False, 'msg': 'Not running'})

@app.route('/retry-network/<case_id>', methods=['POST'])
def retry_network(case_id):
    """Manually retry network solver for a case."""
    case_dir = get_case_dir(case_id)
    results_dir = get_results_dir(case_id)
    meta_file = os.path.join(case_dir, 'meta.json')

    if not os.path.exists(meta_file):
        return jsonify({'success': False, 'error': 'Case not found'})

    with open(meta_file) as f:
        meta = json.load(f)

    def _run_net():
        """★ CB-04: solver/merge/Stage E 를 자체 구현하지 않고 **중앙 helper** 를 쓴다.

        옛 구현의 문제 (Codex 교차검증):
          • 새 `network_run_id` 를 만들지 않고 도장도 찍지 않았다 → 옛
            `network_run_id == stage_e_parent_network_run_id` 가 그대로 남아 **같아
            보이지만 실제 baseline/Stage E 는 새 세대**인 stale-equality false-green.
          • merge key 목록을 **따로 하드코딩**해 `_NET_MERGE_KEYS` 와 drift.
          • Stage E 에 rc/기대 산출물 계약이 없었다.
          • `failed` / `no_output` / `error` 여도 마지막에 `status='done'` 을 적었다.
        """
        results_dir = get_results_dir(case_id)
        atoms_csv = os.path.join(results_dir, 'atoms.csv')
        contacts_csv = os.path.join(results_dir, 'contacts.csv')
        meta['status'] = 'network_solving'
        meta['network_solver_status'] = 'running'
        _ps.atomic_write_json(meta_file, meta)

        if not (os.path.exists(atoms_csv) and os.path.exists(contacts_csv)):
            meta['network_solver_status'] = 'no_input'
            meta['network_solver_error'] = (f'atoms.csv={os.path.exists(atoms_csv)}, '
                                            f'contacts.csv={os.path.exists(contacts_csv)}')
            meta['status'] = 'error'
            _ps.atomic_write_json(meta_file, meta)
            print(f"  [Network Retry] 입력 없음 — solver 미실행 ({case_id})")
            return

        _log = []
        stages, run_id = _network_and_stage_e(
            results_dir, app.config['SCRIPTS_FOLDER'], atoms_csv, contacts_csv,
            _type_map_resolve.map_str_from_meta(meta, 'retry/_network_and_stage_e', _log)[0],
            meta.get('scale', 1000), _log,
            preserve_network=False)
        status, failed = _ps.summarize(stages)

        # AM-AM 접촉역학 backfill (retry 고유 — helper 뒤에 얹는다)
        try:
            sys.path.insert(0, app.config['SCRIPTS_FOLDER'])
            from backfill_am_metrics import calc_am_am_paths, calc_am_am_stats
            fm = os.path.join(results_dir, 'full_metrics.json')
            if os.path.exists(fm):
                with open(fm) as _f:
                    met_data = json.load(_f)
                for _fn, _tag in ((calc_am_am_stats, 'CN'), (calc_am_am_paths, 'Gd')):
                    try:
                        st = _fn(atoms_csv, contacts_csv,
                                 _type_map_resolve.map_str_from_meta(meta, 'retry/AM-AM backfill')[0],
                                 scale=meta.get('scale', 1000))
                        if st:
                            met_data.update(st)
                    except Exception as _be:                       # noqa: BLE001
                        print(f"  [AM-AM] {_tag} backfill 실패 (retry): {_be}")
                _ps.atomic_write_json(fm, met_data)
        except Exception as _be:                                   # noqa: BLE001
            print(f"  [AM-AM] backfill 건너뜀 (retry): {_be}")

        meta['network_run_id'] = run_id
        meta['pipeline_status'] = status
        meta['failed_stages'] = [s.get('step') for s in failed]
        meta['network_solver_status'] = 'failed' if status == 'failed' else 'success'
        meta['status'] = 'error' if status == 'failed' else 'done'   # ★ 실패를 done 으로 올리지 않는다
        meta['analysis_log'] = _log
        _ps.atomic_write_json(meta_file, meta)
        print(f"  [Network Retry] {status}  run_id={run_id}  ({case_id})")
    def _run_net_guarded():
        # ★ CB-03: lock 미획득(LockUnavailable)은 solver 를 돌리지 않았다는 뜻이므로
        #   'done' 이 아니라 상태로 남긴다.  다른 예외도 스레드가 조용히 죽어 케이스가
        #   'network_solving' 에 영원히 머무는 것을 막는다.
        try:
            _run_net()
        except _ps.LockUnavailable as _lk_e:
            meta['network_solver_status'] = 'lock_unavailable'
            meta['network_solver_error'] = str(_lk_e)
            meta['status'] = 'error'
            _ps.atomic_write_json(meta_file, meta)
            print(f"  [Network Retry] LOCK 미획득 — solver 미실행 ({case_id})")
        except Exception as _e:                                   # noqa: BLE001
            import traceback
            traceback.print_exc()
            meta['network_solver_status'] = 'error'
            meta['network_solver_error'] = f'{type(_e).__name__}: {_e}'
            meta['status'] = 'error'
            try:
                _ps.atomic_write_json(meta_file, meta)
            except Exception:
                pass

    thread = threading.Thread(target=_run_net_guarded, daemon=True)
    thread.start()
    return jsonify({'success': True, 'status': 'started'})


# Global status for the batch rerun (single-shot, last run wins).
_batch_status = {'running': False, 'total': 0, 'done': 0,
                 'current': '', 'failures': [], 'started_at': '', 'finished_at': ''}


def _find_all_cases():
    """Return list of cases to batch-process.
    Scans webapp/results/<cid>/ (meta.json lives in webapp/uploads/<cid>/ —
    NOT in the same dir as atoms.csv) and webapp/archive/<category>/<name>/
    (meta.json lives next to atoms.csv). Deduplicated by cid.
    """
    out = []
    seen = set()
    uploads_root = Path(app.config['UPLOAD_FOLDER'])
    rroot = Path(app.config['RESULTS_FOLDER'])
    if rroot.is_dir():
        for d in sorted(rroot.iterdir()):
            if not d.is_dir() or d.name in ('reports', 'group_plots'): continue
            atoms = d / 'atoms.csv'; contacts = d / 'contacts.csv'
            # meta.json is in uploads/<cid>/, not in results/<cid>/
            meta = uploads_root / d.name / 'meta.json'
            if atoms.exists() and contacts.exists() and meta.exists():
                if d.name in seen: continue
                seen.add(d.name)
                out.append(dict(cid=d.name, case_dir=str(d), results_dir=str(d),
                                meta=str(meta), atoms=str(atoms),
                                contacts=str(contacts), source='results'))
    aroot = Path(app.config['ARCHIVE_FOLDER'])
    if aroot.is_dir():
        for meta in sorted(aroot.rglob('meta.json')):
            d = meta.parent
            atoms = d / 'atoms.csv'; contacts = d / 'contacts.csv'
            if atoms.exists() and contacts.exists():
                if d.name in seen: continue
                seen.add(d.name)
                out.append(dict(cid=d.name, case_dir=str(d), results_dir=str(d),
                                meta=str(meta), atoms=str(atoms),
                                contacts=str(contacts), source='archive'))
    return out


@app.route('/batch-rerun-physics', methods=['POST'])
def batch_rerun_physics():
    """Re-run analyze_contacts + Network solver (both modes) + Physics coverage
    on every case. Keeps raw CSVs, only refreshes the analysis summary and
    solver output. Use after changing the solver resistance model."""
    global _batch_status
    if _batch_status['running']:
        return jsonify({'success': False, 'error': 'Already running', 'status': _batch_status})

    cases = _find_all_cases()
    _batch_status = {'running': True, 'total': len(cases), 'done': 0,
                     'current': '', 'failures': [],
                     'started_at': datetime.now().strftime('%H:%M:%S'),
                     'finished_at': ''}

    def _worker():
        scripts = app.config['SCRIPTS_FOLDER']
        # Dedup (archive + results may both point to the same case).
        seen = set(); dedup_cases = []
        for c in cases:
            key = c['cid']
            if key in seen: continue
            seen.add(key); dedup_cases.append(c)
        _batch_status['total'] = len(dedup_cases)

        for c in dedup_cases:
            _batch_status['current'] = c['cid']
            try:
                with open(c['meta']) as f: meta = json.load(f)
                mode = meta.get('mode', 'standard')
                type_map = _type_map_resolve.map_str_from_meta(meta, 'batch reanalyze')[0]
                scale = str(meta.get('scale', 1000))

                # Order matters. analyze_contacts writes full_metrics.json from
                # scratch, so it MUST run before the physics merge — otherwise
                # it wipes the physics_resistance_model / sigma_full_mScm_physics
                # keys we just wrote. The τ_Lap_eff-style σ-derived metrics are
                # rendered on-the-fly by the webapp template using the stored
                # σ values, so order here does not affect that.

                # 1) 구조 요약 (contact) — **required 계약**.
                #    ★ R3 (Codex 2회차): 앞선 커밋 메시지는 "batch contact 도 required
                #      run_stage 로 감쌌다" 고 적었지만 **실제 diff 에는 없었다** — 교체 범위가
                #      이 호출 앞에서 끝났고 나는 의도만 적고 확인하지 않았다.  Codex 가 diff 로
                #      잡았다.  이제 실제로 계약 안에 넣고, 실패하면 아래 단계를 건너뛴다.
                _bstages = []
                ac_script = 'analyze_contacts_bimodal.py' if mode == 'bimodal' else 'analyze_contacts.py'
                _cst = _ps.run_stage(
                    'Contact Analysis (batch)',
                    [sys.executable, os.path.join(scripts, ac_script),
                     c['atoms'], c['contacts'], '-o', c['results_dir'],
                     '-t', type_map, '-s', scale],
                    required=True, results_dir=c['results_dir'],
                    # ★ RR3-04 (Codex): batch 는 results 를 지우지 않으므로 **존재 확인만**
                    #   하면 옛 산출물이 새 성공으로 재도장된다.
                    # ★ RC7-03 (Codex 7회차): 그 자리를 fresh 지문으로 막아 뒀고, 주석에
                    #   "최종형은 빈 candidate 에서만 실행" 이라고 **적어만 두고 배선하지
                    #   않았다**.  이제 실제로 그 최종형(causal stash)으로 바꾼다 —
                    #   metadata-only touch 로는 더 이상 통과할 수 없다.
                    causal=True,
                    expects=('full_metrics.json', 'atoms_analyzed.csv',
                             'contacts_analyzed.csv', 'network_summary.csv'))
                _bstages.append(_cst)
                if not _cst.ok:
                    _batch_status['failures'].append(
                        {'cid': c['cid'], 'err': 'contact 실패 — network/StageE 미실행: '
                         + (_cst.get('stderr') or '')[-160:]})
                    continue                      # ★ finally 에서 done 은 증가한다

                # 2) Coverage (optional) — read-modify-write, 아래 helper 가 그 위에 얹는다.
                #    main pipeline 과 같은 contact → coverage → helper 순서 (F-17 drift 제거).
                _bstages.append(_ps.run_stage(
                    'Coverage Physics vs Hertzian (batch)',
                    [sys.executable, os.path.join(scripts, 'coverage_physics_vs_hertzian.py'),
                     '--case-dir', c['case_dir']],
                    required=False, results_dir=c['results_dir']))
                # 3) Network solver + merge + Stage E — **중앙 helper**.
                #    옛 구현은 새 run_id 를 만들지 않고 도장도 찍지 않아, 옛
                #    network_run_id == stage_e_parent_network_run_id 가 그대로 남아
                #    **같아 보이지만 실제로는 새 세대**인 stale-equality false-green 이 됐다.
                #    merge key 도 따로 하드코딩돼 _NET_MERGE_KEYS 와 drift 했다.
                _blog = []
                _ns, _brun_id = _network_and_stage_e(
                    c['results_dir'], scripts, c['atoms'], c['contacts'],
                    type_map, scale, _blog, preserve_network=False)
                _bstages.extend(_ns)          # ★ 덮어쓰면 contact/coverage 단계가 버려진다
                _bstatus, _bfailed = _ps.summarize(_bstages)
                if _bstatus == 'failed':
                    # ★ 옛 batch 는 subprocess rc 를 아예 안 봐서 실패도 done 으로 셌다.
                    _batch_status['failures'].append(
                        {'cid': c['cid'], 'err': 'network/StageE 실패: '
                         + ', '.join(s.get('step', '?') for s in _bfailed)})
            except Exception as e:
                _batch_status['failures'].append({'cid': c['cid'], 'err': str(e)[:200]})
            finally:
                # ★ RV-03: done 증가는 **케이스마다 정확히 한 번**.  내 CB-04 교체가
                #   성공 경로의 증가를 삼켜 성공/실패 모두 done=0 이 됐다 (Codex 재현).
                _batch_status['done'] += 1
        _batch_status['running'] = False
        _batch_status['current'] = '(done)'
        _batch_status['finished_at'] = datetime.now().strftime('%H:%M:%S')

    threading.Thread(target=_worker, daemon=True).start()
    return jsonify({'success': True, 'count': len(cases)})


@app.route('/batch-rerun-physics/status')
def batch_rerun_physics_status():
    # Scan all cases (already deduplicated by _find_all_cases) and summarise
    # which resistance model each one is on. Four states:
    #   'maxwell+film' → new formula applied (PHYS ✓)
    #   'maxwell'      → legacy Physics σ, needs rerun (PHYS legacy)
    #   'no_physics'   → Physics solver never ran (PHYS ∅)
    #   'no_metrics'   → full_metrics.json missing (shouldn't normally happen)
    counts = {'upgraded': 0, 'maxwell': 0,
              'no_physics': 0, 'no_metrics': 0}
    latest_at = ''
    for c in _find_all_cases():
        fm_path = os.path.join(c['results_dir'], 'full_metrics.json')
        if not os.path.exists(fm_path):
            counts['no_metrics'] += 1; continue
        try:
            with open(fm_path) as f: m = json.load(f)
        except Exception:
            counts['no_metrics'] += 1; continue
        model = m.get('physics_resistance_model')
        if model in ('mikic', 'maxwell+film'):
            counts['upgraded'] += 1
        elif model == 'maxwell' or 'sigma_full_mScm_physics' in m:
            counts['maxwell'] += 1
        else:
            counts['no_physics'] += 1
        ts = m.get('physics_solver_at', '')
        if ts > latest_at: latest_at = ts
    status = dict(_batch_status)
    status['model_counts'] = counts
    status['latest_physics_at'] = latest_at
    status['total_cases'] = sum(counts.values())
    return jsonify(status)


def _resolve_results_dir(case_id, meta):
    """Return (results_dir, archive_rel) for a case, falling back to archive/
    when the live results/ dir has no analysis data (archive-migrated cases).
    archive_rel is the path under archive/ when the fallback triggered, else
    None.  Shared by the /single dashboard and the report exporter so both see
    the same data."""
    results_dir = get_results_dir(case_id)

    def _has_data(d):
        if not os.path.isdir(d):
            return False
        return any(os.path.exists(os.path.join(d, n + '.csv'))
                   for n in ['atom_statistics', 'contact_summary',
                             'coordination_summary', 'network_summary']) \
            or os.path.exists(os.path.join(d, 'full_metrics.json'))

    if _has_data(results_dir):
        return results_dir, None

    archive_root = app.config.get('ARCHIVE_FOLDER')
    if archive_root and os.path.isdir(archive_root):
        search_keys = [case_id]
        for k in ('name', 'label', 'case_id', 'case_name'):
            v = meta.get(k)
            if isinstance(v, str) and v and v not in search_keys:
                search_keys.append(v)
        for dirpath, dirs, _ in os.walk(archive_root):
            for key in search_keys:
                if key in dirs:
                    candidate = os.path.join(dirpath, key)
                    if _has_data(candidate):
                        return candidate, os.path.relpath(candidate, archive_root)
    return results_dir, None


def _load_case_tables(results_dir, meta):
    """Assemble the analysis-summary `tables` dict (입자 정보 / 접촉 요약 /
    배위수 / 네트워크 지표 / 취성 파괴 / 종합 등급) plus the metrics and
    input_params exactly as the single-case dashboard does, so MD/PDF reports
    stay byte-for-byte consistent with what the page shows.

    Returns (tables, metrics, input_params)."""
    import pandas as pd
    tables = {}
    for csv_name in ['atom_statistics', 'contact_summary', 'coordination_summary',
                     'network_summary']:
        csv_path = os.path.join(results_dir, f'{csv_name}.csv')
        if os.path.exists(csv_path):
            df = pd.read_csv(csv_path)
            tables[csv_name] = {
                'columns': df.columns.tolist(),
                'data': df.values.tolist(),
            }

    metrics = {}
    metrics_path = os.path.join(results_dir, 'full_metrics.json')
    if os.path.exists(metrics_path):
        with open(metrics_path) as f:
            metrics = json.load(f)
    #  ★ 10-05 RGLR2-02 — 망 활성 세대가 확정되지 않았으면 망 · Stage E 값을 None 으로 (화면 · MD/PDF 보고서 · 등급 · τ 인계 행이 같은 metrics 를 본다)
    _network_generation_guard(results_dir, metrics)

    # Patch placeholder '-' values from full_metrics.json BEFORE 4-col transform
    # (transform copies row[1] → row[2], so placeholders must be filled first)
    if 'network_summary' in tables and metrics:
        n_large = metrics.get('n_large_components')
        if n_large is not None:
            for row in tables['network_summary']['data']:
                if str(row[0]) == 'SE Cluster 수' and '≥10' not in str(row[1]):
                    row[1] = f"{n_large}(≥10) / {row[1]}"
        placeholder_map = {
            'GB Density(hops/μm)': 'gb_density_mean',
            'Path Hop Area mean(μm²)': 'path_hop_area_mean',
            'Path Bottleneck(μm²)': 'path_hop_area_min_mean',
            'Path Conductance(μm²)': 'path_conductance_mean',
        }
        for row in tables['network_summary']['data']:
            label = str(row[0])
            if label in placeholder_map and str(row[1]).strip() in ('-', ''):
                val = metrics.get(placeholder_map[label])
                if val is not None:
                    row[1] = val
            if label == 'σ_eff/σ_bulk':
                row[0] = 'σ_brug/σ_grain (Bruggeman)'
        has_brug_abs = any(str(row[0]) == 'σ_Bruggeman (mS/cm)'
                           for row in tables['network_summary']['data'])
        if not has_brug_abs and metrics.get('sigma_ratio'):
            sigma_brug_mScm = round(_sigma_grain_mS_cm(metrics) * metrics['sigma_ratio'], 4)
            for idx, row in enumerate(tables['network_summary']['data']):
                if 'σ_brug/σ_grain' in str(row[0]):
                    tables['network_summary']['data'].insert(
                        idx, ['σ_Bruggeman (mS/cm)', sigma_brug_mScm])
                    break

    # input_params (RVE area for inject_cell_asr_rows)
    input_params = {}
    params_path = os.path.join(results_dir, 'input_params.json')
    if os.path.exists(params_path):
        with open(params_path) as f:
            input_params = json.load(f)
    if input_params and 'scale' not in input_params:
        input_params['scale'] = meta.get('scale', 1)

    # ── PHANTOM σ_e/κ STRIP (2026-05-28, v4 unified) ────────────────────
    # If the Stage E pipeline used Bruggeman fallback (stage_e_source flags
    # 'fallback_weighted_factor'), the value was ALSO written to the raw
    # network-solver key — causing the Network Solver row to display the
    # phantom value (e.g. 1mAh_100_2 showed σ_e Physics=61.83 even though
    # raw electronic was suppressed elsewhere).  Strip those raw keys here
    # so EVERY downstream renderer (Network Solver row, ASR row, Stage E
    # row, predictor) sees '—' consistently.
    _src_fb_global = metrics.get('stage_e_source') or {}
    _phantom_strip_pairs = [
        ('electronic_sigma_full_mScm',          'sigma_e'),
        ('electronic_sigma_full_mScm_physics',  'sigma_e_physics'),
        ('thermal_sigma_full_mScm',             'sigma_thermal'),
        ('thermal_sigma_full_mScm_physics',     'sigma_thermal_physics'),
    ]
    for _rk, _sk in _phantom_strip_pairs:
        if _src_fb_global.get(_sk) == 'fallback_weighted_factor':
            metrics[_rk] = None
            # also strip Stage E + Stage E physics counterparts
            metrics[_rk + '_stage_e'] = None
            metrics[_rk + '_stage_e_physics'] = None

    # 4-column transform + section injection — shared helpers
    #  ★ 10-04 τ 결정 16 ② — 이온 인계 상태 (tau_flux) 를 표시용으로 붙인다 (계산은 도우미 · 값 행은 그대로).
    metrics['_ion_handover'] = _ion_handover(results_dir, metrics)
    #  ★ 10-06 밤 (G2RR-01 웹앱 짝 · J20-l) — 도장 ↔ 레코드 세대 대조 (인계 P4 와 같은 함수 · 어긋날 때만 세대 행에 표지)
    metrics['_ion_handover_stamp'] = _ion_handover_stamp(results_dir, metrics['_ion_handover'])
    #  ★ 10-05 RGL-04 웹앱 짝 — 활성 세대 · 최근 시도 (승격 전 검사에 실패한 후보는 활성이 아니다 — 최근 시도에만 남는다).
    metrics['_network_generation'] = _network_generation(results_dir)
    transform_network_summary_4col(tables, metrics, meta)
    inject_tier1_patch_rows(tables, metrics)
    inject_stage_e_rows(tables, metrics)
    inject_cell_asr_rows(tables, metrics, input_params)
    normalize_network_summary_layout(tables, metrics)
    apply_paper_labels(tables)
    inject_dual_porosity_rows(tables, metrics)
    inject_physics_union_coverage_rows(tables, metrics)      # ⑥ 합집합 cap 피복 (C2-⑥ · LHS-25) — Physics 열 · legacy 줄
    inject_physics_v2_rows(tables, metrics)
    # ── Phantom σ_e / κ suppression (v7 — unconditional, AFTER label rename) ──
    # v6 placed inside normalize's Hertz+Phys merge if-block, which doesn't
    # run for already-merged cases.  Now called from the route handler so
    # it runs for EVERY case, scanning the FINAL paper-labeled rows.
    if 'network_summary' in tables:
        _suppress_phantom_sigma_rows(tables['network_summary'].get('data', []),
                                     metrics)

    fracture_tbl = build_fracture_summary_table(metrics)
    if fracture_tbl is not None:
        tables['fracture_summary'] = fracture_tbl

    overall_tbl = build_overall_grade_table(metrics, results_dir)
    if overall_tbl is not None:
        tables['overall_grade'] = overall_tbl

    return tables, metrics, input_params


def _load_mpm_metrics(results_dir):
    """MPM result params for the case page — the compact mpm_metrics.json written on
    upload (falls back to extracting from the heavier mpm_payload.json).  {} when no
    MPM result has been uploaded yet (→ the result table stays hidden).

    MERGE (2026-07-14): the sim이 뽑는 mpm_metrics.json에는 payload 파생 지표(step3 σ/
    pore-τ/additive_dispersion 등)가 없어서, 그 파일이 small을 덮으면 카드의 STEP3 행들이
    사라진다 → small에 payload 지표가 빠져 있으면 payload에서 1회 추출해 병합하고 small을
    다시 써서 캐시 (다음 뷰부터는 무거운 payload를 안 읽음).  sim 키가 우선(authoritative)."""
    small = os.path.join(results_dir, 'mpm_metrics.json')
    out = {}
    if os.path.exists(small):
        try:
            with open(small) as f:
                out = json.load(f) or {}
        except Exception:
            out = {}
    # payload-파생 지표 마커 = se_surface_tris (payload mpm_metrics에는 항상 있고 sim 파일엔 없음)
    if 'se_surface_tris' not in out:
        payload = os.path.join(results_dir, 'mpm_payload.json')
        if os.path.exists(payload):
            try:
                with open(payload) as f:
                    pm = (json.load(f) or {}).get('mpm_metrics', {}) or {}
                if pm:
                    pm.update(out)                          # sim(small) 키가 payload 키를 덮음
                    out = pm
                    try:
                        with open(small, 'w') as f:
                            json.dump(out, f)               # 병합 캐시 — 재스캔 방지
                    except Exception:
                        pass
            except Exception:
                pass
    return out


@app.route('/single/<case_id>')
def single(case_id):
    """View single case results.
    Falls back to archive/<folder>/<case_id>/ if results/ is empty (archive-migrated cases)."""
    case_dir = get_case_dir(case_id)
    results_dir = get_results_dir(case_id)
    meta_file = os.path.join(case_dir, 'meta.json')

    if not os.path.exists(meta_file):
        return redirect(url_for('index'))

    with open(meta_file) as f:
        meta = json.load(f)
    meta['id'] = case_id

    # ── Archive fallback: if results/ is empty, find case in archive/ ──
    results_dir, archive_path = _resolve_results_dir(case_id, meta)

    # Collect figures
    figures = []
    figures_dir = os.path.join(results_dir, 'figures')
    if os.path.isdir(figures_dir):
        for png in sorted(globmod.glob(os.path.join(figures_dir, '*.png'))):
            figures.append(os.path.basename(png))

    # Load report
    report = ''
    report_path = os.path.join(results_dir, 'report.md')
    if os.path.exists(report_path):
        with open(report_path) as f:
            report = f.read()

    # Summary tables + metrics + input_params (shared with the report exporter)
    tables, metrics, input_params = _load_case_tables(results_dir, meta)

    return render_template('single.html', case=meta, figures=figures,
                         report=report, tables=tables, metrics=metrics,
                         input_params=input_params, archive_path=archive_path,
                         mpm_metrics=_load_mpm_metrics(results_dir),
                         trust_card=_build_trust_card(metrics),
                         lv=_page_lv('single'))

# ── 그룹 비교 표 (/group) — 열 정의 · 최고값 강조 (웹앱 ②-b · LHS-24 (e) · J20-l) ──────────────
# (label, unit, key, category).  카테고리 순서는 σ_ionic/σ_e 생산 폼의 입력 순서를 따른다:
#   조성 → 구조 → SE 계면 (이온) → AM 계면 (전자, Stage 15) → 전송 (Stage E, 세 채널) → 접촉역학 → 응력.
#   전송 칸은 Stage E 값 (phantom 거름) — 생산 적합의 타깃.
def _group_union_coverage_cells(metrics):
    """⑥ 합집합 cap 피복의 그룹 표 칸 (C2-⑥ · J20-l) — mono 케이스 (상 이름 AM) 의 `coverage_AM_mean_physics_union` 을 P:S 로 P 또는 S 열에
    (Hertz 'Coverage P/S' 와 같은 규칙 · 상별 키가 이미 있으면 그대로) · 빈칸 침대 (status 'blank: …') 의 값 칸 = '— (빈칸)' (None 이 'None' 으로
    보이지 않게 · 문자열이라 최고값 후보 아님) · 키가 없는 옛 케이스는 건드리지 않는다 (표에 '-')."""
    st = metrics.get('coverage_status_physics_union')
    if isinstance(st, str) and st.startswith('blank'):
        for k in ('coverage_AM_P_mean_physics_union', 'coverage_AM_S_mean_physics_union', 'coverage_AM_mean_physics_union'):
            if k in metrics and metrics[k] is None:
                metrics[k] = '— (빈칸)'
        return metrics
    agg = _union_num(metrics.get('coverage_AM_mean_physics_union'))
    if agg is not None and 'coverage_AM_P_mean_physics_union' not in metrics and 'coverage_AM_S_mean_physics_union' not in metrics:
        side = 'P' if metrics.get('ps_ratio', '') in ('P only', '10:0') else 'S'
        metrics[f'coverage_AM_{side}_mean_physics_union'] = agg
    return metrics


def _group_am_am_mean_na(metrics):
    """★ 10-05 RGL-05 (인계표와 같은 정의 · J20-l) — AM–AM 접촉 0 이면 평균 면적은 정의되지 않는다 (0/0).
    `calc_am_am_cn` 은 접촉 0 에 평균 0 을 넣는다 → 인계표 `am_am_mean_area` 는 빈칸 (N/A) 인데 그룹 표는 0 을 보였다.
    개수 0 · 총합 0 은 측정된 0 그대로 둔다 · 개수 키가 없으면 판단하지 않는다 · 옛 세대의 문자열 개수 ('0') 도 같은 규칙."""
    try:
        n = float(metrics.get('am_am_n_contacts'))
    except (TypeError, ValueError):
        return metrics
    if n == 0.0:
        metrics['am_am_mean_area'] = None
    return metrics


GROUP_DISPLAY_KEYS = [
    ('P:S', '', 'ps_ratio', '조성/구조'),
    ('φ_AM', '', 'phi_am', '조성/구조'),
    ('φ_SE', '', 'phi_se', '조성/구조'),
    ('Porosity', '(%)', 'porosity', '조성/구조'),
    ('Porosity (union)', '(%)', 'porosity_union', '조성/구조'),
    ('Overlap fraction', '(%)', 'overlap_fraction_pct', '조성/구조'),
    ('Porosity (union exact)', '(%)', 'porosity_union_exact_pct', '조성/구조'),        # ③ 정확 union (MC · 인계 규약)
    ('두께', '(μm)', 'thickness_um', '조성/구조'),
    ('두께 (질량 보존)', '(μm)', 'thickness_mass_conserving_um', '조성/구조'),         # ③ J20-e (라)
    ('φ_SE (질량 보존)', '', 'phi_se_mass_conserving', '조성/구조'),
    ('φ_AM (질량 보존)', '', 'phi_am_mass_conserving', '조성/구조'),
    # ── SE 계면/네트워크 (σ_ionic form inputs) ──
    ('SE-SE CN', '', 'se_se_cn', 'SE 네트워크'),
    ('SE-SE CN std', '', 'se_se_cn_std', 'SE 네트워크'),
    ('SE-SE Total', '(μm²)', 'area_SE_SE_total', 'SE 네트워크'),
    ('Coverage P', '(%)', 'coverage_AM_P_mean', 'SE 네트워크'),
    ('Coverage S', '(%)', 'coverage_AM_S_mean', 'SE 네트워크'),
    ('Coverage P (Physics 합집합)', '(%)', 'coverage_AM_P_mean_physics_union', 'SE 네트워크'),   # ⑥ C2-⑥ · LHS-25 (10-06)
    ('Coverage S (Physics 합집합)', '(%)', 'coverage_AM_S_mean_physics_union', 'SE 네트워크'),
    ('Percolation', '(%)', 'percolation_pct', 'SE 네트워크'),
    ('Tortuosity', '', 'tortuosity_mean', 'SE 네트워크'),
    ('Tortuosity all-SE', '', 'tortuosity_all_mean', 'SE 네트워크'),   # 기하 τ 전체판 (10-02 · calc_tortuosity_all)
    ('Hop Area', '(μm²)', 'path_hop_area_mean', 'SE 네트워크'),
    ('Bottleneck', '(μm²)', 'path_hop_area_min_mean', 'SE 네트워크'),
    # ── AM 네트워크 (σ_e Stage 15 form inputs) ──
    ('AM-AM CN', '', 'am_am_cn', 'AM 네트워크'),
    ('AM-AM CN std', '', 'am_am_cn_std', 'AM 네트워크'),          # J20-j · ②-b (e)
    ('AM-AM Mean Area', '(μm²)', 'am_am_mean_area', 'AM 네트워크'),
    ('AM-AM N contacts', '', 'am_am_n_contacts', 'AM 네트워크'),
    ('AM-SE CN', '', 'am_se_cn_mean', 'AM 네트워크'),
    ('AM Vulnerable', '(%)', 'am_vulnerable_pct', 'AM 네트워크'),
    ('Ionic Active', '(%)', 'ionic_active_pct', 'AM 네트워크'),
    ('Ionic Isolated (path)', '(%)', 'am_ionic_isolated_pct', 'AM 네트워크'),      # v1.1 ① = 100 − 활성 (옛 세대는 로드 때 유도)
    ('Isolated: SE not linked', '(%)', 'ionic_dead_pct', 'AM 네트워크'),          # v1.1 ② 분해 (옛 세대 = 빈칸)
    ('Isolated: no SE', '(%)', 'ionic_no_se_pct', 'AM 네트워크'),
    # ── Transport (Stage E — production form targets) ──
    ('σ_ionic (Stage E)', '(mS/cm)', '_sigma_i_stage_e_display', '전송 (Stage E)'),
    ('σ_electronic (Stage E)', '(mS/cm)', '_sigma_e_stage_e_display', '전송 (Stage E)'),
    ('σ_thermal (Stage E)', '(mS/cm)', '_sigma_k_stage_e_display', '전송 (Stage E)'),
    ('R_brug', '(×)', 'R_brug_over_full', '전송 (Stage E)'),
    ('Constriction (비가중)', '(%)', '_constriction_pct', '전송 (Stage E)'),     # 1 − 접촉별 R_bulk/R_total 비가중 평균 (L2-08 · 전력 몫 아님)
    ('Constriction I²R', '(%)', '_constriction_power_pct', '전송 (Stage E)'),      # ④a 10-04 — Σ I²R_c / Σ I²R_total (이온 · hertz)
    # ── 접촉력 (force chain) ──
    ('Fn AM-AM', '(μN)', 'fn_AM_P_AM_P_mean', '접촉력'),
    ('Fn AM-SE', '(μN)', 'fn_AM_P_SE_mean', '접촉력'),
    ('Fn SE-SE', '(μN)', 'fn_SE_SE_mean', '접촉력'),
    ('CP mean', '(MPa)', 'contact_pressure_mean', '접촉력'),
    ('CP max', '(MPa)', 'contact_pressure_max', '접촉력'),
    # ── 응력 분포 ── 옛 네 열 = LIGGGHTS stress/atom (접촉 virial 50/50 분할) · 대각 — 열 이름에 규약 표기 (LHS-29) · ④b Love–Weber 열
    ('Stress CV (50/50)', '(%)', 'stress_cv', '응력'),
    ('σ_AM_P/σ_mean (50/50)', '', 'stress_ratio_AM_P', '응력'),
    ('σ_AM_S/σ_mean (50/50)', '', 'stress_ratio_AM_S', '응력'),
    ('σ_SE/σ_mean (50/50)', '', 'stress_ratio_SE', '응력'),
    ('Stress CV LW', '(%)', 'stress_cv_lw', '응력'),
    ('σ_AM_P/σ_mean LW', '', 'stress_ratio_AM_P_lw', '응력'),
    ('σ_AM_S/σ_mean LW', '', 'stress_ratio_AM_S_lw', '응력'),
    ('σ_SE/σ_mean LW', '', 'stress_ratio_SE_lw', '응력'),
    ('Stress CV LW (벽 제외)', '(%)', 'stress_cv_lw_nowall', '응력'),
    ('σ_AM_P/σ_mean LW (벽 제외)', '', 'stress_ratio_AM_P_lw_nowall', '응력'),
    ('σ_AM_S/σ_mean LW (벽 제외)', '', 'stress_ratio_AM_S_lw_nowall', '응력'),
    ('σ_SE/σ_mean LW (벽 제외)', '', 'stress_ratio_SE_lw_nowall', '응력'),
]

# 낮을수록 좋은 열 — **표의 열 이름과 같은 철자** (test_closed_param_groupview E2 가 강제).
#   옛 집합은 porosity union · overlap · CN std 가 없었고 'Vulnerable' 은 열 'AM Vulnerable' 과 철자가 달라
#   조용히 '높을수록 좋음' 으로 강조됐다 · 표에 없는 이름 (τ std · GB Density · SE Cluster) 은 뺐다.
GROUP_LOWER_BETTER = {
    'Porosity', 'Porosity (union)', 'Porosity (union exact)', 'Overlap fraction', '두께', '두께 (질량 보존)',
    'SE-SE CN std', 'AM-AM CN std', 'Tortuosity', 'Tortuosity all-SE', 'AM Vulnerable',
    'Ionic Isolated (path)', 'Isolated: SE not linked', 'Isolated: no SE',
    'R_brug', 'Constriction (비가중)', 'Constriction I²R', 'CP mean', 'CP max', 'Stress CV (50/50)', 'Stress CV LW', 'Stress CV LW (벽 제외)',
}


def _group_best_marks(group_rows, display_keys, lower_better=None):
    """그룹 안에서 열마다 최고값 행 → {(label, 행 번호)}.  숫자로 못 읽는 칸 ('-') 은 후보가 아니고,
    모든 값이 같으면 강조하지 않는다.  낮을수록 좋음 = GROUP_LOWER_BETTER (그 밖은 높을수록 좋음)."""
    lower_better = GROUP_LOWER_BETTER if lower_better is None else lower_better
    marks = set()
    for label, _unit, _key in display_keys:
        if label in ('P:S', '케이스'):
            continue
        vals = []
        for ri, r in enumerate(group_rows):
            try:
                vals.append((ri, float(str(r.get(label, '-')).replace('e', 'E').strip())))
            except (ValueError, TypeError):
                pass
        if not vals:
            continue
        lo = min(vals, key=lambda x: x[1]); hi = max(vals, key=lambda x: x[1])
        if lo[1] == hi[1]:
            continue
        marks.add((label, (lo if label in lower_better else hi)[0]))
    return marks


@app.route('/group', methods=['GET', 'POST'])
def group():
    """Group comparison page."""
    cases = list_cases()
    selected = request.args.getlist('cases')
    case_groups_param = request.args.get('case_groups', '[]')

    comparison_data = {}
    case_groups_parsed = []
    try:
        case_groups_parsed = json.loads(case_groups_param)
    except:
        pass
    if selected:
        # Key metrics grouped by category
        # (label, unit, key, category)
        # Categories ordered to mirror the σ_ionic/σ_e production forms' inputs:
        #   composition → structure → SE interface (ionic) → AM interface
        #   (electronic, Stage 15) → transport (Stage E, all 3 channels) →
        #   contact mechanics → stress.  Each transport channel shows the
        #   Stage E value (phantom-filtered) — what the production fit targets.
        display_keys_raw = GROUP_DISPLAY_KEYS
        display_keys = [(l, u, k) for l, u, k, _ in display_keys_raw]
        # Track category boundaries for column separators
        col_categories = [''] + [cat for _, _, _, cat in display_keys_raw]
        rows = []
        for cid in selected:
            # Handle archive: prefix
            if cid.startswith('archive:'):
                archive_rel = cid[len('archive:'):]
                case_path = _archive_join(archive_rel)
                meta_file = os.path.join(case_path, 'meta.json')
                metrics_path = os.path.join(case_path, 'full_metrics.json')
                case_name = os.path.basename(archive_rel)
            else:
                case_path = get_results_dir(cid)
                meta_file = os.path.join(get_case_dir(cid), 'meta.json')
                metrics_path = os.path.join(case_path, 'full_metrics.json')
                case_name = cid

            if os.path.exists(meta_file):
                with open(meta_file) as f:
                    meta = json.load(f)
                case_name = meta.get('name', case_name)

            metrics = {}
            if os.path.exists(metrics_path):
                with open(metrics_path) as f:
                    metrics = json.load(f)
            else:
                continue

            # v1.1 ① — 경로 기준 고립 (옛 세대는 키가 없다 → 100 − 활성 · 분해 두 열은 비워 둔다 = 측정 안 함)
            if metrics.get('am_ionic_isolated_pct') is None and isinstance(metrics.get('ionic_active_pct'), (int, float)):
                metrics['am_ionic_isolated_pct'] = 100.0 - metrics['ionic_active_pct']
            _group_am_am_mean_na(metrics)
            _group_union_coverage_cells(metrics)                    # ⑥ 합집합 칸 (mono 매핑 · 빈칸 표지 · J20-l)
            from metrics_json import stress_cv_group_cells as _scv_cells   # LHS-33 — 옛 σ_VM 네 열 무효 · 미정의 = '— (사유)' (None · 0 아님)
            _scv_cells(metrics)

            # Derived: constriction percentage (1 − 접촉별 비가중 평균 · L2-08)
            bf = metrics.get('bulk_resistance_fraction')
            if bf is not None and bf > 0:
                metrics['_constriction_pct'] = round((1 - bf) * 100, 1)
            # ④a 10-04 — 같은 FULL 해의 협착 전력 몫 (이온 · hertz) · 키 없으면 빈칸 (0 으로 안 채움)
            _cps = metrics.get('constriction_power_share_ion_hertz')
            if isinstance(_cps, (int, float)) and not isinstance(_cps, bool) and _cps == _cps:
                metrics['_constriction_power_pct'] = round(100 * _cps, 1)

            # Stage E σ display (phantom-aware) — matches what production form fits.
            # For σ_e: requires raw > 0 AND not both-fallback (input_1mAh_5 raw=51.89
            # would otherwise be misleading vs Stage E=9.014).  Same logic for σ_ionic
            # and σ_thermal Stage E columns.
            src = metrics.get('stage_e_source') or {}
            # σ_e Stage E
            raw_e = metrics.get('electronic_sigma_full_mScm')
            if (isinstance(raw_e, (int, float)) and raw_e > 0
                    and not (src.get('sigma_e') == 'fallback_weighted_factor'
                             and src.get('sigma_e_physics') == 'fallback_weighted_factor')):
                stE_e = metrics.get('electronic_sigma_full_mScm_stage_e')
                metrics['_sigma_e_stage_e_display'] = (
                    stE_e if isinstance(stE_e, (int, float)) and 0 < stE_e <= 100
                    else (raw_e if raw_e <= 100 else None))
            else:
                metrics['_sigma_e_stage_e_display'] = None
            # σ_thermal Stage E
            raw_k = metrics.get('thermal_sigma_full_mScm')
            if (isinstance(raw_k, (int, float)) and raw_k > 0
                    and src.get('sigma_thermal') != 'fallback_weighted_factor'):
                stE_k = metrics.get('thermal_sigma_full_mScm_stage_e')
                metrics['_sigma_k_stage_e_display'] = (
                    stE_k if isinstance(stE_k, (int, float)) and stE_k > 0
                    else raw_k)
            else:
                metrics['_sigma_k_stage_e_display'] = None
            # σ_ionic Stage E (prefer stage_e value; raw fallback)
            stE_i = metrics.get('sigma_full_mScm_stage_e')
            raw_i = metrics.get('sigma_full_mScm')
            metrics['_sigma_i_stage_e_display'] = (
                stE_i if isinstance(stE_i, (int, float)) and stE_i > 0
                else (raw_i if isinstance(raw_i, (int, float)) and raw_i > 0 else None))

            # Standard 모드: coverage_AM_mean → P:S에 따라 P 또는 S에 매핑
            if 'coverage_AM_mean' in metrics:
                ps = metrics.get('ps_ratio', '')
                if ps in ('P only', '10:0'):
                    metrics.setdefault('coverage_AM_P_mean', metrics['coverage_AM_mean'])
                else:
                    metrics.setdefault('coverage_AM_S_mean', metrics['coverage_AM_mean'])
            # Standard 모드: area_AM_SE_total → P:S에 따라 매핑
            if 'area_AM_SE_total' in metrics and 'area_AM_P_SE_total' not in metrics:
                ps = metrics.get('ps_ratio', '')
                if ps in ('P only', '10:0'):
                    metrics['area_AM_P_SE_total'] = metrics['area_AM_SE_total']
                else:
                    metrics['area_AM_S_SE_total'] = metrics['area_AM_SE_total']

            # Force metric fallbacks: AM_P↔AM_S
            if 'fn_AM_P_AM_P_mean' not in metrics and 'fn_AM_S_AM_S_mean' in metrics:
                metrics['fn_AM_P_AM_P_mean'] = metrics['fn_AM_S_AM_S_mean']
            if 'fn_AM_P_SE_mean' not in metrics and 'fn_AM_S_SE_mean' in metrics:
                metrics['fn_AM_P_SE_mean'] = metrics['fn_AM_S_SE_mean']

            row = {'케이스': case_name}
            for label, unit, key in display_keys:
                val = metrics.get(key, '')
                if isinstance(val, float):
                    if key in ('path_conductance_mean', 'path_hop_area_min_mean'):
                        val = f"{val:.2e}" if val > 0 else '-'
                    else:
                        val = round(val, 2)
                row[label] = val if val != '' else '-'
            rows.append(row)

        if rows:
            # Build columns with unit subtitles
            col_headers = [{'name': '케이스', 'unit': ''}]
            for label, unit, key in display_keys:
                col_headers.append({'name': label, 'unit': unit})

            # Split into case group tables
            if case_groups_parsed and len(case_groups_parsed) > 1:
                tables = []
                row_idx = 0
                for gi, g in enumerate(case_groups_parsed):
                    gname = g.get('name', '') or f"Case {chr(65+gi)}"
                    group_rows = []
                    for _ in g.get('cases', []):
                        if row_idx < len(rows):
                            group_rows.append(rows[row_idx])
                            row_idx += 1
                    # Mark best values per column (GROUP_LOWER_BETTER · _group_best_marks — ②-b (e))
                    best_marks = _group_best_marks(group_rows, display_keys)
                    for ri, r in enumerate(group_rows):
                        r['__best__'] = {label for (label, idx) in best_marks if idx == ri}

                    tables.append({'name': gname, 'rows': group_rows, 'color': ['#6c8cff','#ff6b6b','#51cf66','#ffd43b'][gi % 4]})
                comparison_data = {
                    'columns': [c['name'] for c in col_headers],
                    'units': [c['unit'] for c in col_headers],
                    'categories': col_categories,
                    'tables': tables
                }
            else:
                comparison_data = {
                    'columns': [c['name'] for c in col_headers],
                    'units': [c['unit'] for c in col_headers],
                    'categories': col_categories,
                    'tables': [{'name': '', 'rows': rows, 'color': ''}]
                }

    # Scan archive for folders with full_metrics.json
    archive_folders = []
    archive_root = app.config['ARCHIVE_FOLDER']
    if os.path.isdir(archive_root):
        for dirpath, dirnames, filenames in os.walk(archive_root):
            # Count cases in this folder (subfolders with full_metrics.json)
            case_count = 0
            for d in dirnames:
                if os.path.exists(os.path.join(dirpath, d, 'full_metrics.json')):
                    case_count += 1
            if case_count > 0:
                rel = os.path.relpath(dirpath, archive_root)
                archive_folders.append({'path': rel if rel != '.' else '(최상위)', 'case_count': case_count})

    return render_template('group.html', cases=cases, selected=selected,
                         comparison=comparison_data, archive_folders=archive_folders,
                         case_groups_json=case_groups_param, lv=_page_lv('group'))

@app.route('/group/archive-cases')
def group_archive_cases():
    """Return cases in an archive folder that have full_metrics.json."""
    folder = request.args.get('folder', '')
    archive_root = app.config['ARCHIVE_FOLDER']
    if folder == '(최상위)':
        base = archive_root
    else:
        base = _archive_join(folder)          # F-06: 사용자 query 를 직접 붙이지 않는다
    if not os.path.isdir(base):
        return jsonify({'cases': []})

    cases = []
    for name in sorted(os.listdir(base)):
        case_dir = os.path.join(base, name)
        metrics_path = os.path.join(case_dir, 'full_metrics.json')
        if os.path.isdir(case_dir) and os.path.exists(metrics_path):
            with open(metrics_path) as f:
                m = json.load(f)
            # Use archive: prefix to distinguish from dashboard cases
            case_id = f"archive:{os.path.relpath(case_dir, archive_root)}"
            cases.append({
                'id': case_id,
                'name': name,
                'ps_ratio': m.get('ps_ratio', ''),
                'warning_count': m.get('warning_count', 0),
                'warning_msgs': [w['msg'] for w in m.get('warnings', [])],
            })
    return jsonify({'cases': cases})

@app.route('/group/plots', methods=['POST'])
def group_plots():
    """Generate comparison plots for selected cases."""
    selected = request.form.getlist('cases')
    plots = request.form.getlist('plots')
    if not selected or not plots:
        return jsonify({'error': '케이스와 플롯을 선택하세요.'}), 400

    session_id = datetime.now().strftime('%y%m%d_%H%M%S') + '_' + str(uuid.uuid4())[:4]
    plot_dir = os.path.join(app.config['RESULTS_FOLDER'], 'group_plots', session_id)
    os.makedirs(plot_dir, exist_ok=True)

    # Collect metrics files and names
    input_files = []
    names = []
    cid_to_name = {}  # case ID → the name the generator receives (for focus matching)
    for cid in selected:
        if cid.startswith('archive:'):
            archive_rel = cid[len('archive:'):]
            case_path = _archive_join(archive_rel)
            metrics_path = os.path.join(case_path, 'full_metrics.json')
            case_name = os.path.basename(archive_rel)
        else:
            case_path = get_results_dir(cid)
            metrics_path = os.path.join(case_path, 'full_metrics.json')
            meta_file = os.path.join(get_case_dir(cid), 'meta.json')
            case_name = cid
            if os.path.exists(meta_file):
                with open(meta_file) as f:
                    case_name = json.load(f).get('name', cid)
        if os.path.exists(metrics_path):
            input_files.append(metrics_path)
            names.append(case_name)
            cid_to_name[cid] = case_name

    if not input_files:
        return jsonify({'error': '메트릭 데이터가 없습니다.'}), 400

    # Pass case groups info
    case_groups_json = request.form.get('case_groups', '[]')
    try:
        case_groups_raw = json.loads(case_groups_json)
    except:
        case_groups_raw = []

    # Build group sizes string: "3,5" means first 3 cases = group A, next 5 = group B
    # Build group names string
    # Filter against ACTUAL surviving cases — if a case was deleted from disk,
    # the main loop below silently drops it from input_files. Without mirroring
    # that filter here, group_sizes would over-count by the number of missing
    # cases and the vertical group separators drift by that amount.
    surviving = set()
    for cid in selected:
        if cid.startswith('archive:'):
            case_path = _archive_join(cid[len('archive:'):])
        else:
            case_path = get_results_dir(cid)
        if os.path.exists(os.path.join(case_path, 'full_metrics.json')):
            surviving.add(cid)

    group_sizes = []
    group_names_list = []
    for g in case_groups_raw:
        count = sum(1 for c in g.get('cases', []) if c in surviving)
        if count == 0:
            continue
        group_sizes.append(str(count))
        group_names_list.append(g.get('name', '') or f"Case {chr(65 + len(group_names_list))}")

    global_rgb = request.form.get('global_rgb', '')
    global_c_ion = request.form.get('global_c_ion', '')
    y_max_sigma = request.form.get('y_max_sigma', '')  # optional unified σ y-axis (mS/cm)

    scripts = app.config['SCRIPTS_FOLDER']
    cmd = [sys.executable, os.path.join(scripts, 'generate_comparison_plots.py'),
           '-i'] + input_files + ['-n'] + names + ['-o', plot_dir, '-p'] + plots
    if group_sizes and len(group_sizes) > 1:
        cmd += ['--group-sizes', ','.join(group_sizes),
                '--group-names', ','.join(group_names_list)]
    if global_rgb:
        cmd += ['--global-rgb', global_rgb]
    if global_c_ion:
        cmd += ['--global-c-ion', global_c_ion]
    if y_max_sigma:
        try:
            # Validate it's a positive number before passing
            _yms = float(y_max_sigma)
            if _yms > 0:
                cmd += ['--y-max-sigma', str(_yms)]
        except ValueError:
            pass  # invalid → ignore, fall back to auto
    # σ_e Y-axis max — user-set σ_AM(e) (mS/cm) ONLY controls plot y-axis ceiling
    # for σ_e plots.  Does NOT change form σ_S/σ_P anchors (those stay locked
    # at Trevisanello 10/5 literature defaults per Stage 22 design).
    sigma_AM_e = request.form.get('sigma_AM_e', '').strip()
    if sigma_AM_e:
        try:
            _sAM = float(sigma_AM_e)
            if _sAM > 0:
                cmd += ['--y-max-sigma-e', str(_sAM)]
        except ValueError:
            pass  # invalid → ignore, auto-scale
    # Generic parameter-comparison selections (param_scatter/bar/corr)
    param_x = request.form.get('param_x', '').strip()
    param_y = request.form.get('param_y', '').strip()
    param_list = request.form.get('param_list', '').strip()
    if param_x:
        cmd += ['--param-x', param_x]
    if param_y:
        cmd += ['--param-y', param_y]
    if param_list:
        cmd += ['--param-list', param_list]
    if request.form.get('param_norm') in ('1', 'true', 'on'):
        cmd += ['--param-norm']
    # "1-1" focus: saved case names to show as a focus parity (tab-separated,
    # since names can contain commas/colons). Fit stays on the full set.
    # focus_cases arrive as case IDs → translate to the exact names the
    # generator sees (archive names are basename'd, so name-matching is fragile).
    focus_cids = request.form.getlist('focus_cases')
    focus_names = [cid_to_name[c] for c in focus_cids if c in cid_to_name]
    if focus_names:
        cmd += ['--focus-cases', '\t'.join(focus_names)]
        focus_label = request.form.get('focus_label', '').strip()
        if focus_label:
            cmd += ['--focus-label', focus_label]
    # Full-corpus metrics for global (n=all) fit stats on per-group fit plots.
    fit_corpus_paths = []
    for cid in request.form.getlist('fit_corpus_cases'):
        if cid.startswith('archive:'):
            mp = os.path.join(_archive_join(cid[len('archive:'):]), 'full_metrics.json')
        else:
            mp = os.path.join(get_results_dir(cid), 'full_metrics.json')
        if os.path.exists(mp):
            fit_corpus_paths.append(mp)
    if fit_corpus_paths:
        cmd += ['--fit-corpus-inputs'] + fit_corpus_paths
    result = subprocess.run(cmd, capture_output=True, text=True, timeout=120)
    if result.stdout:
        print(f"[plots] stdout:\n{result.stdout}")
    if result.stderr:
        print(f"[plots] stderr:\n{result.stderr}")

    if result.returncode != 0:
        return jsonify({'error': f'Plot 생성 실패: {result.stderr}'}), 500

    # Load plot info
    info_path = os.path.join(plot_dir, 'plot_info.json')
    plot_list = []
    if os.path.exists(info_path):
        with open(info_path) as f:
            info = json.load(f)
        # particle_info always first
        if 'particle_info' in info:
            plot_list.append(info['particle_info'])
        for key in plots:
            if key in info:
                plot_list.append(info[key])
            # Append the "1-1" focus variant (if any) right after its parent
            if f"{key}_focus" in info:
                plot_list.append(info[f"{key}_focus"])

    return jsonify({'session': session_id, 'plots': plot_list})

@app.route('/group/param-options', methods=['POST'])
def group_param_options():
    """Return the union of comparable numeric parameters across the selected
    cases — full_metrics.json scalars + derived 3D-viewer (viewer_aux.json)
    diagnostics — for the generic parameter-comparison picker."""
    selected = request.form.getlist('cases')
    keys = set()
    for cid in selected:
        if cid.startswith('archive:'):
            case_path = _archive_join(cid[len('archive:'):])
        else:
            case_path = get_results_dir(cid)
        fm = os.path.join(case_path, 'full_metrics.json')
        if os.path.exists(fm):
            try:
                with open(fm) as f:
                    d = json.load(f)
            except (OSError, ValueError):
                d = {}
            from metrics_json import metric_number as _metric_number
            for k, v in d.items():
                # 옛 케이스의 숫자 문자열 ('412' — numpy int 가 json default=str 로 저장된 것) 도 숫자 (LHS-24 (a))
                if not k.startswith('_') and _metric_number(v) is not None:
                    keys.add(k)
        aux = os.path.join(case_path, 'viewer_aux.json')
        if os.path.exists(aux):
            try:
                with open(aux) as f:
                    a = json.load(f)
            except (OSError, ValueError):
                a = {}
            for k, v in a.items():
                if isinstance(v, (int, float)) and not isinstance(v, bool):
                    keys.add(f'aux:{k}')
            apts = a.get('se_articulation_points')
            if a.get('se_n_percolating') and (
                    a.get('se_n_articulation_points') is not None
                    or isinstance(apts, list)):
                keys.add('cut_fraction')
            if a.get('se_n_bn_below_threshold') is not None and a.get('se_n_perc_edges'):
                keys.add('bn_below_frac')
            if a.get('se_bn_median_norm') is not None:
                keys.add('bn_median_norm')
        # Grade-engine derived metrics (Q/ASR/τ_Laplace/cycle-stable …) →
        # 'grade:<label>' params (mirrors generate_comparison_plots._merged_params)
        if os.path.exists(fm):
            try:
                import sys as _sys
                _sd = os.path.join(os.path.dirname(__file__), '..', 'scripts')
                if _sd not in _sys.path:
                    _sys.path.insert(0, _sd)
                import grade_engine as _ge
                with open(fm) as f:
                    _m = json.load(f)
                _ip = {}
                _ipp = os.path.join(case_path, 'input_params.json')
                if os.path.exists(_ipp):
                    with open(_ipp) as f:
                        _ip = json.load(f)
                _meta = {}
                _mp = os.path.join(case_path, 'meta.json')
                if os.path.exists(_mp):
                    with open(_mp) as f:
                        _meta = json.load(f)
                _se = None
                _ap = os.path.join(case_path, 'viewer_aux.json')
                if os.path.exists(_ap):
                    with open(_ap) as f:
                        _a = json.load(f)
                    _apts = _a.get('se_articulation_points')
                    _se = {
                        'n_percolating': _a.get('se_n_percolating'),
                        'n_articulation_points': (_a.get('se_n_articulation_points')
                            if _a.get('se_n_articulation_points') is not None
                            else (len(_apts) if isinstance(_apts, list) else None)),
                        'n_bn_below_threshold': _a.get('se_n_bn_below_threshold'),
                        'n_perc_edges': _a.get('se_n_perc_edges'),
                        'bn_median_norm': _a.get('se_bn_median_norm'),
                    }
                _prepared = {**_m, **_ge.map_input_params(_ip, _meta)}
                for _lbl in _ge.axis_values(_prepared, _se):
                    keys.add(f'grade:{_lbl}')
            except Exception:
                pass
    return jsonify({'params': sorted(keys)})


@app.route('/group/plot-image/<session>/<filename>')
def serve_group_plot(session, filename):
    plot_dir = os.path.join(app.config['RESULTS_FOLDER'], 'group_plots', session)
    return send_from_directory(plot_dir, filename)

@app.route('/group/report', methods=['POST'])
def group_report():
    """Generate comprehensive group comparison markdown report."""
    selected = request.form.getlist('cases')
    title = request.form.get('title', 'DEM_Bimodal_Comparison')
    notes = request.form.get('notes', '')

    now = datetime.now().strftime('%y%m%d')
    L = []  # lines

    # Header
    L.append(f'# {now}_{title}\n')
    L.append(f'> **날짜**: {datetime.now().strftime("%Y-%m-%d")}')
    L.append(f'> **비교 케이스**: {len(selected)}개')
    if notes:
        L.append(f'> **메모**: {notes}')
    L.append('')
    L.append('---\n')

    # Load all metrics
    all_metrics = []
    case_names = []
    for cid in selected:
        if cid.startswith('archive:'):
            archive_rel = cid[len('archive:'):]
            case_path = _archive_join(archive_rel)
            meta_file = os.path.join(case_path, 'meta.json')
            metrics_path = os.path.join(case_path, 'full_metrics.json')
            name = os.path.basename(archive_rel)
        else:
            case_path = get_results_dir(cid)
            meta_file = os.path.join(get_case_dir(cid), 'meta.json')
            metrics_path = os.path.join(case_path, 'full_metrics.json')
            name = cid
        if os.path.exists(meta_file):
            with open(meta_file) as f:
                name = json.load(f).get('name', name)
        metrics = {}
        if os.path.exists(metrics_path):
            with open(metrics_path) as f:
                metrics = json.load(f)
        all_metrics.append(metrics)
        case_names.append(name)

    if not all_metrics:
        return jsonify({'report': '메트릭 데이터가 없습니다.', 'path': ''})

    # 1. System Overview
    L.append('## 1. System Overview\n')
    import pandas as pd
    overview_rows = []
    #  ★ 09-30 (웹앱 ① · J20-l) — 화면 · 단일 보고서와 같은 한정어
    display_keys = [
        ('P:S', 'ps_ratio'), ('Porosity ε_sphere(%)', 'porosity'),
        ('Porosity ε_union pair-lens(%)', 'porosity_union'),
        ('Overlap pair-lens(%)', 'overlap_fraction_pct'),
        ('Porosity ε_union exact MC(%)', 'porosity_union_exact_pct'),
        ('Thickness plate gap(μm)', 'thickness_um'),
        ('AM-SE Total(μm²)', 'area_AM전체_SE_total'),
        ('SE-SE Total(μm²)', 'area_SE_SE_total'),
        ('SE-SE CN', 'se_se_cn'), ('SE-SE CN std', 'se_se_cn_std'), ('SE Cluster', 'n_components'),
        ('Percolation(%)', 'percolation_pct'),
        ('Top Reachable(%)', 'top_reachable_pct'),
        ('Tortuosity', 'tortuosity_mean'),
        ('Tortuosity all-SE (geometric)', 'tortuosity_all_mean'),
        ('Ionic Active(%)', 'ionic_active_pct'),
        #  ⑥ 10-06 (C2-⑥ · LHS-25) — Physics 피복 = 합집합 cap (세대 2 면적) · 옛 합-클립 아님
        ('Coverage AM_P Physics union-of-caps g2(%)', 'coverage_AM_P_mean_physics_union'),
        ('Coverage AM_S Physics union-of-caps g2(%)', 'coverage_AM_S_mean_physics_union'),
    ]
    for i, name in enumerate(case_names):
        row = {'Case': name}
        for label, key in display_keys:
            val = all_metrics[i].get(key, '-')
            if val is None:                                  # 빈칸 (None) 을 'None' 으로 보이지 않게 — 없는 키와 같은 '-'
                val = '-'
            if isinstance(val, float):
                val = round(val, 2)
            row[label] = val
        overview_rows.append(row)
    df = pd.DataFrame(overview_rows)
    L.append(df.to_markdown(index=False))
    L.append('')

    # 2. Key Findings (자동 분석)
    L.append('\n## 2. Key Findings\n')

    porosities = [(case_names[i], m.get('porosity', 0)) for i, m in enumerate(all_metrics) if m.get('porosity')]
    if porosities:
        min_p = min(porosities, key=lambda x: x[1])
        L.append(f'- **Porosity 최저**: {min_p[0]} ({min_p[1]:.2f}%)')

    percs = [(case_names[i], m.get('percolation_pct', 0)) for i, m in enumerate(all_metrics) if m.get('percolation_pct')]
    if percs:
        max_perc = max(percs, key=lambda x: x[1])
        L.append(f'- **Percolation 최대**: {max_perc[0]} ({max_perc[1]:.1f}%)')

    torts = [(case_names[i], m.get('tortuosity_mean', 99)) for i, m in enumerate(all_metrics) if m.get('tortuosity_mean')]
    if torts:
        min_tort = min(torts, key=lambda x: x[1])
        L.append(f'- **Tortuosity 최저**: {min_tort[0]} ({min_tort[1]:.2f})')

    ionics = [(case_names[i], m.get('ionic_active_pct', 0)) for i, m in enumerate(all_metrics) if m.get('ionic_active_pct')]
    if ionics:
        max_ionic = max(ionics, key=lambda x: x[1])
        L.append(f'- **Ionic Active 최대**: {max_ionic[0]} ({max_ionic[1]:.1f}%)')

    se_totals = [(case_names[i], m.get('area_SE_SE_total', 0)) for i, m in enumerate(all_metrics) if m.get('area_SE_SE_total')]
    if se_totals:
        max_se = max(se_totals, key=lambda x: x[1])
        L.append(f'- **SE-SE Total Area 최대**: {max_se[0]} ({max_se[1]:,.1f} μm²)')

    L.append('')

    # 3. Trade-off Analysis
    L.append('\n## 3. Trade-off Analysis\n')
    L.append('### AM-SE vs SE-SE Trade-off\n')
    L.append('| AM_P ↑ | AM-SE 계면 | SE-SE 네트워크 |')
    L.append('|---|---|---|')
    L.append('| 변화 | **감소** | **개선** (percolation↑, tortuosity↓) |')
    L.append('| 의미 | 반응 면적 감소 | 이온 경로 확보 |')
    L.append('| 제한 요인 | charge transfer | ionic transport |')
    L.append('')
    L.append('> **전극 성능 = 병목(bottleneck)이 결정**')
    L.append('> - SE 네트워크 부족 (P 적음) → ionic transport limited')
    L.append('> - AM-SE 계면 부족 (P 많음) → charge transfer limited')
    L.append('')

    # 4. SE-SE Contact Network Trade-off
    L.append('### SE-SE Contact: Quality vs Quantity\n')
    L.append('AM_P↑ → SE-SE 접촉 개수↑ (넓은 공간에 분산) + 개별 접촉 면적↓ (느슨하게 배치)')
    L.append('')
    se_n = [(case_names[i], m.get('area_SE_SE_n', 0), m.get('area_SE_SE_mean', 0))
            for i, m in enumerate(all_metrics) if m.get('area_SE_SE_n')]
    if se_n:
        L.append('| Case | SE-SE N | SE-SE Mean Area(μm²) | SE-SE Total(μm²) |')
        L.append('|---|---|---|---|')
        for name, n, mean in se_n:
            total = n * mean
            L.append(f'| {name} | {int(n):,} | {mean:.4f} | {total:,.1f} |')
    L.append('')

    # 5. Conclusion
    L.append('\n## 4. Conclusion\n')
    if porosities and len(porosities) > 2:
        L.append(f'- Porosity: {porosities[0][0]} ({porosities[0][1]:.1f}%) → {porosities[-1][0]} ({porosities[-1][1]:.1f}%)')
    if percs and torts:
        L.append(f'- 이온경로: Percolation {percs[0][1]:.0f}%→{percs[-1][1]:.0f}%, Tortuosity {torts[0][1]:.1f}→{torts[-1][1]:.1f}')
    L.append('')

    # Tags
    L.append('---\n')

    # Claude AI 심층 분석
    ai_analysis = _generate_ai_analysis(all_metrics, case_names, title, notes)
    if ai_analysis:
        L.append('\n## 5. AI 심층 분석 (Claude)\n')
        L.append(ai_analysis)
        L.append('')

    L.append('---\n')
    L.append('#DEM #bimodal #comparison #percolation #tortuosity #coverage #ASSB\n')

    report = '\n'.join(L)

    # Save report
    group_dir = os.path.join(app.config['RESULTS_FOLDER'], 'group_reports')
    os.makedirs(group_dir, exist_ok=True)
    report_path = os.path.join(group_dir, f'{now}_{title.replace(" ", "_")}.md')
    with open(report_path, 'w') as f:
        f.write(report)

    return jsonify({'report': report, 'path': report_path})

@app.route('/results/<case_id>/figures/<filename>')
def serve_figure(case_id, filename):
    figures_dir = os.path.join(get_results_dir(case_id), 'figures')
    return send_from_directory(figures_dir, filename)

@app.route('/results/<case_id>/3d-mpm-data')
def serve_3d_mpm_data(case_id):
    """Serve the pre-built MPM continuum payload (AM spheres + SE plastic-continuum
    surface mesh + mpm_metrics), in the SAME schema the DEM viewer already renders.
    Built off-line by scripts/mpm_webapp_payload.py and dropped into
    results/<case_id>/mpm_payload.json.  ?state=seed swaps in the loose pre-compaction
    SE surface (before/after view)."""
    results_dir = get_results_dir(case_id)
    payload_path = os.path.join(results_dir, 'mpm_payload.json')
    if not os.path.exists(payload_path):
        return jsonify({'error': 'No MPM payload for this case', 'kind': 'mpm', 'available': False}), 404
    with open(payload_path) as f:
        payload = json.load(f)
    if request.args.get('state') == 'seed' and payload.get('seed_mesh_triangles'):
        payload['mesh_triangles'] = payload['seed_mesh_triangles']     # before/after swap
    payload.pop('seed_mesh_triangles', None)                            # ship only the active mesh
    return jsonify(payload)


def _rint_anchor_pair(key):
    """R_int 시나리오 (pristine, cycled) Ω·cm² — 정본 docs/data/rint_eis_anchors.csv에서 읽음
    (scripts/rint_cycle_traj.load_scenario 재사용 = 단일 출처).  CSV/키 불가 시 2026-07-21 스냅샷
    fallback.  ⚠ load_scenario는 SystemExit를 던지므로 Exception만 잡으면 앱이 죽음."""
    if key not in ('sbe', 'dbe', 'csus', 'sus'):  # fallback dict에 없는 키가 CSV-실패 경로에서
        raise ValueError(f'unknown R_int scenario key: {key!r}')   # KeyError 500 되던 것 조기 차단
    try:
        import sys as _s
        _sd = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'scripts')
        if _sd not in _s.path:
            _s.path.insert(0, _sd)
        from rint_cycle_traj import load_scenario
        r0, rc, _nt, _pr = load_scenario(key)
        return float(r0), float(rc)
    except (Exception, SystemExit):
        return {'sbe': (18.0, 110.0), 'dbe': (12.0, 46.0), 'csus': (10.0, 30.0),
                'sus': (50.0, 150.0)}[key]               # 이종기술 SUS = 실측 50 / 문헌투영 150 (SC √N)


@app.route('/rint-anchors')
def rint_anchors():
    """kit-gen UI 힌트 — 정본 anchors CSV의 시나리오 (pristine, cycled) R_int Ω·cm² (단일 출처)."""
    return jsonify({k: dict(zip(('pristine', 'cycled'), _rint_anchor_pair(k)))
                    for k in ('sbe', 'dbe', 'csus', 'sus')})


# ── ★ 운전조건 축 (온도 · 구동 스택압) — docs/temp_pressure_capability.md ──────────────────
#    두 축 모두 "미지정 = 현행" 이 절대 규약이다: &tempc=/&pop= 를 안 주면 킷 방출물은 예전과
#    **바이트 동일**하고, 이 블록은 코드 경로에 들어오지도 않는다.
#    ⚠ 온도는 σ_ion(SE) 하나만 움직인다 (Kraft 2017 σ·T Arrhenius, T_ref=25 °C 규약).
#      i0/R_ct · D_s · OCP dU/dT · σ_e · κ · SE 경도 H/σ_y 는 앵커가 없어(§F1) 25 °C 상수로
#      남는다 → **전-물리 온도 스윕이 아니다**.  UI 경고( #kit-op-warn )가 이 사실을 화면에 적는다.
def _se_material():
    """scripts/se_material.py (σ_grain + 온도 규약 단일 출처) 지연 임포트."""
    import sys as _s
    _sd = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'scripts')
    if _sd not in _s.path:
        _s.path.insert(0, _sd)
    import se_material
    return se_material


def _tau_flux():
    """scripts/tau_flux.py (τ 소비처 공용 도우미 · TAU-03) 지연 임포트 — 경로는 `_se_material()` 과 같다."""
    _se_material()
    import tau_flux
    return tau_flux


def _sigma_grain_mS_cm(metrics=None):
    """σ_grain [mS/cm] — 이 파일에서 파생량(σ_Bruggeman, τ_Laplace)을 만들 때 쓰는 단 하나의 값.

    ★ 2026-07-28 적대검증(담당 C-1) 수정: 이 파일에는 bare `3.0` 이 7곳 박혀 있었다
    (`σ_brug = 3.0 × sigma_ratio` ×3, `SIGMA_GRAIN_MS = 3.0` ×2, MD 리포트 ×2 — 검증이 지목한
    `:2418`/`:2550` 은 그중 둘이고, **7곳 전부가 살아있는 Flask 요청 경로**다).  즉
    `se_material.py` 가 자기 헤더에서 주장하는 "SINGLE SOURCE OF TRUTH" 가 webapp 에서는
    성립하지 않았다.  이제 전부 이 함수를 통한다 (잔존 범위는 docs §9-2 인벤토리 참조).

    ★ 온도 정합이 핵심이다.  τ_Lap_eff = √(φ_SE·σ_grain/σ_full) 은 σ_grain 과 σ_full 이 **같은
    온도**일 때만 옳다.  런이 `--temp-c` 로 풀렸다면 σ_full 은 Arrhenius 로 커져 있는데 여기서
    25 °C 상수 3.0 을 쓰면 τ 가 √factor 배 (60 °C 면 ×0.46) 만큼 **조용히 틀린다.**  그래서 런이
    남긴 provenance(= se_material.provenance) 의 `sigma_ion_T_factor` 를 그대로 따라간다.

    ★ 기본값 불변: T 를 안 준 런(=현존 전 코퍼스)은 provenance 가 없거나 factor 가 **정확히 1.0**
    이므로 `3.0 * 1.0` → bitwise 3.0.  `sigma_grain_S_cm` 폴백도 3.0e-3 이면 곱셈을 아예 하지 않고
    상수를 돌려준다(0.003*1000 = 3.0000000000000004 라 bitwise 가 깨지기 때문).
    """
    return _sigma_grain_context(metrics)[0]


def _sigma_grain_context(metrics=None):
    """(σ_grain [mS/cm], mixed_T_note|None) — 값과 "왜 이 값인가" 를 함께 돌려준다.

    ★ 10-04 (TAU-03 · 1저자 비준 *"권고대로"*): 판정 규칙 전문은 `scripts/se_material.sigma_grain_context` 로 옮겼다 —
      등급 τ 축 · COMSOL 2D 내보내기 · regime DB 도 **같은 짝 σ₀** 를 쓴다 (옛 셋은 3.0 고정 — L4-04).  여기는 그것을
      그대로 돌려준다 (값 · 경고 같음 — `webapp/test_tau_grade_unify.py` W1).  기본값 불변: 온도 키 없는 런 = bitwise 3.0.
    """
    return _se_material().sigma_grain_context(metrics)


# 킷 run_mpm.sh 안의 STEP3(σ) 호출 = 온도를 주입할 유일한 지점.  생성기(scripts/mpm_input_from_case.py)
# 는 다른 에이전트 담당이라 --temp-c 인자를 갖지 않으므로, webapp 이 생성 직후 이 한 줄에 플래그를
# 덧붙인다.  마커가 정확히 1회가 아니면 **조용히 무시하지 않고 500 으로 실패**한다 (침묵 no-op 금지).
_KIT_STEP3_CALL = 'python3 "$SCR/mpm_webapp_payload.py" \\\n'


def _kit_apply_temperature(tmp, t_c, ea_ev):
    """킷에 운전 온도를 굽는다 — run_mpm.sh 의 STEP3 σ 호출에 --temp-c/--ea-ion-ev 를 주입하고
    mpm_input.json 에 temperature_provenance 를 남긴다.  실패 시 RuntimeError (호출부가 500)."""
    se_material = _se_material()
    rp = os.path.join(tmp, 'run_mpm.sh')
    if not os.path.exists(rp):
        raise RuntimeError('run_mpm.sh 없음 — 킷 생성기 산출물 구조가 바뀜')
    src = open(rp).read()
    if src.count(_KIT_STEP3_CALL) != 1:
        raise RuntimeError('run_mpm.sh 의 STEP3(payload) 호출 마커를 찾지 못함 — 생성기가 바뀌었으니 '
                           'webapp/app.py _KIT_STEP3_CALL 을 갱신해야 한다 (온도 주입 침묵실패 방지)')
    flags = f' --temp-c {t_c:g}' + (f' --ea-ion-ev {ea_ev:g}' if ea_ev is not None else '')
    note = (f'# ★ 운전 온도 {t_c:g} °C (webapp &tempc=) — σ_ion(SE) 은 Kraft-2017 σ·T Arrhenius,\n'
            f'#   i0 는 kim2025 R_ct(T) 앵커로 스케일 (STEP4 에 --temp-k {t_c + 273.15:g} '
            f'--i0-temp-scale 을 **한 쌍으로** 주입 — 한쪽만 주면 부호역전/거짓라벨).\n'
            f'#   D_s/OCP dU/dT/σ_e/κ/SE-경도는 앵커 없어 25 °C 상수 → 전-물리 온도 스윕 아님 '
            f'(docs/temp_pressure_capability.md §3).  Eₐ 는 밴드 0.29/0.41/0.46 eV 를 쓸어 보고할 것.\n')
    src = src.replace(
        _KIT_STEP3_CALL, note + _KIT_STEP3_CALL.replace(' \\\n', flags + ' \\\n'))
    # ── ★ 2026-07-29: STEP4 에도 온도를 굽는다 ──────────────────────────────────────────────
    #   이전에는 STEP3(σ 그리드)에만 --temp-c 를 넣었다.  그러면 그리드는 60 °C σ_ion 인데
    #   step4_dyn 은 기본 --temp-k 298.15 로 돌아가고, T1-d 가드가 GRID_T_MISMATCH 로
    #   **첫 STEP4 스텝에서 hard-fail** 한다 (실제 킷으로 재현 확인).  가드는 옳다 — 60 °C σ 위에서
    #   25 °C 반응속도를 돌리면 조용히 틀리니까.  틀린 건 킷이 그 짝을 안 맞춰준 것이었다.
    #   ⚠ (옛 주석 정정 2026-07-30) i0 는 앵커가 **있다** — kim2025 R_ct(T).  D_s/OCP 만 미앵커라
    #     이 런은 **"σ_ion 만 60 °C" 인 혼합 상태**다.  플래그는 그 사실을 승인하는 것이고,
    #     산출물에는 PARTIAL_sigma_ion_only@<T>C 로 박힌다 — 전-물리 온도 스윕이 아니다.
    _S4_CALL = 'python3 "$SCR/step4_dyn.py" --grid step4_grid.npz \\\n'
    _n_s4 = src.count(_S4_CALL)
    import sys as _s3
    _sd3 = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'scripts')
    if _sd3 not in _s3.path:
        _s3.path.insert(0, _sd3)
    import cam_kinetics as _ck
    _i0f = _ck.i0_temperature_factor(t_c, ea_ev if ea_ev else None)
    if _n_s4:
        # ★★ 규약 이력 (중요 — 되돌리지 말 것) ★★
        #   [옛 규약] --temp-k 를 **굽지 않았다** (§3-3① 부호역전).  Kinetics.T 는 BV 지수의
        #     f=F/(RT) 를 바꾸는데 i0 가 25 °C 상수로 남으면 T 를 올릴수록 같은 전류에 필요한
        #     η_ct 가 **커진다** — 실제 R_ct 는 30→60 °C 에 4.28× **감소**하므로 정확히 반대다.
        #     "온도를 반영했다는 인상을 주면서 반대 답을 내는 것" 이 가장 나쁜 실패라, 킷은
        #     kinetics 를 25 °C 로 두고 그리드 불일치만 --allow-grid-t-mismatch 로 승인했다.
        #   [HIGH-4, 2026-07-30] 그 결과 프로덕션 경로엔 i0(T) 가 아예 없었다 → --i0-temp-scale 추가.
        #   [자체검증 정정, 2026-07-30] ★그 수정이 반쪽이었다★ — --i0-temp-scale 은 **--temp-k 를
        #     읽어** 배수를 만든다.  --temp-k 를 기본(298.15 K)으로 둔 채 플래그만 주면 배수는
        #     **정확히 1.0** 인데 배너·provenance 는 ×6.25 를 광고하고 npz 엔
        #     kinetics_T_scaling=I0_ARRHENIUS_kim2025 가 찍힌다 = 새 거짓 진술.
        #   ⇒ **i0 앵커가 생긴 지금은 --temp-k 를 굽는 것이 옳다.**  옛 금지 사유(부호역전)는
        #     i0 가 미앵커일 때만 성립했고, --i0-temp-scale 과 **함께** 주면 부호역전이 해소된다
        #     (step4_dyn selftest A5: η_ct 60 °C 93.4 → 26.6 mV).  두 플래그는 **한 쌍**이다.
        #   ⇒ --allow-grid-t-mismatch 는 **뺀다**: σ_ion 도 kinetics 도 같은 t_c 라 혼합이 아니다.
        #     남겨두면 STEP3 가 --temp-c 를 못 구운 경우의 진짜 불일치까지 조용히 통과시킨다.
        src = src.replace(_S4_CALL,
                          _S4_CALL + f'    --temp-k {t_c + 273.15:g} --i0-temp-scale \\\n')
        src = src.replace('echo "[run_mpm] STEP4 솔버:',
                          f'echo "[run_mpm] ★ STEP4 온도: σ_ion = 그리드의 {t_c:g} °C · '
                          f'i0 = kim2025 R_ct(T) 앵커로 스케일(--temp-k {t_c + 273.15:g} '
                          f'--i0-temp-scale, x{_i0f:.3f}) · BV 열전압 f=F/RT 도 {t_c:g} °C. '
                          f'D_s/OCP dU/dT/sigma_e/kappa 는 앵커 없어 25 °C 상수 = PARTIAL. '
                          f'--temp-k 는 --i0-temp-scale 과 **한 쌍**이다 — 단독으로 주면 '
                          f'부호역전(§3-3①). 코팅계는 Ea 가 다름(kim2025 LNO 비-Arrhenius)"\n'
                          f'echo "[run_mpm] STEP4 솔버:', 1)
    open(rp, 'w').write(src)
    pj = os.path.join(tmp, 'mpm_input.json')
    if not os.path.exists(pj):
        raise RuntimeError('mpm_input.json 없음 — provenance 를 남길 수 없음')
    prov = json.load(open(pj))
    tp = se_material.provenance(t_c, ea_ev)
    tp['applied_to'] = ['run_mpm.sh: mpm_webapp_payload.py --temp-c '
                        '(STEP3 σ_ion 복셀 솔브 + step4_grid.npz σ 테이블)',
                        f'run_mpm.sh: step4_dyn.py --temp-k {t_c + 273.15:g} --i0-temp-scale '
                        f'({_n_s4} 개 STEP4 호출) — σ_ion 은 그리드의 {t_c:g} °C, '
                        f'i0 는 kim2025 R_ct(T) 앵커로 ×{_i0f:.4f} (RT 전인자 포함), '
                        f'BV 열전압 f=F/RT 도 {t_c:g} °C.  ★두 플래그는 **한 쌍**이다: '
                        f'--temp-k 단독 = 부호역전(§3-3①), --i0-temp-scale 단독 = 배수 1.0 인데 '
                        f'kinetics_T_scaling 만 찍히는 거짓 라벨.  '
                        f'⚠코팅계 Eₐ 는 다름(kim2025 LNO 비-Arrhenius — 앵커는 uncoated)']
    tp['not_applied_to'] = {
        'STEP1/2 MPM 압밀': 'SE 경도 H(T)/σ_y(T) 앵커 없음 (§F1) → 형상은 25 °C 값',
        'STEP4 kinetics (D_s/OCP만)': 'D_s(T) / OCP dU/dT 앵커 없음 (§F1) → 25 °C 상수.  '
                        '★i0 와 BV 열전압은 예외 — kim2025 R_ct(T) 앵커가 있어 '
                        '--temp-k + --i0-temp-scale 한 쌍으로 반영된다 '
                        '(i0 앵커가 생기기 전에는 --temp-k 를 굽지 않았다: f=F/RT 만 움직이면 '
                        '반응 과전압 부호가 실험과 반대, §3-3①)',
        'σ_e / κ': 'ohmic 은 T-무관 (Reisacher, 정성) — 상수가 오히려 정합',
        'STEP5 열화율': 'Arrhenius 앵커 0건 (§F1) — Joule v2 는 Eₐ-free 유지',
    }
    tp['injected_by'] = 'webapp/app.py mpm_input_package (&tempc=)'
    prov['temperature_provenance'] = tp
    json.dump(prov, open(pj, 'w'), indent=2)
    return tp


@app.route('/results/<case_id>/mpm-input')
def mpm_input_package(case_id):
    """[MPM input 변환]: build the per-case MPM input (am/se scaffolds + run_mpm.sh +
    provenance) from the case's atoms.csv and return it as a zip to run on a GPU box."""
    import subprocess
    import tempfile
    import zipfile
    import io
    import shutil
    results_dir = get_results_dir(case_id)
    if not os.path.exists(os.path.join(results_dir, 'atoms.csv')):
        return jsonify({'error': 'no atoms.csv for this case'}), 404
    repo = os.path.dirname(os.path.dirname(__file__))
    gen = os.path.join(repo, 'scripts', 'mpm_input_from_case.py')
    tmp = tempfile.mkdtemp()
    # the case's type map decides which atom type is SE (NOT always type 3)
    tmap = ''
    meta_p = os.path.join(get_case_dir(case_id), 'meta.json')
    if os.path.exists(meta_p):
        try:
            tmap = (json.load(open(meta_p)) or {}).get('type_map', '')
        except Exception:
            tmap = ''
    # ★ F-18: bare 'python3' 은 Windows 에서 없어서 이 route 가 500 이었다 (Codex 5회차 실측
    #   500 → 200).  sys.executable = **지금 webapp 을 돌리는 인터프리터** 라 플랫폼 무관하고,
    #   venv 도 자동으로 맞는다.  ⚠ 리눅스에서는 bare python3 가 우연히 있어서 200 이 나오므로
    #   회귀는 HTTP 코드가 아니라 **argv[0]** 을 봐야 한다 (Codex 지적).
    cmd = [sys.executable, gen, '--results', results_dir, '--case', case_id, '--out', tmp]
    if tmap:
        cmd += ['--type-map', tmap]
    # optional conductive-additive recipe baked into run_mpm.sh (첨가제 적용 section)
    def _addf(name):
        try:
            return max(0.0, min(10.0, float(request.args.get(name, 0.0))))
        except ValueError:
            return 0.0
    _vg, _sp, _pt, _sd = _addf('vgcf'), _addf('superp'), _addf('ptfe'), _addf('sdcp')
    # VGCF + Super P are both conductive carbon → mutually exclusive.
    if _vg > 0 and _sp > 0:
        shutil.rmtree(tmp, ignore_errors=True)
        return jsonify({'error': 'VGCF와 Super P는 함께 사용 불가 — 도전재는 하나만 '
                                 '(VGCF/Super P/PTFE/VGCF+PTFE/Super P+PTFE)'}), 400
    recipe = _add_recipe_str(_vg, _sp, _pt, _sd)
    mixing = request.args.get('mixing', 'thinky')
    if mixing not in ('ballmill', 'thinky', 'handmix'):
        mixing = 'thinky'
    if recipe:
        cmd += ['--add-recipe', recipe, '--mixing', mixing]
    # STEP3 collector selection.  R_int is an (ELECTRODE, collector) PAIR property — the Fig6e
    # anchors are (SBE,bare)=110 / (DBE,bare)=46 / (DBE,C-SUS)=30 Ω·cm² (post-cycling).  The UI
    # picks only the COLLECTOR; the electrode side is what the recipe already is (SDCP in the
    # recipe = DBE-class bottom interface).  (SBE,C-SUS) was not measured → DBE-anchored proxy,
    # labelled.  Every preset is still computed; this tags metrics.step3.collector.selected.
    _coll = request.args.get('collector', '')
    _dbe = _sd > 0                                       # recipe contains SDCP → DBE-class electrode
    _scn = ''                                            # anchors CSV scenario key (단일 출처)
    if _coll == 'bare':
        _scn = 'dbe' if _dbe else 'sbe'
        _rint = _rint_anchor_pair(_scn)[1]               # cycled (aged 민감도 — payload가 pristine 병기)
        _cname = 'bare_Al+DBE_electrode' if _dbe else 'bare_Al+SBE_electrode'
    elif _coll == 'csus':
        _scn = 'csus'
        _rint = _rint_anchor_pair('csus')[1]
        _cname = 'C-SUS_primer+DBE' if _dbe else 'C-SUS_primer+SBE(proxy_DBE-anchored)'
    elif _coll == 'sus':                                 # bare SUS (무코팅) — 추정 reference (미측정)
        _scn = 'sus'
        _rint = _rint_anchor_pair('sus')[1]              # cycled 추정 60 (pristine 20 병기); 밴드 CSV note
        _cname = 'SUS_bare_estimated'                    # shell-safe token (no space/paren)
    elif _coll == 'ideal':
        _rint, _cname = 0.0, 'ideal'
    else:
        _rint, _cname = -1.0, ''
    if _rint >= 0.0:
        cmd += ['--collector-rint', str(_rint), '--collector-name', _cname]
        if _scn:
            cmd += ['--collector-scenario', _scn]
    # STEP3 voxel resolution (µm).  ONLY the σ solve grid — NOT the MPM compaction (n_grid) nor the
    # porosity/thickness/coverage/econn (those are unchanged by vox).  Finer = neck/SDCP-channel detail
    # for the current-density FIELD figure; σ_e/σ_ion/R_geom can shift slightly (finite-volume grid
    # dependence).  Whitelisted so the UI can't request a runaway dof (∝1/vox³).
    _vox = request.args.get('vox', '0.4')
    if _vox not in ('0.4', '0.25', '0.2'):
        _vox = '0.4'
    cmd += ['--step3-vox', _vox]
    # ── ★ 운전조건 (미지정 = 현행, 방출물 바이트 동일) ─────────────────────────────────────
    #   &tempc= 운전 온도 [°C]  → 킷 STEP3 σ 호출에 --temp-c 주입 (아래 subprocess 성공 후)
    #   &eaion= 이온 Eₐ [eV]    → 밴드 스윕용 (0.29/0.41/0.46); 온도 없이 단독 지정은 무의미 → 400
    #   &pop=   구동 스택압 [MPa] → 생성기 --op-pressure-mpa (A-1 앵커를 2단 제작→구동으로)
    def _opnum(name, lo, hi, unit):
        _raw = (request.args.get(name, '') or '').strip()
        if not _raw:
            return None, None
        try:
            _v = float(_raw)
        except (ValueError, TypeError):
            return None, f'&{name}= 값이 숫자가 아님: {_raw!r}'
        if not (lo <= _v <= hi):
            return None, f'&{name}= 는 {lo:g}~{hi:g} {unit} 범위여야 함 (got {_v:g})'
        return _v, None
    _tempc, _te1 = _opnum('tempc', -20.0, 200.0, '°C')
    _eaion, _te2 = _opnum('eaion', 0.10, 1.00, 'eV')
    _oppress, _te3 = _opnum('pop', 0.1, 2000.0, 'MPa')
    _terr = next((e for e in (_te1, _te2, _te3) if e), None)
    if _terr is None and _eaion is not None and _tempc is None:
        _terr = '&eaion= (이온 Eₐ) 는 &tempc= 와 함께만 의미가 있음 — 온도를 먼저 지정하세요'
    if _terr:
        shutil.rmtree(tmp, ignore_errors=True)
        return jsonify({'error': _terr}), 400
    if _oppress is not None:
        cmd += ['--op-pressure-mpa', f'{_oppress:g}']
    # STEP4 체크박스 (중복 선택 가능): &step4=0.5,1 → run_mpm.sh가 payload 후 각 rate를
    # 순차 자동 실행 (미선택 = step4_grid.npz export까지만 — 나중에 step4_only.sh로 재개).
    def _rates_of(name):
        out = []
        for _tok in request.args.get(name, '').split(','):
            _tok = _tok.strip()
            if _tok:
                try:
                    _v = float(_tok)
                    if 0.02 <= _v <= 5.0 and _v not in out:
                        out.append(_v)
                except ValueError:
                    pass
        return out
    _s4_clean = _rates_of('step4')
    _s4chg_clean = _rates_of('step4chg')                # 충전(CCCV) 체크박스
    # ★Zive 스케줄 (&s4sched=JSON) — 지정 시 crates/charge 대신 순서대로 실행 (charge-first, per-step 컷오프).
    #   crates/charge 체크박스와 동시 지정 시 스케줄 우선 (kit이 s4_sched 있으면 그걸로 시퀀스 생성).
    _s4sched = request.args.get('s4sched', '')
    if _s4sched:
        import json as _json
        try:
            _sj = _json.loads(_s4sched)
            if isinstance(_sj, list) and _sj:
                cmd += ['--step4-sched', _json.dumps(_sj, separators=(',', ':'), ensure_ascii=True)]
            else:
                _s4sched = ''
        except Exception:
            _s4sched = ''                               # 파싱 실패 → 스케줄 무시 (체크박스 경로 유지)
    # ★STEP4 grid까지만 (&s4grid=1): step4_grid.npz 만 만들고 step4_dyn(v2) 스킵 — C-rate/충전/스케줄 무시
    _s4grid = request.args.get('s4grid', '') in ('1', 'true', 'yes', 'on')
    if _s4grid:
        cmd.append('--step4-grid-only')
        _s4_clean, _s4chg_clean, _s4sched = [], [], ''       # 아래 컷오프/R_int 주입 게이트도 함께 끔
    # ★s4cap 은 게이트 밖에서 먼저 읽는다 — 옛 구조는 STEP4 미선택 + cap 셀렉트 조합에서 태그 블록의
    #   _s4cap 참조가 NameError 500 (코드리뷰 chain#10, 기존 버그).  cmd 주입은 여전히 게이트 안.
    _s4cap = request.args.get('s4cap', '')
    if _s4_clean and not _s4sched:
        cmd += ['--step4-crates', ','.join(f'{v:g}' for v in _s4_clean)]
    if _s4chg_clean and not _s4sched:
        cmd += ['--step4-charge', ','.join(f'{v:g}' for v in _s4chg_clean)]

    def _cut(name, default, lo, hi):                    # 컷오프 스케줄 (화이트리스트 클램프)
        try:
            v = float(request.args.get(name, default))
            return min(max(v, lo), hi)
        except ValueError:
            return default
    if _s4_clean or _s4chg_clean or _s4sched:           # 컷오프·R_int·poly/SC는 STEP4 선택(또는 스케줄) 시 주입
        _vmin = _cut('s4vmin', 3.0, 1.5, 4.0)
        _vmax = _cut('s4vmax', 4.5, 3.5, 4.8)
        _icut = _cut('s4icut', 0.05, 0.01, 2.0)   # 절대 C (충전 rate와 독립) — 고율 충전의 '절반 종지' 허용 위해 2.0까지
        cmd += ['--step4-vmin', f'{_vmin:g}', '--step4-vmax', f'{_vmax:g}', '--step4-icut', f'{_icut:g}']
        # 방전끝 x100: UI 필드 제거됨 → 기본은 킷 생성기(mpm_input_from_case --step4-x100)의
        # 0.9084(NMC811 vs-Li GITT 실측 방전끝).  URL에 &s4x100= 를 주면 그때만 오버라이드(파워유저용).
        _x100 = request.args.get('s4x100', '')
        if _x100:
            try:
                cmd += ['--step4-x100', f'{max(0.85, min(0.99, float(_x100))):g}']
            except (ValueError, TypeError):
                pass
        # ★풀셀 축 (A11/R_int Phase 1): &s4rint= → STEP4 직렬 R_int.  기본 없음 = 전극-내부 R_int=0.
        #   숫자(Ω·cm²) 또는 키워드 'pristine'/'cycled' — 키워드는 선택된 collector+전극(SBE/DBE)에
        #   맞는 시나리오 값을 정본 anchors CSV에서 자동 해석 (예: &collector=bare + SDCP 레시피 +
        #   &s4rint=pristine → DBE bare-Al pristine 12).  collector 미선택 시 키워드는 무시(어느
        #   시나리오인지 모호 — 침묵 기본값 금지).  음수/비수치는 무시.
        _s4r = request.args.get('s4rint', '')
        if _s4r in ('pristine', 'cycled'):
            if _scn:
                _pr_v, _cy_v = _rint_anchor_pair(_scn)
                cmd += ['--step4-r-int', f'{(_pr_v if _s4r == "pristine" else _cy_v):g}']
        elif _s4r:
            try:
                _s4rv = float(_s4r)
                if _s4rv >= 0.0:
                    cmd += ['--step4-r-int', f'{_s4rv:g}']
            except (ValueError, TypeError):
                pass
        # ★STEP4 솔버 σ-대비 cap (&s4cap=) — near-null 수렴정체 완화 (docs/step4_bottleneck_analysis_20260727).
        #   화이트리스트만 허용(임의값 금지): 0=OFF 기본 · 200 권장(CG ×5.2, σ_eff −7.8%) · 1000/2000=보수적.
        #   킷은 이 값을 MPM_S4_CONTRAST_CAP 기본값으로 굽고, 런타임 env 가 다시 override 가능.
        if _s4cap in ('200', '1000', '2000'):
            cmd += ['--step4-solver-cap', _s4cap]
        # ★v2 chaining (&s4chain=1, 스케줄 전용) — 각 스텝이 직전 스텝 끝 셸-SOC에서 시작(연속
        #   사이클, Loop 반복도 상태 누적) + Rest 는 실제 I=0 완화 런.  미지정 = v1 독립런.
        if _s4sched and request.args.get('s4chain', '') in ('1', 'true', 'on'):
            cmd += ['--step4-chain']
    # ★2026-08-04 게이트 탈출: poly/SC 분리는 STEP4-v2 전용이 아니다 — scaffold 의
    #   AM_P/AM_S **라벨**을 정하므로 MPM·mpm_metrics·grid 에도 영향.  위 게이트("STEP4 선택
    #   시 주입")에 묶여 있어 s4grid=1(grid까지만)일 때 체크박스·URL 파라미터가 **조용히
    #   무시**됐고, 생성기가 레거시 경로로 떨어져 0:10 의 2µm 입자 4587 개를 전부 AM_P 로
    #   찍었다 (실측 mpm_metrics: coverage_AM_P=76.6 / AM_S=0.0).  컷오프·R_int 는 진짜
    #   v2 전용이라 게이트 안에 남긴다.
    # ★bimodal poly/SC 전기화학 분리 (파워유저 URL, s4x100 문법): &s4dsp=&s4dss= (D_s [m²/s])
    #   &s4i0p=&s4i0s= (i0 [A/m²]) &s4split= (반경 문턱 µm, 기본 3.5).  반쪽 지정은 400으로
    #   명시 거부(생성기 ap.error를 500 stderr로 흘리지 않고 앞단에서 — 침묵/불명확 실패 금지).
    #   값 가이드: docs/ncm_sc_poly_electrochem_anchors.md (i0 분리값은 문헌 부재 — 스윕 전용).
    def _fpos(name):
        _t = request.args.get(name, '').strip()
        if not _t:
            return None, None
        try:
            _v = float(_t)
        except (ValueError, TypeError):
            return None, f'&{name}= 값이 숫자가 아님: {_t!r}'
        return (_v, None) if _v > 0 else (None, f'&{name}= 는 > 0 이어야 함: {_t}')
    _dsp, _e1 = _fpos('s4dsp'); _dss, _e2 = _fpos('s4dss')
    _i0p, _e3 = _fpos('s4i0p'); _i0s, _e4 = _fpos('s4i0s')
    _spl, _e5 = _fpos('s4split')
    _err = next((e for e in (_e1, _e2, _e3, _e4, _e5) if e), None)
    if _err:
        shutil.rmtree(tmp, ignore_errors=True)
        return jsonify({'error': _err}), 400
    if (_dsp is None) != (_dss is None) or (_i0p is None) != (_i0s is None):
        shutil.rmtree(tmp, ignore_errors=True)
        return jsonify({'error': 's4dsp/s4dss (또는 s4i0p/s4i0s)는 쌍으로만 — 반쪽 지정 거부'}), 400
    if _dsp is not None:
        cmd += ['--step4-ds-poly', f'{_dsp:g}', '--step4-ds-sc', f'{_dss:g}']
    if _i0p is not None:
        cmd += ['--step4-i0-poly', f'{_i0p:g}', '--step4-i0-sc', f'{_i0s:g}']
    if _spl is not None and (_dsp is not None or _i0p is not None):
        cmd += ['--step4-am-split-um', f'{_spl:g}']
    # ★문헌 프리셋 (&s4pp=1, UI 체크박스): 정본 docs/data/sc_poly_preset.csv를 생성기가 해석
    #   (D_s poly 4e-15 Chen2020 / SC 3e-15 Trevisanello 밴드 기하중앙; i0 분리 부재 확정 →
    #   공유).  명시 s4dsp와 동시 지정은 생성기가 모호-거부 → 여기서도 앞단 400.
    if request.args.get('s4pp', '') in ('1', 'true', 'on'):
        if _dsp is not None or _i0p is not None:
            shutil.rmtree(tmp, ignore_errors=True)
            return jsonify({'error': 's4pp(프리셋)와 명시 s4dsp/s4i0p 동시 지정 불가 — 하나만'}), 400
        cmd += ['--step4-sc-poly-preset']

    try:
        subprocess.run(cmd, check=True, cwd=repo, capture_output=True, text=True)
    except subprocess.CalledProcessError as e:
        shutil.rmtree(tmp, ignore_errors=True)
        return jsonify({'error': 'generation failed', 'detail': (e.stderr or '')[-500:]}), 500
    if _tempc is not None:                              # 생성 직후 온도 주입 (미지정이면 이 줄도 안 탄다)
        try:
            _kit_apply_temperature(tmp, _tempc, _eaion)
        except Exception as e:                          # 침묵 no-op 금지 — 온도가 안 구워졌으면 킷을 주지 않는다
            shutil.rmtree(tmp, ignore_errors=True)
            return jsonify({'error': f'온도 배선 실패 — 킷을 만들지 않았습니다: {e}'}), 500
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, 'w', zipfile.ZIP_DEFLATED) as z:
        for fn in sorted(os.listdir(tmp)):
            z.write(os.path.join(tmp, fn), fn)
    shutil.rmtree(tmp, ignore_errors=True)
    buf.seek(0)
    # filename carries BOTH the recipe and the mixing, so a thinky vs ball-mill zip
    # of the same recipe are distinct files (mixing changes the baked run_mpm.sh).
    # zip 이름 = [A-Za-z0-9._] 만 사용 (자기서술형 재료+값 쌍).  ':'/'-' 구분자는 사용자
    # 환경(브라우저/OS 다운로드 새니타이즈)에서 삭제돼 JS 예측명과 실제 파일명이 계속
    # 어긋났음 (예: VGCF-PTFE-SDCP_2.97-0.495-0.495 → VGCFPTFESDCP_2.970.4950.495).
    _pairs = [('VGCF', _vg), ('SuperP', _sp), ('PTFE', _pt), ('SDCP', _sd)]
    tag = (('_' + '_'.join(f'{k}{v:g}' for k, v in _pairs if v > 0) + '_' + mixing)
           if recipe else '')
    if recipe and _vox != '0.4':                        # finer STEP3 vox → carried into the zip/name
        tag += '_vox' + _vox
    # ★스케줄 지정 시 체크박스 rate 는 킷에 안 들어가므로(위 게이트) 태그에서도 뺀다 —
    #   안 그러면 zip 이름은 '_s40.2C' 인데 내용은 스케줄이라 서로 어긋난다 (감사 L10).
    if _s4sched:
        _s4_clean = _s4chg_clean = []
    if _s4_clean:                                       # STEP4 선택 → zip 이름에 rate 표기
        tag += '_s4' + '_'.join(f'{v:g}C' for v in _s4_clean)
    if _s4chg_clean:
        tag += '_s4chg' + '_'.join(f'{v:g}C' for v in _s4chg_clean)
    if _s4sched:
        tag += '_sched'
        # ★체인 킷은 실행 의미가 다름(연속 사이클) → 독립런 킷과 파일명 구별 (cap 태그와 같은 규약)
        if request.args.get('s4chain', '') in ('1', 'true', 'on'):
            tag += '_chain'
    # ★솔버 cap 은 σ_eff 를 −7.8% 바꾸는 노브 → 같은 이름의 두 킷이 생기지 않게 태그 (감사 M10)
    #   STEP4 솔브가 실제로 있을 때만 (grid-only/미선택 킷엔 cap 이 안 구워짐 → 태그도 없음)
    if _s4cap in ('200', '1000', '2000') and (_s4_clean or _s4chg_clean or _s4sched):
        tag += '_cap' + _s4cap
    # ★poly/SC 크기-분리 프리셋 → run_mpm.sh 가 달라짐(σ_e 재료분류+D_s) → 파일명도 구별.
    #   클라이언트 _addTag 의 '_ppds' 와 반드시 일치 (예전 _sched7step/VGCFPTFESDCP 어긋남 교훈).
    if recipe and request.args.get('s4pp', '') in ('1', 'true', 'on'):
        tag += '_ppds'
    # ★운전조건 태그 — 온도/구동압은 킷 내용을 바꾸는 노브라 같은 이름의 두 킷이 생기면 안 된다.
    #   클라이언트 _tpTag() 와 **정확히** 미러 (순서: _T…C → _Ea… → _op…MPa; VGCFPTFESDCP 사건 교훈).
    if _tempc is not None:
        tag += f'_T{_tempc:g}C' + (f'_Ea{_eaion:g}' if _eaion is not None else '')
    if _oppress is not None:
        tag += f'_op{_oppress:g}MPa'
    return send_file(buf, mimetype='application/zip', as_attachment=True,
                     download_name=f'mpm_input_{case_id}{tag}.zip')


@app.route('/results/<case_id>/mpm-upload', methods=['POST'])
def mpm_upload(case_id):
    """Ingest the MPM result (mpm_payload.json produced on the GPU box) back into the
    case → results/<case_id>/mpm_payload.json, activating the MPM viewer + compare."""
    results_dir = get_results_dir(case_id)
    f = request.files.get('payload')
    if not f:
        return jsonify({'error': 'no payload file (field "payload")'}), 400
    try:
        data = json.load(f.stream)
    except Exception as e:
        return jsonify({'error': f'not valid JSON: {e}'}), 400
    if data.get('kind') != 'mpm' or 'particles' not in data:
        return jsonify({'error': 'not an MPM payload (expected kind=mpm + particles)'}), 400
    with open(os.path.join(results_dir, 'mpm_payload.json'), 'w') as out:
        json.dump(data, out)
    m = data.get('mpm_metrics', {}) or {}
    # ★provenance 승계 — payload 최상위의 temperature_provenance(= se_material.provenance, T1-a)는
    #   mpm_metrics 안에 없다(payload 가 step3 하위와 최상위에만 적는다).  사이드카에 함께 실어야
    #   케이스 페이지 배지가 "이 런이 몇 °C 규약으로 풀렸는지"를 말할 수 있다 (없으면 조용히 25 °C 가정).
    if isinstance(data.get('temperature_provenance'), dict):
        m.setdefault('temperature_provenance', data['temperature_provenance'])
    # compact sidecar → the case page's MPM result table reads this, not the 16 MB payload
    with open(os.path.join(results_dir, 'mpm_metrics.json'), 'w') as mf:
        json.dump(m, mf)
    return jsonify({'ok': True, 'mpm_metrics': m,
                    'porosity_mpm_pct': m.get('porosity_mpm_pct'),
                    'coverage_AM_P_mpm_pct': m.get('coverage_AM_P_mpm_pct'),
                    'n_am': m.get('n_am'), 'se_surface_tris': m.get('se_surface_tris')})


# ── Standalone MPM / 도전재 payload viewer (independent of the DEM case list) ─────────────
#    Upload an mpm_payload.json, view it in 3D, and keep an accumulating saved list — so an MPM
#    result that isn't tied to a known DEM case can still be viewed and compared on its own.
def _mpm_lab_slug(s):
    # Sanitize to a filesystem-safe token.  NO length cap here: this ALSO runs on LOOKUP, where the
    # pid passed in is already "<name-slug>_<uuid6>".  The old [:60] truncation chopped the uuid off
    # for long names (the _vox0.2 name suffix pushed the pid past 60 chars → wrong folder → 404).
    # The length cap now lives at CREATION (upload), on the NAME part only, so the uuid always survives.
    # `.` 는 유지(예: VGCF2.97)하되 연속점 `..` 는 붕괴 → 경로 traversal(부모 디렉토리) 차단.
    return re.sub(r'\.{2,}', '_', re.sub(r'[^A-Za-z0-9_.-]+', '_', str(s or ''))).strip('_') or 'payload'


def _mpm_lab_list():
    root = app.config['MPM_LAB_FOLDER']
    out = []
    if not os.path.isdir(root):
        return out
    for name in os.listdir(root):
        mp = os.path.join(root, name, 'meta.json')
        if os.path.isfile(mp):
            try:
                m = json.load(open(mp))
                m['id'] = name
                out.append(m)
            except Exception:
                pass
    out.sort(key=lambda x: x.get('uploaded_at', ''), reverse=True)  # 순수 시간순(최신 위) — 즐겨찾기 상단고정 제거
    return out


@app.route('/mpm-lab')
def mpm_lab():
    return render_template('mpm_lab.html', items=_mpm_lab_list(), lv=_page_lv('mpm_lab'))


@app.route('/mpm-lab/fav/<pid>', methods=['POST'])
def mpm_lab_fav(pid):
    """★ 즐겨찾기 토글 — meta.json의 fav 불리언; 목록에서 fav 그룹이 상단 고정."""
    mp = os.path.join(app.config['MPM_LAB_FOLDER'], _mpm_lab_slug(pid), 'meta.json')
    if not os.path.isfile(mp):
        return jsonify({'ok': False, 'error': 'payload not found'}), 404
    try:
        m = json.load(open(mp))
        m['fav'] = not m.get('fav')
        _ps.atomic_write_json(mp, m)   # ★ 09-26 원자적 쓰기 (temp→fsync→replace) — 제자리 'w' 는 크래시 때 반쪽을 남겼다
        return jsonify({'ok': True, 'fav': m['fav']})
    except Exception as e:
        return jsonify({'ok': False, 'error': str(e)}), 500


@app.route('/mpm-lab/upload', methods=['POST'])
def mpm_lab_upload():
    f = request.files.get('payload')
    if not f:
        return jsonify({'ok': False, 'error': 'no payload file (field "payload")'}), 400
    try:
        data = json.load(f.stream)
    except Exception as e:
        return jsonify({'ok': False, 'error': f'JSON 파싱 실패: {e}'}), 400
    name = (request.form.get('name') or data.get('case') or 'payload').strip()
    # 등록 로직은 mpm_lab_register.register_local 한 곳 — CLI 훅(원격 결과회수)과 meta 공유.
    try:
        pid, _d, meta = mpm_lab_register.register_local(data, name, app.config['MPM_LAB_FOLDER'])
    except ValueError as e:      # non-mpm payload
        return jsonify({'ok': False, 'error': str(e)}), 400
    meta['id'] = pid
    return jsonify({'ok': True, 'item': meta})


@app.route('/mpm-lab/data/<pid>')
def mpm_lab_data(pid):
    d = os.path.join(app.config['MPM_LAB_FOLDER'], _mpm_lab_slug(pid))
    p = os.path.join(d, 'payload.json')
    if not os.path.isfile(p):
        return jsonify({'error': 'payload not found', 'kind': 'mpm', 'available': False}), 404
    with open(p) as fh:
        payload = json.load(fh)
    if request.args.get('state') == 'seed' and payload.get('seed_mesh_triangles'):
        payload['mesh_triangles'] = payload['seed_mesh_triangles']
    payload.pop('seed_mesh_triangles', None)
    return jsonify(payload)


def _mpm_lab_payload_or_none(pid):
    p = os.path.join(app.config['MPM_LAB_FOLDER'], _mpm_lab_slug(pid), 'payload.json')
    if not os.path.isfile(p):
        return None
    with open(p) as fh:
        return json.load(fh)


def _mech_bins(raw, default=14):
    """Sanitize the ?bins query for the mech-reaction routes — invalid / out-of-range
    (incl. 0 → ZeroDivisionError, negative → IndexError) falls back to the default."""
    try:
        b = int(raw) if raw is not None else default
    except (TypeError, ValueError):
        return default
    return b if 2 <= b <= 200 else default


@app.route('/mpm-lab/mech-reaction/<pid>.png')
def mpm_lab_mech_reaction_png(pid):
    """Server-render the mechanics(SE plastic strain / AM contact-coverage) ↔
    reaction(j_rxn) spatial correlation figure for a saved MPM payload.
    OBSERVATIONAL (no stress→reaction coupling); see scripts/mech_reaction_correlation.py."""
    import sys as _sys
    import io as _io
    _sd = os.path.join(os.path.dirname(__file__), '..', 'scripts')
    if _sd not in _sys.path:
        _sys.path.insert(0, _sd)
    payload = _mpm_lab_payload_or_none(pid)
    if payload is None:
        return ('payload not found', 404)
    _bins = _mech_bins(request.args.get('bins'))
    import matplotlib.pyplot as _plt
    fig = None
    try:
        from mech_reaction_correlation import render_figure
        fig = render_figure(payload, _bins)
        buf = _io.BytesIO()
        fig.savefig(buf, format='png', dpi=150)
    except Exception:
        import traceback
        traceback.print_exc()
        return ('mech-reaction render failed', 500)   # no internal string in body
    finally:
        if fig is not None:
            _plt.close(fig)                            # close on success AND error → no fig leak
    buf.seek(0)
    return send_file(buf, mimetype='image/png', as_attachment=False,
                     download_name=f'mech_reaction_{_mpm_lab_slug(pid)}.png')


@app.route('/mpm-lab/mech-reaction/<pid>.csv')
def mpm_lab_mech_reaction_csv(pid):
    import sys as _sys
    import io as _io
    import csv as _csv
    _sd = os.path.join(os.path.dirname(__file__), '..', 'scripts')
    if _sd not in _sys.path:
        _sys.path.insert(0, _sd)
    payload = _mpm_lab_payload_or_none(pid)
    if payload is None:
        return ('payload not found', 404)
    _bins = _mech_bins(request.args.get('bins'))
    try:
        from mech_reaction_correlation import to_csv_rows, compute
        d = compute(payload, _bins)          # compute ONCE at the requested bins;
        rows = to_csv_rows(payload, _bins)   # header stats + rows now share n_bins
    except Exception:
        import traceback
        traceback.print_exc()
        return ('mech-reaction compute failed', 500)
    buf = _io.StringIO()
    w = _csv.writer(buf)
    w.writerow(['# reaction<->mechanics spatial correlation (OBSERVATIONAL, no stress->reaction coupling)'])
    w.writerow([f'# z-profile jrxn-coverage={d["corr_jrxn_coverage"]} (raw, z-confounded)',
                f'jrxn-strain={d["corr_jrxn_strain"]} (co-location)'])
    w.writerow([f'# reaction~z={d["corr_jrxn_z"]} (ion-limited)',
                f'jrxn-coverage z-controlled={d["corr_jrxn_coverage_partial_z"]}',
                f'within-slice={d["corr_jrxn_coverage_within_slice"]} (GENUINE coverage link)'])
    w.writerows(rows)
    resp = make_response(buf.getvalue())
    resp.headers['Content-Type'] = 'text/csv; charset=utf-8'
    resp.headers['Content-Disposition'] = (
        f'attachment; filename="mech_reaction_{_mpm_lab_slug(pid)}.csv"')
    return resp


@app.route('/mpm-lab/st4/<pid>', methods=['GET', 'POST'])
def mpm_lab_st4(pid):
    """STEP4-v2 viz(step4_viz*.json)를 lab 엔트리에 저장/서빙 — 뷰어가 st4 모드 진입 시
    자동 로드(GET)하고, 피커로 처음 연 파일은 자동 저장(POST)돼 다음부터 수동 선택이
    필요 없다.  엔트리당 1개(최근 저장본)."""
    d = os.path.join(app.config['MPM_LAB_FOLDER'], _mpm_lab_slug(pid))
    p = os.path.join(d, 'st4_viz.json')
    if request.method == 'POST':
        if not os.path.isdir(d):
            return jsonify({'ok': False, 'error': 'entry not found'}), 404
        try:
            data = json.loads(request.get_data(as_text=True))
        except Exception as e:
            return jsonify({'ok': False, 'error': f'JSON 파싱 실패: {e}'}), 400
        if not isinstance(data, dict) or data.get('kind') != 'step4_viz':
            return jsonify({'ok': False, 'error': 'step4_viz 형식이 아님 (kind 확인)'}), 400
        with open(p, 'w') as fh:
            json.dump(data, fh)
        return jsonify({'ok': True, 'size_mb': round(os.path.getsize(p) / 1e6, 1)})
    if not os.path.isfile(p):
        return jsonify({'available': False,          # 200: "아직 저장 안 됨"은 정상 autoload 상태 (404면 브라우저 콘솔 노이즈)
                        'hint': '뷰어 st4 모드에서 📂로 한 번 열면 자동 저장됩니다'}), 200
    return send_file(p, mimetype='application/json')


@app.route('/mpm-lab/gif', methods=['POST'])
def mpm_lab_gif():
    """PNG 프레임 시퀀스(data URL 배열) → 애니메이션 GIF (Pillow).  st4 시간전개
    (3D geometry · 두께방향 프로파일)를 뷰어가 체크포인트별로 캡처해 보내면 여기서 묶어 반환."""
    import base64
    import io
    try:
        from PIL import Image
    except Exception as e:                                    # webapp venv에 Pillow 없을 때
        return jsonify({'ok': False, 'error': f'Pillow 미설치 ({e}) — 🎞 PNG 프레임으로 외부 조립하세요'}), 500
    data = request.get_json(force=True, silent=True) or {}
    frames_b64 = data.get('frames') or []
    fps = float(data.get('fps') or 2) or 2.0
    name = _mpm_lab_slug(data.get('name') or 'st4')
    if not frames_b64:
        return jsonify({'ok': False, 'error': '프레임 없음'}), 400
    imgs = []
    for fb in frames_b64:
        if ',' in fb:
            fb = fb.split(',', 1)[1]                          # "data:image/png;base64," 접두 제거
        im = Image.open(io.BytesIO(base64.b64decode(fb))).convert('RGBA')
        bg = Image.new('RGBA', im.size, (255, 255, 255, 255))    # 투명 배경 → 흰색 합성
        imgs.append(Image.alpha_composite(bg, im).convert('RGB'))
    sz = imgs[0].size                                        # GIF는 프레임 크기 동일 필요 → 첫 프레임에 맞춤
    imgs = [im if im.size == sz else im.resize(sz) for im in imgs]
    buf = io.BytesIO()
    dur = max(20, int(round(1000.0 / max(fps, 0.1))))        # ms/frame
    imgs[0].save(buf, format='GIF', save_all=True, append_images=imgs[1:],
                 duration=dur, loop=0, optimize=True, disposal=2)
    buf.seek(0)
    return send_file(buf, mimetype='image/gif', as_attachment=True,
                     download_name=f'{name}.gif')


@app.route('/mpm-lab/summary/<pid>')
def mpm_lab_summary(pid):
    """Metrics-only fetch for the 요약 button — returns just mpm_metrics (a few KB) so the
    summary doesn't ship the whole multi-MB payload.  Reads the dict cached in meta.json
    (new uploads); falls back to parsing payload.json once for older uploads."""
    d = os.path.join(app.config['MPM_LAB_FOLDER'], _mpm_lab_slug(pid))
    mp = os.path.join(d, 'meta.json')
    if not os.path.isfile(mp):
        return jsonify({'ok': False, 'error': 'not found'}), 404
    meta = json.load(open(mp))
    mm = meta.get('mpm_metrics')
    if mm is None:                                       # pre-cache upload → read it out of the payload once
        pp = os.path.join(d, 'payload.json')
        try:
            mm = (json.load(open(pp)).get('mpm_metrics') or {}) if os.path.isfile(pp) else {}
        except Exception:
            mm = {}
    return jsonify({'ok': True, 'name': meta.get('name', pid),
                    'case': meta.get('source_case', ''), 'mpm_metrics': mm})


@app.route('/mpm-lab/rename/<pid>', methods=['POST'])
def mpm_lab_rename(pid):
    mp = os.path.join(app.config['MPM_LAB_FOLDER'], _mpm_lab_slug(pid), 'meta.json')
    if not os.path.isfile(mp):
        return jsonify({'ok': False, 'error': 'not found'}), 404
    name = ((request.get_json(silent=True) or {}).get('name') if request.is_json
            else request.form.get('name')) or ''
    name = name.strip()
    if not name:
        return jsonify({'ok': False, 'error': 'empty name'}), 400
    m = json.load(open(mp))
    m['name'] = name
    _ps.atomic_write_json(mp, m)   # ★ 09-26 원자적 쓰기 (temp→fsync→replace) — 제자리 'w' 는 크래시 때 반쪽을 남겼다
    return jsonify({'ok': True, 'name': name})


@app.route('/mpm-lab/delete/<pid>', methods=['POST'])
def mpm_lab_delete(pid):
    root = os.path.realpath(app.config['MPM_LAB_FOLDER'])
    d = os.path.realpath(os.path.join(root, _mpm_lab_slug(pid)))
    if os.path.isdir(d) and os.path.dirname(d) == root:     # stay inside the lab folder
        shutil.rmtree(d, ignore_errors=True)
        return jsonify({'ok': True})
    return jsonify({'ok': False, 'error': 'not found'}), 404


@app.route('/results/<case_id>/3d-data')
def serve_3d_data(case_id):
    """Serve particle + percolation data for 3D viewer."""
    import pandas as pd
    results_dir = get_results_dir(case_id)
    case_dir = get_case_dir(case_id)
    meta_file = os.path.join(case_dir, 'meta.json')

    if not os.path.exists(meta_file):
        return jsonify({'error': 'Case not found'}), 404

    with open(meta_file) as f:
        meta = json.load(f)
    scale = meta.get('scale', 1000)
    type_map_str = _type_map_resolve.map_str_from_meta(meta, 'viewer payload')[0]
    type_map = {}
    for item in type_map_str.split(','):
        k, v = item.split(':')
        type_map[int(k)] = v.strip()

    # Load atoms
    atoms_csv = os.path.join(results_dir, 'atoms.csv')
    if not os.path.exists(atoms_csv):
        return jsonify({'error': 'No atom data'}), 404

    # atoms-only flag: no contacts.csv OR full_metrics.has_contacts=False
    contacts_csv = os.path.join(results_dir, 'contacts.csv')
    atoms_only_mode = not os.path.exists(contacts_csv)
    fm_path = os.path.join(results_dir, 'full_metrics.json')
    if os.path.exists(fm_path):
        try:
            with open(fm_path) as f:
                _fm = json.load(f)
            if _fm.get('has_contacts') is False:
                atoms_only_mode = True
        except Exception:
            pass

    df = pd.read_csv(atoms_csv)
    for col in df.columns:
        df[col] = pd.to_numeric(df[col], errors='coerce')

    # Vectorized build (iterrows is ~100x slower and dominates load time on
    # particulate cases with 10^5+ atoms).
    ids = df['id'].astype('int64').tolist()
    ts = df['type'].astype('int64').tolist()
    xs = (df['x'] * scale).round(2).tolist()
    ys = (df['y'] * scale).round(2).tolist()
    zs = (df['z'] * scale).round(2).tolist()
    rs = (df['radius'] * scale).round(2).tolist()
    _tname = {}
    particles = []
    for i in range(len(ids)):
        t = ts[i]
        nm = _tname.get(t)
        if nm is None:
            nm = type_map.get(t, f'T{t}'); _tname[t] = nm
        particles.append({'id': ids[i], 'type': nm,
                          'x': xs[i], 'y': ys[i], 'z': zs[i], 'r': rs[i]})

    # Box bounds — read from input_params.json if available
    _box_x, _box_y = 0.05, 0.05
    _ip_path = os.path.join(results_dir, 'input_params.json')
    if os.path.exists(_ip_path):
        with open(_ip_path) as f:
            _ip = json.load(f)
        _box_x = _ip.get('box_x', 0.05)
        _box_y = _ip.get('box_y', 0.05)
    box = {
        'x_min': 0, 'x_max': round(_box_x * scale, 1),
        'y_min': 0, 'y_max': round(_box_y * scale, 1),
        'z_min': 0,
    }
    # box.z_max = tight fit to actual particles (ignores stale mesh_info plate_z
    # which can drift from the real packed height after DEM re-analysis).
    particle_z_top = max(p['z'] + p['r'] for p in particles) if particles else 0
    mesh_file = os.path.join(results_dir, 'mesh_info.json')
    mesh_triangles = []
    if os.path.exists(mesh_file):
        try:
            with open(mesh_file) as f:
                _mesh_data = json.load(f)
            plate_z_mesh = _mesh_data['plate_z'] * scale
            # Use whichever is smaller — avoids oversized bounding box when
            # mesh_info.plate_z is a stale pre-compaction value
            box['z_max'] = round(min(plate_z_mesh, particle_z_top), 1)
            # Pull triangles (raw sim units) and scale to display μm
            for tri in _mesh_data.get('triangles', []):
                mesh_triangles.append([
                    [round(v[0] * scale, 3), round(v[1] * scale, 3), round(v[2] * scale, 3)]
                    for v in tri
                ])
        except Exception:
            box['z_max'] = round(particle_z_top, 1)
    else:
        box['z_max'] = round(particle_z_top, 1)

    # Percolation data from full_metrics
    percolation = {'top_reachable': [], 'bottom_se': [], 'top_se': []}
    metrics_path = os.path.join(results_dir, 'full_metrics.json')

    # Try to load percolation sets from a saved file
    perc_path = os.path.join(results_dir, 'percolation_sets.json')
    if os.path.exists(perc_path):
        with open(perc_path) as f:
            percolation = json.load(f)

    # Paths (tortuosity sample paths)
    paths = []
    paths_path = os.path.join(results_dir, 'tortuosity_paths.json')
    if os.path.exists(paths_path):
        with open(paths_path) as f:
            paths = json.load(f)

    # SE clusters for click interaction
    clusters = {}
    clusters_path = os.path.join(results_dir, 'se_clusters.json')
    if os.path.exists(clusters_path):
        with open(clusters_path) as f:
            clusters = json.load(f)

    # ── 3D viewer auxiliary data: stress / brittle / cluster classification ──
    # Lightweight recompute over contacts.csv on each request — small CSV
    # (<100k rows typical) so this stays fast (< 200 ms).
    aux = {
        'stress_max': {}, 'dr_max': {},
        'brittle_pairs': [], 'se_stress_pairs': [],
        'am_se_stress_pairs': [],
        'se_states': {}, 'tabor_stats': {}, 'all_se_ids_count': 0,
        'se_engagement': {},
        'cluster_meta': {}, 'cluster_id_per_se': {},
        'coverage_per_am': {}, 'coverage_per_am_source': None,
        # Phase A1/A3/A4 — per-particle fracture aggregates + stress chain
        'particle_max_fpc': {}, 'particle_worst_stage': {},
        'particle_n_brittle': {}, 'particle_worst_partner_brittle': {},
        'particle_worst_pair_type': {},
        'am_p_skeleton': [], 'stress_chain_segments': [],
        # Phase A5+A6 — SE network diagnostics
        'se_percolating': [], 'se_articulation_points': [],
        'se_bottleneck_edges': [], 'se_dead_end_clusters': [],
        'se_n_percolating': 0,
        'se_bn_median_norm': 0, 'se_bn_threshold_norm': 0,
        'se_n_bn_below_threshold': 0,
    }
    try:
        import sys as _sys
        _scripts_dir = os.path.join(os.path.dirname(__file__), '..', 'scripts')
        if _scripts_dir not in _sys.path:
            _sys.path.insert(0, _scripts_dir)
        from viewer3d_data import (
            aggregate_particle_metrics, classify_clusters,
            build_cluster_id_map, build_coverage_map, coverage_map_column,
            compute_se_network_diagnostics,
        )
        # Build atoms_by_id from atoms.csv we already loaded.
        # Include x/y/z so compute_se_network_diagnostics can identify
        # bottom/top SE for percolation boundary.  LIGGGHTS dump always
        # carries these columns; default 0 only as defensive fallback.
        atoms_by_id = {int(r['id']): {
            'type':   int(r['type']),
            'radius': float(r['radius']),
            'x':      float(r['x']) if 'x' in df.columns else 0.0,
            'y':      float(r['y']) if 'y' in df.columns else 0.0,
            'z':      float(r['z']) if 'z' in df.columns else 0.0,
        } for _, r in df.iterrows()}
        if os.path.exists(contacts_csv):
            import time as _t
            # Aux cache — particulate cases with sub-μm SE balloon to
            # 2-3 M contacts; recomputing aux on every page load would
            # be a 60-90 s endpoint.  Cache the aggregate dict on disk
            # under viewer_aux.json keyed by contacts.csv mtime; next
            # load is then instant.
            cache_path = os.path.join(results_dir, 'viewer_aux.json')
            contacts_mtime = os.path.getmtime(contacts_csv)
            cache_valid = False
            if os.path.exists(cache_path):
                try:
                    with open(cache_path) as _cf:
                        cached = json.load(_cf)
                    if cached.get('_contacts_mtime') == contacts_mtime and cached.get('_schema') == 12:   # 12 = 입자별 배위수 (10-06)
                        # Restore every cached key except metadata.  Some
                        # int-keyed dicts (stress_max, dr_max, se_engagement,
                        # particle_max_fpc, particle_n_brittle) need their
                        # JSON-string keys coerced back to int so the
                        # frontend's numeric-key lookups (`engagement[p.id]`)
                        # work.
                        _INT_KEYED = {
                            'stress_max', 'dr_max', 'se_engagement',
                            'particle_max_fpc', 'particle_n_brittle',
                            'particle_worst_stage',
                            'particle_worst_partner_brittle',
                            'particle_worst_pair_type',
                        }
                        for k, v in cached.items():
                            if k.startswith('_'):
                                continue
                            if k in _INT_KEYED and isinstance(v, dict):
                                aux[k] = {int(kk): vv for kk, vv in v.items()}
                            else:
                                aux[k] = v
                        cache_valid = True
                        print(f'  [3d-data aux] cache HIT')
                except (OSError, ValueError, KeyError) as _ce:
                    print(f'  [3d-data aux] cache invalid: {_ce}')

            if not cache_valid:
                _t0 = _t.time()
                contacts_df = pd.read_csv(contacts_csv, low_memory=False)
                _t1 = _t.time()
                n_rows = len(contacts_df)
                print(f'  [3d-data aux] contacts.csv: {n_rows} rows, '
                      f'read in {_t1-_t0:.1f}s')
                # 5 M rows ≈ 2-3 GB peak via to_dict; switching to a
                # streaming itertuples → dict generator drops peak
                # memory to ~200 MB and runs in ~30-90 s on commodity
                # workstations.  Cases above 5 M stay skipped (still
                # very rare — would require sub-100 nm SE).
                if n_rows > 5_000_000:
                    print(f'  [3d-data aux] skipping aggregate '
                          f'(> 5 M rows; out-of-budget)')
                else:
                    _cols = list(contacts_df.columns)
                    def _stream_records(df, cols=_cols):
                        # yield one dict per row — lazy, no upfront
                        # materialisation of 2-3 M dicts in memory.
                        for tup in df.itertuples(index=False, name=None):
                            yield dict(zip(cols, tup))
                    _t2 = _t.time()
                    agg = aggregate_particle_metrics(
                        _stream_records(contacts_df),
                        atoms_by_id, type_map, scale=scale)
                    _t3 = _t.time()
                    print(f'  [3d-data aux] streaming aggregate '
                          f'in {_t3-_t2:.1f}s (total {_t3-_t0:.1f}s)')
                    aux['stress_max']         = agg['stress_max']
                    aux['dr_max']             = agg['dr_max']
                    aux['brittle_pairs']      = agg['brittle_pairs']
                    aux['se_stress_pairs']    = agg['se_stress_pairs']
                    aux['am_se_stress_pairs'] = agg.get('am_se_stress_pairs', [])
                    aux['se_states']          = agg.get('se_states', {})
                    aux['tabor_stats']        = agg.get('tabor_stats', {})
                    aux['all_se_ids_count']   = agg.get('all_se_ids_count', 0)
                    aux['se_engagement']      = agg.get('se_engagement', {})
                    # Phase A1/A3/A4
                    aux['particle_max_fpc']         = agg.get('particle_max_fpc', {})
                    aux['particle_worst_stage']     = agg.get('particle_worst_stage', {})
                    aux['particle_n_brittle']       = agg.get('particle_n_brittle', {})
                    aux['particle_worst_partner_brittle'] = agg.get('particle_worst_partner_brittle', {})
                    aux['particle_worst_pair_type'] = agg.get('particle_worst_pair_type', {})
                    aux['am_p_skeleton']            = agg.get('am_p_skeleton', [])
                    aux['stress_chain_segments']    = agg.get('stress_chain_segments', [])
                    # 입자별 배위수 + 상별 요약 (3D 뷰어 '배위수' 보기 · 10-06 · 스키마 12)
                    for _k in ('cn_se_se', 'cn_am_se', 'cn_am_am', 'cn_summary'):
                        aux[_k] = agg.get(_k, {})

                    # Phase A5+A6 — SE network diagnostics (re-stream contacts;
                    # NetworkX-based, ~1-2 s for typical 60k SE-SE contacts).
                    try:
                        _plate_z_sim = box.get('z_max', 0) / max(scale, 1)
                        _se_diag = compute_se_network_diagnostics(
                            _stream_records(contacts_df), atoms_by_id,
                            type_map, plate_z=_plate_z_sim, scale=scale)
                        aux['se_percolating']           = _se_diag.get('percolating_se', [])
                        aux['se_articulation_points']   = _se_diag.get('articulation_points', [])
                        aux['se_bottleneck_edges']      = _se_diag.get('bottleneck_edges', [])
                        aux['se_dead_end_clusters']     = _se_diag.get('dead_end_clusters', [])
                        aux['se_n_percolating']         = _se_diag.get('n_percolating', 0)
                        aux['se_bn_median_norm']        = _se_diag.get('bn_median_norm', 0)
                        aux['se_bn_threshold_norm']     = _se_diag.get('bn_threshold_norm', 0)
                        aux['se_n_bn_below_threshold']  = _se_diag.get('n_bn_below_threshold', 0)
                        aux['se_n_perc_edges']          = _se_diag.get('n_perc_edges', 0)
                        print(f'  [3d-data aux] SE diag: '
                              f'{aux["se_n_percolating"]} percolating, '
                              f'{len(aux["se_articulation_points"])} cut-pts, '
                              f'{len(aux["se_bottleneck_edges"])} narrow edges, '
                              f'{len(aux["se_dead_end_clusters"])} dead-ends')
                    except Exception as _ediag:
                        print(f'  [3d-data aux] SE diag failed: {_ediag}')

                    # Write cache so subsequent page loads are instant.
                    try:
                        cache_blob = dict(aux)
                        cache_blob['_contacts_mtime'] = contacts_mtime; cache_blob['_schema'] = 12
                        with open(cache_path, 'w') as _cf:
                            json.dump(cache_blob, _cf, default=str)
                        print(f'  [3d-data aux] cache WROTE → '
                              f'{os.path.basename(cache_path)}')
                    except OSError as _we:
                        print(f'  [3d-data aux] cache write failed: {_we}')
        aux['cluster_meta']      = classify_clusters(clusters)
        aux['cluster_id_per_se'] = {str(k): v for k, v in
                                     build_cluster_id_map(clusters).items()}
        aux['coverage_per_am']   = {str(k): v for k, v in build_coverage_map(
            os.path.join(results_dir, 'coverage_per_am.csv')).items()}
        # 뷰어 범례가 읽은 열을 표지 (physics 없음 → Hertz 계열 대체 · ②-b (f))
        aux['coverage_per_am_source'] = coverage_map_column(
            os.path.join(results_dir, 'coverage_per_am.csv'))
    except Exception as _e:
        # Aux data is best-effort — don't break the viewer if it fails.
        import traceback
        print(f'  [3d-data aux] FAILED: {type(_e).__name__}: {_e}')
        traceback.print_exc()

    # Defensive: try jsonify the full response.  If anything (numpy
    # types, NaN, huge dict serialisation, etc.) blows up here we'd
    # silently return either a 500 with HTML body or a truncated JSON,
    # which on the frontend looks like "Unexpected end of JSON input"
    # with no clue why.  Explicit fallback returns at least the base
    # geometry so the user sees particles instead of a red error box.
    payload = {
        'particles': particles,
        'box': box,
        'percolation': percolation,
        'paths': paths,
        'clusters': clusters,
        'mesh_triangles': mesh_triangles,
        'atoms_only': atoms_only_mode,
        'aux': aux,
    }
    try:
        resp = jsonify(payload)
        # Force compute Content-Length so chunked-encoding doesn't
        # mask a truncation downstream.
        body = resp.get_data()
        print(f'  [3d-data] response: {len(body)/1e6:.2f} MB')
        return resp
    except (TypeError, ValueError) as _je:
        import traceback
        traceback.print_exc()
        print(f'  [3d-data] jsonify FAILED ({type(_je).__name__}: {_je}) — '
              f'returning base geometry only, aux dropped')
        # Strip aux and retry — if particles+box+clusters serialise,
        # the viewer can at least show shapes.
        payload['aux'] = {}
        payload['_aux_error'] = f'{type(_je).__name__}: {_je}'[:200]
        return jsonify(payload)
    except Exception as _je:
        import traceback
        traceback.print_exc()
        print(f'  [3d-data] CATASTROPHIC FAIL: {type(_je).__name__}: {_je}')
        return jsonify({'error': str(_je)[:300],
                         'particles': [], 'aux': {},
                         'box': box, 'atoms_only': True}), 200

@app.route('/toggle-warning/<case_id>', methods=['POST'])
def toggle_warning(case_id):
    """Toggle a warning on/off in full_metrics.json."""
    data = request.get_json()
    warn_type = data.get('warning_type', '')
    if not warn_type:
        return jsonify({'error': 'No warning type'}), 400

    # Try dashboard results first, then archive
    metrics_path = os.path.join(get_results_dir(case_id), 'full_metrics.json')
    if case_id.startswith('archive:'):
        archive_rel = case_id[len('archive:'):]
        target = _safe_path(archive_rel)
        if target:
            metrics_path = os.path.join(target, 'full_metrics.json')

    if not os.path.exists(metrics_path):
        return jsonify({'error': 'Metrics not found'}), 404

    with open(metrics_path) as f:
        metrics = json.load(f)

    disabled = metrics.get('disabled_warnings', [])
    if warn_type in disabled:
        disabled.remove(warn_type)
        is_disabled = False
    else:
        disabled.append(warn_type)
        is_disabled = True
    metrics['disabled_warnings'] = disabled

    with open(metrics_path, 'w') as f:
        json.dump(metrics, f, indent=2, default=str)

    return jsonify({'success': True, 'disabled': is_disabled})


@app.route('/results/<case_id>/save-screenshot', methods=['POST'])
def save_screenshot(case_id):
    """Save 3D viewer screenshot to figures folder."""
    import base64
    data = request.get_json()
    if not data or 'image' not in data:
        return jsonify({'error': 'No image data'}), 400
    figures_dir = os.path.join(get_results_dir(case_id), 'figures')
    os.makedirs(figures_dir, exist_ok=True)
    filename = data.get('filename', 'screenshot.png')
    filename = filename.replace('/', '_').replace('\\', '_')
    img_data = data['image'].split(',')[1]  # strip data:image/png;base64,
    with open(os.path.join(figures_dir, filename), 'wb') as f:
        f.write(base64.b64decode(img_data))
    return jsonify({'success': True, 'filename': filename})


@app.route('/results/<case_id>/force-chains')
def serve_force_chains(case_id):
    """Serve force chain data for 3D viewer."""
    results_dir = get_results_dir(case_id)
    fc_path = os.path.join(results_dir, 'force_chains.json')
    if os.path.exists(fc_path):
        with open(fc_path) as f:
            return jsonify(json.load(f))
    return jsonify([])


def _am_contacts_response(data_dir, meta, extra_dirs=()):
    """3D 뷰어 'AM 접촉 확대' (2026-10-06 · 1저자 보고 슬라이드) — `?am_id=` AM 하나의 접촉 행 (contacts.csv) · 상대 입자 ·
    cap 면적.  live · archive 경로가 같이 부른다 (계산 = scripts/viewer3d_data.am_contact_closeup — 생산 함수 재사용).
    상자 = input_params.json box_x · box_y (data_dir → extra_dirs) — 없으면 그리기만 뷰어와 같은 0.05 기본, 보고 규칙 합집합은 빈칸."""
    raw = (request.args.get('am_id') or '').strip()
    try:
        am_id = int(raw)
    except ValueError:
        return jsonify({'error': f'am_id (정수) 가 필요하다 (받은 값 {raw!r})'}), 400
    atoms_csv = os.path.join(data_dir, 'atoms.csv')
    contacts_csv = os.path.join(data_dir, 'contacts.csv')
    if not os.path.exists(atoms_csv):
        return jsonify({'error': 'atoms.csv 가 없다'}), 404
    if not os.path.exists(contacts_csv):
        return jsonify({'error': 'contacts.csv 가 없다 — 접촉 덤프 없는 케이스 (atoms-only) 는 AM 접촉 확대를 그릴 수 없다'}), 404
    type_map = {}
    for item in _type_map_resolve.map_str_from_meta(meta, 'am-contacts')[0].split(','):
        k, _, v = item.partition(':')
        try:
            type_map[int(k)] = v.strip()
        except ValueError:
            continue
    from viewer3d_data import load_am_contact_index, am_contact_closeup
    from coverage_physics_vs_hertzian import read_box_xy
    box, why = None, None
    for d in (data_dir,) + tuple(extra_dirs):
        box, why = read_box_xy(d)
        if box:
            break
    fm = {}
    fm_path = os.path.join(data_dir, 'full_metrics.json')
    if os.path.exists(fm_path):
        try:
            with open(fm_path) as f:
                fm = json.load(f) or {}
        except (OSError, ValueError):
            fm = {}
    try:
        idx = load_am_contact_index(atoms_csv, contacts_csv, type_map)
    except (OSError, ValueError) as e:
        return jsonify({'error': f'atoms.csv · contacts.csv 를 못 읽었다 — {type(e).__name__}: {e}'}), 400
    try:
        payload, code = am_contact_closeup(idx, type_map, am_id, scale=meta.get('scale', 1000), box_xy=box,
                                           box_source=('input_params' if box else 'default_0.05'), box_reason=why,
                                           full_metrics=fm)
    except Exception as e:                                         # noqa: BLE001 — 모달이 사유를 띄운다 (HTML 500 대신 JSON)
        import traceback
        traceback.print_exc()
        return jsonify({'error': f'AM 접촉 확대 계산 실패 — {type(e).__name__}: {e}'}), 500
    return jsonify(payload), code


@app.route('/results/<case_id>/am-contacts')
def serve_am_contacts(case_id):
    """AM 하나의 접촉 (3D 뷰어 'AM 접촉 확대' 모달) — `_am_contacts_response` (archive 경로와 같은 계산)."""
    meta_file = os.path.join(get_case_dir(case_id), 'meta.json')
    if not os.path.exists(meta_file):
        return jsonify({'error': 'Case not found'}), 404
    with open(meta_file) as f:
        meta = json.load(f)
    return _am_contacts_response(get_results_dir(case_id), meta, extra_dirs=(get_case_dir(case_id),))


def _network_current_response(results_dir, meta_path):
    """⚡ 전류 흐름 (DEM 3D 뷰어 'net_current') 자료 — 망 FULL 해의 간선 전류 상위 N (`scripts/network_current.current_payload`).

    자료 = 케이스 폴더 `network_raw_dump/` — 웹앱 망 단계는 간선 전류를 남기지 않는다 (`--dump-raw-dir` 를 넘기지 않는다 · 망 단계 ·
    게시 계약 그대로).  한 번 `python3 scripts/network_current.py dump <결과 폴더>` 로 만든다 (같은 argv · 옆 폴더 · 게시 파일 무변경).
    없으면 404 + 그 명령 · 잘못된 인자 400.  좌표 배율 = 3d-data 와 같은 meta.json scale."""
    meta = {}
    try:
        with open(meta_path, encoding='utf-8') as f:
            meta = json.load(f) or {}
    except (OSError, ValueError):
        meta = {}
    _scripts_dir = os.path.join(os.path.dirname(__file__), '..', 'scripts')
    if _scripts_dir not in sys.path:
        sys.path.insert(0, _scripts_dir)
    import network_current as _ncur
    st, body = _ncur.current_payload(results_dir, channel=request.args.get('channel', 'ionic'),
                                     mode=request.args.get('mode', 'hertzian'), top=request.args.get('top'),
                                     scale=(meta.get('scale', 1000) if isinstance(meta, dict) else 1000) or 1000)
    return jsonify(body), st


@app.route('/results/<case_id>/network-current')
def serve_network_current(case_id):
    """⚡ 전류 흐름 — 망 해의 간선 전류 (상위 N · on-demand · force-chains 와 같은 방식)."""
    return _network_current_response(get_results_dir(case_id), os.path.join(get_case_dir(case_id), 'meta.json'))


@app.route('/porosity-corpus.csv')
def porosity_corpus_csv():
    """Walk EVERY uploaded case, read its JSONs, and stream one row per case
    as CSV: MPM porosity (mpm_metrics.json) + DEM porosity (full_metrics) +
    composition (AM:SE) + P:S + radii + the SE-rich/SE-poor/cross-validated
    regime gate (gap = DEM - MPM, |gap|>4 splits the regime).  No form / no
    grid extrapolation — this is the raw per-case corpus dump the списку view
    already computes, exported flat.  Missing fields render blank.
    NOTE: `areal_mAh` is an IDENTIFIER (cell-design target parsed from the name),
    NOT a porosity driver — porosity is intensive, set by composition/P:S/radii/
    pressure; it does not depend on areal capacity (except at the thin-SE-poor
    corner where thickness enters the regime gate)."""
    import io as _io, csv as _csv, re as _re
    up = app.config['UPLOAD_FOLDER']
    res = app.config['RESULTS_FOLDER']

    def _j(p):
        try:
            with open(p) as f:
                return json.load(f) or {}
        except Exception:
            return {}

    def _ratio(s):
        if not s or ':' not in str(s):
            return (None, None)
        try:
            a, b = str(s).split(':')[:2]
            return float(a), float(b)
        except Exception:
            return (None, None)

    rows = []
    if os.path.isdir(up):
        for cid in sorted(os.listdir(up)):
            cdir = os.path.join(up, cid)
            if not os.path.isdir(cdir):
                continue
            meta = _j(os.path.join(cdir, 'meta.json'))
            rdir = os.path.join(res, cid)
            fm = _j(os.path.join(rdir, 'full_metrics.json'))
            mm = _j(os.path.join(rdir, 'mpm_metrics.json'))
            ip = _j(os.path.join(cdir, 'input_params.json')) \
                or _j(os.path.join(rdir, 'input_params.json'))

            dem = fm.get('porosity_spheresum')
            if dem is None:
                dem = fm.get('porosity')
            mpm = mm.get('porosity_mpm_pct')
            if dem is None and mpm is None:
                continue  # no porosity of any kind → skip

            name = meta.get('name') or cid
            _mm = (_re.search(r'(\d+(?:\.\d+)?)\s*mAh', str(name), _re.I)
                   or _re.search(r'(\d+(?:\.\d+)?)\s*mAh', str(cid), _re.I))
            areal = _mm.group(1) if _mm else ''
            am_wt, se_wt = _ratio(fm.get('am_se_ratio') or ip.get('am_se_ratio')
                                  or meta.get('am_se_ratio'))
            P, S = _ratio(fm.get('ps_ratio') or meta.get('ps_ratio'))
            def _rp(k):
                # full_metrics stores particle radii in PHYSICAL µm already
                # (cf. docs/data/dem_design_points.csv: r_AM_P=6 / r_AM_S=2 /
                # r_SE=0.5–1.5).  Use the value as-is; only collapse a stray
                # ×1000 sim-inflated legacy value (no real radius is ≥100 µm).
                r = fm.get(k)
                try:
                    r = float(r)
                except (TypeError, ValueError):
                    return ''
                if r == 0:
                    return 0.0
                while abs(r) >= 100:
                    r /= 1000.0
                return round(r, 3)

            gap = ''
            regime = ''
            _graw = None
            if dem is not None and mpm is not None:
                _graw = float(dem) - float(mpm)   # RAW gap for the threshold (match list view)
                gap = round(_graw, 1)             # rounded only for display
                regime = ('SE-poor' if _graw > 4.0
                          else 'SE-rich' if _graw < -4.0 else 'cross-validated')
            # reliability gate — WHICH porosity to trust per regime:
            #   SE-poor  (gap>+4): MPM over-compresses the mono-large/thin corner
            #                      (no rigid contact net to hold the bed open)
            #                      → use DEM (rigid loose-truth).  band ±4.9
            #   SE-rich  (gap<-4): DEM ε_sphere overlap over-compresses
            #                      → use MPM (true plastic void-fill).  band ±1.1
            #   cross-validated  : two independent models agree → use MPM.  ±2.4
            use_source, use_por = '', ''
            if dem is not None and mpm is not None:
                if _graw > 4.0:
                    use_source, use_por = 'DEM', round(float(dem), 2)
                else:
                    use_source, use_por = 'MPM', round(float(mpm), 2)
            elif mpm is not None:
                use_source, use_por = 'MPM', round(float(mpm), 2)
            elif dem is not None:
                use_source, use_por = 'DEM', round(float(dem), 2)
            rows.append({
                'case': name, 'case_id': cid, 'areal_mAh': areal,
                'am_wt': am_wt if am_wt is not None else '',
                'se_wt': se_wt if se_wt is not None else '',
                'ps': ('%g:%g' % (P, S)) if (P is not None and S is not None)
                      else (fm.get('ps_ratio') or meta.get('ps_ratio') or ''),
                'r_AM_P_um': _rp('r_AM_P'), 'r_AM_S_um': _rp('r_AM_S'),
                'r_SE_um': _rp('r_SE'),
                'mpm_porosity_pct': round(float(mpm), 2) if mpm is not None else '',
                'dem_porosity_pct': round(float(dem), 2) if dem is not None else '',
                'gap_dem_minus_mpm': gap, 'regime': regime,
                'use_source': use_source, 'use_porosity_pct': use_por,
                'thickness_um': mm.get('thickness_mpm_um', ''),
                'se_fraction_pct': mm.get('se_fraction_pct', ''),
            })
    rows.sort(key=lambda r: str(r['case']))

    buf = _io.StringIO()
    fn = ['case', 'case_id', 'areal_mAh', 'am_wt', 'se_wt', 'ps',
          'r_AM_P_um', 'r_AM_S_um', 'r_SE_um', 'mpm_porosity_pct',
          'dem_porosity_pct', 'gap_dem_minus_mpm', 'regime',
          'use_source', 'use_porosity_pct',
          'thickness_um', 'se_fraction_pct']
    w = _csv.DictWriter(buf, fieldnames=fn)
    w.writeheader()
    w.writerows(rows)
    resp = make_response(buf.getvalue())
    resp.headers['Content-Type'] = 'text/csv; charset=utf-8'
    resp.headers['Content-Disposition'] = 'attachment; filename="porosity_corpus.csv"'
    return resp


def _brittle_z_csv_response(case_dir, case_name):
    """Compute brittle z-profile on demand and stream as CSV download.
    Shared helper for /results/<id> and /archive/results/<path> endpoints.
    """
    import csv as _csv
    import io as _io
    import sys as _sys
    _scripts_dir = os.path.join(os.path.dirname(__file__), '..', 'scripts')
    if _scripts_dir not in _sys.path:
        _sys.path.insert(0, _scripts_dir)
    if not (os.path.exists(os.path.join(case_dir, 'atoms.csv'))
            and os.path.exists(os.path.join(case_dir, 'contacts.csv'))):
        return ('atoms.csv or contacts.csv missing', 404)
    # meta.json optional — _load_case has its own fallbacks.
    from plot_brittle_z_distribution import (
        compute_brittle_zprofile, profile_to_csv_rows,
    )
    bins = int(request.args.get('bins', 25))
    try:
        profile = compute_brittle_zprofile(case_dir, bins=bins)
        buf = _io.StringIO()
        _csv.writer(buf).writerows(profile_to_csv_rows(profile))
    except Exception as e:
        import traceback
        traceback.print_exc()
        return (f'{type(e).__name__}: {e}', 500)
    resp = make_response(buf.getvalue())
    resp.headers['Content-Type'] = 'text/csv; charset=utf-8'
    resp.headers['Content-Disposition'] = (
        f'attachment; filename="brittle_z_{case_name}.csv"')
    return resp


def _brittle_z_profile_compute(case_dir, bins=25):
    """Shared loader used by data / png / csv helpers."""
    import sys as _sys
    _scripts_dir = os.path.join(os.path.dirname(__file__), '..', 'scripts')
    if _scripts_dir not in _sys.path:
        _sys.path.insert(0, _scripts_dir)
    from plot_brittle_z_distribution import compute_brittle_zprofile
    return compute_brittle_zprofile(case_dir, bins=bins)


def _brittle_z_data_response(case_dir, case_name):
    """Return brittle z-profile as JSON for the modal's table."""
    if not (os.path.exists(os.path.join(case_dir, 'atoms.csv'))
            and os.path.exists(os.path.join(case_dir, 'contacts.csv'))):
        return jsonify({'error': 'atoms.csv or contacts.csv missing'}), 404
    # meta.json is optional — _load_case now falls back to
    # input_params.json or project defaults (scale=1000,
    # type_map={1:AM_P,2:AM_S,3:SE}).
    bins = int(request.args.get('bins', 25))
    try:
        profile = _brittle_z_profile_compute(case_dir, bins=bins)
    except Exception as e:
        import traceback
        traceback.print_exc()
        return jsonify({
            'error': f'{type(e).__name__}: {e}',
        }), 500
    # numpy arrays → plain lists for JSON
    return jsonify({
        'case_name':      case_name,
        'thickness_um':   float(profile['thickness_um']),
        'n_total':        int(profile['n_total']),
        'n_damaged':      int(profile['n_damaged']),
        'damaged_pct':    float(profile['damaged_pct']),
        'bin_centers_um': [float(x) for x in profile['bin_centers_um']],
        'bin_edges_um':   [float(x) for x in profile['bin_edges_um']],
        'counts': {k: [int(x) for x in v] for k, v in profile['counts'].items()},
        'mean_m':         [float(x) for x in profile['mean_m']],
        'stage_totals':   {k: int(v) for k, v in profile['stage_totals'].items()},
        'counts_by_pair': {
            pt: {s: [int(x) for x in arr] for s, arr in stages.items()}
            for pt, stages in (profile.get('counts_by_pair') or {}).items()
        },
        'pair_totals':    {k: int(v) for k, v in
                            (profile.get('pair_totals') or {}).items()},
    })


def _brittle_z_png_response(case_dir, case_name):
    """Render the 3-panel brittle z-profile figure server-side and stream PNG."""
    import io as _io
    if not (os.path.exists(os.path.join(case_dir, 'atoms.csv'))
            and os.path.exists(os.path.join(case_dir, 'contacts.csv'))):
        return ('atoms.csv or contacts.csv missing', 404)
    # meta.json optional — _load_case has its own fallbacks.
    bins = int(request.args.get('bins', 25))
    try:
        profile = _brittle_z_profile_compute(case_dir, bins=bins)
        import sys as _sys
        _scripts_dir = os.path.join(os.path.dirname(__file__), '..', 'scripts')
        if _scripts_dir not in _sys.path:
            _sys.path.insert(0, _scripts_dir)
        from plot_brittle_z_distribution import render_brittle_figure
        fig = render_brittle_figure(profile)
        buf = _io.BytesIO()
        fig.savefig(buf, format='png', dpi=150, bbox_inches='tight')
        import matplotlib.pyplot as plt
        plt.close(fig)
        buf.seek(0)
    except Exception as e:
        import traceback
        traceback.print_exc()
        return (f'{type(e).__name__}: {e}', 500)
    return send_file(buf, mimetype='image/png', as_attachment=False,
                      download_name=f'brittle_z_{case_name}.png')


@app.route('/results/<case_id>/brittle-z-csv')
def serve_brittle_z_csv(case_id):
    results_dir = get_results_dir(case_id)
    return _brittle_z_csv_response(results_dir, case_id)


@app.route('/results/<case_id>/brittle-z-data')
def serve_brittle_z_data(case_id):
    return _brittle_z_data_response(get_results_dir(case_id), case_id)


@app.route('/results/<case_id>/brittle-z-png')
def serve_brittle_z_png(case_id):
    return _brittle_z_png_response(get_results_dir(case_id), case_id)


# ── Stress-hotspot z-profile (analogous to brittle z-profile) ───────
def _stress_z_profile_compute(case_dir, bins=25):
    import sys as _sys
    _scripts_dir = os.path.join(os.path.dirname(__file__), '..', 'scripts')
    if _scripts_dir not in _sys.path:
        _sys.path.insert(0, _scripts_dir)
    from plot_stress_z_distribution import compute_stress_zprofile
    return compute_stress_zprofile(case_dir, bins=bins)


def _stress_z_data_response(case_dir, case_name):
    if not (os.path.exists(os.path.join(case_dir, 'atoms.csv'))
            and os.path.exists(os.path.join(case_dir, 'contacts.csv'))):
        return jsonify({'error': 'atoms.csv or contacts.csv missing'}), 404
    bins = int(request.args.get('bins', 25))
    try:
        profile = _stress_z_profile_compute(case_dir, bins=bins)
    except Exception as e:
        import traceback
        traceback.print_exc()
        return jsonify({'error': f'{type(e).__name__}: {e}'}), 500
    return jsonify({
        'case_name':       case_name,
        'thickness_um':    float(profile['thickness_um']),
        'n_total':         int(profile['n_total']),
        'n_with_stress':   int(profile['n_with_stress']),
        'bin_centers_um':  [float(x) for x in profile['bin_centers_um']],
        'bin_edges_um':    [float(x) for x in profile['bin_edges_um']],
        'counts_per_type': {k: [int(x) for x in v]
                             for k, v in profile['counts_per_type'].items()},
        'counts_by_bracket': {k: [int(x) for x in v]
                              for k, v in profile['counts_by_bracket'].items()},
        'mean_MPa':        [float(x) for x in profile['mean_MPa']],
        'median_MPa':      [float(x) for x in profile['median_MPa']],
        'p95_MPa':         [float(x) for x in profile['p95_MPa']],
        'max_MPa':         [float(x) for x in profile['max_MPa']],
        'bracket_edges_MPa': [float(x) for x in profile['bracket_edges_MPa']],
        'type_totals':     {k: int(v) for k, v in profile['type_totals'].items()},
        'sLo':  float(profile['sLo']),  'sMed': float(profile['sMed']),
        'sHi':  float(profile['sHi']),  'sMax': float(profile['sMax']),
    })


def _stress_z_png_response(case_dir, case_name):
    import io as _io
    if not (os.path.exists(os.path.join(case_dir, 'atoms.csv'))
            and os.path.exists(os.path.join(case_dir, 'contacts.csv'))):
        return ('atoms.csv or contacts.csv missing', 404)
    bins = int(request.args.get('bins', 25))
    try:
        profile = _stress_z_profile_compute(case_dir, bins=bins)
        import sys as _sys
        _scripts_dir = os.path.join(os.path.dirname(__file__), '..', 'scripts')
        if _scripts_dir not in _sys.path:
            _sys.path.insert(0, _scripts_dir)
        from plot_stress_z_distribution import render_stress_figure
        fig = render_stress_figure(profile)
        buf = _io.BytesIO()
        fig.savefig(buf, format='png', dpi=150, bbox_inches='tight')
        import matplotlib.pyplot as plt
        plt.close(fig); buf.seek(0)
    except Exception as e:
        import traceback
        traceback.print_exc()
        return (f'{type(e).__name__}: {e}', 500)
    return send_file(buf, mimetype='image/png', as_attachment=False,
                      download_name=f'stress_z_{case_name}.png')


def _stress_z_csv_response(case_dir, case_name):
    import csv as _csv
    import io as _io
    if not (os.path.exists(os.path.join(case_dir, 'atoms.csv'))
            and os.path.exists(os.path.join(case_dir, 'contacts.csv'))):
        return ('atoms.csv or contacts.csv missing', 404)
    bins = int(request.args.get('bins', 25))
    try:
        profile = _stress_z_profile_compute(case_dir, bins=bins)
        import sys as _sys
        _scripts_dir = os.path.join(os.path.dirname(__file__), '..', 'scripts')
        if _scripts_dir not in _sys.path:
            _sys.path.insert(0, _scripts_dir)
        from plot_stress_z_distribution import profile_to_csv_rows
        buf = _io.StringIO()
        _csv.writer(buf).writerows(profile_to_csv_rows(profile))
    except Exception as e:
        import traceback
        traceback.print_exc()
        return (f'{type(e).__name__}: {e}', 500)
    resp = make_response(buf.getvalue())
    resp.headers['Content-Type'] = 'text/csv; charset=utf-8'
    resp.headers['Content-Disposition'] = (
        f'attachment; filename="stress_z_{case_name}.csv"')
    return resp


@app.route('/results/<case_id>/stress-z-data')
def serve_stress_z_data(case_id):
    return _stress_z_data_response(get_results_dir(case_id), case_id)

@app.route('/results/<case_id>/stress-z-png')
def serve_stress_z_png(case_id):
    return _stress_z_png_response(get_results_dir(case_id), case_id)

@app.route('/results/<case_id>/stress-z-csv')
def serve_stress_z_csv(case_id):
    return _stress_z_csv_response(get_results_dir(case_id), case_id)


# ── Combined (Brittle + Stress) z-profile — overlay PNG / merged CSV ──
def _combined_z_png_response(case_dir, case_name):
    import io as _io
    if not (os.path.exists(os.path.join(case_dir, 'atoms.csv'))
            and os.path.exists(os.path.join(case_dir, 'contacts.csv'))):
        return ('atoms.csv or contacts.csv missing', 404)
    bins = int(request.args.get('bins', 25))
    try:
        import sys as _sys
        _scripts_dir = os.path.join(os.path.dirname(__file__), '..', 'scripts')
        if _scripts_dir not in _sys.path:
            _sys.path.insert(0, _scripts_dir)
        from plot_combined_z_distribution import (
            compute_combined_zprofile, render_combined_figure,
        )
        profile = compute_combined_zprofile(case_dir, bins=bins)
        fig = render_combined_figure(profile)
        buf = _io.BytesIO()
        fig.savefig(buf, format='png', dpi=150, bbox_inches='tight')
        import matplotlib.pyplot as plt
        plt.close(fig); buf.seek(0)
    except Exception as e:
        import traceback
        traceback.print_exc()
        return (f'{type(e).__name__}: {e}', 500)
    return send_file(buf, mimetype='image/png', as_attachment=False,
                      download_name=f'combined_z_{case_name}.png')


def _combined_z_csv_response(case_dir, case_name):
    import csv as _csv
    import io as _io
    if not (os.path.exists(os.path.join(case_dir, 'atoms.csv'))
            and os.path.exists(os.path.join(case_dir, 'contacts.csv'))):
        return ('atoms.csv or contacts.csv missing', 404)
    bins = int(request.args.get('bins', 25))
    try:
        import sys as _sys
        _scripts_dir = os.path.join(os.path.dirname(__file__), '..', 'scripts')
        if _scripts_dir not in _sys.path:
            _sys.path.insert(0, _scripts_dir)
        from plot_combined_z_distribution import (
            compute_combined_zprofile, profile_to_csv_rows,
        )
        profile = compute_combined_zprofile(case_dir, bins=bins)
        buf = _io.StringIO()
        _csv.writer(buf).writerows(profile_to_csv_rows(profile))
    except Exception as e:
        import traceback
        traceback.print_exc()
        return (f'{type(e).__name__}: {e}', 500)
    resp = make_response(buf.getvalue())
    resp.headers['Content-Type'] = 'text/csv; charset=utf-8'
    resp.headers['Content-Disposition'] = (
        f'attachment; filename="combined_z_{case_name}.csv"')
    return resp


@app.route('/results/<case_id>/combined-z-png')
def serve_combined_z_png(case_id):
    return _combined_z_png_response(get_results_dir(case_id), case_id)

@app.route('/results/<case_id>/combined-z-csv')
def serve_combined_z_csv(case_id):
    return _combined_z_csv_response(get_results_dir(case_id), case_id)


# ── Coverage z-profile (per-AM SE-coverage %) ───────────────────────
def _coverage_z_profile_compute(case_dir, bins=25):
    import sys as _sys
    _scripts_dir = os.path.join(os.path.dirname(__file__), '..', 'scripts')
    if _scripts_dir not in _sys.path:
        _sys.path.insert(0, _scripts_dir)
    from plot_coverage_z_distribution import compute_coverage_zprofile
    return compute_coverage_zprofile(case_dir, bins=bins)


def _coverage_z_data_response(case_dir, case_name):
    if not (os.path.exists(os.path.join(case_dir, 'atoms.csv'))
            and os.path.exists(os.path.join(case_dir, 'coverage_per_am.csv'))):
        return jsonify({'error': 'atoms.csv or coverage_per_am.csv missing'}), 404
    bins = int(request.args.get('bins', 25))
    try:
        profile = _coverage_z_profile_compute(case_dir, bins=bins)
    except Exception as e:
        import traceback
        traceback.print_exc()
        return jsonify({'error': f'{type(e).__name__}: {e}'}), 500
    return jsonify({
        'case_name':       case_name,
        'thickness_um':    float(profile['thickness_um']),
        'n_with_cov':      int(profile['n_with_cov']),
        'bin_centers_um':  [float(x) for x in profile['bin_centers_um']],
        'bin_edges_um':    [float(x) for x in profile['bin_edges_um']],
        'counts_per_type': {k: [int(x) for x in v]
                             for k, v in profile['counts_per_type'].items()},
        'counts_by_band':  {k: [int(x) for x in v]
                             for k, v in profile['counts_by_band'].items()},
        'mean_pct':        [float(x) for x in profile['mean_pct']],
        'median_pct':      [float(x) for x in profile['median_pct']],
        'p5_pct':          [float(x) for x in profile['p5_pct']],
        'p95_pct':         [float(x) for x in profile['p95_pct']],
        'band_edges_pct':  [float(x) for x in profile['band_edges_pct']],
        'type_totals':     {k: int(v) for k, v in profile['type_totals'].items()},
        'cLo':  float(profile['cLo']),  'cMed': float(profile['cMed']),
        'cHi':  float(profile['cHi']),  'cMean': float(profile['cMean']),
    })


def _coverage_z_png_response(case_dir, case_name):
    import io as _io
    if not (os.path.exists(os.path.join(case_dir, 'atoms.csv'))
            and os.path.exists(os.path.join(case_dir, 'coverage_per_am.csv'))):
        return ('atoms.csv or coverage_per_am.csv missing', 404)
    bins = int(request.args.get('bins', 25))
    try:
        profile = _coverage_z_profile_compute(case_dir, bins=bins)
        import sys as _sys
        _scripts_dir = os.path.join(os.path.dirname(__file__), '..', 'scripts')
        if _scripts_dir not in _sys.path:
            _sys.path.insert(0, _scripts_dir)
        from plot_coverage_z_distribution import render_coverage_figure
        fig = render_coverage_figure(profile)
        buf = _io.BytesIO()
        fig.savefig(buf, format='png', dpi=150, bbox_inches='tight')
        import matplotlib.pyplot as plt
        plt.close(fig); buf.seek(0)
    except Exception as e:
        import traceback
        traceback.print_exc()
        return (f'{type(e).__name__}: {e}', 500)
    return send_file(buf, mimetype='image/png', as_attachment=False,
                      download_name=f'coverage_z_{case_name}.png')


def _coverage_z_csv_response(case_dir, case_name):
    import csv as _csv
    import io as _io
    if not (os.path.exists(os.path.join(case_dir, 'atoms.csv'))
            and os.path.exists(os.path.join(case_dir, 'coverage_per_am.csv'))):
        return ('atoms.csv or coverage_per_am.csv missing', 404)
    bins = int(request.args.get('bins', 25))
    try:
        profile = _coverage_z_profile_compute(case_dir, bins=bins)
        import sys as _sys
        _scripts_dir = os.path.join(os.path.dirname(__file__), '..', 'scripts')
        if _scripts_dir not in _sys.path:
            _sys.path.insert(0, _scripts_dir)
        from plot_coverage_z_distribution import profile_to_csv_rows
        buf = _io.StringIO()
        _csv.writer(buf).writerows(profile_to_csv_rows(profile))
    except Exception as e:
        import traceback
        traceback.print_exc()
        return (f'{type(e).__name__}: {e}', 500)
    resp = make_response(buf.getvalue())
    resp.headers['Content-Type'] = 'text/csv; charset=utf-8'
    resp.headers['Content-Disposition'] = (
        f'attachment; filename="coverage_z_{case_name}.csv"')
    return resp


@app.route('/results/<case_id>/coverage-z-data')
def serve_coverage_z_data(case_id):
    return _coverage_z_data_response(get_results_dir(case_id), case_id)

@app.route('/results/<case_id>/coverage-z-png')
def serve_coverage_z_png(case_id):
    return _coverage_z_png_response(get_results_dir(case_id), case_id)

@app.route('/results/<case_id>/coverage-z-csv')
def serve_coverage_z_csv(case_id):
    return _coverage_z_csv_response(get_results_dir(case_id), case_id)


def _report_strip_html(s):
    """Plain-text a possibly-HTML cell for markdown: <br> → '; ', drop tags,
    unescape common entities, collapse whitespace, escape pipes."""
    if s is None:
        return ''
    s = str(s)
    s = re.sub(r'<\s*br\s*/?\s*>', '; ', s, flags=re.I)
    s = re.sub(r'<[^>]+>', '', s)
    s = (s.replace('&lt;', '<').replace('&gt;', '>')
          .replace('&amp;', '&').replace('&nbsp;', ' ')
          .replace('&#10;', ' '))
    s = re.sub(r'\s+', ' ', s).strip()
    return s.replace('|', '\\|')


def _report_fmt_cell(v):
    """Format one table cell for markdown output (nan→'-', trim floats,
    strip any HTML)."""
    if isinstance(v, float):
        if v != v:  # NaN
            return '-'
        v = f'{v:.4g}'
    return _report_strip_html(v)


def _report_md_table(tbl):
    """Render a dashboard `tables[...]` entry (columns + data, possibly with
    HTML cells and '── section ──' header rows) as a GitHub-flavoured
    markdown table.  Section-header rows become bold separator rows."""
    cols = [str(c) for c in tbl.get('columns', [])]
    ncol = max(len(cols), 1)
    out = ['| ' + ' | '.join(cols) + ' |',
           '|' + '|'.join(['---'] * ncol) + '|']
    for row in tbl.get('data', []):
        row = list(row)
        first = str(row[0]) if row else ''
        if first.strip().startswith('──') or len(row) == 1:
            label = _report_strip_html(first).strip().strip('─ ').strip()
            out.append(f'| **{label}** |' + ' |' * (ncol - 1))
            continue
        cells = [_report_fmt_cell(c) for c in row[:ncol]]
        cells += [''] * (ncol - len(cells))
        out.append('| ' + ' | '.join(cells) + ' |')
    return '\n'.join(out)


@app.route('/results/<case_id>/report')
def serve_report(case_id):
    """Generate a comprehensive MD/PDF report that mirrors the full single-case
    dashboard: 개요 badges, Trust card, every analysis-summary tab (입자/접촉/
    배위수/네트워크/취성/종합 등급), physics derivations and figures."""
    case_dir = get_case_dir(case_id)
    meta_file = os.path.join(case_dir, 'meta.json')
    meta = {}
    if os.path.exists(meta_file):
        with open(meta_file) as f:
            meta = json.load(f)

    results_dir, archive_rel = _resolve_results_dir(case_id, meta)
    tables, metrics, input_params = _load_case_tables(results_dir, meta)
    trust_card = _build_trust_card(metrics)

    name = meta.get('name', case_id)
    scale = meta.get('scale', 1) or 1
    L = []

    # ── Header ──
    L.append(f'# DEM Analysis Report: {name}')
    L.append(f'> DEM/MPM Analyzer v3.0 | {datetime.now().strftime("%Y-%m-%d")}'
             + (f' | archive: `{archive_rel}`' if archive_rel else ''))
    L.append('')

    section = 1

    # ── 1. 케이스 개요 (header badges) ──
    L.append(f'## {section}. 케이스 개요 (Overview)\n')
    L.append('| 항목 | 값 |')
    L.append('|------|-----|')
    L.append(f'| Mode | {meta.get("mode", "-")} |')
    L.append(f'| Scale | {scale}× |')
    if meta.get('type_map'):
        L.append(f'| Type map | {meta["type_map"]} |')
    ps = meta.get('ps_ratio') or metrics.get('ps_ratio')
    if ps:
        L.append(f'| P:S (AM_P:AM_S 부피비) | {ps} |')
    am_se = metrics.get('am_se_ratio') or input_params.get('am_se_ratio')
    if am_se:
        tgt = input_params.get('am_se_ratio')
        if tgt and metrics.get('am_se_ratio') and tgt != metrics.get('am_se_ratio'):
            L.append(f'| AM:SE (무게비, 실측/target) | {metrics["am_se_ratio"]} ({tgt}) |')
        else:
            L.append(f'| AM:SE (무게비) | {am_se} |')
    if input_params.get('box_x') is not None and input_params.get('box_y') is not None:
        L.append(f'| RVE 단면적 | {input_params["box_x"]*scale:.0f}×'
                 f'{input_params["box_y"]*scale:.0f} μm |')
    #  ★ 09-30 (웹앱 ① · J20-l) — 화면 배지 · 네트워크 표와 같은 이름 · 한정어
    if metrics.get('porosity') is not None:
        L.append(f'| Porosity ε_sphere (구 부피 합 · 생산 규약) | {metrics["porosity"]:.1f}% |')
    if metrics.get('porosity_union') is not None:
        L.append(f'| Porosity ε_union (쌍 렌즈 · 벽 밖 미제거 — 인계 정확 union 과 다른 양) | '
                 f'{metrics["porosity_union"]:.1f}% |')
    if metrics.get('overlap_fraction_pct') is not None:
        L.append(f'| Overlap fraction (쌍 렌즈 부피 ÷ 구 부피 합) | {metrics["overlap_fraction_pct"]:.2f}% |')
    if metrics.get('porosity_union_exact_pct') is not None:
        _se = metrics.get('porosity_union_exact_se_pct')
        L.append(f'| Porosity ε_union 정확 (몬테카를로 · 벽 밖 제외 · 인계 규약) | '
                 f'{metrics["porosity_union_exact_pct"]:.2f}%' + (f' ± {_se:.2f}' if isinstance(_se, (int, float)) else '') + ' |')
    if metrics.get('thickness_mass_conserving_um') is not None:
        L.append(f'| 두께 질량 보존 (판 간격 × (1−ε_sphere)/(1−ε_정확)) | {metrics["thickness_mass_conserving_um"]:.2f} μm |')
    if metrics.get('phi_se_mass_conserving') is not None and metrics.get('phi_am_mass_conserving') is not None:
        L.append(f'| φ_SE · φ_AM 질량 보존 ((1−ε_정확) × 부피 몫) | {metrics["phi_se_mass_conserving"]:.4f} · '
                 f'{metrics["phi_am_mass_conserving"]:.4f} |')
    if metrics.get('thickness_um') is not None:
        _pzs = {'mesh': '판 메시 mesh_info.json',
                'estimated_center': '⚠ mesh 없음 — 최고 입자 중심 z 로 추정'}.get(
                    metrics.get('plate_z_source'), '출처 미기록')
        L.append(f'| 두께 (판 간격 · {_pzs}) | {metrics["thickness_um"]:.1f} μm |')
    if metrics.get('percolation_pct') is not None:
        L.append(f'| SE Percolation | {metrics["percolation_pct"]:.1f}% |')
    if metrics.get('ionic_active_pct') is not None:
        L.append(f'| Ionic Active AM | {metrics["ionic_active_pct"]:.1f}% |')
        _iso = metrics.get('am_ionic_isolated_pct')
        if not isinstance(_iso, (int, float)):
            _iso = 100.0 - metrics['ionic_active_pct']
        L.append(f'| Ionically-isolated AM (path-based, = 100 − active · ≠ vulnerable) | {_iso:.1f}% (am_ionic_isolated_pct) |')
        for _k, _lab in (('ionic_dead_pct', '├ isolated — touches SE, none linked to the separator side'),
                         ('ionic_no_se_pct', '└ isolated — no SE contact')):
            if isinstance(metrics.get(_k), (int, float)):
                L.append(f'| {_lab} | {metrics[_k]:.1f}% ({_k}) |')
    if metrics.get('e_se_eff_gpa') is not None:
        L.append(f'| E_SE_eff | {metrics["e_se_eff_gpa"]:.2f} GPa (bulk LPSCl: 24 GPa) |')
    if metrics.get('target_pressure_mpa') is not None:
        L.append(f'| Target Pressure | {metrics["target_pressure_mpa"]} MPa |')
    elif input_params.get('target_press_sim') is not None:
        L.append(f'| Target Pressure | {input_params["target_press_sim"]*1000:.1f} MPa |')
    L.append('')

    # Warnings
    warnings = metrics.get('warnings', [])
    if warnings:
        L.append('**⚠ Warnings**')
        L.append('')
        for w in warnings:
            icon = '🔴' if w.get('severity') == 'critical' else '🟡'
            L.append(f'- {icon} {w.get("msg", "")}')
        L.append('')
    L.append('---\n')
    section += 1

    # ── 2. Trust Card ──
    if trust_card:
        L.append(f'## {section}. Trust Card (Stage E self-report)\n')
        L.append(f'**Verdict: {_report_strip_html(trust_card["verdict"])}** '
                 f'— {trust_card["verdict_summary"]}')
        L.append('')
        L.append(f'> {_report_strip_html(trust_card["verdict_kr"])}')
        L.append('')
        L.append('| Gate | 상태 | 값 | 기준 (criterion) |')
        L.append('|------|------|-----|------------------|')
        state_map = {'pass': '✓ PASS', 'fail': '✗ FAIL', 'na': '— N/A'}
        for g in trust_card['leds']:
            L.append(f'| {_report_strip_html(g["label"])} '
                     f'| {state_map.get(g["cls"], g["cls"])} '
                     f'| {_report_strip_html(g["value"])} '
                     f'| {_report_strip_html(g["criterion"])} |')
        L.append('')
        L.append('---\n')
        section += 1

    # ── Analysis-summary tables (mirror dashboard tab order) ──
    tab_titles = [
        ('atom_statistics',      '입자 정보 (Particle Statistics)'),
        ('contact_summary',      '접촉 요약 (Contact Summary)'),
        ('coordination_summary', '배위수 (Coordination Number)'),
        ('network_summary',      '네트워크 지표 (Network Metrics)'),
        ('fracture_summary',     '취성 파괴 (Auerbach Fracture)'),
        ('overall_grade',        '종합 등급 (Overall Grade)'),
    ]
    for key, title in tab_titles:
        tbl = tables.get(key)
        if not tbl or not tbl.get('data'):
            continue
        L.append(f'## {section}. {title}\n')
        L.append(_report_md_table(tbl))
        L.append('')
        section += 1

    # ── Physics derivations (formula-level detail beyond the tables) ──
    L.append(f'## {section}. Physics Derivations\n')
    sigma_ratio = metrics.get('sigma_ratio')
    _sg_mS, _sg_note_md = _sigma_grain_context(metrics)   # 단일 출처 + 혼합-온도 경고 (S-8)
    if _sg_note_md:
        L.append(f'> {_sg_note_md}\n')
    sigma_brug = sigma_ratio * _sg_mS if sigma_ratio else None
    sigma_net = metrics.get('sigma_full_mScm')

    L.append('### Ionic Conductivity — Bruggeman vs Network Solver\n')
    L.append('```')
    L.append('σ_Bruggeman = σ_grain × φ_SE × f_perc / τ²   (접촉 저항 무시)')
    if sigma_ratio and metrics.get('phi_se') and metrics.get('tortuosity_mean'):
        tau = metrics.get('tortuosity_recommended', metrics.get('tortuosity_mean', 1))
        f_perc = metrics.get('percolation_pct', 100) / 100
        L.append(f'            = {_sg_mS:.1f} × {metrics["phi_se"]:.3f} × {f_perc:.3f} / {tau:.2f}²')
        L.append(f'            = {sigma_brug:.4f} mS/cm')
    if sigma_net:
        L.append('')
        L.append(f'σ_ionic     = {sigma_net:.4f} mS/cm   (Kirchhoff network solver, Holm 1967)')
        if sigma_brug:
            L.append(f'σ_brug/σ_ionic = {sigma_brug/sigma_net:.1f}×   (Bruggeman overestimation)')
        if metrics.get('bulk_resistance_fraction') is not None:
            L.append(f'Constriction fraction (접촉별 R_c/R_total 비가중 평균 · 전력 몫 아님 · L2-08) = {(1-metrics["bulk_resistance_fraction"])*100:.1f}%')
        if isinstance(metrics.get('constriction_power_share_ion_hertz'), (int, float)):
            #  ④a 10-04 — 같은 FULL 해의 Σ I²R_c / Σ I²R_total (관통 간선 · 가상 전극 제외)
            L.append(f'Constriction power share (I²R · 이온 · hertz) = {100 * metrics["constriction_power_share_ion_hertz"]:.1f}%')
    L.append('```')
    L.append('')

    sigma_el = metrics.get('electronic_sigma_full_mScm')
    sigma_th = metrics.get('thermal_sigma_full_mScm')
    from metrics_json import stress_cv_report_line as _scv_line   # LHS-33 — 옛 σ_VM 무효 · 미정의 = '—' + 사유 (0 아님)
    _scv_rl = _scv_line(metrics)
    if sigma_el is not None or sigma_th is not None or metrics.get('stress_cv') or metrics.get('stress_cv_status') not in (None, 'computed'):
        L.append('### Electronic / Thermal / Mechanical\n')
        if sigma_el is not None:
            L.append(f'- **σ_electronic**: {sigma_el:.2f} mS/cm')
            if metrics.get('electronic_percolating_fraction') is not None:
                L.append(f'- **AM Percolation (전자)**: {metrics["electronic_percolating_fraction"]*100:.1f}%')
            if metrics.get('electronic_active_fraction') is not None:
                L.append(f'- **Electronic Active AM**: {metrics["electronic_active_fraction"]*100:.1f}%')
                dead = (1 - metrics['electronic_active_fraction']) * 100
                if dead > 10:
                    L.append(f'- **Dead AM**: {dead:.1f}% → 도전재 추가 검토 필요')
        if sigma_th is not None:
            L.append(f'- **σ_thermal**: {sigma_th:.3f} mS/cm equiv')
        if metrics.get('stress_cv'):
            #  옛 네 줄 = LIGGGHTS stress/atom (접촉 virial 50/50 분할) · 대각 — 이름표 정정 (LHS-29).  상 비 키 = stress_ratio_<상>
            #  (옛 판은 없는 키 sigma_AM_P_ratio 를 읽어 상 비가 보고서에 한 번도 안 나왔다 · 10-04 ④b 같은 묶음에서 고침)
            L.append(f'- **Stress CV (LIGGGHTS stress/atom 50/50 분할 · 대각)**: {metrics["stress_cv"]:.1f}%')
            for ph in ('AM_P', 'AM_S', 'SE'):
                val = metrics.get(f'stress_ratio_{ph}')
                if isinstance(val, (int, float)) and not isinstance(val, bool):
                    L.append(f'- **σ_{ph}/σ_mean (50/50 분할)**: {val:.3f}')
        elif _scv_rl:
            L.append(_scv_rl)
        if metrics.get('stress_lw_status') == 'OK' and isinstance(metrics.get('stress_cv_lw'), (int, float)):
            #  ④b Love–Weber (접촉점 · 9 성분 텐서의 대칭부 · J20-s 10-04) — 벽 · 판 접촉 입자의 벽 힘은 두 규약 다 없다.
            #  RGL-06 이름 한정: 입자 접촉력 기반 대칭 응력의 VM (kinetic · 벽 · couple 미포함) · 벽 제외 = 선별 모집단 (결측 벽 힘 복원 아님)
            L.append(f'- **Stress CV (Love–Weber · 입자 접촉력 기반 대칭 응력의 VM — kinetic · 벽 · couple 미포함)**: '
                     f'{metrics["stress_cv_lw"]:.1f}%'
                     + (f' · 벽 접촉 제외 (선별 모집단 — 결측 벽 힘 복원 아님) {metrics["stress_cv_lw_nowall"]:.1f}%'
                        if isinstance(metrics.get('stress_cv_lw_nowall'), (int, float)) else ''))
            for ph in ('AM_P', 'AM_S', 'SE'):
                val = metrics.get(f'stress_ratio_{ph}_lw')
                if isinstance(val, (int, float)) and not isinstance(val, bool):
                    vn = metrics.get(f'stress_ratio_{ph}_lw_nowall')
                    wf = metrics.get(f'stress_lw_wall_frac_{ph}')
                    L.append(f'- **σ_{ph}/σ_mean (Love–Weber)**: {val:.3f}'
                             + (f' · 벽 접촉 제외 {vn:.3f}' if isinstance(vn, (int, float)) else '')
                             + (f' · 벽 접촉 입자 {100 * wf:.1f}%' if isinstance(wf, (int, float)) else ''))
            if not metrics.get('stress_lw_contract'):
                L.append('- ⚠ Love–Weber 값은 입력 검증 전 세대 (계약 v1 · RGL-06 이전) — 재분석 권장')
        elif metrics.get('stress_lw_status'):
            L.append(f'- **Stress (Love–Weber)**: {metrics["stress_lw_status"]}')
        L.append('')

    L.append('### Scaling Law Reference\n')
    L.append('| Channel | Formula | R² |')
    L.append('|---------|---------|-----|')
    L.append('| σ_ion (v12-clean v3, final) | σ_grain × √(φ−0.2) × CN^(3/2) × cov^(2/5) × f_p³ × C_blend(τ) | 0.981 |')
    L.append('| σ_el | 0.015 × σ_AM × φ_AM^(3/2) × CN_AM² × exp(π/(T/d)) | 0.89 |')
    L.append('| σ_th | 286 × σ_ion^(3/4) × φ_AM² / CN_SE | 0.90 |')
    L.append('')
    L.append('> σ_ion is the v12-clean v3 production model (n=57, LOOCV=0.979): '
             'σ_grain=3.0 mS/cm, φc=0.20; the τ dependence is carried by the '
             'sigmoid-blended prefactor C_blend(τ). See '
             'docs/ionic_scaling_law_experiments.md.')
    # 온도가 적용된 런에서만 한 줄 더 (미적용 = 전 코퍼스 = 이 줄 없음 → 리포트 바이트 동일).
    # 스케일링-법칙의 3.0 은 T_ref=25 °C 규약값이므로, T-스케일된 σ 와 나란히 두면 오독된다.
    if abs(_sg_mS - _se_material().SIGMA_GRAIN_MS_CM_25C) > 1e-12:
        L.append(f'>\n> ⚠ 이 런은 운전온도가 적용되어 σ_grain = {_sg_mS:.4f} mS/cm '
                 f'(= 25 °C 규약값 3.0 × Arrhenius)로 풀렸다. 위 스케일링-법칙 표의 3.0 은 '
                 f'**25 °C 규약값**이며 그 회귀(LOOCV 0.979)는 25 °C 코퍼스에서 적합된 것이다 '
                 f'— 온도축 비교에 그대로 쓰지 말 것 (docs/temp_pressure_capability.md §3-4).')
    L.append('')
    section += 1

    # ── Figures ──
    figures_dir = os.path.join(results_dir, 'figures')
    if os.path.isdir(figures_dir):
        pngs = sorted(os.path.basename(p)
                      for p in globmod.glob(os.path.join(figures_dir, '*.png')))
        if pngs:
            L.append(f'## {section}. Figures ({len(pngs)})\n')
            for fn in pngs:
                L.append(f'### {fn}\n')
                L.append(f'![{fn}](figures/{fn})\n')
            section += 1

    L.append('---\n')
    L.append('*Generated by DEM/MPM Analyzer v3.0 — Kirchhoff Network Solver + Physics Scaling Laws*\n')

    report = '\n'.join(L)

    from io import BytesIO
    fmt = request.args.get('format', 'md')
    if fmt == 'pdf':
        return _generate_pdf_report(report, name)

    buf = BytesIO(report.encode('utf-8'))
    return send_file(buf, mimetype='text/markdown', as_attachment=True,
                    download_name=f'{name}_report.md')


_GRADE_DIR_KR = {
    'higher':        '높을수록 ↑ 좋음',
    'lower':         '낮을수록 ↓ 좋음',
    'band':          '적정 band (optimum 근처일수록 좋음)',
    'higher_corpus': 'corpus 대비 높을수록 ↑ 좋음 (percentile)',
    'lower_corpus':  'corpus 대비 낮을수록 ↓ 좋음 (percentile)',
}


# Plain-language ("쉽게 말하면") explanations per grade axis (keyed by axis
# key), written for a first-time reader.  The technical `meaning` from
# grade_engine is kept intact; the guide shows this friendly version first.
_GRADE_PLAIN = {
    'porosity': '전극 안의 빈 공간 비율이에요 (sphere-sum 방식, production calibration anchor). '
        '빈틈이 너무 많으면 이온·전자가 지날 길이 끊기고, 너무 빽빽하면 충·방전 때 부풀다 깨질 수 있어요. '
        '그래서 적당한 값(약 13%)이 가장 좋습니다.',
    #  ★ 09-30 (웹앱 ① · SELF-72) — 옛 문구 "문헌 비교용" 은 틀렸다 (쌍 렌즈 · 벽 밖 미제거 → 정확 union 보다 낮다)
    'porosity_union': '같은 빈 공간 비율인데, 겹친 쌍마다 렌즈 부피를 한 번 되돌린 "쌍 렌즈" 버전이에요. '
        '세 입자가 겹친 곳과 벽 밖으로 삐져나간 부피는 빼지 않아서, 몬테카를로로 잰 정확한 union '
        '(인계표 porosity_union_exact_pct) 보다 조금 낮게 나와요 (LHS 194 건 전부 · 중앙 0.6 %p). '
        'Sphere-sum 보다는 늘 큽니다 (겹친 만큼 빈공간이 더 보이니까요). sphere-sum 과 나란히 보는 값이에요.',
    'porosity_union_exact_pct': '빈 공간 비율의 "정확한" 버전이에요. 상자 안에 점 400 만 개를 뿌려서 어느 입자에도 '
        '안 들어간 점의 비율을 셉니다 — 셋 이상 겹친 곳도 맞게 세고, 바닥 · 판 밖으로 삐져나간 입자 부피는 고체로 치지 않아요. '
        'LHS 인계표 (porosity_union_exact_pct) 와 같은 계산이고, 점 수 때문에 생기는 오차는 ±0.01 %p 정도예요.',
    'thickness_mass_conserving_um': 'DEM 에서 겹친 부피는 사라져요. 정확한 빈 공간 비율을 실제 값으로 받으면서 재료 양을 '
        '보존하려면 두께가 조금 늘어나야 해요 — 판 간격 × (1 − ε_sphere) / (1 − ε_정확). 인계표 두께 열과 같은 식이에요.',
    'overlap_fraction_pct': '입자들이 서로 얼마나 겹쳤는지(소성변형 정도)를 백분율로 나타낸 값이에요. '
        '380 MPa 압력에서 SE 입자는 문헌상 5-10% 정도 소성변형하는데, 그 범위 안이면 정상. '
        '10% 넘으면 과압축 의심.',
    'thickness_um': '전극을 얼마나 두껍게 쌓았는지예요. 너무 얇으면 실험용 샘플 수준이고, '
        '너무 두꺼우면 이온이 끝까지 가기 힘들어 저항이 커집니다. 60~130μm가 실제 배터리에 쓰는 범위예요.',
    'percolation_pct': '이온이 다니는 고체전해질 길이 위에서 아래까지 끊김 없이 이어진 비율이에요. '
        '100%에 가까울수록 모든 이온이 길을 찾고, 낮으면 막다른 골목(죽은 구역)이 생깁니다.',
    '__cut_fraction': '이온 길에서 "딱 하나 끊으면 전체가 둘로 갈라지는 핵심 길목"이 얼마나 많은지예요. '
        '적을수록 길이 여러 갈래로 튼튼하게 이어진 거라 좋습니다. (다리 하나뿐인 섬 vs 다리 여러 개)',
    '__bn_below_frac': '이온 길 중 "병목(아주 좁은 통로)"이 차지하는 비율이에요. 좁은 통로가 많으면 '
        '거기서 저항이 커져 이온이 느려집니다. 적을수록 좋아요. (고속도로에 좁은 1차선 구간이 적을수록 안 막힘)',
    '__bn_median_norm': '이온이 지나는 통로(접촉면)가 평균적으로 얼마나 넓은지예요. 넓을수록 잘 흐릅니다. '
        '(수도관이 굵을수록 물이 잘 나오는 것과 같아요)',
    'se_se_cn': '고체전해질 알갱이 하나가 평균 몇 개의 이웃과 맞닿아 있는지예요. 많을수록(4~6개) '
        '촘촘히 잘 쌓인 거고, 적으면(<3) 듬성듬성한 상태입니다.',
    'se_se_cn_std': '위 "이웃 수"가 알갱이마다 얼마나 들쭉날쭉한지예요. 작을수록 모두 고르게 쌓인 거라 '
        '좋고, 크면 어떤 건 외톨이·어떤 건 과밀이라 불균일합니다.',
    '__tau_lap_eff': '이온이 위→아래로 갈 때 실제로 얼마나 "돌아가고 좁아져서" 느려지는지를 한 숫자로 '
        '나타낸 거예요(굴곡도 τ · Hertz 접촉 면적 기준 · 그 런의 짝 σ₀ 로 계산 — 케이스 τ 블록 Hertz 칸과 같은 값). 1이면 직선, 클수록 빙 돌아가 느립니다. 작을수록 좋아요. 연속체 모델 입력 칸에 넣는 꼴은 이 값의 제곱(tau2)입니다.',
    '__tau_lap_bulk': '위 굴곡도에서 "좁아짐(병목)" 효과를 빼고 길이 순수하게 얼마나 돌아가는지만 본 값이에요. '
        '구조 자체의 우회 정도입니다.',
    '__constriction_overhead': '전체 굴곡도(Hertz)가 "좁아짐을 뺀 우회"보다 몇 배 더 나빠졌는지예요 — 모델 안의 비라 실제 협착 배수보다 '
        '큽니다(원기둥 bulk 기준). 1배면 좁아짐 손해가 없는 거고, 클수록 좁은 통로 때문에 추가로 느려진 겁니다.',
    'tortuosity_recommended': '이온이 갈 수 있는 가장 짧은 길이 직선 대비 얼마나 더 돌아가는지(기하학적 우회만). '
        '1.0이면 거의 직선, 클수록 미로처럼 돌아갑니다.',
    'path_hop_area_mean_physics': '이온이 길을 한 칸씩 건널 때 거치는 접촉면의 평균 넓이예요. '
        '넓을수록 한 번에 더 많이 흘러서 좋습니다.',
    'coverage_AM_P_mean_physics': '큰 활물질 입자(AM_P) 표면 중 고체전해질이 닿아있는 비율이에요. '
        '많이 닿아야 그 부분에서 이온을 주고받습니다. 60% 이상 권장. '
        '다만 접촉마다 추정한 면적을 표면 한도 없이 더한 값이라, SE 가 많은 전극에서는 100 % 에 붙어(포화) 서로 구분이 안 돼요. '
        '케이스 표의 Physics 열은 이제 겹친 곳을 한 번만 세는 합집합 값이고 이 옛 값은 그 아래 legacy 줄에 있어요 — '
        '이 등급 축은 아직 옛 합-클립 값을 씁니다 (LHS-25 · 축을 바꿀지는 따로 정한다).',
    'coverage_AM_S_mean_physics': '작은 활물질 입자(AM_S) 표면이 고체전해질에 덮인 비율이에요. '
        '작은 입자는 더 고르게 덮일수록 좋습니다. '
        '다만 SE 가 많은 전극에서는 100 % 에 붙어(포화) 서로 구분이 안 돼요. '
        '케이스 표의 Physics 열은 이제 합집합 값이고 이 등급 축은 아직 옛 합-클립 값을 씁니다 (LHS-25).',
    'coverage_AM_mean_physics_rough': '입자 모양 인자(다결정 1.40 · 단결정 1.10 — 가정값)로 표면적을 키워 다시 계산한 전체 덮임 '
        '비율이에요. 활물질이 이온과 만나는 면적이 얼마나 되는지를 봅니다.',
    'am_se_cn_mean': '활물질 입자 하나가 평균 몇 개의 고체전해질과 닿아있는지예요. 많을수록 이온 공급 '
        '통로가 여러 개라 안정적입니다.',
    'ionic_active_pct': '고체전해질 접촉 그래프로 위쪽 (분리막 쪽) 경계 띠까지 이어진 활물질의 비율이에요. 그래프 연결 지표라 '
        '실제 이온 전류 · 계면 저항은 계산하지 않아요 (LREL-05). 낮으면 위로 이어지지 않는 활물질이 많다는 뜻이에요. '
        '그래프로 이어지지 않은 활물질 (경로 기준 고립) 은 100 − 이 값이에요 — '
        '닿은 개수 (0–1 군데) 로 보는 "고립 위험" 과는 다른 양입니다.',
    '__vulnerable_pct': '고체전해질과 닿은 곳이 0–1 군데뿐인 활물질 비율이에요. 닿은 곳이 하나면 그 하나만 끊겨도 '
        '이온이 못 가서, 충·방전을 반복하면 먼저 죽을 수 있어요. 덮인 넓이가 아니라 닿은 개수로 셉니다. 적을수록 좋습니다.',
    '__am_percolation_pct': '활물질끼리 서로 닿아 전자가 위→아래로 통하는 비율이에요. 낮으면 도전재(탄소)를 '
        '넣어 보완할 수 있어 그렇게 치명적이진 않습니다.',
    '__electronic_active_pct': '전자가 아래 집전체(전류 받는 판)까지 도달할 수 있는 활물질 비율이에요. '
        '역시 도전재로 보완 가능합니다.',
    'electronic_sigma_full_mScm_stage_e_physics': '도전재(탄소) 없이 활물질만으로의 전자 전도도예요. '
        '낮아도 탄소 1~3%만 넣으면 크게 좋아지므로 점수 비중은 작게 둡니다.',
    '__frac_severe_force_pct': '압착하는 동안 입자가 "완전히 부서진" 비율이에요. 한번 부서지면 못 '
        '돌아오는 진짜 손상이라 적을수록 좋습니다. 마지막 순간의 힘으로 센 값이라 실제보다 작게 (하한) 나올 수 있어요 (LHS-31).',
    'frac_multicrack_force_pct': '입자에 금이 여러 개 간(완전히 부서진 건 아닌) 비율이에요. 고체전지에선 '
        '일부 금이 오히려 새 접촉면을 만들어 그렇게 나쁘지만은 않아 비중을 작게 둡니다.',
    'fracture_index_force': '압착 중 생긴 균열을 종합한 점수예요(심할수록 큼). 단 사이클 중 손상이 아니라 '
        '제조 시점 손상이라 비중이 작습니다. 마지막 순간의 힘으로 센 값이라 실제 손상보다 작게 (하한) 나올 수 있고, '
        '벽 · 판에 닿은 입자는 빠져 있어요 (LHS-31).',
    '__sigma_vm_cv_pct': '입자들이 받는 힘(응력)이 얼마나 들쭉날쭉한지예요. 작을수록 골고루 눌린 거고, '
        '크면 특정 입자에 힘이 몰리는 "핫스팟"이 있다는 뜻입니다. ⚠ 지금 이 축은 옛 규약 (LIGGGHTS stress/atom 50/50 분할 · '
        '대각) 의 값이에요 — 크기가 다른 입자에서 편향이 있어 (LHS-29) Love–Weber 값으로 바꿀 예정이고, 바뀌는 등급값을 먼저 보고한 뒤에 바꿉니다. '
        '응력 자료가 없거나 망가졌거나 (c_strs 없음 · 입력 무효) 하중이 0 이라 계산이 안 되는 케이스는 0 이 아니라 빈칸이고, 이 축은 등급을 '
        '매기지 않아요 (LHS-33 — 예전에는 0 으로 저장돼 최고 등급으로 보였습니다).',
    'sigma_full_mScm_stage_e_physics': '이 전극의 이온 전도도 — 이온이 얼마나 잘 흐르는지를 나타내는 가장 '
        '중요한 값이에요(높을수록 좋음). 배터리 성능 1순위 지표입니다.',
    'thermal_sigma_full_mScm_stage_e_physics': '열을 얼마나 잘 퍼뜨리는지(냉각 능력)예요. 고체전지에서 '
        '성능을 좌우하는 1차 요소는 아니라 비중이 작습니다.',
    #  ★ L2-07 — 이 키는 **이름과 달리 Bruggeman 이 아니라 CONTACT_FREE/FULL** 이다.
    #    옛 문구는 분자·분모를 모두 바꿔 읽었다 (같은 침대에서 CF/FULL 3.65 ↔ Brug/FULL 0.28).
    'R_brug_over_full_physics': '"접촉 저항이 아예 없다면" 이온 전도도가 지금보다 몇 배였을지예요 '
        '(같은 접촉망 안에서 목 좁아짐만 뺀 값과의 비). 작을수록 접촉 목에서 잃는 몫이 적다는 뜻입니다. '
        '⚠ 이론식(Bruggeman)과 실측을 비교한 값이 아닙니다.',
    #  ★ L2-08 — "전체 저항 중의 비율" 이 아니라 **접촉 하나하나의 비율을 그냥 평균**한 값이다.
    '__constriction_R_fraction_pct': '접촉 하나하나에서 "좁은 통로(병목)" 가 차지하는 저항 비율을 '
        '**그냥 평균**한 값이에요. 작을수록 좁아짐 손해가 적습니다. '
        '⚠ 전류가 거의 안 흐르는 접촉도 똑같이 한 표를 행사하므로, 전극 전체 저항에서 병목이 '
        '차지하는 몫과는 다릅니다 (같은 망에서 이 값 45 % ↔ 실제 몫 8.2 % 인 예가 있습니다).',
    '__Q_gravimetric_mAhg': '무게 1g당 담을 수 있는 전기량(비용량)이에요. 같은 무게로 더 멀리 가는 배터리 '
        '= 높을수록 좋음. 업계에서 가장 중요한 지표 중 하나입니다.',
    '__Q_volumetric_mAhcc': '부피 1cc당 담을 수 있는 전기량이에요. 같은 크기로 더 오래 쓰는 배터리. '
        '상용화 목표는 500 이상입니다.',
    '__commercial_composition': '활물질:고체전해질 무게비가 상용 배터리들이 쓰는 "황금 비율(약 82%)"에 '
        '얼마나 가까운지예요. 한쪽으로 너무 치우치면 비용이나 에너지에서 손해입니다.',
    '__wt_am_pct': '전극에서 활물질이 차지하는 무게 비율이에요. 많을수록 에너지가 크지만, 너무 많으면 '
        '이온 길이 부족해집니다.',
    '__Q_target_match_pct': '이 케이스가 "목표로 한 용량(예: 6 mAh/cm²)"을 실제로 달성했는지 맞춰보는 '
        '거예요. 목표가 없는 케이스는 평가하지 않습니다(N/A).',
    '__ps_ratio_band': '큰 입자:작은 입자 비율이 여러 논문이 최적이라 보는 "7:3" 근처인지예요. 큰 입자 '
        '사이를 작은 입자가 채워 더 촘촘히 쌓입니다.',
    '__r_SE_um': '넣은 고체전해질 알갱이 크기(반지름)예요. 입력값일 뿐 성능 점수엔 거의 영향 없는 참고 정보입니다.',
    '__lambda_eff': '활물질 입자가 고체전해질 입자보다 몇 배 큰지예요. 설계 비율 참고용이고 점수 영향은 작습니다.',
    '__stage_e_available': '문헌 기반 보정(Stage E)이 적용됐는지 체크하는 품질 표시예요. 적용 안 되면 '
        '전도도가 부풀려졌을 수 있습니다.',
    '__compaction_efficiency': '300 MPa로 눌렀을 때 빈 공간이 적당히(12~18%) 줄었는지예요. 너무 누르면 '
        '깨지고, 덜 누르면 접촉이 부족합니다.',
    '__bimodal_design': '큰 입자+작은 입자를 섞은 설계(bimodal)인지예요. 상용 양극은 거의 이렇게 만들어 '
        '더 촘촘히 쌓입니다. 한 종류만 쓴 경우는 페널티 없이 따로 평가합니다.',
    '__volume_change_buffer': '충·방전 때 활물질이 ~5% 부풀어도 견딜 빈 공간(완충 여유)이 충분한지예요. '
        '10% 이상이면 안전, 6% 미만이면 박리 위험.',
    '__asr_ionic_Ohm_cm2': '이온이 전극을 통과할 때 받는 "면적당 저항"이에요(낮을수록 좋음). 100 이하면 '
        '실용 가능. 단 고체전해질이 많으면 자동으로 낮아지니 에너지밀도와 같이 봐야 합니다.',
    '__Q_areal_mAhcm2': '전극 1cm²가 내는 용량이에요. 클수록 같은 저항이라도 더 가치 있는 셀입니다. '
        '5 이상이 상용 목표.',
    '__ASR_per_capacity': '저항을 용량으로 나눈 값 — "용량 대비 저항 부담"이에요. 얇아서 용량이 작으면 같은 '
        '저항이라도 더 불리해지는 걸 잡아냅니다. 작을수록 좋음.',
    '__asr_electronic_Ohm_cm2': '전자가 받는 면적당 저항이에요. 도전재로 낮출 수 있어 비중은 작습니다.',
    '__asr_thermal_Kcm2_W': '열이 빠져나갈 때의 저항(냉각 효율)이에요. 1차 성능 요소는 아닙니다.',
    '__ASR_total_Ohm_cm2': '이온+전자 저항을 합친 전체 저항이에요. 한쪽만 보면 안 되니 합쳐서 봅니다. '
        '낮을수록 좋음.',
    '__c_rate_capability': '전체 저항의 역수 — "빠르게 충·방전할 수 있는 능력"을 직관적으로 본 값이에요. '
        '클수록 고출력에 유리합니다.',
    '__polarization_mV_at_C3': '실제 C/3 속도로 쓸 때 생기는 전압 손실(분극)이에요. 작을수록 효율적이고, '
        '실험(EIS)으로 바로 확인 가능한 값입니다.',
    '__am_am_short_risk_cn': '활물질끼리 얼마나 직접 붙어있는지예요. 2~3개가 적당 — 너무 적으면 전자전도가 '
        '약하고, 너무 많으면 전자가 지름길로 흘러 내부 단락(쇼트) 위험이 커집니다.',
    '__cycle_stable_AM_pct': '충·방전을 반복해도 안정적으로 살아남는 활물질 비율이에요(이온도 닿고, 전자도 '
        '통하고, 심한 손상도 없는 입자). 한번 부서지면 영구 손실이라 수명의 핵심 지표입니다.',
    '__sigma_e_fracture_loss_pct': '입자가 깨져서 전자 전도가 잃은 비율이에요. 단 이건 도전재로 회복 '
        '가능해서 비중은 작습니다.',
    '__validation_pass_pct': '이 분석 결과가 믿을 만한지 자체 점검(Stage E) 통과율이에요. 100%면 완전히 '
        '재현 가능, 60% 미만이면 결과를 의심해야 합니다.',
}


def _fmt_num(v):
    """Compact number formatting for grade-band cutoffs."""
    try:
        f = float(v)
    except (TypeError, ValueError):
        return str(v)
    if f == int(f):
        return str(int(f))
    return f'{f:.4g}'


def _grade_band_desc(ax_meta):
    """Human-readable grade-band breakdown for one axis, derived from its
    thresholds / band / corpus definition.  Scores anchor at A95 B+88 B80
    B-72 C+64 C56 (see grade_engine._interp_score)."""
    direction = ax_meta.get('direction')
    grades = ['A', 'B+', 'B', 'B-', 'C+', 'C']
    if direction in ('higher', 'lower'):
        thr = ax_meta.get('thresholds') or []
        sym = '≥' if direction == 'higher' else '≤'
        tail = '그 미만 D' if direction == 'higher' else '그 초과 D'
        parts = [f'{g} {sym}{_fmt_num(t)}' for g, t in zip(grades, thr)]
        return ' · '.join(parts) + f' · {tail}'
    if direction == 'band':
        opt = ax_meta.get('optimum'); bw = ax_meta.get('band_width', 0)
        return (f'적정값 {_fmt_num(opt)} 기준 |값−optimum|: '
                f'A ≤{_fmt_num(0.2*bw)} · B+ ≤{_fmt_num(0.6*bw)} · '
                f'B ≤{_fmt_num(1.0*bw)} · C+ ≤{_fmt_num(1.5*bw)} · '
                f'C ≤{_fmt_num(2.0*bw)} · 그 밖 D')
    if direction in ('higher_corpus', 'lower_corpus'):
        better = '낮을수록' if direction == 'lower_corpus' else '높을수록'
        return (f'동적 corpus(기준 82개 + 현재 분석된 모든 케이스)의 백분위로 채점 — '
                f'{better} 좋은 백분위에 높은 등급. corpus가 케이스 추가 시 자동으로 '
                f'커집니다. (percolating 필터를 통과하는) 유효 케이스가 5개 미만이면 '
                f'비교 기준이 없어 "—" (채점 불가).')
    return '—'


def _build_grade_guide_md(case_id):
    """Build a per-case '평가표 상세 설명 / grade 근거' document: the grading
    rubric (scale, weighting, corpus rule) plus every axis with this case's
    value+grade+basis and its meaning/formula — pulled live from
    scripts/grade_engine so it never drifts from the 종합 등급 tab."""
    import sys as _sys
    scripts_dir = os.path.join(os.path.dirname(__file__), '..', 'scripts')
    if scripts_dir not in _sys.path:
        _sys.path.insert(0, scripts_dir)
    from grade_engine import AXES, GRADE_SCALE  # noqa: E402

    case_dir = get_case_dir(case_id)
    meta = {}
    meta_file = os.path.join(case_dir, 'meta.json')
    if os.path.exists(meta_file):
        with open(meta_file) as f:
            meta = json.load(f)
    results_dir, _arch = _resolve_results_dir(case_id, meta)
    metrics = {}
    mp = os.path.join(results_dir, 'full_metrics.json')
    if os.path.exists(mp):
        with open(mp) as f:
            metrics = json.load(f)

    result = _grade_engine_result(metrics, results_dir)
    name = meta.get('name', case_id)
    # axis metadata (weight/formula) by label for merging with scored axes
    meta_by_label = {ax['label']: ax for ax in AXES}

    L = [f'# 종합 등급 평가표 상세 설명: {name}',
         f'> Grade rubric & rationale | {datetime.now().strftime("%Y-%m-%d")}',
         '']
    # Grade scale
    L.append('## 등급 척도 (Grade scale)\n')
    L.append('| 등급 | 최소 점수 | GPA |')
    L.append('|------|-----------|-----|')
    for label, cutoff, gpa in GRADE_SCALE:
        L.append(f'| {label} | {cutoff} | {gpa} |')
    L.append('')
    # How scoring works
    L.append('## 채점 방식 (How each axis is scored)\n')
    L.append('- **higher / lower**: 고정 문헌-기반 임계값 6개(A→C)에 값을 보간해 점수화.')
    L.append('- **band**: optimum 근처일수록 A, |값−optimum| 이 커질수록 감점.')
    L.append('- **corpus (higher_corpus / lower_corpus)**: 고정 임계 대신 **백분위(등수)**'
             '로 채점. 비교 명단(corpus)은 **동적** — 기준 82개 baseline에 **현재까지 '
             '분석된(3D 뷰어가 로드된) 모든 케이스를 합쳐** 만들며, 케이스가 추가될수록 '
             '자동으로 커집니다. (percolating 필터를 통과하는) 유효 케이스가 '
             '**5개 미만이면 채점 불가 → "—"**. 예) *Bottleneck burden* 은 `bn_below_frac` '
             '값을 가진 케이스가 아직 5개 미만이면 "—" 로 나오며, 뷰어를 로드한 케이스가 '
             '쌓이면 자동으로 채점됩니다. 또 이 케이스 자체의 SE 진단값(viewer_aux.json)이 '
             '없으면(3D 뷰어 미로드) 값이 없어 "—" 가 됩니다.')
    L.append('- **종합**: 점수가 매겨진 axis들의 **가중평균** (weight 열). '
             '카테고리 평균은 해당 카테고리 axis 점수의 단순평균.')
    L.append('')

    # Quick-scan summary table, then a detailed narrative per axis
    if result and result.get('axes'):
        L.append('## 한눈에 보기 (요약)\n')
        L.append('| 카테고리 | 지표 | 값 | 등급 | 가중치 |')
        L.append('|----------|------|-----|------|--------|')
        for ax in result['axes']:
            v = ax['value']
            vstr = ('—' if v is None else f'{v:.1f}' if abs(v) >= 100
                    else f'{v:.3g}' if abs(v) >= 1 else f'{v:.4g}')
            sc = ax['score']
            gstr = f'{ax["grade"]}({sc:.0f})' if sc is not None else '—'
            wt = meta_by_label.get(ax['label'], {}).get('weight', ax.get('weight', '—'))
            L.append('| ' + ' | '.join(_report_strip_html(x) for x in [
                ax['category'], ax['label'], vstr, gstr, str(wt)]) + ' |')
        L.append('')

        L.append('---\n')
        L.append('# 지표별 상세 설명\n')
        last_cat = None
        for ax in result['axes']:
            cat = ax['category']
            if cat != last_cat:
                L.append(f'## {cat}\n')
                last_cat = cat
            v = ax['value']
            if v is None:
                vstr = '값 없음'
            elif abs(v) >= 100:
                vstr = f'{v:.1f}'
            elif abs(v) >= 1:
                vstr = f'{v:.3g}'
            else:
                vstr = f'{v:.4g}'
            score = ax['score']
            gstr = f'{ax["grade"]} ({score:.0f}점)' if score is not None else '— (채점 불가)'
            ax_meta = meta_by_label.get(ax['label'], {})
            wt = ax_meta.get('weight', ax.get('weight', '—'))
            dir_kr = _GRADE_DIR_KR.get(ax.get('direction'), ax.get('direction') or '—')
            L.append(f'### {_report_strip_html(ax["label"])}\n')
            L.append(f'**이 케이스: {gstr} · 값 = {vstr}**')
            L.append('')
            L.append(f'- **카테고리**: {_report_strip_html(cat)}')
            L.append(f'- **가중치**: {wt}  (종합 가중평균에서의 영향력 — 클수록 핵심 지표)')
            L.append(f'- **방향**: {dir_kr}')
            if ax.get('formula'):
                L.append(f'- **계산식**: `{_report_strip_html(ax["formula"])}`')
            L.append(f'- **등급 구간**: {_report_strip_html(_grade_band_desc(ax_meta))}')
            basis = ax.get('basis')
            if basis and basis != 'no data':
                L.append(f'- **이 케이스 채점 근거**: {_report_strip_html(basis)}')
            elif basis == 'no data':
                L.append('- **이 케이스 채점 근거**: 데이터 없음 — 값 또는 '
                         'corpus 비교군 부족으로 채점되지 않음.')
            plain = _GRADE_PLAIN.get(ax_meta.get('key'))
            if plain:
                L.append('')
                L.append(f'**쉽게 말하면**: {_report_strip_html(plain)}')
            meaning = ax.get('meaning', '')
            if meaning:
                L.append('')
                L.append(f'**자세히 (기술적 근거)**: {_report_strip_html(meaning)}')
            L.append('')
        comp = result.get('composite', {})
        L.append('## 종합 (Composite)\n')
        L.append(f'- **Overall**: {comp.get("grade","—")} '
                 f'({comp.get("score","—")} / 100, '
                 f'GPA {comp.get("gpa","—")} / 4.3) — '
                 f'{comp.get("n_axes","?")}/{comp.get("n_total","?")} axes scored')
        cs = result.get('category_scores', {})
        if cs:
            L.append('')
            L.append('| 카테고리 | 평균 점수 |')
            L.append('|----------|-----------|')
            for c, s in cs.items():
                L.append(f'| {_report_strip_html(c)} | {s:.1f} |')
        L.append('')
    else:
        L.append('> 이 케이스는 종합 등급을 산출할 수 없습니다 (full_metrics.json 없음 '
                 '또는 채점 가능한 axis 없음).')
        L.append('')

    L.append('---\n')
    L.append('*Generated by DEM/MPM Analyzer — grade rubric from scripts/grade_engine.py*')
    return '\n'.join(L), name


@app.route('/results/<case_id>/grade-guide')
def serve_grade_guide(case_id):
    """평가표 상세 설명 + grade 근거 문서 (MD 기본, ?format=pdf 로 PDF)."""
    from io import BytesIO
    report, name = _build_grade_guide_md(case_id)
    if request.args.get('format') == 'pdf':
        return _generate_pdf_report(report, f'{name}_grade_guide')
    buf = BytesIO(report.encode('utf-8'))
    return send_file(buf, mimetype='text/markdown', as_attachment=True,
                    download_name=f'{name}_grade_guide.md')


def _generate_pdf_report(md_text, name):
    """Convert markdown report to PDF."""
    from io import BytesIO
    try:
        import markdown
        html_body = markdown.markdown(md_text, extensions=['tables', 'fenced_code'])
    except ImportError:
        html_body = md_text.replace('\n', '<br>')

    html = f"""<!DOCTYPE html>
<html><head><meta charset="utf-8">
<style>
  body {{ font-family: 'Helvetica Neue', Arial, sans-serif; font-size: 11pt; line-height: 1.6; margin: 40px; color: #222; }}
  h1 {{ font-size: 18pt; border-bottom: 2px solid #333; padding-bottom: 6px; }}
  h2 {{ font-size: 14pt; color: #1a56db; margin-top: 24px; }}
  h3 {{ font-size: 12pt; color: #444; }}
  table {{ border-collapse: collapse; width: 100%; margin: 12px 0; font-size: 10pt; }}
  th, td {{ border: 1px solid #ccc; padding: 6px 10px; text-align: left; }}
  th {{ background: #f0f4ff; font-weight: 600; }}
  code, pre {{ background: #f5f5f5; padding: 2px 6px; border-radius: 3px; font-size: 10pt; }}
  pre {{ padding: 12px; overflow-x: auto; }}
  blockquote {{ border-left: 3px solid #1a56db; padding-left: 12px; color: #555; margin: 8px 0; }}
  hr {{ border: none; border-top: 1px solid #ddd; margin: 20px 0; }}
  ul {{ padding-left: 20px; }}
  li {{ margin: 3px 0; }}
</style>
</head><body>{html_body}</body></html>"""

    # Try weasyprint first, fallback to HTML download
    try:
        from weasyprint import HTML
        pdf_buf = BytesIO()
        HTML(string=html).write_pdf(pdf_buf)
        pdf_buf.seek(0)
        return send_file(pdf_buf, mimetype='application/pdf', as_attachment=True,
                        download_name=f'{name}_report.pdf')
    except ImportError:
        # Fallback: return HTML (browser can print to PDF)
        buf = BytesIO(html.encode('utf-8'))
        return send_file(buf, mimetype='text/html', as_attachment=True,
                        download_name=f'{name}_report.html')

_2D_SCALAR_KEYS = (
    'case_id', 'case_name', 'mode', 'ps_ratio', 'phase_fracs',
    'coverage_2d_pct', 'coverage_3d_target_pct',
    'coverage_AM_P_pct', 'coverage_AM_S_pct',
    'coverage_AM_P_target_pct', 'coverage_AM_S_target_pct',
    'r_AM_P_d50_um', 'r_AM_S_d50_um', 'thickness_um',
    'a_extent', 'b_extent', 'n_pixels', 'pa_um', 'grain_size_um',
)


def _synth_2d_png_path(results_dir, seed=None):
    """Single canonical cache — the last generated figure is 'the existing one'
    shown on load; regenerating overwrites it."""
    return os.path.join(results_dir, 'microstructure_2d.png')


def _synth_2d(case_id, px=600, seed=0, force=False):
    """Synthesize + render the 2D representative microstructure, caching the
    PNG and a scalar summary JSON under the results dir.  Returns the scalar
    summary dict (or None if the case lacks the required data)."""
    import sys as _sys
    case_dir = get_case_dir(case_id)
    results_dir = get_results_dir(case_id)
    atoms_csv = os.path.join(results_dir, 'atoms.csv')
    if not os.path.exists(atoms_csv):
        return None
    png_path = _synth_2d_png_path(results_dir, seed)
    sum_path = png_path.replace('.png', '_summary.json')
    _scripts_dir = app.config['SCRIPTS_FOLDER']
    script_path = os.path.join(_scripts_dir, 'extract_2d_microstructure.py')

    def _stale():
        if not (os.path.exists(png_path) and os.path.exists(sum_path)):
            return True
        cm = os.path.getmtime(png_path)
        # invalidate when the source data OR the generator script changes
        if cm < os.path.getmtime(atoms_csv):
            return True
        if os.path.exists(script_path) and cm < os.path.getmtime(script_path):
            return True
        return False

    if not force and not _stale():
        try:
            with open(sum_path) as f:
                return json.load(f)
        except Exception:
            pass
    if _scripts_dir not in _sys.path:
        _sys.path.insert(0, _scripts_dir)
    import importlib
    import extract_2d_microstructure as ex2d
    ex2d = importlib.reload(ex2d)                    # pick up edits in a live process
    data, gap = ex2d.synthesize_adaptive(Path(case_dir), n_pixels=px, seed=seed)
    if data is None:
        return None
    ex2d.render_png(data, Path(png_path))
    # Clean geometry-only export (LEFT phase map, no axes/labels/legend), kept
    # in sync with the displayed figure.
    try:
        ex2d.render_geometry_png(data, Path(png_path.replace('.png', '_geometry.png')))
    except Exception:
        import traceback; traceback.print_exc()
    summary = {k: data.get(k) for k in _2D_SCALAR_KEYS}
    summary['seed'] = int(seed)                      # remember which seed is shown
    summary['gap_um'] = round(float(gap), 3)         # auto-picked per case
    with open(sum_path, 'w') as f:                   # np.float64 → float for JSON
        json.dump(summary, f, indent=2,
                  default=lambda o: float(o) if hasattr(o, '__float__') else str(o))
    # round-trip so returned scalars are plain Python (csv/format safe)
    return json.loads(json.dumps(summary,
                      default=lambda o: float(o) if hasattr(o, '__float__') else str(o)))


def _synth_2d_auto(case_id, seed=0, px=450, iters=3):
    """Closed-loop generate→check→fine-tune; caches PNG + a JSON report
    (achieved vs target coverage, SE connectivity, per-iteration trace)."""
    import sys as _sys
    import importlib
    case_dir = get_case_dir(case_id)
    results_dir = get_results_dir(case_id)
    if not os.path.exists(os.path.join(results_dir, 'atoms.csv')):
        return None
    _sd = app.config['SCRIPTS_FOLDER']
    if _sd not in _sys.path:
        _sys.path.insert(0, _sd)
    import extract_2d_microstructure as ex2d
    ex2d = importlib.reload(ex2d)
    data, report = ex2d.synthesize_calibrated(Path(case_dir), n_pixels=px,
                                              seed=seed, iters=iters)
    if data is None:
        return None
    png = os.path.join(results_dir, f'microstructure_2d_auto_s{seed}.png')
    ex2d.render_png(data, Path(png))
    out = {'report': report, 'se_conn': ex2d._se_connectivity_pct(data['labels']),
           'phase_fracs': data.get('phase_fracs'), 'ps_ratio': data.get('ps_ratio'),
           'covP': data.get('coverage_AM_P_pct'), 'tgtP': data.get('coverage_AM_P_target_pct'),
           'covS': data.get('coverage_AM_S_pct'), 'tgtS': data.get('coverage_AM_S_target_pct')}
    out = json.loads(json.dumps(out, default=lambda o: float(o) if hasattr(o, '__float__') else str(o)))
    with open(os.path.join(results_dir, f'microstructure_2d_auto_s{seed}.json'), 'w') as f:
        json.dump(out, f)
    return out


@app.route('/results/<case_id>/2d-auto.png')
def serve_2d_auto(case_id):
    """Generate with the auto-calibration loop and serve the figure."""
    seed = int(request.args.get('seed', 0))
    try:
        rep = _synth_2d_auto(case_id, seed=seed)
    except Exception as e:
        import traceback; traceback.print_exc()
        return (f'{type(e).__name__}: {e}', 500)
    if rep is None:
        return ('2D microstructure unavailable (need atoms.csv + meta/params)', 404)
    png = os.path.join(get_results_dir(case_id), f'microstructure_2d_auto_s{seed}.png')
    return send_file(png, mimetype='image/png', as_attachment=False,
                     download_name=f'microstructure_2d_auto_{case_id}_s{seed}.png')


@app.route('/results/<case_id>/2d-auto-report.json')
def serve_2d_auto_report(case_id):
    seed = int(request.args.get('seed', 0))
    p = os.path.join(get_results_dir(case_id), f'microstructure_2d_auto_s{seed}.json')
    if not os.path.exists(p):
        return jsonify({'error': 'not generated yet'}), 404
    return send_file(p, mimetype='application/json')


@app.route('/results/<case_id>/2d-microstructure.png')
def serve_2d_microstructure(case_id):
    """2D microstructure figure.  Without ?fresh=1 it serves the EXISTING
    cached figure (the last one generated); ?fresh=1 regenerates with the given
    (random) seed and overwrites the cache."""
    px = max(200, min(1200, int(request.args.get('px', 600))))
    seed = int(request.args.get('seed', 0))
    force = request.args.get('fresh') in ('1', 'true', 'yes')
    try:
        summary = _synth_2d(case_id, px=px, seed=seed, force=force)
    except Exception as e:
        import traceback; traceback.print_exc()
        return (f'{type(e).__name__}: {e}', 500)
    if summary is None:
        return ('2D microstructure unavailable (need atoms.csv + meta/params)', 404)
    png_path = _synth_2d_png_path(get_results_dir(case_id), seed)
    return send_file(png_path, mimetype='image/png', as_attachment=False,
                     download_name=f'microstructure_2d_{case_id}.png')


@app.route('/results/<case_id>/2d-geometry.png')
def serve_2d_geometry(case_id):
    """Clean geometry-only export of the LEFT phase map (4-phase raster +
    AM_P grain boundaries) — NO axes/ticks/labels/legend/title, high-res.
    Downloads as an attachment.  Stays in sync with the displayed figure."""
    px = max(200, min(1200, int(request.args.get('px', 600))))
    seed = int(request.args.get('seed', 0))
    geo_path = _synth_2d_png_path(get_results_dir(case_id), seed).replace('.png', '_geometry.png')
    force = request.args.get('fresh') in ('1', 'true', 'yes') or not os.path.exists(geo_path)
    try:
        summary = _synth_2d(case_id, px=px, seed=seed, force=force)
    except Exception as e:
        import traceback; traceback.print_exc()
        return (f'{type(e).__name__}: {e}', 500)
    if summary is None:
        return ('2D microstructure unavailable (need atoms.csv + meta/params)', 404)
    if not os.path.exists(geo_path):
        return ('geometry export unavailable', 404)
    return send_file(geo_path, mimetype='image/png', as_attachment=True,
                     download_name=f'microstructure_2d_geometry_{case_id}.png')


@app.route('/results/<case_id>/2d-summary.json')
def serve_2d_summary(case_id):
    """The cached figure's scalar summary (incl. the seed it was made with),
    so the client can keep the ZIP/regenerate in sync with what's shown."""
    p = os.path.join(get_results_dir(case_id), 'microstructure_2d_summary.json')
    if not os.path.exists(p):
        return jsonify({'exists': False}), 200
    try:
        with open(p) as f:
            s = json.load(f)
        s['exists'] = True
        return jsonify(s)
    except Exception:
        return jsonify({'exists': False}), 200


def _build_2d_readme(case_id, s):
    f = s.get('phase_fracs') or {}
    def g(k, d='—'):
        v = s.get(k)
        return d if v is None else v
    return f"""# 2D Representative Microstructure — {s.get('case_name', case_id)}

Procedurally synthesized from the 3D DEM statistics (NOT a literal slice).
A planar slice cannot show the true particle D50 and the correct area
fractions at the same time (Wicksell), so AM particles are placed with a
size distribution whose MEDIAN equals the analysis D50, at the measured
area fractions; SE forms a single connected matrix; porosity is carved to
the measured value; and the AM–SE coverage is matched separately for AM_P
and AM_S.

## Design parameters
- P:S (AM_P:AM_S): {g('ps_ratio')}  (weight; AM_P/AM_S are the same material,
  so weight ratio = volume ratio)
- AM_P D50 radius: {g('r_AM_P_d50_um')} um
- AM_S D50 radius: {g('r_AM_S_d50_um')} um
- electrode thickness: {g('thickness_um')} um

## Achieved (this figure)
- void (porosity): {f.get('void','—')} %
- AM_P: {f.get('AM_P','—')} %   AM_S: {f.get('AM_S','—')} %   SE: {f.get('SE','—')} %
- AM–SE coverage (all): {g('coverage_2d_pct')} %   (3D target {g('coverage_3d_target_pct')} %)
- AM_P coverage: {g('coverage_AM_P_pct')} %  (target {g('coverage_AM_P_target_pct')} %)
- AM_S coverage: {g('coverage_AM_S_pct')} %  (target {g('coverage_AM_S_target_pct')} %)
- domain: {g('a_extent')} x {g('b_extent')} um, {g('n_pixels')} px, {g('pa_um')} um/px

## Files in this archive
- microstructure_2d.png   — 4-phase microstructure (left) + AM–SE coverage (right)
- summary.csv             — all scalar metrics (key, value)
- phase_fractions.csv     — phase area fractions (%)

Coverage convention: covered = AM perimeter touching SE; uncovered = AM
perimeter facing void / another AM (interfacial pore).  Fully-inactive
particles occur only inside multi-particle clusters (held by neighbours);
isolated particles keep some SE contact (no floating particles).
"""


@app.route('/results/<case_id>/2d-export.zip')
def serve_2d_export_zip(case_id):
    """Bundle the full COMSOL-import package: geometry.dxf (vector domains +
    coverage-as-boundary layers), parameters.csv/json (3D effective materials),
    geometry.svg/png preview, microstructure.npy, phase_fractions.csv, and a
    README with COMSOL import steps."""
    import io as _io
    import zipfile
    import sys as _sys
    import importlib
    import tempfile
    px = max(200, min(1200, int(request.args.get('px', 600))))
    seed = int(request.args.get('seed', 0))
    case_dir = get_case_dir(case_id)
    results_dir = get_results_dir(case_id)
    if not os.path.exists(os.path.join(results_dir, 'atoms.csv')):
        return ('2D microstructure unavailable (need atoms.csv + meta/params)', 404)
    meta_file = os.path.join(case_dir, 'meta.json')
    case_name = case_id
    if os.path.exists(meta_file):
        try:
            case_name = json.load(open(meta_file)).get('name', case_id)
        except Exception:
            pass
    _scripts_dir = app.config['SCRIPTS_FOLDER']
    if _scripts_dir not in _sys.path:
        _sys.path.insert(0, _scripts_dir)
    out_dir = None
    try:
        import extract_2d_microstructure as ex2d
        import export_comsol_2d as expc
        ex2d = importlib.reload(ex2d)
        expc = importlib.reload(expc)
        sd, _gap = ex2d.synthesize_adaptive(Path(case_dir), n_pixels=px, seed=seed)
        if sd is None:
            return ('2D microstructure generation failed (missing meta/params)', 404)
        out_dir = tempfile.mkdtemp(prefix=f'comsol_{case_id}_')
        expc.write_comsol_package(case_name, Path(case_dir), sd, out_dir, axis='synth')
        # phase_fractions.csv (convenience; not in the package)
        fr = sd.get('phase_fracs') or {}
        with open(os.path.join(out_dir, 'phase_fractions.csv'), 'w') as f:
            f.write('phase,area_pct\n')
            for ph in ('void', 'AM_P', 'AM_S', 'SE'):
                f.write(f'{ph},{fr.get(ph, "")}\n')
        buf = _io.BytesIO()
        with zipfile.ZipFile(buf, 'w', zipfile.ZIP_DEFLATED) as z:
            for fn in sorted(os.listdir(out_dir)):
                z.write(os.path.join(out_dir, fn), fn)
        buf.seek(0)
    except Exception as e:
        import traceback; traceback.print_exc()
        return (f'{type(e).__name__}: {e}', 500)
    finally:
        if out_dir:
            shutil.rmtree(out_dir, ignore_errors=True)
    return send_file(buf, mimetype='application/zip', as_attachment=True,
                     download_name=f'{case_name}_comsol_2d.zip')


@app.route('/download-file/<case_id>/<filename>')
def download_case_file(case_id, filename):
    """Download an uploaded file from a case."""
    case_dir = get_case_dir(case_id)
    return send_from_directory(case_dir, filename, as_attachment=True)

@app.route('/rename/<case_id>', methods=['POST'])
def rename_case(case_id):
    """Rename a case."""
    new_name = request.form.get('name', '').strip()
    if not new_name:
        return jsonify({'error': '이름을 입력하세요.'}), 400
    case_dir = get_case_dir(case_id)
    meta_file = os.path.join(case_dir, 'meta.json')
    if not os.path.exists(meta_file):
        return jsonify({'error': '케이스를 찾을 수 없습니다.'}), 404
    with open(meta_file) as f:
        meta = json.load(f)
    meta['name'] = new_name
    _ps.atomic_write_json(meta_file, meta)   # ★ 09-26 원자적 쓰기 (temp→fsync→replace) — 제자리 'w' 는 크래시 때 반쪽을 남겼다
    storage_sync.upload_file(f'uploads/{case_id}/meta.json', meta_file)
    return jsonify({'success': True})

@app.route('/favorite/<case_id>', methods=['POST'])
def toggle_favorite(case_id):
    meta_file = os.path.join(get_case_dir(case_id), 'meta.json')
    if not os.path.exists(meta_file):
        return jsonify({'success': False}), 404
    with open(meta_file) as f:
        meta = json.load(f)
    meta['favorite'] = not meta.get('favorite', False)
    _ps.atomic_write_json(meta_file, meta)   # ★ 09-26 원자적 쓰기 (temp→fsync→replace) — 제자리 'w' 는 크래시 때 반쪽을 남겼다
    return jsonify({'success': True, 'favorite': meta['favorite']})

@app.route('/delete/<case_id>', methods=['POST'])
def delete_case(case_id):
    case_dir = get_case_dir(case_id)
    results_dir = get_results_dir(case_id)
    if os.path.exists(case_dir):
        shutil.rmtree(case_dir)
    if os.path.exists(results_dir):
        shutil.rmtree(results_dir)
    storage_sync.delete_prefix(f'uploads/{case_id}')
    storage_sync.delete_prefix(f'results/{case_id}')
    return jsonify({'success': True})

# ─── Archive (보관함) ───────────────────────────────────────────────────────

def _archive_root():
    return app.config['ARCHIVE_FOLDER']

def _safe_path(rel):
    """Prevent path traversal.

    BUG FIX: the old `startswith(base)` check accepted siblings like
    `<base_parent>/archive_evil/...` when the archive root is e.g.
    `/app/archive` — `/app/archive_evil/secret` also starts with the
    base string. Anchor the boundary to `base + os.sep` (or require
    exact equality) so only true descendants are allowed.
    """
    base = os.path.realpath(_archive_root())
    target = os.path.realpath(os.path.join(base, rel))
    if target != base and not target.startswith(base + os.sep):
        return None
    return target

def _scan_folder(abs_path, rel_prefix=''):
    """Recursively scan a folder and return tree structure."""
    items = []
    if not os.path.isdir(abs_path):
        return items
    for name in sorted(os.listdir(abs_path)):
        full = os.path.join(abs_path, name)
        rel = os.path.join(rel_prefix, name) if rel_prefix else name
        if os.path.isdir(full):
            children = _scan_folder(full, rel)
            file_count = sum(1 for c in children if c['type'] == 'file') + \
                         sum(c.get('file_count', 0) for c in children if c['type'] == 'folder')
            items.append({
                'type': 'folder', 'name': name, 'path': rel,
                'children': children, 'file_count': file_count
            })
        else:
            size = os.path.getsize(full)
            items.append({
                'type': 'file', 'name': name, 'path': rel,
                'size': size, 'ext': os.path.splitext(name)[1].lower()
            })
    return items

@app.route('/archive')
def archive():
    tree = _scan_folder(_archive_root())
    current = request.args.get('folder', '')
    # List files in current folder
    if current:
        target = _safe_path(current)
        if not target or not os.path.isdir(target):
            current = ''
    folder_path = _safe_path(current) if current else _archive_root()
    files = []
    folders = []
    for name in sorted(os.listdir(folder_path)):
        full = os.path.join(folder_path, name)
        rel = os.path.join(current, name) if current else name
        if os.path.isdir(full):
            cnt = len([f for f in os.listdir(full) if os.path.isfile(os.path.join(full, f))])
            sub = len([f for f in os.listdir(full) if os.path.isdir(os.path.join(full, f))])
            has_metrics = os.path.exists(os.path.join(full, 'full_metrics.json'))
            folders.append({'name': name, 'path': rel, 'file_count': cnt, 'subfolder_count': sub,
                           'has_metrics': has_metrics})
        else:
            size = os.path.getsize(full)
            files.append({'name': name, 'path': rel, 'size': size,
                         'ext': os.path.splitext(name)[1].lower()})

    # Sort: 0-file folders first, then by name
    folders.sort(key=lambda f: (0 if f['file_count'] == 0 and f['subfolder_count'] == 0 else 1, f['name']))

    # Breadcrumb
    breadcrumb = []
    if current:
        parts = current.split(os.sep)
        for i, p in enumerate(parts):
            breadcrumb.append({'name': p, 'path': os.sep.join(parts[:i+1])})

    return render_template('archive.html', tree=tree, folders=folders, files=files,
                         current=current, breadcrumb=breadcrumb)

@app.route('/archive/create-folder', methods=['POST'])
def archive_create_folder():
    parent = request.form.get('parent', '')
    name = request.form.get('name', '').strip()
    if not name:
        return jsonify({'error': '폴더 이름을 입력하세요.'}), 400
    # Sanitize
    name = name.replace('/', '_').replace('\\', '_').replace('..', '')
    base = _safe_path(parent) if parent else _archive_root()
    if not base:
        return jsonify({'error': '잘못된 경로입니다.'}), 400
    target = os.path.join(base, name)
    os.makedirs(target, exist_ok=True)
    return jsonify({'success': True, 'path': os.path.join(parent, name) if parent else name})

@app.route('/archive/delete', methods=['POST'])
def archive_delete():
    path = request.form.get('path', '')
    target = _safe_path(path)
    if not target or target == os.path.realpath(_archive_root()):
        return jsonify({'error': '삭제할 수 없습니다.'}), 400
    rel = os.path.relpath(target, app.config['ARCHIVE_FOLDER'])
    if os.path.isdir(target):
        storage_sync.delete_prefix(f'archive/{rel}')
        shutil.rmtree(target)
    elif os.path.isfile(target):
        storage_sync.delete_path(f'archive/{rel}')
        os.remove(target)
    return jsonify({'success': True})

@app.route('/archive/rename', methods=['POST'])
def archive_rename():
    old_path = request.form.get('path', '')
    new_name = request.form.get('new_name', '').strip()
    if not new_name:
        return jsonify({'error': '새 이름을 입력하세요.'}), 400
    new_name = new_name.replace('/', '_').replace('\\', '_').replace('..', '')
    target = _safe_path(old_path)
    if not target:
        return jsonify({'error': '잘못된 경로입니다.'}), 400
    parent = os.path.dirname(target)
    new_full = os.path.join(parent, new_name)
    os.rename(target, new_full)
    return jsonify({'success': True})

@app.route('/archive/move', methods=['POST'])
def archive_move():
    src = request.form.get('src', '')
    dst_folder = request.form.get('dst', '')
    src_full = _safe_path(src)
    dst_full = _safe_path(dst_folder) if dst_folder else _archive_root()
    if not src_full or not dst_full:
        return jsonify({'error': '잘못된 경로입니다.'}), 400
    name = os.path.basename(src_full)
    shutil.move(src_full, os.path.join(dst_full, name))
    return jsonify({'success': True})

@app.route('/archive/folders-list')
def archive_folders_list():
    """Return list of archive folder names for save dialog."""
    root = _archive_root()
    folders = []
    if os.path.isdir(root):
        for name in sorted(os.listdir(root)):
            if os.path.isdir(os.path.join(root, name)):
                folders.append(name)
    return jsonify({'folders': folders})

def _save_case_to_archive(case_id, folder=''):
    """Copy a live case (results + meta + raw uploads) into the archive
    (보관함) so it survives results/uploads being cleared, and sync to remote.
    Returns (save_dir, None) on success or (None, error_message)."""
    results_dir = get_results_dir(case_id)
    case_dir = get_case_dir(case_id)
    meta_file = os.path.join(case_dir, 'meta.json')
    if not os.path.exists(meta_file):
        return None, '케이스를 찾을 수 없습니다.'
    with open(meta_file) as f:
        meta = json.load(f)
    case_name = meta.get('name', case_id)
    dst = _safe_path(folder) if folder else _archive_root()
    if not dst:
        return None, '잘못된 경로입니다.'
    # ★ F-06: 표시 이름과 저장 경로를 분리한다.  옛 코드는 사용자가 정한 meta['name'] 을
    #   그대로 경로에 썼는데, 업로드·rename 어디에도 경로 문자 검증이 없어 archive 저장
    #   위치가 루트를 벗어날 수 있었다.  경로에는 slug 만, 표시 이름은 meta 에만.
    slug = _slugify_case_name(case_name, fallback=case_id)
    save_dir = _archive_join(os.path.join(os.path.relpath(dst, _archive_root()), slug)
                             if dst != _archive_root() else slug)
    if os.path.exists(save_dir):
        save_dir = save_dir + '_' + datetime.now().strftime('%H%M%S')
    shutil.copytree(results_dir, save_dir, dirs_exist_ok=True)
    shutil.copy2(meta_file, os.path.join(save_dir, 'meta.json'))
    raw_dir = os.path.join(save_dir, 'raw_files')
    os.makedirs(raw_dir, exist_ok=True)
    for fname in os.listdir(case_dir):
        fpath = os.path.join(case_dir, fname)
        if os.path.isfile(fpath) and fname != 'meta.json':
            shutil.copy2(fpath, os.path.join(raw_dir, fname))
    rel = os.path.relpath(save_dir, app.config['ARCHIVE_FOLDER'])
    storage_sync.sync_dir_to_remote(save_dir, f'archive/{rel}')
    return save_dir, None


@app.route('/archive/save-case', methods=['POST'])
def archive_save_case():
    """Save a case's results to archive folder."""
    save_dir, err = _save_case_to_archive(request.form.get('case_id', ''),
                                          request.form.get('folder', ''))
    if err:
        return jsonify({'error': err}), (404 if '찾을' in err else 400)
    return jsonify({'success': True, 'saved_to': save_dir})


@app.route('/group/save-cases', methods=['POST'])
def group_save_cases():
    """Save all selected LOCAL cases in the group view to the archive in one
    click (archive: cases are already persisted, so they're skipped)."""
    case_ids = request.form.getlist('cases')
    folder = request.form.get('folder', '')
    saved, skipped, errors = [], 0, []
    for cid in case_ids:
        cid = (cid or '').strip()
        if not cid or cid.startswith('archive:'):
            skipped += 1
            continue
        try:
            sd, err = _save_case_to_archive(cid, folder)
            if err:
                errors.append(f'{cid}: {err}')
            else:
                saved.append(os.path.basename(sd))
        except Exception as e:
            errors.append(f'{cid}: {type(e).__name__}: {e}')
    return jsonify({'success': True, 'saved': saved,
                    'skipped': skipped, 'errors': errors})

@app.route('/archive/reanalyze/<path:folder>', methods=['POST'])
def archive_reanalyze(folder):
    """Re-run analysis on an archive case using raw_files."""
    target = _safe_path(folder)
    if not target or not os.path.isdir(target):
        return jsonify({'error': 'Not found'}), 404

    meta_file = os.path.join(target, 'meta.json')
    if not os.path.exists(meta_file):
        return jsonify({'error': 'No meta.json'}), 404

    with open(meta_file) as f:
        meta = json.load(f)

    # Find source files: raw_files/ or directly in folder
    raw_dir = os.path.join(target, 'raw_files')
    source_dir = raw_dir if os.path.isdir(raw_dir) else target

    atom_files = sorted(globmod.glob(os.path.join(source_dir, 'atom*.liggghts')))
    contact_files = sorted(globmod.glob(os.path.join(source_dir, 'contact*.liggghts')))
    mesh_files = sorted(globmod.glob(os.path.join(source_dir, '*.stl')))
    input_files = sorted(globmod.glob(os.path.join(source_dir, 'input*.liggghts')))

    if not atom_files or not contact_files:
        return jsonify({'error': 'No atom/contact files in raw_files/'}), 400

    # Write a status file for polling
    status_file = os.path.join(target, '.reanalyze_status')
    with open(status_file, 'w') as f:
        f.write('running')

    def _run():
        """★ RV-04 (Codex 재검증): archive 재분석이 helper·단계 계약 **밖**에 있었다.

        옛 구현은 parse/contact/coverage/Stage E 를 raw subprocess 로 따로 구현하고
        **모든 rc 를 무시**한 뒤 status 파일에 무조건 'done' 을 썼다.  더구나
        **network solver 를 한 번도 부르지 않아** baseline σ 가 갱신되지 않은 채
        Stage E 만 다시 돌았다 (Codex 가 contact rc=1 로 동적 재현: scripts 4개 호출,
        network_solver_calls=0, helper_calls=0, status='done').

        이제 main pipeline 과 같은 순서·같은 계약을 쓴다:
          parse(required) → contact(required) → coverage(optional) → _network_and_stage_e
        """
        scripts = app.config['SCRIPTS_FOLDER']
        mode = meta.get('mode', 'standard')
        stages, log = [], []
        type_map = _type_map_resolve.map_str_from_meta(meta, 'reprocess pipeline', log)[0]
        scale = meta.get('scale', 1000)

        for pyc in globmod.glob(os.path.join(scripts, '__pycache__', '*.pyc')):
            os.remove(pyc)

        def _finish(status, failed):
            """status 파일에 **사실**을 쓴다 — 옛 코드는 무조건 done 이었다."""
            payload = {'status': status,
                       'failed_stages': [s.get('step') for s in failed]}
            with open(status_file, 'w') as f:
                # 옛 폴러가 'done'/'running' 문자열을 읽으므로 첫 줄은 그 규약을 지킨다.
                f.write(('done' if status in ('done', 'partial') else 'error')
                        + '\n' + json.dumps(payload, ensure_ascii=False))

        cmd = [sys.executable, os.path.join(scripts, 'parse_liggghts.py')]
        cmd += atom_files + contact_files + mesh_files + input_files + ['-o', target]
        st = _ps.run_stage('Parse (archive)', cmd, required=True, results_dir=target,
                           expects=('atoms.csv', 'contacts.csv'))
        stages.append(st); log.append(st)
        if not st.ok:
            _finish(*_ps.summarize(stages))
            return

        atoms_csv = os.path.join(target, 'atoms.csv')
        contacts_csv = os.path.join(target, 'contacts.csv')
        script = 'analyze_contacts_bimodal.py' if mode == 'bimodal' else 'analyze_contacts.py'
        st = _ps.run_stage(
            'Contact Analysis (archive)',
            [sys.executable, os.path.join(scripts, script), atoms_csv, contacts_csv,
             '-o', target, '-t', type_map, '-s', str(scale)],
            required=True, results_dir=target,
            # ★ RC6-05 → RC7-03: archive 재분석도 기존 target 위에 다시 돈다.  지문이 아니라
            #   인과(빈 자리 실행)로 판정한다.
            causal=True,
            expects=('full_metrics.json', 'atoms_analyzed.csv', 'contacts_analyzed.csv',
                     'network_summary.csv'))
        stages.append(st); log.append(st)
        if not st.ok:
            # ★ 필수 단계가 실패하면 network/Stage E 를 돌리지 않는다 (옛 코드는 계속 갔다).
            _finish(*_ps.summarize(stages))
            return

        # coverage 는 --case-dir 를 쓴다 (archive 는 webapp/archive/<category>/<case> 로
        # 중첩될 수 있어 leaf 이름으로는 못 찾는다).  optional.
        st = _ps.run_stage(
            'Coverage Physics vs Hertzian (archive)',
            [sys.executable, os.path.join(scripts, 'coverage_physics_vs_hertzian.py'),
             '--case-dir', target],
            required=False, results_dir=target)
        stages.append(st); log.append(st)

        # ★ network baseline + Stage E — main/retry/batch 와 **같은 helper**.
        #   옛 archive 경로에는 network solver 호출 자체가 없었다.
        try:
            _ns, _rid = _network_and_stage_e(target, scripts, atoms_csv, contacts_csv,
                                             type_map, scale, log, preserve_network=False)
            stages.extend(_ns)
        except _ps.LockUnavailable as _lk:
            stages.append(_ps.StageOutcome(
                step='Network Solver (archive, LOCK 미획득 — 미실행)', stdout='',
                stderr=str(_lk), rc=1, ok=False, required=True, missing_outputs=[]))

        status, failed = _ps.summarize(stages)
        _finish(status, failed)
        print(f"  [Archive Reanalyze] {status} ({folder})"
              + (f" 실패: {[s.get('step') for s in failed]}" if failed else ''))
    thread = threading.Thread(target=_run, daemon=True)
    thread.start()
    return jsonify({'success': True, 'status': 'running'})


@app.route('/archive/reanalyze-status/<path:folder>')
def archive_reanalyze_status(folder):
    target = _safe_path(folder)
    if not target:
        return jsonify({'status': 'unknown'})
    status_file = os.path.join(target, '.reanalyze_status')
    if os.path.exists(status_file):
        # ★ RV-04: 형식이 '<status>\n<json detail>' 로 바뀌었다.  첫 줄은 옛 폴러 규약
        #   ('running'/'done'/'error')을 그대로 지키고, 둘째 줄에 pipeline_status 와
        #   실패 단계를 실어 UI 가 partial 을 done 과 구별할 수 있게 한다 (CB-08 과 같은 취지).
        with open(status_file) as f:
            raw = f.read()
        head, _, detail = raw.partition('\n')
        out = {'status': head.strip() or 'unknown'}
        if detail.strip():
            try:
                d = json.loads(detail)
                out['pipeline_status'] = d.get('status')
                out['failed_stages'] = d.get('failed_stages', [])
            except ValueError:
                pass
        return jsonify(out)
    return jsonify({'status': 'done'})


@app.route('/archive/view/<path:folder>')
def archive_view(folder):
    """View archive case results like single page."""
    target = _safe_path(folder)
    if not target or not os.path.isdir(target):
        return redirect(url_for('archive'))

    results_dir = target
    case_name = os.path.basename(folder)

    # Load meta
    meta = {'name': case_name, 'mode': 'unknown', 'status': 'done'}
    meta_file = os.path.join(results_dir, 'meta.json')
    if os.path.exists(meta_file):
        with open(meta_file) as f:
            meta = json.load(f)
    meta['id'] = f'archive:{folder}'
    meta['name'] = meta.get('name', case_name)

    # Figures
    figures = []
    figures_dir = os.path.join(results_dir, 'figures')
    if os.path.isdir(figures_dir):
        for png in sorted(globmod.glob(os.path.join(figures_dir, '*.png'))):
            figures.append(os.path.basename(png))

    # Report
    report = ''
    report_path = os.path.join(results_dir, 'report.md')
    if os.path.exists(report_path):
        with open(report_path) as f:
            report = f.read()

    # Summary tables + metrics + input_params (shared with /single + report)
    tables, metrics, input_params = _load_case_tables(results_dir, meta)

    return render_template('single.html', case=meta, figures=figures,
                         report=report, tables=tables, metrics=metrics,
                         input_params=input_params, archive_path=folder,
                         mpm_metrics=_load_mpm_metrics(results_dir),
                         trust_card=_build_trust_card(metrics),
                         lv=_page_lv('single'))


@app.route('/archive/results/<path:folder>/figures/<filename>')
def serve_archive_figure(folder, filename):
    target = _safe_path(os.path.join(folder, 'figures'))
    if not target:
        return 'Not found', 404
    return send_from_directory(target, filename)


@app.route('/archive/results/<path:folder>/3d-data')
def serve_archive_3d_data(folder):
    """Serve 3D data for archive case."""
    import pandas as pd
    target = _safe_path(folder)
    if not target:
        return jsonify({'error': 'Not found'}), 404

    meta = {}
    meta_file = os.path.join(target, 'meta.json')
    if os.path.exists(meta_file):
        with open(meta_file) as f:
            meta = json.load(f)
    scale = meta.get('scale', 1000)
    type_map_str = _type_map_resolve.map_str_from_meta(meta, 'viewer payload')[0]
    type_map = {}
    for item in type_map_str.split(','):
        k, v = item.split(':')
        type_map[int(k)] = v.strip()

    atoms_csv = os.path.join(target, 'atoms.csv')
    if not os.path.exists(atoms_csv):
        return jsonify({'error': 'No atom data'}), 404

    contacts_csv = os.path.join(target, 'contacts.csv')
    atoms_only_mode = not os.path.exists(contacts_csv)
    fm_path = os.path.join(target, 'full_metrics.json')
    if os.path.exists(fm_path):
        try:
            with open(fm_path) as f:
                _fm = json.load(f)
            if _fm.get('has_contacts') is False:
                atoms_only_mode = True
        except Exception:
            pass

    df = pd.read_csv(atoms_csv)
    for col in df.columns:
        df[col] = pd.to_numeric(df[col], errors='coerce')

    # Vectorized build (iterrows is ~100x slower and dominates load time on
    # particulate cases with 10^5+ atoms).
    ids = df['id'].astype('int64').tolist()
    ts = df['type'].astype('int64').tolist()
    xs = (df['x'] * scale).round(2).tolist()
    ys = (df['y'] * scale).round(2).tolist()
    zs = (df['z'] * scale).round(2).tolist()
    rs = (df['radius'] * scale).round(2).tolist()
    _tname = {}
    particles = []
    for i in range(len(ids)):
        t = ts[i]
        nm = _tname.get(t)
        if nm is None:
            nm = type_map.get(t, f'T{t}'); _tname[t] = nm
        particles.append({'id': ids[i], 'type': nm,
                          'x': xs[i], 'y': ys[i], 'z': zs[i], 'r': rs[i]})

    # Box bounds from input_params.json
    _box_x, _box_y = 0.05, 0.05
    _ip_path = os.path.join(target, 'input_params.json')
    if os.path.exists(_ip_path):
        with open(_ip_path) as f:
            _ip = json.load(f)
        _box_x = _ip.get('box_x', 0.05)
        _box_y = _ip.get('box_y', 0.05)
    box = {
        'x_min': 0, 'x_max': round(_box_x * scale, 1),
        'y_min': 0, 'y_max': round(_box_y * scale, 1),
        'z_min': 0,
    }
    particle_z_top = max(p['z'] + p['r'] for p in particles) if particles else 0
    mesh_file = os.path.join(target, 'mesh_info.json')
    mesh_triangles = []
    if os.path.exists(mesh_file):
        try:
            with open(mesh_file) as f:
                _mesh_data = json.load(f)
            plate_z_mesh = _mesh_data['plate_z'] * scale
            box['z_max'] = round(min(plate_z_mesh, particle_z_top), 1)
            for tri in _mesh_data.get('triangles', []):
                mesh_triangles.append([
                    [round(v[0] * scale, 3), round(v[1] * scale, 3), round(v[2] * scale, 3)]
                    for v in tri
                ])
        except Exception:
            box['z_max'] = round(particle_z_top, 1)
    else:
        box['z_max'] = round(particle_z_top, 1)

    percolation = {'top_reachable': [], 'bottom_se': [], 'top_se': []}
    perc_path = os.path.join(target, 'percolation_sets.json')
    if os.path.exists(perc_path):
        with open(perc_path) as f:
            percolation = json.load(f)

    paths = []
    paths_path = os.path.join(target, 'tortuosity_paths.json')
    if os.path.exists(paths_path):
        with open(paths_path) as f:
            paths = json.load(f)

    clusters = {}
    clusters_path = os.path.join(target, 'se_clusters.json')
    if os.path.exists(clusters_path):
        with open(clusters_path) as f:
            clusters = json.load(f)

    # ── Auxiliary data for new view modes (mirrors /results/<id>/3d-data) ──
    aux = {
        'stress_max': {}, 'dr_max': {},
        'brittle_pairs': [], 'se_stress_pairs': [],
        'am_se_stress_pairs': [],
        'se_states': {}, 'tabor_stats': {}, 'all_se_ids_count': 0,
        'se_engagement': {},
        'cluster_meta': {}, 'cluster_id_per_se': {},
        'coverage_per_am': {}, 'coverage_per_am_source': None,
        # Phase A1/A3/A4 — per-particle fracture aggregates + stress chain
        'particle_max_fpc': {}, 'particle_worst_stage': {},
        'particle_n_brittle': {}, 'particle_worst_partner_brittle': {},
        'particle_worst_pair_type': {},
        'am_p_skeleton': [], 'stress_chain_segments': [],
        # Phase A5+A6 — SE network diagnostics
        'se_percolating': [], 'se_articulation_points': [],
        'se_bottleneck_edges': [], 'se_dead_end_clusters': [],
        'se_n_percolating': 0,
        'se_bn_median_norm': 0, 'se_bn_threshold_norm': 0,
        'se_n_bn_below_threshold': 0,
    }
    try:
        import sys as _sys
        _scripts_dir = os.path.join(os.path.dirname(__file__), '..', 'scripts')
        if _scripts_dir not in _sys.path:
            _sys.path.insert(0, _scripts_dir)
        from viewer3d_data import (
            aggregate_particle_metrics, classify_clusters,
            build_cluster_id_map, build_coverage_map, coverage_map_column,
            compute_se_network_diagnostics,
        )
        atoms_by_id = {int(r['id']): {
            'type':   int(r['type']),
            'radius': float(r['radius']),
        } for _, r in df.iterrows()}
        if os.path.exists(contacts_csv):
            import time as _t
            # Aux cache (same logic as /results/<id>/3d-data above —
            # 2-3 M contact cases would otherwise re-aggregate per page
            # load).  Keyed on contacts.csv mtime.
            cache_path = os.path.join(target, 'viewer_aux.json')
            contacts_mtime = os.path.getmtime(contacts_csv)
            cache_valid = False
            if os.path.exists(cache_path):
                try:
                    with open(cache_path) as _cf:
                        cached = json.load(_cf)
                    if cached.get('_contacts_mtime') == contacts_mtime and cached.get('_schema') == 12:   # 12 = 입자별 배위수 (10-06)
                        for k in ('stress_max', 'dr_max', 'brittle_pairs',
                                   'se_stress_pairs', 'am_se_stress_pairs',
                                   'se_states', 'tabor_stats', 'all_se_ids_count',
                                   'se_engagement'):
                            if k in cached:
                                if k in ('stress_max', 'dr_max',
                                         'se_engagement'):
                                    aux[k] = {int(kk): v for kk, v
                                               in cached[k].items()}
                                else:
                                    aux[k] = cached[k]
                        for k in ('cn_se_se', 'cn_am_se', 'cn_am_am', 'cn_summary'):   # 배위수 (live 경로는 전 키 복원)
                            if k in cached:
                                aux[k] = cached[k]
                        cache_valid = True
                        print(f'  [3d-data aux/archive] cache HIT')
                except (OSError, ValueError, KeyError) as _ce:
                    print(f'  [3d-data aux/archive] cache invalid: {_ce}')

            if not cache_valid:
                _t0 = _t.time()
                contacts_df = pd.read_csv(contacts_csv, low_memory=False)
                _t1 = _t.time()
                n_rows = len(contacts_df)
                print(f'  [3d-data aux/archive] contacts.csv: {n_rows} rows, '
                      f'read in {_t1-_t0:.1f}s')
                if n_rows > 5_000_000:
                    print(f'  [3d-data aux/archive] skipping aggregate '
                          f'(> 5 M rows; out-of-budget)')
                else:
                    _cols = list(contacts_df.columns)
                    def _stream_records(df, cols=_cols):
                        for tup in df.itertuples(index=False, name=None):
                            yield dict(zip(cols, tup))
                    _t2 = _t.time()
                    agg = aggregate_particle_metrics(
                        _stream_records(contacts_df),
                        atoms_by_id, type_map, scale=scale)
                    _t3 = _t.time()
                    print(f'  [3d-data aux/archive] streaming aggregate '
                          f'in {_t3-_t2:.1f}s (total {_t3-_t0:.1f}s)')
                    aux['stress_max']         = agg['stress_max']
                    aux['dr_max']             = agg['dr_max']
                    aux['brittle_pairs']      = agg['brittle_pairs']
                    aux['se_stress_pairs']    = agg['se_stress_pairs']
                    aux['am_se_stress_pairs'] = agg.get('am_se_stress_pairs', [])
                    aux['se_states']          = agg.get('se_states', {})
                    aux['tabor_stats']        = agg.get('tabor_stats', {})
                    aux['all_se_ids_count']   = agg.get('all_se_ids_count', 0)
                    aux['se_engagement']      = agg.get('se_engagement', {})
                    # Phase A1/A3/A4
                    aux['particle_max_fpc']         = agg.get('particle_max_fpc', {})
                    aux['particle_worst_stage']     = agg.get('particle_worst_stage', {})
                    aux['particle_n_brittle']       = agg.get('particle_n_brittle', {})
                    aux['particle_worst_partner_brittle'] = agg.get('particle_worst_partner_brittle', {})
                    aux['particle_worst_pair_type'] = agg.get('particle_worst_pair_type', {})
                    aux['am_p_skeleton']            = agg.get('am_p_skeleton', [])
                    aux['stress_chain_segments']    = agg.get('stress_chain_segments', [])
                    # 입자별 배위수 + 상별 요약 (3D 뷰어 '배위수' 보기 · 10-06 · 스키마 12)
                    for _k in ('cn_se_se', 'cn_am_se', 'cn_am_am', 'cn_summary'):
                        aux[_k] = agg.get(_k, {})
                    # Phase A5+A6 — SE network diagnostics
                    try:
                        _plate_z_sim = box.get('z_max', 0) / max(scale, 1)
                        _se_diag = compute_se_network_diagnostics(
                            _stream_records(contacts_df), atoms_by_id,
                            type_map, plate_z=_plate_z_sim, scale=scale)
                        aux['se_percolating']           = _se_diag.get('percolating_se', [])
                        aux['se_articulation_points']   = _se_diag.get('articulation_points', [])
                        aux['se_bottleneck_edges']      = _se_diag.get('bottleneck_edges', [])
                        aux['se_dead_end_clusters']     = _se_diag.get('dead_end_clusters', [])
                        aux['se_n_percolating']         = _se_diag.get('n_percolating', 0)
                        aux['se_bn_median_norm']        = _se_diag.get('bn_median_norm', 0)
                        aux['se_bn_threshold_norm']     = _se_diag.get('bn_threshold_norm', 0)
                        aux['se_n_bn_below_threshold']  = _se_diag.get('n_bn_below_threshold', 0)
                        aux['se_n_perc_edges']          = _se_diag.get('n_perc_edges', 0)
                    except Exception as _ediag:
                        print(f'  [3d-data aux/archive] SE diag failed: {_ediag}')
                    try:
                        cache_blob = dict(aux)
                        cache_blob['_contacts_mtime'] = contacts_mtime; cache_blob['_schema'] = 12
                        with open(cache_path, 'w') as _cf:
                            json.dump(cache_blob, _cf, default=str)
                        print(f'  [3d-data aux/archive] cache WROTE')
                    except OSError as _we:
                        print(f'  [3d-data aux/archive] cache write failed: '
                              f'{_we}')
        aux['cluster_meta']      = classify_clusters(clusters)
        aux['cluster_id_per_se'] = {str(k): v for k, v in
                                     build_cluster_id_map(clusters).items()}
        aux['coverage_per_am']   = {str(k): v for k, v in build_coverage_map(
            os.path.join(target, 'coverage_per_am.csv')).items()}
        # 뷰어 범례가 읽은 열을 표지 (physics 없음 → Hertz 계열 대체 · ②-b (f))
        aux['coverage_per_am_source'] = coverage_map_column(
            os.path.join(target, 'coverage_per_am.csv'))
    except Exception as _e:
        import traceback
        print(f'  [3d-data aux/archive] FAILED: '
              f'{type(_e).__name__}: {_e}')
        traceback.print_exc()

    payload = {
        'particles': particles, 'box': box,
        'percolation': percolation, 'paths': paths, 'clusters': clusters,
        'mesh_triangles': mesh_triangles,
        'atoms_only': atoms_only_mode,
        'aux': aux,
    }
    try:
        resp = jsonify(payload)
        body = resp.get_data()
        print(f'  [3d-data/archive] response: {len(body)/1e6:.2f} MB')
        return resp
    except (TypeError, ValueError) as _je:
        import traceback
        traceback.print_exc()
        print(f'  [3d-data/archive] jsonify FAILED — dropping aux')
        payload['aux'] = {}
        payload['_aux_error'] = f'{type(_je).__name__}: {_je}'[:200]
        return jsonify(payload)
    except Exception as _je:
        import traceback
        traceback.print_exc()
        return jsonify({'error': str(_je)[:300],
                         'particles': [], 'aux': {},
                         'box': box, 'atoms_only': True}), 200


@app.route('/archive/results/<path:folder>/save-screenshot', methods=['POST'])
def archive_save_screenshot(folder):
    """Save 3D screenshot to archive figures folder."""
    import base64
    target = _safe_path(folder)
    if not target:
        return jsonify({'error': 'Not found'}), 404
    data = request.get_json()
    if not data or 'image' not in data:
        return jsonify({'error': 'No image data'}), 400
    figures_dir = os.path.join(target, 'figures')
    os.makedirs(figures_dir, exist_ok=True)
    filename = data.get('filename', 'screenshot.png')
    filename = filename.replace('/', '_').replace('\\', '_')
    img_data = data['image'].split(',')[1]
    with open(os.path.join(figures_dir, filename), 'wb') as f:
        f.write(base64.b64decode(img_data))
    return jsonify({'success': True, 'filename': filename})


@app.route('/archive/results/<path:folder>/force-chains')
def serve_archive_force_chains(folder):
    target = _safe_path(folder)
    if not target:
        return jsonify([])
    fc_path = os.path.join(target, 'force_chains.json')
    if os.path.exists(fc_path):
        with open(fc_path) as f:
            return jsonify(json.load(f))
    return jsonify([])


@app.route('/archive/results/<path:folder>/am-contacts')
def serve_archive_am_contacts(folder):
    """AM 하나의 접촉 (3D 뷰어 'AM 접촉 확대' 모달 · archive) — live 경로와 같은 `_am_contacts_response`."""
    target = _safe_path(folder)
    if not target or not os.path.isdir(target):
        return jsonify({'error': 'Not found'}), 404
    meta = {}
    meta_file = os.path.join(target, 'meta.json')
    if os.path.exists(meta_file):
        try:
            with open(meta_file) as f:
                meta = json.load(f) or {}
        except (OSError, ValueError):
            meta = {}
    return _am_contacts_response(target, meta)


@app.route('/archive/results/<path:folder>/network-current')
def serve_archive_network_current(folder):
    """⚡ 전류 흐름 — 보관 케이스 (결과 · meta.json 이 한 폴더)."""
    target = _safe_path(folder)
    if not target:
        return jsonify({'ok': False, 'error': 'not_found', 'message': 'archive folder not found'}), 404
    return _network_current_response(target, os.path.join(target, 'meta.json'))


@app.route('/archive/results/<path:folder>/brittle-z-csv')
def serve_archive_brittle_z_csv(folder):
    target = _safe_path(folder)
    if not target:
        return ('Not found', 404)
    return _brittle_z_csv_response(target, os.path.basename(target.rstrip('/')))


@app.route('/archive/results/<path:folder>/brittle-z-data')
def serve_archive_brittle_z_data(folder):
    target = _safe_path(folder)
    if not target:
        return jsonify({'error': 'Not found'}), 404
    return _brittle_z_data_response(target, os.path.basename(target.rstrip('/')))


@app.route('/archive/results/<path:folder>/brittle-z-png')
def serve_archive_brittle_z_png(folder):
    target = _safe_path(folder)
    if not target:
        return ('Not found', 404)
    return _brittle_z_png_response(target, os.path.basename(target.rstrip('/')))


@app.route('/archive/results/<path:folder>/stress-z-data')
def serve_archive_stress_z_data(folder):
    target = _safe_path(folder)
    if not target:
        return jsonify({'error': 'Not found'}), 404
    return _stress_z_data_response(target, os.path.basename(target.rstrip('/')))


@app.route('/archive/results/<path:folder>/stress-z-png')
def serve_archive_stress_z_png(folder):
    target = _safe_path(folder)
    if not target:
        return ('Not found', 404)
    return _stress_z_png_response(target, os.path.basename(target.rstrip('/')))


@app.route('/archive/results/<path:folder>/stress-z-csv')
def serve_archive_stress_z_csv(folder):
    target = _safe_path(folder)
    if not target:
        return ('Not found', 404)
    return _stress_z_csv_response(target, os.path.basename(target.rstrip('/')))


@app.route('/archive/results/<path:folder>/combined-z-png')
def serve_archive_combined_z_png(folder):
    target = _safe_path(folder)
    if not target:
        return ('Not found', 404)
    return _combined_z_png_response(target, os.path.basename(target.rstrip('/')))


@app.route('/archive/results/<path:folder>/combined-z-csv')
def serve_archive_combined_z_csv(folder):
    target = _safe_path(folder)
    if not target:
        return ('Not found', 404)
    return _combined_z_csv_response(target, os.path.basename(target.rstrip('/')))


@app.route('/archive/results/<path:folder>/coverage-z-data')
def serve_archive_coverage_z_data(folder):
    target = _safe_path(folder)
    if not target:
        return jsonify({'error': 'Not found'}), 404
    return _coverage_z_data_response(target, os.path.basename(target.rstrip('/')))


@app.route('/archive/results/<path:folder>/coverage-z-png')
def serve_archive_coverage_z_png(folder):
    target = _safe_path(folder)
    if not target:
        return ('Not found', 404)
    return _coverage_z_png_response(target, os.path.basename(target.rstrip('/')))


@app.route('/archive/results/<path:folder>/coverage-z-csv')
def serve_archive_coverage_z_csv(folder):
    target = _safe_path(folder)
    if not target:
        return ('Not found', 404)
    return _coverage_z_csv_response(target, os.path.basename(target.rstrip('/')))


@app.route('/archive/download/<path:filepath>')
def archive_download(filepath):
    target = _safe_path(filepath)
    if not target or not os.path.isfile(target):
        return 'File not found', 404
    return send_file(target, as_attachment=True)

@app.route('/archive/preview/<path:filepath>')
def archive_preview(filepath):
    target = _safe_path(filepath)
    if not target or not os.path.isfile(target):
        return 'File not found', 404
    ext = os.path.splitext(target)[1].lower()
    if ext == '.md':
        with open(target) as f:
            content = f.read()
        return jsonify({'type': 'markdown', 'content': content})
    elif ext == '.csv':
        import pandas as pd
        df = pd.read_csv(target)
        return jsonify({'type': 'csv', 'columns': df.columns.tolist(),
                       'data': df.head(100).values.tolist()})
    elif ext == '.png':
        return send_file(target, mimetype='image/png')
    elif ext == '.json':
        with open(target) as f:
            content = f.read()
        return jsonify({'type': 'json', 'content': content})
    return jsonify({'type': 'unknown', 'message': '미리보기를 지원하지 않는 파일 형식입니다.'})

@app.route('/download-doc/<path:filename>')
def download_doc(filename):
    """Download documentation files from project root."""
    doc_dir = os.path.dirname(os.path.dirname(__file__))
    return send_from_directory(doc_dir, filename, as_attachment=True)


# ── Trust Audit dashboard ────────────────────────────────────────────
# Walks every case under webapp/results/** + webapp/archive/** that has
# both atoms.csv and full_metrics.json, then renders the 5-gate matrix.
# This is the live counterpart to scripts/audit_validation_flags.py
# (which produces the CSV / LaTeX for the paper).
_AUDIT_GATE_TIPS = {
    'within_bielefeld_range':
        'ASR_ionic ∈ literature range (Bielefeld 2022 / Lee 2020 / Minnmann 2021)',
    'fracture_distribution_realistic':
        'severe % ≤ 50 and ≥1 Lawn stage populated (Lawn 1998 envelope)',
    'solver_input_intact':
        'Stage-E edge-drop ratio ≤ 0.5 (direct Laplacian dominates)',
    'stage_e_le_baseline_sigma_e':
        'Stage-E σ_e ≤ baseline (factor-≤-1 invariant; Bruggeman bound)',
}
_AUDIT_GATES = list(_AUDIT_GATE_TIPS.keys())


def _audit_discover_cases():
    """Yield (display_id, url, results_dir, archive_rel) for each case that has
    a full_metrics.json, de-duplicated by case NAME across results + archive.
    A case present in both a local results dir and the archive (or under both an
    id- and a name-keyed entry) is listed ONCE; the live local results copy is
    preferred over the archived one."""
    out = []
    seen = set()                       # canonical case names already added
    results_root = app.config.get('RESULTS_FOLDER')
    archive_root = app.config.get('ARCHIVE_FOLDER')

    def _canon(name):
        return (name or '').strip().lower()

    def _results_name(case_id, results_dir):
        for p in (os.path.join(app.config['UPLOAD_FOLDER'], case_id, 'meta.json'),
                  os.path.join(results_dir, 'meta.json')):
            if os.path.exists(p):
                try:
                    nm = json.load(open(p)).get('name')
                    if nm:
                        return nm
                except Exception:
                    pass
        return case_id

    # local results FIRST (live/current copy preferred over an archived one)
    if results_root and os.path.isdir(results_root):
        for case_id in sorted(os.listdir(results_root)):
            d = os.path.join(results_root, case_id)
            if not (os.path.isdir(d)
                    and os.path.exists(os.path.join(d, 'full_metrics.json'))):
                continue
            nm = _results_name(case_id, d)
            key = _canon(nm)
            if key in seen:
                continue
            seen.add(key)
            out.append((nm, url_for('single', case_id=case_id), d, None))

    # archive cases — only if that NAME isn't already shown from results
    if archive_root and os.path.isdir(archive_root):
        for dirpath, _, files in os.walk(archive_root):
            if 'full_metrics.json' in files and 'atoms.csv' in files:
                rel = os.path.relpath(dirpath, archive_root)
                nm = os.path.basename(dirpath)
                key = _canon(nm)
                if key in seen:
                    continue
                seen.add(key)
                out.append((nm, url_for('archive_view', folder=rel), dirpath, rel))
    return out


def _audit_load_row(display_id, url, results_dir, archive_rel):
    try:
        with open(os.path.join(results_dir, 'full_metrics.json')) as f:
            fm = json.load(f)
    except (OSError, ValueError):
        return None

    flags = fm.get('validation_flags') or {}
    campaign = fm.get('campaign') or fm.get('source_case')
    source_case = fm.get('source_case')

    # Pull campaign / source_case from meta.json or input_params.json
    # if missing in full_metrics
    for fname in ('meta.json', 'input_params.json'):
        if campaign and source_case:
            break
        p = os.path.join(results_dir, fname)
        if not os.path.exists(p):
            continue
        try:
            with open(p) as f:
                meta = json.load(f)
            campaign = campaign or meta.get('campaign')
            source_case = source_case or meta.get('source_case') \
                or meta.get('name') or meta.get('case_id')
        except (OSError, ValueError):
            continue

    # Build per-gate cells
    gates = []
    n_fail = n_assess = 0
    for k in _AUDIT_GATES:
        v = flags.get(k)
        if v is None:
            gates.append({'cls': 'na', 'symbol': '—', 'tip': _AUDIT_GATE_TIPS[k] + ' (not assessable)'})
        elif v:
            gates.append({'cls': 'pass', 'symbol': '✓', 'tip': _AUDIT_GATE_TIPS[k]})
            n_assess += 1
        else:
            gates.append({'cls': 'fail', 'symbol': '✗', 'tip': _AUDIT_GATE_TIPS[k] + ' — FAILED'})
            n_fail += 1
            n_assess += 1

    # Bruggeman indicator (5th column, polarity flipped)
    brugg = flags.get('bruggeman_fallback_fired_any')
    if brugg is None:
        gates.append({'cls': 'na', 'symbol': '—', 'tip': 'Bruggeman fallback status unknown'})
    elif brugg:
        gates.append({'cls': 'fail', 'symbol': '●', 'tip': 'Bruggeman fallback fired (EMT carried part of solve)'})
    else:
        gates.append({'cls': 'pass', 'symbol': '○', 'tip': 'Direct solver throughout (no EMT fallback)'})

    if n_assess == 0:
        verdict, verdict_cls = 'N/A', 'na'
    elif n_fail == 0:
        verdict, verdict_cls = '✓ Trust', 'trust'
    elif n_fail == 1:
        verdict, verdict_cls = '~ Warn', 'warn'
    else:
        verdict, verdict_cls = '✗ Untrust', 'fail'

    return {
        'case_dir': display_id,
        'display_id': source_case or display_id,
        'campaign': campaign,
        'source_case': source_case,
        'url': url,
        'gates': gates,
        'brugg_fired': bool(brugg),
        'verdict': verdict,
        'verdict_cls': verdict_cls,
        'archive_rel': archive_rel,
    }


#: ★ v3 (2026-09-09) — **페이지 신선도 선언**.
#:   전수 감사가 잰 것: 웹앱 8 영역 전부에서 기계는 최신인데 라벨이 3~15 개월 뒤였고,
#:   그것을 알아낸 유일한 방법이 **감사를 한 번 도는 것**이었다.  ⇒ 화면이 스스로 말하게 한다.
#:   `updated` = 그 화면의 마지막 **의미 있는** 갱신 (커밋 날짜가 아니라 내용 검토 날짜).
#:   `ledger`  = 그 화면이 서술하는 클레임.  그 뒤에 등재가 움직이면 경고가 뜬다.
#:   ⚠ 날짜를 올릴 때는 **실제로 그 화면을 원장에 맞춰 검토한 뒤**에만 올린다 —
#:     그러지 않으면 이 계기가 거짓 초록을 내는 또 하나의 자리가 된다.
#: ★★ **`findings` 축 신설 2026-09-14 (webapp 감사 D-2).**  `ledger` 만 선언하던 옛 판은
#:   **결함 원장을 아예 안 봤다** — `/single` 이 `updated=2026-09-09` 로 초록 *'검토됐다'* 를
#:   띄우는 동안, 그 화면을 구동하는 코드(`grade_engine`·`generate_comparison_plots`)에 대해
#:   **09-13 자 결함이 6건**(P1 4건) 열려 있었다.  원장이 claims 축으로만 배선돼 있었던 것이다.
#:   ⇒ 규율 ⑤ 의 false-green 이 **매체가 아니라 축**에서 재현됐다.
#:   ⚠ 여기 적는 것은 *"이 화면을 만드는 코드에 걸린 결함"* 이다.  닫히지 않은 것이 하나라도
#:     있으면 **날짜와 무관하게** 초록이 안 나온다 — 다시 본 날이 최신이어도 *'검토됐다'* 가
#:     참이 아니기 때문이다.
PAGE_FRESHNESS = {
    'single':    {'updated': '2026-09-09',
                  'ledger': ['CL-81', 'CL-41', 'CL-33', 'CL-24', 'CL-04'],
                  #  L4-01 종합등급의 ASR 합 · L4-02 source flag 가 등급을 안 막음
                  #  L3-01 은 그림 경로(`generate_comparison_plots`)를 타고 들어온다
                  'findings': ['L4-01', 'L4-02', 'L3-01']},
    'group':     {'updated': '2026-08-07',
                  'ledger': ['CL-12', 'CL-24'],
                  'findings': ['L3-01', 'L3-02']},
    'predictor': {'updated': '2026-08-25', 'ledger': ['CL-24'],
                  'findings': ['AUD-03', 'AUD-04', 'L5-01', 'L5-02', 'L5-06']},
    'eis':       {'updated': '2026-08-03', 'ledger': ['CL-24', 'CL-38'],
                  'findings': ['L4-10']},
    'mpm_lab':   {'updated': '2026-09-07', 'ledger': ['CL-81', 'CL-41'],
                  'findings': []},
    'step5':     {'updated': '2026-07-21', 'ledger': [], 'findings': []},
}


def _page_lv(page):
    """그 페이지용 원장 문맥 (신선도 포함)."""
    f = PAGE_FRESHNESS.get(page) or {}
    return ledger_view.context(page_updated=f.get('updated'),
                               ledger_ids=f.get('ledger') or (),
                               finding_ids=f.get('findings') or ())


@app.route('/ledger')
def ledger_page():
    """판정 원장 — **이 앱이 보여 주는 모든 값의 상태가 여기서 온다.**

    v3 (2026-09-09).  전에는 *"무엇이 철회됐나"* 가 페이지마다 손으로 적힌 산문이었고,
    감사 실측대로 그 산문이 원장을 따라가지 않았다 (8 영역 전부, 3~15 개월 지연).
    ⚠ 금지값 자체는 렌더하지 않는다 — 등록부 패턴이 곧 금지 문자열이라 화면에 뿌리면
    이 페이지가 누수가 된다.  `banned_summary()` 가 개수와 클레임 id 만 준다.
    """
    return render_template(
        'ledger.html',
        lv=ledger_view.context(),
        all_claims=ledger_view.claims(),
        all_findings=ledger_view.open_findings(),
        ledger_error=ledger_view.error())


@app.route('/ledger/before-after')
def ledger_before_after():
    """리뷰 **비포/애프터** — *"무엇을 믿었고 무엇을 쟀나"* 를 항목마다 나란히.

    ★ **요청마다 원장에서 다시 렌더한다** (`scripts/build_review_before_after.render()`).
      커밋된 `docs/reviews/review_before_after.html` 을 그냥 보내면 원장이 움직인 뒤에
      **낡은 페이지를 조용히 서빙**하게 되고, 그것이 이 리포가 반복해 맞은 부류다
      (규율 ④ — 정본은 밖으로 강제되지 않으면 새어나간다).  생성기가 순수 함수라
      디스크에 쓰지 않고 문자열만 받는다.
    ⚠ 렌더가 실패하면 **낡은 파일로 조용히 되돌아가지 않는다** — 실패를 보여 준다.
      (되돌아가면 "페이지는 떠 있는데 원장과 다르다" 가 되고, 그게 감사가 잡은 그 상태다.)
    """
    #  ⚠ 함수 안에서 import 한다 — 모듈 수준에 `html` 을 올리면 이 파일이 지역변수로
    #    쓰는 `html` 들과 가려진다 (실제로 여러 곳에서 쓴다).
    import html as _html
    import importlib.util as _ilu
    import pathlib as _pl
    _p = _pl.Path(__file__).resolve().parent.parent / 'scripts' / 'build_review_before_after.py'
    try:
        _spec = _ilu.spec_from_file_location('_rba', _p)
        _mod = _ilu.module_from_spec(_spec)
        _spec.loader.exec_module(_mod)
        html_out = _mod.render(nav_home='/ledger')
    except Exception as e:                                      # noqa: BLE001
        return (f'<!doctype html><meta charset="utf-8">'
                f'<title>비포/애프터 — 렌더 실패</title>'
                f'<body style="font:14px/1.6 system-ui;padding:2rem;max-width:44rem">'
                f'<h1 style="font-size:1.3rem">비포/애프터를 원장에서 렌더하지 못했다</h1>'
                f'<p><code>{_html.escape(type(e).__name__)}: {_html.escape(str(e))}</code></p>'
                f'<p>⚠ 커밋된 낡은 사본으로 **되돌아가지 않는다** — 원장과 다른 페이지를 띄우는 것이 '
                f'이 페이지가 막으려는 실패다.  생성기를 고친 뒤 새로고침할 것: '
                f'<code>python3 scripts/build_review_before_after.py --selftest</code></p>'
                f'<p><a href="/ledger">← 원장</a></p></body>'), 500
    return Response(html_out, mimetype='text/html; charset=utf-8')


@app.route('/audit')
def audit():
    rows = []
    counts = {'trust': 0, 'warn': 0, 'fail': 0, 'na': 0}
    for display_id, url, results_dir, archive_rel in _audit_discover_cases():
        row = _audit_load_row(display_id, url, results_dir, archive_rel)
        if row is None:
            continue
        rows.append(row)
        counts[row['verdict_cls']] = counts.get(row['verdict_cls'], 0) + 1

    rows.sort(key=lambda r: (r['verdict_cls'] != 'fail',
                              r['verdict_cls'] != 'warn',
                              (r['campaign'] or ''),
                              r['display_id']))

    return render_template('audit.html',
                           rows=rows, counts=counts, total=len(rows))


@app.route('/group/fitting-report', methods=['POST'])
def group_fitting_report():
    """Generate GB correction fitting analysis report (downloadable MD)."""
    selected = request.form.getlist('cases')
    if not selected:
        return jsonify({'error': '케이스를 선택하세요.'}), 400

    # Collect metrics
    input_files = []
    names = []
    for cid in selected:
        if cid.startswith('archive:'):
            archive_rel = cid[len('archive:'):]
            case_path = _archive_join(archive_rel)
            metrics_path = os.path.join(case_path, 'full_metrics.json')
            case_name = os.path.basename(archive_rel)
        else:
            case_path = get_results_dir(cid)
            metrics_path = os.path.join(case_path, 'full_metrics.json')
            meta_file = os.path.join(get_case_dir(cid), 'meta.json')
            case_name = cid
            if os.path.exists(meta_file):
                with open(meta_file) as f:
                    case_name = json.load(f).get('name', cid)
        if os.path.exists(metrics_path):
            input_files.append(metrics_path)
            names.append(case_name)

    if len(input_files) < 3:
        return jsonify({'error': '최소 3개 케이스가 필요합니다.'}), 400

    session_id = datetime.now().strftime('%y%m%d_%H%M%S') + '_fit'
    report_dir = os.path.join(app.config['RESULTS_FOLDER'], 'fitting_reports', session_id)
    os.makedirs(report_dir, exist_ok=True)

    scripts = app.config['SCRIPTS_FOLDER']
    cmd = [sys.executable, os.path.join(scripts, 'generate_fitting_report.py'),
           '-i'] + input_files + ['-n'] + names + ['-o', report_dir]
    result = subprocess.run(cmd, capture_output=True, text=True, timeout=60)

    if result.returncode != 0:
        return jsonify({'error': f'리포트 생성 실패: {result.stderr}'}), 500

    report_path = os.path.join(report_dir, 'fitting_report.md')
    if not os.path.exists(report_path):
        return jsonify({'error': '리포트 파일이 생성되지 않았습니다.'}), 500

    with open(report_path, encoding='utf-8') as f:
        content = f.read()

    return jsonify({
        'success': True,
        'content': content,
        'download_url': f'/group/fitting-report-download/{session_id}'
    })


@app.route('/group/fitting-report-download/<session_id>')
def download_fitting_report(session_id):
    """Download fitting report as markdown file."""
    report_dir = os.path.join(app.config['RESULTS_FOLDER'], 'fitting_reports', session_id)
    return send_from_directory(report_dir, 'fitting_report.md', as_attachment=True,
                              download_name='GB_correction_fitting_report.md')


@app.route('/scaling-report')
def scaling_report():
    """Generate and download scaling law report."""
    import subprocess
    scripts = app.config['SCRIPTS_FOLDER']
    cmd = [sys.executable, os.path.join(scripts, 'generate_scaling_report.py')]
    result = subprocess.run(cmd, capture_output=True, text=True, timeout=60)
    if result.returncode != 0:
        return jsonify({'error': result.stderr[-500:]}), 500
    report_path = os.path.join(app.config['RESULTS_FOLDER'], 'reports', 'scaling_law_report.md')
    if os.path.exists(report_path):
        return send_file(report_path, as_attachment=True,
                        download_name='Scaling_Law_Report.md')
    return jsonify({'error': 'Report generation failed'}), 500

@app.route('/docs/full-report')
def full_report():
    """Download full scaling law report."""
    path = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'docs', 'Scaling_Law_Report_Full.md')
    if os.path.exists(path):
        return send_file(path, as_attachment=True, download_name='Scaling_Law_Report_Full.md')
    return jsonify({'error': 'Not found'}), 404

@app.route('/docs/formula-catalog')
def formula_catalog():
    """Download formula catalog."""
    path = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'docs', 'Formula_Catalog.md')
    if os.path.exists(path):
        return send_file(path, as_attachment=True, download_name='Formula_Catalog.md')
    return jsonify({'error': 'Not found'}), 404


# ─── ML Predictor ──────────────────────────────────────────────────────────

@app.route('/predictor')
def predictor_page():
    """ML-based electrode property predictor page."""
    data_count = predictor_engine.get_data_count(
        app.config['RESULTS_FOLDER'], app.config['ARCHIVE_FOLDER'])
    models_ready = predictor_engine._cached_models is not None
    return render_template('predictor.html', active='predictor',
                           data_count=data_count, models_ready=models_ready,
                           lv=_page_lv('predictor'))


@app.route('/predictor/structure/status')
def predictor_structure_status():
    """구조 예측기(sklearn 불요) 상태 + 타깃별 판정표."""
    try:
        return jsonify(structure_predictor.status())
    except Exception as e:                                     # noqa: BLE001 — 항상 JSON
        return jsonify({'ready': False, 'error': f'{type(e).__name__}: {e}'}), 200


@app.route('/predictor/structure', methods=['POST'])
def predictor_structure():
    """설계 6 노브 → 구조 (판정·PI·외삽 게이트 포함).  REJECT 타깃은 안 내보낸다."""
    d = request.get_json() or {}
    try:
        return jsonify(structure_predictor.predict_structure(
            d_se=float(d.get('d_se', 1.0)), d_am=float(d.get('d_am', 5.0)),
            am_pct=float(d.get('am_pct', 80.0)), ps_frac=float(d.get('ps_frac', 0.5)),
            rve=float(d.get('rve', 50.0)), loading=float(d.get('loading', 6.0)),
            include_weak=bool(d.get('include_weak', True))))
    except Exception as e:                                     # noqa: BLE001
        return jsonify({'ready': False, 'error': f'{type(e).__name__}: {e}'}), 200


@app.route('/predictor/structure/shap', methods=['POST'])
def predictor_structure_shap():
    """설계 노브의 **정확 Shapley** 중요도 (타깃별 100 % 정규화 히트맵).

    ★ 양수영 세미나(2026-08-18) 방법의 이식 — 단 근사 대신 **2⁶ 연합 전수 열거**이고,
      유도 특징이 아니라 **자유노브**에만 건다.  litdb `talks/yang2026_bml_ml_radial_cathode`.
    """
    d = request.get_json() or {}
    try:
        return jsonify(structure_predictor.shap_importance(
            n_explain=int(d.get('n_explain', 48)), n_bg=int(d.get('n_bg', 24)),
            seed=int(d.get('seed', 0)), include_weak=bool(d.get('include_weak', True))))
    except Exception as e:                                     # noqa: BLE001
        return jsonify({'ready': False, 'error': f'{type(e).__name__}: {e}'}), 200


@app.route('/predictor/structure/pareto', methods=['POST'])
def predictor_structure_pareto():
    """다목적 Pareto front + 하이퍼볼륨 추이.  추천은 **물리 경계 안**에서만 고른다."""
    d = request.get_json() or {}
    try:
        return jsonify(structure_predictor.pareto(
            objectives=d.get('objectives'), n=int(d.get('n', 1200)),
            seed=int(d.get('seed', 0)), include_weak=bool(d.get('include_weak', True))))
    except Exception as e:                                     # noqa: BLE001
        return jsonify({'ready': False, 'error': f'{type(e).__name__}: {e}'}), 200


@app.route('/predictor/structure/surface', methods=['POST'])
def predictor_structure_surface():
    """2 인자 응답면 (교호작용 지도) + 실제 코퍼스 산점."""
    d = request.get_json() or {}
    try:
        return jsonify(structure_predictor.surface(
            target=d.get('target', 'tau'), x_knob=d.get('x_knob', 'am_pct'),
            y_knob=d.get('y_knob', 'd_am'), n=int(d.get('n', 25)),
            fixed=d.get('fixed') or None))
    except Exception as e:                                     # noqa: BLE001
        return jsonify({'error': f'{type(e).__name__}: {e}'}), 200


@app.route('/predictor/structure/suggest')
def predictor_structure_suggest():
    """다음 DEM 배치 제안 (순차 D-최적)."""
    try:
        return jsonify(structure_predictor.suggest_batch(
            n=int(request.args.get('n', 10)),
            target=request.args.get('target', 'tau'),
            allow_weak=request.args.get('allow_weak', '') in ('1', 'true', 'yes')))
    except Exception as e:                                     # noqa: BLE001
        return jsonify({'error': f'{type(e).__name__}: {e}', 'rows': []}), 200


@app.route('/predictor/train')
def predictor_train():
    """Train GPR models from existing data.  sklearn 부재(클라우드) 시 raw 500 대신 JSON 안내."""
    try:
        result = predictor_engine.train_models(
            app.config['RESULTS_FOLDER'], app.config['ARCHIVE_FOLDER'])
    except ImportError as e:                                   # sklearn/joblib 미설치 → WSL 안내
        return jsonify({'success': False,
                        'error': f'학습 라이브러리 미설치 ({e}) — WSL/로컬서 pip install scikit-learn joblib 후 학습'}), 200
    except Exception as e:                                     # 그 외도 JSON (JS "Unexpected token <" 방지)
        return jsonify({'success': False, 'error': f'{type(e).__name__}: {e}'}), 200
    return jsonify(result)


@app.route('/predictor/predict', methods=['POST'])
def predictor_predict():
    """Predict electrode properties from design parameters."""
    data = request.get_json()
    if not data:
        return jsonify({'error': 'No input data'}), 400
    try:
        result = predictor_engine.predict(
            d_se=float(data.get('d_se', 1.0)),
            d_am=float(data.get('d_am', 5.0)),
            am_pct=float(data.get('am_pct', 80)),
            ps_frac=float(data.get('ps_frac', 0.5)),
            loading=float(data.get('loading', 6)),
            rve=float(data.get('rve', 50)),
            temperature=float(data.get('temperature', 298)),
            additive=data.get('additive', 'none'),
            ptfe=bool(data.get('ptfe', False)),
            # ★온도 규약 (docs/temp_pressure_capability.md T1-c/T1-e): σ_e 는 기본 T-무관
            #   ('none' = 문헌 Reisacher + 솔버 정합).  'legacy_arrhenius' 는 2026-07-28 이전
            #   Ea_AM=0.50 eV('rough', 미앵커 §F1) 재현용.  ea_ion_ev 는 밴드 스윕(0.29/0.41/0.46)용
            #   — 미지정이면 엔진 기본(0.41) → 요청에 안 실으면 동작 불변.
            sigma_e_t_model=str(data.get('sigma_e_t_model', 'none')),
            ea_ion_ev=(float(data['ea_ion_ev']) if data.get('ea_ion_ev') not in (None, '') else None),
        )
        return jsonify(result)
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@app.route('/predictor/optimal')
def predictor_optimal():
    """Find optimal design by sweeping parameter space."""
    try:
        fixed = json.loads(request.args.get('fixed', '{}'))
        sweep = json.loads(request.args.get('sweep', '[]'))
        defaults = {}
        for k, v in request.args.items():
            if k in ('fixed', 'sweep'): continue
            try:
                defaults[k] = float(v)
            except (ValueError, TypeError):
                defaults[k] = v  # keep string for additive, ptfe etc.
        result = predictor_engine.sweep_optimal(
            top_n=10, fixed_params=fixed, sweep_keys=sweep if sweep else None, defaults=defaults
        )
        if isinstance(result, dict) and 'error' in result:
            return jsonify(result), 400
        return jsonify(result)
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@app.route('/predictor/heatmap', methods=['POST'])
def predictor_heatmap():
    """Generate 2D heatmap data for two parameters vs a target."""
    data = request.get_json()
    if not data:
        return jsonify({'error': 'No input data'}), 400
    try:
        fixed = {}
        for k in ['d_se', 'd_am', 'am_pct', 'ps_frac', 'loading', 'rve']:
            if k in data.get('fixed', {}):
                fixed[k] = float(data['fixed'][k])
        result = predictor_engine.generate_heatmap(
            x_param=data.get('x_param', 'd_se'),
            y_param=data.get('y_param', 'am_pct'),
            target=data.get('target', 'sigma_ionic'),
            fixed_params=fixed,
            n_points=int(data.get('n_points', 15)),
        )
        return jsonify(result)
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@app.route('/predictor/phase-diagram', methods=['POST'])
def predictor_phase_diagram():
    """Generate phase diagram with contour boundaries."""
    data = request.get_json()
    if not data:
        return jsonify({'error': 'No input data'}), 400
    try:
        fixed = {}
        for k in ['d_se', 'd_am', 'am_pct', 'ps_frac', 'loading', 'rve']:
            if k in data.get('fixed', {}):
                fixed[k] = float(data['fixed'][k])
        result = predictor_engine.generate_phase_diagram(
            x_param=data.get('x_param', 'd_se'),
            y_param=data.get('y_param', 'am_pct'),
            fixed_params=fixed,
            n_points=int(data.get('n_points', 30)),
        )
        return jsonify(result)
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@app.route('/predictor/sensitivity', methods=['POST'])
def predictor_sensitivity():
    """Sensitivity analysis: vary each param +/-30%."""
    data = request.get_json()
    if not data:
        return jsonify({'error': 'No input data'}), 400
    try:
        result = predictor_engine.sensitivity_analysis(data)
        return jsonify(result)
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@app.route('/predictor/pareto', methods=['POST'])
def predictor_pareto():
    """Compute Pareto front for sigma_ionic vs energy density."""
    data = request.get_json() or {}
    try:
        fixed = {}
        for k in ['d_am', 'ps_frac', 'rve']:
            if k in data:
                fixed[k] = float(data[k])
        result = predictor_engine.compute_pareto(fixed_params=fixed, n_points=int(data.get('n_points', 8)))
        return jsonify(result)
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@app.route('/predictor/suggest')
def predictor_suggest():
    """Suggest next DEM conditions using Bayesian optimization."""
    try:
        result = predictor_engine.suggest_next(
            app.config['RESULTS_FOLDER'], app.config['ARCHIVE_FOLDER'])
        return jsonify(result)
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@app.route('/predictor/export')
def predictor_export():
    """Export training data as CSV download."""
    try:
        csv_str = predictor_engine.export_training_csv(
            app.config['RESULTS_FOLDER'], app.config['ARCHIVE_FOLDER'])
        if not csv_str:
            return jsonify({'error': 'No training data available'}), 404
        import io
        buf = io.BytesIO(csv_str.encode('utf-8'))
        buf.seek(0)
        return send_file(buf, mimetype='text/csv', as_attachment=True,
                         download_name='predictor_training_data.csv')
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@app.route('/healthz')
def healthz():
    """배포 헬스체크 — 인증 게이트 면제 경로 (상태를 바꾸지 않는다)."""
    return jsonify({'ok': True})


# ── 인증 게이트 설치 (코드리뷰 F-01) ────────────────────────────────────────────
#   모든 라우트가 등록된 **뒤에** 설치한다 (before_request 는 순서와 무관하지만,
#   /login·/logout 이름 충돌을 여기서 바로 확인할 수 있다).
#   WEBAPP_REQUIRE_AUTH 미설정 = 사설망/로컬 가정으로 기존 동작 유지.
try:
    from . import security as _sec
except ImportError:
    import security as _sec
_AUTH_ON, _AUTH_HAS_TOKEN = _sec.init_security(app)


if __name__ == '__main__':
    port = int(os.environ.get('PORT', 5000))
    # debug OFF by default — host=0.0.0.0 exposes the app, and Flask's debug=True enables the
    # Werkzeug debugger (remote code execution on a public IP).  Opt in locally with FLASK_DEBUG=1.
    debug = os.environ.get('FLASK_DEBUG', '').lower() in ('1', 'true', 'yes', 'on')
    app.run(debug=debug, host='0.0.0.0', port=port)

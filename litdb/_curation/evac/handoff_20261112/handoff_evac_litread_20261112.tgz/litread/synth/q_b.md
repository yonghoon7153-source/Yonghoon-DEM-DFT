# 질문 b — 배치별 근거 묶음 (원문 줄 그대로 · 파일 41 개)

### [batch_01] b. 압력을 뺄 때 되돌아오는 양과 잰 방법

되돌아온 양의 **수치는 이 배치에 없음**. 아래는 정성 서술과 계산 조건.

- [b] lim2025_virtual_calendering_framework | 값 없음 — strain-controlled 탄성 압축이라 스프링백 미반영 · 가상 압축한 3.6 g/cm³ 윗면이 실제 재구성 3.6 보다 "더 평평" (정성). 실제 쪽 = 캘린더링을 마친 전극 (뺀 뒤) 을 FIB-SEM 으로 재구성 · 도메인 두께 85 µm (압축 전 2.3) → 55 µm (3.6) | §3.2 (L146–148) · §3.1 (L133) | 카드 표기 "한계(명시)" · 두께 값 표지 없음 | NCM622 + Super P + PVDF 액체계 전극 (SE 없음) · 되돌아온 양을 숫자로 주지 않음
- [b] choi2024_digital_twin_review_echem | 값 없음 — 압연 DEM 자료를 학습한 공정 모델이 "압축 – 스프링백 (sb) – 접촉 면적 · 다공도 · 굴곡도" 를 예측 대상으로 둔다 (ref 112 · Galvez-Aranda) | §8.1 Fig 6c (L338–340) · p.29 | 표지 없음 | 총설의 그림 인용 · 잰 방법 카드에 없음
- [b] nam2026_dpe_microstructure_review | 값 없음 — 큰 다결정 + 작은 단결정 혼합은 packing density 가 높아 "사이클 중 elastic spring-back 억제" (정성) | §3.4.1 (L280–281) · Fig 6b · ref 116 | 표지 없음 | Li-ion 건식전극 · 가압 직후 탈압이 아니라 사이클 중 서술
- [b] bardenhagen2001_mpm_improved_contact_granular_stress_waves | 되돌아옴을 계산하는 조건 (값 없음): 분리를 운동학만으로 판정하면 "frictionless collisions … slightly increase system energy" · 수직 견인력 판정 (t_n < 0 이면 접촉 유지) 이면 "slightly dissipative" · 계면은 "unloaded to their stress free state" | §3 표 (L69) · §0 (L18–22) · p.512 | stated (산문) · 에너지 크기 수치 없음 (L138) | 탄성 물체의 되튐 서술 · 제하 곡선 없음 · 소성 없음
- [b] bardenhagen2000_mpm_granular_multibody_frictional_contact | 논문에 제하 없음 — 카드의 우리 쪽 상태표: DEM = 제하 있음 · MPM = "부분 (재시작 제하)" | §8-1 (L304) | 표지 없음 (우리 쪽 기록) | 값 없음


### [batch_02] b. 압력을 뺄 때 되돌아오는 양과 잰 방법

- [b] pycompact2025_dem_mpfem_workflow | Fe–Si–Al–P · 3D: 기공이 하중 중 @2000 MPa ≈ 4.5 % (Coarse) / ≈ 3.5 % (Fine) → 제하 뒤 (P → 0) ≈ 17 / ≈ 16 %; 제하 가지는 1000 MPa 에서도 ≈ 5 / 4 % 로 거의 평평하다가 P → 0 에서 수직으로 튐 | §3.3 (L107–108) · §9.5 (L412–415) · Fig 4b | digitized | 금속 · 1400–2000 MPa · 시드 1 개 · 고체 부피 = 압축 전 초기 구 부피 합 (stated · L110)
- [b] pycompact2025_dem_mpfem_workflow | 응력–변형 루프: 정점 ε ≈ 0.622 / 0.577 @2000 MPa → 제하 뒤 잔류 ε ≈ 0.598 / 0.556 ⇒ Δε ≈ 0.024 / 0.020 (압축 높이 대비 회복률 6.3 / 4.7 %) | §9.4 (L405–407) · Fig 4a | digitized (회복률은 derived(ours)) | 변형의 정규화 길이 미기재 → 절대 변형값 해석 불가 (L408–409)
- [b] pycompact2025_dem_mpfem_workflow | 잰 방법: 상대밀도 = Σ 초기 구 부피 / RVE 부피, RVE 부피는 제하 중 5 MPa 도달 시점 — "a designated pressure level of 5 MPa was established as the threshold for determining the volume of the compacted powders in the unloading phase." | §3.3 (L109–110) · §10 (L466–467) · §14 (L577–579) | stated | 문턱이 제하 곡선의 수직 구간 위 (≈ 9 → ≈ 17 % 가 마지막 수십 MPa 안 · L468–470) · 제하 뒤 상대밀도 세 경로 ≈ 90.3 (Fig 4a 유도 · derived(ours)) / ≈ 83–84 (Fig 4b · digitized) / 85.4 % (stated) 가 5–7 %p 어긋남 (L471–477)
- [b] pycompact2025_dem_mpfem_workflow | 마찰이 되돌아감을 잠금: μ 0.1 → 0.2 → 0.3 에서 제하 뒤 상대밀도 ≈ 84.2 → 85.4 → 86.0 % (Coarse · 2000 MPa) · 저자 기전 "plateauing beyond µ = 0.2 due to reduced sliding and elastic recovery" · 제하 프레임에서 입자 사이 틈이 넓어짐 (접촉이 열림) | §3.4 (L119) · §9.2 (L387–389) · §9.6 (L428) · Fig 3f · 4e/f | digitized (기전 문장은 stated) | "접촉이 열린다" 는 카드의 그림 관찰 · 정량 없음
- [b] pycompact2025_dem_mpfem_workflow | 탄성 회복 변형 어림: 그들 2000 MPa / 170 GPa = 1.2 % · 우리 DEM (300 MPa · E_eff 1.35 · ν 0.3 ⇒ K 1.125 GPa) 체적 26.7 % · 우리 MPM (K 25.5 GPa) 체적 1.2 % | §15.5 (L685–690) | derived(ours) | 우리 쪽 산술 (논문 값 아님) · 표 머리는 P/E 인데 우리 두 행은 P/K (카드 문제 A-5)
- [b] nguyen2017_mpm_bpm_deformable_particle_compaction | BPM 단일 입자 (2D · 강체 1차입자 1750 개 응집체) 를 ε 10 % · 30 % 에서 제하: 응력이 선형으로 하강 ("stress decreases linearly … slope … increase slightly with strain") · 잔류 ε ≈ 0.092 · 0.294 → 회복 변형 ≈ 0.008–0.009 · 제하 안내선 기울기 ≈ 52 → ≈ 109 MPa | §3.3 (L118) · §5.1 (L182–183) · Fig 1 | stated / digitized | 2D · 재료 σ_y 가 아닌 응집체 문턱 · 잰 방법 σ = F/L · ε = ln(1 + d/R) (L94) · MPM 쪽 제하는 없음 · 30 % 쪽 숫자가 카드 안에서 닫히지 않음 (카드 문제 A-6)
- [b] nguyen2017_mpm_bpm_deformable_particle_compaction | 카드의 가설: 집합체 되돌아옴의 주역이 입자 내부 탄성이 아니라 접촉 열림일 수 있다 → 분리가 불가능한 단일 속도장 MPM 은 제하를 원리적으로 과소평가 | §8-⑤ (L298–300) | "카드 간 종합 · 우리 추론" | 가설 (시험 전) · BPM 2D 단일 입자와 금속 MPFEM 두 카드를 이은 것
- [b] nezamabadi2022_mpm_cd_plastic_particle_compaction | 제하 없음 ("제하는 이 논문에서 얻을 것이 없다") · 우리 쪽: DEM 언로딩 진행 중 · MPM 은 300 → 90 MPa 재시작 기능만 (0 까지 대조한 적 없음) · "실험 대조된 제하는 셋 다 없음" | §7.1 표 제하 행 (L354) · §9 행동 8 (L453–454) | 표지 없음 | 우리 쪽 기록 포함
- [b] alabdali2023_cgmd_wet_manufacturing_ssb_cathode | 탈압 없음: "springback (압연 후 회복) n/a — 평판을 떼는 서술 없음 (후속 Weitze 2024 는 있음)" · 구조가 하중이 걸린 상태일 가능성 | §3-4 (L168) · §10-20 (L709–710) | 표지 없음 (n/a) | "가능성" 은 카드의 판단
- stomakhin2013 · alizadeh2018: 카드에 없음.


### [batch_03] b. 압력을 뺄 때 되돌아오는 양과 잰 방법

되돌아온 양의 **수치는 이 배치에 없음**. 다섯 카드 모두 하중 쪽만 다룬다.

- [b] cardenasbarrantes2020_rigid_deformable_mixture_compaction_nscd | 탈압 없음 — "하중 쪽만 다룬다 (탈압 · 스프링백 없음)" · 무른 입자가 초탄성이라 소성 잔류 · 탈압 후 기공 유지가 "원리적으로 없다" · "탈압 시 마찰 고착 몫 말고는 되돌아올 것" 은 카드의 추론 (논문은 탈압을 안 함) | §0 (L40–41) · §3-5 (L170) · §8-2 (L435) · §12-A (L572) | 표지 없음 (L435 는 카드가 "추론" 이라 적음) | 2D · 초탄성 · 잰 방법 없음
- [b] cardenasbarrantes2020_rigid_deformable_mixture_compaction_nscd | 체적탄성률 K(φ) 는 "탈압 (스프링백) 강성과 이어지는 양이지만 논문은 하중 쪽만" · 우리 쪽 상태표: DEM = gen-2 언로딩 (진행 중) · MPM = 부분 (300 → 90 MPa 재시작만) | 그림 4 설명 (L360) · §8-0 (L419) | 표지 없음 (우리 쪽 기록) | 값 없음
- [b] cardenasbarrantes2021_soft_rigid_mix_compaction_proceedings | 탈압 없음 ("수송 · 피복 · 힘사슬 · 탈압 없음") | §7 (L168–169) | 표지 없음 | 모체와 같은 계산
- [b] cardenasbarrantes2022_soft_hard_grains_compaction_experiment_dic | 탈압 없음 — 하중 단계마다 0.5 mm 이동 (2 mm/min) → 1 min 이완 → 스캔 (누른 채 측정) | §0 (L32) · §3-1 (L89) · §3-5 (L142) · §12-A (L396) | stated (절차) | 2D · 초탄성 실리콘 (가역) · kPa
- [b] arzt1982_particle_coordination_densification_spheres · bouvard2000_hard_soft_powder_densification | 탈압 · 되돌아옴 서술은 카드에 없음 | — | — | —


### [batch_04] b. 압력을 뺄 때 되돌아오는 양과 잰 방법

되돌아온 양의 **수치는 이 배치에 없음**.

- [b] giannis2021_stress_based_multicontact_dem | 수치 없음. 514 하이드로겔 침대 = z 단축 압축 → ε_max 13.4 % → 감압 (decompression) 의 응력–변형 곡선 (Fig 11 · 0–600 Pa) · 514 고무 침대 = 압축 + 감압 (Fig 15 · 0–300 kPa × 0–28 % · 실험 곡선 없음). 잰 방법 = 변위 제어 (공학 변형률) · 벽 반력 / 단면적 → 공학 응력 | §4.8 표 (L256–261) · §5 Fig 11 · 15 행 (L293 · L297) · §6 (L305) | 프로토콜 = 표지 없음 (카드 서술) · 곡선 = digitized (TREND only) | 탄성 재료 (하이드로겔 · 고무) · 소성 없음 → 영구 변형 · 되돌아온 비율 없음 · 감압 가지의 값은 카드에 옮겨져 있지 않음
- [b] giannis2021_stress_based_multicontact_dem | 제하 가지에 다접촉 보정을 얹을 때의 문제 (카드 판정): 이력 법칙 (δ_max 기억) 은 제하 가지에서 힘이 급락 — 거기에 양의 P 항을 더하면 총 힘이 재하 가지 위로 올라가 k₁ ≤ k₂ ≤ k̂₂ 서열을 깬다 · Giannis 의 기반은 경로 무관 Hertz 라 이 문제가 없다 → "보정을 재하 가지에만 적용하거나 f_n ≤ k̂₂-가지로 clamp" | §7-2 가드 ① (L349–351) | 표지 없음 (카드의 우리 쪽 판정 · 시험 전) | 논문 내용 아님
- [b] dmt1975_adhesion_contact_deformation | 되돌아오는 양 없음 — 떼는 (pull-off) 힘의 정의만: F₀ = 2πRγ (점접촉 α = 0) · 접촉 변형이 생겨도 떼는 힘은 늘지 않음 · 무하중에서도 접촉 면적 S = παR = πa² 가 유한 | §3 표 (L35 · L39) · §1 (L15–17) | stated (eq 41/51 · eq 60) | 탄성 구–평면 한 쌍 · 예시 폴리스티렌–강철 · 소성 압흔 없음. 카드: 깊이 압밀된 SE–SE 의 소성 pull-off 증가는 Thornton–Ning (eq 77 · P_cr = 1.5πΓR_p*) 소관 (L144–145)
- [b] coetzee2017_dem_calibration_review | 리뷰에 탈압 · 되돌아옴 서술 없음. 카드의 우리 쪽 검증 후보에 "(b) 다압력 두께/스프링백" 만 거명 | §11-② (L877–880) | 표지 없음 (우리 쪽 실행 항목) | 값 없음
- [b] electromechanical_contact_model_particulate_systems · deng2021_mechanical_surface_energy_tester_bond_number | 이 배치에 없음 (탈압 없음) | — | — | —


### [batch_05] b. 압력을 뺄 때 되돌아오는 양과 잰 방법

- [b] heck2026_densification_sulfide_se_binder_scalable | 순간 탄성 회복 (springback): 3 wt% HNBR 6.7 % (1 mm/min) · 9.2 % (5 mm/min) · 4.3 wt% 7.9 % · 10.4 %; 수염 범위 5.4–7.7 · 8.6–10.0 · 7.3–8.5 · 8.7–11.8 (+ 이상점 12.9). 방법: 재료시험기 · 위 플런저 Ø1 mm · 500 N ≈ 640 MPa · 가압 = 감압 속도 · 장치 회복 보정 d_p,corr = d_p + F/a_corr (Eq 2) · Springback = (δ_a − δ_max)/δ_max × 100 % (Eq 3 · δ_a = 시료와 플런저 접촉이 끊기는 보정 거리 · δ_max = 최대 하중 보정 거리) · 각 13–15 회 · Welch p (바인더량 10 × 10⁻⁶ · 2 × 10⁻³ / 속도 4 × 10⁻¹¹ · 2 × 10⁻⁶) | §3-8 (L146–152) · §3-1 (L62) · Fig 12 · p.5 · p.14 | 평균 = [인쇄] · 수염 = [판독] | β-LPS + HNBR 시트 · 다이가 아닌 펀치 (반구속 압입) · 시료 두께 [미확인] · 장치 보정 ≈ 0.046 mm @500 N [재계산] 이 회복량보다 클 수 있음 (L155)
- [b] heck2026_densification_sulfide_se_binder_scalable | 금형 안 감압 (1.5 → 0.01 GPa) 의 두께 회복 = ρ_max/ρ_end − 1: 분말 +6.9 % (2.01 → 1.88; 가압 끝 1.98 기준이면 +5.3 %) · 3 wt% +12.9 % (1.66 → 1.47) · 4.3 wt% +9.1 % (1.67 → 1.53); 감압 가지 0.3 → 0.01 GPa 만: 분말 +2.8 % · 0.2 → 0.01 GPa +2.1 %. 방법: 빈 셀 기준을 뺀 in situ 두께 · 단계 15 분 휴지 | §3-7 (L142) · §0 표 ① (L24) | [판독 → 우리 산술] · 시트 오차막대 ±0.06 g/cm³ → ±4–5 %p | 1.5 GPa 를 겪은 완전 치밀 상태 · β-LPS
- [b] heck2026_densification_sulfide_se_binder_scalable | 해석: 분말 회복 6.9 % 를 고체 탄성 팽창만으로 보면 K ≈ 23 GPa (선형 근사) → "순수 LPS 는 in-die 감압에서 공극이 다시 열린 증거가 없다"; 바인더 시트는 D 0.91 → 0.80 (3 wt%) · 0.92 → 0.84 (4.3 wt%) 로 공극이 다시 열림 | §3-7 (L141 · L143) · §7-2 (L242) | [우리 산술] · β-LPS 의 K 는 논문에 없음 [미확인] | 가정 K 에 의존
- [b] heck2026_densification_sulfide_se_binder_scalable | 저자 서술: 속도 ↑ → 되튐 ↑ = 바인더 점탄성 → "slow and stepwise pressure application and release are recommended"; 회복은 대부분 감압 직후 (시간 분해 자료 없음); 수직 방향만 측정 ("minor recovery is expected in the lateral directions as well") | §3-8 (L154) · p.15 | [인쇄] (서술만) | "보관 중 추가 회복은 작다" 는 인용 금지 (카드 §10-10 L287)
- [b] heck2026_densification_sulfide_se_binder_scalable | 감압 중 수송 · 격자: σ_ion 감압 10 MPa 분말 0.135 mS/cm (가압 같은 압력 ≈ 0.009) · 3 wt% ≈ 0.022 · 4.3 wt% ≈ 0.028; 최대 대비 잔존 0.53 · 0.26 · 0.37; 단위포 부피 원분말 → 1.5 GPa 뒤 (감압 · 모세관 측정) 640.46 → 637.96 Å³ (−0.39 %) | §3-4 (L96–104) · Fig 8 · §3-5 (L116) | [판독, ±0.003 mS/cm] · 비 · 부피 = [우리 산술] | β-LPS · 10 MPa 가압 값은 ±50 %
- [b] heck2026_densification_sulfide_se_binder_scalable | 카드의 크기 감각 (판정 아님): 구속 축변형 σ/M — 실물 LPSCl (E ≈ 22 GPa · ν 0.36) 은 160 MPa 에서 ≈ 0.4 % · 무르게 맞춘 E_eff 1.35 GPa (ν 0.3) 이면 ≈ 9 % | §7-2 (L244) | [우리 산술 — 크기 감각, 판정 아님] | 우리 쪽 기록 · 연속체 산술 (접촉망 값과 같지 않다고 카드가 적음)
- [b] he2026_dem_calendering_inhomogeneity_areal_density | 나노압입 제하: 압입 깊이 2.28 / 2.76 / 2.97 µm 에서 잔류 깊이 실험 ≈ 2.18 / 2.32 / 2.55 µm ↔ 시뮬 ≈ 1.82 / 1.85 / (겹침) → 시뮬 잔류 깊이가 0.36–0.47 µm 작다 (DEM 이 탄성 회복 과대 · 소성 잔류 과소). 방법: Vickers 다이아 압자 · 로딩 0.3 µm/s · 언로딩 0.03 µm/s · 3 점 · 시료 = 양면 35.2 mg/cm² 전극 | §3.9 (L201–213) · Fig 4a · §10 L3 (L475–477) | digitized | NCM622 액체계 전극 · EEPA 접촉 DEM · 압연 뒤 되돌아옴 자체는 계산하지 않음
- [b] he2026_dem_calendering_inhomogeneity_areal_density | 압연 계산에 제하 단계 없음 — 서론에서 Gimenez 2019 의 회복률 10.25–17 % 를 인용만 함 | §4.5 (L296–297) · §8 ③ (L408) | 표지 없음 (카드 서술) | 인용값의 재료 · 방법은 카드에 없음
- [b] gonzalez2012_nonlocal_contact_confined_granular | 되돌아옴 수치 없음 — Tatara 고무 구는 지름의 40 % 압축까지 이력 · 영구변형이 관측되지 않음 (탄성) | §3.1 (L70) · §5.2 (L325–326) | stated §3 | 고무 구 1 개 · 탄성
- [b] johnson1971_jkr_surface_energy_contact_elastic_solids | 되돌아옴 양이 아니라 분리 조건: 하중 제어에서 떼는 힘 −(3/2)γπR (식 21) · 떼는 순간 접촉 반경 = 무하중 반경의 0.63 배; 고무는 평형이 느림 (높은 하중 수 초 → 0 근처 수 분) "viscous peeling forces which are rate dependent" · 예비 실험의 떼는 하중 ½–5 g 산포 | §3-1 (L95) · §4-3 (L165) · §3-2 (L112) · p.307 · p.309–310 | [인쇄] · 0.63 배 = [우리 산술 — 식 (19)] | 탄성 점착 접촉 (소성 없음) · cm 고무
- [b] jacksongreen2005_fem_elastoplastic_hemispherical_contact | 제하 없음 (변위 제어 로딩만 · 잔류 변형 · 되돌아옴 서술이 카드에 없음) | §4 (L57–59) | — | —


### [batch_06] b. 압력을 뺄 때 되돌아오는 양과 잰 방법

실제 펠릿 · 전극의 두께 되돌아옴을 잰 카드는 **이 배치에 없음**. 아래는 접촉 법칙 · 압입 · 이론 수준.

- [b] luding2008_cohesive_frictional_contact_models | 접촉 법칙 안의 되돌아옴: 제하는 기울기 k₂ 가지를 따르고 힘이 0 이 되는 겹침 δ₀ = (1 − k₁/k₂)·δ_max 가 영구히 남는다 (δ_max = 이력 변수) · 더 빼면 점착 가지 −k_c·δ 로 인장. 데모: 등방 압밀 뒤 응력 완화 (p_r ≪ 1) 에서 배위수 7.16 → 6.19 (k_c/k̂₂ 0.5) / 6.23 (k_c 0) | §4 (L78–100 · eq 6 · §2.3.2) · §3 (L55–58) | stated | 재료 무관 예시 단위계 · 3D N = 1728 · 완화 뒤 부피분율 값은 카드에 없음 · 재료 측정 아님
- [b] kissel2026_mechanofusion_derived_cathode_composite_microstructures_scalable | 매트릭스 펠릿 (CB + LIC · 380 MPa · 3 min) 나노압입: Ø100 µm 평편 압자 · 변위 제어 10 µm · 500 nm/s · 펠릿당 25 회 · W_elastic = ∫ F_unloading ds · W_plastic = W_total − W_elastic (식 6–8). 소성 몫 30.4 ± 2.3 % (CB 1 wt%) · 20.7 ± 3.2 (2.5) · 28.4 ± 2.0 (5) · 42.6 ± 5.9 (10) · 51.6 ± 5.8 % (15) | §3-9 (L251–262) · p.14 · Fig 9e | [인쇄 p.14] · [원자료 Figure9e] | 할라이드 + CB · 압입 일의 몫이지 펠릿 두께의 되돌아옴이 아님 · 캡션 n = 24 ↔ Methods 25 (L456) · 1 wt% 는 최대 깊이 ≈8.2 µm
- [b] molerus1975_theory_of_yield_cohesive_powders | 이론 서술만: 순수 탄성이면 하중을 빼면 원상태로 돌아가 응집력이 압밀에 무관해진다 — "which is in sharp contrast to all experimental experience with cohesive powders" → 비가역 소성 변형이 응집력을 "frozen" (p.264). 항복 개시까지는 "small changes in the elastic deformations during unloading ... may be neglected" (p.268) | §4-4 (L166) · §4-6 (L182) | stated (원문 따옴표) | 되돌아오는 양의 측정 없음 · kPa 응집 분말 · 돌기 척도
- [b] oh2026_bimodal_composite_cathode | 되돌아옴 자료 없음. 성형 (양극 200 → 음극 300 MPa) · 측정 (100 MPa 일정) · He 펠릿 (370 MPa) 의 압력이 다르다는 것만 | L41–42 · L119–120 · L630–632 | 표지 없음 | 값 없음
- [b] kogutetsion2002_ep_sphere_rigid_flat · mesarovicfleck2000_dissimilar_elastoplastic_indentation · martinbouvard2003_dem_composite_cold_compaction | 하중 (압입 · 압밀) 만 — 제하 서술이 카드에 없음 | KE §4 (L66) · MF §4 (L56–57) · MB §4 (L52) | — | 카드에 없음


### [batch_07] b. 압력을 뺄 때 되돌아오는 양과 잰 방법

되돌아온 양의 **수치는 이 배치에 없음**. 접촉 법칙의 제하 가지 · 잰 방법의 정의만 있다.

- [b] so2022_dem_contact_model_assb_compaction_sintering | 접촉 수준: 누른 뒤 압력을 풀어도 입자가 붙어 있는 것을 평형 겹침 h_eq 로 표현 — F_spring = k_n(h_ov − h_eq) (eq 1) · release 곡선이 h_eq 만큼 오른쪽으로 평행 이동 (Fig 2 · h_eq^rel 0 / 0.05 / 0.1 / 0.15) | §4.2 (L92–99) | stated (식) | 되돌아온 양의 수치 없음 · LPS
- [b] so2022_dem_contact_model_assb_compaction_sintering | 층 수준 잰 방법: PI/servo 로 200 MPa 까지 올린 뒤 release → 전극 높이–시간 곡선에서 탄성 회복 (springback) 을 읽음 · c_spring ↑ 이면 springback 감소 (Fig 7a) | §4.9 (L184) · Fig 7 행 (L197) · §6 (L202) | 표지 없음 (그림 설명) | 되돌아온 양 (µm · %) 은 카드에 없음
- [b] so2022_dem_contact_model_assb_compaction_sintering | 탈압 때 분리 규칙 (융착 결합): 스프링력이 −F_th 보다 작아지면 (인장) detachment → h_eq 가 0 까지 감소 · −F_th < F < F_th 는 불변 구간 · 더 깊이 눌린 접촉일수록 떼는 데 더 큰 인장 필요 (eq 7 · Fig 3b) · SE 에만 허용 (AM 불허) | §4.4 (L126–137) | stated (식) | 값 없음
- [b] pasha2014_linear_elastoplastic_adhesive_contact | 접촉 수준: 탄성 제하 f = k_e(α − α_p) · α_p = 제하 중 힘이 0 이 되는 겹침 = 영구 소성 겹침 (eq 7) → 그 아래로 pull-off f_cp 까지 → 음의 강성 −k_e 가지 → 힘 5f_cp/9 에서 접촉이 끊어짐 (eq 8) · 다시 닿으면 α_c0 (> α_cp) 에서 8f_cp/9 로 재성립 | §4.2 (L130–134) | stated (식) | 암모늄 플루오레세인 · 벌크 되돌아옴 값 없음
- [b] pasha2014_linear_elastoplastic_adhesive_contact | 벌크 수준 잰 방법: 일축 압축 뒤 같은 속도로 제하 · 재하 곡선 아래 면적 = 소성 일 · 제하 곡선 아래 = 탄성 일 (Fig 15) → 정규화 W_e/W_input · W_p/W_input · k_e/k_p = 1 에서도 소성 > 탄성 (재배열 · 마찰 소산) · k_e/k_p ≈ 20 이상이면 거의 전부 소성 (Fig 16) | §4.7 (L195–196) · §6 (L238–239) · Fig 16 행 (L230) | stated | 일반 1 mm 구 · 11 % strain / 고체 분율 0.58 까지 · 되돌아온 변형량 (%) 은 카드에 없음
- [b] schreiner2020_dem_calendering_lib | spring-back = 탄성 변형 입자의 회복 + 갇힌 공기 · roll 직경 ↑ · 압연 속도 ↓ → de-aeration ↑ → 소성 변형비 ↑ → spring-back ↓ [21] · Fig 3 (c) 에서 제하 때 압력이 0 아래로 내려가고 잔류 변위가 남음 · 곡선의 탄성 회복 구간은 EEPA 접촉 소성비 λ_P 가 지배 (Fig 5 (c)) | §4.4 (L81) · Fig 3 · 5 행 (L107 · L109) | stated (정성) | 정량값 없음 (카드: "정량값 없이 기계-파라미터 의존성만" L175) · LIB 압연
- [b] schreiner2020_dem_calendering_lib | 잰 방법: flat punch ⌀100 µm 를 0.15 µm/s 로 누르고 같은 속도로 제하한 하중–변위 한 줄 | §3 (L40) · §4.4 (L82) | stated | NMC622 + 바인더 전극 · 값 없음
- [b] schreiner2020_dem_calendering_lib | 카드가 옮긴 다른 논문 값: Sangrós 2019 의 탄성 회복 ER 10.25 → 17 % | 대비 절 A-5 (L175) · L252 | 표지 없음 (다른 카드 소관) | 이 카드에서 확인 불가 · LIB
- [b] paulick2015_elastic_particle_properties_dem_review | 제하–재하 정의들: [21] 의 구속 벌크계수는 "once a stable hysteresis loop was reached" 뒤의 사이클 기울기 · [26] 선형 법칙 F_n = k_load·δ (재하) / k_unload·(δ − δ₀) (제하 · δ₀ = 완전 제하 때 잔류 겹침) · [32] 접촉 소성도 λ_p = 1 − k_load/k_unload · 벌크 소성도 = 소성 벌크 변형 ÷ 총 변형 · 선형 모델의 반발계수 = √(k_load/k_unload) | §5-A 판정 (L417–420) · §6 (L555–556 · L576–577) · §5-Q7 (L490–495) · §5-Q8 표 (L511) · §14 (L1056–1057) | stated · 일부 원문 인용 | 응력 96 kPa 이하 · 되돌아온 양의 수치 없음
- [b] roessler2019_dem_cohesive_aor_cylinder_lift_calibration | 단순 JKR (CED × 접촉 면적) 점착은 "강한 다짐 · 응력 이력 표현 못 함 (하중을 빼면 거의 원 상태로 돌아감)" — 저자 | §3-1 (L61) | [인쇄] p.2 (카드의 우리말 요약) | 젖은 모래 · 가압 계산 아님
- [b] sharma2023_nmc_single_crystal_anisotropic_nanoindentation | 없음 (압입 강성으로 M · H 를 뽑을 뿐 되돌아옴 값 없음) | — | — | —


### [batch_08] b. 압력을 뺄 때 되돌아오는 양과 잰 방법

수치는 `thompson2026` (LPSCl · GPa 영역 · 감압 하한 ≈1.1 GPa) 과 `vanlew2015` (세라믹 침대 · 6 MPa) 둘. 나머지는 제하 가지의 정의.

- [b] thompson2026_high_pressure_densification_lps_lpscl_xrd_tomography | 감압 3770 → 1144 MPa: 흡수 (거시) 밀도 2.089 → 1.862 g/cm³ (−11 %) · 같은 구간 결정밀도 2.008 → 1.925 (−4.1 %) → 격자 팽창 몫을 넘는 거시 밀도 감소 ≈7 %p | §0 ① (L25) · Fig 1 · SI Fig S2 | 값 = [판독] · 차 = [우리 산술] | 감압이 ≈1.14 GPa 에서 멈춤 (0 아님) · 두께 · 거시 회복률은 안 잼 · 오차막대 ±0.03–0.04 g/cm³ 안팎 · 준등방
- [b] thompson2026_high_pressure_densification_lps_lpscl_xrd_tomography | 같은 압력에서 가압 ↔ 감압: ≈1150 MPa 흡수 밀도 1.985 ↔ 1.862 (−6.2 %) · ≈1931 MPa 가압 보간 ≈2.057 ↔ 1.944 (−5.5 %) — 반대로 결정밀도는 감압 가지가 1.5 % 높음 (1.925 ↔ 1.896) | §3-2 (L70) · §7-2 (L181) | [우리 산술] (입력은 [판독]) | "그 차는 고체가 아니라 공극 · 균열 재개방 쪽이라는 정성 신호" 는 카드 해석 · 흡수 밀도 절대 보정 문제 한정
- [b] thompson2026_high_pressure_densification_lps_lpscl_xrd_tomography | 가역 / 비가역을 가른 방법: 중성자 회절 격자상수 2249 MPa 9.60589 Å ↔ 2255 MPa (감압) 9.60592 Å = 가역 · ED-XRD — "Upon decompression, the peak shift is reversible, in line with elastic lattice strain, whereas the broadening appears largely irreversible, suggesting the development of permanent microstructural defects or disorder." · 선폭 변형 (WH) 최대 2.00 % → 감압 1931 MPa 2.05 · 1143 MPa 1.97 % | §0 (L24) · §3-4 (L83) · §3-5 (L93–95) · p.6 §4.1 · SI Table S1 · Fig S6 | 격자상수 · 인용문 = [인쇄] · WH = [판독, 육안] | NPD 감압 최저 1837 MPa · ED-XRD 1143 MPa — 시료 · 압력 배정이 서로 다름 (L95 · L121) · SI Note S1 은 "결정밀도가 감압 뒤 pristine 보다 높다 → 격자상수의 영구 변화" 라 적어 본문과 반쯤 엇갈림 (L24)
- [b] thompson2026_high_pressure_densification_lps_lpscl_xrd_tomography | 원문 (p.3): "For LPS, the density–pressure curve during unloading closely follows that recorded during compression … In contrast, LPSCl exhibits slightly lower density values upon decompression, suggesting a greater degree of irreversible (plastic) deformation." | §3-2 (L70) | [인쇄] | 흡수 밀도 기준 · 감압 하한 같은 한정
- [b] thompson2026_high_pressure_densification_lps_lpscl_xrd_tomography | 꺼낸 뒤: "the pellet exhibited spontaneous fracture several minutes after removal from the Paris–Edinburgh (PE) press. This provides strong evidence of residual stress and strain trapped within the LPSCl sample" · 파면은 입계 파괴 | §3-7 (L112) · p.4–5 · Fig 4 | [인쇄] | 3.7 GPa 까지 누른 시료
- [b] vanlew2015_modifying_youngs_modulus_distribution | 침대 수준 (일축 6 MPa · 1 사이클): 최대 변형 ≈2.08 % (상수 E) / ≈2.75 % (수정 E) · 제하 뒤 잔류 변형 ≈1.20 / ≈1.33 % · 회복 (탄성) 변형 ≈0.88 / ≈1.42 %p (비 1.61) → 추가 변형 +0.67 %p 의 ~80 % 가 제하 때 회복 | §3.2 (L101–111) · Fig 4 | DIGITIZED (추세 전용 · 절대값 인용 금지) · 분해는 카드 산술 (ours) | Li₄SiO₄ pebble 0.5 mm · 순수 탄성 Hertz DEM · 6 MPa · 침대당 실현 1 개 · 잰 방법 = 판 응력 – 침대 높이 변형 (L389) · 논문의 그룹 평균 stated 값은 1.9 / 2.6 % (L76) 로 단일 곡선 판독과 다름 · 카드가 "우리 계로 곧장 옮기지 말 것" (L314)
- [b] thakur2014_eepa_adhesive_elastoplastic_dem | 정의: 접촉 소성 λ_p = δ_p/δ = 1 − k₁/k₂ (eq 16 · δ_p = 제하 가지가 힘 0 을 만나는 영구 겹침) · 벌크 소성 λ_b = ε_p/ε (eq 17) — λ_p ↑ → 제하 때 탄성 복원 ↓ · λ_p = 0 (탄성) 이어도 λ_b 는 큼 (재배열 · Fig 11) | §1 (L40) · §4 (L103–105) · §5 Fig 11 행 (L174) · §6 (L191) | 표지 없음 (식 · 그림 설명) | 되돌아온 양의 수치는 카드에 없음 · 석회석 16–96 kPa
- [b] thorntonning1998_adhesive_elastoplastic_contact | 접촉 수준: 제하는 더 큰 반경 R_p* 의 Hertz — P = (4/3)E*R_p*^{1/2}(α − α_p)^{3/2} (eq29) · R_p* = (4E*/(3P*))·((2P* + P_y)/(2πp_y))^{3/2} (eq28) · α_p = 힘이 0 이 되는 영구 잔류 겹침 · 충돌 속도가 클수록 제하 강성 ↑ (Fig 3) | §4 Phase 4 (L115–124) | stated (식) | 수치 예 없음 (Fig 3 은 100–400 nm 변위 · L161) · 단일 충돌 · 재료 무관
- [b] varkey2026_multicontact_elastoplastic_dem | 접촉 법칙에 제하 가지 F_unl = (4/3)E*√(R_p*(δ − δ_R)) (잔류 겹침 δ_R) 가 있음 · 층 수준에서 되돌아온 양은 카드에 없음 | §4 (L31) | 표지 없음 (식) | —
- [b] tovar2026_cold_spray_cathode_composite_dem_plastic_elastic_bond | 결합 수준: 제하는 늘 탄성 기울기 — 탄소성 · 소성 구간에서 0 까지 제하하면 잔류각 · 잔류 변위가 남음 (Fig 4) · 충돌 뒤 되튐은 COR 로만 보고 (잔류 변형 · 압흔 치수 정량 0) | §4-2 (L76 · L79) · §4-6 (L137) | stated (식 설명) | 160 m/s 충돌 · NMC622 결합구
- [b] wang2024_hot_pressed_lpscl_pressure_invariant_conductivity | 되돌아온 양을 재지 않음 — 밀도가 전부 다이 밖 값이라 "하중 제거 회복을 포함" (카드 한정어) · 냉간 펠릿 σ 는 측정 스택압 내림 가지가 올림보다 높음 (예 1.97 MPa 0.102 ↔ 0.195 mS/cm) = 저자 "additional densification of the cold pressed pellet during the testing process" | §7 한정어 ③ (L229) · §3-4 (L138) | 한정어 = 카드 문장 · σ = [판독] · 인용 = 본문 | 0–8 MPa 측정압의 이력이지 가압 뒤 탈압 측정이 아님
- [b] stallard2022 · storakers1997 | 해당 없음 (Stallard 는 압입 제하 기울기 S 로 E 를 구하는 방법만 · L261) | — | — | —


### [batch_09] b. 압력을 뺄 때 되돌아오는 양과 잰 방법

수치가 있는 것은 Avicel 실험 한 건뿐 (LPSCl 아님). 나머지는 접촉 수준의 제하 처리와 그림 설명이다.

- [b] zunker2025_dem_large_deformation_compaction | 실험 (Avicel PH102 · die Ø8 mm): 최대 축변형 0.4 (높이 5.85 → 3.57 mm 로는 0.390) 뒤 제하 종료 변형 0.32 ⇒ 탄성 회복 0.08 (축변형) · 압축체 높이 대비 13.1 % · 해제 뒤 잔류 반경응력 15 MPa · 배출 축응력 실험 1.2 / 계산 1.5 MPa | §3-1 (L58–66) · Fig 9 (L270) | stated (0.32 · 15 MPa · 1.2 / 1.5 MPa) · DERIVED (0.390 · 13.1 %) | 연성 유기물 · 최대 240 MPa · 압축 + 해제 1 초 · 0.08 은 최대 변형을 0.4 로 둔 값 (카드 문제 12)
- [b] zunker2025_dem_large_deformation_compaction | 잰 방법: 압축 시험기의 상 · 하 펀치 축력 센서 + die 내면 반경압력 센서 2 개 (상 / 하) · 상 펀치를 사인파 변위로 축변형 0.4 까지 → 같은 사인파로 복귀 → 하 펀치 상승으로 배출 · 축응력 = 펀치 총 힘 / 펀치 면적 | §3-1 (L55–56) · §8 (L279–280) · §10 (L352–357) | stated | 계산 쪽 반경응력은 벽 반력이 아니라 입자 응력 텐서 평균 × 부피분율 — 실험 센서와 같은 양이 아님 (L281–284)
- [b] zunker2025_dem_large_deformation_compaction | 접촉 수준: 제하 때 쌍 사이 가상 강체 평면의 위치를 소성 변위로 선형 보간해 양쪽이 동시에 힘 0 에 닿게 함 (eq 1–2) · 반경비 [1, 0.75, 0.5, 0.25] 네 경우 모두 제하 곡선은 FEM 과 잘 맞음 | §4 (L133–135 · L149–151) · App C · Fig C.10 | stated (식 · 서술) | 같은 재료 쌍만 · 수치 없음
- [b] zunker2024_mdr_contact_model_partI | 접촉 수준: 제하 · 재하에 추가 처리 없음 — δ 만 줄이면 eq (30) 이 비선형 제하 곡선을 냄 · 누적 소성이 클수록 제하 곡선이 뻣뻣해지는 것까지 FEM 과 일치 (§8.1.1) · die 예고 (E/Y = 20 · ν = 0.3) 에서 2차 접촉은 제하 뒤에도 F 가 0 이 아님 (소성 반경 팽창은 비가역 · Fig 12) | §4-3 (L167–168) · Fig 12 행 (L253) | stated (서술) | 단일 입자 ↔ 강체 평판 · 되돌아온 양의 수치는 카드에 없음 (그림 판독 0 개)
- [b] zunker2024_mdr_contact_model_partI | 분리 (점착): 임계 신장 길이 Δl(a) = √(2πaΔγ/E*_c) (eq 11) · 분리 판정 계수 ξ = 3 (하중 제어) / 1 (변위 제어) (eq 15) · 뛰어 붙기 (jump-in) 는 무시 · 검증 δ_o,max/R_o = 0.5 까지 · 하중을 뺀 프로파일은 δ_o,max/R_o > 0.15 에서 접촉 중심 근처가 오목으로 바뀜 (FEM) — 모델은 볼록만 | §4-6 (L224–231) · §3 (L70–71) · Fig 13b | stated | 재료 무관 이론
- [b] zunker2024_mdr_contact_model_partI | 카드의 우리 쪽 대조: 우리 DEM 의 제하 = Walton–Braun 이력 (k₂ > k₁ 선형) ↔ 이 모델 = 비선형 제하 + 소성 누적에 따른 강성 증가 — "spring-back 정량이 필요하면 흡수 대상" | §7-2 (L301) | 표지 없음 (카드 판정) | 논문 값 아님
- [b] zunker2024_bulk_elastic_partII | die 구속: 제하 뒤 부피가 안 돌아옴 (2차 접촉 힘이 남아서) — 모델이 이 잔류까지 맞춤 (Fig 6) · 아무 정보도 넣지 않은 2차 접촉을 검출 · 진화시키고 제하 뒤에도 힘이 남음 (Fig 3c) | §5 (L135 · L138) | 표지 없음 (그림 설명 · 판독 0 개) | E/Y = 20 · ν = 0.3 단일 입자 · 수치 없음
- [b] zunker2024_bulk_elastic_partII | 함정: 제하 때 접촉 면적이 유한값 → 0 으로 급락 (die 1차 접촉 · Fig 4b) = 모델 인공물 (저자 설명: MDR · 벌크가 동시에 제하되어 MDR 쪽이 먼저 0) · ψ_b 를 키우면 (0.08 → 0.28 → 0.48) 제하 뒤 잔류 (소성 변위) 예측이 나빠짐 (App A · Fig A.7) | §5 (L136 · L139) · §7-3 (L211–212) · §10 (L269–270) | stated (서술) | 수치 없음
- [b] xu2017_nmc532_nanoindentation_modulus_hardness_toughness | 층 · 입자의 되돌아옴 값 없음 — 압입 제하 초기 기울기 S 로 환산 탄성률을 뽑는 Oliver–Pharr (식 2) · 하중 / 유지 / 제하 10 / 5 / 10 s | §4-2 (L204–209) · §0 (L26) | stated | NMC532 · 압입


### [batch_10] b. 압력을 뺄 때 되돌아오는 양과 잰 방법

되돌아온 **두께** 를 잰 값은 lee2025 의 한 점뿐. faka2026 은 감압 가지의 σ 만 주고 두께는 없다. 나머지 카드는 제하가 없거나 "압밀압 ≠ 측정압" 서술뿐.

- [b] lee2025_heckel_argyrodite_powder_densification_nanoindentation | 다이 안 완전 제하 (≈ 900 MPa → 0): 총 회복 0.433 mm = 펀치 탄성 0.200 mm + **펠릿 0.233 mm** → 펠릿 높이 ≈ 5.0 mm 대비 **≈ 4.7 %** · 최대 하중 ≈ 440 s → 제거 ≈ 448 s → 무하중 ≈ 452 s (수 초 안). 잰 방법 = DIC (3 fps) 로 상 · 하 펀치 거리 추적 · 기준선 6.711 → 6.511 → 6.278 mm. 저자: *"It can be regarded that the difference between (2) and (3) is the elastic recovery because there is no appearance of irreversible deformation such as cracks on the surface of the pellet."* | §3-5 (L101–104) · §0 표 ① (L24) · 논문 Fig 1c (p.6343) | 길이 = [판독] (±0.005 mm) · % 와 σ_max = [우리 산술] · 인용문 = [인쇄] | 상용 Li₆PS₅Cl 한 시료 · 한 압력 · 높이 5 mm 는 설계값 (실측 미보고) · 측방 구속 (다이 안)
- [b] lee2025_heckel_argyrodite_powder_densification_nanoindentation | 크기 감각: 4.7 % / 900 MPa = **0.52 %/100 MPa** · 치밀 고체 탄성 p/E = 3.3 % (E 27.6 GPa) – 4.1 % (22.06 GPa) 의 1.1–1.4 배 · 일축 구속 계수로는 순수 고체 탄성 ≈ 2.3 % — 나머지는 접촉 · 남은 공극의 순응 (추정). 나란히 적힌 다른 카드 값: miss2026 (Li₅.₅PS₄.₅Cl₁.₅) 0.53 · 0.69 %/100 MPa | §3-5 (L105–106) · §7-2 (L181–184) | [우리 산술] · "추정" | 두 논문 · 다른 조성 · 다른 프로토콜 (카드 표기) · 카드: 우리 시험과 조건이 달라 "표적이 아니다"
- [b] faka2026_particle_size_consolidation_strain_lpscl | 두께 회복 자료 없음 — 감압 가지 σ_ion (mS/cm): 40 µm 3.24 (0.5 GPa) → 3.61 (0.3) → 3.74 (0.2 · 최대) → 3.44 (0.15) → 3.00 (0.10) → ≈ 1.6 (0.05) · 20 µm 1.91 (1.5) → 2.39 (1.0) → 3.13 (0.5) → 3.34 (0.3 · 최대) → 1.63 (0.05) · 11 µm 2.66 (0.25 · 최대) → 2.01 (0.05) · 4 µm 2.54 (0.3 · 최대) → 1.44 (0.05). 최대 → 0.05 GPa 하락 **−57 / −51 / −24 / −43 %** (40 / 20 / 11 / 4 µm) | §3-2 (L68–75) · §7-2 (L195–197) · 논문 Fig 1b · S1 | [판독] · 하락 % = [우리 산술] · 기전 = [미확인] | 순수 SE · 최저 압력 0.05 GPa (우리 측정 압력 1 MPa 의 50 배 · L197) · 감압 때 σ 계산에 쓴 두께 [미확인] (L128) · 하락 원인 (접촉 상실 · 두께 회복 · 계면) 미분리
- [b] faka2026_particle_size_consolidation_strain_lpscl | 용어 정의 (인용 가능): *"There were two types of Heckel analysis. The “in-die” (at pressure) accounts for powder deformation upon applying pressure—in compression. The “out-of-die” (zero pressure) analysis could be used in an already compacted material and also accounts for its elastic recovery."* — 논문 자신은 in-die 만 측정 | §0 표 첫 행 (L24) · §8-1 (L220) · 논문 §4.2 p.10 | [인쇄] | 뺀 뒤 밀도 자료 없음
- [b] faka2026_particle_size_consolidation_strain_lpscl | 같은 압력에서 감압 가지 σ > 가압 가지 σ (≲ 0.7 GPa) = 비가역 치밀화 · 고압 쪽 겹침 = 활성화 부피 (가역) | §3-2 (L74) | [우리 산술] 줄에 붙은 풀이 | 두께가 아니라 σ 로 본 것
- [b] minnmann2021_jes_charge_transport_bottlenecks | 되돌아온 양 없음 — 압력 세 가지 구분: 압밀 380 MPa → EIS · 사이클은 ≈ 40 MPa. 이온 측정 시료는 380 MPa 로 두 번 눌렸고 재압 뒤 두께를 다시 쟀는지 [미확인] | §0 (L75–84) · §15 (L697–698) | stated · [미확인] | 두께 변화 미보고
- [b] minnmann2024_microstructure_porosity_visualization · frankenberg2025_milling_dry_processed_sulfide_cathode_microstructure · lin2025_submicron_lpscl_cathode_li_kinetics · kim2024_optimal_cathode_composite_mechanical_mixing_se_coverage | 되돌아온 양 없음 — 압밀 뒤 낮은 압력에서 측정했다는 조건만: 380 MPa → 측정 (380 또는 100 MPa — 카드 문제 12) → 사이클 30 MPa / 380 MPa 3 min → 50 MPa · 6 h 대기 → DC 분극 / 640 MPa 성형 → 사이클 50 MPa / 2 t · 1 min → 지그 토크 5 N·m | minnmann2024 L56 · L75 · L91 / frankenberg L146 / lin2025 L73 / kim2024 L109 | stated · [인쇄] | 두께 변화 미보고
- [b] bazzoun2025_dem_parameter_sensitivity_assb_cathode · bazzoun2026_dem_fem_rnm_ionic | DEM 은 PID 로 목표 압력을 유지한 상태에서 끝 — 제하 서술 없음 | bazzoun2025 L74 · bazzoun2026 L29 | 표지 없음 | —
- [b] lei2026_se_particle_size_effects_review | 이 카드에 없음 (표 2 는 제조 · 운전 압력의 역할만 · L109) | — | — | —


### [batch_11] b. 압력을 뺄 때 되돌아오는 양과 잰 방법

되돌아온 양이 적힌 카드 = 1 (schneider2023 · t-Li₇SiPS₈). 나머지 6 장은 제하가 없거나 "성형압 ≠ 측정 · 작동압" 조건만 있고 두께 변화가 없다.

- [b] schneider2023_particle_size_pressure_transport | 감압 때 상대밀도 "약 −4 % 복원" (stated) · 펠릿 두께 ~1600 → 1000 µm (0 → 1.7 GPa 가압) 뒤 감압 때 ~4 % 증가 (digitized). 잰 방법 = 압력 프로토콜을 따라간 펠릿 두께–압력 (Fig 2d) 과 "in die" ↔ "out of die" Heckel 로 탄성 복원 분리 (SI Fig S9) | §3 (L58–59) · §5 (L106 · L112) · §6 (L118–120) | stated · digitized (Fig 2d) | t-Li₇SiPS₈ · 최대 1.7 GPa · "−4 %" 의 분모 (상대밀도 %p 인지 상대 % 인지) 와 측정 장치 · 순응도 보정은 카드에 없음 · SI 미독
- [b] schneider2023_particle_size_pressure_transport | 감압 이력이 σ 에 남는 크기: 0.01 GPa 에서 가압 가지 0.3 / 0.7 mS/cm ↔ 감압 가지 4.4 / 2.1 mS/cm (<50 / >50 µm) · 감압 최대 5.3 / 6.6 mS/cm @~0.1–0.2 GPa · 1.7 GPa 뒤 표면 균열 수십 µm (SI S10) · stack 0.1 GPa 가 0.01 GPa 보다 σ 높음 (표면 균열 · 접촉저항) | §3 (L49–52) · §5 Fig 3 · Fig 5 (L107 · L109 · L113) | stated (SI S10 은 본문 인용분) | 두께가 아니라 σ 로 본 것 · 재료 다름
- [b] otani2025_dem_se_dispersion_aggregation_compression · shi2019_high_am_loading_particle_size_assb | 제하 없음 — otani: 0 → 1000 MPa 점증 가압에서 끝 (L276–278) · shi: 200 MPa 에서 압력 일정 유지 · 운동에너지 0 에서 끝 (L215–219) | 왼쪽 괄호 | 표지 없음 / stated (p.2) | —
- [b] schlautmann2023_se_particle_size_composite_transport · stavola2023_thick_nmc111_lpscl_lithiation_gradient_tortuosity · tailored_cathode_microstructure_low_pressure_assb | 되돌아온 양 없음 — 성형 뒤 낮은 압력에서 쟀다는 조건만: 3 t (≈375 MPa · 우리 산수) → 50 MPa (schlautmann L141 · L159 · L169) / 양극 100 MPa → 운전 50 MPa · EIS 셀 50 / 150 MPa 성형 → 50 MPa 측정 (stavola L58 · L155) / 제조압 미기재 → 작동 30 / 10 / 2 MPa (Zhou L70 · L112) | 왼쪽 괄호 | stated · [인쇄] | 두께 변화 미보고
- [b] park2020_dimension_controlled_se_percolation_contact_area | 이 카드에 없음 | — | — | —


### [batch_12] b. 압력을 뺄 때 되돌아오는 양과 잰 방법

되돌아온 **두께** 를 준 카드: 모델 2 (benhadjali2026 DEM · sangros2019 DEM) + 실험 2 (diener2022 캘린더 · demirtas2021 정제) + 정성 2 (so2021 · sangros2020). **황화물 SE 복합체의 실험 되돌아옴 값은 이 배치에 없다** (LPSCl 이 든 것은 benhadjali 의 모델 값뿐이고 그것도 보정에 흡수됐다고 카드가 적음).

- [b] benhadjali2026_wip_vs_cup_pressing_assb_cathode_dem | DEM (습식 NMC622 + LPSCl + 탄소-바인더 · 3D) 제하: Fig 2 그림 안 치수 — 건조 51.94 µm → CUP 눌림 (298 K) 41.55 → 회복 뒤 45.71 µm · WIP 눌림 (353 K) 36.36 → 회복 뒤 37.40 µm. 카드 산술: 부과 감소 중 되돌아온 몫 CUP 40.0 % (4.16 / 10.39 µm) · WIP 6.7 % (1.04 / 15.58 µm) · ρ = (h − h₀)/h₀ 꼴로 CUP 10.0 % · WIP 2.9 % | §3-8 (L167–170) · 논문 Fig 2 | 치수 = [인쇄 그림] · 몫 · ρ = [우리 산술] | 잰 방법 = 모델 안 (윗 경계를 올린 뒤 두께 · 운동에너지가 거의 안정할 때까지 이완 · L163–165) · 실험은 눌린 두께를 재지 않음 (L350) · 최종 두께를 실험에 맞춘 것이라 되돌아옴이 목표 변위 선택에 흡수됨 (L36 · L350) · 변위 제어 (압력 모름) · 프리프린트
- [b] benhadjali2026_wip_vs_cup_pressing_assb_cathode_dem | 카드가 적은 손잡이 후보: 같은 건조 침대에서 "더 깊은 목표 (30 %) + 4 ms 유지" 가 ρ 를 10.0 → 2.9 % 로 (둘이 섞여 유지 몫은 분리 안 됨). 카드가 나란히 적은 다른 정본 카드 값: Qin 2026 압축이 깊어지면 회복 비 25–28 → 11–14 % · Weitze 2024 10–15 % | §8-0 EM-02 (L350) · 관련 카드 (L469) | [우리 산술] · [추정] · "그 카드 산술" | 다른 카드 값은 이 배치에서 확인하지 않음
- [b] sangros2019_dem_calendering_lib_electrode | DEM (LIB NMC111 양극 · 구 2237 개) 탄성 회복 ER = (h_C − h_B)/h_A (식 14): 본문 Conclusion *"from 10.25% up to almost 17%"* · Fig 8 판독 ~0.136 / ~0.171 / ~0.116 / ~0.103 (C1–C4 = 19.82 / 42.71 / 79.13 / 159.37 MPa). 절차 = 위치 B (목표 최대 응력) → 위치 C (판을 같은 속도로 반대 방향으로 올림). Fig 5 주석: C2 누른 채 기공 0.193 → 회복 뒤 0.368 | §3 (L28–29) · §4.5 (L97–101) · §5 Fig 5 · 8 (L130 · L133) · §6 (L144) | 범위 = stated · 케이스별 값 = digitized | 실험으로는 못 잼 (롤 사이 입자 위치를 µm 분해능으로 못 봄 — 저자 강조 · L121) → 시뮬레이션 값 · LIB · 20–160 MPa · SE 없음 · 범위 서술과 Fig 8 판독의 케이스 대응이 카드 안에서 어긋남 (카드 문제 5)
- [b] sangros2019_dem_calendering_lib_electrode | 회복이 바꾸는 다른 지표: 배위수는 위치 C 가 B 보다 약간 큼 · NMC–집전체 접촉 면적비는 B > C (회복으로 일부 분리) · 자유표면 감소율은 C 쪽에서 일부 회복 | §3 (L31–33) · §5 Fig 9–11 (L134–136) | stated + digitized | 추세만
- [b] sangros2020_lib_electrode_dem_mech_elec_ionic | 위치 B (최대 응력) ↔ 위치 C (springback 뒤): 최종 기공 posC > posB · 초기 기공이 높을수록 둘 다 낮아짐 (Fig 8) — 수치는 카드에 없음 | §4 (L71) · §5 Fig 7 · 8 (L85–86) | digitized (추세만) | LIB 캘린더링
- [b] so2021_dem_mold_pressure_assb_coldpress | DEM (LPS + Si · 3D): 윗벽을 PI 제어로 목표 몰드압까지 가압한 뒤 release — "압축해제 시 전극이 약간 팽창(springback) 관찰" · 수치 없음 | §4 (L67) | 표지 없음 | 정성
- [b] diener2022_roll_gap_springback_calendering | 실험 (LIB NMC622 양극 · 캘린더): SB = (δ_El,ρi − δ_Γ)/δ_Γ (Eq 6 · Armstrong & Haines-Nutt 1974) — δ_Γ = 간극 안 전극 두께 (= 직접 측정 간극) · δ_El,ρi = 캘린더 직후 두께. 보고 SB 0.04–0.57 (최소 두께 기준) · 최종 두께 기준 4–37 % · 선하중에 선형 (R² 0.96–0.99) · 두꺼울수록 · PVDF 가 많을수록 작음. 최고 하중 판독: 0.397 (200 g/m² · 615 N/mm) · 0.465 · 0.509 · 0.505 (350 g/m² · 1015 N/mm) | §0 (L23–24) · §3-5 (L84–94) · 논문 p.4 · p.8 · Fig 6 | 정의 · 범위 = [인쇄] · 점별 값 = [판독 ±0.005] | 잰 방법 = 하중 중 두께는 롤 양끝 위치 센서 4 개 · 뺀 뒤 두께는 가운데 시트의 접촉식 게이지 (위치 · 방법이 다름 · L129) · 선하중 (N/mm) 이라 압력 환산 없음 · SE 없음
- [b] diener2022_roll_gap_springback_calendering | 카드 점검: 최고 하중의 보고 SB 는 간극 안 코팅 밀도 5.08–6.11 g/cm³ (혼합 진밀도 4.21–4.38 초과 · 간극 안 공극 −19 ~ −45 %) 를 뜻함 → 직접 간극이 전극 두께를 7.5–20.6 µm 과소 · SB 상한 (간극 안 공극 0 가정) 20.4–24.1 % | §3-7 (L105–121) | [우리 산술] (입력 = Fig 5 · 6 [판독] · Table 1–2 [인쇄] → 혼합 진밀도 [재계산]) | 저자 표현은 *"slightly overestimated"* · *"A roll flattening below 5 μm seemed to be a realistic value"* (p.6 · [인쇄]) — 카드 산술과 충돌 · 카드: 고하중 절대값 인용 금지
- [b] diener2022_roll_gap_springback_calendering | 탄성 · 소성 몫 (Eq 11–15): δ_el = δ_El,ρi − δ_Γ · δ_pl = δ_El,ρ0 − δ_El,ρi · h_R = δ_el + δ_pl · δ_el,n = δ_el/h_R × 100. 350 g/m² 는 ≈ 50 % 로 일정 (52 / 49.4 / 51 / 52.6 %) · 얇은 200 g/m² 는 36.8 → 55.7 % | §3-6 (L100–103) · 논문 p.6–7 · Fig 8 | 정의 = [인쇄] · 값 = [판독] | 같은 간극 측정에 기대므로 고하중 값은 위 한정과 같음
- [b] demirtas2021_mpfem_hollow_sphere_die_compaction | 실험 (HPMCAS 중공 입자 정제): 다이 안 → 다이 밖 팽창 61 % (45 °C 분말) · 78 % (80 °C 분말) · 다이 밖 정제 두께 1.398 ± 0.024 / 1.552 ± 0.077 mm (Table 2). 입자별 FE 제하 단면 (Fig 13a) 의 recoil 거리는 얇은 껍질 (d/w 10) 에서 눈에 띄게 김 — 수치 없음 | §3-4 (L187–190 · L205–208) · §4-8 (L428–431) · §5 Fig 13 (L469) | 팽창 · 두께 = stated · recoil = figure-read (정성) | 기준 상태 정의가 본문에 없음 — "펀치 간격 1 mm" 와 ≈ 13 % 어긋남 (derived · L207 · §10-B-10) · 고분자 중공 입자 · 점착 요소가 없어 배출은 계산 안 함
- [b] larson2025_hot_pressing_argyrodite_low_stack_pressure_conductivity | 두께 회복 자료 없음 — 두께는 시험 뒤 한 번만 (다이 밖). 닿는 것: 같은 0.12 MPa 로 돌아왔을 때 냉간 펠릿 σ 가 사다리 전보다 +40 / +48 / +85 / +25 % (열간 +1.0 / 0 / +2.6 %) | §3-4 (L107) · §4-1 (L167) | [판독] | 두께가 아니라 σ 의 이력 · 본문 표현은 *"30 to 40% higher"*
- [b] yano2026_se_psd_width_ionic_tortuosity_dem · yadav2021_lpscl_sieved_psd_impedance_tortuosity | 이 카드에 없음 (yano DEM 의 언로딩 · 이완 · 밀도 판독 시점 [미확인] · L198) | — | — | —


### [batch_13] b. 압력을 뺄 때 되돌아오는 양과 잰 방법

되돌아온 **두께를 실측** 한 카드 = **1** (miss2026_insitu: 300 MPa 에서 놓을 때 다이 안 SE +1.6 % · 다결정 NMC622 +7.9 % · 400 MPa 뒤 다이 밖 +6.5 % · +1.7 %). **한 모델 안에서 누른 채 ↔ 뺀 뒤** 를 준 카드 = 1 (zhang2026: 두께 회복 11–16 % · 탄성 Hertz + 취성 bond 의 산물). 역산 · 간접 = 2 (xu2023: 기공 – 두께 감소율 항등식의 잔차로 0.3 → 3.5 % · ngandjong2021: 압입 제하 회복 16 ↔ 25 %). 없음 = 2 (lyu2025 · miss2026_pressure — 단조 가압뿐).

- [b] miss2026_insitu_conductivity_porosity_pressure_compaction | **다이 안 두께 회복 (최소압 두께 ÷ 누른 채 두께 − 1) — 순수 SE**: 10 MPa −0.08 % · 20 +1.02 · 30 +0.26 · 40 −0.27 · 50 +1.01 · 70 +0.85 · 100 +1.93 · 150 +2.22 · 200 +2.17 · 250 +1.79 · **300 +1.62 % (0.588 → 0.5975 mm · 9.5 µm)** · 350 +2.17 · 400 +2.76 %. 본문: *"After releasing the respective applied pressure to the minimum pressure, the sample thickness increases by 0.3−2.8%."* | §3-2 (L80–98 · L113) · 논문 p.32832 · SI Table S2 (p.6) | 두께 = [인쇄] · 회복 % = [재계산] · 인용문 = [인쇄] | 조성 Li₅.₅PS₄.₅Cl₁.₅ · 단계마다 놓았다 다시 누름 · 불확도 "기호 크기 이하" ≈ 5–6 µm 라 SE 회복은 불확도의 약 2 배 (약한 신호) · 음수 두 칸은 불확도 안
- [b] miss2026_insitu_conductivity_porosity_pressure_compaction | **다이 안 두께 회복 — pc-NMC622 단독**: 50 MPa +0.73 % · 100 +2.30 · 150 +3.21 · 200 +5.06 · 250 +6.57 · **300 +7.90 % (0.276875 → 0.29875 mm · 21.9 µm)** · 350 +8.61 (최대) · 400 +7.09 % | §3-2 (L100–111) · SI Table S2 | 두께 = [인쇄] · 회복 % = [재계산] | 다이 밖과 모순 (아래) — 카드: "CAM 의 7.9 % 는 위 끝 · 불확실" · 다결정 NMC622 (단결정 자료 없음)
- [b] miss2026_insitu_conductivity_porosity_pressure_compaction | **다이 밖 (400 MPa 뒤 밀어낸 펠릿)**: SE 0.6036 mm = 누른 채 대비 +6.5 % · 다이 안 놓은 뒤 대비 +3.6 % ; NMC622 0.2689 mm = 누른 채 대비 +1.7 % 인데 다이 안 놓은 뒤 (0.2831 mm) 보다 **5.0 % 얇음** (저자 무언급). 본문: *"Removal of the pellet … leads to a further increase in the sample thickness"* (SE) | §3-4 (L139–146) · §10-2 (L334) · 논문 Fig 3a · S4a · p.32832–32833 | 다이 밖 두께 = [판독] · 비 = [재계산] | 400 MPa 뒤 한 번뿐 · NMC 모순의 원인은 카드 추정 (110 kPa 에서 시료 – 피스톤 틈)
- [b] miss2026_insitu_conductivity_porosity_pressure_compaction | 잰 방법: 경화강 피스톤 2 + PEEK 밀폐 하우징 · 스프링 4 개로 일정압 (연한 스프링 ≤ 250 MPa · 단단한 것 그 위) · 마이크로미터 (정밀도 5 µm · 피스톤 끝 홈으로 같은 자리) · 시료 없이 압력별 피스톤 길이를 재서 뺌 (식 1) · 최소압 ≈ 110 kPa = 위 피스톤 무게 + 대기압 · 단계마다 누른 채 → 놓은 뒤 순으로 두께 + 임피던스 | §4-1–4-3 (L186–199) · 논문 Fig 1 · 2 · S3 | [인쇄] | 유지 시간 · 하중 속도 · 교정 곡선 값 [미확인] · 축 방향 피스톤 탄성만 보정
- [b] miss2026_insitu_conductivity_porosity_pressure_compaction | 가역 몫: 첫 단계 → 400 MPa 치밀화 가운데 400 MPa 에서 놓을 때 되돌아오는 몫 **SE 7.8 %** (ε 0.299 → 0.043 → 놓으면 0.063) · **NMC 28.1 %** (0.338 → 0.142 → 0.197). 본문: *"the major fraction of the densification of μc-LPSCl is irreversible, while a significant fraction of the densification of pc-NMC622 is reversible"*. 카드 풀이: SE 의 300–400 MPa 회복 1.6–2.8 % 는 고체 탄성 p/E (E 22 GPa 면 1.4–1.8 %) 와 같은 자릿수 · NMC 는 p/E (0.17 %) 의 약 50 배라 구조적 회복 | §3-7 (L167–169) · §7-2 (L279) · 논문 p.32834 | 몫 = [재계산] · 인용문 = [인쇄] · 풀이 = 우리 해석 ([우리 산술]) | 기준이 헐거운 분말이 아니라 첫 측정 단계 (SE 10 · NMC 50 MPa) · 풀이는 불확도 ≈ 1 % 안이라 판정 약함 (카드 표기)
- [b] miss2026_insitu_conductivity_porosity_pressure_compaction | 두께 규약이 전도도에 주는 편향: 같은 펠릿 · 같은 저항에 다이 밖 두께 하나를 쓰면 σ 가 10 MPa −22 % · 200 MPa ≈ 0 · 400 MPa +6.5 % (부호가 압력에 따라 바뀜). 저자: 다이 밖 두께로는 *"do not converge … misleading information about the pressure dependence"* | §3-5 (L151) · §7-5 (L301) · 논문 Fig 3b · p.32833 | [판독] · 인용문 = [인쇄] | Li₅.₅PS₄.₅Cl₁.₅ 한 시료
- [b] zhang2026_xct_dem_cathode_calendering_peel_calibration | **같은 DEM 안의 누른 채 ↔ 뺀 뒤 기공**: 30 MPa 0.333 → 0.411 (Δε 0.078 · 두께 회복 ER = (h_제하 − h_하중)/h₀ = 11.3 % · 영구 압밀 몫 21 %) ; 60 MPa ≈ 0.280 → ≈ 0.370 (≈ 0.090 · ≈ 11.3 % · ≈ 41 %) ; 200 MPa ≈ 0.152 → ≈ 0.319 (≈ 0.167 · ≈ 16.4 % · ≈ 40 %). 실험의 뺀 뒤 기공 0.412 / ≈ 0.359 / ≈ 0.310 (0 MPa 는 DEM 0.432 ↔ 실험 ≈ 0.424) | §3.5 (L167–184) · §12 D2 (L512–519) · 논문 Fig 4b · 4c | 30 MPa 기공 = stated · 60 · 200 MPa = figure-read ≈ · ER · 몫 = derived(ours) | LIB (NMC + CBD) · 회복은 탄성 Hertz + 취성 bond 의 산물 (카드: 소성 SE 는 "회복이 훨씬 작을 것으로 예상만") · 실측 두께 회복과 견준 것 아님 · ER 은 Sangrós 2019 카드의 10.25 → ~17 % 와 같은 밴드 (카드 표기) · Fig 4b 에 범례가 없어 세 색 = 세 런이라는 것은 카드의 해석
- [b] zhang2026_xct_dem_cathode_calendering_peel_calibration | 제하 곡선의 모양: 200 MPa 런은 5 MPa 에서 아직 ε ≈ 0.236 이고 0 MPa 에서 0.319 → **회복의 ≈ 50 % 가 5 MPa 아래** ; 30 MPa 런도 5 MPa ≈ 0.370 → 0.411. 잰 방법 (모의) = 판을 0.01 m/s 로 내려 목표 응력 도달 즉시 정지 → 같은 속도로 올림 (목표 응력에서의 유지 없음) | §3.5 (L181) · §4.5 (L305–307) · §8 ② (L430–432) · D2 (L519) | figure-read ≈ · 프로토콜 = stated | 실험의 제하 곡선은 없음 (끝점 4 개뿐 · 실험 압연 방법 · 기공 측정법 [미확인])
- [b] zhang2026_xct_dem_cathode_calendering_peel_calibration | 누른 채 값을 헤드라인으로 쓴 사례: 체적 에너지밀도 곡선 (Fig 12 · 1422 → ≈ 2002 @ ≈ 140 MPa → ≈ 2050 Wh/L @200 MPa) 은 누른 채 두께로 계산됨 — 고체 부피 보존 검산이 다섯 점 모두 0.2 % 안. 뗀 뒤 구조로는 30 / 60 / 200 MPa 에서 ≈ 1470 / ≈ 1565 / ≈ 1680 Wh/L (200 MPa 에서 ≈ −18 %) | §3.10 (L238–251) · §12 D1 (L506–510) | 1422 · ≈ 2002 = stated · 나머지 figure-read ≈ · 검산 = derived(ours) (가정: 초기 두께 75 µm · 집전체 몫 6 µm) | 논문은 이 구분을 적지 않음 (카드의 판독)
- [b] xu2023_realistic_am_shape_cgmd_calendering | 모의 프로토콜 = 평면을 일정 속도 (값 미기재) 로 내림 → 목표 CD → 평면 해제 → 완화 · 60 ℃ 등온. 논문 문장: *"the plane is released and the electrode is 'relaxed' … the thickness … is partially regained"* · *"the particles re-stabilize due to self-reorganization"* | §4 (L349–350) · §3-B-4 (L261–262) | stated (인용) | 되돌아온 두께를 논문이 수로 주지 않음 · CD 의 기준 두께 (해제 전 / 후) 미기재 · 실험 쪽 되돌아옴 미보고
- [b] xu2023_realistic_am_shape_cgmd_calendering | 카드가 역산한 두께 회복: 바닥 고정 + 고체 부피 보존이면 ε = 1 − (1 − ε₀)/(1 − CD) 인데 모의 점이 이 식보다 성김 → 96 % AM: CD 15.37 → +0.33 % · 24.76 → +0.69 % · 32.68 → +2.20 % · 35.18 → +3.12 % · 36.11 → +3.52 % ; 94 % AM: CD 15.70 → +0.26 % · 25.49 → +0.34 % · 34.32 → +0.99 % · 38.72 → +2.20 % · 42.17 → +3.51 % (두 조성의 끝값이 거의 같음) | §3-B-4 (L243–270) · T6 (L300) | derived(ours) · 카드 표기 "가정 3 개 · 측정된 springback 으로 인용 금지 · 규모 감각만" | 논문 값 아님 · "CD 는 해제 전 두께 기준 · 기공은 해제 뒤" 라는 가정에 걸림 (다른 풀이 = 후처리에서 고체 부피 2.8 %p 미보존) · 탄성 + 점착 접촉 (소성 없음) · LIB 전극
- [b] ngandjong2021_dem_calendering_digital_twin | 압연 모의 2 단계 = ① 목표 압력까지 위 평면 하강 ② 처음 위치로 복귀 → 완화 (탄성 회복). **보고 압력 = 압축 끝 시점 · 보고 기공 = 탄성 회복 뒤**. 전극 높이 = 감압 중 위 평면과 전극의 접촉이 0 이 아닌 가장 높은 평면 위치. 감압은 압축과 같은 스텝 수 (13×10⁷–20×10⁷) · 같은 속도 (0.002 m/s) · 방향만 반대 | §4 (L272–273 · L318–320) · §6 (L505–506) | stated | 되돌아온 두께 · 기공의 **수** (누른 채 ↔ 뺀 뒤의 차) 는 카드에 없음 — 카드: "ε(P) 를 겹치려면 springback 만큼의 오프셋을 먼저 알아야 한다" (T5 · L245)
- [b] ngandjong2021_dem_calendering_digital_twin | 압입 제하 (Fig 2A): 힘이 0 이 되는 깊이 실험 ≈ 0.84 d_max · 모의 ≈ 0.75 d_max → 탄성 회복 실험 ≈ 16 % · 모의 ≈ 25 % (모델이 ≈ 1.5 배 더 되돌아옴). 잰 방법 = Vickers 다이아몬드 (CSM MHT) · 상온 · 하중 · 제하 0.4 mN/s · 최대 200 mN · 3 s 유지 · 30 회 · 침투 < 두께의 10 %; 모의 = 두께의 10 % 까지 압입 뒤 원위치 복귀 (8×10⁷ / 8×10⁷ 스텝) · F/F_max – d/d_max 로 정규화 | §3-B T6 (L246) · §4 (L323–328) · §5 Fig 2A (L462) | 회복 % = digitized · 시험 조건 = stated | 압입 회복이지 압연 뒤 되돌아옴이 아님 (카드 표기) · LIB 전극 · 실험 (접촉 면적 ≈ 31,000 µm² · 변위 ≈ 18 µm · 두께 ≈ 180 µm) 과 모의 (≈ 11,600 µm² · ≈ 16 µm · ≈ 154 µm) 의 치수가 달라 정규화 비교
- [b] ngandjong2021_dem_calendering_digital_twin | 복귀 뒤 구조의 두께 (FEM 메시) 165.0 / 141.6 / 133.8 µm (ε 41.6 / 31.5 / 27.2 %) · 고체 부피 보존 검산 +0.6 % · +1.1 %. 실험 쪽 기공 = 압연 뒤 지름 13 mm 디스크 8 장의 질량 · 두께 (압연기 BPN250 · 롤 지름 25 cm · 0.54 m/min · 롤 60 ℃ · 갭 → 압력 환산은 FlexiForce 힘 센서 필름) | §3 (L84) · §6 (L519–520) | stated · 검산 = derived(ours) | 누른 채 두께는 실험 · 모의 모두 카드에 없음
- [b] lyu2025_3d_dem_drying_calendering_lib | 되돌아온 양 없음 — 압연 모의는 위 판을 0.01 m/s 로 내리는 데까지 (무차원 시간 0 → 1.0 · 두께 80 → 60 → 40 µm) 이고 판을 되올리는 단계가 카드에 없음 | §3 (L29 · L47) · §4 (L74) | stated | 보고된 기공 22 % · 응력은 압연 끝 시점 값으로 읽힘 (누른 채인지 카드에 낱말로는 없음)
- [b] miss2026_pressure_tortuosity_composite_cathode_coating | 되돌아온 양 없음 — 8.8 → 663 MPa 단조 계단 가압뿐 (Fig S2 · 하중 제거 없음). 결론 끝 문단은 제작 압력을 빼고 작동 적층압을 거는 과정이 *"expected to be more reversible in nature"* 라고 기대만 적음 | §0 표 ① (L25) · §7-2 (L215–217) · 논문 p.11 · SI p.2 | [인쇄] | 카드: 언로딩의 실험 표적 · 기전 근거로 쓰지 않는다


### [batch_14] b. 압력을 뺄 때 되돌아오는 양과 잰 방법

되돌아온 두께 · 기공을 잰 카드는 **이 배치에 없다**. 가까운 것 = 접촉 임피던스의 압력 이력 (doux2020) · 영구 변형만 재는 절차와 재적층 몫 분리 (kakar1967) · 접촉 법칙의 제하 분기 (lee2024 · so2022) · 사이클 뒤 재가압 회복 (리뷰 둘의 인용).

- [b] doux2020_stack_pressure_assb | 두께 되돌아옴은 재지 않음. 접촉의 이력: Li 대칭셀 임피던스 > 500 Ω (1 MPa) → ≈ 110 (5) → ≈ 50 (10) → ≈ 40 (15) → 35 (20) → 32 Ω (25 MPa) → 5 MPa 로 내리면 ≈ 50 Ω (처음 5 MPa 값의 절반 이하) = 비가역 | §4 L144–163 · Fig 4c | 본문 stated (L365–366) | Li/SE 계면 접촉 (흐르는 것은 Li 금속) — SE 펠릿의 두께 · 기공 회복이 아님 · 25 → 5 MPa 한 번
- [b] doux2020_stack_pressure_assb | 잰 방법: 3-ton 로드셀을 셀 축 아래에 둔 홀더로 적층압 0–220 MPa 를 실측 · 제어 (100 kN Instron 5982 로 교정) · 나사 조임으로 압력을 바꾸며 EIS · 전압을 같이 측정 | §2.2 L97–100 · Fig 2a | 표지 없음 | 변위 (두께) 측정은 카드에 없음
- [b] doux2020_stack_pressure_assb | 저자의 가정 (측정 아님): "5/25/75 MPa stack pressure 의 (펠릿 자체) 기계적 성질은 단락 메커니즘에 영향을 주지 않을 것으로 본다 — 펠릿은 이미 370 MPa 로 cold-press 되어 있기 때문." (카드의 한국어 옮김) | §8 L235–236 | 카드 표기 "본문 명시" | 370 MPa 에서 놓은 뒤 펠릿이 얼마나 되돌아왔는지는 카드에 없음
- [b] kakar1967_deformation_theory_hot_pressing | 되돌아온 양은 재지 않음 — 잰 것은 영구 변형: 납 압분의 영구 변형 = Instron 차트의 처음 · 끝 읽기 차 (초기 하중 10 lb 가 기준점 · 고온은 2 lb) · 접촉 평면은 하중을 걷고 꺼낸 구의 잔류 평면 (측각기) | §3-A L64 · §4-2 L145 · §10 L302 · 논문 p.3227 | stated | 납 · 사파이어 · 카드: "탄성 회복 논의 없음"
- [b] kakar1967_deformation_theory_hot_pressing | 소성 전 재적층 몫을 떼는 법 (유리 구 380–400 µ · 다이 지름 1.25 in × 높이 0.25 in · 총하중 1000 lb): 초기 하중 2 · 5 · 10 · 40 lb 별 잔류 변형을 0 하중으로 외삽 → **10 psi 에서 약 1.5 % 부피 변화** · *"This strain is attributed to restacking or repacking alone"* · 구리 구는 1.3–4.3 % @10 psi (Duffield & Grootenhuis [21]) | §3-A L63 · §4-3 L150 · 논문 p.3226–3227 | stated | 유리 · 구리 구 · 10 psi (카드 환산 0.069 MPa)
- [b] lee2024_multiphysics_dem_fem_initial_pressure_assb | 수치 없음. 접촉 법칙에 제하 분기만: 하중 F = min(K_nl·S, F_prev + K_nl·ΔS) · 제하 F = max(F_prev + K_nu·ΔS, λ·K_nl·S) · K_nu = K_nl/ε² (ε = 반발계수) — 제하 강성이 하중 강성보다 커서 잔류 겹침이 남는 꼴 | §4.2 L118–124 · 식 3 · 6 | stated (식) | 침대 수준의 되돌아온 두께 · 기공은 카드에 없음 · 외부압 0–100 MPa 는 FEM 경계 조건 (탈압 계산 아님) · λ 값 없음
- [b] so2022_dem_compaction_coated_particles_assb | 탈압 단계 없음 (위 벽 PID 로 목표 몰드압 유지). 접촉 법칙의 관련 부품: 평형 겹침 h_eq (영구 잔류 겹침) · F_spring < −F_th 에서 detachment (융착 / 코팅 박리) · detachment 때 F_th = 0 (같은 응집체가 아니거나 기존 융착이 끊긴 경우) | §4.1 L87–94 · §4.6 L124 · 식 5–7 | stated (식) | 침대의 되돌아옴 값 없음
- [b] deysher2022_transport_mechanical_aspects_assb_review | 되돌아옴 자료 없음. 관련 인용: 첫 수십 사이클 뒤 370 MPa 재가압 → 잃은 용량 상당 회복 (Li₃PS₄ + NMC · [121] Koerver) | §3 L81 | stated (인용) | 사이클 열화의 접촉 손실 (탈압 되돌아옴 아님) · 리뷰
- [b] kang2026_intertwined_electrochemo_mechanical_sulfide_assb_review | 되돌아옴 자료 없음. 관련 인용: 300 MPa 재가압 → 용량 상당 부분 회복 · 30 사이클 뒤 저주파 저항이 재가압으로 ≈ 1/3 (Fig 8a · b · ref 105) ; 사이클 중 적층압 변동 ≈ 3.8 MPa (Li–In 셀) ↔ ≈ 0.2 MPa (LTO 셀) (ref 120) | §5.1 L134 · §6.2 L172 | 2 차 인용 | 재가압 압력이 deysher 카드 (370 MPa) 와 다름 (카드 문제 36)
- [b] sakuda2013_sulfide_mechanical_property | 이 카드에 없음 | — | — | —
- [b] nisar2024_dem_effective_electrical_conductivity_sps | 이 카드에 없음 | — | — | —


### [batch_15] b. 압력을 뺄 때 되돌아오는 양과 잰 방법

되돌아온 두께 · 기공을 잰 카드는 **이 배치에 없다**. 가까운 것 = 압력을 뺀 뒤의 한 상태만 잰 펠릿 (beutl2024) · 제조압과 작동압을 따로 적은 셀 (cronk2026).

- [b] beutl2024_round_robin_coin_cell_sulfide_assb | 되돌아온 양은 재지 않음. 잰 것은 압력을 뺀 뒤의 한 상태: 다이에서 꺼낸 자유 펠릿 두께 ≈ 0.8 mm (하중 중 두께가 없어 차를 낼 수 없음) | §0 L33 ④ · §3-2 L83 · §7-3 L315 · 논문 p.4 | [인쇄] (두께) · "꺼낸 뒤 (스프링백 · 취출 포함)" 은 카드 서술 | 측정 도구 · 오차 [미확인] · "하중 중 두께 · 언로딩" 은 카드가 이 논문에 없는 것으로 적음
- [b] beutl2024_round_robin_coin_cell_sulfide_assb | 카드가 붙인 우리 쪽 어림 (논문 값 아님): 다이 안으로 옮기면 "회복 1.6–7 % 만큼 더 치밀 (−1.4 – −4 %p, 세대 2 계획 표 B)" | §7-2 ⑤ L305 | [우리 산술 · 어림] | 근거 식 · 자료가 이 카드에 없음 (작업 브랜치 계획 문서를 가리킴) · 인용 불가
- [b] beutl2024_round_robin_coin_cell_sulfide_assb | 압력을 뺀 뒤 (코인셀 ≈ 0.2 MPa) 에서 잰 수송: *"In a recent study, the pressure inside a CR2032 setup was determined as 0.2 MPa,[15] considering a total sample thickness of 1.9 mm (without the spring)"* · 그 상태의 σ_ion 0.3–0.4 mS/cm ↔ 전극을 360 MPa 로 함께 누른 셀 1.0–1.8 mS/cm · 카드: "코인셀 자료와 맞대려면 언로딩 끝 상태가 대응 상태" | §3-1 L67 · §3-4 L130–134 · §7-1 L271 · §8-5 L324 | [인쇄] · 대응 상태는 카드 판단 | 0.2 MPa 는 이 논문이 잰 값이 아님 · 재료의 접촉 손실과 전극 접촉 규약이 갈리지 않음
- [b] cronk2026_lis_positive_electrode_geometry_fem | 탈압 되돌아옴 측정 없음. 닿는 것: 제조압 (375 MPa · 파우치 WIP 500 MPa @80 °C) 과 작동압 (75 MPa · 10 MPa) 을 따로 적음 · operando 적층압 변화 (75 MPa 기준 |Δ| ≈ 1.6 MPa (LiSi‖S) · 밴드 ≈ 0.4 (µSi‖Li₂S) · +4.7 (LiSi‖LCO)) 는 사이클 부피 변화 · FEM 은 "1st 리튬화 1회 스냅샷 — 사이클 누적·springback·재습윤 없음" | §2 L58–60 · §6.6 L487–495 · §10-13 L666 | digitized · TREND only (압력) | 리튬화 팽창 (탈압 아님) · Li–S
- [b] asano2017_ncm111_li3ps4_composite_electronic_ionic_conductivity | 이 카드에 없음 — "성형 360 MPa 실온 · 측정 하중 · 5 층 셀 조건 미기재 → springback 이력 비교 불가" | §7 L245 · §8-1 L266 | 카드 판단 | —
- [b] bielefeld2019 · bielefeld2020 · chen2011 · cooper2017 | 이 카드들에 없음 (역학 없음) | — | — | —


### [batch_16] b. 압력을 뺄 때 되돌아오는 양과 잰 방법

되돌아온 양을 수로 준 카드 = **1** (galvezaranda2024 — DEM 계산 · 값은 카드의 그림 판독). 실측은 **없다**.

- [b] galvezaranda2024_time_dependent_dl_calendering_microstructure | DEM 압연 (평면 프레스 · 일정 속도) → 목표 CD 에서 프레스 해제 → 완화: CD 25 / 35 / 45 % 에서 되돌아옴 4.8 / 7.6 / 10.1 %p (최대 압축 CD 22.6 / 33.9 / 42.9 % → 완화 뒤 17.7 / 26.3 / 32.8 %) · 눌린 두께 대비 +6.3 / +11.5 / +17.7 % · 잰 방법 = Fig 5b · 6a · 6c 의 void 복셀 수를 판독해 두께 h = (722,000 − void)/(76 × 76) 복셀로 환산 (압축 최저 96.8 / 82.6 / 71.3 → 완화 102.8 / 92.1 / 84.0 복셀) | §3-D L143–157 · §4-1 L171–174 | derived(ours) · digitized — TREND only (읽기 오차 ≈ ± 0.7 %p) | **논문 본문에는 되돌아옴 숫자가 하나도 없음** (L32–34 · L81) · 액체계 LIB (NMC111 + CBD) · 압력 축 없음 (CD %) · DEM 물성 미기재 · 카드: "값은 전이 금지, 부호와 곡률만" (L448)
- [b] galvezaranda2024_time_dependent_dl_calendering_microstructure | 방향: 되돌아옴이 압축 깊이에 단조 증가 — 눌린 두께 대비 회복률 6 → 18 % ("세게 누를수록 더 많이 되튄다") | §3-D L155–157 · §7-3 L424 | derived(ours) | 세 점이 서로 다른 미세구조 (III · II · I) · 시드 · 오차막대 없음
- [b] galvezaranda2024_time_dependent_dl_calendering_microstructure | 같은 그룹 선행 (ngandjong2021 카드 2 판에서 옮김): 압입 언로딩 잔류 깊이 exp ≈ 0.84 · sim ≈ 0.75 d_max → 탄성 회복 16 % vs 25 % | §4-1 L191–193 | 표지 없음 (다른 카드 인용 · "≈") | 압입 회복이지 압연 되돌아옴이 아님 (카드 경고 L193) · LIB
- [b] galvezaranda2024_time_dependent_dl_calendering_microstructure | 지배 기전에 대한 카드 서술: LIB 에서는 되돌아옴을 CBD 점탄성이 지배 (hong2026 카드 인용) — 이 논문의 DEM 은 CBD 를 단일 라벨로 다뤄 그 기전이 모델에 없음 | §7-3 L424 · §10-⑩ L649–650 | 카드 서술 (다른 카드 인용) | ASSB (PTFE · SE) 로 값 전이 금지
- [b] hlushkou2018_void_space_ion_transport_assb_cathode | 재지 않음. 두께는 EIS 측정 뒤 에폭시 매립 단면의 광학 측정 (208 ± 5 µm) 한 상태뿐 · "측정 중 적층압 · 스프링백 [미확인]" | §3-A L81 · L83 · §7 L258 | stated (두께) · [미확인] | 하중 중 두께 없음
- [b] duquesnoy2020_calendering_ml_mesostructure_generator | 재지 않음. 닿는 사실: 제어량이 롤 gap 이고 캘린더 뒤 두께 → 기공률만 있음 — gap 1 µm (초기 두께 138–178 µm) 에서 캘린더 뒤 기공 22.8–25.6 % (실측 평균) · 22.4–25.7 % (다항식) | §3.1 L44 · §3.3 L69–72 · §12 L453 | stated (xlsx) · 카드 검증 표 | 카드는 gap ↔ 최종 두께의 차를 되돌아옴으로 풀이하지 않음 · LIB
- [b] froboese2019 · hamann2026 · holzer2013 · islam2026 | 이 카드들에 없음 | — | — | —


### [batch_17] b. 압력을 뺄 때 되돌아오는 양과 잰 방법

되돌아온 양을 잰 카드 = **0**. 닿는 것은 "누른 압력과 잰 압력이 다르다" 는 기록뿐이다.

- [b] kato2018_thick_electrode_assb_cycle_tortuosity | 재지 않음. 세 층을 500 MPa 로 함께 누른 뒤 10 MPa 로 집전체 접합 → 하우징 50 MPa 에서 전기화학 측정 · 두께는 기공 0 의 명목값 (실측 언급 없음) — 카드 서술: 되튐 · 기공은 치밀 장부 (용량 밀도 q) 의 오차로 들어가 상자 기준 τ 를 낮추는 쪽 | §4-4 L243–245 · §3-3 L107 · §7 L338 · §10-3-6 L450 | stated (압력 이력) · [미확인] (두께 실측) · 카드 서술 (방향) | 되돌아온 양 · 하중 중 두께 0 건 · LGPS · 유리 + LCO
- [b] ketter2025_resistor_network_models_predict_transport_properties | 재지 않음. 두 상태만 있음 — LFA 펠릿 = 등방 500 MPa 뒤 하중 없이 잰 기하 밀도 · 전기 셀 = 370 MPa 성형 뒤 50 MPa 누른 채 (밀도 n/a) | §0 L25 · §4-5 L188 · L191 | 카드 서술 · n/a | 같은 시료의 누른 채 ↔ 뺀 뒤 비교 없음
- [b] kim2026_pregranulation_ptfe_dry_nca_cathode_crack_delithiation | 압밀의 되돌아옴 아님 — 전극 나노압입의 탄성 회복 (%): 기존 전극 25.2 → 36.5 · 과립화 전극 38.4 → 44.2 (사이클 전 → 전셀 10 사이클 뒤) | §3-8 L183–188 · 표 S3 | [인쇄] | LIB 건식 전극 (NCA + PTFE + 탄소) 의 겉보기 값 · 압입 회복이지 탈압 두께 회복이 아님 · 깊이 축 단위 의심 (L191)
- [b] kim2026_pregranulation_ptfe_dry_nca_cathode_crack_delithiation | 탈압 아님 — 사이클에 따른 두께 팽창: 144 µm → 10 사이클 뒤 162 µm (+12.5 %) / 156 µm (+8.33 %) · 저자: 원인 "remains uncertain" | §3-8 L194 · Fig 5h–j | [인쇄] | 전기화학 사이클 팽창 — 되돌아옴 자료 아님
- [b] kim2024_carbon_volumetric_occupation_se_domain | 재지 않음. σ 를 SE/복합체/SE 적층 517 MPa 와 103 MPa 가압 뒤 쟀다고만 적혀 있음 (두께 · 밀도 · 압력별 σ 값 없음) | §2 L43 · §6 L121 | 표지 없음 | —
- [b] jung2023 · kim2026_a3d · landesfeind2016 | 이 카드들에 없음 | — | — | —


### [batch_18] b. 압력을 뺄 때 되돌아오는 양과 잰 방법

되돌아온 양을 잰 카드 = **0**. 닿는 것은 "언제 · 어떤 상태에서 쟀는가" 의 기록뿐이다.

- [b] nakamura2020_dry_coating_ncm_li3ps4_core_shell | 재지 않음. 이력 = ⌀10 mm 일축 360 MPa → 303 K 50 회 충방전 → 완전 방전 뒤 분해 → FIB-SEM (하중을 뺀 뒤 · 사이클을 거친 구조). DC 분극은 따로 만든 새 80 mg 펠릿 (360 MPa). 누른 채의 두께 · 뺀 뒤의 두께 어느 것도 실측 없음 — 층 두께 ≈ 38 µm (반쪽셀 10 mg) · ≈ 300 µm (DC 80 mg) 는 복합 밀도 3387 kg/m³ 로 낸 카드 산술 | §3-4 L92–98 · §3-6 L124 · §10-7 L320 | [인쇄] (이력) · [우리 산술] (두께) | 같은 시료의 누른 채 ↔ 뺀 뒤 비교 없음 · Li₃PS₄ 유리
- [b] lee2026_unveiling_ptfe_dry_electrode_digital_twin | 재지 않음. 전극을 370 MPa 5 min 누른 뒤 FIB-SEM · 셀은 적층압 50 MPa · 전도도 측정 중 압력 · 전극 두께는 [미확인]. 카드가 우리 대칭셀 계획의 기록 항목으로 "가압 중 / 놓은 뒤 두께" 를 적음 | §3-1 L69–72 · §3-2 L87 · §8-8 L420 · §10-10 L439 | [인쇄] (이력) · [미확인] | 되돌아온 양 0 건
- [b] lee2026_unveiling_ptfe_dry_electrode_digital_twin | 탈압 아님 — 사이클 중 압력 변화 (OEP · NCM/LTO · 일정 체적 10 MPa · 0.2 C · 압력센서 분해능 0.1 kg): 첫 사이클 ΔP 최저 ≈ −0.44 MPa (PTFE 0) / ≈ −0.22 MPa (0.2 wt%) | §3-9 L192 · Fig S19 | [판독] | 전기화학 부피 변화 — 용량당 정규화 없음
- [b] matthews2024_ptfe_nanofibril_network | 재지 않음 — 캘린더 80 °C · 라인압 50 N/mm → ≈ 100 µm (porosity · 밀도 미보고). 카드가 옮긴 타 논문 값: Hippauf 2019 의 NMC + Li₆PS₅Cl + CNF + PTFE 0.1–1 wt% 막 ≈ 200 µm → 300 MPa 압축 뒤 ≈ 100 µm | §3.2 L140 · §8 L462 · §2 L99 | stated · [인쇄 p.3–5] (hippauf2019 카드 기준 · 카드의 2026-10-13 정정 표지) | 압축으로 준 두께지 되돌아온 양이 아님
- [b] landesfeind2018 · malifarge2017 · morasch2018 · nguyen2020 | 이 카드들에 없음 | — | — | —


### [batch_19] b. 압력을 뺄 때 되돌아오는 양 · 잰 방법

- [b] song2025_porous_argyrodite_modulus_fracture_toughness | 되돌아옴 직접 측정 없음. 압밀 · 열처리 뒤 펠릿의 소변형 굽힘 힘–처짐이 "거의 선형·가역 (약한 이력 = 소량 비탄성)", 파괴 직전 작은 평탄부 = 소성/손상 개시; 대표 외팔보 최대 ≈215 mN @ ≈0.042 mm → 강성 ≈5.1 N/mm | §4.1 L108–111 · §3.2 L58 · Fig 1e | stated (관찰) · figure-read ≈ | 탈압 과정이 아니라 탈압 **뒤** 시편의 굽힘 · 잰 방법 = 하중계 (21 N/mm 이중 외팔보 · 광섬유 변위센서) + 현미경 DIC 처짐 (L72 · L108)
- [b] pouraghajan2018_tortuosity_polarization_interrupt_vs_blocking_electrolyte | 집전체에서 막을 떼면 (화학 박리) 두께 +12 % (양극 3) · +5 % (음극); 명목 건조 두께로 계산한 τ 가 박리 전후 BE 끼리 ≈ −40 % · −21 % 다름 | §3-1 L60–61 · §3-2 L78 | stated (두께) · 판독/파생 (τ 차) | 압력 해제가 아니라 구속 (집전체) 제거 · 두께를 잰 방법 카드에 없음 · 액체 LIB
- 나머지: 해당 없음.


### [batch_20] b. 압력을 뺄 때 되돌아오는 양 · 잰 방법

이 배치 카드 자신의 측정 · 계산값은 없다. 다른 카드를 가리키는 서술과 방법만.
- [b] vijay2025_hybrid_cgmd_dl_slurry_microstructure | 압연 DL 자매편 (정본 `galvezaranda2024_time_dependent_dl_calendering_microstructure`) 의 springback 을 "우리가 그림에서 뽑았다": 압연도 25 / 35 / 45 % → 4.8 / 7.6 / 10.1 %p (그 논문은 숫자 0 건) | §12-1 L645 | 다른 카드의 그림 판독 (2차) | 이 카드의 값 아님 · 재료 · %p 의 정의가 이 카드에 없음 → 그쪽 카드에서 확인
- [b] zhang2026_dryprocess_electrode_architecture_cell_level | Weitze 2024 카드가 springback 을 다룬다는 포인터뿐 | §8-E L1135 · §13 L1329 | 표지 없음 | 값 없음
- [b] wang2027_ncm811_effective_bulk_modulus_mapper_dfs_gnn | 되돌아옴 측정 없음 · 대신 압축이 끝난 구조의 작은 변형 탄성 균질화 (주기 경계 · ε₁₁ = ε₂₂ = ε₃₃ = −0.0125 · K = −P/(ΔV/V₀)) 방법 — 되돌아옴 크기를 정하는 탄성 계수 쪽 | §3-3 L90–91 · §8-7 L371–374 | [인쇄] · 카드 제안 | 액체 LIB · 선형 탄성 · 완전 결합 복셀


### [batch_21] b. 압력을 뺄 때 되돌아오는 양 · 잰 방법

이 배치에 없음 (되돌아옴을 잰 카드 없음). 관련만:
- [b] zhou2026_gyroid_structural_electrolyte_stiffness_ionic_tradeoff | 압밀이 끝난 MPM 상 격자에 선형 탄성 주기 균질화 (단위 변형 6 경우) 를 걸면 이방 탄성 텐서 (E_x · E_z · ν) 를 낼 수 있다는 카드 제안 — 접촉이 완전 결합으로 들어가 실제보다 뻣뻣하고, 언로딩 · 스프링백은 접촉이 열려 비선형 | §7-5 L243 | [제안] · [추정] | 값 없음 · 방법 제안만
- [b] frankenberg2024_dem_high_intensity_mixer_assb | 압축 보정 시험은 하중 쪽만 (1 g · 상부 stamp 4.17 mm/s 로 6 mm 까지 · force–displacement) — 되돌림 구간 기록 없음 | §4.6 L116 · Fig 5b | stated | heteroaggregate 분체 · 되돌아옴 값 없음
- [b] duquesnoy2023_ml_multiobjective_manufacturing_optimization | 되돌아옴을 다루지 않음 — Table 4 의 두께 68 ± 4 → 48 ± 4 µm (압연 30 %) 만 있음 | §3.5 L91 | stated | 액체 LIB · 두께 감소율 축 · 카드에 되돌아옴 해석 없음


### [batch_22] b. 압력을 뺄 때 되돌아오는 양 · 잰 방법

이 배치에 없음 (압밀 탈압 되돌아옴을 잰 카드 없음). 관련만:
- [b] han2025_icep_conductive_elastic_binder | 전극 나노압입 탄성 회복률 ICEP 48.0 % vs PVDF 35.8 % (2.0 mN · 깊이 936.1 vs 3345.2 nm) — 카드: "탄성 binder → 소성변형 최소" | §3c L61–63 · Fig 2j | stated | 압입 회복률 (계산식 카드에 없음) — 압밀 탈압 되돌아옴과 다른 양 · 액체 LIB 전극
- [b] hong2026_sulfide_cathode_binder_digitaltwin | operando pressiometry = 압력 센서로 단위용량당 압력 변화 Δ(ΔP)_Q [MPa·g·(A·h)⁻¹] (LTO zero-strain 음극으로 양극만 분리): Pwd 1.88 · S-Pwd 1.89 · NBR 1.99 · PTFE 1.74 | §2.3 L105–106 · §4.3 L244–248 · Fig 3a · S16 · S17 | 표지 없음 | 사이클 중 부피 변화 지표 (탈압 아님) · 고정 구속 아래 치수 변화를 압력으로 재는 방법의 예
- [b] hippauf2019_dry_film_ptfe_sulfide_cathode_sheet | 압연 막 ≈200 µm (기공 ≈50 %) → 300 MPa 뒤 ≈100 µm · 전셀은 300 MPa 1 회 가압 뒤 외부 가압 없이 100 사이클 93.6 % · SE 층 · 양극 거시 균열 없음 | §3-2 L81–82 · §3-7 L151–154 | [인쇄] | 탈압 뒤 두께 변화를 따로 재지 않음


### [batch_23] b. 압력을 뺄 때 되돌아오는 양 · 잰 방법

이 배치에 없음 (성형 압밀 뒤 탈압 되돌아옴을 잰 카드 없음). 관련만 (성형 뒤 운전 · 체결 스택압):
- [b] jun2026_ppma_econductive_binder_si_lowpressure_assb | 370 MPa 성형 뒤 운전 압력을 load cell 로 실측 유지 (5 또는 70 MPa) — PVDF-Si 0.2C 용량 2490 (70 MPa) → 1820 mAh/g (5 MPa) · 해석 = 탈리튬화 수축 → 공동 · 균열 → 전자망 붕괴 (PVDF 2.0×10⁻³ → 4.3×10⁻⁵ S/cm) | §6 L98 · §5 L76 · L82 · §7.1 L108 · Supp 1 · Fig 3e | 표지 없음 | 탈압 되돌아옴 측정 아님 (사이클 중 스택압 효과) · Si 음극
- [b] jun2026_ppma_econductive_binder_si_lowpressure_assb | OEP (operando electrochemical pressiometry) — 가압 셀 안 압력 센서 (0.1 kg 분해능) 로 충방전 중 압력 변동을 Δ(ΔP)/Q_discharge 로 기록 · 부피 변화 가역성 지표 | §6 L100 · §12 L190 · §17 L247 · Supp 37 | 표지 없음 | 구속 아래 치수 변화를 압력으로 재는 방법 (탈압 되돌아옴과 다른 양)
- [b] kawaguchi2023_doe_electrode_fabrication_dry_coated_ncm_lps | 성형 (180 / 360 MPa) 뒤 볼트 체결 토크 Ts 0.5 → 2.5 N·m 에서 Xs 0.1 첫 방전 이득 단순 +22.3 · 코팅 +42.1 mAh/g — 토크 → 압력 환산 원문 없음 · 카드 어림 ≈21 → ≈106 MPa (K = 0.2 가정 · 마찰 · 절연 시트 무시) | §0 ⑥ L32 · §3-2 L75–76 · §8-1 L242 | [우리 산술] · [추정] | 되돌아온 양 측정 없음 · 조건마다 셀 1 개


### [batch_24] b. 압력을 뺄 때 되돌아오는 양 · 잰 방법

이 배치에 없음 (성형 뒤 탈압 되돌아옴을 잰 카드 없음). 관련만:
- [b] lee2025_corolling_dryprocess_lpscl_ptfe | 500 MPa 제조 뒤 운전 스택압 75 → 2 MPa 에서 사이클 뒤 계면 void 비 freestanding 4.0 → 15.5 · co-rolled 1.9 → 3.5 (ImageJ 하위 5 % 문턱 · 세 영역 상대비) · 2 MPa 에서도 500 사이클 >80 % 유지 (75 MPa >95 %) | §3 L45 · §5 L83 · §6 L98 · Fig 5a,b,e,f · Supp Fig 27–29 | stated | 되돌아옴 측정 아님 (사이클 뒤 계면 void · 상대 지표)
- [b] lee2026_li_underlayer_primer_free_dry_prelithiated_thick_anode | 자립 막 ≈85 µm → 라미네이트 뒤 전극 63–65 µm — 줄어든 과정 (라미네이트 압밀) 서술 없음 · 압력 미기재 | §3-1 L73 · L77 | [인쇄] (두께) · [미확인] (과정) | 가압 뒤 두께만 · 되돌아옴 아님
- [b] koo2026_swcnt_sheath_thick_electrode | 파우치 장기 사이클 외부 가압 1 MPa (Table S8) — 탈압 거동 기록 없음 | §11.9 L906 | 표지 없음 | 운전 압력 기록일 뿐


### [batch_25] b. 압력을 뺄 때 되돌아오는 양 · 잰 방법

이 배치에 없음 (성형 압밀 뒤 탈압 되돌아옴을 잰 카드 없음). 관련만:
- [b] lippke2023_dem_drying_structure_formation_lib | 구동력 (액면 모세관력) 이 끊긴 뒤 상부 층이 이완해 두께가 약간 다시 오름 — 저자는 실제 공정에서는 pore-by-pore 증발이 일어나므로 이 이완 구간을 비물리로 보고 버림 · 최종 두께 = 층–액면 간격이 최대 입자 직경 (11.35 µm) 을 넘는 순간의 값 | §4.8 L401–405 · Fig 5 | stated | 습식 건조 (압밀 탈압 아님) · 되돌아온 양의 수치 카드에 없음
- [b] mun2025_dry_electrode_technology_assb_review | 리뷰 Perspective 과제 목록에 "pressure-free 운용" (스택압 없는 운전) | §2 L31 | 리뷰 서술 · 표지 없음 | 값 · 측정 없음


### [batch_26] b. 압력을 뺄 때 되돌아오는 양과 잰 방법

- [b] qin2026_bilayer_cathode_cgmd_dem_graded_thick_electrode | 스프링백 비 (부과 두께감소 중 제하 뒤 회복 분율) *"approximately 25 to 28% at c10 to approximately 11 to 14% at c40"*; 회복 두께 = H_c0 의 ≈2.6 % (c10) → ≈5.1–5.4 % (c40) (비는 줄어도 절대 회복은 는다); 방법 = 강체 윗벽 변위제어 하강 → 같은 속도 상승 (롤이 떠나는 것) → 회복 두께 | §3.2(c) 줄 147–157 · §2.5 줄 85 · §4.4 줄 297 (p.12 · p.17 · Fig 4b·c) · D13 줄 629–630 | stated (범위) · figure-read ≈ · derived(ours) | NMC111 + CBD 액체계 LIB · 3D CGMD-DEM (LJ + JKR · 강체 1차구) · 압력 축 없음 · 회복 크기의 물리 근거 = JKR-LJ 탄성-점착, 실측 미비교 (L-13 줄 507) · 1 실현
- [b] sankar2026_fiber_scale_dem_carbon_felt_manufacturing | 캘린더링 = 평판 변위제어 "압축 → 압축 후 (되튐)" 2 단 알고리즘 · 분석 구조 = 되튐 뒤 평형 구조인데 되튐 뒤 두께 · 공극률은 미보고 · 되튐 판정 조건 [미확인] | §4.6 ④ 줄 329 · §3.7 줄 240 · L6 줄 596 (p.15–16) | stated · [미확인] (SI S1.2.4) | 산화 PAN 섬유 부직포 · 결합구 사슬의 탄성 되튐 · 회복량 수치 없음
- [b] nam2026_primer_layer_dry_electrode_collector | 나노압입 탄성회복비 S100 ≈61.5 · S75C25 ≈78.7 · S50C50 ≈76.5 · S25C75 ≈88.5 · C100 ≈93.5 % (비가역 분율 38.5 → 6.5 %); 방법 = 나노압입 하중-변위 (Fig S6 · Oliver–Pharr 계열 명시 없음) | §4.3 줄 228–247 · §8 줄 498 (Fig 3e–g) | digitized ±5 % | 카본 (Super P/MWCNT) + CMC primer 층 (SE 아님) · 압입 하중 카드에 없음 · 가루 침대 탈압 아님
- [b] park2026_thiolene_sbr_binder_assb | 나노압입 50 µN 하중 제거 뒤 탄성회복 X10 66.3 % vs SBR 38.2 % (X6 · X10 은 침투깊이도 얕음) | §2.2 줄 133–134 (Fig 3d) | 표지 없음 | SBR 계 바인더 시료 (시료 형태 카드에 없음) · SE · 침대 아님


### [batch_27] b. 압력을 뺄 때 되돌아오는 양 · 잰 방법

- [b] wet_processing_resolved_am_ssb_cathode_manufacturing | roll 을 목표 압연도까지 등속 하강 → 같은 속도로 후퇴 → springback.  카드 산출 되돌아옴 = 압축량의 10–15 % (압연도 0.1 → 0.45 에서 15 → 10 %) · 압연도 0.45 에서 풀린 두께 ≈23.8–24.6 µm (처음 40 · 눌린 22 µm).  잰 법 = 고체 부피 보존 + '압연도 = 적용 두께 감소율' 가정으로 Fig 6 기공에서 역산 · Fig 5 의 45 % 곡선 종단 ≈24 µm 와 자기일관 | §①-C 줄 386 · §②-7 줄 438 · §③-C ④ 줄 488 | 우리 산출 (derived) · Fig 6 digitized | 압력 축 없음 · 습식 · 초연질 CBD ~10 vol% · AM 강체 multisphere · SI springback 영상 미열람 · 카드: Sangrós 2019 LIB ~17 % 와 같은 자릿수
- [b] wet_processing_resolved_am_ssb_cathode_manufacturing | 기공-압연도 곡선 (0.57 → 0.30) 의 비선형을 저자는 'springback 이 압연도에 따라 달라서' 로 설명 | §3 줄 54 · Fig 6 줄 106 | stated | 되돌아옴 수치 자체는 논문에 없음 (카드 산출만)
- [b] wang2026_dryprocess_thick_cathode_failure_ncm94 | 되돌아옴 측정 아님 — 강체 다이 일정 부피에서 압력 완화: 조립 110 MPa → 측정 시작 107.6 MPa (2.4 MPa 이미 사라짐) · 처음 12 h 완만한 하강은 점탄성 크리프와 구별 안 됨 (휴지만 한 대조 없음) | §8.3 줄 394 · §8.4 줄 408–409 · §15-14 줄 735–736 | digitized · DERIVED(ours) | NCM94 + Cl-rich 황화물 · LTO 사이클 셀 · 스택 강성 미공개
- [b] wolf2026_extruder_vs_batch_mixing_core_shell_dry_sulfide_cathode | 캘린더 롤 간격 ≈126 · 127 µm 를 닙의 막 두께로 읽으면 닙 공극 ≈52 % — 카드: '풀린 뒤 두께는 더 크다' (측정 없음) | §3-5 줄 122 · 127 | [판독] · [우리 산술] · 가정 | 되돌아옴 수치 없음 · PTFE · C65 포함 막


### [batch_28] b. 압력을 뺄 때 되돌아오는 양과 잰 방법

- [b] dem_mechanical_stresses_ssb_electrode_cycling | 일축 375 MPa → 1 atm 점감 (relaxation): z 두께 84 → 95 µm (카드: "영구변형 + 탄성 회복") · 같은 단계 σ_el/σ_AM 0.072 → 0.032 ("significant decrease upon relaxation" · 접촉 끊김); 잰 방법 = DEM 상자 z 두께 (xy 150 µm 주기 고정) | §3.1 줄 66 · §4.4 줄 155 · §3.5 줄 109–110 (Fig 2 · Fig 6a) | digitized | 강체 구 Hertz DEM (실험 아님) · NMC532 + LPSCl · 기공률 미보고 · 다음 등방 단계는 xy 150 → 130 µm 로 바뀌어 두께로 견줄 수 없음 (줄 68)
- [b] gandla2026_layered_cathode_degradation_diagnostics_review | 측정법 경고: ex situ 분해 중 *"contact recovery under pressure, lithium redistribution, and stress relaxation can partially reverse"* → 실제 고장 상태를 가림 · 논쟁 5.2.5 의 결정 실험 = 같은 입자 operando → 완화 → 재측정 짝 비교 | §3-1 줄 64 (p.2–3) · §3-10 표 줄 198 (p.27) | [인쇄] | 회복 양 수치 없음 · 총설 (2 차)
- [b] intergranular_cracking_nmc811_jmca2023 | 측정법 경고: FIB-SEM 처럼 입자를 잘라 보면 잔류응력이 풀림 → 같은 입자를 비파괴 CT 로 충전 전 · 후 두 번 (탭 형상으로 같은 RoI 재추적) | 머리 줄 65–67 · §A-1 줄 289 | 카드 서술 | 탈압 회복 값 없음 · 액체계 LIB
- (가까운 것) [b] kim2023_chemomech_failure_highstrain_anode | 150 사이클 뒤 250 MPa 재가압 → 방전용량 25.2 → 38.3 mAh/g 만 회복 (불완전 = 비가역 손상 해석) · R_int 약간 ↓ | §5 줄 231–232 · §7 줄 275 (Fig S13–S14) | 그림 / 본문 근사 (줄 365) | 재가압 (제하 아님) · NCA · 사이클 뒤


### [batch_29] b. 압력을 뺄 때 되돌아오는 양 · 잰 방법

- [b] so2021_dem_fabrication_degradation_ductile_particles | 순수 SE (LPS 유리) 제조 뒤 제하: 높이가 가압 중 지수 감소 → 제하 때 springback 으로 **부분 회복 · 처음 높이로 안 돌아감 (영구 h_eq)** · "higher Pfab → lower final height" · 되돌아온 양의 수치는 카드에 없음 (y 축 ×10⁴ µm · 응집체 척도 모델) | §3.2 L79 · §5.4 L193 · Fig 3b | digitized · stated | 잰 방법 = DEM 전극 높이 시계열 (모델 출력) · 2D · LPS 유리 · 복합 (Si + SE) 은 Fig 5a "지수감소 → unload → 안정" 서술만 (L197)
- [b] so2021_dem_fabrication_degradation_ductile_particles | 접촉 하나의 되돌아옴 (모델): 임계 초과 뒤 제하 곡선이 오른쪽으로 평행 이동 (h_eq > 0 영구) · F_max 50 / 100 / 200 µN · σ_H 1.0 / 1.5 / 2.0 GPa 별 이력 — σ_H 가 소성 전이점 · 최종 h_eq 를 정함 | §4.2 L144 · Fig 2c–d | stated (모식) | 수치 없음 · 가공경화 무시
- [b] sedlatschek2026_nmc811_grain_boundary_strength_micro_tensile | NMC811 2 차입자 단면 flat-punch (Ø5 µm · 최대변위 5 µm · 15 s): 제하 곡선이 0 에 닿는 잔류변위가 있음 (Fig 4b · 값은 카드 §3.3 L113 "인용 금지 정밀도" 표지라 생략) · 저자: "no quantitative results could be derived" (불규칙 단면 · 바인더 주변 · 내부 결함) | §3.2 L96 · §3.3 L113–117 | stated (조건) · figure-read ≈ (곡선) | **SE 아님** · 입계 파괴 · 바인더 박리를 겪은 뒤 · 정량 불가 (저자)
- [b] tron2023_lpscl_ccd_ambient_pressure | 되돌아옴 측정 없음 — 두께를 잰 상태 (다이 안 / 놓은 뒤 / 꺼낸 뒤) · 꺼낸 뒤 지름 [미확인] | §0 ② L27 · ⛔ 한정어 ③ L32 · L58 | [미확인] | —
- 나머지 여섯 카드: 없음.


### [batch_30] b — 탈압 때 되돌아오는 양

- [b] 이 배치에 없음 — 압력을 뺀 뒤 되돌아오는 양 (spring-back) 을 잰 카드는 없다.
- [b] kim2024_digital_twin_acsenergyletters | spring-back 은 ACS EL 그림에 별도 패널이 없음 (한국어 매거진판 Fig 6c 에만) — 동료심사 인용은 본문 ref 50 · 104 (drying · calendering DEM) + Fig 5a (calendered electrode) 로 하라는 카드 안내 | §7.1 (줄 387–392) · §10 (줄 499–500) | 카드 안내 | 값 없음 · ref 50 · 104 원문 미확인
- [b] lee2023_sicspe_digitaltwin_assb | 디지털트윈 = 단일 스냅샷 (spring-back · 사이클 열화 없음) | §7(c) (줄 357–358) | 카드 기록 | 값 없음
- [b] yun2023_deciphering_degradation_halide_vs_sulfide | AFM FS 국소 영률을 가압 전 · 후로 잼 (LPSCl 32.8 → 29.3 · LIC 41.1 → 19.8 GPa) — 되돌아오는 변형량이 아니라 가압 손상 지표 | §3.3 (줄 152–161) · Fig 4c–f | stated | 회복량 아님


### [batch_31] b — 탈압 때 되돌아오는 양 · 잰 방법

- [b] boschpadros2014_dem_liggghts_msc_thesis | 접촉 하나 수준의 개념 그림만: 하중 기울기 k₁ < 제하 기울기 k₂ · δ_max 에서 제하하면 잔류 겹침이 남는 이력 (값 없음 · 데모는 전부 가역 Hertz) | §4.2 (줄 109) · thesis Fig 2.34 | 표지 없음 (카드 서술) | 침대 (덩어리) 탈압 · 되돌아옴 측정 아님 · 비출판 MSc
- [b] 그 밖에는 이 배치에 없음.


### [batch_32] b — 탈압 때 되돌아오는 양 · 잰 방법

- [b] hong2026_cbd_viscoelasticity_springback | 압연 (목표 3.5 g/cm³) 뒤 보관 중 두께 회복 = 시간의존 spring-back: 단결정 NCMA RT 58 → 61.7 µm (3 주 · Fig 3b) · RC-P 58 → RC-S ~62 (+~4 µm) · HT 58 → ~59 (+~1 µm) · 다결정 66 µm 유지 (Fig S4); 잰 방법 = 2D 단면 SEM 다지점 (Table S1: 1 · 2 · 3 주 각 3 값) · 보관 뒤 bulk 전자저항 0.50 → 0.56 Ω·cm (46-point probe · Fig 3c) | §4.2 (줄 178–206) · §4.4 (줄 233–241) · Fig 3 · 5a · S8 · Table S1 | 표지 없음 | 액체 LIB · 무른 상 = CBD (PVDF + Super P) · 압연 직후 (즉각) 회복량은 카드에 없음 · 3 주 값 61.7 (Fig 3b) ↔ Table S1 61 / 61 / 61 (카드 문제 5)
- [b] hong2026_cbd_viscoelasticity_springback | 즉각 회복 (압력 해제 직후) 을 다룬 선행 = refs 18, 19 (이름 없음) · 보관 중 회복 첫 보고 = Kollenda et al. [20] (다결정 2차입자라 보관 중 두께 증가가 무시할 만했다) | §1 (줄 72–75) · §3 (1) (줄 140) | 카드 서술 (2 차) | Kollenda 원문 미확인 · 서지 일부만 → [n]
- [b] endo2001_vgcf_basic_properties_battery_applications | 섬유 매트 복원율 (resiliency): 넣은 부피 V₀ → 일정 압력 P 아래 V₁ → 압력 제거 뒤 V₂ · Fig. 9b (x = log(압력/부피밀도)) 흑연화 s-VGCF ≈ 104–178 % · s-VGCF (○) ≈ 85–119 % · 기존 탄소섬유 ≈ 19–59 % · 서열 흑연화 > 탄화 ≫ 기존 섬유 | §4-6 (줄 252–254) · Fig. 9 (줄 326) · §8-1 (줄 365–368) | figure-read ≈ | 정의식이 본문 (V₀−V₁)/(V₀−V₂) ↔ 캡션 (V₀−V₂)/(V₀−V₁)×100 % 로 역수 · 어느 식도 그림 범위를 설명 못 함 → 서열만 · 순수 섬유 · 압력값 미보고
- [b] 그 밖의 일곱 카드 — 되돌아오는 양 없음 (huang2025 는 압밀 끝 침대만 쓰고 탈압 · 되돌아옴을 보고하지 않음 · 카드 §4 (A) 줄 53).


### [batch_33] b — 탈압 때 되돌아오는 양 · 잰 방법

- [b] kaiser2018 (N. Kaiser et al., J. Power Sources 396 (2018) 175–181) | 되돌아오는 양 값 없음 — 원문은 springback 을 다루지 않음 (압력 의존 · 이완 · 되튐 논의 없음).  압력 이력 = 4 t/cm² (≈392 MPa, 카드 파생) 압밀 → Type-A 는 *"the pressure was relaxed to 2 t cm⁻²"* (≈196 MPa) 상태로 측정 · 두께는 측정 뒤 수지 단면 (ex situ) → 카드 판단: R 은 부분 해제 하중 (τ↑), 두께는 해제 뒤 (τ↓) 라 두 성분 부호가 반대 · 크기 미상 | §0 · §4-4 · §8-1 · §10-1 2 · SI p.1–2 · p.178 | stated (압력 이력) · 카드 해석 (부호) | Type-B · C 측정 하중 미기재 [미확인] · Type-C 409 vs 420 Ω (2.7 %) 는 방법 차와 재압밀 이력이 교락 → springback 시험 아님 · LPSI 유리 · 카본블랙 계
- [b] jung2019 (S.-K. Jung et al., J. Mater. Chem. A 7 (2019) 22967–22976) | 되돌아오는 양 값 없음.  무가압 · 진공 in situ SEM 5 일 (베어만) 에서 균열 생성 · 확대 — 저자는 가압 해제 이완 [29] 을 배제하려는 시도로 썼으나 카드는 "화학 유발 균열과 압력 해제 · 진공 효과를 가르지 못한다" 고 적음 · 원문 *"chemically induced physical degradation, which must be confirmed further"* | §6-bis 3 · §8 표 · §10 · SI p.4 · p.22971 | stated (관찰 · 인용문) · 카드 판단 | 코팅 대조 없음 · 무가압 측정만
- [b] lawrence2008 | (참고 · 단섬유) AFM 3점 굽힘의 누르기 · 빼기 곡선이 점착 구간 밖에서는 겹침 → 탄성 (최대 90 nN · 시험 뒤 TEM 손상 없음) | §4-4 · Fig. 4 · p.1232 | stated | VGCF 단섬유 · 복합체 탈압 아님 · Fig. 4 주 그림 ↔ 삽입 불일치 (카드 §10-1 ⑦)


### [batch_34] b — 탈압 때 되돌아오는 양과 잰 방법

- [b] nase2001_granular_bond_collision_number_wet_cohesion | 측정 없음. 접촉 단위 제하 법칙만: 항복 전 제하 = 탄성 · 항복 뒤 제하 F_n = F_max − k_n√R̄ (α_max − α)^{3/2}, R̄ = R′/R* = (F_y/F_max)((2F_max + F_y)/(3F_y))^{3/2} (새 접촉 반경 R′ = 잔류 압흔) | §3-1 L59 · 식 6–7 · p.215 | [인쇄] | mm 유리 충돌 · 흐름 모사 (압밀 · 탈압 아님) · 이 법칙으로 되돌아옴을 잰 검증 없음
- [b] luan2025_graded_cathode_400whkg_pouch | 되돌아옴 측정 없음. 제조압 (양극 단축 300 MPa · 파우치 등방 500 MPa) 과 사이클 스택압 30 MPa 를 나눠 적음 | §3-1 L73–77 · §7-A L426 | stated | 탈압 뒤 두께 · 기공 없음
- [b] minnmann2022_designing_cathodes_solidstate | 되돌아옴 측정 없음. 제조 (cold-press) 압 ↔ 작동 스택압 "수~수십 MPa" 구분만 | §0 표 L92 · §2.2 L159–161 · §10-4 L372–373 | 표지 없음 · 직접 인용 | 범위 권고뿐


### [batch_35] b — 탈압 때 되돌아오는 양 · 잰 방법

이 배치에 직접 값 없음.  참고:

- [b] otani2023 | 되돌아오는 양 없음.  순수 층 공극은 "구속 상태 두께" 로 냈고, SEM 단면 시료는 "구속 못 해 측정 공극률과 다름" (이진화 공극으로 대신) — 누른 채 ↔ 뺀 뒤 차를 보고하지 않음 | §3-1 (줄 60 · 64) · §10-3 (줄 246) · p.2–3 | [인쇄] | 차이 크기 미보고
- [b] pan2026_thesis_rate_capable_energy_dense_cathode_composites | 되돌아옴 측정 없음.  압축률 대 기공 비선형 (40 % 두께 감소에 CT 기공 38 → 29 %) 을 저자는 표면 돌기로 설명 · 카드는 스프링백 (`diener2022_roll_gap_springback_calendering`) 을 같은 방향의 다른 후보로 적음 (압축률 측정 방식 [미확인]) | §3-1-3 (줄 104) · §12 보강 2 (줄 475) · p.43–44 | [인쇄] (저자 해석) · 카드 추정 | 액체 LIB 습식 롤 프레스 · 압력 미기재
- [b] song2025_electrochemo_mechanical_microelectrode_ees | 이 논문 자신의 탈압 측정 없음.  카드가 다른 카드 (`hong2026_cbd_viscoelasticity_springback`, #285) 의 시간 의존 되돌아옴 "RT 3주 +4µm vs HT +1µm" 을 가리키고 이 논문의 Perzyna 점소성을 그 정식 후보로 연결 | §6.3 (줄 427 · 431–438) | 카드 해석 | 액체 LIB CBD · 수치는 다른 카드 몫


### [batch_36] b — 탈압 때 되돌아오는 양 · 잰 방법

이 배치에 없음.  (zhang2026 §8-2 줄 106 이 우리 쪽 "제하 팔 부재 (F-SB1)" 를 공백으로 적었을 뿐 측정 · 계산 값은 없다.)


### [batch_37] b — 탈압 때 되돌아오는 양 · 잰 방법

되돌아온 두께 · 기공을 잰 카드 = 0.  참고 둘 (둘 다 cao2026 · 탈압 측정 아님):

- [b] cao2026 | 셀 속 USF 띠 figure-read ≈12 µm (Fig. 5a · 점선 사이 ≈79 px ↔ 축척 20 µm = 128 px) — 자립막 명목 18 µm 보다 얇음.  카드: "100 °C·75 MPa 적층 압밀? 점선 위치 오차? — 저자 언급 없음" → 되돌아옴이 아니라 추가 압밀 쪽 관찰 (원인 미정) | §5.12 줄 242 · §10-7 줄 463 | figure-read | 그림 한 장 · 카드 §14 가 "18 µm 를 셀 속 두께로" 쓰는 것을 인용 금지로 둠 (줄 508)
- [b] cao2026 | LCO 셀 압력 모니터 (첫 10 사이클): PTFE 막 셀은 피크 압력 ≈0.45 → ≈0.27 MPa (Δ 0.18 MPa) 로 내려앉고, USF 셀은 사이클마다 0 → ≈0.4 MPa 를 오르내리되 피크 일정 — 사이클 부피 변화이지 탈압 아님 | §3g 줄 151 · §5.11 줄 237 | 본문 (0.18 MPa) · figure-read (Fig. 4e,f) | 본문 "negligible pressure variation" 은 피크 표류에만 맞음 (카드 §10-9 줄 465)


### [batch_38] b — 탈압 때 되돌아오는 양 · 잰 방법

되돌아온 두께 · 기공을 잰 카드 = 0.  참고 셋:

- [b] tron2023 | 성형 300 MPa · 5 min (두 번) → 측정 10 MPa (압력 셀) 로 성형압과 운전압이 다른 규약 — 되돌아온 두께 · 기공은 재지 않음 | §3c 줄 82 · Fig. 1 | stated | 측정 없음
- [b] yuan2026_layered_composite_electrolyte_stress_homogenization_li_metal | (고분자 전해질 · 탈압 아님) 파우치를 두 판 사이 정간격 (constant-gap) 으로 고정하고 압력 변화를 잼 (25 kg ≈ 100 kPa · 30 °C · 0.1 mA/cm²): 5 → 25 사이클 평균 증가 +0.075 (무첨가) vs +0.020 MPa (층상) · 카드 용어집: "힘 증가 = 두께 증가 × 적층 강성 · '정압' 모드는 반대로 압력을 고정하고 두께를 잰다" | §3d 줄 119–125 · §12 줄 385 | (원자료 재계산) | Li 석출 팽창 · 압력막 화소 10 mm
- [b] liu2024 | 성형 1000 MPa 2 min 뒤 운전 스택 압력 [미확인] · 두께 · 기공 측정 없음 | §3-1 줄 62 | [인쇄] · [미확인] | —


### [batch_39] b. 압력을 뺄 때 되돌아오는 양 · 잰 방법

이 배치에 없음.


### [batch_40] b — 탈압 때 되돌아오는 양 · 잰 방법

압력 하중은 없음.  대응하는 것 (자유 변형률을 넣었다 뺌) 만:
- [b] gritton2017_mpm_chemomechanical_coupling_silicon_anode | 리튬화 → 탈리튬화 한 바퀴 뒤 끝 상태 (처음 대비): 높이 ×1.35 · 최대 폭 ×0.98 · 회전체 부피 ≈ ×1.1; 완전 리튬화 때는 폭 ×1.45 · 가운데 높이 ×3.40 · 부피 ≈ ×5.0 — "부피는 거의 돌아오고 모양은 안 돌아온다" | 카드 §3-5 · §0-2 (iv) · 논문 Fig. 10 · §4.7 p.19 | [판독] (내장 래스터의 윤곽 화소 계수 · 회전체 적분은 [카드 산술]) | 논문에 인쇄된 잔류 변형 값은 없음 (*"shows the amount of plastic deformation"* 한 문장) · 압력이 아니라 농도 유도 팽창 · 규소 · 계면은 붙은 채 (열림 없음) · 되돌아오는 탄성량 · 응력 값 없음


### [layer3] b. 압력을 뺄 때 되돌아오는 양 · 잰 방법

- [b] miss2026_insitu_conductivity_porosity_pressure_compaction | 300 MPa 다이 안 두께 회복 (Table S2 재계산): µc-Li₅.₅PS₄.₅Cl₁.₅ 1.6 % · pc-NMC622 7.9 % (전 범위 SE −0.3…+2.8 % · CAM +0.7…+8.6 %) · 다이 밖 (400 MPa 뒤) SE +6.5 % · CAM +1.7 % · 잰 방법 = 스프링 일정압 셀 · 경화강 피스톤 + PEEK 하우징 · 마이크로미터 (1 회 5 µm) · 피스톤 압축만 교정 (Eq. 1: d_sample = d − d_pistons(p)) · 매 단계 110 kPa 로 놓았다 다시 누름 | §A L106–107 | "재계산" · 다이 밖 값 = "판독" | 단일상 펠릿 (복합체 없음) · Li₅.₅PS₄.₅Cl₁.₅ ≠ Li₆PS₅Cl · pc-NMC622 만 (SC 자료 없음) · 단계 하중 ≠ 단조 · CAM 다이 밖이 다이 안 놓은 뒤보다 5 % 얇음 (저자 무언급 · L110 은 "모순" 이라 적음)
- [b] miss2026_insitu_conductivity_porosity_pressure_compaction | 단일상 회복을 복합체에 씌운 환산 Δε = (1 − ε)·회복: SE 같은 1.6 % → −1.1…−1.3 %p · pc-CAM 같은 7.9 % → −5.6…−6.2 %p ⇒ 스프링백 = 실험 (다이 안 · 하중 제거 후) − DEM (300 MPa 판 정지) 공극 차 +5.7…+9.3 %p 의 일부 (≈ 1–6 %p) · 10:0 · 0:10 은 위 끝에서도 ≥ 3.5 %p 남고 7:3 만 다 설명될 수 있음 · 스프링백만으로 메우려면 두께 회복 7.4–13.0 % 필요 | §A L108–110 | derived(ours) · ps45 수치 = "1저자 숫자" | 복합체가 두 상 사이라는 것도 가정 · 진밀도 손잡이와 섞여 비식별
- [b] ngandjong2021_dem_calendering_digital_twin | 압입 언로딩 (Fig 2A) 잔류깊이 exp ≈ 0.84 · sim ≈ 0.75 d_max ⇒ 탄성회복 16 % (exp) vs 25 % (sim) — 모델이 ~1.5 배 더 튕김 | §A L224–227 | 표지 없음 (≈ 값) | 압입 회복이지 압연 springback 아님 · LIB 전극 (NMC111 96 wt% + CBD) · 비교 문서: galvezaranda2024 카드가 "springback 숫자 0 건" 이라 적은 축의 첫 정량 표적
- [b] xu2023_realistic_am_shape_cgmd_calendering | 변위 제어 + 해제 · 완화 프로토콜 (우리 MPM `--protocol hold` / `release` 와 같은 종류) · 시뮬 점을 항등식 ε = 1 − (1 − ε₀)/(1 − CD) 에 넣은 잔차로 두께 회복을 함의값으로 냄 (CD 가 클수록 단조 증가 · 두 조성이 같은 곡선) | §A L142–150 | derived(ours) · "값 인용 금지" (숫자 안 옮김) | 논문 값 아님 · 가정 3 개 (바닥 고정 · 고체부피 보존 · ε 는 해제 후) · 액체 LIB CGMD · 압력 0 건
- [b] ngandjong2021_dem_calendering_digital_twin | 그들 ε 는 플레이트를 되올린 뒤 (springback 후 · out-of-die) 값이라 in-die / 하중 중 값과 "같은 양이 아니다" | §A L197 · L216 | 표지 없음 | LIB
- [b] lee2025_corolling_dryprocess_lpscl_ptfe | 셀 압력 프로토콜 두 가지: fixed gap (ΔP ≈ −1.5 / cyc) vs constant pressure (스프링 · ΔP ≈ −0.1) (Supp Fig 25) — 되돌아옴 값은 아님 (사이클 중 압력 변화) | §A L409–412 | 표지 없음 | 작동압 (2–75 MPa) 축 · 제조 압밀의 되돌아옴 아님
- [b] zunker2025_dem_large_deformation_compaction (+ Part I · II) | MCC 타정 DEM: 최대 축응력 240 MPa · 최대 반경응력 147 MPa (측압비 0.61) · 잔류 반경응력 15 MPa · 배출 1.2 (exp) / 1.5 (sim) MPa · 탄성회복 축변형 0.08 (압축체 높이 대비 13.1 %) · 순서 = die fill (20,000 입자 + 중력침전) → 압축 → 해제 → 배출 | §A L666–670 | 측압비 · 13.1 % = DERIVED · 나머지 표지 없음 | MCC (연성 유기물 · 파쇄 없음) ≠ LPSCl · porosity 는 비교 불가 (압력만 대응)
- [b] zhang2026_xct_dem_cathode_calendering_peel_calibration | 같은 RVE 를 30 / 60 / 200 MPa 로 누르고 제하: 하중 중 공극률 0.333 / ≈ 0.280 / ≈ 0.152 → 제하 후 0.411 (실험 0.412) / ≈ 0.370 / ≈ 0.319 — 한 모델 안에서 0.08–0.17 벌어짐 · 탄성 회복 ER = (h_제하 − h_하중)/h₀ 의 값은 §F L2907–2908 에서 "값 인용 금지" (숫자 안 옮김) · 제하 회복의 ≈ 절반이 5 MPa 아래에서 일어남 · 측압계수 K 0.40 → 0.68 · RVE σ_zz ≈ 플래튼 응력 (30.4 @ 30 · 198.5 @ 200 MPa) | §A L877–897 | 0.333 · 0.411 · σ_zz = stated · ≈ 값 = figure-read (카드 Fig 4b · 4c) · K = derived | NMC111 + CBD 액체 LIB (SE 없음) · Hertz–Mindlin + linear parallel bond (코드 미명시) · springback 크기는 "취성 bond + 탄성 Hertz 의 산물" 이라 못 씀 · 검증은 제하 후 공극률 4 점뿐이고 보정 표적과 분리 안 됨
- [b] zhang2026_xct_dem_cathode_calendering_peel_calibration + sangros2019_dem_calendering_lib_electrode | (묶음) Zhang 의 탄성 회복 ER 이 Sangrós 2019 의 값과 같은 밴드 = "강체구 + bond DEM 부류의 공통 거동" | §A L888–889 (같은 값이 §F L2907–2908 에서는 "값 인용 금지" — 숫자 안 옮김) | derived | 둘 다 액체 LIB
- [b] heck2026_densification_sulfide_se_binder_scalable | springback 6.7–10.4 % (LPS + HNBR) — 비교 문서: 우리 언로딩 ρ_c 와 같은 꼴의 정의이지 앵커가 아님 | §A L925 | 표지 없음 | LPS + 바인더 (LPSCl 아님) · 압력 · 측정법 이 줄에 없음
- [b] diener2022_roll_gap_springback_calendering | 고하중 springback 은 간극 안 밀도가 진밀도를 넘게 만든다 → 회복값 상한 ≈ 20–24 % (진밀도로 먼저 점검) | §A L924 | 표지 없음 | 롤 압연 (재료는 이 줄에 없음)
- [b] benhadjali2026_wip_vs_cup_pressing_assb_cathode_dem | DEM (Franco CGMD) 은 변위 제어 20 ↔ 30 % + 4 ms 유지 · 제하로 최종 두께를 맞춤 (밀도 일치 = 두께 일치 · 같은 정보) — 되돌아옴을 따로 재지 않음 | §A L934 | 표지 없음 | 습식 NMC622 : LPSCl : CBD
- [b] gonzalez2012_nonlocal_contact_confined_granular + vanlew2015_modifying_youngs_modulus_distribution | 되돌아옴 없음 — 둘 다 탄성 · 하중 쪽만 (Gonzalez: 정적 해석 · Van Lew: 6 MPa 단일점) | §A L716–719 · L601–602 · L639–640 | 표지 없음 | 
- [b] nguyen2017_mpm_bpm_deformable_particle_compaction + pycompact2025_dem_mpfem_workflow | (묶음 · "카드 간 종합 · 우리 추론") BPM 소성 입자의 제하 회복 ≈ 0.008–0.009 (입자 수준) + PyCompact 의 P → 0 기공 반등 · 접촉 틈 → 집합체 되돌아옴의 주역이 접촉 열림이면 단일 속도장 MPM 은 제하를 원리적으로 과소평가 | §C L2710–2711 | "우리 추론" · digitized (2D) | Nguyen = 2D · 학회 4 쪽 (Fig 2 ↔ Fig 3 범례 모순) · PyCompact = Fe–Si–Al–P 금속 @ 1400–2000 MPa
- [b] bardenhagen2001_mpm_improved_contact_granular_stress_waves | MPM 접촉의 분리 판정을 수직 견인력 t_n = n·σ·n 으로 (압축이면 마찰 접촉 유지 · 아니면 자유 분리) — 운동학 판정은 되튈 때 "경계 즉시 제거" 꼴이라 마찰 없는 충돌에서 에너지가 약간 늘었음 · 원문 경고: 이종 재료는 같은 늘림에 다른 견인력을 내 접촉 노드에서 견인력 평형이 안 맞고, 소성 같은 영구 변형이면 분리 시점이 어긋날 수 있음 | §C L2722–2725 | 카드 서술 (영어 원문 없음) | 압밀 없음 (경사면 위 고무 같은 구 1 개 = 3D 회귀 시험 · §F L3977 + Plexiglas 원판 ≤ 5 개 응력파) · 접촉 노드당 물체 ≤ 2 로 한정한 분석
- [b] nam2026_primer_layer_dry_electrode_collector | 나노압입 탄성회복비 61.5 % (S100) → 93.5 % (C100) = 비가역 분율 38.5 → 6.5 % (~6 배) · E/H = 12.5 → 2.2 (5.7 배 · 같은 방향) | §C L2384–2387 | 표지 없음 | 카본 / CMC primer 층 (LPSCl 아님 — "SE 값 아님") · 압입 회복 (압밀 되돌아옴 아님)
- [b] alabdali2023_cgmd_wet_manufacturing_ssb_cathode | springback 없음 (접촉 = LJ + 순수 Hertz + Coulomb · 잔류겹침 없음) | §C L2432–2433 | 표지 없음 | 습식 SSB CGMD
- [b] demirtas2021_mpfem_hollow_sphere_die_compaction | 점착이 없어 배출 (ejection) 미계산 — 되돌아옴 값 없음 | §C L2549 | 표지 없음 | HPMCAS 중공 입자
- [b] endo2001_vgcf_basic_properties_battery_applications | 섬유 매트 스프링백 서열: 흑연화 s-VGCF > 탄화 ≫ 기존 탄소섬유 (Fig. 9b) — 정의식이 본문과 캡션에서 서로 역수라 서열만 | §C L2647 | 표지 없음 | 탄소 섬유 매트 (전극 아님) · 값 금지
- [b] miss2026_insitu_conductivity_porosity_pressure_compaction | "이 축의 첫 ASSB 재료 실측" — 다이 안 회복 (Table S2 재계산): SE 1.6 % (300 MPa) · 2.8 % (400) · pc-NMC622 7.9 % (300) · 8.6 % (350) · 다이 밖 (400 MPa 뒤) SE 6.5 % · CAM 1.7 % | §F L2911 | 재계산 · 다이 밖 = 판독 | 단일상 · Li₅.₅PS₄.₅Cl₁.₅ · 단계 하중
- [b] zhang2026_xct_dem_cathode_calendering_peel_calibration + sangros2019_dem_calendering_lib_electrode | 같은 DEM 안에서 가압–제하를 끝까지 풀어 얻은 탄성 회복 ER = (h_제하 − h_하중)/h₀ 가 Sangrós 2019 와 같은 밴드 · 회복의 ≈ 절반이 5 MPa 아래 (figure-read) → 제하 팔에 적층압 유지 팔 (P_stack ∈ {0, 5, 10, 50} MPa) 을 같이 | §F L2906–2910 (같은 값이 §A L888–889 에도) | derived(ours) · "값 인용 금지" (숫자 안 옮김) | 액체 LIB · 취성 bond · 탄성 Hertz
- [b] galvezaranda2024_time_dependent_dl_calendering_microstructure + hong2026_cbd_viscoelasticity_springback | springback 이 압연도에 단조 증가: CD 25 / 35 / 45 % → 공극 되돌아옴 4.8 / 7.6 / 10.1 %p · 압축두께 대비 회복 6.3 → 11.5 → 17.7 % (Fig 5b / 6a / 6c) | §F L3010–3013 | derived(ours) · 디지타이즈 · "값 전이 금지 · 부호 · 곡률만" | 액체 LIB · CBD 점탄성 지배 · DL 논문 자체의 springback 출력은 "숫자 0 건" (L3004)
- [b] xu2023_realistic_am_shape_cgmd_calendering + ngandjong2021_dem_calendering_digital_twin | (묶음 · F-SB1) galvezaranda2024 는 "숫자 0 건" · Ngandjong 은 압입 언로딩 잔류깊이뿐 (탄성회복 exp ≈ 16 % · sim ≈ 25 %) · Xu 는 직접 값 없이 CD–공극 점의 함의값만 | §F L2900–2905 | derived(ours) · Xu 함의값 = "값 인용 금지" (숫자 안 옮김) | 전부 액체 LIB
- [b] pycompact2025_dem_mpfem_workflow | 제하 후 규약: 하중–제하를 끝까지 풀고 상대밀도를 제하 중 5 MPa 도달 시점에 잼 · porosity–pressure 하중 + 제하 루프 한 장 (Fig 4b) · 탄성 회복변형 P/E 어림: 그들 2000 MPa / 170 GPa = 1.2 % · 우리 MPM (300 MPa · K 25.5 GPa) 체적 1.2 % · 우리 DEM (300 MPa · E_eff 1.35 · ν 0.3 ⇒ K 1.125 GPa) 체적 26.7 % → "DEM 의 연화는 제하를 풀면 무너진다 (지금은 제하를 안 풀어 노출되지 않은 잠재 한계)" | §F L3718–3728 | derived(ours) | Fe–Si–Al–P 금속 · P/E 는 어림 (탄성 체적 회복만)
- [b] zunker2025_dem_large_deformation_compaction | 제하 곡선이 접촉 법칙에서 저절로 나옴 (비선형 + 소성누적에 따른 강성증가까지 FEM 일치) · 2 차 접촉은 제하 후에도 힘이 남음 · 잔류 반경응력 (실험 15 MPa) 재현 — 측방 주기경계 RVE (벽 없음) 로는 못 잼 | §F L3745–3750 | 표지 없음 | MCC · 프로토콜 하나 (0 → 0.4 → 0)
- [b] paulick2015_elastic_particle_properties_dem_review | 구속 벌크계수 (제하–재하) = E 에 민감한 검증 관측량 — Coetzee & Els [21] 규약 "once a stable hysteresis loop was reached" = 제하–재하 강성 (hooke/hysteresis 의 제하강성 k₂ 가 지배) · 선형 모델에서 "the coefficient of restitution in normal direction corresponds to the square root of loading to unloading stiffness" (§4 p.75) | §F L3445–3452 · L3472–3476 | 원문 인용 | 실험 앵커 부재 (LPSCl 분말 제하–재하 계수 없음)
- [b] qin2026_bilayer_cathode_cgmd_dem_graded_thick_electrode | 입자마다 층 출신 라벨을 들고 층별 공극률 · 혼합 폭 · 스프링백을 잼 — 비교 문서: 우리 MPM `--protocol` 은 servo · hold 둘뿐 · release 팔 없음 | §F L3919–3922 | 표지 없음 | 액체 LIB · 프리프린트 · 값은 §A L172 에서 전이 금지
- [b] sankar2026_fiber_scale_dem_carbon_felt_manufacturing | 캘린더링 = 평판 변위제어 + 되튐 (결합구 사슬 섬유 DEM) | §F L3903 | 표지 없음 | 탄소펠트 · 프리프린트 · 압력 출력 0 · 값 인용 금지



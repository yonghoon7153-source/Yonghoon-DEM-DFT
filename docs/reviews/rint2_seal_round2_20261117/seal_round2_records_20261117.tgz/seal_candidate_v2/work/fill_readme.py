import re, sys
V = '/tmp/claude-0/-home-user-Yonghoon-DEM-DFT/81c0ad95-542f-503b-9cf7-2f6a678a4b5b/scratchpad/rint/seal_candidate_v2'
e1 = open(V + '/work/evG/e1_test_rint_r_chain_full_G.txt', encoding='utf-8').read()
npass = len(re.findall(r'^  PASS', e1, re.M)); nfail = len(re.findall(r'^  FAIL', e1, re.M))
m = re.search(r'^test_rint_r_chain: \d+/\d+ PASS \(([\d.]+) s\)', e1, re.M); secs = float(m.group(1))
rc = re.search(r'^rc=(\d+)', e1, re.M).group(1)
summ = re.search(r'^test_rint_r_chain: .*$', e1, re.M).group(0)
print('e1', npass, nfail, secs, rc, summ)
assert nfail == 0 and rc == '0', 'e1 실패 — 손으로 본다'
t = open(V + '/README.md', encoding='utf-8').read()
vals = {'@@E1G@@': f'{npass}/{npass + nfail} PASS · {secs:.1f} s',
        '@@E9G2@@': sys.argv[1], '@@E10G2@@': sys.argv[2], '@@SEALN@@': sys.argv[3]}
for k, v in vals.items():
    assert t.count(k) == 1, (k, t.count(k)); t = t.replace(k, v)
open(V + '/README.md', 'w', encoding='utf-8').write(t)
print('filled', vals)

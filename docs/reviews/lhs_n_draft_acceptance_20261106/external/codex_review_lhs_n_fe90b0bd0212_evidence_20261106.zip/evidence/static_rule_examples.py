"""Exact synthetic arithmetic illustrating the draft, NOT a production classifier.
No LHS values, research source execution, or collection is involved.
"""
from fractions import Fraction
import json

cases=[
    ('empty', [], 'NOT_ESTABLISHED or NOT_IDENTIFIABLE according to the documented reason; never directional'),
    ('zero_N_only', [(0,'-9')], 'No usable N contrast; NOT_IDENTIFIABLE, retained separately'),
    ('negative_plus_zero_N', [(10,'-2'),(0,'9')], 'Negative direction on nonzero-N pair only; zero-N pair retained separately'),
    ('positive', [(10,'2')], 'DIRECTION_OPPOSITE if all other eligibility conditions hold'),
    ('mixed', [(10,'-2'),(20,'1')], 'DIRECTION_MIXED_OR_TIED'),
    ('pressure_tie', [(10,'0')], 'DIRECTION_MIXED_OR_TIED; no equivalence claim'),
    ('tiny_negative', [(10,'-0.000001')], 'Negative arithmetic direction only; no significance or practical-strength claim'),
]
rows=[]
for name,pairs,reading in cases:
    usable=[(dn,Fraction(dp)) for dn,dp in pairs if dn!=0]
    products=[dn*dp for dn,dp in usable]
    rows.append({'name':name,'delta_N_particles_delta_P_MPa':pairs,
      'nonzero_N_products_particle_MPa':[str(v) for v in products],
      'naive_all_negative':all(v<0 for v in products),
      'has_nonzero_N_pair':bool(usable),'document_reading':reading})
assert rows[0]['naive_all_negative'] and not rows[0]['has_nonzero_N_pair']
assert rows[1]['naive_all_negative'] and not rows[1]['has_nonzero_N_pair']
assert rows[2]['nonzero_N_products_particle_MPa']==['-20']
assert rows[5]['nonzero_N_products_particle_MPa']==['0']
print(json.dumps({'scope':'reviewer synthetic exact arithmetic; no classifier exists in the draft',
                 'examples':rows,'not_proven':['statistical significance','independent N causality','pressure equivalence','production implementation']},indent=2))

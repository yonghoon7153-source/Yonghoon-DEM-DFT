#!/bin/bash
# e12 = stoic 가리킴 다시 (봉인 꼴 사본 안 git · 읽기만 · 객체 = 본 리포 공유 · 원격 추적 ref = 본 리포 지금 판으로 다시 받은 뒤)
C=$1
echo "# stoic 가리킴 확인 (v2.1 · $(date -u +%Y-%m-%dT%H:%MZ) 측정 · 봉인 꼴 사본 HEAD $(git -C $C rev-parse HEAD) · 원격 추적 ref $(git -C $C for-each-ref refs/remotes | wc -l) 개 = 본 리포와 같음)"
for spec in b3481336c:docs/reviews/rint2_time_reestimate_20261111/README.md b80f10d08:docs/reviews/rint2_time_reestimate_20261111/README.md c0c3b1ff5:docs/reviews/rint2_time_reestimate_20261111/README.md b3481336c:docs/reviews/rint2_time_reestimate_20261111/v3 b3481336c:docs/reviews/rint2_time_reestimate_20261111/v3/numbers_sources.tsv b3481336c:docs/reviews/rint2_time_reestimate_20261111/v3/work/time_budget_v3.py 2da71fe5a:docs/reviews/claims.json 2da71fe5a:docs/handoff_return_to_stoic_knuth_20261117.md; do
  if git -C $C cat-file -e "$spec" 2>/dev/null; then echo "있음  $spec  → $(git -C $C cat-file -t "$spec") $(git -C $C rev-parse "$spec")"; else echo "없음  $spec"; fi; done
echo "## 커밋이 원격 추적 ref 에 있나 (git branch -r --contains)"
for c in b3481336c b80f10d08 c0c3b1ff5 5a04acd15 5645b86c8 2da71fe5a 64e4d213e; do n=$(git -C $C branch -r --contains $c 2>/dev/null | wc -l); echo "$c → 원격 가지 $n 개 ($(git -C $C branch -r --contains $c 2>/dev/null | head -2 | tr -d ' ' | tr '\n' ' '))"; done
echo "## 원격 stoic 끝 = $(git -C $C rev-parse refs/remotes/origin/claude/stoic-knuth-NObVQ) · 그 판의 3 판 README blob = $(git -C $C rev-parse refs/remotes/origin/claude/stoic-knuth-NObVQ:docs/reviews/rint2_time_reestimate_20261111/README.md)"
echo "## 봉인 가지의 같은 경로 = 2 판 (3 판 절 없음)"
echo "64e4d213e README 의 '## 3 판' 줄 수: $(git -C $C show 64e4d213e:docs/reviews/rint2_time_reestimate_20261111/README.md | grep -c '^## 3 판')"
echo "b3481336c README 의 '## 3 판' 줄 수: $(git -C $C show b3481336c:docs/reviews/rint2_time_reestimate_20261111/README.md | grep -c '^## 3 판')"
echo "HEAD README 의 '## 3 판' 줄 수: $(git -C $C show HEAD:docs/reviews/rint2_time_reestimate_20261111/README.md | grep -c '^## 3 판')"

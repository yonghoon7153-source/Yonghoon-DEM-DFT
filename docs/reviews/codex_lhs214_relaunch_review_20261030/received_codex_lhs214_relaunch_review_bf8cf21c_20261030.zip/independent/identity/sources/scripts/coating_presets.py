#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""이종기술 코팅 프리셋 (webapp v3, #33) — CAM 표면 이종층을 하나의 셀렉터로 통합.

CLAUDE.md frame[5]: 코팅 = **화학 CEI 축**(Stage-E 기계 coverage와 별개).  litdb 적용표(B-2위):
코팅이 현재 3경로(화학CEI STEP5 --chem-x · 계면전도 Han2025 t/σ_b · 구조seeding SDCP/SWCNT)로
흩어져 있어 → 통합 프리셋 {cei_suppress, r_ct_factor, σ_ion_mod, σ_e_mod, seed_morph}.

★정직 규약: **크기(magnitude)는 앵커, shape(√N)는 ASSUMED** (fit_rint_curve.py가 ≥4 N점 실측으로
게이트).  앵커 없는 항목은 값 미지정(스윕 전용).  cei_suppress = bare 대비 화학성장 증분 억제배수
(LNO 13–20× = Kim2025 R_ct 20×·CEI 13–20×; Payandeh 93%@200cyc; Kang LZO 6–8nm).

`coated_chem_x(coating, bare_chem_x)`: bare 화학성장 × → 코팅 적용 후 억제된 화학성장 × 반환
  = 1 + (bare_chem_x − 1) / cei_suppress   (증분만 억제, 앵커 끝점 규약과 정합).
"""
from __future__ import annotations

# 각 프리셋: cei_suppress(화학성장 증분 억제배수, ≥1)·r_ct_factor(계면 R_ct 배수, <1=개선)·
#            sigma_ion_mod·sigma_e_mod(계면/벌크 σ 배수)·seed_morph·anchor(출처)·shape(항상 ASSUMED).
# ★값 = magnitude 앵커.  None = 앵커 없음(스윕 전용, 날조 금지).
#
# ⚠⚠⚠ **NOT WIRED — 이 표를 보고 "코팅이 배선돼 있다" 고 믿지 말 것** (2026-08-19 코드리뷰).
#   ★ 정확히 말하면 필드가 아니라 **함수** 단위로 갈린다 (전수 검색, 이 파일 제외):
#     ✅ 살아 있는 경로 = `get_preset` + `coated_chem_x` (각 외부 호출 2회)
#          → `b1_chem_fade.py:329-331` · `webapp/app.py:3912-3915`.  **소비되는 필드는
#            `cei_suppress` 하나뿐**이다.
#     ⛔ `coated_rint0`   — 외부 호출 **0 회**.  `r_ct_factor` 를 실제로 쓰는 곳은 이 함수
#          하나인데 그 함수를 아무도 안 부른다 ⇒ **죽은 함수를 통해 죽은 필드**다.
#     ⛔ `coating_effect` — 외부 호출 0 회.  `sigma_ion_mod` · `sigma_e_mod` · `seed_morph` 는
#          이 함수가 dict 로 **노출만** 하고, 그 dict 를 받는 곳이 없다.
#     ⛔ `preset_summary` — 외부 호출 0 회.
#   ⚠ `seed_morph` 는 값 `'shell'` 에 **대응하는 시더도 없다** (`additives.py` =
#     seed_coat / seed_sheath / seed_sdcp / seed_fibres / seed_blobs / seed_carbon_black;
#     `seed_coat(shell_um=…)` 가 의미상 가장 가깝지만 그 매핑을 하는 코드가 없다).
#   ⚠ grep 주의: `sigma_e_mod` 로 검색하면 5건이 잡히는데 전부 `se_material.sigma_e_modelled`
#     = **다른 식별자**의 부분일치다.  실사용 아님.
#   ⇒ 네 필드는 **설계 자리표시자(placeholder)** 다.  배선하려면 소비처를 먼저 만들고,
#     그때 이 배너를 갱신한다 (아래 `_selftest` 의 NOT-WIRED 검사가 강제한다).
#   ⚠ 특히 `r_ct_factor` 는 **STEP3 옴 경로가 아니라 STEP4 패러데이 경로**(step4_dyn.Kinetics
#     i0 / asr_film)에 들어가야 한다 — 두 경로를 섞으면 같은 물리를 두 번 센다.
#     (LPSCl 코팅 = 이온전도체 → 복셀 옴 / LNO·LZO 산화물 = 표면화학 → R_ct.  분기를 못 박을 것.)
COATING_PRESETS = {
    'none': {
        'label': 'bare NCM (무코팅)', 'cei_suppress': 1.0, 'r_ct_factor': 1.0,
        'sigma_ion_mod': 1.0, 'sigma_e_mod': 1.0, 'seed_morph': None,
        'anchor': 'baseline — 화학 CEI 전량(억제 없음)', 'shape': 'ASSUMED (√N)'},
    'LNO': {                                              # LiNbO3 — 가장 흔한 sulfide-ASSB CAM 코팅
        'label': 'LiNbO₃ (LNO)', 'cei_suppress': 15.0, 'r_ct_factor': 1.0 / 20.0,
        'sigma_ion_mod': 1.0, 'sigma_e_mod': 1.0, 'seed_morph': 'shell',
        'anchor': 'Kim2025: R_ct 20× 억제·CEI 13–20× / Payandeh 93%@200cyc (크기 앵커)',
        'shape': 'ASSUMED (√N; ≥4 N점 실측 필요)'},
    'LZO': {                                              # Li2ZrO3
        'label': 'Li₂ZrO₃ (LZO) 6–8nm', 'cei_suppress': 8.0, 'r_ct_factor': 1.0 / 6.0,
        'sigma_ion_mod': 1.0, 'sigma_e_mod': 1.0, 'seed_morph': 'shell',
        'anchor': 'Kang&Shin LZO 6–8nm CEI 억제 (크기 앵커, 배수는 LNO 하한 보수 추정)',
        'shape': 'ASSUMED (√N)'},
    'Li3PO4': {
        'label': 'Li₃PO₄', 'cei_suppress': None, 'r_ct_factor': None,
        'sigma_ion_mod': 1.0, 'sigma_e_mod': 1.0, 'seed_morph': 'shell',
        'anchor': '⛔ 정량 앵커 미확보 → 스윕 전용(날조 금지)', 'shape': 'ASSUMED'},
    'carbon': {                                           # 전도성 코팅 (탄소)
        'label': 'carbon-coat (전도성)', 'cei_suppress': 1.0, 'r_ct_factor': None,
        'sigma_ion_mod': 1.0, 'sigma_e_mod': None, 'seed_morph': 'shell',
        'anchor': 'Reisacher p_c≈4wt%(정확 LPSCl+C65)·So2022 core-shell — σ_e↑(값=A4 GPU), '
                  'CEI 억제 아님(오히려 탄소-촉매 SE분해=#30 별도 축)',
        'shape': 'N/A (화학열화는 #30 carbon-촉매로)'},
    'SDCP': {                                             # 자기도핑 전도성 바인더 (우리 A4′)
        'label': 'SDCP (S-PEDOT 자기도핑)', 'cei_suppress': None, 'r_ct_factor': None,
        'sigma_ion_mod': 0.80, 'sigma_e_mod': 5.1, 'seed_morph': 'particle',   # 매뉴스크립트 FigS3 = 분산 singles('coat'는 레거시)
        'anchor': 'A4′ 완비: σ_e×5.1·σ_ion×0.80·E 9.0GPa (σ 비는 manuscript pellet-COMPOSITE — phase σ 아님; E 는 ADD_E_SET 2026-08-18, 옛 23.6); E_bind DFT 잔여',
        'shape': 'N/A (전도 이종상, 화학 CEI 아님)'},
    'SWCNT': {                                            # 연속 SWCNT sheath (우리 A14)
        'label': 'SWCNT sheath', 'cei_suppress': None, 'r_ct_factor': None,
        'sigma_ion_mod': 1.0, 'sigma_e_mod': None, 'seed_morph': 'sheath',
        'anchor': 'A14 완비: seed_sheath geodesic vein, sid8 (Koo2026); σ_e=--sigma-swcnt',
        'shape': 'N/A (전도 이종상)'},
}


def get_preset(coating: str) -> dict:
    """코팅 이름 → 프리셋 dict (대소문자 무관).  미지원 → 'none'."""
    if not coating:
        return COATING_PRESETS['none']
    key = str(coating).strip()
    for k in COATING_PRESETS:
        if k.lower() == key.lower():
            return COATING_PRESETS[k]
    return COATING_PRESETS['none']


def coated_chem_x(coating: str, bare_chem_x: float) -> float:
    """bare 화학성장 ×(>1) → 코팅 CEI 억제 후 화학성장 ×.  증분만 억제(끝점 규약 정합):
    chem_x_coated = 1 + (bare_chem_x − 1) / cei_suppress.  cei_suppress None(앵커없음)/≤1 → bare 유지.
    ★크기만 앵커 — shape(√N)는 b1_chem_fade가 ASSUMED-FORM 라벨로 처리."""
    p = get_preset(coating)
    s = p.get('cei_suppress')
    b = float(bare_chem_x)
    if s is None or s <= 1.0:
        return b
    return 1.0 + (b - 1.0) / float(s)


def coated_rint0(coating: str, bare_rint0: float, rct_frac=None) -> float:
    """코팅의 계면 R_ct 억제(r_ct_factor, 예 LNO 1/20)를 pristine R_int0에 적용.
    ★정직: R_ct는 R_int의 **한 성분**이라, 그 성분 분율(rct_frac)을 caller가 줄 때만 적용 —
    분율은 별도 앵커(EIS-TLM 분해), 미상이면 None=미적용(날조 금지, bare 유지).
    R_int0_coated = R_int0·[(1−f) + f·r_ct_factor]  (f=rct_frac, R_ct 성분만 억제)."""
    p = get_preset(coating)
    rf = p.get('r_ct_factor')
    if rf is None or rct_frac is None:
        return float(bare_rint0)
    f = min(1.0, max(0.0, float(rct_frac)))
    return float(bare_rint0) * ((1.0 - f) + f * float(rf))


def coating_effect(coating: str, bare_chem_x=None) -> dict:
    """코팅의 **전체** 문서화 효과를 한 dict로 (webapp/CLI 표기 단일소스).
    chem_x는 앵커(bare 주면 계산), r_ct/σ_mod는 앵커된 '적용 계수'(적용엔 성분분율/STEP3 필요)."""
    p = get_preset(coating)
    return {'coating': coating, 'label': p['label'], 'anchor': p['anchor'], 'shape': p['shape'],
            'cei_suppress': p.get('cei_suppress'),
            'chem_x_coated': (coated_chem_x(coating, bare_chem_x) if bare_chem_x is not None else None),
            'r_ct_factor': p.get('r_ct_factor'), 'sigma_ion_mod': p.get('sigma_ion_mod'),
            'sigma_e_mod': p.get('sigma_e_mod'), 'seed_morph': p.get('seed_morph'),
            'note': '화학 CEI는 chem_x로 적용됨(앵커).  r_ct/σ_mod는 앵커된 계수이나 적용은 '
                    'R_ct 성분분율(coated_rint0)·STEP3(σ) 필요 — 미상 시 미적용(날조 금지).'}


def preset_summary() -> str:
    """프리셋 표 텍스트 (webapp/CLI 표기용)."""
    rows = ['coating        cei_suppress  r_ct×   σ_ion×  σ_e×   morph   anchor']
    for k, p in COATING_PRESETS.items():
        rows.append(f"{k:14s} {str(p['cei_suppress']):>11s}  {str(p['r_ct_factor'])[:6]:>6s}  "
                    f"{str(p['sigma_ion_mod']):>5s}  {str(p['sigma_e_mod']):>5s}  "
                    f"{str(p['seed_morph'] or '-'):>6s}  {p['anchor'][:40]}")
    return '\n'.join(rows)


# ─────────────────────────── self-test ───────────────────────────
def _selftest() -> int:
    fails = []
    # none = bare 불변
    assert abs(coated_chem_x('none', 1.30) - 1.30) < 1e-12
    assert abs(coated_chem_x('', 1.30) - 1.30) < 1e-12
    # LNO 15× 억제: 1.30 → 1 + 0.30/15 = 1.02
    assert abs(coated_chem_x('LNO', 1.30) - 1.02) < 1e-9, coated_chem_x('LNO', 1.30)
    assert abs(coated_chem_x('lno', 1.30) - 1.02) < 1e-9    # 대소문자 무관
    # LZO 8× : 1.30 → 1 + 0.30/8 = 1.0375
    assert abs(coated_chem_x('LZO', 1.30) - 1.0375) < 1e-9
    # 앵커 없는 프리셋(Li3PO4/SDCP/SWCNT) → bare 유지 (날조 금지 = 억제 미적용)
    for c in ('Li3PO4', 'SDCP', 'SWCNT', 'carbon'):
        if abs(coated_chem_x(c, 1.30) - 1.30) > 1e-9:
            fails.append(f'{c} 앵커없음인데 chem_x 변경')
    # 미지원 코팅 → none
    assert get_preset('unknown_xyz')['label'] == COATING_PRESETS['none']['label']
    # 억제는 단조 (suppress 클수록 chem_x 작음): LNO(15) < LZO(8) 억제 후
    assert coated_chem_x('LNO', 1.5) < coated_chem_x('LZO', 1.5) < 1.5
    # 억제 후에도 ≥1 (성장은 음수 안 됨)
    assert coated_chem_x('LNO', 1.30) >= 1.0
    # coated_rint0: rct_frac 없으면 bare 유지(날조금지), 주면 R_ct 성분만 억제
    assert abs(coated_rint0('LNO', 18.0) - 18.0) < 1e-9              # rct_frac=None → bare
    assert abs(coated_rint0('none', 18.0, rct_frac=0.5) - 18.0) < 1e-9   # 앵커없음 → bare
    # LNO r_ct_factor=1/20, rct_frac=0.5 → 18·(0.5 + 0.5/20) = 18·0.525 = 9.45
    assert abs(coated_rint0('LNO', 18.0, rct_frac=0.5) - 18.0 * 0.525) < 1e-9, coated_rint0('LNO', 18.0, rct_frac=0.5)
    # coating_effect: chem_x 계산 + 전체 필드
    eff = coating_effect('LNO', bare_chem_x=1.30)
    assert abs(eff['chem_x_coated'] - 1.02) < 1e-9 and eff['r_ct_factor'] == 1.0 / 20.0 and 'note' in eff
    assert coating_effect('SDCP')['chem_x_coated'] is None      # bare 안 주면 None
    # ── NOT-WIRED 검사 (2026-08-19) ─────────────────────────────────────────────
    #   위 배너가 **조용히 낡는 것**을 막는다.  누군가 `coated_rint0`/`coating_effect`/
    #   `preset_summary` 를 배선하면 여기서 실패하고, 그때 배너를 갱신하게 된다.
    #   ⚠ 반대 방향(배선을 지우는 것)은 이 검사가 못 잡는다 — 그건 그 소비처의 회귀다.
    import os as _os
    import re as _re
    _root = _os.path.dirname(_os.path.dirname(_os.path.abspath(__file__)))
    _me = _os.path.abspath(__file__)
    _dead = {'coated_rint0': 0, 'coating_effect': 0, 'preset_summary': 0}
    _live = {'coated_chem_x': 0, 'get_preset': 0}
    _pat = _re.compile(r'\b(' + '|'.join(list(_dead) + list(_live)) + r')\s*\(')
    for _dp, _dn, _fs in _os.walk(_root):
        if any(x in _dp for x in ('/.git', '/__pycache__', '/node_modules', '/litdb')):
            continue
        for _f in _fs:
            if not _f.endswith('.py'):
                continue
            _p = _os.path.join(_dp, _f)
            if _os.path.abspath(_p) == _me:
                continue
            try:
                _t = open(_p, encoding='utf-8', errors='replace').read()
            except OSError:
                continue
            for _m in _pat.findall(_t):
                (_dead if _m in _dead else _live)[_m] += 1
    for _k, _v in _dead.items():
        if _v:
            fails.append(f'배너가 낡았다 — `{_k}` 가 이제 외부에서 {_v}회 호출된다 '
                         f'(NOT WIRED 배너를 갱신할 것)')
    for _k, _v in _live.items():
        if not _v:
            fails.append(f'회귀 — `{_k}` 외부 호출이 사라졌다 (cei_suppress 경로가 끊겼다)')
    print('selftest OK' if not fails else 'selftest FAIL: ' + '; '.join(fails))
    print(preset_summary())
    return 1 if fails else 0


if __name__ == '__main__':
    import sys
    raise SystemExit(_selftest() if (len(sys.argv) > 1 and sys.argv[1] == '--selftest') else _selftest())

# 정독 근거 — bares2021_soft_rigid_mix_experiment_dic_proceedings (Barés, Cárdenas-Barrantes, Cantor, Azéma, Renouf, EPJ Web Conf. 249, 05004, 2021)

카드: `litdb/papers/bares2021_soft_rigid_mix_experiment_dic_proceedings.md` (정본 · 2026-11-10 digest).  쪽 = PDF 의 쪽 (4 쪽).  기호 𝒞 = 원문 |C| (오른쪽 Cauchy–Green 텐서의 von Mises 척도).

## a. 순수 SE (LPSCl · 황화물) 압력별 기공 곡선
이 배치에 없음 (모델 재료 · 실리콘 + PVC 2D).

## b. 압력을 뺄 때 되돌아오는 양
이 배치에 없음 — 하중 단계만 (0.5 mm 이동 → 1 분 이완 → 스캔 · p. 1 · 카드 §0-2 (iv)) · 초탄성이라 영구 변형도 없다.

## c. 항복 · 경도 · 크리프 값과 정의
- [c] bares2021_soft_rigid_mix_experiment_dic_proceedings | 탄성 계수만: 실리콘 E 0.45 MPa ([18] = Exp. Mech. 59, 453) · PVC E 1.2 GPa · ν 둘 다 미기재 · 항복 · 경도 없음 | 카드 §3-1 · p. 1 | 본문 | 모델 재료 (SE 아님) · 일축 항복 세기 환산 없음

## d. 단단한 + 무른 입자 혼합 · 하중 몫 · 재밍
- [d] bares2021_soft_rigid_mix_experiment_dic_proceedings | "Since rigid particle deformation is negligible, this suggests that rigid particles do not carry more load than the soft ones. The loading seems to be balanced between soft and rigid particles." — 근거 = 무른 입자 평균 변형이 전역 응력과 "exact same tendency" 로 변한다는 것 하나 | 카드 §5-4 · §9-2 · p. 4 | 본문 (문장) | 단단한 입자 응력 · 접촉력은 재지 않음 (PVC 기대 변형 ≈ 6 × 10⁻⁵ ↔ 영상 색 범위 ≈ 10⁻² · 카드 §3-4 [카드 산술]) · "똑같은 경향" 은 φ ≥ 0.90 에서만 ((1 − 𝒞)/σ 가 φ 0.84 → 0.90 에서 2.4 배 · [판독 + 카드 산술]) · 2D · κ 0.5 (단단한 입자 개수 · 넓이 절반) — AM 이 부피 다수인 우리 전극 (DEM 실측 AM–AM 몫 0.52–0.68) 에 옮기지 않음
- [d] bares2021_soft_rigid_mix_experiment_dic_proceedings | 재밍 φj ≈ 0.84 · "a coordination value slightly above 3 as predicted theoretically [23] since particles are slightly frictional" (κ 0.5) ↔ 그려진 Z(0.84) 3.61 · Z = 3.0 은 φ ≈ 0.822 | 카드 §3-2 · §3-3 · §12-B 1 · p. 2 · 그림 2 | 본문 + [판독] | 기준 미기재 · 같은 장치 2022 SM (φJ 0.831 · ZJ 3.50 · 압력 상승 시작) · vu2019 (Zc 4, 미끄러운 입자) 와 서술 방향이 다름
- [d] bares2021_soft_rigid_mix_experiment_dic_proceedings | 강체가 많을수록 무른 입자 변형 분포가 빨리 넓어진다 — std(𝒞) 의 꺾임 κ 0.2 ≈ 0.045–0.05 · κ 0.5 ≈ 0.075–0.08 · κ 0.8 0.105 까지 완만 (φ − φJ) · 처음 기울기 4.5 · 3.8 · 2.7 × 10⁻⁴ | 카드 §3-3 · §5-3 · p. 3–4 · 그림 4 삽도 | [판독 + 카드 산술] | std 의 정의 · κ 별 φJ 미기재 · 삽도 std (≤ 1.8 × 10⁻⁴) 가 같은 그림의 분포 폭 (0.003–0.09) 과 2–3 자릿수 다름 (카드 §3-4)

## e. 점접촉 법칙이 큰 변형에서 깨지는 범위와 대안
- [e] bares2021_soft_rigid_mix_experiment_dic_proceedings | "This quantity [specific contact length] increases linearly with φ, which is not in agreement with the Hertz's contact law in 2D [24]. This last point is not surprising since soft particles are far from the small deformation assumption in our study." · l 0.13 → 0.32 (φ 0.797 → 0.912 · 기울기 1.5–1.7 / 단위 φ) | 카드 §0-2 (i) · §5-1 · p. 2 · 그림 2 | 본문 (문장) · [판독 + 카드 산술] (값) | 2D · 초탄성 · 실험만 · 대안 접촉 법칙 없음 · 맞춘 값 0 개 · 같은 그룹 2022 SM 은 같은 선형을 Hertz 척도로 '예측된다' 고 씀 (반대 서술)

## f. MPM 의 접촉 · 다물체 · 강체 결합 방법과 해상도 규칙
이 배치에 없음 (실험).  측정 해상도만: 2400 dpi (10.58 µm/px · 지름 20 mm = 1,890 px) · 무늬 상관 길이 50 µm · 상관 칸 "self-adjusted … as already presented in [13]" ↔ [13] (vu2019) 원문은 40 px 고정 칸 (카드 §4-2 · §12-B 6 · p. 2).

## g. 2D 결과를 3D 로 옮길 때의 경고나 증거
- [g] bares2021_soft_rigid_mix_experiment_dic_proceedings | 원문에 3D 전이 문장 없음 (평면 응력 / 평면 변형률 낱말도 없음) · 무른 입자 안쪽 tr C ≈ 1.90–1.95 → 바닥면 넓이 비 J ≤ tr C/2 ≈ 0.95–0.975 (2D 에서 tr C ≥ 2J) · φ 0.795 → 0.915 와 "over 15 %" 를 함께 쓰면 입자 바닥면 넓이 합 ≤ 0.978 배 | 카드 §0-2 (iii) · §3-4 · 그림 3 | [판독 + 카드 산술] · 추론 | 위가 자유인 2D 실험 ≠ 2D 평면 변형률 계산 (형제 카드 vu2019 −2 % · 2022 −8 % 와 같은 부류)

## h. DEM 에서 FE · MPM 으로 넘긴 선례와 넘긴 시점
이 배치에 없음 (계산 없음).  수치 쪽 말은 "The stress vs. packing fraction curve is also similar to what has been observed in a recent numerical study [14]" (p. 4 · [14] = Cárdenas-Barrantes 외 PRE 102, 032904 (2020)) 한 줄 — 겹친 그림 · 무차원화 없음 (카드 §5-4 4).

## i. 복합 양극 (AM + SE) 의 압력별 기공
이 배치에 없음.

## j. 카드가 스스로 적은 한계 (가압 · 탈압 관련)
- [j] bares2021_soft_rigid_mix_experiment_dic_proceedings | 하중 쪽만 (탈압 없음) · 응력 단위 · 정의 불확실 ('MPa' · 나눈 넓이 없음) · 접촉 판정 문턱 미기재 · 단단한 입자가 낀 접촉 판정법 없음 · 그림 2–4 = κ 0.5 한 실험 · 맞춤 · 수치 대조 없음 · 빈틈 넓이 · std 정의 없음 | 카드 §12-A · §12-B · §12-C | 본문 + 카드 산술 | —

## k. DEM 의 한계 (인용 서지: Barés, Cárdenas-Barrantes, Cantor, Azéma, Renouf, EPJ Web of Conferences 249, 05004 (2021))
- [k] bares2021_soft_rigid_mix_experiment_dic_proceedings (Barés 외 2021, EPJ Web Conf.) | **'DEM' 낱말 없음 — 말 없음.**  닿는 문장: "This quantity increases linearly with φ, which is not in agreement with the Hertz's contact law in 2D [24]. This last point is not surprising since soft particles are far from the small deformation assumption in our study." | p. 2 · 카드 §0-2 (i) · `eq_02c…` | 본문 | 실험 논문 · DEM 대조 없음 · 믿을 수 있는 변형 상한 같은 수치 없음 · 같은 그룹 2022 SM 의 반대 서술 (Hertz 척도로 선형 예측) 을 함께 적어야 함
- [k] bares2021_soft_rigid_mix_experiment_dic_proceedings (Barés 외 2021, EPJ Web Conf.) | "These kinds of mixed soft-rigid granular systems display singular behaviors different from purely rigid or purely soft systems." · "This exponential tail is reminiscent of what is observed for force values in packing of rigid granular systems [25]" | p. 1 · p. 3 · 카드 §11 | 본문 | 서술 · 수치 없음

## l. 소성변형이 왜 어려운가 (인용 서지: Barés 외, EPJ Web Conf. 249, 05004 (2021))
- [l] bares2021_soft_rigid_mix_experiment_dic_proceedings (Barés 외 2021, EPJ Web Conf.) | 소성 없음 (초탄성 실리콘 + 단단한 PVC).  어려움 문장: "Due to the already complex process of measuring local mechanical properties of each grain for fewly deformed particles [11] the challenge is even more important of measuring them for soft highly deformed particles." · 우회 = 계산이 아니라 측정 (무른 = 대변형 DIC [18] · 단단한 = 처음 영상과 상관하는 작은 변형 DIC) · 비용 = 96 개 · 실험마다 사진 ≈ 100 장 (한 장 ≈ 4.9 × 10⁸ px · [카드 산술]) · 단계당 15 s + 60 s + 스캔 (스캔 시간 미기재 — vu2019 의 10 분이면 ≈ 19 h · [카드 산술 · 가정]) · 맞춘 값 0 개 | p. 1–2 · 카드 §0-2 (ii) · §3-4 | 본문 + 카드 산술 | 모델 쪽 서술은 "will permit to improve their compression models [14]" 뿐

## m. 받아들일 통찰
- [m] bares2021_soft_rigid_mix_experiment_dic_proceedings | 피복 · 접촉의 '하중 없는 기준선' 을 결과 전에 잰다 — 이 실험은 σ ≈ 0 · Z 2.48 인 출발에서 특정 접촉 길이 0.13 (닿은 원의 0.5 mm 근접 호만으로 ≈ 16 % · 13–25 % [카드 산술 · 가정]) · 같은 장치 vu2019 0.09 · 2022 ≈ 0–2 % → 기준선은 판정 규칙이 정한다 · 우리 MPM 피복 (근접 띠만 · MPMC-02) 에 하중 0 프레임 기준선을 먼저 | 단계 0; 단계 7 | 카드 §3-4 · §4-4 · §9-1 · 그림 2
- [m] bares2021_soft_rigid_mix_experiment_dic_proceedings | AM 하중 몫 (R1) 은 SE 변형장에서 추론하지 않고 접촉력 · 판 반력 분할로 잰다 — 이 글의 "하중 균형" 결론이 변형으로 추론한 실례 (단단한 입자 응력은 측정 밖) | 조건 R1; 단계 5; 후보 D0 | 카드 §5-4 · §8-4 · §9-2
- [m] bares2021_soft_rigid_mix_experiment_dic_proceedings | 재밍점 정의를 결과 전에 고정하고 퍼짐을 함께 보고 — 이 글 곡선 하나에서도 φj 0.822 (Z = 3) · 0.823 (2022 의 압력 기준 0.92) · 0.84 (본문) · Z 법칙 계수 k 2.3–2.6 ↔ 4.1–4.7 [카드 산술] | 단계 0; 결과 전 대조 항목 | 카드 §3-4 · §9-3
- [m] bares2021_soft_rigid_mix_experiment_dic_proceedings | 변형 통계의 단위를 이름으로 나눈다 — 같은 글의 '평균 𝒞' (그림 2 · 0.966) 와 분포의 1 차 모멘트 (그림 4 · ≈ 1.03) 가 반대 방향 · 삽도 std 가 분포 폭보다 2–3 자릿수 작다 → MPM 변형장 보고에 '화소 분포' 와 '입자 평균' 을 따로 | 단계 7; 결과 전 대조 항목 | 카드 §3-4 · §9-5

## 카드 문제
- 이 카드 안: 없음 (원문 어긋남은 카드 §12-B 에 원문 그대로 적었다).
- 형제 카드 (고치지 않음 · 본 세션 보고): ① `vu2019_soft_grain_compression_beyond_jamming_dic` 311 행 "(2022 학회판 정의는 벽 포함 …)" — 학회판은 2021 (EPJ Web Conf. 249, 05004) ② `cardenasbarrantes2022_soft_hard_grains_compaction_experiment_dic` §14 · §10-2 의 "이 실험의 학회판" — 원문 2022 Letter 는 이 글을 장치 · 기름 · PVC 변형 무시의 근거로만 인용하고 (setup partially introduced by [12,33]) 자료는 같은 φ 에서 다르다 (응력 1.1–1.8 배 · Z 0.14–0.32 낮음) → '같은 장치의 앞 판' 이 정확 · 그 카드가 이 글에서 옮긴 값 (마찰 0.05 ± 0.02 · 96 개 · 1/2 · 2/3 · Hertz 문장 · l 정의 · PVC ν 없음) 은 원문과 같다.

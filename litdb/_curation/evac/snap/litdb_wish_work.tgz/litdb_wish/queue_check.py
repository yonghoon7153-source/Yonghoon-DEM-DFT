import json, re, sys, unicodedata
items_p, qp = sys.argv[1:3]
def fold(s): return "".join(c for c in unicodedata.normalize("NFKD", s) if not unicodedata.combining(c)).lower()
Q = json.load(open(qp, encoding="utf-8"))
qt = {k: fold(v.get("bib","")+" "+v.get("pdf","").replace("_"," ")) for k,v in Q.items()}
PREF = {"1016","1021","1002","1149","1039","1038","1007","1063","1103","1006","0032","5910","1680","1252","1557","2307","1088","3390","1115","1299"}
YEAR = re.compile(r"^(19[0-9]\d|20[0-3]\d)$")
rows = [l.rstrip("\n").split("\t") for l in open(items_p, encoding="utf-8")][1:]
for idx, line, batch, bib, why, check in rows:
    fb = fold(bib)
    dois = [d.rstrip(".") for d in re.findall(r"10\.\d{4,9}/[^\s,;)]+", fb)]
    nums = [n for n in re.findall(r"\d{4,}", fb) if not YEAR.match(n) and n not in PREF]
    # 제목 낱말 6 개 연속 (영문 낱말만) — 제목이 있으면
    words = re.findall(r"[a-z]{4,}", fb)
    hits = []
    for k, t in qt.items():
        ev = [("doi:"+d) for d in dois if d in t]
        nh = [n for n in nums if re.search(r"(?<!\d)"+n+r"(?!\d)", t)]
        if nh: ev.append("num:"+"+".join(nh))
        # 제목 낱말 겹침 (6 개 이상 공통 4 글자 이상 낱말)
        common = set(words) & set(re.findall(r"[a-z]{4,}", t))
        if len(common) >= 9: ev.append(f"words:{len(common)}")
        if ev: hits.append((k, ";".join(ev)))
    if hits:
        print(idx, "L"+line, batch, "|", " ".join(f"{k}[{e}]" for k,e in hits))

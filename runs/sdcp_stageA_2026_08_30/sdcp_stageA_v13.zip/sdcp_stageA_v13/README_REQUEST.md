# VASP 계산 요청 — LiNiO₂(104) 위 분자 조각 단일점

바쁘신 중에 부탁드려 죄송합니다. **VASP 실행 25회**입니다
(dense 1 · static 24).
슬랩 쪽은 구조 최적화를 저희가 MLIP 으로 끝내서 단일점만 돌리면 되고,
기체 분자 기준계만 DFT 이완이 필요합니다 (잡당 몇 분).

## 하실 일

```
mkdir -p <이 묶음 전용 빈 디렉터리> && cd <그 디렉터리>
unzip <이 묶음>.zip
cd <잡폴더>
PP=/path/to/potpaw_PBE.54 bash POTCAR_ASSEMBLE.sh     # 그 잡 전용 POTCAR 조립
VASP_CMD="mpirun -np 256 vasp_std" bash run_job.sh
```

⚠ **묶음이 둘 이상이면 반드시 서로 다른 빈 디렉터리에 풀고 따로 반송해 주세요.**
같은 자리에 겹쳐 풀면 어느 결과가 어느 묶음 것인지 저희가 되살릴 수 없습니다.

잡 폴더 24개가 `prospective` · `refs` 에 있습니다.
서로 **완전히 독립**이라 원하시는 만큼 동시에 돌리셔도 됩니다.

## 잡 census (산출물에서 센 값)

| | 끝점 | D3-off 쌍둥이 | 계 |
|---|---:|---:|---:|
| references | 8 | 0 | **8** |
| calibration complexes | 16 | 0 | **16** |
| | | | **24** |

audit pose **0개**. pose 당: pm1/D3-on · net4/D3-on — **D3-off 쌍둥이를 만들지 않는다** (C3 는 D3-on OUTCAR 의 Edisp 로 낸다)


## 실행 단계와 결과 범위 (읽어 주세요)

이 요청은 **최종 흡착 결론이 아니라 Stage A calibration tranche** 입니다.
포함된 복합체는 사전 지정된 calibration pose 뿐이고 **audit pose 는 없습니다.**

각 calibration pose 는 `pm1/D3-on` · `pm1/D3-off` · `net4/D3-on` 세 계산으로
구성됩니다. **`net4/D3-off` 는 의도적으로 만들지 않습니다** — 고정기하 D3(zero)는
구조 기반 additive correction 이라 자기상태에 무관하므로 반복이 불필요합니다.
따라서 같은 POSCAR 가 여러 번 보이는 것은 **정상이고 설계**입니다.
중복으로 보고 하나만 돌리시면 그 짝이 통째로 무의미해집니다.

Stage A 회수 **후에만** 상대오차 경계 (B)와 최종 선택창 (W)를 확정하고, 창 안의
전체 candidate 와 창 밖 sealed audit 로 Stage B 를 새로 생성합니다.
**Stage A 결과만으로 두 조각의 최종 흡착 선호를 종결하지 않습니다.**

`pm1` 과 `net4` 는 **초기 MAGMOM seed 이름**입니다. 최종 자기상태가 아닙니다.
저희 분석기가 최종 Ni 국소모멘트 부호벡터 · moment collapse · 유기종 상대스핀으로
realized magnetic basin 을 판정하고, **같은 realized basin 으로 매칭되지 않은**
complex 와 clean slab 에너지로는 흡착에너지를 만들지 않습니다.
그래서 `LORBIT` 를 켜 두었습니다 — OUTCAR 의 국소모멘트 표가 판정 근거입니다.

가능하시면 **`refs/clean_slab__*` 두 잡을 먼저** 돌려 보내 주세요. 그것으로 자기
topology gate 를 통과시킨 뒤 complex 결과를 씁니다. raw `net4` 가 pose 마다 다른
basin 으로 수렴하면 저희가 계산을 중단하고 별도 절차를 요청드립니다.

모든 결과는 MLIP 이 고른 **고정기하에서의 PBE+U+D3 단일점 전자에너지**입니다.
DFT-relaxed adsorption energy · 평형 결합에너지 · 자유에너지로 표현하지 않습니다.

## 미리 아셔야 할 것

- **전 잡이 단일점입니다.** `relax/` 폴더가 아예 없습니다. 확인하실 수 있습니다:
  `find . -maxdepth 3 -type d -name relax | wc -l` → **0**
  잡 수는 `find . -name run_job.sh | wc -l` 이 정답입니다.
- **가장 긴 잡이 약 45 시간**입니다 (256코어 기준 추정, ±2배).
  walltime 상한이 이보다 짧으면 그 잡만 알려 주세요 — 나눠서 다시 만들어 드립니다.
- **POTCAR 는 잡마다 종 순서가 다릅니다.** `POTCAR_ASSEMBLE.sh` 가 그 잡에 맞게
  조립하고 순서·variant·PAW_PBE 까지 확인합니다. 하나를 만들어 전체에 복사하시면
  **에러 없이 다른 계를 계산합니다.**

## 보내 주실 것

각 잡의 **`static/OUTCAR`** — 이것 하나면 판정이 됩니다. `.gz` 그대로 좋습니다.
그리고 각 잡의 **`POTCAR_PROVENANCE.json`** (조립기가 자동 생성합니다).

- `static/vasprun.xml` — 선택
- **CHGCAR / WAVECAR 반송 불필요** (용량)
- 발산·미수렴 잡도 **지우지 말고 그대로** 보내 주세요. 어느 잡이 왜 실패했는지가
  판정의 일부입니다.

## 부탁 — 입력을 고치지 말아 주세요

`INCAR` · `KPOINTS` · `POSCAR` 를 **한 글자도 고치지 말아 주세요.**
분석기가 `MANIFEST.json` 의 sha256 으로 대조하며, **예외 태그 목록을 두지 않았습니다.**
`NCORE` 를 포함해 무엇이든 한 줄이 바뀌면 그 잡은 거부됩니다
(`NCORE` 는 4 로 넣어 두었습니다).

- 병렬 조정이 꼭 필요하시면 **알려 주세요** — 저희가 다시 만들어 드리는 게 빠릅니다.
- **SCF 가 안 붙는 잡은 그대로 두고 알려만 주세요.** 설정을 바꿔 다시 돌리신 값은
  저희 검증을 통과하지 못해 버려집니다.
- 그래도 직접 재시도해 보셔야 한다면, **원본을 덮지 마시고**
  `<잡폴더>/_retry_1/` 처럼 별도 디렉터리에 남겨 주세요. 원본 실패 상태와 재시도를
  둘 다 받아야 저희가 원인을 압니다.

## 확인용

```
python3 analyze_results.py .       # 필수 산출이 빠지면 exit 2 로 알려 줍니다
```

---
계산 조건·근거·범위는 `MANIFEST.json` 에, 제출 관련 수치는 `SUBMIT_CONTRACT.md` 에
적어 두었습니다. 궁금한 점 있으시면 편하게 물어봐 주세요.

<details><summary>프로토콜 요약 (참고)</summary>

PBE+U(Ni d 6.2 Dudarev) · D3 zero damping(IVDW=11) · ENCUT 520 · ISMEAR 0/0.05 ·
ISYM=0 · LASPH · ADDGRID · LDIPOL/IDIPOL=3 · static k 3 4 1 · dense k 4 6 1 ·
고정 평면 z ≤ 17.396 Å · 자기 seed 2종(각 끝점마다 둘 다 필요합니다) ·
Ni 는 **Ni_pv** (2026-08-08 납품과 동일 계보) · VASP 5.4.4 또는 6.x + PBE PAW 5.4.
dense 는 k 검증용이라 1개 잡에만 있습니다: (없음).
</details>

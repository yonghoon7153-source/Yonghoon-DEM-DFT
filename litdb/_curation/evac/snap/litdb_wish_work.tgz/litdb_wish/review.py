import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from keys import K
from rules import classify, letters
from collections import OrderedDict
rows = [l.rstrip("\n").split("\t") for l in open(sys.argv[1], encoding="utf-8")][1:]
G = OrderedDict()
for idx, line, batch, bib, why, check in rows:
    key = K[int(idx)][0]
    g = G.setdefault(key, {"idx": [], "batches": [], "why": []})
    g["idx"].append(int(idx)); g["why"].append(why)
    if batch not in g["batches"]: g["batches"].append(batch)
from collections import Counter
cnt = Counter()
for key, g in G.items():
    nb = len([b for b in g["batches"] if b.startswith("batch_")]) + (1 if any(not b.startswith("batch_") for b in g["batches"]) else 0)
    cls, trig, lets = classify(" ‖ ".join(g["why"]), nb)
    cnt[cls] += 1
    print(f"{g['idx'][0]:>3} {key:<26} nb={nb} {cls} {','.join(trig):<14} L={''.join(sorted(lets)):<8} | {g['why'][0][:70]}")
print(cnt, len(G))

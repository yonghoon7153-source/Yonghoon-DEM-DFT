# POTCAR / VASP attestation 요청 (계산 **전**)

이 묶음은 탐색용 정책(post_hoc)입니다 — attestation 은 **선택**입니다. 있으면 PAW dataset 신원
**기록**이 남고, 없어도 계산·판정은 그대로입니다. 있어도 원고 인용 자격이 올라가지는 않습니다
(회신 BA P0-3). POTCAR 파일 자체는 주고받지 않습니다 — 지문과 버전 토큰만입니다.

아래 스크립트를 묶음 루트에서, README 실행 블록의 export 뒤 · `bash run_staged.sh 1` **앞**에서
실행하시면 `POTCAR_ATTESTATION.json` 이 만들어집니다. 반송 때 그 파일도 함께 옵니다
(푼 디렉터리를 통째로 압축하시면 자동입니다).

```bash
# 먼저 받으신 ZIP 의 SHA256 을 구합니다 (번들 안에는 자기 해시를 넣을 수 없습니다)
ZS=$(sha256sum /경로/받은번들.zip | cut -d" " -f1)

PP=/path/to/potpaw_PBE.54 POTCAR_ALLOWLIST=/abs/site_allow.txt RELEASE_LABEL="potpaw_PBE.54" SITE="기관/담당자" BUNDLE_ZIP_SHA256="$ZS" VASP_EXE=/abs/path/to/vasp_std bash MAKE_POTCAR_ATTESTATION.sh
```
(README 실행 블록의 `export` 를 이미 하셨으면 `PP`·`POTCAR_ALLOWLIST`·`BUNDLE_ZIP_SHA256`·`VASP_EXE` 는
그 값이 그대로 쓰이므로 `RELEASE_LABEL`·`SITE` 두 개만 붙이면 됩니다.)

⚠ **첫 VASP 실행 전에** 돌려 주세요. 스크립트가 OUTCAR/CONTCAR/CHGCAR 등 산출물이
있으면 거부합니다 — "계산 전에 만들었다" 를 선언이 아니라 **검사**로 남기기
위해서입니다.

담기는 것 (회신 AP #12 목록 그대로):
- 받으신 **정확한 ZIP** 의 SHA256 (BUNDLE_ZIP_SHA256) 과 MANIFEST.json 의 SHA256
- release label 과 variant 목록
- variant 별 **원본 파일 전체** SHA256
- POTCAR 내부 `TITEL` 줄과 embedded hash
- site allowlist 의 SHA256
- 생성 UTC 시각 · 사이트/담당자
- VASP 배너의 버전 토큰 (`vasp.<버전>` — 봉인 `SEAL_POTCAR_ROOT.sh` 와 같은 규칙) 과 배너 앞 8줄
- VASP 실행파일의 SHA256 과 resolved path

⚠ 있어도 없어도 이 묶음의 결과는 **원고 인용용이 아닙니다** (post_hoc 정책 · MANIFEST
`potcar_identity_policy.manuscript_citable = false`). 있으면 Methods 에 PAW release 이름을 **기록**으로
적을 수 있고, 없으면 "계산 수행 기관이 관리하는 트리" 로만 적습니다.

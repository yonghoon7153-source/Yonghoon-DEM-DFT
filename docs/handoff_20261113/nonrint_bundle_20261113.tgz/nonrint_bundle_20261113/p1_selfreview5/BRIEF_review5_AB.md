# 지시서 — P1 G2c′ A · B 설계 확인을 Codex 대신 내부 반박 리뷰로 (5 회차 · 11-13 · Codex 아님 · 문서만 · 결과 0 건 · 구현 전)

S = `<SCRATCH>`

## 0. 배경 · 지위

- 1저자 11-13: Codex 사용량 소진 (리셋 11-16 14:38 KST) → *"그냥 자체리뷰로 우선 보내봐"* = Codex 에 보내려던 설계 확인 요청을 그대로 내부 반박 리뷰로 받는다 (1저자 11-10 운영 결정과 같은 꼴 · 기록은 "Codex 아님" · Codex verified 로 올리지 않는다).
- 리뷰 대상 = ZIP `S/codex_zip/codex_p1_g2c_ab_design_3daa2c48a.zip` (핀 `3daa2c48a` 의 blob 그대로 + `PIN.txt` · 224 파일).
- 요청서 = ZIP 안 `repo/docs/reviews/codex_p1_g2c_ab_design_request_20261112.md` — **Codex 가 이 요청서를 받은 것처럼 그대로 따른다** (§0 닫는 것 / 닫지 않는 것 · §1 보내는 것 · §2 Q1–Q6).
- 요청서 §3 끝: 4 회차 고침 (`disposition4_AB.md`) 의 독립 재확인이 아직 없다 — 이 리뷰가 그 확인도 겸한다.
- 실제 RJ 발사 GO 는 이 리뷰의 범위가 아니다 (요청서 머리 QA5 = Codex · 리셋 뒤 · B 결과 붙여).

## 1. 할 일

1. ZIP 을 새 빈 폴더 `S/p1_ab_selfreview/zip/` 에 푼다 (폴더가 이미 있으면 멈추고 알린다).  직접 쓰는 스크립트 · 출력은 `S/p1_ab_selfreview/review5/` 에 둔다 (풀린 폴더 안에서 실행하지 않는다 · 파이썬은 `-I`).
2. 요청서 → A (`dem_unloading_ps45_prereg_20261009.md` §15) → B (`p1_g2c_mpi_stage2_registration_20261112.md`) → 메모 · `README_g2cp.md` · 샌드박스 (`run_g2cp.sh` · `compare_g2cp.py` · `test_g2cp.py`) · 키트 코드 (`run_unload.sh` · `ul_reader.py` · `ul_gates.py` · `make_unload_decks.py` · `seal_kit.py` · `active_rules.json`) 를 읽고 **자기 판단을 먼저 세운다**.  지난 내부 리뷰 기록 (`internal_reviews/p1next_AB_20261112/`) 은 그 뒤에 — 닫혔다는 주장 대조 · 중복 피하기에만 쓴다.
3. Q1–Q6 마다 판정 (수용 · 조건부 수용 · 거부) + 근거 (파일:행 · 절) · 조건부면 조건을 적는다.
4. **보장마다 작은 해석 반례** (리포 CLAUDE.md "Codex 요청 전 사전 공격" ③) — 설계가 내세우는 보장마다 손으로 풀리는 작은 반례를 만들어 깨 본다.  적어도: 15-5b 전역 W ≤ 0.05 · 칸별 W ≤ 0.5 · 칸 하중 쌍 ≥ 100 (칸 하나 통째 소실 24/24 · 칸 경계 · 칸 수가 바뀌는 교차 NP · 쌍 집합 같음 · 한쪽 0 행) / 경로 규칙 (글자 같음 + 폴더 양쪽 realpath · 반례 12/12 — 심볼릭 뿌리 · `..` · 끝 `/` · 이름 바꾼 앞 시도 · 같은 이름 다른 폴더 · 기록과 로그 중 하나만 바뀐 꼴) / RT1 · RT2 자리 (UN 뒤 · UK 앞) 와 실패 · 건너뜀 처리 / GD17 첫 낱말 규칙 / B 의 "부분 결론 없음" · 시도 셈 · 셈 밖 분류 (ExitCode `3:0` · 장부 줄 · rc 3 = `attempt` 줄 앞) · 섞인 결과 = 그 NP 동결 / "같은 S0 같은 경로 = 같은 쌍 상태" / RT 문법 fixture 검사 20.  깨지면 반례 + 등급 + 고칠 방향 한 줄 · 안 깨지면 시도한 꼴 목록.
5. 요청서의 숫자 · 전칭 (*"24/24"* · *"12/12"* · *"×16.2"* · *"×2.36"* · *"×8.3–×210"* · *"3111/3111"* · *"41 → 49"* · *"무변경"* · *"사례 수 안 줄임"* · *"부분 결론 없음"*) 을 ZIP 의 파일 · 산술 스크립트 출력과 한 줄씩 대조한다.  산술 스크립트 (`rb_count.py` · `r2_cont_guard.py` · `r2_alt_metrics.py` · `f2_guard_power.py` · `pfa_w_check.py` · `f3_choice.py` · `f3_path_rule.py` · `r4_check.py`) 는 가벼우면 ZIP 사본에서 다시 돌려 기록된 출력과 대조한다 (출력 = `review5/`).
6. 4 회차 고침 (PFA2-01 + P3 넷) 마다 닫힘 · 부분 · 안 됨.
7. 새 지적 = ID `SR5-NN` · 등급 P1 · P2 · P3 · 자리 · 반례 · 고칠 방향 한 줄.
8. 끝 판정 한 줄: **구현 (시험 먼저) 진행 가능 / 조건부 (구현 전에 고칠 것 목록) / HOLD** — RJ 발사 GO 는 범위 밖이라고 함께 적는다.

## 2. 규칙 (꼭)

- 본 리포 `/home/user/Yonghoon-DEM-DFT` 는 읽기만 · **git 명령 금지**.  **`GIT_DIR` · `GIT_WORK_TREE` · `GIT_INDEX_FILE` 을 export 하거나 명령 앞에 붙이지 않는다** (`SELF-169`).  git 이 꼭 필요하면 `S/p1_ab_selfreview/review5/` 안에서 따로 `git init` 한 일회용 리포만 쓴다.
- ibb · 원격 기계 접속 없음 · LIGGGHTS 실행 없음 · 무거운 시험 없음 (명령 하나 10 분 · 메모리 4 GB 안 · 키트 전체 시험 · 리포 게이트 금지).  샌드박스 `test_g2cp.py` 같은 가벼운 시험은 ZIP 사본에서 돌려도 된다.
- 신호 실험이 필요하면 `unshare -pf --mount-proc --kill-child` 안에서만 · kill 번호 = 직접 만든 자식 · > 1 · 자기 · 부모 아님 (`SELF-164`).
- 주소 · 포트 · 계정 · 홈 경로 · 노드 이름 값을 쓰지 않는다 (자리표 `<HOME>` · `<LUSTRE_HOME>` · `<SCRATCH>`).  Artifact 도구 · 웹 게시 · 시스템 패키지 설치 · 시스템 설정 변경 금지 (`SELF-168`).
- 결과 0 건: 생산 결과 · 7:3 ⓡ 사전 셈 (⑥′) 은 하지 않는다 (요청서 §0 "닫지 않는 것").
- 큰 사본은 끝나면 지운다 (디스크 빠듯 · 풀린 `zip/` 은 산출을 쓴 뒤 남겨도 된다).

## 3. 산출 · 답장

- 산출 = `S/p1_ab_selfreview/review5_AB.md` (Q1–Q6 판정표 · 지적 표 · 반례 시도 목록 · 숫자 대조표 · 4 회차 고침 확인 · 끝 판정) + 스크립트 · 출력 `S/p1_ab_selfreview/review5/`.
- 답장 10 줄 안팎: Q1–Q6 판정 · 지적 등급별 수 + 한 줄씩 · 4 회차 고침 확인 · 숫자 대조 · 끝 판정 · 산출 파일 전체 경로.

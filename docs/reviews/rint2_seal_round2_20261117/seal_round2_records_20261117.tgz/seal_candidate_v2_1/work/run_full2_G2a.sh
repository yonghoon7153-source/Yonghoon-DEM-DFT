#!/bin/bash
# 사슬 시험 전체 다시 (sparse 에 시험 고정물 폴더 codex_rint2_rr_round4_evidence_20261109/ 를 더한 뒤 · 첫 판 = 504/506 · RR4A · RR4B = FileNotFoundError (sparse 밖 고정물))
until [ -e /tmp/claude-0/-home-user-Yonghoon-DEM-DFT/81c0ad95-542f-503b-9cf7-2f6a678a4b5b/scratchpad/rint/seal_candidate_v2_1/work/evG2a/_done.txt ]; do sleep 5; done
mv /tmp/claude-0/-home-user-Yonghoon-DEM-DFT/81c0ad95-542f-503b-9cf7-2f6a678a4b5b/scratchpad/rint/seal_candidate_v2_1/work/evG2a/e1_test_rint_r_chain_full.txt /tmp/claude-0/-home-user-Yonghoon-DEM-DFT/81c0ad95-542f-503b-9cf7-2f6a678a4b5b/scratchpad/rint/seal_candidate_v2_1/work/evG2a/e1_test_rint_r_chain_full_try1_sparse.txt
cd /tmp/claude-0/-home-user-Yonghoon-DEM-DFT/81c0ad95-542f-503b-9cf7-2f6a678a4b5b/scratchpad/rint/v21_clone || exit 9
H=$(git rev-parse HEAD)
{ echo "# HEAD $H (G″a · v2.1 · 봉인 꼴 한 커밋 · 부모 64e4d213e) · $(python3 -V 2>&1) · git 저장소 사본 (clone --shared · sparse = 시험이 읽는 폴더 · 원격 추적 ref = 본 리포 지금 판 154) · python3 -I scripts/test_rint_r_chain.py (둘째 판 · 첫 판 504/506 = RR4A · RR4B 고정물 폴더가 sparse 밖 · 더한 뒤)"; ( time nice -n 10 python3 -I scripts/test_rint_r_chain.py ) 2>&1; echo "rc=$?"; } > /tmp/claude-0/-home-user-Yonghoon-DEM-DFT/81c0ad95-542f-503b-9cf7-2f6a678a4b5b/scratchpad/rint/seal_candidate_v2_1/work/evG2a/e1_test_rint_r_chain_full.txt 2>&1
echo DONE2 > /tmp/claude-0/-home-user-Yonghoon-DEM-DFT/81c0ad95-542f-503b-9cf7-2f6a678a4b5b/scratchpad/rint/seal_candidate_v2_1/work/evG2a/_done2.txt

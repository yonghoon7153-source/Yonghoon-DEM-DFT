"""Reproduce local, read-only scientific checks and retain their actual output."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'outputs'
TARGET = ROOT / 'work/microshort-v2-d72e735f/bms-balancing'


def main():
    sys.stdout.reconfigure(encoding='utf-8')
    commands = [
        [str(TARGET / 'reviews/r14_repros/mph_dump.py'), '--self-test'],
        [str(OUT / 'mph_v2_extractor_check.py')],
        [str(OUT / 'mph_v2_workbooks_audit.py')],
        [str(OUT / 'mph_v2_physics_checks.py')],
        [str(OUT / 'mph_v2_solver_scope_inspect.py'), '--build'],
        [str(OUT / 'mph_v2_solver_scope_inspect.py'), '--finalize'],
    ]
    results = []
    for args in commands:
        result = subprocess.run([sys.executable, *args], cwd=ROOT,
                                capture_output=True, encoding='utf-8', errors='replace')
        results.append({'command': [sys.executable, *args], 'returncode': result.returncode,
                        'stdout': result.stdout, 'stderr': result.stderr})
        print(Path(args[0]).name, ' '.join(args[1:]), 'rc', result.returncode)
        if result.returncode:
            break
    records = {'scope': 'Local XML/OOXML/algebra checks only. No COMSOL, MATLAB refit, or solver execution.',
               'results': results, 'all_completed_successfully': len(results) == len(commands) and all(r['returncode'] == 0 for r in results)}
    (OUT / 'mph_v2_replay_log.json').write_text(json.dumps(records, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    source_files = [TARGET / p for p in ['docs/MICROSHORT_MPH_REVIEW.md', 'reviews/r14_repros/mph_dump.py',
                   'reviews/r14_repros/mph_dump_output.txt', 'reviews/REQ_MPH_MICROSHORT.md',
                   'reviews/REQ_FIT_RAILS.md', 'reviews/MPH_R1_RESPONSE.md']]
    identities = {str(p.relative_to(TARGET)): {'bytes': p.stat().st_size, 'sha256': hashlib.sha256(p.read_bytes()).hexdigest()} for p in source_files}
    (OUT / 'mph_v2_target_hashes.json').write_text(json.dumps(identities, indent=2) + '\n', encoding='utf-8')
    if not records['all_completed_successfully']:
        raise SystemExit(1)


if __name__ == '__main__':
    main()

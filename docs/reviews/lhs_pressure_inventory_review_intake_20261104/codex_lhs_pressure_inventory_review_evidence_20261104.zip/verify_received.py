"""Read-only integrity check of received review files and captured GitHub blob IDs.

No host paths, shell commands, Git process, or research log are opened.
The online GitHub directory responses were captured separately at the fixed PIN.
"""
from pathlib import Path
import hashlib
import json

BASE = Path(__file__).resolve().parent
R = BASE / 'received'
PIN = 'c8a55c8ae1021ec80634ee8c6533deeebc67ce61'
assert (R / 'PIN.txt').read_text(encoding='utf-8').strip() == PIN
manifest = json.loads((R / 'SNAPSHOT_MANIFEST.json').read_text(encoding='utf-8'))
remote = json.loads((BASE / 'remote_blob_listing.json').read_text(encoding='utf-8'))
assert manifest['pin'] == remote['pin'] == PIN
lookup = {e['path']: e for e in remote['entries']}
assert len(lookup) == len(remote['entries']) == 17
results = []
for e in manifest['entries']:
    b = (R / e['path']).read_bytes()
    sha = hashlib.sha256(b).hexdigest()
    blob = hashlib.sha1(b'blob ' + str(len(b)).encode() + b'\0' + b).hexdigest()
    assert len(b) == e['bytes'] and sha == e['sha256'], e['path']
    assert blob == lookup[e['path']]['sha'], e['path']
    assert len(b) == lookup[e['path']]['size'], e['path']
    results.append(dict(path=e['path'], bytes=len(b), sha256=sha,
                        remote_git_blob=blob, matched=True))
checked = set()
for line in (R / 'PACKAGE_SHA256SUMS').read_text(encoding='utf-8').splitlines():
    h, p = line.split('  ', 1)
    p = p[2:] if p.startswith('./') else p
    assert p not in checked
    assert hashlib.sha256((R / p).read_bytes()).hexdigest() == h, p
    checked.add(p)
actual = {p.relative_to(R).as_posix() for p in R.rglob('*') if p.is_file()}
assert actual - checked == {'PACKAGE_SHA256SUMS'}
print(json.dumps(dict(pin=PIN, package_checked=len(checked),
                     snapshot_and_remote_blob_checked=len(results),
                     source_unchanged=True, results=results),
                 ensure_ascii=False, indent=2))

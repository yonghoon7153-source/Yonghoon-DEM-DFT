import sys, importlib.util
from pathlib import Path
tree = Path(sys.argv[1])
spec = importlib.util.spec_from_file_location('T', tree/'scripts'/'test_mixer_precal_observe.py')
T = importlib.util.module_from_spec(spec); spec.loader.exec_module(T)
deck = tree.joinpath(*T.E0_DECK).read_text(encoding='utf-8')
log = T.actual_log(deck, {'ins': 100000})
L = log.split('\n')
print('lines', len(L), 'bytes', len(log.encode()))
for k, l in enumerate(L):
    if 'ERROR' in l or l.startswith('Loop') or 'INFO' in l or 'Setting up' in l or l.strip().startswith('Step'):
        print(k, repr(l[:130]))
i = L.index(T.ACTUAL_HEADER)
print('\n'.join(L[i-3:i+6]))

# Dry-run helpers (scratch only).  Source after setting D (dry folder).  Every call appends one
# line to $D/runs/summary.tsv:  stage <TAB> step <TAB> rc <TAB> verdict-line
F8REL=docs/reviews/mixer_first8_launch_preparation_20261106
INREL=docs/reviews/mixer_inactive_preparation_20261109
log_line() { printf '%s\t%s\t%s\t%s\n' "$1" "$2" "$3" "$4" >> "$D/runs/summary.tsv"; printf '%-6s %-28s rc=%s  %s\n' "$1" "$2" "$3" "$4"; }
# vin <stage> <step> <in_dir> <mode> <snapshot> <candidate>   (evidence = new folder <stage>/<step>_ev)
vin() {
  local st=$1 sp=$2 indir=$3 mode=$4 snap=$5 cand=$6 out="$D/runs/$1/$2.out"
  mkdir -p "$D/runs/$st"
  python3 -I -B -X utf8 "$indir/verify_inactive.py" --mode "$mode" --snapshot "$snap" --candidate "$cand" --evidence "$D/runs/$st/${sp}_ev" > "$out" 2>&1
  local rc=$?
  local why; why=$(grep -E '^ValueError: |^AssertionError: |"rc": ' "$out" | tail -1 | sed -E 's/.*("rc": [0-9]+).*/report \1/' | cut -c1-160)
  [ -z "$why" ] && why=$(tail -1 "$out" | cut -c1-160)
  log_line "$st" "$sp" "$rc" "$why"
}
# f8tests <stage> <step> <f8_dir>   (four first8 package tests, cwd = f8_dir)
f8tests() {
  local st=$1 sp=$2 f8=$3 t
  mkdir -p "$D/runs/$st"
  for t in test_submit_draft test_mla_boundaries test_job_start_draft test_prepare_only; do
    local out="$D/runs/$st/${sp}_$t.out"
    ( cd "$f8" && python3 -I -B "$t.py" ) > "$out" 2>&1
    local rc=$?
    local ran; ran=$(grep -E '^Ran [0-9]+ test' "$out" | tail -1)
    local res; res=$(grep -E '^(OK|FAILED)' "$out" | tail -1)
    log_line "$st" "${sp}:$t" "$rc" "$ran · $res"
  done
}
# py <stage> <step> <cmd...>   (any of our python tools; verdict = last line)
py() {
  local st=$1 sp=$2; shift 2
  mkdir -p "$D/runs/$st"
  local out="$D/runs/$st/$sp.out"
  python3 -I -B "$@" > "$out" 2>&1
  local rc=$?
  log_line "$st" "$sp" "$rc" "$(grep -v '^$' "$out" | tail -1 | cut -c1-200)"
}
# mini_tree <src_tree> <new_dir> : the subset the IN verifier, the first8 tests and validate_planned read
mini_tree() {
  local src=$1 dst=$2 f
  [ -e "$dst" ] && { echo "mini_tree: $dst exists"; return 1; }
  mkdir -p "$dst/scripts" "$dst/dem_scripts/mixer_20260919" "$dst/docs/reviews"
  for f in mixer_precal_prepare mixer_precal_observe mixer_contact_reader measure_mixing_index measure_bed_aspect make_mixer_deck mixer_deck_readback mixer_deck_diff make_mixer_resume test_mixer_precal_prepare; do cp -p "$src/scripts/$f.py" "$dst/scripts/"; done
  cp -p "$src"/dem_scripts/mixer_20260919/{Drum,Front,Back}.stl "$dst/dem_scripts/mixer_20260919/"
  cp -rp "$src/$F8REL" "$src/$INREL" "$dst/docs/reviews/"
}

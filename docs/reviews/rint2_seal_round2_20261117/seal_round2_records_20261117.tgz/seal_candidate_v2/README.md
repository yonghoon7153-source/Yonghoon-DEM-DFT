# Rint ② 봉인 후보 v2 (11-17 · 조수 초안 · 문서 · scratch 만 · 결과 0 건 · 실행 0 · σ 열람 0)

- **지위** = 봉인 후보 v2 — 봉인 커밋 (Rint 고정 가지 끝 `64e4d213e` 위 문서 커밋) 의 글 · 파일 목록 · 만드는 도구 · 다시 잰 증거.  봉인 자체 = Codex 2/2 GO 뒤 · 결과 전 등록 넷 = Codex 회신 뒤 · S0 단계 2 전 1저자.  v1 (`/tmp/claude-0/-home-user-Yonghoon-DEM-DFT/81c0ad95-542f-503b-9cf7-2f6a678a4b5b/scratchpad/rint/seal_candidate/`) 은 고치지 않았다.
- **v1 → v2** = 1저자 11-17 결정 (*"권고대로해 · 이런걸로 병목 만들지마"* · 아래 표) — 봉인 꼴 = **넷째 길** (봉인본 새 파일 `docs/reviews/rint2_seal_<봉인 날짜>/registration_R_sealed.md` · 원본 등록 R = 핀 판 + 머리 표지 한 줄 · `scripts/` 무변경 · ⑥ 다시 없음) · 모든 사슬 단계 명령 `--registration <봉인본>` · S0 단계 2 `--r-doc <봉인본>`.
- **읽은 판** = 코드 핀 `64e4d213e` (`git show` · 봉인 꼴 사본의 HEAD 조상) · 본 리포 HEAD 5a04acd15 · stoic-next (가지 tmp-stoic-next) 끝 b3481336c — 읽기만 (git show · log · ls-tree · archive · `clone --shared`).  리포 · 작업 트리 쓰기 0 · σ 열람 0 · 코드 실행 = scratch 사본에서 `python3 -I` (Python 3.11.18).
- **표지**: [실측] = 이 후보가 scratch 에서 돌린 것 · [코드] = 코드 읽기 · [기록] = 리포 문서 · [추정] · [미확인].
- **보기 날짜** — 이 후보의 `<봉인 날짜>` 자리 = **20261120 (보기 · 봉인 때 1저자가 정한 날짜로 도구를 다시 돌린다)**.  그래서 아래 경로의 `20261120` 은 보기다.
- **함께 낸 파일** (scratch 후보 폴더 `/tmp/claude-0/-home-user-Yonghoon-DEM-DFT/81c0ad95-542f-503b-9cf7-2f6a678a4b5b/scratchpad/rint/seal_candidate_v2/` · 봉인 꼴 커밋에서는 같은 바이트가 `docs/reviews/rint2_seal_20261120/tools/` 에):

| 파일 | 무엇 |
|---|---|
| `make_sealed_copy.py` (커밋 자리 `docs/reviews/rint2_seal_20261120/tools/make_sealed_copy.py`) | 핀 판 원본 등록 R + 조각 + 계획 파일 → 봉인본 · 원본 자리 (표지 한 줄) · 명령 문서 · 계획 사본 바이트 · `_manifest.json` (같은 입력 = 같은 바이트 [실측 두 번 · 전 파일 같음]) · 자기 시험 17/17 [실측] |
| `registration_R_insert.md` (`docs/reviews/rint2_seal_20261120/tools/registration_R_insert.md`) | 봉인본에 넣는 글 R-00 · R-01 – R-15 + 원본 자리 표지 R-MARK (조각마다 `@op` 한 줄 = 도구가 읽는 자리) |
| `commands_doc_insert.md` (`docs/reviews/rint2_seal_20261120/tools/commands_doc_insert.md`) | 명령 문서에 넣는 글 K-01 – K-05 (bash 블록 = 주석만 · 실제 줄 = §3-1b sh 블록) |
| `plan_candidate.json` | 후보 계획 (v1 과 바이트 같음 · sha256 f09b3efbe50d104d7e294a6b3dce8bda5214d267a4fecfc99b7e50023396d3c4 · 결과 전 넷 null) |
| `build_20261120/` | 도구 출력 (봉인 꼴 파일 넷 + `_manifest.json`) |
| `evidence/` | 다시 잰 증거 (봉인 꼴 사본) + 시험 도구 (`evidence/tools/`) — 봉인 꼴 커밋에서는 `docs/reviews/rint2_seal_20261120/evidence/` |

## 이번에 닫는 것 / 닫지 않는 것

| 닫는 것 (글 · 도구 · scratch 실측) | 닫지 않는 것 |
|---|---|
| 봉인 꼴 = 넷째 길을 **기계로** 만드는 도구 (봉인본 · 원본 자리 표지 한 줄 · 명령 문서 · 계획 사본) — 블록 = 핀 사슬 `--stage plan-doc` 출력 그대로 · 해시 칸 = 계획 바이트 sha256 · 사슬 함수 대조 11 개를 도구가 스스로 본다 (1저자 11-17 봉인 후보 Q1) | 결과 전 등록 넷의 값 (`max_ladder_points` · `calib_rj_ratio_max` · `sv_cf_threshold` · `sv_cf_scope` · ⬜ 그대로 · §가-2) → 그래서 봉인 계획 sha256 · 블록 · 봉인본의 최종 바이트 (넷이 들어가면 바뀐다 · 도구를 다시 돌린다) |
| 모든 사슬 단계 명령 `--registration ~/dem-ca1/<봉인본>` · S0 단계 2 `--r-doc <봉인본>` (두 문서 sh 블록 · Q1) + 그 줄 전부 argparse 대조 (Q2 · 증거 ③) | 봉인 날짜 · 가지 이름 · 봉인 커밋 · push · Codex 2/2 요청서 · 두 기계 조립 같음 (11-12 Q10) |
| 결정 Q3 – Q7 반영 (계획 자리 · 꼴 · v3 표지 · 저장본 `~/ca1_cjstore` · 원장 넘김 `flock` · P0 / P1 · 첫 배정 · 합치는 기계 · 넘침 점 어림 꼴) | 감도 (FIBRE · UNREG · GRID · SVORDER) 경로 (Q8 · R 시작 전 따로 · ⬜) |
| v1 (마-3) 게이트 문제 (PC18 · EP06 · E17) = 넷째 길로 닫힘 — 봉인 꼴 사본에서 사슬 시험 전체 506/506 · E17 1/1 [실측] | 시간 어림 값 · 판정 · 보정 (3 판 그대로) |
| 봉인 가지 문서 참조 — 깨진 참조 5 건 처분 → `scripts/check_doc_refs.py` rc 0 [실측 · §마-4] | 리포 게이트 전체 (`scripts/check_all.sh`) 를 봉인 꼴 트리에서 돌린 것 (이 후보는 ①–⑦ · 원본 자리 · 원장을 읽는 게이트 시험 셋 · 참조 · 철회값 스윕 (바뀐 파일) 만) |
| 봉인 꼴 커밋에서 러너 규율 검사 (핀 판 `scripts/check_method_discipline.py`) rc 0 [실측 · R3-08 의 조건] | |
| 11-17 현장 (두 기계 · 읽기만 · 1저자 출력을 메인이 전함 [기록]) 반영 — `flock` 두 기계 다 있음 (봉인 후보 Q5 의 '없는 기계' 규칙 = 한정만) · kgy git 2.25.1 `bundle create --all` 이 `refs/heads/master` · `HEAD` 를 싣는다 · 홈 경로 글자 · 디스크 여유 · R venv = 두 기계 `~/dem-venv` (3.8.10 · 1.24.4 · 1.10.1 · cupy 12.3.0 · 1저자 결정 · gabia `~/rint-venv38` 손대지 않음) · 실행 트리 = 기존 트리 저장소에서 새로 뗌 → 명령 문서 §3-1b (1) (2) (5) · 봉인본 R-10 (0) · R-13 §10-7 ① · §10-8 ④ | 봉인 뒤 현장 확인 (두 기계 · PIN = 봉인 커밋 · 기존 트리의 `origin` 이 봉인 가지를 받는지) · DBE 저장본 파일 크기 |

## 증거 한눈에 (봉인 꼴 사본 = `git clone --shared` · 원격 추적 ref = 본 리포 `refs/remotes/origin/*` 153 개와 이름 · 객체 같음 [실측])

- 봉인 꼴 커밋 = scratch 사본의 scratch 가지 (리포에 올리지 않음): A (첫 조각) → B (마지막 조각) → B2 (봉인 기록 README · 증거 · 등록부 = stoic 바이트) → F (B2 의 나무 + README · 증거 고친 판을 `64e4d213e` 위 한 커밋으로) → **G** (F + 11-17 현장 반영 = 조각 둘을 고쳐 도구로 봉인본 · 명령 문서를 다시 만듦 + 이 README 의 현장 절 · `64e4d213e` 위 한 커밋 · F ↔ G 차이 = 명령 문서 · 봉인본 · 조각 둘 · README 5 파일 [실측 git diff] · 원본 자리 · 계획 바이트 = F 와 같음 · ①–⑦ 을 G 에서 다시 잼) → G′ (이 README · 증거를 G 결과로 고친 판 · G 와 다른 곳 = 봉인 기록 폴더의 README · `evidence/` 뿐 · 참조 · 철회값 · 경계를 G′ 에서 다시 잼 = scratch `evidence/raw/` 의 `G2_` 파일).  B ↔ F 차이 = 봉인 기록 폴더의 README · `evidence/` 와 `docs/reviews/claims.json` 뿐 [실측 git diff] — 시험 · 사슬 · S0 관문은 `claims.json` · 봉인 기록 폴더의 README · `evidence/` 를 읽지 않는다 [코드 grep] · 규율 검사 입력 (`scripts/` · `claims.json` · 원고 · CI 설정) = F ↔ G 같음 [실측 git diff] (그래도 ⑦ 을 G 에서 다시 잼).
- 리포에 넣는 증거 사본 = 긴 시험 · 규율 검사 출력은 요약 · 철회값 등록부 글자는 가림 (`evidence/tools/make_committed_evidence.py`) · 원 출력 = scratch 후보 폴더 `evidence/raw/` (리포에 넣지 않음).

| # | 무엇 | 결과 [실측] | 파일 |
|---|---|---|---|
| ① | `scripts/test_rint_r_chain.py` 전체 (핀 판 · 봉인 꼴 커밋 G) | **506/506 PASS · 552.8 s** (G · F = 506/506 · 543.1 s · B = 506/506 · 530.0 s · A = 506/506 · 498.5 s) — v1 의 실패 Y13 · RR4A · RR4B (git 저장소가 아닌 사본 탓) 도 지남 · 이 시험은 `claims.json` · 봉인 기록 폴더를 읽지 않는다 [코드 grep] | `evidence/e1_test_rint_r_chain_full_G.txt` · `evidence/e1_test_rint_r_chain_full_F.txt` · `evidence/e1_test_rint_r_chain_full_B.txt` · `evidence/e1_test_rint_r_chain_full_A.txt` |
| ② | `scripts/test_rint_r_chain_e2e.py --only E17` | 1 PASS · 0 FAIL (G · F · B 도 같음) | `evidence/e2_e2e_E17.txt` |
| ②′ | v1 이 막힌 시험 묶음 `--only K01,PC18,PC20,EP06` (명령 문서 · 원본 자리를 읽는다) | 4/4 PASS (G · F 도 같음) | `evidence/e13_seal_doc_tests.txt` |
| ③ | 두 문서 sh 블록 명령 argparse (사슬 · S0 · 단계 함수 받기만 · 실제 0755 저장본 폴더) | 봉인본 사슬 13 + S0 1 · 명령 문서 사슬 14 + S0 1 · 모두 지남 · `--registration` 값 = 봉인본 하나 · S0 `--r-doc` = 봉인본 · 종류 13 중 12 = 두 문서 인자 이름 같음 · `ladder_dry` = 명령 문서에만 · 문제 0 (G · F · B 도 같음) | `evidence/e3_sh_argparse.txt` |
| ④ | `--stage plan-doc --check-doc --registration <봉인본>` · 기본 (원본 자리) | rc 0 `PLAN_DOC_SAME` · 기본 = rc 3 `PLAN_DOC_MISMATCH` (표지 0 · 0) (G · F 도 같음) · 블록이 봉인본에 정확히 한 번 (B) | `evidence/e4_plan_doc_check.txt` |
| ④′ | 사슬 함수 (봉인본 · 원본 자리 · 계획 · S0 계획) | 봉인본 해시 줄 둘 = 계획 · S0 계획 sha256 · 원본 자리 = `PLAN_HASH_UNREGISTERED` · `S0_PLAN_HASH_UNREGISTERED` · `plans_cross_problems` [] · `require_plan_numbers` = 넷뿐 멈춤 (G · F · B 도 같음) | `evidence/e4b_chain_functions.txt` |
| ⑤ | S0 단계 2 관문 `ca_s0_census.verify_plan_commit` | 후보 커밋 (r_doc = 봉인본) = 거부 · 사유 = 넷뿐 · r_doc = 기본 = 거부 (S0 해시 줄 ⬜) · 고정물 값 (시험 값 · 등록 숫자 아님) 계획으로 도구가 다시 만든 봉인본 커밋 (G 위 · 작업 트리 없는 둘째 사본) = **통과** (F · B 위에서도 같음) | `evidence/e5_s0_stage2_gate.txt` · `evidence/e5_fixture_build.txt` |
| ⑥ | 철회값 등록부 (`docs/reviews/claims.json` `quotation_ban` · 42 패턴 · 게이트 함수 `ban_sweep` · 바뀐 파일 전부 = 게이트 글롭 밖 `.txt` 까지) | 최종 (G′) = 새로 쓴 글 (더한 줄 · 면제 없이) 0 건 · 바뀐 파일 전부 문제 0 (최종 등록부 = stoic 바이트 · G · F 도 같음) — 지나온 것: 핀 판 등록부면 11-16 S0 kit JSON 숫자 4 건 (§마-1 ⓒ) · B2 에서 이 README 가 패턴 글자 둘을 적은 것 · 리포에 넣은 규율 검사 전체 출력이 등록부 원문을 인용한 것 (4 건) 을 잡아 고침 (README = 글자 지움 · 증거 = 요약 · 가림본) | `evidence/e6_ban_new_text.txt` · `evidence/e6_ban_new_text_B2.txt` · `evidence/e6_ban_pin_claims.txt` |
| ⑦ | 핀 판 `scripts/check_method_discipline.py` (봉인 꼴 커밋 · 최종 등록부 = stoic 바이트) | 0 오류 · rc 0 (경고 17 · G · 38.8 s · F = 같음 · 76.6 s) — 핀 판 등록부 (커밋 B) 도 0 오류 · rc 0 (경고 17 · 114.0 s) | `evidence/e7_check_method_discipline.txt` · `evidence/e7_check_method_discipline_B_pin_claims.txt` |
| 참조 | 핀 판 `scripts/check_doc_refs.py` (봉인 꼴 커밋 B2 · F · G · 최종 G′) | G′ (최종) = rc 0 · 없는 경로 0 · 없는 커밋 0 [scratch evidence/raw/G2_check_doc_refs.txt (scratch 후보 폴더 · 리포 밖)] · F = rc 0 (처음 판 = 없는 경로 4 · 없는 커밋 1 → §마-4 · G = 없는 경로 2 = 이 README 가 가리키는 새 증거 둘 (`e12` · `e13`) 이 G 의 증거 폴더에 아직 없음 → G′ 에서 넣음) | `evidence/e9_check_doc_refs.txt` |
| 경계 | 바뀐 파일마다 풀이 코드 목록 다섯 경로 · CODE_FILES 20 · S0 일곱 · 규율 검사 입력 | §마-1 표 (= G · 바뀐 파일 78 = 새 74 · 고침 4 · G′ = 83 = 새 79 · 고침 4 · 다른 곳 = 봉인 기록 폴더 31 → 36 [scratch evidence/raw/G2_seal_files.txt (scratch 후보 폴더 · 리포 밖)]) · `git diff --quiet 64e4d213e <봉인 꼴> -- <다섯 경로>` rc 0 · 규율 검사 입력 안 = `docs/reviews/claims.json` 하나 | `evidence/e10_seal_files.txt` · `evidence/e10_seal_files_B2.txt` |
| 게이트 셋 | 원본 자리 · 원장을 읽는 게이트 시험 셋 (핀 판 `docs/reviews/rint2_probe6_prep_20261110/tools/test_probe6_read.py` · `scripts/test_ca_ext_z3.py` · `scripts/test_ca_s0_census.py` · G) | 셋 다 rc 0 — `test_probe6_read.py` 357 PASS · 0 FAIL (370 s) · `test_ca_ext_z3.py` 84 PASS · 0 FAIL (33.2 s) · `test_ca_s0_census.py` 186 PASS · 0 FAIL (9.3 s) · 이 셋은 봉인 기록 폴더를 읽지 않는다 (`rint2_seal` 0 건 [코드 grep]) → G′ 도 같은 입력 | `evidence/e14_gate_tests_docs.txt` |
| 도구 | `make_sealed_copy.py --selftest` · 같은 입력 두 번 | 17/17 · 두 번 출력 전 파일 같음 (11-17 현장 반영 조각 · G) | `evidence/e11_make_sealed_copy.txt` · `evidence/make_sealed_copy_manifest.json` |
| v1 표 | v1 (가) 표가 적은 줄 번호 65 개 | 65/65 맞음 (핀 판) | `evidence/e8_v1_table_lines.txt` |

## 1저자 결정 (11-17 · 봉인 후보 Q1 – Q8 · *"권고대로해 · 이런걸로 병목 만들지마"* · 이 후보가 그대로 쓴 것)

| # | 결정 | 반영 자리 |
|---|---|---|
| Q1 | 봉인 꼴 = 봉인본 새 파일 `docs/reviews/rint2_seal_<봉인 날짜>/registration_R_sealed.md` (원본 등록 R = 핀 판 그대로 + 머리 표지 한 줄 · `scripts/` 무변경 · ⑥ 다시 없음) · 모든 사슬 단계 명령에 `--registration <봉인본>` · S0 단계 2 명령에 `--r-doc <봉인본>` | 도구 · R-00 · R-MARK · R-09 · R-10 · K-01 – K-05 |
| Q2 | 12 단위 · 저장본 실행 줄 = `sh` 블록 (K01 은 `bash` 만 읽는다) + 사슬 argparse 대조 기록을 봉인 기록에 | R-10 · K-03 · 증거 ③ (봉인 꼴 커밋의 `evidence/`) |
| Q3 | 계획 자리 = `docs/data/rint2_r_plan_<봉인 날짜>/ca1_plan.json` · 꼴 = indent 1 · sort_keys · 끝 줄바꿈 없음 · schema `rint-r-plan-v3` (문서의 "v2 · 칸 11" = 낡은 글 → 표지) | R-05 · K-02 · §라 |
| Q4 | R 저장본 = 기계마다 새 빈 폴더 `~/ca1_cjstore` (⑥ · S0 시험 저장본 안 씀) | R-10 · R-13 §10-6 ③ · K-03 (1) (2) |
| Q5 | 원장 넘김 = 사슬과 같은 잠금 파일에 `flock` (gabia 에 없으면 "그 기계 사슬이 시작 확인 뒤 도는 중일 때만 넘긴다" · 11-17 현장 = 두 기계 다 있음 → 이 규칙 = 한정만) | R-13 §10-7 ① · K-03 (2) (5) |
| Q6 | 사다리 P0 = kgy · P1 = gabia · 12 단위 첫 배정 kgy 7 · gabia 5 · 합치는 기계 = kgy · 합친 폴더 `ca1_predict` · `ca1_predict_x` (봉인 밖) | R-08 · R-10 · R-13 §10-7 ⑤ · K-03 (1) (6) |
| Q7 | 넘침 점 안전 규칙 어림 = 3 판 §3-3 (4) "팔 전체" 꼴 | R-13 §10-8 ⑩ · K-03 (6) (줄 + 셈 한 줄) |
| Q8 | 감도 (FIBRE · UNREG · GRID · SVORDER) 경로 = R 시작 전 따로 (이 후보 밖 · ⬜) | R-10 끝 줄 |
| 그대로 ⬜ | 결과 전 등록 넷 (Codex 2/2 회신 뒤 · S0 단계 2 전 1저자 · `sv_cf_scope` = 10-23 결정 all3 기록) · 봉인 날짜 · 가지 이름 · 봉인 뒤 현장 확인 (PIN = 봉인 커밋) · 두 기계 조립 같음 | §가-2 · §바 |
| 11-17 현장 뒤 | R venv = 두 기계 `~/dem-venv` (3.8.10 · 1.24.4 · 1.10.1 · cupy 12.3.0 = kgy 와 패치 판까지 같음 · gabia `~/rint-venv38` 3.8.20 = 손대지 않음 · FAM 등록 951 줄) · 봉인 직전 확인 줄 = 두 기계 같은 한 줄 · 기대 `3.8.10 1.24.4 1.10.1 12.3.0` (메인 결정 · 1저자 "병목 만들지마" 권고 기본) | R-10 (0) · R-13 §10-8 ④ · K-03 (1) (2) |
| 앞의 결정 | maxiter 5,000,000 (`p2_extra` = `--step3-maxiter 5000000`) · `max_hours` 168 · `max_attempts` 8 · 허용 기계 kgy · gabia · v100 · env_unit (3.8 · 1.24.4 · 1.10.1) · 원장 공유 (가-2) · 넘침 점 112 h 규칙 · 마감 12-05 24:00 KST (3 판 Q1 – Q3 · Q9 – Q11 · 10-23 Q11) | §가 · R-10 · R-12 · R-13 |

## (가) 봉인 숫자 · 실행 정책 · 계획 칸 값 표 (v1 그대로 + 봉인본 자리 · 줄 번호 = `64e4d213e` 판 · v1 표의 줄 번호 65 개 = 이 후보가 다시 대조 65/65 [실측 · `evidence/e8_v1_table_lines.txt`])

### 가-1. 계획 칸 (후보 값 = `plan_candidate.json` · 봉인 꼴 커밋 자리 `docs/data/rint2_r_plan_20261120/ca1_plan.json`)

| 칸 | 값 (후보) | 근거 줄 | 사슬이 대조하는 곳 (`scripts/rint_r_chain.py` · 그 밖은 파일명) |
|---|---|---|---|
| `schema` | `"rint-r-plan-v3"` | 사슬 `PLAN_SCHEMA` 301 줄 · 칸 `PLAN_KEYS` 302 줄 | `plan_form_problems` 1238–1239 (다르면 `PLAN_INVALID`) · `load_plan` 1265 |
| `len_law` | `"len_scaled_v0"` | `scripts/carbon_junction.py` 90 줄 `CJUNC_LEN_LAW` · ⑥ 시도 4 env (`docs/data/rint2_probe6_a4_20261116/command.txt`) | `plan_form_problems` 1240–1241 · `plans_cross_problems` 1426–1427 · `ca_s0_census.verify_plan_commit` (len_law) |
| `unreg_law` | `"cut"` | 사슬 `PLAN_UNREG_MAIN` 322 줄 · 등록 R §2-1 86 줄 | `plan_form_problems` 1242–1243 · `plans_cross_problems` 1428–1429 |
| `s_min_um` | `0.0` | 등록 R §2-1b 99–103 줄 (1저자 11-09 = 0 µm) · ⑥ 시도 4 env `CJUNC_S_MIN_UM=0.0` | `plan_form_problems` 1244–1247 · `plan_env` 1391 · §2-1b 산문 ↔ 블록 = 사람 대조 (등록 R 108 줄) |
| `tol_ff_um` | `0.07381254285530132` | S0 계획 (11-16) `values_um.tol_ff` | `plans_cross_problems` 1419 (같은 float) · `verify_plan_commit` (≠ S0 = 거부) |
| `step3_rtol` | `1e-12` | `scripts/step3_conv_cert.py` 66 줄 `CERT_RTOL_MAX` · 등록 R §3-5 | `plans_cross_problems` 1425 · `plan_env` 1391 |
| `p2_extra` | `"--step3-maxiter 5000000"` | 3 판 Q2 · 3 판 §3-4 | `plan_form_problems` 1248–1249 · `plan_env` 1395 (`P2_EXTRA`) · 러너가 `--step3-rtol` 를 거부 (등록 R 336 줄) |
| `max_ladder_points` | `null` (⬜) | §가-2 | `plan_form_problems` 1250–1252 · `require_plan_numbers` 1287 · `ladder_cap` 1386 |
| `calib_rj_ratio_max` | `null` (⬜) | §가-2 | `plan_form_problems` 1253–1255 (`'none'` = 상한 없음 · 320 줄) |
| `sv_cf_threshold` | `null` (⬜) | §가-2 | `plan_form_problems` 1256–1258 (유한 ≥ 1) · 예측 6887 · 합치기 7356 |
| `sv_cf_scope` | `null` (⬜) | §가-2 | `plan_form_problems` 1259–1260 (`R_j0` · `all3` · 321 줄) · 예측 6887 · 합치기 7356 |
| `exec_policy.max_hours` | `168` | 3 판 Q3 · 3 판 §3-4 | `exec_policy_problems` 1215–1217 · `exec_check_or_stop` 1303 (`--max-hours` 정확히 · 다르면 `NOT_REGISTERED`) · 마감 = 사다리 6683 · 예측 6895 · 합치기 7392 |
| `exec_policy.max_attempts` | `8` | 3 판 Q10 (§3-6c) | `exec_policy_problems` 1218–1220 · `attempt_limit_problem` 3562 (`ATTEMPT_LIMIT`) |
| `exec_policy.allowed_machines` | `["kgy","gabia","v100"]` | 등록 R §10-4 589 줄 (1저자 10-23 *"kgy, gabia에서 돌릴거야"* · Q11 · v100 = 요청할 때만) | `exec_policy_problems` 1221–1224 · `exec_check_or_stop` 1306 (`MACHINE_NOT_ALLOWED`) · `stage_machine_problem` 1367 |
| `exec_policy.env_unit` | `{"numpy":"1.24.4","python_minor":"3.8","scipy":"1.10.1"}` | 현장 예행 11-12 · 11-16 S0 보고 `code` 칸 (3.8.10 · 1.24.4 · 1.10.1 · `docs/data/rint2_s0_sbe_20261116/ADOPTION_CHECK.md` E1) · ⑥ 시도 4 `env.txt` | `exec_policy_problems` 1225–1228 · `exec_check_or_stop` 1308 → `env_seal_problem` 1313 (`CODE_PIN_MISMATCH`) · 칸 이름 = `run_contract.ENV_UNIT_KEYS` (1597 줄) |
| `exec_policy` 규칙 칸 넷 | `retry_rule` `pre_result_only_v1` · `same_config` `plan_code_bed_env_v1` · `adoption` `first_not_pre_result_v1` · `attempt_dir` `attempt_<n>` | 사슬 `EXEC_POLICY_RULES` 311–312 줄 | `exec_policy_problems` 1214 (다르면 `PLAN_INVALID`) |

### 가-2. 결과 전 등록 넷 — 지금 등록 글의 권고 · 기본값 (⬜ 그대로 · 등록 R §11 ④ = Codex 회신 뒤 · S0 단계 2 전 1저자)

| 칸 | 등록 글이 지금 말하는 것 | 근거 줄 |
|---|---|---|
| `max_ladder_points` | "점 수 상한 12 … **상한 = ⬜ 결과 전 등록**" · RCA-01 회로 = 정확히 12 점 · 천장 근처 꺾임 망 = 13 점 · 사슬 = 기본값 없음 (`ladder_cap` 1386) · 3 판 시간 표 = 법칙마다 12 점 가정 | 등록 R §3-2 127 줄 · 3 판 §3-4 끝 표 |
| `calib_rj_ratio_max` | "폭 상한 (넘으면 `CALIB_UNIDENTIFIED`) = ⬜ 결과 전 등록" · 권고 숫자 없음 · 사슬 값 `'none'` = 상한 없음으로 등록 | 등록 R §3-2b ④ 135 줄 · 사슬 320 줄 |
| `sv_cf_threshold` | "비 문턱 (넘으면 `SV_DEPENDENT` · 차단) = ⬜ 결과 전 등록" · 권고 숫자 없음 · 사슬 꼴 = 유한 ≥ 1 | 등록 R §5-6 216 줄 · 사슬 1256–1258 |
| `sv_cf_scope` | "세 R 전부로 할지 = ⬜ 1저자 … 봉인 커밋 때" · 기록된 결정 = **all3** (재검토 수정 계획 Q5 (가) · 1저자 10-23 *"다 권고대로 해줘"* = Q1–Q8 전부 (가) · 등록 R §10-4 573 · 584 줄) — 칸 표시는 봉인 때 | 등록 R §5-6 216 · §10-5 사 ① 634 줄 · `docs/reviews/rint2_rereview_fix_plan_20261022.md` 55–56 · 96 줄 |

### 가-3. 해시 줄 · 블록 · 봉인본 자리 (v2 = 봉인본에만 채운다 · 원본 자리는 ⬜ 그대로)

| 자리 | 봉인 값 | 대조 |
|---|---|---|
| 봉인본 자리 | `docs/reviews/rint2_seal_<봉인 날짜>/registration_R_sealed.md` (보기 `docs/reviews/rint2_seal_20261120/registration_R_sealed.md` · 도구가 만든다) | 사슬 `--registration` · S0 `--r-doc` 의 값 (증거 ③) |
| 원본 자리 머리 표지 (R-MARK · 제목 줄 바로 뒤 한 줄) | 봉인본 자리 · 봉인 커밋 (= 그 파일을 넣은 커밋) 을 가리킴 · 해시 줄 머리 · 블록 표지 · 자리 줄 글자 없음 | 도구 확인 · 원본 자리 `registration_plan_hash` = `PLAN_HASH_UNREGISTERED` (증거 ④′) |
| 봉인본 §2-1 표 "계획 해시" 줄 (원본 80 줄) 끝 칸 | 봉인 계획 파일 바이트의 sha256 (도구가 채움 · 넷을 채운 뒤 · 후보 f09b3efb… 는 **봉인 값 아님**) | `registration_row_hash` 1145 (그 줄 하나뿐) · `check_plan_registered` 1399 · `verify_plan_commit` |
| 봉인본 "S0 계획 해시" 줄 (원본 81 줄) 끝 칸 | `6346d9ed5fda248b89d1e28dbcb35c90d67264f060be345673c7da63f9924520` (11-16 S0 · 정준 바이트) | `registration_s0_hash` 1167 · `verify_plan_commit` |
| 봉인본 자리 줄 (원본 83 줄) 바로 아래 | 봉인 계획의 `--stage plan-doc` 출력 그대로 (도구가 넣음) | `plan_doc_problem` 1339 · 사다리 6657 · 예측 6881 · 합치기 7348 · 판정 |

## (나) 봉인본 글 (`registration_R_insert.md` · 자리 = 원본 줄 · 넣는 것 = 도구)

| 조각 | 자리 (원본) | 무엇 (v1 에서 바뀐 것) |
|---|---|---|
| R-MARK | 1 줄 뒤 · **원본 자리에만** | 머리 표지 한 줄 (새로) |
| R-00 | 1 줄 뒤 · 봉인본에만 | 봉인본 머리 절 — "이 문서 = 등록 R 봉인본 · 원본 = … @`64e4d213e` · 바뀐 곳 = 이 절 + 조각뿐 · 다시 만드는 도구 · 읽는 법 (`--registration` · `--r-doc`) · `<봉인 커밋>` 구하는 줄 · 줄 번호 = 원본 기준" (새로) |
| R-01 – R-04 | 72 · 73 · 76 · 77 줄 숫자 칸 | u · tol_ff · tol_P · tol_sj = 0.07381254285530132 µm · 긴 접촉 칸 (11-16 보고 수 · s_min 0 µm) — 채택 확인 `ADOPTION_CHECK.md` 를 근거에 더함 |
| R-05 · R-06 | 80 · 81 줄 | 계획 해시 (v3 표지 · 꼴 · **끝 칸 = 도구가 계획 sha256**) · S0 계획 해시 `6346d9ed…` |
| R-07 | 83 줄 뒤 | 계획 숫자 블록 = **도구가 핀 사슬 `--stage plan-doc` 출력을 넣는다** (조각 안 = 자리표 한 줄 · 블록 표지 글자 없음) |
| R-08 | 334 줄 뒤 | 기계 = kgy · gabia · P0 = kgy · P1 = gabia · 첫 배정 7 / 5 · 합치기 = kgy (Q6) |
| R-09 | 391 줄 뒤 (bash 블록 주석) | 이 블록 = 인자 계약 꼴 · 실제 줄 = §10-1b · 모든 사슬 명령 `--registration` · S0 `--r-doc` |
| R-10 | 458 줄 뒤 | **§10-1b** — 경로 · 등록 문서 = 봉인본 (사슬이 읽는 단계 = 사다리 · 예측 · 판정 · plan-doc [코드 6656 · 6880 · 7347 · 7715 · 8606 줄] · 원장 · recover · 다시 판정은 읽지 않음 [코드 8260 줄] · 그래도 한 규칙으로 붙임) · 기계 · 숫자 · 저장본 · sh 블록 (0) 확인 → (1) **S0 단계 2 (`--r-doc`)** → (2) 원장 시작 → (3) 사다리 → (4) 단위 → (5) 첫 합치기 → (6) 넘침 점 · 끝 합치기 → (7) 판정 · 다시 판정 → (8) recover — 사슬 명령 13 줄 전부 `--registration ~/dem-ca1/<봉인본>` |
| R-11 · R-12 | 590 · 601 줄 뒤 | 허용 기계 값 · 시간 상한 168 h (근거 = 3 판 §3-4 · stoic 기록은 봉인 기록 §사 가 가리킴) |
| R-13 | 660 줄 뒤 | **§10-6 저장본** (③ = `~/ca1_cjstore` 새 빈 폴더 · Q4) · **§10-7 원장 공유 (가-2)** (① 넘김 = 사슬 잠금 파일 `flock` + 없는 기계 규칙 · Q5 · 11-17 현장 = 두 기계 다 있음 → 규칙 = 한정 · ⑤ 배정 · 폴더 · Q6) · **§10-8 운영 규칙** (⑩ 안전 규칙 + 어림 꼴 = 3 판 "팔 전체" · Q7) |
| R-14 · R-15 | 674 · 696 줄 뒤 | §11 ⑥ 기록 · §12 실행 기록 (봉인 커밋 = 이 봉인본을 넣은 커밋 · S0 단계 2 `--r-doc` · R `--registration`) |

- v1 의 저장본 개정 문장 (2 판 E-2 의 4 ①–④ 처분 · §10-6) · 원장 공유 (§10-7) · 운영 규칙 (§10-8) 본문은 그대로 이어받았다 (자리 · 줄 번호 = 이 후보가 핀 판에서 다시 대조 · 고친 것 = `_ledger_lock_path` 3164 줄 (v1 의 다른 표기 없음) · 결정 Q4 – Q7 문장).
- 도구가 본 것 (봉인본): 원본 줄 747 개가 순서대로 다 있고 (지움 없음) 바뀐 줄 = R-01 – R-06 의 끝 칸 · 가운데 칸 자리뿐 · 블록 표지 1 · 1 · 해시 줄 둘 1 · 1 · 자리 줄 글자 1 줄 · 사슬 `registration_plan_hash` = 계획 sha256 · `registration_s0_hash` = S0 계획 sha256 · `plan_doc_problem` None [실측 · `_manifest.json` `checks` 11 개 참].

## (다) 명령 문서에 넣을 블록 (`commands_doc_insert.md` · 명령 문서는 제자리 고침)

| 조각 | 자리 (원본) | 무엇 |
|---|---|---|
| K-05 | 425 줄 뒤 (§2-3 bash 블록 주석) | 이 블록 = 인자 계약 꼴 · 실제 S0 단계 2 = §3-1b (2b) (`--r-doc <봉인본>`) · 기본 `--r-doc` = 관문 거부 (틀린 결과 없음) (새로) |
| K-01 | 480 줄 뒤 (§3 bash 블록 주석) | 실제 실행 = 봉인본 · `--registration` · 한 기계 예측 줄 = 이 경로 아님 · `--untracked-files=no` 는 사슬보다 덜 본다 |
| K-02 | 486 줄 뒤 | 계획 = v3 · 칸 12 · 봉인 계획 자리 · 대조 대상 = 봉인본 해시 줄 · 실제 실행 = `--registration` |
| K-03 | 564 줄 앞 | **§3-1b** — 머리 (실행 정책 · 등록 문서 = 봉인본) · (1) 기계마다 바탕 표 (봉인본 · 저장본 = 새 빈 폴더 · 잠금 파일) · (2) 두 기계 준비 (실행 트리 = 기존 트리 저장소에서 새로 뗌 · venv 확인 줄 = 두 기계 같은 한 줄 · 기대 `3.8.10 1.24.4 1.10.1 12.3.0` · 봉인본 sha256 · 해시 줄 grep · `--check-doc --registration` · 11-17 현장 사실 한 묶음) · **(2b) S0 단계 2 (same-version 손 확인 + `--r-doc`)** · (3) 원장 시작 · (4) 시도 꼴 · (5) 원장 넘김 (`flock` · 없는 기계 규칙 = 11-17 현장 뒤 한정 · 넘김 기록 표에 잠금 칸) · (6) (가-2) 정상 흐름 (0 번 = S0 단계 2) · rc 3 가르기 · recover · 첫 배정 · 안전 규칙 + 어림 셈 한 줄 · (7) 합치기 · 넘침 점 · 판정 · 다시 판정 · recover · (8) 운영 규칙 (10 = `--registration` 빼지 않기) — 사슬 명령 14 줄 전부 `--registration` |
| K-04 | 590 줄 뒤 | §5 기록 = 넘김 기록 자리 · 등록 = 봉인본 |

- 도구가 본 것 (명령 문서): ```` ```bash ```` 블록의 주석 아닌 줄 = 원본과 같다 (시험 K01 이 읽는 인자 그대로 · 울타리 셈 = K01 의 `doc_tool_commands` 와 같은 꼴) · 블록 표지 없음.  K01 자체 = ① 안에서 PASS [실측].
- 넘김 줄 (v1 실측 · scratch 두 가짜 홈 · git 2.43 · flock 2.39.3 · 11-17 현장 = kgy git 2.25.1 · gabia 2.43.0 · 두 기계 `bundle create --all` 묶음에 `HEAD` 실림 · `flock` kgy util-linux 2.34 · gabia 2.39.3 [기록 · 1저자 현장 출력]): 보낸 쪽 `flock` + `bundle create --all` + 세워 두기 → 받는 쪽 `clone -b` → 다시 보낸 쪽 → 세워 둔 사본 되살려 `pull --ff-only` · 끝 커밋 같음 · `git bundle verify` 는 저장소 밖에서 안 돈다 → 받는 쪽 확인 = `sha256sum` + `git bundle list-heads` + `rev-parse HEAD` [기록 = v1 README §다].
- 잠금 파일 = `<원장>/.git/rint_r_ledger.lock` (사슬 `LEDGER_LOCK_FILE` 3060 줄 · `_ledger_lock_path` 3164 줄) · 대기 상한 120 s = `LEDGER_LOCK_WAIT_S` 3061 줄 [코드].
- 넘침 점 어림 꼴 확인 [실측 · 산술]: 3 판 값 (kgy T_hit 4,932 · T_first 9,067 · gabia 6,682 · 10,817 s · r 2.933 · 3 판 §3-2 595 · 597 줄) → kgy 48.99 h · gabia 60.40 h = 3 판 §3-3 (4) 의 49.0 · 60.4 h · 112 h = 168 × 2/3.

## (라) R 계획 JSON (v1 그대로 · 넷 null 후보 · 봉인 때 다시)

- **자리** = `docs/data/rint2_r_plan_<봉인 날짜>/ca1_plan.json` (Q3) — 풀이 코드 목록 다섯 경로 밖 · S0 단계 2 관문 조건 = 리포 상대 · ASCII · 빈칸 없음 · `..` 없음 [코드 `verify_plan_commit`].  SHA256SUMS 는 두지 않는다 (권고 — 해시 = 봉인본 해시 줄 하나 · 같은 값을 두 자리에 적지 않는다).
- **꼴** = `json.dump(plan, f, indent=1, sort_keys=True)` · 끝 줄바꿈 없음 · `s_min_um` = `0.0` · `max_hours` = `168` (Q3).
- **후보** = `plan_candidate.json` 666 B · sha256 f09b3efbe50d104d7e294a6b3dce8bda5214d267a4fecfc99b7e50023396d3c4 (v1 과 바이트 같음 [실측]) · 결과 전 넷 null.  블록 = 핀 사슬 `--stage plan-doc` 출력 (끝 줄바꿈 없는 블록 바이트 sha256 0a62a8b5c58452b60b628926a4cbeb2e071403bd7a165ba83cb36001b3cc7851 · 화면 출력 (끝 줄바꿈 하나) = v1 `plan_doc_block.txt` 의 24ad274f… 와 같은 바이트 [실측]).
- **봉인 때** = 넷을 채운 계획 파일 (꼴 위 그대로) → `make_sealed_copy.py --plan <봉인 계획> --seal-date <날짜>` → 봉인본 해시 칸 · 블록이 바뀐다 (사람이 옮기지 않는다).  `sv_cf_scope` 값 = 10-23 결정 all3 (기록) · 나머지 셋 = Codex 회신 뒤 1저자.
- S0 계획 (11-16) = `docs/data/rint2_s0_sbe_20261116/files/ca1_s0_sbe_20261116T004809Z_q14final/cjunc_plan.json` 1,485 B · sha256 6346d9ed… · 채택 확인 = 그 폴더 `ADOPTION_CHECK.md` (E1–E4 · T1–T3 기대대로 [기록]).

## (마) 봉인 커밋 구성

### 마-1. 파일 (`64e4d213e` 위 · 문서 · 자료만 · 표 = 봉인 꼴 커밋에서 기계로 가름 `evidence/e10_seal_files.txt`)

(표 = 증거 e10 그대로 (G) · 경로 `20261120` = 보기 날짜 · G′ = 같은 표에서 봉인 기록 폴더만 36 (증거에 G 결과 · `e12` · `e13` · `e1` F · G 판을 더함) [실측 · scratch evidence/raw/G2_seal_files.txt (scratch 후보 폴더 · 리포 밖)])

| 상태 | 자리 (폴더는 묶음) | 파일 수 | 다섯 경로 밖 | CODE_FILES 20 · S0 일곱 밖 | 규율 검사 입력 밖 |
|---|---|---|---|---|---|
| A | `docs/data/rint2_probe6_a3_20261116` | 13 | 밖 | 밖 | 밖 |
| A | `docs/data/rint2_probe6_a4_20261116` | 13 | 밖 | 밖 | 밖 |
| A | `docs/data/rint2_r_plan_20261120` | 1 | 밖 | 밖 | 밖 |
| A | `docs/data/rint2_s0_sbe_20261116` | 14 | 밖 | 밖 | 밖 |
| M | `docs/reviews/claims.json` | 1 | 밖 | 밖 | **안** |
| M | `docs/reviews/rint2_dev_probe_ledger_20261026.md` | 1 | 밖 | 밖 | 밖 |
| M | `docs/reviews/rint2_kgy_commands_20261020.md` | 1 | 밖 | 밖 | 밖 |
| A | `docs/reviews/rint2_q14_finalpin_preparation_20261113` | 2 | 밖 | 밖 | 밖 |
| A | `docs/reviews/rint2_seal_20261120` | 31 | 밖 | 밖 | 밖 |
| M | `docs/reviews/rint_carbon_additive_registration_R_draft_20261020.md` | 1 | 밖 | 밖 | 밖 |

- git diff --quiet 64e4d213e826 HEAD -- <다섯 경로> → rc 0 (같음 = 원장 §2 같은 핀)
- CODE_FILES 20 · S0 일곱 7 · 다섯 경로 · CODE_FILES · S0 일곱 안의 바뀐 파일: 없음
- 규율 검사 입력 안의 바뀐 파일: ['M docs/reviews/claims.json'] (→ 그 판으로 규율 검사를 직접 돌려 본다)

- **ⓐ 넣는 것** — 봉인본 (새) · 원본 자리 (표지 한 줄) · 명령 문서 (K 조각) · 개발 탐침 원장 (stoic-next 바이트 · §2 핀 칸 · §3 시도 3 · 4) · 계획 (새) · 자료 폴더 셋 (`docs/data/rint2_s0_sbe_20261116/` 14 · `docs/data/rint2_probe6_a3_20261116/` 13 · `docs/data/rint2_probe6_a4_20261116/` 13 = stoic-next 바이트 그대로 [실측 blob 대조 40/40]) · q14 준비 두 파일 (§마-4) · 봉인 기록 폴더 (`README.md` = 이 문서를 봉인 값으로 고친 판 · `tools/` = 도구 + 조각 둘 · `evidence/`) · `docs/reviews/claims.json` (ⓒ).
- **ⓑ 넣지 않는 것** — 시간 다시 어림 3 판 (`docs/reviews/rint2_time_reestimate_20261111/README.md` 끝 절 + `v3/`) · `docs/data/rint2_s0_sbe_20261113/` · `docs/data/rint2_q11_gpu_check_kgy_20261116/` — stoic 기록 · 봉인 파일이 이 가지 안에서 가리키지 않는다 · 3 판은 봉인 기록이 stoic 커밋 · 경로 · blob 으로 가리킨다 (§사 · §마-4).
- **ⓒ `docs/reviews/claims.json` = stoic 바이트 (blob 3f8324543… = 원격 stoic 2da71fe5a 판)** — 11-16 S0 kit JSON (가린 사본 · 숫자 원자료) 안 숫자가 철회값 등록부의 두 패턴 (CL-41 · CL-33 의 글자 · 여기 옮겨 적지 않는다) 과 우연히 겹쳐, 핀 판 등록부 그대로면 게이트 철회값 스윕이 4 건으로 실패한다 [실측 · `evidence/e6_ban_pin_claims.txt`].  stoic 이 같은 사본을 두 패턴 `allowed_in` 에 넣은 커밋 = `2da71fe5a` (원격 stoic · "11-08 · 11-13 사본과 같은 처리") · 핀 판 ↔ stoic 판 등록부 차이 = 그 두 `allowed_in` 덩어리뿐 (+6 −2 [실측 git diff]) → stoic 바이트를 그대로 넣는다 (나중에 합칠 때 같은 덩어리라 충돌 없음 · 11-13 줄은 이 가지에서 걸리는 파일 없는 글롭 · `allowed_in` 은 거르는 글롭으로만 쓰이고 실재 검사 없음 [코드 `check_review_findings.py` 580 줄]).  ⚠ `claims.json` 은 **규율 검사 입력**이다 (v1 §마-2 조건 "네 자리를 바꾸지 않는다" 를 이 한 파일에서 깬다) → 대신 이 등록부로 규율 검사 rc 0 을 직접 보였다 (⑦) · 풀이 코드 목록 밖 (원장 §3 54 줄 = 규율 검사 입력은 목록 밖) → ⑥ 다시 없음.
- **ⓓ 도구 · 조각을 봉인 기록 폴더에 넣는 까닭 (권고)** — 봉인본 바이트를 리포 안에서 다시 만들 수 있게 (핀 판 원본 + 조각 + 계획 → 같은 바이트) · `scripts/` 밖 (`.py` 지만 규율 검사 = `scripts/**/*.py` 만 · `check_method_discipline.py` 340–345 줄 · 2 판 `time_budget_v2.py` 선례) · 풀이 코드 목록 · CODE_FILES · S0 일곱 밖.
- **ⓔ 각 파일이 경계 밖인지** = 표의 세 칸 (기계로 가름 · 경계 = 원장 §3 54 줄의 다섯 경로 · 사슬 `CODE_FILES` 20 (335–340 줄) · `S0_SAME_FILES` 7 (345–346 줄) · 규율 검사 입력 = `scripts/**` · `docs/reviews/claims.json` (53 줄) · `docs/manuscript/methods_simulation_v7_draft.md` (2125 줄) · `.github/workflows/discipline.yml` (806 줄)) — `claims.json` 만 규율 검사 입력 안 (ⓒ).

### 마-2. 러너 규율 검사가 봉인 커밋에서 통과할 조건 (R3-08)

- 러너가 런마다 `python3 scripts/check_method_discipline.py` 를 돌리고 실패면 `exit 2` [코드 · 러너 `scripts/sdcp_gain_vox015_8arm.sh` 724–731 줄 · 통과 = 734 줄] · 그 검사가 읽는 리포 파일 = `scripts/` 아래 + `docs/reviews/claims.json` + 원고 + CI 설정 · git 을 부르지 않는다 [코드].
- v2 = `claims.json` 을 stoic 바이트로 바꾼다 (§마-1 ⓒ) → **봉인 꼴 커밋 (최종 등록부) 에서 핀 판 규율 검사 = 0 오류 · rc 0 (경고 17)** [실측 · ⑦].  핀 판 등록부로도 0 오류 · rc 0 (경고 17) [실측 · 커밋 B].
- R 동안 실행 트리 · 봉인본 · 원본 자리 무변경 (봉인본 §10-8 ④) — 사슬이 단계마다 등록 문서 해시 줄 · 블록을 읽고 판정 JSON 이 등록 문서 sha256 · 절대 경로를 싣고 다시 판정이 바이트 대조 [코드 7715–7717 · 8260 줄].

### 마-3. v1 의 게이트 문제 (PC18 · EP06 · E17) — 넷째 길로 닫힘

- v1 = 원본 자리에 블록을 넣으면 시험 PC18 · EP06 · E17 실패 [v1 실측].  v2 = 원본 자리는 표지 한 줄뿐 (블록 · 해시 = 봉인본) → 봉인 꼴 커밋에서 **사슬 시험 전체 506/506 · E17 1/1** [실측 ① ②] (넷째 길 확인 scratch `/tmp/claude-0/-home-user-Yonghoon-DEM-DFT/81c0ad95-542f-503b-9cf7-2f6a678a4b5b/scratchpad/rint/seal_opt4/opt4_check.py` 의 K01 · PC18 · PC20 · EP06 4/4 · E17 1/1 을 전체 시험으로 넓힘).
- 원본 자리를 읽는 다른 시험 (게이트에 있음) = `scripts/test_ca_s0_census.py` · `scripts/test_ca_ext_z3.py` (머리 글 언급) · `docs/reviews/rint2_probe6_prep_20261110/tools/test_probe6_read.py` (§10-1 블록 · 원장 §3 줄을 읽는다) — 봉인 꼴 커밋 G 에서 셋 다 돌림: `test_probe6_read.py` 357/357 · `test_ca_ext_z3.py` 84/84 · `test_ca_s0_census.py` 186/186 · 셋 다 rc 0 [실측 · `evidence/e14_gate_tests_docs.txt` · 이 셋은 봉인 기록 폴더를 읽지 않는다 (`rint2_seal` 0 건 [코드 grep]) → G′ 도 같은 입력].

### 마-4. 봉인 가지 문서 참조 (`scripts/check_doc_refs.py` · 도달 기준 = 원격 추적 ref + HEAD [코드 163–167 줄]) — 처분

- 방법: scratch 에 본 리포의 `git clone --shared --no-checkout` → 원격 추적 ref 를 지우고 `+refs/remotes/origin/*:refs/remotes/origin/*` 로 다시 받음 (본 리포 `refs/remotes/origin/*` 153 개와 이름 · 객체 같음 [실측]) → `64e4d213e` 위 scratch 가지에 봉인 꼴 커밋 → 그 트리에서 핀 판 검사기.  기준선 (핀 트리) = rc 0 (문서 2,080 · 커밋 13,502 [실측]).
- stoic-next 쪽 기록을 다 넣은 첫 판 = **없는 경로 4 · 없는 커밋 1** [실측 · `evidence/e9_check_doc_refs.txt` 첫 절]:

| 깨진 참조 | 가리키는 곳 | 처분 · 까닭 |
|---|---|---|
| `docs/data/rint2_s0_sbe_20261116/ADOPTION_CHECK.md` → `docs/reviews/rint2_q14_finalpin_preparation_20261113/s0_preregistration.md` · `block_manifest.json` (2 건) · 같은 폴더 `README.md` → `s0_preregistration.md` (1 건) | 원격 `codex/rint-q14-prep-1113` · 원격 stoic (같은 blob) · 핀 트리엔 없음 | **봉인 가지에 넣는다** (두 파일 · blob = 원격 q14 가지 = 원격 stoic [실측]) — S0 계획 (S0 단계 2 · 사다리 `--s0-plan` 의 입력) 이 든 자료 폴더의 결과 전 등록 · 블록 구성이라 그 폴더와 한 묶음 · 자료 폴더 바이트는 고치지 않는다 |
| 3 판 README (stoic 판 · 이 가지에 넣으면) → docs/handoff_return_to_stoic_knuth_20261117.md | 원격 stoic 2da71fe5a 판 (운영 인계 문서) | **3 판을 봉인 가지에 넣지 않고** 봉인 기록이 stoic 커밋 · 경로 · blob 으로 가리킨다 (§사) — 3 판 = stoic 기록 (시간 어림 · 결정) · 그 안의 참조가 stoic 운영 문서로 이어진다 · 사본 줄을 고치면 stoic 판과 바이트가 갈린다 |
| 3 판 v3/review3_internal_20261117/REVIEW.md (stoic 판) → 커밋 5a04acd15 | 본 리포 로컬 HEAD (원격 밖 · 지금 게이트 중) | 위와 같다 (`v3/` 를 넣지 않음) |

- 처분 뒤 = **rc 0 · 없는 경로 0 · 없는 커밋 0** (최종 봉인 꼴 커밋 G′ · 이 README 와 `evidence/` 포함) [실측 · G′ = scratch evidence/raw/G2_check_doc_refs.txt (scratch 후보 폴더 · 리포 밖) (그 커밋 자신의 출력이라 리포 사본에 못 넣음) · F = `evidence/e9_check_doc_refs.txt` 4b 절 (rc 0) · G (중간) = 같은 파일 4c 절 (없는 경로 2 = 이 README 가 가리키는 새 증거 둘이 G 의 증거 폴더에 아직 없던 판 → G′ 에서 넣음)].
- ⚠ 이 검사기는 한 백틱 안 `<커밋>:<경로>` 꼴을 경로로도 커밋으로도 읽지 않는다 [코드 `_RE_PATH` · `_RE_SHA`] → §사 의 stoic 가리킴은 검사기가 못 본다 → 이 후보가 `git cat-file -e` 로 따로 확인 [실측 · §사].

### 마-5. 차례 (제안 · v1 §마-4 를 고침)

1. Codex 2/2 (측정 결과 + 봉인 숫자 + 이 후보 · 발송 = 1저자) → GO.
2. 결과 전 넷 (Codex 회신 뒤 · 1저자) → 계획 파일 확정 → `make_sealed_copy.py` (봉인 날짜 · 가지 이름 · 봉인 계획 · 핀 판 원본 · 사슬 · S0 계획) → 출력 넷 + 봉인 기록 폴더 (`README.md` 봉인 값 · `tools/` · `evidence/` = 봉인 계획으로 ③ ④ ⑤ 다시) + §마-1 ⓐ 의 나머지 파일 → 봉인 커밋 하나 → 게이트 → push.
3. 현장 확인 (두 기계 · PIN = 봉인 커밋 · 명령 문서 §3-1b (2)) · 두 기계 조립 같음 (11-12 Q10) → S0 단계 2 (kgy · `--threshold-commit <봉인 커밋>` · `--r-doc <봉인본>`) → R (모든 사슬 단계 `--registration ~/dem-ca1/<봉인본>`).

## (바) [미확인] (질문 없음 — 작은 꼴 · 자리 · 이름은 이 후보가 권고로 정하고 위에 적었다: SHA256SUMS 안 둠 · 도구 · 조각 · 증거를 봉인 기록 폴더에 · 3 판을 넣지 않고 stoic 가리킴 · q14 두 파일 넣음 · `claims.json` = stoic 바이트 · K-05 · 넘김 기록 표 잠금 칸)

- 봉인 꼴 트리에서 리포 게이트 전체 (`scripts/check_all.sh`) 는 돌리지 않았다 — 원본 자리 · 원장을 읽는 게이트 시험 셋은 G 에서 돌렸고 (§마-3 · 증거 표 '게이트 셋') 나머지 단계 (`scripts/test_rint_r_chain_e2e.py` 전체 · `scripts/test_rint_r_chain_e2e12.py` 포함) [미확인].  (참고: 같은 원장 · 같은 S0 자료 폴더 · 같은 등록부 덩어리는 stoic 에서 그 쪽 게이트를 지났다 [기록 · 2da71fe5a 커밋 글] — 코드 판이 달라 이 가지의 증거가 아니다.)
- stoic 가리킴의 커밋 (b3481336c · b80f10d08 · c0c3b1ff5) = 지금 본 리포 로컬 가지 tmp-stoic-next 에만 (원격 밖 · push 전) [실측] → 봉인 때 원격 stoic 의 커밋으로 다시 확인 (`git branch -r --contains` · blob 이 같으면 그대로) [미확인].
- 원본 자리 머리 표지 한 줄 때문에 원본 자리의 줄 번호가 핀 판보다 1 밀린다 → 다른 문서의 "등록 R N 줄" (판 없이 적은 것) 은 봉인 커밋 판에서 N+1 — 판 (`64e4d213e`) 을 같이 적는 것이 안전 [실측 · 한정].
- 봉인본 sh 블록은 리포 시험이 읽지 않는다 (K01 = 원본 자리 · 명령 문서 bash 만) — 인자 대조 = 이 후보의 도구 (증거 ③) · 봉인 때 다시 [한정].
- **11-17 현장으로 닫힌 것** (두 기계 · 1저자 읽기만 · 메인이 전한 출력 [기록] · 이 후보가 기계에서 본 것 아님): `flock` 두 기계 다 있음 (kgy util-linux 2.34 · gabia 2.39.3) · 홈 경로 글자 = `[A-Za-z0-9._/-]` 안 · `git bundle create --all` 묶음에 `HEAD` 실림 (kgy git 2.25.1 = `refs/heads/master` · `HEAD` · gabia git 2.43.0) · 디스크 여유 kgy 240 GB (916 GB 중) · gabia 192 GB (422 GB 중) = SBE 저장본 파일 1,340,095,705 B 에 충분 · R venv = 두 기계 `~/dem-venv` (3.8.10 · 1.24.4 · 1.10.1 · cupy 12.3.0 · env_unit 통과 · gabia `~/rint-venv38` 3.8.20 = 쓰지 않고 손대지 않음) · 두 기계 기본 `python3` = 3.13 (conda base → venv 를 켠다) · gabia GPU = RTX A6000 49 GB (드라이버 595.58.03) · 실행 트리 = 기존 트리 (kgy `<HOME>/dem-p6-64e4d213e` · `<HOME>/dem-s0-64e4d213e` · gabia `<HOME>/dem-siteq-11a794674` · `<HOME>/dem-siteq-db86ce9b9` · gabia `dem-mt` 없음) 의 저장소에서 새로 뗀다 → 명령 문서 §3-1b (1) (2) (5) · 봉인본 R-10 (0) · R-13 §10-7 ① · §10-8 ④ 에 넣음 (그래서 v1 의 gabia 칸 · kgy git 2.25.1 칸은 닫음).
- **남은 현장** [미확인]: 기존 트리의 `origin` 이 봉인 가지를 받는지 (push 뒤 · 못 받으면 명령 문서 §3-1b (2) 의 `fetch` 줄 대신 묶음으로) · DBE 저장본 파일 크기 · 실침대 C 꼴 속도 [v1 그대로] · kgy GPU · 드라이버 (이번 출력에 없음 · (2) 의 `nvidia-smi` 줄로 적는다) · 봉인 뒤 PIN = 봉인 커밋 확인 · 두 기계 조립 같음 (11-12 Q10).
- 단위마다 SV 위끝 풀이 수 (S0 단계 2 census) · 넘김 지연 (사람 손 · 3 판 표 밖 · +7d) [v1 그대로].
- 1저자만 정할 것 (한 줄씩):
  - 결과 전 등록 넷 값 (Codex 2/2 회신 뒤 · S0 단계 2 전) · 봉인 날짜 · 가지 이름 — ⬜ 그대로.

## (사) stoic 기록 가리킴 (봉인 가지에 넣지 않은 것 · 커밋 · 경로 · blob · 이 후보가 `git cat-file -e` 로 확인 [실측 · `evidence/e12_stoic_refs.txt` = 8/8 있음 · stoic-next 세 커밋 = 원격 가지 0 개 · 2da71fe5a = 원격 가지 4 개])

| 무엇 | 가리킴 (`<커밋>:<경로>`) | blob · 나무 | 어디서 쓰나 |
|---|---|---|---|
| 시간 다시 어림 3 판 (README 끝 절 · §3-2 · §3-3 (4) · §3-4 · §3-6b · §3-6c = 3 판 Q1 – Q11) | `b3481336c:docs/reviews/rint2_time_reestimate_20261111/README.md` (그 꼴이 된 커밋 = b80f10d08 · 첫 반입 = c0c3b1ff5) | blob 8e4781ac4e89b5968e788ed21d486824ed3fcf45 | 봉인본 R-00 · R-12 · R-13 ⑩ · R-14 · 명령 문서 §3-1b (6) · 이 README §가 · §다 |
| 3 판 숫자 · 산술 | `b3481336c:docs/reviews/rint2_time_reestimate_20261111/v3/numbers_sources.tsv` · `…/v3/work/time_budget_v3.py` | 나무 (v3) b07ecf38e1fa620b3b9e81fc51b0f282670cfb1f | 같음 |
| 11-16 S0 kit JSON 의 등록부 `allowed_in` | 원격 stoic `2da71fe5a` (`docs/reviews/claims.json`) | blob 3f83245436d927dc534880fa32a958bc99ce7ddf | §마-1 ⓒ (봉인 가지에 같은 바이트) |

- 이 가지의 같은 경로 `docs/reviews/rint2_time_reestimate_20261111/README.md` = 2 판까지 (3 판 절 없음) · 원장 §2 핀 칸 문장의 근거 "11-17 Q5" 는 3 판 (위 가리킴) 에 있다.

## (아) 재현 (scratch · `python3 -I`)

```sh
# 핀 판 원본 둘 (읽기만)
git -C <본 리포> show 64e4d213e:docs/reviews/rint_carbon_additive_registration_R_draft_20261020.md > pin_reg.md   # sha256 219b6351…
git -C <본 리포> show 64e4d213e:docs/reviews/rint2_kgy_commands_20261020.md > pin_cmd.md                         # sha256 0fe96bb8…
# 봉인 꼴 파일 넷 (사슬 = 핀 판 scripts/rint_r_chain.py · S0 계획 = 11-16 · 날짜 = 봉인 때 1저자)
python3 -I make_sealed_copy.py --pin-reg pin_reg.md --pin-cmd pin_cmd.md --reg-insert registration_R_insert.md --cmd-insert commands_doc_insert.md \
    --plan <봉인 계획> --s0-plan <11-16 cjunc_plan.json> --chain <핀 트리>/scripts/rint_r_chain.py --seal-date <봉인 날짜> [--seal-branch <가지>] --out <빈 폴더>
python3 -I make_sealed_copy.py --selftest --chain <핀 트리>/scripts/rint_r_chain.py      # 17/17
# 증거 (봉인 꼴 사본) — evidence/tools/
python3 -I evidence/tools/check_sh_commands.py <사본> docs/reviews/rint2_seal_<날짜>/registration_R_sealed.md <새 가짜 홈>
python3 -I evidence/tools/check_s0_stage2_gate.py <사본> <고정물 값 도구 출력> <새 둘째 사본>
python3 -I evidence/tools/check_chain_functions.py <사본>
python3 -I evidence/tools/check_seal_files.py <사본> 64e4d213e8267bafaf3ae5af00a42996cefd3f33 HEAD
python3 -I evidence/tools/check_ban_new_text.py <사본> 64e4d213e8267bafaf3ae5af00a42996cefd3f33 HEAD 2da71fe5abbaa856beb87c39c2a49424e4c87bc7   # 등록부 기대 판 = stoic
python3 -I evidence/tools/check_v1_table_lines.py <사본> <사본> 64e4d213e8267bafaf3ae5af00a42996cefd3f33
python3 -I evidence/tools/make_committed_evidence.py evidence/raw evidence <사본>/docs/reviews/claims.json   # 리포 사본 증거 (요약 · 가림)
```

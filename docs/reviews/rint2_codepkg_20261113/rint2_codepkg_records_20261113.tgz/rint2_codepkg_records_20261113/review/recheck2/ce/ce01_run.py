#!/usr/bin/env python3
"""recheck2 RCP2-01 반례 묶음 — 갈래마다 새 저장본 폴더 · 새 코드 사본 → 드라이버 (그 갈래) → 같은 폴더를 '열쇠의 코드 판' 으로 돈 정직한 새 프로세스가
열어 적중인지 · 받은 원장 = 그 판으로 따로 지은 원장인지 (아니면 = 독 원장이 저장돼 뒤 런에 지속).
사용: python3 ce01_run.py <트리 scripts> <작업 폴더> [갈래 …]"""
import json
import os
import shutil
import subprocess
import sys

scripts, wd = sys.argv[1:3]
modes = sys.argv[3:] or ['honest', 'samesec', 'samesec_store', 'mtime_restore', 'samesize', 'symlink', 'preloaded']
HERE = os.path.dirname(os.path.abspath(__file__))
KEY = ('carbon_junction.py', 'step3_sigma.py', 'fibre_segment_raster.py', 'cjunc_store.py')
fx = json.loads(subprocess.run([sys.executable, os.path.join(HERE, 'ce01_setup.py'), scripts, wd], capture_output=True, text=True,
                               check=True).stdout.strip().splitlines()[-1])


def code_dir(name, mutant=False, link=False):
    d = os.path.join(wd, 'code_' + name)
    os.makedirs(d)
    for fn in KEY:
        src = fx['mut'] if (mutant and fn == 'fibre_segment_raster.py') else os.path.join(scripts, fn)
        if link and fn == 'fibre_segment_raster.py':
            real = os.path.join(wd, 'drv', f'orig_fsr_{name}.py')
            shutil.copyfile(src, real)
            os.symlink(real, os.path.join(d, fn))
        else:
            shutil.copyfile(src, os.path.join(d, fn))
    return d


def store_dir(name):
    d = os.path.join(wd, 'stores', name)
    os.makedirs(d)
    os.chmod(d, 0o755)
    return d


def run(cd, sd, mode):
    r = subprocess.run([sys.executable, os.path.join(HERE, 'ce01_drv.py'), cd, scripts, sd, fx['mfile'], fx['inp'], mode, fx['mut']],
                       capture_output=True, text=True, timeout=900, stdin=subprocess.DEVNULL)
    m = [ln for ln in r.stdout.splitlines() if ln.startswith('CE01 ')]
    got = json.loads(m[-1][5:]) if m else {}
    got['rc'] = r.returncode
    if r.returncode:
        got['err'] = r.stderr[-400:]
    return got


#: 열쇠의 코드 판 (그 저장본 폴더를 정직하게 다시 여는 쪽의 디스크) — 원판 / 변이판
HONEST_SIDE = {'honest': False, 'samesec': False, 'samesec_store': True, 'mtime_restore': False, 'samesize': False, 'symlink': False,
               'preloaded': True}
res = {}
for m in modes:
    sd = store_dir(m)
    a = run(code_dir(m, link=(m == 'symlink')), sd, m)
    b = run(code_dir(m + '_honest', mutant=HONEST_SIDE[m]), sd, 'honest')
    poison = b.get('status') == 'hit' and b.get('reg_fp') != b.get('fresh_fp')
    res[m] = {'first': a, 'honest_reopen': b, 'POISON_PERSISTED': poison}
    print(f"{m:14s} 첫 런 = {a.get('status')} (짓기 {a.get('builds')} · 원장 {a.get('reg_fp')} · 따로 {a.get('fresh_fp')} · 열쇠 코드 fsr "
          f"{a.get('code_fsr')} · 시작 fsr {a.get('start_fsr')} · {a.get('note')} · why {a.get('why', '')[:70]!r}) → 정직한 다시 열기 = "
          f"{b.get('status')} (받은 {b.get('reg_fp')} · 따로 {b.get('fresh_fp')}) → 독 지속 {poison}", flush=True)
json.dump(res, open(os.path.join(wd, 'ce01_results.json'), 'w'), ensure_ascii=False, indent=1)

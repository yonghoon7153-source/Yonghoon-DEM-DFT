# LHS 구조 디스크립터 — 배포 v1.3 최종판 (20991231 · 접촉망 세대 g2)

> 수영 님 ML 용 구조 디스크립터 + 접촉망 수송 지표 — **v1.3 = 최종판** (1저자 10-06 밤 *"v1.3 에 최종이라고 하고 확실하게 넘겨주자"*).
> v1.2 (`docs/data/lhs_release_20261006_v12/`) 의 열 · 값 규약을 이어받고 더한 것: **세대 2 망 값** · **ML 표 (빈칸 뜻 코드 · #1)** · **f 타깃 + 관통 분류 안내 (#2)** · **porosity–σ–CN 재적합 (#5)** · 표시 이름 **수송 tortuosity** · 새 열 **`se_isolated_pct`**.
> 정본 인계표 = `lhs_handover_v13_20991231.csv` · `lhsx_handover_v13_20991231.csv` · 재현 명령 = §10.

## 외부 검토 — 먼저 읽을 것

- Codex 세대 2 판정문 (GO): `TEST_ONLY_NOT_GO.md` — 이 배포는 GO 뒤에만 만든다.  판정문의 전달 문안이 이 README 와 다르면 **판정문이 우선**이다.
- 배치 manifest: `manifest.json` (sha256 `89220d649f9a42e90463819dab432b982c20f53841a0ffd4924d389d1b5fd33c` · expected_network_generation = `g2`) · τ 다시 읽기 (생성기 `load_tau_results` · 같은 기대 세대 · 인계표 τ 칸 대조) = **performed**.
- 코드 신원 (세대 2 등록 §3): 발사 봉인 (배치 manifest `code_hashes`) 4 파일 — 이 빌드 체크아웃과 **같다** · 인계 생성기 · 다시 읽기 도구 (`handover_code_hashes`) = 발사 기록 · 빌드 git HEAD `None` · 커밋 안 된 추적 파일 변경 None 줄.
- 배치 관문 (등록 §5-2 · §5-3 · ★ G2RR3-01 — 두 기록 필수 · build · 단계 A · check_v13 이 같은 판정 `v13_batch_gate_problems`): `seal_audit.json` sha256 `20b426fb88092ef8e177712599ba25d7a811465a9fcaf96ab998f897e4a33126` (봉인 판정 {'SEALED': 194} · merged {'same': 194}) · `reread.json` sha256 `ce36833166464a86eeebef96e855dec267be0896a144256633da75531f5e4cf3` (n_fail 0 · 기대 세대 `g2` · 등록 집합 `production194` 194/194) — **통과**: ⓪ 감사 = 실행 형식 자격 current · 봉인 판정 SEALED 만 194 · merged same · 등록 ID · 기대 세대 g2 · 세대 · 입력 지문 · import 관측 문제 0 / ⓪b 다시 읽기 = n_fail 0 · g2 · production194 194/194 · 둘 다 이 배치 뿌리 (`batch`) · 이 manifest · 이 발사 봉인 지문의 기록
- 완료 압력 (DESC-06): `press_*` 열 — 압밀 루프가 목표 300 MPa 에서 빠져나온 기록 (마지막 프레임 응력이 아니다)
- 5차 판정 (`docs/reviews/codex_review_rglr3_reverify_20261006.md` §6 · §7) 의 사용 조건은 그대로다: 모델 내부 ML 기술자 · 기본 = Hertz · Physics = opt-in 부록 · 상태 열 필수 · 실험 절대값 타깃 · 실물 순위 · COMSOL 물성 대입 금지 · T ≥ 1 이나 상태 OK 도 물리 정확도 인증이 아니다.

## 0. 바뀐 것 (v1.2 → v1.3)

| 무엇 | 내용 |
|---|---|
| 망 세대 | lhs = `g2` · lhsx = `g2` — Physics = ψ 곱셈 · 면적 physics_g2 · 정확 Dirichlet 전극 (세대 2 · 1저자 비준 10-06 저녁) · Hertz (H0) 간선은 세대 1 과 같고 전극만 바뀌었다 (σ 상대 ~1e-5) |
| 새 열 | `se_isolated_pct` (고립 전해질 · §5) · 세대 2 출처 `ion_net_generation` · `ion_net_constriction_hertz` · `ion_net_area_rule_hertz` · `ion_net_electrode_hertz` · `ion_net_bulk_hertz` (194 행 상수 — 출처 표지) · 완료 압력 `press_target_mpa` · `press_last_loop_mpa` · `press_reached` |
| ML 표 (#1) | `<ds>_mltable_20991231_v13.csv` — 배포 열 + 빈칸 코드 열 (`<열>__blank`) + `dataset` + 관통 분류 `ion_percolates_hertz` (§2 · §3) |
| 재적합 (#5) | `lhs_v13_refit_porosity_sigma_cn_*` + `origin/` + `previews/` (§6) |
| 표시 이름 | `tau2_ion_*` = **수송 tortuosity** (제곱근 아님) — 열 사전 · 웹앱 · COMSOL 2D 내보내기 같은 이름 (§4) |

## 1. 파일

| 파일 | 행 × 열 | sha256 |
|---|---|---|
| `lhs_mltable_20991231_v13.csv` | 130 × 196 | `795ea89f6f8d9a0f411df5d35024e3fe5dbade72b3b415baa962deb130d4b3b0` |
| `lhs_mltable_20991231_v13_columns.tsv` | — | `6bb23921b6284e17f3d4e362f11b3b7e182c8dd95711b53d6a054b081bd538ed` |
| `lhs_release_20991231_v13.csv` | 130 × 141 | `fb09824ca088c4d7007c73b35e500be23b6cd688b2a0057cbeb38f172c72b738` |
| `lhs_release_20991231_v13_columns.tsv` | — | `ac2a3c3f362efe969eb98d2d8a4b4c7cdab5dd6dd23c706814fcbd466fe45945` |
| `lhs_release_20991231_v13_physics.csv` | 130 × 16 | `94e7005b6c3ae89532764e8f9c037eb503220378b822ec286a90a864f0b20cd0` |
| `lhs_release_20991231_v13_physics_columns.tsv` | — | `9f91f3b7f957ce1ff4017997cb837ab5eb467781d1520b0a273a68f3ba495fdb` |
| `lhs_v13_refit_porosity_sigma_cn_rows.csv` | 194 × 18 | `a71e7594e95d2467b27baf29635e5d329b93fb4ad24c8e9b3d3dda5d18235465` |
| `lhs_v13_refit_porosity_sigma_cn_summary.json` | — | `98e6e915db74ffebad84f8949ccdbfade090f6e697b751711f3a755630cd45a7` |
| `lhsx_mltable_20991231_v13.csv` | 64 × 195 | `7671108033b6319209e822508a9e6641ee152d468fcf5bd986e5761e7584f49a` |
| `lhsx_mltable_20991231_v13_columns.tsv` | — | `9564f99b1495879d8fbefcc94c1078f22dd817e41d988717962d8b250b58c684` |
| `lhsx_release_20991231_v13.csv` | 64 × 140 | `0b15c3e0920fe2ce23c2a610a26b817535eb431bdef6ffe6da3cb60929388aab` |
| `lhsx_release_20991231_v13_columns.tsv` | — | `b133f94d62b4bf005a6da0cd7f2487dc860fd3b8320dd1008a4ac433aeeb90c6` |
| `lhsx_release_20991231_v13_physics.csv` | 64 × 16 | `02895a40c041f7ca9716ec3bbc52e3cec5201fd325c3ff60793e02fdf220991d` |
| `lhsx_release_20991231_v13_physics_columns.tsv` | — | `9f91f3b7f957ce1ff4017997cb837ab5eb467781d1520b0a273a68f3ba495fdb` |
| `origin/GUIDE.md` | — | `d208e0a9751097dc540bd5cbe6cd06242c3cf326df599d628954b6c06a8da66a` |
| `origin/v13_refit_collapse.csv` | 171 × 5 | `a0c5473efdd374a1852a2c9593a5ca57e637e9ebcfb5bc55b6a871835518ecfc` |
| `origin/v13_refit_parity.csv` | 171 × 5 | `ce70e434e7dd908a75a1a023157da0d81f96a870b0d253be9eb18f30aa825a59` |
| `origin/v13_refit_porosity_f.csv` | 195 × 6 | `fbd4ff5220cf8adf882bbd7be440ecc71a3a8d952f53417fea37072f98830f7b` |
| `previews/v13_refit_porosity_sigma_cn.png` | — | `dde94280e95de2569cb9dd02e9d7803a7e4238df55d6b30b2cbf109a5871fae1` |
| `previews/v13_refit_porosity_sigma_cn.svg` | — | `493ea750a9f72ea700b7df1a7f529afe4f691d85d52d46aa9769efa4bd8b07e0` |
| `README.md` · `v13_build_manifest.json` | — | (빌드 manifest 가 모든 파일의 sha256 을 적는다) |

한 행 = 한 침대 (300 MPa 압밀 뒤 한 프레임) · `case_id` 키 · 행 순서 = v1.2 와 같다.  두 데이터셋을 합칠 때는 `dataset` 표지를 둔다 (ML 표에는 있다).

## 2. 빈칸 뜻 (#1 — ML 표)

배포 CSV 의 빈칸은 뜻이 여럿이다 — **0 으로 채우지도, 한꺼번에 버리지도 않는다.**  ML 표는 배포 값 칸을 그대로 두고 (채우지 않았다 · 되읽기 검산), 빈칸이 있는 열마다 바로 뒤에 `<열>__blank` (코드 · 값이 있는 칸은 빈칸) 를 붙였다.  코드 규칙은 같은 행의 설계 `block` · 접촉 개수 · 상태 열이 정하고, 규칙에 없는 빈칸이나 빈칸이어야 할 칸의 값이 하나라도 있으면 생성기가 만들기를 거부한다.

| 코드 | 뜻 | 130 | 64 |
|---|---|---|---|
| `NA_PHASE_ABSENT` | 그 상 (AM_P · AM_S) 이 없는 mono 침대 — 정의되지 않음 (0 이 아니다 · 설계 block 이 정한다) | 720 | 384 |
| `NA_ZERO_CONTACTS` | 그 쌍 · AM–AM 접촉 0 개 — 평균 · 파괴 단계가 정의되지 않음 (개수 · 총합은 측정된 0 으로 값이 있다) | 3 | 6 |
| `NA_NOT_PERCOLATING` | 관통 SE 성분 없음 (percolation_pct = 0) — 관통 성분 기준 양 (se_se_cn_perc · _n_perc · _eff_area_perc · 기하학적 tortuosity) 이 정의되지 않음 | 120 | 0 |
| `INF_NOT_PERCOLATING` | 관통 이온 경로 없음 (ion_net_status = NOT_PERCOLATING) — 수송 tortuosity T · √T = 물리적 무한대의 저장 표현 (같은 행 f = 0.0 은 값으로 실려 있다) · 기술적 결측이 아니다 | 48 | 0 |
| `NOT_COMPUTED` | 기술적 실패 (ion_net_status = NOT_COMPUTED · 사유 = ion_net_status_reason) — 값 없음 · 무한대로 읽지 않는다 | 0 | 0 |
| `HOLD_BAND_FALLBACK` | 등록된 과학적 HOLD (솔버 띠 규칙이 L0 아님 · BAND_FALLBACK) — 값 없음 | 0 | 0 |
| `EMPTY_NO_REASON` | 텍스트 칸의 빈칸 = 사유 없음 (빈 집합) — hold_reason_codes (적격성 OK 행) · ion_net_status_reason (NOT_COMPUTED 가 아닌 행) | 201 | 66 |

- 쓰는 법: `NA_*` = 결측 표지 (그 특징을 못 쓰는 행 — 0 대입 금지 · 모델이 결측을 못 받으면 표지 열과 함께) · `INF_NOT_PERCOLATING` = T · √T 의 무한대 (회귀 타깃으로 쓰지 말고 §3 의 분류 가지로) · `NOT_COMPUTED` · `HOLD_BAND_FALLBACK` = 그 칸만 제외 사유 (무한대 아님) · `EMPTY_NO_REASON` = 빈 집합.
- 열 역할 = ML 열 사전 (`<ds>_mltable_20991231_v13_columns.tsv` 의 role) — `ID` 키 — 특징 금지 · `DATASET` 데이터셋 표지 (lhs = 130 · lhsx = 64 · 전부 SE-rich — 분포가 다르다 · 섞을 때 함께 둔다) · `X` 자유 설계 노브 — 설계 → 구조 예측의 입력 · `X_DERIVED` 설계의 재표현 — 같은 정보 (넣어도 독립 정보가 늘지 않는다) · `CONST` 194 행 상수 (규약 · 세대 · 목표압) — 특징 · 타깃 금지 · `DIAG` 진단 기록 — 특징 · 타깃 아님 · `FLAG` 적격성 표지 — 특징 금지 (물리 타깃 적격성 · HOLD 포함/제외 민감도 구분) · `STATUS` 수송 지표 상태 — 값과 반드시 같이 읽는다 (특징 아님 · Codex 5차 QV2) · `RESULT_COUNT` 실측 입자 수 (시뮬레이션 결과) — 설계 → 구조 예측의 X 로 쓰면 누설 · `Y` 구조 결과 — 타깃 후보 (항등식으로 묶인 열은 한 묶음에서 하나만 독립) · `Y_TARGET` 이온 수송 1차 타깃 (#2 — f · 유한 · 비관통 = 0.0) · `Y_IDENTITY` 항등식 유도 (T = φ_SE,mc/f · √T) — f 와 같이 타깃 · 특징으로 쓰지 않는다 · `Y_CLASS` 관통 분류 타깃 (#2 — 1 = 관통 · 0 = 비관통) · `BLANK_CODE` 바로 왼쪽 열의 빈칸 뜻 (코드 · 값이 있으면 빈칸) — 결측 표지로만.

## 3. 타깃 — `f_ion_hertz` 와 관통 분류 (#2)

- lhs 상태 (`ion_net_status_hertz`): NOT_PERCOLATING 24 · OK 106
- lhsx 상태 (`ion_net_status_hertz`): OK 64
- **이온 수송 타깃은 `f_ion_hertz`** (= σ_eff/σ₀ · 무차원 · 유한 — 비관통 행 = **0.0 = 물리적 0**, 결측이 아니다).  `tau2_ion_hertz` (수송 tortuosity T) · `tau_ion_hertz` (√T) 는 비관통에서 ∞ (빈칸) 라 그대로는 회귀 타깃이 아니다 · T = φ_SE,mc / f 항등식이라 **f 를 예측하면서 T · √T 를 특징으로 넣지 않는다**.
- **2 단계 (권장)**: ① 관통 분류 `ion_percolates_hertz` (ML 표 · 1 = 관통 · 0 = 비관통 · `percolation_pct > 0` 과 같은 판정) → ② 관통 행에서 f (또는 폴드 안에서 고른 변환 log f) 회귀.  예측 f = P(관통) × E[f | 관통] 로 묶을 수 있다 (hurdle).  비관통 행을 지우면 전도 가능한 하위집합만 남는다 — 지우지 않는다.
- 고립 열은 비관통 침대에 몰린다 → **관통 여부를 먼저 분류**한다 (평균 · 최대, 관통 / 비관통):
  - lhs: `am_ionic_isolated_pct` 관통 2.7 · 최대 52.7 / 비관통 88.9 · 최대 96.9 (n 106 · 24) · `se_isolated_pct` 관통 3.8 · 최대 51.6 / 비관통 90.2 · 최대 97.8 (n 106 · 24)
  - lhsx: `am_ionic_isolated_pct` 관통 0.0 · 최대 0.1 / 비관통 — · 최대 — (n 64 · 0) · `se_isolated_pct` 관통 0.0 · 최대 0.0 / 비관통 — · 최대 — (n 64 · 0)
- 다른 모드 — Physics 부록 = opt-in (기본 학습 열 아님 · 면적과 협착식이 함께 다른 규약의 결합 민감도 · Codex QV3) · H12 = 민감도 부록 (이 묶음에 없다).

## 4. 표시 이름 — 수송 tortuosity (τ 명명 규약)

| 열 | 이름 · 뜻 |
|---|---|
| `tau2_ion_<모드>` | **수송 tortuosity** T = φ_SE,mc / f (**제곱근 아님** = 문헌의 tortuosity factor · Tjaden κ = τ² · Landesfeind τ · COMSOL τ_F) · 키는 tau2 그대로 |
| `tau_ion_<모드>` | √T (유도량) — "수송 tortuosity" 라 부르지 않는다 · Dijkstra 경로 길이비의 뜻도 아니다 · COMSOL 입력 아님 |
| `f_ion_<모드>` | f = σ_eff/σ₀ (무차원) — 판 간격 해를 질량보존 두께로 재척도한 값 (L_mc 에서 다시 푼 해가 아니다) |
| `tortuosity_SE_wall` | **기하학적 tortuosity** — 경계 띠 SE 중심 쌍의 최단경로 / 그 쌍의 z 간격 (수송 τ 아님 · 수송 쪽 짝 = `tau2_ion_hertz`) |

## 5. 새 열 `se_isolated_pct` (고립 전해질)

- = **100 − `top_reachable_pct`** — 등록된 상단 2r 경계 띠 (분리막 쪽) 와 SE 접촉 그래프로 이어지지 않은 SE 의 비율 (%).  AM 경로 고립 (`am_ionic_isolated_pct` = 100 − `ionic_active_pct`) 과 같은 규칙 · 생성기가 유도 (재실행 없음) · 관문 S1 (= 100 − top) · S2 (≤ 100 − `percolation_pct`).
- 한정: 분리막 쪽 띠에 앉은 외톨이 SE (접촉 0) 를 연결로 세어 고립을 **약간 적게** 잡는다 · 큰 값은 비관통 침대에 몰린다 (§3) → 관통 분류 먼저.
- 그래프 지표다 — 실제 분리막 접촉 · 계면 저항 · 이온 전류를 계산하지 않는다.

## 6. porosity–σ–CN 재적합 (#5)

- 대상: ln f_ion_hertz (f = σ_eff/σ₀ · 무차원 · L_mc 기준 · Hertz 망) — 관통 행만 (상태 OK · MODEL_BELOW_CONTINUUM_BOUND) · n = 170 (lhs 106 · lhsx 64) · 적합 밖: NOT_PERCOLATING 24 (행은 표에 남긴다).
- φ_eff: φ_eff = √[(φ_SE,mc − φc_eff)² + (δ·g)²] · φc_eff = (1 − g)·φc_P + g·φc_S · g = min(r_cut / r_AM_eff, 1)^2 · r_AM_eff = (1 − p)·r_AM_S + p·r_AM_P (p = ps_frac · mono 는 있는 상만) · φ_SE,mc = phi_se_mass_conserving.  상수 = σ_ionic T1 등록식 동결값 (φc_P 0.2 · φc_S 0.195 · δ 0.04 · r_cut 3.5 µm · 게이트 지수 2.0) — 생산 코드에서 읽었다.

| 식 | a | α | β | R² | LOOCV R² | 잔차 sd (ln) | 편향 130 | 편향 64 |
|---|---|---|---|---|---|---|---|---|
| locked (½ · 2) | -5.314 ± 0.062 | 0.500 | 2.000 | 0.794 | 0.792 | 0.805 | -0.174 | 0.289 |
| free | -6.564 ± 0.633 | 0.630 ± 0.119 | 2.775 ± 0.242 | 0.850 | 0.836 | 0.687 | 0.059 | -0.098 |

- 파일: `lhs_v13_refit_porosity_sigma_cn_rows.csv` (행마다 φ_eff · 예측 · 잔차) · `lhs_v13_refit_porosity_sigma_cn_summary.json` · Origin 워크시트 `origin/` (1 줄 Long Name · 2 줄 Units · GUIDE) · 미리보기 `previews/v13_refit_porosity_sigma_cn.png` · `.svg`.
- 한정: 모델 내부 관계 — 고정 접촉망 · 면적 · 협착 · 경계 규약에서 계산한 f 의 근사식 · 실험 절대값 · 실물 순위 · COMSOL 물성 아님 · 지수 (α · β) 는 이 코퍼스 · 이 규약의 적합값 — 물리 상수로 인용하지 않는다 · f_p (관통 분율) · coverage · τ 항을 넣지 않았다 — τ 는 f 의 항등식 (누설) · 관통 여부는 분류 가지 (ion_percolates_hertz) · 두 데이터셋 (130 · 64 SE-rich) 은 분포가 다르다 — by_dataset 편향 · R² 를 따로 본다 · LOOCV = 해석적 hat 행렬 (OLS) — 변수 선택 · φc 재선정은 하지 않았다 (동결값).

## 7. Physics 부록 (opt-in) · H12

- lhs Physics 상태: NOT_PERCOLATING 24 · OK 106
- lhsx Physics 상태: MODEL_BELOW_CONTINUUM_BOUND 10 · OK 54
- 기본 학습 열에 자동 포함하지 않는다 · `MODEL_BELOW_CONTINUUM_BOUND` 행은 값 유지 + 표지 — 그 행만 지우고 나머지 Physics 의 타당성을 주장하지 않는다 (Codex QV3).
- 세대 2 Physics = ψ 곱셈 + 면적 physics_g2 + 정확 Dirichlet (출처 표지 열 — 부록에 있다) · Hertz 와 Physics 의 차이를 "소성 접촉 면적만의 민감도" 로 읽지 않는다.

## 8. 규약 (v1.2 README §3 · §4 그대로 — 요지)

- 상태 열 (`ion_net_status_hertz`) 을 값과 같이 읽는다 · 숫자 열만 골라 dropna / 0 채움 하는 학습 코드는 충분하지 않다 (Codex QV2).
- 항등식 묶음에서 하나만 독립 타깃: ε + φ_SE,mc + φ_AM,mc = 1 · T = φ_SE,mc/f · √T · `se_isolated_pct` = 100 − `top_reachable_pct` · `am_ionic_isolated_pct` = 100 − `ionic_active_pct` · 이온 분할 셋 = 100 · 파괴 · 면적 · F1 항등식 (v1.2 §3-2).
- 총량 열 (`area_*_total` · `n_*` · 개수) 은 정규화해서 쓴다 · CN · 비율 열에는 벽 효과가 섞여 있다 (`wall_touch_frac_*`).
- σ basis — `f_ion_hertz` × σ₀ (3.0 mS/cm) 는 L_mc 재척도 σ 다 (웹앱 화면 · 보고 덱의 판 간격 해와 무표지 혼용 금지 · Codex QV5).
- 적격성 HOLD (`physical_target_status`) 는 그대로 — 행을 지우지 않는다 · 에뮬레이터 (HOLD 포함) ↔ 물리 타깃 후보 (HOLD 불허) 를 구분해 보고한다.
- 변수 선택 · 스케일링 · 변환 · 초매개변수는 학습 폴드 안에서 (중첩 CV) · 130 ↔ 64 이동 성능을 무작위 CV 와 따로 보고한다.

## 9. AI 도구에 붙여 넣을 프롬프트

```
너는 고체전지 복합 양극 DEM 시뮬레이션 데이터로 ML 을 하는 조수다.  데이터 = lhs_mltable_20991231_v13.csv (130 행) · lhsx_mltable_20991231_v13.csv
(64 행, 전부 SE-rich — 분포가 달라 dataset 표지를 둔다).  한 행 = 300 MPa 로 압밀한 전극 침대 하나.  열 역할은 *_mltable_*_columns.tsv 의
role 열 · 뜻은 배포 *_columns.tsv 와 README (README 가 정정판).  *_physics.csv 는 부록이다 — 요청받기 전에는 쓰지 마라.
1) X = role X 다섯 (am_pct · ps_frac · d_am_p_um · d_am_s_um · d_se_um).  X_DERIVED 는 같은 정보 · CONST · FLAG · ID · STATUS 는 특징이 아니다.
   RESULT_COUNT (실측 입자 수) · 두께 · CN 같은 결과를 설계 → 구조 예측의 X 로 쓰면 누설이다.
2) 빈칸은 <열>__blank 코드가 뜻을 정한다.  0 으로 채우지 마라.  NA_* = 결측 표지 · INF_NOT_PERCOLATING = 무한대 (관통 경로 없음) ·
   NOT_COMPUTED · HOLD_BAND_FALLBACK = 그 칸만 제외 · EMPTY_NO_REASON = 빈 집합.
3) 이온 수송 타깃 = f_ion_hertz (유한 · 비관통 0.0).  먼저 ion_percolates_hertz (1 관통 · 0 비관통) 를 분류하고 관통 행에서 f (또는 폴드 안에서
   고른 log f) 를 회귀하라.  tau2_ion_hertz (수송 tortuosity T) · tau_ion_hertz (√T) 는 role Y_IDENTITY — f 와 항등식 (T = φ_SE,mc/f) 이라
   f 를 예측하면서 특징으로 넣지 마라.  tortuosity_SE_wall 은 기하학적 tortuosity (다른 양) 다.
4) 항등식 열을 독립 타깃처럼 세지 마라 (README §8).  총량 열은 정규화하라.  se_isolated_pct · am_ionic_isolated_pct 는 비관통에 몰린다.
5) physical_target_status = HOLD 행은 지우지 말고 에뮬레이터 (HOLD 포함) 와 물리 타깃 후보 (HOLD 불허) 를 구분해 보고하라.
6) 값은 고정 접촉망 · 면적 · 협착 · 경계 규약의 모델 기술자다 — 실험값 · 실물 순위 · COMSOL 물성으로 바꾸어 쓰지 마라.
7) lhs_v13_refit_porosity_sigma_cn_summary.json 의 식은 이 코퍼스의 근사 관계다 — 지수를 물리 상수로 인용하지 마라.
8) 변수 선택 · 스케일링 · 초매개변수는 학습 폴드 안에서 (중첩 CV) · 130 과 64 의 이동 성능을 따로 · 불확실성을 함께 보고하라.
```

## 10. 재현

- 생성기: `scripts/lhs_release_build.py --v13` (단계 A = 인계표 생성기 `scripts/lhs_design_dataset.py --export-handover … --webapp-groups contact,percolation,f1,fracture,area,tau,se_isolation --tau-results … --tau-batch-manifest …` · 단계 B = 이 묶음 · 대조 `--v13-check`) — 명령 전문 = `docs/reviews/lhs_release_v13_plan_20261007.md`.
- 빌드 manifest `v13_build_manifest.json` = 인계표 sha256 · 코드 sha256 · 파일 sha256 · 코드 신원 (발사 봉인 대조 · 명시 승인 · git HEAD) · 배치 관문 기록 (⓪ 감사 · ⓪b 다시 읽기 sha256) · 경고.

from pathlib import Path
import json,hashlib,os,difflib,ast
R=Path(__file__).resolve().parent;O=R.parent/'bmin_r2_limited_validation_retry2_20261005'
def write(p,b):
 with p.open('xb') as f:f.write(b)
def put(p,o):write(p,json.dumps(o,ensure_ascii=False,indent=2).encode())
for name in ('INPUT_CASE_MAP.json','ENGINE_IDENTITIES.json','EXTRACTION_MAP.json','SOURCE_IDENTITIES_BEFORE.json','ps_cases.ps1','python_cases.py'):
 write(R/name,(O/name).read_bytes())
for name in ('extracted','harness'):
 (R/name).mkdir()
 for p in (O/name).iterdir():write(R/name/p.name,p.read_bytes())
old=(O/'seal_and_run.py').read_text('utf-8')
new=old.replace('2026-10-05T07:16:31.025186+00:00','2026-10-05T07:29:48.897983+00:00')
new=new.replace(" for cp in (R/'fixtures').glob('*/contract_fixture.json'):"," known_paths={x['path'] for x in files}\n for cp in (R/'fixtures').glob('*/contract_fixture.json'):")
new=new.replace("   if not any(x['path']==path.resolve().as_posix() for x in files):files.append(ident(path))","   resolved=path.resolve().as_posix()\n   if resolved not in known_paths:\n    files.append(ident(path));known_paths.add(resolved)")
assert 'any(x[' not in new;ast.parse(new);write(R/'seal_and_run.py',new.encode())
write(R/'SEAL_COST_DIFF.patch',''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='retry2/seal_and_run.py',tofile='retry3/seal_and_run.py')).encode())
(R/'fixtures').mkdir();prepared=[]
for case in json.loads((O/'PREPARED_PYTHON_INPUTS.json').read_bytes()):
 oldq=Path(case['path']);q=R/'fixtures'/oldq.name;q.mkdir();(q/'tables_source').mkdir()
 for p in (oldq/'tables_source').iterdir():os.link(p,q/'tables_source'/p.name)
 for name in ('batch.log','console.log','INPUT_EXPECTATION.json'):os.link(oldq/name,q/name)
 cc=json.loads((oldq/'contract_fixture.json').read_bytes());cc['run_root']=(q/'run_fixture').resolve().as_posix();put(q/'contract_fixture.json',cc)
 prepared.append(dict(case,path=q.resolve().as_posix()))
put(R/'PREPARED_PYTHON_INPUTS.json',prepared)
put(R/'REVISION.json',{'approval':'User 다시 ㄱ following stopped preseal and minimal fix proposal','origin_utc':'2026-10-05T07:29:48.897983+00:00','change':'Resolve each baseline path once outside membership lookup; set membership instead of repeated resolve inside any()','production_changes':0,'python_ps_helper_bytes_same_as_retry2':True,'fixture_values_and_expectations_unchanged':True,'unique_ids':62,'inputs':77,'budget_seconds':{'preparation':600,'python':250,'java_compile':90,'stub_jvm':60,'PS51':240,'preserve_package':300,'incomplete':120,'overall':1660},'previous_stop_dir':str(O),'native_approved':False})
print(json.dumps({'status':'PREPARED_NO_TESTS','python_inputs':len(prepared),'production_changes':0}))

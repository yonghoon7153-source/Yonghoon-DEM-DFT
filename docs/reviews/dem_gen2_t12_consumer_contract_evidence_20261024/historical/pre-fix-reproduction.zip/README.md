# T12 ULPRI pre-fix reproduction

Pinned consumer: 01c1aaf5be8acdf7d1716f34cc86fc77d8e27362.
This is an immutable synthetic failure fixture, not a physical T12 result.
Extract into a new writable directory, then run from that directory:

    python3 -I scripts/test_dem_gen2_t12_consumer_contract.py --repo /path/to/Yonghoon-DEM-DFT

Expected process rc 1: 44 of 52 cases pass; exactly the eight new marker and Unicode rejection cases fail.
The repository must contain the pinned Git objects. No fetch, merge, checkout, physical run, or source edit is performed.
The script, source manifest, and contract are the exact pre-fix snapshot. EXPECTED-RESULT.json preserves the observed result and hashes.
The ULPR source itself is loaded unchanged from Git and is not included here.

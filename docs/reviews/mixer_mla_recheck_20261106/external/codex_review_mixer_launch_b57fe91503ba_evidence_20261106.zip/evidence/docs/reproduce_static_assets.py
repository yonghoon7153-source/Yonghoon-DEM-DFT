"""Reproduce the bounded static_assets_rebind.json checks, without research runs.

From any working directory:
  python -B <review-root>/evidence/docs/reproduce_static_assets.py

The review root must contain package/ and evidence/docs/. The original successful
run used Python 3.12.14. This script contains the same eight validate_case calls,
three diff_d2_decks calls, and manifest checks as that run. Path discovery is made
relative to this file instead of the original package working directory.

The earlier inaccessible WindowsApps Python alias executed zero tests; its
separate unavailable_python_attempt.json is historical evidence, not a check
that this reproducer repeats. No scientific CLI or existing selftest is invoked.
"""
import hashlib
import json
import sys
import traceback
from pathlib import Path

sys.dont_write_bytecode = True
root = Path(__file__).resolve().parents[2] / 'package'
base = root / 'docs/reviews/mixer_first8_launch_preparation_20261106'
out = Path(__file__).resolve().parent
out.mkdir(parents=True, exist_ok=True)
report = {
    'scope': 'new first8 planned assets only: local in-memory recipe binding and static pair checks',
    'python': sys.version,
    'scientific_execution': False,
    'host_scheduler_calls': False,
    'package_writes': False,
    'whole_gate': 'HOLD',
    'case_bindings': [],
    'pair_checks': [],
    'hash_errors': [],
}
exitcode = 0
try:
    manifest = json.loads((base / 'static_asset_manifest.json').read_text(encoding='utf-8'))
    seal = json.loads((base / 'source_seal.json').read_text(encoding='utf-8'))
    for item in manifest['files']:
        b = (base / item['path']).read_bytes()
        if len(b) != item['bytes'] or hashlib.sha256(b).hexdigest() != item['sha256']:
            report['hash_errors'].append(item['path'])
    for item in seal['files']:
        if hashlib.sha256((root / item['path']).read_bytes()).hexdigest() != item['sha256']:
            report['hash_errors'].append(item['path'])
    report['asset_files_checked'] = len(manifest['files'])
    report['source_seal_files_checked'] = len(seal['files'])
    assert not report['hash_errors']
    sys.path.insert(0, str(root / 'scripts'))
    import mixer_precal_prepare as prep
    assert tuple(c['case_id'] for c in manifest['cases']) == prep.CASE_IDS
    assets = {}
    for case in manifest['cases']:
        cid = case['case_id']
        folder = base / 'planned_assets' / cid
        deck = (folder / 'in.mixer').read_bytes()
        meta = json.loads((folder / 'deck_meta.json').read_text(encoding='utf-8'))
        binding = prep.validate_case(cid, deck, meta)
        assert binding['n_planned'] == 100000 and binding['execution_authorized'] is False
        assert binding['registered'] is None
        assets[cid] = (deck, meta)
        report['case_bindings'].append({
            'case_id': cid,
            'verdict': 'PASS',
            'planned_atoms': binding['n_planned'],
            'role': binding['role'],
            'revolutions': binding['revolutions'],
            'observed_atoms': None,
            'execution_authorized': False,
            'deck_sha256': hashlib.sha256(deck).hexdigest(),
        })
    for b in (1, 2, 3):
        u, um = assets['PRECAL_R1_B%d_U' % b]
        c, cm = assets['PRECAL_R1_B%d_C' % b]
        result = prep.diff.diff_d2_decks(u, c, um, cm)
        report['pair_checks'].append({
            'pair': 'R1_B%d' % b,
            'verdict': result['verdict'],
            'failures': result['failures'],
        })
        assert result['verdict'] == 'PASS'
    report['outcome'] = 'PASS'
except Exception as exc:
    report['outcome'] = 'ERROR'
    report['exception'] = repr(exc)
    report['traceback'] = traceback.format_exc()
    exitcode = 1
report['case_bindings_completed'] = len(report['case_bindings'])
report['pair_checks_completed'] = len(report['pair_checks'])
path = out / 'static_assets_rebind.json'
path.write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
print(json.dumps({
    'evidence': str(path),
    'outcome': report['outcome'],
    'asset_files_checked': report.get('asset_files_checked', 0),
    'source_seal_files_checked': report.get('source_seal_files_checked', 0),
    'case_bindings_completed': report['case_bindings_completed'],
    'pair_checks_completed': report['pair_checks_completed'],
    'exception': report.get('exception'),
}, indent=2))
sys.exit(exitcode)

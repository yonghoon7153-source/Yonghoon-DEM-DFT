"""Run Git for Windows sh with fake python3 only. Never uses WSL/ibb.

The received shell bytes stay unchanged. The fake interpreter exits before
reading its arguments, so the embedded inventory code never executes here.
"""
import json
from pathlib import Path
import subprocess
import sys

HERE = Path(__file__).resolve().parent
COMMAND = HERE.parent / 'received/docs/reviews/lhs_pressure_inventory_20261104/pressure_inventory.sh'
SH = Path('C:/Program Files/Git/bin/sh.exe')
stubdir = HERE / 'interpreter_stub'
stubdir.mkdir(exist_ok=True)
stub = stubdir / 'python3'
def unix_path(path):
    return '/' + path.drive[0].lower() + path.as_posix()[2:]
def run(exit_code, close_stdout):
    stub.write_text('#!/bin/sh\nexit %d\n' % exit_code, encoding='ascii', newline='\n')
    body = 'PATH="$1:/usr/bin:/bin"; export PATH; /bin/sh "$2" ibb'
    if close_stdout:
        body += ' 1>&-'
    completed = subprocess.run([str(SH), '-c', body, 'probe', unix_path(stubdir), unix_path(COMMAND)], capture_output=True, text=True)
    return {'interpreter_exit': exit_code, 'stdout_closed': close_stdout, 'process_rc': completed.returncode, 'stdout': completed.stdout, 'stderr': completed.stderr}
result = {
    'scope': 'Git for Windows sh; fake interpreter exits before embedded Python; no WSL/ibb/actual inventory',
    'interpreter_rc2': run(2, False),
    'interpreter_rc1': run(1, False),
    'fallback_closed_stdout': run(1, True),
}
if any(probe['process_rc'] == 3221225794 for key, probe in result.items() if isinstance(probe, dict)):
    result['verification'] = 'BLOCKED: Git sh cannot start under current Windows permissions; no shell behavior established by this probe'
    (HERE / 'shell_protocol_result.json').write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
    print(json.dumps(result, indent=2))
    sys.exit(0)
assert result['interpreter_rc2']['process_rc'] == 2
assert result['interpreter_rc2']['stdout'] == ''
assert result['interpreter_rc1']['process_rc'] == 2
assert json.loads(result['interpreter_rc1']['stdout'])['reason'] == 'RUNTIME_ERROR'
assert result['fallback_closed_stdout']['process_rc'] == 2
assert result['fallback_closed_stdout']['stderr'] != ''
(HERE / 'shell_protocol_result.json').write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
print(json.dumps(result, indent=2))

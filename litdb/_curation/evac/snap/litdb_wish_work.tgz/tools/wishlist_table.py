#!/usr/bin/env python3
"""wishlist_table.py — 정본 wishlist.md (배치마다 덧붙인 원문) 를 한 표로 묶는다 (중복 · 카드 있음 · 후보 표에 있음 · PDF 필요).

python3 -I wishlist_table.py <wishlist.md> <papers_list.txt> <queue.json>  → 화면 요약 + TSV (표준 출력 뒤쪽)
열쇠 = 제1 저자 성 (소문자 · ASCII 로 접음) + 해.  짐작으로 맞추는 것이라 '같음' 은 [추정] — 사람이 마지막에 본다.
"""
import json
import re
import sys
import unicodedata
from collections import OrderedDict

wl, plist, qp = sys.argv[1:4]
papers = [l.strip() for l in open(plist, encoding="utf-8") if l.strip()]
Q = json.load(open(qp, encoding="utf-8"))


def fold(s):
    return "".join(c for c in unicodedata.normalize("NFKD", s) if not unicodedata.combining(c)).lower()


def first_author(bib):
    b = re.sub(r"^\s*(\[[^\]]*\]\s*)+", "", bib).strip()
    tok = re.split(r"[,;]", b)[0].strip()
    words = [w for w in re.split(r"\s+", tok) if w]
    if not words:
        return ""
    # "A. Hayashi" · "J. A. Dawson" (머리글자 먼저) → 마지막 낱말 · "Steffen M" · "Bielefeld" (성 먼저) → 첫 낱말
    if re.fullmatch(r"([A-Z]\.(-?[A-Z]\.)?\s*)+", " ".join(words[:-1]) + " ") or all(re.fullmatch(r"[A-Z]\.(-[A-Z]\.)?", w) for w in words[:-1]):
        name = words[-1]
    else:
        name = words[0]
    return fold(re.sub(r"[^\w\-]", "", name)).split("-")[0]


def year(bib):
    m = re.findall(r"\b(19[5-9]\d|20[0-2]\d)\b", bib)
    return m[0] if m else ""


groups = OrderedDict()
sec = "?"
for line in open(wl, encoding="utf-8"):
    if line.startswith("### "):
        sec = line[4:].strip()
        continue
    if not line.startswith("- [") and not line.startswith("- [대피"):
        continue
    body = line[2:].strip()
    bib = re.split(r"\s\|\s|\s—\s", body, maxsplit=1)[0]
    why = body[len(bib):].strip(" |—")
    a, y = first_author(bib), year(bib)
    key = f"{a}{y}" if a and y else ("?" + bib[:30])
    g = groups.setdefault(key, {"bib": bib, "secs": [], "why": why[:90]})
    if sec not in g["secs"]:
        g["secs"].append(sec)

qtext = {k: fold(v.get("bib", "") + " " + v.get("pdf", "")) for k, v in Q.items()}
rows = []
for key, g in groups.items():
    m = re.match(r"([a-z\-]+)(\d{4})$", key)
    card = []
    inq = []
    if m:
        a, y = m.groups()
        card = [p for p in papers if p.lower().startswith(a + y)]
        inq = [k for k, t in qtext.items() if a in t and y in t]
    st = "카드 있음" if card else ("후보 표 " + ",".join(inq) if inq else "PDF 필요")
    rows.append((key, len(g["secs"]), st, g["bib"][:110], ";".join(g["secs"]), ";".join(card)[:80]))

n = len(rows)
c = sum(1 for r in rows if r[2] == "카드 있음")
q = sum(1 for r in rows if r[2].startswith("후보 표"))
p = sum(1 for r in rows if r[2] == "PDF 필요")
multi = sum(1 for r in rows if r[1] > 1)
print(f"고유 {n} 편 (항목 → 열쇠 묶음) · 카드 있음 {c} · 후보 표에 있음 {q} · PDF 필요 {p} · 두 배치 이상이 요청 {multi}")
print("key\tn_batches\tstatus\tbib\tbatches\tcards")
for r in sorted(rows, key=lambda r: (r[2] != "PDF 필요", -r[1], r[0])):
    print("\t".join(str(x) for x in r))

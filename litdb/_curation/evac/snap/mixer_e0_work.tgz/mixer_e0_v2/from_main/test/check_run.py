#!/usr/bin/env python3
"""check_run.py — run_tests.sh 의 판정기.  snap <root…> = 스냅숏 JSON · check <T> <md5> <H1..H5> = 단언."""
import hashlib
import json
import os
import re
import socket
import stat
import subprocess
import sys
import tarfile

ALLOWED_GIT = {'--version', 'rev-parse', 'symbolic-ref', 'log', 'status', 'diff-index', 'ls-files'}
STATUSES = {'OK', 'FAIL', 'MISSING', 'TIMEOUT', 'TRUNC', 'SKIPPED_BUDGET', 'SKIPPED_SWITCH', 'SKIPPED_NOT_LUSTRE'}
SECRETS = ['SECRET_M_VALUE', 'SECRET_DUMP_VALUE', 'SECRET_SMOKE']


def sha(p):
    h = hashlib.sha256()
    with open(p, 'rb') as f:
        for b in iter(lambda: f.read(1 << 20), b''):
            h.update(b)
    return h.hexdigest()


def snap(roots):
    out = {}
    for root in roots:
        for dp, dns, fns in os.walk(root):
            for n in dns + fns:
                p = os.path.join(dp, n)
                st = os.lstat(p)
                rec = [stat.S_IFMT(st.st_mode), st.st_size, st.st_mtime_ns]
                if stat.S_ISREG(st.st_mode) and st.st_size < 2_000_000:
                    rec.append(sha(p))
                out[p] = rec
    return out


R = {'pass': 0, 'fail': 0, 'lines': []}


def ok(cond, msg):
    R['pass' if cond else 'fail'] += 1
    R['lines'].append(('PASS ' if cond else 'FAIL ') + msg)


def read(p, mode='r'):
    with open(p, mode) as f:
        return f.read()


def kv(path):
    d = {}
    if os.path.exists(path):
        for line in read(path).splitlines():
            if '=' in line:
                k, v = line.split('=', 1)
                d.setdefault(k, []).append(v)
    return d


def probes(path):
    out = {}
    for line in read(path).splitlines():
        c = line.split('|')
        if len(c) >= 6:
            out[c[0]] = c
    return out


def new_dirs(T, name, home):
    b = json.load(open(os.path.join(T, name + '.snap_before.json')))
    a = json.load(open(os.path.join(T, name + '.snap_after.json')))
    added = sorted(set(a) - set(b))
    removed = sorted(set(b) - set(a))
    changed = sorted(p for p in set(a) & set(b) if a[p] != b[p])
    meta = sorted({p for p in added if re.fullmatch(re.escape(home) + r'/mixer_e0_meta_\d{8}T\d{6}Z(_\d)?', p)})
    outside = [p for p in added if not any(p == m or p.startswith(m + '/') for m in meta)]
    return meta, outside, removed, changed


def common_exec(T, name, home, md5, forbid_extra=()):
    rc = read(os.path.join(T, name + '.rc')).strip()
    ok(rc == '0', f'{name}: rc {rc} = 0')
    meta, outside, removed, changed = new_dirs(T, name, home)
    ok(len(meta) == 1, f'{name}: 새 메타 폴더 정확히 1 개 ({len(meta)})')
    ok(not outside and not removed and not changed,
       f'{name}: 새 폴더 밖 변화 0 (추가 {len(outside)} · 삭제 {len(removed)} · 변경 {len(changed)}) {outside[:2]}{removed[:2]}{changed[:2]}')
    ok(not os.path.exists(os.path.join(T, name + '.sentinel')), f'{name}: 금지 명령 (sbatch · scancel · scontrol · rm · mv) 호출 0')
    gl = os.path.join(T, name + '.gitlog')
    subs = set()
    if os.path.exists(gl):
        for line in read(gl).splitlines():
            t = line.split()
            i = 0
            while i < len(t) and t[i] in ('-C', '--no-optional-locks'):
                i += 2 if t[i] == '-C' else 1
            subs.add(t[i] if i < len(t) else '')
    ok(subs <= ALLOWED_GIT, f'{name}: git 부속 명령 = 읽기만 {sorted(subs)}')
    if len(meta) < 1:
        return None
    D = meta[0]
    nm = os.path.basename(D)
    for sub in ('raw', 'out', 'work'):
        ok(os.path.isdir(os.path.join(D, sub)), f'{name}: {sub}/ 있음')
    tgz = os.path.join(D, nm + '.tgz')
    ok(os.path.isfile(tgz) and os.path.isfile(tgz + '.sha256'), f'{name}: tgz · sha256 옆 파일')
    so = read(os.path.join(T, name + '.stdout'))
    m = re.search(r'sha256\s+([0-9a-f]{64})', so)
    if os.path.isfile(tgz):
        ok(m is not None and m.group(1) == sha(tgz), f'{name}: 화면 sha256 = tgz 실제 sha256')
        with tarfile.open(tgz, 'r:gz') as tf:
            mem = tf.getmembers()
        ok(all(x.name == 'out' or x.name.startswith('out/') for x in mem), f'{name}: tgz 멤버 = out/ 만 ({len(mem)})')
        ok(all(x.uname == '' and x.gname == '' and x.uid == 0 and x.gid == 0 for x in mem), f'{name}: tgz 소유자 이름 없음 · uid/gid 0')
        ok(all(x.isdir() or x.isfile() for x in mem), f'{name}: tgz 링크 · 장치 없음')
        ok({x.name[4:] for x in mem if x.isfile()} == set(os.listdir(os.path.join(D, 'out'))), f'{name}: tgz 파일 = out/ 파일')
    out = os.path.join(D, 'out')
    ok(hashlib.md5(read(os.path.join(out, 'meta_script.sh'), 'rb')).hexdigest() == md5, f'{name}: out/meta_script.sh md5 = 게이트 md5')
    sums = read(os.path.join(out, 'SHA256SUMS')).splitlines()
    good = all(sha(os.path.join(out, l.split('  ', 1)[1])) == l.split('  ', 1)[0] for l in sums if l.strip())
    ok(good and len(sums) == len(os.listdir(out)) - 1, f'{name}: out/SHA256SUMS 전수 대조 ({len(sums)})')
    rsums = read(os.path.join(out, 'RAW_SHA256SUMS')).splitlines()
    ok(all(sha(os.path.join(D, 'raw', l.split('  ', 1)[1])) == l.split('  ', 1)[0] for l in rsums if l.strip()), f'{name}: RAW_SHA256SUMS = raw/ 원문')
    ok(not any(l.split('  ', 1)[1].startswith('private_') for l in rsums if l.strip()), f'{name}: private_* 원문은 해시 목록에도 없음')
    ok(not any(f.startswith('private_') for f in os.listdir(out)), f'{name}: private_* 는 out/ 에 없음')
    hosts = {socket.gethostname(), socket.getfqdn(), socket.gethostname().split('.')[0]}
    forbid = [home, 'fakeuser', 'SECRET-LOGIN-HOST', 'SECRET-NODE', 'fakebuilder'] + [h for h in hosts if len(h) >= 2] + SECRETS + list(forbid_extra)
    texts = {'stdout': so}
    for f in os.listdir(out):
        texts['out/' + f] = read(os.path.join(out, f), 'rb').decode('utf-8', 'replace')
    leaks = [(k, s) for k, t in texts.items() for s in forbid if s in t and not (k == 'out/meta_script.sh')]
    ok(not leaks, f'{name}: 화면 · out/ 에 경로 · 계정 · 호스트 · 금고 · 덤프 문자열 0 {leaks[:4]}')
    rawt = ''.join(read(os.path.join(D, 'raw', f), 'rb').decode('utf-8', 'replace') for f in os.listdir(os.path.join(D, 'raw')))
    ok(not any(s in rawt for s in SECRETS), f'{name}: raw/ 에도 금고 · 덤프 내용 0 (열지 않음)')
    hl = read(os.path.join(D, 'raw', 'hashes.txt'))
    ok(not re.search(r'/\.e0_diag/|/\.smoke_blind/|/post/', hl), f'{name}: 금고 · 덤프 파일은 해시도 안 함')
    post = kv(os.path.join(out, 'fields_post.txt'))
    ok(post.get('redaction.residual_token_hits') == ['0'], f'{name}: 가림 남은 토큰 0 ({post.get("redaction.residual_token_hits")})')
    pr = probes(os.path.join(D, 'raw', 'probes.txt'))
    ok(all(c[1] in STATUSES for c in pr.values()), f'{name}: 조회 상태 어휘 {sorted({c[1] for c in pr.values()})}')
    return D, kv(os.path.join(D, 'raw', 'fields.txt')), pr, so


def st(pr, k):
    return pr.get(k, ['', 'ABSENT'])[1]


def main():
    if sys.argv[1] == 'snap':
        json.dump(snap(sys.argv[2:]), sys.stdout)
        return 0
    T, md5, H1, H2, H3, H4, H5 = sys.argv[2:9]
    r = common_exec(T, 't1', H1, md5)
    if r:
        D, f, pr, so = r
        for k in ('slurm_sinfo_version', 'slurm_sinfo_partitions', 'slurm_qos', 'slurm_assoc_me', 'slurm_squeue_me'):
            ok(st(pr, k) == 'MISSING', f't1: {k} = MISSING ({st(pr, k)})')
        ok(f.get('lmp.n_unique_found') == ['0'], f"t1: LIGGGHTS 실제 파일 0 (MISSING 칸) {f.get('lmp.n_unique_found')}")
        ok(f.get('mpi.n_unique_found') == ['0'], f"t1: mpirun 실제 0 {f.get('mpi.n_unique_found')}")
        ok(st(pr, 'module_list') == 'MISSING', f"t1: module = MISSING ({st(pr, 'module_list')})")
        ok(st(pr, 'quota_s') == 'TIMEOUT', f"t1: 가짜 quota (멈춤) = TIMEOUT ({st(pr, 'quota_s')})")
        ok(st(pr, 'private_acl1') == 'FAIL', f"t1: 가짜 getfacl (실패) = FAIL ({st(pr, 'private_acl1')})")
        ok(st(pr, 'lfs_quota_home') == 'SKIPPED_NOT_LUSTRE', f"t1: lfs = SKIPPED_NOT_LUSTRE")
        ok(st(pr, 'seal_extract') == 'OK' and st(pr, 'repo1_status') == 'OK', 't1: 봉인 추출 · git status 읽기 OK')
        ok(f.get('first8.e0_deck_vs_static') == ['absent'], 't1: first8 E0 덱 = absent')
        ok(any('mixer_dev7_20260930_v26' in v for v in f.get('mix1.path', []) + f.get('mix2.path', []) + f.get('mix3.path', [])), 't1: DEV OUT 폴더 찾음')
        ok('끝' in so and '가져올 파일' in so, 't1: 화면 요약 · 가져올 파일 줄')
    r = common_exec(T, 't2', H2, md5, forbid_extra=('otheruser',))
    if r:
        D, f, pr, so = r
        ok('/home/<OTHER_USER>/bin' in f.get('env.PATH', [''])[0] or '/home/<OTHER_USER>/bin' in read(os.path.join(D, 'out', 'fields.txt')),
           't2: 다른 사용자 홈 경로 = /home/<OTHER_USER>')
        ok(all(f.get(f'tool.{t}') == ['present'] for t in ('stat', 'readlink', 'find', 'sha256sum', 'awk', 'tar')), 't2: 기본 도구 칸 present')
        for k in ('slurm_sinfo_version', 'slurm_sinfo_partitions', 'slurm_qos', 'slurm_assoc_me', 'slurm_squeue_me', 'module_list', 'quota_s', 'mpi1_version', 'lmp1_help', 'lmp1_banner_static', 'py1_version', 'conda1_meta', 'mix1_du'):
            ok(st(pr, k) == 'OK', f't2: {k} = OK ({st(pr, k)})')
        s = f.get('slurm.my_jobs_summary', [''])[0]
        ok('jobs=2' in s and 'RUNNING=1(cpus 56)' in s and 'PENDING=1(cpus 28)' in s, f't2: squeue 요약 {s}')
        ok(f.get('lmp.n_unique_found') == ['1'] and f.get('lmp1.vs_receipt_v2_ibb_20260928') == ['different'], 't2: LIGGGHTS 1 개 · 09-28 영수증과 different')
        ok('log.liggghts' not in f.get('work.files_after_help', [''])[0], f"t2: -h 가 log 를 안 남김 (-log none · work/ 안) {f.get('work.files_after_help')}")
        bs = read(os.path.join(D, 'out', 'lmp1_banner_static.txt'))
        ok('<BUILD_USER>' in bs and '3.8.0' in bs, f't2: 정적 배너 · 빌드 사용자 가림 {bs.strip()[:90]}')
        ok(f.get('acl1.named_entries') == ['1'], f"t2: ACL 이름 붙은 항목 수 {f.get('acl1.named_entries')}")
        ok(f.get('first8.e0_deck_vs_static') == ['different'], 't2: first8 E0 덱 = different')
        q = read(os.path.join(D, 'out', 'quota_s.txt'))
        ok('<USER>' in q and 'uid <UID>' in q, f't2: quota 가림 {q.strip()}')
        ok(f.get('mpi.n_unique_found') == ['1'], f"t2: mpirun 1 개 (mpirun → orterun 중복 제거) {f.get('mpi.n_unique_found')}")
    for n in ('t3a', 't3b'):
        meta, outside, removed, changed = new_dirs(T, n, H3)
        ok(not meta and not outside and not removed and not changed, f'{n}: 게이트 — 아무것도 안 만듦 (새 {len(meta) + len(outside)} · 변경 {len(changed)})')
        ok(not os.path.exists(os.path.join(T, n + '.sentinel')), f'{n}: 금지 명령 0')
    ok('아무것도 안 함' in read(os.path.join(T, 't3a.stdout')), 't3a: 한 글자 깨짐 = md5 다름 문구')
    r = common_exec(T, 't3c', H3, md5)
    if r:
        D, f, pr, so = r
        ok(f.get('switch.MIX_SLURM') == ['0'], 't3c: 대화형 bash -i 로도 돎 (느낌표 · 기록 확장 문제 없음)')
    r = common_exec(T, 't4', H4, md5)
    if r:
        D, f, pr, so = r
        ok(st(pr, 'lmp1_help') == 'SKIPPED_SWITCH' and st(pr, 'slurm') == 'SKIPPED_SWITCH', f"t4: 스위치 — lmp -h · SLURM 안 부름 ({st(pr, 'lmp1_help')} · {st(pr, 'slurm')})")
        ok(st(pr, 'repo1_status') == 'FAIL' and st(pr, 'repo1_diff_index') == 'OK' and st(pr, 'repo1_untracked') == 'OK',
           f"t4: 옛 git — status 실패 → plumbing 대체 OK ({st(pr, 'repo1_status')} · {st(pr, 'repo1_diff_index')} · {st(pr, 'repo1_untracked')})")
        ut = read(os.path.join(D, 'out', 'repo1_untracked.txt'))
        ok('notes.txt' in ut, f't4: 추적 안 된 파일 보임 {ut.strip()}')
    r = common_exec(T, 't5', H5, md5)
    if r:
        D, f, pr, so = r
        nb = sum(1 for c in pr.values() if c[1] == 'SKIPPED_BUDGET')
        ok(nb > 0, f't5: 예산 1 초 — SKIPPED_BUDGET {nb} 개 · 묶음은 만듦')
    rd = []
    for n, h in (('t1', H1), ('t2', H2)):
        meta = new_dirs(T, n, h)[0]
        if meta:
            D = meta[0]
            dest = os.path.join(T, 'read_' + n)
            p = subprocess.run([sys.executable, '-I', os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'read_meta_bundle.py'),
                                os.path.join(D, os.path.basename(D) + '.tgz'), dest, '--expect-md5', md5,
                                '--expect-sha256', read(os.path.join(D, os.path.basename(D) + '.tgz.sha256')).split()[0]],
                               capture_output=True, text=True, timeout=120)
            with open(os.path.join(T, 'read_' + n + '.txt'), 'w') as fo:
                fo.write(p.stdout + p.stderr)
            ok(p.returncode == 0, f'reader {n}: rc {p.returncode} (빈 폴더에 풀기 · SHA256SUMS · md5 대조)')
    print('\n'.join(R['lines']))
    print(f"== PASS {R['pass']} · FAIL {R['fail']}")
    json.dump(R, open(os.path.join(T, 'check_result.json'), 'w'), ensure_ascii=False, indent=1)
    return 0 if R['fail'] == 0 else 1


if __name__ == '__main__':
    sys.exit(main())

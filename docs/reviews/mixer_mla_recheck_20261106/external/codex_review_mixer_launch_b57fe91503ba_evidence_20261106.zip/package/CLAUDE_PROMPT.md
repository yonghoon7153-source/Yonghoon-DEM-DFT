# mixer-launch 준비 쪽지 — 반입 시점은1저자

`codex/mixer-1104` · `b57fe91503ba68cec6f41aec247851262788e48f`의 `docs/collab/codex_to_claude/20261106-0455_mixer-launch-preparation.md`과 같은 폴더 ledger_proposal.json을 읽어 주세요.
이번 범위는 첫8 정적 덱·자산과 비활성 정책·한 팔 발사/작업시작/감시/회수/중단 초안 및 모의 경계 검사입니다. 새 외부 반박 리뷰는 대기이며 자체 종결하지 않았습니다. 실제 실행/값 열람/제출/활성 등록/공유 원장 변경은 없습니다. Rint②우선·전체 HOLD 유지.

기준 main18bb에는 기존 첫4커밋의 반입본이 이미 있으므로 반복하지 않습니다. 정확한 대응은 INTEGRATION.json을 참조하세요. 아직 남은 선행 체인과 새 단위 순서는:
- d0107959955f284df56cb546ee008595d26dac61 — Draft precalibration mixer exploration map
- 0f284e7db65278acb52dd4666b1b22151604e9ba — Record precalibration map acceptance and clarify wall forces
- 6d9d838a931bf2269d7bd43f22fe61c904f4b9ac — Record independent PRECAL NOTE01 confirmation
- 189930cc68b6e58beb6b4546d80353dc03852195 — Prepare first8 precalibration mixer contracts and observations
- ec484c2719d6a444214ddc9c48fe683a7735688b — Bind precal observation inputs and loaded source bytes
- cce92af161fa5385fd2fd895ae5c85adb786ce01 — Record scoped external acceptance of PRE8 bindings
- b5331d89e9029a1e372d320acee31cddce41474e — Preserve recovered PRE8 metadata bytes
- eb400b9dde3d630d8d4571d48b879ef5093d08e5 — Draft mixer damping applicability and resource update
- 7e40b7f2398a82cd5ae04b84017c0a9e1a89d521 — Record external acceptance of mixer damping draft
- b57fe91503ba68cec6f41aec247851262788e48f — Prepare first8 mixer single case launch and collection drafts

동기화 merge `527e244e4ebd6f0cb04c6cfb2ff5f3a52fb01996`는 cherry-pick 대상에서 제외합니다. 실제 반입 때 당시 main의 동일내용 여부를 다시 대조하고 1저자가 정한 시점에 cherry-pick -x합니다. 지금 자동 통합·실행하라는 요청이 아닙니다. 새 외부 판정이 오면 수용 범위/남은 조건을 함께 전달합니다.

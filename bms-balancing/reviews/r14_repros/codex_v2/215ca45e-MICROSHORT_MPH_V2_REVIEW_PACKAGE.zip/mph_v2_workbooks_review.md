# Workbook audit for the COMSOL microshort review v2

Target: `d72e735fed52a06b4a4e739fdbd2c71fa9e8a3b6`, principally `bms-balancing/docs/MICROSHORT_MPH_REVIEW.md` §2 and §5-2 and `bms-balancing/reviews/REQ_FIT_RAILS.md`. This is a scientific audit of the supplied result workbooks and their numerical correspondence to the MPH parameters. It is not an R13 harness review.

The documented four identities and the counts of repeated alpha values reproduce. There is an additional identity in **all 37 rows** that the v2 discussion omits:

```text
c_lit = C_cell * (a_PE + b_PE - b_NE)
```

Its maximum absolute reconstruction error is **0.0 in each workbook** when the stored numeric tokens are parsed as binary64 and the operations are evaluated in that order. LLI therefore differs from capacity loss but is not an additional unconstrained output once those alpha/beta values and capacity are specified. The files also establish equality of two reported LAM values on particular rows; they do not establish an optimizer bound, a loss of identifiability, a null direction of the voltage model, or the magnitude of parameter uncertainty.

## 1. Complete source coverage and scope

All workbooks were read directly from their OOXML ZIP contents without modifying or exporting them. Every stored cell, formula element, cached value, row/column attribute, sheet, relationship, number format, and defined name was inspected and retained in the JSON evidence. Original workbook hashes were identical before and after the audit. No source refresh, Excel recalculation, fitting, COMSOL computation, or new workbook was performed.

The source directory is `C:/Users/Administrator/Documents/카카오톡 받은 파일/`.

| Short name | Exact filename | Sheet and complete populated range | Data rows | Cycles |
|---|---|---|---:|---|
| ref1 | `result_L_ref#1 _0.1C 12h__charge.xlsx` | `Sheet1!A1:K11` | 10 | 0–9 |
| ref2 | `result_L_ref#2 _0.1C 12h__charge.xlsx` | `Sheet1!A1:K11` | 10 | 0–9 |
| PE1 | `result_L_PE#1 _0.1C 12h__charge.xlsx` | `Sheet1!A1:K11` | 10 | 0–9 |
| PE5 | `result_L_PE#5 _0.1C 12h__charge.xlsx` | `Sheet1!A1:K8` | 7 | 0–6 |

There are **37 data rows across four files**, not 37 ref1 rows. This agrees with `REQ_FIT_RAILS.md:26`. The files contain 451 stored cells: 44 text headers and 407 numeric data cells. Each has one visible sheet, no missing table entries, no duplicate cycle labels, no cells beyond the stated rectangle, no error-valued or nonfinite cells, and no hidden data sheets. The package inventories contain only workbook, style, shared-string, worksheet, and relationship parts. There are no raw voltage traces, time series, residual arrays, charts, comments, external data links, or optimizer settings elsewhere in these workbooks.

There are **zero Excel formulas and therefore zero formula-result caches**. These are literal exported results. `fullCalcOnLoad=true` appears in workbook metadata, but with no formulas it does not supply calculation provenance or indicate that fitting will rerun. All populated cells use the default General style. A spare date-format style exists in the styles part but is not applied to the data.

| Column | Header | What can be established from this audit |
|---|---|---|
| A | `cycle` | Integer record labels. No calendar dates or sampling times. |
| B | `C_cell` | Positive stored capacity values; workbook headers provide no unit. |
| C | `x_cell` | Equals each B value divided by B2. Dimensionless ratio. |
| D–G | `a_PE, b_PE, a_NE, b_NE` | Stored fit-coordinate quantities; their operational definitions and physical normalization are absent. |
| H | `c_lit` | Equals B × (D + E − G). Absolute unit is not labeled. |
| I–K | `LAM_PE, LAM_NE, LLI` | Dimensionless normalized differences reproduced below; fractions, not percentage-point integers. |

The MPH uses `C_lit0_ref1` in Ah and its numeric value matches ref1 H2 at the stated precision. This supports the intended transfer convention, but **the workbook alone does not certify its capacity unit or its physical lithium-inventory definition**. The filename's `0.1C 12h__charge` is a source label, not a recorded protocol or voltage trace. In particular, workbook `b_PE` is a fitted shift coordinate; the MPH parameter with the same spelling is a Bruggeman exponent. The shared spelling is not a parameter mapping.

## 2. Recomputed identities, including the missing dependence

For each workbook separately, use its own cycle-0 row (Excel row 2). The equations tested on every subsequent row, including the baseline, are:

```text
x_cell = C_cell / C_cell0
LAM_PE = 1 - x_cell*a_PE/a_PE0
LAM_NE = 1 - x_cell*a_NE/a_NE0
LLI = 1 - c_lit/c_lit0
c_lit = C_cell*(a_PE+b_PE-b_NE)
```

The maximum absolute errors reproduce the v2 table for the first four equations:

| File | x_cell | LAM_PE | LAM_NE | LLI | Additional c_lit identity |
|---|---:|---:|---:|---:|---:|
| ref1 | 0 | 1.387779e-16 | 5.551115e-17 | 4.163336e-17 | 0 |
| ref2 | 0 | 2.567391e-16 | 1.595946e-16 | 4.857226e-17 | 0 |
| PE1 | 0 | 9.714451e-17 | 8.326673e-17 | 5.551115e-17 | 0 |
| PE5 | 0 | 1.387779e-16 | 5.551115e-17 | 5.551115e-17 | 0 |

These are explicit maximum errors, not a default `allclose` acceptance test. They describe agreement of stored numerical outputs, not accuracy of the electrochemical model or underlying measurements.

Exact source ranges for the additional identity are B2:B11, D2:E11, G2:H11 in ref1, ref2, and PE1; B2:B8, D2:E8, G2:H8 in PE5. For a concrete ref1 cycle-2 example, B4 = 0.003800359, D4 = 1.1041030778540413, E4 = −0.15683805380755067, G4 = 0, and H4 = 0.003599947159520297. The multiplication reproduces H4 exactly in binary64.

The same identity gives:

```text
s = a_PE+b_PE-b_NE
LLI = 1 - x_cell*s/s0
LLI - (1-x_cell) = x_cell*(1-s/s0)
```

Directly rebuilding LLI through this expression differs from the stored LLI by at most 1.804113e-16 across the four files. Thus the v2 correction that **LLI does not equal `1-x_cell` on the postbaseline rail rows is correct**. It should not be expanded into proof that LLI is statistically independent, independently measured, uniquely identified, or derived from a fifth unconstrained fitted variable. An exact output relation alone also does not reveal computation direction: c_lit could have been derived from beta, beta derived from c_lit, or both related by a constraint. The MATLAB parameter vector is needed to say what was actually optimized.

This matters to `MICROSHORT_MPH_REVIEW.md:139` and `REQ_FIT_RAILS.md:47`, which assert the actual fitted-variable list without source code. It also qualifies `MICROSHORT_MPH_REVIEW.md:503`–505: at fixed capacity and betas, varying a_PE changes both LAM_PE and LLI through the observed formulas. Holding LLI fixed while varying a_PE requires compensating beta changes, for example Δb_PE = −Δa_PE when b_NE is fixed. Independent physical sensitivity sweeps remain possible, but a rectangular parameter sweep is not an empirically calibrated joint uncertainty region just because the LLI values differ from capacity loss.

## 3. Repeated alpha values: confirmed data, narrower inference

The repeated a_PE values are identical both as stored XML numeric strings and as parsed binary64 values. Each file's a_NE values are also identical internally.

| File | a_NE value within file | a_PE equals its baseline at cycles | Exact a_PE cell locations | Count |
|---|---:|---|---|---:|
| ref1 | 1 | 0, 3–9 | D2 and D5:D11 | 8/10 |
| ref2 | 1.020080608741945 | 0, 5–9 | D2 and D7:D11 | 6/10 |
| PE1 | 1.0240193955979178 | 0, 2–9 | D2 and D4:D11 | 9/10 |
| PE5 | 1 | 0–6 | D2:D8 | 7/7 |

No a_PE value exceeds that file's baseline. Cycle 0 is one of the maxima; the maximum is not unique. The 30/37 total includes four baseline rows that equal themselves by construction. Excluding those baselines gives **26/33** repeated-alpha rows. These are useful diagnostics, not 30 independent demonstrations of an optimizer touching a bound. Also, “a_NE is identical across 37 rows” is inaccurate if read across files: there are three distinct a_NE values in the combined population. The correct statement is “constant within each file.”

The listed rows match the rows satisfying `abs(LAM_PE-LAM_NE) <= 1e-9*abs(LAM_NE)`, with zero absolute tolerance. Their two LAM outputs equal `1-x_cell` up to the measured floating-point discrepancies. Because a_NE is constant within every file, **LAM_NE alone reduces to `1-x_cell` on all 37 rows**, not merely the a_PE rail rows.

The closed-form equality follows from the reported ratios; it does not depend on discovering an upper bound. Accordingly, B4/B5 should distinguish the observable restriction of these exported points from a claim about optimizer constraints or the forward model's information content.

A simple logical counterexample establishes that equal estimates do not prove nonidentifiability. Let a hypothetical observation model be

```text
y1 = LAM_PE + LAM_NE
y2 = LAM_PE - LAM_NE
J = [[1, 1], [1, -1]], det(J) = -2
```

At any point where LAM_PE = LAM_NE, y2 = 0, yet both parameters remain uniquely recoverable and the Jacobian remains full rank. This is a mathematical counterexample to the inference, not a fitting experiment or a claim about actual battery observations. It shows why “equal reported LAM outputs” cannot establish “zero information to distinguish the electrodes.” The actual observation map, residual surface or profile, and constraints are needed.

Similarly, later ref1 rows are not the same parameter point: I5 is 0.036633118191882544 whereas I11 is 0.07297871551632154, and K5/K11 change from 0.05818459186976609 to 0.10847827461637723. They lie at different positions on the reported equal-LAM locus. The stronger language at `MICROSHORT_MPH_REVIEW.md:162`–169 and `REQ_FIT_RAILS.md:65`–98 should be narrowed. Merely being off that locus does not show ref1 cycle 2 is more reliable or better identified than another cycle.

## 4. Exact-zero and LLI-range corrections

`MICROSHORT_MPH_REVIEW.md:150` and the rails table incorrectly call every postbaseline b_NE exactly zero. There are two finite, numerically negligible exceptions:

| File | Cycle | Cell | Stored value |
|---|---:|---|---:|
| ref1 | 8 | G10 | −2.1778531752142977e-17 |
| PE5 | 4 | G6 | −1.762553861534616e-16 |

The ref1 and PE5 baseline values at G2 are −0.003024815249939983 and −0.0007604515116410196 respectively. Exact zero counts are ref1 8/10, ref2 10/10, PE1 10/10, and PE5 5/7. With `abs(b_NE)<1e-15`, the counts become 9/10, 10/10, 10/10, and 6/7. The reproduction code in `REQ_FIT_RAILS.md:116` labels this tolerance test as “b_NE == 0”; the label should state its tolerance. This is a wording/diagnostic precision correction, not a material physical difference.

| File | LLI − (1−x_cell), postbaseline repeated-a_PE rows |
|---|---|
| ref1 | 0.021551473677883563 to 0.035499559100055714 |
| ref2 | 0.02110593689162661 to 0.030342579174297682 |
| PE1 | 0.01632581379440172 to 0.05277736215527906 |
| PE5 | 0.01162107330790925 to 0.026666247457853676 |

For ref1 the inputs are C5:C11 and K5:K11. The shorthand “0.0216–0.0355 on rail rows” must exclude cycle 0. Including cycle 0 makes the lower endpoint 0. The reproduction section of the rails request correctly clarifies this distinction.

## 5. Numerical correspondence to the original MPH

The audit read the original `ICA_degradation mode.mph`, SHA-256 `8b2e71506ba2a5ebad1ce27e268417b0e74b28cbaa9a81d1a6c32c58573557a9`, directly and extracted the named expression values from `dmodel.xml`. Each match below is unique among all 407 stored numeric cells within half a unit of the MPH number's last printed decimal digit.

| MPH expression | Matching source cell | Stored source value | Source minus MPH |
|---|---|---:|---:|
| LAM_PE = 0.0296398242 | ref1 I4 | 0.029639824168682806 | −3.1317194e-11 |
| LAM_NE = 0.0257219788 | ref1 J4 | 0.025721978780813833 | −1.9186167e-11 |
| LLI = 0.0439355 | ref1 K4 | 0.043935523277593341 | +2.3277593341e-8 |
| C_lit0_ref1 = 0.003765381[Ah] | ref1 H2 | 0.0037653811507166184 | +1.507166184e-10 |
| dNE = −0.00302481525 | ref1 G2 | −0.0030248152499399829 | +6.00171e-14 |

Ref1 A4 is cycle 2. This is strong numerical correspondence to the proposed row and baseline cells. It does not independently prove causal copy history, a hand calculation, or author intent. The row is one of ref1's two nonbaseline-a_PE rows, D3:D4, as the v2 document says.

For the MPH's own displayed LAM values, `1-LAM_NE = 0.9742780212` and `1-LAM_PE = 0.9703601758`. The stored dm values differ by −1.2e-9 and +4.2e-9 respectively. They are consistent with rounding to eight decimal places. In particular the PE value rounds **up**, so strict truncation is not an accurate characterization. The numerical match cannot show whether this was done manually.

No numeric source cell matches dPE = 0.0101000283 to its printed precision. This confirms “not directly present in these four result tables,” not that the value lacks a derivation or external source. No candidate derivation was invented. Absence from a result table also does not make a parameter erroneous.

## 6. Concise answers to REQ_FIT_RAILS Q1–Q5

1. **Alternative explanation:** postprocessing that clamps or copies selected alpha outputs, a deterministic fit initialized at the same stationary point, or a chosen reference-electrode normalization can produce repeated values without the proposed optimizer bound. These are alternatives to test, not findings that any one occurred. Within-file constancy does not identify which parameter was free, and no probability model supports the assertion that repeated bits have zero probability. MATLAB's parameter list, normalization, bounds, and export logic are the direct evidence to request.
2. **B4/B5:** the reported equal-LAM locus is real and survives either proposed explanation, but the inference to zero electrode-identification information does not. Equality of fitted values and nonidentifiability are different properties, as the full-rank counterexample shows. Repeated outputs alone cannot justify a forward-model null direction or demonstrate that later cycles contain no new information.
3. **Alpha interpretation:** the supplied equations establish ratios of the numerical proxies `C_cell*a_PE` and `C_cell*a_NE`. Calling those proxies physical electrode capacities requires the fit's coordinate definitions and half-cell normalization. The result workbooks contain neither. This audit therefore does not certify a literature convention or the physical capacity mapping. The extra c_lit identity should be included before assigning the number of fit degrees of freedom.
4. **Detection:** report per-file constant-value runs, exact and tolerance-based zero counts separately, repeated-alpha counts both with and without the baseline, paired LAM equality with explicit tolerance, and the existing output identities. Describe observed maxima as maxima until the configured bound is available. These should be review warnings, not data-rejection rules: correct or intentionally constrained fits can produce them. If optimizer metadata later supplies bounds and activity flags, report those separately from output-based inference.
5. **Communication:** “Your parameter uncertainty covers the conclusion” is not yet measured. A supported statement is: “The exported LAM values coincide on 26 of 33 postbaseline rows; we need fit constraints, residual/profile information and the joint parameter range before deciding whether separate electrode degradation or the microshort conclusion is resolved.” A chosen sensitivity sweep can show response to chosen perturbations, but its width is not an uncertainty estimate unless its joint input region is independently justified.

## 7. Reproducibility and remaining limits

Source hashes:

| File | SHA-256 |
|---|---|
| ref1 | `40244664d69880788382a32cca887d9a8363233921f71e2e71fbc45cdef43d84` |
| ref2 | `a1f09b88c6e29c279b604187ddb84efa73f960425925e82e09546d8c63aa98ad` |
| PE1 | `c0c319e48413ff60ab6d0337e85fc956f9edc4a778abc94c7da0a24c7be1697c` |
| PE5 | `beb4e4372b09446a2ed2081cb4d973cae3aa2df5af10d589c65734b41f4b87d6` |

`mph_v2_workbooks_audit.py` produces `mph_v2_workbooks_evidence.json`, which contains every stored cell with its XML token, numeric value, formula/cache status, every row's independent recomputation, and source-match tolerances. The script uses only standard-library read-only ZIP/XML extraction for the workbooks, followed by arithmetic and JSON evidence output. The original source files are unchanged.

The workbook audit does not establish MATLAB implementation, measurement uncertainty, raw curve quality, physical alpha/beta definitions, exact unit contracts, fit bounds or convergence, joint fit covariance, COMSOL runtime behavior, or optimizer-to-MPH copying provenance. Those are the evidence gaps that remain after the numerical claims have been checked.

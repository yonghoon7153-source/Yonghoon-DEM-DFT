#!/bin/bash
# build_block.sh — query_script_b.sh 를 붙여넣기 블록으로 (11-12 조회 블록 build_block.sh 와 같은 검사 · DEM1 make_block.sh 꼴)
#   bash build_block.sh <query_script_b.sh> <query_block_b.txt>
#   검사: bash -n · 느낌표 (history 확장) · 탭 · CR · 줄 첫 글자 ^ · 구분자 줄 · 끝 개행 · 크기 (인자 한 개 상한 128 KiB 보다 작게)
#   블록 = 머리 주석 (스크립트 md5 · 승인 범위) + 본문을 셸 변수에 담는 heredoc + md5 를 대조하고 맞을 때만 bash -c 로 도는 마지막 줄
set -u
S=$1; OUT=$2; DELIM=MIX_E0_QUERYB_EOF; BAD=0
[ -s "$S" ] || { echo "사용법: bash build_block.sh <스크립트> <블록>"; exit 2; }
bash -n "$S" || { echo "FAIL bash -n"; BAD=1; }
n=$(tr -cd '\041' < "$S" | wc -c); [ "$n" = 0 ] || { echo "FAIL 느낌표 $n 개"; grep -n "$(printf '\041')" "$S" | head -5; BAD=1; }
n=$(tr -cd '\t' < "$S" | wc -c); [ "$n" = 0 ] || { echo "FAIL 탭 $n 개"; BAD=1; }
n=$(tr -cd '\r' < "$S" | wc -c); [ "$n" = 0 ] || { echo "FAIL CR $n 개"; BAD=1; }
grep -q '^\^' "$S" && { echo "FAIL 줄 첫 글자 ^ (history 빠른 치환)"; BAD=1; }
grep -qx "$DELIM" "$S" && { echo "FAIL 본문에 구분자 줄"; BAD=1; }
[ "$(tail -c 1 "$S" | od -An -c | tr -d ' ')" = '\n' ] || { echo "FAIL 끝 개행 없음"; BAD=1; }
sz=$(wc -c < "$S"); [ "$sz" -lt 120000 ] || { echo "FAIL 스크립트 $sz 바이트 — bash -c 인자 한 개 상한 (128 KiB) 에 가깝다"; BAD=1; }
[ "$BAD" = 0 ] || exit 1
M=$(md5sum < "$S" | cut -c1-32)
{
  echo "# 믹서 E0 보충 조회 블록 q9b · q2b · q7b · 스크립트 md5 $M · 읽기 전용 · ibb 로그인 셸 (bash) 에 통째로 붙여넣기 — 마지막 줄이 같은 md5 를 대조하고 맞을 때만 돈다 · 새 폴더 ~/mixer_e0_queryb_<UTC>/ 하나에만 쓴다"
  echo "# 승인 범위 = 1저자 11-12 밤 오버나잇 \"권고대로\" = 등록 초안 18 절 2 회차 Q-F′ (q9b 로그 다섯 + dev-bo · dev-u) · Q-G′ (q7b conda 꾸러미 파일 해시) · Q-K (q2b 프레임 줄 끝 꼴) · 13-1 · 숫자 값 · 본문 · 경로 문자열은 안 옮김"
  echo "IFS= read -r -d '' MIX_E0_QUERYB_SH <<'$DELIM' || true"
  cat "$S"
  echo "$DELIM"
  echo "MIX_MD5=\$(printf '%s' \"\$MIX_E0_QUERYB_SH\" | timeout 10 md5sum 2>/dev/null); if [ \"\${MIX_MD5%% *}\" = $M ]; then BASH_ENV= bash -c \"\$MIX_E0_QUERYB_SH\" mixer_e0_queryb \"\$MIX_E0_QUERYB_SH\"; else echo \"붙여넣기가 깨짐 (md5 다름) 또는 md5sum · timeout 없음 — 아무것도 안 함\"; fi; unset MIX_E0_QUERYB_SH MIX_MD5"
} > "$OUT"
n=$(tr -cd '\041' < "$OUT" | wc -c); [ "$n" = 0 ] || { echo "FAIL 블록 느낌표 $n"; exit 1; }
n=$(tr -cd '\t\r' < "$OUT" | wc -c); [ "$n" = 0 ] || { echo "FAIL 블록 탭/CR $n"; exit 1; }
grep -q '^\^' "$OUT" && { echo "FAIL 블록 줄 첫 글자 ^"; exit 1; }
bash -n "$OUT" || { echo "FAIL 블록 bash -n"; exit 1; }
echo "OK $OUT · 스크립트 md5 $M · 블록 $(wc -l < "$OUT") 줄 $(wc -c < "$OUT") 바이트 · 스크립트 $(wc -l < "$S") 줄 $(wc -c < "$S") 바이트 · 최장 줄 $(awk '{ if (length($0) > m) m = length($0) } END { print m }' "$S") 바이트"

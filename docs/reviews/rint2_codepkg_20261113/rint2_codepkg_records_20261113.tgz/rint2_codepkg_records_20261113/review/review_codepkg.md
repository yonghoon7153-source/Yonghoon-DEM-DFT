# 내부 반박 리뷰 (Codex 아님) · 대상 af3cce37b..2f97617ef · 11-12

- 대상 = 작업 트리 `/home/user/rint-codepkg` 의 커밋 셋 (ebb0e9f80 시험 먼저 · f17ea8c6b 구현 · 2f97617ef 시험 보강) · 읽기만 (git 상태 바꾸지 않음).
- 차례 = diff + 의도 문서 (README 결정 절 · 벤치 README · design.md · BRIEF_codepkg · BRIEF_evac) 로 먼저 판단 → 반례 · 변이 → 마지막에 notes · amend_drafts 로 주장 대조.
- 실험 자리 = `review/work/new` (`git archive 2f97617ef` 의 scripts · webapp · docs/data · 필요한 docs/reviews 몇) · `review/work/base` (같은 사본에 바뀐 파일만 af3cce37b 판 + 시험 먼저 커밋의 시험) · `review/work/mut` (하드링크 사본 · 변이 파일만 갈아 끼움).  기반 판 `git show` 는 원 저장소 객체를 `GIT_DIR` 로 읽기만.  사본 폴더 (`review/work/*`) 는 끝나고 지웠다 (다시 만들기 = 같은 `git archive` · 기록 = `review/logs/` · 반례 = `review/ce/` · payload 대조 산출 = `review/ovbwd/`).
- 돌린 것: 새 시험 둘 (3.11.18 · numpy 2.4.6 · scipy 1.17.1 / kgy 판 3.8.20 · 1.24.4 · 1.10.1) · 고치기 전 판 재현 · 반례 CE1 · 옛 cupy 꼴 탐침 · 변이 31 · payload 끔 길 ↔ 바탕 대조 · 사슬 전체 (3.11).  킷 풀이 · GPU · σ 열람 없음 · 신호 실험 없음 (기존 T10 은 시험 안에서 PID 이름공간).
- 판정 아님 — 지적 목록이다 (1저자 11-10 운영 결정 · Codex verified 로 올리지 않는다).

## 1. 지적 (P1 1 · P2 3 · P3 7)

| 번호 | 등급 | 어디 (파일:행 · 2f97617ef) | 반례 · 재현 | 고칠 방향 |
|---|---|---|---|---|
| RCP-01 | **P1 (조건부)** | `scripts/cjunc_store.py:56–57` (`CODE_MODULES`) · 9 줄 (머리 "코드 파일 sha256 … 셋") · `scripts/carbon_junction.py:743` (`_positions`) → 587 · 605 (`fibre_segment_raster.segment_cells`) | 원장 짓기는 `fibre_segment_raster.py` 를 부르는데 열쇠의 코드 칸은 carbon_junction · step3_sigma · cjunc_store 셋뿐 (56 줄 "원장 코드 = 이 파일들" · 설계 (나) "실제 불러온 모듈 파일" 과 다름).  **CE1** (`review/ce/ce1.py` · 출력 `review/ce/ce1_out.txt`): 원 코드로 조밀 침대 원장을 지어 저장 (`built_written`) → `segment_cells` 의 칸 **차례만** 뒤집은 판 (칸 집합 그대로 → sid 지문 `7146035b24bd` 같음) 에서 같은 폴더 → 열쇠 `85ebe5ae…` 같음 → **`hit`** (짓기 0 회) · 옛 원장 (registry_fp `f24cbd6245dc` · 위치 833) 을 돌려준다 · 지금 코드로 지으면 `202eb91e965d` (위치 1,911).  머리 · 엄격 지문 · registry_fp · sid 지문 대조를 다 지난다 (파일 자체는 자기 일관).  비 SV 팔은 독립 재조립이 없으므로 (`scripts/rint_r_chain.py:2307` `graph_applicable` 만) 멈춤 없이 팔 결과 (계획 · σ) 가 바뀐다.  조건 = 저장본 폴더가 `fibre_segment_raster.py` 가 다른 코드 판 사이에서 다시 쓰일 때 (설계가 "시도 사이 재사용 · 다른 코드 = 열쇠가 달라 짓는다" 를 약속하는 흐름 · 그 파일 마지막 변경 08-12).  래스터 (sid) 와 원장이 같은 `segment_cells` 를 쓰므로 칸 **집합**을 바꾸는 변경은 대개 sid 도 바꿔 열쇠가 갈리지만, 차례 · 상자 밖 칸 (원장은 `lin = -1` 로 남김 · 래스터는 버림) · 다른 상에 덮이는 칸만 바꾸는 변경은 sid 를 안 바꾼다 | (가) `CODE_MODULES` 에 `fibre_segment_raster` 더함 + 시험: 원장 짓기 동안 새로 불러온 `scripts/` 모듈 집합 ⊆ 열쇠 코드 칸 (import 갈고리 · 지금 시험은 이 집합을 재지 않는다 — 변이 MS16 = 열쇠에서 step3_sigma 를 빼도 안 잡힘) · (나) 또는 코드 칸 = 사슬 `CODE_FILES` 전체 (봉인 코드 신원 · 과결속이지만 단순) · (다) 겹 방어 = RCP-03 (가) · 개정 초안 37 줄 "코드 sha256 셋" 문장도 같이 |
| RCP-02 | P2 | `scripts/check_all.sh` · `scripts/check_kgy_py38.sh:48–60` (둘 다 이 범위에서 안 바뀜) · `scripts/check_method_discipline.py:788` (규칙 K = 정해진 selftest 만) | 새 시험 셋 (`test_step3_gpu_precond.py` · `test_cjunc_store.py` · `test_cjunc_store_e2e.py`) 이 게이트 · kgy 판 단계 · CI 어디에도 없다 → 반입 뒤 `cjunc_store` · `_solve_cg` 를 누가 바꿔도 게이트가 초록 (규율 ⑤ "검사기가 수동이면 없는 것과 같다").  알려짐 = `amend_drafts.md` 97–103 줄 ⬜ (본 세션 몫) — 잊지 않게 등급을 단다 | 반입 커밋에서 게이트 + kgy 판 두 목록에 배선 (precond 2 s · store 1 분 안팎 · 사본에서 kgy 판 15/15 · 46/46 확인함) · e2e (십수 분) 는 넣을지 결정 |
| RCP-03 | P2 | `scripts/cjunc_store.py:29–30` (한정 문장) · `scripts/ca_s0_census.py:1412` · `1426–1427` (`fp_use: record_only`) · `scripts/ca_ext_cjunc.py:262` · `317` · `scripts/rint_r_chain.py:2307` · `2461` | 저장본에서 온 원장을 독립으로 견주는 곳이 SV 모서리 팔의 끝 그래프 (봉인 원천) 뿐인데, 모듈 머리는 "자기 일관 위조 … 그 몫 = 봉인 원천 재조립 대조" 로 범위 없이 적는다 (개정 초안 61 줄은 "SV 모서리 팔만 · 다른 팔은 같은 코드의 결정성 가정" 으로 바르게 좁혔다 — 그 가정은 RCP-01 때문에 지금 서지 않는다).  S0 단계 2 보고가 봉인 문턱 · off 격자 원장 지문을 이미 싣고 ("지문은 기록만 · 지금 대조 안 함"), 팔 JSON 은 쓴 원장 지문 `fp.registry` 를 싣는다 → 같은 규약 DBE arm 0 팔은 대조가 공짜인데 안 한다.  그래서 RCP-01 꼴 낡은 원장 · 위조 원장이 비 SV 팔에서 조용히 지나간다 | (가) `read_run` 에서 같은 규약 · arm 0 팔의 증거 `fp.registry` = S0 단계 2 봉인 원장 지문 (`s0_census_seed` 와 같은 키 규칙 · 다르면 `S0_REPORT_MISMATCH`) · (나) 머리 docstring 범위 정정 · (다) SBE 사다리 팔 (S0 단계 1 = 봉인 전 문턱이라 대조 자리 없음) 은 열쇠마다 저장본 없이 한 번 지은 원장 지문과 견주는 길을 둘지 = 1저자 결정 |
| RCP-04 | P2 | `design.md` (마) 끝 "한정" · `scripts/cjunc_store.py:94–115` (`_order` · `_check_array` · 읽기 전용 · 비연속) · 214–224 (겹침) · 542–548 (발행 전 다시 읽기 = 원장 사본 하나 더) | 실침대 원장이 저장 꼴 안인지 (보기 · 겹침 · 읽기 전용 → `Unsupported` = 저장 안 함) · 쓰기 · 다시 읽기의 시간 · 최대 메모리가 R 첫 SBE 팔 전에는 잴 자리가 없다 (⑥ 시도 3 · S0 = 저장본 끔).  첫 팔에서 `⚠ … 저장 안 함` 이면 Q2 이득 (82–225 h · 마감 12 월 초의 근거) 이 조용히 0 (사슬은 그 줄을 안 본다 · RCP-07) · 메모리 넘침이면 그 런이 멈춘다 (⑥ RSS 최대 32.9 GiB) | S0 단계 1 다시 (kgy · CPU · 어차피 돈다) 때 그 원장으로 `encode_strict` → 쓰기 → 읽기 (스크래치 폴더) 의 상태 · 시간 · 최대 RSS 를 재고 기록 (결과 전 기대 먼저 · 원장 줄 문장 = 본 세션) |
| RCP-05 | P3 | `scripts/cjunc_store.py:363–373` (`machine_fp`) · 445–452 (`key_parts`) · 437–440 (코드 칸 = `Store()` 때 디스크 파일 해시) · `scripts/run_contract.py:1458–1472` | 환경 칸 = python 부 판 · numpy · scipy 판 글자뿐 · 기계 칸 = `/etc/machine-id` 뿐 · 코드 칸 = 불러온 코드가 아니라 그때의 디스크 파일.  같은 기계 두 venv (판 같고 빌드 · BLAS 다름 — 원장 길 `np.linalg.norm(d)` 1 차원 = BLAS dot · `fibre_segment_raster.py:76`) · 복제 이미지로 machine-id 가 같은 두 기계 사이에 폴더를 옮김 → 같은 열쇠.  실제 원장 차이는 재현 못 함 (반례 없음 · 위험 낮음) | 인터프리터 실경로 + numpy · scipy 패키지 파일 지문 (또는 빌드 설정 해시) · 기계 칸에 사슬 `--machine` 이름표를 더할지 = 판단 |
| RCP-06 | P3 | `scripts/cjunc_store.py:657–662` (`_read_members`) · 422–433 (폴더만) | 읽을 때 파일의 소유자 · 모드 (그룹 · 남 쓰기) · 링크 수는 보지 않는다 (보통 파일 · 심볼릭 아님만) · 뿌리 폴더는 `os.stat` (심볼릭 링크 따라감).  손으로 0666 이 된 파일 · 폴더가 0777 이던 때 남이 넣은 파일 (뒤에 0755 로) = 자기 일관이면 받는다 | 파일도 소유자 = 이 사용자 · 모드 & 0o022 = 0 (아니면 어긋남 · 멈춤) · 뿌리 `lstat` |
| RCP-07 | P3 | `scripts/cjunc_store.py:533` · `scripts/test_cjunc_store.py:1235` (T10a 가 남은 임시 파일을 기대값으로 고정) · `scripts/rint_r_chain.py:6587–6588` · `6791–6792` | 끊긴 쓰기의 `.cjreg_*.tmp` (원장 크기) 는 안 지워지고 · 못 읽는 최종 파일은 덮어쓰지 않아 그 열쇠의 팔은 매번 다시 짓는다 · 상태 (읽음 · 저장 안 함 · 못 읽음) 는 payload 화면 한 줄뿐 · 사슬 요약은 `cjunc_store: True` (폴더 · 런별 상태 없음) → 이득이 사라져도 · 어느 팔이 어느 저장본을 읽었는지도 사슬 기록으로는 모른다 (로그 글을 훑어야) | 사슬이 런 로그의 저장본 줄 (상태 · 열쇠 12 자리) 을 런 기록에 싣기 (재실행 payload 바이트 대조 밖) · 요약에 폴더 · 상태 셈 · 운영 문서에 tmp · 못 읽는 파일 정리 |
| RCP-08 | P3 | `scripts/step3_sigma.py:569` · 593–600 | `cg` 와 `LinearOperator` 를 한 줄로 불러온다 → `cg` 만 있는 cupy (옛 판) 에서 바탕 = GPU 로 푸는데 새 판 = ImportError → CPU 폴백 · REQUIRE_GPU 면 "GPU 를 비우고 … 재개" 라는 맞지 않는 조치 글로 멈춤.  가짜 cupy 로 재현 (바탕 `used gpu` 둘 · 새 판 `used cpu` · `SystemExit`).  R 판 cupy 12.3.0 에는 있으므로 R 무영향 · 시험 G6 은 linalg 전체 불러오기 실패만 본다 | 그 한정을 주석 · 시험 갈래로 (조치 글을 사유별로) |
| RCP-09 | P3 | `scripts/test_step3_gpu_precond.py:342–352` (G4) | G4 "바이트 차이는 값 0 자리에서만" 은 가짜 cg 의 해 x 가 +0 에서 시작해 −0 을 갖지 않으므로 다른 바이트 0 칸으로 늘 참이다 (시험이 스스로 "(G4 관찰: 바이트 다른 칸 0 …)" 를 찍음 · 고치기 전 판에서도 PASS).  부호 있는 0 갈림을 잡는 시험이 아니다 (설계의 논증 — 생산 b ≥ +0 이면 r 이 −0 이 될 수 없다 — 은 맞다고 봄) | 이름을 관찰로 낮추거나 전처리 출력 z 를 직접 견주는 꼴 |
| RCP-10 | P3 | `scripts/mpm_webapp_payload.py:936–940` · 2398–2446 | 입구 계약이 `Store()` 의 `ValueError` 만 구조화 거부 (`STORE_PATH`) 로 바꾼다 (모듈 파일 못 읽음 `OSError` · `ImportError` = traceback) · `--step3-rasterize-only` 와 함께면 저장본 인자가 조용히 안 쓰인다 (그 길은 접합 준비 전에 `SystemExit(0)` · 접합 인자 전체의 기존 꼴) | `Store()` 예외 전부를 `STORE_PATH` 로 · rasterize-only + 저장본 = 거부 (graph-only 와 같은 줄) |
| RCP-11 | P3 | `scripts/cjunc_store.py:530` | 저장본 머리에 `socket.gethostname()` 을 싣는다 — 사슬은 기계를 실행자가 넣는 짧은 이름표로만 남긴다 (`rint_r_chain.py:347–348` "IP · 주소 금지") · 호스트 이름은 FQDN · 주소일 수 있다 | 이름표 (없으면 생략) 로 바꾸거나 뺀다 |

## 2. 보장 ⓐ–ⓕ

| 보장 | 판정 | 근거 |
|---|---|---|
| ⓐ 끔 경로 = 바탕 (af3cce37b) 과 비트 같음 | **섬** (결과 칸) | 끔 길의 원장 호출 · 반환 칸 · 차례가 diff 상 같다 (`ca_ext_cjunc.py:232–269` · payload `**{}`) · CPU 풀이 G5 = 바탕과 해 바이트 같음 · `solve_sigma_z` (가짜 GPU) G7 = 결과 dict 비트 같음.  달라지는 칸 = 코드 신원 (code_sha · `exec_env` 모듈 수 · 해시 — `ca_ext_cjunc` 가 늘 `cjunc_store` 를 부름 · 변이 MC7 이 그 의도를 지킨다).  GPU 길은 C 꼴로 바뀜 (끔이 아님 · ⓔ).  payload 산출 바탕 대조 = 내가 돌림 (`review/ovb.py` · `review/ovb_diff.py` · b6 픽스처 · CPU · 같은 작업 폴더): 접합 켬 · 저장본 끔 = 잎 차이 2 (`exec_env.loaded_project_modules` 8 → 9 · `project_module_digest`) · 접합 끔 = 1 (`project_module_digest`) · σ · 계획 · 증서 · 그 밖 잎 같음 (사본이 git 이 아니라 code_sha 는 둘 다 None — 실제로는 그 칸도 다르다) |
| ⓑ 열쇠가 원장 입력을 빠짐없이 덮나 | **깨짐** | 코드 칸이 `fibre_segment_raster.py` 를 빠뜨림 — 하나만 바꾼 두 입력 (그 파일) 이 같은 열쇠 (RCP-01 · CE1).  나머지 칸 (sid · lo · vox · 입력 넷 정준 값 · 문턱 · 모델 · 스키마 · 꼴 · 환경 · 기계) 은 T4 + 내 변이 MS1 · 2 · 3 · 15 · 17 이 잡는다 · 원장은 문턱을 `float` 로, 입력을 `_input_check` 로 정준화하므로 형 차이 (int ↔ float · int32 ↔ int64) 는 열쇠가 갈려도 원장은 같다 (빗나감일 뿐 · 틀림 아님) · 환경 · 기계 칸의 해상도 한계 = RCP-05 |
| ⓒ 낡거나 어긋난 저장본을 돌려주는 길 | **조건부** | 다른 침대 · 문턱 · 기계 · 꼴 판 = 열쇠 다름 (섬) · 다른 코드 = 깨짐 (RCP-01) · 0 바이트 · 잘림 · CRC = 다시 짓기 (섬 · T6) · 손으로 고친 파일: CRC 를 맞춘 편집 = 멈춤 (섬 · T7 · 변이 MS4 · 5 · 6 · 18) / CRC 를 깬 편집 · 멤버 더함 = "못 읽음" 으로 다시 짓기 (결과는 맞고 멈춤은 아님 — 설계 (나) 끝의 경계 그대로) / 자기 일관 위조 = 받음 (알려진 한정 · 막는 독립 대조가 SV 팔뿐 = RCP-03) · 두 팔 동시 = `os.link` 먼저 쓴 쪽 + 엄격 지문 대조 (섬 · T9 · MS8 · MS9) · 쓰는 중 끊김 = 최종 이름 없음 · 임시 파일 남음 (섬 + RCP-07) · 원장 짓기의 같은 환경 결정성 = 코드 읽기 (정수 · 정수 튜플 집합만) 와 T9c (두 프로세스 같은 원장) |
| ⓓ 소유자 · 권한 | **조건부** | 폴더 = 절대 · 폴더 · 그룹 · 남 쓰기 없음 · 소유자 (섬 · T11 · C1 · 러너 R1 · 변이 MS10 · 11 · MC3) · 파일 = 보통 파일 · 심볼릭 아님만 (RCP-06) |
| ⓔ GPU 전처리 꼴이 수렴 판정 · 반복 수 · 잔차 정의를 바꾸지 않나 · LinearOperator 없을 때 | **조건부** | 가짜 cupy (cupy 12.3.0 cg 를 옮긴 산술 · `p = z` 별칭 포함) 에서 해 바이트 · info · 반복 수 · `LAST_BACKEND` · callback 반복 수 · x0 길 같음 (G3 24 짝 · G7) · 변이 MQ1–6 (제자리 버퍼 · dtype 없음 · 나눗셈 · 글자 · dia 되돌림 · float32) 다 잡힘 · 수렴 판정 · 잔차는 cupyx `cg` 안 (손대지 않음) · 1 원소 행 spMV 와 원소 곱은 −0 만 다를 수 있고 생산 b ≥ +0 이면 r 이 −0 이 될 수 없다는 논증에 동의.  실기계 비트 같음 · 반복당 시간 = **미확인** (GPU 확인 블록 · 돌리지 않음 · 합성 벤치 200 반복만) · G4 는 그 논증을 시험하지 못함 (RCP-09) · LinearOperator 없는 옛 cupy = 거동 바뀜 (RCP-08 · R 무영향) |
| ⓕ 사슬 · 계약 · 러너에 새 칸이 결속되나 (증서 ↔ 결과) | **조건부** | 배선 = 섬: 사슬 `--cjunc-store` (ladder · predict 만 · 폴더 꼴) → `Runner.env_delta` `CJUNC_STORE` → 러너 (CJUNC=1 · 조립만 · 절대 · 글자 · 폴더 거부) → payload `--step3-cjunc-store` · 봉인 원천 env 에서 지움 · CLI 회계 mode · 규율 격리 목록 · CODE_FILES 20 (C · R · P 시험 · 변이 MC1–7 · 사슬 D10 · D14 통과).  증서 ↔ 결과: 저장본 사용 · 열쇠는 팔 JSON · 런 기록에 안 남는다 (설계상 — 재실행 payload 바이트 대조 때문) → 감사는 로그 줄만 (RCP-07) · 저장본 원장 ↔ S0 봉인 원장 대조 없음 (RCP-03) · 새 시험은 게이트 밖 (RCP-02) |

## 3. 변이 (리뷰어 것 · 구현 쪽 목록과 따로)

- 도구 `review/mutate.py` · 정의 `review/muts.json` · 결과 `review/mut_results_muts.json` (+ `_MC7` = 하네스 고친 뒤 다시) · 사본 `review/work/mut` · 3.11.
- **31 개 중 29 잡힘 · 2 동등.**
  - 잡힘 — Q11: MQ1 제자리 버퍼 (G2 · G3 · G4) · MQ2 dtype 안 줌 (G2) · MQ3 `r / diag` 나눗셈 (G2 · G3) · MQ4 precond 글자 (G3 · G7) · MQ5 dia 되돌림 (G1 · G1r · G2) · MQ6 float32 역수 (G2 · G3).  저장본: MS1 열쇠에서 입력 뺌 · MS2 기계 뺌 (T4 · T8) · MS3 sid 뺌 · MS15 문턱 값 뺌 · MS17 환경 뺌 (T4) · MS4 엄격 지문 대조 끔 · MS5 registry_fp 대조 끔 · MS6 sid 대조 끔 · MS18 심볼릭 링크 = 못 읽음 (T7) · MS8 남의 파일 대조 끔 (T9b) · MS9 `os.replace` 덮어쓰기 (T9a · b · c) · MS10 폴더 소유자 끔 · MS11 폴더 모드 끔 (T11) · MS12 별칭 끔 (T1 · T2 · T5f) · MS13 겹침 검사 끔 (T3) · MS14 dict 키 정렬 (T1 · T2 · T10b · T13c).  배선: MC1 봉인 원천 env 에 남김 (C3) · MC2 Runner env 안 넣음 (C2) · MC3 모든 단계 허용 (C1) · MC4 러너 조립만 거부 끔 (R1) · MC5 payload 조립만 거부 끔 (P1 · P2) · MC6 어긋남을 구조화 멈춤 대신 그냥 올림 (P4) · MC7 끔 런이 저장본 모듈을 안 부름 (P2 · P3 · P5).
  - 동등 — MS7 (발행 전 대조의 `ok_back = … strict_digest(got) == strict` 줄을 참으로): 바로 위 `_read` → `_content` 가 같은 엄격 지문을 머리 값 (= 쓴 쪽 strict) 과 이미 대조하므로 겹친 줄.  MS16 (열쇠 코드에서 step3_sigma 뺌): 원장은 step3_sigma 에서 `_grid_fp` 만 쓰고 그 값은 sid 칸에 이미 있다 → 정확성으로는 동등.  다만 **열쇠 코드 칸 고르기를 재는 시험이 없다**는 것을 보여 주고, 그 틈으로 RCP-01 이 지나갔다.
  - ⚠ 첫 실행에서 MC7 이 "안 잡힘" 으로 나왔던 것은 내 하네스 결함 (같은 파일 두 고침 중 둘째가 원본을 다시 읽어 첫째를 덮음 = 사실상 동등 변이) — 고친 하네스로 다시 = 잡힘.
- 고치기 전 판 재현 (`review/work/base` = af3cce37b 코드 + ebb0e9f80 시험): Q11 **10/13** (실패 G1 · G1r · G2 · 사유 = M 이 `dia_matrix`) · 저장본 **0/21** (모듈 없음) — 커밋 메시지와 같다 (옳은 이유로 실패).

## 4. 숫자 · 전칭 대조

| 주장 (자리) | 대조 | 결과 |
|---|---|---|
| "고치기 전 10/13 · 0/21" (ebb0e9f80 · f17ea8c6b 메시지) | 바탕 코드 + 시험 먼저 시험 | 같음 |
| "15/15 · 46/46" (f17ea8c6b · 2f97617ef) | 3.11 · kgy 판 3.8.20 둘 다 | 같음 — 3.11 = 전체 45 + R 다시 2/2 (첫 실행의 R2 실패 = 내 사본에 러너가 읽는 사전등록 문서가 없었음 · `logs/log_store_new_311*.txt`) · kgy 판 46/46 한 번에 (61.8 s) |
| "CODE_FILES 20 (D10 · D14)" | `test_rint_r_chain.py --only D10,D14` | 2/2 |
| `step3_sigma.py:572–577` 주석 "약 75 % · 3.40–3.79 배 · 200 반복 해 비트 같음" | 벤치 README §1 · §2 | 같음 (73–75 % · 3.397 / 3.795 · 3.794) |
| `cjunc_store.py` 머리 "약 47 만 멤버" | 117,583 × 4 = 470,332 | 같음 |
| `cjunc_store.py:9` · `:56` "열쇠 코드 = 원장 코드" · 설계 (나) "실제 불러온 모듈 파일" | 원장 길의 import | **틀림** (RCP-01) |
| `cjunc_store.py:29–30` "자기 일관 위조 … 그 몫 = 봉인 원천 재조립 대조" | `rint_r_chain.py:2307` | **범위 빠짐** (RCP-03 · 개정 초안 61 줄은 맞음) |
| G4 이름 "바이트 차이는 값 0 자리에서만" | 시험 출력 "바이트 다른 칸 0" | 공허하게 참 (RCP-09) |
| 설계 (마) "T13c 12 만 멤버 · 쓰기 2.5 s · 읽기 6.6 s" | 내 실행 T13c | 쓰기 2.3 s · 읽기 6.4 s (기계 차 안) |
| 메모 "rint_r_chain 506/506" | 내 사본 3.11 전체 = 505/506 (380.9 s) · 실패 Y13 = 사본이 git 저장소가 아니라 `git check-ignore` rc 128 → git 으로 초기화한 사본에서 Y13 1/1 | 같음 (환경 산물 하나) |
| 메모 "끔 길 ↔ 바탕 = 코드 신원 칸만" | 내 payload 대조 (ⓐ 칸) | 같음 |
| 메모 "변이 89 잡힘 · 동등 3" · "store e2e 6/6" · "chown 막힌 길 통과" | 그 도구 · 사본은 지워짐 · e2e 는 돌리지 않음 | 확인 안 함 (내 변이 31 = §3) |

## 5. 확인 못 한 것

- GPU 실기계 A ↔ C 비트 같음 · 반복당 시간 (GPU 없음 · GPU 확인 블록 `gpu_check_block.txt` 은 읽기만 — 옛 · 새 `_solve_cg` 를 같은 합성 계에서 x0 길 · callback 포함으로 견주는 꼴 = 의도와 맞음 · 돌리지 않음).
- `test_cjunc_store_e2e.py` (Z1–Z6 · 십수 분) — 돌리지 않음.
- 실침대 원장의 저장 꼴 · 시간 · 메모리 (RCP-04).
- RCP-05 의 실제 차이 (두 빌드 · 복제 machine-id) — 재현 못 함.

"""Q5 reseal CANDIDATE (not operational).  Reads only; writes the candidate JSON and a
change table into this folder.  Usage:
  python3 -I -B make_and_check_seal_candidate.py <patched_tree_root> <out_dir>      # make + check
  python3 -I -B make_and_check_seal_candidate.py <root> <out_dir> --check-only      # recheck a root
The operating seal, campaign policy, launch files and inactive candidate are not modified."""
import hashlib, json, sys, subprocess
from pathlib import Path
root, out = Path(sys.argv[1]), Path(sys.argv[2])
check_only = sys.argv[3:] == ['--check-only']
F8 = 'docs/reviews/mixer_first8_launch_preparation_20261106/source_seal.json'
IN = 'docs/reviews/mixer_inactive_preparation_20261109/candidate/inactive_candidate.json'
INV = 'docs/reviews/mixer_inactive_preparation_20261109/source_inventory.json'
def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
operating = json.loads((root/F8).read_text(encoding='utf-8'))
inactive = json.loads((root/IN).read_text(encoding='utf-8'))
paths = [f['path'] for f in operating['files']]
assert paths == [f['path'] for f in inactive['files']] and len(paths) == 12
now = {p: sha(root/p) for p in paths}
cand_path = out/'source_seal.candidate.json'
if not check_only:
    tree = subprocess.run(['git', '-C', str(root), 'rev-parse', 'HEAD^{tree}'], capture_output=True, text=True).stdout.strip() or None
    obs = root/'scripts/mixer_precal_observe.py'
    blob = subprocess.run(['git', 'hash-object', str(obs)], capture_output=True, text=True).stdout.strip()
    candidate = dict(
        status='CANDIDATE_NOT_OPERATIONAL',
        note=('Q5 reseal candidate = registration draft 18 Q7 recommendation (current-source candidate + Q5 observer fix). '
              'Operating seal, campaign policy, launch files and inactive candidate are unchanged. Not an approval, not GO.'),
        # No `source_pin` key on purpose: the first8 guard reads seal['source_pin'] by subscript, so
        # a candidate installed by mistake fails closed (KeyError -> HOLD).  A null pin would NOT be
        # safe: c.get('source_pin') == None matches an approval that omits the pin.
        source_pin_pending=('add "source_pin" = the repository commit that contains patches 0001-0002 on top of '
                            'ef68eb7dada1459f1f634f5b1e2724815605c3f4, only at the reviewed reseal step'),
        base_commit='ef68eb7dada1459f1f634f5b1e2724815605c3f4',
        patched_git_tree=tree,
        scope=operating['scope'],
        files=[dict(path=p, sha256=now[p]) for p in paths],
        inactive_inventory_row_candidate=dict(path='scripts/mixer_precal_observe.py', bytes=obs.stat().st_size,
                                              sha256=now['scripts/mixer_precal_observe.py'], git_blob=blob))
    cand_path.write_text(json.dumps(candidate, indent=2, ensure_ascii=False)+'\n', encoding='utf-8')
cand = json.loads(cand_path.read_text(encoding='utf-8'))
op = {f['path']: f['sha256'] for f in operating['files']}
ina = {f['path']: f['sha256'] for f in inactive['files']}
cd = {f['path']: f['sha256'] for f in cand['files']}
rows, ok = [], True
for p in paths:
    match = cd[p] == now[p]; ok &= match
    rows.append(dict(path=p, operating_seal=op[p], inactive_candidate=ina[p], candidate=cd[p], root_now=now[p],
                     candidate_matches_root=match, differs_from_operating=cd[p] != op[p], differs_from_inactive=cd[p] != ina[p]))
inv = json.loads((root/INV).read_text(encoding='utf-8'))
inv_obs = [r for r in inv['source_dependencies'] if r['path'] == 'scripts/mixer_precal_observe.py'][0]
report = dict(root=str(root), all_candidate_hashes_match_root=ok,
              differs_from_operating=[r['path'] for r in rows if r['differs_from_operating']],
              differs_from_inactive=[r['path'] for r in rows if r['differs_from_inactive']],
              inactive_inventory_observer_row_now=dict(bytes=inv_obs['bytes'], sha256=inv_obs['sha256'], git_blob=inv_obs['git_blob']),
              rows=rows)
if not check_only:
    (out/'seal_candidate_changes.json').write_text(json.dumps(report, indent=2, ensure_ascii=False)+'\n', encoding='utf-8')
print(json.dumps({k: v for k, v in report.items() if k != 'rows'}, indent=1, ensure_ascii=False))
sys.exit(0 if ok else 1)

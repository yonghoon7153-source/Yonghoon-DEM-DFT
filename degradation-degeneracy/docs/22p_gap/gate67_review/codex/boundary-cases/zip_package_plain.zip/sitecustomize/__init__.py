# standard ZIP startup

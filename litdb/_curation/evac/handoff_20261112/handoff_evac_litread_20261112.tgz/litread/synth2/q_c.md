# 질문 c — 배치별 근거 묶음 (원문 줄 그대로 · 파일 43 개)

### [batch_01] c. 항복 · 경도 · 크리프 값과 정의 · 일축 항복 세기 환산

LPSCl 의 측정 항복 · 경도 · 크리프 값은 **이 배치에 없음**. 경도 ↔ 일축 항복 환산식도 **카드에 없음**.

- [c] bardenhagen2000_mpm_granular_multibody_frictional_contact | HMX 근사 알갱이 = von Mises + 선형 경화 · 항복강도 0.3 GPa · 경화계수 0.01 GPa · 전단계수 7.5 GPa · 체적계수 11.4 GPa; 여기서 E 18.5 GPa · ν 0.230 · E/σ_y 61.5 | §3-2 (L101–102) | 앞 = stated · 뒤 = derived(ours · 3D 등방 관계식 가정 — 2D 계산의 평면 가정은 미기재) | HMX 근사 (LPSCl 아님) · 2D · 항복이 일축 값인지 카드에 없음
- [c] bardenhagen2000_mpm_granular_multibody_frictional_contact | 카드가 적은 우리 쪽 값: "실제 LPSCl (E 22–24 GPa, σ_y 0.05–0.30 GPa)" · 우리 MPM SE = E 1.53 GPa · ν 0.49 · σ_y 0.30 GPa · 우리 DEM SE = E_eff 1.35 GPa | §8-2 (L315) · §8-1 (L305) | 표지 없음 (우리 쪽 기록) | 출처 · 정의 · 일축 환산 카드에 없음 · 카드 스스로 "숫자 관찰일 뿐 재료 전이가 아니다"
- [c] klar2016_dp_sand_animation | 우리 MPM 항복 정의 = von Mises J2 "편차응력 노름 ≤ √(2/3)·σ_y" · σ_y 0.15 (2D) / 0.30 (3D) GPa · 선형 가공경화 (HARD_SE ≈ 10) | §7 표 (L195 · L199–200) | 표지 없음 (우리 쪽 기록) | 논문 값 아님 · σ_y 가 일축 항복 세기라는 말은 식 꼴뿐 (환산 설명 없음)
- [c] klar2016_dp_sand_animation | 모래 Drucker-Prager: 마찰각 30° (스윕 20 / 25 / 30 / 35 / 40°) · α = √(2/3)·2 sinφ_F / (3 − sinφ_F) (식 31) · 점착 0 · 경화 h₀ / h₁ / h₂ / h₃ = 35 / 9 / 0.2–0.3 / 10 (°) | §3 표 (L39–45) · §4.4 (L134–136) | stated (Table 3 · 식 30–31) | 마른 모래 · 마찰형 항복 (일축 항복 세기 아님)
- [c] lim2025_virtual_calendering_framework | NCM 2차입자 "최대항복강도 100–150 MPa" (보고값 · ref 25 / 52) → von Mises 응력이 이를 넘는 체적을 crackable 로 정의; 탄성 입력 E_NCM622 2.61 GPa · E_CBD 1.55 GPa · E_Al 68.96 GPa · ν 0.30 (Al 0.33) | §6.1 (L219–220) · §3.2 (L142–144) · SI Table S4 | 표지 없음 ("보고값") | NCM622 2차입자 · E 2.61 GPa 는 전극 유효값 (카드 주의) · 항복 정의 카드에 없음
- [c] nam2026_dpe_microstructure_review | PTFE 인장강도 0.43 MPa (30 ℃ · 피브릴화 부족) → ≈ 0.85 MPa (80 ℃); PTFE 0.5 → 4 wt% 에서 전극의 Young's modulus · yield stress 가 비선형으로 증가 (값 없음) | §3.2 (L231–232) · §3.4.2 (L295–296) · Fig 4d · Fig 6d · ref 77 · 122 | 표지 없음 | PTFE · Li-ion 건식전극 · 정성


### [batch_02] c. 항복 · 경도 · 크리프 값과 정의 · 일축 항복 세기 환산

이 배치에 **경도 · 크리프 값 없음**. LPSCl 의 항복값을 잰 카드도 없음.

- [c] nezamabadi2022_mpm_cd_plastic_particle_compaction | 입자 항복 σ_y = 0.4 MPa (속도 무관 von Mises + 이선형 등방 경화 H = 0 / 1 / 3 MPa · E 10 MPa · 출처 = ANSYS 이론서 [12]) | §3.1 (L106) · §4.3 (L178–179) | stated | 모델 입력 (측정값 아님) · 일반 무른 재료 · 2D
- [c] nezamabadi2022_mpm_cd_plastic_particle_compaction | 단일 원판 직경 압축: σ_yy ≃ 0.4 MPa (= σ_y) 까지 선형 → 그 뒤 선형 소성; 꺾임 ≈ 0.40–0.42 MPa @ ε_yy ≈ 0.035–0.04 · 꺾인 뒤 기울기 ≈ 0.7 / 1.9 / 3.7 MPa (H 0 / 1 / 3) | §5.1 (L241–245) · Fig 1 | stated (꺾임 = σ_y) / digitized (수치) | σ_yy · ε_yy 정의 미기재 (L481)
- [c] nezamabadi2022_mpm_cd_plastic_particle_compaction | 집합체의 거시 소성 분기 σ ≳ 0.35 MPa (σ_y 보다 낮음 · 카드 환산 0.875 σ_y) — "not all the particles … undergo plastic deformation at the same time"; σ = σ_y 에서 Φ ≈ 0.84 · Φ 0.95 / 0.97 에 2.8 / 3.5 σ_y (H0) | §3.3 (L129 · L135–136) · §0 (L33) | stated (0.35 MPa) / digitized · derived(ours) (σ_y 단위 값) | 2D 면적 분율
- [c] nezamabadi2022_mpm_cd_plastic_particle_compaction | ★ 일축 환산이 카드에 있음 (우리 코드 쪽): 우리 `--sigma-y` 는 Hencky 편차 변형 노름 문턱 (dg = (dev ε_H 의 노름) − σ_y/(2µ)) · 응력은 fixed-corotated → σ_y 0.30 일 때 단축 항복응력 = 생산 연화 재료 (E 1.53 · ν 0.49) 압축 0.318 · 인장 0.454 GPa / 실제 강성 (E 22.06 · ν 0.36) 압축 0.363 · 인장 0.372 GPa · √(3/2)·σ_y = 0.367 GPa 는 작은 변형 극한 · 생산 연화 재료 압축이면 300 MPa = 0.94 σ_y,uniaxial · 처음 판의 "단축 = √(3/2)·σ_y · 1.22 배 보정" 은 철회 | §7.3-5 (L371–376) | "우리 코드 판독 — 이 논문 밖 사실 · 11-09 메인 세션 정정" · [우리 산술 · 코드 식을 그대로 풂] | 논문 값 아님 · 카드: 논문 (ANSYS 이선형) 의 σ_y 는 단축값으로 "읽히므로" 나란히 놓을 때 우리 쪽을 환산 · stomakhin 카드의 서술과 다름 (카드 문제 A-2)
- [c] nguyen2017_mpm_bpm_deformable_particle_compaction | BPM 소성 문턱 σ_I = F0/⟨a0⟩ = 100 N / 0.2 mm = 0.5 MPa (단위 깊이당) · 그림의 평탄 평균 ≈ 0.54 MPa (sd 0.04 · ε 0.05–0.49) | §3.2 (L105) · §3.3 (L117) | stated 정의 (0.5 MPa 는 derived(ours)) / digitized (0.54) | 재료 항복이 아닌 수치 매개변수 (L246–247 · L294) · 2D · MPM 쪽은 탄성뿐
- [c] pycompact2025_dem_mpfem_workflow | Fe–Si–Al–P: Swift 경화 σ = K(ε + ε₀)ⁿ · K 1380 MPa · n 0.254 · ε₀ 0.0354 (실험 보정 · ref [17]) → 초기 항복 590.6 MPa · σ(ε = 1.0) 1392 MPa · σ(ε = 1.3) 1485 MPa · P/σ_y 3.39–1.44 · E/σ_y 288 | §3.1 (L75–80) | stated (K · n · ε₀) / derived(ours) (나머지) | 금속 합금 · 유동응력 곡선이 단축 시험 기준인지는 카드에 없음
- [c] stomakhin2013_mpm_snow_elastoplastic | 눈: 항복을 주응력이 아니라 주신장 (F_E 의 특이값) 구간 [1 − θ_c, 1 + θ_s] 로 정의 · θ_c 2.5 × 10⁻² · θ_s 7.5 × 10⁻³ · 경화 μ, λ ∝ exp(ξ(1 − J_P)) · ξ 10 | §3 (L37–39) · §4.2 (L96–104) · Table 2 · 식 2 | stated | 측정값 아님 (저자 표현 "useful starting point" · L223) · 일축 항복 세기 환산은 카드에 없음
- [c] alabdali2023_cgmd_wet_manufacturing_ssb_cathode | E · σ_y · ν (AM · SE · CBD) = n/a — "물성으로 준 적이 없다. FF 계수 (k_n 등) 만 있다" | §3-4 (L163) | 표지 없음 (n/a) | —
- [c] alizadeh2018_dem_adhesion_calibration_segregation_heap | 입자 항복 · 경도 · 크리프 없음 — 있는 것은 EP 실제 영률 1.6 GPa [ref 37] · DEM E 0.25 GPa 와 분말 층의 유동 지표 Jenike ffc = σ₁/σ_c (비코팅 6.3 → 코팅 4.4 · 2–8 kPa 평균) | §3-2 (L81–82) · §3-4 (L121) · §3-5 (L133) | [인쇄] p.5 · p.9 | ffc 는 분말 층의 유동 함수 (입자 항복 아님) · 세제 과립


### [batch_03] c. 항복 · 경도 · 크리프 값과 정의 · 일축 항복 세기 환산

LPSCl 의 측정 항복 · 경도 · 크리프 값은 **이 배치에 없음**. 경도 ↔ 항복 환산은 `arzt1982` 카드의 "3σ_f = H" 한 줄뿐.

- [c] arzt1982_particle_coordination_densification_spheres | 접촉 항복 (압입 해 · Hill [13]) f/a = 3σ_f — "국부 항복 조건" | §3 (L52) · §4-7 식 (19) (L174) · 논문 p.1888 | stated | 소재 무관 · σ_f 가 일축 항복인지 유동응력인지 카드에 정의 없음
- [c] arzt1982_particle_coordination_densification_spheres | 경도 ↔ 항복 환산 한 줄: 3σ_f = H → H = 0.85 GPa 이면 σ_f ≈ 0.28 GPa ("우리 MPM σ_y 0.30 GPa 와 같은 자릿수 · 우연 일치 여부 미검증") | §7 표 소재 행 (L268) | 표지 없음 (H = "지시문 기준 우리 코드 값" · 출처 검증은 카드 범위 밖 L436) | LPSCl 측정값 아님 · 구속 인자 3 의 적용 범위 설명 없음
- [c] arzt1982_particle_coordination_densification_spheres | 포화 판별: Tabor 면적 합 ÷ 구 표면 = p̄_i/H → 포화 문턱 p̄_i = 0.85 GPa ≈ 300 MPa 의 2.83 배 · 평균장 부하율 p/(D·H) (300 MPa) = 0.42 (D 0.84) · 0.39 (0.90) · 0.35 (1.0) | §L-3 (L304–318) | "우리 유도" · "우리 산술" | 법선력만 · 가지 길이 ≈ R 가정 (보정 셋 L323) · 미검증
- [c] arzt1982_particle_coordination_densification_spheres | 크리프 (HIP): 멱법칙 ε̇ = ε̇₀(σ/σ₀)ⁿ (식 22) → dD/dt ∝ √a/(aZ)ⁿ (식 24) · n = 3 이면 배위수 증가만으로 치밀화 속도가 "by a factor of up to three" 감소 | §3 (L55) · §4-3 (L111) · 식 22–24 (L177–179) · 논문 p.1888–1889 | stated (그림 6 판독 D = 1 ≈ 0.24 는 본문과 어긋남 `[판독 불확실]` L206 · L438) | 재료 상수 값 없음 (형식만)
- [c] bouvard2000_hard_soft_powder_densification | 정량 σ_y · E 표 없음 — 정성: 연상 = visco-plastic (고온 HIP) 또는 plastic · 온도가 σ_y_soft 조절자: Al + 60 vol% carbide die 600 MPa ρ ~0.85 (20 °C) → ~0.91 (450 °C) · HIP 는 시간의존 creep 이라 Heckel 부적합 | §4 (L48) · §3 (L29) · §6 (L78) | stated (Fig 7) | 금속 + 세라믹 · 값 없음 · 체제 구분 기준 "연상 항복응력 vs 압력" 은 정성 (L10)
- [c] bouvard2000_hard_soft_powder_densification | 카드의 우리 쪽 값: "우리 LPSCl 300 MPa 는 연상 변형 지배 (σ_y_SE ~50–300 MPa ≲ P)" | §8 ③ (L104) | 표지 없음 | 출처 · 정의 카드에 없음
- [c] cardenasbarrantes2020_rigid_deformable_mixture_compaction_nscd | 무른 입자에 항복 없음 (neo-Hookean 초탄성 · ν 0.495 · E 절대값 미기재) · Secondi 식의 A1 은 "[47] 에 따르면 등가 항복응력과 관련" — 적합 A1 ≃ 0.05E (μs 0) · 0.079E (μs 0.8) | §3-1 (L105) · §3-2 (L117–118) · §5-3 (L291–293) | stated | 2D · 초탄성 · 일축 항복 환산 없음
- [c] cardenasbarrantes2020_rigid_deformable_mixture_compaction_nscd | 카드의 우리 쪽 값: MPM SE = J2 소성 E 1.53 GPa · ν 0.49 · σ_y 0.30 GPa · DEM SE = E_eff 1.35 GPa (실제 ~24 의 ~18× 연화) | §8-0 (L413) | 표지 없음 (우리 쪽 기록) | 논문 값 아님
- [c] cardenasbarrantes2021_soft_rigid_mix_compaction_proceedings | 단일 입자 법칙의 b ≃ 0.14 를 원문이 "a constant of proportionality called the yield stress" 라 부름 — 카드: 초탄성 입자의 무차원 상수이지 항복응력 아님 | §4 (L121–122) · §9-3 (L189–190) | stated (b) · 카드 판단 | σ_y 자리와 혼동 금지 (카드)
- [c] cardenasbarrantes2022_soft_hard_grains_compaction_experiment_dic | 실리콘 E0 = 0.45 MPa · ν = 0.5 · PVC E = 1.2 GPa · 혼합 유효 영률 E* = E0/[2κ(1 − ν²)] — 항복 · 경도 · 크리프 없음 | §3-1 (L91–92) · §3-2 (L108) | stated | 초탄성 · 2D


### [batch_04] c. 항복 · 경도 · 크리프 값과 정의 · 일축 항복 세기 환산

LPSCl 의 항복 · 경도 · 크리프 **측정값은 이 배치에 없음**. 경도 ↔ 항복 환산은 카드 표의 한 줄 (H ≈ 3σ_y) 뿐.

- [c] giannis2021_stress_based_multicontact_dem | 경도 ↔ 항복: 경도 항복 캡 (So 2021/2022 · Thornton–Ning 1998) = "국소 접촉압 ≤ H ≈ 3σ_y (물성)" · 자유변수 0 · "LPSCl σ_y 밴드 0.05–0.30 GPa 자체가 6× 폭" | §7-3 표 (L370) | 표지 없음 (카드의 우리 쪽 표 · 출처 카드에 없음) | Giannis 논문의 값 아님 · 계수 3 의 출처 · σ_y 가 일축 값인지 카드에 없음
- [c] giannis2021_stress_based_multicontact_dem | 항복 없음 (순수 탄성 Hertz). 재료 값 (Table 1): 하이드로겔 E 23.3 kPa · ν 0.5 / 고무 1.85 MPa · 0.46 / 유리 65 GPa · 0.24. 우리 쪽 참고 열: LPSCl E 22–24 GPa (real) · 1.35 GPa (우리 E_eff) · ν 0.37 (Bazzoun) / 0.360 (우리 DFT) / 0.3 (우리 DEM 입력) | §3.1 표 (L51–58) | 논문 값 = stated · 우리 쪽 열 = 표지 없음 ("(참고)") | LPSCl 값의 측정 조건 카드에 없음
- [c] coetzee2017_dem_calibration_review | 재료 항복 · 경도 · 크리프 없음 ("plastic" 본문 1 회 · Thornton–Ning / EEPA / Storåkers 부재). 닿는 것: Sadek [200] = 전단 응력–변위 곡선의 "항복점" 으로 입자 강성을 보정 (벌크 항복) · 직접 측정 E = 압축 / 압입 시험 + Hertz 가정 (ν 는 가정) | §3 (L49–50) · §5-Q2(a) (L208) · 카드 §6 의 "§6 Direct measuring" 요약 (L649) · §13 (L968–969) | 리뷰 stated (1차 출처 소환값) | 저응력 벌크 · 일축 항복 환산 없음
- [c] electromechanical_contact_model_particulate_systems | 항복 캡 · 소성 분기 없음. 금속 E: Ni 199.5 · Cu 129.8 · 스테인리스 195 · 강철 bed 200 GPa (Table 1–3) · HPT 재료 E 7e8 Pa · BPM bond 파단 σ_crit = τ_crit = 1e8 Pa (Table 4) | §3 표 (L59–62) · §4 (L72–73) | stated | 금속 · bond 파단 강도는 재료 항복이 아님
- [c] dmt1975_adhesion_contact_deformation | 항복 없음 (탄성). 예시 E = 3×10¹⁰ dyne/cm² (= 3 GPa) · σ (Poisson) 0.33 — 폴리스티렌–강철 (Table II) | §3 표 (L41) | stated | LPSCl 아님
- [c] deng2021_mechanical_surface_energy_tester_bond_number | 이 배치에 없음 | — | — | —


### [batch_05] c. 항복 · 경도 · 크리프 값과 정의 · 일축 항복 세기 환산

LPSCl 의 측정 항복 · 경도 · 크리프 값은 **이 배치에 없음**. 경도 ↔ 항복 세기 환산식은 jg 한 장 (재료 무차원).

- [c] jacksongreen2005_fem_elastoplastic_hemispherical_contact | 경도 (완전소성 평균 접촉압) ↔ 항복 세기 환산: H_G/σ_y = 2.84·[1 − exp(−0.82·(a/R)^(−0.7))] — a/R → 0 에서 2.84 (Williams 이론 2.83) · 카드 계산값 a/R 0.2 → 2.61 · 0.3 → 2.42 · 0.4 → 2.24 (2.84 대비 −8 / −15 / −21 %) · a/R = 1 에서 1 (Fig 7 개념도) | §3 표 (L29–31) · §7.3 (L178–179) · 식 17 · Fig 6 · 7 | stated (Weibull 적합) · 0.2–0.4 값 = "eq17 계산값" (카드) · a/R = 1 = stated (Fig 7) | 탄성-완전소성 강 범위 (σ_y 0.21–1.62 GPa · E 200 GPa · ν 0.32) · 반구 ↔ 강체 평판 · 적합 범위 a/R ≤ 0.412 · LPSCl 값 아님 · 식과 "a/R = 1 → 1" 은 카드 문제 A-2
- [c] jacksongreen2005_fem_elastoplastic_hemispherical_contact | Tabor 상수 H ≈ 3σ_y (Abbott–Firestone P/AS_y = 3) 는 변형에 따라 변한다는 것으로 반증; 첫 항복의 최대 접촉압 p_oc/σ_y = C = 1.295·exp(0.736ν) = 1.639 (ν 0.32 · 식 2); 큰 간섭의 평균압 peak P/(A·σ_y) ≈ 2.8 (가장 약한 재료) ~ 더 낮음 (가장 강한 재료) | §3 표 (L32–34) · Fig 5 · 6 | stated · peak = digitized Fig5/6 (추세) | 위와 같음
- [c] jacksongreen2005_fem_elastoplastic_hemispherical_contact | Johnson 구리 구 실험 대조: a/R = 0.204 에서 평균압 ≈ 2.59σ_y (카드 표기 "P≈2.59σ_y") ↔ 예측 P/(A·σ_y) = 2.61 · 모델 최대 차 10.9 % · 최대 하중에서 1.7 % | §3 표 (L41) · (5) (L134–137) · Table 2 | stated | 구리 · 카드의 구리 σ_y 단위는 카드 문제 A-4
- [c] heck2026_densification_sulfide_se_binder_scalable | 나노압입 (평펀치 Ø50 µm · LPS + 3 wt% HNBR 시트): 감소탄성률 E_R 0.491 (비압축) · 1.929 (100 MPa · 40 °C) · 2.332 (100 MPa · 100 °C) · 5.344 GPa (300 MPa); 경도 H 0.009 · 0.172 · 0.086 · 0.809 GPa | §3-2 표 (L70–77) · Fig 2 · p.6 | [인쇄 그림] | 다공 시트의 겉보기 값 (카드 §7-4 L253) · 고체 값 아님 · 일축 항복 환산은 카드에 없음
- [c] heck2026_densification_sulfide_se_binder_scalable | 압밀 저항 값: Meyer γ_c 금형 안 0.32 GPa (분말) · 뺀 뒤 시트 26–61 MPa (Table S6) · Heckel P_y ≈ 260 MPa (β-LPS in-die); 크리프 값 없음 (단계 15 분 휴지 · springback 의 속도 의존뿐); LPS T_g ≈ 200 °C (인용) | §0 표 ④ (L27) · §3-6 (L119–123 · L127) | [인쇄] SI · P_y = [우리 산술] | β-LPS · T_g 는 유리질 LPS 문헌값 · 일축 항복 세기 환산 카드에 없음
- [c] he2026_dem_calendering_inhomogeneity_areal_density | 항복 · 경도 값 없음 — EEPA 접촉 소성비 λ_p 0.96 (규약 λ_p = 1 − k₁/k₂ 이면 k₂ = 25 k₁) · 파괴 판정 문턱 = 입자 축응력 > 2 GPa ([38] 차용) · E_NCM 47 GPa (표에 출처 열 없음) | §3.2 (L97 · L107–108) · §3.8 (L187) · §3.1 (L80) | stated (Table 1 · 2) · k₂ = 25 k₁ = derived(ours) | NCM622 · 접촉 모델 값 (재료 항복 세기 아님)
- [c] gonzalez2012_nonlocal_contact_confined_granular · johnson1971_jkr_surface_energy_contact_elastic_solids | 논문에 없음 (탄성 전용). gonzalez 카드가 우리 쪽 값으로 "LPSCl σ_y 0.05–0.30 GPa" 를 적음 | gonzalez §10.3 (L630) | 표지 없음 (우리 쪽 기록) | 출처 · 정의 카드에 없음


### [batch_06] c. 항복 · 경도 · 크리프 값과 정의 · 일축 항복 세기와의 환산

크리프 값은 **이 배치에 없음**. LPSCl 의 항복 · 경도 실측도 없음 (전부 무차원 · 다른 재료).

- [c] kogutetsion2002_ep_sphere_rigid_flat | 환산 H = 2.8·Y (본문 채택 · Tabor) · 항복 개시 평균압 p_c = (2/3)·K·H · K = 0.454 + 0.41ν (ν 0.3 → K 0.577 · p_c/Y 1.08 · fit 은 1.19) · 임계 간섭 ω_c = (πKH/2E)²·R · 완전소성 평균압 p/Y → 2.8 @ ω/ω_c = 110 | §3 (L24–31 · eq 1 · 4 · 5 · 6 · Fig 7) | stated | 탄성-완전소성 · 무차원 · 100 < E/Y < 1000 · ν 0.3 · 강경화 (접선 0.1E) 에서 차 < 20 %
- [c] mesarovicfleck2000_dissimilar_elastoplastic_indentation | 평균 접촉압 첫 항복 ≈ 1.1σ_y → 완전소성 plateau ≈ 2.8–3.0σ_y = 경도 H (m = ∞) · 강경화 m = 3 이면 plateau ≈ 1.6 (σ_r 로 정규화) · 이질 접촉의 지배 항복 σ₀ = min(σ₀₁, σ₀₂) (eq 5.1) | §3 (L29–32) · §4 (L54) · L104–111 | 1.1 = stated (Johnson · 자매편) · 2.8–3.0 · 1.6 = digitized (Fig 4 · 5) · 같은 표에 F/(πa²σ₀) = 3.0 stated | 무차원 · 무마찰 · LPSCl 값 없음
- [c] molerus1975_theory_of_yield_cohesive_powders | 소성 항복압 p_f ("plastic yield pressure" · 구속 때문에 σ_f 보다 큼) ≈ 3σ_f (Hencky [14] · Isklinsky [15]) · 석회석 p_f = 50 kp/mm² ≈ 5×10⁸ Pa (Schönert–Steier [16] 단일 입자). 카드가 다른 카드 값을 나란히 적음: zunker2024 의 구속 항복압 p̄/Y 2.75 (2.61–2.84) | §0 (L27) · §4-4 (L167) · p.264–265 · L424 | stated · 다른 카드 인용은 표지 없음 | 석회석 · 돌기 척도 · 카드 파생 "3σ_f = H (0.85 GPa) → σ_f ≈ 0.28 GPa" 는 카드가 "검증으로 쓰지 않는다" 고 적음 (L321)
- [c] martinbouvard2003_dem_composite_cold_compaction | 연질상 소성칙 σ_e = Σ_p·ε_e^(1/m) (eq 1) · 1/m = 0 / 0.2 / 0.4 · 혼합 접촉 Σ_pq = (Σ_p^(−m) + Σ_q^(−m))^(−1/m) (eq 4) · 접촉면적 A = 2π·c(m)²·r_pq·h · c(m) 0.5 (선형 경화) → 1.45 (이상소성) | §3 (L30–31) · §4 (L40–42) | stated | 무차원 (Σ₁ 로 정규화) · 금속 모델 · 일축 항복 절대값 없음
- [c] kissel2026_mechanofusion_derived_cathode_composite_microstructures_scalable | DEM 보정값: Thornton–Ning 항복비 0.00756 (입자–입자) · 0.0256 (입자–벽) · 영률 0.228 GPa · ν 0.3 — "yield ratio" 의 정의는 [미확인] | §3-5 (L137–148) · SI 표 S2 | [인쇄] · 정의 [미확인] | 300 µm 거친 입자 · 혼합물 겉보기 값 · 일축 항복 환산은 카드에 없음
- [c] luding2008_cohesive_frictional_contact_models | 경도 · 항복압 값 없음 — 소성은 소성 깊이 φ_f (예 0.05) 와 강성비 k₁/k̂₂ (예 0.5) 로만 들어간다 · "magnitude of k cannot be compared directly with bulk modulus C" | §3 (L59) · §4 (L93–94 · L123) | stated | 일축 항복 환산 없음
- [c] oh2026_bimodal_composite_cathode | 항복 · 경도 없음. 시뮬 입력 탄성값만: E_SE 22 GPa · ν_SE 0.30 · ν_AM 0.25 (Table S15) · CAM 영률 NCWA 130 → 200 · NCM 140 → 225 GPa (Li x 0.3 → 1.0 · Fig S14) | §4.5 (L369–382) · L417 | 표지 없음 | 22 GPa 가 측정인지 입력 가정인지 카드 안에서 갈림 (카드 문제 38)
- [c] liao2025_interfacial_adhesion_li_plating_carbon_interlayer | SE 항복값 없음. 박리 팔 (Kapton) 만: E 3.6 GPa · σ = Aεⁿ · n 0.51 · A 381 MPa · ε_Y 0.01 | §3.4 (L108–112) · SI p.3 · p.6 | 인쇄 (SI) | tape 재료 — 계획과 무관


### [batch_07] c. 항복 · 경도 · 크리프 값과 정의 · 일축 항복 세기 환산

LPSCl 의 측정 항복 · 경도 · 크리프 값은 **이 배치에 없음**. 경도를 일축 항복으로 바꾸는 환산을 논문이 직접 준 카드도 없다 (So 는 σ_yield ≈ H 로 그대로 씀).

- [c] so2022_dem_contact_model_assb_compaction_sintering | 경도 (문헌값을 입력으로): H_SE (LPS) 1.9 GPa (McGrogan [8]) · H_AM 11.2 GPa (Cheng [10]) · 항복 임계 F_th = min(σ_i^yield, σ_j^yield) · A_con^eff · "문헌에 항복강도 정보가 부족하므로 σ^yield ≈ H(경도)로 근사" · A_con^eff = (2/3)·π·h_ov·R_eff (포물선 응력 분포라 최대 = 평균의 3/2) | §3 표 (L32–33 · L40) · §4.3 (L116–124) · Table 1 · eq 5–6 | stated | LPS (LPSCl 아님) · 경도의 측정 방법 · 정의는 카드에 없음 · 일축 항복 환산 없음 (카드: "우리 Stage-E 가 H≈3σ_y 쓰는 것과 같은 발상; 여기선 직접 H로" L120)
- [c] so2022_dem_contact_model_assb_compaction_sintering | 크리프 · 점탄성: Maxwell σ = E·t_rel·∂ε/∂t → ∂h_eq/∂t = (F_spring − F_th)/(t_rel·k_n) (eq 2–4) · 소성 전용 계산은 t_rel ≪ 시뮬 시간 (정상 상태) · 점탄성 모드는 t_press/t_rel = 0.1 / 1 / 10 / 100 (Fig 9) — 비가 클수록 더 치밀 | §4.3 (L102–114) · §4.7 (L170–174) · §3 (L43) | stated | t_rel 의 재료 값 없음 (Li 에 적용 가능하다는 언급만)
- [c] so2022_dem_contact_model_assb_compaction_sintering | 항복과 영률이 힘–변위 곡선에서 맡는 축: σ^yield 는 수직 (임계력) · E 는 수평 (강성) 방향 · ±20 % E 스윕에서 임계력 거의 불변 | §4.5 (L160) · Fig 5 행 (L195) | 표지 없음 (그림 설명) | 접촉 한 쌍의 곡선
- [c] sharma2023_nmc_single_crystal_anisotropic_nanoindentation | AM (NMC) 압입 경도 H = F/A_c (Oliver–Pharr · Berkovich CSM 200 nm): NMC111 9.37 ± 2.94 · NMC532 14.29 ± 2.53 (선행 [23] 재수록) · NMC622 9.92 ± 3.11 · NMC811 14.17 ± 3.32 GPa | §0 (L27) · §3-2 표 (L106–111) · 논문 p.6 Fig 6 캡션 · SI Table S2 | stated (± 정의 미기재 — SD 로 읽는 것은 카드 추론 L28) | 소결 펠릿 · 방위 미분해 · 결정립 안 국소값 (NMC622 만 확인) · 일축 항복 환산은 논문에 없음
- [c] sharma2023_nmc_single_crystal_anisotropic_nanoindentation | 압입 인성 K_c 평균: NMC111 0.162 · NMC532 0.296 · NMC622 0.258 · NMC811 0.271 MPa m^½ · 전 범위 0.05–0.65 · 중앙값 ≈ 0.103 / 0.227 / 0.212 / 0.221 | §0 (L25) · §3-2 (L106–113) · 논문 p.6 Fig 6d | stated (평균 · 범위) · digitized (중앙값) | ± · N 없음 · 분석 인자 h_min 50 / 100 / 150 nm 에 봉우리 ≈ 0.20 / 0.23 / 0.32 (digitized ±0.005 · L26)
- [c] sharma2023_nmc_single_crystal_anisotropic_nanoindentation | 탄성: NMC622 VRH E 140.16 GPa · ν 0.253 (C₁₁ 194.89 · C₁₂ 133.74 · C₁₃ 11.85 · C₁₄ 8.61 · C₄₄ 74.14 · C₃₃ 177.24 GPa · 108 자리 평균) | §3-1 (L72–77) · 논문 p.5 Fig 5 캡션 · Eq. 10 | stated | NMC622 · 역산 비유일 (§8-4) · ν 는 측정이 아니라 계산값
- [c] sharma2023_nmc_single_crystal_anisotropic_nanoindentation | 우리 쪽 기록 — 경도 ↔ 항복: `analyze_tabor_regime.py` σ_y,AM = H/3 = 2.0 (H_AM 6.0 기준) · 하중 분담 모듈 기본 H_AM 4.0 · 밴드 3–6 · 역산 3.83 GPa | §7 표 (L329) | 표지 없음 (우리 코드 값) | 논문 값 아님 · 카드 판정: 작은 압흔 경도 (9.4–14.3) 는 그 밴드와 안 겹침 (§7-4)
- [c] pasha2014_linear_elastoplastic_adhesive_contact | 접촉 항복압 p_y 35.3 MPa (암모늄 플루오레세인 · Table 1) — 항복 시작 겹침 · 힘 (α_y · f_y) 을 Thornton[24] · Johnson[25] 식으로 잡는 데만 쓰고 소성 가지에서 접촉압을 p_y 로 묶지 않음 | §3 표 (L85) · §7.3 (L317–321) | stated (값) · 카드 해석 (쓰임) | LPSCl 아님 · 일축 항복 환산 없음
- [c] paulick2015_elastic_particle_properties_dem_review | 항복 · 경도 · 크리프 없음 ("σ_y 는 이 리뷰의 소관이 전혀 아니다 — 탄성 리뷰" L929) · 우리 쪽 기록: MPM (E, ν, σ_y) = 1.53 GPa · 0.49 · 0.30 GPa · DFT 쌍 (B₀ 26.23 · E_VRH 22.06 GPa) → ν 0.360 · G 8.11 GPa · MPM 유도 G 0.5134 GPa (÷15.80) · K 25.5 GPa | §4 (L128) · §5-Q4 ⑤ (L349–354) · §10 사전 정리 (L761–763) | DERIVED-BY-US | 논문 값 아님
- [c] schreiner2020_dem_calendering_lib | 값 없음 — Young's modulus 를 먼저 보정했다고 하나 확정값 미공개 · 입자 항복비 추출 안 함 | §3 (L47) · B-4 (L206) | 표지 없음 | —
- [c] roessler2019_dem_cohesive_aor_cylinder_lift_calibration | 없음 (모래 알갱이 G ≈ 90 GPa 를 10⁸ Pa 로 낮춘 탄성 입력뿐 · L91) | — | — | —


### [batch_08] c. 항복 · 경도 · 크리프 값과 정의 · 일축 항복 세기 환산

LPSCl 의 항복 · 경도 · 크리프 실측값은 **이 배치에 없음** (LPSCl 은 Heckel 환산과 체적탄성률뿐). 정의 · 환산은 접촉 이론 카드에 있다.

- [c] storakers1997_similarity_inelastic_contact | 구형 압입 평균 접촉압 (경도): eq78 L/πa² = [3(n+2)/n]·σ₀·(a/3D)^{1/m}·(ȧ/3D)^{1/n} · Tabor 상수 α = 2.8 · β_m = 0.4 채택 → 이상소성 평탄부 H ≈ 2.8σ₀ · 대표 변형 ~0.4·a/D | §3 표 (L36–37) · §7.2 (L131–136) | stated (Tabor 1951 채택) | 재료 무관 · σ₀ = 구성식 σ_e = σ₀·ε̇_e^{1/n}·ε_e^{1/m} (eq6 · L39 · L50) 의 기준 응력 · n = 율 민감 / 크리프 지수 · LPSCl 값 없음
- [c] thorntonning1998_adhesive_elastoplastic_contact | 항복압 캡 정의 p_y = 2E*a_y/(πR*) (eq9) = 3P_y/(2πa_y²) (eq14) · 예시 0.5 / 1.0 / 3.04 GPa · 일축 항복과의 환산 — p_y ≈ 1.6σ_y (항복 시작) · 완전소성에서 평균압 → H ≈ 3σ_y (Tabor) · So 의 F_th = 2/3·H·A_con 은 평균압 ≈ 2σ_y | §3 표 (L68 · L76) · §4 (L96–98) · §7.3 (L250–252) | 예시 값 = stated · 환산은 표지 없음 (카드가 "근사" 라고 적음 · L366) | 재료 무관 (금속급 예시) · p_y 가 평균압인지 중심 (peak) 압인지 카드 안에서 엇갈림 (카드 문제) · LPSCl p_y ≈ 0.08–0.48 GPa (= 1.6 × σ_y 0.05–0.30 GPa) 는 우리 쪽 기록 (L214)
- [c] thorntonning1998_adhesive_elastoplastic_contact | FE 인용: 항복 뒤 압분포가 균일 p_y 로 · 소성 영역이 표면에 닿는 것 = 항복력의 ~6 배 · 중심에 "elastic enclave" 잔존 | §3 표 (L75) · §6 (L187–188) | stated (Hardy et al. [8] 인용) | 다른 논문의 FE
- [c] stallard2022_cathode_mechanical_properties_review | 정의: H = P_I/A_P (식 1 · 압흔 투영 면적) · "the hardness is directly related to the yield strength σY, such that H≈3σY" [79 Tabor] · 양극재 "The hardness varies from 6 to 18 GPa, whereas the Young's modulus varies from 80 to 200 GPa." | §3-1 (L76–77) · §4-1 (L259) · p.992–993 | stated | AM (NMC · LCO · LMO · LCP) — SE 아님
- [c] stallard2022_cathode_mechanical_properties_review | 크기 의존: NMC 작은 압흔 H 7.1–14.0 GPa (Fig 7 · 6 점) ↔ 압흔 ≥ 결정립 (stage III) NMC532 이차입자 5.5 → 3.2 GPa (압흔 크기 0.59–2.59 µm · log-log 기울기 −0.36 · 포화 안 함) | §0 #4 (L26) · §3-3 (L131 · L145) · Fig 7 · 9B/D | vector-read (2차 인용) · 기울기 = derived(ours) D10 | NMC532 · 단일 계열 · 1차 출처 미표기 (추정 [74]) · "H · E 는 A_P^½/d 를 적지 않으면 의미가 없다" (L478)
- [c] stallard2022_cathode_mechanical_properties_review | 일축 항복 환산의 한계: "the tensile strengths are an order of magnitude or more below the uniaxial yield strength σY≈H/3 for all of the layered transition metal oxides" — 인장에서는 항복 전에 깨짐 | §3-1 (L83) · §7 표 (L373) · p.996 | stated (원문 인용) | AM
- [c] varkey2026_multicontact_elastoplastic_dem | 항복비 0.0103 ("δ ~1.03 % 서 소성 시작") · 항복 시작 f_y = (1/6)(R*/E*)²(πp_y)³ · δ_y = (1/4)(R*/E*²)(πp_y)² · E_SE 10.58 GPa · E_CAM 140 GPa · FE 검증 재료 σ_y 280 MPa · E 71 GPa · ν 0.33 | §3 표 (L24–25) · §4 (L30) · Supplementary (L94) | stated (Table 1 · Table S1) | 할라이드 / 금속급 일반 재료 · p_y 값 자체와 항복비의 정의는 카드에 없음
- [c] wang2024_hot_pressed_lpscl_pressure_invariant_conductivity | Heckel 평균 항복압 (LPSCl 냉간 3 점 · 다이 밖): P_y ≈ 354–370 MPa (1.64 기준) · 731–757 MPa (1.86 기준) · R² 0.99–1.00 · 참고로 lee2025 다이 안 294–344 MPa (1.64 기준) | §0 #5 (L32) · §7 표 (L221) | [우리 산술] (입력 [판독] 2 점 + [인쇄] 1 점) · lee2025 값은 이 카드가 정본 카드에서 옮김 | Heckel P_y 는 일축 항복 세기가 아님 — 환산은 카드에 없음 · 3 점 · 다이 밖 (회복 포함) · 기준 밀도에 따라 2 배
- [c] tovar2026_cold_spray_cathode_composite_dem_plastic_elastic_bond | 결합 수준 유효 항복: NMC 복합 응집체 σ0 9.30 × 10⁶ Pa · 경화 인자 α 1.2 (큰 소성변형 유동응력 / 항복응력 · F_p-lim = α·σ0·A · 식 16) · 기판 σ0 Al 3.00 × 10⁷ … W 7.50 × 10⁸ Pa | §3 표 (L42–43) · §4-2 (L79) · Table 1–2 | stated (기판은 "general literature values") | NMC 값은 "복합체를 대표하도록 정한 값 (측정 아님)" · 표의 유도 한계와 Al · Cu · W 의 σ0 가 어긋나 실제 입력 확인 불가 (L159)
- [c] thompson2026_high_pressure_densification_lps_lpscl_xrd_tomography | 항복 · 경도 · 크리프 값 없음 — 탄성 체적 강성만: K₀ 22.9 ± 1.0 GPa · K′ 7.2 ± 0.7 (K′ = 4 고정이면 27.5 ± 0.7 GPa) · 0.3 GPa 에서 고체 부피 −1.24 % | §0 ⑤ (L29) · §3-4 (L89) | [우리 산술] (입력 SI Table S1 = [인쇄]) | 결정 격자의 K 이지 분말 덩어리의 체적 강성이 아님 (L189)
- [c] thakur2014 · vanlew2015 | 항복 · 경도 값 없음 (Thakur: k₁ · k₂ 는 접촉 강성 kN/m 이고 벌크 E 로 환산 불가 · L75; Van Lew: 겉보기 영률과 압쇄 변형에너지뿐 · 압쇄 강도 분포 수치는 미보고 · L148) | — | — | —


### [batch_09] c. 항복 · 경도 · 크리프 값과 정의 · 일축 항복 세기 환산

LPSCl 의 측정 항복 · 경도 · 크리프 값은 **이 배치에 없음**. 경도 (접촉 평균압) ↔ 일축 항복의 환산은 Part I 카드에 있다 (배수가 변위에 따라 2.75 → 1.0).

- [c] zunker2024_mdr_contact_model_partI | 항복 = 일축 항복 세기 Y (탄성-완전소성 · 국부 von Mises). 접촉 평균압의 상한 (카드가 "경화곡선" 이라 부름): p̄/Y = 1.75·exp(−4.4 δ_o/R_o) + 1 (eq 16) → δ→0 에서 2.75 (실험 · 이론 인정 범위 2.61–2.84: Tabor 2000 · Ishlinsky 1944 · Lee 1972) · δ/R→1 에서 1.0 (접촉이 원기둥 단축압축으로 · Quicksall 2004 · Jackson & Green 2005) | §3 (L61–63) · §4-1 (L121) · §4-3 (L148) | stated | 재료 무관 · 상수 2 개는 E/Y = 200 FEM 곡선 한 번에 맞춘 것 · 가공 경화 없음 (완전소성)
- [c] zunker2024_mdr_contact_model_partI | 탄성 → 완전소성 전이: Hertz 평균압 p̄_H = (4E*_c/3π)·√(δ/R) 가 p_Y 에 닿을 때 (eq 40) · 항복 변위는 (4E*_c/3π)·√(δ_Y/R) = Y(1.75e^{−4.4δ_Y/R} + 1) 의 해 (eq 41) | §4-3 (L149–150) | stated (식) | —
- [c] zunker2024_mdr_contact_model_partI | 카드의 우리 계산 (LPSCl 가정 E 22.1 GPa · ν 0.37 · E*_c 12.80 GPa): Y 0.05 / 0.15 / 0.30 GPa → 항복 변위 δ_Y/R (구–평면) 0.064 / 0.56 / 2.06 % · (구–구 ×2) 0.13 / 1.12 / 4.12 % · 우리 겹침에서의 p_Y/Y = 2.26 (복합) / 2.08 (순수 SE) | §3-1 (L79–92) | DERIVED-BY-US ("논문 수치 아님") | 논문에 LPSCl 없음 · E*_c 정의 확인 필요 (카드 문제 4) — p_Y/Y 값은 E*_c 와 무관
- [c] zunker2024_bulk_elastic_partII | FEM 재료 E/Y = 20 · ν = 0.3 고정 · 단축압축에서는 p̄ → Y 로 수렴 | §3 (L54 · L58) | stated | —
- [c] zunker2025_dem_large_deformation_compaction | Avicel PH102 의 Y = 19 MPa — 문헌값이 없어 맞춘 값: "No reports in the literature on Avicel PH102 yield stress could be located, necessitating a fitting of Y" · E 5 GPa · ν 0.4 (문헌 범위) → E/Y 263 | §3-2 Table 1 (L73–75) · L80 · L85–86 | stated · 원문 인용 · DERIVED (E/Y) | 미결정 셀룰로오스 · 카드: "축 · 반경 응력 일치는 Y 를 맞춘 뒤의 일치" (L535)
- [c] zunker2025_dem_large_deformation_compaction | 크리프 · 속도 의존 없음: "Specific compaction speeds and loading sequence timings are omitted because of the rate-independent nature of the defined contact models" · Δγ 450 J/m² 는 K_Ic = √(2ΔγE*_c) 로 역산한 값 (카드 환산 K_Ic 1.64 MPa·m^½) | §3-2 (L76 · L81–84 · L90–92) | 원문 인용 · stated · DERIVED (1.64) | 카드 판정: 이 Δγ 는 열역학 표면 에너지가 아니라 소성 소산까지 묶은 유효 파괴 에너지
- [c] xu2017_nmc532_nanoindentation_modulus_hardness_toughness | AM 경도 — 정의 H = P_max/A(h_c) (식 1 · Oliver–Pharr · Berkovich · 1 mN · 접촉 깊이 ≈ 69 nm · 배치당 이차입자 15 개): NMC532 이차입자 pristine 8.6 ± 1.3 GPa · 소결 펠릿 12.6 ± 1.4 · 4.3 V 충전 7.1 ± 0.8 · 100 사이클 6.5 ± 0.9 GPa | §0 (L24 · L29–31) · Table 1 p. A3337 (L81) · §3-9 (L186) | stated (± 가 SD 인지 SE 인지 미기재 L25) · DERIVED (접촉 깊이) | NMC532 · sub-µm 국소값 · LPSCl 아님
- [c] xu2017_nmc532_nanoindentation_modulus_hardness_toughness | 일축 항복 환산: 논문에 없음. 카드의 우리 쪽 기록 — `analyze_tabor_regime.py` σ_y = H/3 = 2.0 GPa (H_AM 6.0 기준) · 우리 H_AM 6.0 은 pristine 8.6 대비 −2.0 SD 라 이 논문이 뒷받침 못 함 · 이상 기하에서 Vickers H_V ≈ 0.927 × 나노압입 H | §0 (L39) · §7 표 (L320) · §7-2 (L340–346) · 용어집 (L469) | 표지 없음 (우리 코드 값 · 카드 산술) | 논문 값 아님
- [c] xu2017_nmc532_nanoindentation_modulus_hardness_toughness | 하중 의존: < 2 mN 은 하중 무관 · > 2 mN 은 균열로 압입 E 가 내려감 (준정적 판독 3 mN ≈ 121 · 6 mN ≈ 102 · 10 mN ≈ 86 GPa) · > 10 mN 은 계면 균열 + sink-in 으로 Oliver–Pharr 부적합 | §3-5 (L141–142) · Fig 4c | stated (구간) · digitized (값) | 크리프 값 없음 (유지 5 s 만)
- [c] xu2017_nmc532_nanoindentation_modulus_hardness_toughness | 전극 기지 압입: CB + PVDF E 1.78 ± 0.35 · H 0.043 ± 0.01 GPa / 페놀수지 E 10.1 ± 0.8 · H 1.1 ± 0.2 GPa | §3-5 (L140) · Fig 4b | stated | 액체계 전극 기지
- [c] xu2017_nmc532_nanoindentation_modulus_hardness_toughness | 계면 파괴 인성 (cube-corner 방사 균열 · K_c = α(E/H)^½·P/c^{3/2} · α 0.036 · 균열 길이는 pop-in 으로 추정): 이차입자 0.102 ± 0.03 · 펠릿 0.309 ± 0.04 · 100 사이클 0.036 ± 0.018 MPa·m^½ | §0 (L33–35) · §4-3 (L211–220) · Table 1 (L82) | stated | 방법 조건부 (pop-in 길이 ±10 nm → K_c −30 / +59 % · 카드 산술 L290) · 15 압입 중 8–10 개만 사용 (L132)
- [c] 크리프 값 | 이 배치에 없음 | — | — | —


### [batch_10] c. 항복 · 경도 · 크리프 값과 정의 · 일축 항복 세기 환산

LPSCl 계열의 **측정 경도 · 탄성률** 은 lee2025 (나노압입), **Heckel 평균 항복 압력** 은 lee2025 (저자 K) 와 faka2026 (카드 산술). **크리프 값은 이 배치에 없음.** 일축 항복으로의 환산은 카드에 두 가지 (P_y/3 = 우리 쪽 규약 · H/3 = Tabor) 가 있고 서로 4–5 배 다르다.

- [c] lee2025_heckel_argyrodite_powder_densification_nanoindentation | 나노압입 (Oliver–Pharr · 최대 8 mN · 4 s 하중 · 2 s 유지 · 4 s 제하 · 5 곳 평균 ± 표준편차): H = Li₆PS₅Br 1.68 ± 0.11 · **Li₆PS₅Cl 1.41 ± 0.24** · BH₄ 1.85 0.69 ± 0.07 · BH₄ 1.45 0.66 ± 0.05 GPa; E = 30.5 / **27.6** / 15.6 / 19.1 GPa; H/E = 5.5 / 5.1 / 4.4 / 3.5 × 10⁻²; 단면 공극 2.5 / 2.5 / 7.3 / 4.7 %; 압입 깊이 Li₆PS₅Cl ≈ 1.3–1.55 µm | §3-6 (L109–116) · §3-1 (L63) · 논문 Table 2 (p.6344) · Fig 3 · S1 | [인쇄] · 깊이 = [판독] | 펠릿 압밀 압력 [미확인] · E 가 환산 계수인지 영률인지 [미확인] (L139) · 표의 Li₆PS₅Cl 이 합성인지 상용인지 표에는 명시 없음 (Fig S1 행은 "합성 Li₆PS₅Cl" · L155) · 유지 2 s 뿐이라 크리프 자료 아님
- [c] lee2025_heckel_argyrodite_powder_densification_nanoindentation | Heckel stage II 기울기 K (× 10⁻⁴ MPa⁻¹): 상용 32.3 · 볼밀 34.0 (±0.15) · 합성 Li₆PS₅Cl 29.1 (±0.14) · Li₆PS₅Br 25.0 (±0.16) · BH₄ 37.0 / 41.3 (±0.11). 저자 정의: *"The reciprocal of the K value physically represents a quantity proportional to the yield strength of the powder."* → P_y = 1/K = 310 / 294 / 344 / 400 / 270 / 242 MPa | §3-2 (L67–79) · 논문 p.6343 · Table 1 (p.6344) | K = [인쇄] · P_y = [우리 산술] | 누른 채 · 이론밀도 기준 (§a) · ± 의 뜻 [미확인] (적합 오차로 읽힘 · L162) · 단계 경계는 [판독]
- [c] lee2025_heckel_argyrodite_powder_densification_nanoindentation | **일축 항복 환산 (카드에 있음 · 둘 다 우리 쪽 산술)**: ① σ_y,eff = P_y/3 = 103 / 98 / 115 MPa (상용 / 볼밀 / 합성 Li₆PS₅Cl — "frame[3] 의 우리 규약") ② Tabor 근사 σ_y ≈ H/3 = Li₆PS₅Cl ≈ 0.47 · Li₆PS₅Br ≈ 0.56 GPa ("금속 관계 — 황화물에 검증 안 됨 · 참고만"). 두 값은 4–5 배 다르고 카드는 "같은 양이 아니다: 국부 압입 항복 vs 분말 체적 치밀화" 라고 적음 | §3-2 표 (L67–74) · §3-6 (L119) · §4-3 (L136) | [우리 산술] | 저자는 일축 항복 값을 주지 않음 · 환산 근거 문헌은 카드에 없음
- [c] faka2026_particle_size_consolidation_strain_lpscl | 저자는 K · P_y 숫자를 내지 않음. 카드 산술 (Fig S2 판독 · 0.40 → 0.75 GPa 직선): K 3.55 / 2.74 / 1.40 / 1.42 GPa⁻¹ → P_y ≈ 280 / 365 / 710 / 700 MPa (40 / 20 / 11 / 4 µm). 영역 I 재배열 0 → ≈ 0.38 · II 변형 ≈ 0.38 → 0.76 · III 파쇄 > 0.76 GPa | §3-4 (L89–92) · §0 표 ④ (L28) · 논문 Fig 1d | P_y = [우리 산술] · 영역 경계 = [판독] | 구간 선택에 ±20 % (L236) · 큰 입자의 영역 II 기울기에는 파쇄 시작이 섞일 수 있음
- [c] faka2026_particle_size_consolidation_strain_lpscl | 탄성: 격자상수 (Table S3 · 11 µm) 할선 체적탄성률 0.08 → 0.53 GPa K ≈ 27 GPa · 0.53 → 1.08 ≈ 41 · 1.08 → 1.51 ≈ 63 GPa. DEM 입력 Y 18.5 GPa · ν 0.3. 격자 변형 (1.5 GPa 뒤 · Williamson–Hall) 2.06 / 1.08 / 0.80 / 0.76 % (4 / 11 / 20 / 40 µm) · 전위 밀도 ρ_GND ≈ 1.14 × 10¹² m⁻² | §3-5 (L95–102) · §3-6 (L110) | K = [우리 산술] (고압 경화는 "미검증") · 변형 = [판독] · ρ_GND · Y = [인쇄] | 항복 · 경도 값은 없음
- [c] bazzoun2025_dem_parameter_sensitivity_assb_cathode · bazzoun2026_dem_fem_rnm_ionic · kim2024_optimal_cathode_composite_mechanical_mixing_se_coverage | 항복 없음 — DEM 탄성 입력만: E_SE 20.5 GPa (15–200 스윕) · ν_SE 0.33 · E_CAM 161.5 GPa / E_SE 22.1 GPa · ν_SE 0.37 · E_CAM 161.5 GPa / E_LPSCl 22 GPa · E_NCM 175 GPa · ν 0.3 | bazzoun2025 L42–44 · bazzoun2026 L21–22 · kim2024 L115 | stated · [인쇄] | 측정값이 아니라 입력
- [c] kim2024_optimal_cathode_composite_mechanical_mixing_se_coverage | 탄성 FEA 의 SE 안 von Mises ≈ 0.45–0.65 GPa — 카드: "LPSCl 항복 범위 (0.05–0.30 GPa, 우리 frame [1] 의 문헌 범위) 를 넘는다 → 실제라면 SE 는 항복했을 것" | §4-2 (L153) · §3-4 (L127) | [판독] (±40 MPa) · [추정] | 가압이 아니라 충전 중 확산 변형 응력 · 0.05–0.30 GPa 의 출처는 카드에 없음 (우리 쪽 기록)
- [c] frankenberg2025_milling_dry_processed_sulfide_cathode_microstructure · lin2025_submicron_lpscl_cathode_li_kinetics · minnmann2024_microstructure_porosity_visualization | 값 없음 — 정성 서술만: LPSCl 이 무르므로 (*"low hardness"*, ref 43 · 44) NCM 과 융합 (frankenberg L122) · *"soft SU-LPSC"* (lin2025 L231) · "E_SE / σ_y / ν n/a (실험; 모듈러스 미측정)" (minnmann2024 L54) | 왼쪽 괄호 | [인쇄] · stated | —
- [c] lei2026_se_particle_size_effects_review | LPSCl 값 없음 — 다른 재료의 2차 인용: LLZO 경도 (9.88 ± 0.49) → (6.86 ± 0.49) GPa (결정립 5 → 600 µm) · 파괴인성 (0.82 ± 0.07) → (0.60 ± 0.05) MPa·m^½ · LGPS 는 > 3 µm 분쇄 / 1–3 µm 균열 / < 1 µm 균열 거의 없음 | §3-4 (L97–99) | [2차 · ref 84 · 62] | LLZO · LGPS (LPSCl 아님) · 원 논문 미확인
- [c] minnmann2021_jes_charge_transport_bottlenecks | 이 카드에 없음 (기계 물성 없음) | — | — | —


### [batch_11] c. 항복 · 경도 · 크리프 값과 정의 · 일축 항복 세기 환산

값이 있는 카드 = 2 (schneider2023 의 Heckel 항복압 · shi2019 의 "σ_y" = 실제로는 경도). 크리프 값은 이 배치에 없다.

- [c] schneider2023_particle_size_pressure_transport | Heckel 평균 항복압 P_y = 1/K ("in die" · regime II 기울기 · 식 ln(1/(1−ρ_rel)) = K·p + A): **0.95(3) GPa (<50 µm) · 1.65(3) GPa (>50 µm)** — 작은 입도 쪽이 낮음 | §3 (L57) · §6 (L118–120) | stated | t-Li₇SiPS₈ · GPa 대 측정 · **일축 항복 세기 환산은 카드에 없음** (카드는 "유효 항복 (σ_y proxy)" 이라고만 · 우리 쪽 기록으로 P_y 138 MPa ↔ σ_y_eff ≈ 46 MPa 를 나란히 적음 L136) · E · σ_y · ν 수치는 본문 미제공 (L64 · L75)
- [c] shi2019_high_am_loading_particle_size_assb | SI "Table 1" 의 "σ_y (Yield stress)" **2 GPa (LPS) · 12.6 GPa (NMC)** · E 18.5 / 177.5 GPa · ν 0.3. 카드 판정: 이 값은 항복응력이 아니라 **나노압입 경도** — AM 177.5 / 12.6 은 정본 xu2017 카드의 소결 NMC532 펠릿 E · H 와 소수점까지 같고 · SE 2 는 McGrogan LPS H 1.9 GPa (so2021 카드 경유 2차 · 원문 미확인) 와 맞음. 환산 문장: "Tabor (H ≈ 3 σ_y) 로 읽으면 실제 항복응력은 이 값의 ≈1/3". 힘 식에는 σ_y 항이 없어 결과에 안 쓰임 | §3 (L120) · §4 (L179–187) · §S.1 (L341 · L348–351) · SI p.2 | SI-stated (값) · 정본 카드 대조 (판정) · derived(ours) (환산) | LPS 유리 (LPSCl 아님) · [1] McGrogan · [2] de Vasconcelos 원문 [미확인] · AM 값의 [2] 귀속은 오류 공산 (판정 보류)
- [c] otani2025_dem_se_dispersion_aggregation_compression | 이 논문에는 항복 · 경도 입력이 없음 (Table 1 에 없음). 카드가 다른 카드에서 가져온 값 H_LPS ≈ 1.9 GPa (McGrogan · So 카드 경유) 와 카드 산술 — 300 MPa 에서 SE 접촉면 평균압 3.00 GPa (Z=6) / 2.73 GPa (Z=8) = 경도의 1.4–1.6 배 · 1000 MPa 에서 4.34 / 3.95 GPa. 같은 연구실 So 2021 / 2022 의 항복식 F_th = 2/3·min(H_i, H_j)·A_con 을 이 논문이 버렸다는 기록 | §0 (L35–37) · §4.5 (L264) · §10-⑦ (L517–521) · §11-② (L547–556) | DERIVED ("오더 추정" · Z · ν 가정) | 논문 값이 아니라 카드 계산 · 평균장 Hertz
- [c] schlautmann2023_se_particle_size_composite_transport | CAM E = 194 GPa (ref 31) — 겹침 영역을 CAM 에 배정하는 근거로만 쓰임 · 항복 · 경도 없음 | §4g (L200) | stated | 역학 계산 없음
- [c] tailored_cathode_microstructure_low_pressure_assb · park2020_dimension_controlled_se_percolation_contact_area · stavola2023_thick_nmc111_lpscl_lithiation_gradient_tortuosity | 이 카드들에 없음 (Zhou: E · σ_y · ν 본문 미기재 L54 · L65 / park: [18] · [19] 영률 인용만 · 값 없음 L239) | — | — | —


### [batch_12] c. 항복 · 경도 · 크리프 값과 정의 · 일축 항복 세기 환산

LPSCl 의 **측정 경도 · 탄성률** = larson2025 (압분체 나노압입 · 100 mN). 경도를 DEM 항복 기준으로 쓴 것 = so2021 (LPS · Si). 단일 입자 항복 변위 = sangros2019 (NMC111). **크리프 값은 이 배치에 없음.** 일축 항복으로의 환산은 larson 카드의 Tabor 어림 (우리 쪽 산술) 하나뿐.

- [c] larson2025_hot_pressing_argyrodite_low_stack_pressure_conductivity | 나노압입 (Li₆PS₅Cl 펠릿 · Berkovich · 최대 100 mN · 무연마 · 압흔 간격 200 µm · 접촉 깊이 > 5 µm 는 제외): 감소 탄성률 E_r 10.6 GPa (SD 3.7 · 냉간 · 압흔 66) · 22.1 GPa (SD 4.9 · 열간 · 압흔 33); 경도 H 0.72 GPa (± 0.16) · 0.78 GPa (± 0.25); 평균 최대 변위 ≈ 2.5 µm · 표면 압흔 15–20 µm (*"tens of grains"*) | §3-7 (L133–142) · 논문 p.3756 · p.3759–3760 · Fig 8 | [인쇄] | 조건마다 펠릿 1 개 · 해석법 (Oliver–Pharr 등) 명칭 [미확인] · 원문은 E_r 를 그대로 "Young's modulus (approximated)" 로 씀 (L146) · 공극 ≈ 12–14 % 압분체의 수십 입자 척도 값
- [c] larson2025_hot_pressing_argyrodite_low_stack_pressure_conductivity | 일축 항복 환산 (카드에 있음 · 우리 쪽 산술): Tabor 어림 σ_y ≈ H/3 = 0.24 (냉간) · 0.26 GPa (열간) — "다공 압분체 · 큰 압흔에서 계수 3 은 [미확인] (참고값)". E_r → E (다이아몬드 E_i 1141 GPa · ν_i 0.07 · 시료 ν 0.37 가정) = 19.5 (열간) · 9.2 GPa (냉간) | §3-7 (L146–147) · §7-1 (L228) | [우리 산술] | 저자는 항복 값을 주지 않음
- [c] larson2025_hot_pressing_argyrodite_low_stack_pressure_conductivity | 탄성 에너지 비 W_e/W_t: 본문 0.2 (20 °C) · 0.38 (150 °C) — 카드는 배정이 뒤바뀐 것으로 봄 (원문이 *"proportional to H/E"* 라 하는데 H/E = 0.068 (20 °C) · 0.035 (150 °C) · Fig 8d 는 d_e,h ≈ 0.5·d_e,c) | §3-7 (L140–145) · 논문 p.3760 | 값 = [인쇄] · 뒤바뀜 = [우리 해석] · H/E = [우리 산술] | —
- [c] larson2025_hot_pressing_argyrodite_low_stack_pressure_conductivity | 크리프: 값 없음. 열간 = 300 MPa 아래 ~45 분 · 냉간 ~5 분이라 "150 °C 효과" 와 "9 배 긴 유지 (크리프 · 이완)" 를 가를 수 없음 (같은 시간 냉간 대조 없음 · 실제 150 °C 체류 시간 [미확인]) | §10-1 (L276) · §3-1 (L58–59) | 조건 = [인쇄] · 판단은 카드 | —
- [c] larson2025_hot_pressing_argyrodite_low_stack_pressure_conductivity | 카드가 모은 같은 Li₆PS₅Cl 의 E 사다리 (다른 정본 카드 값 포함): 다공 13 % 냉간 압분체 굽힘 4.7 ± 1.1 GPa (song2025) · 냉간 펠릿 100 mN E_r 10.6 · 열간 22.1 (이 논문) · DFT 22 (Deng 2016) · 치밀 · 연마 나노압입 27.6 (Lee 2025) · 28.0 (Ning 2023) | §7-4 (L246–254) | "[인쇄 값 · 정본 카드]" | 다른 카드 값은 이 배치에서 확인하지 않음
- [c] so2021_dem_mold_pressure_assb_coldpress | 경도 (DEM 입력): H_SE (LPS) 1.9 GPa (McGrogan [8]) · H_AM (Si) 10.6 GPa (de Vasconcelos [38]) · E_SE 24 GPa (Sakuda [12]) · E_AM 70 GPa (Sethuraman [37]). 항복 정의: 임계력 F_th = 2/3·min(H_i, H_j)·A_con (식 14 · 포물선 응력 분포의 2/3 인자) · A_con = π·h_ov·R_eff (식 15) · 평형 겹침의 변화율 ∂h_eq/∂t = (F_spring − F_th)/(t_rel·k_n) (식 13 · t_rel = 완화시간) | §3 (L38–41) · §4 (L55) · 논문 Table 1 · eq 12–15 | stated | LPS · Si (LPSCl · NCM 아님) · t_rel 값은 카드에 없음 · 일축 항복 환산 없음
- [c] sangros2019_dem_calendering_lib_electrode | 단일 NMC111 입자 나노압입 (TriboIndenter TI 900 · 30 nm s⁻¹ · 40 입자): 항복 시작 법선변위 δ_y = 8.59 × 10⁻³ · x (x = 입자 크기 µm · R² = 0.89) — 항복 전 (겹침 ≲ 반경의 0.1 %) 은 Hertz 와 맞고 그 뒤는 벗어남. Thornton–Ning 항복: F_y = (1/6)·(R*/E*)²·(π·p_y)³ · δ_y = (1/4)·(R*/E*²)·(π·p_y)² (p_y = 항복 시작의 최대 접촉압) · E_NMC 142 GPa · ν 0.25 | §3 (L34–38) · §4.2 (L56–72) · 논문 Table 2 · Fig 1 · 2 · eq 3–4 | stated | 활물질 NMC111 (SE 아님) · p_y 값 자체는 카드에 없음 · 일축 항복 환산 없음
- [c] sangros2020_lib_electrode_dem_mech_elec_ionic | NMC 입자 강도 σ_p ~3.4 × 10⁸ → 1 × 10⁸ N/m² (입자 2 → 20 µm · 작을수록 강함 · 나노압입 80 입자) · E_NMC 142.5 → 111.6 GPa (리튬이 빠질수록 감소) | §3 (L41–42) · §4 (L49) · 논문 Fig 3 | stated/digitized | 파쇄 기준용 값 · NMC111
- [c] yano2026_se_psd_width_ionic_tortuosity_dem | 항복 · 경도 값 없음 — EEPA 접촉 소성비 λp = 1 − k₁/k₂ (식 6 · 하중 / 제하 강성비): NCM–NCM 0.38 (Cheng 2017) · LPSCl–LPSCl 0.642 (Papakyriakou 2021) · NCM–LPSCl 0.619 (등가 소성비 · Yano 2024); 입력 E_LPSCl 21 GPa · ν 0.37 · E_NCM 71 GPa (원래의 절반) | §4d (L186–192) · 논문 p.3–4 · 표 2 · 3 | [인쇄] | 소성비는 항복 세기가 아님 · 일축 환산 없음
- [c] demirtas2021_mpfem_hollow_sphere_die_compaction | 재료값 없음 — 무차원 탄성-완전소성 E/σ_y = 100 · ν 0.3. 항복 관측량 YV/TV = 등가 소성변형이 0 이 아닌 요소의 부피 합 ÷ 전체 요소 부피 | §4-4 (L311–318) · §3-3 (L152–153) | stated | HPMCAS · 실제 E · σ_y · 진밀도 없음 (L227)
- [c] diener2022_roll_gap_springback_calendering | 항복 · 경도 없음 — 전극 E 14 GPa (Haselrieder 인장 · ref 2) · 강철 롤 E 210 GPa · ν 0.3 | §3-3 (L68–69) | [인쇄] | LIB 전극 층의 값
- [c] yadav2021_lpscl_sieved_psd_impedance_tortuosity | 값 없음 — 동기 문장의 *"young's modulus reported up to 20 GPa"* [Sakuda 2013] 뿐 | §2 (L51) | [인쇄] | —
- [c] benhadjali2026_wip_vs_cup_pressing_assb_cathode_dem | 값 없음 — FEM 의 E · ν (AM · SE · CBD) 는 본문 어디에도 없음 (Table S2 [미확인]) | §4-3 (L244) | [미확인] | —


### [batch_13] c. 항복 · 경도 · 크리프 값과 정의 · 일축 항복 세기 환산

항복 세기 · 경도 · 크리프를 직접 잰 카드는 이 배치에 없다. Heckel 기울기를 **카드가** 맞춘 것 둘 — miss2026_insitu (순수 SE 누른 채 P_y 219–243 MPa) · ngandjong2021 (LIB 전극 · 뺀 뒤 · 408–1,284 MPa · 카드 스스로 인용 금지 판정). 일축 항복 세기로의 환산은 어느 카드에도 없다.

- [c] miss2026_insitu_conductivity_porosity_pressure_compaction | 항복 · 경도 · 크리프의 직접 값 없음. 카드가 재계산 기공으로 맞춘 Heckel (논문은 안 함 · ln(1/ε) = K·p + A · P_y = 1/K): SE 누른 채 (그림 규약) 10–400 MPa K 4.57 /GPa → **P_y 219 MPa** (R² 0.984) · 100–400 MPa 4.11 → **243 MPa** (0.985) · 보정 없음 205 · 220 MPa · SE 놓은 뒤 263 · 300 MPa · NMC 누른 채 391 · 384 MPa (0.998) · NMC 놓은 뒤 658 MPa | §3-8 (L171–180) · §7-6 (L307–309) | [우리 산술] | 일축 항복 세기로의 환산은 카드에 없음 · 단계 하중 · 반복 제거 이력의 값 (단조 Heckel 과 다를 수 있음) · ρ₀ 선택이 K 를 움직임 · 조성 Li₅.₅PS₄.₅Cl₁.₅
- [c] miss2026_insitu_conductivity_porosity_pressure_compaction | 탄성 입력의 문제: 논문은 SE 에 E = 67 GPa (Munsif 2023 DFT 인용) 를 씀 — 카드: 우리 DFT E_VRH 22.06 GPa 의 3 배이고 문헌 띠 10–30 GPa 밖 → 탄성 보정이 1/3 크기 (300 MPa 에서 0.45 % ↔ E 22 면 1.36 % · 기공으로 0.4 ↔ 1.3 %p). 압력에 따른 물질 고유 σ 변화 (Faka 2023 활성화 부피 0.6–1.1 cm³/mol → 0 → 400 MPa 에 −10–20 %) 는 저자가 무시 | §4-4 (L206) · §4-8 (L228) · §10-4 · 5 (L336–337) | E = [인쇄] · 비교 = [우리 산술] · 활성화 부피 = [인쇄 p.32833] (ref 30 인용) | 유지 시간 [미확인] 이라 시간 의존 (크리프) 은 알 수 없음
- [c] zhang2026_xct_dem_cathode_calendering_peel_calibration | 모델에 항복 · 경도 없음 (순수 탄성 Hertz). 카드가 대조 기준으로 끌어온 값: NMC532 이차입자 나노압입 경도 H = 8.6 ± 1.3 GPa (정본 xu2017 카드) · NMC811 이차입자 파괴강도 σ_F = P_f/D² = 207 ± 49 MPa (평판 압축) · 67 ± 21 MPa (원뿔-구형 팁) (정본 wheatcroft2023 카드 · stated) | §12 D7 (L549) · D7b (L552–554) | 다른 카드 값의 인용 | NMC 값 (SE 아님) · 일축 항복 세기 환산은 카드에 없음 · 재료 · 기하가 달라 "크기 감각만" (카드 표기)
- [c] zhang2026_xct_dem_cathode_calendering_peel_calibration | 점착 쪽 값: 박리 (수직 인장) 피크 0.0347 ± 0.0032 MPa (보정 표적 · 3 회 · 0.01 m/min) ↔ 같은 쪽의 "박리강도 0.17 ± 15 % MPa (~200 MPa 압연 전극)" — ≈ 4.9 배 차이를 논문이 가르지 않음. 보정된 입자–Al bond 강도 7.2 × 10⁴ Pa · 입자–입자 3.6 × 10⁷ Pa (비 500) | §3.4 (L153–165) · §12 D6 (L536–538) · §10 L5 (L468) | stated · 비 = derived(ours) | 카드: "박리 수치는 정의가 확정될 때까지 절대값 인용 금지" · 시간축이 무차원이라 에너지 (G_c) 는 못 냄
- [c] ngandjong2021_dem_calendering_digital_twin | 항복 · 경도 · 크리프 값 없음 (Vickers 압입은 F–d 곡선의 정규화 비교에만 씀). 카드가 직접 한 Heckel 변환 (논문은 하지 않음) 의 1/K = 408 (실험 전체 0–156 MPa · n 5 · R² 0.637) · 740 (P ≥ 5 · n 4 · 0.796) · 410 (5–90 · n 3 · 0.992) · 1,284 MPa (30–160 · n 3 · 0.571) · 모의 5–90 은 476 MPa (0.957) → 카드 판정 "이 논문에서 Heckel P_y 를 인용하면 안 된다" (창에 따라 3.1 배 · 자유도 1 · 뺀 뒤 값) | §3-A-6 (L189–209) · T11 (L251) | derived(ours) | 일축 항복 세기와의 환산은 카드에 없음 · LIB 전극 · "DEM Heckel P_y = 138 MPa · σ_y_eff ≈ 46 MPa" (L217) 는 우리 쪽 기록
- [c] lyu2025_3d_dem_drying_calendering_lib | 항복 · 경도 · 크리프 값 없음 (접촉에 항복 캡 없음). 관련 값은 실험 입자 파쇄 임계 응력 200 MPa (fracture onset · ref [57]) 하나 — 논문은 두께 방향 응력을 이 아래로 두라고 경고만 하고 파쇄 모델은 없음 | §3 (L35) · §1 (L13) · §4 (L57) | stated | NCM811 입자 (평균 13 µm) · 파쇄 임계의 정의 (입자 응력인지 전극 평균 응력인지) 는 카드에 없음 · 일축 항복 세기 환산 없음
- [c] xu2023_realistic_am_shape_cgmd_calendering | 항복 · 경도 · 크리프 값 없음 — 접촉은 JKR (탄성 + 점착) 이고 소성이 없음. 탄성 입력만: E_AM 135 GPa (refs [39–41] = 실험 + grid indentation) · E_CBD 건조 2 GPa · 슬러리 0.0005 GPa · ν 0.3 (다섯 상 모두) | §3 (L110–111) · §4 (L340) | stated | 일축 항복 세기 환산 없음 · NMC111
- [c] miss2026_pressure_tortuosity_composite_cathode_coating | 이 카드에 없음 (항복 · 경도 · Heckel · 두께 자료 없음) | §0 표 ④ (L28) · §6 (L197) | — | —


### [batch_14] c. 항복 · 경도 · 크리프 값과 정의 · 일축 항복 세기 환산

황화물 SE 의 항복 · 경도 · 크리프를 직접 잰 카드는 없다. 값이 있는 것 = DEM 입력 경도 (so2022: LPS 1.9 GPa · 인용값) · 탄성률 (sakuda2013: 유리 18–25 GPa) · Li 금속 항복 ≈ 0.8 MPa (doux2020 · deysher2022 의 인용) · CAM 항복 ≈ 100 MPa (kang2026 의 인용). **일축 항복 세기로의 환산은 어느 카드에도 없다.**

- [c] so2022_dem_compaction_coated_particles_assb | DEM 입력: H_SE (LPS) 1.9 GPa (McGrogan [7]) · H_AM (NCM) 11.2 GPa (Cheng [37]) · E_SE 24 GPa (Sakuda [8]) · E_AM 199 GPa (Cheng [37]) · ν 0.32 / 0.25 · 마찰 0.5 · 반발계수 0.5. 항복 문턱 F_th = min(H_i, H_j)·A_con (카드: "σ_yield ≈ H 근사") | §3.1 L43–49 · §4.1 L94 · Table 1 · 식 7 | stated (Table 1) | LPS (LPSCl 아님) · 접촉 평균 압력을 경도 H 로 둔 것이고 일축 항복 세기 환산은 카드에 없음 · 완화 시간 t_rel 값 없음
- [c] sakuda2013_sulfide_mechanical_property | 탄성률 (초음파 펄스법 · Tg 근처 열간 프레스 고밀도 펠릿 · 10 mm φ × 수 mm): xLi₂S·(100−x)P₂S₅ x = 50–80 에서 18–25 GPa · 75Li₂S·25P₂S₅ = 24 GPa · 50Li₂S·50P₂S₅ = 18 GPa (원문 p.3 인쇄는 "18 Pa" 오식) · 75Na₂S·25P₂S₅ = 18 GPa · Fig 5 점 ≈ 17.5 / 22 / 23.5 / 25 GPa @50 / 70 / 72 / 80 mol% | §3 L55–60 · §13-5 L256 · Fig 5 | stated · 네 점은 digitized (Fig 5) | 유리 (LPSCl 아님) · 항복 · 경도 · 크리프 값 없음 ("small-scale plasticity" 는 정성 설명 · L119) · 일축 항복 환산 없음
- [c] doux2020_stack_pressure_assb | Li 금속 항복강도 ≈ 0.8 MPa (Masias 외 / Tariq 외) · 그 위에서 creep · LePage 외: 상온 Li 항복은 creep 지배. 작동압 5 MPa 가 그 ≈ 6 배 · 75 MPa 가 ≈ 100 배 | §1 L72–75 | 표지 없음 (카드: "본문 인용") | Li 금속 값 — LPSCl 의 항복 · 경도 · 크리프 값은 카드에 없음 (카드: "creep 주체는 Li metal")
- [c] deysher2022_transport_mechanical_aspects_assb_review | Li 크리프 항복 ≈ 0.8 MPa (1–7 MPa 적층압에서 소성 + creep · [107] Masias) | §3 L94 | stated (인용) | Li 금속 · SE 값 없음 · 리뷰
- [c] kang2026_intertwined_electrochemo_mechanical_sulfide_assb_review | CAM (Ni-rich 산화물) 항복강도 σ_y ≈ 100 MPa · 불균일 탈리튬에서 수 GPa 응력 (ref 111 계산) · CAM E 150–200 GPa (ref 101 / 102) · 황화물 SE E 20–30 GPa · Li 는 점성 거동 (diffusional creep · 정성) | §5.1 L127 · L138 · §5.2 L151 · §9 L258–261 | 2 차 인용 | 리뷰 인용값 · ≈ 100 MPa 의 원전 번호가 카드에 없음 · SE 항복 · 경도 없음
- [c] lee2024_multiphysics_dem_fem_initial_pressure_assb | 항복 · 경도 없음 (접촉에 항복 캡 없음). 탄성 입력 E: LGPS 37.2 · LLZO 150.3 · NMC 144 · graphite 1 · carbon black 80 GPa · ν 0.3 / 0.26 / 0.25 / 0.3 / 0.3 (LGPS / LLZO / NMC / graphite / CB) | §3 L59–64 · Table 1 | stated (Table 1) | LGPS · 저자 한계: FEM 이 항복 응력 초과 변형 / 파괴 미반영
- [c] kakar1967_deformation_theory_hot_pressing | 항복 · 경도 값 없음 (카드: "힘 · 경도 법칙은 없다 (순수 기하)"). 크리프와 닿는 절차: 사파이어는 순간 변형이 수 초 안에 둔화 → 30 s 만 유지 (확산 크리프가 아닌 소성 흐름 보장 목적) · 평면 크기 산포의 원인 가운데 하나로 "구 부위별 경도 차" | §3-A L65 · L67 · §4-4 L160 · 논문 p.3227–3228 | stated | 사파이어 1570–1700 ℃ · 납
- [c] nisar2024_dem_effective_electrical_conductivity_sps | 역학 값 (E · σ_y · ν) 본문 미보고 — 소결 모델 [43] 에 위임 | §3 L46 · §4 L63–64 | — | —


### [batch_15] c. 항복 · 경도 · 크리프 값과 정의 · 일축 항복 세기 환산

황화물 SE 의 항복 · 경도 · 크리프 값을 준 카드는 **없다**. 있는 것은 탄성 입력뿐 (cronk2026: LPSCl E 22 GPa · ν 0.3 / bielefeld: ≈ 25 GPa). **일축 항복 세기로의 환산은 어느 카드에도 없다.**

- [c] cronk2026_lis_positive_electrode_geometry_fem | 항복 · 경도 · 크리프 값 없음 — FEM 파라미터 표에 "항복응력 σ_y 없음 · 경화 없음 · 소성 없음 · 파괴/CZM 없음" (카드 서술). 탄성 입력: E_SE 22 GPa · ν_SE 0.3 (LPSCl) · E_S 17.8 GPa · ν_S 0.32 (황) | §4.2 L214–227 · SI p43 Table S6 | stated (표) · "없음" 은 카드의 표 전수 확인 | ν 0.3 은 출처 표기 없는 FEM 입력 (L14) · 측정값 아님
- [c] cronk2026_lis_positive_electrode_geometry_fem | LPSCl 탄성상수 대조 (카드 계산): Cronk FEM E 22 · ν 0.3 → G 8.462 · K 18.333 GPa / Deng 2016 (논문 ref 57) E 22.1 · ν 0.37 · G 8.1 · K 28.7 / 우리 DFT E 22.06 · ν 0.360 · G 8.11 · B₀ 26.23 — E 는 0.3 % 안 · K 만 −30~−36 % (ν 선택 탓) · 계면 von Mises 에 주는 영향은 ≈ +12 % | §4.7 L296–317 | derived(ours) | 탄성만 · 일축 항복 환산 없음
- [c] cronk2026_lis_positive_electrode_geometry_fem | 소성 개시와 닿는 논문 문장: *"The plastic deformation of the SSE matrix is not surprising, as the simulated stresses estimated above is **near the shear modulus of LPSCl**"* (p10 · ref 57 = Deng 2016) — 계산된 von Mises 평균 2.42 / 2.40 GPa · *"beyond 5 GPa"* · 꼬리 8 GPa ↔ G 8.1 GPa (평균은 G 의 30 % — 카드 계산) | §5.1 L331–335 · §5.2 L344–346 | stated (인용문 · 그림 주석) · 비율은 derived(ours) | 선형탄성 · 기공 0 · 경계 고정의 상한 응력 — 항복 세기 값이 아님
- [c] cronk2026_lis_positive_electrode_geometry_fem | 파괴 쪽 환산 (카드 계산): K_IC 0.3 MPa·m^½ (Fan 2026 의 0.2–0.4) → 임계 결함 a_c ≈ K_IC²/(πσ²) = 0.8 nm @6 GPa · 5 nm @2.4 GPa · G_c 환산 3.24 J/m² (E 24 사용) | §5.2 L368–374 | derived(ours) | 2 차 인용 + 카드 계산 · 항복 아님
- [c] bielefeld2019_microstructural_modeling_composite_cathode | E_SE ≈ 25 GPa (LPS · 논문 refs 32–34) — SE 다면체의 겹침을 허용하는 근거 ("낮은 영률 + 연성") 로만 쓰고 계산에는 안 씀 | §3 L59 · §4 L71 · 논문 p.1628 | stated | thiophosphate 일반 (LPSCl 특정 아님) · 항복 · 경도 없음
- [c] bielefeld2020_effective_ionic_conductivity_binder | 같은 근거를 이어 씀: "LPS의 낮은 Young's modulus ~25 GPa·연성을 기하 겹침으로 근사" | §2.1 L106–108 | 표지 없음 (카드 서술) | 항복 · 경도 없음
- [c] beutl2024_round_robin_coin_cell_sulfide_assb | SE 값 없음. 다이 재료만: *"compressive strength of PEEK is around 118–130 MPa[38]"* (자작 PEEK 다이는 고압 치밀화를 못 견딜 수 있다) | §3-2 L87 · 논문 p.5 | [인쇄] | 다이 재료 (공급사 자료 인용)
- [c] asano2017 · chen2011 · cooper2017 | 이 카드들에 없음 (chen2011: "E·ν·μ·COR·σ_y 전혀 없음" L82) | — | — | —


### [batch_16] c. 항복 · 경도 · 크리프 값과 정의 · 일축 항복 세기 환산

황화물 SE 의 항복 · 경도 · 크리프 값을 준 카드는 **없다**. 있는 것은 파괴 인성 (hamann2026 — LLZO · 인용된 LPSCl 값) 과 다른 카드에서 옮긴 탄성 입력뿐이다. **일축 항복 세기로의 환산은 어느 카드에도 없다.**

- [c] hamann2026_llzo_bilayer_porosity_asr_dendrite_ccd | 항복 · 경도 · 크리프 값 없음. 파괴 쪽만: LLZO K_IC 1.25 MPa·m^½ · 표면 결함 깊이 0.4–1.0 µm · γ 1.12 (Porz 식의 입력) → 결함 파괴 응력 σ₀ = K_IC/(γ√(πa)) = 996 MPa (0.4 µm) · 630 MPa (1.0 µm) | §3.1 L112 · §13 D2 L415 | stated (입력) · derived(ours) (응력) | LLZO (산화물) · 파괴 인성이지 항복이 아님
- [c] hamann2026_llzo_bilayer_porosity_asr_dendrite_ccd | LPSCl 쪽 (다른 카드 인용): K_Ic 0.17 (song2025 · 다공 13 % 펠릿 · 거시 시험) — LLZO 의 약 1/7 · Fan 2026 초안 범위 0.2–0.4 | §7 L275 · §9 I-7 L344 · §13 D10 L448 | 표지 없음 (다른 카드 인용) | 이 카드에는 숫자만 (단위는 LLZO 값과 같은 줄에 놓여 있음) · 일축 항복 환산 없음
- [c] hlushkou2018_void_space_ion_transport_assb_cathode | SE (LPSI 유리) 의 E · σ_y · 입경 · 펠릿 밀도는 원문에 없음 | §3-A L73 · §10 L341 | [미확인] | —
- [c] galvezaranda2024_time_dependent_dl_calendering_microstructure | 이 논문에 DEM 물성 0 건 (E · ν · µ · COR · 접촉 법칙 전부 미기재). 카드가 옮긴 계보 카드 값 (ngandjong2021 · 같은 그룹 · 같은 조성): E_AM 200 GPa · E_CBD 2 GPa · ν_AM 0.3 / ν_CBD 0.5 · COR 0.15 · X_µ 0.001 | §4-1 L165–185 | 미기재 (이 논문) · 다른 카드 값 (출처 분리 경고 L184–185) | 탄성 입력뿐 · LIB · 이 논문 값이 아님
- [c] froboese2019_microstructure_ionic_conductivity_assb_electrode | 기계 물성 0 건 — 카드가 "famprikis2019 카드가 이 논문을 σ_y(SE) · K_Ic · µ 조달 대상으로 적었으나 이 논문에는 기계 물성이 하나도 없다" 는 정정 후보를 적음 | §10 L440 | 카드 서술 | —
- [c] duquesnoy2020 · holzer2013 · islam2026 | 이 카드들에 없음 | — | — | —


### [batch_17] c. 항복 · 경도 · 크리프 값과 정의 · 일축 항복 세기 환산

황화물 SE 의 항복 · 경도 · 크리프 값을 준 카드는 **없다**. 있는 것은 AM 입자 경도 (jung2023) 와 LIB 전극 · 과립 · DFT 값 (kim2026_pregranulation), 다른 카드에서 옮긴 SE 탄성 (kato2018) 뿐이다. **일축 항복 세기로의 환산은 어느 카드에도 없다.**

- [c] jung2023_single_crystal_ncm_morphology | NCM 입자 경도 (particle hardness): 단결정 SC 972.7 MPa · 다결정 PC ~113.3 MPa (≈ 8.6 배) — 정의 = micro-indenter (MCT-W500 · Shimadzu) 응력–변형 곡선의 peak · 액체 전해질 침지 뒤 PC 는 급감 · SC 는 유지 (정성) | §3 L60–61 · Fig 3c (L100) · Fig S8 (L112) | stated · stated(정성) | AM (NCM · Ni 82 %) 입자 값 — SE 아님 · D50 5.0 / 4.9 µm · 시료 수 · 하중 조건은 카드에 없음 · 일축 항복 환산 없음
- [c] jung2023_single_crystal_ncm_morphology | 분말 값: tap density SC 2.10 / PC 2.02 g/cm³ · BET 0.23 / 0.28 m²/g | §3 L62–63 · Fig S5 | stated | 압밀 밀도 아님
- [c] kim2026_pregranulation_ptfe_dry_nca_cathode_crack_delithiation | 과립 압축 강도 C₁₀: 1.832 → 3.889 kgf/mm² (= 17.97 → 38.14 MPa · × 2.12) — NCA + PTFE (+ 탄소) 과립 · 미세 압축 시험 (MCT-510) · C₁₀ 의 정의 · 시료 수 · 과립 크기는 [미확인] | §3-2 L92 · Fig 1i | [인쇄] · [우리 산술] (MPa 환산) | LIB 건식 과립 — SE 아님
- [c] kim2026_pregranulation_ptfe_dry_nca_cathode_crack_delithiation | 전극 나노압입 (G200): 경도 24.5 / 19.3 MPa (기존 / 과립화 · 사이클 전) → 5.6 / 9.0 MPa (10 사이클 뒤) · 탄성률 774.65 / 327.13 → 125.66 / 163.58 MPa | §3-8 L183–190 · 표 S3 | [인쇄] | 다공 복합 전극의 겉보기 값 (입자 물성 아님 — 카드 L191) · LIB · 가로축 단위 의심
- [c] kim2026_pregranulation_ptfe_dry_nca_cathode_crack_delithiation | 전극 인장 (UTM): 최대 응력 0.61 MPa (연신 7.4 %) / 0.59 MPa (23.6 %) · toughness 36.6 → 121.2 kJ/m³ | §3-3 L102 · Fig 2g · S16 | [인쇄] | PTFE 로 묶인 막의 인장 — 압축 항복 아님
- [c] kim2026_pregranulation_ptfe_dry_nca_cathode_crack_delithiation | DFT (NCM622 대리 모형 · PBE · 힘 수렴 0.2 eV/Å): pristine B 128 · E 141 · G 54 GPa · ν 0.315 · Vickers 4.40 GPa — 경도는 B · G 의 경험식 재표현 (카드 재현 ≤ 3 %) 이라 독립 지표가 아님 | §3-5 L140–156 | [인쇄] · [우리 산술] (ν · 경도 재현) | AM (그것도 NCA 가 아닌 NCM622) · 느슨한 수렴 · 구조 하나 · 카드: 앵커로 쓰지 않음 (L307)
- [c] kim2026_pregranulation_ptfe_dry_nca_cathode_crack_delithiation | PTFE · PVDF 물성 표 (표 S1) 가 있으나 출처 인용이 없어 카드가 입력으로 옮기지 말라고 적음 — 숫자 옮기지 않음 | §5 L284 · §7-4 L323 | [인쇄] (출처 없음) | —
- [c] kato2018_thick_electrode_assb_cycle_tortuosity | SE 의 탄성만 (다른 카드에서 옮김): LGPS E 21.7 GPa (deng2016 카드 · DFT 결정) · 75Li₂S–25P₂S₅ 유리 E 24 GPa (Sakuda 카드 · 실험) — 원문은 "thiophosphates exhibit similar elastic properties³⁶ and can be easily deformed by cold pressing" (SI p.8) 라고만 | §4-2 L220–221 | 타 카드 값 · stated (인용문) | 항복 · 경도 · 크리프 0 건 · LPSCl 아님
- [c] ketter2025 · kim2024 · kim2026_a3d · landesfeind2016 | 이 카드들에 없음 (kim2024 L64 · L203 "E_SE · σ_y · 소성 데이터 없음") | — | — | —


### [batch_18] c. 항복 · 경도 · 크리프 값과 정의 · 일축 항복 세기 환산

항복 · 경도 · 크리프 값을 준 카드 = **0**. **일축 항복 세기로의 환산은 어느 카드에도 없다.**

- [c] nakamura2020_dry_coating_ncm_li3ps4_core_shell | 값 없음 — 정성 서술뿐: 황화물 SE (Li₃PS₄ 유리) = 연하고 연성 (근거 ref 24 = Sakuda 2013) · NCM = 단단 · 취성. 원문: "a significant difference between the mechanical properties of the active material and solid electrolyte particle is a key property for successful dry coating" | §3-2 L78 · L16 · p.6 | [인쇄] (인용문) | 수치 0 · Li₃PS₄ 유리
- [c] matthews2024_ptfe_nanofibril_network | 기계 물성 (인장 강도 · 접착력 · 모듈러스) 미보고 — "flexible / fabric-like" 같은 정성 표현뿐 | §8 L466 · §4.2 L196 | n/a | LIB 건식 전극
- [c] lee2026_unveiling_ptfe_dry_electrode_digital_twin | 논문 값 없음. 카드가 비교표에 우리 쪽 입력을 적음: DEM E_eff 1.35 GPa · MPM E 1.53 · σ_y 0.30 (3D) | §7-1 L330 | 표지 없음 (우리 값) | 논문의 측정이 아님 — 환산 없음
- [c] landesfeind2018 (L57) · morasch2018 (L52) · nguyen2020 (L62) · malifarge2017 | 카드가 "n/a" 로 적음 (E_SE · Heckel 같은 소재 물성 앵커를 주지 않는 논문) | — | n/a | —


### [batch_19] c. 항복 · 경도 · 크리프 값과 정의 · 일축 항복 환산

- [c] song2025_porous_argyrodite_modulus_fracture_toughness | 경도 H **미측정** (n/a) | §3.1 L50 · L11 | stated | —
- [c] song2025_porous_argyrodite_modulus_fracture_toughness | 일축 항복 환산이 카드에 있다 — 단 빌린 값: 항복변형 2.0 % (**황화물 유리** ref 24 인용) × E 4.7 GPa → σ_Y ≈ 94 MPa; 이로부터 "균열선단 소성역" 8.2 µm = 2.5 (K_Ic/σ_Y)² (ASTM E399 꼴 · Irwin 꼴 (1/2π)(K/σ_Y)² 이면 0.52 µm) | §3.1 L49 · §10 L189 · §13 L224 | stated (식) + 이 digest 산술 | 다른 재료의 항복변형으로 만든 추정 — LPSCl 항복 측정 아님
- [c] song2025_porous_argyrodite_modulus_fracture_toughness | 벌크 E 4.7 ± 1.1 GPa (13 % 다공 · mm 시편) ↔ 나노압입 Ning 2023 E 28.0 ± 1.8 GPa · K 0.69 ± 0.12 (400 MPa + 300 °C 20 min 소결 · 10 µm) → ≈⅙ · ≈¼ | §3.1 L43 · §3.4 L81 · §1 L20 | stated · 2차 인용 (Ning) | 측정 척도 · 공정이 달라 같은 물리량 아님 (L10)
- [c] song2025_porous_argyrodite_modulus_fracture_toughness | 크리프 · 점소성: 같은 재료 나노압입 점소성 시간척도 10⁵ s (ref 23) vs 이 시험 상한 4 × 10³ s → 하중속도 1–40 µm/s 무관과 모순 아님 | §4.4 L123 · §3.1 L48 | stated | ref 23 은 인쇄 전 (2차 인용)
- [c] song2025_porous_argyrodite_modulus_fracture_toughness | 2차 인용 탄성값: Papakyriakou 2021 환산 탄성률 42.1 (−40 °C) · 29.4 (300 °C) GPa · Deng 2016 DFT 22.1 GPa · McGrogan 2017 Li₂S–P₂S₅ 유리 E 18.5 ± 0.9 · K 0.23 ± 0.04 | §3.4 L82–84 · L91 | 2차 인용 (원문 미확인 · 카드 경고) | 항복 값 아님
- [c] reisacher2023_percolation_sulfide_carbon_matrix | E_SE · σ_y · ν n/a (역학 미모델) | §3 L124 | — | —
- [c] sangros2020_dem_electrical_conductive_paths_assb | 항복 값 없음 — DEM 입력 탄성값만: E LFP 123.90 · CB 5.00 GPa · ν 0.28 / 0.23 · COR 0.40 / 0.40 | §3 L41–43 · Table 2 | stated (입력, ref 26–28) | LFP · CB (SE 아님) · 항복 캡 없음


### [batch_20] c. 항복 · 경도 · 크리프 값과 정의 · 일축 항복 환산

- [c] yoo2026_porosity_gradient_dry_electrode | primer layer (Super P : 바인더 90 : 10) 미세압입: PVDF-PL 압축계수 6.31 MPa · 탄성계수 15.99 MPa (최저) · PAA · CMC-PL 은 약 2 배 | §4.1 L140–142 · Fig 2c–e · S4 | 표지 없음 | 탄성 · 압축 계수뿐 (항복 · 경도 · 크리프 없음) · 일축 항복 환산 없음 · 비압연 PL (SAICAS-DN 원통팁 Ø600 µm · 0.1 µm/s · stop 0.45 N = 1.6 MPa) · SE 아님
- [c] wang2027_ncm811_effective_bulk_modulus_mapper_dfs_gnn | NCM 경도 2차 인용: de Vasconcelos [26] = NMC532 이차입자 E 139 GPa · H 8.9 GPa · [25] = 113 GPa · H 7.8 (정본 sedlatschek2026 카드가 전한 값) | §7-3 L316 · L28 | [추정] (2차 대 2차 · 원전 미열람) | NMC532 (NCM811 아님) · AM · 압입 경도 · 일축 항복 환산 없음
- [c] vijay2025_hybrid_cgmd_dl_slurry_microstructure · zhang2026_dryprocess_electrode_architecture_cell_level | 항복 · 경도 값 없음 (vijay = E · ν · σ_y · COR 0 건 · L421 / zhang = 인장강도 · 탄성계수 수치 n/a · L508) | L421 · L508 | — | —


### [batch_21] c. 항복 · 경도 · 크리프 값과 정의 · 일축 항복 환산

항복 · 경도 · 크리프를 잰 카드 없음. 관련 정의 · 값만:
- [c] asylbekov2023_cb_fragmentation_pbe_dem_dry_mixing | σ₅₀ = 50 % 확률로 파괴를 일으키는 비(比)파괴응력 (eq 11 · Tavares 계열) · x_p = 그 아래에서 소성변형이 지배해 더는 안 깨지는 크기 0.199 µm | §4.5 L327–333 · §3.3 L102 | stated | CB 응집체 **파괴** 강도 (항복 아님) · 적합값 σ_crit(x) = '인용 금지' 표지 (L801 · 숫자 안 옮김 · Fig 7 right) · 미보고 λ 와 축퇴 (§A-4) · eq 16 은 σ_crit 를 hard threshold 로 써 "50 % 확률" 이 실제로 구현되지 않음 (§10 L831) · 일축 항복 환산 없음
- [c] asylbekov2023_cb_fragmentation_pbe_dem_dry_mixing | NCM622 E 230 GPa = 실물 재료값 · DEM 에 넣은 E 는 논문이 밝히지 않음 (Table 1 에 E 없음 → 접촉 강성 축 재현 불가) | §3.4 L123–124 | stated | AM 탄성 · 항복 아님
- [c] frankenberg2024_dem_high_intensity_mixer_assb | 보정 E 25 MPa · ν 0.3 = heteroaggregate 분체 (다공) 의 압축 거동 모듈러스 · 재료 E 아님 (저자 명시) · 항복 캡 (p_y) 없음 | Table 3 · §3 L44 · §4.2 L77 · §10 L278 | stated | 분체 강성 · 일축 항복 환산 없음
- [c] zhou2026_gyroid_structural_electrolyte_stiffness_ionic_tradeoff | 고체 E_s 3 GPa · ν_s 0.3 = 인쇄 PLA 대표값 ("dimensional reference") · 선형 탄성뿐 | §3-1 L69 · p.5 | [인쇄] | 고분자 · 항복 · 경도 없음
- [c] cho2024_conflicting_roles_conductive_additive | E_SE · σ_y · ν = n/a (역학 미모델) | §3 L133 | — | —
- [c] bak2024_binder_distribution_multilayer · duquesnoy2023_ml_multiobjective_manufacturing_optimization | 항복 · 경도 · 크리프 값 없음 (bak = SAICAS 접착 강도 N/m · M 층 100 % 정규화뿐 · §2.4 L128–131 · §4.1) | — | — | —


### [batch_22] c. 항복 · 경도 · 크리프 값과 정의 · 일축 항복 세기와 견줄 환산

SE 의 항복 · 경도 · 크리프 값은 이 배치에 없음. 일축 항복 세기와 견줄 환산 (H/3 류) 은 이 배치 어느 카드에도 없음. 관련만:
- [c] han2025_icep_conductive_elastic_binder | 바인더 필름 나노압입 E 6.03 · H 0.42 GPa (ICEP) vs 3.73 · 0.34 GPa (PVDF) · 0.1 mN · 깊이 96.5 vs 120.0 nm (카드: 표면 / 유리질 hard-block 지배 + Oliver–Pharr 고분자 과대 경향) | §3a L39–40 · Fig 1c | stated | 바인더 (SE 아님) · 환산 없음
- [c] han2025_icep_conductive_elastic_binder | 전극 나노압입 E 1.57 · H 0.15 GPa (ICEP 전극) vs 0.11 · 0.014 GPa (PVDF 전극) · 2.0 mN | §3c L61–62 · Fig 2j | stated | 다공 고분자 복합 전극 — MPM E_eff 와 동일시 금지 (§7-⑦ L133)
- [c] han2025_icep_conductive_elastic_binder | 필름 인장 flow stress ≈2.7 MPa plateau (PVDF ≈9 MPa 피크 뒤 조기 파단) · 초기 기울기 E_tensile ~10–25 MPa | §3a L43 · Fig 1a | digitized (추세) | 카드: MPM binder σ_y 스케일 후보 (§8-②) · E 는 프로브에 따라 3 자릿수 차 (§10 L171–172)
- [c] hippauf2019_dry_film_ptfe_sulfide_cathode_sheet | SE 연성 서술 — "SE 는 냉간 압축으로 입계가 사라질 만큼 연성" (값 없음) | §4-2 L165 | [인쇄] 서술 (p.5) | 정성
- hare2026 · hong2026 · jadidi2023 · galvezaranda2025: 항복 · 경도 값 없음 (hare 는 Hertz–Mindlin 순수 탄성 · §4.2 L217–219).


### [batch_23] c. 항복 · 경도 · 크리프 값과 정의 · 일축 항복 세기와 견줄 환산

SE 의 항복 · 경도 · 크리프 값은 이 배치에 없음. 일축 항복 세기와 견줄 환산 (H/3 류) 도 없음 — 응력 척도 환산 메모 하나 (kang2026) 뿐. 관련만:
- [c] kang2026_multiscale_inverse_design_ptfe_fibrillation_dry_electrode | PTFE 구성식 모수 (SI 표 1): 초기 전단 223.7 · 거시 전단 200 MPa · 체적 2.72 GPa · locking stretch 5.6 · 흐름 저항 9.014 / 4.845 MPa · 응력 지수 1 · 80 °C → 카드 환산 E 585.6 MPa · ν 0.464 · AB 급수 초기 전단 203.9 MPa (표 223.7 과 9.7 % 차) | §3-2 L103–104 | [인쇄] · [우리 산술] | 바인더 (SE 아님) · 본문 식 (순수 초탄성) 과 표 (점탄소성 다중 가지 계열 [추정]) 가 다른 모형을 가리킴 · 원문 확인 전 우리 입력 금지 (L292)
- [c] kang2026_multiscale_inverse_design_ptfe_fibrillation_dry_electrode | 문턱 45 MPa = 데이터시트 인장 강도 (보통 공칭) ↔ 출력 P_lm = 2nd Piola–Kirchhoff — 단축 비압축이면 P = λS · σ = λ²S 라 변형률 2–3 에서 수 배 차 · 변형률 정의 · '최종' 값을 뽑는 점 미기재 | §10-6 L347 · §4-4 L221 · §3-2 L107 | [추정] · [미확인] | 이 배치에서 응력 척도 환산이 적힌 유일한 자리 (SE 항복과 무관)
- [c] kang2025_bollard_anchored_binder_dry_electrode | 필름 E PVdF_PTFE 0.83 · CMC_PTFE 0.80 · PC_PTFE 0.15 · PAA_PTFE 0.66 · PTFE 3.50 MPa · 파단 strain 10.8 / 7.4 / 21.9 / 1.2 / 5.2 % (UTM 인장 1 × 3 cm · 0.5 mm/min) | §3a L85–86 · L93 · Fig 3e,f | stated (그림에서만 읽힘) | 다공 fibril 시트의 유효값 · MPM 입력 불가 · 서열만 (L195 · L709)
- [c] jeong2025_tough_adhesive_binder_shield_ncm811 | 바인더 자립 필름 UTS PVDF fr≈18.5 · PVDFA 12.3 · N1 25.4 · N2 36.0 · N5 42.5 MPa · 파단 신율 7.8 / 2.7 / 19.2 / 22.5 / 26.7 % (ASTM D638-M type V · 10 mm/min · n ≥ 5) · PVDFA 는 소성 구간 없이 ≈3 % 에서 취성 파단 | §3b L87–97 | figure-read | 바인더 필름 (SE 아님) · 나노압입 0 (L393)
- [c] jun2026_ppma_econductive_binder_si_lowpressure_assb | 바인더 나노압입 경도 · 영률 = "PVDF·PAA와 comparable" — 수치는 SI 에만 (카드에 값 없음) | §5 L93 · Supp 22 | 표지 없음 | 값 없음
- [c] kim2026_charge_engineered_cnf_binder | 슬러리 항복응력 (진동 G′/G″ 교차) c-CNF 120 vs PVDF 0.2 Pa · 필름 toughness 16.3 MJ/m³ | §4.2 L194 · §4.1 L185 | 표지 없음 | 슬러리 유변 (입자 항복과 다른 양)
- [c] kawaguchi2017_dry_coating_parametric_na2so4_model_se | 게스트 Na₂SO₄ 의 강성 · 탄소성이 황화물과 비슷하다는 근거 = 압입 시험 (ref 18) · 수치는 이 논문에 없음 | §3-1 L62 · §10-1 L219 | [미확인] | 값 없음
- kawaguchi2023: 항복 · 경도 값 없음.


### [batch_24] c. 항복 · 경도 · 크리프 값과 정의 · 일축 항복 세기와 견줄 환산

SE 의 항복 · 경도 · 크리프 값은 이 배치에 없음. 일축 항복 세기와 견줄 환산도 없음. 관련만:
- [c] koo2025_cnt_wrapped_sc_nca_dry_cathode | AM 입자강도 = nano-press 로 입자를 10 % 변형시키는 압력, H = 2.8P/(π·d_p²) — 단결정 SC-NCA 111.63 vs 다결정 PC-NCA 48.96 MPa (≈2.3×) | §5(a) L245–246 · §8 L357 · SI Fig S23 | 카드가 '본문/표 명시값 (정밀)' 으로 분류 (L457) | NCA (AM · SE 아님) · 식은 하중 → 입자강도 환산 (일축 항복 환산 아님) · 액체 LIB
- [c] koo2026_swcnt_sheath_thick_electrode | VMS 디지털 트윈 입력 NCMA 영률 105 GPa · ν 0.27 (NCM811 값 대용) · 3.4 vol% 팽창 (부분몰 팽창계수 2.912e-7 m³/mol) · 모든 상 선형탄성 | §5 L281–282 · §11.10 L935–937 · L948 · SI Note S5 · Fig S28 | 표지 없음 (Table S7 'NCM811 대용') | 탄성값만 (항복 없음) · 다른 재료 값을 빌림
- [c] lee2025_corolling_dryprocess_lpscl_ptfe | PTFE storage modulus 30 → 120 °C 에서 67 % 감소 (≈150 → 50 MPa · DMA 1 Hz) · 인장강도 SSE 막 0.049 · 전극 0.441 · co-rolled 0.510 N/cm (n=5) | §3 L42–43 · Supp Fig 10 · Fig 3b | stated | 바인더 · 막 값 (입자 항복 아님)
- [c] lee2025_dual_fibrous_ptfe_dry_electrode | 건식 자립막 인장강도 SDE 0.47 · DDE 1.39 N/mm² · "yield strain" (= 최대하중 변형률) 0.35 / 0.70 % · 시컨트 탄성률 ≈0.13 / 0.20 GPa (카드 계산) | §4 L157–159 · Fig 4c | stated (강도 · 변형률) · derived TREND (시컨트) | 면내 인장 — 카드: 우리 압축 접촉강성 · AFM 압입과 같은 양 아님 (L389 · L519–520) · '항복' 이름이 최대하중점을 가리킴
- [c] lee2024_shear_force_dry_process_cathode_coverage | LPSCl = "ductile sulfide solid electrolyte" (전단 · 가압에서 변형해 활물질을 덮는다) — 값 없음 | §3-2 L96 · §4-2 L232 · p.2 | [인쇄] (문장) | 정성
- [c] lee2026_li_underlayer_primer_free_dry_prelithiated_thick_anode | Li 금속 = "항복 강도가 아주 낮은 금속" (값 없음) | §4-3 L189 · §7-2 L267 | [추정] (카드 풀이) | 논문 문장 아님


### [batch_25] c. 항복 · 경도 · 크리프 값과 정의 · 일축 항복 세기와 견줄 환산

SE 의 항복 · 경도 · 크리프 값은 이 배치에 없음. 일축 항복 세기와 견줄 환산도 없음. 관련만 (탄성률 · 운용 강성):
- [c] mun2025_dry_electrode_technology_assb_review | Young's modulus 표: Li₂S-P₂S₅ glass 18–25 · Li₂O-P₂O₅ glass 50 · SiO₂ glass 75 · Li₂O-SiO₂ glass 70–80 · LLZO (소결) 92 · polymer 1–6 GPa — 카드 풀이: 황화물 저모듈러스 = 상온 calendering 가능의 근거 | §3b L52 · Fig 3e · 원전 ref [40] | 리뷰 인용 stated | 탄성률 (항복 아님) · glass ≠ LPSCl 아지로다이트 (카드 L251) · 화학식 확인 필요 (카드 문제)
- [c] mun2025_dry_electrode_technology_assb_review | PTFE 상전이 19 °C (triclinic → hexagonal) · 30 °C — >19 °C 에서 storage modulus 급감 → 상온 전단으로 섬유화 (PVDF · CMC 는 이 상전이 없음) | §3b L53 · §4 L86 | 리뷰 인용 (ref [42–46]) | 바인더 (SE 아님)
- [c] liu2025_dry_processing_high_energy_li_batteries_review | 리뷰 경계: E < ~25 GPa 황화물 SE = cold press 만으로 입자간 intimate contact · E > 50 GPa 산화물 = hot press (900–1100 °C) 필요 | §3 (라) L85 · §A ② L157–158 | 표지 없음 (카드 표기 "(Eq context)" · 원전 ref 카드에 없음) | 탄성률 경계 (항복 아님)
- [c] lippke2023_dem_drying_structure_formation_lib | E (NCM622) 142 GPa (ref [22] Sangrós 2018) · ρ 4.74 g/cm³ · Hertz–Mindlin 항복 캡 없음 · ν · COR · 감쇠 · rolling friction 미제시 | §3-B L114–117 · §4.2 L205 · L211 | stated | AM (SE 아님) · 카드: 같은 원천 (Sangrós 나노압입) 한 측정의 반복 인용일 수 있음 (L645–647)
- [c] lischka2025_dem_eirich_intensive_mixer_dry_mixing | 입자 전단탄성률 G = 1e8 Pa — "constant shear modulus of 1e8 Pa … to minimize the computational cost associated with higher shear moduli" (계산비용 · 물성 아님) · ν 0.25 · COR 0.5 (측정 불가라 가정) · 벽 G 1e11 Pa | §3.1 L56 · §4.2 L151–152 | stated | 운용 강성 · NMC + CB 합친 CG 입자
- [c] meng2026_phase_inversion_binder_ultrathick_zn_iodine | 후막 전극 (활성탄 + PES–PVP) 인장 최대 fr≈0.096 MPa @≈11.3 % · 파단 ≈12.8 % · 할선 E (0–4 %) ≈1.3 MPa | §3a L74 · §5.5 L266 · Fig S9 | figure-read · 우리 산수 (카드 작성자) | 다공 고분자–탄소 전극 (SE 아님) · 시편 형상 · 속도 · 젖음 미기술


### [batch_26] c. 항복 · 경도 · 크리프 값과 정의 (일축 항복 환산 여부)

- [c] nam2026_primer_layer_dry_electrode_collector | 나노압입 경도 H ≈11.7 (S100) → ≈23 MPa (C100) · 압입 영률 E ≈146 (S100) · ≈51–77 MPa (나머지 넷) · 카드 해석 소성지수 ψ ∝ E/H (S100 12.5 vs C100 2.2) | §4.3 줄 228–256 (Fig 3e–g) | digitized ±10 % · E/H = 카드 계산 | primer 층 · 일축 항복 세기 환산 카드에 없음 · 논문의 "E 단조 증가" 는 데이터와 어긋난다고 카드가 적음 (줄 241–244)
- [c] park2026_thiolene_sbr_binder_assb | 바인더 영률 (인장) SBR 0.78 · X6 6.36 · X10 14.31 · X14 23.53 MPa · 인장 파단 strain SBR > 200 % · X-SBR < 50 % · 가교밀도 15.7 / 19.5 / 25.6 ×10⁻⁵ mol/cm³ (Flory-Rehner) | §2.2 줄 121–132 (Table S1 · Fig 3b·c) | 표지 없음 | 바인더상 (SE 와 3–4 자릿수 차 · 카드 줄 497) · 항복 · 경도 값 없음 · 환산 없음
- [c] sankar2026_fiber_scale_dem_carbon_felt_manufacturing | 산화 PAN 인장강도 ≈130–230 MPa · 영률 ≈4–6 GPa (refs 40–41 인용 · 원문 미확인) — 모델 입력값 아님 (입력 E 등 [미확인] · 카드 C6) | §3.1 줄 109–110 · C6 줄 546 (p.4) | stated (인용) | 섬유 재료 · SE 아님 · 환산 없음
- qin2026 · pfeffer2001: 항복 · 경도 값 없음 (Qin 접촉 = 항복 없는 LJ + JKR · 줄 278).


### [batch_27] c. 항복 · 경도 · 크리프 값과 정의 · 일축 항복 환산

- [c] wet_processing_resolved_am_ssb_cathode_manufacturing | 논문에 항복 · 경도 · 소성 없음 ('plastic/plasticity' 0 회 · 카드 grep).  카드 산출: Hertz 평균 접촉압 p̄ = (4/3π)·E*·√(δ/R) 와 항복 개시 p̄ ≈ 1.1 σ_y (= 접촉압 ↔ 일축 항복 환산) → E* 135 GPa · R_eff 0.2425 µm 에서 δ = 10 nm 일 때 p̄ ≈ 11.6 GPa · 항복 개시 δ ≈ 2 pm | §①-D 줄 392 · 394–396 | 우리 산출 (σ_y 0.15 GPa = 우리 MPM 값 · 논문 값 아님) | E* 는 SI 단위 오식 가정 위의 카드 환산 · '문헌대 0.05–0.30' 표기는 카드 문제 참조
- [c] wang2026_dryprocess_thick_cathode_failure_ncm94 | AFM 힘-거리 국소 영률 3.056 · 2.248 · 1.263 GPa (3 점 · 2.4× 산포) — 탄성률이지 항복 · 경도 아님 · σ_y · K_IC · G_c 미측정 | §3.3 줄 156–166 · §12 줄 580 | stated (소프트웨어 출력) | 복합막 (NCM + SE + PTFE + 공극) 국소 값 · 접촉 모델 · 팁 · ν 미공개 · Cl-rich SE
- [c] bucci2017_chemomech_failure_assb_cycling_czm | 항복 없음 (AM · SE 선형 탄성 · σ_y n/a).  파괴: McGrogan 나노압입 K_IC 0.23 ± 0.04 MPa·m^0.5 · E 18.5 ± 0.9 GPa → G_c = K_IC²/E ≈ 2.8 ± 1.8 J/m²; Table 1 페로브스카이트 K_IC 0.890–1.34 MPa·m^0.5 | §3.5 줄 148 · §5.3 줄 260–261 · §3.2 줄 96–102 | stated (본문 환산 · 문헌 survey) | 유리 Li₂S–P₂S₅ (결정 argyrodite 아님 — 카드 줄 455) · 일축 항복 환산 없음
- [c] wolf2026_extruder_vs_batch_mixing_core_shell_dry_sulfide_cathode | 항복 · 경도 측정 없음; 막 인장 (응집 파괴) 29.4 [24.1–34.7] vs 9.3 [8.8–9.9] N/cm² (압출 · 배치 · 3 시료); 저자: 고온은 LPSCl 을 더 연성으로 [17] (정성) | §3-5 줄 124–125 · §4-2 줄 171 | [인쇄] · [판독] | 막 인장 ≠ 재료 항복 · PTFE · C65 포함


### [batch_28] c. 항복 · 경도 · 크리프 값과 정의 (일축 항복 환산 여부)

- [c] bucci2018_mechanical_instability_interface_delamination | 항복 정의: 구대칭에서 von Mises ≡ Tresca → σ_θθ − σ_RR = σ_yield · 개시 변형 (αc)_plastic = −(f³−1)νσ_yield/[3f³λ(2ν−1)] (Eq 13) · 기준 σ_yield < 0.5·F_c (Eq 14 · F_c = 2–20 GPa @ ‖u‖_R 1 nm) — σ_yield 값 자체는 없음 (σ_yield/F_c 비 스윕) | §4.4 줄 163–174 · §3.2 줄 48–49 (Fig 7) | stated | 소재 무관 · 1D 구대칭 · 일축 시험 값으로 환산하는 별도 식 없음 (같은 σ_yield 를 씀)
- [c] kang2025_toughened_bimodal_nca_lzo | 항복 · 경도 없음; FEM 탄성 입력 E_NCA 175 · E_LPSCl 22.1 GPa · cohesive 계면 강도 100 MPa · G_c 1 J/m² · 손상 개시 = 2 차 nominal stress 기준 (압축은 Macaulay 로 제외) | §3 줄 60–61 · Table S4 줄 130–131 · §4 줄 168–169 | stated (SI verbatim) | 2D FEM 입력값 (측정 아님) · NCA
- [c] kim2023_chemomech_failure_highstrain_anode | 항복 · 경도 없음; FEM 입력 E NCA 175 / LPSCl 22.1 GPa (ref [39]) · σ_Mises 값 미명시 ("입계에서 더 빠르게 증가 → 소성/균열") | §3 줄 77 · 91 | stated · 정성 | 카드 안 E 표기 충돌 (카드 문제)
- [c] intergranular_cracking_nmc811_jmca2023 | 항복 없음 (1 차입자 = 등방 선형탄성); FEM 입력 E_p 150 GPa · CBD E_c 0.3 GPa · ν 0.3 · 입계 / 입내 파괴 인성은 보조장 γ 로 나눔 (값 카드에 없음); 카드가 다른 논문 값으로 Jung2023 다결정 경도 113 MPa 인용 | §3 줄 90–91 · §4-B 줄 139 · 153–155 · §A-4 줄 320 | stated · (113 MPa = 다른 카드 값) | NMC811 · 액체계
- [c] dem_mechanical_stresses_ssb_electrode_cycling | σ_y · 소성 · 균열 = n/a (강체 구 + Hertz) · GFF 물성 (E · ν · 마찰 · COR) 은 refs [30,31] · SI 에만 (카드에 값 없음) | §3.6 줄 127 · §4.0 줄 139 · §6 줄 234 | 카드 서술 | —
- [c] interfacial_impedance_formulation_assb_cathode | 항복 값 없음 — 저자 정성 "낮은 모듈러스 SE (LPSC)" 만 | §4.5 줄 186 | 저자 명시 (카드 옮김) | 값 없음
- [c] gandla2026_layered_cathode_degradation_diagnostics_review | 항복 값 없음 — AFM DMT 탄성률 (1.0 GPa · 100 MPa 등) 은 고분자 전해질 셀 CEI 값 | §3-6 줄 136 (그림 6f–g) | [인쇄] | 다른 계 · 역학 항복 아님


### [batch_29] c. 항복 · 경도 · 크리프 값과 정의 · 일축 항복 세기와 견줄 환산

- [c] so2021_dem_fabrication_degradation_ductile_particles | LPS 유리 압입 경도 σ_H = 1.9 GPa (McGrogan [31] · 비슷한 Li₂S 함량) 를 **항복으로 그대로** 씀: 접촉 최대응력 σ_max = 3/2·F/A_con (eq 7 · 포물선 분포) · 항복 임계 F_th = 2/3·σ_H·A_con (eq 8) → 접촉 최대응력이 σ_H 에 닿으면 소성 · 카드 원문 요약 "σ_yield ≈ σ_H 근사; 문헌 항복강도 부족" — **H/3 같은 일축 환산은 없다** | Table I L57 · §4.2 L136–139 · §5.4 L194 | stated | 가공경화 무시 (실험 자료 부족 L144) · 일정 하중에서 접촉면적↑ → 응력이 H 아래로 내려갈 때까지 시간 경과 감소 ("creep-like", 완화시간 t_rel 임의 L135 · L144) · 재료 LPS 유리
- [c] so2021_dem_fabrication_degradation_ductile_particles | Li₂S 파괴강도 σ_c = 2γ/δ = 5.6 GPa (γ 2.8 J/m² · δ ≈1 nm) → σ_H/σ_c = 1.9/5.6 = 0.34 → "초기 파손은 소성이 지배 (취성 아님)" = ductile particle 모델의 근거 | Table I L69–72 · eq 10 · §4.5 L158 | stated | 문헌 값 [2, 24, 31] · 분리 (융착 끊김) 조건은 σ_H 기준
- [c] li2026_electrochemomechanical_coupling_asslmb_review | 리뷰 표 3 의 경도 H: LPSCl 0.9 GPa (이 행 전체가 song2025 13 % 다공 펠릿값 [우리 대조]) · 75Li₂S–25P₂S₅ 1.9 GPa (E 18 GPa) · Li₁₀GeP₂S₁₂ 0.5 · Li₃YCl₆ 1.7 · K_Ic LPSCl 0.17 · 75Li₂S–25P₂S₅ 0.23 MPa m^½ | §3-2 L54–61 · 리뷰 p.8 | [인쇄] | 2 차 인용 · 표 3 인용 번호 +7 어긋남 (L60) · H 의 정의 (압입 방식 · 하중) 카드에 없음 · 일축 환산 없음 · LPSCl E 는 카드 L139 인용하지 않음 표지
- [c] sedlatschek2026_nmc811_grain_boundary_strength_micro_tensile | NMC811 (AM): 자체 H 없음 (L29 · L87) · 인용 H 7.8 / 8.9 / 8.6 GPa (NMC532 다결정 2 차입자 [27]–[29]) · 14.2 GPa (NMC811 펠릿 [23]) · 입계 강도 Weibull σ_ch 745 MPa (m 6.91 · n 3) · 파괴변형률 ≈0.4 % · 입자 단위 파쇄강도 인용 172.8–210.6 · 207 (NMC811) · 188 MPa (NMC111) · 환산: 논문이 Stallard 2022 [30] 를 들어 "H/3 로 인장강도 추정 불가" 논거를 전함 | §3.1 L75–77 · §3.4 L136–144 · L141 | stated · 2 차 인용 | **SE 아님** · 취성 (인장은 소성 선행 없음 L75) · K_IC 는 재지 않음 (Sharma 2023 [23] 차용 · 카드 L304: 이 카드를 K_IC 출처로 인용하지 말 것)
- [c] lee2026_microcrack_tolerant_bilayer_cathode_chemomech_fastcharging | NCM92 전극 나노압입 (5 mN): H_IT 0.086 (LPC) · 0.18 GPa (SSC) · E_IT 5.17 · 6.02 GPa | §3 L34 · Fig S9 | stated (그림 값) | 전극 / 다공 2 차입자 유효값 (카드: 모델 E 191 GPa 와 다른 양 L103) · 액체 LIB · 일축 환산 없음
- 나머지 넷 (kim2025 L117 "E_SE / σ_y / ν n/a" · siroma2015 · spencerjolly2023 · tron2023): 없음. tabakovic2026 는 영률 (NMC 199 · 흑연 15 GPa) 만 · 항복 없음.


### [batch_30] c — 항복 · 경도 · 크리프 값과 정의 · 일축 항복 환산

- [c] wheatcroft2023_nmc811_secondary_particle_fracture_insitu_sem | 파괴 순간 경도 H_f = P_f / A(h), A(h) = π(2h(0.71 + 0.505 h^1.01) − h²) (µm; h = "stiffness corrected tip displacement", TEM 팁 사진으로 면적함수 보정) — NMC811 pristine 3.6 ± 0.9 · 3 사이클 뒤 3.0 V 3.3 ± 1.5 · 4.3 V 0.5 ± 0.3 GPa · 같은 군 안에서 D 와 무관 | §3.4 (줄 121–129) · §4.5 · SI p.4–5 · Fig S4 | SI-stated | AM 값 (SE 아님) · Oliver–Pharr 압입 경도 아님 · h 에 입자 전체 변형 포함 → 하한 쪽 (카드 판단) · 일축 항복 환산 없음
- [c] wheatcroft2023_nmc811_secondary_particle_fracture_insitu_sem | 강도 (항복 아님) σ_F = P_f/D² (Hiramatsu–Oka, 계수 1) — pristine 평판 207 ± 49 · 원뿔 67 ± 21 MPa; 명목 → FE 최대 인장 환산 계수 = 중심 0.79 · 평판 최대 1.38 · 원뿔 최대 4.77 (탄성 FE · D 10 µm) | p.4–6 · §3.1 · §3.5 (줄 150) · Fig. 3c | stated / digitized (TREND) | 파괴 강도 · 일축 항복과의 환산 없음 · 같은 그룹 리뷰 [20] 규약 2.8/π (0.891) 과 12 % 차 (D24 derived) · 환산한 응력값은 카드가 "인용값 아님" 으로 둠
- [c] wheatcroft2023_nmc811_secondary_particle_fracture_insitu_sem | 2차 인용: [Sedl26] 이 인용한 NMC 압입 경도 7.8–14.2 GPa · stallard2022 카드의 stage-III NMC532 2차입자 압입 H 3.2–5.5 GPa | §7.7 (줄 397 · 399) | 2차 인용 (원문 미확인) | AM · 다른 카드 소관
- [c] yun2023_deciphering_degradation_halide_vs_sulfide | LPSCl 항복 강도 = 본문 "200 GPa" — 카드: 영률 32.8 GPa 보다 클 수 없으니 200 MPa 오타로 강하게 의심 · FEM 에서 LPSCl = elastic-plastic (ref 54 Papakyriakou) · LIC = elastic-only · σ_y 정량 · 경화는 n/a | §3.4 (줄 171) · §3.5 (줄 181) · §4.1 (줄 202–203) · §12 (줄 594–596) | stated_text ⚠ · 카드 판단 | 항복 정의 · 경화 법칙 · 일축 환산 카드에 없음 · 카드는 σ_y 앵커에 넣지 말라고 적음
- [c] kim2024_digital_twin_acsenergyletters · lee2023_sicspe_digitaltwin_assb · park2020_digitaltwin_assb_foundational | 항복 · 경도 · 크리프 값 없음 | — | — | —


### [batch_31] c — 항복 · 경도 · 크리프 값과 정의 · 일축 항복 환산

- [c] 이 배치에 없음 — SE · 황화물의 항복 · 경도 · 크리프 값과 일축 항복 환산을 가진 카드는 없다.
- [c] choi2026_elastomeric_li_metal_anode | (참고 · SE 아님) Ni-PDMS 막 나노압입 (Oliver-Pharr) reduced modulus 22 / 24 / 39 / 42 MPa → Es 29.3 / 31.4 / 52.5 / 55.7 MPa (@ Ni 도금 30 / 60 / 120 / 180 s) — Es = Er/(1−ν²) 근사 · ν 0.50 가정 · 압입자 (diamond) 컴플라이언스 무시 · 탄성률이지 항복 · 경도 아님 | §2.2 (줄 123–126) · Fig 2c · Fig S12 | 표지 없음 | 탄성 고분자 막


### [batch_32] c — 항복 · 경도 · 크리프 값과 정의 · 일축 항복 환산

- [c] hong2026_cbd_viscoelasticity_springback | CBD 필름 (Super P : PVDF = 1:1) 나노압입 (구형 다이아 SD-C13 · 최대하중 5 mN · 유지 2 s · 20 Hz): h_max RT ~1193 → HT ~1948 nm (약 +63 %) · 소산 에너지비 0.62 → 0.67; DMA (인장 1 Hz · strain 0.01–1 %) E′ HT 가 RT 보다 −41.2 % · tan δ 는 온도 ↑ 로 ↑ (Fig S7 · 추세만) | §2.4 (줄 121–125) · §4.3 (줄 212–222) · Fig 4a–d | 표지 없음 | 항복 · 경도 값 아님 · 일축 항복 환산 없음 · CBD (LPSCl 아님)
- [c] endo2001_vgcf_basic_properties_battery_applications | 흑연화 s-VGCF 인장강도 ≈ 0.53–2.1 GPa (21 점 · 직경 0.11–0.84 µm · 가늘수록 강함 · Fig. 5) · 인장탄성률 개략 영역 ≈ 110–310 GPa (탄화 + 흑연화 한 상자 · 측정법 미기재 · Fig. 6) | §3-4 (줄 166–192) | figure-read ≈ | 섬유 인장 (압축 항복 아님) · 환산 없음 · Fig. 5 ↔ Fig. 6 강도 범위 어긋남 (§8-2 #6)
- [c] 나머지 여덟 카드 — 항복 · 경도 · 크리프 값 없음.


### [batch_33] c — 항복 · 경도 · 크리프 · 일축 항복 환산

- [c] lawrence2008 | 항복 · 경도 · 크리프 값 없음 · 탄성률만 (굽힘 겉보기 6–207 GPa).  고하중 시험: 두꺼운 외벽 840 nN 에서 접촉점 균열 · 얇은 외벽 190 nN 에서 파단 — 응력으로 바꿀 형상 치수 없음 (n/a) · 일축 항복 환산 없음 | §3-4 · Fig. 5 · p.1233 | stated | VGCF 단섬유 · SE · AM 아님

그 밖 8 장: 해당 값 없음.


### [batch_34] c — 항복 · 경도 · 크리프 값과 정의

- [c] nase2001_granular_bond_collision_number_wet_cohesion | 접촉 단위 항복 힘 F_y (Thornton 탄–완전소성) — "본질적으로 맞춤 매개변수" · 항복 뒤 선형 F_n = F_y + k_y(α − α_y), k_y = (2/3)(F_y/α_y) · F_y 값 [미확인] · 경도 · 크리프 · 일축 항복 세기와의 환산은 카드에 없음 | §3-1 L58 · 식 5 · p.215 · §10-9 L192 | [인쇄] · [미확인] | 접촉 힘이지 재료 응력 아님 · k_y 계수 확인 필요 (카드 문제) · 환산은 배치 밖 thorntonning1998 카드 L250–251 에 p_y ≈ 1.6σ_y · H ≈ 3σ_y 서술이 있음
- 나머지 6 장: 이 배치에 없음.


### [batch_35] c — 항복 · 경도 · 크리프 값과 정의 · 일축 환산

- [c] song2025 | NMC711: E_AM 2.611 GPa · σ_y,AM 0.1534 GPa · 등방 접선 1.3055 GPa · ν 0.25 — 단일입자를 수십 µm 평면 압자로 압축 (카드는 nanoindentation 이라 부름) | Table 2 (줄 148–151) · §2.1 (줄 110–111) | 표지 없음 (표 값) · 카드 해석: 2.611 은 균열 · 기공 포함 유효값 (줄 153–156) | oxide AM · 압입 → 일축 환산 방법 카드에 없음 · 식 22 는 AM 비탄성 변형을 뺌 (σ_y,AM 이 쓰이는지 카드에 없음 → 카드 문제 18)
- [c] song2025 | CBM (PVDF + Super P 통합상): E 1.05 GPa · σ_y 19.36 MPa · 접선 284.90 MPa · ν 0.326 · Perzyna b 1 · A 0 → 3×10⁻³ s⁻¹ · Ludwick n 2 · k ≈1100 → 1200 MPa (변형률 속도 함수) · PVDF 파괴 강도 45 MPa (0.00003 s⁻¹).  항복 함수 = von Mises (f = σ̄ − σ_y · σ̄ = √(3/2 s:s), 식 26–27) — 인장 시험값을 일축 등가 σ_y 로 그대로 씀 | Table 3 (줄 158–173) · §3.2(3) (줄 236–244) · §4.5 (줄 332–344) · Fig 6A | 표지 없음 · Fig 6A 곡선 판독 | 건조 필름 (전해질 swelling 미반영 · 논문 명시) · 바인더이지 SE 아님
- [c] shenouda2020_dem_metal_powder_am_liggghts_tutorial | 항복 · 경화 없음 (Hertz 무한탄성) · 예제 E 강철 200 GPa · 분말 5e7 barye (≈5 GPa) · ν 0.3 | §3 (줄 44) · §4 (줄 67–70) | stated | 소재 무관 예시값
- 나머지 (oh2026 · otani2023 · pan2026 · park2019 · park2026): 값 없음.  oh2026 SAICAS 응집 · 접착 강도 (N/m · Fig 5f,g) 는 항복이 아님.


### [batch_36] c — 항복 · 경도 · 크리프 값과 정의 · 일축 환산

이 배치에 없음.  (zhang2023 줄 397 의 G_c · K_IC 는 카드가 우리 쪽 파괴 모델 입력으로 적은 것 — 이 논문 값이 아니고 항복 · 경도도 아니다.)


### [batch_37] c — 항복 · 경도 · 크리프 값과 정의 · 일축 환산

황화물 SE 의 항복 · 크리프 값 = 0.  경도는 cao2026 에 있으나 카드가 물성으로 쓰는 것을 금지했다.  **일축 항복 세기로의 환산은 어느 카드에도 없다.**

- [c] cao2026 | 나노압입 (Hysitron TI 980 · Oliver–Pharr · 최대 하중 figure-read ≈1.5 mN) 을 LPSCl 냉간 펠릿 · LPSCl-PTFE 전구막 · USF 세 시료에 함.  감소 탄성률 Er · 경도 H 값은 카드 §3e 표 (줄 125–127) 에 있으나 카드 §14 ⛔ ("나노압입 Er·H 를 LPSCl 탄성으로 · 우리 E_VRH 와 같은 줄에" 인용 금지 · 줄 506) → 숫자 옮기지 않음.  옮길 수 있는 것: 소산 효율 43.5 % (펠릿) · 44.3 % (전구막) · 47.7 % (USF) · 최대 깊이 figure-read ≈2.4 / ≈2.9 / ≈4.7 µm ≈ 입자 크기 (1–3 µm) → 카드: "단결정 탄성이 아니라 다공 성형체·막의 국소 응답" · DFT 탄성과의 40–600 배 차는 기공 · 접촉 때문 | §3e 줄 121–130 · §7 줄 381 · Fig. 1g–i · 본문 p.4 | 본문 값 (± 는 전구막 · USF 만) · figure-read (펠릿 값 · 깊이 · 하중) | 냉간 펠릿의 성형압 · 기공이 카드에 없음 · 소산 효율의 정의식 · 오차막대 없음 · 일축 환산 없음
- [c] famprikis2019 | (리뷰 소환값) Li₂S–P₂S₅ thiophosphate 유리 E ≈ 20 GPa · G ≈ 7 GPa (ref 108 = McGrogan 2017 · 카드: 나노인덴테이션 실측 · *"Compliant yet brittle"*) / 단결정 garnet E ≈ 150 · G ≈ 60 GPa (ref 147) / LiBH₄ G ≈ 4 GPa (ref 148) / Li 금속 항복강도 ~0.8 MPa (ref 144 = Masias 2019 — 탄성 · 소성 · 크리프) → 금속 음극은 MPa 급 압축에서 항상 소성 영역.  SE 의 항복 · 경도 · 크리프 값 0 건 · K_Ic · γ 값 0 건 | §4.3 줄 109–120 · §5.5 Box 1 줄 275–277 · §7.1 줄 409–425 | 소환값 (2차 인용 · "≈") | 유리 (결정 아지로다이트 아님) · 시편 밀도 · 오차 · 측정 조건이 리뷰에 없음 (§14-1 줄 573) · 다른 카드는 같은 원전을 E 18.5 ± 0.9 GPa 로 옮김 (카드 문제 5)
- [c] calpa2019 | 값 아님 — 저자 문장: *"Young's moduli of about 20 GPa (ref 6) … room temperature pressure sintering, and therefore the resistance of pelletized sulfide solid electrolytes is not largely influenced by the particle size"* | §3b 줄 74 · p.475 | stated | 황화물 일반 (ref 6 서지는 카드에 없음) · 항복 · 경도 아님
- cronk2026 (둘째 카드): 새 값 없음 (FEM 입력 E 22 GPa 는 배치 15).  alharbi2026: 무관.


### [batch_38] c — 항복 · 경도 · 크리프 값과 정의 · 일축 환산

황화물 SE 의 값 = 0.  같은 시료에서 압입과 인장을 함께 잰 것은 고분자 막 (yuan2026) 하나.

- [c] yuan2026 | PEO-LiTFSI ± 2D SiO₂ 18 wt% 막 (고분자 전해질 · LPSCl 아님 · 25 ± 2 °C): 압입 경도 H (4×4 지도 평균 · TI950 Berkovich · Oliver–Pharr · 하중 10 mN · 접촉 깊이 ≤2 µm) 0.07 (무첨가) · 0.17 GPa (층상) / 인장 항복강도 4.1 · 20.5 MPa (2 mm × 10 mm · 게이지 3 mm · 1 mm/min · figure-read 최고점은 ≈5.6 / ≈22 MPa — 정의 차로 보인다) / 탄성률은 같은 막이 압입 3.7 GPa ↔ 인장 190 MPa 로 15–19 배 갈림 (카드의 허용 서술 · 줄 422).  압입 → 일축 환산식은 카드에 없음 (저자 설명: 유리질 고분자 + 미세구조 이방성).  FEM 입력 Li 압자 E 5 GPa · ν 0.42 (Table S1) | §3b 줄 83–93 · §4b 줄 192 · 본문 p.5 · Fig. 3 · Fig. S26 | 본문 값 (표지 없음) · figure-read · 일부 (원자료 재계산) | 고분자 · Oliver–Pharr 는 점탄성 재료에서 크리프로 과대평가되기 쉬움 (카드 용어집 줄 393) · 카드 §13-7: 이 값들을 우리 E_VRH 와 같은 양으로 쓰지 않음 (줄 415)
- kim2012: 항복 · 경도 없음 (표면 에너지 DFT).  liu2024 · tron2023: 없음.


### [batch_39] c. 항복 · 경도 · 크리프 값과 정의 · 일축 항복 환산

이 배치에 없음 (기계 물성 값 없음). 관련만:
- [c] choi2026_bzox_dry_zro2x_nmc_shell_coating | 코팅 뒤 NMC 입자 SEM: ~5 µm 단결정 · 표면 매끈 · "기계 손상 · 균열 없음" (mechanofusion 2000 rpm 10 min → 4000 rpm 30 min 뒤) | §5 SI 표 L120 (Fig S2) · §3.1 L33 | 표지 없음 (SEM 정성) | 힘 · 응력 값 없음 · 단결정 NMC811 (SE 아님)


### [batch_40] c — 항복 · 경도 · 크리프 값과 정의 · 일축 환산

- [c] gritton2017_mpm_chemomechanical_coupling_silicon_anode | 비정질 규소: 항복 응력 σ_Y 1.4 GPa (von Mises 항복면 √(3/2 σ_dev:σ_dev) − σ_Y = 0 · 완전 소성 또는 선형 등방 경화 · 소성 계수 1.15 GPa) · K 67 · G 31 GPa → E 80.6 GPa · ν 0.300 · E/σ_Y ≈ 58; 기판 σ_Y 0.7 GPa · K 180.4 · G 76 GPa → E 199.9 GPa · ν 0.315 | 카드 §3-1 · §4-5 · 논문 식 (34)(35) p.10 · p.11 · 13–19 | σ_Y · K · G · 소성 계수 = 인쇄 (출처 미인쇄 — *"reasonable values"*) · E · ν · E/σ_Y = [카드 산술] | **규소 · 이름 없는 기판 — LPSCl · NCM 값으로 쓰지 않는다** · von Mises 꼴이라 σ_Y 는 일축 항복 세기와 같은 정의이나 카드에 환산 서술은 따로 없음 · 경도 · 크리프 없음 · 탄성 계수는 농도와 무관하게 고정


### [batch_41] c — 항복 · 경도 · 크리프 값과 정의 · 일축 환산

이 배치에 없음 (탄성만 · 항복 없음).  관련만:
- [c] bardenhagen2005_mpm_foam_densification_simulation | 뼈대 재료 = 압축성 neo-Hookean 탄성 · K 10.2 GPa · G 7.2 GPa · ρ 1900 kg/m³ → E 17.49 GPa · ν 0.214 · 종파속 3,228 m/s; Gibson–Ashby 의 '항복' 응력은 소성 항복이 아니라 발포체가 고원으로 넘어가는 (탄성 붕괴) 응력 — 그림의 선 5.53 · 8.13 MPa | 카드 §3-1 · §3-5 · 논문 p.602 · p.607–608 · Fig. 6 | K · G · ρ = 인쇄 (출처 미인쇄) · E · ν · 파속 = [카드 산술] · 선의 값 = [판독] | 발포체 뼈대 값 — LPSCl · NCM 값으로 쓰지 않는다 · 경도 · 크리프 없음


### [batch_42] c — 항복 · 경도 · 크리프 값과 정의 · 일축 환산

- [c] pycompact2025_dem_mpfem_workflow | **고친 산술 · 표기**: Swift σ = K(ε + ε0)^n (식 3) 의 σ(ε=0) = 1380 × 0.0354^0.254 = **590.7 MPa** (옛 590.6) · σ(ε=1.0) 1392 MPa 는 '포화유동응력' 이 아니라 ε = 1.0 의 유동응력 (Swift 는 포화 없음) · 재료 모형 = *PIECEWISE_LINEAR_PLASTICITY* — 원문은 'J2 · von Mises 항복' 이라 쓰지 않는다 (옛 'J2형' 은 카드 해석) | 카드 §3.1 · §7.3 · 논문 식 3 p.5 · p.3 | 인쇄 · [카드 산술] | 금속 값 — 전이 0


### [layer3] c. 항복 · 경도 · 크리프 값과 정의 · 일축 항복 환산

- [c] miss2026_insitu_conductivity_porosity_pressure_compaction | 비교 문서가 적합한 Heckel P_y ≈ 220–245 MPa (µc-Li₅.₅PS₄.₅Cl₁.₅ · 가압 중 · R² 0.98) ↔ 우리 DEM 순수 SE 138 MPa | §A L111 | "우리 적합" | 조성 · 프로토콜 · 규약 다름 · 일축 항복 환산 이 줄에 없음
- [c] ngandjong2021_dem_calendering_digital_twin | 그들 점을 Heckel 로 옮긴 P_y 는 "인용 금지" (창에 따라 3.1 배 흔들림 · R² 0.99 창은 n = 3 · 자유도 1) — 남는 진술 하나: 모든 창이 P_y ≫ P_max (156 MPa) | §A L193–197 | derived(ours) · 인용 금지 (숫자 안 옮김) | 논문은 Heckel 을 하지 않음 · LIB · springback 후 ε
- [c] famprikis2019_fundamentals_inorganic_sse | Li 금속 항복강도 ~0.8 MPa (ref 144 = Masias 2019 · 탄성 · 소성 · 크리프) · DEM 입력 조달 표: "SE 입자 σ_y = 없음 (공백)" · "파쇄 판정 K_Ic = 리뷰에 수치 0 (미세구조 의존 → 실험으로만 결정)" · litdb 유일 소환값 = [Fan26] 0.2–0.4 MPa·m^½ | §A L310 · L324–326 | 표지 없음 | 리뷰 · Li 금속 값 (SE 아님)
- [c] sakuda2013_sulfide_mechanical_property + bazzoun2026_dem_fem_rnm_ionic + kang2025_toughened_bimodal_nca_lzo | (묶음) SE 탄성계수 앵커: Sakuda 초음파 18–25 GPa (75Li₂S·25P₂S₅ = 24 · 50Li₂S·50P₂S₅ = 18 · 산화물 50Li₂O·50P₂O₅ = 50) · Bazzoun 22.1 (LPSCl) · Kang FEM E_LPSCl 22.1 · E_NCA 175 GPa → "SE 모듈러스 앵커 3 중 확인" | §A L417–421 · L445–446 | 표지 없음 | 탄성계수 (항복 · 경도 아님) · Sakuda = hot-press 고밀도 펠릿의 재료 고유 E (압밀 침대 E_eff 와 층위 다름) · Kang 의 22.1 은 FEM 입력
- [c] famprikis2019_fundamentals_inorganic_sse | DEM 입력 조달 표: 리뷰 소환 실측 E ≈ 20 GPa (ref 108) · G ≈ 7 GPa ↔ 우리 DFT E_VRH 22.06 (comp1) / 27.66 (modelc) · G_VRH 8.13 GPa | §A L320–321 | 표지 없음 | 리뷰 2 차 인용
- [c] vanlew2015_modifying_youngs_modulus_distribution | 실측 개별 입자 (pebble) 겉보기 E 가 소결 벌크 문헌값보다 낮음: 90 GPa vs 49 GPa (stated) → 평균 연화 1.84× (κ̄ = 0.544) · 변형 1.9 → 2.6 % (stated) · 배치 내 산포 ~7× (digitized) | §A L579–582 | stated / 산술 / digitized | Li₄SiO₄ · Li₂TiO₃ 세라믹 pebble (LPSCl 아님) · 탄성 (항복 아님) · 상수 Ē = 49 GPa 통제군 없음 (분포 효과 · 평균 효과 분리 불가)
- [c] doux2020_stack_pressure_assb | Li 금속이 LPSCl 의 기존 18 % 공극으로 creep (Li 항복 0.8 MPa · 작동압이 그 ~6–100 배) | §A L395–398 | 표지 없음 | Li 금속 (SE 아님) — 비교 문서: SE 소성의 직접 검증 아님 (over-claim 금지)
- [c] lee2025_heckel_argyrodite_powder_densification_nanoindentation | Heckel P_y 294–344 MPa (LPSCl) ↔ 우리 DEM 138 MPa = 2.1–2.5 배 | §A L925 | 표지 없음 | in-die 인지 · 일축 항복 환산 이 줄에 없음 (카드 본문 소관)
- [c] thompson2026_high_pressure_densification_lps_lpscl_xrd_tomography | NPD 격자 BM3 K₀ 22.9 GPa ↔ MPM K 25.5 · DFT B₀ 26.23 | §A L925 | [우리 산술] | 체적 탄성 (항복 · 경도 아님)
- [c] zunker2024_mdr_contact_model_partI | 접촉 법칙의 경화곡선 p̄/Y = 1.75·exp(−4.4 δ/R) + 1 (상수 2 개 · 전 재료 공통) — 완전소성 접촉력 F ≈ p_Y(δ)·A_geo(δ) 에는 E 가 안 들어감 · 구-구 항복겹침 δ_Y/R 을 LPSCl (E 22.1 · ν 0.37) 로 평가한 값은 L657–660 | §A L649–660 | 법칙 = 표지 없음 · LPSCl 평가 = DERIVED · "우리 계산 — 논문 수치로 인용 금지" (숫자 안 옮김) | MCC · Y 는 피팅값 · 일축 항복과의 환산 이 줄에 없음
- [c] he2026_dem_calendering_inhomogeneity_areal_density | 비교 문서가 3 점으로 파생한 Heckel P_y 1,010–2,921 MPa — "다른 상 · 다른 압력창" 이라 못 씀 | §A L869–870 | "우리가 3 점으로 파생" | NCM622 97.77 wt% + CBD (SE 없음)
- [c] jung2026_sio2_cosubstitution_mechanical_argyrodite | 기계 물성 (B₀ · E · 경도) 은 이 문서에 없음 — `comparison_vs_ours.md` §C 가 정본이라고만 적힘 | §A L921 | 표지 없음 | 
- [c] nezamabadi2022_mpm_cd_plastic_particle_compaction | (비교 문서의 우리 코드 판독 · 11-09 정정) `--sigma-y` 는 Hencky 편차 변형 노름 문턱 (‖dev ε_H‖ > σ_y/(2μ)) · 응력은 fixed-corotated → 단축 항복응력이 강성 · 하중 부호에 따라 다름: σ_y 0.30 일 때 연화 재료 (E 1.53 · ν 0.49) 압축 0.318 · 인장 0.454 GPa · 실제 강성 (E 22.06 · ν 0.36) 압축 0.363 · 인장 0.372 GPa · √(3/2)·σ_y = 0.367 GPa 는 작은 변형 극한 | §C L2700 | [우리 산술 · 코드 식을 그대로 풂] | 논문 밖 (우리 코드) · 처음 판 "단축 = √(3/2)·σ_y · 1.22 배 보정" 은 철회라고 적힘
- [c] nezamabadi2022_mpm_cd_plastic_particle_compaction | 2D 원판 von Mises 이선형 경화 σ_y 0.4 MPa · H 0 / 1 / 3 MPa · E 10 MPa (E/σ_y = 25) · 소성 / 탄성 분기 0.35 MPa (= 0.875 σ_y) · Φ 0.95 에 σ = 1.11 (H 0) · 1.53 MPa (탄성) = 2.8 · 3.8 σ_y · σ = σ_y 에서 Φ ≈ 0.84 | §C L2689–2697 | 분기 = stated · 나머지 digitized (2D) | 2D · mm 급 · 값 전이 금지
- [c] cronk2026_lis_positive_electrode_geometry_fem + deng2016_elastic_superionic_electrolytes_dft | (묶음) LPSCl 탄성 세 출처: Cronk FEM (Table S6) E 22 GPa · ν 0.3 · G 8.462 · K 18.333 / Deng 2016 E 22.1 · ν 0.37 · G 8.1 · K 28.7 / 우리 DFT E 22.06 · ν 0.360 · G 8.11 · B₀ 26.23 — E 는 0.3 % 안 · K 만 −30~−36 % (ν = 0.3 탓 · 자기 인용원과 불일치) | §C L2580–2591 | 표지 없음 (SI 실물 확인) | 탄성 (항복 아님) · Cronk 는 항복 · 경화 · 접촉 없음 (선형탄성 + 등방 eigenstrain)
- [c] cronk2026_lis_positive_electrode_geometry_fem | 본문 관측 "the resulting stress on the SSE matrix causes it to plastically deform to accommodate particle expansion" (cryo-FIB) ↔ 모델은 탄성 → 보고 응력 "beyond 5 GPa" 는 소성이 필요하다는 증거이지 실제 응력이 아님 · K_IC 0.3 MPa·m^½ 에서 임계 결함 a_c ≈ 0.8 nm @ 6 GPa · 5 nm @ 2.4 GPa | §C L2561–2579 | 원문 인용 · derived(ours) | Li–S 양극 · 사이클 팽창 (압밀 아님)
- [c] fan2026_sulfide_assb_stability_review_ECERD2600097 (비교 문서 표기 "Li(Yang) 2026 ECER 리뷰원고") | E (황화물) 10–30 GPa · K_IC 0.2–0.4 MPa·m^½ [122–124 McGrogan 계열] · 임계입경 규칙: > ~3 µm → 탄성변형에너지 축적 → 파편화 / < 1 µm → 협조변형 [72, 74] · 합금 음극 상대밀도 vs 정규화압력 σ/σ_y [210 Nat Mater 24, 907] | §C L2360–2373 | 표지 없음 | 리뷰 2 차 출처 · "황화물 소성 변형성" 은 정성 (접촉 소성 ↔ 형상 소성 구분 없음) · 항복 값 없음
- [c] wheatcroft2023_nmc811_secondary_particle_fracture_insitu_sem + zhang2026_xct_dem_cathode_calendering_peel_calibration | (묶음 · AM 파괴 세기) NMC811 2 차 입자 σ_F = P_f/D²: 평판 207 ± 49 · 원뿔 67 ± 21 MPa · Zhang Fig 9 의 접촉력 (최대 ≈ 177 mN @ 200 MPa) 을 이 식으로 정규화하면 가장 과응력인 것은 큰 입자에 끼인 작은 입자 (163 mN 접촉의 4.7 µm 쪽 ≈ 7 GPa ≈ 평판 강도의 36 배) · 같은 힘이면 큰 쌍의 Hertz 면압이 더 낮음 (177 mN: 16–16 µm ≈ 9.7 vs 6–6 µm ≈ 18.6 GPa) | §C L2345–2354 | figure-read · derived(ours) | NMC811 기준을 NMC111 계에 댄 "방향 감각만" · 액체 LIB · 파괴 모델 없는 DEM
- [c] lee2026_microcrack_tolerant_bilayer_cathode_chemomech_fastcharging + han2025_icep_conductive_elastic_binder + nam2026_primer_layer_dry_electrode_collector | (묶음 · 나노압입은 재는 대상에 따라 자릿수가 다름) Lee 2026: "cathodes" E_IT 5.17 / 6.02 GPa · H_IT 0.086 / 0.18 GPa = 전극 / 입자 유효값 (모델 E 191 GPa 와 다른 양) · Han: 바인더 필름 나노압입 6.03 GPa vs 인장 초기 ~10–25 MPa (3 자릿수 스프레드) · 전극 나노압입 E 1.57 GPa (PVDF 전극 0.11 GPa) · Nam: primer E ≈ 50–150 MPa | §C L2073–2074 · L2322–2327 · L2381–2382 | Lee = Fig S9 · Han 인장 = digitized | 전부 액체 LIB / 첨가제 층 (LPSCl 아님) · 일축 항복 환산 없음
- [c] tovar2026_cold_spray_cathode_composite_dem_plastic_elastic_bond | 결합 항복응력 σ0 (NMC 유효 9.3 MPa · α 1.2) = 기공 붕괴 · 재배열 · 바인더 변형 · 계면 미끄럼을 뭉친 복합체 유효값 (stated) · 강성은 실재값 E_b = 1.99 × 10¹¹ Pa · 항복변형률 4.7 × 10⁻⁵ | §C L2678–2682 | stated · 항복변형률 = "우리 산수" | LIB 조성 냉간분무 충돌 (압밀 아님) · Journal Pre-proof · 표 σ0 불일치 (Al · Cu · W)
- [c] zunker2024_bulk_elastic_partII + varkey2026_multicontact_elastoplastic_dem | (묶음) 다접촉 보정에 필요한 물성: Varkey = ν · Zunker = κ (체적탄성률 — 우리 DFT B₀ 26.23 을 그대로 쓸 수 있다고 적힘) | §C L2156–2159 | 표지 없음 | 
- [c] varkey2026_multicontact_elastoplastic_dem | 탄성 → 소성 무릎 ~100 MPa (비교 문서: 우리 Heckel P_y 138 과 같은 계열 · "소재 일반성") | §E L2827 | 표지 없음 | halide · 무릎의 정의 (Heckel 1/K 인지 육안 꺾임인지) 이 줄에 없음
- [c] zunker2024_mdr_contact_model_partI + jacksongreen2005_fem_elastoplastic_hemispherical_contact | (묶음 · 접촉 압력 ↔ 항복 환산) δ-의존 항복캡 p_Y/Y = 1.75e^{−4.4δ/R} + 1 (2.75 → 1.0) ↔ 상수 경도 H (2.8–3.0 Y · Tabor 꼴) — 우리 겹침 범위의 참값은 2.08–2.26 Y → A = F/H 가 24–44 % 과소 · Jackson–Green 2005 가 같은 방향 (2 독립 출처) | §F L3741–3744 | DERIVED | MCC 법칙을 LPSCl 겹침에 대입한 환산 · 구-구 ↔ 구-평면 δ 환산 규약 필요 (동일반경 δ_sf = δ_ss/2 · 12 : 1 이면 SE 가 겹침의 92 % — L3762–3763)
- [c] vanlew2015_modifying_youngs_modulus_distribution | 압쇄 임계력 F_c = C·(E*)^{2/5}(R*)^{1/5}(W_ε,l)^{3/5} (Eq. 7) → F_c ∝ E^{2/5} — E 를 낮추면 압쇄 문턱도 같이 내려감 (1.84× 연화 → 문턱 −21 %) · 압쇄강도 W_ε,l 도 입자마다 분포에서 배정 (모수 미보고) | §F L3335–3350 | 표지 없음 (−21 % = 산술) | 세라믹 pebble
- [c] sedlatschek2026_nmc811_grain_boundary_strength_micro_tensile + wheatcroft2023_nmc811_secondary_particle_fracture_insitu_sem | (묶음 · AM 파괴 입력) 다결정 NMC811 입계 σ_ch 745 MPa · 파괴변형률 ≈ 0.4 % · 집합체 E 138–165 GPa · 입자 분할 하중 σ_F = P_f/D²: 평판 207 ± 49 / 원뿔-구형 팁 67 ± 21 MPa | §F L3893–3899 | 표지 없음 (§G 가 정본) | NMC811 (AM) · SE 값 아님
- [c] zunker2024_mdr_contact_model_partI + fan2026_sulfide_assb_stability_review_ECERD2600097 | (묶음 · 파라미터 전이 함정) Zunker 의 Δγ 450 J/m² 는 유효 파괴에너지 (K_Ic 역산) · 열역학 W_ad 1.107 J/m² 와 400 배 차 → LPSCl 은 G_c = K_Ic²(1 − ν²)/E ≈ 3.24 J/m² (K_Ic 0.3 · E 24) | §F L3774–3777 | DERIVED | 
- [c] luan2025_graded_cathode_400whkg_pouch | (밀도 가정) vol% 환산에 ρ 4.8 / 1.86 / 2.0 (CAM / LPSCl / 탄소) "ASSUMED" | §F L3646 | DERIVED vol% · ASSUMED | 같은 문서 §E L2855 는 LPSCl 1.64 를 대입 (어긋남) · 랩 표준과 다른 값



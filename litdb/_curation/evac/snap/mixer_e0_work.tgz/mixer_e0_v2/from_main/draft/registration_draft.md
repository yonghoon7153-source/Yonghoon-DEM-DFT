# 믹서 E0 자격 pilot 한 팔 — 결과 전 등록 초안 (2026-11-11)

**지위: 초안 · 문서만 · 실행 0 · 제출 0 · 결과 0 건 · 봉인 아님 · 발사 GO 아님 · 전체 HOLD 그대로.**
이 문서는 런 **전에** 적어 두는 계약의 초안이다. 1저자 비준 → 봉인 → 내부 반박 리뷰 → 1저자 발사 GO 가 따로 남아 있다.

## 0. 자리 · 이번에 정하는 것 / 정하지 않는 것

- 자리 = 준비 단계 ② "기준 고정" 의 둘째 산출물 (첫째 = 같은 폴더 `baseline_table.md`). 다음 = ③ 봉인 → ④ 내부 반박 리뷰 → ⑤ 1저자 GO.
- 숫자의 출처 = `docs/data/mixer_e0_meta_ibb_20261110/out/` (아래 "out/") 와 리포 문서. 파일 · 줄을 적었다. `L` = 줄 번호.
- [산술] = 인용한 숫자로 계산한 값. [추정] = 가정이 든 값. 미확인 = 못 찾은 값.

| 이번에 정하려는 것 (초안) | 정하지 않는 것 |
|---|---|
| walltime · 디스크 바닥 · STOP 수치 (1저자 Q6) | 발사 · 제출 · 봉인 · 운영 봉인 교체 |
| 통과 / 실패 / 기술 실패라는 말의 뜻 (계획 문서에 있는 것만) | 새 물리 값 · 새 판정 문턱 |
| 런 폴더 규칙 (Q5) | N0 · B1–B3 팔 · 둘째 팔 · 확인 블록 |
| 내부 반박 리뷰가 볼 것 (Q7) · 1저자가 정할 것 | E0 수용 뒤의 `MAP_CASE_GO` · 다음 wave |

## 1. 무엇을 돌리는가 (계획 문서의 정의 그대로)

경로 줄임: `F8` = `docs/reviews/mixer_first8_launch_preparation_20261106` · `P8` = `docs/reviews/mixer_precal_first8_preparation_20261104`.

| 항목 | 값 | 근거 |
|---|---|---|
| 팔 | first8 의 `PRECAL_E0` 한 팔 = 점착 0 · 균일 삽입 · 0 바퀴 (정착만) | `P8/README.md` L9 · `F8/inventory.md` L22 |
| 역할 | 기존 M 분모의 출처가 되는 정착 기준. 회전 자료와 바꿔 쓰지 않는다 | `docs/reviews/mixer_precal_exploration_registration_draft_20261104.md` L48 |
| 고정 조건 | seed 32452843 · 밀도 세대 lab20261014 · 계획 원자 100,000 · CGF 151.4 · SE ×20 · 쌍별 힘 보존 · dt_factor 1 · Fr 0.0827 · 배플 0 · 전 정밀도 덤프 | `P8/README.md` L9 · `F8/planned_assets/PRECAL_E0/deck_meta.json` L12 · L14 · L15 · L18–20 · L208–209 |
| NP | 팔당 20 (1저자 채택 정책) | `docs/reviews/mixer_inactive_preparation_20261109/author_policy_record.json` L13 |
| 순서 | E0 한 팔만 → 검토. 그 뒤 팔은 별도 승인 | 같은 파일 L14–17 · `docs/reviews/nonrint_first_link_20261109/mixer_ibb_fixed_qualification_plan.md` L12 |
| 풀리는 GO | `QUALIFICATION_PILOT_GO` = E0 한 팔만. 전체 HOLD 는 그대로 | `F8/README.md` L26 |
| 이 팔만의 특례 | 내부 반박 리뷰가 Codex GO 자리를 대신한다 (이 한 팔뿐 · 발사 GO 는 1저자) | `docs/session_20260923_progress.md` L1423 의 ④ · `docs/data/mixer_e0_meta_ibb_20261110/README.md` L41 |
| 덱 | `in.mixer` 11,347 B · sha256 8b588b24117ab77bf72d93662237268b401f714df8515d62ef7b964d01c6e718 | `F8/planned_assets/SHA256SUMS` L36 · `F8/blockers.json` L72 |
| 덱이 하는 일 | dt 2.373e-07 s. run 1 → run 560,606 → 삽입 해제 → run 560,606 → 정착 상태 저장 → run 0. 합 1,121,213 step [산술] | `F8/planned_assets/PRECAL_E0/in.mixer` L84 · L133 · L145–147 · L150 · L156 |
| 출력 | 덤프 = 1,000 step 마다 · 12 열 (id type x y z vx vy vz fx fy fz radius) · 정수 2 열 + `%.17g` 10 열. 프레임 1,121 장 [산술 = 1,121,213 ÷ 1,000 버림]. t0 = step 1,121,000. thermo 5,000 step. 체크포인트 = 56,060 step 마다 두 파일 번갈아 + 정착 끝 한 파일 | 같은 덱 L136 · L139 · L121 · L132 · L150 · `deck_meta.json` L64–66 |
| 메타 | 후보 둘 (덱 바이트는 같다). 원 계획 = c6543f3800d0d76d… (생성기 해시 661936b7…) / 현재 소스용 비활성 후보 = 498b941c898ea963… (생성기 해시 dc253bc8…). 다른 곳은 `generator_sha256` 한 칸뿐 | `F8/planned_assets/SHA256SUMS` L37 · `docs/reviews/mixer_inactive_preparation_20261109/candidate/candidate_asset_manifest.json` L36 · 같은 폴더 `README.md` L25 |
| STL | Drum fe821a8a… · Front 443f9c3c… · Back 2e7b962d… (ibb 체크아웃 · DEV 런의 STL 과 같은 해시) | `F8/planned_assets/SHA256SUMS` L38–40 · `baseline_table.md` 7 절 |
| 바이너리 · MPI | lmp_mpi sha256 ee2d7726… · mpirun sha256 407990f9… (Open MPI 5.0.10) | `baseline_table.md` 2 · 3 절 |
| 제출 길 | first8 가드 하나: 제출 가드 → 러너 → job 시작 대조 → `mpirun --oversubscribe --bind-to none -np 20 <바이너리> -in in.mixer` 한 번. raw sbatch · 옛 런처 (`launch_highbo.sh`) 는 쓰지 않는다 | `F8/commands.txt` L24–40 · `F8/job_start.py.txt` L44 · `F8/inventory.md` L30 |
| 러너의 SLURM 줄 | 파티션 cpu · QOS cpu-60 · 노드 1 · task 20 · task 당 CPU 1 · requeue 없음 · 시간 = 승인값 (형식 `D-HH:MM:SS`) | `F8/run_one.sbatch.txt` L2–9 · `F8/submit_one.py.txt` L22–23 |
| 관측 명령 (런 뒤) | `python3 scripts/mixer_precal_observe.py --case PRECAL_E0 --run <검증된 스냅숏>` (기준 런이라 `--reference` 없음) | `F8/commands.txt` L58 · `F8/inventory.md` L60 |

주의: 위 가드 · 러너 · job 시작 대조기는 "비활성 초안" 이다. 실제 SLURM · MPI 에서 돈 적이 없다 (`F8/README.md` L11 · L30).

## 2. 결과 전 pilot 표 (계획 문서 M-2 3 절의 여섯 칸)

M-2 = `docs/reviews/mixer_qualification_plan_20261110.md` (HEAD 에는 없다. 원격 가지 `origin/codex/mixer-qualification-plan-1110` 의 커밋 `0c56deba6` 판 · 줄 번호도 그 판).

| 칸 (M-2 줄) | 이 초안의 답 | 아직 빈 것 |
|---|---|---|
| 목적 (L30) | 자격 관측 여섯 가지: (1) 입력 결속 — 놓인 덱 · 메타 · STL 이 계획 바이트와 같다 (2) 바이너리 · MPI — job 안 해시 · 배너 · rank 20 (3) 100k 관측 — 전 정밀도 12 열 덤프가 써지고 읽힌다 · 로그가 네 run 을 끝낸다 (4) 시간 — 실제 런 시간 (5) 저장 — 실제 프레임 · 폴더 크기 (6) 회수 — 새 스냅숏 복사와 해시 대조. **과학 비교는 목적이 아니다** (`F8/inventory.md` L70: 기준 · 로그 · I/O 자격) | 없음 |
| 최소 입력 (L31) | 1 절 표 (팔 · seed · 덱 · STL · NP 20 · 순서 · 관측 주기 · 열) | 메타 후보 선택 · 소스 핀 · Python 경로 · 러너 바이트 (봉인 단계) |
| 합격 / 거부 (L32) | 7 절 — 계획 문서에 있는 상태 말만 쓴다 | 정량 합격선은 계획 문서에 없다 (L32 "각 정량 문턱과 기준은 미등록"). 이 초안도 만들지 않는다 |
| STOP (L33) | 6 절 — walltime · 저장 바닥 · 런 폴더 상한 · 멈춤 문턱 (Q6 초안) + 계획 문서의 정성 규칙 | 디스크 수치는 조회 (9 절) 뒤 한 번 고친다 |
| 회수 (L34) | 담당 = 1저자 (`docs/reviews/nonrint_approved_preparation_20261109/mixer_ibb_qualification_receipt_plan.md` L67). 정확한 job ID 하나만 중단. 부분 · 실패도 원바이트로 남긴다. 새 스냅숏 + 해시 대조 (`F8/commands.txt` L53–57 · L62–66) | 회수 범위 (전부 / 일부) · 로컬 여유 (13 절 Q8) |
| 확대 (L35) | E0 수용 ≠ first8 전체 GO. 다음 (N0) 은 실제 자격 수용 뒤 `MAP_CASE_GO` 로 따로. 자동 전이 없음 (`F8/README.md` L26) | 이 문서의 범위 밖 |

## 3. 런 폴더 (Q5)

| 항목 | 내용 | 근거 |
|---|---|---|
| 결정 | 발사 때 새로 만든다. dev7 · dev7_v26 폴더는 쓰지 않는다. 지금은 만들지 않는다 | `docs/data/mixer_e0_meta_ibb_20261110/README.md` L16 |
| 지금 상태 | first8 제안 root 가 ibb 에 없다 | out/ `fields.txt` L353 · `hashes.txt` L473 |
| fresh 조건 | 런 폴더에 post · restart · log.liggghts · job_start.json · job_end.json · simulator.stdout · simulator.stderr 가 없어야 한다 (제출 영수증 둘도) | `F8/job_start.py.txt` L37–38 · `F8/submit_one.py.txt` L138–139 |
| 폴더 구조 | root 아래 `campaign_policy.json` · `cases/PRECAL_E0/` · `admission/` | `F8/commands.txt` L68–71 |
| 같은 파일시스템 | HOME 아래면 Lustre 다 (여유 · inode = `baseline_table.md` 5 절) | out/ `fields.txt` L539–540 |
| 아직 미정 | root 이름 · 경로 꼴 (풀린 꼴로 통일할지) | 13 절 Q4 |

## 4. Q6 — 시간 (walltime)

**상태: 실측이 out/ 에 있다 (런별 다섯). 아래에 산술 · 여유 배수 · 까닭을 적었다.**

### 4-1. 실측: DEV E0 다섯 런 (dev7_v26)

런 시간 = job 시작 시각 (`job_start.json` 의 `time_utc`) 에서 `log.liggghts` 의 마지막 수정 시각까지 [산술]. step 수 = 리포의 같은 덱 메타 (`docs/data/mixer_highbo_dev_decks_20260930_v26/decks/<런>/deck_meta.json` 의 `steps` — E0_ref L77–78 · dthalf L79–80) 에서 1 + fill × 2. ibb 런의 덱 sha256 이 리포 덱과 같다 (`baseline_table.md` 7 절).

| 런 | job 시작 (UTC) | 근거 (out/ `seal_extract.txt`) | 로그 마지막 수정 (epoch 초) | 근거 (out/) | 런 시간 | step 수 | step/s |
|---|---|---|---|---|---|---|---|
| E0_ref_s32452843 | 2026-09-30T08:12:16Z | L957 | 1790769933 | `mix3_run23_ls.txt` L6 | 13,997 s (3.89 h) | 1,037,429 | 74.12 |
| E0_ref_s49979687 | 2026-09-30T09:12:36Z | L917 | 1790773512 | `mix3_run22_ls.txt` L8 | 13,956 s (3.88 h) | 1,037,429 | 74.34 |
| E0_ref_s67867967 | 2026-09-30T09:12:39Z | L557 | 1790770830 | `mix3_run9_ls.txt` L6 | 11,271 s (3.13 h) | 1,037,429 | 92.04 |
| E0_ref2_s32452843 | 2026-09-30T12:05:39Z | L437 | 1790787354 | `mix3_run1_ls.txt` L8 | 17,415 s (4.84 h) | 1,467,147 | 84.25 |
| E0_ref_dthalf_s32452843 | 2026-09-30T12:20:32Z | L717 | 1790795353 | `mix3_run14_ls.txt` L6 | 24,521 s (6.81 h) | 2,074,857 | 84.62 |

다섯 다 NP 20 · QOS cpu-60 · 시간 한도 2-00:00:00 으로 돌았다 (out/ `seal_extract.txt` L984 · L986 · L988 과 같은 칸).

참고 — 옛 덱 (dev7) 의 E0 다섯 런을 같은 방법으로 읽으면 80.26 · 65.25 · 70.82 · 67.29 · 63.49 step/s 다 [산술. 시작 = out/ `seal_extract.txt` L117 · L157 · L197 · L357 · L237 / 로그 = `mix2_run1_ls.txt` L6 · `mix2_run2_ls.txt` L8 · `mix2_run3_ls.txt` L6 · `mix2_run7_ls.txt` L8 · `mix2_run4_ls.txt` L6 / step 수 = 리포 `docs/data/mixer_highbo_dev_decks_20260930/decks/<런>/deck_meta.json` 의 `steps`].
열 런을 합친 범위 = **63.49 ~ 92.04 step/s** (폭 1.45 배).

### 4-2. 이 읽는 법이 맞는가

같은 방법으로 dev-bo 두 런을 읽으면 96,969 s · 87,640 s 다 (out/ `seal_extract.txt` L597 · L797 / `mix3_run11_ls.txt` L6 · `mix3_run16_ls.txt` L8).
그 두 런의 sacct 기록은 1-02:56:12 (= 96,972 s) · 1-00:20:44 (= 87,644 s) 다 (`docs/data/mixer_highbo_devbo_prelim_20261003/README.md` L14).
차이 3 초 · 4 초. 이 읽는 법은 sacct 와 맞는다.

### 4-3. pilot 으로 옮기는 산술

| 항목 | 값 | 근거 |
|---|---|---|
| pilot step 수 | 1,121,213 (DEV E0_ref 1,037,429 의 1.081 배) | 1 절 |
| 예상 런 시간 | 3.38 h (92.04 step/s) ~ 4.20 h (74.12, dev7_v26 에서 가장 느림) ~ 4.91 h (63.49, 열 런에서 가장 느림) [산술 = step 수 ÷ 속도] | 4-1 |
| 기존 문서 어림과 비교 | 4.4 ~ 4.9 h (63–70 step/s 가정) — 겹친다 | `F8/README.md` L20 |
| 안 잰 것 (1) | 전 정밀도 12 열 덤프의 쓰기 시간. 덱 주석은 덤프 크기를 "약 2 배" 로 적는다 | `F8/planned_assets/PRECAL_E0/in.mixer` L138 |
| 안 잰 것 (2) | 덱 세대가 다르다 (밀도 · dt · 드럼 크기 · 정착 step 수). 원자 수 · 덤프 열 · 덤프 간격은 같다 | 두 덱을 줄 단위로 견줌 [본 세션]: `docs/data/mixer_highbo_dev_decks_20260930_v26/decks/E0_ref_s32452843/in.mixer` ↔ `F8/planned_assets/PRECAL_E0/in.mixer` |
| 안 잰 것 (3) | 러너가 다르다. pilot 러너는 노드 1 고정 · task 당 CPU 1 을 적는다. DEV 러너는 `-n` 만 적었다 | `F8/run_one.sbatch.txt` L4–6 · `dem_scripts/mixer_20260921/launch_highbo.sh` L293–298 |

### 4-4. walltime 초안

**초안값: `1-00:00:00` (24 시간).**

| 항목 | 내용 |
|---|---|
| 여유 배수 | 86,400 s ÷ 17,658 s = 4.9 배 (열 런에서 가장 느린 속도 기준) · 86,400 ÷ 15,127 = 5.7 배 (dev7_v26 에서 가장 느린 속도 기준) [산술] |
| 까닭 1 | 이 팔은 재시도 · resume · requeue 가 없다 (`F8/README.md` L22). 시간 초과로 죽으면 팔을 잃는다. 넉넉한 쪽의 비용은 작다 |
| 까닭 2 | 안 잰 것이 셋 있다 (4-3) |
| 까닭 3 | 속도가 고르지 않다. 같은 덱 세 런 (dev7_v26 E0_ref) 사이에 1.24 배, 열 런 전체로는 1.45 배 벌어졌다 [산술 = 92.04 ÷ 74.12 · 92.04 ÷ 63.49] |
| 까닭 4 | 멈춘 런은 walltime 이 아니라 감시 (6 절 S5) 로 잡는다 |
| 한도 확인 | 내 association MaxWall 7-00:00:00 · 파티션 14-00:00:00 안이다 (`baseline_table.md` 4 절) |
| 대안 | `0-12:00:00` (2.4 ~ 2.9 배) · `2-00:00:00` (DEV E0 정책값 그대로 · 9.8 ~ 11.4 배) |

## 5. Q6 — 디스크 (크기 · 바닥)

**상태: 런별 크기 실측이 out/ 에 없다 → 1저자 / ibb 읽기 전용 조회 필요 (9 절 q1–q3). 아래 수치는 조회 전의 임시 상한이다.**

### 5-1. out/ 에 있는 것 · 없는 것

| 있는 것 | 값 | 근거 (out/) |
|---|---|---|
| dev7_v26 폴더 합계 | 90,504,844 KB | `mix3_du.txt` L1 |
| dev7_v26 의 post 항목 수 합 | 7,763 = 1,037 × 4 + 1,467 + 307 + 267 + 170 + 234 × 6 | `fields.txt` L348 · L343 · L252 · L291 / L201 / L221 · L286 · L315 / L239 · L267 · L278 · L299 · L310 · L332 |
| dev7 폴더 합계 | 63,444,400 KB | `mix2_du.txt` L1 |
| dev7 의 post 항목 수 합 | 5,355 = 867 × 4 + 1,227 + 314 + 135 + 211 | `fields.txt` L129 · L140 · L145 · L153 / L181 / L161 · L170 · L189 |

**없는 것: DEV E0 런별 덤프 크기 · 프레임 한 장 크기.** post 는 디렉터리 항목 크기만 찍혔다 (`mix3_run23_ls.txt` L10). 그래서 아래 5-2 는 평균 [추정] 이고, 실측은 9 절의 조회가 필요하다.

### 5-2. 폴더 평균으로 본 프레임 크기 [추정]

| 폴더 | 산술 | 값 |
|---|---|---|
| dev7_v26 | 90,504,844 KB ÷ 7,763 | 11,658 KB = 11.94 MB / 항목 |
| dev7 | 63,444,400 KB ÷ 5,355 | 11,848 KB = 12.13 MB / 항목 |

가정: 폴더 크기가 전부 프레임이고 프레임 크기가 고르다. 실제로는 체크포인트 · 로그 · 보충 폴더가 섞여 있어 위로 약 1.5 % 치우친다 [추정 — 체크포인트 한 파일 36,179,883 B (리포 `docs/data/mixer_highbo_devu_prelim_20261006/exact_runs/exact_LU212_settled/exact_receipt.json` L38) × 39 개].
DEV E0_ref 한 런 ≈ 1,037 × 11.94 MB = 12.4 GB [추정]. 기존 문서의 상한 어림 14.5 GB (`docs/data/mixer_highbo_dev_decks_20260930_v26/README.md` L17) 의 85 % 다.

### 5-3. pilot 의 상한 산술

리포에 있는 규칙 (`scripts/mixer_stage_gate.py` L85–86 · L303–318): 줄 폭 = id 자릿수 + type 2 + 실수 열 × 최악 폭 + 구분자. 프레임 = 원자 수 × 줄 폭 + 512 B. 체크포인트 = 원자당 400 B × 3 파일. 기본 형식 (`%g`) 의 최악 폭은 12 다.

| 단계 | 산술 | 값 |
|---|---|---|
| `%.17g` 의 최악 폭 | 부호 1 + 유효숫자 17 + 소수점 1 + e 1 + 지수 부호 1 + 지수 3 [산술 — 본 세션이 난수 double 200 만 개와 끝값으로 최대 길이 24 를 확인. 리포 문서에는 없는 수다] | 24 |
| 한 줄 | 6 + 2 + 10 × 24 + 12 | 260 B |
| 프레임 한 장 | 100,000 × 260 + 512 | 26,000,512 B |
| 덤프 전체 | 1,121 × 26,000,512 | 29,146,573,952 B |
| 체크포인트 | 3 × 100,000 × 400 | 120,000,000 B |
| **합 (상한)** | | **29,266,573,952 B ≈ 29.27 GB** |

이 합이 상한이 되는 조건 [추정]: 원자 ≤ 100,000 · 덤프 12 열 · 형식 줄이 덱대로 적용됨. 형식 줄이 안 먹으면 프레임은 더 작다 (기본 형식).

교차 확인 둘:
- `%g` 규칙의 상한은 14,000,512 B / 장이다. 5-2 의 평균은 그 85 ~ 87 % 다. 규칙이 위쪽 값이라는 것과 맞는다.
- 덱 주석의 "약 2 배" 로 어림하면 2 × 11.94 MB × 1,121 = 26.8 GB [추정]. 상한 29.27 GB 안이다.

### 5-4. 바닥 · 상한 초안

| 수치 | 초안값 | 산술 · 까닭 | 지금 값과 비교 |
|---|---|---|---|
| 런 폴더 상한 | 29,266,573,952 B | 5-3 의 합. 넘으면 계획에 없는 출력이다 | — |
| 여유 바닥 (`minimum_free_bytes`) | 32,193,231,348 B (≈ 32.2 GB) | 상한 × 1.10 올림. 1.10 = 리포에 이미 있는 여유 규칙 "필요 × 1.10 ≤ 가용" (`scripts/mixer_stage_gate.py` L84) | 지금 여유 142,604,135,108,608 B = 바닥의 약 4,430 배 |
| inode 바닥 (`minimum_free_inodes`) | 1,250 | 프레임 1,121 + 체크포인트 3 + 영수증 · 로그 · 폴더 약 12 [추정] = 1,136 → × 1.10 올림 | 지금 여유 559,481,276 |
| 회수 목적지 여유 | ≥ 32.2 GB | 전부 가져올 때 같은 양이 한 번 더 든다 | 미확인 (로컬) |

두 바닥 칸은 job 시작 대조기가 요구하는 칸이다 (`F8/job_start.py.txt` L39–42 — 값이 없으면 시작을 거부한다).
상한에는 로그 · 영수증을 넣지 않았다. DEV E0 런의 로그는 수십 KB 였다 (out/ `fields.txt` L345 · L349). `du` 는 할당 블록 기준이라 파일 크기 합과 조금 다를 수 있다 [추정].

### 5-5. 등록 전에 한 번 고칠 것

위 수치는 실측이 아니라 산술 상한이다. 9 절의 조회 (런별 du · 프레임 크기) 가 오면 5-2 의 평균을 실측으로 바꿔 적고, 상한이 실측과 어긋나지 않는지 본다. 상한 · 바닥의 식은 그대로 둔다.

## 6. Q6 — STOP 수치 (한 표)

| # | 언제 | 조건 | 수치 | 누가 · 무엇을 | 근거 |
|---|---|---|---|---|---|
| S0 | 제출 전 | 현장 조회가 5 분보다 오래됨 | 300 초 | 가드가 제출을 막는다 | `F8/submit_one.py.txt` L125–126 (이미 있는 수치) |
| S0 | 제출 전 | 내 잡 CPU + 20 > 60 · 동시 팔 수 초과 | 60 · 1 팔 | 가드가 막는다 | `F8/submit_one.py.txt` L132–134 · 정책 (1 절) |
| S1 | 실행 중 | 시간 한도에 닿음 | `1-00:00:00` (4-4 초안) | SLURM 이 끊는다 (TIMEOUT) → 기술 실패. 다시 내지 않는다 | 4 절 |
| S2 | job 시작 · 감시 | 파일시스템 여유 < 바닥 | 32,193,231,348 B | 시작 때는 대조기가 거부. 실행 중이면 1저자가 중단 | 5-4 · `F8/job_start.py.txt` L39–42 |
| S3 | job 시작 | inode 여유 < 바닥 | 1,250 | 대조기가 거부 | 5-4 |
| S4 | 감시 | 런 폴더 크기 > 상한 | 29,266,573,952 B | 1저자가 중단 → 기술 실패 | 5-4 |
| S5 | 감시 | 새 프레임이 안 생김 | 30 분 | 1저자가 중단 → 기술 실패 | 아래 산술 |
| S6 | 감시 | 로그에 ERROR · 비유한 값 · 입자 소실 | (정성) | 1저자가 중단 → 기술 실패 | `F8/README.md` L22 · `F8/commands.txt` L50 |
| S7 | job 시작 | 신원이 봉인과 다름 (덱 · 소스 · 정책 · 바이너리 · rank) | (일치 / 불일치) | 대조기가 시뮬레이션 전에 멈춘다 | `F8/job_start.py.txt` L20–36 |

- S5 의 산술: 프레임 간격 = 1,000 step ÷ 속도 = 10.9 ~ 15.8 초 [산술 · 4-1 의 63.49 ~ 92.04 step/s]. 30 분은 그 114 ~ 166 배다. 사람이 보는 감시라 분 단위로 잡았다. 첫 프레임까지 걸리는 시간 (삽입) 은 미확인이라 같은 30 분을 쓴다.
- S6 의 "입자 소실" 읽는 법 (초안): thermo 의 Atoms 값이 앞 줄보다 줄어든다. 덱이 소실을 오류로 올리지 않기 때문이다 (`F8/planned_assets/PRECAL_E0/in.mixer` L122). 계획 문서는 "소실" 이라고만 적는다.
- 중단은 정확한 job ID 하나에만 한다. 사용자 전체 취소 · 재시도 · resume · requeue 는 없다 (`F8/commands.txt` L62–66).
- 중단 · 실패 뒤에도 원 출력은 지우지 않는다. 다음 팔은 내지 않는다.

이 표의 수 가운데 이 초안이 새로 내는 것과 이미 있던 것:

| 구분 | 수 | 출처 |
|---|---|---|
| 새로 냄 (Q6 의 몫 · 1저자 비준 대상) | walltime `1-00:00:00` · 런 폴더 상한 29,266,573,952 B · 여유 바닥 32,193,231,348 B · inode 바닥 1,250 · 멈춤 30 분 | 4 절 · 5 절 · 위 산술 |
| 이미 있던 것 | 300 초 · cpu 60 · NP 20 · 동시 1 팔 · 여유 배수 1.10 · 체크포인트 원자당 400 B · 프레임 머리 512 B · 초기 총누락 0 ~ 10 | `F8/submit_one.py.txt` L126 · L133 · `docs/reviews/mixer_inactive_preparation_20261109/author_policy_record.json` L13–14 · `scripts/mixer_stage_gate.py` L84 · L86 · L315 · `scripts/mixer_precal_observe.py` L246 |

## 7. 통과 / 실패 / 기술 실패

### 7-1. 계획 문서에 있는 상태 말

| 층 | 상태 | 뜻 | 근거 |
|---|---|---|---|
| 제출 | HOLD | 신원 · 정책 · rank · cap · 저장 · 선행 조건이 안 맞으면 발사 전에 막힌다 | `F8/README.md` L22 |
| 실행 | `EXITED_REQUIRES_QUALIFICATION` | MPI 종료 코드 0. "자격 검토가 필요한 끝남" 이지 자격이 아니다 | `F8/job_start.py.txt` L54 |
| 실행 | `TECH_HOLD` | 종료 코드가 0 이 아니거나 실행 예외 | `F8/job_start.py.txt` L52–54 |
| 감시 | TECH / HOLD | 중단 · 오류 · 비유한 · 입자 소실 · 문턱 초과 · 진행 불명 | `F8/README.md` L22 · `F8/inventory.md` L56 |
| 회수 | 미자격 | 불완전 · 바뀐 · 진행 중 복사 · 해시 불일치 | `F8/inventory.md` L58 · `F8/commands.txt` L53–57 |
| 관측 | OK (종료 코드 0) | 구조 · 신원 · 로그 · 프레임 자격을 다 지나 값을 낸다. E0 는 t0 접촉과 칸 원 분산만 낸다 (M 은 해당 없음) | `scripts/mixer_precal_observe.py` L453 · L484 · L393 · L402 |
| 관측 | UNDEFINED (종료 코드 2) | 분모 미정의 · 비유한. 0 으로 바꾸지 않는다 | `P8/README.md` L18 · 관측기 L460–461 |
| 관측 | TECH (종료 코드 2) | 구조 · 신원 · 중단 오류. 값을 내지 않는다 | `P8/README.md` L18 · L35 · 관측기 L462–467 |
| 자격 | 수용 / 거부 | 사람의 검토 + 1저자. 다음 팔의 `MAP_CASE_GO` 는 "수용된 실제 자격" 을 따로 요구한다. 자동 전이 없음 | `F8/README.md` L26 · `docs/reviews/nonrint_first_link_20261109/mixer_ibb_fixed_qualification_plan.md` L54 |

관측이 보는 것 (E0): 초기 총누락 0 ~ 10 · ID 가 1..N · 덤프 반경 = 템플릿 반경 (관측기 L218–253) · t0 프레임이 정확히 1 장 (L297) · 로그가 네 run 을 끝냄 · ERROR / 재개 흔적 없음 (L307–337).

### 7-2. 이 초안에서 쓰는 세 말

| 말 | 뜻 (위 상태 말의 조합) |
|---|---|
| 통과 | 실행 `EXITED_REQUIRES_QUALIFICATION` + 회수 대조 일치 + 관측 OK. **뜻 = "자격 검토로 넘길 수 있다".** 자격 수용도 물리 자격도 아니다 |
| 기술 실패 | 실행 `TECH_HOLD` · 감시 TECH / HOLD · 회수 미자격 · 관측 TECH / UNDEFINED · 시간 초과 중 하나. 값을 쓰지 않는다 |
| 실패 (자격 거부) | 통과한 런을 검토에서 수용하지 않음. **무엇이면 거부인지의 정량 기준은 계획 문서에 없다** (M-2 L32). 이 초안은 만들지 않는다 → 13 절 Q9 |

성공 문자열 · 종료 코드 0 · 스케줄러 COMPLETED 만으로는 통과가 아니다 (M-2 L32 · `F8/commands.txt` L37–38).

### 7-3. 관찰 — 지금 봉인된 관측기로는 "관측 OK" 가 나올 수 없어 보인다

| 항목 | 내용 | 근거 |
|---|---|---|
| 관측기가 요구하는 thermo 머리 | 토큰이 정확히 `Step Atoms KinEng c_rke Volume` | `scripts/mixer_precal_observe.py` L316 |
| 관측기가 요구하는 Loop 줄 | 줄 전체가 "… steps with N atoms" 로 끝나야 한다 | 같은 파일 L319 |
| 실제 ibb 로그의 thermo 머리 | `Step Atoms KinEng rke Volume` (c_ 가 없다) | `docs/data/mixer_highbo_devu_prelim_20261006/exact_runs/exact_LU212_settled/log.exact` L65 |
| 실제 ibb 로그의 Loop 줄 | "… atoms, finish time <날짜>" 로 끝난다 | 같은 로그 L67 |
| 같은 조건인가 | 같은 바이너리 (sha256 ee2d7726…) · 같은 thermo_style 글자 | 같은 폴더 `exact_receipt.json` L124 · L126 · `in.exact` L114 ↔ pilot 덱 L120 |
| 로그 파일에서도 그런가 | 그렇다. 위 로그는 화면 출력을 받은 것이다. 같은 빌드 배너의 `log.liggghts` 에서도 변수 열 머리에 접두어가 없고 (thermo_style `v_pressMPa` → 머리 `pressMPa`), Loop 줄에 "finish time" 뒤꼬리가 있다 | `docs/data/kg50_d07_end_20261105/kg50_d07_b50_log_main1103.liggghts` L1 · L150 · L171 · `docs/data/kg50_d07_end_20261105/kg50_d07_b50_log_ins1.liggghts` L121 |
| 본 세션 확인 | 관측기의 로그 계약 함수 글자를 메모리에서만 돌렸다 (파일 쓰기 없음). 실제 꼴 줄 → "log fresh four-run completion mismatch". 머리만 시험 꼴 → "invalid five-column thermo row". Loop 만 시험 꼴 → "Loop lacks a qualified thermo table". 둘 다 시험 꼴 → MATCH | 이 세션의 일회 확인 (기록 파일 없음) |
| 문서의 한정 | "실제 LIGGGHTS 로그 호환성은 아직 검증하지 않았다" | `P8/README.md` L53 |

뜻: 관측기 (sha256 df22dcf0… · `F8/source_seal.json` L11) 를 그대로 두면 정상 완주 런도 관측 TECH 가 된다 [관찰 — 실제 PRECAL_E0 로그로는 미확인]. 그러면 7-2 의 "통과" 는 나올 수 없다. 처리 = 13 절 Q5.

## 8. 결과 전 기대 (예측 · 판정선 아님)

| # | 기대 | 출처 |
|---|---|---|
| E1 | 런 시간 3.4 ~ 4.9 h [추정]. 전 정밀도 쓰기 시간만큼 더 길 수 있다 | 4-3 |
| E2 | post 항목 1,121 개. 마지막 프레임 step = 1,121,000 (= t0) | 1 절 |
| E3 | restart 항목 3 개 | 1 절 · DEV 다섯 런도 3 (out/ `fields.txt` L347 등) |
| E4 | 프레임 한 장 ≤ 26,000,512 B. 2 배 어림이면 약 23.9 MB [추정] | 5-3 |
| E5 | 런 폴더 ≤ 29.27 GB. 2 배 어림이면 약 26.8 GB [추정] | 5-3 |
| E6 | t0 원자 수 99,990 ~ 100,000 (관측 계약의 허용 폭). 상별 수는 계획과 몇 개 다를 수 있다 (MPI 삽입) | 관측기 L246 · CLAUDE.md L40 의 `SELF-70` 서술 |
| E7 | MPI 종료 코드 0 | — |
| E8 | 관측기를 고치지 않으면 관측 = TECH (로그 계약) [관찰] | 7-3 |

값 (접촉 수 · 칸 분산) 에 대한 기대는 적지 않는다. 판정에 쓰지 않기 때문이다.

## 9. 필요한 ibb 읽기 전용 조회 (승인 뒤 · 1저자)

전부 읽기만 한다. 가린 사본만 반입한다 (Q8 규칙). 명령 꼴은 초안이다 — 블록으로 만들 때 컨테이너 시험을 먼저 한다.

| # | 무엇 | 명령 꼴 (초안) | 채우는 칸 |
|---|---|---|---|
| q1 | DEV E0 다섯 런의 post · restart 크기 | 런마다 `du -sk <런>/post <런>/restart` | 5 절 — 런별 실측 |
| q2 | 한 런의 프레임 크기 · 시각 | post 안 파일의 크기 · 수정 시각 목록에서 처음 3 · 가운데 1 · 끝 3 줄 | 프레임 한 장 크기 · 첫 프레임까지 시간 · 프레임 간격 |
| q3 | 전 정밀도와 기본 형식의 실제 크기 비 | 보충 폴더 (exact) 의 hp · g6 파일 크기 (6 열) | 5-3 의 폭 가정 검산 |
| q4 | 기본 할당 한도 | `lfs quota -U <마운트>` + `lfs quota -u <나> <마운트>` | `baseline_table.md` 5 절 "내 할당" |
| q5 | OST 별 여유 | `lfs df <마운트>` | 같은 절 "OST 별 여유" |
| q6 | DEV E0 잡 다섯의 기록 | `sacct -j 249080,249081,249082,249083,249084` (State · ExitCode · Elapsed · AllocCPUS · MaxRSS · ReqMem) | 4-1 대조 · 메모리 칸 |
| q7 | 라이브러리 신원 | `readelf -d` 의 RPATH / RUNPATH 줄 + ldd 대상의 실제 파일 `sha256sum` | `baseline_table.md` 2 절 미확인 둘 |
| q8 | 빈 코어 (발사 직전) | `sinfo` 의 CPU 할당 / 유휴 요약 | 대기 가늠 (판정 아님) |

주의: q6 의 sacct 는 지난 블록의 승인 범위 (sinfo · sacctmgr show · 내 squeue) 밖이다. 새 승인이 필요하다 (`docs/data/mixer_e0_meta_ibb_20261110/README.md` L15). 잡 번호는 out/ `seal_extract.txt` L968 · L928 · L568 · L448 · L728 이다.

## 10. 하지 않는 것

- N0 · B1–B3 팔 · 둘째 팔 · 자동 후속 제출 (`F8/README.md` L22 · L26).
- 재시도 · resume · requeue · 체크포인트 이어 돌리기 (`P8/README.md` L29).
- NP · 덱 · 길이 · 허용폭을 속도나 결과에 맞춰 바꾸기.
- 옛 런처 · 옛 정책 · raw sbatch 로 내기 (`F8/inventory.md` L30 · `F8/commands.txt` L26).
- dev7 · dev7_v26 폴더에 쓰기 (Q5).
- ibb 의 기존 체크아웃을 pull · checkout 하기. 09-21 층상 런 폴더가 그 체크아웃 안에 있고 (out/ `fields.txt` L74), 가지 이름 없이 한 커밋에 놓여 있다 (떨어진 HEAD 로 읽힘 [추정] · `baseline_table.md` 7 절). pilot 소스는 새 폴더에 따로 놓는다.
- E0 의 값으로 과학 문장 쓰기 (코팅 · 분산 · 응집). 이 팔은 기준 · 로그 · I/O 자격용이다.
- 강성 축 등록의 E0 진단 (접촉 겹침 1 %) 판정. first8 문서에 그 기준이 묶여 있지 않다 → 13 절 Q10.
- 확인 18 런 · DEV 자료 · 맹검 금고 열기.

## 11. 한정

- 시간 실측은 다른 덱 (옛 밀도 세대 · 기본 형식 덤프 · 옛 러너) 의 것이다. pilot 의 시간은 [추정] 이다.
- 크기는 런별 실측이 없다. 5 절은 폴더 평균 [추정] 과 산술 상한이다.
- 실측 열 런은 seed 세 개 · 한 번씩이다. 분포가 아니다.
- 통과해도 물리 자격 · NP 20 인증 · 다음 팔의 GO 가 아니다 (`F8/README.md` L26 · 관측기의 `limitations`).
- 로그 조건 일치는 종료 코드 · rank · 바이너리 신원의 증명이 아니다 (`P8/README.md` L35).
- 7-3 은 다른 런의 로그 줄로 본 관찰이다. 실제 pilot 로그로 확인한 것이 아니다.
- 가드 · 러너는 가짜 sbatch 와 모의 프로세스로만 시험됐다 (`F8/README.md` L30 · L34).
- 운영 봉인 (`F8/source_seal.json`) 은 지금 HEAD 와 두 파일이 다르다 (생성기 · 되읽기. 본 세션 sha256 대조 · `docs/reviews/mixer_inactive_preparation_20261109/README.md` L17). 어느 묶음으로 낼지는 봉인 단계 + 1저자다.

## 12. 내부 반박 리뷰가 볼 것 (Q7 — 블록 + 기준 표 + 봉인 묶음을 실행 전에 한 번에)

| # | 볼 것 | 왜 |
|---|---|---|
| 1 | 7-3 의 재현 — 관측기 로그 계약에 실제 꼴 줄을 넣어 본다. 덤프 머리 등 다른 실제 형식도 같은 식으로 본다 | 통과 정의가 닿을 수 없는 등록이 되면 안 된다 |
| 2 | 경로 꼴 — HOME 이 심볼릭 링크를 지난다 (out/ `walk.txt` L77). 가드는 풀린 경로와 대조한다 (`F8/submit_one.py.txt` L43–44 · L52 · `F8/job_start.py.txt` L32). 계획 문서의 정본 root 문자열 (`F8/commands.txt` L25 · L69) 은 로그인 꼴이다 | 그대로 적으면 제출이 막힌다 [관찰] |
| 3 | 4 절 산술 — 시작 · 끝 시각 읽는 법 · step 수 · 배수. 다른 덱의 속도를 pilot 에 옮겨도 되는가 | walltime 근거 |
| 4 | 5 절 산술 — 폭 24 · 프레임 수 · 체크포인트 · 1.10 · 상한이 되는 조건 셋. Lustre 는 집계 여유와 OST 여유가 다르다 | 바닥 · 상한 근거 |
| 5 | S5 의 30 분 · S6 의 "입자 소실" 읽는 법이 계획 문서 범위 안인가 | 새 기준을 만들지 않았는지 |
| 6 | 라이브러리 29 개에 해시가 없다 (out/ `hashes.txt` L475–504). 봉인 묶음의 binary / MPI 행이 무엇을 고정하는가 | 신원의 빈 곳 |
| 7 | Python 판 — ibb 3.10.20 (numpy 2.2.6) · 3.9.13 ↔ 시험 판 3.8.20 · 3.11.17 · 3.12.14 | 가드 · 관측기를 ibb 판에서 돌린 적이 없다 |
| 8 | 운영 봉인과 HEAD 의 차이 · 메타 후보 둘 (1 절) | 어느 소스 핀으로 봉인하는가 |
| 9 | 현장 조회 영수증 (`live_preflight`) 을 누가 · 무엇으로 만드는가. 가드는 참 / 거짓 칸만 읽는다 (`F8/submit_one.py.txt` L123–134) | 손으로 쓴 JSON 의 진위 |
| 10 | 권한 — 바이너리 · conda env 가 그룹 쓰기 가능 (out/ `walk.txt` L75 · L79–82). HOME 은 700 | 변경 통제가 정해져 있지 않다 |
| 11 | DEV 와 다른 러너 줄 (노드 1 고정 · conda activate 없음 · 절대 경로 mpirun) 에서 라이브러리 · 런타임이 풀리는가 | 처음 쓰는 조합 |
| 12 | 메타 수집 블록 자체 — 가림 한계 (낱말 경계) · `-h` 가 로그인 노드에서 MPI 를 띄운 흔적 (out/ `fields.txt` L489) | Q7 의 "이 블록" |
| 13 | 원장의 열린 믹서 항목이 이 팔에 닿는가 — `MIX-11` · `MXD2-01` · `SELF-62` (open) · `MLA-01`–`03` · `MIP-01` (claimed_fixed) | 한정 종결 범위 |
| 14 | 승인 묶음에 꼭 있어야 하는 영수증 — author_go · qualification · mxd2r_disposition · live_preflight · source_manifest · policy · runner · binary · mpi_launcher (`F8/submit_one.py.txt` L113) · D0.7 종료 확인 칸 (L127) | 빠진 것이 없는지 |

## 13. 1저자가 정할 것 (질문 + 권고 한 줄)

| Q | 질문 | 권고 |
|---|---|---|
| Q1 | walltime 을 `1-00:00:00` 으로 할까요? | 예 — 가장 느린 실측 속도로 4.9 h, 여유 4.9 배. 재시도 없는 한 팔이라 시간 초과가 더 비싸다 |
| Q2 | 디스크 수치 (런 폴더 상한 29.27 GB · 여유 바닥 32.2 GB · inode 바닥 1,250) 를 등록값으로 할까요? | 9 절 q1–q3 로 프레임 실측을 받아 한 번 확인한 뒤 등록 — 지금 값은 실측이 아니라 산술 상한이다 |
| Q3 | 멈춤 문턱을 "30 분 동안 새 프레임 0" 으로 할까요? | 예 — 예상 프레임 간격 (≤ 16 초) 의 100 배 남짓. 감시 간격은 10 분 이하로 |
| Q4 | 런 폴더: first8 제안 이름 그대로 발사 때 새로 만들고, 봉인 묶음의 경로는 풀린 꼴 (`<HOME_REAL>/…`) 로 통일할까요? | 예 — 가드가 풀린 경로와 대조한다 |
| Q5 | 관측기 로그 계약의 어긋남 (7-3) 을 발사 전에 고칠까요? | 예 — 시험 먼저 (실제 꼴 줄을 fixture 로) → 고침 → 재봉인 → 내부 반박 리뷰 범위에 넣는다. 런 뒤에 판독기를 고치는 것은 피한다 |
| Q6 | 9 절의 읽기 전용 조회 여덟 줄 (sacct 포함) 을 승인할까요? | 예 — 런별 크기 · 기본 한도 · 라이브러리 해시가 여기서만 나온다 |
| Q7 | 어느 소스 묶음으로 봉인할까요? (원 봉인 + 원 메타 / 현재 소스 후보 + 새 메타) | 현재 소스 후보 쪽 + Q5 고침 — HEAD 소스와 맞는 쪽이다. 운영 봉인 교체는 1저자 별도 승인 사항이다 |
| Q8 | 전 덤프 (약 29 GB) 를 로컬로 다 가져올까요? | 계획 문서대로 전부 — 먼저 로컬 여유 ≥ 32.2 GB 를 확인 |
| Q9 | 성능 · 자원에 합격선을 둘까요? | 두지 않는다 — 실측을 보고만 하고 다음 팔 시간표의 입력으로 쓴다 |
| Q10 | 이 팔에서 접촉 겹침 (강성 축 등록의 1 %) 을 잴까요? | 이 팔의 판정에는 넣지 않는다 — 재려면 보고 전용 항목으로 따로 등록 (도구의 새 밀도 세대 지원은 원장 `MXD2-01` open) |

## 14. 근거 목록

| 묶음 | 파일 |
|---|---|
| 받은 메타 | `docs/data/mixer_e0_meta_ibb_20261110/README.md` · 같은 폴더 `out/` (fields.txt · probes.txt · hashes.txt · seal_extract.txt · walk.txt · slurm_* · df_* · lfs_quota_home.txt · mix1_du.txt · mix2_du.txt · mix3_du.txt · mix2_run*_ls.txt · mix3_run*_ls.txt) |
| 계획 | `docs/reviews/nonrint_first_link_20261109/mixer_ibb_fixed_qualification_plan.md` · `docs/reviews/nonrint_approved_preparation_20261109/mixer_ibb_qualification_receipt_plan.md` · `docs/reviews/mixer_qualification_plan_20261110.md` (원격 가지 판) |
| first8 | `docs/reviews/mixer_first8_launch_preparation_20261106/` (README.md · inventory.md · commands.txt · blockers.json · submit_one.py.txt · job_start.py.txt · run_one.sbatch.txt · source_seal.json · planned_assets/) · `docs/reviews/mixer_precal_first8_preparation_20261104/README.md` · `docs/reviews/mixer_precal_exploration_registration_draft_20261104.md` · `docs/reviews/mixer_inactive_preparation_20261109/` |
| DEV 덱 · 기록 | `docs/data/mixer_highbo_dev_decks_20260930_v26/` · `docs/data/mixer_highbo_dev_decks_20260930/` · `docs/data/mixer_highbo_devbo_prelim_20261003/README.md` · `docs/data/mixer_highbo_devu_prelim_20261006/` |
| 같은 빌드의 실제 로그 (7-3) | `docs/data/mixer_highbo_devu_prelim_20261006/exact_runs/exact_LU212_settled/log.exact` · `docs/data/kg50_d07_end_20261105/kg50_d07_b50_log_main1103.liggghts` · `docs/data/kg50_d07_end_20261105/kg50_d07_b50_log_ins1.liggghts` |
| 코드 | `scripts/mixer_precal_observe.py` · `scripts/mixer_stage_gate.py` · `dem_scripts/mixer_20260921/launch_highbo.sh` |
| 결정 기록 | `docs/session_20260923_progress.md` L1423 · L1428 · L1430 |

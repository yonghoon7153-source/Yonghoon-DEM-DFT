"""Replay delivered fixed input bytes through prior/candidate local Python CLIs."""
from pathlib import Path
import hashlib,json,subprocess,sys
r=Path(__file__).resolve().parent
p=r/'package'
src=p/'docs/reviews/mxd2r_r01_recheck_20261106/evidence'
records=[]
for case in ['max_layered','max_uniform','nearmax_layered']:
    d=r/'evidence/delivered_replay'/case;d.mkdir(parents=True,exist_ok=True)
    inputs={}
    for name in ['old.in','new.in','old.json','new.json']:
        a=(src/'red_cli'/case/name).read_bytes();b=(src/'green_cli'/case/name).read_bytes()
        assert a==b
        (d/name).write_bytes(a)
        inputs[name]={'bytes':len(a),'sha256':hashlib.sha256(a).hexdigest(),'red_green_equal':True}
    commands={
       'readback':['mixer_deck_readback.py','--d2',str(d/'old.in'),str(d/'old.json')],
       'pair':['mixer_deck_diff.py',str(d/'old.in'),str(d/'new.in'),'--allow','D2','--meta-ref',str(d/'old.json'),'--meta-new',str(d/'new.json')],
       'plan':['mixer_smoke_blind.py','--d2-plan',str(d/'old.in'),'--d2-meta',str(d/'old.json')]}
    row={'case':case,'inputs':inputs,'runs':{}}
    for version,source in [('before',r/'scratch/before/scripts'),('candidate',p/'scripts')]:
        row['runs'][version]={}
        for k,args in commands.items():
            out=subprocess.run([sys.executable,'-I','-B','-X','utf8',str(source/args[0])]+args[1:],capture_output=True,timeout=20)
            (d/(version+'_'+k+'.stdout')).write_bytes(out.stdout)
            (d/(version+'_'+k+'.stderr')).write_bytes(out.stderr)
            row['runs'][version][k]={'rc':out.returncode,'stdout':out.stdout.decode('utf-8'),'stderr':out.stderr.decode('utf-8')}
            expected=1 if version=='candidate' and case=='max_layered' else 0
            assert out.returncode==expected
            if expected:assert b'insB seed 2147483659: outside 1..2147483647' in out.stdout
    records.append(row)
(r/'evidence/delivered_replay.json').write_text(json.dumps(records,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({x['case']:{v:{k:w['rc'] for k,w in runs.items()} for v,runs in x['runs'].items()} for x in records},indent=2))

# recheck2 RCP3-04 ② 재현 (unshare -pf --mount-proc --kill-child bash ce06b_demo.sh <작업 폴더> <옛 트리 scripts (run_contract · payload = 0ac6edf3c)> <새 트리 scripts> <TMPDIR>)
# 부르는 쪽이 GIT_CONFIG_GLOBAL=/dev/null 로 전역 설정을 끈 채 run_contract --selftest — 옛 판 (env 물려받음) ↔ 새 판 (GIT_ 전부 지움) 의 전역 훅 실행 수.
set -u
W=$1; OLD=$2; NEW=$3; T=$4
mkdir -p $W/hooks $W/home $W/marks
for h in pre-commit post-commit; do printf '#!/bin/sh\necho x >> %s/marks/%s\n' "$W" "$h" > $W/hooks/$h; chmod 755 $W/hooks/$h; done
printf '[core]\n\thooksPath = %s/hooks\n' "$W" > $W<HOME>
for side in old new; do
  rm -f $W/marks/*
  if [ $side = old ]; then S=$OLD; else S=$NEW; fi
  ( cd $W && env -i PATH="$PATH" HOME=$W/home TMPDIR=$T GIT_CONFIG_GLOBAL=/dev/null python3 $S/run_contract.py --selftest > $W/out_$side.txt 2>&1 )
  echo "$side · rc $? · 훅 실행: pre=$(cat $W/marks/pre-commit 2>/dev/null | wc -l) post=$(cat $W/marks/post-commit 2>/dev/null | wc -l)"
done

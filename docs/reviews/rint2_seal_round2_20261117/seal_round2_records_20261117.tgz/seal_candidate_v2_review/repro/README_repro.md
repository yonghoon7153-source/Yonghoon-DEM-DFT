# 재현 (scratch · python3 -I · Python 3.11.18 · git 2.43.0 · flock 2.39.3)

사본 만들기 (지운 뒤 다시):
    R=<이 폴더>; git clone -q --shared --no-checkout /home/user/Yonghoon-DEM-DFT $R/clone
    git -C $R/clone fetch -q <후보>/seal_form_Gprime_20261117.bundle refs/heads/seal-form-scratch:refs/heads/seal-form-scratch
    (원격 추적 ref: git -C $R/clone symbolic-ref --delete refs/remotes/origin/HEAD; for-each-ref refs/remotes → update-ref delete;
     git -C $R/clone fetch -q --no-tags /home/user/Yonghoon-DEM-DFT '+refs/remotes/origin/*:refs/remotes/origin/*')
    sparse 꼴 = repro/sparse-checkout.txt (git -C $R/clone sparse-checkout init --no-cone · 그 파일을 .git/info/sparse-checkout 로 · checkout seal-form-scratch)

| 폴더 | 무엇 | 결과 |
|---|---|---|
| a_tool/ | make_sealed_copy 같은 입력 두 번 · 변이 34 (mutate.py) · selftest | result = mutate_result.txt · selftest.txt |
| b_plan_bytes/ | 계획 한 바이트 (끝 줄바꿈 · indent 2 · 1.0e-12 · 값) → check-doc · check_plan_registered | result.txt |
| c_default/ | --registration 빼기 (plan-doc) · 사슬 함수 (봉인본 · 원본 자리) | plandoc_default.txt · chain_functions.txt |
| d_sh_tool/ | 증거 ③ 도구 변이 D0–D10 (mk.sh) | result.txt |
| d_indep/ | ③ 독립 셈 (argparse 없이 · 울타리별) | result.txt |
| e_s0gate/ | S0 단계 2 관문 — 후보 + 틀린 tol_ff · len_law · env_unit (도구로 다시 만든 봉인본 커밋) | result.txt · variant_commits.txt |
| f_boundary/ | 다섯 경로 · 자료 폴더 blob 대조 · 원격 ref 목록 (지금 · 후보 때) | *.txt |
| g_claims/ | claims.json 두 판 json 대조 · 철회값 스윕 (바뀐 파일 83 · sparse 1,479) | result.txt · ban_result.txt (값 가림) |
| h_docrefs/ | check_doc_refs (핀 판) on G′ 존재 나무 (.md 실바이트 · 나머지 빈 파일 · gitfile) | result_Gp.txt · make_exist_tree.py |
| i_discipline/ | check_method_discipline (핀 판) on G′ sparse | summary.txt |
| j_tests/ | K01 · PC18 · PC20 · EP06 · E17 · S16 · C03 · ca_s0_census · ca_ext_z3 · probe6_read (G′) | *.txt |
| k_relay/ | 원장 넘김 흉내 (명령 문서 §3-1b (5) 블록 그대로) · 받는 쪽 창 | result.txt · relay_sim.py |
| num_lines/ | README · 조각의 줄 번호 107 개 대조 | result.txt |

## 지운 사본 다시 만들기
- `pin/` (핀 판 파일 사본 · `num_lines/check_lines.py` 입력) = `git -C <본 리포> show 64e4d213e:<경로>` (사슬 · 등록 R · 명령 문서 · check_* · 러너 · run_contract · carbon_junction · step3_conv_cert · cjunc_store · FAM 등록 · 재검토 수정 계획 · Q9 설계 · ca_s0_census) + stoic-next `b3481336c:docs/reviews/rint2_time_reestimate_20261111/README.md` → `pin/reest3_README.md`.
- `a_tool/in/` = pin_reg.md · pin_cmd.md (위 git show) · reg_ins.md · cmd_ins.md (= 봉인 꼴 커밋 `docs/reviews/rint2_seal_20261120/tools/` 의 두 조각) · plan.json (= 커밋 `docs/data/rint2_r_plan_20261120/ca1_plan.json`) · s0.json (= 커밋 `docs/data/rint2_s0_sbe_20261116/files/ca1_s0_sbe_20261116T004809Z_q14final/cjunc_plan.json`) · `a_tool/tool.py` = 커밋 `tools/make_sealed_copy.py` (sha256 ebf95e0d…).
- `d_sh_tool/` 변이 문서 = `mk.sh` 위 파이썬 블록 (REVIEW P2-1 표의 바꿈) · 도구 = 커밋 `evidence/tools/check_sh_commands.py`.

#!/usr/bin/env python3
"""정독 근거 파일 (batch_NN_findings.md) 을 질문 (a-n · 카드 문제) 별로 묶는다.
쓰기: synth/q_<letter>.md · synth/q_cards.md · synth/merge_report.txt
원문 줄을 그대로 옮긴다 (요약 없음) — 절 머리마다 출처 배치 표지를 붙인다."""
import re, sys, glob, os, collections
src = sys.argv[1]; out = sys.argv[2]
files = sorted(glob.glob(os.path.join(src, 'batch_*_findings.md')))
l3 = os.path.join(src, 'layer3_findings.md')
if os.path.exists(l3): files.append(l3)
head = re.compile(r'^## +(.*)$')
def key_of(title):
    t = title.strip()
    m = re.match(r'^([a-n])(?:\.|\s|$)', t)
    if m: return m.group(1)
    if t.startswith('카드') or t.startswith('비교 문서'): return 'cards'
    return None
buckets = collections.OrderedDict()
report = []
for f in files:
    b = os.path.basename(f).replace('_findings.md', '')
    part = 'm3'
    mb = re.match(r'batch_(\d+)$', b)
    if mb: part = 'm1' if int(mb.group(1)) <= 8 else ('m2' if int(mb.group(1)) <= 19 else 'm3')
    cur = None; pre = []; seen = []
    nbytes = collections.Counter()
    for line in open(f, encoding='utf-8'):
        m = head.match(line)
        if m:
            k = key_of(m.group(1))
            if k is None:
                report.append('UNCLASSIFIED %s | %s' % (b, line.strip()))
                cur = 'other'
            else:
                cur = k
            seen.append(cur)
            buckets.setdefault(cur, []).append('\n### [%s] %s\n' % (b, m.group(1).strip()))
            if cur == 'm': buckets.setdefault(part, []).append('\n### [%s] %s\n' % (b, m.group(1).strip()))
            continue
        if cur is None:
            pre.append(line); continue
        buckets[cur].append(line)
        if cur == 'm': buckets[part].append(line)
        nbytes[cur] += len(line.encode('utf-8'))
    report.append('%s sections=%s pre_lines=%d' % (b, ''.join(s if len(s) == 1 else '[' + s + ']' for s in seen), len(pre)))
os.makedirs(out, exist_ok=True)
tot_in = sum(os.path.getsize(f) for f in files); tot_out = 0
for k, lines in buckets.items():
    p = os.path.join(out, 'q_%s.md' % k)
    with open(p, 'w', encoding='utf-8') as w:
        w.write('# 질문 %s — 배치별 근거 묶음 (원문 줄 그대로 · 파일 %d 개)\n' % (k, len(files)))
        w.writelines(lines)
    sz = os.path.getsize(p)
    if k not in ('m1', 'm2', 'm3'): tot_out += sz
    report.append('q_%s.md %d B' % (k, sz))
report.append('files=%d in_bytes=%d out_bytes=%d' % (len(files), tot_in, tot_out))
open(os.path.join(out, 'merge_report.txt'), 'w', encoding='utf-8').write('\n'.join(report) + '\n')
print('\n'.join(r for r in report if not r.startswith('batch_')))

#!/usr/bin/env python3
"""5 회차 내부 반박 리뷰 (Codex 아님) — 작은 해석 반례 (임시 폴더 · 읽기만 · 리포 무관 · LIGGGHTS 없음).

쓰는 법: python3 -I sr5_counterexamples.py <키트 사본 폴더 (ul_lib.py 가 있는 곳)>
  [P] 경로 규칙 (A 15-5 (i) 글자 같음 + (ii) 양쪽 realpath) — 판독기 CLI 가 실제로 하는 os.path.abspath (글자 접기) 를 넣어 다시 셈
  [D] 결합 줄 중복 · sha 꼴 — ul_lib.read_kv (마지막 값만 남김) 로 읽으면 무엇이 되나
  [I] RT 쌍 덤프 ID 열 (c_ul_ph[7] · [8]) — ul_lib.ID_COLS 밖이면 정수 토큰 정확성 (Q4) 이 빠지나
  [W] 15-5b 글 그대로 구현 (전역 W ≤ 0.05 · 쓴 격자 칸별 안쪽 W ≤ 0.5 · 칸마다 안쪽 하중 쌍 ≥ 100 · 위반 먼저) — 경계 · 칸 수 바뀜 · 한쪽 0 행
  [L] B §8 분류표 — f4 모형에 없는 꼴 (N ∉ {200, 40000} · 자동 재큐 · 장부 경로 바꿈)
"""
import math
import os
import random
import sys
import tempfile

KIT = os.path.abspath(sys.argv[1])
sys.path.insert(0, KIT)
import ul_lib  # noqa: E402

out = []


def say(s=''):
    out.append(s)
    print(s)


# ─────────────────────────────────────────────────────────────── [P]
say('[P] 경로 규칙 — 판독기 CLI = os.path.abspath(루트) (ul_reader.py main) · 러너 · LIGGGHTS = OS 물리 해석')


def rule(rec, reader_root, bed, job):
    """A 15-5 PASS 행 (i) + (ii) · 판독기 잡 폴더 = join(abspath(루트), 침대, 잡) (ul_reader.py main 3876 · restore_verdict 1561)."""
    exp = rec['job_dir'] + '/RT1/rt.bin'
    chars = rec['rt1_bin'] == exp and rec['rt2_ckpt'] == exp and rec['log'] == exp
    folder = os.path.join(os.path.abspath(reader_root), bed, job)
    return chars and os.path.realpath(rec['job_dir']) == os.path.realpath(folder), folder


with tempfile.TemporaryDirectory(prefix='sr5_p_', dir=os.path.dirname(os.path.abspath(__file__))) as td:
    lustre = os.path.join(td, 'LUSTRE_HOME')
    home = os.path.join(td, 'HOME')
    os.makedirs(os.path.join(lustre, 'deep', 'sub'))
    os.makedirs(os.path.join(lustre, 'x'))
    os.symlink(lustre, home)                                    # <HOME> -> <LUSTRE_HOME>
    os.symlink(os.path.join(lustre, 'deep', 'sub'), os.path.join(lustre, 'sym'))   # <LUSTRE_HOME>/sym -> deep/sub
    bed, job = 'bed', 'RJ'

    def runner(work_root):
        jd = f'{work_root}/{bed}/{job}'                        # run_unload.sh 141 행 글자
        os.makedirs(jd + '/RT1', exist_ok=True)                 # OS = 물리 해석 (bash mkdir 와 같음)
        open(jd + '/RT1/rt.bin', 'wb').write(b'x')
        return {'job_dir': jd, 'rt1_bin': jd + '/RT1/rt.bin', 'rt2_ckpt': jd + '/RT1/rt.bin', 'log': jd + '/RT1/rt.bin'}

    cases = []
    wr = home + '/w'
    os.makedirs(lustre + '/w', exist_ok=True)
    r = runner(wr)
    cases.append(('정직 · WORK_ROOT 링크 꼴 · 러너 안 판독 (같은 글자)', r, wr, True))
    cases.append(('정직 · 다시 읽기 루트 realpath 꼴', r, os.path.realpath(wr), True))
    wr2 = home + '/w2/'
    os.makedirs(lustre + '/w2', exist_ok=True)
    r2 = runner(wr2)
    cases.append(('정직 · WORK_ROOT 끝 / (JD 에 //)', r2, wr2, True))
    wr3 = home + '/x/../w3'
    os.makedirs(lustre + '/w3', exist_ok=True)
    r3 = runner(wr3)
    cases.append(('정직 · WORK_ROOT 에 .. (실제 폴더 x 아래 · 글자 접기 = 물리)', r3, wr3, True))
    wr4 = home + '/sym/../w4'                                   # sym 아래 .. — 물리 = deep/w4 · 글자 접기 = HOME/w4
    r4 = runner(wr4)
    ok4, f4 = rule(r4, wr4, bed, job)
    phys4 = os.path.realpath(r4['job_dir'])
    lex4 = os.path.realpath(f4)
    cases.append(('정직 · WORK_ROOT 에 심볼릭 아래 .. (러너 = 물리 deep/w4 · 판독기 abspath = HOME/w4)', r4, wr4, True))
    for lab, rec, root, want in cases:
        got, folder = rule(rec, root, bed, job)
        mark = '✓' if got == want else ('✗ (fail-closed · 정직 런 거부)' if want and not got else '✗')
        say(f'  {mark} {lab}: 규칙 {"통과" if got else "거부"} · 기대 {"통과" if want else "거부"}')
    say(f'    └ 심볼릭 아래 .. : 러너가 쓴 실제 폴더 = …/{os.path.relpath(phys4, td)} · 판독기 잡 폴더 = …/{os.path.relpath(lex4, td) if lex4.startswith(td) else lex4} '
        f'(존재 {os.path.isdir(f4)}) — 지금 판독기도 다른 (없는) 폴더를 읽는다 · (ii) 가 SYNTAX_FAIL 로 바꿈 = fail-closed')

# ─────────────────────────────────────────────────────────────── [D]
say('')
say('[D] 결합 줄 중복 · sha 꼴 — ul_lib.read_kv (첫 = 에서 자름 · 같은 키는 마지막 값)')
with tempfile.TemporaryDirectory(prefix='sr5_d_', dir=os.path.dirname(os.path.abspath(__file__))) as td:
    man = os.path.join(td, 'run_manifest.txt')
    open(man, 'w').write('job_dir=/H/w/bed/RJ\nstage=RT1 screen=screen.txt rc=0 check=PASS\n'
                         'rt1_bin=/H/w/bed/RJ.try1/RT1/rt.bin sha256=' + 'a' * 64 + '\n'
                         'rt1_bin=/H/w/bed/RJ/RT1/rt.bin sha256=' + 'b' * 64 + '\n'
                         'rt2_ckpt=/H/w/bed/RJ/RT1/rt.bin sha256=' + 'b' * 64 + '\n'
                         'stage=RT2 screen=screen.txt rc=0 check=PASS\njob_dir=/H/w/bed/RJ\n')
    kv = ul_lib.read_kv(man)
    say(f'  rt1_bin 줄 둘 (앞 = 앞 시도 경로 · 뒤 = 이 잡) → read_kv 값 = {kv.get("rt1_bin")!r} (뒤 줄만 · 앞 줄은 조용히 사라짐)')
    say(f'  job_dir 줄 둘 → read_kv 값 하나 = {kv.get("job_dir")!r} · stage 값 = {kv.get("stage")!r} (마지막 stage 만 · PFA-06 꼴)')
    say('  ⇒ 15-5 는 "치환 줄 정확히 하나" 만 적고 결합 줄 (job_dir · rt1_bin · rt2_ckpt) 의 수 · sha 꼴 (64 소문자 16 진) 은 안 정함')

# ─────────────────────────────────────────────────────────────── [I]
say('')
say(f'[I] RT 쌍 덤프 ID 열 — ul_lib.ID_COLS = {ul_lib.ID_COLS}')


def local_dump(path, cols, rows):
    with open(path, 'w') as f:
        f.write('ITEM: TIMESTEP\n2000\nITEM: NUMBER OF ENTRIES\n%d\nITEM: BOX BOUNDS pp pp ff\n0 0.05\n0 0.05\n-0.01 0.1\n' % len(rows))
        f.write('ITEM: ENTRIES ' + ' '.join(cols) + '\n')
        for r in rows:
            f.write(' '.join(r) + '\n')


with tempfile.TemporaryDirectory(prefix='sr5_i_', dir=os.path.dirname(os.path.abspath(__file__))) as td:
    for name, ncol in (('c_cpl', 26), ('c_ul_ph', 30)):
        cols = [f'{name}[{i}]' for i in range(1, ncol + 1)]
        for tok in ('9007199254740993', '2.0000000000000001', '2.5'):
            row = ['0.001'] * ncol
            row[6], row[7], row[8] = '1', tok, '0'
            p = os.path.join(td, f'{name}_{tok}.dump')
            local_dump(p, cols, [row])
            d = ul_lib.read_dump(p, 'local', cols)
            v = d['rows'][0][f'{name}[8]'] if d['rows'] else None
            eid = ul_lib.exact_id(v) if d['rows'] else None
            acc = d['ok'] and eid is not None
            say(f'  {name}[8] = {tok!r}: read_dump ok={d["ok"]} · 값 {v!r} · exact_id → {eid} · 받아들임={acc}')
    say('  ⇒ c_cpl 이름은 Q4 (정수 토큰 = 정확한 int · 가려진 비정수 거부) 를 받고 c_ul_ph 이름은 float 를 거쳐 2^53+1 → 2^53 · 2.0000000000000001 → 2 로 받아들여진다')

# ─────────────────────────────────────────────────────────────── [W]
say('')
say('[W] 15-5b 글 그대로 (전역 W ≤ 0.05 ∧ N ≥ 100 칸 W_c ≤ 0.5 ∧ 쌍 집합 같음 · 위반 먼저 · 애매 1e-12 L · 칸 = 원쪽 상자 고른 나눔)')


def guard(orig, test, grid, box=((0.0, 0.05), (0.0, 0.05)), nmin=100):
    """orig · test = {key: (xa, ya, xb, yb, |Ft|-벡터)} · 반환 = (판정, 전역 W, 칸 W 최대, 칸 N 최소)."""
    if not orig and not test:
        return 'UNCONFIRMED', None, None, None
    if not orig or not test or not (set(orig) & set(test)):
        return 'VALUE_MISMATCH', None, None, None
    if set(orig) != set(test):
        return 'VALUE_MISMATCH', None, None, None
    (x0, x1), (y0, y1) = box
    lx, ly = x1 - x0, y1 - y0
    P, Q = grid

    def cell(x, y):
        x = x0 + (x - x0) % lx
        y = y0 + (y - y0) % ly
        amb = any(abs(x - (x0 + lx * k / P)) <= 1e-12 * lx for k in range(P + 1)) or any(abs(y - (y0 + ly * k / Q)) <= 1e-12 * ly for k in range(Q + 1))
        return (min(int((x - x0) / lx * P), P - 1), min(int((y - y0) / ly * Q), Q - 1)), amb

    num = den = 0.0
    cn, cd, cnt = {}, {}, {}
    for k, (xa, ya, xb, yb, fo) in orig.items():
        fo_n = math.sqrt(sum(c * c for c in fo))
        ft = test[k][4]
        reset = fo_n > 0 and math.sqrt(sum((a - b) ** 2 for a, b in zip(ft, fo))) > 0.5 * fo_n
        den += fo_n
        num += fo_n if reset else 0.0
        (ca, aa), (cb, ab) = cell(xa, ya), cell(xb, yb)
        if aa or ab or ca != cb or fo_n == 0:
            continue
        cd[ca] = cd.get(ca, 0.0) + fo_n
        cn[ca] = cn.get(ca, 0.0) + (fo_n if reset else 0.0)
        cnt[ca] = cnt.get(ca, 0) + 1
    if den == 0:
        return 'UNCONFIRMED', None, None, None
    W = num / den
    cells = [(i, j) for i in range(P) for j in range(Q)]
    wc = {c: cn[c] / cd[c] for c in cd}
    viol = W > 0.05 or any(cnt.get(c, 0) >= nmin and wc[c] > 0.5 for c in cells)
    short = any(cnt.get(c, 0) < nmin for c in cells)
    status = 'VALUE_MISMATCH' if viol else ('UNCONFIRMED' if short else 'PASS')
    return status, W, max(wc.values()) if wc else None, min(cnt.get(c, 0) for c in cells)


def bed(grid, per_cell, seed=1, box=((0.0, 0.05), (0.0, 0.05)), straddle=0.15):
    """칸마다 안쪽 쌍 per_cell 개 + 칸 경계에 걸친 쌍 (몫 straddle) · |Ft| = 1 (같은 무게)."""
    rnd = random.Random(seed)
    (x0, x1), (y0, y1) = box
    P, Q = grid
    lx, ly = (x1 - x0) / P, (y1 - y0) / Q
    o, k = {}, 0
    for i in range(P):
        for j in range(Q):
            for _ in range(per_cell):
                xa = x0 + (i + 0.1 + 0.8 * rnd.random()) * lx
                ya = y0 + (j + 0.1 + 0.8 * rnd.random()) * ly
                o[k] = (xa, ya, xa + 1e-5, ya, (1.0, 0.0, 0.0))
                k += 1
    nst = int(straddle * len(o))
    for _ in range(nst):
        i = rnd.randrange(1, P) if P > 1 else 0
        xb = x0 + i * lx
        o[k] = (xb - 1e-5, y0 + rnd.random() * (y1 - y0), xb + 1e-5, y0 + rnd.random() * (y1 - y0), (1.0, 0.0, 0.0))
        k += 1
    return o


def lose(o, pred):
    return {k: (v[:4] + ((0.0, 0.0, 0.0),) if pred(k, v) else v) for k, v in o.items()}


def c_of(v, grid, box=((0.0, 0.05), (0.0, 0.05))):
    (x0, x1), (y0, y1) = box
    return (min(int((v[0] - x0) / (x1 - x0) * grid[0]), grid[0] - 1), min(int((v[1] - y0) / (y1 - y0) * grid[1]), grid[1] - 1))


G = (6, 4)
o = bed(G, 120)
tests = []
tests.append(('정직 (값 같음) · 6×4 · 칸마다 120', o, o, G, 'PASS'))
tests.append(('6×4 칸 (2,1) 안쪽 쌍 통째 소실 (전역 W ≈ 1/24 · 0.05 밑)', o, lose(o, lambda k, v: c_of(v, G) == (2, 1) and c_of(v[2:], G) == (2, 1)), G, 'VALUE_MISMATCH'))
tests.append(('칸 경계에 걸친 쌍만 모두 소실 (안쪽 0 · 걸친 몫 0.15/1.15 = 0.13)', o, lose(o, lambda k, v: c_of(v, G) != c_of(v[2:], G)), G, 'VALUE_MISMATCH (전역)'))
o2 = bed(G, 120, straddle=0.04)
tests.append(('칸 경계에 걸친 쌍만 소실 · 걸친 몫 0.04 → 전역 0.038 (주장 안 함 = 15-8)', o2, lose(o2, lambda k, v: c_of(v, G) != c_of(v[2:], G)), G, 'PASS (못 잡음 · 한정 안)'))
tests.append(('칸 (0,0) 안쪽 쌍 정확히 절반 소실 → W_c = 0.5 (≤ 0.5 = 통과 · 15-8 한정 안)', o,
              lose(o, lambda k, v: c_of(v, G) == (0, 0) and c_of(v[2:], G) == (0, 0) and k % 2 == 0), G, 'PASS (못 잡음 · 한정 안)'))
# 읽는 격자 3×2 칸 하나 소실 (교차 NP) = 쓴 6×4 칸 넷 통째
tests.append(('읽는 3×2 칸 하나 소실 (교차 NP · 쓴 6×4 칸 넷 통째)', o,
              lose(o, lambda k, v: c_of(v, (3, 2)) == (1, 0) and c_of(v[2:], (3, 2)) == (1, 0)), G, 'VALUE_MISMATCH'))
G11 = (11, 1)
o11 = bed(G11, 120)
tests.append(('10:0 꼴 쓴 11×1 · 읽는 3×2 칸 하나 소실 (쓴 띠 ≈ 3.7 개 반쪽씩)', o11,
              lose(o11, lambda k, v: c_of(v, (3, 2)) == (0, 0) and c_of(v[2:], (3, 2)) == (0, 0)), G11, 'VALUE_MISMATCH (전역)'))
o99 = bed(G, 99)
tests.append(('칸마다 99 · 정직 → N 하한 못 채움', o99, o99, G, 'UNCONFIRMED'))
tests.append(('칸마다 99 · 칸 하나 통째 소실 → 칸 값 1.0 이지만 N < 100 · 전역 1/24', o99,
              lose(o99, lambda k, v: c_of(v, G) == (3, 3) and c_of(v[2:], G) == (3, 3)), G, 'UNCONFIRMED (칸 하한 밖)'))
tests.append(('한쪽 0 행', o, {}, G, 'VALUE_MISMATCH'))
tests.append(('두 쪽 0 행', {}, {}, G, 'UNCONFIRMED'))
for lab, a, b, g, want in tests:
    st, W, wcmax, nmin = guard(a, b, g)
    fmt = (lambda x: 'None' if x is None else f'{x:.4f}')
    say(f'  {lab}: {st} · 전역 W {fmt(W)} · 칸 W 최대 {fmt(wcmax)} · 칸 N 최소 {nmin} · 기대 {want}')

# ─────────────────────────────────────────────────────────────── [L]
say('')
say('[L] B §8 분류표 — f4 모형 (n ≠ 40000 = 건식) 에 없는 꼴 · 등록 글 = "n 40000 = 셈 · n 200 = 건식"')
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)) + '/rerun')
import importlib.util  # noqa: E402
spec = importlib.util.spec_from_file_location('f4', os.path.join(os.path.dirname(os.path.abspath(__file__)), 'rerun', 'f4_ledger_rule.py'))
import io  # noqa: E402
import contextlib  # noqa: E402
f4 = importlib.util.module_from_spec(spec)
with contextlib.redirect_stdout(io.StringIO()):
    spec.loader.exec_module(f4)
S = 'start'
extra = [
    ('N 39900 MPI 꼴 런 (등록 밖 N · 실행기 N 규칙 = 200 이상 100 의 배수라 받음) 뒤 N 40000 시도',
     [('e1', 'g2cp_mpi4', S, '0:0'), ('s1', 'g2cp_mpi4', S, '0:0')], [f4.A('e1', 4, 39900), f4.A('s1', 4, 40000)], {'s1'},
     '등록 글 = 분류 없음 · f4 모형 = 건식 (셈 밖) → 결과 본 런이 셈에서 빠짐'),
    ('자동 재큐 (NODE_FAIL · 같은 잡 번호로 다시 돎) — attempt 둘',
     [('s1', 'g2cp_mpi2', S, '0:0')], [f4.A('s1', 2, 40000), f4.A('s1', 2, 40000)], {'s1'}, '어긋남 → 결론 없음 (fail-closed · 정직 흐름)'),
    ('장부 경로 바꿈 (G2CP_LEDGER=다른 파일) + 잡 이름 바꿈 — 그 런은 장부 · sacct 이름 목록 둘 다 밖',
     [('s1', 'g2cp_mpi4', S, '0:0')], [f4.A('s1', 4, 40000)], {'s1'}, '결론 섬 = 숨은 시도 (손 조작 꼴 · 한정 문장에 없음)'),
]
for lab, sacct, ledger, ret, note in extra:
    got, cls, n = f4.verdict(sacct, ledger, ret)
    say(f'  {lab}: f4 모형 = {got} · 분류 {cls} · N 40000 시도 {n} — {note}')

with open(os.path.join(os.path.dirname(os.path.abspath(__file__)), 'sr5_counterexamples_out.txt'), 'w') as f:
    f.write('\n'.join(out) + '\n')

"""우선 규칙 (BRIEF 2-3 + 덧붙임 트랙) — wishlist · 대기열 공용.  근거는 '왜' 칸 글자만 본다.

순서: ① A 조건 → A  ② 아니면 '흐름 밖' 표지 → C  ③ 아니면 방법 원전 → B  ④ 나머지 → C (배경).
A 조건 (트랙 순서 = 덧붙임 11-16):
  R  Rint ② : Rint · SE–SE 계면 · 입계 · 계면 저항 · σ₀ · 탄소 접합 · SDCP · PTFE 막/개구/절연
  U  언로딩   : 질문 b · 단계 6 · U3 · U4 · R4 · 탈압 · 되돌아(옴)
  D  믹서 D3  : D3 · 유동성 · Bo · (믹서 맥락 ∧ 응집/점착/접착/agglomerat/adhesion) · SE–SE 접착/점착
  S  순수 SE  : 질문 a (왜 칸이 재료를 SE 아님 · 목재 · 폭약으로 적으면 빼고) · 순수 SE · 진밀도 · 1.64
  P  수영 단계 0–3 : 단계 0 · 1 · 2 · 3 · 단위 시험 U0 · U1 · U2 · U5 · U6 (READING_BRIEF 3 절: 단위 시험 = 단계 2 의 일)
  X  두 배치 이상 : wishlist 의 [n] 줄을 낸 배치가 둘 이상 ('참고 · 후보로 세지 않음' 줄은 세지 않는다)
B (방법 원전): 질문 e · f · g · h · k · l · 후보 이름 (A · A′ · A′-0 · B · C · C′ · D0 · M0) ·
   질문 c 가운데 왜 칸이 방법 · 식 · 장치 · 정의 · 측정법의 원전이라 적은 것 (값 출처만이면 C).
"""
import re

LET = re.compile(r"(?<![A-Za-z0-9가-힣_′])([a-n])(?![A-Za-z0-9가-힣_′])")


def letters(why):
    """왜 칸 머리 (첫 ' — ' 앞) 의 질문 글자 + '질문 x · y' 꼴의 글자."""
    head = why.split(" — ")[0]
    head = re.sub(r"`[^`]*`", " ", head)
    out = set(LET.findall(head))
    for m in re.finditer(r"질문 ([a-n](?:\s*·\s*[a-n])*)", why):
        out |= set(re.findall(r"[a-n]", m.group(1)))
    m = re.search(r"·\s*([a-n])\s*\(구조 역학\)", why)  # '흐름 밖: … · d (구조 역학)' 꼴
    if m:
        out.add(m.group(1))
    m = re.search(r"결과 전 대조 항목\s*·\s*([a-n])\b", why)
    if m:
        out.add(m.group(1))
    return out


R_PAT = re.compile(r"Rint|SE–SE 계면|입계|계면 저항|σ₀|탄소 접합|SDCP|PTFE[^—|]{0,25}(막 개구|개구|절연|피복)")
U_PAT = re.compile(r"단계 6|단계 5 · 6|단계 5–6|\bU3\b|\bU4\b|\bR4\b|탈압|되돌아")
D_DIRECT = re.compile(r"D3|유동성|\bBo\b|SE–SE 접착|SE–SE 점착")
D_MIX = re.compile(r"믹서|믹싱|혼합|dev-u|이종기술")
D_COH = re.compile(r"응집|점착|접착|agglomerat|adhesion|붙는")
S_PAT = re.compile(r"순수 SE|진밀도|1\.64")
NOT_SE = re.compile(r"SE 아님|목재|폭약")
P_PAT = re.compile(r"단계 [0-3](?![0-9–])|\bU[0-2]\b|\bU[56]\b")
CAND = re.compile(r"후보 (A′-0|A′|A|B|C′|C|D0|M0)(?![A-Za-z0-9])")
METHOD_C = re.compile(r"원전|방법|재는 법|장치|해석법|측정법|정의|식 \(|식의")


def classify(why_all, n_batches, flow_out_override=None):
    """why_all = 같은 논문 항목들의 왜 칸 (이어 붙임).  반환 (등급, 트리거 문자열)."""
    lets = letters(why_all) if isinstance(why_all, str) else set()
    trig = []
    if R_PAT.search(why_all):
        trig.append("R")
    if "b" in lets or U_PAT.search(why_all):
        trig.append("U")
    if D_DIRECT.search(why_all) or (D_MIX.search(why_all) and D_COH.search(why_all)):
        trig.append("D")
    if ("a" in lets and not NOT_SE.search(why_all)) or S_PAT.search(why_all):
        trig.append("S")
    if P_PAT.search(why_all):
        trig.append("P")
    if n_batches >= 2:
        trig.append("X")
    if trig:
        return "A", trig, lets
    flow_out = ("흐름 밖" in why_all) if flow_out_override is None else flow_out_override
    if flow_out:
        return "C", ["흐름 밖"], lets
    b_lets = sorted(lets & set("efghkl"))
    cands = sorted(set(CAND.findall(why_all)))
    if b_lets or cands:
        return "B", b_lets + ["후보 " + c for c in cands], lets
    if "c" in lets and METHOD_C.search(why_all):
        return "B", ["c 방법"], lets
    return "C", ["배경"], lets


GROUP_NAME = {
    "R": "Rint ② (SE–SE · 입계 · 계면 저항 · PTFE 막)",
    "U": "언로딩 (탈압 · 되돌아옴 · 단계 6 · U3 · U4)",
    "D": "믹서 D3 · 응집 (SE 유동성 · 점착)",
    "S": "순수 SE 기준 (질문 a · 진밀도)",
    "P": "[DEM 우선 (수영)] 단계 0–3 · 단위 시험",
    "X": "두 배치 이상이 요청",
}
ORDER = ["R", "U", "D", "S", "P", "X"]

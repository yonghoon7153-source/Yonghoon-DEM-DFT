#!/usr/bin/env python3
"""스크래치 (커밋 안 함) — s0_store_probe.py 감싸개를 S0 시험 픽스처 킷 (test_ca_s0_census.write_kit · kit_A) 에서 돌려 본다:
감싸개 없이 돈 S0 단계 1 과 산출이 같은가 (보고 JSON 잎 · 계획 바이트 · 배열) · 재기 기록 (지어 씀 → 적중 · 같음).
  python3 try_probe.py <작업 트리> <작업 폴더 (새로)> [감싸개 경로]"""
import json
import os
import subprocess
import sys
import zipfile

import numpy as np

tree, wd = os.path.abspath(sys.argv[1]), os.path.abspath(sys.argv[2])
scripts = os.path.join(tree, 'scripts')
here = os.path.dirname(os.path.abspath(__file__))
wrapper = os.path.abspath(sys.argv[3]) if len(sys.argv) > 3 else os.path.join(here, 's0_store_probe.py')
sys.path.insert(0, scripts)
import test_ca_s0_census as T                                    # noqa: E402 — 픽스처 킷 작성기 (사본 없음)

os.makedirs(wd)
kit = T.write_kit(wd, 'kit_J', vgcf=T._kit_j_fibres(), ptfe=[T.J_PTFE], vol={'VGCF': 0.05, 'PTFE': 0.1})   # instance 있는 킷 (VV · 자기 · PTFE 덮임)
s0 = os.path.join(scripts, 'ca_s0_census.py')
common = ['--stage', '1', '--kit', kit, '--vox', str(T.VOX)]
out, outP, outW = os.path.join(wd, 'out'), os.path.join(wd, 'outP'), os.path.join(wd, 'outW')   # 같은 --out 자리로 차례로 (argv 지문에 경로가 든다)
store, log = os.path.join(wd, 'store'), os.path.join(wd, 'probe_log')
os.makedirs(store)
os.chmod(store, 0o755)
rP = subprocess.run([sys.executable, s0, *common, '--out', out], capture_output=True, text=True, cwd=wd)
os.rename(out, outP)
rW = subprocess.run([sys.executable, wrapper, log, store, s0, *common, '--out', out], capture_output=True,
                    text=True, cwd=wd)
os.rename(out, outW)
print('rc plain', rP.returncode, '· rc probe', rW.returncode)
print('probe stderr:', [ln for ln in rW.stderr.splitlines() if 'store-probe' in ln])


def leaves(a, b, p='$', out=None):
    out = [] if out is None else out
    if type(a) is not type(b):
        out.append((p, 'type'))
    elif isinstance(a, dict):
        for k in sorted(set(a) | set(b), key=str):
            if k not in a or k not in b:
                out.append((f'{p}.{k}', 'missing'))
            else:
                leaves(a[k], b[k], f'{p}.{k}', out)
    elif isinstance(a, list):
        if len(a) != len(b):
            out.append((p, 'len'))
        else:
            for i, (x, y) in enumerate(zip(a, b)):
                leaves(x, y, f'{p}[{i}]', out)
    elif a != b:
        out.append((p, f'{str(a)[:60]} ↔ {str(b)[:60]}'))
    return out


files = sorted(os.listdir(outP))
print('outputs plain', files, '· probe', sorted(os.listdir(outW)))
for fn in files:
    a, b = os.path.join(outP, fn), os.path.join(outW, fn)
    if fn.endswith('.json'):
        d = leaves(json.load(open(a, encoding='utf-8')), json.load(open(b, encoding='utf-8')))
        print(f'  {fn}: 다른 잎 {len(d)}', d[:12])
    elif fn.endswith('.npz'):
        za, zb = np.load(a, allow_pickle=False), np.load(b, allow_pickle=False)
        same = sorted(za.files) == sorted(zb.files) and all(za[k].dtype == zb[k].dtype and za[k].shape == zb[k].shape
                                                            and za[k].tobytes() == zb[k].tobytes() for k in za.files)
        print(f'  {fn}: 배열 같음 {same}')
    else:
        print(f'  {fn}: 바이트 같음 {open(a, "rb").read() == open(b, "rb").read()}')
rec = json.load(open(os.path.join(log, 'store_probe.json'), encoding='utf-8'))
print(json.dumps(rec, ensure_ascii=False, indent=1)[:3000])
print('store files', sorted(os.listdir(store)))

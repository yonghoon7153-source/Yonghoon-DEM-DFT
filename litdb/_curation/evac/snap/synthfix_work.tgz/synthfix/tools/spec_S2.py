# V_S2.md 문제 1–9 → S2_material_loadshare_contactlaw.md
V = 'V_S2'
D = 'S2'
PYC = 'pycompact2025_dem_mpfem_workflow'

ROW35_END = '[b12 · so2021_dem_mold_pressure_assb_coldpress · §3 (L28 · L36–37) · §5 Fig 4c · 5 · 6 (L75–77)] |\n\n## 빈 곳'
ROW36 = ('| 36 | So 계열 항복 캡의 맞춘 값 수 | 카드 표 (비국소 카드 · So 원문 미열람) \'경도 항복 캡 (So 2021) 0 (H = 물성)\' ↔ '
         'So 2022 MethodsX 맞춘 값 3 개 (c_area · c_spring · h_ov^max) ↔ So 2021 제조 α 1 개 (카드 셈 4 개 보정 / 물리 인자) '
         '| E-47 · E-49 · E-100 | [b05 · gonzalez2012_nonlocal_contact_confined_granular · §10.2 표 (L587–594)] '
         '[b07 · so2022_dem_contact_model_assb_compaction_sintering · §3 표 (L30–39)] '
         '[b29 · so2021_dem_fabrication_degradation_ductile_particles · Table I L58–68] |')

EDITS = [
    # ── 문제 1 · D-46
    dict(doc=D, v=V, num=1, item='D-46 (값)', kind='값 다름 (카드 11-11 재판독)', line=r'^\| D-46 \|',
         old='응력 개시 ε ≈ 0.365 (Coarse) / 0.285 (Fine)',
         new='응력 개시 ε ≈ 0.371 (Coarse) / 0.287 (Fine) (2026-11-11 재판독 · 옛 판독 0.365 / 0.285)',
         note='카드 대조: pycompact2025 §9.4 L582 "응력 개시 ε ≈ 0.371 / 0.287" 맞음'),
    dict(doc=D, v=V, num=1, item='D-46 (꼬리)', kind='위치 틀림 (카드 줄 이동)', line=r'^\| D-46 \|',
         old='[b02 · ' + PYC + ' · §9.4 (L403–405) · Fig 4a]',
         new='[b02 · ' + PYC + ' · §9.4 (현 카드 L579–594) · Fig 4a]',
         note='카드 §9.4 = L579–594 맞음'),
    # ── 문제 2 · 요지 9 줄 + 어긋남 36 새 행 + 셈
    dict(doc=D, v=V, num=2, item='요지 9 줄', kind='넓게 말함 · 어긋남 빠짐',
         old='- 맞춘 값 수: 항복 캡 (Thornton–Ning p_y · So H) 0 (물성) · 다접촉 β 1 · MC-strain γ 1 · 비국소 0 · MDR 법칙 상수 2 (전 재료 공통) 이나 DEM 전체 자유 값 6–8 · EEPA 5 · 우리 연화 1 · 비교 문서: "부호가 맞고 자유변수가 0 인 것은 항복캡뿐" · "18× 연화 = 빠진 항복캡의 대역" (E-43 · E-52–E-55 · E-59 · E-60 · E-62 · E-100 · E-101).',
         new='- 맞춘 값 수: Thornton–Ning p_y 0 (재료 값) · So 계열 H 는 물성이나 구현마다 보조 맞춤 1–3 개 (MethodsX c_area · c_spring · h_ov^max 3 · 2021 제조 α 1 — 어긋남 36) · 다접촉 β 1 · MC-strain γ 1 · 비국소 0 · MDR 법칙 상수 2 (전 재료 공통) 이나 DEM 전체 자유 값 6–8 · EEPA 매개변수 5 (Thakur 3 개 스윕 · Yano 침대 맞춤 0) · 우리 연화 1 · 비교 문서: "부호가 맞고 자유변수가 0 인 것은 항복캡뿐" · "18× 연화 = 빠진 항복캡의 대역" (E-43 · E-47 · E-49 · E-52–E-55 · E-59 · E-60 · E-62 · E-65 · E-100 · E-101).',
         note='문서 안 E-43 · E-47 · E-49 · E-62 · E-65 와 맞음'),
    dict(doc=D, v=V, num=2, item='어긋남 36 (새 행)', kind='넓게 말함 · 어긋남 빠짐', multiline=True, cells_change=True,
         old=ROW35_END,
         new=ROW35_END.replace('\n\n## 빈 곳', '\n' + ROW36 + '\n\n## 빈 곳'),
         note='검증이 준 새 행 그대로 (칸 구분 "\\|" → "|") · 꼬리 셋은 E-100 · E-47 · E-49 의 꼬리에 이미 있는 위치'),
    dict(doc=D, v=V, num=2, item='읽은 범위와 셈 (어긋남 개수)', kind='넓게 말함 · 어긋남 빠짐',
         old='= 243 · 어긋남 35 · 빈 곳 12.',
         new='= 243 · 어긋남 36 (36 번 = 검증 뒤 더한 행) · 빈 곳 12.',
         note='어긋남 행을 더해 개수를 맞춤'),
    dict(doc=D, v=V, num=2, item='읽은 범위와 셈 (어긋남 꼬리 수)', kind='넓게 말함 · 어긋남 빠짐',
         old='- 출처 꼬리 수: C 276 · D 194 · E 234 · 어긋남 97 · 빈 곳 42.',
         new='- 출처 꼬리 수: C 276 · D 194 · E 234 · 어긋남 100 (36 번의 꼬리 3 포함) · 빈 곳 42.',
         note='새 행의 꼬리 3 개를 더함 (97 + 3)'),
    # ── 문제 3 · D-42
    dict(doc=D, v=V, num=3, item='D-42', kind='위치 틀림 (서지 귀속)', line=r'^\| D-42 \|',
         old='바인더가 "buffer" 로 응력을 흡수해 입자 소성 변형을 줄임 (참고문헌 61 Ohashi 외 · J. Power Sources 470 (2020) 228437 지목만)',
         new='저자 해석: 바인더가 "buffer" 로 응력을 흡수해 입자 소성 변형을 줄임 · 참고문헌 61 (Ohashi 외 · J. Power Sources 470 (2020) 228437 · 복합 전극 응력 분포 · 강성 높은 상으로 응력 집중) 은 지목만 — 카드: CL-90 의 확인 불가 인용과 같은 권 · 다른 저자 · 다른 쪽번호 · 연결 [미확인]',
         note='카드 대조: heck2026 L305 (ref 61 Ohashi … J. Power Sources 470 (2020) 228437 · CL-90 표지) 맞음'),
    # ── 문제 4 · C-76 · 어긋남 3
    dict(doc=D, v=V, num=4, item='C-76', kind='재료 빠짐', line=r'^\| C-76 \|',
         old='· So 계열 24 (Sakuda) ·',
         new='· So 계열 24 (Sakuda · LPS 유리 값 — LPSCl 아님) ·',
         note='카드 대조: so2022_dem_compaction_coated L43 · so2021_dem_mold_pressure L38 "E_SE (LPS) 24 GPa" 맞음'),
    dict(doc=D, v=V, num=4, item='어긋남 3', kind='재료 빠짐', line=r'^\| 3 \| LPSCl 탄성률 E \|',
         old='· 입력 18.5–24 ↔ miss2026 입력 67 GPa',
         new='· 입력 18.5–22.1 (LPSCl) · So 계열 24 (LPS 유리 · LPSCl 아님) ↔ miss2026 입력 67 GPa',
         note='18.5–22.1 = C-76 의 LPSCl 입력값 범위 (faka2026 18.5 … Bazzoun 2026 22.1)'),
    # ── 문제 5 · 어긋남 1
    dict(doc=D, v=V, num=5, item='어긋남 1', kind='표지 빠짐 (우리 산술)', line=r'^\| 1 \| LPSCl "일축 항복" 의 환산값 \|',
         old='P_y/3 = 98–115 MPa (Heckel · 우리 규약) ↔ H/3 ≈ 0.47 GPa (치밀 펠릿 8 mN · Tabor) ↔ H/3 = 0.24–0.26 GPa (다공 압분체 100 mN) ↔ 빌린 항복변형 2.0 % × E 4.7 GPa = 94 MPa ↔',
         new='P_y/3 = 98–115 MPa ([우리 산술] · Heckel · 우리 규약) ↔ H/3 ≈ 0.47 GPa ([우리 산술] · 치밀 펠릿 8 mN · Tabor · 황화물에 검증 안 됨) ↔ H/3 = 0.24–0.26 GPa ([우리 산술] · 다공 압분체 100 mN · 계수 3 [미확인]) ↔ 빌린 항복변형 2.0 % (황화물 유리) × E 4.7 GPa = 94 MPa (이 digest 산술) ↔',
         note='카드 대조: lee2025 L119 · larson2025 L147 · song2025 L49 표지 맞음'),
    # ── 문제 6 · D-55 · 어긋남 11
    dict(doc=D, v=V, num=6, item='D-55', kind='표지 빠짐 (카드 판정)', line=r'^\| D-55 \|',
         old='· Hertz 재구성 0.843 (E 1.35) / 0.258 (E 24) ·',
         new='· Hertz 재구성 0.843 (E 1.35 · 과대) / 0.258 (E 24 · 과소) — 카드: 믿을 값은 접촉력 직접측정 (0.670 / 0.809) · Hertz 재구성 아님 ·',
         note='카드 대조: luding2008 §7.3 L212 · L223 맞음'),
    dict(doc=D, v=V, num=6, item='어긋남 11', kind='표지 빠짐 (카드 판정)', line=r'^\| 11 \| 우리 AM 하중 분담',
         old='↔ Hertz 재구성 0.843 (E 1.35) / 0.258 (E 24) |',
         new='↔ Hertz 재구성 0.843 (E 1.35 · 과대) / 0.258 (E 24 · 과소) — 카드: 믿을 값은 접촉력 직접측정 (0.670 / 0.809) · Hertz 재구성 아님 |',
         note='같은 글 (검증: 어긋남 11 도)'),
    # ── 문제 7 · 요지 6 줄
    dict(doc=D, v=V, num=7, item='요지 6 줄', kind='표지 (조수 판단 · 카드 풀이) 빠짐',
         old='· 강체 골격이 잼되면 압력을 1.8 배 올려도 기공이 0.1 %p 만 줆 — 2D · LIB 값이라 절대값 전이는 0 (D-18 · D-19 · D-20 · D-32).',
         new='· 뺀 뒤 기공이 86 → 156 MPa (1.8 배) 에서 0.1 %p 만 줆 (LIB · 원인 = 카드 풀이 \'강체 NMC 골격의 잼\' · 측정된 전이 아님) — 2D · LIB 값이라 절대값 전이는 0 (D-18 · D-19 · D-20 · D-32).',
         note='문서 안 D-32 (ngandjong2021 86 → 156 MPa · 0.1 %p) 와 대조'),
    # ── 문제 8 · 요지 1 줄
    dict(doc=D, v=V, num=8, item='요지 1 줄', kind='재료 빠짐',
         old='와 조건 · 기준 밀도마다 다른 Heckel P_y (219–757 MPa) 뿐이고,',
         new='와 조건 · 기준 밀도 · 조성마다 다른 Heckel P_y (219–757 MPa · 219–243 은 Li₅.₅PS₄.₅Cl₁.₅) 뿐이고,',
         note='문서 안 C-6 과 대조'),
    # ── 문제 9 · C-57 · E-80 꼬리
    dict(doc=D, v=V, num=9, item='C-57 (꼬리)', kind='위치 틀림 (카드 줄 이동)', line=r'^\| C-57 \|',
         old='[b02 · ' + PYC + ' · §3.1 (L75–80)]',
         new='[b02 · ' + PYC + ' · §3.1 (현 카드 L85–97)]',
         note='카드 §3.1 = L85–97 맞음'),
    dict(doc=D, v=V, num=9, item='E-80 (꼬리)', kind='위치 틀림 (카드 줄 이동)', line=r'^\| E-80 \|',
         old='[b02 · ' + PYC + ' · §7.3 (L344–346) · §9.2 (L390–393) · §15.2 (L628)]',
         new='[b02 · ' + PYC + ' · §7.3 (현 L502–519) · §9.2 (현 L563–572) · §15.2 (현 L857–869)]',
         note='카드 절 머리 줄 (§7.3 L502 · §9.2 L563 · §15.2 L857) 맞음'),
    # ── 머리 한정 줄
    dict(doc=D, v=V, num='머리', item='한정 줄', kind='한정 (지시서)', multiline=True,
         old='# 재료 값 · 하중 몫 · 접촉 법칙 (정독 종합 · 질문 c · d · e)\n\n',
         new='# 재료 값 · 하중 몫 · 접촉 법칙 (정독 종합 · 질문 c · d · e)\n\n'
             '한정 (2026-11-12): 검증 = 표본 (넷에 하나 + 따옴표 · 서지 전부) · 문제 비율 = 문제 9 / 본 항목 99 (전체 항목 243 · 표본 99 = 넷에 하나 62 + LPSCl 경도 · 항복 · 탄성률 · 크리프 항목과 pycompact2025 항목 37 · 숫자 = V_S2.md 셈) · 표본 밖 항목은 대조하지 않았다 · 이 판은 검증 표의 "고칠 글" 을 적용한 뒤다 (기록 = APPLIED.md).\n\n',
         note='숫자는 V_S2.md 셈 절에서만'),
]

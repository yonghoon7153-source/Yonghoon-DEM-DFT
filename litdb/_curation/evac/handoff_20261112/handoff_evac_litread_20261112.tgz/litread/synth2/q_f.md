# 질문 f — 배치별 근거 묶음 (원문 줄 그대로 · 파일 43 개)

### [batch_01] f. MPM 의 접촉 · 다물체 · 강체 결합 방법 · 해상도 규칙 (지름당 셀 수) · 수치 오차 추정

- [f] bardenhagen2000_mpm_granular_multibody_frictional_contact | 방법: 알갱이별 격자 속도장 v_i^g 를 질량중심 속도장 v_i 와 노드마다 비교 — 다르면 접촉 노드 · (v_i^g − v_i)·n > 0 (접근) 일 때만 법선 성분을 v_i 값으로 (식 12–14) · 접선은 μ′ = min(μ, 붙임에 필요한 비) 로 자름 (식 21–23) · 멀어지면 자유 분리 · 법선 = 알갱이 밀도 (2차 B-spline) 의 기울기 (식 24) · 짝 탐색 · 반복 없음 · 알갱이 수에 선형. 강체 = 계산 영역 경계 (강체 벽) 와의 마찰 접촉. 단일 속도장이면 "no-slip contact … is automatic" | §4-2 (L151–186) · §0 (L18 · p.531) · §5-1 (L241) | stated (식은 렌더 이미지 판독) · 보정의 시간 단계 내 위치 · 법선 부호는 [우리 판독] | 2D · 알갱이별 장의 저장 방식 미기재
- [f] bardenhagen2000_mpm_granular_multibody_frictional_contact | 해상도: 지름당 16 요소 "excellent" · 8 요소 "discrepancy is small" · 4 요소는 체제는 재현하나 구름 경우 오차 최대. 변위비 (μ 0.5 · θ π/6 · t = 0.4) 4 / 8 / 16 요소 ≈ 0.23 / 0.77 / 1.0. 다분산 시료는 지름당 4–32 (평균 ≈ 8) 요소 · 요소당 물질점 4 (검증 계산은 9) · 지름 4 요소는 "clearly insufficient to resolve the stress distribution within the small grains" | §3-1 (L83 · L91–93) · §3-2 (L107–109) · §5-2 (L251) · Fig 4 | stated · 변위비 = figure-read ≈ (추세 전용) | 2D 탄성 원판 (전단계수 2.5 MPa) · 경사면 (압축 아님)
- [f] bardenhagen2000_mpm_granular_multibody_frictional_contact | 오차 추정 방법 = 강체 해석해 (식 25) 와 질량중심 위치 비교 + 격자 3 단 (0.5R · 0.25R · 0.125R). 운동량 보존은 두 알갱이가 공통 법선을 쓰지 않아 "small errors" (크기 없음). 시간 간격 · CFL 수 · 총 물질점 수 [미확인] · 에너지 검사 없음 | §3-1 (L88–93) · §4-2 (6) (L182) · §3-3 (L124) | stated · [미확인] | 고밀도 · 다접촉 노드 (압밀) 에서의 오차는 "이 논문으로 알 수 없다" (L384)
- [f] bardenhagen2000_mpm_granular_multibody_frictional_contact | 카드의 우리 산술 (논문 밖): real_14 규모 (SE 씨앗 32,832 + AM 457 · ≥ 384³ ≈ 5.7×10⁷ 노드) 에서 장 하나 ≈ 0.91 GB (f32 · 16 B/노드) → 알갱이마다 통째로 두면 ≈ 30 TB (불가능) · 노드당 희소 슬롯 2 칸 (칸당 36 B 가정) ≈ 4 GB · 색칠 장 K × 0.91 GB. SE 1 µm 는 dx ≈ 0.141 µm 에서 ≈ 7 셀 · 8 셀이려면 dx ≤ 0.125 µm | §4-4 (L213–219) · §6 Fig 4 행 (L268) · §9-⑤ (L335) | derived(ours) · 가정 / 우리 추론 | 논문에 없음 · 3D 실행 없음
- [f] bardenhagen2001_mpm_improved_contact_granular_stress_waves | 방법 개정: 물체별 v^α = p^α / m^α (식 4) · v^cm = Σp^α / M (식 5–6) · 접촉 노드 v^cm − v^α ≠ 0 (식 7) · 접근 판정 (식 8) + 수직 견인력 t_n^α = n·σ·n < 0 (압축) 이면 마찰 접촉 유지 (식 9) · 갱신 ṽ = v − Δv_n (n + μ′t) (식 10) · 격자 붕괴 안정화 ε̇_max·Δt < γ 로 보정을 비례 축소 (식 17–22 · γ = 0.5 · 0.5–1 둔감 · < 0.5 침투). 분석은 접촉 노드당 물체 ≤ 2 로 한정 ("not all of the properties … hold for N > 2"). 계면 해상도 = 격자 셀 크기 | §5-2 (L156–168) · §5-4 (L182) · §5-5 (L189–199) · §4-1 (L100) · p.512 | stated · 식 (22) 의 'max' 를 'min' 으로 읽는 것은 [우리 판독] | 강체 없음 (평판도 변형체 · 10 배 단단) · N ≥ 3 처리 없음 · 견인력 · 법선의 격자 보간 세부 [미확인]
- [f] bardenhagen2001_mpm_improved_contact_granular_stress_waves | 해상도 (3D 구 · 셀당 물질점 8): 셀 R/2 (지름 4 셀) 는 '평평한 점' 때문에 구르지 못함 · R/4 (8 셀) · R/8 (16 셀) 은 강체 해로 수렴 · "it is resolution of the geometry that is most important". t = 2 s 위치 0 · ≈ 7.4 · ≈ 9.7 ↔ 강체 10.1 m; backspin t = 3 s 강체 ≈ 4.08 · dx 0.125 ≈ 3.95 · dx 0.250 ≈ 3.5 m. 응력파 원판은 지름당 80 셀 · 셀당 물질점 1 | §4-1 (L95 · L106–107 · L111) · §4-2 (L124) · §6-1 (L242) · Fig 5 · 7 | stated · 위치 값 = figure-read ≈ | 무른 neo-Hookean 구 1 개 (체적계수 6 MPa) · 탄성 · 경사면 (압축 아님)
- [f] bardenhagen2001_mpm_improved_contact_granular_stress_waves | 오차 추정 방법 = 강체 해석해 (식 23–26) 대조 + 해상도 3 단. 운동량: 붙음은 정확 보존 (식 15) · 미끄럼은 두 법선이 공선일 때만 (식 16). 에너지: 산문만 ("slightly increase" ↔ "slightly dissipative") · 시계열 없음. MPM 에너지 보존 오차는 시간 간격의 제곱에 비례 (Brackbill & Ruppel 1986 · Bardenhagen 2001). 실험 대조 = 광탄성 무늬가 맞는 프레임을 눈으로 고름 · 시뮬/실험 시간비 ≈ 0.84 (한 줄) · 0.57 (지그재그 미끄럼 μ 0.5) · 0.86 (접착) | §5-4 (L184–185) · §4-3 (L138) · §5-1 (L152) · §4-2 (L127–130) · §8 (L290) | stated · 시간비 = derived(ours) | 저자 표현 "excellent qualitative agreement" (정량 일치 주장 아님) · 미끄럼 배치에서 차이 최대
- [f] bardenhagen2001_mpm_improved_contact_granular_stress_waves | 재하율 관련 카드 산술 (논문 밖): ν 0.49 면 c_L / c_S ≈ 7.1 → 판 속도를 c_L 기준 Mach 0.03 으로 맞춰도 c_S 기준으로는 ≈ 0.21 | §10-⑧ (L329) | [우리 산술] · [우리 추론] | 논문 근거는 "ν 0.22 → 0.48 에서 무늬 속도 2 배 넘게 감소" (stated · L131) 뿐
- [f] devaucorbeil2020_mpm_after_25_years_review | 단일값 속도장이라 no-slip · no-penetration 접촉이 MPM 에 내재 (추가 비용 0) · 마찰 · 다물체 분리 · 미끄럼은 Bardenhagen 다물체 알고리즘 (2000/2001) 이 표준 (grain 수에 선형) · Nairn (2018) 이 임의 마찰 법칙 (adhesion 포함) 으로 일반화. 저자 명시 한계 = 수렴 비최적 (1D 에서도 FEM 이하 · 매우 고운 격자에서 비수렴 — Sulsky-Gong 2016) · BC 부여 어려움 · null-space · 큰 메모리 (ULMPM) | §5 (L44–48) · §6 (L68–69) | intro stated | PDF 미제공 · 원문 §2–6 미열람 · 지름당 셀 수 규칙 없음
- [f] klar2016_dp_sand_animation | 물질끼리는 격자 하나 (입자별 구성식만 다르게 주면 2-way coupling 자동). 격자 충돌 물체는 level-set φ 로 sticky / slipping / separating + Coulomb μ_b. 해상도 = dx 0.00083–0.016 m · ppc 2–9 · 입자 4.6×10⁵–6.6×10⁶ (지름당 셀 수 규칙 없음 — 알갱이를 풀지 않는 연속체 모래). 오차 추정 = 정량 검증 · 수렴 연구 없음 (Narain 2010 과의 정성 비교뿐) | §4.1 단계 3 (L74) · §4.5 (L146–150) · §3 표 (L48) · §6 (L182) | stated (Table 2 · 3) | 모래 · 컴퓨터그래픽스 · 시각 사실성 우선


### [batch_02] f. MPM 의 접촉 · 다물체 · 강체 결합 방법 · 해상도 규칙 (지름당 셀 수) · 수치 오차 추정

- [f] nezamabadi2022_mpm_cd_plastic_particle_compaction | 다물체 방법 = 다중 격자: "each soft particle maps in its proper background mesh … introducing a common background mesh with the same type of grids for the transfer of nodal quantities from proper meshes to the common mesh" + 접촉 절점력 f^C 를 Contact Dynamics (암시적 · 비평활) 로 — 격자 운동량식 M a = f^int + f^ext + f^C (식 3) | §4.1 (L158–159) · §4.2 (L163–171) · 논문 p.3 | 표지 없음 (원문 따옴표 인용) | 접촉 절차 세부는 [10, 9, 11] (카드 "우리 미열람") · 벽 = 강체 · 강체 입자 없음 · 집합체 마찰 0 · 2D
- [f] nezamabadi2022_mpm_cd_plastic_particle_compaction | 해상도: 4 절점 사각형 요소 · 요소당 물질점 4 · cubic spline · Δt 0.1 µs — 격자 간격 · 입자당 요소 수 [미확인] · 수렴 시험 없음; 수치 오차 추정 없음 — Φ > 0.97 의 해석식–MPM 불일치를 저자가 "the particles discretisation may be refined in order to resolve correctly the small radii of curvature at the contact zones between particles" 로 의심만 (마지막 점에서 +23 / +38 / +33 % · digitized) | §3.1 (L100–104) · §3.3 (L142) · §5.4 (L269–276) · §11 (L479–480) | stated / [미확인] / digitized | 비용 (코어 · 시간) [미확인] · 시드 1 개 · 지름당 셀 수는 카드에 없음
- [f] nezamabadi2022_mpm_cd_plastic_particle_compaction | 3D 비용 어림 (카드): 짝 논문 해상도 R/Δr ≈ 34.5 를 3D 구에 쓰면 SE 하나 ≈ 1.7 × 10⁵ 물질점 × 32,832 = 5.6 × 10⁹ · R/Δr 8 → 7.0 × 10⁷ · 10 → 1.4 × 10⁸ · 여기에 입자별 격자 메모리가 더해짐 · "장 색칠" 로 장 수를 O(10) 으로 줄이는 안은 "우리 추론 (논문 밖)" | §9 행동 4 (L443–447) | derived(ours) — "결정 전 재확인" | 논문 값 아님 · 2D 해상도를 3D 로 옮긴 어림
- [f] nguyen2017_mpm_bpm_deformable_particle_compaction | MPM 은 마찰 접촉을 위해 CD 와 결합이 필요: "The important point for the treatment of soft particles with MPM is the necessity of coupling it with the CD approach for a rigorous treatment of frictional contacts." (논문 p.2) · μ 0 / 0.5 두 경우를 계산 | §4.1 (L136–137) · §10 (L336–337) | 표지 없음 (원문 따옴표 인용) | 접촉 알고리즘 세부는 [5] (미열람) · 2D
- [f] nguyen2017_mpm_bpm_deformable_particle_compaction | 해상도 (단일 원판): Δr/R = 0.029 (Δr = 물질점 평균 간격) → R/Δr ≈ 34.5 · 원판당 물질점 ≈ 3,700 · 요소 ≈ 930; 집합체 해상도 미기재 · 수렴 · 오차막대 없음 | §3.1 (L90) · §3.2 (L104) · §6 (L258) | stated (0.029) / derived(ours) (34.5 · 3,700 · 930) | 2D · 지름당 셀 수로 적힌 값은 카드에 없음 (요소당 물질점 4 개)
- [f] stomakhin2013_mpm_snow_elastoplastic | 단일 속도장 MPM (입자 간 다물체 접촉 없음); 강체 결합 = 격자 기반 + 입자 기반 body collision (level-set φ ≤ 0 · inelastic · Coulomb 마찰) · sticky collision (상대속도 0 강제) | §4.1 단계 5 · 9 (L76 · L82) · §4.4 (L142–144) | 표지 없음 (카드 서술) | 눈 · 그래픽스 · 충돌 식 세부 (논문 §8) 는 카드에 없음
- [f] stomakhin2013_mpm_snow_elastoplastic | 해상도: 격자당 입자 4–10 개 · cubic B-spline · dt 명시 ~1 × 10⁻⁵ s ↔ semi-implicit ~5 × 10⁻⁴ s (CG 10–30 회 · 격자 해상도 · 입자 수와 무관); 수치 오차 추정 · 수렴 · 정량 검증 없음 | §3 (L44–46) · §4.0 (L64–67) · §4.3 (L118) · §10 (L222) | stated | 3D · 눈
- [f] 참고 (입자별 FE · MPM 아님) pycompact2025_dem_mpfem_workflow | 접촉 = General contact /TYPE26 (penalty · surface-to-surface) + Coulomb μ 0.2 · 입자당 평균 2000 요소 (/TETRA4); 오차 추정 = 입자당 요소 수 스윕: 95 % 밀도 축응력 500 → 1650 · 1000 ≈ 1510 · 1500 ≈ 1440 · 2000 ≈ 1375 · 2500 → 1310 MPa (단조 감소 · 2000 → 2500 −5 %) — 저자는 "convergence" 라 적었으나 선택 이유는 런타임 (9 h ↔ 36 h) | §7.2 (L316–322) · §3.4 (L115–118) · §9.1 (L373–379) | stated (500 · 2500 · 런타임) / digitized (중간점) / derived(ours) (−5 %) | 금속 · 3D · 시드 1
- [f] 우리 쪽 기록 (카드 안) | 우리 MPM = 단일 속도장 "닿으면 붙음 (no-slip + 결합)" · 우리 격자 규칙 d_h/dx ≳ 3.5 | nezamabadi2022 §7.1 (L344) · §8-⑥ (L415) | 표지 없음 | 논문 값 아님


### [batch_03] f. MPM 의 접촉 · 다물체 · 강체 결합 방법과 해상도 규칙 · 수치 오차 추정

MPM 방법 논문은 **이 배치에 없음**. 해상도 감각과 우리 쪽 서술만.

- [f] cardenasbarrantes2021_soft_rigid_mix_compaction_proceedings | 입자별 FE 의 해상도: 입자당 92 삼각형으로 다각형 형상 변화가 그려짐 · 단일 입자 메시 Ne 92 → 968 에 결과 거의 불변 — "MPM 이라면 SE 한 알당 격자 칸 수가 같은 역할 (우리 n_grid 384 · dx ≈ 141 nm 에서 ⌀1 µm SE ≈ 7 칸)" | 그림 1 · 5 설명 (L153 · L158) · §5-4 (L139) | stated (메시 결과) · "파생 산술" (7 칸) | FE 메시 수 (MPM 셀 수 규칙 아님) · 2D · 초탄성
- [f] cardenasbarrantes2020_rigid_deformable_mixture_compaction_nscd | 단일 입자 상자 시험 메시 Ne = 92 · 174 · 272 · 572 · 968 — "Ne 가 결과에 작은 영향" · 식 (9) 는 고압에서 맞고 저 · 중압에서 0.01–0.02 낮음 | §3-1 (L104) · §3-2 (L128) · §3-4 (L161) · 그림 8b | stated · derived(ours) | 수렴 차수 · 오차 추정식 없음 · 2D
- [f] cardenasbarrantes2020_rigid_deformable_mixture_compaction_nscd | 수치 통제: 하중 단계 안정 판정 = φ 변화 < 0.01 % · 관성수 I < 10⁻⁴ · 시간 간격 · 반복 횟수 · 허용오차 · 요소 종류 · 접촉 탐색 방식은 미기재 | §3-1 (L109–111) · §3-5 (L167–168) | stated · [미확인] | NSCD + FE (MPM 아님)
- [f] cardenasbarrantes2020_rigid_deformable_mixture_compaction_nscd | 카드의 우리 쪽 서술: 우리 MPM 은 단일 속도장 — "격자 암묵 · 마찰 없음 = 사실상 무한 마찰 + 점착" · 닿은 SE 가 융합 · AM = 얼린 격자 장애물; 다물체 / 다중 속도장 (A′ · Bardenhagen 류) 은 이름만 나옴 (방법 · 해상도 규칙 서술 없음) — NSCD 가 "A′ 의 접촉 근사를 검증할 기준 해 (2D 소형 대조)" | §4-6 (L253–255) · §10-1 (L517) · §14 (L629) | 표지 없음 (우리 쪽 기록 · 카드 제안) | MPM 접촉 알고리즘 자체는 다른 카드 소관


### [batch_04] f. MPM 의 접촉 · 다물체 · 강체 결합 방법 · 해상도 규칙 (지름당 셀 수) · 수치 오차 추정

이 배치에 **MPM 카드 없음** → 접촉 방법 · 해상도 규칙 · 오차 추정 없음. 닿는 두 줄만.

- [f] giannis2021_stress_based_multicontact_dem | 저자 §1 (카드의 우리말 옮김): MPM · MPFEM · FEM-DEM = "단일 입자의 이방성 변형과 변형 후 임의 형상을 다룰 수 있는 방법 — 그러나 계산비용이 많은 입자 수에서 사용을 막는다" | §7-5 표 (L426) · §8 ⑦ (L490–492) | 카드의 우리말 옮김 (원문 영어 문장은 카드에 없음 · L507–509 는 카드가 지은 인용용 문장) | 접촉 방법 · 해상도 · 오차 추정 없음 · 비용 수치 없음
- [f] coetzee2017_dem_calibration_review | 리뷰 §1 요약: "FEM/메쉬프리는 대변형·혼합·분리에 약함" (DEM 이 벌크재 취급 설계의 주력) | 카드 §6 의 "§1 Introduction" 요약 (L505) · p.105 | 표지 없음 (카드 요약) | MPM 접촉 · 해상도 없음
- [f] electromechanical_contact_model_particulate_systems · dmt1975_adhesion_contact_deformation · deng2021_mechanical_surface_energy_tester_bond_number | 이 배치에 없음 (electromechanical L80 "MPM/continuum: 없음") | — | — | —


### [batch_05] f. MPM 의 접촉 · 다물체 · 강체 결합 방법 · 해상도 규칙 (지름당 셀 수) · 수치 오차 추정

**이 배치에 MPM 카드 없음.** 아래는 MPM 이 아닌 계산의 해상도 · 수렴 기준 가운데 단위 시험 설계에 닿는 것.

- [f] jacksongreen2005_fem_elastoplastic_hemispherical_contact | (FEM) 단접촉 축대칭 메시: 최종 11,101 요소 · 접촉 요소 100 개; 메시를 2 배씩 정밀화해 접촉력 · 면적 변동 1 % 미만까지; 접촉 요소 강성도 자릿수 올려 1 % 수렴; 각 간섭에서 30 개 이상 접촉 요소가 접촉 (최대 접촉 반경 오차 3.3 %); 침투 ≤ 요소 폭의 1 % (Lagrange multiplier); 변위 제어가 하중 제어보다 수렴 빠름; 바닥 절점 구속 방식 차는 면적 < 3 % · 하중 < 1 %; ANSYS ↔ ABAQUS 교차 확인 | §4 (L49–50 · L57–59 · L66–72) | stated | 반구 1 개 · 강체 평판 · 무마찰
- [f] gonzalez2012_nonlocal_contact_confined_granular | (FEM) 구 1/8 메시 324,000 개 10-node 4 면체 / 461,404 절점 (예시 그림은 40,500 요소) · 강체 무마찰 경계 = 벌칙법 · 메시 수렴은 더 조밀한 메시를 기준으로 확인 · 구성식 압축성 neo-Hookean | §3.1 (L71–73) · §5.3 (L329–332) | stated | 탄성 고무 구
- [f] he2026_dem_calendering_inhomogeneity_areal_density | (DEM) 도메인 수렴: 변 20 / 25 / 30 / 35 / 40 µm 에서 평균 면하중 0.1471 / 0.1167 / 0.0982 / 0.0900 / 0.0928 mN/µm² · 편차 58.51 / 25.75 / 5.82 / 3.02 % (40 µm 기준) → 30 × 30 채택 (변당 D50 입자 ≈ 8 개); 입도 이산화는 7 개 대표경에서 판 압력 안정 (정량 문턱 없음) | §3.4 (L126–132) · §3.3 (L118–119) · §7 표 (L373) | stated (Table 4) · "≈ 8" 은 카드 산술 | 시드 반복 0 · 판정선 (5 % / 10 %) 사후 선택 (카드 L320)
- [f] he2026_dem_calendering_inhomogeneity_areal_density | 준정적성: 판 속도 0.003 m/s · NCM P 파속 √(E/ρ) = 3207 m/s → Mach ≈ 9 × 10⁻⁷; 카드가 적은 우리 MPM 판 = 기본 0.03 · 실측 V/c_S 0.22–0.75 | §4.5 (L301–305) · §7 표 (L371) | derived(ours) · 우리 값은 우리 쪽 기록 | —


### [batch_06] f. MPM 의 접촉 · 다물체 · 강체 결합 방법과 해상도 규칙 · 수치 오차 추정

이 배치에 **MPM 을 쓴 카드 없음**. 해상도 · 오차 추정의 FE / FV 쪽 선례만.

- [f] kogutetsion2002_ep_sphere_rigid_flat | (FEM) 축대칭 격자 225 개 8 절점 요소 · 714 절점 · Zone I = 구 끝 0.1R 안에 절점 87 % · dx ≈ 0.03·a_c (a_c = √(R·ω_c)) · 강체 평판은 선 (line) + target / contact 요소. 오차 추정 = ① 탄성 구간을 Hertz 해석해와 (< 2.8 %) ② 2944 절점 격자와 (하중 1 % · 면적 3 %) | §4 (L69–76) | stated | 단접촉 · "지름당 셀 수" 꼴의 규칙은 카드에 없음 (항복 개시 접촉 반경 기준 dx)
- [f] mesarovicfleck2000_dissimilar_elastoplastic_indentation | (FEM) 축대칭 ~2500 2차 요소 · ~23,500 DOF · 초기 접촉 절점 간격 1.5×10⁻³R — a/R = 0.01 에서 h 산포 ±7.5 % · a/R > 0.08 에서 < 2.5 %; 3D B2 ~4300 요소 · ~100,000 DOF · 절점 간격 5×10⁻³R · m = 3 한 런 145 increment · ~30 일 CPU | §4 (L66–69) | 표지 없음 | 단접촉 / 단위셀
- [f] oh2026_bimodal_composite_cathode | (FVM / FEM) 재구성 구조 40×40×t µm³ · voxel 0.1 µm · SSE 구 0.8 µm (Table S14) · 메싱 전 3 voxel smoothing. 오차 = 시뮬 ↔ 실측 평균편차 σ_ion 1.98 % · σ_e 3.66 % | §2.3 (L146–161) · Table S9 · S11 | 표지 없음 | 실측에 맞춘 재구성 — 격자 수렴 시험은 카드에 없음


### [batch_07] f. MPM 의 접촉 · 다물체 · 강체 결합 방법 · 해상도 규칙 (지름당 셀 수) · 수치 오차 추정

이 배치에 없음. (여섯 카드 모두 MPM 을 다루지 않는다 — Pasha "MPM / continuum: 없음" L198 · So "MPM/morphology ✗ 없음" L222 · Paulick 은 우리 쪽 기록 한 줄 "MPM 은 CFL, Eq.2 비적용" L128.)


### [batch_08] f. MPM 의 접촉 · 다물체 · 강체 결합 방법 · 해상도 규칙 (지름당 셀 수) · 수치 오차 추정

**이 배치에 MPM 논문 없음.** 해상도 · 수치 오차와 닿는 것 (MPM 아님 — 참고):

- [f] storakers1997_similarity_inelastic_contact | 단접촉 FE: 13,882 자유도 · 원격 경계 ρ/a ≤ 50 (1/m + 1/n ≤ 0.25 면 10) · 접촉 테두리 특이점 (HRR 균열 선단형) 을 정밀 메시로 해상 · 검증 = 뉴턴 유체 해석해 (타원체 압입의 접촉 윤곽이 정확히 타원 · 일정 하중에서 a ∝ t^{1/3}) | §3 (L40) · §4 (L44 · L66–67) · §7.4 (L151–153) | stated | 오차 수치는 카드에 없음 (소성 ↔ 크리프의 c² 일치는 "약 5 % 이내" · L279)
- [f] varkey2026_multicontact_elastoplastic_dem | FE 검증 메시 0.66 mm (구 지름 10 mm) · 변형체 구 3 개 · 무마찰 (Augmented Lagrange) 접촉 · 두 판 변위 5 mm | Supplementary (L92–95) | stated (Table S1) | 수렴 시험 여부는 카드에 없음
- [f] tovar2026_cold_spray_cathode_composite_dem_plastic_elastic_bond | 결합구 해상도: 입자 하나 = Ø1 µm 구 2,499 개 (지름 ≈15 µm) · "preliminary tests showed that the sphere resolution did not affect the qualitative trends" (자료 미제시) · 2 µm 입자는 구 ≈6 개 · Δt/√(m/K) ≈ 0.016 · 같은 기판의 COR 이 단일 실행에서 ≈0.02–0.03 폭 흔들림 | §4-4 (L95) · §4-7 (L141–143) · §10-7 · 14 (L301 · L308) | 인용 = stated · 지름 · 구 수 · 시간 간격 비 = 우리 산수 · 흔들림 = figure-read | 결합구 DEM · 수치 오차 추정은 논문에 없음
- [f] thakur2014_eepa_adhesive_elastoplastic_dem | 시간 간격 < Rayleigh 의 10 % (8 × 10⁻⁷ – 2 × 10⁻⁶ s) · 관성수 I < 10⁻⁴ (준정적) · 시드 3 개 (N 2,200) + 큰 계 1 개 (N 10,000) 로 산포 평가 (σ_u COV 3.4 %) | §4 (L87 · L156–157) · §3 (L72) | stated | DEM


### [batch_09] f. MPM 의 접촉 · 다물체 · 강체 결합 방법 · 해상도 규칙 (지름당 셀 수) · 수치 오차 추정

MPM 을 쓴 카드는 **이 배치에 없음** (지름당 셀 수 규칙 없음). 가까운 것만 적는다.

- [f] zunker2025_dem_large_deformation_compaction | 입자별 FE (MPFEM) 설정: 단분산 14 / 삼분산 12 입자 · C3D10M · Abaqus dynamic explicit · 감쇠 없음 · 강체 벽 6 면 등속 접근 · 법선 hard · 접선 마찰 µ 0.5 | §3-3 (L98–102) | stated | 요소 수 · 메시 수렴 · 오차 추정은 카드에 없음
- [f] zunker2024_mdr_contact_model_partI · zunker2024_bulk_elastic_partII | 단일 입자 FEM 메시: 7,653 CAX4R (축대칭 · 접촉 곡면 국부 세밀화 · 평판 = analytical rigid) / 48,167 C3D10 (삼축 · 단축) · 264,500 C3D10 (die) | Part I §3 (L74) · Part II §3 (L55) | stated | 수치 오차 추정 없음 — Part I 일치도는 "semi-quantitative" · 오차 지표 (RMSE 등) 미제시 (L379–380)
- [f] zunker2025_dem_large_deformation_compaction | DEM 시간 간격 규칙: Δt = 0.35·√(m/k) · m = ρ(4/3)πR_min³ · k = κ·R_min → 3×10⁻⁸ s (카드 검산 2.98×10⁻⁸ s) · 입자 관성 ≪ 평균 접촉력으로 준정적 확인 | §3-2 (L87–92) | stated · DERIVED (검산 일치) | DEM 규칙 (MPM 아님)
- [f] zunker2024_mdr_contact_model_partI | 카드의 우리 쪽 기록: "우리 MPM 은 J2 + σ_y 0.15–0.30 GPa 인데 E = 24 GPa 면 33–38 % porosity · E = 1.53 이어야 10 %" | §7-3 (L313–316) | 표지 없음 (우리 쪽 서술) | 차원 (2D / 3D) · 해상도는 이 카드에 없음


### [batch_10] f. MPM 의 접촉 · 다물체 · 강체 결합 방법 · 해상도 규칙 (지름당 셀 수) · 수치 오차 추정

**이 배치에 없음** (MPM 논문 없음 — MPM 은 카드의 "우리 쪽" 칸에만 나온다). 해상도가 기공 세기에 미치는 영향으로 옮겨 볼 수 있는 것 둘만 적는다 (MPM 아님).

- [f] minnmann2024_microstructure_porosity_visualization | (MPM 아님 · 영상 해상도) 100 nm 정육면체 복셀 토모그래피는 50 nm 아래 공극을 못 봄 → 분할 기공 ≈ 10 / 7.5 / 6 % 가 질량 · 밀도 기대값 ≈ 20 / 16 / 11 % 보다 낮음 | §3 (L36–37) · §4 (L79 · L90) · §10 (L189) | digitized · 원인은 "본문도 명시" (카드) | Li₃PS₄–0.5LiI 복합
- [f] bazzoun2025_dem_parameter_sensitivity_assb_cathode | (MPM 아님 · DEM 후처리 수렴) 몬테카를로 점 30,000 개에서 기공 수렴 (100 → 200,000 스윕 · 50,000 권장) · 상자 크기 인자 8 이상에서 수렴 (10 채택) · 벽에서 2–4 입경 안은 bulk 가 아니라 제외 → 가상 상자 비 ω = 0.7 | §4 (L68 · L75) · 논문 Fig 8–10 | 표지 없음 | —


### [batch_11] f. MPM 의 접촉 · 다물체 · 강체 결합 방법과 해상도 규칙 · 수치 오차 추정

이 배치에 없음 (MPM 을 쓴 카드 0 장).

참고 — MPM 은 아니지만 "지름당 칸 수 · 수렴" 에 닿는 것 (복셀 수송 · DEM 상자):
- [f] park2020_dimension_controlled_se_percolation_contact_area | 복셀 100 nm = 최소 치수 250 nm 의 **2.5 복셀** (원문은 "approximately one-third" 라 적지만 실제 비 0.4) · 고정 겹침 0.1 µm = 1 복셀 · **수렴 시험 보고 없음** · 단일 실현 | §3-A (L48) · §4.3 (L246–248) · §10 (L468) | stated (복셀 · 문장) · 파생 (2.5) | 복셀 수송 계산 (MPM 아님)
- [f] schlautmann2023_se_particle_size_composite_transport | 복셀 600 nm · (300 µm)³ (M / L / XL) ↔ 300 nm · (90 µm)³ (S 만) → CAM 지름당 ≈7.6 / 15 복셀 · 구조 3 개 평균 · 수렴 시험은 카드에 없음 · S 만 격자 · 상자가 달라 비교에 이산화 차가 섞임 | §4g (L195) · §7a (L321) · §10-15 (L442) | stated (격자) · 우리 산수 (지름당 수) | 복셀 수송 계산
- [f] shi2019_high_am_loading_particle_size_assb | DEM 상자 크기 수렴: 상자 11 개에서 L < 50 µm (CAM 5 µm) · L < 120 µm (CAM 12 µm) 이면 큰 오차 → L_min ≈ 10 D̄_max · 사용 L_box = 1.5 L_min ≈ 15 D̄_max (D̄_max = 가장 큰 성분의 평균 지름 · 압밀 전 초기 입방 한 변) · 작은 상자 오차의 부호는 일정하지 않음 (첫 점 44.0 · 54.1 %) · 판정 지표는 연결성 θ 하나 · 조성 80:15 한 점 | §3 (L147) · §S.2 (L371–380) | stated · SI-stated · digitized (평탄값) | 해상도가 아니라 상자 (RVE) 크기 · 시드 산포 없음


### [batch_12] f. MPM 의 접촉 · 다물체 · 강체 결합 방법 · 해상도 규칙 (지름당 셀 수) · 수치 오차 추정

**이 배치에 MPM 카드 없음.** 해상도 · 수치 오차 추정의 선례는 입자별 FE (demirtas2021) 하나 — "지름당 셀 수" 가 아니라 "입자당 요소 수" 이고 MPM 값으로 옮기지 않는다.

- [f] demirtas2021_mpfem_hollow_sphere_die_compaction | (MPM 아님 · 입자별 FE) 접촉 = Abaqus general explicit contact + Coulomb 마찰 μ 0.1 (입자–입자 · 펀치 · 다이벽 같은 값) + penalty; 펀치 · 다이 = 3D discrete rigid body; 입자 = C3D8R 약 1650 요소 (전역 seeding ≈ 0.125 r · 절점 2208 · 표면 절점 552 · 두께 방향 3 구획) | §4-3 (L274–292) · 논문 Fig 2 · 3 | stated | 강체–변형체 결합은 강체 공구뿐 (움직이는 강체 입자 없음)
- [f] demirtas2021_mpfem_hollow_sphere_die_compaction | 수치 오차 추정 방법: (i) 8 입자 simple-cubic 축소 모델을 RD 0.90 까지 → 요소 600 / 1059 / 1650 / 1800 / 3363 비교 (ii) coarse / fine / optimal 을 520 입자 본 모델에서 재확인. 지표 둘 = 응력 Σ_y 와 정규화 접촉 면적 (총 접촉 면적 / 전체 입자 표면적) — 둘째를 넣은 이유 *"this study requires another confirmation point to be defined for hollow particles due to the buckling phenomenon"*. 결과: Σ_y 는 8 입자 ≲ 2 % · 520 입자 +5 % ↔ 접촉 면적은 4 s 에서 0.64 → 0.49 (−23 %) · 0.72 → 0.56 (−22 %) · 1 s 에서 −26 % / −43 % · plateau 없음 | §4-6 (L345–370) · 논문 Fig 4 · 5 | 방법 · 인용문 = stated · 값 = figure-read ≈ (추세 전용) | 카드: 고른 1650 은 수렴점이 아니라 1650 ↔ 1800 의 비단조 구간 (L366–370) · 중공 껍질 좌굴 문제
- [f] demirtas2021_mpfem_hollow_sphere_die_compaction | 준정적 판정: mass scaling (밀도를 올려 Δt 를 키움) 의 영향을 운동 / 퍼텐셜 에너지 비로 — *"the energy balance ratio was kept below 1 % at RD ≥ 0.6"* · 안정 시간증분 Δt ≤ min(δ·√(ρ/(λ̂ + 2μ̂))) | §4-5 (L327–333) | stated | RD < 0.6 구간 (전면 항복 0.46–0.47 이 일어나는 곳) 은 기준 밖 (L334–336) · 팔마다 펀치 속도가 다름 (derived ≈ 2.87 배 · L337–343)
- [f] demirtas2021_mpfem_hollow_sphere_die_compaction | 비용: 8 입자 모델 런타임 46.3 / 53.0 / 72.1 / 98.3 / 218.2 분 (입자당 요소 600 → 3363) — 요소 5.61 배 → 시간 4.71 배; 본 모델은 입자 411–1979 · *"under 2000"* · *"<60 h"* | §4-3 (L286–302) · §7-B-2 (L627–628) | 표 = stated (Fig 3 그림 안 · PDF 글자층에 없음) · 배율 = derived | 머신 · 코어 수 · 모델별 시간 없음 · 8 입자 값을 본 모델에 선형 외삽하면 297 h 로 <60 h 와 5 배 어긋남 (카드 · L301)
- [f] benhadjali2026_wip_vs_cup_pressing_assb_cathode_dem | (MPM 아님) DEM → 0.2 µm 등방 복셀 → FEM · 기공-목 망은 0.6 µm (≈ 3 복셀) 문턱 — 복셀 · 메시 수렴 시험 없음 · DEM 한 실현 | §3-8 (L165) · §3-9 (L192) · §6 (L290) | [인쇄] · 수렴 없음은 카드 확인 | —
- [f] 나머지 일곱 카드 | MPM · 격자 해상도 서술 없음 | — | — | —


### [batch_13] f. MPM 의 접촉 · 다물체 · 강체 결합 방법과 해상도 규칙 · 수치 오차 추정

이 배치에 MPM 카드 없음. 아래는 DEM 쪽 수렴 · 해상도 · 준정적성 점검을 참고로 적은 것이다 (MPM 의 지름당 셀 수 규칙이 아님).

- [f] ngandjong2021_dem_calendering_digital_twin | MPM 없음. 참고 (DEM 쪽 수렴 점검): 대표 면적 사다리 723 → 2,892 → 11,569 µm² (작은 면적은 큰 AM 하나의 움직임이 힘에 크게 반영돼 압입 곡선이 들쭉날쭉 → 11,569 채택) · 평면 속도 4 점 (2×10⁻³–2×10⁻⁴ µm/µs · 10 배) 에서 ε 31.5 % 구조의 PSD · g(r) 겹침 · 시드 0 건 · τ 계산 복셀 0.25 µm | §3 (L107) · §5 S3 (L478) · §4-B-2 (L421–423) · §4 (L303 · L322) | stated | MPM 해상도 규칙 아님 · 수치 오차의 정량 추정은 카드에 없음
- [f] xu2023_realistic_am_shape_cgmd_calendering | MPM 없음. 참고 (이산 표현의 해상도): 형상 해상 = XCT 복셀 0.642 µm 를 2×2×2 로 줄여 1.284 µm 정육면체 → 등체적 구 Ø1.59 µm (2차입자 2–14 µm 당 평균 62.2 · 57.5 개) ; 후처리 복셀 0.25 µm ↔ XCT 0.642 µm (2.6 배) 라 공극망 비교에 해상도 교락 (본문 *"most likely due to the smaller voxel sizes"*) ; 대표 부피 편향 = 전체 볼륨 τ 가 서브볼륨 20 개 평균보다 −4.8 % (압연 전) · −10.7 % (압연 뒤) | §3 (L119 · L124 · L127) · §4-B-1 (L414–422) · §5 Fig 1B (L502) · §10 (L767–768) | stated · digitized | MPM 규칙 아님 · 시간 간격 · 판 속도 · 시드 미기재라 수치 오차 추정 자체가 없음 (L773–774)
- [f] zhang2026_xct_dem_cathode_calendering_peel_calibration | MPM 없음. 참고 (수치 건전성): RVE 1 개 · 시드 앙상블 · 크기 수렴 검사 보고 없음 · 측면 100 µm ≈ 3 d_max ; 재하율 Mach ≈ 1.8 × 10⁻⁶ (NMC) – 3 × 10⁻⁵ (bond 급 강성) · 관성수 I ≈ 2.0 × 10⁻⁵ (30 MPa) · 7.8 × 10⁻⁶ (200 MPa) ; 자기 일관 σ_zz(RVE) / 목표 = 1.013 · ≈ 1.11 · 0.993 | §4.1 (L266–267) · §12 D8 (L571–573) · D3 (L524–526) | derived(ours) · 60 MPa 는 figure-read 기반 | MPM 해상도 규칙 아님 · 입자 수 · 시간 간격 [미확인]
- [f] lyu2025_3d_dem_drying_calendering_lib | MPM 없음 · 해상도 · 수렴 점검 · 시드 서술 없음 ("seeds: 명시 안 됨 (단일 RVE 추정)") | §4 (L69 · L76) | 카드 표기 "추정" | —
- [f] miss2026_insitu_conductivity_porosity_pressure_compaction · miss2026_pressure_tortuosity_composite_cathode_coating | 이 카드들에 없음 (시뮬레이션 없음) | 왼쪽과 같음 | — | —


### [batch_14] f. MPM 의 접촉 · 다물체 · 강체 결합 방법과 해상도 규칙 · 수치 오차 추정

이 배치에 없음 — 여덟 장 모두 MPM 을 쓰지 않는다. (so2022 는 입자를 3D 격자에 옮겨 TauFactor 를 돌리지만 격자 해상도는 카드에 없고 [§4.3 L108], nisar2024 의 수렴 기준 2 × 10⁻⁴ 는 저항망 반복 해의 것이다 [§4 L76].)


### [batch_15] f. MPM 의 접촉 · 다물체 · 강체 결합 방법과 해상도 규칙 · 수치 오차 추정

MPM 을 쓴 카드는 **없다**. 복셀 · FEM 계산의 해상도 규칙과 오차 추정법만 적는다.

- [f] cooper2017_simulated_impedance_diffusion_porous_media | 복셀 유한차분의 격자 규칙: 가장 작은 특징 = 5 × 5 voxel ("격자 무관 해를 위해" · Sierpinski carpet) — 수렴 자료는 없음. 오차 추정법 = 해석해 대조: 곧은 개방 기공은 tanh(s)/s, 곧은 폐쇄 기공은 coth(s)/s (저주파 실수부 1/3 · 그림 판독 0.330) 를 되찾아야 함 | §3-2 L77 · §3-6 L112–117 · §4-5 L157 · §4-7 L181 · 논문 p.683 | stated (규칙) · 우리 재계산 (해석해 값) | MPM 아님 · 확산 문제 · 카드 계산: 주파수 창 상한에서 침투 깊이 ≈ L/45 → L = 128 voxel 이면 ≈ 2.8 voxel (우리 산술 · L254)
- [f] cronk2026_lis_positive_electrode_geometry_fem | 해상도를 적지 않은 사례와 그 귀결: voxel 크기 · 주기경계 · 겹침 · 시드 · 메시 크기가 본문 + SI 에 0 건 (카드의 전수 grep) · 복셀 껍질 분율 f ≤ 3h/R → 보고값 87.6 % 면 R/h ≤ 3.4 (sub-micron 입자가 반지름 3 셀 이하) · 상자 변당 입자 지름 개수 2.0–2.5 (Bulk) / 6.7 / 18.7 · 수치 오차 추정 없음 (3 반복인데 산포 미보고 · 상자 수렴 검사 없음) | §3.2 L87–98 · §3.3 L100–112 · §3.4 L134–147 | derived(ours) · 미기록은 카드 확인 | MPM 아님 · FEM 요소 크기도 미기록
- [f] cronk2026_lis_positive_electrode_geometry_fem | 카드가 옮긴 우리 쪽 규칙: d_h/dx ≳ 3.5 (좁은 채널 2.65 셀이면 격자 정밀화에 +23.8 % · 7.71 셀이면 +4.0 %) | §3.5 L183–184 | 우리 쪽 값 (카드 표기 "CLAUDE.md 2026-08-07") | 논문 값 아님
- [f] bielefeld2019 · bielefeld2020 | 복셀 0.2 µm → "3 µm 입자까지 합리적" · "입경 3 µm 가 모델 하한" (지름당 15 voxel — 내 산술) · 수치 오차 추정은 카드에 없음 (2020 의 검증은 실측 한 점: 0.68 ↔ 0.73 mS/cm) | bielefeld2019 §3 L60 · §5.2 L102 · bielefeld2020 §2.4 L160–162 · §3.1.1 L211 | stated | MPM 아님
- [f] chen2011_percolation_micromodel_composite_electrode | 격자 없음 (해석식). 이산화 인공물 하나: 입경 분포를 9 크기로 나누면 곡선에 여러 전이가 생기고 "더 많은 크기로 표현하면 사라짐" | §5.4 L141 | 카드 서술 | —


### [batch_16] f. MPM 의 접촉 · 다물체 · 강체 결합 방법과 해상도 규칙 · 수치 오차 추정

**MPM 을 쓴 카드가 없다** (접촉 · 다물체 · 강체 결합 정보 0). 아래는 복셀 · 격자 계산의 해상도 규칙과 수치 오차를 다룬 방식이다.

- [f] holzer2013_constrictivity_effective_transport_porous_layers | 영상 복셀 대비 특징 크기: 평균 입자 > 10 × 복셀 (c-PSD r50 157 nm ÷ 15 nm) · 좁은 목도 4–5 × 복셀 (MIP r50 66 nm) | §3-A L65 · §6 L220 · 논문 p.2940 | stated | FIB-SEM 영상 분석 (수송 · 역학 솔브 아님) · LSC 소결체 · 수렴 시험이 아니라 "여유" 서술
- [f] holzer2013_constrictivity_effective_transport_porous_layers | 대표 부피로 오차를 다룸: 두께를 75 nm 씩 1.5 µm 까지 · 그 뒤 1.25 µm 씩 7.6 µm 까지 늘려 반복 → 목 반지름 통계는 침투 깊이 ≈ 3 µm (= 최대 입자 반지름의 2–5 배) 위에서 평탄 · 거품 크기 통계는 > 6 µm 필요 · 6 방향 반복 ± 1 nm | §3-A L70–74 · §4-4 L155–156 · 논문 p.2943–2947 · p.2951 | stated | 기하 지표의 대표성 (힘 · 수송 계산 아님)
- [f] galvezaranda2024_time_dependent_dl_calendering_microstructure | DEM → 복셀 해상도: 0.4 µm = "가장 작은 입자의 거의 1/4" (최소 입자 지름 ≈ 1.6 µm 로 환산) · 상 경계 접촉면 오차 (최대 16.76 %) 의 해법으로 저자가 복셀 축소를 제시 · 프레임 수 · 격자 해상도는 "미탐색" | §3-B L97–99 · §5-3 L287–289 · §5-4 L305 | stated · derived(ours) (1.6 µm) | 수렴 시험 0 · 오차 추정 없음 (시드 · 오차막대 0 · L261–262)
- [f] duquesnoy2020_calendering_ml_mesostructure_generator | 구를 복셀로 찍을 때의 부피 손실 (슬라이스 반경을 내림 처리): 복셀 부피 ÷ 해석 부피 = 0.51 (R = 1.0 µm = 1 복셀) · 0.67 (R = 4.0 µm) · PSD 가중 0.694 · R = 1.25 에서 1.06 으로 비단조 → 분포의 모양이 왜곡 | §5(f) L330 | 카드 산출 (20 개 sub-voxel z-offset 평균) | 그 코드의 래스터 규칙에 한한 값 · 1 µm 단일 해상도 · 수렴 시험 없음 (L435)
- [f] duquesnoy2020_calendering_ml_mesostructure_generator | 채널 폭 대 격자: 논문 원자료 두 열로 d_h = ε/(S_V(1 − ε)) = 1.00–1.03 µm → d_h/dx ≈ 1.0 (n = 880) · 카드가 견준 우리 쪽 규칙 d_h/dx ≳ 3.5 의 근거 = MPM 응력 판독에서 격자를 2.25 배 조일 때 3.43 셀 +4.0 % ↔ 1.18 셀 +23.8 % | §5(d) L307–315 | 카드 산출 · 우리 쪽 규칙 인용 | 카드 자기비판: 3.5 는 MPM 응력 판독으로 맞춘 값이고 수송에서는 부호가 반대일 수 있어 "증명된 문턱이 아니라 자릿수 경고" (L315)
- [f] hlushkou2018_void_space_ion_transport_assb_cathode | 복셀 35.6 × 35.6 × 100 nm (비등방) · 무작위 걸음의 시간 간격 = 평균 변위 ≤ 복셀/10 · 추적자 10⁷ · 방법 검증 = 구 배열 해석해 [38] 대조 (이전 논문 [36, 37]) · 유한크기: 부분 부피 한 변을 10 → 100 % 로 키우며 반복 — LCO · SE · void 지표는 ~70 % 에서 점근 · SE + void 를 합친 상은 100 % 에서도 미수렴 | §3-C L111 · §3-D L126 · §3-E L133–137 | stated · 판독 (Fig S1) | 확산 계산 (역학 아님) · τ_diff 에 오차 막대 없음 · 도메인 외곽 경계조건 [미확인]
- [f] hamann2026_llzo_bilayer_porosity_asr_dendrite_ccd | 복셀 크기 · 격자 수 미기재 · 수렴 기준 = 전위 · 전극 면전류 상대 잔차 < 10⁻⁵ (식 S49 · S57) · 메모리는 겹치는 부분영역 분할로 GPU 에 올림 | §3.1 L110–111 · §4.4 L197–200 · §4.6 L210 | stated · [미확인] (복셀 크기) | 최대값 통계의 격자 수렴 근거 없음 (L365) · 전기화학 계산
- [f] islam2026_microstructure_resolved_impedance_lpscl_symmetric_cell | 2D 200 × 100 격자 · dx 3.75 µm · 입자 평균 반경 60 µm · "격자수렴 0 · 시드 0" | §4-2 L60 · §10 L118 | stated · 카드 서술 | 2D · FEM / phase-field


### [batch_17] f. MPM 의 접촉 · 다물체 · 강체 결합 방법과 해상도 규칙 · 수치 오차 추정

**이 배치에 없음** — MPM 을 쓴 카드가 없다. 아래 둘은 MPM 이 아니라 복셀 수송 계산의 해상도 자료 (참고용 — 쓸 수 있는 부분은 m 에 옮김).

- [f] ketter2025_resistor_network_models_predict_transport_properties | (MPM 아님 · 복셀 저항망) NCM 입자 = 복셀 1 개 (2 µm) · LPSCl 도메인 = 500 복셀 덩어리 (등가 지름 19.7 µm) · 거친 망 60³ (10 µm/복셀) 은 문턱 근처에서 자릿수로 무너짐 (σ_e @ φ_NCM 20 %: 3.3 × 10⁻¹¹ ↔ 300³ 0.00918 mS/cm) · 오차 관리 = 잔차 r < 10⁻⁹ K + 직렬 · 병렬 층상 해석해 재현 + Yuge 수정 EMT 재현 · 실현 (시드) 수는 n/a | §3-6 L142–151 · §4-2 L165–169 | SD · derived(ours) (부피 등가) · stated · n/a | 수송 계산 — 역학 · 접촉 없음
- [f] kim2026_a3d_air_electrode_microstructure_transport | (MPM 아님 · GeoDict 복셀) 0.01 µm/복셀 (≈ 8 µm 영역 · 축당 약 800 복셀) · foam 은 8 µm/복셀 로 두께 120 µm — 고른 이유는 "충분한 구조 정확도 + 합리적 계산 비용" 의 타협 · 수렴 시험은 카드에 없음 | §2.1 L145–155 | 표지 없음 | 수송 계산 · Li–O₂


### [batch_18] f. MPM 의 접촉 · 다물체 · 강체 결합 방법과 해상도 규칙 · 수치 오차 추정

**이 배치에 없음** — MPM 을 쓴 카드가 없다. 아래는 MPM 이 아니라 복셀 · 사다리 수송 계산의 해상도와 오차 추정 자료 (참고용 — 쓸 수 있는 부분은 m 에 옮김).

- [f] nakamura2020_dry_coating_ncm_li3ps4_core_shell | (MPM 아님 · 측정 구조 위 복셀 Poisson) 복셀 0.2 µm · 100³ = 20 µm 정육면체 1 개 (NCM 약 4 지름) · 저자 "sufficient spatial resolution" · 경계 = 두께 방향 1.0 / 0.0 V + 나머지 면 주기 · 계면 저항 항 없음. 카드 산술: SE 개수 D50 0.49 µm ≈ 2.5 복셀이라 SE–SE 목이 부분적으로만 풀림 · 측정 f ÷ 복셀 f = 1.65 (코팅) · 1.55 (혼합) = 복셀 값이 측정보다 **낮다**. 수렴 · 반복 · RVE 시험은 안 함 | §3-6 L124–125 · §4-2 L196 · §3-7 L170 · §6 L228 · §7-2 L253 | [인쇄] (설정) · [우리 산술 · 추정] (해상 · 비) | 수송 계산 — 역학 · 접촉 없음 · 측정과 복셀의 시료가 다름 (L320)
- [f] lee2026_unveiling_ptfe_dry_electrode_digital_twin | (MPM 아님 · GeoDict FVM) 복셀 20.83 × 20.83 × 50 nm (비등방 — 그림 범례는 "Voxel size: 20 nm") · 25 µm 정육면체 1 개 (NCM D50 7 µm 의 약 3.6 배) · 검증 = 부피분율 ↔ 밀도 기반 대조 (Table S1) 하나 (기공 차 −2.5 · −0.7 %p) · 분할 정확도 지표 · RVE 수렴 · 재구성 반복 [미확인]. 시뮬 ÷ 실측: σ_e 0.99 · 0.97 · σ_ion 1.46 · 1.42 (σ_LPSCl 입력 1.0 mS/cm 에 조건부) | §3-2 L84–86 · §4-2 L243 · §3-12 L226–228 · §10-2 L431 · §10-8 L437 | [인쇄] · [우리 산술] · [미확인] | 수송 계산 — 역학 없음
- [f] nguyen2020_electrode_tortuosity_factor | (MPM 아님 · 복셀 유한차분 TauFactor) 3D 구 충전 A: 입경 2 µm · 100³ 복셀 · 250 nm (내 검산: 지름당 8 복셀 · 한 변 12.5 지름) ↔ B: 입경 5 µm · 50³ 복셀 (지름당 20 복셀 · 한 변 2.5 지름) — B 는 모사 임피던스가 TLM 에서 벗어남 = 대표성 부족 신호 (p6–7). 오차 추정 대신 쓴 것 = 가장 단순한 구조의 교차검증 (곧은 관통 기공에서 두 방법 모두 τ = 1) + "TLM 45° 에서 벗어나면 부피가 비대표이거나 균질화 불가" 진단. 반복 실현 · 시드 통계 없음 | §3-1 L31 · L37–38 · §6 L126 · §6-bis L131 · L134 · §10 L217 | stated(그림) · stated · 내 검산 (지름당 복셀) | Table 1 은 복셀 1 µm (가정) ↔ Fig 5 캡션 250 nm (원문 불일치 L60) — 지름당 복셀 수는 캡션 값 기준 · 액체 LIB
- [f] landesfeind2018_tortuosity_impedance_vs_tomography | (MPM 아님 · X선 단층촬영 재구성 위 수치 확산) voxel 325 nm · 통계적으로 의미 있는 부피 (입자 수천 개) 를 보려면 ~1 mm³ 가 필요하고 그 해상도로는 바인더 · 탄소가 안 보임. 불확도로 보고한 것은 이진화 문턱 변화 (± 0.03–0.06) 뿐 · 고해상 재구성 (15 µm 큐브 · 입자 ~8 µm) 의 τ 2–7 은 비대표 (인용 Ref 17) | §4-6 L157–159 · §3 L78 · §8-2 L306–307 · §10 L369 | stated | 수송 · 영상 — 해상도 ↔ 대표 부피 맞바꿈의 실례
- [f] malifarge2017_tortuosity_symmetric_cell_impedance_tlm | (MPM 아님 · 1D 사다리 회로) 이산 사다리 (행렬 Kirchhoff · Eq 2–10) 는 해석식 Eq 11 로 O(1/n) 수렴 — n × 상대차 ≈ 0.89 (n = 101 · 401 · 1601 에서 같은 값) → n ≥ 100 이면 < 1 %. 원문은 n 을 적지 않음 | §4-3 L184 · 원문 대조 기록 L455 | 우리 재계산 | 카드 작성자의 검산 — 논문 수치 아님
- [f] morasch2018_binder_gradient_impedance_tortuosity | (MPM 아님 · RC 사다리) 카드가 원문 매개변수로 RC 사다리 4000 요소를 다시 풀어 원문 겉보기 저항 비 (0.750 · 1.250 · 0.531 · 1.656) 를 재현 · 균질 기준은 de Levie 해석해와 대조 (위상 극소 43.40°) | §3 L65 · §4-4 L128–129 | 파생 | 카드 검산
- [f] matthews2024_ptfe_nanofibril_network | (논문 내용 아님 — 카드가 적은 우리 복셀 규칙) 구 스탬프 게이트 d/vox ≥ 2 · 생산 복셀 0.15 µm · 30 nm 섬유를 풀려면 vox ≤ 0.015 µm (≈ 16 TB · dof ∝ vox⁻³ 외삽) → "격자로 닫히지 않는다" | §10.2 L568–583 | 🧮 DERIVED (ours) | 수송 격자의 첨가제 표현 — MPM 해상도 규칙 아님


### [batch_19] f. MPM 접촉 · 다물체 · 강체 결합 · 해상도 규칙 · 수치 오차 추정

(MPM 카드 없음 — 아래는 복셀 · FE · DEM 쪽 해상도 · 수치 오차 규칙)
- [f] taufactor_tortuosity_factor_tomography_tool | voxel 표면적 과대: 1 구 = 1 voxel → ×~2, 여러 voxel 구 → 최소 ×1.5, sub-voxel 복잡 구조 → 임의 과소 (Marching Cubes 안 씀 · 일관성 우선) | §3 L39 · Fig 7 · §10 L133 | stated | 면적 · 피복 metric 을 voxel 로 뽑으면 같은 한계
- [f] taufactor_tortuosity_factor_tomography_tool | sub-voxel 목 (throat) 소실 → τ 가 bulk 쪽으로 편향 (카드 예: SE ⌀1 µm 을 1 µm 격자로) | §10 L134 · L187 | 카드 풀이 | 우리 쪽 예시는 카드 서술
- [f] taufactor_tortuosity_factor_tomography_tool | 실증 사례 (Duquesnoy 2020): 1 µm/voxel · d_h/dx ≈ 1.00–1.03 → τ 가 같은 그룹 EIS (τ_TLM 1.3808 @ ε 31.5 %) 의 2.4–2.7 배 · active surface 가 100·ε/(1−ε) 와 R² 0.9964 (포화) — "TauFactor 는 정확했고, 입력 voxel 이 미해상이었다" | 역링크 절 L218–225 | 카드 산출 | 우리 규칙 d_h/dx ≳ 3.5 대조는 카드 서술
- [f] taufactor_tortuosity_factor_tomography_tool | 수렴 판정 = 상대변화 < 0.5 % 를 5 회 연속 + 위 · 아래 면 τ 차 < 4 % · 보고값 = 두 면 평균 · 이완 w = 2 − π/(1.5a); RVE 충분성 = RVA 4 종 (≈5 % 증분 · metric–부피 그래프) | 코드 대조 L239 · L249 · L253–254 · §4C L73 | 코드 대조 (1.424.0) · stated | MATLAB 실행 안 함 (정적 읽기)
- [f] tjaden2018_tortuosity_review_calculation_approaches | flux 알고리즘끼리 (RW vs LBM · RW vs FVM) 축별 τ 차 ≤ 0.04; RW 는 walker 10⁵ · step 10⁷ 로 정확도 확보; mesh 방법은 매개변수 감도 분석 필요 ("care must be taken … and sensitivity analyses should be carried out") | §3-C L86–91 · §3-A L55 · §4.4.3 L205 | stated · 우리 산술 | 기공상 · SOFC/LIB
- [f] tjaden2018_tortuosity_review_calculation_approaches | 해상도: 같은 Li-ion 양극 micro (597 nm) vs nano (65 nm) CT — ε 36.3 / 38.0 % · 기하 τ 2.0 / 1.9 비슷, 비표면적 0.6 / 1.3 µm²/µm³ (×2 이상) | §3-A L59 · §4.5 L219 | stated | 기공상 · 기하 τ
- [f] tjaden2018_tortuosity_review_calculation_approaches | RVE: Joos — l_cat > 10 µm 에서 평탄, 시료 2 LSCF 는 거의 2 배 두께 필요; Wilson vs Iwai 부피 9 배 차에도 τ 차 없음 (균질 시료) | §3-A L56 · L60 · §4.5 L221 | stated · 우리 산술 (9.24) | SOFC
- [f] song2025_porous_argyrodite_modulus_fracture_toughness | FE 수치 설정: 외팔보 3D C3D20 · 두께방향 요소 < 60 µm; CT 평면응력 CPS8/CPS6 · 1/4-점 중간절점 · 선단 요소 0.04–0.2 mm 로그 분포 · > 15 000 요소 · J 적분 5 경로 평균; 장치 검증 = Al 합금 영률 기지값과 < 2 % | §4.1 L110 · §4.2 L115 · §3.3 L75 | stated | 연속체 FE (입자 없음)
- [f] sangros2020_dem_electrical_conductive_paths_assb | DEM 쪽: 입자 6000 고정을 위해 조성마다 상자 크기를 바꿈 (6.8 → 2.43 µm · 고-CB 1.69 µm) · 조성당 구조 1 개 위주 (반복 수 불명) · x·y 주기 | §3 L49 · §4.6 L102–104 | stated · 카드 판독 (반복 수 불명) | 시드 반복으로 수치 산포를 재지 않음


### [batch_20] f. MPM 접촉 · 다물체 · 강체 결합 · 해상도 규칙 · 수치 오차 추정

MPM 카드 없음. 해상도 · 수치 오차 관련 (전부 MPM 아님).
- [f] wang2027_ncm811_effective_bulk_modulus_mapper_dfs_gnn | 복셀 FE 격자 수렴 (10³ · 20³ · 40³ · 80³ · 100³ 재사상): 80³ ↔ 100³ 차 0.36–0.75 % (평균 0.61 %) · 10³ 의 100³ 대비 상대 편차 1.04–2.01 (= 2–3 배 단단 · 거칠면 목이 굵어짐) · 40³ (복셀 0.45 µm) 부터 평탄 | 부록 D.2 L94–95 · 그림 D1 · §8-4 L358–359 | [인쇄] / [판독] | 복셀 FE · 입경 분포 [미확인] (L47) 이라 지름당 셀 수로 못 바꿈 · RVE 크기 수렴 시험 없음 (L289)
- [f] zhang2026_dryprocess_electrode_architecture_cell_level | PFIB z 슬라이스 250 nm > VGCF 직경 100 nm → 개별 섬유 해상 불가 → "CBD" 균질상 lumping (σ_CBD 700 S m⁻¹ 한 상수) · 카드: "선택이 아니라 해상도의 강제" | §5-2 L811–813 · §14-2 L1380–1384 | stated / 카드 풀이 | 영상 해상도 · 면내 픽셀 미보고 · REV / voxel 수렴 시험 n/a (L506)
- [f] yoo2026_porosity_gradient_dry_electrode | 같은 두께 방향 기공 구배가 XCT (픽셀 250 nm) 와 FIB-SEM (46.52 nm) 두 해상도에서 모두 보임 → "측정해상도 artifact 아님" | §4.3 L204–205 · Fig 5e | 표지 없음 | 영상 (계산 격자 아님)
- [f] vijay2025_hybrid_cgmd_dl_slurry_microstructure | 정규화 위치 오차를 물리 단위로 바꾸면 test ≈1.7 µm = 최근접 접촉 거리 (RDF 첫 봉우리 ≈2.5 µm) 의 ≈68 % · 건조 bead 지름 1.3 µm 의 ≈1.3 배 — 오차를 특징 크기 대비로 판정 · SI 비정규화 CV MeanAE 0.991–0.998 µm 가 환산 1.0 µm 와 1 % 안 | §10-D L558–566 | derived(ours) + figure-read | DL 좌표 오차 · 스케일러 범위 가정 (L567–569)


### [batch_21] f. MPM 의 접촉 · 다물체 · 강체 결합 · 해상도 규칙 · 수치 오차 추정

이 배치에 MPM 카드 없음. 해상도 · 수치 오차 관련만 (모두 MPM 아님):
- [f] zhou2026_gyroid_structural_electrolyte_stiffness_ionic_tradeoff | (복셀 FV 수송) 조화평균 면 복셀 FV 는 매끈한 기하에서 1 차 수렴 (오차 ∝ 1/N) · 덜 풀린 쪽이 늘 낮게 나옴 · 원문 대비 오차 ≈ −0.28/(d_h/dx) (시트 28 점 · d_h/dx 1.6–18.8 · 최대 잔차 1.3 %p) · d_h = V_liq/S · N 64 · 128 + 1 차 Richardson 외삽 | §7-3 L221–224 · §6 L178 | [우리 산술] | 카드의 독립 재현 (논문 값 아님) · 입자 목이 없어 '가짜 상호연결' 인공물은 이 규칙 밖 (L224) · 원문 FEM 은 메시 · 요소 · 수렴 정보 없음 (§3-1 L71)
- [f] bak2024_binder_distribution_multilayer | (GeoDict 복셀) CBD voxel 1 nm · 입경 20 nm / 전극 voxel 100 nm · NCM 입경 10 µm | §2.6 L160–164 (SI Table S1 · S2) | 표지 없음 | 수치 오차 추정 카드에 없음
- [f] asylbekov2023_cb_fragmentation_pbe_dem_dry_mixing | (DEM · PBE) CG 100 = Feng et al. [55] 에 따르면 방법의 상한 부근 · PBE RK4 Δt ≤ 0.1 s 면 시간간격 무관 · 크기 클래스 수 N 은 "결과 품질이 클래스 수에 크게 의존" 하는데 값 미보고 · Kumar 보정으로 질량보존이 격자 무관 | §3.5 L137–138 · L146–147 · §4.3 L288–296 | stated | DEM 응력 절대값은 독립 검증 없음 (§4.8 L395)
- [f] frankenberg2024_dem_high_intensity_mixer_assb | (DEM) Δt_sim = 0.2·πR*√(ρ/G*)/(0.8766 + 0.1631ν) ∝ R* · force-scaling 검증 = 같은 크기 두 입자 충돌 (ρ 1,250 kg/m³ · v 0.1 m/s · 거리 10 mm · friction 0.001) 의 force–time 곡선이 f² 를 따르는지 확인 | §3 L60 · §4.3 L97 | stated | —
- [f] duquesnoy2023_ml_multiobjective_manufacturing_optimization | 복셀 물성 추출 (GeoDict · TauFactor) 의 격자 수렴 미시험 (2020 → 2023 "바뀌지 않은 것") | §선행 논문 L363 | 표지 없음 (카드 비교표) | —


### [batch_22] f. MPM 의 접촉 · 다물체 · 강체 결합 · 해상도 규칙 (지름당 셀 수) · 수치 오차 추정

이 배치에 없음 (MPM 카드 없음 · 지름당 셀 수 규칙 없음). 관련만 (복셀 해상도):
- [f] han2025_icep_conductive_elastic_binder | 카드 규칙 — 7 nm 코팅은 sub-voxel (우리 복셀 ~0.14 µm 의 1/20) 이므로 resolved 상으로 깔지 말고 계면 성질 (AM–SE 접촉 conductance 수정 · coverage modifier) 로 · fibril (PTFE) 만 resolved 시딩 | §8-③ L146–148 | 카드 풀이 | MPM 아님 · 복셀 수송 쪽 규칙


### [batch_23] f. MPM 의 접촉 · 다물체 · 강체 결합 · 해상도 규칙 (지름당 셀 수) · 수치 오차 추정

이 배치에 없음 (MPM 카드 없음 · 지름당 셀 수 규칙 없음). 관련만:
- [f] kang2026_multiscale_inverse_design_ptfe_fibrillation_dry_electrode | 미시 FEM 의 PTFE 띠 두께 ≲1 µm (입자 10–20 µm 보다 한 자릿수 얇음) · 메시 크기 · 수렴 시험 미기재 — 카드: 우리 MPM `d_h/dx ≳ 3.5` 규칙과 같은 질문을 던질 그림 | §7-2 L279 · SI Fig 1c–d | [판독] · [추정] | FEM (MPM 아님) · 메시 미기재
- [f] kang2026_multiscale_inverse_design_ptfe_fibrillation_dry_electrode | 변형률 3–6 (학습표 최대 5.91) 의 대변형을 라그랑주 메시로 · 재메시 · 메시 수렴 언급 없음 — 카드 풀이: MLS-MPM 은 메시 엉킴이 없어 이런 대변형 바인더에 원리적으로 맞는 도구 (구성식 · 섬유화 판정은 새로 정의해야) | §7-2 L278 | [추정] · [미확인] | 카드 풀이
- [f] kang2026_multiscale_inverse_design_ptfe_fibrillation_dry_electrode | 오차 추정 = GPR 5-겹 CV (응력 모형만 · 무작위 폴드 = 같은 입경 곡선 안 보간) R² 0.989 / 0.995 · 메시 수렴 · 하중 속도 의존 · 입경 하나 빼기 검증 없음 | §3-7 L194 · §6 L256 · §10-12 L353 | [SI 코드] | 대리 모형 오차이지 FEM 이산화 오차 아님
- [f] kang2025_bollard_anchored_binder_dry_electrode | XRM (Xradia 810 Ultra) FOV 18×18×18 µm³ · 화소 128 nm — 카본 · 바인더는 X 선 투명이라 NMC 만 보이고 porosity 를 뽑지 못함 | §6.2 L564 · §6.3 L582 | stated | 영상 해상도 (계산 해상도 아님)


### [batch_24] f. MPM 의 접촉 · 다물체 · 강체 결합과 해상도 규칙 · 수치 오차 추정

이 배치에 없음 (MPM 카드 없음). 관련만 (다른 수치 해석의 해상도 · 오차 추정):
- [f] koo2026_swcnt_sheath_thick_electrode | FIB-SEM 820 장 · milling 32.5 nm · voxel 31.01 / 37.22 nm · 재구성 부피분율 ↔ 이론값 상대오차 6.56 % (CB-wet) / 5.45 % (SWCNT-dry) · 2C 방전 시뮬 ↔ 실측 상대오차 ~2.15 % | §5 L239–252 · §11.10 L943–945 · SI Note S2 · S4 · Fig S25 | 표지 없음 | 복셀 균질화 (MPM 아님) · 카드: 입력 σ_s 가 이미 전극 시트 측정값이라 Exp–Sim 일치는 "자기일관 검사" (L772–775)
- [f] koo2025_cnt_wrapped_sc_nca_dry_cathode | FIB-SEM 840 장 · voxel 32.5 · 37.22 nm · Unet 분할 · 재구성 ↔ 이론 부피분율 편차 (카드에 두 값 — 카드 문제) · σ_s,eff exp ↔ sim 편차 4.2 % | §4 L201–204 · L221–222 · §7 L337 | 표지 없음 | MPM 아님
- [f] lee2025_dual_fibrous_ptfe_dry_electrode | micro-CT 복셀 650 nm = rope Ø 248 nm 의 2.6 배 → "이 CT 는 피브릴을 원리적으로 못 본다" (CT 의 'pore–CB–PTFE' 상 = 세 상의 혼합 저밀도상) | §7 L262 · §13 L512–513 · Fig 3 | 표지 없음 (카드 판정) | 영상 해상도 사례 (MPM 아님)
- [f] lee2024_shear_force_dry_process_cathode_coverage | 논문의 "MPM" = multi-particle model (COMSOL 전기화학) — 물질점법과 다른 말 | 머리 L38 ⑤ · §3-6 L166 · §10 L383 | [인쇄] | 문헌 검색 · 인용 때 용어 충돌


### [batch_25] f. MPM 의 접촉 · 다물체 · 강체 결합 · 해상도 규칙 (지름당 셀 수) · 수치 오차 추정

이 배치에 없음 (MPM 카드 없음 · 지름당 셀 수 규칙 없음). 관련만 (DEM 의 해상도 · 수치 오차):
- [f] lischka2025_dem_eirich_intensive_mixer_dry_mixing | coarse-grain 상한을 정규화 관측량 (입자당 충돌률) 으로 CGF 100 · 150 · 200 · 400 · 800 을 올려 가며 찾음 → CGF ≤ 200 (d ≤ 2 mm) · CGF 400 · 800 은 "to induce deviations from the base case" 로 넣은 프로브 (상한은 위로 밀어 깨뜨려 본 것) · CGF 마다 넣은 γ 미보고 → 기하 수렴과 점착 재계산이 교락 | §3.4 L104 · §4.4 L206–210 · §10 ⑭ L509 | stated · 카드 판정 | DEM coarse-graining (MPM 아님)
- [f] lischka2025_dem_eirich_intensive_mixer_dry_mixing | 전단율 = 입자 데이터를 가우시안 가중으로 보간한 연속 속도장 — 커널 폭 · 격자 간격 미보고 (격자 의존 미보고) · timestep = Rayleigh 의 20 % | §4.1 L142–144 | stated · 카드 판정 | —
- [f] lippke2023_dem_drying_structure_formation_lib | 수치 오차 = loading 당 3 seed · 표준편차 "insignificantly low" (수치 미제시 · 시뮬 오차막대 없음) · 모세관력 스케일을 ≈9×10³ 넘게 올리면 겹침 과대 → 수치 불안정 | §3-B L128 · L130 · §4.8 L399–400 | stated | DEM


### [batch_26] f. MPM 의 접촉 · 다물체 · 강체 결합 · 해상도 규칙 · 수치 오차

이 배치에 없음 (MPM 을 쓴 카드 없음).
- (가까운 것 · MPM 아님) [f] sankar2026_fiber_scale_dem_carbon_felt_manufacturing | GeoDict 복셀 = 섬유 지름의 1/4 · PSD bin = 2 복셀 (9 · 11.5 µm) · 카드: D 값의 0.01 µm 표기는 bin 보다 작은 차이를 해상하지 못한 거짓 정밀 | §3.1 줄 129–130 · §3.3 줄 159 · L14 줄 604 | stated · 카드 비판 | 복셀 수송 해석의 해상도 규칙 · 수렴 시험 없음
- (가까운 것 · MPM 아님) [f] qin2026_bilayer_cathode_cgmd_dem_graded_thick_electrode | PNM 목 지름 하한 0.40 µm 의 근거 미기재 · c40 분포가 하한에 붙음 = 해상도 제한 · 복셀 크기 · 복셀화 규칙 미기재 | §3.8 줄 253 · L-8 줄 502 · §4.7 줄 312 | figure-read ≈ · [미확인] | 수치 오차 추정 없음


### [batch_27] f. MPM 접촉 · 다물체 · 강체 결합 · 해상도 규칙 · 수치 오차

이 배치에 없음 (MPM 카드 없음).  인접 근거 (다른 방법의 해상도 · 수치 오차 기록):
- [f] wet_processing_resolved_am_ssb_cathode_manufacturing | (DEM) multisphere 강체 = harmonic bond κ 1×10⁶ pg µs⁻² ≈ 1000 N/m · 1 차 구 pitch 0.98 µm (≈50 개/입자 · 카드 어림) · 카드: JKR 인력 (≈1.1 mN) 옆에서 강체성이 자동 보장 안 됨 · 2 차 입자 실제 변형량 미보고; GeoDict voxel 크기 미보고 (감사 불가); 오차 막대 = 반복의 standard error · 반복 수 미보고; 'energy was unable to reach full equilibrium' | §①-B 줄 371–378 · §①-A 줄 322 · §①-F 줄 420 · §4 줄 89 · §①-E 줄 408 | stated (SI) · 카드 환산 · 우리 산출 | MPM 아님
- [f] sun2026_dem_extrusion_recirculation_dry_electrode | (DEM) Δt = 0.15 Δt_c (Rayleigh · AM 지배); GeoDict 복셀 해상도 · 도메인 · 경계조건 본문에 없음 (n/a); 조건당 1 런 · 오차 막대 · 앙상블 없음 | §3 라 줄 107 · §4.1 줄 188–189 · §4.5 줄 256 | stated | MPM 아님
- [f] bucci2017_chemomech_failure_assb_cycling_czm | (FEM) deal.II 선형 사각 요소 + intrinsic CZM (균열 경로에 응집 요소를 미리 넣음) · 낮은 G_c 에서 마지막 (포화) 단계가 미리 넣은 경로에 치우칠 수 있음 — 저자 'even if about 10 % of the pre-inserted cohesive interfaces remain unfractured' · 메시 수렴 기록 카드에 없음 | §4.2 줄 181–183 · 193–194 | stated (저자 자인) | MPM 아님 · 2D


### [batch_28] f. MPM 의 접촉 · 다물체 · 강체 결합 방법과 해상도 규칙 · 수치 오차

이 배치에 없음 (MPM 을 쓴 카드 없음).
- (가까운 것 · MPM 아님) [f] dem_mechanical_stresses_ssb_electrode_cycling | DEM → 복셀 0.5 µm (AM 3–10 µm · SE 6–13 µm) · AM–SE 겹침 복셀은 영률 높은 쪽 (AM) 에 배정 · z 1 V / Δc · 측방 주기 · 해상도 수렴 시험 카드에 없음 | §4.7 줄 168–169 | stated | 수송 후처리
- (가까운 것 · MPM 아님) [f] intergranular_cracking_nmc811_jmca2023 | phase-field FEM ~4 M 요소 · 13 M DOF · MUMPS · 2 차 backward Euler + time-step sensitivity · CT 화소 ~124 nm 아래 균열은 해상 못 해 부분 부피로 간접 보정 | §4-B 줄 134–135 · §3 줄 93 · §6 줄 189–190 | stated | 오차 크기 카드에 없음
- (가까운 것 · MPM 아님) [f] bucci2018_mechanical_instability_interface_delamination | FPT: 입자 표면 2160 삼각형 · walker 1000 · step = 반경의 1 % | §4.5 줄 178 | stated | 이산화 오차 추정 카드에 없음


### [batch_29] f. MPM 의 접촉 · 다물체 · 강체 결합 방법과 해상도 규칙 · 수치 오차 추정

이 배치에 없음 (MPM 을 쓴 카드 없음). 수치 검산 방법으로 쓸 만한 것은 siroma2015 의 이산 사다리 대조 하나 (m 절).


### [batch_30] f — MPM 접촉 · 다물체 · 강체 결합 · 해상도 규칙 · 수치 오차

- [f] 이 배치에 MPM 없음.
- [f] park2020_digitaltwin_assb_foundational | (MPM 아닌 voxel 구조 생성) GeoDict voxel 0.5 µm · seed 1–5 · 부피분율이 목표 대비 "within a 2% error range" (%p 인지 상대 % 인지 미기술) · σ 시뮬 밴드 = 5 seed 범위 · 잘린 입자는 주기 함수로 반대편에 생성 | §2 (줄 154–183) · Fig 1d · §4 (줄 352) | stated | 수렴 시험 아님 · 지름당 셀 수 규칙 없음
- [f] lee2023_sicspe_digitaltwin_assb | voxel 0.2 µm · 도메인 40 × 40 µm × 두께 · 균일 구 NMC D50 8.0 · LPSCl D50 2.3 µm | §2.3 (줄 105–107) | 표지 없음 | 수렴 시험 카드에 없음
- [f] wheatcroft2023_nmc811_secondary_particle_fracture_insitu_sem | FE 메시 수렴 · 요소 종류 미기재 | §6 (줄 309) | 카드 기록 | 수치 오차 추정 없음


### [batch_31] f — MPM 접촉 · 다물체 · 강체 결합 · 해상도 규칙

- [f] 이 배치에 없음 (MPM 카드 없음).
- [f] balasubramanian2026_rfb_electrolyte_kmc_lbm_preprint | (참고 · MPM 아님) LBM 복셀 1 µm 에 섬유 지름 4.7 µm = 지름당 ≈ 4.7 복셀 — 얇은 섬유 쪽 경계 표현이 거칢 · 수렴 검토는 SI S6 · S9 (미보유) | §10-3 (줄 96) · §3-2 (줄 43) | [우리 산술] · [미확인] | 액체 유동 LBM · 접촉 · 다물체 없음


### [batch_32] f — MPM 접촉 · 다물체 · 강체 결합 · 해상도 규칙 · 수치 오차

- [f] 이 배치에 없음 — MPM (material point method) 카드는 없다.
- [f] eizenhammer2026_lfp_psd_halfcell_many_particle_fullcell | 함정: 이 논문의 "MPM" = many-particle model (다입자 전기화학 모델) — material point method 와 무관 · 입자 수 수렴 (대표입자 N 100 진동 · 1000 감소 · 10⁴ 무시 가능) 은 공간 해상도가 아님 | 카드 머리 ① (줄 10) · §4.6 (줄 201) · Fig. 10 (p.32–33) | stated (정성) | 상분리 물질 한정 · C-rate 미기재
- [f] huang2025_dem_lbm_heat_conduction_composite_cathode | (MPM 아님 · voxel LBM 열 수송) 격자 1 µm · mesh 독립성 5 해상도 (1 · 2 · 1.333 · 0.667 · 0.5 µm) 에서 ETC 불변 (한 경우: 기공 21.1 % · LCO 5 / LLZO 10 µm · 1:1) · 수렴 L² < 1×10⁻⁷ K (~6×10⁵ iteration) · LBM 안정창 ω 0.4–0.95 → 상마다 시간척도 다르게 (LCO 10 + LLZO 1 iteration / step) | §4 (B) (줄 66 · 74–77) | stated | 입자 3 · 5 · 6 · 10 µm (지름 · 반지름 구분 카드에 없음) · 해상도 확인은 한 경우뿐 · 열만


### [batch_33] f — MPM 접촉 · 다물체 · 강체 결합 · 해상도 규칙 · 수치 오차

MPM 접촉 · 다물체 · 강체 결합 방법은 이 배치에 없음.  복셀 넓이 연산자의 해상도 규칙만:

- [f] lindblad2005 | 해상도 규칙 (논문 값): 가중 (A₁ 0.636) 에서 구 |편향| ≤ 0.1 % (r ≥ 2 voxel) · CV ≈3 % (r 2) · 0.7 % (r 5) · 0.25 % (r 10) · 최대 AD ≈9 % (r 3.5) → 2.6 % (r 7) → 0.7 % (r 20); 평면 면을 가진 물체 (정육면체 · 원기둥 · 구모자) 는 r ≈2 에서 −6 … −8 % · r 10 에서 ≈ −2 %; 격자 정렬 평면 최악 7.3 % 는 해상도를 올려도 남음 (국소 추정기 = multigrid 수렴 없음).  수치 오차 추정 = 무작위 위치 · 방향 Gauss 디지털화 반복 (Table 3 = 100,000 회 · 크기 사다리 = 물체별 150,000 개) 의 편향 · CV · mean AD · max AD | Fig. 13 · Fig. 15 · Table 3 · p.118–121 · §10 2 · 5 | figure-read ≈ (Fig. 13 · 15) · stated (Table 3 · 7.3 %) | 이진 영상 넓이 추정 (접촉 · 역학 아님) · 카드가 우리 r/h 로 옮긴 pilot 값 (§7-3 표 A · B · C) 은 카드 줄 5 · 232 의 "인용 전 재계산" 조건이라 숫자를 옮기지 않음
- [f] lawrence2008 | (참고 · 카드 산술) MPM 섬유 표현 = sub-grid 재료점 (중공 · 층 표현 없음); 중공관 → 중실 재료점 환산 인자 축강성 1 − (d/D)² = 0.55–0.96 · 굽힘 1 − (d/D)⁴ = 0.79–1.00 → 실측 중앙값 55 GPa 와 모델 입력 10 GPa 의 간격을 못 메움 | §7 표 (값의 종류 · 표현 행) | DERIVED (카드) | 접촉 · 해상도 규칙 아님


### [batch_34] f — MPM 접촉 · 다물체 · 강체 결합 · 해상도 규칙

- [f] neumann2021_garnet_3d_structure_grain_boundaries_li_transport | MPM 아님 — 복셀 연속체 참고값: 분할 0.1 µm → 계산 voxel 0.5 µm · 입자 지름 3.1–4.6 µm = 6–9 voxel · 축소 뒤 입자 번호 규칙 · 격자 수렴 · 실현 수 미기재. 저자: "due to the spatial resolution … the lithium distribution algorithm most likely overestimates the residual lithium content needed for a percolating network" | §0-1 L15–17 · §4-1 L139–140 · §4-5 L163 · §3-6 L134 (p.4798) | stated · n/a | 소결 garnet · 역학 없음 · 수치 오차 추정 없음
- 나머지 6 장: 이 배치에 없음.


### [batch_35] f — MPM 접촉 · 다물체 · 강체 결합 · 해상도 규칙 · 수치 오차

MPM 카드는 이 배치에 없음.  복셀 · 영상 계산의 해상도 규칙만:

- [f] park2019_electrode_design_methodology_assb_3d | 복셀 0.1 µm = *"approximately a third of the smallest LSTP particle"* (p.125) → LSTP 지름 2.5–5 voxel · **격자 수렴 시험 없음** · RVE 시험 = 도메인 25–200 µm 에서 a_s CV 2.0 · 1.4 % · σ_ion (3 도메인만) 40 % CV 0.85 % · 20 % CV 53 % · 실현 반복 없음 | §3-B (줄 81 · 90) · §4-6 (줄 226–231) · SI Fig. S2–S3 | stated · 우리 산술 (voxel 수 · CV) | 산화물 · 복셀 FVM (접촉 저항 0)
- [f] song2025 | FIB-SEM 43.78 nm 화소 → 계산비용 때문에 600 nm/voxel 로 낮춰 8 절점 고체 요소 · CBM (sub-µm 탄소) 은 개별 입자화 불가 → 목표 부피분율 연속상 · 도메인 30×70.8×30 µm³ (Table 1) ↔ Fig 1E 90×90×90 µm³ · 방전 곡선 하나 ≈2 주 (64 코어) · 격자 수렴 시험 카드에 없음 | §2.2 (줄 115–126) · §3 (줄 191–193) | 표지 없음 | 1차입자 0.5–1.5 µm 대비 해상도 비는 카드에 없음
- [f] pan2026 | μCT 0.5 µm voxel · 평균 공극 지름 3.1–4.2 µm (6–8 voxel) · 목 둘레 9–15 µm (18–30 voxel) > Nyquist 2–4 voxel 을 해상도 근거로 · CBD (100–300 nm) 미해상 → 고체 쪽에 합침 · PNM 편향 *"uniform across all configurations"* (주장 · 검증 없음) | §3-1-2 (줄 80–83) · §10-1-8 (줄 421) · p.38–42 | [인쇄] | 영상 해상도 규칙 (계산 격자 아님)
- [f] otani2023 | 2D 무작위 행보 (행보자 200 개) · 그림 크기 · 화소 · 시료 수 · 반복 [미확인] · 오차 추정 없음 | §3-1 (줄 64–65) | [인쇄] · [미확인] | —


### [batch_36] f — MPM 접촉 · 다물체 · 강체 결합 · 해상도 규칙 · 수치 오차

MPM 카드는 이 배치에 없음.  복셀 · 영상 계산의 해상도 규칙과 오차 추정법만:

- [f] windreich2003_voxel_based_surface_area_estimation | 복셀 넓이 (노출 면 배치로 가중하는 국소 추정기) 의 해상도 규칙: 구 반경 2 voxel 에서 평균 상대오차 < 1 % · 반경 > 10 에서 사실상 0 (물체 · 배경 평균) · CV ≈4 % (r 2) → 0.5 % (r 5) · 무작위 방향 평면 CV 2.33 % (최악 경우).  오차 추정법 = 반경마다 중심을 단위 voxel 안 균일 무작위 50 개로 놓고 해석해 (구 넓이 · 타원 적분) 대비 평균 상대오차와 CV 를 따로 본다.  국소 추정기는 multigrid 수렴 (해상도 → ∞ 에서 참값) 이 없고 (저자), marching cubes 삼각형 넓이 합도 해상도를 올려도 참 넓이로 수렴하지 않는다 (Klette 등 [7]) | §3-2 (줄 58–72) · §4-2 (줄 96–97) · §4-3 (줄 99–103) · p.2532 · 2535 · 2537 · Fig. 6 · 7 | stated (본문) · figure-read ≈ (r 2 +0.97 % 등) | 볼록 형상뿐 · 디지털화 규칙 미기재 · 계산 격자가 아니라 넓이 측정 규칙
- [f] ziegel2010_surface_area_measure_digitizations | 2×2×2 배치 수 가중 추정기의 점근 (t → 0) 최악 상대오차 최솟값 3.98 % (기존 가중 7.3 % · 12.8 %).  유한 해상도 시뮬: 단위 구 r/t 10 (t 0.1) 최대 0.9–1.5 % · 원기둥 r/t 18 (t 0.055) 0.2–0.4 % — 오차 추정 = 10 회 무작위 위치의 최대 상대오차.  작은 구 (r/h < 3) 에서는 r = 0 가중이 −14 % (r/h 1.67) · −40 % (1.0) · −86 % (0.625).  MPM 측정 격자의 SE 셀 판정 (점 수 n/8 ≥ ½) 은 부피 문턱 디지털화 부류 — 원문은 점근 항등식이 부피 문턱에도 성립한다고 적지만 (p.65) 가중치 값이 그대로 옮는지는 보이지 않았다 | §3-3 (줄 62–69) · §3-4 (줄 76–78) · §7-2 (줄 132) · §7-3 (줄 135) · §7-4 (줄 143) · p.65 · 71 · Fig. 7 · 8 | stated · pilot(ours) (작은 구) · n/a (부피 문턱 가중) | 점근 결과 · 평행이동만 무작위 · pilot 은 scratch 1 회 (원문 값 아님 · 인용 전 재현 필요)
- [f] zhang2023_pfib_multiscale_imaging_4d_thick_cathode | 영상 → FE 격자: 원 복셀 15.2 × 15.2 × 100 nm³ (비등방) → tortuosity 용 100 nm 등방 리샘플 · 전기화학용 하위체적 33 × 33 × 71.5 µm³ (전 두께 유지 · 측방만 축소 · 균질성 확인) → INNOV 메싱 ≈2.3 M 요소 → COMSOL.  선형 솔버 · 시간 적분 · 수렴 판정 · 격자 수렴 시험 · 세그멘테이션 불확실도는 미보고 | §4-1 (줄 195–207) · §4-2 (줄 209–218) · §4-3 (줄 238) · §10-B 7 (줄 498) · Fig S6 | stated · 카드 판정 (미보고) | 액체 LIB · 수치 오차 추정 없음
- [f] wiedenmann2013_pore_structure_ion_conductivity_ceramic_diaphragms | 단층 재구성 370 nm → 660³ voxel @ 740 nm 부분부피 (모서리 488 µm) · 대표 부피 비 (모서리 ÷ r_max) 42–170 · PSD (기공 부피 · r50) 재현성 SD 4–10 % (대개 < 5 %) · τ_geo = 60,269–419,079 쌍 평균 (SD 0.10–0.24) · 원문 *"segmentation by 3-D thresholding can represent a significant source of errors"* · R² · RMSE 는 내지 않음 | §3-A (줄 71–73) · §3-B (줄 87–94) · §3-C ⑮ (줄 116) · §6 (줄 220) · p.1450–1453 · Table 2 | stated · 우리 산술 (대표 부피 비) | 영상 해상도 규칙 (계산 격자 아님) · 액체 격막
- wang2018 · zhang2026: 해당 없음.


### [batch_37] f — MPM 접촉 · 다물체 · 강체 결합 · 해상도 규칙 · 수치 오차

이 배치에 없음.


### [batch_38] f — MPM 접촉 · 다물체 · 강체 결합 · 해상도 규칙 · 수치 오차

MPM 카드 없음.  참고 (FEM · 수치 오차를 추정하지 않은 사례):

- [f] yuan2026 | FEM (Ansys LS-DYNA · 선형탄성 명시적 동역학 · 2D): 압자 1822 요소 / 1891 절점 · 무첨가 13104 / 13345 · 층상 14926 / 15236 (4 절점 사각형) — 격자 수렴 시험 없음 · 접촉 알고리즘 · 밀도 · 감쇠 · 시간 간격 미기재 · 층상 시트는 실제 3.8 nm 를 ≈0.5 µm × ≈4.5 µm '집합 단위' 강체로 단순화 | §4b 줄 190–193 · §4d 줄 222 · Table S2 | 본문 (SI) 값 · figure-read (시트 치수) | MPM 아님 · 고분자 전해질


### [batch_39] f. MPM 의 접촉 · 다물체 · 강체 결합 방법과 해상도 규칙

이 배치에 없음.


### [batch_40] f — MPM 접촉 · 다물체 · 강체 결합 · 해상도 규칙 · 수치 오차

- [f] gritton2017_mpm_chemomechanical_coupling_silicon_anode | **접촉 알고리즘 없음** — 본문 · 참고문헌에 'contact' 0 회 · 기둥은 기판에 *affixed* (한 속도장으로 붙음 · 미끄럼 · 분리 없음) · 기판으로의 확산 없음 (거는 방법 미인쇄) | 카드 §4-7 · 머리 ③ · 논문 §4.6 p.17 · §4.7 p.19 | 인쇄 + [카드 전문 검색] · "한 속도장" 은 [카드 판독] | 다물체 · 마찰 · 강체 결합의 방법을 주지 않음
- [f] gritton2017_mpm_chemomechanical_coupling_silicon_anode | 이산화 = CPDI 변종 (ref. [38]) · Uintah · 시간 간격 dt = min(dx/(c_s + v), dx²/2D) 를 매 걸음 다시 계산 (식 43–45 · 안전계수 미인쇄) · 1D 검증은 셀당 입자 2 · 3D 는 격자 간격 · 셀당 입자 수 · 입자 수 미인쇄 (작은 기둥의 입자 영역 ≈ 40 개/지름 · 간격 ≈ 2.5 nm) | 카드 §3-2 · §4-1 · §4-6 · 논문 p.3 · 5 · 12 | 인쇄 · 3D 입자 영역 수는 [판독] | **지름당 셀 수 같은 해상도 규칙은 없다** · 'explicit' 낱말도 본문에 없음 ([카드 판독])
- [f] gritton2017_mpm_chemomechanical_coupling_silicon_anode | 수치 오차 추정 = 1D 확산 해석해 대비 입자별 상대오차의 노름 (식 14 · 15): 오차 0.56 · 0.049 · 0.0123 · 0.0068 · 0.0037 · 0.0016 · 0.00079 (h 0.1 → 0.001) · 저자 판정 O(h) · 인쇄된 노름 √(Σe²)/N 을 RMS 로 되돌리면 0.123 → 0.035 (h 0.02 → 0.001 · 기울기 ≈ 0.42) | 카드 §3-3 · 논문 §2.2 p.5–6 · Fig. 1 | 오차 값 = [판독] · O(h) = 인쇄 · RMS 환산 = [카드 산술] | 순수 확산 1D 뿐 — 역학 · 결합 · 3D 의 수렴 시험 없음 · 식 (13) 지수에 t 누락 (인쇄 어긋남)
- [f] gritton2017_mpm_chemomechanical_coupling_silicon_anode | **질량 (밀도) 스케일링**: 탄성파 시간 간격 (인쇄 6.8 × 10⁻¹¹ s · 산술 1.47 × 10⁻¹² s) ≪ 확산 시간 간격 0.05 s → 밀도를 인위로 올림 · 근거 = 준정적 ∇·σ = 0 (식 42) · a = (2G/ρ)∇·ε_dev + (3K/ρ)∇·ε_vol (식 49) · 시험 = 밀도 10⁵ 배 · 10⁶ 배 차 두 쌍 (2.33e3 ↔ 2.33e8 · 2.33e18 ↔ 2.33e24 kg/m³ — 본문은 둘 다 *five orders*) 이 *qualitatively* 같음 · 윤곽 높이 차 ≤ 1 % · 겉면 속도 ÷ 종파속 ≈ 5e-5 ↔ 1.6e-2 · 6e-6 ↔ 6e-3 | 카드 §3-4 · §4-6 · §8-2 · 논문 §4.1–4.2.1 p.11–14 · Fig. 3 · 4 | 식 · 밀도 · 저자 판정 = 인쇄 · 높이 차 = [판독] · 속도 비 = [판독 · 카드 산술] | 판정이 눈 대조 (응력 · 에너지 비교 없음) · 본 계산에 쓴 밀도 미인쇄 · 자유 팽창 문제 (가압 아님)


### [batch_41] f — MPM 접촉 · 다물체 · 강체 결합 · 해상도 규칙 · 수치 오차

- [f] bardenhagen2005_mpm_foam_densification_simulation | **접촉 = no-slip** (*"elastic material models and no-slip contact are used in these simulations"*) · 알고리즘 이름 · 접촉 거리 · 분리 판정 미기재 · 한 물체 (뼈대) 의 자기 접촉이라 격자 한 벌의 속도장이 주는 붙는 접촉으로 읽힘 · 마찰 미끄럼은 *"will be studied later"* · 같은 제1 저자의 다물체 마찰 접촉 (2000 · 2001) 은 인용만 | 카드 머리 ③ · §4-3 · 논문 p.600–601 | 인용문 = 인쇄 · "한 속도장" 은 [카드 판독] | 다물체 · 마찰 · 강체 결합의 방법을 주지 않음
- [f] bardenhagen2005_mpm_foam_densification_simulation | 기법 = GIMP (MPM 을 특수한 경우로 포함) · *"the contiguous particle GIMP method used here"* · 명시적 적분 · 격자는 매 걸음 처음 배치로 되돌림 (*"eliminating mesh tangling problems"*) · 형상 이산화 = 규칙 격자의 후보점 가운데 물체 안의 점에 물질점 (*"similar to using pixels to represent an image"*) | 카드 §4-1 · 논문 p.600–603 | 인쇄 | 보간 함수 · 갱신식은 논문에 없음 (Bardenhagen and Kober 2004 로 넘김)
- [f] bardenhagen2005_mpm_foam_densification_simulation | 해상도: 꽉 찬 블록 1 mm³ 에 셀 0.01 mm (한 변 100 셀) · 발포체도 "같은 이산화" · **단위 셀 변 길이 · 셀당 물질점 수 · 물질점 수 미인쇄** · strut 지름 ÷ 셀 변 ≈ 0.10–0.14 (셀 변이 1 mm 라면 지름당 10–14 셀) · **격자 수렴 시험 없음** | 카드 §3-2 · §3-10 · 논문 p.603 · p.605 · Fig. 2 | 셀 크기 = 인쇄 · 지름비 = [판독] · 괄호는 [카드 산술 · 가정] | 지름당 셀 수 같은 해상도 규칙을 주지 않음
- [f] bardenhagen2005_mpm_foam_densification_simulation | 수치 오차 추정 = 꽉 찬 블록의 일축 변형 압축 ↔ 해석해 한 건: 끝 (ε 0.9) 오차 *"approximately 5%"* — 수치 286,061 ↔ 해석 271,063 MPa (+5.5 %) · 구간 평균 (수치 ÷ 해석 − 1) +6.6 % (ε 0.1–0.3) · +6.0 % (0.3–0.5) · +5.7 % (0.5–0.7) · +5.8 % (0.7–0.8) · +5.5 % (0.8–0.9) · 큰 변형률의 튐 = 물질점이 셀 경계를 넘을 때의 오차 · ε 0.9 에서 응력 5 % = 판 위치 0.32 셀 | 카드 §3-3 · 논문 p.603 · Fig. 1 | "5 %" · 튐의 원인 = 인쇄 · 값 · 구간 평균 = [판독] · 0.32 셀 = [카드 산술] | 접촉 없는 균질 블록뿐 — 발포체 계산의 오차 추정은 없음 · 구간 평균이 한쪽으로 치우친 원인 미기재
- [f] bardenhagen2005_mpm_foam_densification_simulation | **준정적 설정**: 판 속도 = 종파속의 3 % (96.8 m/s) · 90 % 압축에 파 통과 시간의 30 배 · 인공 점성 (계수 미인쇄) · 절반 속도 런 1 건과 *"similar"* → 빠른 속도 채택.  구간 평균 반력의 비 (빠름 ÷ 느림) 1.02 (ε 0.05–0.3) · 1.35 (0.3–0.55) · 1.09 (0.55–0.7) · ε 0.7 에서 361 ↔ 289 MPa · 구조의 겉보기 파속 기준으로는 판 속도 0.05–0.12 | 카드 §3-2 · §3-4 · 논문 p.603 · p.606 · Fig. 4 | 설정 · 판정문 = 인쇄 · m/s = [카드 산술] · 비 · 값 = [판독 · 카드 산술] | 판정이 눈 대조 (에너지 · 수치 기준 없음) · 탄성 발포체 · 재하율 효과의 방향이 우리 MPM 과 반대 (카드 §9 ⑥)
- [f] bardenhagen2005_mpm_foam_densification_simulation | 붙는 접촉의 틈: 한 속도장의 접촉은 셀 크기 급 거리에서 걸리므로 strut 지름 10–14 셀 · 틈 0.5–1 셀이면 틈이 뼈대 부피의 7–21 % = ε 0.9 에서 기공 5–20 %p 급 — 그 논문은 재지 않음 | 카드 §9 ⑩ | [카드 추론 · 카드 산술 · 가정: 단위 셀 1 mm] | 논문 주장 아님


### [batch_42] f — MPM 접촉 · 다물체 · 강체 결합 · 해상도 규칙 · 수치 오차

- [f] pycompact2025_dem_mpfem_workflow | **고친 값 (FE 해상도 규칙 — MPM 아님)**: 95 % 밀도 축응력 그림 다섯 점 1641 · 1529 · 1469 · 1398 · 1379 MPa (500 → 2500 요소/입자) — 마지막 증분 **−1.4 %** (그림 = 평탄화) ↔ 본문 2500 = **1310** MPa (−6.3 %) — 수렴 판정이 원문 안에서 갈린다 · 옛 '−5 % · 미수렴' 철회 · 지름당 요소 변 ≈4.8 → 8.3 개 (2000 요소 ≈7.7 개) | 카드 §3.4 · §9.1 · Fig 3(e) p.5 · 본문 p.6 | [판독] (1 화소 = 4.8 MPa · 두 판독 일치) · [카드 산술 — 같은 크기 정사면체 가정] | Coarse 만 · 금속


### [layer3] f. MPM 의 접촉 · 다물체 · 강체 결합 방법과 해상도 규칙 · 수치 오차

- [f] bardenhagen2000_mpm_granular_multibody_frictional_contact + bardenhagen2001_mpm_improved_contact_granular_stress_waves | MPM 다물체 접촉 판정은 "같은 노드를 공유" 하는 순간 = 표면이 닿기 전 셀 크기 거리에서 걸림 ("Resolution of the interface is commensurate with the computational grid cell size") → 입자별 속도장 (A′) 의 압밀 기공률은 dx 수렴을 먼저 보여야 실험 표적과 비교 가능 · 2 차 B-spline 은 지지 3 셀이라 1 차보다 그 거리가 김 | §A L953 | 원문 인용 · 뒤 절반 = "우리 추론" | 지름당 셀 수 규칙 값은 이 줄에 없음
- [f] nezamabadi2022_mpm_cd_plastic_particle_compaction | 해석식 (5)–(17) = 재밍 뒤 다공 연속체 압밀식 (Kováčik 유효계수 · 맞춤 4 + Φc) — 맞춘 p_c 를 모델끼리 비교 (단일 속도장 MPM 의 p_c 가 재밍 기공률보다 크면 결합 골격 가설의 간접 증거) | §A L950–951 | 표지 없음 | 2D 맞춤값 (f_E 1.2 · f_G 0.2 · α 2.5) 전이 금지
- [f] he2026_dem_calendering_inhomogeneity_areal_density + ngandjong2021_dem_calendering_digital_twin | (묶음 · DEM 쪽 준정적 기준점) 재하율 Mach ≈ 1e-6 (He) · 3.1×10⁻⁷–1.4×10⁻⁶ (Ngandjong) ↔ 우리 MPM `--platen-mach 0.03` = 10⁴–10⁵ 배 차 | §A L867 · L246–247 | derived(ours) | DEM ↔ MPM 이라 직접 비교 아님 (L247)
- [f] bardenhagen2000_mpm_granular_multibody_frictional_contact | MPM 다물체 마찰 접촉 원전: 알갱이마다 격자 속도장 v_i^g + 질량 가중 평균 (질량중심) 속도장 v_i · 두 장이 다른 노드 = 접촉 · 다가오면 [(v_i^g − v_i)·n_i^g > 0] 법선 성분을 v_i 것으로 · 접선은 Coulomb (μ′ = min(μ, 붙임 비)) · 멀어지면 자유 분리 — 식 (23) 한 줄 · 짝 탐색 · 반복 없음 · 알갱이 수에 선형 · 원문 "Because the velocity field is single-valued, interpenetration of material is precluded, and also no-slip contact between impinging bodies is automatic" (§2) | §C L2713–2716 | 원문 인용 | 2D · 압밀 없음 (경사면 원판 + 원판 369 개 전단) · Comput. Methods Appl. Mech. Engrg. 187, 529–541 (2000)
- [f] bardenhagen2000_mpm_granular_multibody_frictional_contact | 해상도 규칙: 지름당 ≈ 8 요소면 접촉력 해상 · 4 요소는 내부 응력 · 구름에 부족 · 16 요소 ≈ 해석해 (Fig 4) — 우리 SE 1 µm 는 dx 0.141 µm (n_grid 384) 에서 ≈ 7 셀 | §C L2719 | 표지 없음 | 2D · 수치 오차 추정 방법은 이 줄에 없음 (해석해 대조)
- [f] bardenhagen2000_mpm_granular_multibody_frictional_contact | 3D 규모 산술: 알갱이별 장을 통째로 두면 real_14 (SE 씨앗 32,832 · ≥ 384³ 노드 · f32 장당 ≈ 0.91 GB) 에서 ≈ 30 TB → '색칠' 장 (같은 노드를 공유하지 않는 알갱이끼리 한 장) · 노드당 희소 슬롯 | §C L2718 | "우리, 논문 밖" 산술 | 
- [f] bardenhagen2001_mpm_improved_contact_granular_stress_waves | 개정판: 견인력 기반 분리 판정 + 격자 붕괴 안정화 ε̇_max Δt < γ (γ = 0.5 · 미만이면 침투) · 물체별 운동량 꼴 v^α = p^α/m^α · 분석은 접촉 노드당 물체 ≤ 2 (N > 2 에선 일부 성질 불성립) · 인쇄 함정: 식 (22) 'max' → 'min' · 식 (19) 부호 · t = ω × n (2000 판과 곱 순서 반대) | §C L2722–2726 | "우리 판독" | 압밀 없음 (구 1 개 회귀 시험 + 원판 ≤ 5 개) · CMES vol. 2, no. 4, 509–522 (2001)
- [f] nezamabadi2022_mpm_cd_plastic_particle_compaction | 입자마다 자기 배경격자 (암시적 MPM) + 공통 격자 위 Contact Dynamics (마찰 0) 로 원판 300 개 압밀 Φ 0.78 → 0.97–0.99 · 연화 없음 (E/σ_y = 25) · 해석식 대조 소성 ± 7 % (Φ 0.85–0.97) · 탄성 −21 % @ Φ 0.85 · 판 속도 V/c_S 0.034 (우리 ≈ 0.21) | §C L2687–2699 | digitized (2D) | 2D 평면변형 · E 10 MPa · mm 급 · Comput. Part. Mech. 9(1) 45–52 (2022)
- [f] nguyen2017_mpm_bpm_deformable_particle_compaction | 입자별 접촉 MPM (MPM-CD · 탄성) 에서 마찰 μ 0 ↔ 0.5 는 Φ(ε) 불변 · Z 만 0.2–0.3 차 → "마찰은 2 차" · 단일 속도장의 결함은 마찰 부재보다 "붙음 (분리 불가 + 결합)" 일 가능성 | §C L2702–2705 | digitized · "가설" | 2D · EPJ Web Conf. 140, 05013 (2017) · Fig 2 ↔ Fig 3 범례 모순 (방법 귀속은 추정)
- [f] pycompact2025_dem_mpfem_workflow + demirtas2021_mpfem_hollow_sphere_die_compaction | (묶음 · 입자별 FE 쪽 해상도 · 오차) PyCompact: "convergence" 라 적었지만 2000 → 2500 요소에서 −5 % 단조 감소 중 · 선택 근거는 런타임 9 h vs 36 h / Demirtas Fig 5: 요소 600 → 3363 / 입자에서 응력 Σ_y 는 ≲ 2 % (8 입자) · ≲ 5 % (520 입자) 변화인데 접촉면적은 −23 % · −22 % (4 s) · −43 % (1 s) 로 plateau 없음 · 런타임 46.3 / 53.0 / 72.1 / 98.3 / 218.2 min (600 / 1059 / 1650 / 1800 / 3363 요소) · 준정적 게이트 KE/PE < 1 % 를 RD ≥ 0.6 에서만 | §C L2486–2488 · L2533–2544 | derived(ours) · figure-read ≈ (TREND) | 금속 @ 1400–2000 MPa / HPMCAS 중공 @ ≈ 50 MPa — 숫자를 서로 섞지 말 것
- [f] wang2027_ncm811_effective_bulk_modulus_mapper_dfs_gnn | 복셀 FE (면 공유 = 완전 결합) 는 접촉 법칙이 없어 같은 기하의 접촉망보다 단단한 쪽 · 거친 재사상 (10³ · 20³) 이 K 를 2–3 배 키움 = 목이 굵어지는 격자 효과 | §C L2666 | [판독 · 우리 산술] | 액체 LIB NCM811 재구성 · 선형 탄성 · 값 이전 금지
- [f] bardenhagen2000_mpm_granular_multibody_frictional_contact + bardenhagen2001_mpm_improved_contact_granular_stress_waves + nezamabadi2022_mpm_cd_plastic_particle_compaction + nguyen2017_mpm_bpm_deformable_particle_compaction | (묶음 · 후보 A′ 의 선례와 빈칸) 단일 속도장 MPM 은 SE–SE 미끄럼 · 분리 · 구름 · 배위수 · 제하 시 접촉 열림을 못 냄 · 2D 선례 = Nezamabadi (다중 격자 + CD) · Nguyen (μ 0 / 0.5) · 원전 = Bardenhagen00 (알갱이별 장 ↔ 질량중심 장 · Coulomb · 자유 분리) · Bardenhagen01 (견인력 분리 · γ 안정화 · 3D 회귀 시험) · 3D · 강체 AM 혼합 · SE 3.3 만 규모 · 비용은 미시험 · 선행 점검 (GPU 불요): 씨앗을 알갱이별로 P2G 해 노드당 물체 수 (≥ 3 비율 = 2001 의 N ≤ 2 가정 위반) · 색 수 K 를 잼 | §F L3974–3977 | "우리 추론" | 
- [f] demirtas2021_mpfem_hollow_sphere_die_compaction | (입자별 FE 쪽 규칙) KE/PE < 1 % 준정적 게이트 (그들은 RD ≥ 0.6 에서만) · 밀도 제어 → 응력 판독 · YV/TV (비영 소성변형 물질점의 부피분율) · ln(RD/RD₀) 축 · 입자 수 상한 < 2000 ("< 60 h") | §F L3800–3809 | 표지 없음 | HPMCAS 중공
- [f] xu2023_realistic_am_shape_cgmd_calendering | (해상도가 아니라 표본 크기) µ-XCT 전체 볼륨 vs 모델 크기 서브볼륨 20 개: τ 편향 (서브 / 전체 − 1) +5.1 % (압연 전) → +12.0 % (압연 후) · 상대 산포 ± 5.4 % → ± 11.6 % | §F L2884–2898 | digitized · "배수 전이 금지 · 규율만" | 액체 LIB τ (pore 전도)



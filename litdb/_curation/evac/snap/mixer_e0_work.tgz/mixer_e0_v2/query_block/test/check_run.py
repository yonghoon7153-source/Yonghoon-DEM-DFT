#!/usr/bin/env python3
"""check_run.py — run_tests.sh 의 판정기.
  snap <root…>              = 스냅숏 JSON (종류 · 크기 · mtime · 작은 파일 sha256)
  check <T> <md5>           = 단언 (run_tests.sh 가 만든 <T>/<사례>.* 파일을 읽는다) → <T>/check_result.json
"""
import hashlib
import io
import json
import os
import re
import shutil
import stat
import subprocess
import sys
import tarfile

STATUSES = {'OK', 'FAIL', 'MISSING', 'TIMEOUT', 'TRUNC', 'SKIPPED_BUDGET', 'SKIPPED_INTERRUPT', 'SKIPPED_SWITCH', 'SKIPPED_NOT_LUSTRE'}
FIXED_FORBID = ['fakeuser', 'SECRET-LOGIN-HOST', 'SECRET-NODE', 'SECRET-MGS', 'fakebuilder', 'uid 4242', 'gid 4243']
CONTENT_SECRETS = ['SECRET_DUMP_VALUE', 'SECRET_RESTART', 'SECRET_EXACT', 'SECRET_M_VALUE', 'SECRET_COMMENT_ECHO', 'SECRET_WARN_TEXT',
                   'SECRET_LOG_PATHLINE', 'SECRET_JOBSTART', '42424242', '91827364', '86420135', '77777771', '31415926', '47979797']
QB = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
READER = os.path.join(QB, 'read_query_bundle.py')
R = {'pass': 0, 'fail': 0, 'lines': []}


def ok(cond, msg):
    R['pass' if cond else 'fail'] += 1
    R['lines'].append(('PASS ' if cond else 'FAIL ') + msg)
    return cond


def sha(p):
    h = hashlib.sha256()
    with open(p, 'rb') as f:
        for b in iter(lambda: f.read(1 << 20), b''):
            h.update(b)
    return h.hexdigest()


def snap(roots):
    out = {}
    for root in roots:
        if not os.path.lexists(root):
            continue
        for dp, dns, fns in os.walk(root):
            for n in dns + fns:
                p = os.path.join(dp, n)
                st = os.lstat(p)
                rec = [stat.S_IFMT(st.st_mode), st.st_size, st.st_mtime_ns, oct(st.st_mode & 0o7777)]
                if stat.S_ISREG(st.st_mode) and st.st_size < 2_000_000:
                    rec.append(sha(p))
                if stat.S_ISLNK(st.st_mode):
                    rec.append(os.readlink(p))
                out[p] = rec
    return out


def read(p, mode='r'):
    with open(p, mode) as f:
        return f.read()


def kv(path):
    d = {}
    if os.path.exists(path):
        for line in read(path).splitlines():
            if '=' in line:
                k, v = line.split('=', 1)
                d.setdefault(k, []).append(v)
    return d


def probes(path):
    out = {}
    for line in read(path).splitlines():
        c = line.split('|')
        if len(c) >= 6:
            out[c[0]] = c
    return out


def st(pr, k):
    return pr.get(k, ['', 'ABSENT'])[1]


def new_dirs(T, name, home_real):
    b = json.load(open(os.path.join(T, name + '.snap_before.json')))
    a = json.load(open(os.path.join(T, name + '.snap_after.json')))
    added = sorted(set(a) - set(b))
    removed = sorted(set(b) - set(a))
    changed = sorted(p for p in set(a) & set(b) if a[p] != b[p]
                     and not (p == home_real and a[p][0] == b[p][0] and a[p][3] == b[p][3]))   # 홈 폴더 자신은 새 하위 폴더 때문에 mtime · 크기만 바뀐다
    meta = sorted({p for p in added if re.fullmatch(re.escape(home_real) + r'/mixer_e0_query_\d{8}T\d{6}Z(_\d)?', p)})
    outside = [p for p in added if not any(p == m or p.startswith(m + '/') for m in meta)]
    return meta, outside, removed, changed


def calls(T, name):
    p = os.path.join(T, name + '.calls')
    return read(p).splitlines() if os.path.exists(p) else []


def common_exec(T, name, md5, expect_rc='0'):
    exp = json.load(open(os.path.join(T, name, 'w', 'expect.json')))
    rc = read(os.path.join(T, name + '.rc')).strip()
    ok(rc == expect_rc, f'{name}: rc {rc} = {expect_rc}')
    meta, outside, removed, changed = new_dirs(T, name, exp['home_real'])
    ok(len(meta) == 1, f'{name}: 새 조회 폴더 정확히 1 개 ({len(meta)})')
    ok(not outside and not removed and not changed,
       f'{name}: 새 폴더 밖 변화 0 (추가 {len(outside)} · 삭제 {len(removed)} · 변경 {len(changed)}) {outside[:2]}{removed[:2]}{changed[:2]}')
    sent = os.path.join(T, name + '.sentinel')
    ok(not os.path.exists(sent), f'{name}: 금지 명령 (제출 · 취소 · 잡 제어 · 지우기 · 옮기기 · git · conda · python …) 호출 0 '
       + (read(sent).strip()[:200] if os.path.exists(sent) else ''))
    if len(meta) != 1:
        return None
    D = meta[0]
    nm = os.path.basename(D)
    for sub in ('raw', 'out', 'work'):
        ok(os.path.isdir(os.path.join(D, sub)), f'{name}: {sub}/ 있음')
    ok(oct(os.stat(D).st_mode & 0o777) == '0o700', f'{name}: 새 폴더 모드 700 (umask 077) {oct(os.stat(D).st_mode & 0o777)}')
    tgz = os.path.join(D, nm + '.tgz')
    ok(os.path.isfile(tgz) and os.path.isfile(tgz + '.sha256'), f'{name}: tgz · sha256 옆 파일')
    so = read(os.path.join(T, name + '.stdout'))
    m = re.search(r'sha256\s+([0-9a-f]{64})', so)
    if os.path.isfile(tgz):
        ok(m is not None and m.group(1) == sha(tgz), f'{name}: 화면 sha256 = tgz 실제 sha256')
        ok(read(tgz + '.sha256').split()[0] == sha(tgz), f'{name}: .sha256 파일 = tgz 실제 sha256')
        with tarfile.open(tgz, 'r:gz') as tf:
            mem = tf.getmembers()
        ok(all(x.name == 'out' or re.fullmatch(r'out/[^/]+', x.name) for x in mem), f'{name}: tgz 멤버 = out/ 바로 아래만 ({len(mem)})')
        ok(all(x.uname == '' and x.gname == '' and x.uid == 0 and x.gid == 0 for x in mem), f'{name}: tgz 소유자 이름 없음 · uid/gid 0')
        ok(all(x.isdir() or x.isfile() for x in mem), f'{name}: tgz 링크 · 장치 없음')
        ok({x.name[4:] for x in mem if x.isfile()} == set(os.listdir(os.path.join(D, 'out'))), f'{name}: tgz 파일 = out/ 파일')
    out = os.path.join(D, 'out')
    ok(hashlib.md5(read(os.path.join(out, 'query_script.sh'), 'rb')).hexdigest() == md5, f'{name}: out/query_script.sh md5 = 게이트 md5')
    sums = read(os.path.join(out, 'SHA256SUMS')).splitlines()
    good = all(sha(os.path.join(out, l.split('  ', 1)[1])) == l.split('  ', 1)[0] for l in sums if l.strip())
    ok(good and len(sums) == len(os.listdir(out)) - 1, f'{name}: out/SHA256SUMS 전수 대조 ({len(sums)})')
    rsums = read(os.path.join(out, 'RAW_SHA256SUMS')).splitlines()
    ok(all(sha(os.path.join(D, 'raw', l.split('  ', 1)[1])) == l.split('  ', 1)[0] for l in rsums if l.strip()), f'{name}: RAW_SHA256SUMS = raw/ 원문')
    ok(not any(l.split('  ', 1)[1].startswith('private_') for l in rsums if l.strip()), f'{name}: private_* 원문은 해시 목록에도 없음')
    ok(not any(f.startswith('private_') for f in os.listdir(out)), f'{name}: private_* 는 out/ 에 없음')
    forbid = [exp['home_login'], exp['home_real'], T] + FIXED_FORBID + exp['secrets']
    texts = {'stdout': so}
    for f in os.listdir(out):
        if f != 'query_script.sh':
            texts['out/' + f] = read(os.path.join(out, f), 'rb').decode('utf-8', 'replace')
    # 시험 산물: Lustre 흉내가 꺼진 사례에서는 df 의 마운트 칸 = 시험이 묶어 붙인 가짜 세계 (T 아래) — 그 한 줄만 T 검사에서 뺀다 (홈 경로 검사는 그대로)
    texts = {k: (re.sub(r'(?m)^disk\.home\.mount=.*$', 'disk.home.mount=<시험 마운트>', t) if k == 'out/fields.txt' and 'disk.home.fstype=lustre' not in t else t)
             for k, t in texts.items()}
    leaks = [(k, s) for k, t in texts.items() for s in forbid if s in t]
    ok(not leaks, f'{name}: 화면 · out/ 에 경로 · 계정 · 호스트 · 노드 · uid · 덤프 · 로그 · 금고 문자열 0 {leaks[:4]}')
    blob = b''
    for dp, dns, fns in os.walk(D):
        for fn in fns:
            if fn.endswith('.tgz'):
                continue
            blob += read(os.path.join(dp, fn), 'rb')
    inside = [s for s in CONTENT_SECRETS if s.encode() in blob]
    ok(not inside, f'{name}: 새 폴더 어디에도 (raw/ · work/ 포함) 덤프 · 체크포인트 · exact · 금고 · 로그 내용 0 — 열지 않았다 {inside[:4]}')
    post = kv(os.path.join(out, 'fields_post.txt'))
    ok(post.get('redaction.residual_token_hits') == ['0'], f'{name}: 가림 남은 토큰 0 ({post.get("redaction.residual_token_hits")})')
    pr = probes(os.path.join(D, 'raw', 'probes.txt'))
    ok(all(c[1] in STATUSES for c in pr.values()), f'{name}: 조회 상태 어휘 {sorted({c[1] for c in pr.values()})}')
    for q in ['q%d' % i for i in range(1, 10)]:
        ok(any(k == q or k.startswith(q + '_') for k in pr), f'{name}: {q} 의 상태 줄이 있다 (빠진 조회 없음)')
    return D, kv(os.path.join(D, 'raw', 'fields.txt')), pr, so, exp


def parse_sum(path):
    line = read(path).strip().splitlines()[-1]
    c = line.split('|')
    return {x.split('=')[0]: int(x.split('=')[1]) for x in c[3:] if '=' in x}


def check_values(name, D, f, pr, exp, full=True):
    out = os.path.join(D, 'out')
    for i in range(1, 6):
        r = exp['q1']['r%d' % i]
        if r.get('absent'):
            for k in ('du', 'post_ls', 'restart_ls'):
                ok(st(pr, f'q1_r{i}_{k}') == 'FAIL', f'{name}: q1 r{i} 런 폴더 없음 → {k} FAIL ({st(pr, "q1_r%d_%s" % (i, k))})')
            continue
        for k in ('du', 'post_ls', 'post_sum', 'restart_ls', 'restart_sum'):
            ok(st(pr, f'q1_r{i}_{k}') == 'OK', f'{name}: q1 r{i} {k} OK')
        ps = parse_sum(os.path.join(out, f'q1_r{i}_post_sum.txt'))
        want = {'entries': r['post_entries'], 'files': r['post_files'], 'bytes': r['post_bytes'], 'min': r['post_min'], 'max': r['post_max'], 'other': r['post_other'], 'noise': 0}
        ok(ps == want, f'{name}: q1 r{i} post 합 · 수 · 최소 · 최대 = 가짜 홈 실측 {ps} / {want}')
        rs = parse_sum(os.path.join(out, f'q1_r{i}_restart_sum.txt'))
        ok(rs['files'] == 3 and rs['bytes'] == r['restart_bytes'], f'{name}: q1 r{i} restart 3 파일 · 합 {rs["bytes"]} = {r["restart_bytes"]}')
        du = read(os.path.join(out, f'q1_r{i}_du.txt'))
        ok(re.search(r'^\d+\t<HOME>/mixer_dev7_20260930_v26/' + r['run'] + '/post$', du, re.M) is not None
           and re.search(r'^\d+\t<HOME>/mixer_dev7_20260930_v26/' + r['run'] + '/restart$', du, re.M) is not None,
           f'{name}: q1 r{i} du 두 줄 (경로 = <HOME> 가림)')
    lines = read(os.path.join(out, 'q2_frames.txt')).splitlines()
    hd = dict(x.split('=', 1) for x in lines[0].split('|')[1:])
    ok(int(hd['files']) == exp['q2']['files'] and int(hd['matched']) == exp['q2']['matched'] and int(hd['other_names']) == exp['q2']['other_names'],
       f'{name}: q2 머리 {hd}')
    got = {}
    for l in lines[1:]:
        c = l.split('|')
        got[c[1]] = [int(c[2]), int(c[3]), int(float(c[4]))]
    ok(got == exp['q2']['frames'], f'{name}: q2 처음 3 · 가운데 · 끝 3 (step · 크기 · 수정 시각) = 기대 {sorted(got)}')
    q3 = {}
    for fn in os.listdir(out):
        if re.fullmatch(r'q3_d\d+_sizes\.txt', fn):
            for l in read(os.path.join(out, fn)).splitlines():
                c = l.split('|')
                if c[0] == 'exact':
                    q3.setdefault(c[1], {})[c[2]] = int(c[3])
                elif c[0] == 'exact_other':
                    q3.setdefault(c[1], {})['_other'] = int(c[2].split('=')[1])
    want3 = {d: dict(v, _other=exp['q3']['other'][d]) for d, v in exp['q3']['dirs'].items()}
    ok(q3 == want3, f'{name}: q3 exact hp · g6 크기 = 기대 (이상한 이름 · notexact 폴더 제외)')
    ok(f.get('q3.skipped_odd_name') == ['yes'] and f.get('q3.n_dirs') == ['2'], f"{name}: q3 공백 든 폴더 이름은 건너뜀 · 폴더 2 ({f.get('q3.n_dirs')})")
    s9 = read(os.path.join(out, 'q9_thermo_shape.txt')).splitlines()
    head = dict(x.split('=', 1) for x in s9[0].split('|')[1:])
    blocks = {}
    for l in s9[1:]:
        c = l.split('|')
        if c[0] == 'block':
            d = dict(x.split('=', 1) for x in c[2:])
            blocks[c[1]] = {'header_cols': int(d['header_cols']), 'rows': int(d['rows']), 'rows_nonfinite': int(d['rows_nonfinite']),
                            'row_cols': dict(x.split(':') for x in d['row_cols'].split(',')) if d['row_cols'] != '-' else {},
                            'nonrow': int(d['nonrow']), 'blank': int(d['blank']), 'closed': d['closed'], 'words': {}}
        elif c[0] == 'nonrow':
            blocks[c[1]]['words'][c[2]] = int(c[3])
    for b in blocks.values():
        b['row_cols'] = {k: int(v) for k, v in b['row_cols'].items()}
    ok(int(head['lines']) == exp['q9']['lines'] and int(head['blocks']) == exp['q9']['blocks'], f'{name}: q9 줄 수 · 표 수 {head}')
    ok(blocks == exp['q9']['block'], f'{name}: q9 표마다 칸 수 · 숫자 줄 · 비유한 · 비-행 첫 낱말 · 빈 줄 · 닫힘 = 기대')
    ok(all(re.fullmatch(r'(q9\|lines=\d+\|blocks=\d+|block\|\d+\|.*|nonrow\|\d+\|[A-Za-z#:._?<>~-]+\|\d+)', l) for l in s9),
       f'{name}: q9 출력 줄 꼴 = 센 수 · 가린 첫 낱말만 (본문 · 숫자 값 없음)')
    if full:
        qd = read(os.path.join(out, 'q4_lfs_quota_default.txt'))
        qu = read(os.path.join(out, 'q4_lfs_quota_user.txt'))
        ok('Disk default usr quota' in qd and '<USER>' in qu and 'uid <UID>' in qu, f'{name}: q4 기본 · 내 할당 (계정 · uid 가림)')
        ok('[OST:0]' in read(os.path.join(out, 'q5_lfs_df.txt')), f'{name}: q5 OST 줄')
        sc = [c for c in calls(T_GLOBAL, name) if c.startswith('sacct|')]
        ok(sc == ['sacct|-j 249080,249081,249082,249083,249084 -P -o JobID,State,ExitCode,Elapsed,AllocCPUS,MaxRSS,ReqMem'],
           f'{name}: q6 sacct 한 번 · 잡 다섯 · 칸 일곱 (노드 · 계정 칸 없음) {sc}')
        ok('CANCELLED by <UID>' in read(os.path.join(out, 'q6_sacct.txt')), f'{name}: q6 "CANCELLED by <uid>" 가림')
        ok(f.get('q7.bin.vs_ref') == ['different'] and f.get('q7.bin.hash', [''])[0].split('|')[0] == exp['bin_sha256'],
           f"{name}: q7 바이너리 sha256 = 실제 · 09-28 기준과 different (가짜)")
        rp = read(os.path.join(out, 'q7_rpath.txt'))
        ok('RUNPATH' in rp and '<HOME>/.conda/envs/myenv/lib' in rp and 'rpath_lines=1' in rp, f'{name}: q7 RUNPATH 줄 (경로 <HOME> 가림) {rp.strip()[:100]}')
        libs = [l.split('|') for l in read(os.path.join(out, 'q7_libs.txt')).splitlines()]
        foo = [c for c in libs if c[1] == 'libfoo.so.1']
        ok(len(foo) == 1 and foo[0][3] == 'symbolic link' and foo[0][4].endswith('/libfoo.so.1.0.0') and foo[0][5] == exp['libfoo_real_sha256']
           and int(foo[0][6]) == exp['libfoo_real_bytes'], f'{name}: q7 심볼릭 링크 라이브러리 → 실제 파일 sha256 · 크기 {foo[:1]}')
        ok(any(c[1] == 'libbar.so.2' and c[3] == 'NOT_FOUND' for c in libs) and any(c[3] == 'VDSO' for c in libs),
           f'{name}: q7 not found · vdso 줄 기록')
        paths = [c for c in libs if c[3] not in ('NOT_FOUND', 'VDSO')]
        ok(paths and all(re.fullmatch(r'[0-9a-f]{64}', c[5]) for c in paths) and st(pr, 'q7_libs') == 'OK',
           f'{name}: q7 경로 라이브러리 {len(paths)} 개 전부 sha256 (링크 → 실제 파일)')
        si = [c for c in calls(T_GLOBAL, name) if c.startswith('sinfo|')]
        ok(si == ['sinfo|-h -o %P|%a|%C', 'sinfo|-h -N -p cpu -o %C|%t'], f'{name}: q8 sinfo 두 번 · 노드 이름 칸 없음 {si}')
        ok(read(os.path.join(out, 'q8_sinfo_nodes_cpu.txt')).count('\n') == 4, f'{name}: q8 cpu 노드 4 줄 (이름 없이)')
        ok(all(st(pr, k) == 'OK' for k in pr if k.startswith(('q4', 'q5', 'q6', 'q7', 'q8', 'q9'))), f'{name}: q4–q9 상태 전부 OK')


T_GLOBAL = None


def run_reader(T, tag, tgz, dest, md5, sha256, extra=()):
    p = subprocess.run([sys.executable, '-I', READER, tgz, dest, '--expect-md5', md5, '--expect-sha256', sha256, *extra],
                       capture_output=True, text=True, timeout=120)
    with open(os.path.join(T, 'reader_' + tag + '.txt'), 'w') as fo:
        fo.write(p.stdout + p.stderr)
    return p


def bundle_of(T, name, home_real):
    meta = new_dirs(T, name, home_real)[0]
    if not meta:
        return None, None
    D = meta[0]
    tgz = os.path.join(D, os.path.basename(D) + '.tgz')
    return tgz, read(tgz + '.sha256').split()[0]


def repack(src, dst, mutate):
    """src tgz 를 읽어 mutate(이름, 바이트) → [(이름, 바이트, 종류)] 로 바꿔 새 tgz"""
    with tarfile.open(src, 'r:gz') as tf:
        items = [(m.name, tf.extractfile(m).read() if m.isfile() else None, m) for m in tf.getmembers()]
    with tarfile.open(dst, 'w:gz') as to:
        for name, data, m in items:
            for nn, nd, kind in mutate(name, data):
                ti = tarfile.TarInfo(nn)
                ti.uid = ti.gid = 0
                ti.uname = ti.gname = ''
                if kind == 'dir':
                    ti.type = tarfile.DIRTYPE
                    ti.mode = 0o700
                    to.addfile(ti)
                elif kind == 'sym':
                    ti.type = tarfile.SYMTYPE
                    ti.linkname = nd
                    to.addfile(ti)
                else:
                    ti.size = len(nd)
                    ti.mode = 0o600
                    to.addfile(ti, io.BytesIO(nd))


def main():
    global T_GLOBAL
    if sys.argv[1] == 'snap':
        json.dump(snap(sys.argv[2:]), sys.stdout)
        return 0
    T, md5 = sys.argv[2:4]
    T_GLOBAL = T

    def tsecs(n):
        return float(read(os.path.join(T, n + '.secs')).strip())

    # 빌드 일관성
    blk = read(os.path.join(QB, 'query_block.txt'))
    h1 = re.search(r'스크립트 md5 ([0-9a-f]{32})', blk.splitlines()[0])
    gate = re.search(r'= ([0-9a-f]{32}) \]', blk.splitlines()[-1])
    src = hashlib.md5(read(os.path.join(QB, 'src', 'query_script.sh'), 'rb')).hexdigest()
    ok(h1 and gate and h1.group(1) == gate.group(1) == src == md5, f'빌드: 블록 머리 md5 = 마지막 줄 게이트 md5 = src md5 = {md5}')
    ok(blk.count('!') == 0 and '\t' not in blk and '\r' not in blk and not re.search(r'^\^', blk, re.M), '빌드: 블록에 느낌표 · 탭 · CR · 줄 첫 ^ 없음')

    # t1 · t2 (전부 · mawk / gawk)
    res = {}
    for n in ('t1', 't2'):
        r = common_exec(T, n, md5)
        if r:
            D, f, pr, so, exp = r
            res[n] = D
            check_values(n, D, f, pr, exp)
            ok(tsecs(n) < 60, f'{n}: 걸린 시간 {tsecs(n):.1f} 초 < 60')
            ok('q1–q9 시작' in so and '가져올 파일' in so and so.count('\n') <= 20, f'{n}: 화면 = 시작 · 조회별 상태 · 가져올 파일 줄 ({so.count(chr(10))} 줄)')
    if 't1' in res:
        ok('mawk' in kv(os.path.join(res['t1'], 'raw', 'fields.txt')).get('awk_version', [''])[0], 't1: awk = mawk (컨테이너 기본)')
    if 't2' in res:
        ok('GNU Awk' in kv(os.path.join(res['t2'], 'raw', 'fields.txt')).get('awk_version', [''])[0], 't2: awk = GNU Awk (ibb 와 같은 종류)')
    if 't1' in res and 't2' in res:
        same = True
        diffs = []
        for fn in sorted(os.listdir(os.path.join(res['t1'], 'out'))):
            if re.fullmatch(r'(q1_r\d_(post|restart)_sum|q1_r\d_restart_ls|q2_frames|q9_thermo_shape|q6_sacct|q8_sinfo_\w+|q4_\w+|q5_lfs_df)\.txt', fn):
                a = sorted(read(os.path.join(res['t1'], 'out', fn)).splitlines())
                b = sorted(read(os.path.join(res['t2'], 'out', fn)).splitlines())
                if a != b:
                    same = False
                    diffs.append(fn)
        ok(same, f't1 ↔ t2: mawk 와 gawk 의 요약 출력이 같다 (q1 · q2 · q4–q6 · q8 · q9) {diffs}')

    # t3 실패 섞기
    r = common_exec(T, 't3', md5)
    if r:
        D, f, pr, so, exp = r
        check_values('t3', D, f, pr, exp, full=False)
        ok(st(pr, 'q6_sacct') == 'MISSING', f"t3: sacct 없음 → q6 MISSING ({st(pr, 'q6_sacct')})")
        ok(st(pr, 'q8_sinfo_partitions') == 'FAIL' and st(pr, 'q8_sinfo_nodes_cpu') == 'FAIL', 't3: sinfo 실패 → q8 FAIL 둘')
        ok(st(pr, 'q4_lfs_quota_default') == 'FAIL' and st(pr, 'q4_lfs_quota_user') == 'OK' and st(pr, 'q5_lfs_df') == 'OK',
           f"t3: lfs quota -U 실패 → 그 줄만 FAIL · 나머지 OK ({st(pr, 'q4_lfs_quota_default')} · {st(pr, 'q4_lfs_quota_user')} · {st(pr, 'q5_lfs_df')})")
        ok(st(pr, 'q7_readelf') == 'MISSING' and st(pr, 'q7_objdump') == 'OK' and 'RUNPATH' in read(os.path.join(D, 'out', 'q7_rpath.txt')),
           f"t3: readelf 없음 (127) → objdump 로 RUNPATH ({st(pr, 'q7_readelf')} · {st(pr, 'q7_objdump')})")
        ok(st(pr, 'q9_thermo_shape') == 'OK' and st(pr, 'q7_libs') == 'OK' and st(pr, 'q2_pick') == 'OK',
           't3: 실패 뒤의 조회 (q2 · q7 · q9) 는 그대로 돎')
        ok('FAIL' in so and 'MISSING' in so, 't3: 화면에 FAIL · MISSING 이 보인다')

    # t4 멈춘 명령 (sacct 가 TERM 을 무시하고 600 초 잔다)
    r = common_exec(T, 't4', md5)
    if r:
        D, f, pr, so, exp = r
        c = pr.get('q6_sacct', [])
        ok(st(pr, 'q6_sacct') == 'TIMEOUT' and len(c) > 3 and 60 <= int(c[3]) <= 70, f't4: q6 = TIMEOUT · {c[3] if len(c) > 3 else "?"} 초 (60 + kill 5 안)')
        ok(all(st(pr, k) == 'OK' for k in ('q7_bin', 'q7_libs', 'q8_sinfo_partitions', 'q9_thermo_shape')), 't4: 멈춘 명령 뒤의 q7 · q8 · q9 는 OK')
        ok(tsecs('t4') < 120, f"t4: 전체 {tsecs('t4'):.1f} 초 < 120")
        ok(read(os.path.join(T, 't4.leftover')).strip() == '0', f"t4: 끝난 뒤 남은 가짜 sacct · sleep 프로세스 0 ({read(os.path.join(T, 't4.leftover')).strip()})")

    # t5 예산 1 초
    r = common_exec(T, 't5', md5)
    if r:
        D, f, pr, so, exp = r
        nb = sum(1 for c in pr.values() if c[1] == 'SKIPPED_BUDGET')
        ok(st(pr, 'q1_r1_du') == 'OK' and nb >= 25, f"t5: 예산 2 초 — 첫 조회 ({st(pr, 'q1_r1_du')}) 만 돌고 SKIPPED_BUDGET {nb} 개 · 묶음은 만듦")
        ok(tsecs('t5') < 30, f"t5: 전체 {tsecs('t5'):.1f} 초 < 30")
        ok(f.get('budget_seconds') == ['2'] and f.get('pack_deadline_seconds') == ['302'], 't5: 예산 · 묶음 상한 칸 기록')

    # t6 MIX_Q=q8
    r = common_exec(T, 't6', md5)
    if r:
        D, f, pr, so, exp = r
        sk = [q for q in ('q1', 'q2', 'q3', 'q4', 'q5', 'q6', 'q7', 'q9') if st(pr, q) == 'SKIPPED_SWITCH']
        ok(len(sk) == 8 and st(pr, 'q8_sinfo_partitions') == 'OK' and st(pr, 'q8_sinfo_nodes_cpu') == 'OK', f't6: MIX_Q=q8 → 나머지 여덟 SKIPPED_SWITCH ({len(sk)}) · q8 OK')
        cl = [c.split('|')[0] for c in calls(T, 't6')]
        ok(set(cl) <= {'df', 'stat', 'sinfo'} and 'sacct' not in cl and 'lfs' not in cl, f't6: 부른 가짜 명령 = df · stat (마운트 확인) · sinfo 만 {sorted(set(cl))}')

    # t7 Lustre 아님 (MIX_Q='q4 q5')
    r = common_exec(T, 't7', md5)
    if r:
        D, f, pr, so, exp = r
        ok(all(st(pr, k) == 'SKIPPED_NOT_LUSTRE' for k in ('q4_lfs_quota_default', 'q4_lfs_quota_user', 'q5_lfs_df')), 't7: Lustre 아님 → q4 · q5 SKIPPED_NOT_LUSTRE')
        ok(not any(c.startswith('lfs|') for c in calls(T, 't7')), 't7: lfs 를 부르지 않음')

    # t9 Ctrl-C (SIGINT 를 조회 스크립트에)
    r = common_exec(T, 't9', md5)
    if r:
        D, f, pr, so, exp = r
        sig = read(os.path.join(T, 't9.signalled')).strip()
        ni = sum(1 for c in pr.values() if c[1] == 'SKIPPED_INTERRUPT')
        ok(sig.isdigit() and f.get('interrupted') == ['1'] and ni >= 20, f't9: SIGINT (pid {sig}) → interrupted=1 · SKIPPED_INTERRUPT {ni} 개')
        ok('Ctrl-C 로 멈춤' in so and '가져올 파일' in so, 't9: 화면에 멈춤 알림 · 묶음은 만듦')
        ok(tsecs('t9') < 12, f"t9: 전체 {tsecs('t9'):.1f} 초 < 12 (멈추지 않으면 16 초 이상)")
    # t8 게이트
    for n in ('t8a', 't8b'):
        exp = json.load(open(os.path.join(T, n, 'w', 'expect.json')))
        meta, outside, removed, changed = new_dirs(T, n, exp['home_real'])
        ok(not meta and not outside and not removed and not changed, f'{n}: 게이트 — 아무것도 안 만듦 (새 {len(meta) + len(outside)} · 변경 {len(changed)})')
        ok(not os.path.exists(os.path.join(T, n + '.sentinel')) and not calls(T, n), f'{n}: 명령 호출 0')
    ok('아무것도 안 함' in read(os.path.join(T, 't8a.stdout')), 't8a: 한 글자 깨짐 = "md5 다름 — 아무것도 안 함"')
    r = common_exec(T, 't8c', md5)
    if r:
        D, f, pr, so, exp = r
        check_values('t8c', D, f, pr, exp)
        ok(True, 't8c: 대화형 bash -i 로 붙여도 돎 (느낌표 · 기록 확장 · 탭 완성 문제 없음)')
    ok(read(os.path.join(T, 't8d.cmp')).strip() == 'same', 't8d: CRLF 사본을 DEM1 의 sed 로 고치면 원본 바이트와 같다')

    # 판독기
    exp1 = json.load(open(os.path.join(T, 't1', 'w', 'expect.json')))
    tgz1, sha1 = bundle_of(T, 't1', exp1['home_real'])
    if tgz1:
        p = run_reader(T, 'r1', tgz1, os.path.join(T, 'read_t1'), md5, sha1, ('--json', os.path.join(T, 'read_t1.json')))
        ok(p.returncode == 0, f'reader r1 (t1): rc {p.returncode}')
        S = json.load(open(os.path.join(T, 'read_t1.json')))
        q1 = {r['tag']: r for r in S['q1']}
        ok(all(q1['r%d' % i]['post']['bytes'] == exp1['q1']['r%d' % i]['post_bytes'] for i in range(1, 6))
           and all(q1['r%d' % i]['post_plus_restart_bytes'] == exp1['q1']['r%d' % i]['post_bytes'] + exp1['q1']['r%d' % i]['restart_bytes'] for i in range(1, 6)),
           'reader r1: q1 post · restart 바이트 = 가짜 홈 실측')
        ok(S['q2']['first_frame_after_job_start_s'] == 1790755942 - 1790755936 and abs(S['q2']['s_per_1000_steps'] - 13.0) < 1e-9,
           f"reader r1: q2 첫 프레임까지 {S['q2']['first_frame_after_job_start_s']} s · 1000 step 당 {S['q2']['s_per_1000_steps']} s")
        ok(len(S['q3']['rows']) == 2 and all(abs(x['ratio_hp_over_g6'] - x['hp_bytes'] / x['g6_bytes']) < 1e-12 for x in S['q3']['rows']), 'reader r1: q3 hp/g6 비')
        ok(S['q5']['n_ost'] == 2 and S['q5']['min_avail_bytes'] == 30000000000 * 1024, f"reader r1: q5 OST 2 · 최소 여유 {S['q5'].get('min_avail_bytes')}")
        j = S['q6']['jobs']
        ok(set(j) == {'249080', '249081', '249082', '249083', '249084'} and j['249080']['elapsed_s'] == 13997
           and j['249082']['max_step_maxrss_bytes'] == int(7.10 * 1024 ** 3) and j['249080']['elapsed_minus_reg41_s'] == 0,
           'reader r1: q6 잡 다섯 · Elapsed 초 · MaxRSS 바이트 · 4-1 과의 차')
        ok(S['q7']['n_hashed'] == S['q7']['n_paths'] >= 3 and S['q7']['n_not_found'] == 1 and len(S['q7']['rpath_lines']) == 1, 'reader r1: q7 라이브러리 · RUNPATH')
        ok(S['q8']['cpu_nodes_with_idle_ge_20'] == 1 and len(S['q8']['partitions']) == 2, 'reader r1: q8 파티션 · 유휴 ≥ 20 노드 수')
        ok(S['q9']['blocks_with_INFO'] == ['1', '3'] and S['q9']['head']['blocks'] == 5, f"reader r1: q9 INFO 가 낀 표 {S['q9']['blocks_with_INFO']}")
        fb = os.path.join(T, 'forbid_none.txt')
        with open(fb, 'w') as fo:
            fo.write('\n'.join(['fakeuser', 'SECRET-LOGIN-HOST', exp1['home_real'], exp1['home_login']]) + '\n')
        p = run_reader(T, 'r1f', tgz1, os.path.join(T, 'read_t1f'), md5, sha1, ('--forbid-file', fb))
        ok(p.returncode == 0 and '나온 곳 0' in p.stdout, 'reader --forbid-file (계정 · 호스트 · 홈 경로) = 0 곳 · rc 0')
        fb2 = os.path.join(T, 'forbid_hit.txt')
        with open(fb2, 'w') as fo:
            fo.write('E0_ref_s32452843\n')
        p = run_reader(T, 'r1h', tgz1, os.path.join(T, 'read_t1h'), md5, sha1, ('--forbid-file', fb2))
        ok(p.returncode == 1 and '금지 문자열이 나옴' in p.stdout, 'reader --forbid-file 이 있는 문자열을 잡는다 (rc 1)')
        p = run_reader(T, 'r_wrongsha', tgz1, os.path.join(T, 'read_wrongsha'), md5, '0' * 64)
        ok(p.returncode == 1 and '화면 값과 다름' in p.stdout, 'reader: 화면 sha256 다름 → rc 1')
        p = run_reader(T, 'r_wrongmd5', tgz1, os.path.join(T, 'read_wrongmd5'), 'f' * 32, sha1)
        ok(p.returncode == 1 and 'md5' in p.stdout, 'reader: 블록 md5 다름 → rc 1')
        os.makedirs(os.path.join(T, 'read_nonempty'))
        with open(os.path.join(T, 'read_nonempty', 'x'), 'w') as fo:
            fo.write('x')
        p = run_reader(T, 'r_nonempty', tgz1, os.path.join(T, 'read_nonempty'), md5, sha1)
        ok(p.returncode == 2, f'reader: 비어 있지 않은 풀 폴더 → 거부 rc {p.returncode}')
        bad1 = os.path.join(T, 'tampered.tgz')
        repack(tgz1, bad1, lambda n, d: [(n, d, 'dir' if d is None else 'file')] if n != 'out/q6_sacct.txt' else [(n, d.replace(b'COMPLETED', b'COMPLETEX', 1), 'file')])
        p = run_reader(T, 'r_tamper', bad1, os.path.join(T, 'read_tamper'), md5, sha(bad1))
        ok(p.returncode == 1 and 'sha256 불일치: q6_sacct.txt' in p.stdout, 'reader: 묶음 안 파일 한 글자 바뀜 → SHA256SUMS 불일치 rc 1')
        bad2 = os.path.join(T, 'evil.tgz')
        repack(tgz1, bad2, lambda n, d: [(n, d, 'dir' if d is None else 'file')] + ([('out/../evil.txt', b'EVIL', 'file'), ('out/link', '/etc/passwd', 'sym'),
                                                                                     ('out/sub/x.txt', b'x', 'file')] if n == 'out' else []))
        p = run_reader(T, 'r_evil', bad2, os.path.join(T, 'read_evil'), md5, sha(bad2))
        ok(p.returncode == 1 and '멤버 이름 거부' in p.stdout and '정규 파일 아님' in p.stdout and not os.path.exists(os.path.join(T, 'evil.txt'))
           and not os.path.exists(os.path.join(T, 'read_evil', 'out', 'link')) and not os.path.exists(os.path.join(T, 'read_evil', 'out', 'sub')),
           'reader: ".." · 링크 · 하위 폴더 멤버 거부 · 밖에 쓰지 않음 (rc 1)')
    for n, tag in (('t2', 'r2'), ('t3', 'r3'), ('t6', 'r6')):
        e = json.load(open(os.path.join(T, n, 'w', 'expect.json')))
        tg, sh = bundle_of(T, n, e['home_real'])
        if tg:
            p = run_reader(T, tag, tg, os.path.join(T, 'read_' + n), md5, sh)
            ok(p.returncode == 0, f'reader {tag} ({n}): rc {p.returncode} (실패 · 건너뜀이 있어도 묶음 구조는 정상)')
    print('\n'.join(R['lines']))
    print(f"== PASS {R['pass']} · FAIL {R['fail']}")
    json.dump(R, open(os.path.join(T, 'check_result.json'), 'w'), ensure_ascii=False, indent=1)
    return 0 if R['fail'] == 0 else 1


if __name__ == '__main__':
    sys.exit(main())

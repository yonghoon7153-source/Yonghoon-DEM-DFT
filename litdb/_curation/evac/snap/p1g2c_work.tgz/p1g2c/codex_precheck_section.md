모두 내부 반박 리뷰 (독립 조수 · Codex 아님 · 1저자 11-10 운영 결정) · 결과 0 건 · 실행 0 건. 기록 = `docs/reviews/p1_g2c_sandbox_20261104/internal_reviews/p1next_AB_20261112/`.

| 회차 | 대상 | 지적 | 처분 |
|---|---|---|---|
| 1 회차 (11-12) | 초안 A · B 첫 판 | P1 1 (10:0 RJ2 S0′ = 주기 restart) · P2 8 · P3 16 | 전부 고침 · `disposition1_AB.md` (리뷰 = `review1_AB.md`) |
| 2 회차 (11-12) | 1 회차 고친 판 | P2 3 (15-5b 정직 여유 · rt.bin 결합 자리 · A ↔ B 멈춤 규칙) · P3 6 | 고침 · 15-5b 지표 = \|Ft\| 가중 reset 몫 W (결과를 본 뒤 정한 문턱 = A 머리 표지) · `disposition2_AB.md` |
| 마지막 사전 공격 (11-12 밤) | 2 회차 고친 판 | P1 1 (PFA-01 · ibb 홈 = 심볼릭 → 한쪽만 realpath 면 정직한 런 거부) · P2 1 (PFA-02 · 교차 NP 에서 쓴 칸 하나 통째 소실 = 전역 W ≈ 1/24 로 통과) · P3 9 | 고침 · 경로 규칙 (글자 같음 + 폴더 양쪽 realpath · 반례 12/12) · 쓴 격자 칸별 W ≤ 0.5 (칸 하나 통째 소실 24/24) · `disposition3_AB.md` |
| 마지막 확인 (11-12 밤) | 3 회차 고친 판 | PFA 11 닫힘 · P2 1 (PFA2-01 · 사전 멈춤 · 시작 안 한 잡이 결론을 지움) · P3 4 | 좁은 4 회차 고침 (그 다섯만) · `disposition4_AB.md` · **4 회차 고침의 독립 재확인 = 없음 (이 요청이 다음 확인)** |

- 숫자 · 전칭 대조: 회차마다 산술 스크립트로 다시 셈 (`rb_count.py` · `r2_cont_guard.py` · `r2_alt_metrics.py` · `f2_guard_power.py` · `pfa_w_check.py` · `f3_choice.py` · `f3_path_rule.py` · `r4_check.py` · 출력 같은 폴더).
- 리포 검사: 문서 참조 (`scripts/check_doc_refs.py`) · 원장 자기일관 · 철회값 스윕 · 게이트 두 조각 (1–125 · 126–끝) = 이 요청서 커밋에서 실패 0 (push 조건).
- 리뷰 기록의 홈 · 스크래치 경로는 자리표 (`<HOME>` · `<LUSTRE_HOME>` · `<SCRATCH>`) 로 가렸다.
- 4 회차 고침 판의 sha256 앞 12 = A `67e8b4517bd1` · B `c7790aca3fa4` (리포 반입 전 스크래치 판 · 반입 때 머리 표지 · 경로만 바뀜).

#!/bin/bash
# F′ = F 의 나무 + (README · 증거를 F 결과로 고친 판) 를 64e4d213e 위 한 커밋으로 · 그 위에서 참조 · 철회값 · 경계만 다시 잰다 (scratch 사본 안 git 만)
set -euo pipefail
V=/tmp/claude-0/-home-user-Yonghoon-DEM-DFT/81c0ad95-542f-503b-9cf7-2f6a678a4b5b/scratchpad/rint/seal_candidate_v2
C=$V/work/sealclone; E=$V/evidence; D=$C/docs/reviews/rint2_seal_20261120; O=$V/work/evF2
PIN=64e4d213e8267bafaf3ae5af00a42996cefd3f33; CLAIMS=2da71fe5abbaa856beb87c39c2a49424e4c87bc7
mkdir -p $O
sed "s#$V/work#<scratch>#g;s#$V#<후보>#g" $V/work/evF/e1_test_rint_r_chain_full_F.txt > $E/raw/e1_test_rint_r_chain_full_F.txt
python3 -I $E/tools/make_committed_evidence.py $E/raw $E $C/docs/reviews/claims.json > $O/make_committed_evidence.txt
F=$(git -C $C rev-parse HEAD)
cp $V/README.md $D/README.md
rm -rf $D/evidence; mkdir -p $D/evidence/tools
(cd $E && cp ./*.txt ./*.json $D/evidence/ && cp tools/*.py $D/evidence/tools/)
cd $C
git add -A
git -c user.name=scratch -c user.email=scratch@invalid -c commit.gpgsign=false commit -q -m "scratch F prime prep"
T=$(git rev-parse 'HEAD^{tree}')
F2=$(git -c user.name=scratch -c user.email=scratch@invalid commit-tree "$T" -p $PIN -m "scratch seal-form commit F prime (seal candidate v2 · README · evidence with F results · NOT for push)")
git update-ref refs/heads/seal-form-scratch "$F2"
{ echo "# F = $F → F′ = $F2 (부모 $(git rev-parse "$F2^"))"; echo "## git diff --stat F F′ (봉인 기록 폴더뿐이어야)"; git diff --stat "$F" "$F2" | tail -40;
  echo "## 봉인 기록 폴더 밖 차이 줄 수: $(git diff --name-only "$F" "$F2" | grep -vc '^docs/reviews/rint2_seal_20261120/\(README.md\|evidence/\)' || true)"; } > $O/F2_diff.txt
{ echo "# HEAD $F2 (F′)"; python3 -I scripts/check_doc_refs.py; echo "rc=$?"; } > $O/F2_check_doc_refs.txt 2>&1 || true
{ echo "# HEAD $F2 (F′ · claims.json = 원격 stoic 2da71fe5a 판) · $(python3 -V)"; python3 -I $E/tools/check_ban_new_text.py $C $PIN HEAD $CLAIMS; echo "rc=$?"; } > $O/F2_ban_new_text.txt 2>&1 || true
{ echo "# HEAD $F2 (F′)"; python3 -I $E/tools/check_seal_files.py $C $PIN HEAD; echo "rc=$?"; } > $O/F2_seal_files.txt 2>&1 || true
git status --porcelain | wc -l > $O/F2_status_lines.txt
echo "F2=$F2"

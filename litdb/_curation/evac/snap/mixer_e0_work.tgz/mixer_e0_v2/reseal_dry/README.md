# 재봉인 건식 — 적힌 차례가 도는가 (재리뷰 MXE0R2-01 · 2026-11-12 · scratch · 결과 0 건)

**지위: scratch 건식 · 리포 쓰기 0 · git 상태 변경 0 · ibb 접속 0 · 실제 재봉인 아님 (1저자 별도 승인) · 발사 GO 아님 · 전체 HOLD 그대로.**
리포에는 읽기만 했다 (`git archive` · `git ls-tree` · `git cat-file` · `git diff --name-only` · `git branch -r --contains`). 실행은 전부 아래 HEAD 사본 (또는 그 일부 사본) 에서만 했다.
목적 = 등록 7-6 의 재봉인 순서 3 · 4 를 **IN 검증기 · first8 가드를 실제로 돌려** 보고, 끝까지 도는 차례 · 같이 바꿀 것을 찾는다. 결과 → 등록 7-6 · 18 절 Q-C′ (바뀐 권고).
줄임: `F8` = `docs/reviews/mixer_first8_launch_preparation_20261106` · `IN` = `docs/reviews/mixer_inactive_preparation_20261109` · ① ② ③ ④ = 등록 7-6 순서 4 의 대상 번호 (① `F8/source_seal.json` · ② `IN/source_inventory.json` 관측기 행 · ③ `F8/static_asset_manifest.json` 메타 줄 · ④ `F8/planned_assets/<case>/deck_meta.json` + `SHA256SUMS`).

## 0. 사본

| 칸 | 값 |
|---|---|
| 원천 | 리포 HEAD `bfd9b3bbdda51ebe85e040de2178c2af8d7880fb` · `git archive --format=tar HEAD \| tar -x -C head/` (11-12T14:41:26Z 시작 · 14:41:31Z 끝 · `archive_*_utc.txt` · `head_commit.txt`) |
| 대조 | `tools/verify_copy.py` — `git ls-tree -r bfd9b3bbd` 의 blob 22904/22904 같음 · 빠짐 0 · 남는 파일 0 (`runs/lstree_bfd9b3bbd.z`) |
| 사고 메모 | 아카이브 시작 1 초 뒤 (14:41:27Z) 다른 조수 셸의 `GIT_DIR` 내보내기 때문에 리포 가지에 시험 커밋 하나가 들어갔다 → 본 세션이 되돌렸다 (가지 = bfd9b3bbd · status 0 줄 — 이 조수가 읽기만으로 다시 확인). 사본은 위 blob 대조로 bfd9b3bbd 내용이다. 건식 단계 (검증기 · 묶음 시험 · 도구) 는 git 을 부르지 않는다 · 리포에는 머리말의 읽기 명령만 (`-C` · GIT_* 내보내기 0) |
| 파이썬 | 3.11.18 · numpy 2.4.6 · 도구 = `python3 -I -B` · 검증기 = `python3 -I -B -X utf8` (`IN/README.md` 의 꼴) |
| `head/` | 본 줄 (S1 ② → S2 ① → S3 ③ → S4 ④ · E0 만) 을 **차례로 얹은 끝 상태** — 지금은 HEAD 와 다르다. 1.1 GB · 다 쓴 뒤 지워도 된다 (아카이브 + `tools/` 로 재현) |
| `runs/pristine_mini/` | 손대기 전 `head/` 에서 뜬 작은 사본 (스크립트 10 · STL 3 · F8 · IN = 146 파일) — 변형 V3–V6 의 출발점 |
| 가림 | `runs/` 의 출력 · `summary.tsv` · `report.json` 의 절대 경로 = `<D>` (이 폴더) · `<REPO>` · `<TMP>` 로 바꿨다 (후보 · 스냅숏 · 사본 바이트는 안 건드림) |

## 1. 도구 (`tools/` · 이 건식용 · 리포 반입 대상 아님)

| 파일 | 하는 일 |
|---|---|
| `verify_copy.py` | 풀린 사본 ↔ `git ls-tree -r -z` 목록 blob 전수 대조 |
| `make_snapshot.py` | IN 목록의 86 경로 (12 의존 + launch 73 + 준비 시험 1) 만 새 폴더로 복사 (`--override` = 한 경로의 바이트를 다른 파일에서 · S0-6 에 한 번) |
| `inv_rows.py` | IN 목록 행의 `bytes` · `sha256` · `git_blob` 만 사본 파일에서 다시 셈 (다른 칸 그대로 · `json.dumps(indent=2)` = 커밋된 파일이 바이트 그대로 돌아오는 꼴) |
| `apply_reseal.py` | ① `seal` (`source_pin` + 12 줄) · ③ `manifest` (메타 줄 · 선택: 머리 `source_pin` 바꿈 / 새 칸 `metadata_generation_source_pin`) · ④ `planned` (메타 바이트 + `SHA256SUMS` 줄) — 바뀐 파일마다 앞 → 뒤 sha256 |
| `guard_case.py` | 사본 F8 의 가드 (`submit_one.py.txt`) 를 그 폴더 자신의 합성 fixture (`test_mla_boundaries.Fixture` · 가짜 sbatch) 로 한 case 한 번 · audit hook 으로 실제 프로세스 · 소켓 거부 |
| `validate_planned.py` | 사본의 `scripts/mixer_precal_prepare.validate_case` 로 F8 계획 자산 (덱 + 메타) 대조 — 관측기가 런 뒤에 하는 바로 그 대조 (`scripts/mixer_precal_observe.py` `validate_case` → `preparation.validate_case`) |
| `lib.sh` | `vin` (검증기 한 번) · `f8tests` (first8 묶음 시험 넷) · `py` · `mini_tree` — 줄마다 `runs/summary.tsv` |

## 2. 단계별 결과 (rc · 거부 사유 = `runs/summary.tsv` · 원 출력 = `runs/<단계>/`)

**S0 — 손대지 않은 HEAD 사본 (적힌 차례: 순서 3 먼저)**

| 단계 | 무엇 | rc | 결과 |
|---|---|---|---|
| S0-2 | IN 검증기 `--mode verify` (HEAD 86 파일 · 커밋된 후보) | 1 | `snapshot SHA256: scripts/mixer_precal_observe.py` |
| S0-3 | IN 검증기 `--mode build` (새 후보 폴더) | 1 | 같은 거부 · 후보 폴더 안 만듦 → **적힌 차례 (3 → 4 ②) 는 3 에서 선다** |
| S0-4 | 재봉인 후보 `make_and_check_seal_candidate.py --check-only` | 0 | 후보 12 = HEAD 파일 · 운영 봉인과 다른 것 3 (관측기 · 생성기 · readback) · 비활성 후보와 다른 것 1 (관측기) |
| S0-5 | `validate_planned` 여덟 (HEAD 준비기 ↔ 지금 계획 메타) | 0 | 0/8 — 여덟 다 `metadata differs from the fixed case recipe` |
| S0-7 | 옛 스냅숏 길: 관측기 바이트만 Q5 전 판 (df22dcf0…) 인 86 파일 · 커밋된 후보 verify | 0 | rc 0 — 이 86 파일 = BASE e48e5fa0 = `21bb09d82` 의 86 파일과 같다 (`git diff --name-only` 21bb09d82 → bfd9b3bbd 사이 86 경로 중 바뀐 것 = 관측기 하나 · e48e5fa0 → 21bb09d82 = 0) |
| S0-8 | first8 묶음 시험 넷 | 1 | submit 3/10 실패 · mla 실패 10 오류 2 /14 · job_start 오류 3 /8 · prepare 1/1 — 사유 `manifest drift` · `input/source drift` (fix_q5 기록과 같다) |

**S1 — ② 먼저 (IN 목록의 관측기 행)** — `head/` 에 그대로 얹음

| 단계 | 무엇 | rc | 결과 |
|---|---|---|---|
| S1-1 | ② 관측기 행: bytes 23987 → 30015 · sha256 df22dcf0… → bb2f3229… · git_blob 98fe91b7… → 03c998fd… (`original_*` · `accepted_*` 칸 그대로) | 0 | 목록 sha256 e0edbae3bb14… → d9076d487da2… |
| S1-3 | `--mode build` → 새 폴더 `runs/S1/cand_reseal/` | 0 | 덱 8 같음 · 메타 8 (생성기 해시만 다름) · STL 24 · 결속 8 · 거부 탐침 33 다 거부 · D2 짝 3 PASS · 묶음 43 파일 |
| S1-4 | `--mode verify` (새 후보) | 0 | — |
| S1-5 | `--mode verify` (커밋된 옛 후보) | 1 | `exact inactive candidate contract` (계약이 목록 sha256 · 관측기 줄을 묶는다 → 옛 후보는 새 목록에서 쓸 수 없다) |
| S1-6 | `--mode old` | 1 | 1 메서드 · 8 subtest 실패 = **기대된 붉음** (`IN/README.md` L59) |
| S1-7 | `--mode preparation-tests` | 0 | 14/14 |
| S1-8 | 새 후보 ↔ 커밋된 후보 (파일마다 sha256) | — | 43 중 다른 것 = `inactive_candidate.json` 하나 (c158416a… → 8cee95e1…) · 자산 40 · 결속 문서 둘 = 바이트 같음 · E0 메타 = 498b941c… |

**S2–S4 — F8 를 하나씩 얹음 (① → ③ → ④ · E0 만)**

| 단계 | 상태 | 가드 E0 | validate_case E0 | 묶음 시험 넷 |
|---|---|---|---|---|
| S2 | ① 만 (`source_pin` f67c0cc92… + 12 줄 · source_seal a3668a2f… → 42709bd7…) | **rc 0 (옛 메타로 통과)** | **REFUSED** `metadata differs …` | **10/10 · 14/14 · 8/8 · 1/1 (다 통과)** |
| S3 | ① + ③ (E0 메타 줄 → 498b941c… · 목록 c0d5179c… → cdd7e7ab…) | HOLD `unsealed or changed planned input deck_meta.json` (놓인 메타 = 원 c6543f38…) | — | submit 3/10 실패 · mla 실패 1 오류 1 · job_start 오류 1 |
| S4 | ① + ③ + ④ (E0 메타 바이트 + `SHA256SUMS` L37 · befb669c… → 925dd897…) | rc 0 (놓인 메타 = 후보 498b941c…) | OK (일곱은 REFUSED · N0 가드는 rc 0) | 10/10 · 14/14 · 8/8 · 1/1 · `sha256sum -c` OK |

**S5 · V2–V6 — 재봉인 뒤 IN 사슬 · 일곱 메타 · `source_pin` · 중간 상태**

| 단계 | 상태 | 결과 |
|---|---|---|
| S5 | 재봉인 뒤 (S4) 의 86 파일 · S1 목록 · verify / build | 둘 다 rc 1 `snapshot SHA256: …/planned_assets/PRECAL_E0/deck_meta.json` — **목록의 launch 73 행이 F8 네 파일의 옛 해시를 묶는다** |
| V2 | S5 + 바뀐 F8 네 파일의 목록 행도 고침 | rc 1 `new generator hash must differ` (검증기 L205 · E0) |
| V3 | ② + ① + 여덟 메타 + 목록 머리 `source_pin` → f67c0cc92… (+ 목록 행) | validate 8/8 OK · 가드 E0 · N0 rc 0 · 묶음 시험 넷 통과 · IN build rc 1 `original asset provenance` (L182) |
| V4 | ② + ① + 여덟 메타 + 머리 `source_pin` **그대로** + 새 칸 `metadata_generation_source_pin` = e48e5fa0… (+ 목록 행) | validate 8/8 OK · 가드 E0 · N0 rc 0 · 묶음 시험 넷 통과 · 목록 차이 = 새 칸 1 줄 + 메타 sha256 8 줄 (c0d5179c… → 191cca9e…) · IN build rc 1 `new generator hash must differ` (L205 · 첫 case) |
| V5 | ② + ① 만 (+ source_seal 목록 행) | IN build rc 1 `operating draft seal unchanged` (L448 · 운영 봉인 핀 == 527e244e 를 요구) · ⚠ build 는 끝 검사 (L444–448) 전에 후보 43 파일을 써 두고 실패한다 (report.json 없음) |
| V6 | ③ + ④ (E0) 먼저 · ① 없이 | 가드 E0 HOLD `manifest drift` (닫힘) · validate E0 OK |

## 3. 찾은 것

1. **적힌 차례 (순서 3 → 4) 는 순서 3 에서 선다** — 검증기는 목록의 관측기 행 (df22dcf0…) 을 HEAD 관측기 (bb2f3229…) 와 맞추지 못한다 (S0-2 · S0-3). 재리뷰의 판독 그대로 실행으로 확인했다.
2. **도는 길 = "목록을 바꾸는 길"** — ② 를 먼저 고치면 HEAD 86 파일로 build · verify rc 0 (S1). 후보 자산은 옛 후보와 바이트 같고, 계약 (`inactive_candidate.json`) 만 새 목록 · 관측기 줄로 바뀐다. 같이 바꿀 것 = 새 후보 폴더 (옛 `IN/candidate/` 는 새 목록에서 `exact inactive candidate contract` 로 거부 · 검증기가 덮어쓰기도 거부).
3. "새 IN 스냅숏" 만 만드는 길 (목록 그대로) 은 둘 중 하나다 — HEAD 86 파일이면 거부 (S0-2), 옛 86 파일 (= BASE e48e5fa0 = 21bb09d82) 이면 rc 0 이지만 이미 있는 IN 기록의 재현일 뿐 재봉인 12 (관측기 bb2f3229) 를 묶지 않는다 (S0-7) → 권하지 않는다.
4. **① 만 먼저는 위험하다** (S2): 가드는 옛 E0 메타를 받아 제출까지 가고 묶음 시험 넷도 다 통과하는데, 관측기의 `validate_case` 는 그 메타를 거부한다 → 런 (4–5 h) 뒤 관측 TECH. ⇒ **first8 묶음 시험은 메타 ↔ 소스 엇갈림을 못 잡는다** — 재봉인 확인에 `validate_case` 대조를 따로 넣어야 한다.
5. ③ 만 (④ 없이) = HOLD (S3) · ③④ 를 ① 보다 먼저 = HOLD `manifest drift` (V6) — 둘 다 닫힘. 끝 상태 ①③④ = 통과 (S4). 등록 7-6 순서 5 의 "두 경우 시험" = S3 (원 메타 거부) · S4 (후보 메타 통과) 로 실제로 섰다.
6. **E0 만 바꾸면 일곱은 함정으로 남는다** (S4): N0 는 가드를 지나는데 (rc 0) validate 는 거부 = N0 때 4 의 꼴. 여덟 다 바꾸면 validate 8/8 · 가드 · 시험 다 통과 (V3 · V4).
7. **재봉인 뒤 IN 검증기는 설계상 F8 를 다시 못 본다** — 목록 행 (S5) · 옛 메타 생성기 ≠ 지금 생성기 (L205 · V2 · V4) · 목록 머리 `source_pin` == 527e244e (L182 · V3) · 운영 봉인 핀 == 527e244e (L448 · V5). 목록 행만 고쳐도 안 된다 (V2). ⇒ IN 묶음 = **재봉인 전 검증 기록** (커밋 A 에서 재현 · 재봉인 뒤 다시 돌리지 않는다). 재봉인 뒤에도 돌게 하려면 검증기 코드 (L182 · L205 · L448) + 목록 행을 바꾸는 별도 검토다 (이 pilot 밖).
8. **목록 머리 `source_pin`** — 가드는 안 읽고 (V3 에서 바꿔도 가드 통과 = 효과 없음), IN L182 는 527e244e 를 요구하며, 덱 · STL 바이트는 527e244e 에서 나왔다 → 그대로 두고 메타 생성 핀을 새 칸에 (V4 = 가드 · 시험 · validate 다 통과 · 목록 차이 9 줄).
9. 검증기 `--mode build` 는 실패해도 후보 폴더를 남길 수 있다 (V5) → 재봉인 때 build 결과는 rc 와 `report.json` 으로만 읽는다 (폴더가 있다는 것으로 읽지 않는다).
10. `make_and_check_seal_candidate.py` 의 만들기 모드는 git 을 부른다 (L21–23) — 이 건식은 `--check-only` 만 (S0-4 rc 0). 재봉인 때 만들기 모드가 필요하면 리포 체크아웃에서 (또는 사본 안 따로 init).

## 4. 실행 가능한 순서 (→ 등록 7-6)

| # | 무엇 | 확인 (건식 근거) |
|---|---|---|
| 1 | ✅ Q5 패치 둘 = 리포 51d45732c · f67c0cc92 | — |
| 2 | ✅ 핀 = f67c0cc92 — push 됨 (원격 추적 ref 11-12T14:06:16Z · `git branch -r --contains` = 1) | 이 조수가 다시 확인 |
| 3 | **커밋 A (IN)**: ② 관측기 행 (S1-1 값) → 검증기 `--mode build` 를 **새** 후보 폴더로 → `verify` · `old` · `preparation-tests` | build · verify rc 0 · old rc 1 (8 = 기대된 붉음) · prep 14/14 · 새 후보 43 중 다른 것 = 계약 하나 (S1) |
| 4 | **커밋 B (F8 · 한 커밋)**: ③ 메타 줄 **여덟** + 머리 `source_pin` 그대로 + 새 칸 `metadata_generation_source_pin` · ④ 메타 바이트 여덟 + `SHA256SUMS` 여덟 줄 · ① `source_pin` = f67c0cc92… + 12 줄 (재봉인 후보) | V4 끝 상태 |
| 4′ | 커밋 B 를 나눠야 하면 ③④ 먼저 → ① (V6 중간 = HOLD) · **① 만 먼저 금지** (S2 중간 = 가드 통과 · 관측 TECH) | S2 · S3 · V6 |
| 5 | 커밋 B 전 · 뒤 확인 (scratch 사본 · 읽기만): 묶음 시험 넷 10/10 · 14/14 · 8/8 · 1/1 · 가드 두 경우 (놓인 E0 메타 = 후보 → rc 0 · 원 → `unsealed or changed planned input deck_meta.json`) · **`validate_case` 여덟 = 8/8 OK** · `sha256sum -c SHA256SUMS` | S3 · S4 · V4 |
| 6 | IN 묶음에 "재봉인 전 검증 기록 (커밋 A)" 표지 · 재봉인 뒤 IN 검증기를 다시 돌리지 않는다 | S5 · V2–V5 |
| 7 | → 내부 반박 리뷰 ("E0 한 팔 한정" 표지) → 1저자 발사 GO | 등록 7-6 순서 5 |

같이 바꿀 것 = ② · 새 IN 후보 폴더 (+ 그 build · verify · old · prep 증거) · ① · ③ · ④ (여덟) · IN README 한 단락 (재봉인 전 기록 표지). 안 바꾸는 것 = `submit_one.py.txt` · `job_start.py.txt` (`REVIEWED_JOB_START_SHA256` 그대로) · 러너 · 덱 여덟 · STL · 정적 목록의 `cases` · `imported_repository_sources` (덱 · STL 생성 기록) · 검증기 코드.

## 5. 한정

- 가드 · job 시작은 그 폴더 자신의 합성 fixture (가짜 sbatch · 모의 환경) 로만 돌렸다 — 실제 SLURM · MPI 아님 (`F8/README.md` L30 · L34 와 같은 한정).
- 커밋 A · B 는 이 건식에서 만들지 않았다 (git 안 씀) — 순서는 파일 상태로만 돌려 봤다. 실제 재봉인 = 1저자 별도 승인 · 리포 게이트는 그때.
- `metadata_generation_source_pin` 값 (e48e5fa0… = 후보 목록의 값 · 같은 생성기 dc253bc8) 과 새 후보 폴더 이름은 [제안] — 재봉인 단계가 정한다.
- 관측기 실제 동작 (실제 로그 · 덤프) 은 이 건식 밖 — `validate_case` 대조는 관측기가 부르는 준비기 함수를 같은 사본에서 직접 부른 것이다.
- Python 3.11.18 하나에서만 돌렸다 (ibb 3.10.20 · 3.9.13 아님).

## 6. 다시 돌리기 (scratch · 리포 읽기만)

```bash
D=<이 폴더> ; source "$D/tools/lib.sh"
mkdir "$D/head" && git -C <REPO> archive --format=tar bfd9b3bbd | tar -x -C "$D/head"
git -C <REPO> ls-tree -r -z bfd9b3bbd > "$D/runs/lstree_bfd9b3bbd.z" && python3 -I -B "$D/tools/verify_copy.py" "$D/runs/lstree_bfd9b3bbd.z" "$D/head"
# 이어서 2 절의 단계 차례대로 — 명령 꼴 = runs/summary.tsv 의 단계 이름 · tools/lib.sh 의 vin · f8tests · py
```
sha256 = `SHA256SUMS` (도구 · 이 README · `runs/summary.tsv` · S1 build 보고 · 새 후보 파일 목록).

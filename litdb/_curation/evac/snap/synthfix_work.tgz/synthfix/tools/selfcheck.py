#!/usr/bin/env python3
"""자기 점검 (읽기만) — 적용한 항목 표본을 정본 카드와 다시 대조한다.

    python3 -I selfcheck.py [<문서 폴더> [<카드 사본의 litdb 폴더>]]

항목마다
  ① doc 글 (doc_has) 이 고친 종합 문서에 있는지
  ② 카드 (정본 c5f78c6 사본) 의 그 줄 범위 (rng) 안에 토큰 (toks) 이 다 있는지
     - 따옴표 (quote=True) 는 토큰 = 따옴표 안 글 전체 — 공백 · 줄바꿈 · 강조 표시 (* · `) 만 정규화해 글자 대조
결과 = 항목마다 한 줄 (통과 / 실패 + 빠진 토큰).
"""
import glob
import os
import re
import sys

FIX = '/tmp/claude-0/-home-user-Yonghoon-DEM-DFT/d26d1e75-209f-540f-83a8-c0e1957edc2f/scratchpad/synthfix'
OUT = '/tmp/claude-0/-home-user-Yonghoon-DEM-DFT/d26d1e75-209f-540f-83a8-c0e1957edc2f/scratchpad/handoff_litread_20261112/litread/synth/out'
CARDS = os.path.join(FIX, 'cards_cache/litdb/papers')
CMP = os.path.join(FIX, 'cards_cache/litdb/comparison_vs_ours_DEM.md')


def norm(s):
    s = s.replace('**', '').replace('*', '').replace('`', '')
    s = re.sub(r'^\s*>\s?', '', s, flags=re.M)
    s = re.sub(r'\s+', ' ', s)
    return s.strip()


def card_text(card, rng):
    if card == 'CMP':
        p = CMP
    else:
        c = sorted(glob.glob(os.path.join(CARDS, card + '*.md')))
        if len(c) != 1:
            raise SystemExit('카드 못 찾음 (하나여야 함): %s %s' % (card, [os.path.basename(x) for x in c]))
        p = c[0]
    L = open(p, encoding='utf-8').read().split('\n')
    if rng:
        a, b = rng
        L = L[a - 1:b]
    return norm('\n'.join(L)), os.path.basename(p)


def doc_text(doc):
    c = sorted(glob.glob(os.path.join(DOCS, doc + '_*.md')))
    if len(c) != 1:
        raise SystemExit('문서 못 찾음: ' + doc)
    return open(c[0], encoding='utf-8').read()


PY = 'pycompact2025_dem_mpfem_workflow'
LEE = 'lee2025_heckel_argyrodite_powder_densification_nanoindentation'
MISS = 'miss2026_insitu_conductivity_porosity_pressure_compaction'
WANG = 'wang2024_hot_pressed_lpscl_pressure_invariant_conductivity'
BARD = 'bardenhagen2005_mpm_foam_densification_simulation'
DOUX = 'doux2020_stack_pressure_assb'

CHECKS = [
    # ── S1
    dict(id='S1 A-48 (값)', doc='S1', doc_has=['42.4 / 42.8 % → 500 MPa 27.0 / 24.7 → 1000 15.6 / 13.7 → 1500 8.5 / 7.0 → 2000 4.4 / 3.3 %'],
         card=PY, rng=(595, 607), toks=['42.4', '42.8', '27.0', '24.7', '15.6', '13.7', '8.5', '7.0', '4.4', '3.3']),
    dict(id='S1 B-28 (값)', doc='S1', doc_has=['≈ 84.2 → 85.5 → 85.9 % (Coarse · 2000 MPa · 카드 11-11 재판독 · μ 0.2 의 stated 값은 85.4 %)'],
         card=PY, rng=(140, 140), toks=['84.2', '85.5', '85.9', '85.4']),
    dict(id='S1 B-25 (값)', doc='S1', doc_has=['K 141.7 GPa → 체적 1.4 % (일축 P/E 1.2 %)'],
         card=PY, rng=(923, 948), toks=['141.7', '1.4', '1.2']),
    dict(id='S1 요지 6', doc='S1', doc_has=['펠릿 회복 0.233 mm [판독] = 설계 높이 5 mm 대비 ≈ 4.7 % [우리 산술]'],
         card=LEE, rng=(100, 106), toks=['0.233', '900', '4.7']),
    dict(id='S1 I-5 (값)', doc='S1', doc_has=['7.0 / 12.1 / 15.7 / 15.2 / 12.8 % (평균 12.6 %'],
         card='minnmann2021_jes_charge_transport_bottlenecks', rng=(130, 185), toks=['4.65', '7.0', '12.1', '15.7', '15.2', '12.8', '12.6', '4.77']),
    dict(id='S1 A-80 (값 · 9.85910)', doc='S1', doc_has=['a = 9.85910 Å (ohno2020 · wang2024 · tron2023) 또는 9.8598 Å (adeli2019 · lee2025 · miss2026)'],
         card=WANG, rng=None, toks=['9.85910']),
    dict(id='S1 A-80 (값 · 9.8598 · lee2025)', doc='S1', doc_has=['9.8598 Å'], card=LEE, rng=(90, 99), toks=['9.8598']),
    dict(id='S1 A-80 (값 · 9.8598 · miss2026)', doc='S1', doc_has=['§3-1 L68–78 (L75)'], card=MISS, rng=(75, 75), toks=['9.8598', '1.860']),
    dict(id='S1 빈 곳 1', doc='S1', doc_has=['1.64 기준 19.2 / 13.5 / 8.5 % ↔ 1.86 기준 28.8 / 23.8 / 19.4 %'],
         card=WANG, rng=None, toks=['19.2', '13.5', '8.5', '28.8', '23.8', '19.4']),
    # ── S2
    dict(id='S2 D-46 (값)', doc='S2', doc_has=['응력 개시 ε ≈ 0.371 (Coarse) / 0.287 (Fine)'],
         card=PY, rng=(579, 594), toks=['0.371', '0.287']),
    dict(id='S2 D-42 (서지)', doc='S2', doc_has=['J. Power Sources 470 (2020) 228437'],
         card='heck2026_densification_sulfide_se_binder_scalable', rng=(300, 310), toks=['Ohashi', '228437', 'CL-90']),
    dict(id='S2 D-55', doc='S2', doc_has=['Hertz 재구성 0.843 (E 1.35 · 과대) / 0.258 (E 24 · 과소)', '(0.670 / 0.809)'],
         card='luding2008_cohesive_frictional_contact_models', rng=(200, 230), toks=['0.843', '0.258', '0.670', '0.809']),
    # ── S3
    dict(id='S3 H-1 (넘긴 시점)', doc='S3', doc_has=['압축 (기공 ≈42–43 → ≈3–4 %) 은 100 % MPFEM'],
         card=PY, rng=(165, 174), toks=['≈42–43', '≈3–4']),
    dict(id='S3 J-3 (따옴표)', doc='S3', quote=True,
         doc_has=['"viscoelasticity for polymeric foams, plasticity for metallic foams, and frictional sliding contact, will be studied later"'],
         card=BARD, rng=(4, 8), toks=['viscoelasticity for polymeric foams, plasticity for metallic foams, and frictional sliding contact, will be studied later']),
    dict(id='S3 G-16 (따옴표)', doc='S3', quote=True, doc_has=["'2D model expected to correctly capture trends in stress and fracture'"],
         card='bucci2017_chemomech_failure_assb_cycling_czm', rng=(212, 216), toks=['2D model expected to correctly capture trends in stress and fracture']),
    dict(id='S3 빈 곳 ㅎ', doc='S3', doc_has=['PyCompact 403–1033 입자 (카드 Table 1 · §15.6'],
         card=PY, rng=(949, 975), toks=['403–1033']),
    # ── S4
    dict(id='S4 K-5 (1-1 무엇을)', doc='S4', doc_has=['하중 중 상대밀도 ≈95.6 · 96.7 % (기공 4.4 / 3.3 %) 까지 가는데'],
         card=PY, rng=(438, 443), toks=['95.6', '96.7']),
    dict(id='S4 K-5 (1-1 한정)', doc='S4', doc_has=['제하하면 5 MPa 규약 13–15 % (P ≈ 0 끝 ≈17 %) 로 되돌아옴'],
         card=PY, rng=(650, 665), toks=['13–15', '17']),
    dict(id='S4 K-196', doc='S4', doc_has=['Coarse-Grain-Factor 가 200 을 넘으면 쓸 수 없다고 적음'],
         card='lischka2025_dem_eirich_intensive_mixer_dry_mixing', rng=(100, 210), toks=['200', '2 mm']),
    dict(id='S4 K-318 (따옴표)', doc='S4', quote=True, doc_has=['| "most likely cause" | A474–A475 · 카드 L32 |'],
         card='landesfeind2018_tortuosity_impedance_vs_tomography', rng=(30, 34), toks=['most likely cause', 'A474']),
    # ── S5
    dict(id='S5 요지 5 째 줄', doc='S5', doc_has=['두께 회복이 1.6 % (300 MPa) · 2.8 % (400 MPa) [재계산]', 'NMC622 는 치밀화의 28 % 가 가역이다'],
         card=MISS, rng=(25, 50), toks=['1.62', 'Li₅.₅PS₄.₅Cl₁.₅']),
    dict(id='S5 요지 5 째 줄 (28 %)', doc='S5', doc_has=['([재계산] · 첫 측정 단계 기준)'],
         card=MISS, rng=(160, 172), toks=['28.1', '첫 측정 단계']),
    dict(id='S5 L-363 (따옴표)', doc='S5', quote=True,
         doc_has=['"Large strains result in numerical inaccuracies as Lagrangian meshes become too distorted or Eulerian meshes require extensive material advection."'],
         card=BARD, rng=(21, 25), toks=['Large strains result in numerical inaccuracies as Lagrangian meshes become too distorted or Eulerian meshes require extensive material advection.']),
    dict(id='S5 5 절 4 (따옴표)', doc='S5', quote=True, doc_has=['"It is believed that no particular model governs the deformation"'],
         card='kakar1967_deformation_theory_hot_pressing', rng=(68, 72), toks=['It is believed that no particular model governs the deformation']),
    dict(id='S5 L-98', doc='S5', doc_has=['카드 보강 11-11: 5 MPa 규약 자리는 ≈ 12–15 %'],
         card=PY, rng=(125, 130), toks=['17.2', '16.9', '≈12', '≈13–14']),
    dict(id='S5 L-108', doc='S5', doc_has=['메시 수렴 판정이 그림 (−1.4 %) ↔ 본문 숫자 (−6.3 %) 로 갈림'],
         card=PY, rng=(546, 561), toks=['−1.4', '−6.3', '철회']),
    dict(id='S5 L-115 (비용)', doc='S5', doc_has=['569 / 874 / 1033 입자 = 9 / 16 / 24 h', '2000 요소/입자 9 h · 2500 요소/입자 36 h', 'PyCompact 7 h ↔ ABAQUS 5 h'],
         card=PY, rng=(350, 360), toks=['569', '874', '1033', '36 h', '9 h', '7 h', '5 h', '24']),
    dict(id='S5 L-8', doc='S5', doc_has=['면적 56 % · 하중 62 % 과대'],
         card='kogutetsion2002_ep_sphere_rigid_flat', rng=(85, 92), toks=['56', '62']),
    dict(id='S5 L-357 (따옴표 1)', doc='S5', quote=True,
         doc_has=['"The main challenges in modeling this process using the MPM is to simulate stress dependent diffusion coupled with concentration dependent stress within a material that undergoes large deformations."'],
         card='gritton2017_mpm_chemomechanical_coupling_silicon_anode', rng=(55, 59),
         toks=['The main challenges in modeling this process using the MPM is to simulate stress dependent diffusion coupled with concentration dependent stress within a material that undergoes large deformations.']),
    dict(id='S5 L-357 (따옴표 2)', doc='S5', quote=True,
         doc_has=['"MPM is chosen as the numerical method of choice because of its ability to handle large deformations."'],
         card='gritton2017_mpm_chemomechanical_coupling_silicon_anode', rng=(37, 41),
         toks=['MPM is chosen as the numerical method of choice because of its ability to handle large deformations.']),
    dict(id='S5 L-346 (원문 위치)', doc='S5', doc_has=['| 묶음 줄에 쪽 없음 (카드 줄 467 · §6.4) |'],
         card='song2025_electrochemo_mechanical_microelectrode_ees', rng=(467, 467), toks=['these models only consider elastic deformation']),
    dict(id='S5 L-347 (원문 위치)', doc='S5', doc_has=['| 묶음 줄에 쪽 없음 (카드 줄 67–68) |'],
         card='song2025_electrochemo_mechanical_microelectrode_ees', rng=(67, 68), toks=['directly defining the governing equations on each component']),
    # ── S6_1
    dict(id='S6_1 MA-221', doc='S6_1', doc_has=['9 ± 2 / 15 ± 2 / 26 ± 4 / 41 ± 5 J/m² @ 100 / 200 / 300 / 400 MPa', '하드카본 인터레이어는 1 / 3 / 7 / 11 J/m²'],
         card='liao2025_interfacial_adhesion_li_plating_carbon_interlayer', rng=(48, 60), toks=['9 ± 2', '15 ± 2', '26 ± 4', '41 ± 5']),
    dict(id='S6_1 MA-25', doc='S6_1', doc_has=['이 논문 MSE 로트 200 °C 펠릿 1.69 > 1.64'],
         card=WANG, rng=(40, 52), toks=['1.69', '그 로트']),
    dict(id='S6_1 MA-26 (따옴표)', doc='S6_1', quote=True, doc_has=['카드: "확인 필요 (주장 아님)"'],
         card='stallard2022_cathode_mechanical_properties_review', rng=(458, 462), toks=['확인 필요 (주장 아님)']),
    dict(id='S6_1 MA-71 (따옴표)', doc='S6_1', quote=True, doc_has=['"리뷰 명문 처방은 아니지만"'],
         card='coetzee2017_dem_calibration_review', rng=(305, 310), toks=['리뷰 명문 처방은 아니지만']),
    dict(id='S6_1 MA-122 (따옴표)', doc='S6_1', quote=True, doc_has=['"총 접합 컨덕턴스가 끝없이 L_c 에 비례"'],
         card='hamasaki2022_single_parallel_contact_mwcnt_conductivity', rng=(192, 196), toks=['총 접합 컨덕턴스가 끝없이 L_c 에 비례']),
    dict(id='S6_1 MA-125 (따옴표)', doc='S6_1', quote=True, doc_has=['"우리 수송 tortuosity (tau2 = φ_SE · σ₀ / σ_eff) 와 같은 정의"'],
         card='kim2023_mechanofusion_ncm811_lpscl_core_shell_intimate_contact', rng=(100, 104), toks=['우리 수송 tortuosity (tau2 = φ_SE · σ₀ / σ_eff) 와 같은 정의']),
    dict(id='S6_1 MA-215 (따옴표)', doc='S6_1', quote=True, doc_has=['"원통 인양 중 기둥의 상 전이 간극 + 슬라이스 지름 (상대 굽힘 y_rel = (y − D)/D)"'],
         card='roessler2019_dem_cohesive_aor_cylinder_lift_calibration', rng=(26, 30), toks=['원통 인양 중 기둥의 상 전이 간극 + 슬라이스 지름 (상대 굽힘 y_rel = (y − D)/D)']),
    # ── S6_2
    dict(id='S6_2 MB-114', doc='S6_2', doc_has=['순수 Li₆PS₅Cl · ≈900 MPa → 0 · 다이 안 · 측방 구속 · 펠릿 높이 ≈5.0 mm 가정'],
         card=LEE, rng=(181, 181), toks=['≈900 MPa → 0', '다이 안', '측방 구속', '다른 조건']),
    dict(id='S6_2 MB-82', doc='S6_2', doc_has=['80.3–84.9 % (이론밀도 1.860 g/cm³ 기준'],
         card=DOUX, rng=(204, 205), toks=['80.3', '84.9', '1.860']),
    dict(id='S6_2 MB-69', doc='S6_2', doc_has=['(분모 = 압밀 시료 Rietveld 결정밀도 · 값 [미확인] · 장치 순응 보정 [미확인])'],
         card='faka2026_particle_size_consolidation_strain_lpscl', rng=(20, 62), toks=['Rietveld', '미확인', '12.9', '26.3']),
    dict(id='S6_2 MB-11 (따옴표)', doc='S6_2', quote=True, doc_has=['"문헌 DEM 압축곡선을 우리 것과 나란히 놓을 때 재하율 미보고는 1급 교란"'],
         card='otani2025_dem_se_dispersion_aggregation_compression', rng=(282, 285), toks=['문헌 DEM 압축곡선을 우리 것과 나란히 놓을 때 재하율 미보고는 1급 교란']),
    dict(id='S6_2 MB-55 (따옴표)', doc='S6_2', quote=True, doc_has=['"우리가 같은 대조를 짜려면 이 규모(12–14 입자)면 된다"'],
         card='zunker2025_dem_large_deformation_compaction', rng=(265, 267), toks=['우리가 같은 대조를 짜려면 이 규모(12–14 입자)면 된다']),
    dict(id='S6_2 MB-70 (따옴표)', doc='S6_2', quote=True, doc_has=['카드가 "앵커" 가 아니라 "후보 (기준 미확인)" 로 한정'],
         card=LEE, rng=(211, 211), toks=['"앵커" 가 아니라 "후보 (기준 미확인)"']),
    dict(id='S6_2 MB-152 (따옴표)', doc='S6_2', quote=True, doc_has=['"CAM utilization 정의(ref 14, Shi 2020)"'],
         card='tailored_cathode_microstructure_low_pressure_assb', rng=(70, 72), toks=['CAM utilization 정의(ref 14, Shi 2020)']),
    dict(id='S6_2 MB-1 (한계)', doc='S6_2', doc_has=['카드가 LPSCl κ ≈ 26 GPa 를 넣어 셈한 값 (논문 측정값 아님)'],
         card='zunker2024_mdr_contact_model_partI', rng=(207, 212), toks=['κ ≈ 26 GPa', '1.2 %']),
    dict(id='S6_2 MB-79', doc='S6_2', doc_has=['분모 ρ₀ = 결정밀도 1.87 · 300 MPa 전 10 회 놓은 단계 하중'],
         card=MISS, rng=(291, 291), toks=['300 MPa 전 10 회 놓기', 'ρ₀ 1.87']),
    # ── S6_3
    dict(id='S6_3 MC-67', doc='S6_3', doc_has=['마지막 증분 −1.4 % (평탄화) 인데 본문 2500 점 1310 MPa 는 그림 ≈1379 와 ≈70 MPa 어긋남'],
         card=PY, rng=(546, 561), toks=['−1.4', '1310', '1379', '36 h', '9 h', '≈70 MPa', '철회']),
    dict(id='S6_3 MC-100', doc='S6_3', doc_has=['단위 환산 (cm → mm ×10, p.3) 만 적고, 번호 (CSV 에 없음 · FE 쪽 pid = i 로 다시 매김)'],
         card=PY, rng=(254, 300), toks=['multiplying by 10', 'pid = i', '가압 전 · 중력 침강 뒤', '겹친 구 · 틈의 처리: 원문에 문장 없음 [미확인]']),
    dict(id='S6_3 MC-112 (따옴표)', doc='S6_3', quote=True, doc_has=['*"Effective densification by bimodal structure → suppression of particle crack"*'],
         card='mun2025_dry_electrode_technology_assb_review', rng=(182, 182), toks=['Effective densification by bimodal structure → suppression of particle crack']),
    dict(id='S6_3 MC-36 (따옴표)', doc='S6_3', quote=True,
         doc_has=['"5/25/75 MPa stack pressure 의 (펠릿 자체) 기계적 성질은 단락 메커니즘에 영향을 주지 않을 것으로 본다 — 펠릿은 이미 370 MPa 로 cold-press 되어 있기 때문."'],
         card=DOUX, rng=(237, 238), toks=['5/25/75 MPa stack pressure 의 (펠릿 자체) 기계적 성질은 단락 메커니즘에 영향을 주지 않을 것으로 본다 — 펠릿은 이미 370 MPa 로 cold-press 되어 있기 때문.']),
    dict(id='S6_3 요지 3 (MC-61)', doc='S6_3', doc_has=['구조 붕괴 구간 (ε 0.3–0.55) 에서 35 % 차 (탄성 구간 2 % · 발포체 3D MPM)'],
         card=BARD, rng=(468, 468), toks=['평균 35 % (ε 0.3–0.55)', '탄성 구간에서는 2 %']),
    dict(id='S6_3 요지 9 (MC-339)', doc='S6_3', doc_has=['2 단자 = 접합 컨덕턴스의 하한 (저항으로는 R ≤ 측정값)'],
         card='fuhrer2000_crossed_nanotube_junctions', rng=(84, 146), toks=['접합 컨덕턴스의 하한', 'R ≤']),
    dict(id='S6_3 어-17', doc='S6_3', doc_has=["'overlap 1.75 %' 를 δ/d 로 읽은 값 ↔ ⟨δ⟩ ÷ 지름 ≈7 % (δ/d)"],
         card='CMP', rng=(700, 705), toks=['δ/d = 0.0175', '0.0739', 'δ/d ≈ 7 %', '4배 차']),
]


def main():
    global DOCS, CARDS, CMP
    DOCS = sys.argv[1] if len(sys.argv) > 1 else OUT
    if len(sys.argv) > 2:      # 카드 사본 뿌리 (…/litdb) 를 바꿔 다른 정본 커밋으로 다시 대조
        CARDS = os.path.join(sys.argv[2], 'papers')
        CMP = os.path.join(sys.argv[2], 'comparison_vs_ours_DEM.md')
    docs = {}
    ok = 0
    fail = 0
    nq = 0
    for c in CHECKS:
        if c['doc'] not in docs:
            docs[c['doc']] = doc_text(c['doc'])
        miss_doc = [s for s in c['doc_has'] if s not in docs[c['doc']]]
        ct, fn = card_text(c['card'], c.get('rng'))
        miss_card = [t for t in c['toks'] if norm(t) not in ct]
        if c.get('quote'):
            nq += 1
        if miss_doc or miss_card:
            fail += 1
            print('✗ %-28s 문서에 없음 %s · 카드에 없음 %s (%s %s)' % (c['id'], miss_doc, miss_card, fn, c.get('rng')))
        else:
            ok += 1
            print('✓ %-28s %s%s L%s' % (c['id'], '[따옴표] ' if c.get('quote') else '', fn[:48], c.get('rng') or '전체'))
    print('자기 점검: 항목 %d (그 가운데 따옴표 글자 대조 %d) · 통과 %d · 실패 %d' % (len(CHECKS), nq, ok, fail))
    return 1 if fail else 0


if __name__ == '__main__':
    sys.exit(main())

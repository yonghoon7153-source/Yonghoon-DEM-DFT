#!/usr/bin/env python3
"""스크래치 (커밋 안 함) — S0 단계 1 다시 + 저장본 재기 블록 (kgy · 1저자 붙여 넣기) 조립: 감싸개 · 감시 셸을 heredoc 으로 싣고 md5 관문 값을 채운다.
  python3 make_s0_block.py <out.txt>
블록 글 = ASCII 만 · 느낌표 · 탭 · CR 없음 (조립 끝에 검사 · 어기면 실패)."""
import hashlib
import os
import sys

here = os.path.dirname(os.path.abspath(__file__))
probe = open(os.path.join(here, 's0_store_probe_en.py'), encoding='ascii').read()
mon = open(os.path.join(here, 'mon.sh'), encoding='ascii').read()
md5p = hashlib.md5(probe.encode('ascii')).hexdigest()
md5m = hashlib.md5(mon.encode('ascii')).hexdigest()
for name, txt, eof in (('probe', probe, 'S0Q_PROBE_EOF'), ('mon', mon, 'S0Q_MON_EOF')):
    assert txt.endswith('\n'), name
    assert eof not in txt and 'S0Q\n' not in txt, name

block = """# S0 stage 1 rerun on kgy + carbon-junction registry store measurement (v2 2026-11-12, Rint 2 code package, RCP-04 / RCP2-04).
# Paste the whole block at the kgy bash prompt (the account that runs R).  Fill PIN first (40-hex tip of the branch after the
# code package import).  PROBE=1 runs S0 under the store probe wrapper (same registry object back to S0, S0 outputs the same,
# only elapsed_s includes the probe seconds); PROBE=0 runs S0 alone (the 2026-11-06 form).  TAG = output folder suffix.
# Author decision 2026-11-12 night: Q-B (a) = the official S0 stage 1 rerun runs under the probe (PROBE=1 = this block's default) and
# the proposed thresholds T1-T3 are adopted as written.  Registered before the result in the repository:
# docs/reviews/rint2_s0_store_probe_20261112/README.md (same E1-E4, T1-T3, md5 gates).
# Expected before the result:
#   E1 S0 rc 0, six outputs, import tool ADOPT_CANDIDATE, S0 report git_head = PIN, git_dirty False
#   E2 one wrapper call, instances 117,583 (the 2026-11-08 SBE run, same bed; the registry code carbon_junction.py and
#      fibre_segment_raster.py is unchanged since that pin f47bde0f6)
#   E3 encode ok, write built_written, read hit, same = strict True and registry_fp True, store_start preloaded [] and error None,
#      code_drift [], error None
#   E4 S0 plan and arrays = 2026-11-08 (code fingerprint and time fields aside)
# Thresholds (exceeded = report, the R plan decides):
#   T1 seconds_write <= 600 s, seconds_read <= 300 s, seconds_read <= 10 % of seconds_build
#   T2 memory increase (VmHWM over steps 2-4 minus VmRSS before step 1) <= 4 GiB
#   T3 store file <= 2 GiB
# E3 fails (built_write_skipped, built_write_failed, disabled = code_changed or no /etc/machine-id, read not hit, same False, error):
# R does not use --cjunc-store; tell the main session; measure again after the fix.
# Writes: a new log folder ~/s0log_<UTC>, a new S0 output folder ~/sdcp/ca1_s0_sbe_<UTC>_<TAG>, a new store folder
# ~/sdcp/cjstore_s0probe_<UTC> (PROBE=1; measurement only - its file is never read by R, the stage-1 thresholds differ), the
# pinned worktree ~/dem-s0-<pin9> (git worktree add, or reused) with its admin entry under BASE's .git/worktrees, BASE's FETCH_HEAD
# and the remote-tracking ref of the branch (git fetch), and at the end ~/s0log_<UTC>.tgz (+ .sha256).
# No kit, run folder or tracked repository file is changed.  No sigma.  About 1.5 h of CPU (2026-11-08: 5,383 s, RSS sample max 5.4 GiB).
bash <<'S0Q'
set -u
PIN='<PIN>'
PROBE=1
TAG=q2q11
BASE="$HOME/dem-mt"
BR=claude/stoic-knuth-NObVQ
KIT="$HOME/sdcp/kit_SBE_vgcf100"
stop() { echo "[s0q] STOP: $* (S0 not started)"; exit 2; }
case "$PROBE" in 0|1) ;; *) stop "PROBE must be 0 or 1 (nothing written)";; esac
printf '%s' "$TAG" | grep -Eqx '[A-Za-z0-9_]{1,40}' || stop "TAG must be letters, digits or _ (nothing written)"
printf '%s' "$PIN" | grep -Eqx '[0-9a-f]{40}' || stop "PIN is not a 40-hex commit (nothing written)"
STAMP="$(date -u +%Y%m%dT%H%M%SZ)"
W="$HOME/dem-s0-$(printf %.9s "$PIN")"
O="$HOME/sdcp/ca1_s0_sbe_${STAMP}_${TAG}"
L="$HOME/s0log_${STAMP}"
S="$HOME/sdcp/cjstore_s0probe_${STAMP}"
for p in "$O" "$L" "$S" "$L.tgz"; do if [ -e "$p" ]; then stop "$p already exists (nothing written)"; fi; done
[ -x "$HOME/dem-venv/bin/python3" ] || stop "venv python not found (nothing written)"
[ -d "$KIT" ] || stop "kit not found (nothing written)"
git -C "$BASE" rev-parse --git-dir > /dev/null 2>&1 || stop "BASE is not a git checkout - fix the BASE line (nothing written)"
for d in "$HOME"/s0log_*; do
  [ -d "$d" ] || continue
  if [ -e "$d/DONE" ] || [ -e "$d/STOPPED" ]; then continue; fi
  stop "earlier log folder $d has no DONE or STOPPED: an S0 run may still be running there - look at its rss.log (nothing written)"
done
git -C "$BASE" fetch -q origin "$BR" || stop "git fetch failed (nothing written)"
TIP="$(git -C "$BASE" rev-parse FETCH_HEAD)"
[ "$TIP" = "$PIN" ] || stop "PIN is not the tip of $BR after the fetch (tip $TIP) - use the tip or fix the PIN line (only git fetch ran)"
if [ -e "$W" ]; then echo "[s0q] reusing worktree $W"; else
  git -C "$BASE" worktree add -q --detach "$W" "$PIN" || stop "git worktree add failed"
fi
[ "$(git -C "$W" rev-parse HEAD)" = "$PIN" ] || stop "worktree HEAD differs from PIN"
[ -z "$(git -C "$W" status --porcelain)" ] || stop "worktree $W has local changes (S0 records git_dirty) - use a clean worktree"
[ -f "$W/scripts/cjunc_store.py" ] || stop "the pinned worktree has no scripts/cjunc_store.py (pin is before the code package)"
umask 022
mkdir "$L" || stop "cannot create $L"
stopl() { echo "reason=$*" > "$L/STOPPED"; stop "$*"; }
if [ "$PROBE" = 1 ]; then mkdir "$S" || stopl "cannot create $S"; fi
cat > "$L/s0_store_probe.py" <<'S0Q_PROBE_EOF'
""" + probe + """S0Q_PROBE_EOF
cat > "$L/mon.sh" <<'S0Q_MON_EOF'
""" + mon + """S0Q_MON_EOF
[ "$(md5sum < "$L/s0_store_probe.py" | cut -c1-32)" = """ + md5p + """ ] || stopl "probe script paste broken (md5 differs)"
[ "$(md5sum < "$L/mon.sh" | cut -c1-32)" = """ + md5m + """ ] || stopl "monitor script paste broken (md5 differs)"
printf 'pin=%s\\nprobe=%s\\ntag=%s\\nkit=%s\\nout=%s\\nstore=%s\\nstart_utc=%s\\n' "$PIN" "$PROBE" "$TAG" "$(basename "$KIT")" "$(basename "$O")" "$(basename "$S")" "$STAMP" > "$L/meta.txt"
setsid bash "$L/mon.sh" "$L" "$W" "$O" "$S" "$KIT" "$PROBE" > "$L/mon.out" 2>&1 < /dev/null &
i=0
while [ "$i" -lt 15 ]; do [ -s "$L/s0.pid" ] && break; sleep 2; i=$((i + 1)); done
[ -s "$L/s0.pid" ] || stopl "the monitor did not start within 30 s - look at $L/mon.out"
echo "[s0q] S0 stage 1 started (probe $PROBE) - log folder $L , output $O"
echo "[s0q] progress:  tail -n 1 $L/rss.log ; grep -c . $L/run.log"
echo "[s0q] when $L/DONE appears (about 1.5 h): send back ~/$(basename "$L").tgz and its .sha256 (S0 outputs + logs + store_probe.json)"
echo "[s0q] the store folder $S is not packed - after the report it can be removed (R never reads it)"
S0Q
"""
for i, ln in enumerate(block.splitlines(), 1):
    for bad, what in (('\t', 'tab'), ('\r', 'CR'), ('!', 'bang')):
        if bad in ln:
            raise SystemExit(f'line {i}: {what}')
    try:
        ln.encode('ascii')
    except UnicodeEncodeError:
        raise SystemExit(f'line {i}: non-ASCII')
out = sys.argv[1]
with open(out, 'w', encoding='ascii') as f:
    f.write(block)
print('written', out, 'probe md5', md5p, 'mon md5', md5m, 'lines', len(block.splitlines()))

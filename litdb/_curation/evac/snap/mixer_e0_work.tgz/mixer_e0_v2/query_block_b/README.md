# 믹서 E0 자격 pilot — 봉인 전 보충 조회 블록 q9b · q2b · q7b (초안 2026-11-12 밤)

**초안 · ibb 실행 0 · 현장 결과 0 · 제출 · 취소 · 계산 0 · 리포 쓰기 0 · 자격 판정 아님 · 봉인 값 확정 아님 · 전체 HOLD 그대로.**
승인 근거: 1저자 11-12 밤 오버나잇 *"권고대로"* = 등록 초안 (`../e0_pilot_registration_draft.md`) 18 절 2 회차 표 **Q-F′ (q9b) · Q-G′ (q7b) · Q-K (q2b)** · 정의 = 13-1 절.
주소 · 포트 · 계정 · 노드 이름 값은 이 폴더의 어느 파일에도 없다 (블록 안은 `$HOME` · `$USER` · sinfo 결과뿐 · 시험 값은 전부 가짜).

## 0. 만든 파일

| 파일 | 뭐 |
|---|---|
| `query_block_b.txt` | **1저자가 ibb 로그인 셸 (bash) 에 붙일 블록 하나** — 551 줄 · 37,817 B · 블록 파일 sha256 `d1a400ad776b38d3b3c6ec8736f4c5b4bf5435c75a1632a5218ed587411d104c` · **스크립트 md5 `3c0a612028d16692625c264224a573fc`** (블록 첫 줄 · 마지막 줄 게이트 · `src/query_script_b.sh` 셋이 같다) |
| `src/query_script_b.sh` | 블록 본문 원본 (546 줄 · 36,783 B · 최장 줄 249 B) — 고칠 때는 이것을 고치고 `src/build_block.sh` 로 다시 만든다 |
| `src/build_block.sh` | 11-12 조회 블록과 같은 검사 (`bash -n` · 느낌표 · 탭 · CR · 줄 첫 `^` · 구분자 줄 · 끝 개행 · 크기) + md5 게이트 블록 생성 |
| `read_query_bundle_b.py` | 받은 tgz 를 빈 새 폴더에 안전하게 풀고 대조 · 요약 (`python3 -I`) — 4 절 |
| `test/` | `run_tests.sh` · `check_run.py` · `mkworld.py` · `fakes/` — 컨테이너 시험 (PID 1 이 아니면 거부) · 기록 `last_run.txt` (뒤) · `last_run_before.txt` (고치기 전) · `run_*/` (판정 기록만 · 가짜 세계는 지움) |

## 1. 조회 셋 ↔ 출력 (out/ · 가린 사본)

| q | 대상 | 출력 파일 · 줄 꼴 (숫자 값 · 본문 · 경로 문자열 없음) |
|---|---|---|
| q9b | `~/mixer_dev7_20260930_v26/<런>/log.liggghts` 아홉 (DEV E0 다섯 r1–r5 + dev-bo `LHx10` · `LHx30` + dev-u `LU212` · `LU637` — 없으면 ABSENT) | `q9b_l<i>.txt`: `log|i|lines|tables|nonrow|emitted|suppressed|tables_suppressed|cr` · 표마다 `table|i|k|header_cols|rows|rows_nonfinite|row_cols|nonrow|blank|closed` (11-12 q9 와 같은 센 수) · **비-행 줄마다 로그 차례대로** `nr|i|표|표 안 차례|rows_before=<앞 숫자 행 수>|sp=<앞 빈칸 수>|tab=<앞 탭 수>|word=<가린 첫 낱말>` (첫 낱말 = 줄 가림 + 4 자 이상 토큰 글자 가림 뒤 숫자 → `#` · `/` → `<PATHLIKE>` · 24 자) · 로그당 300 줄까지 (넘치면 `suppressed` + 상태 `q9b_l<i>_cap|TRUNC`) |
| q2b | r1 `post/` 의 `mix_<step>.liggghts` — **이름의 step 으로만** 처음 · 가운데 ((n+1)/2 번째 = 11-12 q2 와 같은 자리) · 끝 | `q2b_pick.txt` (`q2b|…|files|matched|sorted|other|noise` · `sel|first|<step>` …) · `q2b_frames.txt`: `frame|pos|step|type|bytes|end_nl=yes/no|newlines=<개행 수>|l1_timestep=yes/no|tstep=same/num/differ/nonint/missing|l3_natoms=yes/no|atoms=<머리 4 째 줄>|nl_eq_9_plus_atoms=yes/no` — 머리 4096 B 와 끝 1 B 는 **셸 변수로만** 읽고 파일에 쓰지 않는다 · TIMESTEP 값은 안 옮김 (꼴만) |
| q7b | `~/.conda/envs/myenv/conda-meta/` 의 openmpi · ucx · ucc · libfabric · libfabric1 · libpmix · libhwloc JSON (이름 = 파일 이름에서 판 · 빌드를 뗀 것이 정확히 같을 때만 · 0 개 = ABSENT · 2 개 이상 = FAIL) | `q7b_p<k>_sum.txt`: `pkg|k|name|json=<JSON 파일 이름>|matches` · `json|k|<JSON sha256>|크기|mtime` · `parse|k|elements|escaped|files_keys|depth_end|instr_end|bad` · `sum|k|listed|in_list|over_cap|hashed|bytes_hashed|links|reasons=<사유:수;…>` · `digest|k|<다이제스트>|lines` · `q7b_p<k>_files.txt`: 파일마다 `f|<JSON files 배열 자리>|<lstat 종류>|<lstat mtime>|<대상 종류>|<대상 크기>|<대상 mtime>|<sha256 또는 사유>` (종류 f · e · l · d · o · 사유 NO_LSTAT · BROKEN · NOT_REGULAR · TOO_BIG (> 1 GiB) · HASH_FAIL · CHANGED_DURING_HASH · STOPPED (시간 · 예산 · Ctrl-C 로 못 감) · ESCAPED (`\"` `\\` `\/` 밖 JSON 이스케이프) · UNSAFE_PATH (절대 · `..`)) · 목록 15000 까지 (넘치면 `over_cap` + `q7b_p<k>_cap|TRUNC`) · 다이제스트 = `자리|lstat 종류|대상 종류|대상 크기|sha256·사유` 줄들의 sha256 (시각 빼고 — 봉인 값 · W9 대조용) |

- JSON 해석 = 맨 위 `"files"` 배열만 (문자열 안 괄호 · 따옴표 · 중첩 `"files"` 무시 · 문자 하나씩 · 3.8 MB 0.7 초 이하 [컨테이너 실측]). 링크는 따라가 해시하고 (`stat -L` · `sha256sum`) 자기 시각도 적는다 · 해시 전후 `stat -L` 이 같아야 sha256.
- 해시는 400 개씩 묶어 한 명령 (`stat` · `stat -L` · `sha256sum` · `stat -L`) — 묶음마다 `timeout` (stat 60 · sha256 120 초 · `-k 5`) · 멈추면 그 단계 이후 파일 = `STOPPED`.

## 2. 블록 설계 (11-12 조회 블록과 같은 꼴 + 바뀐 것)

- 붙여넣기 꼴 · md5 게이트 · `BASH_ENV=` · 새 폴더 하나 (`~/mixer_e0_queryb_<UTC>/` · umask 077 · `raw/` `out/` `work/` · tgz + `.sha256`) · `TMPDIR` = `work/tmp` · Ctrl-C trap · 예산 `MIX_BUDGET` 600 초 · 묶음 상한 +300 초 = 그대로.
- **안 부르는 명령** = 11-12 목록 + sacct · lfs · ldd · readelf · objdump · du · cp (시험의 감시 명령 33 종 호출 0). 부르는 것 = stat · readlink · find · sort · awk · head · tail · wc · cat · grep · sha256sum · md5sum · tar · gzip · **sinfo (`-h -N -o %N` · 노드 이름 → 가림 목록에만)** · hostname · id · date.
- **상태 어휘** = OK · FAIL · MISSING (명령 없음) · **ABSENT (대상 없음) · DENIED (stat 권한 거부)** · TIMEOUT · TRUNC · SKIPPED_BUDGET · SKIPPED_INTERRUPT · SKIPPED_SWITCH. 어느 것도 멈추지 않는다 (시작 관문만 예외).
- **가림** = 11-12 규칙 그대로 (홈 · 실제 홈 · 호스트 · 계정 (낱말 경계) · `/home/<다른 사용자>` · IPv4 (+포트) · uid/gid · `compiled … by` · `CANCELLED by` · `host:<이름>:<포트>`) **+ 노드 이름** (sinfo · 2–64 자 `[A-Za-z0-9._-]` · 중복 하나로 → `<NODE>` · 낱말 경계) **+ 도메인** (호스트 FQDN 의 첫 점 뒤 · 점 든 6 자 이상 → `<DOMAIN>`) · 토큰은 긴 것 먼저. 가린 사본은 `work/` 에 먼저 쓰고 awk 가 성공할 때만 `out/` 에 옮겨 적는다 (실패 = `out/` 에 그 파일 없음 + `redact_fail` + 화면 ⚠).
- **남은 토큰 검사** = 16 진 글자만인 토큰 · 6 자 미만 토큰은 낱말 일치 (`grep -w` — sha256 안의 우연한 일치를 세지 않게) · 그 밖은 글자 일치 (붙은 꼴도 잡게). sinfo 가 실패하면 화면에 "노드 이름 ⚠ 가림 목록 0 개".
- 스위치: `MIX_Q='q9b q2b q7b'` (기본 셋 다 · 쉼표도 됨) · 발사 직전 · T9 직후 다시 재는 q7b 만이면 `export MIX_Q=q7b` (W9 · 등록 12 절) · `MIX_BUDGET=<초>`.

## 3. 시험 (컨테이너 · PID 이름공간 · 읽기 전용 마운트 · DAC 무시 권한 뗀 root · 가짜 HOME · 가짜 명령)

**고치기 전 (블록 · 판독기 · 원본 없음) PASS 48 · FAIL 38 → 뒤 PASS 1104 · FAIL 0 (같은 파일로 두 번 · 두 번 다)**. 고치기 전의 PASS 48 = 아무것도 안 해도 참인 단언 (rc 0 · 밖 변화 0 · 금지 명령 0 · 게이트 무생성) — 폴더가 안 생겨 나머지 단언 대부분은 닿지도 않았다.

| 사례 | 넣은 것 | 결과 (뒤) |
|---|---|---|
| 공통 (16 사례 중 14 — 게이트 t8a · t8b 빼고) | rc · 새 폴더 1 · 밖 변화 0 · 금지 명령 0 · tgz = out/ 바로 아래만 · 소유자 이름 없음 · 화면 sha256 = 실제 · SHA256SUMS · RAW_SHA256SUMS 전수 · private_* 없음 · 화면 / out/ 에 홈 · 계정 · 호스트 · 노드 · 도메인 · IPv4 · 경로 표지 0 · **새 폴더 어디에도 (raw/ · work/ 포함) 로그 · 덤프 · conda 파일 · JSON · 금고 내용 0** · 남은 토큰 0 · 상태 어휘 | 전부 PASS |
| t1 · t2 · t10 · t8c · t13 | 정상 세계 (mawk · gawk · ibb 경로 관계 · 대화형 `bash -i` · ucx 파일 하나 바뀜) | q9b 아홉 · q2b 세 장 · q7b 일곱 줄마다 = 명세에서 독립 계산한 기대 (보고 쌍 = E0 표 1 · dev-bo/dev-u 표 1 · 3 · INFO 앞 공백 0 · `-` 앞 공백 1 · 첫 행 뒤) · mawk = gawk 바이트 같음 · 노드 토큰 4 (중복 · 1 글자 · 공백 이름 뺌) · 16 진 노드 이름 `e7` 이 out/ 의 sha256 안에 글자로 11 번 있어도 남은 토큰 0 (낱말 일치 0) |
| t3 실패 섞기 | 로그 없음 2 · 읽기 권한 없음 · 로그가 디렉터리 · 막힌 런 폴더 · 프레임 권한 없음 · 0 채운 TIMESTEP · 끝 개행 없음 + TIMESTEP 어긋남 · conda 파일 없음 · 권한 없음 · 막힌 폴더 · 깨진 링크 · 1.07 GiB 성긴 파일 · `é` · `../` · 절대 경로 · JSON 없음 · 깨진 JSON · sinfo 실패 · 표 밖 WARNING · 앞 공백 2 · 자리 어긋남 · 닫히지 않은 표 | ABSENT 2 · FAIL 2 · DENIED 1 · 프레임 FAIL 셋 · `tstep=num` · `end_nl=no · differ · nl_eq no` · 사유 NO_LSTAT 2 · HASH_FAIL 1 · BROKEN 1 · TOO_BIG 1 (읽지 않음) · ESCAPED 1 · UNSAFE_PATH 2 · ABSENT · 해석 FAIL (해시 안 함) · 노드 토큰 0 + 화면 경고 · 묶음은 만듦 · rc 0 |
| t4 멈춘 명령 | conda 묶음 해시 · 프레임 머리 읽기가 TERM 을 무시하고 잔다 (한 번씩) | 해시 TIMEOUT 125 초 → 그 꾸러미 파일 = STOPPED · 다른 꾸러미 OK · 머리 TIMEOUT 35 초 → 그 프레임은 끝 개행 · 개행 수만 · 나머지 `-` · 전체 162 초 · 남은 프로세스 0 |
| t5 예산 · t6 스위치 · t9 Ctrl-C · t14 빈 세계 | `MIX_BUDGET=2` · `MIX_Q=q7b` · SIGINT · DEV 폴더 · conda 환경 없음 | 셋 다 SKIPPED_BUDGET · q9b · q2b SKIPPED_SWITCH · interrupted=1 (2.3 초) · q9b ABSENT 아홉 · q2b_names FAIL (find 오류 문구를 이름으로 안 셈) · q7b_env ABSENT — 전부 묶음 만듦 |
| t7 줄 수 넘침 | 비-행 1002 줄 · JSON 목록 16000 · CRLF 로그 | 300 줄만 + `suppressed=702` + TRUNC · 15000 까지 + `over_cap=1000` + TRUNC · `cr` = 줄 수 · 출력 < 4 MB |
| t12a · t12b 가림 실패 | JSON 파일 이름에 계정 문자열이 붙음 · 가림 awk 실패 | 남은 토큰 1 → 화면 ⚠ "넘기지 말 것" · 판독기 rc 1 / 가린 사본 out/ 에 없음 · redact_fail · 화면 ⚠ · 판독기 rc 1 · (첫 낱말에 붙은 계정 · 노드 · 도메인은 `<USER>X:` · `<NODE>x:` · `<NODE>.<DOMAIN>:` 로 가려짐) |
| t8 게이트 | 한 글자 · CRLF · 대화형 · CRLF 를 DEM1 sed 로 고침 | 아무것도 안 만듦 · 명령 0 · 정상 · 원본과 바이트 같음 |
| t11 실물 로그 (리포 읽기만) | 블록 본문의 가림 함수 + q9b awk 를 꺼내 kg50 `log_ins1` · devu `log.exact` · kg50 `log_main1103` 에 | mawk = gawk 바이트 같음 · `log_ins1` 삽입 표 1 = `INFO:` (앞 공백 0) 다음 `-` (앞 공백 1) · 둘 다 첫 행 뒤 (1 프로세스 실물) · `log.exact` 비-행 0 · `log_main1103` 표 210 · 비-행 0 |
| 판독기 | 정상 · 실패 · 넘침 · 빈 묶음 · 위조 | rc 0 (값 = 기대) · 허용 꼴 ③ 밖 줄 · 보고 쌍 표 ↔ 덱 기대 · C3 전제 · q7b 사유 · `--q7b-ref` (같음 / JSON 바뀜 / ucx 1 · 2 번만 다름 + 시각) / 화면 sha256 · md5 다름 · 한 글자 변조 · `..` · 링크 · 하위 폴더 · 비어 있지 않은 풀 폴더 · 금지 문자열 · **SHA256SUMS 까지 맞춘 본문 섞인 줄** = 전부 거부 |

시험 한계: 진짜 SLURM · Lustre · conda 가 없어 sinfo 는 가짜 · 파일은 일반 디스크다. ibb 의 bash 4.4.20 · gawk 4.2.1 · coreutils 8.30 에서는 안 돌렸다 — 쓴 문법은 bash 4.4 · gawk 4.x 에 있는 것만 (`mapfile` · 배열 자르기 · 프로세스 치환 · `$'\n'` · awk 구간 반복 `{n}` 안 씀) [문법 기준 · 실행 미확인]. bash 4.4 는 붙여넣은 here-document 를 `$TMPDIR` / `/tmp` 임시 파일로 잠깐 만든다 (11-12 블록과 같음 · 셸의 몫). 노드 이름이 로그인 노드와 다른 도메인을 쓰면 그 도메인은 가림 목록에 없다 (첫 낱말 24 자 안에서만 나올 수 있는 자리 · 남은 토큰 검사는 못 셈) · IPv6 꼴은 가리지 않는다 (11-12 와 같음).

## 4. 1저자가 할 일 · 본 세션이 읽는 법

1. ibb **로그인 셸** (SLURM 잡 안 아님 · bash) 에 `query_block_b.txt` 를 통째로 붙인다 (첫 줄 md5 `3c0a612028d16692625c264224a573fc`). 끝 화면에서 `가림 확인 … 0 곳` 과 `가져올 파일 …` · `sha256 <64 자>` 를 본다 — ⚠ 줄이 있으면 넘기지 않는다.
2. WSL (`<IBB>` = 1저자의 ibb 접속 — 포트 · 계정 · 주소): `N=<끝 화면의 폴더 이름 mixer_e0_queryb_…>; scp <IBB>:"~/$N/$N.tgz" . && sha256sum "$N.tgz"` → 화면 값과 같은지 본다 → tgz 하나 + 화면 sha256 을 세션에 올린다.
3. 본 세션: tgz 는 scratch 의 새 폴더에 · 풀 곳은 다른 빈 새 폴더 · 금지 목록 (계정 · 주소 · 포트 · 알면 노드 이름) 파일은 따로 →
   `python3 -I <이 폴더>/read_query_bundle_b.py <tgz> <빈 새 폴더> --expect-md5 3c0a612028d16692625c264224a573fc --expect-sha256 <화면 값> --json <새 요약.json> --forbid-file <금지 목록>`
   (나중에 발사 직전 · T9 직후 `MIX_Q=q7b` 묶음은 `--q7b-ref <이번 요약.json>` 을 붙여 꾸러미 · 파일마다 대조 — 다르면 바뀐 번호 · 옛 / 새 sha256 · 시각을 낸다 · W9 의 ✗ / △ 는 그 시각으로 세션이 정한다).
4. 반입 (하게 되면): 가린 out/ 만 · 새 증거 폴더 [제안] · README 에 묶음 sha256 · 스크립트 md5 · 판독기 rc · 금지 문자열 0 (11-10 · 11-12 와 같은 규칙).

## 5. 한정

- 관측이다 — 자격 수행 · 봉인 · 운영 승인 · 발사 GO 가 아니다. `UNKNOWN` · `ABSENT` · `FAIL` 은 0 · 정상이 아니다.
- q9b 의 판독기 "허용 꼴 ③ 밖" 은 첫 낱말 · 차례 · 표 안 자리 · 앞 공백 수준이다 — step = setup + 1 · 넣은 수 · mass · 다음 행 Atoms 는 이 조회 밖이다 (숫자를 안 옮기므로). 덱 기대 표 (E0 [1] · dev-bo / dev-u [1, 3]) 는 리포 덱 사본 (`docs/data/mixer_highbo_dev_decks_20260930_v26` · `…_20261002_bo` · `…_20261005_u` 의 `in.mixer`) 에서 읽은 것이다.
- q2b 는 DEV (기본 `%g` 덤프) 세 장이다 — pilot (전 정밀도) 의 쓰기 꼴은 같은 쓰기 코드 [추정] 로만 이어진다 (등록 7-3 C3 · 13-1).
- q7b 는 설치된 파일 목록의 해시다 — 실제로 불러 쓴 부품 · 두 대조 사이의 변경은 말하지 않는다 (등록 15-1 L11).

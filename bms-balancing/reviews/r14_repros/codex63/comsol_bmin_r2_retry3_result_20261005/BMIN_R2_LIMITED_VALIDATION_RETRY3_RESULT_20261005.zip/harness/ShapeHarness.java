import java.util.Arrays;
public class ShapeHarness {
    static double[] TIMES=null;
    static void checkShape(String tag,double[][] values,int count) {
        if(values==null||values.length!=count||count==0||values[0]==null||values[0].length==0)throw new IllegalStateException("SHAPE:"+tag);
        int n=values[0].length;
        for(double[] row:values){if(row==null||row.length!=n)throw new IllegalStateException("RAGGED:"+tag);for(double v:row)if(!Double.isFinite(v))throw new IllegalStateException("NONFINITE:"+tag);}
        if(values[0][0]!=0.0)throw new IllegalStateException("TIME_ORIGIN:"+tag);
        for(int i=0;i<n;i++)if(values[0][i]<0||values[0][i]>150||(i>0&&values[0][i]<=values[0][i-1]))throw new IllegalStateException("TIME_ORDER:"+tag);
        if(TIMES==null)TIMES=values[0].clone();else if(!Arrays.equals(values[0],TIMES))throw new IllegalStateException("EXACT_TIMES:"+tag);
    }
    public static void main(String[] args) {
        TIMES=null; checkShape("JV01-01",new double[][]{{0,75,150}},1);
        System.out.println("JV01-01|PASS|accepted");
        TIMES=null;
        try { checkShape("JV01-02",new double[][]{{0,75,150.0001}},1); throw new AssertionError("EXPECTED_REJECTION"); }
        catch (IllegalStateException e) { if (!e.getMessage().equals("TIME_ORDER:JV01-02")) throw e; System.out.println("JV01-02|PASS|TIME_ORDER"); }
    }
}

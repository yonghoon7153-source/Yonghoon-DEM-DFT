$ErrorActionPreference='Stop'
$r=$PSScriptRoot
$clock=[Diagnostics.Stopwatch]::StartNew()
$seen=@();$failure=$null
foreach($name in @('GDecision','GNativeAxis','GFields')) { . ([scriptblock]::Create([IO.File]::ReadAllText((Join-Path $r ('extracted/'+$name+'.ps1.txt'))))) }
function Read-Fixture([string]$Name) { ConvertFrom-Json -InputObject ([IO.File]::ReadAllText((Join-Path $r ('results/'+$Name+'_1.json')))) }
function Require-Fixture($Ok,[string]$Why) { if(-not $Ok){throw $Why} }
$cases=Get-Content -Raw -LiteralPath (Join-Path $r 'INPUT_CASE_MAP.json') | ConvertFrom-Json
$cases=@($cases|Where-Object {$_.id -like 'PS*'})
try {
 Require-Fixture ($PSVersionTable.PSEdition -ceq 'Desktop' -and $PSVersionTable.PSVersion.Major -eq 5) 'ENGINE'
 foreach($case in $cases) {
  Require-Fixture ($clock.Elapsed.TotalSeconds -le 240) 'PS_BUDGET'
  $id=$case.id;$index=[int]$case.input_index;$x=Read-Fixture 'PY01-01'
  $native=@{returned=$true;invocation_succeeded=$true;native_rc=[int]0;new_error=$false;exception=$null}
  $analysis=@{returned=$true;invocation_succeeded=$true;native_rc=[int]0;new_error=$false;exception=$null;elapsed_seconds=1.0}
  $expected=@{run_id=$x.run_id;manifest_sha256=$x.code_manifest_sha256};$overall=100.0;$want='INCOMPLETE';$cause=$null;$nativeWant='NORMAL_150S_COMPLETED'
  switch($id) {
   'PS01-01' {$want='AWAITING_BMIN640_150S_EXTERNAL_ACCEPTANCE'}
   'PS01-02' {$x=Read-Fixture 'PY01-03';$want='AWAITING_BMIN640_150S_EXTERNAL_ACCEPTANCE'}
   'PS01-03' {$x=Read-Fixture 'PY01-03';$x.mesh_comparison='WITHIN_LIMITS_THIS_WINDOW'}
   'PS01-04' {$x=Read-Fixture 'PY01-02';$want='AWAITING_BMIN640_150S_EXTERNAL_ACCEPTANCE'}
   'PS01-05' {$analysis.elapsed_seconds=901.0;$x.analysis_elapsed_seconds=901.0}
   'PS01-06' {$overall=10501.0}
   'PS01-07' {$x=Read-Fixture 'PY02-04';$analysis.native_rc=[int]1;$analysis.invocation_succeeded=$false;$nativeWant='PROTECTIVE_STOP';if($index -eq 1){$want='PROTECTED_STOP_150S_INCOMPLETE'}else{$x.mesh_comparison='WITHIN_LIMITS_THIS_WINDOW'}}
   'PS01-08' {if($index -eq 1){$analysis.native_rc=[int]1}else{$native.native_rc=[int]1;$nativeWant='NOT_ESTABLISHED';$cause='NATIVE_CHILD_RC'}}
   'PS01-09' {$x=Read-Fixture 'PY03-01';$analysis.native_rc=[int]1;$analysis.invocation_succeeded=$false}
   'PS01-10' {$x=Read-Fixture 'PY07-02';$analysis.native_rc=[int]1;$analysis.invocation_succeeded=$false;$analysis.elapsed_seconds=901.0}
   'PS01-11' {$want='AWAITING_BMIN640_150S_EXTERNAL_ACCEPTANCE'}
   'PS01-12' {$native.native_rc=[int]1;$nativeWant='NOT_ESTABLISHED';$cause='NATIVE_CHILD_RC'}
   'PS01-13' {if($index -eq 1){$x=$null}else{$x.PSObject.Properties.Remove('termination');$x.PSObject.Properties.Remove('native_termination')};$nativeWant='NOT_ESTABLISHED';$cause='TERMINATION_EVIDENCE_MISSING'}
   'PS01-14' {$x=Read-Fixture 'PY02-04';$x.native_completion='NORMAL_150S_COMPLETED';$nativeWant='NOT_ESTABLISHED';$cause='CONSUMER_NATIVE_LABEL_MISMATCH'}
   'PS01-15' {$x=Read-Fixture 'PY02-04';$x.errors=@(@{axis='configuration';error='FIXTURE_CONFIGURATION'});$x.limited_result='INCOMPLETE';$analysis.native_rc=[int]1;$analysis.invocation_succeeded=$false;$nativeWant='PROTECTIVE_STOP'}
   'PS01-16' {$x.numeric.windows.primary.voltage_V.maximum_absolute='0.001000000000000000000000000001';$x.mesh_comparison='EXCEEDS_LIMITS'}
   'PS01-17' {if($index -eq 1){$x.mesh_readback.PSObject.Properties.Remove('transient_dof')}else{$x.mesh_readback.transient_dof.solved=[int]0}}
   'PS01-18' {switch($index){1{$native=$null}2{$native.returned=$false}3{$native.exception='fixture'}4{$native.new_error=$true}5{$native.native_rc='0'}};$nativeWant='NOT_ESTABLISHED';$cause='NATIVE_CHILD_RETURN_MISSING_OR_ERROR'}
   'PS01-19' {if($index -eq 1){$x.run_id='wrong_fixture'}else{$x.code_manifest_sha256=('0'*64)};$nativeWant='NOT_ESTABLISHED';$cause='RESULT_IDENTITY'}
   'PS01-20' {switch($index){1{$x.termination.active_guards=@('electrolyte_guard')}2{$x.termination.final_time_s='149.9'}3{$x.native_termination.step_count=[int]2}4{$x=Read-Fixture 'PY02-04';$x.native_termination.stop_reason='wrong fixture'}};$nativeWant='NOT_ESTABLISHED';$cause='TERMINATION_EVIDENCE_INVALID'}
   'PS01-21' {$x=$null;$nativeWant='NOT_ESTABLISHED';$cause='NATIVE_AXIS_NOT_EVALUATED'}
   default {throw 'UNMAPPED_CASE'}
  }
  if($id -eq 'PS01-21'){$axis=$null;$decision='INCOMPLETE'}else{$axis=GNativeAxis $native $x $expected;$decision=GDecision $native $analysis $x $expected $overall}
  Require-Fixture ($decision -ceq $want) ('DECISION_EXPECTED_'+$want+'_OBSERVED_'+$decision)
  if($id -eq 'PS01-11'){$decision='INCOMPLETE'}
  $fields=GFields $decision $axis $x
  Require-Fixture ($fields.native_completion -ceq $nativeWant) 'NATIVE_AXIS_MISMATCH'
  if($cause){Require-Fixture ($fields.native_completion_cause -ceq $cause) ('CAUSE_'+$cause)}
  if($decision -ceq 'AWAITING_BMIN640_150S_EXTERNAL_ACCEPTANCE'){
   Require-Fixture ($fields.evidence_validity -ceq 'VALID' -and $fields.mesh_comparison -ceq $x.mesh_comparison) 'VALID_FIELDS'
  }else{Require-Fixture ($fields.evidence_validity -ceq 'INVALID' -and $fields.mesh_comparison -ceq 'INCONCLUSIVE') 'INVALID_FIELDS'}
  if($id -eq 'PS01-21'){Require-Fixture ($null -eq $fields.consumer_native_completion_unverified) 'NULL_CONSUMER'}
  $row=@{id=$id;input_index=$index;status='PASS';decision=$decision;fields=$fields;expected_reason=$case.expected;reached_functions=@('GDecision','GNativeAxis','GFields');elapsed_s=$clock.Elapsed.TotalSeconds}
  if($id -eq 'PS01-21'){$row.reached_functions=@('GFields')}
  $seen+=,$row;ConvertTo-Json -InputObject $row -Depth 12 -Compress
 }
}catch{$failure=@{id=$id;input_index=$index;error=$_.ToString();script_stack=$_.ScriptStackTrace};ConvertTo-Json -InputObject $failure -Depth 8 -Compress}
$record=@{status=$(if($failure){'FAIL'}else{'PASS'});results=$seen;first_failure=$failure;elapsed_s=$clock.Elapsed.TotalSeconds;limit_s=240;expected_inputs=33}
[IO.File]::WriteAllText((Join-Path $r 'results/PS_RESULTS.json'),(ConvertTo-Json -InputObject $record -Depth 30),[Text.UTF8Encoding]::new($false))
if($failure){exit 1}else{exit 0}

# PRE8-01 한정 독립 재확인

대상 핀: `ec484c2719d6a444214ddc9c48fe683a7735688b`.

판정: 실행한 PRE8-01 일반 파일 경계에서는 원 반례가 닫혔다. 새 결함은 발견하지 않았다. 실제 dangling symlink 경로는 Windows 권한 오류로 미실행이므로 그 경로까지 독립 동적 수용했다고 확대하지 않는다.

## 방법과 관측

- `REQUEST.md`와 원 외부 `external/observe_binding_review/probe_observe_binding.py`를 읽고 기존 3입자 E0 반례를 재현했다. `_load` 실제 반환 시점에 없는 `n_expected`에 `999`를 쓰면 현재는 `TECH: optional input presence changed`, contact/mixing/counts/reference_counts 모두 null이다. 바로 같은 최종 파일을 다시 분석하면 `TECH: n_expected differs from planned count`이다.
- 독립 탐침은 **71개 실행, 71개 예상대로 통과**했다(OK 12, TECH 59). 실제 symlink 생성 자체가 WinError 1314로 거부되어 계획한 symlink 조합 21개는 **미실행**으로 기록했다. 성공 수에 더하지 않았다.
- 3입자 E0와 48입자 회전 run/E0 reference를 사용했다. 48입자는 각 설정 격자에서 24입자씩 두 셀을 만들고 초기 AM 2개를 한 셀에 두며, 이후/reference에서는 한 개씩 분산했다. 세 격자 모두 실제 계산에서 S0=0.0017361111111111104, SR=0, M_mean=1을 반환하여 계산 전체를 거치는 작은 양성 경로를 확인했다.
- run과 reference 각각 처음 없던 파일의 정상값/잘못된값 출현을 `_load` 뒤, 실제 contact 함수 반환, 첫 실제 cell_stats 반환 시점에 주입했다. 전부 TECH 및 값 제거였다. 정상값 출현도 거부하므로 단순한 숫자 재검사에 의존하지 않는다.
- 처음 있던 정상 파일의 삭제, 다른 숫자로 재작성, 같은 숫자에 공백 추가, 다른 bytes의 파일로 교체를 같은 세 시점에서 시험했다. 모두 TECH 및 값 제거였다. 초기 부재/정상 파일이 그대로인 대조는 OK, 처음부터 999인 대조는 TECH였다.
- 기존 정상 파일을 동일 bytes의 다른 regular file로 교체하면 OK였다. 원 외부 최소수정 요구는 기존 파일의 SHA 검증이므로 이는 내용 결속의 명시적 경계이며 새 발견으로 분류하지 않았다. 무관한 파일 추가도 OK였다. 확인점 사이에 생성하고 삭제하여 원래 상태로 되돌리는 모든 순간을 추적한다는 주장은 하지 않는다.

## 실제 코드와 남는 경계

`scripts/mixer_precal_observe.py`의 340–350행은 `_load` 진입 시 run/reference `n_expected`의 존재·부재를 별도 기록한다. 165–171행의 `_present`는 `lstat`를 사용하므로 dangling symlink를 존재로 취급하고 ENOENT만 부재로 처리한다. 181–186행의 `_verify_sources`는 존재 상태와 기존 입력 SHA를 다시 비교한다. `analyse_run` 450, 452, 465행에서 분석 전·후 및 예외 뒤 재검증하며, 468–469행에서 TECH/UNDEFINED 값과 counts를 제거한다. 실제 symlink는 이 정적 확인만 가능했다.

별도 최소수정 요구는 없다. 실행 근거의 범위는 해당 핀에서의 PRE8-01 합성 파일 결속이다. 준비기 `validate_case`만 제출 fixture처럼 mock 처리했다. `_load`, hash/read/parser, contact, cell_stats, 계산 결과, 출처 확인은 mock하지 않았다. 함수 반환 프로파일러는 파일 이벤트만 주입하고 실제 반환값을 바꾸지 않았다. 48입자 합성 양성은 실제 100000입자, DEM, 물리·통계 자격, 전체 게이트, 실행·등록·배포 또는 원장 종결 근거가 아니다.

## 재실행·증거

`probe_pre8_absence.py`를 Python 3.12.14, NumPy 2.5.3, SciPy 1.16.3에서 `-I -B -X utf8`로 실행했다. `sys.path`는 scratch 복사본을 명시하고 `tempfile.tempdir`도 이 작업의 scratch로 고정했다. 받은 10개 소스의 SHA-256은 실행 전후 일치했다. 세부 case, 실행/미실행 수, 주입 함수/행, 값 제거, optional 존재 스냅샷, 소스 SHA는 `probe_results.json`에 있다. 입력 ZIP 추출본은 수정하지 않았다.

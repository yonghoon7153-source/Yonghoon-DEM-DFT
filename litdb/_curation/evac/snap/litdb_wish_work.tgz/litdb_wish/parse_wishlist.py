#!/usr/bin/env python3
"""wishlist.md 의 항목 줄을 쪼갠다 (읽기만).

python3 -I parse_wishlist.py <wishlist.md> <out.tsv>
항목 = '- [n]' 또는 '- [대피' 로 시작하는 줄 (wishlist 3 행의 꼴).
'(참고 · 후보로 세지 않음)' · '(n 밖 …)' 줄은 항목이 아니라 따로 센다.
칸: idx · line · batch · bib · why · check
"""
import re
import sys

src, out = sys.argv[1:3]
rows = []
others = []
batch = "(머리)"
for ln, line in enumerate(open(src, encoding="utf-8"), 1):
    line = line.rstrip("\n")
    m = re.match(r"^### (batch_\d+)", line)
    if m:
        batch = m.group(1)
        continue
    if line.startswith("## 대피 세션"):
        batch = "대피 머리"
        continue
    if line.startswith("- [n]") or line.startswith("- [대피"):
        body = line[2:]
        if body.startswith("[n]"):
            body = body[3:].strip()
            parts = body.split(" | ")
            if len(parts) >= 3:
                bib = parts[0]
                check = parts[-1]
                why = " | ".join(parts[1:-1])
            elif len(parts) == 2:
                bib, why, check = parts[0], parts[1], ""
            else:
                bib, why, check = body, "", ""
        else:  # [대피 · 11-12] … — 왜 — 카드 — 확인
            body = re.sub(r"^\[대피[^\]]*\]\s*", "", body)
            parts = body.split(" — ")
            bib = parts[0]
            why = parts[1] if len(parts) > 1 else ""
            check = " — ".join(parts[2:])
        rows.append((len(rows) + 1, ln, batch, bib.strip(), why.strip(), check.strip()))
    elif line.startswith("- (") or line.startswith("("):
        others.append((ln, batch, line[:120]))

with open(out, "w", encoding="utf-8") as f:
    f.write("idx\tline\tbatch\tbib\twhy\tcheck\n")
    for r in rows:
        f.write("\t".join(str(x).replace("\t", " ") for x in r) + "\n")
print(f"항목 {len(rows)} 줄 · 배치 {len(set(r[2] for r in rows))} · 항목 아닌 괄호 줄 {len(others)}")
for o in others:
    print("  비항목", o[0], o[1], o[2][:70])

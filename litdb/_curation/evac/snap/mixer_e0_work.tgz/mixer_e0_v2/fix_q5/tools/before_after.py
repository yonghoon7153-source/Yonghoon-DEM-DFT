"""Evidence: every counterexample of ActualLogRejections judged by the OLD and the NEW
log contract.  Old = _need/_log_contract text from the base observer (git blob, AST extract,
in memory), new = fixed observer.  Writes JSON + markdown; touches nothing else.
Usage: python3 -B before_after.py <tree> <out_dir>"""
import ast, hashlib, importlib.util, json, math, re, subprocess, sys
from pathlib import Path
tree, out = Path(sys.argv[1]), Path(sys.argv[2])
spec = importlib.util.spec_from_file_location('T', tree/'scripts'/'test_mixer_precal_observe.py')
T = importlib.util.module_from_spec(spec); spec.loader.exec_module(T)
O = T.O
old_src = subprocess.run(['git', '-C', str(tree), 'show', 'base:scripts/mixer_precal_observe.py'], capture_output=True, check=True).stdout
nodes = [n for n in ast.parse(old_src).body if isinstance(n, ast.FunctionDef) and n.name in ('_need', '_log_contract')]
class OldTech(ValueError): pass
ns = {'re': re, 'math': math, 'Tech': OldTech}
exec(compile(ast.Module(body=nodes, type_ignores=[]), 'base:scripts/mixer_precal_observe.py', 'exec'), ns)
old_contract = ns['_log_contract']
cases = []
class Recorder(T.ActualLogRejections):
    def rejects(self, text, reason, facts='deck'):
        cases.append((self._case, text, reason, self.facts if facts == 'deck' else facts))
    def subTest(self, msg=None, **kw):
        self._case = '%s[%s]' % (self._method, msg)
        import contextlib; return contextlib.nullcontext()
Recorder.setUpClass()
for method in ('test_true_error_lines_stay_tech', 'test_truncated_logs_stay_tech', 'test_corrupted_rows_stay_tech',
               'test_lost_particles_stay_tech', 'test_insertion_report_contract', 'test_table_structure_stays_tech'):
    r = Recorder(method); r._method = method
    try: getattr(r, method)()
    except AssertionError: pass   # direct assertRaises (utf8_cut) is outside the recorder
def judge(fn, raw, *args):
    try:
        fn(raw, *args); return 'MATCH', ''
    except (ValueError,) as exc:
        return 'TECH', str(exc)
rows = []
base = Recorder.base.encode('utf-8')
rows.append(dict(case='(normal) planned PRECAL_E0 actual-form log', expected='MATCH',
                 old=judge(old_contract, base, Recorder.RUNS), new=judge(O._log_contract, base, Recorder.RUNS, Recorder.facts)))
for name, text, reason, facts in cases:
    raw = text if isinstance(text, bytes) else text.encode('utf-8')
    rows.append(dict(case=name, expected='TECH: '+reason, old=judge(old_contract, raw, Recorder.RUNS),
                     new=judge(O._log_contract, raw, Recorder.RUNS, facts)))
bad = [r for r in rows[1:] if r['old'][0] != 'TECH' or r['new'][0] != 'TECH' or r['expected'][6:] not in r['new'][1]]
summary = dict(old_source_sha256=hashlib.sha256(old_src).hexdigest(),
               new_source_sha256=hashlib.sha256((tree/'scripts'/'mixer_precal_observe.py').read_bytes()).hexdigest(),
               counterexamples=len(rows)-1, old_tech=sum(r['old'][0] == 'TECH' for r in rows[1:]),
               new_tech_expected_reason=sum(r['new'][0] == 'TECH' and r['expected'][6:] in r['new'][1] for r in rows[1:]),
               normal_log=dict(old=rows[0]['old'], new=rows[0]['new']), inconsistent=[r['case'] for r in bad])
json.dump(dict(summary=summary, rows=rows), open(out/'before_after_counterexamples.json', 'w'), indent=1, ensure_ascii=False)
md = ['| case | expected | old observer (df22dcf0…) | new observer |', '|---|---|---|---|']
for r in rows:
    md.append('| %s | %s | %s | %s |' % (r['case'], r['expected'], ' '.join(r['old']).strip(), ' '.join(r['new']).strip()))
(out/'before_after_counterexamples.md').write_text('\n'.join(md)+'\n', encoding='utf-8')
print(json.dumps(summary, indent=1, ensure_ascii=False))

# 질문 g — 배치별 근거 묶음 (원문 줄 그대로 · 파일 43 개)

### [batch_01] g. 2D 결과를 3D 로 옮길 때의 경고 · 증거

- [g] bardenhagen2000_mpm_granular_multibody_frictional_contact | 논문 계산 전부 2D ("carried out in two dimensions"). 카드: 전단 띠 폭 (평균 지름 7 개) · 힘 사슬 모양은 "재료 · 2D · 전단 (압밀 아님) 이라 전이 불가". E · ν 유도는 "3D 등방 관계식 가정 — 2D 계산의 평면 가정은 미기재" | §11-1 (L369) · §8-2 (L313) · §3-2 (L102) | stated / derived(ours) | 3D 대조 자료 없음
- [g] bardenhagen2000 ↔ bardenhagen2001 (두 카드) | 같은 지름 4 셀에서: 2D 원판 (2000) 은 미끄럼 · 구름 체제를 재현하되 구름 경우 변위비 ≈ 0.17 (t = 0.3) – 0.23 (t = 0.4) · 3D 구 (2001) 는 "fails to roll because of a flat spot" (x = 0). 2001 카드가 "이 해상도의 3D 판 (R/2) 에서 구가 아예 구르지 못했다" 고 잇는다 | 2000 §3-1 (L92–93) · 2001 §4-1 (L106–107) · §7 Fig 1 행 (L268) | 2000 = figure-read ≈ · 2001 = stated | 두 계산의 재료 · μ · θ · 셀당 물질점 수가 달라 같은 조건 비교는 아님
- [g] bardenhagen2001_mpm_improved_contact_granular_stress_waves | 광탄성 응력파 시뮬의 차원 (2D / 3D) 은 [미확인] — 실험은 평면응력 원판 | §4-3 (L139) | [미확인] | —
- [g] klar2016_dp_sand_animation | 저자 한계: DP 원뿔은 2D 에서만 Coulomb 마찰과 정확히 등가 · 3D 에서는 탄성 영역이 Mohr-Coulomb 이고 DP 는 근사. 카드의 우리 쪽 기록: J2 항복 세기 2D 0.15 → 3D 0.30 GPa | §4.6 (L154–155) · §7 표 (L199 · L205) · §10 (L300–301) | 저자 명시 / 표지 없음 (우리 쪽 기록) | 모래 · 우리 값의 근거는 이 카드에 없음
- [g] choi2024 · devaucorbeil2020 · lim2025 · nam2026 | 2D → 3D 서술 없음 | — | — | —


### [batch_02] g. 2D 결과를 3D 로 옮길 때의 경고 · 증거

2D ↔ 3D 를 같은 모델로 견준 **증거는 없음** — 경고만 있음.

- [g] nezamabadi2022_mpm_cd_plastic_particle_compaction | 경고: 계산 전부 2D 원판 · Φ = 2D 면적 분율 · 재밍 Φc ≈ 0.8 도 2D 값 ⇒ "LPSCl + NCM811 3D 기공률로 절대 전이 0 건"; 전이 금지 = Φ 값 · Φc 0.8 · 응력 MPa 절대값 · 맞춤 매개변수 (f_E 1.2 · f_G 0.2 · α 2.5) · "σ = σ_y 에서 Φ 0.84" 를 3D 기공률로 옮기는 것 | 머리 경고 (L6–9) · §7.4 (L381–382) | 표지 없음 (카드의 경고) | 저자의 2D 문장은 "the disks do not represent real particle shapes" 뿐 (L224)
- [g] nezamabadi2022_mpm_cd_plastic_particle_compaction | 2D 에서 입자 체적계수 K = λ + µ (34.5 MPa) — 3D 식 λ + 2µ/3 (33.3 MPa) 과 다름; "이 논문은 2D … 우리 3D 에서 연화가 사라진다는 증거는 아니다" | §3.2 (L117) · §4.6 (L200) · §8-① (L391) | stated (K = λ + µ) / derived(ours) (수치) | —
- [g] nguyen2017_mpm_bpm_deformable_particle_compaction | 2D Hertz (원판) 는 힘이 변형에 선형 (식 2) — 3D 구의 지수 3/2 와 다름: "3D 구 (지수 3/2) 로 직접 옮기지 않는다"; Z 절대값 (2D) · Φ 값 전이 금지 · "2D ↔ 3D 숫자 비교 금지 · 지수만" | §4.3 (L155) · 식 크롭 (L248–249) · §7 (L271 · L277) | stated (식 2) + 카드 경고 | —
- [g] alizadeh2018_dem_adhesion_calibration_segregation_heap | (2D 측정 ↔ 3D 침대 — 2D 계산은 아님) 16 mm 상자에서 벽 층 CoV 가 가운데의 2–3 배 (비코팅 0.94 · 0.77 ↔ 0.30) · 앞면 S_n 2.88 ↔ 전체 더미 1.57 — "앞면 영상은 침대 전체를 대표하지 못한다 (저자)" | §0 ⑥ (L32) · §3-4 (L113–116) · §8-5 (L238) · Fig 12 · 13 | [판독] · [인쇄] p.8 | 세제 과립 · 분리 지표 (기공 아님) · DEM 은 조건마다 1 런 [추정]
- [g] 우리 쪽 기록 (카드 안) | 우리 맞춤값이 2D 0.15 → 3D 0.30 (σ_y) 으로 달랐다는 언급 | stomakhin2013 §7 (L181) · §10 (L228–229) | 표지 없음 | 논문 값 아님
- pycompact2025 · alabdali2023: 3D 계산만 — 2D → 3D 서술 없음.


### [batch_03] g. 2D 결과를 3D 로 옮길 때의 경고나 증거

- [g] cardenasbarrantes2020_rigid_deformable_mixture_compaction_nscd | 카드 머리 "세 겹의 전이 금지" ① 2D (원판 · 평면변형률 · jammed φ0 ≈ 0.81) ≠ 3D 구 · "φ0 ≈ 0.81 · b ≈ 0.14 · ξ ≈ 5.1 은 차원에 묶인 수" · "2D 원판의 jammed 충전률은 3D 구보다 훨씬 높다 — 어떤 φ 값도 옮기지 않는다" | 머리 (L6–10) · §8-2 (L434) · §12-A (L571) | 표지 없음 (카드 판단) | 3D 근거 자료는 카드에 없음
- [g] cardenasbarrantes2020_rigid_deformable_mixture_compaction_nscd | 3D 대응 시작값: 구 / 외접 정육면체 = π/6 ≈ 0.524 (2D 의 π/4 대응) · "2D 값 0.5 를 기대값으로 쓰지 않는다" (Z–φ 지수) · 3D 판 = Soft Matter 18, 312 (2022) 는 litdb 미보유 | §3-4 (L163) · §10-2 (L526 · L537–539) | derived(ours) (π/6) | 3D 판 미독
- [g] cardenasbarrantes2021_soft_rigid_mix_compaction_proceedings | 저자 스스로 3D 를 다음 과제로: "The natural path of this work is the analysis of more real systems, such as 3D systems, composite assemblies of particles with more realistic geometries, all under different compaction conditions." · 카드: 2D 값 (φ0 ≈ 0.81 · Z0 ≈ 3.5) 은 3D 로 옮기지 않는다 | §11 (L215–216 · 논문 p. 4) · §8 (L178) | stated (원문 인용) | —
- [g] cardenasbarrantes2022_soft_hard_grains_compaction_experiment_dic | 준 2D — 높이 15 mm 원기둥의 바닥면만 봄 (높이 방향 변형 · 기울어짐 [미확인]) · "φ · Z · ⟨l⟩ 의 값은 3D 로 옮기지 않는다" | §4-5 (L190) · §8-2 (L307) | 표지 없음 · [미확인] | 2D 실험 (k = 4.9) 과 2D 시뮬 (ξ = 5.1) 의 일치는 2D 끼리의 증거
- [g] bouvard2000_hard_soft_powder_densification | Delie & Bouvard [14] 변형 계산은 2D 정사각 배열 (circular 연입자 + 임의형상 rigid inclusion) — "2D 주기배열, 진짜 morphology 아님" · 패킹 모사 · 실험은 3D 라 percolation 임계 수치 (0.32 등) 는 "직접 참조 가능" | §4 (L50) · §7 (L99) | 표지 없음 (카드 판단) | 금속 + 세라믹
- [g] arzt1982_particle_coordination_densification_spheres | 3D 모델 (Voronoi 다면체) — "기하 비율 (TKD 1.099 등) 은 차원 오류 없이 대조 가능" · 2D 는 Fig. 2 모식뿐 | §7 (L267) · §5 (L202) | 표지 없음 | 단분산
- [g] banerjee2019_tunneling_tlm_parallel_nanoscale_contacts | 2D 전송선 (두께 · 폭 방향 변화 없음) — 저자 한계: 가로 방향 무시 · 모서리 근처 전류 쏠림 · 가장자리 장은 장 해법 필요 | §4 (L80 · L83) | stated (저자 한계) | 전기 접합 모형 (가압과 무관)


### [batch_04] g. 2D 결과를 3D 로 옮길 때의 경고나 증거

- [g] electromechanical_contact_model_particulate_systems | 강철 입자상의 저항 vs 힘 (3 / 5 / 10 층): 3D 계산은 Bourbatache 2012 실험과 잘 맞고 · 2D 는 층수가 늘수록 발산 (2D 가 셋째 차원의 입자 상호작용 = out-of-plane 접촉 경로를 못 잡음) | §5 Fig 12 행 (L120) · "왜 2D 가 틀리나" (L166–167) · §10 (L340) | 그림 = digitized 추세값 (L337) | 금속 입자상 · 전기 저항 (역학 · 기공 아님) · 카드: "경향 (3D 필수) 만 · 절대값 직역 금지"
- [g] coetzee2017_dem_calibration_review | Feng [125] 스케일 불변 조건: F_n = k r^a δ^b 에서 a + b = n_d − 1 (2D n_d = 2 · 3D n_d = 3) ⇒ 선형 접촉 법칙은 2D 에서만 스케일 불변 · Hertz (a = 1/2 · b = 3/2) 는 3D 불변 (Obermayr [35] · r 3 → 30 mm 삼축으로 확인) | 카드 §6 의 "§3.2 Particle size" 요약 (L553–562) | 리뷰 stated (소환) | 입자 크기 스케일업 문맥 · 같은 절에 리뷰 본문의 모순 1 건 (카드 문제 B-1)
- [g] coetzee2017_dem_calibration_review | 2D 값의 지위: Li [189] 2D 디스크로 보정한 마찰 0.92–1.04 = "relatively high" (형상 결손 보상) · Franco [196] (2D) 강성 ↑ → 벌크 마찰 ↑. 카드 주의: [25,26,189,190] 등 다수가 2D 인데 리뷰가 매번 밝히지 않음 · "구속 단축압축은 마찰에 둔감" 의 근거 [25]/[205] 도 "파쇄암·옥수수, 저응력, 2D/클럼프" 결과 | §5-Q2(c) (L249–252) · 카드 §6 의 "§5.4" 요약 (L629) · §13 (L975) · §10.3-W1 (L787–789) | 리뷰 stated (소환) · 주의 = 카드 판정 | 2D ↔ 3D 를 수치로 견준 것은 없음
- [g] giannis2021_stress_based_multicontact_dem · dmt1975_adhesion_contact_deformation · deng2021_mechanical_surface_energy_tester_bond_number | 이 배치에 없음 | — | — | —


### [batch_05] g. 2D 결과를 3D 로 옮길 때의 경고나 증거

- [g] gonzalez2012_nonlocal_contact_confined_granular | Hertz 대비 불일치 Δ 는 격자의 차원 배치에 약하게만 의존 (1D ≈ 2D ≈ 3D): 식 17 (1D) 과 식 18 (2D · 3D) 의 앞 두 항이 같고 2D · 3D 는 O(ε^(5/4)) 항만 추가; 1 조 / 2 조 측방 구속 FEM (Fig 8) 과 정합 | §6.1 (L362–374) · Fig 10 (L451) | stated | 주기 격자의 탄성 구 (기공 · 소성 아님)
- [g] jarray2019_cohesion_driven_mixing_segregation_drum | 경고: 측정이 드럼 앞면 (PMMA 창) 한 면의 2D 영상 — "벌크 3D 혼합이 아니다"; 2 mm 입자에서 L/d = 5.5 (창에 닿은 한 층만 보임); 저자 기준 = Jain 2005 의 L > 6.4 r | 한정어 ③ (L36) · §3-1 (L67) · §4-4 (L185) · §10-2 (L301) | 카드 서술 · 기준 = [인쇄] p.8 | 믹싱 실험
- [g] jacksongreen2005_fem_elastoplastic_hemispherical_contact | 축대칭 2D 단접촉 FEM — 카드 판단: 단접촉이라 2D / 3D 절대 스케일 문제가 없음 (임계값 정규화로 흡수); 카드가 적은 우리 쪽 값: MPM σ_y = 0.15 (2D) · 0.30 (3D) | §7.1 표 (L160 · L155) | 표지 없음 (카드 판단 · 우리 쪽 기록) | 논문의 진술 아님
- 그 밖: 2D 결과를 3D 로 옮기는 증거 · 경고 없음 (he 는 3D DEM 만).


### [batch_06] g. 2D 결과를 3D 로 옮길 때의 경고나 증거

- [g] oh2026_bimodal_composite_cathode | 2D 단면 기공과 3D (He) 기공이 다르다: 끝점 2D 16.80 / 17.96 % vs He 12.78 / 11.58 % · 최적점 2D 7.55 vs He 8.83 % · dip 깊이 2D ~9–10 %p vs He ~3.5–4 %p | §4.1 (L203–215 · Table S1) | 표지 없음 | 2D = pore 수동 적색 마킹 → ImageJ 이진화 · He = 370 MPa 펠릿 (압력도 다름)
- [g] mesarovicfleck2000_dissimilar_elastoplastic_indentation | 다체 상호작용이 기하에 따라 갈린다: 3D B2 가 가장 현실적 · 라인–수축튜브 (case II) 는 과구속 (Fig 9) · 유한변형 영역은 a/R₀ 로도 기하별로 갈라져 일반 천이 기준이 없다 (Fig 4b) | §5 (L86) · L116–117 | stated | 단위셀 수준
- [g] kogutetsion2002_ep_sphere_rigid_flat · mesarovicfleck2000_dissimilar_elastoplastic_indentation | 축대칭 단접촉이라 "2D/3D 절대스케일 이슈 없음" 이라는 카드 서술 | KE §7.1 (L131) · MF §7.1 (L147) | 카드 판단 | 평면 2D 계산을 3D 로 옮기는 근거는 아님
- [g] mcgeary1961_bimodal_sphere_packing | 용기 / 구 지름비 벽 효과: D/d ≳ 10 에서 62.5 % 로 수렴 · D/d = 3 · 4 에서 역방향 dip | §5 Fig 2 (L75) | 표지 없음 | 3D 실험 · 2D → 3D 의 직접 증거가 아니라 상자 크기 경고
- [g] martinbouvard2003_dem_composite_cold_compaction · luding2008_cohesive_frictional_contact_models | 3D 계산 (4000 구 주기 RVE / N = 1728) — 2D 대조 없음 | MB L85 · Luding L267 | — | 2D → 3D 근거 없음


### [batch_07] g. 2D 결과를 3D 로 옮길 때의 경고나 증거

- [g] paulick2015_elastic_particle_properties_dem_review | [31] Antony 2005 — 2D vs 3D 단축 압축 (구 · 비구 · 실험 대조): "2D 는 벌크강성을 상당히 과소평가하고 특히 큰 변형에서 심함; 3D 는 실험과 잘 일치" | §6 의 §2.2 (L582–584) | 표지 없음 (카드의 리뷰 요약 · 원문 영어 문장은 카드에 없음) | 저응력 · 수치 없음 · 재료 카드에 없음
- [g] paulick2015_elastic_particle_properties_dem_review | 같은 관계를 2D 와 3D 에서 따로 본 예: 구속 벌크계수 ∝ k_n 을 PFC2D 오이도미터 [21] 가 보고 PFC3D 비구형 [30] 이 검증 · 2D 동일 재료의 등가 영률은 E* = E/(2(1−ν²)) [28,57] | §5-Q1 표 (L169–172) · §5-Q4 표 (L315) · §6 (L576–581) | stated | 옮김 규칙은 아님
- [g] paulick2015_elastic_particle_properties_dem_review | 우리 쪽 기록: "우리 MPM 2D σ_y 0.15 → 3D 0.30 필요와 같은 방향" | L584 | 표지 없음 | 논문 값 아님
- [g] 나머지 다섯 카드 | 없음 (Pasha · So · Roessler 는 3D DEM · Schreiner 는 부피 control volume · Sharma 는 실험) | — | — | —


### [batch_08] g. 2D 결과를 3D 로 옮길 때의 경고나 증거

**이 배치에 없음.** (`storakers1997` 카드가 차원을 "axisym 2D + 이체 (단접촉)" 로만 적고 "단접촉이라 절대스케일 이슈 없음" 이라 함 · L171 — 평면 2D 계산으로 옮길 수 있는지에 대한 말은 카드에 없음.)


### [batch_09] g. 2D 결과를 3D 로 옮길 때의 경고나 증거

직접 경고는 **이 배치에 없음**.

- [g] zunker2025_dem_large_deformation_compaction | 한 줄뿐: "So 2021 이 rel.density 0.98 을 보였으나 LPS+Si, 600 MPa, 다른 캡, 2D" | §13-2 b (L467–468) | 표지 없음 | 어느 카드 (slug) 인지 적혀 있지 않음 · Part I 카드의 같은 문장 (L319) 에는 "2D" 가 없음 (카드 문제 14)
- [g] zunker2024_mdr_contact_model_partI · zunker2024_bulk_elastic_partII | Part I 의 FEM 은 2D 축대칭 요소로 3D 축대칭 접촉을 푼 것 (평면 2D 아님) · Part II 는 삼축 · die 구속을 3D (1/8 구 C3D10) 로 품 | Part I §3 (L74) · Part II §2 (L36) · §3 (L55) | stated | 2D ↔ 3D 비교 자체는 없음


### [batch_10] g. 2D 결과를 3D 로 옮길 때의 경고나 증거

**이 배치에 없음.** 2D 계산은 lei2026 이 2차 인용한 Taghikhani 의 2D FEM (NMC 입자 계면 분리 최대 틈 9.3 / 16.0 / 13.8 nm @ r_s 0.5 / 1.5 / 3.0 µm · L115 · [2차 · ref 166]) 하나뿐이고, 3D 로 옮길 때의 경고 · 증거는 카드에 없다.


### [batch_11] g. 2D 결과를 3D 로 옮길 때의 경고나 증거

이 배치에 없음 (2D ↔ 3D 를 직접 견준 카드 0 장).

참고 — 차원에 관한 주의 셋:
- [g] stavola2023_thick_nmc111_lpscl_lithiation_gradient_tortuosity | COMSOL 모델은 2D 균질화 위에 원형 NMC 24 개를 놓은 "기하 장식" — 접촉 · 공극 · SE 형상이 없고 지수 a 두 개를 손으로 맞춤 → "동역학이 아니라 수송" 결론은 이 모델 안의 민감도 | §4-3 (L160) · §9-8 (L283) | [인쇄 SI p.24] (모델 사양) · 카드 판단 (한정) | 2D → 3D 이전의 증거는 아님
- [g] park2020_dimension_controlled_se_percolation_contact_area | 제목의 "0D · 1D · 2D" 는 SE **형상** 차원 (구 · 원기둥 · 판) 이고 계산은 3D 복셀 — 2D 계산으로 읽으면 안 됨 | 머리 (L1) · §3-A (L43) | stated | —
- [g] shi2019_high_am_loading_particle_size_assb | 카드 기록: Shi 모델은 3D 라 2D–3D 주의가 이 비교에는 해당 없음 | §11 (L734) | 표지 없음 | —


### [batch_12] g. 2D 결과를 3D 로 옮길 때의 경고나 증거

2D ↔ 3D 를 견준 수치나 경고는 **이 배치에 없음**. 닿는 사실만 적는다.

- [g] so2021_dem_mold_pressure_assb_coldpress | 이 3D 모델은 같은 그룹 2D 모델 (So 2020 [27]) 의 3D 확장 — 두 차원의 결과를 견준 수치 · 경고는 카드에 없음 | §1 (L15) · §7 (L94) · §10 (L118) | 표지 없음 | —
- [g] demirtas2021_mpfem_hollow_sphere_die_compaction | 3D 만 — *"To the authors' knowledge, this is the first study investigating the compaction behavior of the hollow particles in 3D MPFEM with the number of particles ranging from 411 to 1979."* · 2D 대조 없음 | §2 (L64–66) | stated | —
- [g] benhadjali2026_wip_vs_cup_pressing_assb_cathode_dem | "2D/3D 해당 없음 (둘 다 3D)" | §7-5 (L339) | 카드 서술 | —


### [batch_13] g. 2D 결과를 3D 로 옮길 때의 경고나 증거

2D 계산 값을 3D 로 옮기는 문제를 직접 다룬 근거는 이 배치에 없다. 가까운 문장 하나 (xu2023 — 2D SEM 에서 만든 형상의 3D 대표성 한계) 와 사실 하나 (lyu2025 — 선행 2D DEM 의 3D 확장).

- [g] xu2023_realistic_am_shape_cgmd_calendering | 2D 유래 형상에 대한 논문의 지적 (비구형 경쟁 모델 Nikpour 2021 · ref [32] 에 대해): *"in their approach the particle morphology is generated from **2D SEM images**, which limits the representativity of the real particle shapes in 3D"* | §2 (L79–82) | stated (인용) | 형상 생성에 관한 말 — 2D 역학 계산 값을 3D 로 옮기는 문제에 대한 증거는 아님
- [g] lyu2025_3d_dem_drying_calendering_lib | 1저자의 선행 연구 (Lyu [22]) 가 2D DEM 건조이고 이 논문이 그것의 3D 확장 + 압연 연결이라는 사실만 적힘 | §2 (L22) | 표지 없음 | 2D 값과 3D 값의 비교 · 옮길 때의 경고는 카드에 없음
- [g] ngandjong2021_dem_calendering_digital_twin · zhang2026_xct_dem_cathode_calendering_peel_calibration · miss2026_insitu_conductivity_porosity_pressure_compaction · miss2026_pressure_tortuosity_composite_cathode_coating | 이 카드들에 없음 (계산은 모두 3D · 실험은 실물) | — | — | —


### [batch_14] g. 2D 결과를 3D 로 옮길 때의 경고나 증거

경고 · 증거는 이 배치에 없음. 차원에 관한 사실 두 줄만 있다.

- [g] so2022_dem_compaction_coated_particles_assb | 계보: So 2020 (2D · ASSB 제조 · 셀 인터칼레이션 DEM) → So 2021 = "그 2D 의 3D 확장" → 이 논문 (3D · 양극 · 코팅). 2D 값과 3D 값의 차이나 옮길 때의 경고는 카드에 없음 | §2 L27–29 | 표지 없음 | —
- [g] lee2024_multiphysics_dem_fem_initial_pressure_assb | FEM 이 pseudo-3D (2D 거시 경계 조건 + 대표 AM 입자 안 1D 확산 · Wolff 2018 기반) · DEM 의 차원은 카드에 없음 | §4.3 L143–144 | 표지 없음 | 3D 로 옮길 때의 경고 · 증거 없음


### [batch_15] g. 2D 결과를 3D 로 옮길 때의 경고나 증거

- [g] cooper2017_simulated_impedance_diffusion_porous_media | 같은 2D 틀을 기둥 (prismatic 2D) 과 회전체 (축대칭 3D) 로 만들어 견줌 (Keiser 폐쇄 기공 5 개 · 그림 1): "3D 가 2D 보다 형상 효과가 크다" · Keiser 1976 결과는 이 논문의 2D 와 3D 사이 | §5 L213 · §6-bis L230 · 논문 p.684–685 | 표지 없음 (그림 설명) | 확산 임피던스 (역학 아님) · 차이의 크기 수치는 카드에 없음 (정성)
- [g] cooper2017_simulated_impedance_diffusion_porous_media | 차원을 줄인 모델의 오차 방향: 1D 균질화 (pseudo-3D) 는 3D 보다 저주파 저항을 과소 — Z̃′(ω = 0) 14.0 ↔ 17.3 (단면비 0.01) · 3.0 ↔ 3.0 (1) · 1.7 ↔ 2.2 (3) → −19 % · 0 · −23 % · 이유 = 등농도면이 흐름에 수직이라는 가정 (가로 확산 무한대) | §3-3 L82–88 · §4-6 L171 · 그림 6 (p.687) | stated(그림) · 비는 우리 재계산 | 그림 6 의 정규화 (A · L) 미기재 → 비만 씀 · 1D ↔ 3D (2D ↔ 3D 아님)
- [g] cooper2017_simulated_impedance_diffusion_porous_media | 카드의 경고: "2D 사례는 개념 증명 — 절대 크기 전이 금지" · "2D 사례가 대부분 (그림 1–3 · 6) … 3D 는 Keiser 회전체 · 구배 구 충전 하나 · 분리막 영상 둘" | §7 L252 · §10 L354 | 카드 서술 | —
- [g] cronk2026_lis_positive_electrode_geometry_fem | 2D → 3D 로 옮긴 사례: eigenstrain 계수 β_H 를 *"a **2-D simulation** consisting of the exact same model for a **single S particle**"* 로 목표 부피팽창에 맞춘 뒤 3D 전극 FEM 에 씀 — 2D ↔ 3D 차이에 대한 검토 · 경고는 카드에 없음 | §4.1 L207 · §9 L623 | stated (인용문) | 팽창 계수 보정 (접촉 아님) · 카드는 "β_H 값은 이식 불가능 (C_Li 미기재)" 만 지적 (L280)
- [g] bielefeld2020_effective_ionic_conductivity_binder | 3D 계산 — 2D 결과 없음 ("본 논문 3D … 우리 3D 와 차원 일치") | §10 L493 | 카드 서술 | —
- 나머지 (asano2017 · beutl2024 · bielefeld2019 · chen2011): 해당 없음.


### [batch_16] g. 2D 결과를 3D 로 옮길 때의 경고나 증거

2D 계산을 3D 와 직접 견준 카드는 없다. 경고로 쓸 수 있는 것:

- [g] islam2026_microstructure_resolved_impedance_lpscl_symmetric_cell | 2D 한 장 · 실현 1 개 결과의 지위: "2D, 실현 1 개, 시드 0, 격자수렴 0 — 통계적 주장 불가" · "크기 전이 금지 (2D · 스케일 카툰)" · 3D 없음 | §4-2 L67 · §7 L99 · §10 L118 | 카드 서술 | 논문 자신의 2D ↔ 3D 비교는 없음
- [g] islam2026_microstructure_resolved_impedance_lpscl_symmetric_cell | 2D 에서 얇은 저항 상을 임계화하면 닫힌 망이 아니라 끊긴 선분이 되어 전류가 우회 — 넣은 저항 항의 효과가 사라짐 (연속 막이라면 직렬 ≈ 66 Ω·cm² 가 더해져야 한다는 카드 산술 ↔ 관측 변화는 거의 없음) | §6 L90 · §10 L120 | derived (카드 산술) · 카드 서술 | 그 "입계 영향 없음" 결과는 카드가 "인용 금지" 표지 (값은 옮기지 않음 · L33 · L76) · 2D · 격자 3.75 µm · 3D 에서 어떻게 되는지는 카드에 없음
- [g] holzer2013_constrictivity_effective_transport_porous_layers | 2D 면 통계의 대표성 부족: 출구면만 본 크기 분포는 6 방향 r50 이 53–94 nm 로 흩어짐 ↔ 전체 부피 통계는 6 방향 ± 1 nm · 입구면 6 방향 평균은 3D 분포와 가까움 (154 ↔ 157 nm) → 3D 부피 통계 권고 | §3-A L74–76 · §4-4 L156 · §5 L207–208 · 논문 p.2946–2948 | stated | 영상 기하 지표 (힘 · 수송 아님) · LSC
- [g] duquesnoy2020_calendering_ml_mesostructure_generator | 경계면 한 장의 2D 면적분율은 3D 연결성을 뜻하지 않음: 집전체 접촉 지표가 z = 1 슬라이스의 면적분율이라 "집전체 위에 떠 있는 고립된 CBD 섬 하나도 그대로 계수" — 연결성 검사 0 | §4.5 L236–241 | 카드 서술 (코드 판독) | 수송 지표 · LIB
- [g] galvezaranda2024 · hamann2026 · hlushkou2018 | 이 카드들에 없음 (모두 3D) | — | — | —


### [batch_17] g. 2D 결과를 3D 로 옮길 때의 경고나 증거

2D → 3D 의 경고 · 증거를 직접 준 카드는 **없다**. 닿는 두 줄:

- [g] landesfeind2016_tortuosity_eis_electrodes_separators | 문헌 대조표의 한 줄: Ebner & Wood [16] 이 SEM 상면 · 단면 (2D 영상) 에서 Bruggeman Estimator 로 관통 방향 지수 α = 0.83 을 얻어 N_M 을 계산 (LCO) · 3D 재구성 기반 τ 가 EIS 보다 낮게 나오는 이유로는 영상 해상도 (도전재 · 바인더 미해상) 를 지목 | §5-8 L308 · §5-5 L269 · §5-6 L285 | stated | 2D → 3D 전환의 정확도를 따진 문장은 카드에 없음 · LIB
- [g] kim2026_a3d_air_electrode_microstructure_transport | 2D → 3D 는 아님 — 3D 구조를 1D 로 평균화할 때의 한계를 저자가 적음: "1D framework relies on volume-averaged effective properties... cannot explicitly capture pore-scale heterogeneities and microstructure-resolved deposition" | §6-(d) L615–616 · 논문 p.7 | stated (인용문) | Li–O₂
- [g] 그 밖의 카드 | 이 배치에 없음 (kato2018 의 모형은 1D 해석식) | — | — | —


### [batch_18] g. 2D 결과를 3D 로 옮길 때의 경고나 증거

직접 닿는 카드 = **1** (nguyen2020 — 2D 손그림 사례와 3D 구 충전이 한 논문에 같이 있음). 나머지는 간접.

- [g] nguyen2020_electrode_tortuosity_factor | 같은 두 정의 (관통형 τ ↔ 전극 τ_e) 의 차가 2D 손그림 구조에서는 +1.0 … +46.7 % (Fig 4 A–D · 300 × 300 px) 인데 3D 구 무작위 충전에서는 +0.8 / +3.9 % (Fig 5 · 퍼콜레이션 > 99 % · 막힌 기공 4 / 8 %) | §3-1 L33–38 · L43 · p4–6 | stated(그림) · derived (비) | 2D 구조는 MS Paint 로 그린 개념 증명용 (L105) — 2D 와 3D 가 같은 구조의 두 표현이 아님 · 액체 LIB
- [g] nguyen2020_electrode_tortuosity_factor | 카드의 경고: 2D 사례 (Fig 2–4) 의 절대 크기 (예 +46.7 %) 를 3D 침대 기대치로 쓰지 말 것 — 3D 의 근거는 구 충전 2 개 (Fig 5) 와 설계된 2 층 1 개 (Fig 6) 뿐 · 반복 · 시드 없음 | §7 L198 · §10 L217 | 카드 서술 | 논문 문장 아님
- [g] nguyen2020_electrode_tortuosity_factor | 2D 와 3D 의 계산 설정 자체가 다름: 2D 는 전극 기공과 정렬된 곧은 기공 분리막 · 3D 는 분리막 기공망 대신 전해질만 있는 자유 층을 두 전극 사이에 둠 (데이터 준비 단순화) | §4-C L101 · p10 | stated | —
- [g] morasch2018_binder_gradient_impedance_tortuosity | 2D → 3D 는 아님 — 모의는 2D (전극 50 × 260 µm) 인데 저자가 "1D 로도 충분" 이라 적음 (가로로 균질한 연속체라 차원을 내려도 같다는 쪽의 사례) | §3 L56 · §4-9 L167 · A3460 | stated | 입자가 없는 균질 모형 — 입자 계산의 2D ↔ 3D 근거가 아님
- [g] malifarge2017 · landesfeind2018 | 2D → 3D 아님 — 1D 균질 TLM 이 dead-end 기공 · 두께 방향 구배를 못 본다는 한계 (malifarge §10 L395) · 강구 검증은 균질 구 충전 한 기하뿐 (landesfeind2018 §10 L365) | — | 카드 서술 | —
- [g] lee2026 · matthews2024 · nakamura2020 | 이 카드들에 없음 (3D 재구성 또는 표면 SEM — 차원을 옮기는 논의 없음) | — | — | —


### [batch_19] g. 2D → 3D 이전의 경고 · 증거

- [g] tjaden2018_tortuosity_review_calculation_approaches | 2D → 3D 경고: "Taiwo [2]: stereology 값은 3D 측정과 상당히 어긋날 수 있다"; 반면 BruggemanEstimator (2D 영상 두 장 → 차원별 α) 는 수치 τ 와 잘 맞았다 [58] | §4.2 L156 | stated (리뷰 인용) | 기공상 상관식 · 사례별
- [g] tjaden2018_tortuosity_review_calculation_approaches | 2D 단면 사슬 방법 (pore centroid) 의 인공물: 특징이 제어부피보다 작으면 단면 무게중심이 중앙으로 몰려 τ → 1 ("resulting in a tortuosity of unity", Cooper [118]) · 축당 값 하나 | §4.4.1 L196 · Fig 7 | stated (원문 인용) | 기하 τ 방법
- [g] song2025_porous_argyrodite_modulus_fracture_toughness | 2D 평면 가정의 규약 차: CT 의 K 는 2D 평면응력 FE · G_c = K²/E (평면응력, 6.15) vs K²(1−ν²)/E (평면변형, 5.31) = × 0.863 | §4.2 L115 · §10 L191 · §3.1 L45–46 | stated · derived(ours) | 2D 입자 계산을 3D 로 옮기는 증거는 아님
- 나머지: 해당 없음.


### [batch_20] g. 2D → 3D 이전의 경고 · 증거

- [g] zhang2026_dryprocess_electrode_architecture_cell_level | 2D 대면적 단면 한 장의 헤드라인 (최대 연결 CBD 61.2 vs 17.1 % = 3.58 배) 이 3D PFIB 슬라이스 통계 (121 / 135 장 평균 0.5359 vs 0.3836) 로는 1.397 배 — "2.6배 과장" · 2D 의 17.1 % 는 3D 분포 최솟값 (16.3 %) 근처 · 61.2 % 는 p75 (58.7 %) 위 | §3-3 L284–298 · L363–371 | stated · source-data → derived(ours) | 액체 LIB CBD · 정규화 분모 미정의 · 2D · 3D 분할 파이프라인 다름 (Weka ↔ Avizo) · 방향은 유지 (d 1.26)
- [g] zhang2026_dryprocess_electrode_architecture_cell_level | COMSOL 메시 = *"by stacking two identical images together"* → 2D 단면의 z 압출 · 면외 연결이 인위적으로 완전 (카드 판단: 대비를 줄이는 보수 편향일 가능성 · 미검증) | §4-3 L655–660 · §11-⑤ L1252–1253 | stated (원문 인용) + 카드 풀이 | 연결성이 논지 핵심인데 편향 방향을 논문이 논하지 않음
- [g] zhang2026_dryprocess_electrode_architecture_cell_level | TauFactor τ 를 2D 에서 쟀는지 3D 에서 쟀는지 애매 ("segmented PFIB-SEM images") | §3-8 L512 · §4-4 L676 | n/a | —
- [g] wang2027_ncm811_effective_bulk_modulus_mapper_dfs_gnn | 2D SEM 질감 (Gram) 손실로 3D 재구성 → 2D 통계만 맞추고 3D 목 연결은 직접 제약하지 않음 · K 는 그 목이 정함 (국소 지수 ≈6) · 직교 세 방향 기준 영상 미기재 (같은 단면이면 등방 가정 — 캘린더 전극은 이방) · 재구성 검증 = 기공률 한 숫자 | §10-3 L388 · §3-2 L79 | [미확인] / 카드 풀이 | 액체 LIB · 재구성 부피 하나
- [g] vijay2025_hybrid_cgmd_dl_slurry_microstructure · yoo2026_porosity_gradient_dry_electrode | 해당 없음 (3D 만) | vijay §10-J L608 | — | —


### [batch_21] g. 2D 결과를 3D 로 옮길 때의 경고 · 증거

이 배치에 없음 (2D → 3D 경고 · 증거를 준 카드 없음 — zhou2026 은 3D 단위셀이고 2D 결과가 없다).


### [batch_22] g. 2D 결과를 3D 로 옮길 때의 경고 · 증거

이 배치에 2D → 3D 전이 경고 · 증거 없음. 관련만:
- [g] hare2026_dem_pept_dry_mixing_nmc622_eirich | depth-average 가 3D 속도장을 2D 로 접어 대조 — z 방향 구조는 대조에서 사라진다 (충진 25 mm) | §5.3 (f) L357 | 카드 풀이 | 3D → 2D 투영 (2D 계산을 3D 로 옮기는 문제 아님)
- [g] jadidi2023_dem_batch_solid_mixers_review | 리뷰 대상 전부 3D — "2D/3D 문제 아님" | §10.2 L521 | 카드 풀이 | —


### [batch_23] g. 2D 결과를 3D 로 옮길 때의 경고 · 증거

이 배치에 2D → 3D 전이 경고 · 증거 없음. 관련만:
- [g] kang2026_multiscale_inverse_design_ptfe_fibrillation_dry_electrode | 미시 FEM 의 차원이 인쇄되지 않음 — SI Fig 1 · Fig 1b 축이 x · y (µm) 라 2D 단면으로 보이고 · 카드의 PTFE 몸체 크기 환산도 '2D 비압축 가정' · 그 결과를 3D 실물 (SiO₂ 막 · LFP 후막) 에 바로 대응시키며 2D → 3D 전이에 대한 논문 서술은 카드에 없음 | §3-2 L99–100 · §0 L34 | [판독] · [우리 산술] · [미확인] | 경고나 증거가 아니라 '차원 미기재' 표지
- [g] kang2025_bollard_anchored_binder_dry_electrode | MD 영상 (3D 궤적의 렌더) 의 픽셀 궤적 재측정 — "2D 투영 중심이다. 논문 지표는 3D 평균거리 → 같은 추정량이 아니다" · 쓸 수 있는 것은 시점 · 서열 · 배수 | §4.10-B L455–456 | 카드 판독 한계 | 3D → 2D 투영 (2D 계산을 3D 로 옮기는 문제 아님)
- jeong2025 · jun2026 · kawaguchi2017 · kawaguchi2023 · kim2026: 2D 계산 없음.


### [batch_24] g. 2D 결과를 3D 로 옮길 때의 경고 · 증거

- [g] lee2024_shear_force_dry_process_cathode_coverage | 피복 = 2D 단면의 둘레 길이 몫 ↔ 우리 = 3D 면적 몫 · 카드: 등방 무작위 단면이면 둘레 몫의 기댓값 = 표면적 몫 (입체해석학 S_V ↔ L_A) 이라 평균끼리는 견줄 수 있으나, 입자별 값은 단면 위치 (적도 ↔ 극) 에 따라 흔들려 2D 분포 폭이 더 넓다 | §7-2 L302 | [추정] (논문은 언급 안 함) | 카드 풀이 · 검증 없음
- [g] lee2024_shear_force_dry_process_cathode_coverage | COMSOL 1D SPM 을 2D 로 확장 · 면외 깊이 D = 36.378 m 로 모델 활물질 부피 V = π·rp²·D = 11.429 mm³ 를 셀 실제값에 축척 · 그 V 의 겉보기 NMC 밀도 2.73 g/cm³ (근거 미확인) | §3-6 L129 · L139 · L151 · Table S1 | [인쇄] (D · V) · [우리 산술] · [추정] | 2D 모델의 3D 축척 근거 미기재
- 다른 카드: 이 배치에 없음.


### [batch_25] g. 2D 결과를 3D 로 옮길 때의 경고 · 증거

이 배치에 없음 (lippke2023 · lischka2025 는 3D DEM · 나머지 셋은 실험 · 리뷰 — 2D ↔ 3D 문제를 다룬 카드 없음).


### [batch_26] g. 2D 결과를 3D 로 옮길 때의 경고 · 증거

- [g] qin2026_bilayer_cathode_cgmd_dem_graded_thick_electrode | 서론: 구 근사 · 2D 형상은 형상 효과를 과소평가 [32,39] | §2.5 줄 81 (p.2–6) | stated (인용 전달 · 원문 미확인) | 정량 근거 카드에 없음
- [g] pfeffer2001_dry_particle_coating_engineered_particulates | Mechanofusion DEM 은 2D (호스트만 · 입자 크기 · 개수 미기재) · 3D 로 옮기는 논의 없음 | §3-8 줄 148 · §0 한정어 ④ 줄 37 (p.58–64) | [인쇄] · [미확인] | 경고 · 증거 아님 (2D 를 쓴 사실만)


### [batch_27] g. 2D → 3D 경고 · 증거

- [g] bucci2017_chemomech_failure_assb_cycling_czm (Bucci · Swamy · Chiang · Carter 2017 · J. Mater. Chem. A 5, 19422–19430) | 2D plane strain (두꺼운 시료 속 얇은 판 가정) · 저자 '2D model expected to correctly capture trends in stress and fracture' · 3D 전체 해석은 계산 비용으로 보류; 카드: 2D ≠ 3D 절대 규모 · 추세와 임계만 신뢰 | §4.5 줄 214–215 · §7.1 줄 328 · §8.4 줄 388 | stated · 카드 판단 | 3D 대조 없음 (경고만)

나머지 다섯 장은 3D DEM 또는 실험 — 2D↔3D 언급 없음.


### [batch_28] g. 2D 결과를 3D 로 옮길 때의 경고 · 증거

- [g] dem_mechanical_stresses_ssb_electrode_cycling | 서론: *"lack of comprehensive 3D models that address material interfaces and mechanics remains a gap"* · 3D 모델이 계면 진화 · 공극 형성 이해에 필요 (refs [11,21]) · 이 논문은 3D (카드: So 2021 · Bucci 는 2D) | §5.1 줄 191–192 · §4.9 줄 182 | stated · 카드 서술 | 2D ↔ 3D 정량 비교 없음
- [g] kang2025_toughened_bimodal_nca_lzo · kim2023_chemomech_failure_highstrain_anode | FEM 이 2D (Voronoi · 12.5 µm 도메인) — 3D 로 옮기는 경고 · 근거 카드에 없음 | kang2025 §2 줄 49 · §4 줄 152–153 · kim2023 §2 줄 66 · §4 줄 167–168 | stated | —
- (가까운 것) [g] gandla2026_layered_cathode_degradation_diagnostics_review | 척도 이전 경고: 얇은 모델 전극에서 얻은 감소 원인 배분을 후막으로 그대로 옮길 수 없다 · 원자 척도 결론 = 입자 몇 개 ↔ 파우치 수십억 | §3-10 줄 187 · 189 (p.26–27) | [인쇄] | 2D/3D 이전 아님
- (가까운 것) [g] intergranular_cracking_nmc811_jmca2023 | 단면 (잘라 보기) 관찰은 잔류응력을 풀어 균열을 바꿀 수 있음 → 3D 비파괴 CT | 머리 줄 65–67 | 카드 서술 | —


### [batch_29] g. 2D 결과를 3D 로 옮길 때의 경고 · 증거

- [g] so2021_dem_fabrication_degradation_ductile_particles | 저자 명시 한계 (Shortcomings): "we simulated only in two dimensions" · "2D cluster DEM may overestimate solid fraction at low Pfab" · <200 MPa 에서 Sakuda 실험보다 과치밀 = "3D aggregate 구조 (더 큰 voids) → 시뮬 (2D) 이 과치밀" · 자매 So 2021 JPS 는 3D | L24 · §4.6 L165 · §5.4 L194 · §5.10 L218 · §7.1 L273 · §10 L381 | stated (따옴표 = 카드가 옮긴 원문) | 2D 의 z 두께 = 평균 SE 지름 가정 (L135 · L244) · 같은 재료의 3D 대조 결과는 카드에 없음
- [g] siroma2015_transmission_line_model_porous_electrode_impedance | (1D → 3D · 2D 아님) "we implicitly assume that the sample is one-dimensional." (p.315) · 카드: 이 논문과 우리 사이에 걸리는 차이는 "1D 균질 연속 ↔ 3D 비균질 접촉망" 하나이고 그 차이가 τ_e ≠ 관통 τ 를 만드는 자리 · 실제 ASSB 에서 적합된 z_A 는 "겉보기" 값 | §4-1 L159 · §7 L366–367 · §10 L493 | stated (원문) · 카드 풀이 | 임피던스 회로 · 압밀과 무관
- 나머지: 없음 (lee2026 모델은 3D 만 · sedlatschek2026 FE 2.5D 는 시편 설계용).


### [batch_30] g — 2D → 3D

- [g] 이 배치에 없음 — 2D 결과를 3D 로 옮길 때의 경고 · 증거를 다룬 카드는 없다.
- [g] park2020_digitaltwin_assb_foundational | 3D 디지털트윈 (Fig 1b) ↔ 같은 구조의 2D 디지털 단면 (Fig 1c) ↔ 실제 FESEM 단면 (Fig S4) 형태 대조 — 3D 구조를 2D 단면으로 검증한 사례 (옮김 경고는 아님) | §2 (줄 183) · Fig 1b,c · S4 | stated | 정성 대조


### [batch_31] g — 2D → 3D 옮김 경고 · 증거

- [g] 이 배치에 없음.


### [batch_32] g — 2D → 3D

- [g] 이 배치에 없음 — 2D 결과를 3D 로 옮기는 경고 · 증거를 다룬 카드는 없다.
- [g] hong2026_cbd_viscoelasticity_springback | 유효 전자전도도 (RC-S 0.19 · HC-S 0.32 S/cm) · 계면 접촉면적 · 기공 분포는 2D 단면 수동 분할 위 GeoDict 계산 (σ_eff = J·L/ΔV · FVM) — 카드는 2D 한계를 따로 적지 않음 | §2.4 (줄 127–133) · §4.5 (줄 272–289) | 판독 (막대) | 3D 값으로 옮길 근거 없음


### [batch_33] g — 2D → 3D 경고 · 증거

- [g] li2007 (C. Li, E. T. Thostenson, T.-W. Chou, Appl. Phys. Lett. 91, 223114 (2007)) | 망 = 2D 정사각 20 × 20 µm² 두 층 (의사-3D) · 임계 지수 1.78–2.14 를 "2D 보편값 1.3 · 3D 2.0 · 문헌 1.2–3.1" 과 나란히 적고 *"the critical exponent depends on the level of contact resistance"* · 카드: "이 논문의 망 (2D 곧은 CNT · 의사-3D) 은 우리 3D 복셀 침대 … 와 다르다 — 값 전이 금지" | §3-2 · §7 머리 (카드 줄 95) · §11 3 · p.223114-3 | stated (지수 · 인용문) · 카드 경고 | CNT 전기 망 (역학 아님)

그 밖: 이 배치에 없음.


### [batch_34] g — 2D ↔ 3D 옮김 경고

- [g] nadeem2023_gnn_mixing_index | 3D CT 를 찍고 이웃은 2D 단면에서만: "since calculations were performed on 2D cross-sectional slices extracted from the 3D volumetric CT reconstructions, neighbor particles were only defined in the 2D plane". 카드: 3D 배위수 (6+, Pinson 이성분 구) 를 2D 이웃에 적용 = 차원 어긋남 · 단면 겉보기 반지름 보정을 GNN 에는 안 함 (MGMMI 에만 면적 가중) | §4.6 L261–267 · §10-② L603–604 | 원문 인용 · 카드 해석 | 방향이 반대 (3D 값을 2D 에) · 혼합지표 (압밀 아님)
- [g] nase2001_granular_bond_collision_number_wet_cohesion | 드럼 충돌 수 Co 의 δ/R_t ≈ 0.03 = Gilchrist 2D 드럼 실험값 차용 — "3D · 배플 · 다른 채움에서는 다를 수 있다 (… 4 제곱이라 민감)" | 한정어 ④ L36 · §3-6 L99 · §10-7 L190 | [우리 산술] · [추정] | 믹서 흐름 (압밀 아님)


### [batch_35] g — 2D → 3D 경고 · 증거

- [g] otani2023 | 2D SEM 단면 무작위 행보로 낸 경로 저항 계수가 3D 펠릿 실측 σ–공극 곡선을 재현 (순수 층 · p.4) = 증거 한 건.  카드 경고: 2D 단면은 3D 연결을 과소 · 과대평가할 수 있다 (2D 퍼콜레이션 문턱이 다름) · SEM 시료는 무구속이라 공극이 다름 | §3-3 (줄 79–81) · §10-3 (줄 246) · Fig 4 · 5 | [인쇄] (재현) · 카드 비판 (경고) | 복합 (AM 있음) 은 2D 계수를 안 냄
- [g] pan2026 | η = 2D FIB 단면 호 길이 ÷ 둘레 = "3D 접촉 면적 분율의 2D 대리" · Holm 산술에 2D 호 길이의 절반을 3D 반지름으로 씀 (입체해석 보정 없음) · 카드: 2D 호 길이 ≠ 3D 접촉 지름 | §3-2-9 (줄 212) · §4-2 (줄 289) · §10-2-3 (줄 430) | [인쇄] · 카드 비판 | 10–11 입자 · 불확도 없음


### [batch_36] g — 2D → 3D 경고 · 증거

- [g] zhang2023 | CBD 연결성 (최대 응집체가 전체 CBD 의 23.6 % (슬러리) ↔ 57 % (건식)) 은 2D 세그멘테이션의 연결 성분 라벨링 값이다.  카드는 이를 "우리 f_perc/최대클러스터 지표와 정의가 같다 · 직접 비교 가능 · 구조지표 전이 가능" 으로 적고 2D → 3D 경고는 달지 않았다 | §3-8 (줄 148) · §5 Fig 6E/F (줄 299) · §6 (줄 325) · §③-3 #6 (줄 445) · §8 ③ (줄 467) | stated (값) · 카드 판단 (전이 등급) | 2D 연결이 3D 연결과 같은지에 대한 증거 · 경고가 카드에 없음 (카드 문제 7)
- 그 밖: 이 배치에 없음 (wiedenmann2013 · windreich2003 · ziegel2010 은 처음부터 3D · wang2018 · zhang2026 은 해당 없음).


### [batch_37] g — 2D → 3D 경고 · 증거

이 배치에 없음.


### [batch_38] g — 2D → 3D 경고 · 증거

이 배치에 없음.  (yuan2026 의 FEM · 위상장은 2D 20 × 10 µm 로 3D 파우치 측정을 설명하지만 2D ↔ 3D 검토는 카드에 없다 — 평면변형인지 평면응력인지도 미기재 · §4b 줄 190.)


### [batch_39] g. 2D 결과를 3D 로 옮길 때의 경고나 증거

이 배치에 없음.


### [batch_40] g — 2D → 3D 경고 · 증거

- [g] gritton2017_mpm_chemomechanical_coupling_silicon_anode | *"while the pillar geometry lends itself to a 2D axisymmetric numerical solution for the purposes of this paper full 3D simulations will be performed"* — 축대칭 2D 로 줄일 수 있는 문제를 3D 로 풀었고 2D 해와 견주지 않음 | 카드 §0-2 (iii) · 논문 §4 p.11 | 인쇄 | 3D 를 택한 까닭 · 2D ↔ 3D 값의 차이는 없음
- [g] gritton2017_mpm_chemomechanical_coupling_silicon_anode | 차원 축소 (구 대칭 1D 모형 [22, 23]) 에 대해: *"While the reduction of dimensionality can lead to insights … without the higher computational costs of higher dimensional simulations, key features associated with anode geometries will be lost."* | 카드 §0-2 (iii) · 논문 §1 p.3 | 인쇄 | 남의 모형에 대한 일반 문장 · 증거 수치 없음
- [g] gritton2017_mpm_chemomechanical_coupling_silicon_anode | 2D 벤치마크에 **축대칭 MPM** (논문 ref. [41]) 을 쓰면 입자 하나 압축 · 구–블록 누르기가 그대로 3D 문제가 된다 | 카드 §9 ⑩ · §10 행동 4 | [카드 추론] | 논문 주장 아님


### [batch_41] g — 2D → 3D 경고 · 증거

- [g] bardenhagen2005_mpm_foam_densification_simulation | 계산은 **3D** (본문에 '3D simulation' 낱말은 없고 *1 mm³ block* · *spherical nodes* · 원근 그림 · *viewed from below* 로 알 수 있음) · 2D ↔ 3D 를 견준 문장 없음 ('two-dimensional' 은 참고문헌 제목 한 번) | 카드 §0-2 (iii) · 논문 p.603–604 · Fig. 2 · 7 | [카드 판독] | 2D → 3D 전이의 증거를 주지 않음
- [g] bardenhagen2005_mpm_foam_densification_simulation | 차원 대신 **크기** 경고: *"Although it is tempting to suggest the results in Fig. 6 are representative of bulk foams with similar microstructures, it is unlikely to be the case.  Much bigger unit cells need to be considered …  Accurate determination of bulk foam response requires finding the necessary size of a representative volume element (RVE) of material."* · 필요한 규모 100–1000 기공 | 카드 §0-2 (iii) · §3-9 · 논문 p.610 · p.615 | 인쇄 | 발포체 — 작은 단위 셀의 값을 거시 값으로 옮기지 말라는 일반 경고로만


### [batch_42] g — 2D → 3D 경고 · 증거

보강 없음 (3D 만 · 2D 대조 없음).


### [layer3] g. 2D 결과를 3D 로 옮길 때의 경고나 증거

비교 문서에 2D → 3D 를 직접 견준 증거는 없다. 있는 것은 "2D 값 전이 금지" 표지와 2D · 3D 가 같은 부호라는 정황뿐이다.

- [g] cardenasbarrantes2020_rigid_deformable_mixture_compaction_nscd + cardenasbarrantes2021_soft_rigid_mix_compaction_proceedings + cardenasbarrantes2022_soft_hard_grains_compaction_experiment_dic | 2D 원판 결과 → "절대값 전이 0 건" (비교 문서 표지) — 옮기는 것은 방향 (φmax 가 κ 에 가파르게 반응하는 구간 · 강체 골격 재밍) 과 적합 꼴뿐 | §A L941–946 | 표지 없음 | 3D 대응 증거는 이 구간에 없음
- [g] nezamabadi2022_mpm_cd_plastic_particle_compaction | 2D 맞춤값 (f_E 1.2 · f_G 0.2 · α 2.5) "전이 금지" — 식의 틀만 3D 에 씀 | §A L950–951 | 표지 없음 | 
- [g] gonzalez2012_nonlocal_contact_confined_granular | 비국소 보정 크기의 2D 값: 논문 §5 요약 "2D · ε 10 % · ν → ½ = 40 %" ↔ 3D 절단급수 25 % — 비교 문서는 급수가 하한이라는 근거로만 씀 | §A L707 | 표지 없음 | 2D 값을 3D 값으로 쓰지 않음
- [g] paulick2015_elastic_particle_properties_dem_review | 강성 ↔ 벌크계수 선형의 근거 4 건 중 2D 1 건 (오이도미터 2D · PFC2D · Coetzee & Els [21]) · 3D 3 건 (Lommen [23] 18k 입자 · Yohannes [24] · Coetzee [30] 비구형) — 2D · 3D 가 같은 부호 | §A L769–774 | 표지 없음 | 응력 ≤ 80 kPa 급
- [g] nezamabadi2022_mpm_cd_plastic_particle_compaction + nguyen2017_mpm_bpm_deformable_particle_compaction + bardenhagen2000_mpm_granular_multibody_frictional_contact + bardenhagen2001_mpm_improved_contact_granular_stress_waves + cardenasbarrantes2020_rigid_deformable_mixture_compaction_nscd | (묶음) 입자별 접촉을 풀어 압밀 · 전단한 선례가 전부 2D (Bardenhagen01 의 구 1 개 회귀 시험만 3D · §F L3977) — 비교 문서 표지: "값 전이 금지 · 방법 · 무차원만" (Nezamabadi) · "값 전이 금지 · 알고리즘 · 해상도 규칙 · 정성 결론만" (Bardenhagen) · 절대 Z 는 2D 값 (Z ≈ 3 → 5.2–5.5 · 2D 무마찰 등정 4) · 3D 로 옮긴 증거는 이 절에 없음 | §C L2685–2727 | 표지 없음 | 
- [g] pycompact2025_dem_mpfem_workflow + demirtas2021_mpfem_hollow_sphere_die_compaction | (묶음) 3D 입자별 FE 는 있으나 규모가 작음 — PyCompact 569 입자 · Demirtas 8 / 520 입자 (C3D8R ~1650 요소 / 입자) | §C L2477 · L2506 · L2534 | 표지 없음 | 차원은 이 줄에 명시 없음 (C3D8R = 3D 요소)
- [g] kang2025_toughened_bimodal_nca_lzo + kang2026_multiscale_inverse_design_ptfe_fibrillation_dry_electrode | (묶음) 2D FEM 사례 — Kang & Shin: 2D Voronoi 다결정 NCA + cohesive-zone · Kang 2026: PTFE 를 두 세라믹 입자 사이에서 늘리는 2D FEM — 2D → 3D 경고 문장은 없음 | §C L2332–2336 · L2664 | 표지 없음 | 
- [g] bielefeld2020_effective_ionic_conductivity_binder | (2D ↔ 3D 아님 · 이산화 차이) 연속체 flux-PDE σ 는 입자 점접촉 좁힘을 빼서 σ 를 상한으로 평가 → Bazzoun · 접촉망이 협착을 되돌려 넣음 | §E L2815–2823 | 표지 없음 | 수송 축
- [g] bardenhagen2001_mpm_improved_contact_granular_stress_waves | 3D 회귀 시험이 있는 유일한 MPM 접촉 원전 (경사면 위 구 1 개) — 2D 압밀 선례 (Nezamabadi · Nguyen) 의 3D · 다물체 판은 "미시험" | §F L3974–3977 · §C L2723 | 표지 없음 | 압밀 아님
- [g] cardenasbarrantes2020_rigid_deformable_mixture_compaction_nscd | 단일 입자 상자 시험을 2D → 3D 로 옮길 때 바뀌는 것: 2D φp,0 = π/4 → 로그 포화 (b ≈ 0.14 · 메시 92 → 968 무관) · 3D 판은 φp,0 = π/6 · 소성 SE 면 P/σ_y 축 | §F L3972 | 표지 없음 (3D 쪽은 비교 문서 제안) | 3D 판 실측 아님 (비교 문서가 확보 후보로 적은 3D 논문 = Soft Matter 18, 312 (2022))
- [g] zunker2025_dem_large_deformation_compaction + demirtas2021_mpfem_hollow_sphere_die_compaction | (묶음 · 경계가 다름) 주기 RVE 에는 벽이 없어 잔류 반경응력 · 밀도구배 · 배출을 못 냄 — 실물 다이 + 벽 마찰은 3D 다이 계산에만 | §F L3749–3750 · L3795–3796 | 표지 없음 | 



"""Verify supplied bytes and saved fixed-pin metadata only."""
from pathlib import Path
import hashlib,json
ROOT=Path(__file__).resolve().parent.parent
P=ROOT/'package'
def sha(b):return hashlib.sha256(b).hexdigest()
def blob(b):return hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
manifest=json.loads((P/'SNAPSHOT_MANIFEST.json').read_text(encoding='utf8'))
pin=(P/'PIN.txt').read_text().strip()
assert pin==manifest['pin']=='b57fe91503ba68cec6f41aec247851262788e48f'
snapshot=[]
for e in manifest['entries']:
 b=(P/e['path']).read_bytes()
 result={'path':e['path'],'size':len(b)==e['bytes'],'sha256':sha(b)==e['sha256'],'git_blob':blob(b)==e['git_blob']}
 assert all(result[k] for k in ('size','sha256','git_blob')),result
 snapshot.append(result)
sums=[]
for line in (P/'SHA256SUMS').read_text().splitlines():
 digest,name=line.split(None,1);name=name.strip().lstrip('*')
 assert sha((P/name).read_bytes())==digest,name
 sums.append(name)
commit=json.loads((ROOT/'evidence/github_commit_metadata.json').read_text(encoding='utf8'))
assert commit['sha']==pin
assert commit['parents'][0]['sha']==(P/'PARENT_PIN.txt').read_text().strip()
for f in commit['files']:
 assert f['status']=='added'
 assert blob((P/f['filename']).read_bytes())==f['sha'],f['filename']
patch=(P/'CHANGE.patch').read_bytes().splitlines(keepends=True)
reconstructed={};name=None;data=[]
for line in patch:
 if line.startswith(b'diff --git '):
  if name is not None:reconstructed[name]=b''.join(data)
  name=None;data=[]
 elif line.startswith(b'+++ b/'):name=line[len(b'+++ b/'):].rstrip(b'\r\n').decode()
 elif name is not None and line.startswith(b'+'):data.append(line[1:])
 elif name is not None and line.startswith(b'\\ No newline at end of file'):
  assert data and data[-1].endswith(b'\n')
  data[-1]=data[-1][:-1]
 elif name is not None and line.startswith(b'-'):raise AssertionError('Not pure addition')
if name is not None:reconstructed[name]=b''.join(data)
assert set(reconstructed)=={f['filename'] for f in commit['files']}
for path,b in reconstructed.items():assert b==(P/path).read_bytes(),path
print(json.dumps({'pin':pin,'snapshot':snapshot,'packaging_entries':sums,'remote_added_blob_matches':len(commit['files']),
 'change_patch_files':len(reconstructed),'patch_reconstructed_bytes_match':True,'scope':'bytes/static identity only'},indent=2))

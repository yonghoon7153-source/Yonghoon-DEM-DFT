#!/usr/bin/env python3
"""check_run.py — run_tests.sh 의 판정기 (보충 조회 블록 q9b · q2b · q7b).
  snap <root…>       = 스냅숏 JSON (종류 · 크기 · mtime · 모드 · 작은 파일 sha256)
  check <T> <md5>    = 단언 (run_tests.sh 가 만든 <T>/<사례>.* 를 읽는다) → <T>/check_result.json
기대값 = 각 사례 세계의 expect.json (mkworld.py 가 명세에서 바로 계산 — 블록 코드와 독립).
"""
import hashlib
import io
import json
import os
import re
import stat
import subprocess
import sys
import tarfile

STATUSES = {'OK', 'FAIL', 'MISSING', 'TIMEOUT', 'TRUNC', 'ABSENT', 'DENIED', 'SKIPPED_BUDGET', 'SKIPPED_INTERRUPT', 'SKIPPED_SWITCH'}
FIXED_FORBID = ['fakeuser', 'SECRET-LOGIN-HOST', 'SECRET-NODE', 'SECRET-DBHOST', '10.1.2.3', 'fakebuilder', 'uid 4242', 'gid 4243',
                'example.org', 'PATHMARK', 'SECRET_DECOY_PATH']
QB = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
READER = os.environ.get('QB_READER') or os.path.join(QB, 'read_query_bundle_b.py')
SRC = os.environ.get('QB_SRC') or os.path.join(QB, 'src', 'query_script_b.sh')
R = {'pass': 0, 'fail': 0, 'lines': []}
NR_RE = r'nr\|\d+\|\d+\|\d+\|rows_before=\d+\|sp=\d+\|tab=\d+\|word=[A-Za-z#:._?<>~-]+'
LOG_RE = r'log\|\d+\|lines=\d+\|tables=\d+\|nonrow=\d+\|emitted=\d+\|suppressed=\d+\|tables_suppressed=\d+\|cr=\d+'
TAB_RE = r'table\|\d+\|\d+\|header_cols=\d+\|rows=\d+\|rows_nonfinite=\d+\|row_cols=[\d:,-]+\|nonrow=\d+\|blank=\d+\|closed=(yes|no)'
T_GLOBAL = None


def ok(cond, msg):
    R['pass' if cond else 'fail'] += 1
    R['lines'].append(('PASS ' if cond else 'FAIL ') + msg)
    return cond


def sha(p):
    h = hashlib.sha256()
    with open(p, 'rb') as f:
        for b in iter(lambda: f.read(1 << 20), b''):
            h.update(b)
    return h.hexdigest()


def snap(roots):
    out = {}
    for root in roots:
        if not os.path.lexists(root):
            continue
        for dp, dns, fns in os.walk(root):
            for n in dns + fns:
                p = os.path.join(dp, n)
                st = os.lstat(p)
                rec = [stat.S_IFMT(st.st_mode), st.st_size, st.st_mtime_ns, oct(st.st_mode & 0o7777)]
                if stat.S_ISREG(st.st_mode) and st.st_size < 2_000_000:
                    try:
                        rec.append(sha(p))
                    except OSError:
                        rec.append('unreadable')
                if stat.S_ISLNK(st.st_mode):
                    rec.append(os.readlink(p))
                out[p] = rec
    return out


def read(p, mode='r'):
    with open(p, mode) as f:
        return f.read()


def lines_of(p):
    return read(p).splitlines() if os.path.exists(p) else None


def kv(path):
    d = {}
    if os.path.exists(path):
        for line in read(path).splitlines():
            if '=' in line:
                k, v = line.split('=', 1)
                d.setdefault(k, []).append(v)
    return d


def probes(path):
    out = {}
    if os.path.exists(path):
        for line in read(path).splitlines():
            c = line.split('|')
            if len(c) >= 6:
                out[c[0]] = c
    return out


def st(pr, k):
    return pr.get(k, ['', 'ABSENT_LINE'])[1]


def new_dirs(T, name, home_real):
    b = json.load(open(os.path.join(T, name + '.snap_before.json')))
    a = json.load(open(os.path.join(T, name + '.snap_after.json')))
    added = sorted(set(a) - set(b))
    removed = sorted(set(b) - set(a))
    changed = sorted(p for p in set(a) & set(b) if a[p] != b[p]
                     and not (p == home_real and a[p][0] == b[p][0] and a[p][3] == b[p][3]))
    meta = sorted({p for p in added if re.fullmatch(re.escape(home_real) + r'/mixer_e0_queryb_\d{8}T\d{6}Z(_\d)?', p)})
    outside = [p for p in added if not any(p == m or p.startswith(m + '/') for m in meta)]
    return meta, outside, removed, changed


def calls(T, name):
    p = os.path.join(T, name + '.calls')
    return read(p).splitlines() if os.path.exists(p) else []


def common_exec(T, name, md5, expect_rc='0', expect_leak=()):
    exp = json.load(open(os.path.join(T, name, 'w', 'expect.json')))
    rc = read(os.path.join(T, name + '.rc')).strip()
    ok(rc == expect_rc, f'{name}: rc {rc} = {expect_rc}')
    meta, outside, removed, changed = new_dirs(T, name, exp['home_real'])
    ok(len(meta) == 1, f'{name}: 새 조회 폴더 정확히 1 개 ({len(meta)})')
    ok(not outside and not removed and not changed,
       f'{name}: 새 폴더 밖 변화 0 (추가 {len(outside)} · 삭제 {len(removed)} · 변경 {len(changed)}) {outside[:2]}{removed[:2]}{changed[:2]}')
    sent = os.path.join(T, name + '.sentinel')
    ok(not os.path.exists(sent), f'{name}: 금지 명령 (제출 · 취소 · 잡 제어 · 지우기 · 옮기기 · git · conda · python · sacct · lfs · ldd …) 호출 0 '
       + (read(sent).strip()[:200] if os.path.exists(sent) else ''))
    if len(meta) != 1:
        return None
    D = meta[0]
    nm = os.path.basename(D)
    for sub in ('raw', 'out', 'work'):
        ok(os.path.isdir(os.path.join(D, sub)), f'{name}: {sub}/ 있음')
    ok(oct(os.stat(D).st_mode & 0o777) == '0o700', f'{name}: 새 폴더 모드 700 (umask 077) {oct(os.stat(D).st_mode & 0o777)}')
    tgz = os.path.join(D, nm + '.tgz')
    ok(os.path.isfile(tgz) and os.path.isfile(tgz + '.sha256'), f'{name}: tgz · sha256 옆 파일')
    so = read(os.path.join(T, name + '.stdout'))
    m = re.search(r'sha256\s+([0-9a-f]{64})', so)
    out = os.path.join(D, 'out')
    if os.path.isfile(tgz):
        ok(m is not None and m.group(1) == sha(tgz), f'{name}: 화면 sha256 = tgz 실제 sha256')
        ok(read(tgz + '.sha256').split()[0] == sha(tgz), f'{name}: .sha256 파일 = tgz 실제 sha256')
        with tarfile.open(tgz, 'r:gz') as tf:
            mem = tf.getmembers()
        ok(all(x.name == 'out' or re.fullmatch(r'out/[^/]+', x.name) for x in mem), f'{name}: tgz 멤버 = out/ 바로 아래만 ({len(mem)})')
        ok(all(x.uname == '' and x.gname == '' and x.uid == 0 and x.gid == 0 for x in mem), f'{name}: tgz 소유자 이름 없음 · uid/gid 0')
        ok(all(x.isdir() or x.isfile() for x in mem), f'{name}: tgz 링크 · 장치 없음')
        ok({x.name[4:] for x in mem if x.isfile()} == set(os.listdir(out)), f'{name}: tgz 파일 = out/ 파일')
    qs = os.path.join(out, 'query_script.sh')
    ok(os.path.exists(qs) and hashlib.md5(read(qs, 'rb')).hexdigest() == md5, f'{name}: out/query_script.sh md5 = 게이트 md5')
    sums = (lines_of(os.path.join(out, 'SHA256SUMS')) or [])
    good = bool(sums) and all(sha(os.path.join(out, l.split('  ', 1)[1])) == l.split('  ', 1)[0] for l in sums if l.strip())
    ok(good and len(sums) == len(os.listdir(out)) - 1, f'{name}: out/SHA256SUMS 전수 대조 ({len(sums)})')
    rsums = (lines_of(os.path.join(out, 'RAW_SHA256SUMS')) or [])
    ok(bool(rsums) and all(sha(os.path.join(D, 'raw', l.split('  ', 1)[1])) == l.split('  ', 1)[0] for l in rsums if l.strip()),
       f'{name}: RAW_SHA256SUMS = raw/ 원문')
    ok(not any(l.split('  ', 1)[1].startswith('private_') for l in rsums if l.strip()), f'{name}: private_* 원문은 해시 목록에도 없음')
    ok(not any(f.startswith('private_') for f in os.listdir(out)), f'{name}: private_* 는 out/ 에 없음')
    forbid = [exp['home_login'], exp['home_real'], T] + FIXED_FORBID + exp['secrets']
    texts = {'stdout': so}
    for f in os.listdir(out):
        if f != 'query_script.sh':
            texts['out/' + f] = read(os.path.join(out, f), 'rb').decode('utf-8', 'replace')
    leaks = sorted((k, s) for k, t in texts.items() for s in forbid if s in t)
    if expect_leak:
        ok(leaks == sorted(expect_leak), f'{name}: 화면 · out/ 의 새는 문자열 = 기대한 것만 {leaks[:6]}')
    else:
        ok(not leaks, f'{name}: 화면 · out/ 에 경로 · 계정 · 호스트 · 노드 · 도메인 · 주소 · 경로 표지 · 덤프 · 로그 · conda · JSON · 금고 문자열 0 {leaks[:4]}')
    blob = b''
    for dp, dns, fns in os.walk(D):
        for fn in fns:
            if fn.endswith('.tgz'):
                continue
            blob += read(os.path.join(dp, fn), 'rb')
    inside = [s for s in exp['secrets'] if s.encode() in blob]
    ok(not inside, f'{name}: 새 폴더 어디에도 (raw/ · work/ 포함) 덤프 · 로그 · conda 파일 · JSON · 금고 내용 0 — 열어 옮기지 않았다 {inside[:4]}')
    post = kv(os.path.join(out, 'fields_post.txt'))
    if not expect_leak:
        ok(post.get('redaction.residual_token_hits') == ['0'], f'{name}: 가림 남은 토큰 0 ({post.get("redaction.residual_token_hits")})')
    pr = probes(os.path.join(D, 'raw', 'probes.txt'))
    ok(pr and all(c[1] in STATUSES for c in pr.values()), f'{name}: 조회 상태 어휘 {sorted({c[1] for c in pr.values()})}')
    for q in ('q9b', 'q2b', 'q7b', 'nodes'):
        ok(any(k == q or k.startswith(q + '_') for k in pr), f'{name}: {q} 의 상태 줄이 있다 (빠진 조회 없음)')
    return D, kv(os.path.join(D, 'raw', 'fields.txt')), pr, so, exp


def frame_line(f):
    return ('frame|pos=%s|step=%s|type=%s|bytes=%s|end_nl=%s|newlines=%s|l1_timestep=%s|tstep=%s|l3_natoms=%s|atoms=%s|nl_eq_9_plus_atoms=%s'
            % (f['pos'], f['step'], f['type'], f['bytes'], f['end_nl'], f['newlines'], f['l1_timestep'], f['tstep'], f['l3_natoms'],
               f['atoms'], f['nl_eq_9_plus_atoms']))


def q7b_sum_lines(k, e):
    out = ['pkg|%s|name=%s|json=%s|matches=%d' % (k, e['name'], e['json'] if e.get('status') != 'ABSENT' else '-', 0 if e.get('status') == 'ABSENT' else 1)]
    if e.get('status') == 'ABSENT':
        return out
    out.append('json|%s|%s' % (k, e['json_hash']))
    if e.get('status') == 'PARSE_BAD':
        return out + ['<parse 줄 · OK 꼴 아님>']
    out.append('parse|%s|elements=%d|escaped=%d|files_keys=1|depth_end=0|instr_end=0|bad=0' % (k, e['listed'], e['escaped']))
    rs = ';'.join('%s:%d' % (c, e['reasons'][c]) for c in sorted(e['reasons'])) or '-'
    out.append('sum|%s|listed=%d|in_list=%d|over_cap=%d|hashed=%d|bytes_hashed=%d|links=%d|reasons=%s'
               % (k, e['listed'], e['in_list'], e['over_cap'], e['hashed'], e['bytes_hashed'], e['links'], rs))
    out.append('digest|%s|%s|lines=%d' % (k, e['digest'], e['digest_lines']))
    return out


def check_q9b(name, D, pr, exp, which=None):
    out = os.path.join(D, 'out')
    for i, lg in sorted(exp['q9b']['logs'].items(), key=lambda x: int(x[0])):
        if which and i not in which:
            continue
        stv = st(pr, 'q9b_l' + i)
        if lg['status'] in ('OK', 'TRUNC'):
            ok(stv == 'OK', f'{name}: q9b l{i} ({lg["run"]}) 상태 OK ({stv})')
            got = lines_of(os.path.join(out, 'q9b_l%s.txt' % i))
            ok(got == lg['lines'], f'{name}: q9b l{i} 줄 = 기대 (로그 · 표 · 비-행 줄 순서 · 자리 · 앞 공백 · 가린 첫 낱말) {len(got or [])}/{len(lg["lines"])}'
               + ('' if got == lg['lines'] else ' 첫 차이 ' + str(next(((a, b) for a, b in zip(got or [], lg['lines']) if a != b), None))))
            ok(got is not None and all(re.fullmatch('(%s|%s|%s)' % (LOG_RE, TAB_RE, NR_RE), l) for l in got),
               f'{name}: q9b l{i} 출력 줄 꼴 = 센 수 · 가린 첫 낱말만 (숫자 값 · 본문 없음)')
            cap = st(pr, 'q9b_l%s_cap' % i)
            ok(cap == ('TRUNC' if lg['status'] == 'TRUNC' else 'ABSENT_LINE'), f'{name}: q9b l{i} 넘침 표지 ({cap})')
        else:
            ok(stv == lg['status'], f'{name}: q9b l{i} ({lg["run"]}) 상태 {lg["status"]} ({stv})')


def check_q2b(name, D, pr, exp):
    out = os.path.join(D, 'out')
    pick = lines_of(os.path.join(out, 'q2b_pick.txt'))
    h, s = exp['q2b']['head'], exp['q2b']['sel']
    want = ['q2b|run=E0_ref_s32452843|files=%d|matched=%d|sorted=%d|other=%d|noise=0' % (h['files'], h['matched'], h['matched'], h['other']),
            'sel|first|' + s['first'], 'sel|mid|' + s['mid'], 'sel|last|' + s['last']]
    ok(pick == want, f'{name}: q2b 이름만으로 고름 (처음 · 가운데 · 끝) = 기대 {pick}')
    got = lines_of(os.path.join(out, 'q2b_frames.txt'))
    wantf = [frame_line(f) for f in exp['q2b']['frames']]
    ok(got == wantf, f'{name}: q2b 프레임 셋 (끝 개행 · 개행 수 · TIMESTEP 꼴 · 원자 수) = 기대' + ('' if got == wantf else f' {got} / {wantf}'))


def check_q7b(name, D, pr, exp, which=None):
    out = os.path.join(D, 'out')
    for k, e in sorted(exp['q7b']['pkgs'].items(), key=lambda x: int(x[0])):
        if which and k not in which:
            continue
        got = lines_of(os.path.join(out, 'q7b_p%s_sum.txt' % k))
        want = q7b_sum_lines(k, e)
        if want[-1] == '<parse 줄 · OK 꼴 아님>' and got and len(got) == len(want) and re.fullmatch(r'parse\|%s\|elements=\d+\|escaped=\d+\|files_keys=\d+\|depth_end=\d+\|instr_end=\d+\|bad=\d+' % k, got[-1])                 and not got[-1].endswith('|files_keys=1|depth_end=0|instr_end=0|bad=0'):
            want = want[:-1] + [got[-1]]
        ok(got == want, f'{name}: q7b p{k} {e["name"]} 요약 (JSON 이름 · 해시 · 해석 · 수 · 사유 · 다이제스트) = 기대' + ('' if got == want else f' {got} / {want}'))
        if e.get('status') in ('OK', 'FAIL', 'TRUNC'):
            gf = lines_of(os.path.join(out, 'q7b_p%s_files.txt' % k))
            ok(gf == e['files_lines'], f'{name}: q7b p{k} 파일마다 (번호 · 종류 · 시각 · 크기 · sha256 · 사유) = 기대 {len(gf or [])}/{len(e["files_lines"])}'
               + ('' if gf == e['files_lines'] else ' 첫 차이 ' + str(next(((a, b) for a, b in zip(gf or [], e['files_lines']) if a != b), None))))
            ok(gf is not None and all(re.fullmatch(r'f\|\d+\|[-felod]\|[-\d]+\|[-felod]\|[-\d]+\|[-\d]+\|([0-9a-f]{64}|[A-Z_]+)', l) for l in gf),
               f'{name}: q7b p{k} 출력 줄 꼴 = 번호 · 종류 · 수 · sha256 · 사유만 (경로 문자열 없음)')
            want_st = 'OK' if not e['reasons'] else 'FAIL'
            ok(st(pr, 'q7b_p%s_files' % k) == want_st, f"{name}: q7b p{k} 파일 상태 {want_st} ({st(pr, 'q7b_p%s_files' % k)})")
            ok(st(pr, 'q7b_p%s_cap' % k) == ('TRUNC' if e['status'] == 'TRUNC' else 'ABSENT_LINE'), f'{name}: q7b p{k} 목록 상한 표지')
        elif e.get('status') == 'ABSENT':
            ok(st(pr, 'q7b_p%s_json' % k) == 'ABSENT', f'{name}: q7b p{k} JSON 없음 → ABSENT')
        elif e.get('status') == 'PARSE_BAD':
            ok(st(pr, 'q7b_p%s_parse_ok' % k) == 'FAIL' and not os.path.exists(os.path.join(out, 'q7b_p%s_files.txt' % k)),
               f'{name}: q7b p{k} 깨진 JSON → 해석 FAIL · 해시 안 함')


def check_full(name, D, f, pr, exp):
    check_q9b(name, D, pr, exp)
    check_q2b(name, D, pr, exp)
    check_q7b(name, D, pr, exp)
    ok(all(st(pr, k) == 'OK' for k in pr if k.startswith(('q9b', 'q2b', 'q7b'))), f'{name}: q9b · q2b · q7b 상태 전부 OK '
       + str(sorted(k + ':' + c[1] for k, c in pr.items() if k.startswith(('q9b', 'q2b', 'q7b')) and c[1] != 'OK')[:6]))
    ok(st(pr, 'nodes_sinfo') == 'OK' and f.get('redaction.node_tokens') == ['4'], f"{name}: 노드 이름 sinfo OK · 노드 토큰 4 (중복 · 1 글자 · 공백 든 이름 뺌) {f.get('redaction.node_tokens')}")
    ok(f.get('q7b.env') == [exp['home_login'] + '/.conda/envs/myenv'], f'{name}: q7b 환경 = 로그인 홈 꼴')


def run_reader(T, tag, tgz, dest, md5, sha256, extra=()):
    try:
        p = subprocess.run([sys.executable, '-I', READER, tgz, dest, '--expect-md5', md5, '--expect-sha256', sha256, *extra],
                           capture_output=True, text=True, timeout=120)
        out, rc = p.stdout + p.stderr, p.returncode
    except Exception as ex:   # 판독기 없음 등
        out, rc = repr(ex), -1
    with open(os.path.join(T, 'reader_' + tag + '.txt'), 'w') as fo:
        fo.write(out)
    return rc, out


def bundle_of(T, name, home_real):
    meta = new_dirs(T, name, home_real)[0]
    if not meta:
        return None, None
    D = meta[0]
    tgz = os.path.join(D, os.path.basename(D) + '.tgz')
    if not os.path.exists(tgz + '.sha256'):
        return None, None
    return tgz, read(tgz + '.sha256').split()[0]


def repack(src, dst, mutate):
    with tarfile.open(src, 'r:gz') as tf:
        items = [(m.name, tf.extractfile(m).read() if m.isfile() else None, m) for m in tf.getmembers()]
    with tarfile.open(dst, 'w:gz') as to:
        for name, data, m in items:
            for nn, nd, kind in mutate(name, data):
                ti = tarfile.TarInfo(nn)
                ti.uid = ti.gid = 0
                ti.uname = ti.gname = ''
                if kind == 'dir':
                    ti.type = tarfile.DIRTYPE
                    ti.mode = 0o700
                    to.addfile(ti)
                elif kind == 'sym':
                    ti.type = tarfile.SYMTYPE
                    ti.linkname = nd
                    to.addfile(ti)
                else:
                    ti.size = len(nd)
                    ti.mode = 0o600
                    to.addfile(ti, io.BytesIO(nd))


def exp_of(T, n):
    return json.load(open(os.path.join(T, n, 'w', 'expect.json')))


def main():
    global T_GLOBAL
    if sys.argv[1] == 'snap':
        json.dump(snap(sys.argv[2:]), sys.stdout)
        return 0
    T, md5 = sys.argv[2:4]
    T_GLOBAL = T

    def tsecs(n):
        try:
            return float(read(os.path.join(T, n + '.secs')).strip())
        except OSError:
            return 1e9

    # 빌드 일관성
    blkp = os.environ.get('QB_BLOCK') or os.path.join(QB, 'query_block_b.txt')
    blk = read(blkp) if os.path.exists(blkp) else ''
    bl = blk.splitlines() or ['']
    h1 = re.search(r'스크립트 md5 ([0-9a-f]{32})', bl[0])
    gate = re.search(r'= ([0-9a-f]{32}) \]', bl[-1])
    src = hashlib.md5(read(SRC, 'rb')).hexdigest() if os.path.exists(SRC) else None
    ok(bool(h1 and gate and h1.group(1) == gate.group(1) == src == md5), f'빌드: 블록 머리 md5 = 마지막 줄 게이트 md5 = src md5 = {md5}')
    ok(bool(blk) and blk.count('!') == 0 and '\t' not in blk and '\r' not in blk and not re.search(r'^\^', blk, re.M), '빌드: 블록에 느낌표 · 탭 · CR · 줄 첫 ^ 없음')
    ok(bool(blk) and len(blk.encode()) < 120000 and blk.endswith('\n'), f'빌드: 블록 크기 {len(blk.encode())} B < 120000 · 끝 개행')

    res = {}
    # t1 · t2 (전부 · mawk / gawk) · t10 (ibb 경로 관계) · t8c (대화형) · t13 (ucx 하나 바뀜)
    for n in ('t1', 't2', 't10', 't8c', 't13'):
        r = common_exec(T, n, md5)
        if r:
            D, f, pr, so, exp = r
            res[n] = D
            check_full(n, D, f, pr, exp)
            ok(tsecs(n) < 60, f'{n}: 걸린 시간 {tsecs(n):.1f} 초 < 60')
            ok('q9b · q2b · q7b 시작' in so and '가져올 파일' in so and so.count('\n') <= 16 and '⚠' not in so, f'{n}: 화면 = 시작 · 조회별 상태 · 가림 · 가져올 파일 줄 · 경고 없음 ({so.count(chr(10))} 줄)')
    if 't1' in res:
        ok('mawk' in kv(os.path.join(res['t1'], 'raw', 'fields.txt')).get('awk_version', [''])[0], 't1: awk = mawk (컨테이너 기본)')
    if 't2' in res:
        ok('GNU Awk' in kv(os.path.join(res['t2'], 'raw', 'fields.txt')).get('awk_version', [''])[0], 't2: awk = GNU Awk (ibb 와 같은 종류)')
    if 't1' in res and 't2' in res:
        diffs = [fn for fn in sorted(os.listdir(os.path.join(res['t1'], 'out'))) if re.fullmatch(r'q(9b|2b|7b)_.*\.txt', fn)
                 and read(os.path.join(res['t1'], 'out', fn)) != read(os.path.join(res['t2'], 'out', fn))]
        ok(not diffs, f't1 ↔ t2: mawk 와 gawk 의 조회 출력이 바이트 같다 (q9b · q2b · q7b) {diffs}')
    if 't10' in res:
        f10 = kv(os.path.join(res['t10'], 'out', 'fields.txt'))
        ok(f10.get('q7b.env_real') == ['<HOME_REAL>/.conda/envs/myenv'] and f10.get('q7b.env') == ['<HOME>/.conda/envs/myenv']
           and '/lustre<HOME>' not in read(os.path.join(res['t10'], 'out', 'fields.txt')),
           f"t10: 실제 경로 = <HOME_REAL> · 로그인 경로 = <HOME> (긴 실제 홈을 먼저 가림) {f10.get('q7b.env_real')}")

    # t3 실패 섞기
    r = common_exec(T, 't3', md5)
    if r:
        D, f, pr, so, exp = r
        check_q9b('t3', D, pr, exp)
        check_q2b('t3', D, pr, exp)
        check_q7b('t3', D, pr, exp)
        ok(st(pr, 'q9b_l3') == 'FAIL' and 'Permission denied' in (read(os.path.join(D, 'out', 'q9b_l3.txt')) if os.path.exists(os.path.join(D, 'out', 'q9b_l3.txt')) else ''),
           't3: 읽기 권한 없는 로그 → FAIL (awk 의 Permission denied · 경로는 가림)')
        ok(f.get('q9b.l4.stat', [''])[0].startswith('d|'), f"t3: log.liggghts 가 디렉터리 → 읽지 않음 ({f.get('q9b.l4.stat')})")
        ok(all(st(pr, 'q2b_mid_' + x) == 'FAIL' for x in ('head', 'tail', 'wc')), 't3: 권한 없는 가운데 프레임 → head · tail · wc FAIL')
        ok(st(pr, 'nodes_sinfo') == 'FAIL' and f.get('redaction.node_tokens') == ['0'], f"t3: sinfo 실패 → 노드 토큰 0 · 기록 ({st(pr, 'nodes_sinfo')})")
        ok('FAIL' in so and 'ABSENT' in so and 'DENIED' in so, 't3: 화면에 FAIL · ABSENT · DENIED 가 보인다')
        ok('노드 이름  ⚠ 가림 목록 0 개' in so, 't3: sinfo 실패 → 화면에 노드 가림 목록 0 개 경고')
        ok(tsecs('t3') < 60, f"t3: 걸린 시간 {tsecs('t3'):.1f} 초 < 60")

    # t4 멈춘 명령
    r = common_exec(T, 't4', md5)
    if r:
        D, f, pr, so, exp = r
        c = pr.get('q7b_p1_hash', [])
        ok(st(pr, 'q7b_p1_hash') == 'TIMEOUT' and len(c) > 3 and 120 <= int(c[3]) <= 135, f't4: openmpi 묶음 해시 = TIMEOUT · {c[3] if len(c) > 3 else "?"} 초 (120 + kill 5 안)')
        gf = lines_of(os.path.join(D, 'out', 'q7b_p1_files.txt')) or []
        ok(gf and all(l.endswith('|STOPPED') for l in gf if '|f|' in l or '|l|' in l or '|e|' in l), f't4: 멈춘 묶음의 파일 = 사유 STOPPED (0 · 빈 값으로 읽지 않음) {gf[:2]}')
        ok(all(st(pr, 'q7b_p%d_files' % k) == 'OK' for k in (2, 3, 5)) and st(pr, 'q7b_p1_files') == 'FAIL', 't4: 다른 꾸러미는 OK · openmpi 만 FAIL')
        c2 = pr.get('q2b_first_head', [])
        ok(st(pr, 'q2b_first_head') == 'TIMEOUT' and len(c2) > 3 and 30 <= int(c2[3]) <= 40, f't4: 첫 프레임 머리 읽기 = TIMEOUT {c2[3] if len(c2) > 3 else "?"} 초')
        fr = lines_of(os.path.join(D, 'out', 'q2b_frames.txt')) or ['']
        ok(fr[0].startswith('frame|pos=first|step=1000|type=f|') and '|end_nl=yes|newlines=59|l1_timestep=-|tstep=-|l3_natoms=-|atoms=-|nl_eq_9_plus_atoms=-' in fr[0],
           f't4: 머리를 못 읽은 프레임 = 끝 개행 · 개행 수만 · 나머지 "-" {fr[0]}')
        check_q9b('t4', D, pr, exp)
        ok(tsecs('t4') < 240, f"t4: 전체 {tsecs('t4'):.1f} 초 < 240")
        ok(read(os.path.join(T, 't4.leftover')).strip() == '0', f"t4: 끝난 뒤 남은 가짜 sha256sum · head · sleep 프로세스 0 ({read(os.path.join(T, 't4.leftover')).strip()})")

    # t5 예산
    r = common_exec(T, 't5', md5)
    if r:
        D, f, pr, so, exp = r
        q = {k: c[1] for k, c in pr.items() if k.startswith(('q9b', 'q2b', 'q7b'))}
        ok(q and all(v == 'SKIPPED_BUDGET' for v in q.values()), f't5: 예산 2 초 · 노드 sinfo 3 초 → 조회 셋 다 SKIPPED_BUDGET ({len(q)}) · 묶음은 만듦')
        ok(tsecs('t5') < 30, f"t5: 전체 {tsecs('t5'):.1f} 초 < 30")
        ok(f.get('budget_seconds') == ['2'] and f.get('pack_deadline_seconds') == ['302'], 't5: 예산 · 묶음 상한 칸 기록')

    # t6 MIX_Q=q7b
    r = common_exec(T, 't6', md5)
    if r:
        D, f, pr, so, exp = r
        ok(st(pr, 'q9b') == 'SKIPPED_SWITCH' and st(pr, 'q2b') == 'SKIPPED_SWITCH' and not any(k.startswith(('q9b_', 'q2b_')) for k in pr),
           't6: MIX_Q=q7b → q9b · q2b SKIPPED_SWITCH (아무것도 안 읽음)')
        check_q7b('t6', D, pr, exp)

    # t7 줄 수 넘침
    r = common_exec(T, 't7', md5)
    if r:
        D, f, pr, so, exp = r
        check_q9b('t7', D, pr, exp)
        check_q7b('t7', D, pr, exp)
        g = lines_of(os.path.join(D, 'out', 'q9b_l2.txt')) or ['']
        ok(g[0].endswith('|nonrow=1002|emitted=300|suppressed=702|tables_suppressed=0|cr=0') and len(g) == 1 + 4 + 300,
           f't7: 비-행 줄 1002 → 300 줄만 옮기고 넘친 수 기록 {g[0]}')
        g1 = lines_of(os.path.join(D, 'out', 'q9b_l1.txt')) or ['']
        ok(re.fullmatch(r'log\|1\|lines=(\d+)\|.*\|cr=\1', g1[0]) is not None, f't7: CRLF 로그 = 모든 줄 CR 기록 · 표 · 비-행 줄은 그대로 {g1[0]}')
        s3 = lines_of(os.path.join(D, 'out', 'q7b_p3_sum.txt')) or []
        ok(any(l.startswith('sum|3|listed=16000|in_list=15000|over_cap=1000|') for l in s3), 't7: 목록 16000 → 15000 까지 · 넘친 수 기록')
        ok(os.path.getsize(os.path.join(D, 'out', 'q7b_p3_files.txt')) < 4 * 1024 * 1024, 't7: 출력 크기 < 4 MB 상한')
        ok('TRUNC' in so, 't7: 화면에 TRUNC 가 보인다')

    # t12a 가림 실패 (남은 토큰) · t12b 가림 단계 실패
    r = common_exec(T, 't12a', md5, expect_leak=(('out/q7b_p7_sum.txt', 'fakeuser'),))
    if r:
        D, f, pr, so, exp = r
        check_q9b('t12a', D, pr, exp)
        post = kv(os.path.join(D, 'out', 'fields_post.txt'))
        ok(post.get('redaction.residual_token_hits', ['0'])[0] not in ('0', ''), f"t12a: 남은 토큰 > 0 기록 ({post.get('redaction.residual_token_hits')})")
        ok('⚠' in so and '넘기지 말 것' in so, 't12a: 화면 경고 (넘기지 말 것)')
        g = lines_of(os.path.join(D, 'out', 'q9b_l1.txt')) or []
        ok(not any('fakeuser' in l or 'SECRET' in l or 'example' in l for l in g), 't12a: 첫 낱말에 붙은 계정 · 노드 · 도메인은 가려짐 (<USER>X: · <NODE>x: · <NODE>.<DOMAIN>:)')
    r = common_exec(T, 't12b', md5)
    if r:
        D, f, pr, so, exp = r
        post = kv(os.path.join(D, 'out', 'fields_post.txt'))
        ok(len(post.get('redact_fail', [])) >= 10 and not any(fn.startswith(('q9b', 'q2b', 'q7b', 'fields.txt', 'probes')) for fn in os.listdir(os.path.join(D, 'out'))),
           f"t12b: 가림 awk 실패 → 가리지 못한 파일은 out/ 에 없음 · redact_fail {len(post.get('redact_fail', []))} 줄")
        ok('⚠' in so and '가림 못 한 파일' in so, 't12b: 화면 경고 (가림 못 한 파일)')

    # t14 빈 세계
    r = common_exec(T, 't14', md5)
    if r:
        D, f, pr, so, exp = r
        check_q9b('t14', D, pr, exp)
        pick = lines_of(os.path.join(D, 'out', 'q2b_pick.txt')) or []
        ok(st(pr, 'q2b_names') == 'FAIL' and pick == ['q2b|run=E0_ref_s32452843|files=0|matched=0|sorted=0|other=0|noise=1']
           and (lines_of(os.path.join(D, 'out', 'q2b_frames.txt')) == []), f't14: post 없음 → q2b_names FAIL · 고른 프레임 0 (find 오류 문구를 이름으로 세지 않음) {pick}')
        ok(st(pr, 'q7b_env') == 'ABSENT' and not any(k.startswith('q7b_p') for k in pr), 't14: conda 환경 없음 → q7b_env ABSENT · 꾸러미 조회 안 함')
        e14 = exp
        tg, sh = bundle_of(T, 't14', e14['home_real'])
        rc, so2 = run_reader(T, 'r14', tg or '/nonexistent', os.path.join(T, 'read_t14'), md5, sh or '0' * 64)
        ok(rc == 0, f'reader r14 (t14): rc {rc} (없는 것뿐이어도 묶음 구조는 정상)')

    # t9 Ctrl-C
    r = common_exec(T, 't9', md5)
    if r:
        D, f, pr, so, exp = r
        sig = read(os.path.join(T, 't9.signalled')).strip()
        ni = sum(1 for c in pr.values() if c[1] == 'SKIPPED_INTERRUPT')
        ok(sig.isdigit() and f.get('interrupted') == ['1'] and ni >= 3 and all(c[1] in ('OK', 'SKIPPED_INTERRUPT') for k, c in pr.items() if k.startswith(('q9b', 'q2b', 'q7b'))),
           f't9: SIGINT (pid {sig}) → interrupted=1 · 남은 조회 SKIPPED_INTERRUPT {ni} 개 (그 전에 끝난 것만 OK)')
        ok('Ctrl-C 로 멈춤' in so and '가져올 파일' in so, 't9: 화면에 멈춤 알림 · 묶음은 만듦')
        ok(tsecs('t9') < 15, f"t9: 전체 {tsecs('t9'):.1f} 초 < 15 (멈추지 않으면 25 초 이상)")

    # t8 게이트
    for n in ('t8a', 't8b'):
        e = exp_of(T, n)
        meta, outside, removed, changed = new_dirs(T, n, e['home_real'])
        ok(not meta and not outside and not removed and not changed, f'{n}: 게이트 — 아무것도 안 만듦 (새 {len(meta) + len(outside)} · 변경 {len(changed)})')
        ok(not os.path.exists(os.path.join(T, n + '.sentinel')) and not calls(T, n), f'{n}: 명령 호출 0')
    ok('아무것도 안 함' in read(os.path.join(T, 't8a.stdout')), 't8a: 한 글자 깨짐 = "md5 다름 — 아무것도 안 함"')
    ok(read(os.path.join(T, 't8d.cmp')).strip() == 'same', 't8d: CRLF 사본을 DEM1 의 sed 로 고치면 원본 바이트와 같다')

    # t11 실제 로그 꼴 (리포 읽기만) — 블록 본문의 가림 함수 + q9b awk 를 그대로 꺼내 mawk · gawk 로
    repo = os.environ.get('QB_REPO', '/home/user/Yonghoon-DEM-DFT')
    srct = read(SRC) if os.path.exists(SRC) else ''
    m1 = re.search(r"^AWK_REDLIB='(.*?)'$", srct, re.S | re.M)
    m2 = re.search(r"^AWK_Q9B_MAIN='(.*?)'$", srct, re.S | re.M)
    prog = (m1.group(1) + m2.group(1)) if (m1 and m2) else None
    ok(prog is not None, 't11: 블록 본문에서 가림 함수 · q9b awk 를 꺼냄')
    logs = {'ins1': 'docs/data/kg50_d07_end_20261105/kg50_d07_b50_log_ins1.liggghts',
            'exact': 'docs/data/mixer_highbo_devu_prelim_20261006/exact_runs/exact_LU212_settled/log.exact',
            'main1103': 'docs/data/kg50_d07_end_20261105/kg50_d07_b50_log_main1103.liggghts'}
    got = {}
    for k, rel in logs.items():
        p = os.path.join(repo, rel)
        if prog is None or not os.path.isfile(p):
            ok(False, f't11 {k}: 실행 못 함 (프로그램 · 리포 로그)')
            continue
        outs = []
        for aw in ('mawk', 'gawk'):
            rr = subprocess.run([aw, '-v', 'li=1', prog, p], capture_output=True, text=True, timeout=60, env={'LC_ALL': 'C', 'PATH': '/usr/bin:/bin'})
            outs.append(rr.stdout)
        got[k] = outs[0]
        ok(outs[0] == outs[1] and outs[0], f't11 {k}: 실제 로그에서 mawk = gawk (바이트 · {len(outs[0].splitlines())} 줄)')
        ok(all(re.fullmatch('(%s|%s|%s)' % (LOG_RE, TAB_RE, NR_RE), l) for l in outs[0].splitlines()), f't11 {k}: 출력 = 센 수 · 가린 첫 낱말만')
    if 'ins1' in got:
        g = got['ins1'].splitlines()
        ok(g[0].startswith('log|1|lines=260|tables=3|nonrow=2|') and 'nr|1|1|1|rows_before=1|sp=0|tab=0|word=INFO:' in g
           and 'nr|1|1|2|rows_before=1|sp=1|tab=0|word=-' in g and g.index('nr|1|1|1|rows_before=1|sp=0|tab=0|word=INFO:') + 1 == g.index('nr|1|1|2|rows_before=1|sp=1|tab=0|word=-'),
           't11 ins1: 삽입 표 1 = INFO (앞 공백 0) 다음 " - a total" (앞 공백 1) · 둘 다 첫 행 뒤 (등록 7-6 허용 꼴 ③ 의 1 프로세스 실물)')
    if 'exact' in got:
        ok(got['exact'].splitlines() == ['log|1|lines=86|tables=1|nonrow=0|emitted=0|suppressed=0|tables_suppressed=0|cr=0',
                                         'table|1|1|header_cols=5|rows=1|rows_nonfinite=0|row_cols=5:1|nonrow=0|blank=0|closed=yes'],
           't11 exact: 5 칸 머리 · 숫자 줄 1 · 비-행 0 · 닫힘')
    if 'main1103' in got:
        ok(got['main1103'].splitlines()[0].startswith('log|1|lines=8032|tables=210|'), f"t11 main1103: 210 표 ({got['main1103'].splitlines()[0][:60]})")

    # 판독기
    exp1 = exp_of(T, 't1')
    tgz1, sha1 = bundle_of(T, 't1', exp1['home_real'])
    j1 = os.path.join(T, 'read_t1.json')
    rc, so = run_reader(T, 'r1', tgz1 or '/nonexistent', os.path.join(T, 'read_t1'), md5, sha1 or '0' * 64, ('--json', j1))
    ok(rc == 0, f'reader r1 (t1): rc {rc}')
    S = json.load(open(j1)) if os.path.exists(j1) else {}
    q9 = S.get('q9b', {})
    ok(q9.get('n_logs_read') == 9 and q9.get('n_logs_clean') == 9, f"reader r1: q9b 로그 9 읽음 · 허용 꼴 ③ 밖 0 인 로그 9 {q9.get('n_logs_read')} · {q9.get('n_logs_clean')}")
    lg = q9.get('logs', {})
    ok(lg.get('1', {}).get('pair_tables') == [1] and lg.get('6', {}).get('pair_tables') == [1, 3] and lg.get('6', {}).get('pair_tables_vs_deck') == 'same',
       'reader r1: 보고 쌍이 놓인 표 = E0 [1] · dev-bo [1, 3] = 덱 기대와 같음')
    q2 = S.get('q2b', {})
    ok(q2.get('c3_premise_all3') is True, f"reader r1: q2b 세 장 다 끝 개행 · 개행 수 = 9 + 원자 수 · TIMESTEP = 이름 step ({q2.get('c3_premise_all3')})")
    q7 = S.get('q7b', {})
    ok(q7.get('n_pkgs_ok') == 7 and all(p.get('json_vs_1110') == 'same' for p in q7.get('pkgs', {}).values()) and q7.get('n_hashed_total') == sum(
        e.get('hashed', 0) for e in exp1['q7b']['pkgs'].values()), f"reader r1: q7b 꾸러미 7 OK · JSON 이름 = 11-10 목록 · 해시 수 {q7.get('n_hashed_total')}")
    fb = os.path.join(T, 'forbid_none.txt')
    with open(fb, 'w') as fo:
        fo.write('\n'.join(['fakeuser', 'SECRET-LOGIN-HOST', 'SECRET-NODE01', exp1['home_real'], exp1['home_login']]) + '\n')
    rc, so = run_reader(T, 'r1f', tgz1 or '/nonexistent', os.path.join(T, 'read_t1f'), md5, sha1 or '0' * 64, ('--forbid-file', fb))
    ok(rc == 0 and '나온 곳 0' in so, 'reader --forbid-file (계정 · 호스트 · 노드 · 홈 경로) = 0 곳 · rc 0')
    fb2 = os.path.join(T, 'forbid_hit.txt')
    with open(fb2, 'w') as fo:
        fo.write('E0_ref_s32452843\n')
    rc, so = run_reader(T, 'r1h', tgz1 or '/nonexistent', os.path.join(T, 'read_t1h'), md5, sha1 or '0' * 64, ('--forbid-file', fb2))
    ok(rc == 1 and '금지 문자열이 나옴' in so, 'reader --forbid-file 이 있는 문자열을 잡는다 (rc 1)')
    rc, so = run_reader(T, 'r_wrongsha', tgz1 or '/nonexistent', os.path.join(T, 'read_wrongsha'), md5, '0' * 64)
    ok(rc == 1 and '화면 값과 다름' in so, 'reader: 화면 sha256 다름 → rc 1')
    rc, so = run_reader(T, 'r_wrongmd5', tgz1 or '/nonexistent', os.path.join(T, 'read_wrongmd5'), 'f' * 32, sha1 or '0' * 64)
    ok(rc == 1 and 'md5' in so, 'reader: 블록 md5 다름 → rc 1')
    os.makedirs(os.path.join(T, 'read_nonempty'), exist_ok=True)
    with open(os.path.join(T, 'read_nonempty', 'x'), 'w') as fo:
        fo.write('x')
    rc, so = run_reader(T, 'r_nonempty', tgz1 or '/nonexistent', os.path.join(T, 'read_nonempty'), md5, sha1 or '0' * 64)
    ok(rc == 2, f'reader: 비어 있지 않은 풀 폴더 → 거부 rc {rc}')
    if tgz1:
        bad1 = os.path.join(T, 'tampered.tgz')
        repack(tgz1, bad1, lambda n, d: [(n, d, 'dir' if d is None else 'file')] if n != 'out/q2b_frames.txt' else [(n, d.replace(b'end_nl=yes', b'end_nl=no', 1), 'file')])
        rc, so = run_reader(T, 'r_tamper', bad1, os.path.join(T, 'read_tamper'), md5, sha(bad1))
        ok(rc == 1 and 'sha256 불일치: q2b_frames.txt' in so, 'reader: 묶음 안 파일 한 글자 바뀜 → SHA256SUMS 불일치 rc 1')
        bad2 = os.path.join(T, 'evil.tgz')
        repack(tgz1, bad2, lambda n, d: [(n, d, 'dir' if d is None else 'file')] + ([('out/../evil.txt', b'EVIL', 'file'), ('out/link', '/etc/passwd', 'sym'),
                                                                                     ('out/sub/x.txt', b'x', 'file')] if n == 'out' else []))
        rc, so = run_reader(T, 'r_evil', bad2, os.path.join(T, 'read_evil'), md5, sha(bad2))
        ok(rc == 1 and '멤버 이름 거부' in so and '정규 파일 아님' in so and not os.path.exists(os.path.join(T, 'evil.txt'))
           and not os.path.exists(os.path.join(T, 'read_evil', 'out', 'link')) and not os.path.exists(os.path.join(T, 'read_evil', 'out', 'sub')),
           'reader: ".." · 링크 · 하위 폴더 멤버 거부 · 밖에 쓰지 않음 (rc 1)')
        bad3 = os.path.join(T, 'badline.tgz')

        def inject(n, d):
            if d is None:
                return [(n, d, 'dir')]
            if n == 'out/q9b_l1.txt':
                d = d + b'nr|1|1|9|rows_before=1|sp=0|tab=0|word=INFO: inserted 42424242\n'
            return [(n, d, 'file')]
        repack(tgz1, bad3, inject)
        # SHA256SUMS 도 맞춰 다시 쓴 위조 (내용 꼴 검사만으로 잡아야 한다)
        with tarfile.open(bad3, 'r:gz') as tf:
            items = {m.name: (tf.extractfile(m).read() if m.isfile() else None) for m in tf.getmembers()}
        sums = ''.join('%s  %s\n' % (hashlib.sha256(v).hexdigest(), k[4:]) for k, v in sorted(items.items()) if v is not None and k != 'out/SHA256SUMS')
        repack(bad3, bad3 + '.2', lambda n, d: [(n, d, 'dir' if d is None else 'file')] if n != 'out/SHA256SUMS' else [(n, sums.encode(), 'file')])
        rc, so = run_reader(T, 'r_badline', bad3 + '.2', os.path.join(T, 'read_badline'), md5, sha(bad3 + '.2'))
        ok(rc == 1 and '꼴 밖 줄' in so, 'reader: q9b 줄 꼴 밖 (본문 · 숫자가 섞인 줄) → rc 1 (SHA256SUMS 를 맞춰도)')
    # 실패 · 넘침 · 가림 실패 묶음
    for n, tag, want in (('t3', 'r3', 0), ('t7', 'r7', 0), ('t6', 'r6', 0), ('t12a', 'r12a', 1), ('t12b', 'r12b', 1), ('t2', 'r2', 0)):
        e = exp_of(T, n)
        tg, sh = bundle_of(T, n, e['home_real'])
        jj = os.path.join(T, 'read_%s.json' % n)
        extra = ('--json', jj) + (('--q7b-ref', j1) if n in ('t2', 't3') else ())
        rc, so = run_reader(T, tag, tg or '/nonexistent', os.path.join(T, 'read_' + n), md5, sh or '0' * 64, extra)
        ok(rc == want, f'reader {tag} ({n}): rc {rc} = {want}')
        if n == 't3' and os.path.exists(jj):
            S3 = json.load(open(jj))
            l3 = S3['q9b']['logs']
            ok(l3['2']['outside_lines'] == 1 and l3['5']['outside_lines'] == 2 and l3['6']['pair_tables'] == [1] and l3['6']['outside_lines'] == 3
               and l3['6']['unclosed_tables'] == [4] and l3['6']['outside_words'] == ['-', 'INFO:', 'Total']
               and l3['1']['clean'] is True and S3['q9b']['n_logs_read'] == 4 and S3['q9b']['n_logs_clean'] == 1,
               'reader r3: 허용 꼴 ③ 밖 = WARNING 1 (l2) · 앞 공백 어긋남 (l5) · 자리 어긋남 + 닫히지 않은 표의 뒤 줄 (l6) 를 잡음 · 읽은 로그 4 · 깨끗한 로그 1')
            p3 = S3['q7b']['pkgs']
            ok(p3['2']['reasons'] == {'BROKEN': 1, 'HASH_FAIL': 1, 'NO_LSTAT': 2, 'TOO_BIG': 1} and p3['6']['status'] == 'ABSENT' and p3['7']['status'] == 'PARSE_BAD'
               and p3['3']['reasons'] == {'ESCAPED': 1, 'UNSAFE_PATH': 2}, 'reader r3: q7b 사유 (깨진 링크 · 권한 · 없음 · 큰 파일 · 이스케이프 · 위험 경로 · JSON 없음 · 깨진 JSON)')
            ok(S3['q2b']['c3_premise_all3'] is False and S3['q2b']['frames']['last']['c3_premise'] is False, 'reader r3: q2b 끝 개행 없는 프레임 → C3 전제 아님')
            ok(S3['q7b_ref']['pkgs']['2']['compare'] == 'json_changed', f"reader r3 --q7b-ref: JSON 이 바뀐 꾸러미는 번호 대조를 하지 않는다 ({S3['q7b_ref']['pkgs']['2']['compare']})")
        if n == 't2' and os.path.exists(jj):
            S2 = json.load(open(jj))
            ok(all(p['compare'] == 'same' for p in S2['q7b_ref']['pkgs'].values()), 'reader r2 --q7b-ref (t1): 일곱 다 같음')
        if n == 't7' and os.path.exists(jj):
            S7 = json.load(open(jj))
            ok(S7['q9b']['logs']['2']['suppressed'] == 702 and S7['q7b']['pkgs']['3']['over_cap'] == 1000 and S7['truncated'], 'reader r7: 넘침 기록 (비-행 702 · 목록 1000) · truncated 표지')
    e13 = exp_of(T, 't13')
    tg, sh = bundle_of(T, 't13', e13['home_real'])
    j13 = os.path.join(T, 'read_t13.json')
    rc, so = run_reader(T, 'r13', tg or '/nonexistent', os.path.join(T, 'read_t13'), md5, sh or '0' * 64, ('--json', j13, '--q7b-ref', j1))
    ok(rc == 0, f'reader r13 (t13): rc {rc}')
    if os.path.exists(j13):
        S13 = json.load(open(j13))
        cp = S13['q7b_ref']['pkgs']
        ch = cp['2'].get('changed', [])
        ok(cp['2']['compare'] == 'different' and [c['i'] for c in ch] == [1, 2] and ch[0]['old_tm'] != ch[0]['new_tm']
           and all(cp[k]['compare'] == 'same' for k in cp if k != '2'), f"reader r13 --q7b-ref: ucx 1 번 (바뀐 파일) · 2 번 (그 파일로 가는 링크) 만 다름 · 시각 같이 보고 · 나머지 같음 {ch[:2]}")
    print('\n'.join(R['lines']))
    print(f"== PASS {R['pass']} · FAIL {R['fail']}")
    json.dump(R, open(os.path.join(T, 'check_result.json'), 'w'), ensure_ascii=False, indent=1)
    return 0 if R['fail'] == 0 else 1


if __name__ == '__main__':
    sys.exit(main())

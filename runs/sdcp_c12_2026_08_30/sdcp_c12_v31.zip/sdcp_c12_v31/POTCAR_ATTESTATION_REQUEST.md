# POTCAR / VASP attestation 요청 (계산 **전**)

원고 Methods 에 PAW release 를 적으려면 아래를 **첫 계산 전에** 확인해 주셔야 합니다.
POTCAR 파일 자체는 주고받지 않습니다 — 지문과 버전 문자열만입니다.

아래 스크립트를 묶음 루트에서 실행하시면 `POTCAR_ATTESTATION.json` 이 만들어집니다.
그 파일만 반송해 주시면 됩니다.

```bash
# 먼저 받으신 ZIP 의 SHA256 을 구합니다 (번들 안에는 자기 해시를 넣을 수 없습니다)
ZS=$(sha256sum /경로/받은번들.zip | cut -d" " -f1)

PP=/path/to/potpaw_PBE.54 POTCAR_ALLOWLIST=/abs/site_allow.txt RELEASE_LABEL="potpaw_PBE.54" SITE="기관/담당자" BUNDLE_ZIP_SHA256="$ZS" bash MAKE_POTCAR_ATTESTATION.sh
```

⚠ **첫 VASP 실행 전에** 돌려 주세요. 스크립트가 OUTCAR/CONTCAR/CHGCAR 등 산출물이
있으면 거부합니다 — "계산 전에 만들었다" 를 선언이 아니라 **검사**로 남기기
위해서입니다.

담기는 것 (회신 AP #12 목록 그대로):
- 받으신 **정확한 ZIP** 의 SHA256 (BUNDLE_ZIP_SHA256) 과 MANIFEST.json 의 SHA256
- release label 과 variant 목록
- variant 별 **원본 파일 전체** SHA256
- POTCAR 내부 `TITEL` 줄과 embedded hash
- site allowlist 의 SHA256
- 생성 UTC 시각 · 사이트/담당자
- `vasp_std --version` 원문
- VASP 실행파일의 SHA256 과 resolved path

⚠ 이것이 없으면 원고는 `PBE PAW 5.4` 를 **단정하지 않고**, D 를 "이 묶음의
PAW dataset 에 조건부" 로만 보고합니다.

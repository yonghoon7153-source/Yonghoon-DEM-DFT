# g2cp_ibb.sh — P1 언로딩 G2c′ 샌드박스를 ibb 에서 (2026-11-12 · 1저자 "g2c'는 ibb 로 · cpu 60 활용")
# 사용:  bash ~/g2cp_ibb.sh prep    폴더 · 덱 풀기 (리포 11a794674 그대로) · LIGGGHTS 3d5c00f 소스 · 잡 스크립트 (제출 안 함)
#        bash ~/g2cp_ibb.sh start   빌드 잡 (직렬 STUBS · 한 노드 16 코어) → 건식 N 200 잡 (1 코어 · 빌드 성공 뒤)
#        bash ~/g2cp_ibb.sh watch   잡 상태 · 로그 끝 (읽기만)
#        bash ~/g2cp_ibb.sh pack    돌려받을 묶음 (g2cp_dry200_return.tgz) 만들기
set -u
W="$HOME/g2cp_20261112"
TGZ="$HOME/g2cp_sandbox_11a794674.tgz"
TGZ_SHA=3f83d561407a0c8e7e82d4e1d91ace41d8f3afc43c3cd59de3ed54e462c0d26e
PIN=11a7946748fa4da2cd8e691ef5f7abc02aac2a56
LSHA=3d5c00f20519e6bb6eb6756f51f1ad36564e649d
LSRC="$HOME/LIGGGHTS-PUBLIC"
LURL=https://github.com/CFDEMproject/LIGGGHTS-PUBLIC.git
SB="$W/repo/docs/reviews/p1_g2c_sandbox_20261104"
SRC="$W/liggghts_3d5c00f"
N=200
NC=16

stop() { echo "⛔ $* — 멈춤"; exit 2; }
say() { echo "[g2cp] $*"; }

jobs_of() {   # squeue 재시도 — 실패를 '비었음' 으로 보지 않는다
  local i out
  for i in 1 2 3; do
    if out=$(squeue -h -j "$1" -o '%i %j %T %M %L %R' 2>/dev/null); then printf '%s\n' "$out"; return 0; fi
    sleep 3
  done
  return 1
}

prep() {
  [ -e "$W" ] && stop "$W 가 이미 있다 (아무것도 안 함 · 다시 하려면 그 폴더를 옮긴 뒤)"
  [ -f "$TGZ" ] || stop "덱 묶음 없음: $TGZ (scp 로 먼저 보낸다)"
  [ "$(sha256sum < "$TGZ" | cut -c1-64)" = "$TGZ_SHA" ] || stop "덱 묶음 sha256 다름 (옮기다 깨짐)"
  for t in git make g++ sbatch squeue scontrol scancel tar sha256sum md5sum; do
    command -v "$t" > /dev/null 2>&1 || stop "명령 없음: $t"
  done
  mkdir "$W" && mkdir "$W/repo" "$W/logs" || stop "폴더를 만들 수 없다: $W"
  tar xzf "$TGZ" -C "$W/repo" || stop "덱 묶음 풀기 실패"
  [ -f "$SB/run_g2cp.sh" ] && [ -f "$SB/run_40000/inputs.md5" ] || stop "풀린 덱에 실행기 · 11-04 기록이 없다"
  {
    echo "pin $PIN (git archive · 리포 docs/reviews/p1_g2c_sandbox_20261104)"
    echo "tgz_sha256 $TGZ_SHA"
    echo "prep_utc $(date -u +%FT%TZ)"
    ( cd "$SB" && find . -type f | LC_ALL=C sort | xargs md5sum )
  } > "$W/PROVENANCE.txt"
  if git -C "$LSRC" cat-file -e "$LSHA^{commit}" 2> /dev/null; then
    git clone -q --no-hardlinks --no-checkout "$LSRC" "$SRC" > "$W/logs/clone.log" 2>&1 || stop "LIGGGHTS 소스 복제 실패 ($LSRC · logs/clone.log)"
    echo "source local_clone_of $LSRC" > "$W/BUILD_ID.txt"
  else
    git clone -q --no-checkout "$LURL" "$SRC" > "$W/logs/clone.log" 2>&1 || stop "LIGGGHTS 소스 내려받기 실패 (logs/clone.log)"
    echo "source github" > "$W/BUILD_ID.txt"
  fi
  git -C "$SRC" checkout -q "$LSHA" > "$W/logs/checkout.log" 2>&1 || stop "3d5c00f 체크아웃 실패"
  [ "$(git -C "$SRC" rev-parse HEAD)" = "$LSHA" ] || stop "소스 HEAD 가 3d5c00f 가 아니다"
  [ -z "$(git -C "$SRC" status --porcelain)" ] || stop "소스 작업 트리가 깨끗하지 않다"
  echo "liggghts_head $LSHA" >> "$W/BUILD_ID.txt"
  ENVL=""
  [ -f "$HOME/.th_grid/env_lines.txt" ] && ENVL=$(cat "$HOME/.th_grid/env_lines.txt")
  {
    printf '#\041/bin/bash\n'
    printf '#SBATCH --job-name=g2cp_build\n#SBATCH --output=%s/logs/build_%%j.out\n' "$W"
    printf '#SBATCH --partition=cpu\n#SBATCH --qos=cpu-60\n#SBATCH -N 1\n#SBATCH -n 1\n#SBATCH -c %s\n#SBATCH --time=01:00:00\n' "$NC"
    [ -n "$ENVL" ] && printf '%s\n' "$ENVL"
    printf 'cd "%s/src/STUBS" || exit 3\n' "$SRC"
    printf 'make > "%s/logs/build_stubs.log" 2>&1 || { echo BUILD_FAIL_STUBS; exit 1; }\n' "$W"
    printf 'cd "%s/src" || exit 3\n' "$SRC"
    printf 'make -j %s serial > "%s/logs/build_serial.log" 2>&1 || { echo BUILD_FAIL_SERIAL; tail -20 "%s/logs/build_serial.log"; exit 1; }\n' "$NC" "$W" "$W"
    printf '[ -x "%s/src/lmp_serial" ] || { echo BUILD_FAIL_NOEXE; exit 1; }\n' "$SRC"
    printf '{ md5sum "%s/src/lmp_serial"; sha256sum "%s/src/lmp_serial"; g++ --version | head -1; } >> "%s/BUILD_ID.txt"\n' "$SRC" "$SRC" "$W"
    printf 'echo BUILD_OK\n'
  } > "$W/job_build.sh"
  {
    printf '#\041/bin/bash\n'
    printf '#SBATCH --job-name=g2cp_dry200\n#SBATCH --output=%s/logs/dry200_%%j.out\n' "$W"
    printf '#SBATCH --partition=cpu\n#SBATCH --qos=cpu-60\n#SBATCH -N 1\n#SBATCH -n 1\n#SBATCH -c 1\n#SBATCH --time=03:00:00\n'
    [ -n "$ENVL" ] && printf '%s\n' "$ENVL"
    printf 'LMP="%s/src/lmp_serial" bash "%s/run_g2cp.sh" %s "%s/dry200"\n' "$SRC" "$SB" "$N" "$W"
    printf 'echo "RUNNER_RC $?"\n'
  } > "$W/job_dry.sh"
  bash -n "$W/job_build.sh" && bash -n "$W/job_dry.sh" || stop "잡 스크립트 문법 오류"
  [ -n "$ENVL" ] && { say "잡 스크립트에 넣은 환경 줄 (~/.th_grid/env_lines.txt):"; printf '%s\n' "$ENVL" | sed 's/^/    /'; }
  say "준비 끝: $W"
  say "  덱 = 리포 ${PIN:0:9} 그대로 (sha256 맞음) · LIGGGHTS 소스 = $(head -1 "$W/BUILD_ID.txt") · HEAD 3d5c00f"
  say "  잡 = 빌드 (한 노드 $NC 코어 · 1 시간 한도) → 건식 N $N (1 코어 · 3 시간 한도) — 팔은 등록대로 직렬 (한 번에 하나)"
  say "  다음: bash ~/g2cp_ibb.sh start"
}

start() {
  [ -f "$W/job_build.sh" ] && [ -f "$W/job_dry.sh" ] || stop "prep 먼저"
  [ -e "$W/jobs.txt" ] && stop "이미 제출했다 ($W/jobs.txt) — watch 로 본다"
  J1=$(sbatch --parsable --hold "$W/job_build.sh" 2> "$W/logs/sbatch1.err") || stop "빌드 잡 제출 실패 (logs/sbatch1.err)"
  J1=${J1%%;*}
  case "$J1" in ''|*[^0-9]*) stop "빌드 잡 번호가 숫자가 아니다: '$J1'";; esac
  J2=$(sbatch --parsable --dependency=afterok:"$J1" "$W/job_dry.sh" 2> "$W/logs/sbatch2.err") || { scancel "$J1"; stop "건식 잡 제출 실패 (빌드 잡 $J1 취소함 · logs/sbatch2.err)"; }
  J2=${J2%%;*}
  case "$J2" in ''|*[^0-9]*) scancel "$J1"; stop "건식 잡 번호가 숫자가 아니다: '$J2' (빌드 잡 취소함)";; esac
  scontrol release "$J1" || say "⚠ scontrol release $J1 실패 — 'scontrol release $J1' 를 손으로"
  printf 'build %s\ndry200 %s\nsubmit_utc %s\n' "$J1" "$J2" "$(date -u +%FT%TZ)" > "$W/jobs.txt"
  say "제출: 빌드 $J1 → 건식 $J2 (빌드 성공 뒤에만 돈다)"
  say "다음: bash ~/g2cp_ibb.sh watch  (끝나면 pack)"
}

watch() {
  [ -f "$W/jobs.txt" ] || stop "제출 기록 없음 (start 먼저)"
  J1=$(awk '$1 == "build" {print $2}' "$W/jobs.txt" < /dev/null); J2=$(awk '$1 == "dry200" {print $2}' "$W/jobs.txt" < /dev/null)
  if Q=$(jobs_of "$J1,$J2"); then
    if [ -n "$Q" ]; then say "큐:"; printf '%s\n' "$Q" | sed 's/^/    /'; else say "큐: 두 잡 다 빠짐 (끝)"; fi
  else
    say "⚠ squeue 실패 (상태 모름 — 잠시 뒤 다시)"
  fi
  for f in "$W"/logs/build_*.out "$W"/logs/dry200_*.out; do
    [ -f "$f" ] && { say "$(basename "$f") 끝 줄:"; tail -3 "$f" | sed 's/^/    /'; }
  done
  [ -f "$W/dry200/rc.txt" ] && { say "dry200/rc.txt:"; sed 's/^/    /' "$W/dry200/rc.txt"; }
  [ -f "$W/dry200/STOP.txt" ] && { say "⛔ dry200/STOP.txt:"; sed 's/^/    /' "$W/dry200/STOP.txt"; }
  return 0
}

pack() {
  [ -d "$W" ] || stop "$W 없음"
  R="$W/g2cp_dry200_return.tgz"
  [ -e "$R" ] && stop "이미 있음: $R"
  L=""
  for x in dry200 logs PROVENANCE.txt BUILD_ID.txt jobs.txt job_build.sh job_dry.sh; do [ -e "$W/$x" ] && L="$L $x"; done
  tar czf "$R" -C "$W" $L || stop "묶기 실패"
  say "돌려받을 묶음: $R"
  sha256sum "$R"
}

main() {
  case "${1:-}" in
    prep) prep ;;
    start) start ;;
    watch) watch ;;
    pack) pack ;;
    *) sed -n '2,6p' "$0" ;;
  esac
}
main "$@"; exit $?

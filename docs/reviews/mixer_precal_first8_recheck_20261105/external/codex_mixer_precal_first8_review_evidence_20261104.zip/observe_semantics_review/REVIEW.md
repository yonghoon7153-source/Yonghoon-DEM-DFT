# Q5 independent semantics review

Target pin: `189930cc68b6e58beb6b4546d80353dc03852195`.

Result: no new P1/P2/P3 defect found in the reviewed contact/cluster/M semantics. This conclusion is limited to static inspection and the small synthetic probes below. It does not determine the other request questions or authorize physical execution.

## Reviewed behavior

- `scripts/mixer_contact_reader.py:324-337`: every SE atom is a graph vertex, including singletons. Strict-overlap SE edges define connected components. The cluster fraction counts atoms in components of size >=2; the largest fraction divides by all SE; number-average component size is N_SE/component_count; histogram entries count components.
- `scripts/mixer_contact_reader.py:340-352`: AM_P and AM_S attachment fractions each deduplicate SE indices and divide by the same all-SE count. Their union is explicitly formed. Per-AM quantities count pairs and divide by that AM phase's atom count. An absent AM phase yields null per-AM, while its attached-SE fraction is zero.
- `scripts/mixer_contact_reader.py:157-178,355-411`: strict printed-distance/radius overlap is used, exact tangency excluded. Neighbor search is padded for resolution bounds; registered edges are separately filtered. Observed radii enter contact arithmetic. Radius correspondence is checked rather than replacing observed radii with an unrelated default.
- `scripts/mixer_precal_observe.py:142-145,269-308`: actual-template radius agreement precedes metrics. Each grid uses the run's declared radius, axis x and n_min=20. Grids are 16x16x4, 12x12x3, 8x8x2. M uses this run's own t0 variance and the qualified E0 t0 variance, with no clipping or theoretical denominator.
- `scripts/measure_mixing_index.py:111-159`: cell fractions use observed radius cubed and combine types1/2 as AM. The >=20 threshold is inclusive; unselected cells remain visible through s2_all, retained-volume/count ratios and dropped-cell count. The adapter preserves the complete raw stats dictionaries.
- `scripts/mixer_precal_observe.py:282-286` and `scripts/measure_mixing_index.py:77-85`: the existing representativeness QC is carried into each grid. A failed QC does not silently delete finite M, consistent with the existing reader's declared rule.
- `scripts/mixer_precal_observe.py:272-279,359-371`: a nonpositive/nonfinite denominator or nonfinite frame M becomes UNDEFINED; no SE also becomes UNDEFINED. Contact and mixing outputs are both removed on non-OK status. Auxiliary NaN values serialize as null, never zero.

## Independent probes

`probe_semantics.py` and `probe_results.json` are reproducible evidence. Five independent probe groups passed with Python3.12.14, NumPy2.5.3, SciPy1.16.3. Maximum particle count was80. No submitted source was changed. No simulation or real research dumps were used.

1. An independent all-pairs/graph oracle verified a 4-SE component plus a singleton: three SE-SE edges, cluster/largest fraction0.8, mean component size2.5, and histogram component counts. Two AM_P-SE and two AM_S-SE contacts gave each phase fraction0.4 but union0.4; per-AM values were1.0 and2.0. Exact tangency was excluded.
2. Real `cell_stats`, not a metric mock, processed80 atoms in four20-atom cells across all three grids. S0=0.25, SR=0, S=0.0625 and M=0.75. IDs/types/radii stayed conserved while positions changed. Raw variance and QC passed through.
3. Unequal-radius hand fractions8/9 and27/35 matched all three grids. A separate59-atom fixture containing20AM_P,20AM_S and19SE in separate cells produced selected variance0, all-nonempty variance2/9, dropped1 and SE retained-volume0; QC correctly failed.
4. Disk entry probes used real raw-byte parsing, frame qualification, contact and cell statistics. Only preparation binding was mocked because an80-atom fixture cannot meet the fixed100000-atom preparation contract. A complete rotating fixture returnedOK and M0.75. Equal denominator, a later one-cell variance and noSE each returnedUNDEFINED with no contact/M. E0 with one occupied cell returnedOK with each grid markedNOT_APPLICABLE and null raw variance; strict JSON emission succeeded.
5. AbsentAM_S gave null per-AM while keeping fraction0. Real cell statistics yielded unclipped M values approximately-3.57143 and1.19048.

Reproduction command:

```powershell
& 'C:\Users\Administrator\Documents\Codex\lhs28\venv\Scripts\python.exe' -I -X utf8 -B 'C:\Users\Administrator\Documents\Codex\outputs\mixer_precal_first8_review_20261104\observe_semantics_review\probe_semantics.py'
```

The initially requested bundled Python3.12.14 could import NumPy but lacked SciPy. No dependencies were installed; the parent supplied the existing working environment above.

## Submitted test boundary and acknowledged limits

- `scripts/test_mixer_precal_observe.py:156-168` mocks `cell_stats` with a repeated18-result side-effect sequence. It confirms orchestration/call count and summary wiring; it does not validate cell construction or radius weighting. The author explicitly labels this boundary at lines158-159 and in `validation_summary.json`. The new independent small probes exercise those functions directly, but still do not replace a100000-atom unmocked positive end-to-end run.
- The original test's tiny E0 fixture permits null cell variances while status isOK. This is not a newly discovered status bypass: E0 is reported as raw-reference statistics with gridNOT_APPLICABLE (`mixer_precal_observe.py:302-303`), and auxiliary-null behavior is explicitly declared at lines328-329.
- Existing `cell_stats` clips transverse coordinates to edge bins and sets axial boundaries using each frame's coordinate min/max (`measure_mixing_index.py:132-135`). The adapter preserves this existing M definition. It does not certify particle containment or measured STL geometry. This was not classified as a new defect under Q5's reuse scope.
- The observer does not promise phase allocation equals planned allocation; its counts record exposes differences. This review does not propose a new phase-count threshold or infer physical representativeness from QC.
- Contact attachment is instantaneous sphere-overlap counting, not surface coverage, persistent binding, statistical significance or a physical coating effect. Frame SD is not seed uncertainty.
- Source hashes in `probe_results.json` match the submitted final observe/contact/mixing hashes. Baseline submitted suites and broader preparation/log/input-binding review are owned by the parent review and are not counted again here.

No minimal fix is proposed because no new reproducible Q5 defect was established.

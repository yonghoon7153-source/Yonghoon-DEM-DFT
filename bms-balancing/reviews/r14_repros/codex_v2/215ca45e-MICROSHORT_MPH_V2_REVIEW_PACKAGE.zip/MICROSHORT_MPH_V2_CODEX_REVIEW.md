# 마이크로 쇼츠 MPH 분석 v2 — 독립 재검토

검토일: 2026-09-13  
대상 커밋: `d72e735fed52a06b4a4e739fdbd2c71fa9e8a3b6`  
대상: v2 분석 문서·1차 대응 원장·추출기, 이번에 제공된 실제 MPH와 적합 결과 XLSX 4개.  
**범위: 마이크로 쇼츠 분석 검토. R13 하네스나 degradation-degeneracy 게이트 판정이 아니다.**

## 판정

**NO-GO — v2를 모델의 현재 동작을 확정하는 진단서·수정 지침으로 사용하기에는 이르다.**

이번에는 원본이 없어서 보류하는 것이 아니다. 원본에서 **문서가 근거로 읽은 저장 식과 선택된 값의 출처가 다르고, 저장 해에 연결된 모델도 현재 편집 상태와 다름**을 확인했다. M1의 “조건을 강하게 지지하는 네 증거”에는 결정적인 선택자가 빠져 있다. 엑셀 수치는 상당 부분 정확하지만, 수치 관계에서 식별성·불확실성으로 넘어가는 결론은 여전히 과하다.

이 판정은 모델이 반드시 잘못됐다는 뜻도, COMSOL 계산을 수행해 실패했다는 뜻도 아니다. **현재 증거로 두 농도 식을 수정하라는 근거가 성립하지 않는다**는 판정이다. COMSOL·MATLAB은 실행하지 않았으며 원본과 대상 작업트리를 수정하지 않았다.

## 요청한 정본 링크

모두 요청한 동일 커밋의 raw URL이다. 표시용 `...`를 실제 경로로 바꿨다.

| 자료 | 고정 링크 |
|---|---|
| v2 분석 문서 | [MICROSHORT_MPH_REVIEW.md](https://raw.githubusercontent.com/yonghoon7153-source/Yonghoon-DEM-DFT/d72e735fed52a06b4a4e739fdbd2c71fa9e8a3b6/bms-balancing/docs/MICROSHORT_MPH_REVIEW.md) |
| 교정 추출기 | [mph_dump.py](https://raw.githubusercontent.com/yonghoon7153-source/Yonghoon-DEM-DFT/d72e735fed52a06b4a4e739fdbd2c71fa9e8a3b6/bms-balancing/reviews/r14_repros/mph_dump.py) |
| 구조 추출본 | [mph_dump_output.txt](https://raw.githubusercontent.com/yonghoon7153-source/Yonghoon-DEM-DFT/d72e735fed52a06b4a4e739fdbd2c71fa9e8a3b6/bms-balancing/reviews/r14_repros/mph_dump_output.txt) |
| 1차 요청문, 대조용 | [REQ_MPH_MICROSHORT.md](https://raw.githubusercontent.com/yonghoon7153-source/Yonghoon-DEM-DFT/d72e735fed52a06b4a4e739fdbd2c71fa9e8a3b6/bms-balancing/reviews/REQ_MPH_MICROSHORT.md) |

추가 대조: [1차 대응 원장](https://raw.githubusercontent.com/yonghoon7153-source/Yonghoon-DEM-DFT/d72e735fed52a06b4a4e739fdbd2c71fa9e8a3b6/bms-balancing/reviews/MPH_R1_RESPONSE.md), [적합 결과 난간 검토 요청](https://raw.githubusercontent.com/yonghoon7153-source/Yonghoon-DEM-DFT/d72e735fed52a06b4a4e739fdbd2c71fa9e8a3b6/bms-balancing/reviews/REQ_FIT_RAILS.md).

## 1. 주요 발견

심각도는 이 분석의 결론·수정 우선순위에 미치는 영향 기준이다. 실행권이나 보안 취약점 등급이 아니다. 아래 “관측”은 저장 XML/OOXML와 독립 산술의 관측이지 COMSOL 수치해가 아니다.

### V2-1 · P1 · M1은 비선택 사용자 식을 선택된 최대농도로 읽었다

대상 문서: 73·76·188–221·428–429행. 대응 원장 R-1.

원본 `dmodel.xml`에 다음이 함께 저장돼 있다.

| 항목 | 음극 pce1/pin1 | 양극 pce2/pin1 |
|---|---|---|
| 최대농도 출처 | **cEeqref_mat = from_mat** (1369행) | **cEeqref_mat = from_mat** (2511행) |
| 저장된 사용자 식 | cs_Gr_max × dm_fNE (1370행) | cs_NCM_max × dm_fPE (2512행) |
| 입자 재료 | mat1 | dommat → 동일 도메인의 mat5 |
| 선택 재료의 cEeqref | def.csmax | def.csmax |
| 재료의 csmax | 31507 mol/m³ | cs_NCM_max = 50707.7 mol/m³ |
| 초기농도 식 | x_Gr_init × cs_Gr_max | x_NCM_init × cs_NCM_max |

재료의 해당 최대농도에는 **dm이 없다**. 문서는 반응 전위의 `Eeq_mat=from_mat`는 선택 근거로 사용하면서, 입자의 `cEeqref_mat=from_mat`는 빼고 저장 사용자 식을 실효값처럼 읽었다.

이는 단순히 “실제 SOC를 아직 안 찍었다”는 것보다 앞단의 문제다. COMSOL 공식 1D 예제도 최대농도의 출처 선택과 사용자 입력 칸을 구분하고, 재료의 cEeqref가 최대 리튬 농도임을 명시한다. [COMSOL 6.4 공식 예제](https://doc.comsol.com/6.4/doc/com.comsol.help.models.battery.li_battery_1d/li_battery_1d.html).

**독립 산술 관측:**

- 선택 재료값으로 나누면 음극 0.01172068149, 양극 **0.9240638866948168**.
- 저장 사용자 식으로 나누면 음극 0.012030119995933, 양극 **0.9522895783860553**.
- 후자는 현재 선택 설정에서 도출한 값이 아니라, 비선택 식을 분모로 삼은 가정값이다.
- 현재 선택 설정의 농도·부피분율 사슬은 문서가 주장한 사이트 수의 `(1−LAM)²` 감소를 지지하지 않는다.

따라서 −14.27 mV 산술 자체를 틀렸다고 하지 않는다. **그 가정을 현재 모델의 진단 근거로 사용하는 연결이 틀렸다.** 저장 사용자 식 두 줄만 바꾸는 조치는 선택 상태를 유지하면 실효 최대농도를 바꾸지 않을 수 있다.

**최소 수정:** M1 표에 값·선택자·재료·최종 물성 식을 함께 싣고, 현재 모델에 대한 이중 반영 주장을 철회한다. 추가 확인은 현재 설정으로 생성된 최대농도/정규화 식을 평가해야 하며, 기존 해에서 숫자 하나를 읽는 것으로 대체하면 안 된다. “네 노드 값이 같으므로 아무도 편집한 적 없다”는 편집 이력 추정도 삭제한다.

### V2-2 · P1 · 기존 해는 현재 설정을 검증하지 못한다 — C-rate보다 큰 차이가 있다

대상 문서: 38·221·403–412·553–555행. 대응 원장 R-18 및 “30초 확인법”.

저장 GUI 메타데이터는 plot 선택으로 `pg19`를 기억한다. 실제 참조는 다음과 같다.

`pg19 → dset1 → sol1 → soldata/sol19, savepoint6`

각각 현재 XML 16339·12098·9602·9606행에서 확인했다. 단, `guiView=GEOM`도 저장돼 있다. **실제 화면에서 그 그래프가 보였다는 주장은 하지 않는다.**

연결된 `savepoint6/model.zip!/dmodel.xml`는 현재 편집 모델과 다르다.

| 설정 | 현재 dmodel | sol1에 연결된 저장 당시 모델 |
|---|---|---|
| C_rate | 0.1 | 0.1 |
| 음·양극 부피분율 | epss_0 × (1−LAM) | **epss_0** |
| 최대농도 선택자 | **from_mat** | **userdef** |
| 사용자 최대농도 | cs_max × dm | cs_max × dm |
| 초기농도 | x_init × cs_max | **x_init × cs_max × dm** |
| x_NCM_init | Li 재고 식 → 약 0.924064 | **0.9189896** |

저장 당시 양극의 `csinit/cEeqref`에서는 dm이 소거돼 **0.9189896**이다. 이는 제안된 “0.924064인가 0.952290인가”에 없는 세 번째 값이다. 이 역시 저장 설정의 산술이지 해 바이너리를 읽은 결과는 아니다.

한편 `sol3..sol6`의 실제 `paramNames/paramVals`에는 0.05C와 네 sigma_short 값이 저장돼 있다. 즉 **0.05C sweep과 0.1C 단일점 해가 함께 존재**한다. “파일을 열어 그림을 그리면 0.05C 결과”라는 단정은 성립하지 않는다.

**최소 수정:** 저장 해마다 dataset·solution·savepoint·모델 hash·주요 설정을 짝지어 표시한다. 현재 설정을 검증할 때는 복사본에서 새 초기화/해를 만들고, 선택한 dataset이 그 결과인지 확인한다. 현재 dmodel의 분율·초기농도와 옛 savepoint의 선택자를 섞은 가상의 조합으로 M1을 판정하지 않는다. 원래 저장 해를 삭제할 필요는 없다.

### V2-3 · P1 · c_lit의 추가 종속식을 놓쳤다 — “LLI 독립”과 적합 변수 목록은 미증명이다

대상 문서: 12·139·505행. REQ_FIT_RAILS 47행.

제공된 4개 파일 **37행 모두**에서 다음 식이 재현됐다.

```text
c_lit = C_cell × (a_PE + b_PE − b_NE)
최대 절대오차: 네 파일 각각 0.0
```

이는 저장 수치 토큰을 binary64로 읽고 위 연산 순서로 계산한 결과다. 예를 들어 ref1 Sheet1의 cycle 2:

```text
B4 = 0.003800359
D4 = 1.1041030778540413
E4 = -0.15683805380755067
G4 = 0
H4 = 0.003599947159520297
B4 × (D4 + E4 − G4) == H4
```

따라서 출력 관계는 다음과 같이 더 닫힌다.

```text
s = a_PE + b_PE − b_NE
LLI = 1 − x_cell × s/s₀
```

**LLI가 용량 감소율과 다르다는 v2 정정은 맞다.** 하지만 그것이 독립 측정·식별된 자유도라는 뜻은 아니다. c_lit을 최적화했는지, beta에서 계산했는지, 반대로 beta가 유도됐는지는 결과 파일만으로 정할 수 없다. “실제로 푼 변수 다섯 개”라는 문장은 MATLAB 구현이 없으면 확정할 수 없다.

a_PE를 바꾸면서 C_cell과 beta를 고정하면 관측 식에서 LAM_PE뿐 아니라 LLI도 변한다. LLI를 고정하려면 예컨대 b_PE가 반대로 보상돼야 한다. 독립 물리 민감도 sweep은 할 수 있지만, 그 사각형 입력 영역을 **적합으로 뒷받침된 공동 불확실성 영역**이라고 부를 수는 없다.

**최소 수정:** 위 항등식을 추가하고 “독립”을 “용량 감소율과 동일하지 않음”으로 좁힌다. 실제 적합 변수·제약·공동 범위가 확보되기 전에는 제안한 띠를 신뢰구간이 아니라 가정한 민감도 범위라고 표시한다.

검사 범위: ref1·ref2·PE1 Sheet1!A1:K11, PE5 Sheet1!A1:K8. 전수 값과 셀 주소는 엑셀 증거 JSON에 보존했다.

### V2-4 · P1 · 두 LAM 값이 같다는 사실은 “전극 구분 정보 0”을 증명하지 않는다

대상 문서: 162–169·495–509행. REQ_FIT_RAILS 65–98행.

각 파일 안에서 a_NE가 일정하고, a_PE가 기준값과 같은 행에서는 보고 LAM_PE와 LAM_NE가 같은 용량 감소율로 환산되는 사실은 확인했다. 그러나 **평가점의 두 좌표가 같다는 것과 관측 함수가 두 좌표를 구분할 수 없다는 것은 다른 명제**다.

다음은 그 추론에 대한 수학적 반례다. 실제 배터리 적합을 실행한 반례라고 부르지 않는다.

```text
y₁ = LAM_PE + LAM_NE
y₂ = LAM_PE − LAM_NE
J = [[1, 1], [1, −1]], det(J) = −2
```

LAM_PE = LAM_NE에서도 J는 full rank이고 두 파라미터는 유일하게 복원된다. 그러므로 엑셀의 같은 값만으로 식별 불가능성·전압 모델의 영공간·전극 정보 0을 도출할 수 없다.

실측은 **기준행 포함 30/37**, 기준행 제외 **26/33**에서 a_PE가 그 파일 기준값과 같다. baseline은 자기 자신과 같으므로 별도 표시해야 한다. a_NE도 “37행 전체 같은 값”이 아니라 **파일 내부에서 일정**하며 전체로는 세 값이다. 또 ref1 cycle 3 이후 LAM·LLI 값은 계속 달라져 “같은 파라미터 점 반복”도 아니다.

**최소 수정:** 반복값·동일 LAM은 진단 경고로 남기되, “상한이 실제 존재한다”, “정보가 없다”, “cycle 2가 더 신뢰할 만하다”, “불확실성이 결론을 덮는다”는 확정은 철회한다. bounds·자유 변수·정규화·잔차/profile을 확인하고, 그 뒤에 식별성·불확실성을 판정한다.

### V2-5 · P2 · 추출기의 일반 참조 검사에는 여전히 누락이 있다

대상: mph_dump.py 89·94–95행.

독립 재현에서:

```xml
<root><expressions name="alias" expr="dPE"/></root>
```

dPE를 소비하는 alias가 있는데 반환 참조는 0이다. RHS 전체가 이름과 같으면 버리는 규칙 때문이다. 선언의 name 필드는 이미 제외됐으므로 정상적인 별칭 대입까지 버릴 이유가 없다.

```xml
<root><expressions name="alias" expr="comp1.dPE+1"/></root>
```

이 역시 bare-name 질의에 0을 반환한다. 경계 정규식이 점 앞의 이름을 제외하기 때문이다. qualified 식은 scope를 해석하거나 최소한 미해결 참조로 신고해야 한다. 비교 대조군 `dPE+1`은 1을 반환한다.

또 “live” 함수는 비활성 노드·비선택 저장값까지 포함한 attribute 필드를 센다. 현재 i_app의 2는 비활성 ecd1의 필드 하나와 **두 ODE를 담은 ge2 벡터 필드 하나**다. 활성 소비자 수 2라는 뜻이 아니다.

**현재의 일곱 0 표를 다시 오답 처리하지는 않는다.** 더 넓은 독립 검색으로 이 일곱 이름은 현행 정의에서 선언 외 참조가 없음을 확인했다. 닫힌 것은 **이번 파일의 표**, 닫히지 않은 것은 범용 “live 소비 그래프” 주장이다.

**최소 수정:** RHS 동일 이름을 보존하고 qualified scope를 처리하며, 값의 출처·활성·consumer 단위를 구분한다. 그 전에는 도구 명칭/출력 설명을 “저장 식 필드 참조 목록”으로 좁힌다.

### V2-6 · P2 · A_cell은 후처리에만 쓰이지 않는다

대상 문서 61행. 현재 XML 360→361→363→333→2520행.

`A_cell → dLi_LLI → nLi_target → x_NCM_init → 양극 csinit`

이 사슬이 명시돼 있다. 다른 셀 입력을 고정하고 A_cell만 두 배로 둔 산술 점검에서 x_NCM_init이 **0.9240638867 → 0.9398120835**로 변했다. 모델·원본 파일을 바꾼 실험은 아니다.

**최소 수정:** “전류·출력의 1m² 정규화와 별도로 실제 셀 면적이 초기 Li 재고의 면적 환산에도 들어간다”로 정정한다.

## 2. 이번에 인정하는 것과 1차 조건별 판정

“닫힘”은 해당 오류·증명 요구의 범위이며 전체 COMSOL 모델 승인과 다르다.

| 1차 ID | 이번 판정 | 근거 |
|---|---|---|
| R-1 활성 OCP 소비 | **안 닫힘** | 누락된 최대농도 source selector가 논증을 바꾼다. V2-1·2 |
| R-2 미사용 변수로 의도 단정 | 닫힘 | 단서와 설계 계약을 분리했다 |
| R-3 휴지 기울기 쇼츠 전용 | 닫힘 | 완화·C_diff 의존을 인정했다. 쇼츠 식별을 새로 증명한 것은 아니다 |
| R-4 시간척도 차원 | 닫힘 | 전하 시간·미분용량 기반 시간을 구분했다 |
| R-5 XML 소유권 | **닫힘** | self-test rc 0, 원본 43행 소유권 불일치 0 |
| R-6 활성 상태 | 부분 | ev own/inherited DISABLED 확인. study activate·runtime name resolution과는 구분 필요 |
| R-7 유효 전도도 보존 | 부분 | 보정계수 이전 산술은 맞음. 실제 지수·생성식·모델 대체 동등성은 미확인 |
| R-8 BOL 재고 재정의 | 닫힘 | 불필요한 기준 변경을 철회. 대안은 여전히 별도 모델 가정 |
| R-9 live 참조 | 부분 | 현행 일곱 0은 독립 확인, 일반 도구에는 누락·단위 혼동 존재 |
| R-10 OCP 곡선 이식 단정 | 부분 | 본문의 affine 반례 수용. 요약의 내장 원본 곡선·겹치면 판정된다는 단정은 여전히 강함 |
| R-11 진단 에너지 무의미 | 닫힘 | 기준 에너지와 단자 에너지 해석을 구분 |
| R-12 초기 OCP → 궤적·ICA | 닫힘 | 확대 해석 철회. 단 M1 현재 모델 적용은 V2-1로 별도 무효 |
| R-13 누락된 초기재고 입력 | **닫힘, 산술 범위** | 실제 입력으로 nLi_target=1.1882256785 mol/m², x_NCM_init=0.9240638867 재현 |
| R-14 세 모드 용량으로 붕괴 | 부분 | LLI≠용량손실 정정은 맞음. 독립·식별성 결론은 V2-3·4 |
| R-15 allclose를 기계정밀도 증명으로 | 닫힘 | 네 파일 모든 행 최대 절대오차 재계산, 표와 일치 |
| R-16 이벤트·Stop Condition | 부분 | 기존 단정 철회. StopCondition은 존재하며 선택/기본값의 runtime 해석은 남음 |
| R-17 Cap 초기값·SOC 해석 | 닫힘, 정의 범위 | 초기값과 내부 누설 한계를 명시. 실제 시간 이력 미실행 |
| R-18 solution 이름으로 설정 추정 | **안 닫힘** | 실제 매핑을 읽으면 저장 가족 둘과 설정 snapshot 차이가 드러남. V2-2 |
| R-19 복붙·분율 의도 단정 | 부분 | 의도 단정 철회는 수용. 적용식·분율 합성은 미확인 |

추가 문구 정정:

- “b_NE가 baseline 외 전부 정확히 0”: ref1 G10 = −2.1778531752142977e−17, PE5 G6 = −1.762553861534616e−16. 물리적으로 큰 차이가 아니라 **exact와 tolerance를 구분할 문제**다.
- ref1의 LLI−용량손실 범위 0.0216–0.0355는 **cycle>0인 반복-a_PE 행** 범위다. cycle 0 포함 시 하한 0.
- MPH 열화값은 ref1 cycle 2 I4:K4와 표시 정밀도에서 유일하게 대응한다. “숫자 대응”은 확인했으나 실제 복사 이력까지 증명한 것은 아니다.
- dPE는 네 결과표의 숫자 셀에서 표시 정밀도 일치값을 찾지 못했다. 외부 출처·계산식이 없다고 증명한 것은 아니다.
- 양극 b_PE는 저장 식상 user-defined 보정에 사용된다. pcb1의 Bruggeman 지수와 혼용하면 안 된다.

## 3. 실제로 실행한 검증

[재현 로그](<C:/Users/Administrator/Documents/Codex/2026-08-24/claude-14-gate-code-review-9qkx05-2/outputs/mph_v2_replay_log.json>)에 각 호출의 stdout·stderr·반환코드를 보존했다. 실행하지 않은 COMSOL 결과를 통과로 세지 않았다.

| 실행 | 관측 |
|---|---|
| 제출 추출기 --self-test | rc 0 |
| 원본 기반 독립 추출 점검 | rc 0 · 43행 · 소유권 불일치 0 · 커밋된 dump와 줄바꿈·양끝 공백을 정규화한 텍스트 동일 |
| XLSX 전수 점검 | rc 0 · 4개 sheet · 37행 · 451셀 · 수식 0 · 원본 hash 불변 |
| 초기재고·선택자·snapshot 산술 | rc 0 · asserts PASS · 알 수 없는 저장 음극 Eeq_inv 호출은 null/미평가로 기록 |
| solver/snapshot 추출 및 증거 축약 | 두 호출 rc 0 · 원본 XML 경로와 1-based 행 보존 |
| Git 상태 확인 | 지정 전체 SHA 일치 · 작업트리 clean |

단일 재현 진입:

```powershell
& 'C:/Users/Administrator/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe' 'C:/Users/Administrator/Documents/Codex/2026-08-24/claude-14-gate-code-review-9qkx05-2/outputs/mph_v2_replay.py'
```

현재 기계의 원본 경로와 검토 checkout 경로를 사용하는 재현 도구다. 다른 기계에서는 스크립트 상단의 입력 위치를 맞춰야 한다. 추출·scope 보조 도구는 lxml이 필요하며, 이번에는 번들 Python 환경에 이미 있었다. Excel을 열거나 재계산하지 않는 읽기 전용 OOXML 점검을 사용했다.

원본 정체성:

- 제공 ZIP SHA-256: `e0f2720e9e08d58b7769b21e963ce6250bcf58031eff73f2c59a57952a8eefc6`
- 내부 MPH: `8b2e71506ba2a5ebad1ce27e268417b0e74b28cbaa9a81d1a6c32c58573557a9`
- 현재 dmodel.xml: `6aa8ebdad37da698dfd8c1cbe65451292dbdfd5f7ece60a9a33cabe8e3b0cfa6`
- savepoint6 내부 dmodel.xml: `ffe8eab9f095c0c985482e75c216399d5dd916d6c60e432af593aac4cfa68c07`

문서·코드 hash: [대상 파일 목록](<C:/Users/Administrator/Documents/Codex/2026-08-24/claude-14-gate-code-review-9qkx05-2/outputs/mph_v2_target_hashes.json>). 개별 XLSX hash는 엑셀 증거에 포함했다.

## 4. 다음 확인 순서 — 파라미터 수정 전

1. **현재 설정·저장 당시 모델·평가 dataset을 분리한다.** M1은 source selector와 최종 물성 사슬부터 고친다.
2. 현재 설정의 복사본으로 생성식/초기화를 확인하고, 평가 dataset·solution과 함께 양 전극의 실제 최대농도·초기농도·정규화·재고를 기록한다. 기존 해의 한 점을 읽는 것으로 끝내지 않는다.
3. LAM의 물리 계약과 α·β의 좌표/정규화를 확보한다. MATLAB의 실제 변수 목록·bounds·export 계산식을 받아 c_lit 관계의 방향을 확인한다.
4. 적합 잔차·profile·공동 허용 범위가 없으면 “불확실성 띠”가 아니라 “명시한 가정에 대한 민감도 띠”로 전달한다.
5. 이후에야 원 반쪽셀 OCP와 모델 OCP의 좌표·단위·정규화를 맞춰 대조한다. 실제 전압곡선·잔차 없는 현재 XLSX만으로 “안 맞는 주원인”은 정할 수 없다.

규진팀에 전달할 수 있는 요지는 다음과 같다.

> 현재 확인된 것은 결과표의 반복된 파라미터와 그로부터 유도되는 LAM/LLI 관계입니다. 이것만으로 파라미터가 틀렸다거나 전극 구분 정보가 없다고 단정하지 않겠습니다. 먼저 COMSOL이 실제 선택한 농도 출처와 비교 중인 저장 해를 맞추고, 적합 제약·잔차·공동 범위로 별도 열화와 쇼츠 결론이 구분되는지 확인하겠습니다.

## 부록 자료

- [선택자·초기재고 산술 증거](<C:/Users/Administrator/Documents/Codex/2026-08-24/claude-14-gate-code-review-9qkx05-2/outputs/mph_v2_physics_evidence.json>)
- [원본 XML·solver/snapshot 상세 검토](<C:/Users/Administrator/Documents/Codex/2026-08-24/claude-14-gate-code-review-9qkx05-2/outputs/mph_v2_solver_scope_review.md>)
- [원본 XML·행 좌표 증거](<C:/Users/Administrator/Documents/Codex/2026-08-24/claude-14-gate-code-review-9qkx05-2/outputs/mph_v2_solver_scope_evidence.json>)
- [엑셀 전수 검토와 REQ_FIT_RAILS Q1–Q5 답변](<C:/Users/Administrator/Documents/Codex/2026-08-24/claude-14-gate-code-review-9qkx05-2/outputs/mph_v2_workbooks_review.md>)
- [엑셀 전수 셀·재계산 증거](<C:/Users/Administrator/Documents/Codex/2026-08-24/claude-14-gate-code-review-9qkx05-2/outputs/mph_v2_workbooks_evidence.json>)
- [추출기 검토](<C:/Users/Administrator/Documents/Codex/2026-08-24/claude-14-gate-code-review-9qkx05-2/outputs/mph_v2_extractor_report.md>)
- [추출기 현재 파일 검증·작은 반례](<C:/Users/Administrator/Documents/Codex/2026-08-24/claude-14-gate-code-review-9qkx05-2/outputs/mph_v2_extractor_evidence.json>)

**최종 판정: NO-GO.** V2-1·2의 모델 상태/값 출처 결속을 바로잡고, V2-3·4의 수치 관계와 식별성 주장을 분리한 뒤 재검토할 수 있다. 이번에 확인한 소유권 수정·일곱 무참조 값·엑셀 산술은 인정하며, 이를 미확인인 COMSOL 동작이나 적합 식별성의 증명으로 확장하지 않는다.

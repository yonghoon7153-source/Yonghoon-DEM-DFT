#!/usr/bin/env python3
"""mkworld.py <W> <variant> — 보충 조회 블록 (q9b · q2b · q7b) 시험용 가짜 ibb 홈 + 기대값 (<W>/expect.json).

로그인 홈 = <W>/hroot/home/fakeuser (링크) → 실제 홈 = <W>/lroot/lustre/home/fakeuser (suffix = 실제 홈 = W/lustre + 로그인 홈 · ibb 꼴).
variant: full (다 정상) · fail (파일 없음 · 권한 없음 · 디렉터리 · 깨진 링크 · 큰 파일 · 깨진 JSON · 이스케이프 · 위험 경로 · 자료 꼴 어긋남)
         suffix · overflow (비-행 줄 1000 · 목록 16000 · CRLF) · glued (낱말에 붙은 계정 · 노드 이름 · JSON 이름의 계정) · mod (ucx 파일 하나만 바뀜)
기대값은 블록 코드를 쓰지 않고 이 파일의 명세에서 바로 계산한다 (블록이 낼 줄 그대로 · 블록은 실행자 = DAC 무시 권한 없는 root 로 돈다).
덤프 · 로그 · conda 파일 · JSON 내용 · 금고에 SECRET 문자열을 넣는다 — 블록이 내용을 옮기면 시험이 잡는다.
"""
import hashlib
import json
import os
import stat
import sys

W = os.path.abspath(sys.argv[1])
VARIANT = sys.argv[2]
USER = 'fakeuser'
if VARIANT == 'suffix':
    HOMEL = os.path.join(W, 'home', USER)
    HOMER = W + '/lustre' + HOMEL
else:
    HOMEL = os.path.join(W, 'hroot', 'home', USER)
    HOMER = os.path.join(W, 'lroot', 'lustre', 'home', USER)
BASE = os.path.join(HOMER, 'mixer_dev7_20260930_v26')
ENV = os.path.join(HOMER, '.conda', 'envs', 'myenv')
ONE_RUN = 'E0_ref_s32452843'
MAXF7 = 15000
MAXB7 = 1073741824
CAPN = 300
T0 = 1774000000
LOGS = [('E0_ref_s32452843', 'e0'), ('E0_ref_s49979687', 'e0'), ('E0_ref_s67867967', 'e0'), ('E0_ref2_s32452843', 'e0'),
        ('E0_ref_dthalf_s32452843', 'e0'), ('LHx10_ref_r2_s32452843', 'devbo'), ('LHx30_ref_r2_s32452843', 'devbo'),
        ('LU212_ref_r2_s32452843', 'devu'), ('LU637_ref_r2_s32452843', 'devu')]
CONTENT_SECRETS = ['42424242', '91827364', '86420135', '77777771', '31415926', '47979797', 'SECRET_COMMENT_ECHO', 'SECRET_WARN_TEXT',
                   'SECRET_LOG_PATHLINE', 'SECRET_CONDA_FILE', 'SECRET_JSON_LINK', 'SECRET_M_VALUE', 'SECRET_BOX']
OUT_FORBID = ['PATHMARK', 'SECRET-NODE', 'SECRET-LOGIN-HOST', 'example.org', 'fakebuilder', 'SECRET-DBHOST', '10.1.2.3']


def sha_bytes(b):
    return hashlib.sha256(b).hexdigest()


def wbytes(p, data, mtime=None, mode=None):
    os.makedirs(os.path.dirname(p), exist_ok=True)
    with open(p, 'wb') as f:
        f.write(data)
    if mtime is not None:
        os.utime(p, (mtime, mtime))
    if mode is not None:
        os.chmod(p, mode)


# ── q9b 로그 ─────────────────────────────────────────────────────────────
HEADER = '    Step    Atoms         KinEng            rke         Volume '


def row(step, atoms=42424242, ke='0.11946796', rke='1.0960987e-10', vol='2.7589053e-05', extra=None):
    s = '%8d %8d %14s %14s %14s ' % (step, atoms, ke, rke, vol)
    if extra is not None:
        s += extra + ' '
    return s


def R(step, **kw):
    return ('R', row(step, **kw))


def N(text, word):
    return ('N', text, word)


B = ('B', '')
INFO = N('INFO: Particle insertion ins: inserted 42424242 particle templates (mass 9.557437e-01) at step 1', 'INFO:')
TOTAL = N(' - a total of 42424242 particle templates (mass 9.557437e-01) inserted so far.', '-')


def pair(step):
    return [N('INFO: Particle insertion insX: inserted 91827364 particle templates (mass 1.0e-01) at step %d' % step, 'INFO:'),
            N(' - a total of 47979797 particle templates (mass 1.0e-01) inserted so far.', '-')]


def rows(a, n, d=5000, **kw):
    return [R(a + k * d, **kw) for k in range(n)]


def render_log(li, tables, crlf=False, closed_last=True):
    """tables = [ [items…], … ] → (본문, 블록이 낼 기대 줄 목록)"""
    L = ['LIGGGHTS (Version LIGGGHTS-PUBLIC 3.8.0, compiled 2026-03-26-14:37:06 by fakebuilder, git commit 3d5c00f20519e6bb6eb6756f51f1ad36564e649d)',
         '# echo — ERROR: youngsModulus <= 1e9 SECRET_COMMENT_ECHO',
         'variable rdir string %s/mixer_dev7_20260930_v26/SECRET_LOG_PATHLINE' % HOMEL,
         'Step-like but not header: Steps 31415926 here', '']
    exp_tables, exp_nr = [], []
    tot = 0
    for k, items in enumerate(tables, 1):
        L += ['Setting up run at Wed Sep 30 08:12:20 2026', '', 'INFO: Particle insertion ins: inserting every 0 steps',
              'Memory usage per processor = 5.3174 Mbytes', HEADER]
        nrow = nfr = nnr = nbl = 0
        rc = {}
        for it in items:
            if it[0] == 'R':
                L.append(it[1])
                nrow += 1
                c = len(it[1].split())
                rc[c] = rc.get(c, 0) + 1
                if any(x.lower() in ('nan', 'inf', '-nan', '-inf') for x in it[1].split()):
                    nfr += 1
            elif it[0] == 'B':
                L.append('')
                nbl += 1
            else:
                L.append(it[1])
                nnr += 1
                tot += 1
                lw = it[1][:len(it[1]) - len(it[1].lstrip(' \t'))]
                exp_nr.append('nr|%d|%d|%d|rows_before=%d|sp=%d|tab=%d|word=%s' % (li, k, nnr, nrow, lw.count(' '), lw.count('\t'), it[2]))
        closed = closed_last or k < len(tables)
        if closed:
            L.append('Loop time of 90.7581 on 20 procs for 1 steps with 42424242 atoms, finish time Wed Sep 30 08:13:51 2026')
            L.append('')
        rcs = ','.join('%d:%d' % (c, rc[c]) for c in sorted(rc)) or '-'
        exp_tables.append('table|%d|%d|header_cols=5|rows=%d|rows_nonfinite=%d|row_cols=%s|nonrow=%d|blank=%d|closed=%s'
                          % (li, k, nrow, nfr, rcs, nnr, nbl, 'yes' if closed else 'no'))
    L += ['Total wall time: 1:23:45', '']
    nl = '\r\n' if crlf else '\n'
    text = nl.join(L)
    nlines = text.count('\n')
    em = min(tot, CAPN)
    head = 'log|%d|lines=%d|tables=%d|nonrow=%d|emitted=%d|suppressed=%d|tables_suppressed=0|cr=%d' % (
        li, nlines, len(tables), tot, em, tot - em, nlines if crlf else 0)
    return text, [head] + exp_tables + exp_nr[:CAPN]


def e0_tables(n2, n3, extra1=(), t1=None):
    t1 = t1 if t1 is not None else [R(0, atoms=0, ke='0', rke='0'), INFO, TOTAL, R(1)] + list(extra1)
    return [t1, rows(1, n2), rows(518715, n3), [R(1037429)]]


def dev_tables(n4, t3=None):
    t3 = t3 if t3 is not None else [R(518715)] + pair(518716) + rows(523715, 3)
    return [[R(0, atoms=0, ke='0', rke='0'), INFO, TOTAL, R(1)], rows(1, 4), t3, rows(1037429, n4)]


def build_logs(exp):
    specs = {i: None for i in range(1, 10)}
    specs[1] = (e0_tables(4, 5), {})
    specs[2] = (e0_tables(6, 7), {})
    specs[3] = (e0_tables(3, 3), {})
    specs[4] = (e0_tables(8, 8), {})
    specs[5] = (e0_tables(10, 10), {})
    specs[6] = (dev_tables(20), {})
    specs[7] = (dev_tables(21), {})
    specs[8] = (dev_tables(22), {})
    specs[9] = (dev_tables(23), {})
    status = {i: 'OK' for i in range(1, 10)}
    if VARIANT == 'fail':
        specs[2] = (e0_tables(6, 7, extra1=[N('WARNING: Particle insertion: Less insertions than requested SECRET_WARN_TEXT', 'WARNING:')]), {})
        specs[5] = (e0_tables(10, 10, t1=[R(0, atoms=0, ke='0', rke='0'), INFO, N('  - a total of 42424242 particle templates', '-'), R(1)]), {})
        specs[6] = (dev_tables(20, t3=[R(518715), R(518716)] + pair(518717) + rows(523715, 3)), {'closed_last': False})
        status.update({3: 'FAIL', 4: 'FAIL', 7: 'DENIED', 8: 'ABSENT', 9: 'ABSENT'})
    if VARIANT == 'overflow':
        specs[1] = (e0_tables(4, 5), {'crlf': True})
        many = [N('WARNING: neighbor list overflow %d' % k, 'WARNING:') for k in range(1000)]
        specs[2] = (e0_tables(6, 7, t1=[R(0, atoms=0, ke='0', rke='0'), INFO, TOTAL, R(1)] + many), {})
        status[2] = 'TRUNC'
    if VARIANT == 'glued':
        specs[1] = (e0_tables(4, 5, extra1=[N('fakeuser: hello', '<USER>:'), N('fakeuserX: glued', '<USER>X:'),
                                            N('SECRET-NODE02x: glued', '<NODE>x:'), N('SECRET-NODE01.example.org: warn', '<NODE>.<DOMAIN>:'),
                                            N('ab12: hexnode', '<NODE>:'), N('e7 short', '<NODE>')]), {})
    logs = {}
    for i, (run, grp) in enumerate(LOGS, 1):
        tables, kw = specs[i]
        text, lines = render_log(i, tables, **kw)
        p = os.path.join(BASE, run, 'log.liggghts')
        st = status[i]
        if st == 'ABSENT':
            logs[str(i)] = {'run': run, 'group': grp, 'status': 'ABSENT', 'lines': []}
            continue
        if VARIANT == 'fail' and i == 4:
            os.makedirs(p)            # log.liggghts 가 디렉터리
            logs[str(i)] = {'run': run, 'group': grp, 'status': 'FAIL', 'lines': [], 'why': 'not_regular'}
            continue
        wbytes(p, text.encode(), T0 + 100 * i)
        if VARIANT == 'fail' and i == 3:
            os.chmod(p, 0)            # 읽기 권한 없음
            logs[str(i)] = {'run': run, 'group': grp, 'status': 'FAIL', 'lines': [], 'why': 'permission'}
            continue
        if VARIANT == 'fail' and i == 7:
            os.chmod(os.path.join(BASE, run), 0)   # 런 폴더 자체가 막힘 → stat 거부
            logs[str(i)] = {'run': run, 'group': grp, 'status': 'DENIED', 'lines': []}
            continue
        logs[str(i)] = {'run': run, 'group': grp, 'status': st, 'lines': lines}
    exp['q9b'] = {'logs': logs}


# ── q2b 프레임 ───────────────────────────────────────────────────────────
NFR = 37
ATOMS = 50


def frame_text(step, tline=None, end_nl=True):
    L = ['ITEM: TIMESTEP', tline if tline is not None else str(step), 'ITEM: NUMBER OF ATOMS', str(ATOMS),
         'ITEM: BOX BOUNDS ff ff ff', '-0.0042 0.0042 SECRET_BOX', '-0.0021 0.0021 77777771', '0 0.0084',
         'ITEM: ATOMS id type x y z vx vy vz fx fy fz radius']
    for a in range(1, ATOMS + 1):
        L.append('%d 1 0.%04d 42424242 0.5 0 0 0 0 0 0 1e-05' % (a, a))
    return '\n'.join(L) + ('\n' if end_nl else '')


def build_frames(exp):
    post = os.path.join(BASE, ONE_RUN, 'post')
    steps = [k * 1000 for k in range(1, NFR + 1)]
    mid = steps[(NFR + 1) // 2 - 1]
    first, last = steps[0], steps[-1]
    special = {}
    if VARIANT == 'fail':
        special = {first: dict(tline='01000'), last: dict(tline='36999', end_nl=False)}
    texts = {}
    for s in steps:
        t = frame_text(s, **special.get(s, {}))
        texts[s] = t
        wbytes(os.path.join(post, 'mix_%d.liggghts' % s), t.encode(), T0 + s // 1000)
    wbytes(os.path.join(post, 'mix_abc.liggghts'), b'SECRET_BOX\n', T0)
    wbytes(os.path.join(post, 'README_SECRET_NAME.txt'), b'SECRET_BOX\n', T0)
    os.makedirs(os.path.join(post, 'mix_99999.liggghts'))
    frames = []
    for pos, s in (('first', first), ('mid', mid), ('last', last)):
        t = texts[s]
        p = os.path.join(post, 'mix_%d.liggghts' % s)
        f = {'pos': pos, 'step': str(s), 'type': 'f', 'bytes': str(len(t.encode()))}
        if VARIANT == 'fail' and s == mid:
            os.chmod(p, 0)
            f.update(end_nl='-', newlines='-', l1_timestep='-', tstep='-', l3_natoms='-', atoms='-', nl_eq_9_plus_atoms='-')
        else:
            lines = t.split('\n')
            tl = lines[1]
            if tl == str(s):
                ts = 'same'
            elif tl.isdigit() and int(tl) == s:
                ts = 'num'
            elif tl.isdigit():
                ts = 'differ'
            else:
                ts = 'nonint'
            nl = t.count('\n')
            f.update(end_nl='yes' if t.endswith('\n') else 'no', newlines=str(nl), l1_timestep='yes' if lines[0] == 'ITEM: TIMESTEP' else 'no',
                     tstep=ts, l3_natoms='yes' if lines[2] == 'ITEM: NUMBER OF ATOMS' else 'no', atoms=str(int(lines[3])),
                     nl_eq_9_plus_atoms='yes' if nl == 9 + int(lines[3]) else 'no')
        frames.append(f)
    exp['q2b'] = {'head': {'files': NFR + 1, 'matched': NFR, 'other': 1}, 'sel': {'first': str(first), 'mid': str(mid), 'last': str(last)},
                  'frames': frames}


# ── q7b conda 꾸러미 ────────────────────────────────────────────────────
def F(rel, data=None):
    return ('F', rel, data if data is not None else ('SECRET_CONDA_FILE ' + rel + '\n').encode())


def Lk(rel, target):
    return ('L', rel, target)


PKGS = [
    ('openmpi', 'openmpi-5.0.10-h67ed482_1.json', 'conda', [
        F('bin/mpirun'), Lk('bin/mpiexec', 'mpirun'), F('bin/prterun'), F('bin/prted'), F('include/mpi.h'),
        Lk('lib/libmpi.so', 'libmpi.so.40.40.7'), Lk('lib/libmpi.so.40', 'libmpi.so.40.40.7'), F('lib/libmpi.so.40.40.7', b'\x7fELF SECRET_CONDA_FILE libmpi\n' * 50),
        F('lib/libopen-pal.so.80.0.5'), F('lib/openmpi/mca_coll_x.so'), F('lib/libPATHMARKq7b.so.1'), F('share/openmpi/help-mpi.txt'),
        F('share/openmpi/empty.txt', b''), F('share/openmpi/odd|name.txt'), F('share/openmpi/with space.txt')]),
    ('ucx', 'ucx-1.20.0-hf72d326_1.json', 'mini', [
        F('lib/libucp.so.0.0.0'), Lk('lib/libucp.so.0', 'libucp.so.0.0.0'), F('lib/ucx/libuct_ib.so.0.0.0'), F('bin/ucx_info'),
        F('share/ucx/doc/readme.txt')]),
    ('ucc', 'ucc-1.7.0-hcedbda0_0.json', 'tricky', [
        F('lib/libucc.so.1.0.0'), Lk('lib/libucc.so.1', 'libucc.so.1.0.0'), F('lib/ucc/libucc_tl_ucp.so')]),
    ('libfabric', 'libfabric-2.5.0-ha770c72_1.json', 'conda', []),
    ('libfabric1', 'libfabric1-2.5.0-h8f87c3e_1.json', 'conda', [F('lib/libfabric.so.1.31.0'), Lk('lib/libfabric.so.1', 'libfabric.so.1.31.0')]),
    ('libpmix', 'libpmix-5.0.8-h31fc519_4.json', 'conda', [F('lib/libpmix.so.2.13.8'), F('lib/pmix/mca_pmix.so'), F('share/pmix/help-pmix.txt')]),
    ('libhwloc', 'libhwloc-2.13.0-default_he001693_1000.json', 'conda', [F('lib/libhwloc.so.15.10.2'), F('bin/lstopo-no-graphics')]),
]
DECOYS = ['mpi-1.0.1-openmpi.json', 'openmpi-mpicxx-5.0.10-h67ed482_1.json', 'python-3.10.20-h741d88c_0.json', 'libfabric-headers-2.5.0-h0_0.json']


def json_text(name, jname, style, rels):
    obj = {'build': jname.rsplit('-', 1)[1][:-5], 'build_number': 1, 'channel': 'https://conda.anaconda.org/conda-forge/linux-64',
           'depends': ['libgcc >=14'], 'extracted_package_dir': HOMER + '/.conda/pkgs/' + jname[:-5] + '-SECRET_JSON_LINK',
           'files': rels, 'fn': jname[:-5] + '.conda', 'link': {'source': HOMER + '/.conda/pkgs/SECRET_JSON_LINK', 'type': 1},
           'name': name, 'paths_data': {'paths': [{'_path': r, 'path_type': 'hardlink', 'sha256': '0' * 64, 'size_in_bytes': 1} for r in rels],
                                        'paths_version': 1}, 'requested_spec': 'None', 'url': 'https://example.invalid/' + jname,
           'version': jname.rsplit('-', 2)[1]}
    if style == 'mini':
        return json.dumps(obj, separators=(',', ':'), sort_keys=True)
    if style == 'tricky':
        obj2 = {'aaa_decoy': {'files': ['SECRET_DECOY_PATH/x'], 'note': 'a [b] {c} "q" , : \\ end'}, 'summary': 'x ] } [ { " : ,'}
        obj2.update(obj)
        t = json.dumps(obj2, indent=2, sort_keys=True, ensure_ascii=True)
        return t.replace('"lib/libucc.so.1.0.0",', '"lib\\/libucc.so.1.0.0",', 1)
    return json.dumps(obj, indent=2, sort_keys=True, ensure_ascii=True)


def tcode(m, size):
    if stat.S_ISREG(m):
        return 'e' if size == 0 else 'f'
    if stat.S_ISLNK(m):
        return 'l'
    if stat.S_ISDIR(m):
        return 'd'
    return 'o'


def nodac_lstat(p):
    """DAC 무시 권한 없는 root 가 보는 lstat: 모든 상위 폴더에 소유자 x 가 있어야 한다 (전부 root 소유)"""
    parts = p.split('/')
    for k in range(2, len(parts)):
        d = '/'.join(parts[:k])
        try:
            if not (os.stat(d).st_mode & 0o100):
                return None
        except OSError:
            return None
    try:
        return os.lstat(p)
    except OSError:
        return None


def build_conda(exp):
    meta = os.path.join(ENV, 'conda-meta')
    os.makedirs(meta, exist_ok=True)
    pk = {}
    for k, (name, jname, style, entries) in enumerate(PKGS, 1):
        ent = list(entries)
        extra_rel = []   # (JSON 에 적는 글자 · 기대 사유)
        if VARIANT == 'fail' and name == 'ucx':
            ent.append(F('lib/libbig.a', None))
        if VARIANT == 'glued' and name == 'libhwloc':
            jname = 'libhwloc-2.13.0-fakeuserX_1000.json'
        rels = [e[1] for e in ent]
        for e in ent:
            p = os.path.join(ENV, e[1])
            os.makedirs(os.path.dirname(p), exist_ok=True)
            if e[0] == 'F':
                if VARIANT == 'fail' and e[1] == 'lib/libbig.a':
                    with open(p, 'wb') as f:
                        f.truncate(MAXB7 + 77 * 1024 * 1024)          # 성긴 파일 1.07 GiB+ → TOO_BIG (읽지 않음)
                else:
                    data = e[2]
                    if VARIANT == 'mod' and e[1] == 'lib/libucp.so.0.0.0':
                        data = data + b'CHANGED\n'
                    wbytes(p, data)
            else:
                tgt = e[2]
                if VARIANT == 'fail' and e[1] == 'lib/libucp.so.0':
                    tgt = 'libucp.so.0.0.0.missing'
                os.symlink(tgt, p)
        if VARIANT == 'overflow' and name == 'ucc':
            rels = rels + ['share/ucc/gen/f%05d.txt' % j for j in range(16000 - len(rels))]
        if VARIANT == 'fail' and name == 'ucc':
            extra_rel = ['share/café.txt', '../../etc/passwd', '/etc/hostname']
            rels = rels + extra_rel
        # 시각 고정 (링크는 자기 시각 · 파일 시각)
        for j, e in enumerate(ent):
            p = os.path.join(ENV, e[1])
            if os.path.lexists(p):
                tt = T0 + 1000 * k + j
                if VARIANT == 'mod' and e[1] == 'lib/libucp.so.0.0.0':
                    tt += 500000
                os.utime(p, (tt, tt), follow_symlinks=False)
        if VARIANT == 'fail' and name == 'ucx':
            os.remove(os.path.join(ENV, 'lib/ucx/libuct_ib.so.0.0.0'))
            os.chmod(os.path.join(ENV, 'bin/ucx_info'), 0)
            os.chmod(os.path.join(ENV, 'share/ucx/doc'), 0)
        jt = json_text(name, jname, style, rels)
        jp = os.path.join(meta, jname)
        absent = VARIANT == 'fail' and name == 'libpmix'
        broken = VARIANT == 'fail' and name == 'libhwloc'
        if broken:
            jt = jt[:jt.index('"files"') + 40]
        if not absent:
            wbytes(jp, jt.encode(), T0 + 50 * k)
        e = {'name': name, 'json': jname}
        if absent:
            e.update(status='ABSENT')
            pk[str(k)] = e
            continue
        jb = jt.encode()
        e['json_hash'] = '%s|%d|%d' % (sha_bytes(jb), len(jb), T0 + 50 * k)
        if broken:
            e.update(status='PARSE_BAD')
            pk[str(k)] = e
            continue
        lines, dig = [], []
        reasons = {}
        nh = nb = nl = 0
        listed = len(rels)
        for i, rel in enumerate(rels[:MAXF7], 1):
            if 'é' in rel:
                r = ('-', '-', '-', '-', '-', 'ESCAPED')
            elif rel.startswith('/') or rel == '..' or rel.startswith('../') or '/../' in rel or rel.endswith('/..'):
                r = ('-', '-', '-', '-', '-', 'UNSAFE_PATH')
            else:
                p = os.path.join(ENV, rel)
                ls = nodac_lstat(p)
                if ls is None:
                    r = ('-', '-', '-', '-', '-', 'NO_LSTAT')
                else:
                    lt, lm = tcode(ls.st_mode, ls.st_size), str(int(ls.st_mtime))
                    if lt == 'l':
                        nl += 1
                    try:
                        ts_ = os.stat(p)
                        if nodac_lstat(os.path.realpath(p)) is None:
                            raise OSError
                    except OSError:
                        ts_ = None
                    if ts_ is None:
                        r = (lt, lm, '-', '-', '-', 'BROKEN')
                    else:
                        tt_, tsz, tm = tcode(ts_.st_mode, ts_.st_size), ts_.st_size, str(int(ts_.st_mtime))
                        if tt_ not in ('f', 'e'):
                            r = (lt, lm, tt_, str(tsz), tm, 'NOT_REGULAR')
                        elif tsz > MAXB7:
                            r = (lt, lm, tt_, str(tsz), tm, 'TOO_BIG')
                        elif not (os.stat(os.path.realpath(p)).st_mode & 0o400):
                            r = (lt, lm, tt_, str(tsz), tm, 'HASH_FAIL')
                        else:
                            with open(p, 'rb') as f:
                                h = sha_bytes(f.read())
                            r = (lt, lm, tt_, str(tsz), tm, h)
                            nh += 1
                            nb += tsz
            if len(r[5]) != 64:
                reasons[r[5]] = reasons.get(r[5], 0) + 1
            lines.append('f|%d|%s|%s|%s|%s|%s|%s' % ((i,) + r))
            dig.append('%d|%s|%s|%s|%s\n' % (i, r[0], r[2], r[3], r[5]))
        e.update(status='TRUNC' if listed > MAXF7 else ('OK' if not reasons else 'FAIL'), listed=listed, in_list=min(listed, MAXF7),
                 escaped=sum(1 for r in rels if 'é' in r),
                 over_cap=max(0, listed - MAXF7), hashed=nh, bytes_hashed=nb, links=nl, reasons=reasons,
                 files_lines=lines, digest=sha_bytes(''.join(dig).encode()), digest_lines=len(dig))
        pk[str(k)] = e
    for d in DECOYS:
        wbytes(os.path.join(meta, d), b'{"files": ["lib/SECRET_JSON_LINK"], "name": "decoy"}', T0)
    os.utime(meta, (T0, T0))
    exp['q7b'] = {'pkgs': pk}


def main():
    for d in (HOMER, os.path.dirname(HOMEL), os.path.join(W, 'cwd'), os.path.join(W, 'tmp_outer')):
        os.makedirs(d, exist_ok=True)
    os.symlink(HOMER, HOMEL)
    exp = {'variant': VARIANT, 'home_login': HOMEL, 'home_real': HOMER, 'user': USER, 'secrets': CONTENT_SECRETS, 'out_forbid': OUT_FORBID}
    build_frames(exp)
    build_logs(exp)
    build_conda(exp)
    wbytes(os.path.join(BASE, '.e0_diag', 'vault.json'), b'{"M": "SECRET_M_VALUE"}\n')
    with open(os.path.join(W, 'expect.json'), 'w') as f:
        json.dump(exp, f, indent=1, sort_keys=True)


if __name__ == '__main__':
    main()

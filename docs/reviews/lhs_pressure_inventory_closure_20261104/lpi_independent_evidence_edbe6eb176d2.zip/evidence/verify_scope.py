import pathlib,hashlib,json,ast,subprocess,re,zipfile
B=pathlib.Path(__file__).resolve().parent.parent;S=B/'source';E=B/'evidence';D=S/'docs/reviews/lhs_pressure_inventory_20261104';F=S/'docs/reviews/lhs_pressure_inventory_lpi_fix_20261104';I=S/'docs/reviews/lhs_pressure_inventory_review_intake_20261104'
sha=lambda b:hashlib.sha256(b).hexdigest(); remote=json.loads((E/'remote_evidence.json').read_text())
old=remote['prior_command']['content'];new=(D/'pressure_inventory.sh').read_text();assert old==(F/'before/pressure_inventory.sh').read_text()
def core(text):
 code=text.split("-c '\n",1)[1].split("\n' \"$@\"",1)[0];tree=ast.parse(code)
 return [ast.dump(n,include_attributes=False) for n in tree.body if not (isinstance(n,ast.FunctionDef) and n.name=='main') and not isinstance(n,ast.If)]
assert core(old)==core(new)
b7=(S/'scripts/lhs_pressure_record.py').read_bytes();assert b7==remote['prior_b7']['content'].encode()
ns={'__name__':'scope'};exec(new.split("-c '\n",1)[1].split("\n' \"$@\"",1)[0],ns)
b7tree=ast.parse(b7);regex=[n.value.args[0].value for n in b7tree.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='PRESS_LINE' for t in n.targets)][0];assert regex==ns['PRESS_LINE'].pattern
before=json.loads((E/'source_before.json').read_text());after={p:sha((S/p).read_bytes()) for p in before};assert before==after
expected={'pressure_inventory.sh':'2305bd2194b29ac5439008906a17b1c673968a59fd52dcdde35b03ff4da20634','test_pressure_inventory.py':'633fc2f4164d350a68a6d9546bdb31174995cec18a639084e58d0a63bafeeeeb','test_output_contract.py':'4490d46fa5d1ca0243e215eee8bd5f3c98e5005f9ae6c77079b71f675d483648'}
for p,h in expected.items():assert sha((D/p).read_bytes())==h
assert sha(b7)=='34eb74142884489505590501840ccc6423a014a508989c82f135020146283ad3'
zp=I/'codex_lhs_pressure_inventory_review_evidence_20261104.zip';assert sha(zp.read_bytes())=='00c6f07b273d55e3717bde6591ae69314dda439c97574fa6b74fe3216e3f5ef0'
z=zipfile.ZipFile(zp);assert z.testzip() is None
# Check fixed-pin worktree bytes against fetched Git objects, not branch tip.
blobs=[]
for p in before:
 raw=(S/p).read_bytes(); actual=hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest();git=subprocess.check_output(['git','-C',str(S),'rev-parse','HEAD:'+p],text=True).strip();assert actual==git;blobs.append({'path':p,'bytes':len(raw),'sha256':sha(raw),'git_blob_sha1':git})
mutation=[]
for p in sorted((B/'mutations/evidence').glob('*.log')):
 s=p.read_text();total=int(re.search(r'Ran (\d+) tests',s)[1]);fail=len(re.findall(r' \.\.\. FAIL$',s,re.M));err=len(re.findall(r' \.\.\. ERROR$',s,re.M));passed=len(re.findall(r' \.\.\. ok$',s,re.M));assert total==fail+err+passed
 mutation.append({'name':p.stem,'tests':total,'passed':passed,'failures':fail,'errors':err,'rc':1,'version':'Python 3.11.17'})
result={'source_before_after_identical':True,'source_files':len(before),'pin_git_blob_matches':len(blobs),'non_main_non_entry_ast_identical':True,'prior_remote_command_equals_preserved_before':True,'b7_prior_current_bytes_identical':True,'regex_pattern_equal':True,'prior_zip_sha256':sha(zp.read_bytes()),'prior_zip_crc_ok':True,'mutations':mutation,'original_status':subprocess.check_output(['git','-C','/workspace/Yonghoon-DEM-DFT','status','--porcelain'],env=dict(__import__('os').environ,GIT_OPTIONAL_LOCKS='0'),text=True),'scratch_status':subprocess.check_output(['git','-C',str(S),'status','--porcelain'],text=True),'remote_changed_paths_count':len(remote['remote_compare']['files']),'remote_changed_paths_confined_to_review_and_handoff':all(x['filename'].startswith(('docs/reviews/lhs_pressure_inventory','docs/collab/codex_to_claude/20261104-')) for x in remote['remote_compare']['files'])}
(E/'scope_verified.json').write_text(json.dumps(result,indent=2));(E/'pin_blob_manifest.json').write_text(json.dumps(blobs,indent=2));(E/'source_after.json').write_text(json.dumps(after,indent=2));print(json.dumps(result,indent=2))

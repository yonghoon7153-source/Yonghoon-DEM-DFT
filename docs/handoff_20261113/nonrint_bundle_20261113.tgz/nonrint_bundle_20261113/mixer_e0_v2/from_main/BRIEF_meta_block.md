# 믹서 E0 자격 pilot 한 팔 — 1 단계: ibb 읽기 전용 메타 수집 블록 초안 (2026-11-10)

1저자 11-10: *"codex 의존하지말고 지금 할 수 있는거 다해"* · 믹서 E0 자격 pilot 한 팔은 내부 반박 리뷰가 Codex GO 를 대신한다 (그 한 팔만 · 발사 GO = 1저자).
이번 일 = 그 pilot 의 **첫 단계** 인 "ibb 메타 수집 블록" 초안. 계산 · 제출 · 예약 해제는 하지 않는다.

## 읽을 것 (읽기만)
- 계획 (Codex 실무 창 · 아직 stoic 에 반입 전 · 시험 트리에 있음): /home/user/Yonghoon-DEM-DFT/.claude/worktrees/agent-a26924cf661ba0325/docs/reviews/mixer_qualification_plan_20261110.md · 같은 트리의 docs/reviews/mixer_scope_followup_20261110/README.md · docs/collab/codex_to_claude/20261110-0246_mixer-scope-followup.md · 20261110-0247_mixer-qualification-plan.md
- 본 리포 (/home/user/Yonghoon-DEM-DFT · 읽기만): docs/reviews/mixer_highbo_prereg_20260927.md (등록 v2.x · §8 · §10 · §11 · §12 · DEV7 E0 · NP20 · 확인 블록) · docs/reviews/mixer_layered_prereg_20260921.md 의 E0 · 런처 · 정책 (scripts/ 의 mixer 관련 · launch_policy.json · start_check.py · mixer_smoke_blind.py --e0-diag) · CLAUDE.md 의 믹서 표 줄 (09-28 ~ 10-06) · docs/dem1/dem1_kit/DEM1_handoff.md (붙여넣기 규칙만 참고).
- 메모리 규칙: ibb 접속 별칭 없음 · 주소 · 포트 · 계정은 리포 · 문서에 쓰지 않는다 (블록 안에서는 $HOME · $USER 만).

## 만들 것 (scratch 에만 · 리포에 쓰지 않는다)
1. <SCRATCH> — 1저자가 ibb 셸에 붙일 블록 하나.
   - 읽기 전용: 새 폴더 ~/mixer_e0_meta_<UTC시각>/ 하나만 만들고 그 안에만 쓴다 · 다른 파일 · 폴더 · 잡 · 큐는 바꾸지 않는다 (sbatch · scancel · scontrol · git pull/checkout · rm · mv 없음).
   - 모으는 것 (계획 문서가 요구하는 칸을 우선 · 아래는 후보): LIGGGHTS 실행 파일 경로 · sha256 · 크기 · mtime · `-h` 머리 줄 (배너 · 빌드 날짜) · 링크 라이브러리 (ldd) · mpirun 판 · module list · SLURM 파티션 · QOS 한도 (sinfo · sacctmgr show qos 읽기) · 지금 내 잡 (squeue -u $USER) · 디스크 (df -h $HOME · quota 가 있으면) · 믹서 확인 블록 · DEV 런 폴더가 있으면 목록 · 크기 · 봉인 파일 sha256 (읽기만) · 체크아웃이 있으면 git rev-parse HEAD · git status --porcelain (읽기만) · python3 판.
   - 끝에 그 폴더를 tgz 하나로 묶고 sha256 을 화면에 찍는다 (1저자가 가져올 파일 하나).
   - 붙여넣기 안전 (DEM1 규칙): `!` 없음 · 탭 없음 · heredoc 구분자 따옴표 · md5 게이트 꼴 (블록 마지막 줄에서 스크립트 md5 를 대조하고 맞을 때만 실행 · 다르면 아무것도 안 함) · 명령이 없으면 그 칸을 MISSING 으로 적고 계속 (멈추지 않음) · 시간 상한 (timeout) 이 있는 명령만.
2. <SCRATCH> — (a) 계획 문서의 E0 pilot 단계 목록 (메타 수집 → 기준 고정 → 봉인 → 내부 리뷰 → 1저자 GO) 과 지금 블록이 그중 어디까지인지 (b) 블록이 모으는 칸 ↔ 계획 문서의 요구 칸 대응표 (빠진 칸은 "블록으로 못 모음 · 1저자 확인" 으로) (c) 받은 묶음을 본 세션이 읽는 법 (빈 폴더에 풀고 python -I) (d) 다음 단계 (기준 고정 · 봉인) 에 필요한 결정 목록 (권고 한 줄씩) (e) 미확인 · 추정 표지.
3. 블록을 이 컨테이너에서 가짜 명령 (없는 명령 · 실패하는 명령 섞어) 으로 한 번 돌려 rc · 만든 파일 목록 · md5 게이트 (한 글자 깨짐 · CRLF) 를 확인하고 README 에 적는다 (컨테이너에는 SLURM · LIGGGHTS 가 없다 — 그 칸은 MISSING 이 나와야 정상).

## 하지 않는 것
- 계산 · 제출 · 리포 쓰기 · git 쓰기 명령 · 다른 세션 파일 고치기. 문턱 · Bo · seed · 칸 규약 바꾸기. 확인 18 런 이야기.

## 답장 (12 줄 안)
블록 줄 수 · md5 · 모으는 칸 수 · 계획 요구 칸 중 못 모으는 것 · 컨테이너 시험 결과 · 1저자가 정할 것 (권고 한 줄씩).

#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Rint ② D — SV 반사실 대조의 **증거 꼴** (등록 R §5-6 SV 행 · Codex RCA-06 · 1저자 Q4 · 2026-10-21).

반사실 대조 = 같은 침대 · 같은 R_j 에서 SV 융합 면 (어느 면을 끊는지 = producer `carbon_junction.CjuncSolver.sv_counterfactual` 의 정의) 을
끊은 판을 한 번 더 풀어 단자 G 비 (`sv_counterfactual_ratio` = G_full/G_cut ≥ 1 · Rayleigh) 를 낸다.  문턱 (`SV_DEPENDENT`) = 사슬 계획
(`rint_r_chain` · 등록 R §5-6 · producer 는 비만 낸다 — 이 배선의 요청은 늘 `{'threshold': None}`).

이 모듈 = 그 원 기록의 **JSON 투영** (payload · 증거 `ca_ext.cjunc.evidence.solve.sv_counterfactual`) 과 **검증기** (`run_contract.ca_ext_record_ok`
가 접합 블록 검증 뒤 부른다).  접합 모듈 (A 소관) 밖에 둔다 — 그리고 **끊는 면의 정의에 기대지 않는다** (사전 리뷰 PRE-impl-04 · 코디네이터
10-21 Q-D): 읽는 칸 = 비 · 상태 · 표지 (· ~~종류는 'counterfactual…' 이기만 하면 아무 정의~~ → ★ 10-23 (사전 공격 리뷰 C5 · 1저자 Q14 (가))
종류 · 규칙 = 등록된 이름 (`SV_CF_KIND` · `SV_CF_RULE` = 생산자 `carbon_junction.CJUNC_SV_CF_KIND` · `CJUNC_SV_CF_RULE` · 시험이 대조) 만 받는다 —
**이름 대조뿐** (그 이름이 뜻하는 끊기 정의를 검증기가 다시 세지 않는다 · 옛 판 = 접두어만 보고 규칙은 투영에서 버려 다른 정의의 기록 · 철회된
옛 정의 이름을 받았다) · 정의별 수 칸 `n_*` 은 이름 그대로 옮긴다).
· 비 +∞ (위상 — 끊은 그래프에 관통 성분 없음) = JSON 비 null + `ratio_limit` 'inf' (극한 R_j 의 `R_j_ohm` null + `rj_limit` 'inf' 와 한 꼴)
· 비를 싣는 상태 = `RATIO_STATUSES` 둘뿐 — 그 밖의 상태 (미수렴 · 수치 실패 · 주 해 미수렴 · 앞으로 producer 가 더할 이름) = 비 없음 →
  사슬은 그 모서리를 `SV_UNCHECKED` 로 센다 (fail-closed · 모르는 상태를 '의존 없음' 으로 읽지 않는다)
★ 10-22 (사전 리뷰 2 회차 PRE2-impl-01 · 1저자 Q1 (다) · 등록 R §5-6 SV 행 개정) 괄호 칸 — 못 가른 덩어리 수 (`n_unsplit_bridging_components`) ·
  규칙 (`bracket_rule`) · 위 끝 상태 · 비 (`status_hi` · `sv_counterfactual_ratio_hi` · +∞ = null + `ratio_limit_hi` 'inf') · 위 끝 풀이 기록
  (`upper` · 아래 끝과 같은 꼴 · 덩어리 0 = None) → 검증기 (꼴 · 덩어리 수 ↔ 위 끝 기록 · 덩어리 0 = 위 = 아래 · 위 끝 칸 = 위 끝 풀이 기록) ·
  사슬 꼴 (아래 끝 · 위 끝 · 덩어리 수 — 위 끝 칸이 없는 옛 기록 = 위 끝 못 읽음 · fail-closed).  비 값의 대조 (G 비 · 아래 ≤ 위) = 다른 묶음
  → ★ PF2 E (10-22 · PRE2-impl-02) `_values_problem` — 비 = G_full/G_cut · 비 ≥ (1 − τ)/(1 + τ) · 증서 ok · computed ↔ G_cut 유한 양수 ·
  no_through ↔ G_cut 0 · 위 끝도 같은 규칙 · 괄호 아래 ≤ 위 (같은 증서 폭 여유) · 사슬 꼴은 유한 양수 · +∞ 만 읽는다.
★★ 10-23 (Codex 재검토 RCA2-01 · 04 · 1저자 Q1 (가) · author 10-23 ratified Q1-Q8) **증서 구간 판정** — 옛 판정은 풀이가 낸 비 하나 (nominal)
  를 문턱과 비교했다 (판정문 반례: nominal 10.291249475344962 < 문턱 10.291251705345072 인데 증서가 보장하는 참 비 구간 전체가 문턱 위).
  · 투영이 주 해 (`conv_cert_full`) · 끝마다 (`conv_cert`) 증서의 목표량 구간 (`target_lo` · `target_hi`) · 게시 판 전류 (`I_bot`) · 결합 칸을
    버리지 않는다 (`_cert_proj`) · 기록 지위 (`standing` — 증서 구간 = 증서를 켠 런 · 진단 = 증서 없는 런) · 판정 근거 칸
    `ratio_cert_interval` = [아래비, 위비] (`cert_interval` — 아래비 = Gfull_lo / Gcut_lower_hi (내림) · 위비 = Gfull_hi / Gcut_upper_lo (올림) ·
    정확 분수 · +∞ = 그 끝의 영값 위상 증서가 증명한 0 분모만 · 못 정하면 None · JSON 의 +∞ = 'inf').
  · 사슬 꼴 (`chain_view`) 이 같은 함수로 다시 센다 (`ratio_cert_lo` · `ratio_cert_hi` · nominal 비 = 기록만 · 판정에 쓰지 않는다).
  · 기록 계약 (`sv_cf_problem` — 실제 소비자 `run_contract.ca_ext_record_ok`): 증서 구간 기록의 비를 싣는 끝마다 현 증서 필수 (판 · 상태 ·
    ⓐ–ⓓ · 목표량 판 · 봉인) · 증서 ↔ 그 끝의 G (게시 판 전류 = G 정확히 · 목표량 구간을 같은 판정 함수 `step3_conv_cert.target_judge` 로
    다시 봄) · 분자 G_full = 주 해 증서 · 솔브 기록 `I_bot_code` · 결합 칸 = 주 해 증서 = 증거 `fp` (다른 회로 · 다른 런 증서 = 거부 — ★ 10-23 C1
    같은 런의 주 해 증서를 끝 자리에 옮긴 꼴은 아래 C1 절의 위상 수 대조가 잡는다) ·
    괄호 규칙 = 등록된 값만 (`BRACKET_RULES`) · 수 칸 = 0 이상 정수 · int64 범위 · 제거 성분 수 = 못 가른 덩어리 수 · 제거 셀 수 ≥ 성분 수 ·
    실제 census (증거 `census`) 와 일관 (못 가른 ⊆ 다리 놓는 ⊆ 닿는 성분) · 진단 기록 = 증서 없음 (사슬은 R 판정 입력으로 받지 않는다 =
    SV_UNCHECKED) · 판정 근거 칸 = 기록의 증서에서 다시 센 값.
★ 10-23 (Codex 재검토 RCA2-06 F6 · author 10-23 ratified Q1-Q8) 위 끝 구조화 실패 `unsplit_census_mismatch` (census 의 못 가른 덩어리 수 ≠ 지문
  묶인 원장에서 다시 가른 수 · 위 끝을 풀지 않음 · fail-closed) = 끝-끝 보존 — 검증기가 그 꼴 (`_mismatch_problem`: 다시 가른 수 ≠ census 수 ·
  사유 · 풀이 칸 없음 · 위 끝 칸 = (상태, None, None)) 을 받는다 (옛 판 = 못 가른 덩어리 0 꼴을 '위 끝 기록' 으로 게시 거부 · 덩어리 > 0 꼴은
  꼴을 보지 않고 받음) → 사슬 = 위 끝 못 읽음 (SV_UNCHECKED · 사유에 상태 이름 · `rint_r_chain.sv_corner_label`).
★ 10-23 (사전 공격 리뷰 C1 · 1저자 Q12 (가) · author 10-23 ratified Q12-Q16) 끝 증서 ↔ 그 끝의 끊은 그래프 — 옛 결합 = 증서 ↔ 그 끝의 G 하나
  (`_pos_cert_problem` 게시 판 전류) + 런 단위 결합 칸 (`BIND_FIELDS`) → 같은 런의 주 해 증서를 끝 자리에 옮기고 G · 비 · 판정 근거 칸을 같이 고친
  기록을 받았다 (리뷰 A2 · 거짓 clear).  투영이 증서 위상 수 (`CERT_TOPO_KEYS`) 를 싣고 검증기 (`_topo_problem`) 가 끝마다 주 해 증서 · 기록의
  끊은 수 (`n_sv_faces_cut` · 위 끝 `n_edges_cut` · `n_plate_couplings_cut`) 와 대조한다 — 생산자 (`carbon_junction.CjuncAssembler._assemble`) 가
  보장하는 관계 (판 결합 수 · 부분 그래프 ≤ · 끊은 것 없음 = 같은 계 · 위 끝 n_sv_faces_cut = 아래 끝) + 등록 핵심 조건 (끊었으면 주 해보다 작다 ·
  같은 수 = 거부).  이 수 칸은 생산자 조립의 '뺀 간선 · 판 결합 수' 로 읽는다 — 어느 면을 끊는지 (끊을 면 규칙) 에는 여전히 기대지 않는다.
★ 10-23 묶음 A″ (1저자 Q17 (가) · Q18 (가) · author 10-23 ratified Q17-Q18 (가)) 핵심 조건 (`_topo_problem` ⑥) 의 '끊은 것' = 생산자가 끝마다 따로
  내는 판에 닿는 성분에서 끊은 쌍 수 (`n_reach_pairs_cut` — 주 계 가지치기와 같은 판정 · 병렬 간선 = 한 쌍 = 증서 간선 수의 셈 · 위 끝은 +
  `n_plate_couplings_cut`) — 옛 판 = 떠 있는 성분을 버리기 전에 센 `n_sv_faces_cut` 으로 판단해 끊은 다리가 판에 닿지 않는 성분에만 있는 정상 기록
  (FLOAT) · 끊는 면 옆에 같은 두 dof 를 잇는 간선이 남는 정상 기록 (S3 c = 1 축약) 을 거부했다 (거짓 거부) · 새 칸 ↔ 옛 칸 = 생산자 보장 관계만 (⑧) ·
  끊은 수 칸까지 같이 고친 일관 편집 · 위 끝 ← 아래 끝 증서 = 받는다 (Q18 (가) · 한정 · Codex 회차 ①) · 새 칸만 0 으로 고친 바꿔 끼우기 = 정직한
  FLOAT 기록과 같은 꼴이라 받는다 (가를 수 없다 · `_topo_problem` ⚠).
★ 10-25 묶음 B (X3 · X5 · 1저자 10-23 Q21 (가) · author 10-23 ratified Q2-Q3 Q20-Q21) X3 — 생산자가 위 끝에 아래 끝 계 대비 판에 닿는 성분에서 끊은
  쌍 수 (`n_reach_pairs_cut_vs_lower`) 를 낸다 → 두 끝 computed 면 위 끝 위상 수 ≠ 아래 끝 ⇔ 그 수 + `n_plate_couplings_cut` > 0 (`_topo_problem` ⑨ ·
  옛 판 = 위 끝 ≤ 아래 끝 만 → 아래 끝 ← 위 끝 증서 (끊은 수 그대로) 를 받았다) · X5 — 수 칸 꼴 · ⑦ · ⑧ 관계를 비를 싣는 끝이 있는 기록 전부에서
  (computed 끝이 없어도 · 위 끝 = 상태와 무관 · 옛 판 = computed 끝이 있을 때만).  ⚠ X3 와 같은 위상 꼴 (두 끝 증서 위상 수가 같아진다) 인 위 끝 ←
  아래 끝 증서 (한정 (c)) · 위 끝 ← 주 해 증서 (아래 끝 = 주 해인 기록 · 한정 (b) (b′)) 도 끊은 수 그대로면 거부된다 — 새 칸까지 0 으로 고친 일관
  편집은 받는다 (남은 한정 · `_topo_problem` ⚠).
★ 10-26 묶음 B6 (Codex 회차 ① RR1-01 · 1저자 10-26 Q1 · Q2 (가) · author 10-23 ratified Q2-Q3 Q20-Q21 (bundle B 10-25)) 끝 증서의 가중 그래프 귀속 —
  위상 수 넷은 가중 그래프를 정하지 않는다 (판정문 §3: 병렬 간선 하나를 뺀 끝 = 고유 쌍 · dof · 판 결합 수 그대로 · k 0 · census 그대로인데 단자 G 가
  다르다 → 같은 런의 주 해 증서를 아래 끝 자리에 옮긴 기록이 계약을 지나 문턱 1.01 에서 거짓 clear).  생산자 (`carbon_junction.solved_graph_fp`) 가
  주 해 · 끝 증서마다 그 증서가 푼 계의 정규 가중 그래프 지문 (`GRAPH_KEY` = dof 식별 집합 · 쌍별 정확 합산 전도도 · 판 결합) 을 싣고 투영이 옮긴다 ·
  계약 = 증서 구간 기록의 증서마다 지문 꼴 (hex64 · 원천 없는 문맥 = 꼴만) · 원천을 준 소비자 (`sv_cf_problem(graphs=)` · `run_contract.ca_ext_record_ok
  (graphs=)` · 사슬 `rint_r_chain.read_run`) = SV 기록 밖 봉인 원천에서 솔브 없이 다시 조립한 지문 (`step3_sigma.solve_sigma_z(cjunc_graph_only=True)`)
  과 대조 (`graph_problem` · 다르면 구조화 실패) · 사슬 판정은 원천 대조를 지난 기록만 받는다 (원천 없음 · 실패 = `SV_UNCHECKED`).  금지 (판정문 §3) =
  사본끼리 비교 · `G_cut != G_full` 규칙 · 원시 간선 개수 — 정직한 FLOAT (아래 끝 지문 = 주 해) · 등전위 다리 (G 같음) 를 받는다.  ⚠ 한정 = 증서 칸
  지문까지 원천 값으로 같이 고친 편집 (증서 수는 다른 끝 그대로) 은 못 가린다 (지문 = 그래프 정체성 · 증서 수의 재증명 아님).
numpy 없이 뜬다 (`numbers` · `fractions` · 원 기록의 numpy 수도 받는다 · 검증기의 증서 대조만 `step3_conv_cert` 를 그 자리에서 부른다)."""
import math
import numbers
import struct
import sys
from fractions import Fraction

#: 비를 싣는 상태 → 비의 꼴 (finite = 유한 양수 · inf = +∞ · JSON null + 'inf')
RATIO_STATUSES = {'computed': 'finite', 'no_through_without_sv': 'inf'}
#: 지금 producer 가 내는 상태 낱말 (기록 · 문서용 — 검증기는 이 목록 밖 상태도 '비 없음' 이면 받는다 · 정의 무관)
KNOWN_STATUSES = ('computed', 'no_through_without_sv', 'unconverged', 'nonpositive_cut_current', 'nonpositive_full_current',
                  'main_unconverged', 'cjunc_electrode_short', 'all_floating_dropped', 'no_through_component',
                  'unsplit_census_mismatch')       # ★ 10-23 (RCA2-06 F6) = `UNSPLIT_MISMATCH` (위 끝 구조화 실패 · 검증기 `_mismatch_problem`)
#: ★ 10-23 (사전 공격 리뷰 C5 · 1저자 Q14 (가) · author 10-23 ratified Q12-Q16) 반사실 기록 종류 · 끊기 규칙 = 등록된 생산자 이름 (=
#:   `carbon_junction.CJUNC_SV_CF_KIND` · `CJUNC_SV_CF_RULE` · 시험 S8q 가 대조) — 이 밖의 값 = 거부 (이름 대조뿐 · 옛 `KIND_PREFIX` 'counterfactual'
#:   접두어 검사 철회 · 옛 이름 'counterfactual_cut_sv_faces' = SV 면 전부를 끊는 다른 양)
SV_CF_KIND = 'counterfactual_cut_sv_bridges_keep_self_v1'
SV_CF_RULE = 'sdcp_component_owner_groups_same_piece_continuity_or_covered_through_cut_nonpassing_v1'
FLAGS = (None, 'SV_DEPENDENT')
#: ★ PF2 E (10-22 · 사전 리뷰 2 회차 PRE2-impl-02 · 결정 없음) — 기록 안 수의 다시 대조.  τ = 수렴 증서 ⓓ 의 보장 상대 오차
#   (= `step3_conv_cert.CERT_TARGET_TOL` · |G − G*| ≤ τ·G · 시험 S8o 가 대조 · 이 모듈은 numpy 없이 뜬다)
CERT_TARGET_TOL = 1.0e-4
#: 비 = G_full/G_cut 다시 셈 허용 (상대 · float 나눗셈 반올림 수준)
RATIO_REL_TOL = 1e-12
#: 증서 폭 꼴 여유 (새 숫자 없음) — 두 풀이가 각각 |G − G*| ≤ τ·G 면 참 비 ≥ 1 (Rayleigh) ⟹ 기록 비 ≥ (1 − τ)/(1 + τ) · 같은 G_full 의 두 끝
#   (괄호 위 = 덩어리를 더 뺀 판 · 참 G_cut,hi ≤ G_cut,lo) ⟹ 기록 위 ≥ 아래 × (1 − τ)/(1 + τ)
RATIO_FLOOR = (1.0 - CERT_TARGET_TOL) / (1.0 + CERT_TARGET_TOL)
CERT_OK_STATUS = 'POSITIVE_SOLVED'    # = `step3_conv_cert.STATUS_POSITIVE` (비를 낸 풀이 = 관통 성분이 있는 양의 해)
CERT_ZERO_STATUS = 'VALID_ZERO_TOPOLOGY'   # = `step3_conv_cert.STATUS_ZERO` (+∞ 의 분모 0 = 위상이 증명한 꼴)
#: ★ 10-23 (Codex 재검토 RCA2-01 · 04 · 1저자 Q1 (가)) 기록 지위 (= `carbon_junction.SV_CF_STANDING_*` · 시험이 대조) — 증서 구간 = 주 해 · 끝마다
#   수렴 증서를 실은 기록 (증서를 켠 런) · 진단 = 증서 없는 런의 기록 (사슬은 R 판정 입력으로 받지 않는다 → SV_UNCHECKED)
STANDING_CERTIFIED = 'certified_interval'
STANDING_DIAGNOSTIC = 'diagnostic_uncertified'
STANDINGS = (STANDING_CERTIFIED, STANDING_DIAGNOSTIC)
#: +∞ 끝 영값 위상 증서의 그래프 이름표 (= `carbon_junction.SV_CF_ZERO_GRAPH` · 시험이 대조 — 끊은 반사실 그래프가 증명한 0 · 다른 그래프의 0 = 거부)
ZERO_GRAPH_SV_CF = 'cjunc_sv_counterfactual'
#: 등록된 괄호 규칙 (= `carbon_junction.CJUNC_SV_CF_BRACKET_RULE` · 시험이 대조 · 등록 R §5-6 SV 행 · 이 밖의 낱말 = 거부)
BRACKET_RULES = ('lower_keep_unsplit_upper_remove_unsplit_sdcp_cells_v1',)
#: 위 끝 구조화 실패 (= `carbon_junction.SV_CF_UNSPLIT_MISMATCH` · 다시 가른 수 ≠ census 수 = 그 상태의 정의 · 제거 수 대조 밖 · 꼴 = `_mismatch_problem`)
UNSPLIT_MISMATCH = 'unsplit_census_mismatch'
#: ★ 10-23 (RCA2-06 F6) 구조화 실패 끝의 풀이 칸 — 풀지 않은 끝 = 전부 없다 (생산자 `carbon_junction._sv_cf_upper_unsolved` 정의: 비 · 표지 (투영) ·
#   G_cut · 잔차 · CG · 증서 · backend 는 None · 제거 셀 · 끊은 간선 · 판 결합 · SV 면 수 · ★ 10-23 묶음 A″ 판에 닿는 성분에서 끊은 쌍 수 · ★ 10-25
#   묶음 B 아래 끝 계 대비 끊은 쌍 수는 푼 끝만 싣는다)
MISMATCH_EMPTY_KEYS = ('sv_counterfactual_ratio', 'ratio_limit', 'G_cut_code', 'resid', 'cg_info', 'conv_cert', 'backend_last_solve',
                       'n_cells_removed', 'n_edges_cut', 'n_plate_couplings_cut', 'n_sv_faces_cut', 'n_reach_pairs_cut',
                       'n_reach_pairs_cut_vs_lower')
#: 수 칸의 의미 범위 (0 이상 · int64 — 10**400 같은 값 = 거부 · RCA2-04)
COUNT_MAX = 2 ** 63 - 1
#: ★ 10-23 (사전 공격 리뷰 C1 · 1저자 Q12 (가) · author 10-23 ratified Q12-Q16) 증서 자신의 위상 수 (`step3_conv_cert.target_bracket` 이 그 풀이의
#   원장에서 센 수 — 간선 = L 위 삼각 비대각 쌍 (병렬 간선 = 한 쌍) · dof · 아래 · 위 판 결합 수) — 끝 증서를 그 끝의 끊은 그래프에 묶는다
#   (`_topo_problem` · 옛 판 = 투영이 버렸다 → 같은 런의 주 해 증서를 끝 자리에 옮겨도 받았다)
CERT_TOPO_KEYS = ('target_n_edges', 'target_n_dof', 'target_n_plate_bot', 'target_n_plate_top')
#: ★ 10-26 묶음 B6 (Codex 회차 ① RR1-01 · 1저자 10-26 Q1 · Q2 (가) · author 10-23 ratified Q2-Q3 Q20-Q21 (bundle B 10-25)) 증서가 푼 계의 정규 가중
#   그래프 지문 칸 (= `carbon_junction.CJUNC_GRAPH_KEY`) · 규칙 (= `carbon_junction.CJUNC_GRAPH_FP_RULE` · 시험 QG 가 대조) · 봉인 원천 꼴의 칸
#   (`step3_sigma.solve_sigma_z(cjunc_graph_only=True)` 의 `cjunc_graphs` · 사슬 `rint_r_chain.SV_GRAPH_SOURCE` 가 돌려주는 꼴)
GRAPH_KEY = 'fp_cjunc_graph'
GRAPH_FP_RULE = 'solved_graph_dof_ids_pair_exact_sum_plates_v1'
GRAPH_SOURCE_KEYS = ('rule', 'main', 'lower', 'upper')
#: 증서 투영 칸 (★ 10-23 — 목표량 구간 · 게시 판 전류 · 영값 위상 칸 · 결합 칸까지 · 옛 판 = 판 · 상태 · ok · ⓐ–ⓓ 만 → 다른 회로 증서를 못 가렸다 ·
#   ★ 10-23 C1 위상 수 넷 · ★ 10-26 묶음 B6 가중 그래프 지문)
CERT_PROJ_KEYS = ('version', 'status', 'ok', 'pass_a', 'pass_b', 'pass_c', 'pass_d', 'I_bot', 'target_lo', 'target_hi',
                  'target_version', 'target_fp', 'target_tol', 'zero_source', 'zero_graph', 'reason', 'n_through_dof', 'sigma',
                  'bind_version', 'fp_sid', 'fp_sig', 'fp_face_plan', 'fp_cjunc_registry', 'fp_cjunc_rows') + CERT_TOPO_KEYS + (GRAPH_KEY,)
_CERT_NUM_KEYS = frozenset(('I_bot', 'target_lo', 'target_hi', 'target_tol', 'n_through_dof', 'sigma') + CERT_TOPO_KEYS)
#: 증서 결합 칸 (= `step3_conv_cert.BIND_KEYS` + 판 · 끝마다 증서 = 주 해 증서와 같은 런 입력)
BIND_FIELDS = ('bind_version', 'fp_sid', 'fp_sig', 'fp_face_plan', 'fp_cjunc_registry', 'fp_cjunc_rows')
#: 실제 census 칸 (증거 `census` · 생산자 `carbon_junction._sv_split` 정의: 못 가른 ⊆ 다리 놓는 ⊆ 닿는 성분) · 기록이 옮겨 실은 census 사본
CENSUS_KEYS = ('n_unsplit_bridging_components', 'n_bridging_components', 'n_sdcp_components_touching')
CENSUS_COPY_KEYS = CENSUS_KEYS + ('n_sv_faces_kept_self',)
#: 투영이 옮기는 칸 (판정 · 기록) — 정의별 수 칸 (`n_*` · int) 은 이 목록 밖이어도 이름 그대로 옮긴다 · ★ 10-23 C5 규칙 (옛 판 = 버렸다)
_COPY = ('kind', 'rule', 'requested', 'threshold', 'status', 'flag', 'cg_info')


def _is_bool(x):
    return isinstance(x, bool) or type(x).__name__ in ('bool_', 'bool')


def _fin_or_none(x):
    """유한 실수 → float · 그 밖 (bool · 수 아님 · NaN · ±inf) → None."""
    if _is_bool(x) or not isinstance(x, numbers.Real):
        return None
    v = float(x)
    return v if math.isfinite(v) else None


def _ratio_proj(r_):
    """비 → (투영 비, 표지) — +∞ = (None, 'inf') · 유한 = (float, None) · NaN · -inf · bool = (None, None) (그 상태의 꼴 검사가 거부한다) ·
    문자열 = 그대로 (검증기가 거부)."""
    if isinstance(r_, numbers.Real) and not _is_bool(r_) and math.isinf(float(r_)) and float(r_) > 0:
        return None, 'inf'
    if r_ is not None and not isinstance(r_, str):
        return _fin_or_none(r_), None
    return r_, None


def _num_proj(v):
    """증서의 수 칸 → JSON 투영 — 정수 = int · 유한 실수 = float · 비유한 = None · bool · 글자 · None = 그대로 (검증기 · 구간 함수가 거부)."""
    if _is_bool(v) or not isinstance(v, numbers.Real):
        return v
    if isinstance(v, numbers.Integral):
        return int(v)
    f = float(v)
    return f if math.isfinite(f) else None


def _cert_proj(cc):
    """수렴 증서 → 투영 (★ 10-23 · RCA2-01 · 04 — `CERT_PROJ_KEYS`: 판 · 상태 · ⓐ–ⓓ · 게시 판 전류 · 목표량 구간 · 목표량 판 · 봉인 · 영값 위상 칸 ·
    결합 칸) · dict 아닌 값 = 그대로 (None = 증서 없음 · 그 밖 = 검증기가 거부)."""
    if not isinstance(cc, dict):
        return cc
    return {k: (_num_proj(cc.get(k)) if k in _CERT_NUM_KEYS else cc.get(k)) for k in CERT_PROJ_KEYS}


def _enc(x):
    """구간 끝 → JSON (+∞ = 'inf' · 유한 float · None 그대로)."""
    return 'inf' if (isinstance(x, float) and x == math.inf) else x


def _end_proj(rec):
    """반사실 한 끝의 풀이 칸 → 투영 (비 · 표지 · G_cut · 잔차 · 증서 · backend · 정의별 수 칸) — 아래 끝 (기록 자신) · 위 끝 (`upper`) 같은 꼴.
    ★ 10-23 — 증서 = `_cert_proj` (목표량 구간 · 게시 판 전류 · 결합 칸을 버리지 않는다)."""
    r_, lim = _ratio_proj(rec.get('sv_counterfactual_ratio'))
    out = {'sv_counterfactual_ratio': r_, 'ratio_limit': lim, 'G_cut_code': _fin_or_none(rec.get('G_cut_code')),
           'resid': _fin_or_none(rec.get('resid'))}
    for k, v in rec.items():                       # 정의별 수 칸 (끊은 면 수 · 다리 놓는 SDCP 수 …) — 이름 그대로 · int 만
        if isinstance(k, str) and k.startswith('n_') and isinstance(v, numbers.Integral) and not _is_bool(v):
            out[k] = int(v)
    out['conv_cert'] = _cert_proj(rec.get('conv_cert'))
    bk = rec.get('backend_last_solve')
    out['backend_last_solve'] = ({k: bk.get(k) for k in ('used', 'requested', 'precond', 'fallback_reason')}
                                 if isinstance(bk, dict) else None)
    return out


def sv_cf_record(rec):
    """반사실 원 기록 → 증거 투영 (JSON 유한 · 판정 칸 · 사본 아님 — 원 기록의 값을 그대로 옮긴다).  ★ 10-22 괄호 칸 (규칙 · 위 끝 상태 · 비 ·
    위 끝 풀이 기록) 도 같은 꼴로 옮긴다 (원 기록에 없으면 None — 검증기가 거부 · 사슬 = 위 끝 못 읽음).
    ★ 10-23 (RCA2-01 · 04 · Q1 (가)) — 기록 지위 (`standing`) · 주 해 증서 (`conv_cert_full`) · 판정 근거 칸 `ratio_cert_interval` (= 이 투영에서
    `cert_interval` 로 센 [아래비, 위비] · +∞ = 'inf' · 못 정함 = None)."""
    if not isinstance(rec, dict):
        return None
    e = _end_proj(rec)
    out = {k: rec.get(k) for k in _COPY}
    out.update({'sv_counterfactual_ratio': e['sv_counterfactual_ratio'], 'ratio_limit': e['ratio_limit'],
                'G_full_code': _fin_or_none(rec.get('G_full_code')), 'G_cut_code': e['G_cut_code'], 'resid': e['resid']})
    out.update({k: v for k, v in e.items() if k.startswith('n_')})
    out['conv_cert'], out['backend_last_solve'] = e['conv_cert'], e['backend_last_solve']
    rh, lh = _ratio_proj(rec.get('sv_counterfactual_ratio_hi'))
    up = rec.get('upper')
    upp = None
    if isinstance(up, dict):
        upp = {'status': up.get('status'), 'cg_info': up.get('cg_info'), 'why': up.get('why')}
        upp.update(_end_proj(up))
    elif up is not None:
        upp = up                                   # dict 아닌 값 = 그대로 (검증기가 거부)
    out.update({'bracket_rule': rec.get('bracket_rule'), 'status_hi': rec.get('status_hi'), 'sv_counterfactual_ratio_hi': rh,
                'ratio_limit_hi': lh, 'upper': upp})
    out['standing'] = rec.get('standing')
    out['conv_cert_full'] = _cert_proj(rec.get('conv_cert_full'))
    lo, hi = cert_interval(out)
    out['ratio_cert_interval'] = [_enc(lo), _enc(hi)]
    return out


def request_problem(req):
    """요청 꼴 → 문제 | None — {'threshold': None | 유한 실수 ≥ 1} (producer `carbon_junction._sv_cf_request` 와 같은 정의역)."""
    if not isinstance(req, dict) or set(req) != {'threshold'}:
        return f"요청 꼴 {req!r} (= {{'threshold': None | 실수 ≥ 1}})"
    t = req['threshold']
    if t is None:
        return None
    if _is_bool(t) or not isinstance(t, numbers.Real) or not math.isfinite(float(t)) or float(t) < 1.0:
        return f'요청 문턱 {t!r} (유한 실수 ≥ 1 · 비 G_full/G_cut ≥ 1 = Rayleigh)'
    return None


def attach_evidence(ev, request):
    """payload — 접합 블록 증거 (`ca_ext_cjunc.payload_blocks` 의 evidence) 에 요청을 싣고, 솔브 요약이 옮긴 원 기록을 투영으로 바꾼다
    (끔 = 이 함수를 부르지 않는다 = 칸 없음 = 옛 바이트)."""
    ev['sv_counterfactual_request'] = dict(request)
    sol = ev.get('solve')
    if isinstance(sol, dict) and 'sv_counterfactual' in sol:
        sol['sv_counterfactual'] = sv_cf_record(sol['sv_counterfactual'])
    return ev


def sv_cf_problem(ev, solved, graphs=None):
    """증거의 SV 반사실 요청 ↔ 기록 → 문제 | None.  solved = 주 전자 솔브가 풀렸나 (접합 영수증 applied · absent_geometry).
    요청 없음 ⟹ 기록 없음 · 요청 + 풀림 ⟹ 기록 (종류 · 문턱 · 상태 ↔ 비 ↔ 표지) · 요청 + 조기 반환 ⟹ 기록 없음 (주 해가 없다).
    ★ 10-26 묶음 B6 (Codex 회차 ① RR1-01 · 1저자 10-26 Q2 (가)) graphs = 봉인 원천 (같은 런의 raster · 원장 · 계획 · 등록 절단 규칙) 에서 다시 조립한
    끝 그래프 지문 (`GRAPH_SOURCE_KEYS` · `step3_sigma.solve_sigma_z(cjunc_graph_only=True)`) — 주면 기록 검사를 다 지난 뒤 증서 지문과 대조
    (`graph_problem` · 다르면 구조화 실패) · None (원천 없는 문맥) = 꼴만 (증서 구간 기록의 증서마다 hex64 지문) — 원천 없는 통과는 판정 입력이 아니다
    (사슬 = 원천 대조 뒤만 · 원천 없음 = `SV_UNCHECKED` · 자기 신고 사본끼리 비교로 대신하지 않는다)."""
    ev = ev if isinstance(ev, dict) else {}
    sol = ev.get('solve') if isinstance(ev.get('solve'), dict) else {}
    has_req, has_rec = 'sv_counterfactual_request' in ev, 'sv_counterfactual' in sol
    if not has_req:
        return 'sv_cf| 요청 없는 반사실 기록 (지금 요청한 런의 것이 아니다)' if has_rec else None
    req = ev['sv_counterfactual_request']
    why = request_problem(req)
    if why:
        return f'sv_cf| {why}'
    if not solved:
        return 'sv_cf| 주 솔브가 조기 반환했는데 반사실 기록이 있다 (주 해 없이 비를 낼 수 없다)' if has_rec else None
    rec = sol.get('sv_counterfactual')
    if not isinstance(rec, dict):
        return 'sv_cf| 요청했고 주 솔브가 풀렸는데 반사실 기록이 없다 (배선 누락)'
    kd, ru = rec.get('kind'), rec.get('rule')
    if not (isinstance(kd, str) and kd == SV_CF_KIND) or rec.get('requested') is not True:
        return (f'sv_cf| 기록 종류 {kd!r} · requested {rec.get("requested")!r} — 등록된 반사실 종류 {SV_CF_KIND!r} · requested True 이어야 '
                f'(이름 대조뿐 · 10-23 사전 공격 리뷰 C5)')
    if not (isinstance(ru, str) and ru == SV_CF_RULE):
        return f'sv_cf| 기록 규칙 {ru!r} ≠ 등록된 끊기 규칙 {SV_CF_RULE!r} (이름 대조뿐 · 10-23 사전 공격 리뷰 C5)'
    thr = req['threshold']
    if rec.get('threshold') != thr:
        return f'sv_cf| 기록 문턱 {rec.get("threshold")!r} ≠ 요청 {thr!r}'
    st = rec.get('status')
    if not (isinstance(st, str) and st):
        return f'sv_cf| 상태 {st!r} (비지 않은 낱말)'
    r_, lim, fl = rec.get('sv_counterfactual_ratio'), rec.get('ratio_limit'), rec.get('flag')
    form = RATIO_STATUSES.get(st)
    if form == 'finite':
        if _is_bool(r_) or not isinstance(r_, float) or not math.isfinite(r_) or not r_ > 0.0 or lim is not None:
            return f'sv_cf| {st} 인데 비 {r_!r} · 표지 {lim!r} (유한 양수 · 표지 없음)'
    elif form == 'inf':
        if r_ is not None or lim != 'inf':
            return f'sv_cf| {st} 인데 비 {r_!r} · 표지 {lim!r} (null · inf — 위상의 +∞)'
    elif r_ is not None or lim is not None:
        return f'sv_cf| {st} 인데 비 {r_!r} · 표지 {lim!r} (이 상태는 비를 싣지 않는다)'
    if fl not in FLAGS:
        return f'sv_cf| 모르는 표지 {fl!r}'
    #  producer 의 문턱 비교 (`carbon_junction` — 비 ≥ 문턱) 와 기록이 맞는가 (이 배선은 문턱 None → 표지 None 이어야)
    dep = thr is not None and (lim == 'inf' or (form == 'finite' and r_ >= float(thr)))
    if (fl == 'SV_DEPENDENT') != dep:
        return f'sv_cf| 표지 {fl!r} ↔ 문턱 {thr!r} · 비 {r_!r} · 표지 {lim!r} (문턱 판정과 기록이 갈렸다)'
    why = _bracket_problem(rec)
    if why:
        return why
    why = _values_problem(rec)
    if why:
        return why
    #  ★ 10-23 (Codex 재검토 RCA2-01 · 04 · 1저자 Q1 (가)) — 증서 (지위 · 끝마다 · 분자 · 결합) → 실제 census → 판정 근거 칸 (기록 안에서 먼저 ·
    #    증거 칸 (census · I_bot_code · fp) 대조는 그 뒤 — 기록 자신의 결함은 자기 사유로 거부된다)
    why = _cert_problem(rec, ev)
    if why:
        return why
    why = _census_problem(rec, ev)
    if why:
        return why
    why = _interval_problem(rec)
    if why or graphs is None:
        return why
    return graph_problem(rec, graphs)                # ★ 10-26 묶음 B6 (RR1-01) — 봉인 원천 대조 (원천을 준 소비자만)


def _form_problem(st, r_, lim, what):
    """상태 ↔ 비 ↔ 표지 꼴 (아래 끝 · 위 끝 같은 규칙) → 문제 | None."""
    form = RATIO_STATUSES.get(st)
    if form == 'finite':
        if _is_bool(r_) or not isinstance(r_, float) or not math.isfinite(r_) or not r_ > 0.0 or lim is not None:
            return f'sv_cf| {what} {st} 인데 비 {r_!r} · 표지 {lim!r} (유한 양수 · 표지 없음)'
    elif form == 'inf':
        if r_ is not None or lim != 'inf':
            return f'sv_cf| {what} {st} 인데 비 {r_!r} · 표지 {lim!r} (null · inf — 위상의 +∞)'
    elif r_ is not None or lim is not None:
        return f'sv_cf| {what} {st} 인데 비 {r_!r} · 표지 {lim!r} (이 상태는 비를 싣지 않는다)'
    return None


def _bracket_problem(rec):
    """★ 10-22 (PRE2-impl-01 · 02 · 1저자 Q1 (다)) 괄호 칸의 꼴 → 문제 | None — 못 가른 덩어리 수 = 0 이상 정수 · 규칙 = 비지 않은 낱말 ·
    위 끝 상태 ↔ 비 ↔ 표지 (아래 끝과 같은 규칙) · 덩어리 0 ⟹ 위 끝 풀이 기록 없음 · 위 = 아래 (상태 · 비 · 표지) · 덩어리 > 0 ⟹ 위 끝 풀이
    기록 (dict · 꼴) = 위 끝 칸.  비 값의 대조 (G 비 다시 셈 · 아래 ≤ 위) 는 이 함수 밖 (★ PF2 E `_values_problem`).
    ★ 10-23 (RCA2-06 F6) 예외 하나 — 위 끝 풀이 기록이 구조화 실패 (`UNSPLIT_MISMATCH` · census 수 ≠ 다시 가른 수) 면 덩어리 수 (0 · > 0) 와 무관하게
    그 꼴만 본다 (`_mismatch_problem` · 덩어리 0 인데 위 끝 기록이 있는 유일한 꼴 · 제거 수 대조 밖)."""
    nu = rec.get('n_unsplit_bridging_components')
    if not _count_ok(nu):
        return f'sv_cf| 못 가른 덩어리 수 {nu!r} (0 이상 정수 · int64 범위 — 의미 범위 · 괄호 판정 10-22 · 10-23 RCA2-04)'
    br = rec.get('bracket_rule')
    if not (isinstance(br, str) and br in BRACKET_RULES):
        return f'sv_cf| 괄호 규칙 {br!r} — 등록된 값만 {BRACKET_RULES} (10-23 RCA2-04 · 위 끝 칸 없는 옛 기록 = 거부)'
    sh, rh, lh = rec.get('status_hi'), rec.get('sv_counterfactual_ratio_hi'), rec.get('ratio_limit_hi')
    if not (isinstance(sh, str) and sh):
        return f'sv_cf| 위 끝 상태 {sh!r} (비지 않은 낱말)'
    why = _form_problem(sh, rh, lh, '위 끝')
    if why:
        return why
    up = rec.get('upper')
    if isinstance(up, dict) and up.get('status') == UNSPLIT_MISMATCH:
        return _mismatch_problem(rec, up, int(nu))
    if int(nu) == 0:
        if up is not None:
            return f'sv_cf| 못 가른 덩어리 0 인데 위 끝 풀이 기록 {type(up).__name__} (다시 풀지 않는다 · 위 = 아래)'
        if (sh, rh, lh) != (rec.get('status'), rec.get('sv_counterfactual_ratio'), rec.get('ratio_limit')):
            return (f'sv_cf| 못 가른 덩어리 0 인데 위 끝 ({sh!r}, {rh!r}, {lh!r}) ≠ 아래 끝 ({rec.get("status")!r}, '
                    f'{rec.get("sv_counterfactual_ratio")!r}, {rec.get("ratio_limit")!r}) (위 = 아래)')
        return None
    if not isinstance(up, dict):
        return f'sv_cf| 못 가른 덩어리 {nu} 인데 위 끝 풀이 기록 {up!r} (덩어리가 있으면 늘 두 번 푼다 · 값 봉인)'
    ust, ur, ul = up.get('status'), up.get('sv_counterfactual_ratio'), up.get('ratio_limit')
    if not (isinstance(ust, str) and ust):
        return f'sv_cf| 위 끝 풀이 기록 상태 {ust!r} (비지 않은 낱말)'
    why = _form_problem(ust, ur, ul, '위 끝 풀이 기록')
    if why:
        return why
    if (ust, ur, ul) != (sh, rh, lh):
        return f'sv_cf| 위 끝 칸 ({sh!r}, {rh!r}, {lh!r}) ≠ 위 끝 풀이 기록 ({ust!r}, {ur!r}, {ul!r})'
    return _removed_problem(up, int(nu))


def _mismatch_problem(rec, up, nu):
    """★ 10-23 (Codex 재검토 RCA2-06 F6 · author 10-23 ratified Q1-Q8) 위 끝 구조화 실패 `UNSPLIT_MISMATCH` → 문제 | None — 생산자 정의
    (`carbon_junction.sv_counterfactual`): census 의 못 가른 덩어리 수 nu ≠ 지문 묶인 원장에서 다시 가른 수 → 위 끝을 풀지 않는다 (fail-closed).
    받는 꼴 = 다시 가른 수 (`n_components_removed` · 0 이상 정수 · int64 범위) ≠ nu · 사유 (`why`) = 비지 않은 글 · 풀이 칸 (`MISMATCH_EMPTY_KEYS`)
    없음 · 위 끝 칸 (`status_hi` · 비 · 표지) = (상태, None, None).  받은 기록의 위 끝 = 비 없음 → 사슬 = 못 읽음 (SV_UNCHECKED · 사유에 상태 이름)."""
    nr = up.get('n_components_removed')
    if not _count_ok(nr) or int(nr) == nu:
        return (f'sv_cf| 위 끝 {UNSPLIT_MISMATCH} 인데 다시 가른 덩어리 수 {nr!r} (0 이상 정수 · int64 범위 · census 수 {nu} 와 달라야 — 그 상태의 '
                f'정의 · 10-23 RCA2-06)')
    why = up.get('why')
    if not (isinstance(why, str) and why.strip()):
        return f'sv_cf| 위 끝 {UNSPLIT_MISMATCH} 인데 사유 {why!r} (비지 않은 글 · 10-23 RCA2-06)'
    filled = [k for k in MISMATCH_EMPTY_KEYS if up.get(k) is not None]
    if filled:
        return f'sv_cf| 위 끝 {UNSPLIT_MISMATCH} 인데 풀이 칸 {filled} 이 있다 (풀지 않은 끝 · 10-23 RCA2-06)'
    hi = (rec.get('status_hi'), rec.get('sv_counterfactual_ratio_hi'), rec.get('ratio_limit_hi'))
    if hi != (UNSPLIT_MISMATCH, None, None):
        return f'sv_cf| 위 끝 풀이 기록 = {UNSPLIT_MISMATCH} 인데 위 끝 칸 {hi!r} (같은 상태 · 비 · 표지 없음 · 10-23 RCA2-06)'
    return None


def _count_ok(v):
    """수 칸의 의미 범위 (★ 10-23 · RCA2-04) — 0 이상 정수 (bool 아님) · int64 범위 (10**400 = 거부)."""
    return isinstance(v, numbers.Integral) and not _is_bool(v) and 0 <= int(v) <= COUNT_MAX


def _removed_problem(up, nu):
    """★ 10-23 (Codex 재검토 RCA2-04 · 생산자 정의 `carbon_junction.sv_counterfactual`) 위 끝 풀이 기록의 제거 수 → 문제 | None —
    제거 성분 수 = 못 가른 덩어리 수 (지문 묶인 원장에서 다시 가른 수 = census 수 · 다르면 `unsplit_census_mismatch` 꼴) · 제거 셀 수 = 그 성분의
    SDCP 셀 수 ≥ 성분 수 (성분마다 셀 ≥ 1 · 비를 싣는 끝은 필수) · 끊은 간선 · 판 결합 · SV 면 수 · ★ 10-23 묶음 A″ 판에 닿는 성분에서 끊은 쌍 수 ·
    ★ 10-25 묶음 B 아래 끝 계 대비 끊은 쌍 수 = 0 이상 정수 (있으면 · 필수 여부 · 관계 = `_topo_problem` X5) · 전부 int64 범위."""
    nc = up.get('n_components_removed')
    if not _count_ok(nc) or int(nc) != nu:
        return f'sv_cf| 위 끝 제거 성분 수 {nc!r} ≠ 못 가른 덩어리 수 {nu} (생산자 정의 = 같다 · 0 이상 정수 · int64 범위 · 10-23 RCA2-04)'
    ncell = up.get('n_cells_removed')
    need = RATIO_STATUSES.get(up.get('status')) is not None
    if (ncell is not None or need) and (not _count_ok(ncell) or int(ncell) < nu):
        return (f'sv_cf| 위 끝 제거 셀 수 {ncell!r} (0 이상 정수 · int64 범위 · 제거 성분 수 {nu} 이상 — 성분마다 SDCP 셀 ≥ 1 · 비를 싣는 끝은 '
                f'필수 · 10-23 RCA2-04)')
    for k in ('n_edges_cut', 'n_plate_couplings_cut', 'n_sv_faces_cut', 'n_reach_pairs_cut', 'n_reach_pairs_cut_vs_lower'):   # ★ A″ · B 새 칸도 같은 꼴
        if up.get(k) is not None and not _count_ok(up.get(k)):
            src = {'n_reach_pairs_cut': '10-23 사전 공격 리뷰 C1 · 묶음 A″', 'n_reach_pairs_cut_vs_lower': '10-25 묶음 B · X3'}.get(k, '10-23 RCA2-04')
            return f'sv_cf| 위 끝 {k} {up.get(k)!r} (0 이상 정수 · int64 범위 · {src})'
    return None


def _pos_float(x):
    """유한 양의 float (bool · 정수 · 글자 · NaN · ±∞ · 0 · 음수 아님)."""
    return isinstance(x, float) and not _is_bool(x) and math.isfinite(x) and x > 0.0


def _end_values_problem(end, G_full, what):
    """★ PF2 E (10-22 · 사전 리뷰 2 회차 PRE2-impl-02 · 결정 없음) — 한 끝 (아래 = 기록 자신 · 위 = `upper`) 의 수 대조 → 문제 | None.
    computed = G_full · G_cut 유한 양수 · 비 = G_full/G_cut (상대 `RATIO_REL_TOL` · 그 값이 유한) · 비 ≥ `RATIO_FLOOR` (증서 폭 꼴) · 반사실 증서가
    있으면 ok · ⓐ–ⓓ 참 · POSITIVE_SOLVED (플래그를 믿지 않는다) · no_through_without_sv = G_cut 정확히 0 · G_full 유한 양수 (+∞ 의 분자) · 비를
    싣지 않는 상태 = 수 대조 없음 (사슬 = 못 읽음)."""
    st = end.get('status')
    form = RATIO_STATUSES.get(st)
    if form is None:
        return None
    if not _pos_float(G_full):
        return f'sv_cf| {what} {st} 인데 G_full {G_full!r} (유한 양수 — 비의 분자 · 주 해 단자 G)'
    gc = end.get('G_cut_code')
    if form == 'inf':
        if not (isinstance(gc, float) and not _is_bool(gc) and gc == 0.0):
            return f'sv_cf| {what} {st} 인데 G_cut {gc!r} (관통 없음 = 0.0)'
        return None
    if not _pos_float(gc):
        return f'sv_cf| {what} {st} 인데 G_cut {gc!r} (유한 양수 — 비의 분모)'
    r_ = end.get('sv_counterfactual_ratio')
    want = G_full / gc
    if not (math.isfinite(want) and abs(r_ - want) <= RATIO_REL_TOL * want):
        return f'sv_cf| {what} 비 {r_!r} ≠ G_full/G_cut {want!r} (상대 {RATIO_REL_TOL:g} · 기록 안 수가 서로 맞지 않는다)'
    if not r_ >= RATIO_FLOOR:
        return (f'sv_cf| {what} 비 {r_!r} < (1 − τ)/(1 + τ) = {RATIO_FLOOR!r} (τ = 증서 ⓓ 보장 상대 오차 {CERT_TARGET_TOL:g} · 끊기만 한 그래프의 '
                f'비 ≥ 1 = Rayleigh)')
    cc = end.get('conv_cert')
    if cc is not None:
        if not isinstance(cc, dict):
            return f'sv_cf| {what} 반사실 증서 꼴 {type(cc).__name__} (dict 이어야)'
        bad = [k for k in ('ok', 'pass_a', 'pass_b', 'pass_c', 'pass_d') if cc.get(k) is not True]
        if bad or cc.get('status') != CERT_OK_STATUS:
            return (f'sv_cf| {what} {st} 인데 반사실 증서 상태 {cc.get("status")!r} · 참이 아닌 칸 {bad} (ok · ⓐ–ⓓ 참 · {CERT_OK_STATUS} 이어야 · '
                    f'플래그를 믿지 않는다)')
    return None


def _values_problem(rec):
    """★ PF2 E — 아래 끝 · 위 끝 (못 가른 덩어리 > 0 이면 `upper`) 의 수 대조 + 괄호 아래 ≤ 위 (같은 증서 폭 여유 · 아래 +∞ ⟹ 위 +∞) → 문제 | None.
    꼴 검사 (`sv_cf_problem` · `_bracket_problem`) 를 지난 기록에만 (상태 ↔ 비 꼴 · 덩어리 0 ⟹ 위 = 아래 · 위 끝 칸 = 위 끝 풀이 기록)."""
    gf = rec.get('G_full_code')
    why = _end_values_problem(rec, gf, '아래 끝')
    if why:
        return why
    up = rec.get('upper')
    if isinstance(up, dict):
        why = _end_values_problem(up, gf, '위 끝')
        if why:
            return why
    lo = _end_view(rec.get('status'), rec.get('sv_counterfactual_ratio'), rec.get('ratio_limit'))
    hi = _end_view(rec.get('status_hi'), rec.get('sv_counterfactual_ratio_hi'), rec.get('ratio_limit_hi'))
    if lo is None or hi is None:
        return None
    if not (hi == math.inf or hi >= lo * RATIO_FLOOR):       # 아래 +∞ ⟹ lo × 여유 = +∞ ⟹ 위도 +∞ 이어야 (관통 없음이 되살아날 수 없다)
        return (f'sv_cf| 괄호 위 {hi!r} < 아래 {lo!r} × (1 − τ)/(1 + τ) (위 = 덩어리를 더 뺀 판 · 참 G_cut,hi ≤ G_cut,lo · 아래 +∞ 면 위도 +∞ · '
                f'증서 폭 여유 τ {CERT_TARGET_TOL:g} · Rayleigh)')
    return None


# ═════════════════════════ ★ 10-23 증서 구간 (Codex 재검토 RCA2-01 · 04 · 1저자 Q1 (가)) ═════════════════════════
def _hex32(v):
    return isinstance(v, str) and len(v) == 32 and all(ch in '0123456789abcdef' for ch in v)


def _hex64(v):
    return isinstance(v, str) and len(v) == 64 and all(ch in '0123456789abcdef' for ch in v)


def _fp_short(v):
    return f'{v[:12]}…' if _hex64(v) else repr(v)


def graph_source_problem(g):
    """★ 10-26 묶음 B6 (RR1-01) 봉인 원천 지문 꼴 → 문제 | None — {'rule' = `GRAPH_FP_RULE`, 'main' · 'lower' · 'upper' = 소문자 hex64 | None}
    (`step3_sigma.solve_sigma_z(cjunc_graph_only=True)` 의 `cjunc_graphs` 꼴 · None = 그 계를 조립할 수 없었다 (단락 · 덩어리 0 · census 불일치))."""
    if not isinstance(g, dict) or set(g) != set(GRAPH_SOURCE_KEYS):
        return f'원천 꼴 {type(g).__name__} · 칸 {sorted(g) if isinstance(g, dict) else None} (= {list(GRAPH_SOURCE_KEYS)})'
    if g['rule'] != GRAPH_FP_RULE:
        return f'원천 지문 규칙 {g["rule"]!r} ≠ {GRAPH_FP_RULE!r}'
    for k in ('main', 'lower', 'upper'):
        if g[k] is not None and not _hex64(g[k]):
            return f'원천 {k} 지문 {g[k]!r} (소문자 hex64 · None 이어야)'
    return None


def graph_applicable(rec):
    """★ 10-26 묶음 B6 — 그래프 귀속 대조가 뜻이 있는 기록인가: 증서 구간 기록 + 비를 싣는 끝이 있다 (그 밖 = 사슬이 이미 판정 입력으로 받지 않는다)."""
    return (isinstance(rec, dict) and rec.get('standing') == STANDING_CERTIFIED
            and any(RATIO_STATUSES.get(e.get('status')) for _w, e in _ends(rec)))


def graph_problem(rec, graphs):
    """★ 10-26 묶음 B6 (Codex 회차 ① RR1-01 · 1저자 10-26 Q2 (가)) 증서 지문 ↔ 봉인 원천에서 다시 조립한 기대 끝 그래프 지문 → 문제 | None.
    graphs = SV 기록 **밖** 원천 (같은 런의 raster · 원장 · 계획 · 등록 절단 규칙 → `solve_sigma_z(cjunc_graph_only=True)` · 솔브 없음) · 원천 꼴이 틀리면
    대조 불가 (문제).  증서 구간 기록의 비를 싣는 끝이 있을 때만 (`graph_applicable`):
      · 주 해 증서 (`conv_cert_full`) 지문 = 원천 주 계
      · 비를 싣는 끝마다 그 끝 증서 지문 = 원천 그 끝 (아래 끝 = 'lower' · 위 끝 풀이 기록 = 'upper' · 원천에 그 끝이 없으면 (None) = 문제)
      · 위 끝 풀이 기록이 없는 꼴 (못 가른 덩어리 0 · 위 = 아래) 인데 원천에 위 끝 그래프가 있다 = 위 끝을 지운 기록 (문제)
    판정문 반례 (아래 끝 ← 같은 런의 주 해 증서 · k 0 · 위상 수 · census 그대로) = 아래 끝 증서 지문 = 주 계 ≠ 원천 아래 끝 → 거부.
    금지 (판정문 §3) = 사본끼리 비교 · `G_cut != G_full` 규칙 · 원시 간선 개수 — 정직한 FLOAT (아래 끝 = 주 계) · 등전위 다리 (G 같음) 는 원천과 같아
    받는다.  ⚠ 한정: 기록의 증서 칸 지문을 원천 값으로 같이 고친 편집 (증서 수는 주 해 그대로) 은 이 대조로 가리지 못한다 — 지문은 그래프 정체성이지
    증서 수의 재증명이 아니다 (풀이 증인 · 다시 풀기 없음)."""
    why = graph_source_problem(graphs)
    if why:
        return f'sv_cf| 봉인 원천 대조 불가 — {why} (10-26 RR1-01)'
    if not graph_applicable(rec):
        return None
    full = rec.get('conv_cert_full') if isinstance(rec.get('conv_cert_full'), dict) else {}
    if graphs['main'] is None or full.get(GRAPH_KEY) != graphs['main']:
        return (f'sv_cf| 주 해 증서 가중 그래프 지문 ({GRAPH_KEY}) {_fp_short(full.get(GRAPH_KEY))} ≠ 봉인 원천에서 다시 조립한 주 계 '
                f'{_fp_short(graphs["main"])} — 이 런 주 해가 푼 계의 증서가 아니다 (10-26 RR1-01)')
    up = rec.get('upper')
    ends = [('아래 끝', rec, 'lower')] + ([('위 끝', up, 'upper')] if isinstance(up, dict) else [])
    for w, e, k in ends:
        if not RATIO_STATUSES.get(e.get('status')):
            continue
        cc = e.get('conv_cert') if isinstance(e.get('conv_cert'), dict) else {}
        if graphs[k] is None or cc.get(GRAPH_KEY) != graphs[k]:
            return (f'sv_cf| {w} 증서 가중 그래프 지문 ({GRAPH_KEY}) {_fp_short(cc.get(GRAPH_KEY))} ≠ 봉인 원천에서 다시 조립한 {w} 그래프 '
                    f'{_fp_short(graphs[k])} — 그 끝에서 푼 계의 증서가 아니다 (10-26 RR1-01)')
    if up is None and graphs['upper'] is not None:
        return (f'sv_cf| 위 끝 풀이 기록이 없다 (못 가른 덩어리 0 꼴 · 위 = 아래) 인데 봉인 원천에서 다시 조립한 위 끝 그래프가 있다 '
                f'({_fp_short(graphs["upper"])}) — 위 끝을 지운 기록 ({GRAPH_KEY} · 10-26 RR1-01)')
    return None


def _ends(rec):
    """기록의 끝 [(이름, 끝)] — 아래 끝 = 기록 자신 · 위 끝 = `upper` 풀이 기록 (dict 일 때 · 못 가른 덩어리 0 = 아래 끝 그 자체)."""
    out = [('아래 끝', rec)]
    if isinstance(rec.get('upper'), dict):
        out.append(('위 끝', rec['upper']))
    return out


def _pos_cert_problem(cc, G, what, CC):
    """양의 해 증서 ↔ 그 끝의 G → 문제 | None — 현 판 (`CERT_VERSION`) · POSITIVE_SOLVED · ok · ⓐ–ⓓ 참 (bool) · 목표량 판 · 부동소수 규칙 · τ 봉인 ·
    게시 판 전류 = G (정확히 — 게시 판 전류가 다른 회로의 증서 = 거부) · 목표량 구간을 그 G 로 같은 판정 함수 (`step3_conv_cert.target_judge`) 에
    다시 넣어 통과.  ★ 10-23 (사전 공격 리뷰 C1 · 1저자 Q12 (가)) 이 결합은 증서 ↔ 그 끝의 **G 하나** 다 — 같은 런의 주 해 증서를 끝 자리에 옮기고
    G 까지 같이 고친 기록은 여기서 걸리지 않는다 (리뷰 A2) → 증서 ↔ 그 끝의 **끊은 그래프** 결합 = `_topo_problem` (증서 위상 수 ↔ 주 해 증서 ·
    끊은 수)."""
    if not isinstance(cc, dict):
        return (f'sv_cf| {what} 증서가 없다 ({type(cc).__name__}) — 증서 구간 기록의 비를 싣는 끝 = 현 증서 필수 (무증서 = 진단 기록만 · '
                f'10-23 RCA2-04)')
    if cc.get('version') != CC.CERT_VERSION:
        return f'sv_cf| {what} 증서 판 {cc.get("version")!r} ≠ 현 판 {CC.CERT_VERSION!r}'
    bad = [k for k in ('ok', 'pass_a', 'pass_b', 'pass_c', 'pass_d') if cc.get(k) is not True]
    if bad or cc.get('status') != CC.STATUS_POSITIVE:
        return f'sv_cf| {what} 증서 상태 {cc.get("status")!r} · 참이 아닌 칸 {bad} ({CC.STATUS_POSITIVE} · ok · ⓐ–ⓓ 참이어야)'
    for k, want in (('target_version', CC.TARGET_VERSION), ('target_fp', CC.TARGET_FP_RULE), ('target_tol', CC.CERT_TARGET_TOL)):
        if cc.get(k) != want:
            return f'sv_cf| {what} 증서 {k} = {cc.get(k)!r} ≠ 이 코드의 봉인 {want!r}'
    ib = cc.get('I_bot')
    if not (isinstance(ib, float) and not _is_bool(ib) and isinstance(G, float) and ib == G):
        return f'sv_cf| {what} 증서 게시 판 전류 {ib!r} ≠ 그 끝의 G {G!r} (정확히 같아야 — 다른 회로의 증서 · 10-23 RCA2-04)'
    jd = CC.target_judge(cc.get('target_lo'), cc.get('target_hi'), G)
    if jd.get('pass_d') is not True:
        return f'sv_cf| {what} 증서 목표량 구간을 그 끝의 G 로 다시 보면 실패 — {jd.get("target_why")}'
    return None


def _zero_cert_problem(cc, what, CC):
    """+∞ 끝 (관통 없음) 의 영값 위상 증서 → 문제 | None — 현 판 · VALID_ZERO_TOPOLOGY · ok True · 조기 반환 출처 · 영값 위상 사유 · 관통 dof 0 ·
    σ 정확히 0 (∞ = 위상이 증명한 0 분모만 · 10-23 RCA2-01)."""
    if not isinstance(cc, dict):
        return (f'sv_cf| {what} 관통 없음 (+∞) 인데 영값 위상 증서가 없다 ({type(cc).__name__}) — ∞ = 위상이 증명한 0 분모만 '
                f'(10-23 RCA2-01)')
    if cc.get('version') != CC.CERT_VERSION or cc.get('status') != CC.STATUS_ZERO or cc.get('ok') is not True:
        return (f'sv_cf| {what} 관통 없음 증서 판 {cc.get("version")!r} · 상태 {cc.get("status")!r} · ok {cc.get("ok")!r} '
                f'({CC.CERT_VERSION} · {CC.STATUS_ZERO} · True 이어야)')
    if (cc.get('zero_source') != 'early_return' or CC.classify_reason(cc.get('reason')) != CC.STATUS_ZERO
            or cc.get('zero_graph') != ZERO_GRAPH_SV_CF):
        return (f'sv_cf| {what} 관통 없음 증서 출처 {cc.get("zero_source")!r} · 사유 {cc.get("reason")!r} · 그래프 {cc.get("zero_graph")!r} '
                f'(조기 반환 · 영값 위상 사유 · 끊은 반사실 그래프 {ZERO_GRAPH_SV_CF!r} 이어야)')
    ntd, s = cc.get('n_through_dof'), cc.get('sigma')
    if not (type(ntd) is int and ntd == 0 and isinstance(s, float) and not _is_bool(s) and s == 0.0):   # noqa: E721
        return f'sv_cf| {what} 관통 없음 증서 관통 dof {ntd!r} · σ {s!r} (0 · 0.0 이어야)'
    return None


def _cert_problem(rec, ev):
    """★ 10-23 (Codex 재검토 RCA2-01 · 04 · 1저자 Q1 (가)) 기록 지위 · 증서 → 문제 | None.
    · 지위 ∈ `STANDINGS` · 진단 = 증서가 하나도 없다 (주 해 · 끝 — 실려 있으면 지위와 모순) · 사슬은 진단 기록을 R 판정 입력으로 받지 않는다
    · 증서 구간 + 비를 싣는 끝이 있다 → 분자 = 주 해 증서 (`conv_cert_full` · `_pos_cert_problem` · 게시 판 전류 = G_full = 솔브 기록
      `I_bot_code` · 결합 칸 = 판 · 격자 · σ 표 hex32 · 증거 `fp` 의 sid · registry · plan_rows) · 비를 싣는 끝마다 그 끝의 증서 (computed =
      양의 해 · 관통 없음 = 영값 위상) · 결합 칸 = 주 해 증서와 같다 (다른 런 · 다른 계획 증서 = 거부) · 비를 싣지 않는 끝 = 대조 없음."""
    st = rec.get('standing')
    if st not in STANDINGS:
        return f'sv_cf| 기록 지위 {st!r} (∈ {STANDINGS} · 10-23 RCA2-04 — 지위 칸 없는 옛 기록 = 거부)'
    ends = _ends(rec)
    full = rec.get('conv_cert_full')
    if st == STANDING_DIAGNOSTIC:
        bad = [w for w, e in ends if e.get('conv_cert') is not None] + (['주 해'] if full is not None else [])
        if bad:
            return f'sv_cf| 진단 기록 (증서 없는 런) 인데 증서가 실려 있다 ({bad}) — 지위 ↔ 증서 모순'
        return None
    if not any(RATIO_STATUSES.get(e.get('status')) for _w, e in ends):
        return None
    import step3_conv_cert as CC                   # 증서 정본 (판 · 상태 · 봉인 · 판정 함수) — 못 불러오면 계약이 unverifiable 로 거부
    G = rec.get('G_full_code')
    why = _pos_cert_problem(full, G, '주 해 (분자 G_full)', CC)
    if why:
        return why
    sol = ev.get('solve') if isinstance(ev.get('solve'), dict) else {}
    ib = sol.get('I_bot_code')
    if not (isinstance(ib, float) and not _is_bool(ib) and ib == G):
        return f'sv_cf| 분자 G_full {G!r} ≠ 솔브 기록 I_bot_code {ib!r} (그 런의 주 해 단자 전류와 정확히 같아야 · 10-23 RCA2-04)'
    if full.get('bind_version') != CC.BIND_VERSION or not _hex32(full.get('fp_sig')):
        return f'sv_cf| 주 해 증서 결합 판 {full.get("bind_version")!r} · σ 표 지문 {full.get("fp_sig")!r} ({CC.BIND_VERSION} · hex32 이어야)'
    fp = ev.get('fp') if isinstance(ev.get('fp'), dict) else {}
    for ck, ek in (('fp_sid', 'sid'), ('fp_cjunc_registry', 'registry'), ('fp_cjunc_rows', 'plan_rows')):
        if not (_hex32(full.get(ck)) and full.get(ck) == fp.get(ek)):
            return f'sv_cf| 주 해 증서 {ck} {full.get(ck)!r} ≠ 증거 fp.{ek} {fp.get(ek)!r} — 다른 런 · 다른 계획의 증서 (10-23 RCA2-04)'
    #  ★ 10-26 묶음 B6 (RR1-01) — 증서 ↔ 그 증서가 푼 가중 그래프: 지문 칸 꼴 (원천 없는 문맥 = 꼴만 · 값 대조 = `graph_problem`)
    if not _hex64(full.get(GRAPH_KEY)):
        return (f'sv_cf| 주 해 증서 가중 그래프 지문 {GRAPH_KEY} = {full.get(GRAPH_KEY)!r} (소문자 hex64 이어야 — 지문 없는 증서 = 그 증서가 푼 '
                f'그래프에 묶을 수 없다 · 10-26 RR1-01)')
    for w, e in ends:
        form = RATIO_STATUSES.get(e.get('status'))
        if form is None:
            continue
        cc = e.get('conv_cert')
        why = (_pos_cert_problem(cc, e.get('G_cut_code'), w, CC) if form == 'finite' else _zero_cert_problem(cc, w, CC))
        if why:
            return why
        diff = [k for k in BIND_FIELDS if cc.get(k) != full.get(k)]
        if diff:
            return f'sv_cf| {w} 증서 결합 칸 {diff} ≠ 주 해 증서 — 다른 런 · 다른 계획의 증서 (10-23 RCA2-04)'
        if not _hex64(cc.get(GRAPH_KEY)):
            return (f'sv_cf| {w} 증서 가중 그래프 지문 {GRAPH_KEY} = {cc.get(GRAPH_KEY)!r} (소문자 hex64 이어야 — 지문 없는 끝 증서 = 그 끝 '
                    f'그래프에 묶을 수 없다 · 10-26 RR1-01)')
    #  ★ 10-23 (사전 공격 리뷰 C1 · 1저자 Q12 (가)) 끝 증서 ↔ 그 끝의 끊은 그래프 (위의 결합 = 그 끝의 G · 런 단위 결합 칸 — 같은 런의 주 해 증서를
    #    끝 자리에 옮긴 기록을 못 가렸다)
    return _topo_problem(rec)


def _topo_of(cc):
    """증서 → 위상 수 (간선, dof, 아래 판 결합, 위 판 결합) | None (dict 아님 · 칸 없음 · 0 이상 정수 · int64 범위 아님 · bool)."""
    if not isinstance(cc, dict):
        return None
    vals = tuple(cc.get(k) for k in CERT_TOPO_KEYS)
    return tuple(int(v) for v in vals) if all(_count_ok(v) for v in vals) else None


def _topo_problem(rec):
    """★ 10-23 (사전 공격 리뷰 C1 · 1저자 Q12 (가) · author 10-23 ratified Q12-Q16) 끝 증서 ↔ 그 끝의 끊은 그래프 → 문제 | None — 비를 싣는 양의 해
    끝 (computed) 이 있는 증서 구간 기록만.  증서 위상 수 (`CERT_TOPO_KEYS` = 간선 · dof · 아래 · 위 판 결합 — 간선 = L 위 삼각 비대각 쌍 · 병렬 간선 =
    한 쌍) 를 주 해 증서 · 기록의 끊은 수와 대조한다.  생산자 (`carbon_junction.CjuncAssembler._assemble`) 가 보장하는 관계: 아래 끝 = 주 계에서 SV 다리
    면 간선 (기록 `n_sv_faces_cut` = 원래 간선 목록에서 떠 있는 성분을 버리기 **전** 에 센 수) 만 뺀 계 (같은 판 입력) · 위 끝 = 아래 끝 계에서 못 가른
    덩어리 셀에 닿는 간선 (`n_edges_cut`) · 판 결합 (`n_plate_couplings_cut`) 을 더 뺀 계 · 끝마다 판에 닿지 않는 성분은 버린다 · ★ 10-23 묶음 A″
    (1저자 Q17 (가)) 끝마다 `n_reach_pairs_cut` = 주 계에서 판에 닿는 성분 (주 계 가지치기와 같은 판정) 안의 dof 쌍 중 그 끝 그래프에 간선이 하나도
    남지 않은 쌍 수 (병렬 간선 = 한 쌍 = 증서 간선 수의 셈 · `carbon_junction._reach_pairs_cut`) ⟹
      ① 아래 끝 판 결합 수 (아래 · 위) = 주 해 (같은 판 입력 · 판 결합은 늘 판에 닿는 성분)
      ② 끝마다 간선 · dof ≤ 주 해 (빼기만 = 부분 그래프 · 판에 닿는 성분은 줄기만 한다)
      ③ 위 끝 판 결합: 아래 · 위 각각 ≤ 주 해 · (주 해 합 − 위 끝 합) = `n_plate_couplings_cut`
      ④ 위 끝 ≤ 아래 끝 (네 수) · 더 뺀 것이 없으면 (`n_edges_cut` = `n_plate_couplings_cut` = 0) 위 끝 = 아래 끝
      ⑤ 끊은 것이 없으면 (아래 끝: n_sv_faces_cut = 0 · 위 끝: n_sv_faces_cut + n_edges_cut + n_plate_couplings_cut = 0) 그 끝 = 주 해 (같은 계)
      ⑥ (등록 핵심 조건 · 1저자 Q12 (가) → ★ 10-23 묶음 A″ 1저자 Q17 (가) — 판에 닿는 성분에서 끊은 수로) 아래 끝: `n_reach_pairs_cut` > 0 이면 그
         끝 ≠ 주 해 (더 작다 · 같은 수 = 거부 — 주 해 증서를 끝 자리에 옮긴 기록) · = 0 이면 그 끝 = 주 해 (같은 계) / 위 끝: `n_reach_pairs_cut` +
         `n_plate_couplings_cut` 으로 같게 — 모든 정직한 기록에서 정확히 성립 (빠진 쌍이 있으면 증서 간선 쌍 수가 준다 · 판 결합을 빼면 판 결합 합이
         준다 · 둘 다 없으면 주 계의 판에 닿는 성분마다 연결이 그대로라 같은 계)
      ⑦ 끊은 수의 독립 출처 — 위 끝 풀이 기록의 `n_sv_faces_cut` (있으면 · 위 끝 상태와 무관) = 아래 끝 (같은 원장 · 같은 끊을 면 표 · 같은 조립에서
         떠 있는 성분을 버리기 전에 센 수)
      ⑧ (★ 10-23 묶음 A″) 새 칸 ↔ 옛 칸 (생산자 보장 · 등식 없음): 아래 끝 `n_reach_pairs_cut` ≤ `n_sv_faces_cut` (빠진 쌍마다 끊은 다리 면 ≥ 1) ·
         위 끝 `n_reach_pairs_cut` ≥ 아래 끝 (위 끝 = 아래 끝 계에서 더 뺀 계) · 위 끝 − 아래 끝 ≤ `n_edges_cut` (위 끝에서만 빠진 쌍마다 더 뺀 간선 ≥ 1) ·
         ★ 10-25 묶음 B (X3) 아래 끝 `n_reach_pairs_cut` + 위 끝 `n_reach_pairs_cut_vs_lower` ≤ 위 끝 `n_reach_pairs_cut` (아래 끝의 판에 닿는 성분 ⊆ 주
         계의 판에 닿는 성분 · 아래 끝에서 이미 빠진 쌍과 겹치지 않는다 — 생산자 보장 · ⑧ 의 위 끝 − 아래 끝 ≤ n_edges_cut 과 함께 그 수 ≤ n_edges_cut)
      ⑨ (★ 10-25 묶음 B · X3 · 1저자 10-23 Q21 (가)) 두 끝 computed: 위 끝 증서 위상 수 ≠ 아래 끝 ⇔ 위 끝 `n_reach_pairs_cut_vs_lower` (아래 끝 그래프의
         판에 닿는 성분 안 dof 쌍 중 위 끝 그래프에 간선이 하나도 남지 않은 쌍 · `carbon_junction._reach_pairs_cut` 같은 함수) + `n_plate_couplings_cut`
         > 0 — 모든 정직한 기록에서 정확히 성립 (⑥ 과 같은 셈: 빠진 쌍이 있으면 증서 간선 쌍 수가 준다 · 판 결합을 빼면 판 결합 합이 준다 · 둘 다
         없으면 아래 끝의 판에 닿는 성분마다 연결이 그대로라 같은 계)
    X5 (★ 10-25 묶음 B · 1저자 10-23 Q21 (가)) — 수 칸 꼴 · ⑦ · ⑧ 관계는 비를 싣는 끝이 있는 기록 전부에서 본다 (computed 끝이 없어도 · 위 끝 풀이 기록 =
      상태와 무관 · 구조화 실패 끝 (`UNSPLIT_MISMATCH`) = 풀이 칸 없음이 그 꼴의 정의 → `_mismatch_problem`) · 증서 위상 수 대조 (①–⑥ · ⑨) 는 computed
      끝이 있을 때만 (옛 판 = 수 칸 꼴 · 관계도 computed 끝이 있을 때만 → 두 끝 +∞ 기록의 새 칸 꼴 · 위 끝 +∞ 의 ⑧ 관계를 안 봤다).
    ⚠ 한정 — ~~⑥ 거짓 거부~~ (★ 10-23 묶음 A″ 고침 — 끊은 간선이 판에 닿지 않는 성분에만 있는 꼴 (FLOAT) · 같은 두 dof 를 잇는 끊지 않은 병렬
      간선이 남는 꼴 (S3 c = 1 축약) = 판에 닿는 성분에서 끊은 쌍 0 → 같은 계로 받는다) · 끊은 수 칸까지 같이 고친 일관 편집 ((a) 아래 끝 ← 주 해
      증서 + n_sv_faces_cut · n_reach_pairs_cut 0 · (b) 위 끝 ← 주 해 증서 + n_edges_cut · n_reach_pairs_cut 0) · 위 끝 ← 아래 끝 증서 (c) 는 받는다
      (1저자 Q18 (가) — 고치지 않는다 · Codex 회차 ① 한정 · 새 칸만 남긴 (a) · (b) 꼴은 ⑧ 이 거부) · 새 칸만 0 으로 고친 바꿔 끼우기 ((a′) 아래 끝 ←
      주 해 증서 + n_reach_pairs_cut 0 · (b′) 위 끝 ← 주 해 증서 + 위 끝 n_reach_pairs_cut 0 · 옛 칸 그대로) = 정직한 FLOAT · 위 끝 FLOAT 기록과 같은 꼴 →
      받는다 (가를 수 없다 · 위 끝 풀이 기록이 있으면 ⑧ 위 끝 ≤ 아래 끝 + n_edges_cut 이 아래 끝 편집을 잡는다) · 증서 수 자체를 지어 낸 편집 (위상
      수까지 고친 위조) 은 이 대조 밖 (봉인이 아니다).
    ⚠ ★ 10-25 묶음 B (X3) 뒤 — 위 끝 ← 아래 끝 증서 (c) 는 아래 끝 ← 위 끝 증서 (X3) 와 같은 위상 꼴 (두 끝 증서 위상 수가 같아진다 · 위상 수만으로 둘을
      가를 수 없다) → 끊은 수 그대로면 ⑨ 가 둘 다 거부한다 (정직한 위 끝 ≠ 아래 끝 기록) · 위 끝 `n_reach_pairs_cut_vs_lower` 까지 0 으로 고친 일관
      편집은 받는다 (남은 한정) · (b) · (b′) 도 아래 끝 = 주 해인 기록 (k = 0) 에서는 같은 꼴 → 그 칸까지 0 으로 고친 편집만 받는다 · (a) · (a′) · k = 0
      경계 (아래 끝 ← 주 해 증서 · 끊은 수 그대로 · 아래 끝 = 주 해인 기록) = 위상 수가 안 바뀌어 그대로 받는다."""
    lo_c = RATIO_STATUSES.get(rec.get('status')) == 'finite'
    up = rec.get('upper') if isinstance(rec.get('upper'), dict) else None
    up_c = up is not None and RATIO_STATUSES.get(up.get('status')) == 'finite'
    tag = '(10-23 사전 공격 리뷰 C1)'
    tag2 = '(10-23 사전 공격 리뷰 C1 · 묶음 A″)'
    tag3 = '(10-25 묶음 B · X3)'
    #  ── ★ 10-25 묶음 B (X5) 수 칸 꼴 · ⑦ · ⑧ = 비를 싣는 끝이 있는 기록 전부 (computed 끝이 없어도 · 위 끝 풀이 기록 = 상태와 무관 · 구조화 실패 끝은
    #     풀이 칸 없음이 정의 → `_mismatch_problem`) ──
    c = rec.get('n_sv_faces_cut')
    if not _count_ok(c):
        return f'sv_cf| 끊은 SV 다리 면 수 n_sv_faces_cut {c!r} (0 이상 정수 · int64 — 비를 싣는 끝의 끊은 그래프를 대조할 수 없다) {tag}'
    c = int(c)
    un = up.get('n_sv_faces_cut') if up is not None else None
    if un is not None and not (_count_ok(un) and int(un) == c):
        return (f'sv_cf| 위 끝 풀이 기록 n_sv_faces_cut {un!r} ≠ 아래 끝 {c} (같은 원장 · 같은 끊을 면 표 · 같은 조립에서 센 수 — 끊은 수 칸이 고쳐졌다) '
                f'{tag}')
    k = rec.get('n_reach_pairs_cut')
    if not _count_ok(k):
        return (f'sv_cf| 아래 끝 판에 닿는 성분에서 끊은 쌍 수 n_reach_pairs_cut {k!r} (0 이상 정수 · int64 — 비를 싣는 끝의 끊은 그래프를 주 해에 대조할 수 '
                f'없다) {tag2}')
    k = int(k)
    if k > c:
        return (f'sv_cf| 아래 끝 n_reach_pairs_cut {k} > n_sv_faces_cut {c} (판에 닿는 성분에서 빠진 쌍마다 끊은 다리 면 ≥ 1 — 생산자 보장 · 새 칸 ↔ 옛 칸 '
                f'모순) {tag2}')
    upr = up if (up is not None and up.get('status') != UNSPLIT_MISMATCH) else None
    ne = npc = ku = kul = None
    #  옮긴 ⑧ · 새 관계 (아래 끝 새 칸 + kul ≤ 위 끝 새 칸) 의 위반 = computed 끝이 없으면 바로 · 있으면 옛 자리 (⑧) · 옛 규칙 뒤 (새 관계) — 옛 판이 거부하던
    #  기록의 사유는 그대로 둔다
    rel8 = late = None
    if upr is not None:
        ne, npc = upr.get('n_edges_cut'), upr.get('n_plate_couplings_cut')
        if not (_count_ok(ne) and _count_ok(npc)):
            return f'sv_cf| 위 끝 n_edges_cut {ne!r} · n_plate_couplings_cut {npc!r} (0 이상 정수 · int64 — 위 끝 끊은 그래프를 대조할 수 없다) {tag}'
        ne, npc = int(ne), int(npc)
        ku = upr.get('n_reach_pairs_cut')
        if not _count_ok(ku):
            return (f'sv_cf| 위 끝 판에 닿는 성분에서 끊은 쌍 수 n_reach_pairs_cut {ku!r} (0 이상 정수 · int64 — 위 끝 끊은 그래프를 주 해에 대조할 수 없다) '
                    f'{tag2}')
        ku = int(ku)
        kul = upr.get('n_reach_pairs_cut_vs_lower')
        if not _count_ok(kul):
            return (f'sv_cf| 위 끝 아래 끝 계 대비 판에 닿는 성분에서 끊은 쌍 수 n_reach_pairs_cut_vs_lower {kul!r} (0 이상 정수 · int64 — 위 끝 끊은 그래프를 '
                    f'아래 끝에 대조할 수 없다 · 위 끝 상태와 무관 · X5) {tag3}')
        kul = int(kul)
        if not k <= ku <= k + ne:
            rel8 = (f'sv_cf| 위 끝 n_reach_pairs_cut {ku} ∉ [아래 끝 {k}, 아래 끝 + n_edges_cut {k + ne}] (위 끝 = 아래 끝 계에서 더 뺀 계 · 위 끝에서만 빠진 쌍마다 '
                    f'더 뺀 간선 ≥ 1 — 생산자 보장 · 새 칸 ↔ 옛 칸 모순) {tag2}')
        if k + kul > ku:
            late = (f'sv_cf| 위 끝 n_reach_pairs_cut_vs_lower {kul} + 아래 끝 n_reach_pairs_cut {k} > 위 끝 n_reach_pairs_cut {ku} (아래 끝의 판에 닿는 성분 ⊆ 주 '
                    f'계의 판에 닿는 성분 · 아래 끝에서 이미 빠진 쌍과 겹치지 않는다 — 생산자 보장 · 새 칸 ↔ 새 칸 모순) {tag3}')
    if not (lo_c or up_c):
        return rel8 or late
    M = _topo_of(rec.get('conv_cert_full'))
    if M is None:
        got = {k_: (rec.get('conv_cert_full') or {}).get(k_) for k_ in CERT_TOPO_KEYS} if isinstance(rec.get('conv_cert_full'), dict) else None
        return f'sv_cf| 주 해 증서 위상 수 {got!r} (간선 · dof · 판 결합 = 0 이상 정수 · int64 — 끝 증서를 끊은 그래프에 묶을 수 없다) {tag}'
    names = ('간선', 'dof', '아래 판 결합', '위 판 결합')
    L = None
    if lo_c:
        L = _topo_of(rec.get('conv_cert'))
        if L is None:
            return f'sv_cf| 아래 끝 증서 위상 수 없음 · 꼴 (간선 · dof · 판 결합 = 0 이상 정수 · int64) {tag}'
        if L[2:] != M[2:]:
            return f'sv_cf| 아래 끝 증서 판 결합 수 {L[2:]} ≠ 주 해 {M[2:]} (아래 끝 = 같은 판 입력 · SV 다리 면만 끊음) {tag}'
        big = [names[i] for i in (0, 1) if L[i] > M[i]]
        if big:
            return f'sv_cf| 아래 끝 증서 {big} {L} > 주 해 {M} (끊기만 한 부분 그래프 — 주 해보다 클 수 없다) {tag}'
        if c == 0 and L != M:
            return f'sv_cf| 끊은 다리 면 0 인데 아래 끝 증서 위상 수 {L} ≠ 주 해 {M} (끊은 것 없음 = 같은 계) {tag}'
        if k == 0 and L != M:
            return (f'sv_cf| 판에 닿는 성분에서 끊은 쌍 0 (n_reach_pairs_cut · 끊은 다리 면 {c}) 인데 아래 끝 증서 위상 수 {L} ≠ 주 해 {M} (빠진 쌍이 없으면 '
                    f'같은 계) {tag2}')
        if k > 0 and L == M:
            return (f'sv_cf| 판에 닿는 성분에서 끊은 쌍 {k} (n_reach_pairs_cut · 끊은 다리 면 {c}) 인데 아래 끝 증서 위상 수 = 주 해 {M} (끊었으면 주 해보다 '
                    f'작다 — 주 해 증서를 끝 자리에 옮긴 기록 · 같은 수 = 거부) {tag2}')
    if up_c:
        U = _topo_of(up.get('conv_cert'))
        if U is None:
            return f'sv_cf| 위 끝 증서 위상 수 없음 · 꼴 (간선 · dof · 판 결합 = 0 이상 정수 · int64) {tag}'
        big = [names[i] for i in range(4) if U[i] > M[i]]
        if big:
            return f'sv_cf| 위 끝 증서 {big} {U} > 주 해 {M} (더 뺀 부분 그래프 — 주 해보다 클 수 없다) {tag}'
        if (M[2] + M[3]) - (U[2] + U[3]) != npc:
            return (f'sv_cf| 위 끝 증서 판 결합 수 {U[2:]} — 주 해 {M[2:]} 에서 뺀 수 {(M[2] + M[3]) - (U[2] + U[3])} ≠ n_plate_couplings_cut {npc} '
                    f'(위 끝 = 덩어리 셀의 판 결합만 뺀 판) {tag}')
        if L is not None:
            big = [names[i] for i in range(4) if U[i] > L[i]]
            if big:
                return f'sv_cf| 위 끝 증서 {big} {U} > 아래 끝 {L} (위 끝 = 아래 끝 판에서 더 뺀 판) {tag}'
            if ne == 0 and npc == 0 and U != L:
                return f'sv_cf| 위 끝이 더 뺀 간선 · 판 결합 0 인데 위 끝 증서 위상 수 {U} ≠ 아래 끝 {L} (더 뺀 것 없음 = 같은 계) {tag}'
        cut_up = c + ne + npc
        if cut_up == 0 and U != M:
            return f'sv_cf| 위 끝이 끊은 것 0 인데 위 끝 증서 위상 수 {U} ≠ 주 해 {M} (끊은 것 없음 = 같은 계) {tag}'
        if rel8:                                           # ⑧ 옛 자리
            return rel8
        reach_up = ku + npc
        if reach_up == 0 and U != M:
            return (f'sv_cf| 위 끝이 판에 닿는 성분에서 끊은 것 0 (n_reach_pairs_cut 0 · 판 결합 0 · 옛 칸 다리 면 {c} · 간선 {ne}) 인데 위 끝 증서 위상 수 {U} ≠ '
                    f'주 해 {M} (빠진 쌍 · 판 결합이 없으면 같은 계) {tag2}')
        if reach_up > 0 and U == M:
            return (f'sv_cf| 위 끝이 판에 닿는 성분에서 끊은 것 {reach_up} (n_reach_pairs_cut {ku} · 판 결합 {npc} · 옛 칸 다리 면 {c} · 간선 {ne}) 인데 위 끝 증서 '
                    f'위상 수 = 주 해 {M} (끊었으면 주 해보다 작다 — 주 해 증서를 끝 자리에 옮긴 기록 · 같은 수 = 거부) {tag2}')
        if L is not None:                                  # ⑨ (★ 10-25 묶음 B · X3) 위 끝 ≠ 아래 끝 ⇔ 아래 끝 계 대비 끊은 쌍 + 판 결합 > 0 (옛 규칙 뒤)
            reach_lo = kul + npc
            if (U != L) != (reach_lo > 0):
                return (f'sv_cf| 위 끝이 아래 끝 계 대비 판에 닿는 성분에서 끊은 것 {reach_lo} (n_reach_pairs_cut_vs_lower {kul} · 판 결합 {npc}) 인데 위 끝 증서 '
                        f'위상 수 {U} {"=" if U == L else "≠"} 아래 끝 {L} (끊었으면 아래 끝보다 작다 · 안 끊었으면 같은 계 — 아래 끝 ← 위 끝 증서 · 위 끝 ← 아래 끝 '
                        f'증서를 옮긴 기록) {tag3}')
    return rel8 or late


def _census_problem(rec, ev):
    """★ 10-23 (Codex 재검토 RCA2-04) 실제 census (증거 `census` · 생산자가 원장에서 낸 값) ↔ 기록 → 문제 | None — 세 칸 = 0 이상 정수 · int64 ·
    못 가른 ≤ 다리 놓는 ≤ 닿는 성분 (생산자 정의 `carbon_junction._sv_split`) · 기록이 옮겨 실은 census 사본 (`CENSUS_COPY_KEYS`) = 실제 census."""
    cen = ev.get('census') if isinstance(ev, dict) else None
    if not isinstance(cen, dict):
        return 'sv_cf| 증거 census 가 없다 — 못 가른 덩어리 수 · 제거 수를 실제 census 와 대조할 수 없다 (10-23 RCA2-04)'
    for k in CENSUS_KEYS:
        if not _count_ok(cen.get(k)):
            return f'sv_cf| 증거 census {k} = {cen.get(k)!r} (0 이상 정수 · int64 범위)'
    nu, nb, nt = (int(cen[k]) for k in CENSUS_KEYS)
    if not nu <= nb <= nt:
        return (f'sv_cf| 증거 census 못 가른 {nu} ≤ 다리 놓는 {nb} ≤ 닿는 성분 {nt} 가 아니다 (생산자 정의 — 못 가른 덩어리 ⊆ 다리 놓는 성분 ⊆ '
                f'닿는 성분)')
    for k in CENSUS_COPY_KEYS:
        v = rec.get(k)
        if v is None and k != 'n_unsplit_bridging_components':
            continue
        w = cen.get(k)
        if not (_count_ok(v) and _count_ok(w) and int(v) == int(w)):
            return f'sv_cf| 기록 {k} {v!r} ≠ 증거 census {w!r} (기록의 census 사본 = 실제 census · 10-23 RCA2-04)'
    return None


def _interval_problem(rec):
    """★ 10-23 (RCA2-01) 판정 근거 칸 `ratio_cert_interval` = 이 기록의 증서에서 `cert_interval` 로 다시 센 값 (같은 꼴 · 같은 수 · +∞ = 'inf')."""
    lo, hi = cert_interval(rec)
    want = [_enc(lo), _enc(hi)]
    got = rec.get('ratio_cert_interval')
    if not (isinstance(got, list) and len(got) == 2 and all(type(a) is type(b) and a == b for a, b in zip(got, want))):   # noqa: E721
        return f'sv_cf| 증서 구간 비 칸 {got!r} ≠ 기록의 증서에서 다시 셈 {want!r} (판정 근거 칸 · 10-23 RCA2-01)'
    return None


def _pos_bracket(cc, G):
    """양의 해 증서 → (목표량 하한, 상한) | None — POSITIVE_SOLVED · ok · ⓐ–ⓓ 참 · 게시 판 전류 = 그 끝의 G (정확) · 0 < 하한 ≤ 상한 유한."""
    if not isinstance(cc, dict) or cc.get('status') != CERT_OK_STATUS:
        return None
    if any(cc.get(k) is not True for k in ('ok', 'pass_a', 'pass_b', 'pass_c', 'pass_d')):
        return None
    ib, a, b = cc.get('I_bot'), cc.get('target_lo'), cc.get('target_hi')
    if not (_pos_float(G) and _pos_float(ib) and ib == G and _pos_float(a) and _pos_float(b) and a <= b):
        return None
    return a, b


def _end_bracket(end):
    """한 끝 → (목표량 하한, 상한) (computed · 양의 해 증서) | 'zero' (관통 없음 · 영값 위상 증서 · G_cut 정확히 0 = 위상이 증명한 0) | None."""
    if not isinstance(end, dict):
        return None
    form = RATIO_STATUSES.get(end.get('status'))
    if form == 'finite':
        return _pos_bracket(end.get('conv_cert'), end.get('G_cut_code'))
    if form == 'inf':
        cc, gc = end.get('conv_cert'), end.get('G_cut_code')
        if (isinstance(cc, dict) and cc.get('status') == CERT_ZERO_STATUS and cc.get('ok') is True
                and cc.get('zero_source') == 'early_return' and cc.get('zero_graph') == ZERO_GRAPH_SV_CF
                and type(cc.get('n_through_dof')) is int and cc['n_through_dof'] == 0
                and isinstance(cc.get('sigma'), float) and cc['sigma'] == 0.0
                and isinstance(gc, float) and not _is_bool(gc) and gc == 0.0):   # noqa: E721
            return 'zero'
    return None


def _nextafter(x, toward):
    """x 다음의 float (toward 쪽) — `math.nextafter` 와 같은 값.  `math.nextafter` 는 3.9+ 이고 kgy dem-venv 는 Python 3.8.10 이다
    (10-24 실측) → 3.8 에서는 IEEE 754 비트 한 칸으로 셈한다 (NaN · ±0 · ±inf · 부호 규칙 = C99 nextafter)."""
    f = getattr(math, 'nextafter', None)
    if f is not None:
        return f(x, toward)
    x, toward = float(x), float(toward)
    if math.isnan(x) or math.isnan(toward):
        return x + toward
    if x == toward:
        return toward
    if x == 0.0:
        return math.copysign(5e-324, toward)
    n = struct.unpack('<q', struct.pack('<d', x))[0]
    n += 1 if (toward > x) == (x > 0.0) else -1
    return struct.unpack('<d', struct.pack('<q', n))[0]


def _div_dir(a, b, up):
    """a / b (유한 양의 float 둘) 의 방향 반올림 — 아래 (up False) = 정확 몫 이하의 가장 큰 float · 위 = 정확 몫 이상의 가장 작은 float
    (정확 분수 — float 나눗셈의 반올림이 칼날에서 판정 쪽으로 기울지 않게) · 위 끝 넘침 = None (∞ = 위상만) · 아래 끝 넘침 = 가장 큰 유한 float."""
    q = Fraction(a) / Fraction(b)
    try:
        f = q.numerator / q.denominator            # int / int = 올바른 반올림 (가장 가까운 float)
    except OverflowError:
        return None if up else sys.float_info.max
    if not math.isfinite(f):
        return None if up else sys.float_info.max
    fq = Fraction(f)
    if up and fq < q:
        f = _nextafter(f, math.inf)
    elif not up and fq > q:
        f = _nextafter(f, -math.inf)
    if not math.isfinite(f):
        return None if up else sys.float_info.max
    return f


def cert_interval(rec):
    """★ 10-23 (Codex 재검토 RCA2-01 · 1저자 Q1 (가)) 증서 구간 비 → (아래비, 위비) — 판정 근거 (nominal 비 아님).
    아래비 = Gfull_lo / Gcut_lower_hi (내림) — 참 비 ≥ 아래 끝 참 비 ≥ 이 값 · 위비 = Gfull_hi / Gcut_upper_lo (올림) — 참 비 ≤ 위 끝 참 비 ≤ 이 값
    (Gfull = 주 해 증서 (`conv_cert_full`) · Gcut_lower = 아래 끝 증서 · Gcut_upper = 위 끝 (`upper`) 증서 · 못 가른 덩어리 0 = 아래 끝 그 자체).
    +∞ = 그 끝의 영값 위상 증서가 증명한 0 분모만 · None = 못 정함 (증서 구간 기록 아님 · 주 해 · 그 끝 증서가 없거나 묶이지 않음 · 비를 싣지
    않는 상태 · 위비 넘침).  넘어 온 값은 float · +∞ · None (JSON 'inf' 는 받지 않는다 — 투영 · 검증기가 다시 센다)."""
    if not isinstance(rec, dict) or rec.get('standing') != STANDING_CERTIFIED:
        return None, None
    full = _pos_bracket(rec.get('conv_cert_full'), rec.get('G_full_code'))
    if full is None:
        return None, None
    lo_end = _end_bracket(rec)
    up, nu = rec.get('upper'), rec.get('n_unsplit_bridging_components')
    if isinstance(up, dict):
        hi_end = _end_bracket(up)
    elif up is None and isinstance(nu, numbers.Integral) and not _is_bool(nu) and int(nu) == 0:
        hi_end = lo_end
    else:
        hi_end = None
    lo = math.inf if lo_end == 'zero' else (None if lo_end is None else _div_dir(full[0], lo_end[1], up=False))
    hi = math.inf if hi_end == 'zero' else (None if hi_end is None else _div_dir(full[1], hi_end[0], up=True))
    return lo, hi


def _end_view(st, r_, lim):
    """한 끝의 (상태, 비, 표지) → 사슬이 읽는 비 (float · +∞ · None = 못 읽음).  ★ PF2 E (10-22) — finite 꼴 = 유한 양의 float 만 ·
    inf 꼴 = 비 null + 표지 'inf' 만 (NaN · 음수 · 0 · ±∞ · bool · 수가 실린 inf 꼴 = 못 읽음 → 사슬 SV_UNCHECKED)."""
    form = RATIO_STATUSES.get(st)
    if form == 'finite' and _pos_float(r_):
        return r_
    if form == 'inf' and lim == 'inf' and r_ is None:
        return math.inf
    return None


def chain_view(rec):
    """사슬 (판정) 이 읽는 꼴 → {'status', 'ratio', 'status_hi', 'ratio_hi' (float · +∞ · None), 'n_unsplit', 'standing', 'ratio_cert_lo',
    'ratio_cert_hi'} — 비 · 상태 · 덩어리 수 · 지위 · 증서 구간 (정의 무관).  ★ 10-22 (Q1 (다)) ratio = 아래 끝 · ratio_hi = 위 끝 (못 가른
    덩어리를 통째로 뺀 판 · 덩어리 0 = 아래 끝과 같다) — 위 끝 칸이 없는 옛 기록 = 위 끝 None (못 읽음 · 사슬 = SV_UNCHECKED · fail-closed).
    ★ 10-23 (RCA2-01 · Q1 (가)) 판정 = `ratio_cert_lo` · `ratio_cert_hi` (`cert_interval` 로 이 자리에서 다시 센다 — 기록의 칸을 믿지 않는다) ·
    ratio · ratio_hi (nominal) = 기록 · 보고만 (판정에 쓰지 않는다)."""
    if not isinstance(rec, dict):
        return {'status': None, 'ratio': None, 'status_hi': None, 'ratio_hi': None, 'n_unsplit': None, 'standing': None,
                'ratio_cert_lo': None, 'ratio_cert_hi': None}
    st, sh = rec.get('status'), rec.get('status_hi')
    nu = rec.get('n_unsplit_bridging_components')
    lo, hi = cert_interval(rec)
    return {'status': st, 'ratio': _end_view(st, rec.get('sv_counterfactual_ratio'), rec.get('ratio_limit')),
            'status_hi': sh, 'ratio_hi': _end_view(sh, rec.get('sv_counterfactual_ratio_hi'), rec.get('ratio_limit_hi')),
            'n_unsplit': (int(nu) if isinstance(nu, numbers.Integral) and not _is_bool(nu) else None),
            'standing': rec.get('standing'), 'ratio_cert_lo': lo, 'ratio_cert_hi': hi}

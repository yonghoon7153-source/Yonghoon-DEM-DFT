#!/bin/bash
# mk.sh <name> <sealed-doc-source> <kgy-doc-source>  -> tree t_<name> with symlinked scripts
D=$(cd "$(dirname "$0")" && pwd); C=$D/../../clone
t=$D/t_$1; rm -rf "$t"; mkdir -p "$t/docs/reviews/rint2_seal_20261120"
ln -s $C/scripts "$t/scripts"
cp "$2" "$t/docs/reviews/rint2_seal_20261120/registration_R_sealed.md"; cp "$3" "$t/docs/reviews/rint2_kgy_commands_20261020.md"

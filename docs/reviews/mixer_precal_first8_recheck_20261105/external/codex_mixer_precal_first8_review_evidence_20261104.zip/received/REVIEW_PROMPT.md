# 보정 전 믹싱 첫8 준비·관측 연결 — 독립 반박 요청

리뷰 핀 `189930cc68b6e58beb6b4546d80353dc03852195`, 가지 `codex/mixer-1104`. ZIP의 PIN.txt·SNAPSHOT_MANIFEST.json과 대조해 주세요. 이전 문서/NOTE01 수용과 별개인 새 코드 단위입니다. REQUEST.md의 여섯 질문을 검토해 주세요.

범위: 첫8 고정 덱·메타 정적 준비, 양의 Bo D2 대조와 별도 미등록 N0/E0, 실제 인쇄 반경/기하/프레임/E0 결속, D13 총누락·상별 관측수, 순간 접촉·기존 M, 해시한 bytes 직접 파싱과 fresh 완료 로그 조건. 출력은 “믹서 판독 전용 AM–SE 접촉 부착”이며 MPM 피복이 아닙니다.

직접 시험: `python scripts/test_mixer_precal_prepare.py`, `python scripts/test_mixer_precal_observe.py` (numpy/scipy 필요). 이들은 작은 합성 입력의 로컬 시험이며 LIGGGHTS/ibb/WSL을 실행하지 않습니다. 작성 측은 각 Python3.8.20/3.11.17에서 준비14·관측20 메서드 통과, 정적8조건 및3짝을 별도로 기록했습니다. 단위 개수·조건·짝 수는 합산하지 않습니다. 관측 단위의 prepare binding mock, 회전 wiring의 cell_stats mock, 실제100000입자 양성 경로/실로그 미검증을 특히 구분해 주세요.

evidence/validation_summary.json은 원본 실패·중간·최종 소스 해시와 경계를 구분합니다. ABA/ERROR 내부 반례 및 thermo5반례의 전후 로그를 포함합니다. 내부 확인을 외부 종결로 인정하지 않습니다. 새 P1/P2/P3가 있으면 재현 조건·최소 수정·대상 핀을 남겨 주세요. 없으면 첫8 정적 준비·합성 관측 연결에만 한정해 수용 여부를 판정해 주세요.

전체 check_all은 이번에 다시 실행하지 않았고 전체 HOLD입니다. 기존 MXD2R 외부 재확인은 별개 대기입니다. 실제 연구 결과0건·실제 호스트 접근/계산·제출·재개·등록·배포·Claude 통합·원장 종결은 요청하지 않습니다. ibb 후속 시점은 D0.7 종료 후·1저자 승인 후입니다. 지금 큐/제출 계획은 없습니다. 발송은1저자가 하며 Rint② 우선입니다.

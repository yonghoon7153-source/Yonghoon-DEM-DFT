KGY_REL = 'docs/reviews/rint2_kgy_commands_20261020.md'
ORIG_REL = 'docs/reviews/rint_carbon_additive_registration_R_draft_20261020.md'


# ── 자기 시험 (11-17 · v2.1 · 내부 반박 리뷰 P2-1 변이 D1–D10 + 새 검사 반례 · 고치기 전 도구에서 먼저 돌려 빠뜨림을 본 뒤 고쳤다) ──
def _fence_spans(text, kind):
    """```<kind> 울타리 안 글자 자리 (시작 · 끝) 목록 — 도구와 같은 울타리 셈 (줄 앞뒤 빈칸을 걷은 줄이 ``` 로 시작하면 울타리 줄)."""
    spans, pos, fence, beg = [], 0, None, 0
    for ln in text.split('\n'):
        s = ln.strip()
        if s.startswith('```'):
            if fence is None:
                fence, beg = s[3:].strip(), pos + len(ln) + 1
            else:
                if fence == kind:
                    spans.append((beg, pos))
                fence = None
        pos += len(ln) + 1
    return spans


def _rep_in(text, kind, old, new):
    """``` <kind> 울타리 안의 첫 `old` 를 `new` 로 — 없으면 시험 오류 (변이 자리 없음 = 그 경우 실패)."""
    for a, b in _fence_spans(text, kind):
        i = text.find(old, a, b)
        if i >= 0:
            return text[:i] + new + text[i + len(old):]
    raise AssertionError(f'변이 자리 없음 ({kind} · {old[:60]!r})')


def _fence_lines(text, kind):
    """첫 ```<kind> 울타리의 여는 줄 · 닫는 줄 번호 (0 부터)."""
    lines, fence, at = text.split('\n'), None, None
    for i, ln in enumerate(lines):
        s = ln.strip()
        if s.startswith('```'):
            if fence is None:
                fence, at = s[3:].strip(), i
            else:
                if fence == kind:
                    return lines, at, i
                fence = None
    raise AssertionError(f'```{kind} 울타리 없음')


def _drop_fence(text, kind):
    lines, a, b = _fence_lines(text, kind)
    return '\n'.join(lines[:a] + lines[a + 1:b] + lines[b + 1:])


def _retag_fence(text, kind, new):
    lines, a, _b = _fence_lines(text, kind)
    lines[a] = lines[a].replace('```' + kind, '```' + new, 1)
    return '\n'.join(lines)


def _drop_line_in(text, kind, prefix):
    for a, b in _fence_spans(text, kind):
        seg = text[a:b].split('\n')
        for k, ln in enumerate(seg):
            if ln.startswith(prefix):
                return text[:a] + '\n'.join(seg[:k] + seg[k + 1:]) + text[b:]
    raise AssertionError(f'변이 자리 없음 (줄 {prefix[:60]!r})')


def _parse_expect(s):
    out = {}
    for part in s.split(','):
        k, _, v = part.partition('=')
        c, _, s0 = v.partition('+')
        if not (k and c.isdigit() and s0.isdigit()):
            raise SystemExit(f'--expect 꼴 = sealed=<사슬>+<S0>,kgy=<사슬>+<S0> · {s!r}')
        out[k] = (int(c), int(s0))
    if set(out) != {'sealed', 'kgy'}:
        raise SystemExit(f'--expect 이름 = sealed · kgy · {sorted(out)}')
    return out


def _fmt_expect(e):
    return ','.join(f'{k}={e[k][0]}+{e[k][1]}' for k in ('sealed', 'kgy'))


def _selftest(argv):
    """argv: <봉인 꼴 트리> <봉인본 리포 상대 자리> --expect sealed=<n>+<m>,kgy=<n>+<m> (= 그 트리 그대로의 셈).
    경우마다 임시 트리 (scripts = 원 트리 심볼릭 링크 · 문서 셋 = 변이) 에서 이 파일을 python3 -I 로 따로 돌려 rc (와 표지 글자) 를 본다."""
    import argparse as _ap
    import shutil as _sh
    import subprocess as _sp
    import tempfile as _tf
    p = _ap.ArgumentParser(prog='check_sh_commands.py --selftest')
    p.add_argument('tree')
    p.add_argument('sealed_rel')
    p.add_argument('--expect', required=True)
    a = p.parse_args(argv)
    tree = os.path.abspath(a.tree)
    exp0 = _parse_expect(a.expect)
    base = {k: Path(tree, rel).read_text(encoding='utf-8') for k, rel in (('sealed', a.sealed_rel), ('kgy', KGY_REL), ('orig', ORIG_REL))}
    reg = '~/dem-ca1/' + a.sealed_rel

    def m(**kw):
        def f(d):
            d = dict(d)
            for k, fn in kw.items():
                d[k] = fn(d[k])
            return d
        return f

    def ex(sealed=(0, 0), kgy=(0, 0)):
        return {'sealed': (exp0['sealed'][0] + sealed[0], exp0['sealed'][1] + sealed[1]), 'kgy': (exp0['kgy'][0] + kgy[0], exp0['kgy'][1] + kgy[1])}

    d1 = lambda t: _rep_in(t, 'sh', f'--init --plan ~/sdcp/ca1_plan.json --registration {reg}', '--init --plan ~/sdcp/ca1_plan.json')

    def d10(t):
        old = 'nohup python3 ~/dem-ca1/scripts/rint_r_chain.py --stage ladder'
        t = _rep_in(t, 'sh', old, 'nohup python3 -I ~/dem-ca1/scripts/rint_r_chain.py --stage ladder')
        i = t.find('nohup python3 -I ~/dem-ca1/scripts/rint_r_chain.py --stage ladder')
        j = t.find(f' --registration {reg}', i)
        assert j > i, '변이 자리 없음 (D10 --registration)'
        return t[:j] + t[j + len(f' --registration {reg}'):]

    def d13(t):
        for aa, bb in _fence_spans(t, 'bash'):
            mo = re.compile(r'python3 (\S*rint_r_chain\.py)').search(t, aa, bb)
            if mo:
                return t[:mo.start()] + 'python3 -I ' + mo.group(1) + t[mo.end():]
        raise AssertionError('변이 자리 없음 (D13)')

    cases = [
        ('D0 그대로', m(), ex(), 0, None),
        ('D1 봉인본 원장 --init 줄 --registration 지움', m(sealed=d1), ex(), 1, None),
        ('D2 봉인본 sh 울타리 지움', m(sealed=lambda t: _drop_fence(t, 'sh')), ex(), 1, None),
        ('D3 봉인본 원장 --init 줄 = python3 -I + --registration 지움', m(sealed=lambda t: _rep_in(
            t, 'sh', f'python3 ~/dem-ca1/scripts/rint_r_chain.py --stage ledger --ledger ~/sdcp/ca1_ledger --init --plan ~/sdcp/ca1_plan.json --registration {reg}',
            'python3 -I ~/dem-ca1/scripts/rint_r_chain.py --stage ledger --ledger ~/sdcp/ca1_ledger --init --plan ~/sdcp/ca1_plan.json')), ex(), 1, None),
        ('D4 D1 + 그 울타리 = bash', m(sealed=lambda t: _retag_fence(d1(t), 'sh', 'bash')), ex(), 1, None),
        ('D5 명령 문서 --max-hours 160', m(kgy=lambda t: _rep_in(t, 'sh', '--max-hours 168', '--max-hours 160')), ex(), 1, None),
        ('D6 명령 문서 --registration = 원본 자리', m(kgy=lambda t: _rep_in(t, 'sh', f'--registration {reg}', '--registration ~/dem-ca1/' + ORIG_REL)), ex(), 1, None),
        ('D7 명령 문서 S0 --r-doc 지움', m(kgy=lambda t: _rep_in(t, 'sh', f' --r-doc {a.sealed_rel}', '')), ex(), 1, None),
        ('D8 명령 문서 S0 --r-doc = 원본 자리', m(kgy=lambda t: _rep_in(t, 'sh', f'--r-doc {a.sealed_rel}', '--r-doc ' + ORIG_REL)), ex(), 1, None),
        ('D8b 명령 문서 S0 줄 python3 -u + --r-doc 지움', m(kgy=lambda t: _rep_in(_rep_in(
            t, 'sh', 'python3 ~/dem-ca1/scripts/ca_s0_census.py --stage 2', 'python3 -u ~/dem-ca1/scripts/ca_s0_census.py --stage 2'),
            'sh', f' --r-doc {a.sealed_rel}', '')), ex(), 1, None),
        ('D9 명령 문서 --cjunc-store ~/p6_cjstore (Q4 표지)', m(kgy=lambda t: _rep_in(t, 'sh', '--cjunc-store ~/ca1_cjstore', '--cjunc-store ~/p6_cjstore')),
         ex(), 1, '(Q4)'),
        ('D10 명령 문서 사다리 nohup 줄 python3 -I + --registration 지움', m(kgy=d10), ex(), 1, None),
        ('D11 봉인본 recover 줄 지움 + 기대 셈 맞춤 (한 문서에만 있는 종류)', m(sealed=lambda t: _drop_line_in(
            t, 'sh', 'python3 ~/dem-ca1/scripts/rint_r_chain.py --stage recover')), ex(sealed=(-1, 0)), 1, '한 문서에만'),
        ('D12 그대로 + 기대 셈 틀림', m(), ex(kgy=(1, 0)), 1, '기대 셈'),
        ('D13 명령 문서 bash (계약 꼴) 사슬 줄 python3 -I', m(kgy=d13), ex(), 1, '못 읽은 줄'),
        ('D14 봉인본 sh 울타리 = shell', m(sealed=lambda t: _retag_fence(t, 'sh', 'shell')), ex(), 1, 'sh · bash 밖'),
        ('D15 원본 자리에 sh 사슬 줄', m(orig=lambda t: t + '\n```sh\npython3 ~/dem-ca1/scripts/rint_r_chain.py --stage plan-doc --plan ~/sdcp/ca1_plan.json '
                                         '--check-doc\n```\n'), ex(), 1, '원본 자리'),
        ('D16 명령 문서 사다리 P0 dry-run --machine gabia (Q6 표지)', m(kgy=lambda t: _rep_in(
            t, 'sh', '--machine kgy --cjunc-store ~/ca1_cjstore --out ~/sdcp/ca1_ladder_P0 --dry-run',
            '--machine gabia --cjunc-store ~/ca1_cjstore --out ~/sdcp/ca1_ladder_P0 --dry-run')), ex(), 1, '(Q6)'),
        ('D2b D2 + 기대 셈 0 (sh 명령 0 개)', m(sealed=lambda t: _drop_fence(t, 'sh')), {'sealed': (0, 0), 'kgy': exp0['kgy']}, 1, 'sh 명령 0'),
    ]
    td = _tf.mkdtemp(prefix='csc_selftest_')
    ok, bad, rows = 0, [], []
    try:
        for name, fn, exp, want, marker in cases:
            tag = name.split()[0]
            try:
                docs = fn(base)
            except AssertionError as e:
                bad.append(f'{tag}: {e}')
                rows.append(f'{tag} | 변이 못 만듦 | {e}')
                continue
            t = os.path.join(td, 't_' + tag)
            for rel in (a.sealed_rel, KGY_REL, ORIG_REL):
                os.makedirs(os.path.dirname(os.path.join(t, rel)), exist_ok=True)
            os.symlink(os.path.join(tree, 'scripts'), os.path.join(t, 'scripts'))
            for k, rel in (('sealed', a.sealed_rel), ('kgy', KGY_REL), ('orig', ORIG_REL)):
                Path(t, rel).write_text(docs[k], encoding='utf-8')
            r = _sp.run([sys.executable, '-I', os.path.abspath(__file__), t, a.sealed_rel, os.path.join(td, 'h_' + tag), '--expect', _fmt_expect(exp)],
                        capture_output=True, text=True)
            good = r.returncode == want and (marker is None or marker in r.stdout)
            last = (r.stdout.strip().splitlines() or [''])[-1]
            rows.append(f'{tag} | 기대 rc {want}{" + " + repr(marker) if marker else ""} | 실제 rc {r.returncode} | {"PASS" if good else "FAIL"} | {last[:150]}')
            if good:
                ok += 1
            else:
                bad.append(tag)
    finally:
        _sh.rmtree(td, ignore_errors=True)
    for r_ in rows:
        print(r_)
    print(f'check_sh_commands selftest: {ok}/{len(cases)} PASS' + (f'   FAILED: {bad}' if bad else ''))
    return 0 if not bad else 1


if __name__ == '__main__' and len(sys.argv) > 1 and sys.argv[1] == '--selftest':
    sys.exit(_selftest(sys.argv[2:]))

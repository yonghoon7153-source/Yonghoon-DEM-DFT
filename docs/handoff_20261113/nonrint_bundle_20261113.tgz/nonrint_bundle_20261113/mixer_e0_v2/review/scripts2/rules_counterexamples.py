"""재리뷰 (Codex 아님 · 11-12) — 고친 등록 초안 (f43af6323a6b) 의 새 결과 전 규칙에 손 반례.
계산 · 시뮬레이션 없음: 작은 합성 바이트 · 숫자 시각만. 리포 · ibb 에 아무것도 하지 않는다.
판정 말: '막힘' = 규칙이 결함을 거부 / 정상을 통과 (의도대로) · '지나감' = 결함이 통과 (거짓 통과) · '거짓 거부' = 정상 런이 떨어짐.
규칙 문장은 등록 초안 7-3 (C3 · C5 · C6 · C7) · 6 절 (S5 · S8) · 6-1 · 9 절 끝 · 12 절 (W9 · W10) 의 글자를 그대로 옮겨 구현했다.
글자가 두 가지로 읽히는 곳은 두 읽기를 다 돌린다.
"""
import json, re

def out(tag, verdict, why):
    print('%-38s %-10s %s' % (tag, verdict, why))

# ---------------------------------------------------------------- C3 장마다 완결
HEAD = (b'ITEM: TIMESTEP\n1121000\nITEM: NUMBER OF ATOMS\n%d\nITEM: BOX BOUNDS pp pp pp\n'
        b'-0.0126 0.0126\n-0.0126 0.0126\n0 0.0050\nITEM: ATOMS id type x y z vx vy vz fx fy fz radius\n')
def atom(i, fmt):
    v = [0.0012345678901234567*i, -0.0098765432109876543, 0.0021212121212121213, 1e-3, -2e-3, 3e-4, 1e-9, -2e-9, 3e-9, 2.6e-5]
    return (('%d %d ' % (i, 1)) + ' '.join(fmt % x for x in v) + ' \n').encode()   # dump custom: 칸 뒤 공백 · 줄 끝 개행
def frame(n, fmt='%.17g'):
    return (HEAD % n) + b''.join(atom(i, fmt) for i in range(1, n+1))
def c3(raw, mode):
    # 등록 C3: 줄 수 = 9 + 머리 원자 수 · 끝 줄 = 12 칸.  '줄 수' 를 mode 로 읽는다.
    lines = raw.split(b'\n') if raw else []
    try:
        n = int(lines[3])
    except (IndexError, ValueError):
        return False
    count = raw.count(b'\n') if mode == 'newline(wc -l)' else len(raw.splitlines())
    last = raw.splitlines()[-1].split() if raw.splitlines() else []
    return count == 9 + n and len(last) == 12
good = frame(3)
cut_line = good[:good.rfind(b'\n', 0, len(good)-1)+1]                    # 마지막 원자 줄 통째 없음
cut_tok = good[:-12]                                                      # 마지막 줄 끝 칸 (radius) 안에서 잘림 · 끝 개행 없음
print('== C3 (장마다 완결)')
for name, raw, want in (('정상 장', good, True), ('1 B', good[:1], False), ('머리만', HEAD % 3, False),
                        ('줄 경계 잘림', cut_line, False), ('끝 칸 안 잘림 (개행 없음)', cut_tok, False),
                        ('%g 완결 장', frame(3, '%g'), True)):
    for mode in ('newline(wc -l)', 'splitlines'):
        got = c3(raw, mode)
        v = ('막힘' if got == want else ('지나감' if got else '거짓 거부'))
        out('C3 %s · %s' % (name, mode), v, 'C3=%s (기대 %s) · 끝 줄 칸 %d' % (got, want, len(raw.splitlines()[-1].split()) if raw.splitlines() else 0))
print('   주: 끝 칸 안 잘림의 끝 줄 =', cut_tok.splitlines()[-1].split()[-1].decode(), '(12 칸 그대로)')

# ---------------------------------------------------------------- C7 정밀도 꼴
def sig_digits(tok):
    m = re.fullmatch(r'[-+]?(\d*)\.?(\d*)(?:[eE][-+]?\d+)?', tok)
    d = (m.group(1) + m.group(2)).lstrip('0')
    return len(d)
def naive_digits(tok):           # 글자로 센 숫자 수 (앞 0 · 지수 포함)
    return sum(ch.isdigit() for ch in tok.split('e')[0].split('E')[0])
def frac_digits(tok):            # 소수점 뒤 숫자 수
    t = tok.split('e')[0].split('E')[0]
    return len(t.split('.')[1]) if '.' in t else 0
def c7(raw, counter):
    xs = [l.split()[2:5] for l in raw.splitlines()[9:]]
    return sum(1 for row in xs for t in row if counter(t.decode()) >= 7) >= 1
print('== C7 (t0 x·y·z 유효숫자 ≥ 7 인 값 ≥ 1)')
unit = (HEAD % 3) + b''.join((('%d 1 ' % i) + ' '.join('%g' % x for x in (1.2345678*i, 2.3456789, 3.4567891) + (0,)*7) + ' \n').encode() for i in range(1, 4))
for name, raw, want in (('%.17g 장 (덱 좌표 0.00x m)', good, True), ('%g 장 (덱 좌표 0.00x m)', frame(3, '%g'), False),
                        ('%g 장 (O(1) 좌표 = 시험 fixture 꼴)', unit, False)):
    for cname, f in (('유효숫자', sig_digits), ('숫자 글자 수', naive_digits), ('소수점 뒤 수', frac_digits)):
        got = c7(raw, f)
        v = ('막힘' if got == want else ('지나감' if got else '거짓 거부'))
        out('C7 %s · %s' % (name, cname), v, 'C7=%s (기대 %s)' % (got, want))
print('   주: %g 의 덱 좌표 한 값 =', '%g' % 0.0012345678901234567, '→ 유효숫자', sig_digits('%g' % 0.0012345678901234567),
      '· 숫자 글자', naive_digits('%g' % 0.0012345678901234567), '· 소수점 뒤', frac_digits('%g' % 0.0012345678901234567))

# ---------------------------------------------------------------- C5 수정 시각 창
RUN = ('post/mix_1000.liggghts', 'post/mix_1121000.liggghts', 'restart/a.bin', 'restart/b.bin', 'restart/settled.bin',
       'log.liggghts', 'simulator.stdout', 'simulator.stderr', 'job_end.json')
PRE = ('in.mixer', 'deck_meta.json', 'Drum.stl', 'Front.stl', 'Back.stl', 'submission.claim.json', 'submission.receipt.json')
def c5(mt, start, end_ref, t9=None, total=None, pre_upper=False):
    if any(t > end_ref + 60 for t in mt.values()):
        return False, 'mtime > End+60'
    if any(mt[f] < start - 60 for f in RUN):
        return False, 'run file < start-60'
    if pre_upper and any(mt[f] > start + 60 for f in PRE):
        return False, 'pre-placed mtime > start+60 (제안 규칙)'
    if t9 is None:
        return None, 'T9 watch 줄 없음 → "합 = T9 값" 판정 불가 (등록 문장에 처리 없음)'
    return (t9 == total), 'sum vs T9'
start, end = 1_000_000.0, 1_000_000.0 + 4.9*3600
base = {f: start - 3600 for f in PRE}
base.update({f: start + 11 for f in RUN}); base.update({'post/mix_1121000.liggghts': end - 3, 'restart/settled.bin': end - 2,
             'log.liggghts': end - 1, 'simulator.stdout': end - 1, 'simulator.stderr': end - 1, 'job_end.json': end - 0.5, 'job_start.json': start})
print('== C5 (수정 시각 창 · 아래 끝 = 런이 쓴 것만)')
ok, why = c5(base, start, end, t9=100, total=100); out('C5 정상 런', '막힘' if ok else '거짓 거부', why)
edit = dict(base); edit['in.mixer'] = start + 3600       # 런 중 덱 고침 → 되돌림 (바이트 = 봉인 · 시각은 남음)
ok, why = c5(edit, start, end, t9=100, total=100);   out('C5 런 중 덱 고침→되돌림 (등록 글자)', '지나감' if ok else '막힘', why + ' · 관측기 덱 바이트 대조도 통과 (바이트 같음)')
ok, why = c5(edit, start, end, t9=100, total=100, pre_upper=True); out('C5 같은 반례 · 제안 (놓인 파일 ≤ start+60)', '막힘' if not ok else '지나감', why)
skew = {f: (t + 90 if f in RUN + ('job_start.json',) else t) for f, t in base.items()}   # 파일 시계가 sacct 시계보다 90 초 앞 [추정 꼴]
ok, why = c5(skew, start + 90, end, t9=100, total=100); out('C5 시계 차 90 초 (End=sacct)', '거짓 거부' if not ok else '막힘', why)
ok, why = c5(skew, start + 90, end + 90, t9=100, total=100); out('C5 같은 반례 · 위 끝 = job_end end_unix', '막힘' if ok else '거짓 거부', why + ' (같은 시계)')
ok, why = c5(base, start, end, t9=None, total=100); out('C5 T9 watch 줄 빠짐', '거짓 거부?' if ok is None else str(ok), why)
same = {f: end + 7200 for f in base}                    # mtime 안 지킨 사본에서 목록 = 모두 같은 시각
ok, why = c5(same, start, end, t9=100, total=100); out('C5 같은 시각 파일 (mtime 안 지킨 사본)', '거짓 거부' if not ok else '지나감', why)

# ---------------------------------------------------------------- S5 · 9 절 끝 '진행 불명'
print('== S5 (R 동안 · post 수정 시각 최댓값 30 분) · 9 절 끝')
def frames(stall_at=None, stall_len=0.0, trickle=False, dt=13.0, n=1121):
    t, out_ = start + 11.0, []
    for k in range(1, n+1):
        if stall_at is not None and k == stall_at:
            if trickle:            # 한 장을 아주 천천히 씀: 5 분마다 조각 → mtime 갱신 · 새 장 없음
                for j in range(1, int(stall_len // 300) + 1):
                    out_.append((k, t + 300*j, 'partial'))
            t += stall_len
        out_.append((k, t, 'done')); t += dt
    return out_
def s5_new(fr, rows, state='R'):
    fired = []
    for w in rows:
        seen = [m for (_, m, _) in fr if m <= w]
        ref = max(seen) if seen else start
        if state == 'R' and w - ref > 1800:
            fired.append(w)
    return fired
def s5_step(fr, rows):
    fired = []
    for w in rows:
        done = [(k, m) for (k, m, s) in fr if s == 'done' and m <= w]
        last_new = max((m for k, m in done), default=start)
        if w - last_new > 1800:
            fired.append(w)
    return fired
fr = frames(stall_at=500, stall_len=3600, trickle=True)
r_end = max(m for (_, m, _) in fr) + 3.0                     # R 구간 = 마지막 장 + 3 초 (그 뒤 줄은 R 아님 · S5 안 셈)
rows = [start + 600*i for i in range(1, 60) if start + 600*i <= r_end]
out('S5 천천히 써지는 한 장 (60 분 · 새 장 0)', '지나감' if not s5_new(fr, rows) else '막힘', '수정 시각 최댓값 = %d 회 울림 · "최대 step 숫자" 로 재면 %d 회' % (len(s5_new(fr, rows)), len(s5_step(fr, rows))))
hits, n_ph = 0, 0
for ph in range(0, 600, 5):
    fr = frames(stall_at=500, stall_len=35*60)
    r_end = max(m for (_, m, _) in fr) + 3.0
    rows = [start + ph + 600*i for i in range(0, 60) if start + ph + 600*i <= r_end]
    n_ph += 1; hits += bool(s5_new(fr, rows))
print('   35 분 멈춤 뒤 회복: watch 가 살아 있으면 S5 기록이 남는 위상 = %d/%d (%.0f %%) · watch 가 UNKNOWN 이면 9 절 끝 ② 사후 규칙 = 늘 기술 실패' % (hits, n_ph, 100.0*hits/n_ph))
out('9 절 끝 · 35 분 멈춤 (watch 살아 있음)', '지나감 (절반)', '분류가 watch 위상 · 가용성에 달림 → 사후 규칙을 모든 런에')

# ---------------------------------------------------------------- C6 ① 관측기 JSON 자리
print('== C6 (관측기 JSON 자리)')
obs = {'status': 'OK', 'provenance': {'completion_log': {'loop_procs': [20, 20, 20, 20]}, 'module_sha256': {'mixer_precal_observe': {'path': '<LOCAL>', 'sha256': 'bb2f…'}}}}
lit = obs.get('completion_log', {}).get('loop_procs')
real = obs['provenance']['completion_log']['loop_procs']
out('C6 ① 글자대로 completion_log.loop_procs', '거짓 거부' if lit is None else '막힘', '최상위 키 없음 · 실제 = provenance.completion_log.loop_procs (관측기 L424 · L550)')
out('C6 ① 손으로 쓴 "on 20 procs"', '지나감', '자기 보고 · 등록 한정에 이미 있음 (7-3 셋째 점)')
out('C6 ① NP 1 · MPI 짝 어긋남 (on 1 procs)', '막힘', 'loop_procs [1,1,1,1] ≠ [20]*4')

# ---------------------------------------------------------------- 6-1 P2 · P6
print('== 6-1 (live_preflight)')
now = start; observed = now - 30; squeue_captured = now - 1200
age_ok = 0 <= now - observed <= 300                     # 가드 L125–126 그대로
out('6-1 새 date + 20 분 묵은 squeue', '지나감' if age_ok else '막힘', '가드는 observed_unix 만 본다 · P6 사람 대조 = "수집 ↔ JSON 이음" — 원 출력 시각 ↔ observed_unix 대조 문장 없음')
out('6-1 같은 반례 · 제안 (원 출력 시각 전부 observed_unix ±10 초)', '막힘' if abs(squeue_captured - observed) > 10 else '지나감', '한 스크립트 수집 + 파일마다 captured_unix')

# ---------------------------------------------------------------- W10 막는 줄
print('== W10 (공유 자산 리뷰 범위)')
assets = {'observer bb2f…': ['internal-E0', 'codex@bb2f…'], 'reseal bundle': ['internal-E0', 'codex@…'], 'watch block': []}
literal = any(r == ['internal-E0'] for r in assets.values())       # "리뷰 기록이 '내부 · E0 한정' 뿐이면 = 아니오"
closed = all(any(x.startswith('codex@') for x in r) for r in assets.values())
out('W10 기록 없는 자산 (watch 블록)', '지나감' if not literal else '막힘', '글자 = 아니오 조건 거짓 → W10 예 · 닫힌 꼴 ("각 자산에 Codex GO") = %s' % ('예' if closed else '아니오'))

# ---------------------------------------------------------------- S8 기준 상태
print('== S8 (할당 초과 표지)')
import sys
q4 = json.load(open(sys.argv[1], encoding='utf-8'))['q4']['user'] if len(sys.argv) > 1 else []
star = any('*' in l for l in q4)
cols = [l.split() for l in q4 if l.strip().startswith('/')]
print('   11-12 q4 -u 줄 수 %d · "*" 표지 %s · 칸 = kbytes quota limit grace files quota limit grace → 한도 칸 %s' % (
      len(q4), '있음' if star else '없음', [c[2:4] + c[6:8] for c in cols]))
out('S8 기준 상태 (발사 전)', '막힘' if not star else '거짓 거부', '시작 때 표지 없음 → 즉시 울리지 않음')
out('S8 표지 다리 (한도 칸 0 0 · 기본 설정)', '지나감?', '보이는 한도가 0 이면 "*" 가 뜰 자리가 없을 수 있다 [추정] → 실효 감시 = S6 ① (파일 열기 실패 ERROR) · 사후 C3 (잘림)')

# ---------------------------------------------------------------- S6 (① 셋 파일 줄 첫머리 · ② thermo 행 안 비유한)
print('== S6')
ROW = re.compile(r'[ \t]*([0-9]+)[ \t]+([0-9]+)[ \t]+(\S+)[ \t]+(\S+)[ \t]+(\S+)[ \t]*$')   # 등록 6 절: 첫 칸 정수 step · 다섯 칸
def s6(log_lines, stdout_lines, stderr_lines):
    e1 = sum(1 for L in (log_lines, stdout_lines, stderr_lines) for l in L if l.startswith('ERROR'))
    rows, active = [], False
    for l in log_lines:
        if l.split()[:5] == ['Step', 'Atoms', 'KinEng', 'rke', 'Volume']:
            active = True; continue
        if l.startswith('Loop time of'):
            active = False; continue
        if active and ROW.match(l):
            rows.append(l)
    e2 = sum(1 for r in rows if re.search(r'nan|inf', r, re.I))
    return e1, e2
base_log = ['LIGGGHTS (Version ...)', '#   (`ERROR: youngsModulus <= 1e9 required for SI units`, ...).', 'Step Atoms KinEng rke Volume',
            '1 100000 0 0 1e-06', 'INFO: Particle insertion ins: inserted 100000 particle templates (mass 1e-3) at step 1',
            ' - a total of 100000 particle templates (mass 1e-3) inserted so far.', '5000 100000 1.5e-08 0 1e-06', 'Loop time of 1 on 20 procs for 1 steps with 100000 atoms, ...']
for name, log, so, se, want in (('정상 (메아리 · INFO · -)', base_log, [], [], (0, 0)),
                                 ('thermo 행 -nan', base_log[:6] + ['10000 100000 -nan 0 1e-06'] + base_log[6:], [], [], (0, 1)),
                                 ('0 아닌 rank 오류 (stderr)', base_log, [], ['ERROR on proc 7: Cannot open dump file (../dump.cpp:123)'], (1, 0))):
    got = s6(log, so, se)
    out('S6 ' + name, '막힘' if got == want else '틀림', 'ERROR 줄 %d · 비유한 행 %d (기대 %s)' % (got[0], got[1], want))

# ---------------------------------------------------------------- 6-1 P1 · P5 (가드 산술 줄을 그대로 옮김 · 가드 실행 아님)
print('== 6-1 P1 · P5 (가드 L53–54 · L83–84 · L123–134 산술)')
def guard(policy_max, approved, running, reserved_slots, reserved_cpus, live_extra_keys=()):
    if not (1 <= policy_max <= 2 and approved == policy_max): return 'HOLD concurrency differs'
    if not (0 <= running < approved <= 2): return 'HOLD concurrency'
    if not (reserved_cpus + 20 <= 60): return 'HOLD aggregate CPU cap'
    if not (reserved_slots + running < policy_max): return 'HOLD campaign slots reserved'
    if not (reserved_cpus + 20*(reserved_slots+1) <= 60): return 'HOLD campaign CPU reservations'
    return 'SUBMIT'          # 덧칸 (raw_outputs · user_quota_limit) 은 가드가 읽지 않는다 (L123–134 = 정해진 키만)
out('6-1 P1 E0 첫 제출 (1·1 · 돌고 있음 0)', '막힘' if guard(1, 1, 0, 0, 0) == 'SUBMIT' else '거짓 거부', guard(1, 1, 0, 0, 0))
out('6-1 P1 E0 돌 때 둘째 case (1·1)', '막힘' if guard(1, 1, 1, 1, 20) != 'SUBMIT' else '지나감', guard(1, 1, 1, 1, 20))
out('6-1 옛 꼴 2·2 · E0 끝 · 예약 남음 · 둘째 case', '지나감' if guard(2, 2, 0, 1, 0) == 'SUBMIT' else '막힘', guard(2, 2, 0, 1, 0) + ' (둘째 자리 열림 · 남는 문 = MAP_CASE_GO · 손으로 쓰는 qualification_accepted)')
out('6-1 P1 1·1 · 같은 상태', '막힘' if guard(1, 1, 0, 1, 0) != 'SUBMIT' else '지나감', guard(1, 1, 0, 1, 0) + ' (검토된 예약 해제 전까지 닫힘)')
out('6-1 P5 덧칸 (raw_outputs · user_quota_limit)', '막힘', '가드 동작 무변경 → 정상 제출을 떨어뜨리지 않음 [판독]')

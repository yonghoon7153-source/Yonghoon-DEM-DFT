import hashlib,json,zipfile,pathlib,sys
ROOT=pathlib.Path(__file__).resolve().parent
ZIP=ROOT/'input/codex_mixer_precal_first8_20261104_189930cc68b6.zip'
if not ZIP.is_file():
    ZIP=pathlib.Path(r'C:/Users/Administrator/Downloads/codex_mixer_precal_first8_20261104_189930cc68b6.zip')
z=zipfile.ZipFile(ZIP)
names=z.namelist()
assert len(set(n.casefold() for n in names))==len(names)
for n in names:
    p=pathlib.PurePosixPath(n)
    assert not p.is_absolute() and '..' not in p.parts and ':' not in n and '\\' not in n
    assert (z.getinfo(n).external_attr>>16)&0o170000 != 0o120000
assert z.testzip() is None
manifest=json.loads(z.read('SNAPSHOT_MANIFEST.json'))
pin=z.read('PIN.txt').decode().strip()
assert manifest['pin']==pin=='189930cc68b6e58beb6b4546d80353dc03852195'
for e in manifest['entries']:
    b=z.read(e['path']);assert len(b)==e['bytes']
    assert hashlib.sha256(b).hexdigest()==e['sha256']
    assert hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()==e['git_blob']
listed=[]
for line in z.read('PACKAGE_SHA256SUMS').decode().splitlines():
    h,n=line.split(None,1);n=n.lstrip('*'); listed.append(n)
    assert hashlib.sha256(z.read(n)).hexdigest()==h
assert set(listed)==set(names)-{'PACKAGE_SHA256SUMS'}
assert z.read('REQUEST.md')==z.read('docs/reviews/codex_mixer_precal_first8_review_request_20261104.md')
remote=json.loads((ROOT/'remote_metadata.json').read_text())
idx={e['path']:e for e in remote['items']}
for e in manifest['entries']:
    assert e['path'] in idx,e['path']
    assert idx[e['path']]['sha']==e['git_blob'] and idx[e['path']]['size']==e['bytes'],e['path']
result={'pin':pin,'zip_sha256':hashlib.sha256(ZIP.read_bytes()).hexdigest(),'zip_bytes':ZIP.stat().st_size,'manifest_entries':len(manifest['entries']),'package_entries':len(listed),'checks':'PASS','remote_blob_and_size_match':len(manifest['entries'])}
(ROOT/'bundle_validation.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))

# ordinary startup

#!/usr/bin/env bash
# 이 잡의 POTCAR 를 만든다. PBE PAW 5.4 세트 경로를 PP 로 준다.
#   PP=/path/to/potpaw_PBE.54 bash POTCAR_ASSEMBLE.sh
# ⚠ 종 순서는 이 잡 POSCAR 전용이다 — 다른 잡에 복사하지 말 것.
#   (하나를 돌려 쓰면 에러 없이 **다른 계**를 계산합니다.)
set -e
ORDER="Li_sv Ni_pv O C F"
SPECIES="Li Ni O C F"
: "${PP:?PP 를 지정하세요 (PBE PAW 5.4 세트 루트)}"
rm -f POTCAR POTCAR_PROVENANCE.json
srcsha=""
for v in $ORDER; do
  f="$PP/$v/POTCAR"
  [ -f "$f" ] || { echo "⛔ 없음: $f"; exit 1; }
  srcsha="$srcsha $v:$(sha256sum "$f" | cut -d" " -f1)"
  cat "$f" >> POTCAR
done
# ① 개수
n=$(grep -ac TITEL POTCAR)
[ "$n" = 5 ] || { echo "⛔ TITEL 5개여야 하는데 $n개"; exit 1; }
# ② 자리별 variant — 토큰 전체 비교 (Ni 가 Ni_pv 에 오탐되지 않게)
i=0
for v in $ORDER; do
  i=$((i+1))
  got=$(grep -a TITEL POTCAR | sed -n "${i}p" | awk '{print $4}')
  fun=$(grep -a TITEL POTCAR | sed -n "${i}p" | awk '{print $3}')
  [ "$got" = "$v" ] || { echo "⛔ ${i}번째 TITEL 이 $got — $v 여야 합니다"; exit 1; }
  [ "$fun" = "PAW_PBE" ] || { echo "⛔ ${i}번째가 $fun — PAW_PBE 여야 합니다"; exit 1; }
done
# ③ trusted hash allowlist 대조 (회신 AA P0-2)
#    variant 이름·PAW_PBE·잡 간 일관성은 "전부 같은 잘못된 PP 트리" 를 못 막는다.
#    정본 SHA 는 라이선스상 우리가 못 싣는다 → **외주처 site-local 목록**을 받는다.
if [ -n "${POTCAR_ALLOWLIST:-}" ]; then
  [ -f "$POTCAR_ALLOWLIST" ] || { echo "⛔ allowlist 파일 없음: $POTCAR_ALLOWLIST"; exit 1; }
  for t in $srcsha; do
    v="${t%%:*}"; h="${t#*:}"
    grep -q "$h" "$POTCAR_ALLOWLIST" || {
      echo "⛔ $v 의 SHA256 이 allowlist 에 없습니다: $h"; exit 1; }
  done
  echo "  ✔ allowlist 대조 통과 ($POTCAR_ALLOWLIST)"
elif [ "${POTCAR_ALLOWLIST_WAIVED:-0}" = "1" ]; then
  echo "  ⚠ allowlist 미대조 — 면제 선언됨. 반송물에 기록됩니다."
else
  echo "⛔ POTCAR_ALLOWLIST 가 지정되지 않았습니다."
  echo "   신뢰하는 PBE.54 세트의 sha256 목록을 **한 번** 만들어 전 잡에 같은"
  echo "   파일을 쓰세요 (잡마다 새로 만들면 아무것도 검증하지 않습니다):"
  echo "     for v in \$(ls \$PP); do sha256sum \$PP/\$v/POTCAR; done > site_allow.txt"
  echo "     POTCAR_ALLOWLIST=/abs/site_allow.txt bash POTCAR_ASSEMBLE.sh"
  echo "   대조 없이 진행해야 하면 POTCAR_ALLOWLIST_WAIVED=1 (반송물에 남습니다)."
  exit 1
fi
# ④ provenance — 이 파일을 결과와 **함께 반송**해 주세요
python3 - "$srcsha" <<'PY' > POTCAR_PROVENANCE.json
import hashlib, json, sys, os as _os
src = dict(t.split(":", 1) for t in sys.argv[1].split())
titel = [l.strip() for l in open("POTCAR", errors="ignore") if "TITEL" in l]
print(json.dumps({"schema": "potcar_provenance/v1",
                  "species_order": "Li Ni O C F".split(),
                  "expected_variants": "Li_sv Ni_pv O C F".split(),
                  "titel_lines": titel, "source_sha256": src,
                  "allowlist": _os.environ.get("POTCAR_ALLOWLIST"),
                  "allowlist_waived":
                      _os.environ.get("POTCAR_ALLOWLIST_WAIVED") == "1",
                  "assembled_sha256": hashlib.sha256(
                      open("POTCAR","rb").read()).hexdigest()},
                 indent=1, ensure_ascii=False))
PY
grep -a TITEL POTCAR
echo "✔ 조립 완료 — 종 순서 Li Ni O C F · variant·순서·PAW_PBE 확인"
echo "  → POTCAR_PROVENANCE.json (결과와 함께 반송해 주세요)"

"""Copy exactly the IN inventory's 86 paths (12 dependencies + 73 launch + 1 test) from a tree
into a NEW folder (the verifier's --snapshot input).  Scratch dry run only.
Usage: python3 -I -B make_snapshot.py <tree_root> <source_inventory.json> <new_dir> [--override=<path>=<file> ...]
--override takes that snapshot path's bytes from another file (used once: the pre-Q5 observer)."""
import json, sys
from pathlib import Path
tree, inv, out = Path(sys.argv[1]), Path(sys.argv[2]), Path(sys.argv[3])
over = {}
for a in sys.argv[4:]:
    assert a.startswith('--override='), a
    k, v = a[len('--override='):].split('=', 1)
    over[k] = Path(v)
assert not out.exists(), 'snapshot folder must be new'
inventory = json.loads(inv.read_bytes())
rows = inventory['source_dependencies'] + inventory['launch_snapshot'] + [inventory['preparation_test']]
assert set(over) <= {r['path'] for r in rows}, 'override outside inventory'
out.mkdir()
for r in rows:
    dst = out / r['path']
    dst.parent.mkdir(parents=True, exist_ok=True)
    dst.write_bytes((over.get(r['path']) or (tree / r['path'])).read_bytes())
print('snapshot_files', len(rows), 'overrides', sorted(over))

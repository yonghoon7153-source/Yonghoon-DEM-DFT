#!/usr/bin/env python3
"""
Generate comparison plots from multiple DEM analysis cases.

Usage:
    python generate_comparison_plots.py \
        -i case1/full_metrics.json case2/full_metrics.json \
        -n "post_real_7" "post_real_8" \
        -o ./figures \
        -p porosity am_se_interface se_se_tradeoff se_se_total \
           percolation_tortuosity ionic_active coverage four_panel
"""

import argparse
import csv
import itertools
import json
import os
import sys

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

_THIS_DIR = os.path.dirname(os.path.abspath(__file__))
if _THIS_DIR not in sys.path:
    sys.path.insert(0, _THIS_DIR)
import se_material  # single source of truth for σ_grain (SE_SG) + its temperature convention
from metrics_json import metric_number  # 옛 full_metrics 의 숫자 문자열 ('412') 도 숫자로 (LHS-24 (a))
from metrics_json import stress_metric_value, stress_cv_status, stress_cv_reason, STRESS_CV_COMPUTED  # LHS-33 옛 σ_VM 열 상태


def _register_cjk_fallback():
    """Register a Korean-capable font so Hangul in titles/labels renders instead
    of tofu boxes.  Searches Linux, WSL-mounted Windows, and macOS locations and
    sets it as the PRIMARY sans-serif (Korean fonts carry Latin glyphs too, so
    the look stays clean and Hangul is guaranteed regardless of mpl fallback)."""
    from matplotlib import font_manager as _fm
    import os as _os, glob as _glob
    candidates = [
        '/usr/share/fonts/truetype/nanum/NanumGothic.ttf',
        '/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc',
        '/usr/share/fonts/opentype/noto/NotoSansCJKkr-Regular.otf',
        '/usr/share/fonts/truetype/nanum/NanumBarunGothic.ttf',
        '/mnt/c/Windows/Fonts/malgun.ttf',     # WSL → Windows Malgun Gothic
        '/mnt/c/Windows/Fonts/malgunbd.ttf',
        '/mnt/c/Windows/Fonts/gulim.ttc',
        '/mnt/c/Windows/Fonts/batang.ttc',
        'C:/Windows/Fonts/malgun.ttf',
        '/Library/Fonts/AppleGothic.ttf',
        '/System/Library/Fonts/AppleSDGothicNeo.ttc',
        '/usr/share/fonts/truetype/wqy/wqy-zenhei.ttc',
    ]
    for pat in ('/usr/share/fonts/**/*Nanum*.ttf',
                '/usr/share/fonts/**/NotoSansCJK*',
                '/usr/share/fonts/**/NotoSansKR*'):
        candidates += sorted(_glob.glob(pat, recursive=True))
    for path in candidates:
        if path and _os.path.exists(path):
            try:
                _fm.fontManager.addfont(path)
                name = _fm.FontProperties(fname=path).get_name()
                sl = [f for f in matplotlib.rcParams['font.sans-serif'] if f != name]
                matplotlib.rcParams['font.sans-serif'] = [name] + sl
                matplotlib.rcParams['font.family'] = 'sans-serif'
                matplotlib.rcParams['axes.unicode_minus'] = False
                return name
            except Exception:
                continue
    return None


_register_cjk_fallback()

try:                       # grade-axis values (Q/ASR/τ_Laplace/…) for param compare
    import grade_engine as _grade_engine
except Exception:
    _grade_engine = None


# ─── Color palette ────────────────────────────────────────────────────────────
BLUE = "#4472C4"
RED = "#C00000"
GREEN = "#548235"
LIGHT_GREEN = "#A9D18E"
BLACK = "#333333"
GRAY = "#888888"

DPI = 150
FIG_SINGLE = (7, 4.5)
FIG_FOUR = (14, 10)
GROUP_COLORS = ['#6c8cff', '#ff6b6b', '#51cf66', '#ffd43b', '#cc5de8', '#ff922b']


# ─── Helpers ──────────────────────────────────────────────────────────────────

_GROUP_INFO = None  # Set by main()
_Y_MAX_SIGMA = None  # Override y-axis max (mS/cm) for multiscale σ plots; set by main()
_Y_MAX_SIGMA_E = None  # Override y-axis max (mS/cm) specifically for σ_e plots (set by main via --y-max-sigma-e / webapp σ_AM(e) input)
_GLOBAL_RGB = None  # (b, ln_k) from global fit across all plot groups
_GLOBAL_C_ION = None  # Fitted C for ionic scaling law (from global/ionic_scaling_fit)
_GLOBAL_FORMX_R2 = None  # (r2, loocv) from FORM X fit
_GLOBAL_IONIC_SIGMOID = None  # (C_thick, C_thin, tau_c, k) for sigmoid C(τ)
_GLOBAL_IONIC_POLY3 = None  # (a0, a1, a2, a3) for poly3 part of v9 BLEND
_GLOBAL_PS_SIGMOID = None   # v19: (k_pf, pc_pf, beta1, beta2, w_pf_mean, pf_t_mean)
_ALL_DATA = None  # all_data for _apply_style auto-detect
_REAL_NAMES = None  # saved case names (args.names), aligned with _ALL_DATA
_FOCUS_CASES = set()  # subset of saved names to show in the "1-1" focus parity
_FOCUS_LABEL = ""     # group name(s) of fully-selected groups, shown on the 1-1 plot
_FIT_CORPUS = []      # full-corpus metrics dicts for global (n=all) fit stats

# Generic parameter-comparison selections (set by main() from CLI args).
_PARAM_X = None       # X-axis metric key (scatter)
_PARAM_Y = None       # Y-axis metric key (scatter)
_PARAM_LIST = None    # list of metric keys (bar / correlation)
_PARAM_NORM = False   # normalize each param to its max (bar)

# Disk cache of the fitted v29 + v32 params. Webapp spawns a separate
# subprocess per plot set, so module globals do not survive across
# calls. Writing the fitted values here lets plot_multiscale_sigma (run
# in a different subprocess) reuse the same v29 that the parity plot
# produced. Keyed by the sorted list of case names so a different case
# selection invalidates stale entries automatically.
import hashlib as _hashlib, tempfile as _tempfile
_V29_CACHE_PATH = os.path.join(_tempfile.gettempdir(), 'dem_v29_v32_cache.json')


def _cases_fingerprint(names):
    """Stable hash of the sorted case-name tuple."""
    return _hashlib.md5(
        ','.join(sorted(str(n) for n in names)).encode('utf-8')
    ).hexdigest()


def _write_v29_cache(names, sigmoid, poly3, ps_sigmoid, v32_gammas=None):
    import json as _json
    name_list = sorted(str(n) for n in names)
    payload = {
        'fingerprint': _cases_fingerprint(names),
        'case_names': name_list,
        'sigmoid':  list(sigmoid),
        'poly3':    list(poly3),
        'ps_sigmoid': list(ps_sigmoid),
        'v32_gammas': dict(v32_gammas) if v32_gammas else None,
    }
    try:
        with open(_V29_CACHE_PATH, 'w') as f:
            _json.dump(payload, f)
        print(f"  [v29 cache] wrote {_V29_CACHE_PATH}  fp={payload['fingerprint'][:8]}  n={len(name_list)}")
    except Exception as e:
        print(f"  [v29 cache] write failed: {e}")


def _load_v29_cache(names):
    """Return (sigmoid, poly3, ps_sigmoid, v32_gammas) if cache covers current
    case list (exact match OR current names are a subset of cached names),
    else None. Subset match handles the webapp's multi-POST flow where the
    parity plot fits on ALL groups and each per-group POST requests only
    its own subset — they should still use the common fitted params."""
    import json as _json
    if not os.path.exists(_V29_CACHE_PATH):
        return None
    try:
        p = _json.load(open(_V29_CACHE_PATH))
    except Exception:
        return None
    cached_names = set(p.get('case_names', []))
    cur = set(str(n) for n in names)
    exact = p.get('fingerprint') == _cases_fingerprint(names)
    subset = bool(cached_names) and cur.issubset(cached_names)
    if not (exact or subset):
        print(f"  [v29 cache] miss (cur={len(cur)} cases, cached={len(cached_names)}; "
              f"not a subset)")
        return None
    tag = 'exact' if exact else f'subset {len(cur)}⊆{len(cached_names)}'
    print(f"  [v29 cache] hit [{tag}]  fp={p.get('fingerprint','?')[:8]}")
    return (tuple(p.get('sigmoid', [])),
            tuple(p.get('poly3', [])),
            tuple(p.get('ps_sigmoid', [])),
            p.get('v32_gammas'))

def _apply_style(ax, ylabel, names, data_list=None):
    """Apply common academic style with group separators.
    Auto-detect monomodal: if all P:S are same, use AM:SE as x-axis."""
    n = len(names)
    ax.set_xticks(range(n))

    # Check if all names (P:S) are the same → monomodal, use AM:SE instead
    x_labels = list(names)
    x_title = "P:S Configuration"
    if data_list is None:
        data_list = _ALL_DATA
    unique_names = set(names)
    if len(unique_names) == 1 and data_list is not None:
        # All P:S same → show AM:SE ratio instead
        am_se_labels = []
        for d in data_list:
            am_se = _get(d, 'am_se_ratio', '')
            if not am_se:
                phi_am = _get(d, 'phi_am', 0)
                phi_se = _get(d, 'phi_se', 0)
                if phi_am > 0 and phi_se > 0:
                    # Mass ratio (density-weighted): NCM=4800, LPSCl=2000 kg/m³
                    am_mass = phi_am * 4800
                    se_mass = phi_se * 2000
                    am_pct = round(am_mass / (am_mass + se_mass) * 100)  # nearest 1%
                    am_se = f"{am_pct:.0f}:{100-am_pct:.0f}"
            am_se_labels.append(str(am_se) if am_se else '?')
        if any(l != '?' for l in am_se_labels):
            x_labels = am_se_labels
            x_title = f"AM:SE Ratio (P:S={names[0]})"

    # Adaptive x-axis label sizing
    if n <= 8:
        ax.set_xticklabels(x_labels, fontsize=10)
    elif n <= 15:
        ax.set_xticklabels(x_labels, fontsize=8, rotation=45, ha='right')
    else:
        ax.set_xticklabels(x_labels, fontsize=7, rotation=45, ha='right')

    ax.set_xlabel(x_title, fontsize=10)
    ax.set_ylabel(ylabel, fontsize=11)
    ax.yaxis.grid(True, linestyle="--", linewidth=0.4, color="#CCCCCC", alpha=0.7)
    ax.set_axisbelow(True)
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)
    ax.tick_params(axis='both', labelsize=9 if n <= 8 else 7)

    # Bottom margin for rotated labels
    if n > 8:
        ax.figure.subplots_adjust(bottom=0.18)

    # Add group separators and break lines at boundaries
    if _GROUP_INFO:
        sizes, gnames = _GROUP_INFO
        n_total = sum(sizes)
        # Break existing lines at group boundaries
        boundaries = []
        pos = 0
        for sz in sizes[:-1]:
            pos += sz
            boundaries.append(pos - 0.5)
        # Draw separators and labels
        pos = 0
        for gi, sz in enumerate(sizes):
            if gi > 0:
                ax.axvline(pos - 0.5, color='#888888', linestyle='--', linewidth=1, alpha=0.6)
            mid = pos + sz / 2 - 0.5
            # Staggered group labels: odd groups lower
            if n > 8:
                label_y = -0.26 if gi % 2 == 0 else -0.36
            else:
                label_y = -0.18
            label_fs = 7 if n > 15 else 8 if n > 8 else 9
            ax.text(mid, label_y, gnames[gi], ha='center', va='top',
                    transform=ax.get_xaxis_transform(),
                    fontsize=label_fs, fontweight='bold', color=GROUP_COLORS[gi % len(GROUP_COLORS)],
                    bbox=dict(boxstyle='round,pad=0.2', facecolor='white', edgecolor=GROUP_COLORS[gi % len(GROUP_COLORS)], alpha=0.8))
            pos += sz


def _marker_size(n):
    """Adaptive marker size based on case count."""
    if n <= 8: return 10
    if n <= 15: return 7
    return 5

def _line_width(n):
    """Adaptive line width based on case count."""
    if n <= 8: return 2.5
    if n <= 15: return 2.0
    return 1.5

def _group_break_data(xs, ys):
    """Insert NaN at group boundaries so matplotlib breaks the line."""
    if not _GROUP_INFO:
        return xs, ys
    sizes = _GROUP_INFO[0]
    new_x, new_y = [], []
    pos = 0
    for gi, sz in enumerate(sizes):
        if gi > 0:
            new_x.append(float('nan'))
            new_y.append(float('nan'))
        for i in range(pos, pos + sz):
            if i < len(xs):
                new_x.append(xs[i] if not isinstance(xs, np.ndarray) else float(xs[i]))
                new_y.append(ys[i] if not isinstance(ys, np.ndarray) else float(ys[i]))
        pos += sz
    return new_x, new_y


def _break_lines_at_groups(fig):
    """Insert NaN at group boundaries for all lines in all axes."""
    if not _GROUP_INFO:
        return
    sizes = _GROUP_INFO[0]
    n_total = sum(sizes)
    for ax in fig.get_axes():
        for line in ax.get_lines():
            xd = line.get_xdata()
            yd = line.get_ydata()
            # Only process data lines (not grid, axvline, etc.)
            if len(xd) != n_total or not line.get_marker() or line.get_marker() == 'None':
                continue
            if True:
                new_x, new_y = [], []
                idx = 0
                for gi, sz in enumerate(sizes):
                    if gi > 0:
                        new_x.append(float('nan'))
                        new_y.append(float('nan'))
                    for j in range(sz):
                        if idx < len(xd):
                            new_x.append(float(xd[idx]))
                            new_y.append(float(yd[idx]))
                            idx += 1
                line.set_xdata(new_x)
                line.set_ydata(new_y)


def _save(fig, outdir, fname):
    _break_lines_at_groups(fig)
    fig.tight_layout(pad=1.5)
    fig.subplots_adjust(right=0.85, bottom=0.22 if _GROUP_INFO else 0.15)
    path = os.path.join(outdir, fname)
    fig.savefig(path, dpi=DPI, bbox_inches="tight", facecolor='white', pad_inches=0.2)
    plt.close(fig)
    return path


def _focus_parity(outdir, file_base, sig_act, sig_pred, kept_names,
                  xlabel, ylabel, title):
    """"1-1" view: if _FOCUS_CASES is set, render <file_base>_focus.png with the
    SAME fit (1:1 + ±20% band + axis limits derived from the full set), but only
    the selected sample points.  The global fit is reused unchanged — this only
    filters which points are drawn.  Returns the path or None."""
    if not _FOCUS_CASES:
        return None
    sig_act = np.asarray(sig_act, float); sig_pred = np.asarray(sig_pred, float)
    foc = np.array([(nm in _FOCUS_CASES) for nm in kept_names])
    if not foc.any():
        print(f"  [SKIP] {file_base}_focus: none of the selected samples are in this fit")
        return None
    lim = [min(sig_act.min(), sig_pred.min())*0.8,
           max(sig_act.max(), sig_pred.max())*1.2]
    fig, ax = plt.subplots(figsize=FIG_SINGLE)
    ax.plot(lim, lim, '--', color=GRAY, label='1:1')
    ax.fill_between(lim, [v*0.8 for v in lim], [v*1.2 for v in lim],
                    color=GREEN, alpha=0.12, label='±20%')
    ax.scatter(sig_act[foc], sig_pred[foc], s=75, c=ORANGE,
               edgecolors='black', zorder=4, label='선택 샘플')
    for i in np.where(foc)[0]:
        ax.annotate(str(kept_names[i]), (sig_act[i], sig_pred[i]), fontsize=6,
                    color='#333333', xytext=(4, 3), textcoords='offset points')
    ax.set_xscale('log'); ax.set_yscale('log')
    ax.set_xlim(lim); ax.set_ylim(lim)
    ax.set_xlabel(xlabel); ax.set_ylabel(ylabel)
    if _FOCUS_LABEL:
        title = title + "\n그룹: " + _FOCUS_LABEL
    ax.set_title(title, fontsize=8)
    ax.legend(fontsize=8, loc='upper left'); ax.grid(True, alpha=0.25, which='both')
    return _save(fig, outdir, file_base + "_focus.png")


def _get(data, key, default=0.0):
    v = data.get(key, default)
    if v is None:
        return default
    try:
        return float(v)
    except (ValueError, TypeError):
        return default


def _write_csv(outdir, fname, headers, names, *columns):
    """Write comparison CSV with case names and data columns."""
    import csv
    with open(os.path.join(outdir, fname), 'w', newline='') as f:
        w = csv.writer(f)
        w.writerow(['Case'] + headers)
        for i, name in enumerate(names):
            row = [name] + [c[i] if i < len(c) else '' for c in columns]
            w.writerow(row)


def _resolve_am_se(d):
    """Standard: AM-SE → P:S에 맞게 AM_P-SE or AM_S-SE로 분배."""
    am_p = _get(d, "area_AM_P_SE_total")
    am_s = _get(d, "area_AM_S_SE_total")
    if am_p == 0 and am_s == 0:
        total = _get(d, "area_AM_SE_total") or _get(d, "area_AM전체_SE_total")
        ps = d.get("ps_ratio", "")
        if ps in ("P only", "10:0"):
            return total, 0
        else:
            return 0, total
    return am_p, am_s


def _resolve_coverage(d):
    """Standard: coverage_AM → P/S에 맞게 분배."""
    cov_p = _get(d, "coverage_AM_P_mean")
    cov_s = _get(d, "coverage_AM_S_mean")
    std_p = _get(d, "coverage_AM_P_std")
    std_s = _get(d, "coverage_AM_S_std")
    if cov_p == 0 and cov_s == 0:
        cov = _get(d, "coverage_AM_mean")
        std = _get(d, "coverage_AM_std")
        ps = d.get("ps_ratio", "")
        if ps in ("P only", "10:0"):
            return cov, std, 0, 0
        else:
            return 0, 0, cov, std
    return cov_p, std_p, cov_s, std_s


# ─── Individual plot functions ────────────────────────────────────────────────

def plot_porosity(all_data, names, ax=None):
    standalone = ax is None
    if standalone:
        fig, ax = plt.subplots(figsize=FIG_SINGLE)
    xs = list(range(len(names)))
    ys = [_get(d, "porosity") for d in all_data]
    ax.plot(xs, ys, marker="s", markersize=9, color=BLACK, linewidth=1.5,
            markerfacecolor=BLACK, markeredgecolor=BLACK, zorder=3)
    # y range with padding
    if ys:
        ymin, ymax = min(ys), max(ys)
        pad = max((ymax - ymin) * 0.15, 0.5)
        ax.set_ylim(ymin - pad, ymax + pad)
    _apply_style(ax, "Porosity (%)", names)
    ax.set_title("Porosity", fontsize=13, fontweight="bold", pad=10)
    if standalone:
        return _save(fig, "", "")
    return ax


def _metric_points(all_data, key):
    """[(케이스 번호, 값)] — 값이 없거나 숫자가 아닌 케이스는 **빠진다** (_get 처럼 0 으로 채우지 않는다 ·
    옛 케이스에 없는 porosity_union 이 0 % 로 그려지지 않게 — 웹앱 ②-b · LHS-24 (g))."""
    pts = []
    for i, d in enumerate(all_data):
        v = d.get(key)
        try:
            v = float(v)
        except (TypeError, ValueError):
            continue
        if v == v and abs(v) != float('inf'):
            pts.append((i, v))
    return pts


def _stress_points(all_data, key):
    """옛 σ_VM 열 (stress_cv · stress_ratio_<상>) 의 [(케이스 번호, 값)] — LHS-33 상태를 따른다: stress_cv_status 가 computed 가
    아니면 (무효 · 미정의) 그 케이스는 빠진다 (저장된 0 도) · 옛 세대 (상태 키 없음) 는 숫자 그대로.  _metric_points 와 같은 꼴."""
    pts = []
    for i, d in enumerate(all_data):
        v = stress_metric_value(d, key)
        if v is not None:
            pts.append((i, v))
    return pts


def _stress_cv_feature(d):
    """잔차 상관용 stress_cv — LHS-33: 무효 · 미정의 · 없음 = NaN (옛 판 `_get(d, 'stress_cv', 0)` 의 0 이 상관에 섞였다)."""
    v = stress_metric_value(d, 'stress_cv')
    return float('nan') if v is None else v


def _stress_export_cells(d):
    """그룹 내보내기 CSV 의 옛 σ_VM 칸 — LHS-33: 무효 · 미정의 · 키 없음 = 빈칸 (옛 판 `_get` = 0.0) · status = stress_cv_status
    (옛 세대 = 빈칸) · reason = '상태 — 사유' (computed · 옛 세대 = 빈칸)."""
    out = {}
    for k in ('stress_cv', 'stress_ratio_AM_P', 'stress_ratio_AM_S', 'stress_ratio_SE'):
        v = stress_metric_value(d, k)
        out[k] = '' if v is None else v
    out['status'] = stress_cv_status(d) or ''
    out['reason'] = stress_cv_reason(d) or ''
    return out


def _plot_metric_line(all_data, names, key, ylabel, title, ax=None):
    standalone = ax is None
    if standalone:
        fig, ax = plt.subplots(figsize=FIG_SINGLE)
    pts = _metric_points(all_data, key)
    if pts:
        xs, ys = zip(*pts)
        ax.plot(xs, ys, marker="s", markersize=9, color=BLACK, linewidth=1.5,
                markerfacecolor=BLACK, markeredgecolor=BLACK, zorder=3)
        pad = max((max(ys) - min(ys)) * 0.15, 0.5)
        ax.set_ylim(min(ys) - pad, max(ys) + pad)
    else:
        ax.text(0.5, 0.5, f"{key}: 값이 있는 케이스 없음 (재분석 전 케이스)", transform=ax.transAxes,
                ha="center", va="center", fontsize=10, color="#888")
    _apply_style(ax, ylabel, names)
    ax.set_title(title, fontsize=13, fontweight="bold", pad=10)
    if standalone:
        return _save(fig, "", "")
    return ax


def plot_porosity_union(all_data, names, ax=None):
    return _plot_metric_line(all_data, names, "porosity_union", "ε_union pair-lens (%)",
                             "Porosity ε_union (pair-lens)", ax)


def plot_porosity_union_exact(all_data, names, ax=None):
    return _plot_metric_line(all_data, names, "porosity_union_exact_pct", "ε_union exact, Monte Carlo (%)",
                             "Porosity ε_union exact (MC · handover)", ax)


def plot_overlap_fraction(all_data, names, ax=None):
    return _plot_metric_line(all_data, names, "overlap_fraction_pct", "Overlap (%)",
                             "Overlap fraction (pair-lens)", ax)


def plot_am_se_interface(all_data, names, ax=None):
    standalone = ax is None
    if standalone:
        fig, ax = plt.subplots(figsize=FIG_SINGLE)
    xs = np.arange(len(names))
    width = 0.5

    resolved = [_resolve_am_se(d) for d in all_data]
    am_p = [r[0] for r in resolved]
    am_s = [r[1] for r in resolved]

    ax.bar(xs, am_p, width, label="AM_P-SE", color=GREEN, zorder=3)
    ax.bar(xs, am_s, width, bottom=am_p, label="AM_S-SE",
           color=LIGHT_GREEN, zorder=3)
    ax.legend(fontsize=10, frameon=False)

    _apply_style(ax, "Interface Area (μm²)", names)
    ax.set_title("AM-SE Interface Area", fontsize=13, fontweight="bold", pad=10)
    if standalone:
        return _save(fig, "", "")
    return ax


def plot_se_se_tradeoff(all_data, names, ax=None):
    standalone = ax is None
    if standalone:
        fig, ax = plt.subplots(figsize=FIG_SINGLE)

    xs = np.arange(len(names))
    width = 0.5
    counts = [_get(d, "area_SE_SE_n") for d in all_data]
    means = [_get(d, "area_SE_SE_mean") for d in all_data]

    ax.bar(xs, counts, width, color=BLUE, alpha=0.75, zorder=3, label="Contact Count")
    _apply_style(ax, "SE-SE Contact Count", names)
    ax.set_title("SE-SE Contact: Count vs Mean Area", fontsize=13, fontweight="bold", pad=10)
    ax.tick_params(axis="y", labelcolor=BLUE)
    ax.legend(loc="upper left", fontsize=9, frameon=False)

    ax2 = ax.twinx()
    ax2.plot(xs, means, marker="s", color=RED, linewidth=2, markersize=8,
             zorder=4, label="Mean Area")
    ax2.set_ylabel("Mean Contact Area (μm²)", fontsize=11, color=RED)
    ax2.tick_params(axis="y", labelcolor=RED, labelsize=9)
    ax2.spines["top"].set_visible(False)
    ax2.legend(loc="upper right", fontsize=9, frameon=False)

    if standalone:
        return _save(fig, "", "")
    return ax


def plot_se_se_total(all_data, names, ax=None):
    standalone = ax is None
    if standalone:
        fig, ax = plt.subplots(figsize=FIG_SINGLE)
    xs = list(range(len(names)))
    ys = [_get(d, "area_SE_SE_total") for d in all_data]
    ax.plot(xs, ys, marker="s", color=GRAY, linewidth=1.5, markersize=8, zorder=3,
            markerfacecolor=GRAY, markeredgecolor=GRAY)

    if ys:
        idx_max = int(np.argmax(ys))
        ax.annotate(f"max: {ys[idx_max]:,.0f}",
                    xy=(idx_max, ys[idx_max]),
                    xytext=(15, 10), textcoords="offset points",
                    fontsize=10, ha="left", color=RED, fontweight="bold",
                    arrowprops=dict(arrowstyle="->", color=RED, lw=1.5))
        ymin, ymax = min(ys), max(ys)
        pad = max((ymax - ymin) * 0.15, 100)
        ax.set_ylim(ymin - pad, ymax + pad)

    _apply_style(ax, "SE-SE Total Contact Area (μm²)", names)
    ax.set_title("SE-SE Total Contact Area", fontsize=13, fontweight="bold", pad=10)
    if standalone:
        return _save(fig, "", "")
    return ax


def plot_percolation_tortuosity(all_data, names, ax=None):
    standalone = ax is None
    if standalone:
        fig, ax = plt.subplots(figsize=FIG_SINGLE)

    xs = list(range(len(names)))
    perc = [_get(d, "percolation_pct") for d in all_data]
    top_reach = [_get(d, "top_reachable_pct") for d in all_data]
    tort = [_get(d, "tortuosity_recommended", _get(d, "tortuosity_mean")) for d in all_data]

    ax.plot(xs, perc, marker="s", color=BLUE, linewidth=2, markersize=8,
            zorder=3, label="Percolation %")
    ax.plot(xs, top_reach, marker="D", color="#00B0F0", linewidth=1.5, markersize=7,
            linestyle="--", zorder=3, label="Top Reachable %")
    _apply_style(ax, "SE Connectivity (%)", names)
    ax.tick_params(axis="y", labelcolor=BLUE)
    ax.set_title("Percolation / Top Reachable & Tortuosity", fontsize=13, fontweight="bold", pad=10)
    ax.legend(loc="center left", fontsize=8, frameon=False)

    ax2 = ax.twinx()
    ax2.plot(xs, tort, marker="^", color=RED, linewidth=2, markersize=9,
             zorder=4, label="Tortuosity")
    ax2.set_ylabel("Tortuosity", fontsize=11, color=RED)
    ax2.tick_params(axis="y", labelcolor=RED, labelsize=9)
    ax2.spines["top"].set_visible(False)
    ax2.legend(loc="center right", fontsize=9, frameon=False)

    if standalone:
        return _save(fig, "", "")
    return ax


def plot_ionic_active(all_data, names, ax=None):
    standalone = ax is None
    if standalone:
        fig, ax = plt.subplots(figsize=FIG_SINGLE)
    xs = list(range(len(names)))
    ys = [_get(d, "ionic_active_pct") for d in all_data]

    # Fill per group to avoid cross-group shading
    if _GROUP_INFO and len(_GROUP_INFO[0]) > 1:
        sizes = _GROUP_INFO[0]
        pos = 0
        for gi, sz in enumerate(sizes):
            gx = xs[pos:pos+sz]
            gy = ys[pos:pos+sz]
            ax.plot(gx, gy, marker="o", color=GREEN, linewidth=2, markersize=9, zorder=3)
            ax.fill_between(gx, gy, 100, color=RED, alpha=0.12, label="Dead zone" if gi == 0 else None)
            ax.fill_between(gx, 0, gy, color=GREEN, alpha=0.12, label="Active zone" if gi == 0 else None)
            pos += sz
    else:
        ax.plot(xs, ys, marker="o", color=GREEN, linewidth=2, markersize=9, zorder=3)
        ax.fill_between(xs, ys, 100, color=RED, alpha=0.12, label="Dead zone")
        ax.fill_between(xs, 0, ys, color=GREEN, alpha=0.12, label="Active zone")
    if ys:
        ymin = max(min(ys) - 3, 0)
        ax.set_ylim(ymin, 101)
    _apply_style(ax, "Ionic Active AM (%)", names)
    ax.set_title("Ionic Active AM Fraction", fontsize=13, fontweight="bold", pad=10)
    ax.legend(fontsize=9, frameon=False, loc="lower left")
    if standalone:
        return _save(fig, "", "")
    return ax


def plot_coverage(all_data, names, ax=None):
    standalone = ax is None
    if standalone:
        fig, ax = plt.subplots(figsize=FIG_SINGLE)

    xs = np.arange(len(names))
    width = 0.3

    resolved = [_resolve_coverage(d) for d in all_data]
    mean_p = [r[0] for r in resolved]
    std_p = [r[1] for r in resolved]
    mean_s = [r[2] for r in resolved]
    std_s = [r[3] for r in resolved]

    # Only plot bars where values > 0
    has_p = any(v > 0 for v in mean_p)
    has_s = any(v > 0 for v in mean_s)

    if has_p:
        ax.bar(xs - width / 2, mean_p, width, yerr=std_p, capsize=4,
               color=GREEN, label="AM_P", zorder=3, error_kw=dict(lw=1.2))
    if has_s:
        ax.bar(xs + width / 2, mean_s, width, yerr=std_s, capsize=4,
               color=LIGHT_GREEN, label="AM_S", zorder=3, error_kw=dict(lw=1.2))

    _apply_style(ax, "Coverage (%)", names)
    ax.set_title("AM Coverage (P vs S)", fontsize=13, fontweight="bold", pad=10)
    ax.legend(fontsize=10, frameon=False)
    if standalone:
        return _save(fig, "", "")
    return ax


def plot_coverage_physics_union(all_data, names, ax=None):
    """⑥ 합집합 cap 피복 (C2-⑥ · 10-06 · LHS-25) — 전체 AM 입자 평균 `coverage_AM_mean_physics_union`.  값이 없는 (재분석 전 · 빈칸 침대)
    케이스는 점을 안 찍는다 (_metric_points — 0 으로 채우지 않는다).  옛 Physics 합-클립 (coverage_AM_mean_physics) 과 다른 양."""
    return _plot_metric_line(all_data, names, "coverage_AM_mean_physics_union", "Coverage, Physics union of caps (%)",
                             "AM Coverage — Physics union of caps (gen-2 area)", ax)


def plot_stress_cv(all_data, names, ax=None):
    """두 규약을 같이 — 실선 = Love–Weber (stress_cv_lw · ④b 10-04 · 입자 접촉력 기반 대칭 응력의 VM — kinetic · 벽 · couple 미포함 ·
    RGL-06 이름 한정) · 점선 = 옛 열 (stress_cv = LIGGGHTS stress/atom 50/50 분할 · 대각 · LHS-29).
    값이 없는 케이스는 그리지 않는다 (_metric_points — 0 으로 채우지 않는다 · 재분석 전 · 무하중 UNDEFINED 케이스에는 LW 가 없다).
    옛 열은 LHS-33 상태를 따른다 (_stress_points — stress_cv_status ≠ computed 면 저장된 0 도 안 그린다)."""
    standalone = ax is None
    if standalone:
        fig, ax = plt.subplots(figsize=FIG_SINGLE)
    allv = []
    for key, sty, lab in (("stress_cv", dict(color=GRAY, linestyle="--", marker="s", markerfacecolor="white"),
                           "stress/atom 50/50 split (old · diagonal)"),
                          ("stress_cv_lw", dict(color=BLACK, linestyle="-", marker="s"),
                           "Love–Weber (particle-contact sym. stress)")):
        pts = (_stress_points if key == "stress_cv" else _metric_points)(all_data, key)
        if pts:
            xs, ys = zip(*pts)
            ax.plot(xs, ys, markersize=9, linewidth=1.5, zorder=3, label=lab, **sty)
            allv += list(ys)
    if allv:
        ymin, ymax = min(allv), max(allv)
        pad = max((ymax - ymin) * 0.15, 1)
        ax.set_ylim(ymin - pad, ymax + pad)
    _apply_style(ax, "Von Mises CV (%)", names)
    ax.set_title("Stress Distribution Uniformity", fontsize=13, fontweight="bold", pad=10)
    ax.legend(fontsize=8, frameon=False)
    if standalone:
        return _save(fig, "", "")
    return ax


def plot_stress_ratio(all_data, names, ax=None):
    """상별 σ/σ_mean — 실선 = Love–Weber (stress_ratio_<상>_lw) · 점선 = 옛 열 (stress/atom 50/50 분할 · 크기 편향 · LHS-29).
    값이 없는 케이스는 그리지 않는다 (옛 판 `_get` 은 0 으로 채웠다)."""
    standalone = ax is None
    if standalone:
        fig, ax = plt.subplots(figsize=FIG_SINGLE)

    type_keys = ['AM_P', 'AM_S', 'SE']
    colors = {'AM_P': RED, 'AM_S': '#FF8C00', 'SE': GREEN}
    markers = {'AM_P': 's', 'AM_S': 'o', 'SE': '^'}

    for tk in type_keys:
        for suffix, ls, mfc, lab in (('', '--', 'white', f'{tk} (50/50 old)'), ('_lw', '-', colors[tk], f'{tk} Love–Weber')):
            pts = (_stress_points if not suffix else _metric_points)(all_data, f"stress_ratio_{tk}{suffix}")   # 옛 열 = LHS-33 상태
            if pts:
                xs, ys = zip(*pts)
                ax.plot(xs, ys, marker=markers[tk], markersize=8, color=colors[tk], linestyle=ls,
                        markerfacecolor=mfc, linewidth=1.5, label=lab, zorder=3)

    ax.axhline(y=1.0, color=GRAY, linestyle=':', linewidth=1, alpha=0.5, label='mean')
    _apply_style(ax, "σ / σ_mean", names)
    ax.set_title("Stress Ratio by Type", fontsize=13, fontweight="bold", pad=10)
    ax.legend(fontsize=7, frameon=False, ncol=2)
    if standalone:
        return _save(fig, "", "")
    return ax


def plot_stress_z_layer(all_data, names, ax=None):
    """Z-layer별 stress CV profile (all cases overlaid)."""
    standalone = ax is None
    if standalone:
        fig, ax = plt.subplots(figsize=FIG_SINGLE)

    colors_cycle = [BLUE, RED, GREEN, '#FF8C00', BLACK, '#9467BD']
    for i, d in enumerate(all_data):
        if stress_cv_status(d) not in (None, STRESS_CV_COMPUTED):       # LHS-33 — 무효 · 미정의 (z 층 None) 는 안 그린다
            continue
        z_data = d.get('stress_z_layer_cv', [])
        if z_data:
            zs = [layer['z_mid_um'] for layer in z_data]
            cvs = [layer['cv'] for layer in z_data]
            c = colors_cycle[i % len(colors_cycle)]
            ax.plot(zs, cvs, marker='o', markersize=5, linewidth=1.5,
                    color=c, label=names[i], zorder=3)

    ax.set_xlabel("Z Position (μm)", fontsize=10)
    ax.set_ylabel("Von Mises CV (%)", fontsize=11)
    ax.yaxis.grid(True, linestyle="--", linewidth=0.4, color="#CCCCCC", alpha=0.7)
    ax.set_axisbelow(True)
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)
    ax.set_title("Stress Uniformity by Z-layer", fontsize=13, fontweight="bold", pad=10)
    ax.legend(fontsize=8, frameon=False)
    if standalone:
        return _save(fig, "", "")
    return ax


def _save_csv(outdir, fname, names, all_data, keys):
    """Save plot data as CSV for download."""
    import csv
    path = os.path.join(outdir, fname)
    with open(path, 'w', newline='', encoding='utf-8') as f:
        writer = csv.writer(f)
        writer.writerow(['Case'] + [k for k, _ in keys])
        for i, name in enumerate(names):
            row = [name]
            for key, transform in keys:
                val = _get(all_data[i], key)
                if transform:
                    val = transform(all_data[i])
                row.append(val)
            writer.writerow(row)
    return fname


# ─── Four-panel composite ────────────────────────────────────────────────────

def plot_four_panel(all_data, names, outdir):
    fig, axes = plt.subplots(2, 2, figsize=FIG_FOUR)
    plot_porosity(all_data, names, ax=axes[0, 0])
    plot_am_se_interface(all_data, names, ax=axes[0, 1])
    plot_se_se_tradeoff(all_data, names, ax=axes[1, 0])
    plot_percolation_tortuosity(all_data, names, ax=axes[1, 1])

    for i, label in enumerate(['(a)', '(b)', '(c)', '(d)']):
        ax = axes.flat[i]
        ax.text(-0.12, 1.05, label, transform=ax.transAxes,
                fontsize=14, fontweight='bold', va='top')

    fig.suptitle("DEM Analysis Comparison", fontsize=16, fontweight="bold", y=1.01)
    return _save(fig, outdir, "four_panel.png")


def _generate_particle_info(all_data, ps_labels, case_names, outdir):
    """Generate particle info summary table(s) as PNG, split by group if available."""
    global _GROUP_INFO

    if _GROUP_INFO and len(_GROUP_INFO[0]) > 1:
        sizes, gnames = _GROUP_INFO
        n_groups = len(sizes)
        fig, axes = plt.subplots(n_groups, 1, figsize=(max(7, max(sizes)*1.5 + 2), 3 * n_groups))
        if n_groups == 1:
            axes = [axes]

        idx = 0
        for gi, (sz, gname) in enumerate(zip(sizes, gnames)):
            ax = axes[gi]
            ax.axis('off')
            ax.set_title(gname, fontsize=12, fontweight='bold', color=GROUP_COLORS[gi % len(GROUP_COLORS)], pad=10)

            group_data = all_data[idx:idx+sz]
            group_labels = ps_labels[idx:idx+sz]

            headers = ['P:S'] + group_labels
            rows_data = []
            for ptype in ['AM_P', 'AM_S', 'SE']:
                row = [f'{ptype} Count']
                for d in group_data:
                    val = d.get(f'n_{ptype}', '-')
                    row.append(str(int(val)) if val != '-' else '-')
                rows_data.append(row)
            for ptype in ['AM_P', 'AM_S', 'SE']:
                row = [f'{ptype} R (μm)']
                for d in group_data:
                    val = d.get(f'r_{ptype}', '-')
                    row.append(str(val) if val != '-' else '-')
                rows_data.append(row)

            table = ax.table(cellText=rows_data, colLabels=headers, loc='center', cellLoc='center')
            table.auto_set_font_size(False)
            table.set_fontsize(9)
            table.scale(1, 1.4)
            for j in range(len(headers)):
                cell = table[0, j]
                cell.set_facecolor(GROUP_COLORS[gi % len(GROUP_COLORS)])
                cell.set_text_props(color='white', fontweight='bold')
            for i in range(len(rows_data)):
                for j in range(len(headers)):
                    cell = table[i+1, j]
                    cell.set_facecolor('#f0f0f0' if i % 2 == 0 else 'white')

            idx += sz

        fig.tight_layout()
        fig.savefig(os.path.join(outdir, 'particle_info.png'), dpi=DPI,
                    bbox_inches='tight', facecolor='white', pad_inches=0.1)
        plt.close(fig)
    else:
        # Single group (original behavior)
        fig, ax = plt.subplots(figsize=(max(7, len(ps_labels)*1.5 + 2), 3))
        ax.axis('off')

        headers = ['P:S'] + ps_labels
        rows_data = []
        for ptype in ['AM_P', 'AM_S', 'SE']:
            row = [f'{ptype} Count']
            for d in all_data:
                val = d.get(f'n_{ptype}', '-')
                row.append(str(int(val)) if val != '-' else '-')
            rows_data.append(row)
        for ptype in ['AM_P', 'AM_S', 'SE']:
            row = [f'{ptype} R (μm)']
            for d in all_data:
                val = d.get(f'r_{ptype}', '-')
                row.append(str(val) if val != '-' else '-')
            rows_data.append(row)

        table = ax.table(cellText=rows_data, colLabels=headers, loc='center', cellLoc='center')
        table.auto_set_font_size(False)
        table.set_fontsize(9)
        table.scale(1, 1.4)
        for j in range(len(headers)):
            cell = table[0, j]
            cell.set_facecolor('#4472C4')
            cell.set_text_props(color='white', fontweight='bold')
        for i in range(len(rows_data)):
            for j in range(len(headers)):
                cell = table[i+1, j]
                cell.set_facecolor('#f0f0f0' if i % 2 == 0 else 'white')

        fig.tight_layout()
        fig.savefig(os.path.join(outdir, 'particle_info.png'), dpi=DPI,
                    bbox_inches='tight', facecolor='white', pad_inches=0.1)
        plt.close(fig)


# ─── New Plots ─────────────────────────────────────────────────────────────────

ORANGE = "#ED7D31"
PURPLE = "#7030A0"


def plot_se_network(data_list, names, outdir):
    """SE-SE CN mean + SE Cluster count (dual Y axis)."""
    fig, ax1 = plt.subplots(figsize=FIG_SINGLE)
    x = np.arange(len(names))

    cn = [_get(d, "se_se_cn") for d in data_list]
    clusters = [_get(d, "n_components") for d in data_list]
    large_clusters = [_get(d, "n_large_components") for d in data_list]

    color1, color2 = BLUE, ORANGE
    ax1.plot(x, cn, 's-', color=color1, markersize=10, linewidth=2.5, label="SE-SE CN mean")
    _apply_style(ax1, "SE-SE CN mean", names)
    ax1.tick_params(axis='y', labelcolor=color1)

    ax2 = ax1.twinx()
    ax2.bar(x - 0.15, clusters, 0.3, color=color2, alpha=0.4, label="Total Clusters")
    ax2.bar(x + 0.15, large_clusters, 0.3, color=color2, alpha=0.85, label="Large (≥10)")
    ax2.set_ylabel("SE Cluster Count", fontsize=11, color=color2)
    ax2.tick_params(axis='y', labelcolor=color2)
    ax2.spines["top"].set_visible(False)

    lines1, labels1 = ax1.get_legend_handles_labels()
    lines2, labels2 = ax2.get_legend_handles_labels()
    ax1.legend(lines1 + lines2, labels1 + labels2, fontsize=8, loc='upper right')
    ax1.set_title("SE Network: CN & Clusters", fontsize=12, fontweight='bold')
    _write_csv(outdir, 'se_network.csv', ['SE-SE CN', 'Total Clusters', 'Large(≥10)'],
               names, cn, clusters, large_clusters)
    return _save(fig, outdir, "se_network.png")


def plot_contact_force(data_list, names, outdir):
    """Contact force distribution by type (grouped bar)."""
    fig, ax = plt.subplots(figsize=FIG_SINGLE)
    n = len(names)
    x = np.arange(n)
    types = ['AM_P-AM_P', 'AM_P-SE', 'SE-SE', 'AM_P-AM_S', 'AM_S-SE']
    colors = [RED, GREEN, BLUE, ORANGE, LIGHT_GREEN]

    # Find which types actually have data
    active = []
    for ct, color in zip(types, colors):
        key = f"fn_{ct.replace('-','_')}_mean"
        vals = [_get(d, key) for d in data_list]
        if any(v > 0 for v in vals):
            active.append((ct, key, color, vals))

    if not active:
        plt.close(fig)
        return None

    w = 0.8 / len(active)
    for i, (ct, key, color, vals) in enumerate(active):
        offset = (i - len(active)/2 + 0.5) * w
        bars = ax.bar(x + offset, vals, w, label=ct, color=color, alpha=0.85)

    _apply_style(ax, "Fn mean (μN)", names)
    ax.legend(fontsize=8, loc='upper right')
    ax.set_title("Contact Force by Type", fontsize=12, fontweight='bold')
    # CSV
    headers = [ct for ct, _, _, _ in active]
    cols = [vals for _, _, _, vals in active]
    _write_csv(outdir, 'contact_force.csv', [f'Fn {h} mean(μN)' for h in headers], names, *cols)
    return _save(fig, outdir, "contact_force.png")


def plot_contact_pressure(data_list, names, outdir):
    """Contact pressure mean & max (dual bar)."""
    fig, ax = plt.subplots(figsize=FIG_SINGLE)
    n = len(names)
    x = np.arange(n)
    w = 0.35

    means = [_get(d, "contact_pressure_mean") for d in data_list]
    maxes = [_get(d, "contact_pressure_max") for d in data_list]

    ax.bar(x - w/2, means, w, label="Mean", color=BLUE, alpha=0.85)
    ax.bar(x + w/2, maxes, w, label="Max", color=RED, alpha=0.85)

    _apply_style(ax, "Contact Pressure (MPa)", names)
    ax.legend(fontsize=9)
    ax.set_title("Contact Pressure", fontsize=12, fontweight='bold')
    _write_csv(outdir, 'contact_pressure.csv', ['CP mean(MPa)', 'CP max(MPa)'], names, means, maxes)
    return _save(fig, outdir, "contact_pressure.png")


def plot_am_vulnerability(data_list, names, outdir):
    """AM vulnerability + AM-SE CN (dual Y axis)."""
    fig, ax1 = plt.subplots(figsize=FIG_SINGLE)
    x = np.arange(len(names))

    vuln = [_get(d, "am_vulnerable_pct") for d in data_list]
    cn = [_get(d, "am_se_cn_mean") for d in data_list]

    color1, color2 = RED, BLUE
    ax1.bar(x, vuln, 0.5, color=color1, alpha=0.7, label="Vulnerable AM (%)")
    _apply_style(ax1, "Vulnerable AM (%)", names)
    ax1.tick_params(axis='y', labelcolor=color1)

    ax2 = ax1.twinx()
    ax2.plot(x, cn, 'o-', color=color2, markersize=8, linewidth=2, label="AM-SE CN")
    ax2.set_ylabel("AM-SE CN mean", fontsize=11, color=color2)
    ax2.tick_params(axis='y', labelcolor=color2)
    ax2.spines["top"].set_visible(False)

    lines1, labels1 = ax1.get_legend_handles_labels()
    lines2, labels2 = ax2.get_legend_handles_labels()
    ax1.legend(lines1 + lines2, labels1 + labels2, fontsize=9, loc='upper right')
    ax1.set_title("AM Vulnerability & SE Connectivity", fontsize=12, fontweight='bold')
    _write_csv(outdir, 'am_vulnerability.csv', ['Vulnerable(%)', 'AM-SE CN'], names, vuln, cn)
    return _save(fig, outdir, "am_vulnerability.png")


def plot_effective_conductivity(data_list, names, outdir):
    """Bruggeman effective ionic conductivity."""
    fig, ax1 = plt.subplots(figsize=FIG_SINGLE)
    x = np.arange(len(names))

    sigma_brug = [_get(d, "sigma_ratio") for d in data_list]
    phi = [_get(d, "phi_se") for d in data_list]

    ax1.plot(x, sigma_brug, 's-', color=GREEN, markersize=10, linewidth=2.5, label="σ_brug/σ_grain")
    _apply_style(ax1, "σ_brug / σ_grain", names)
    ax1.tick_params(axis='y', labelcolor=GREEN)

    ax1b = ax1.twinx()
    ax1b.bar(x, phi, 0.4, color=BLUE, alpha=0.25, label="φ_SE")
    ax1b.set_ylabel("φ_SE", fontsize=10, color=BLUE)
    ax1b.set_ylim(0.2, max(phi) * 1.15 if phi else 0.4)
    ax1b.tick_params(axis='y', labelcolor=BLUE)
    ax1b.spines["top"].set_visible(False)

    lines1, labels1 = ax1.get_legend_handles_labels()
    lines2, labels2 = ax1b.get_legend_handles_labels()
    ax1.legend(lines1 + lines2, labels1 + labels2, fontsize=9, loc='upper right')
    ax1.set_title("Bruggeman: σ_brug/σ_grain = φ_SE × f_perc / τ²", fontsize=12, fontweight='bold')

    _write_csv(outdir, 'effective_conductivity.csv',
               ['φ_SE', 'σ_brug/σ_grain'], names, phi, sigma_brug)
    return _save(fig, outdir, "effective_conductivity.png")


R_GB_MIN_R2 = 0.75  # minimum R² for R_gb fitting to be valid

def _fit_r_gb(data_list, names, use_global=True):
    """Fit GB correction: BLM+Constriction model R = C × (GB_d² × T)^α.
    log(R) = α × log(GB_d²×T) + ln(C)
    Returns alpha, ln_C, valid_idx, r_squared."""
    sigma_brug = [_get(d, "sigma_ratio") for d in data_list]
    perc = [_get(d, "percolation_pct") / 100 for d in data_list]
    tau = [_get(d, "tortuosity_recommended", _get(d, "tortuosity_mean", 1)) for d in data_list]
    g_path = [_get(d, "path_conductance_mean") for d in data_list]
    gb_dens = [_get(d, "gb_density_mean") for d in data_list]
    thickness = [_get(d, "thickness_um", 0) for d in data_list]

    sigma_proxy = [g_path[i] * perc[i] / tau[i] if g_path[i] > 0 and tau[i] > 0 else 0
                   for i in range(len(data_list))]

    valid_idx = [i for i in range(len(data_list))
                 if sigma_proxy[i] > 0 and gb_dens[i] > 0 and sigma_brug[i] > 0 and thickness[i] > 0]

    if use_global and _GLOBAL_RGB is not None:
        return _GLOBAL_RGB[0], _GLOBAL_RGB[1], valid_idx, 1.0

    alpha = 1.87
    ln_C = -3.26
    r_squared = 0
    if len(valid_idx) >= 2:
        ratio = np.array([sigma_brug[i] / sigma_proxy[i] for i in valid_idx])
        # x = GB_d² × T (BLM + Constriction)
        x_vals = np.array([gb_dens[i]**2 * thickness[i] for i in valid_idx])
        log_y = np.log(ratio)
        log_x = np.log(x_vals)
        from scipy import stats as sp_stats
        slope, intercept, r_val, _, _ = sp_stats.linregress(log_x, log_y)
        alpha = slope
        ln_C = intercept
        r_squared = r_val ** 2
    return alpha, ln_C, valid_idx, r_squared


def plot_rgb_fitting(data_list, names, outdir):
    """BLM+Constriction fitting: log(R) vs log(GB_d²×T)."""
    alpha, ln_C, valid_idx, r_squared = _fit_r_gb(data_list, names)

    sigma_brug = [_get(d, "sigma_ratio") for d in data_list]
    perc = [_get(d, "percolation_pct") / 100 for d in data_list]
    tau = [_get(d, "tortuosity_recommended", _get(d, "tortuosity_mean", 1)) for d in data_list]
    g_path = [_get(d, "path_conductance_mean") for d in data_list]
    gb_dens = [_get(d, "gb_density_mean") for d in data_list]
    thickness = [_get(d, "thickness_um", 100) for d in data_list]
    sigma_proxy = [g_path[i] * perc[i] / tau[i] if g_path[i] > 0 and tau[i] > 0 else 0
                   for i in range(len(data_list))]

    fig, ax = plt.subplots(figsize=FIG_SINGLE)

    # x = log(GB_d² × T), y = log(R)
    x_pts = np.array([np.log(gb_dens[i]**2 * thickness[i]) for i in valid_idx])
    y_pts = np.array([np.log(sigma_brug[i] / sigma_proxy[i]) for i in valid_idx])

    # Group colors
    point_groups = [0] * len(valid_idx)
    group_boundaries = []
    if _GROUP_INFO:
        sizes, gnames = _GROUP_INFO
        pos = 0
        for sz in sizes:
            group_boundaries.append((pos, pos + sz))
            pos += sz
        for j, i in enumerate(valid_idx):
            for g_idx, (start, end) in enumerate(group_boundaries):
                if start <= i < end:
                    point_groups[j] = g_idx
                    break

    if _GROUP_INFO:
        for j in range(len(valid_idx)):
            gi = point_groups[j]
            ax.scatter(x_pts[j], y_pts[j], s=100, c=GROUP_COLORS[gi % len(GROUP_COLORS)],
                      zorder=5, edgecolors='white', linewidth=1.5)
    else:
        ax.scatter(x_pts, y_pts, s=100, c=BLUE, zorder=5, edgecolors='white', linewidth=1.5)

    # Labels
    try:
        from adjustText import adjust_text
        texts = []
        for j, i in enumerate(valid_idx):
            texts.append(ax.text(x_pts[j], y_pts[j], names[i], fontsize=8, color=BLACK, zorder=6))
        adjust_text(texts, x=list(x_pts), y=list(y_pts), ax=ax,
                   arrowprops=dict(arrowstyle='-', color='gray', lw=0.5),
                   force_text=(0.5, 0.5), expand=(1.3, 1.5))
    except ImportError:
        for j, i in enumerate(valid_idx):
            ax.annotate(names[i], (x_pts[j], y_pts[j]),
                       fontsize=8, ha='left', va='bottom', xytext=(5, 5),
                       textcoords='offset points', color=BLACK, zorder=6)

    # Group labels
    if _GROUP_INFO:
        for gi, (start, end) in enumerate(group_boundaries):
            group_js = [j for j, i in enumerate(valid_idx) if start <= i < end]
            if group_js:
                cx = np.mean([x_pts[j] for j in group_js])
                cy = min([y_pts[j] for j in group_js])
                ax.text(cx, cy - (max(y_pts) - min(y_pts)) * 0.08, gnames[gi],
                       ha='center', va='top',
                       fontsize=9, fontweight='bold', color=GROUP_COLORS[gi % len(GROUP_COLORS)],
                       bbox=dict(boxstyle='round,pad=0.2', facecolor='white',
                                edgecolor=GROUP_COLORS[gi % len(GROUP_COLORS)], alpha=0.8))

    # Fit line
    x_line = np.linspace(min(x_pts) * 0.9, max(x_pts) * 1.1, 100)
    y_line = alpha * x_line + ln_C
    ax.plot(x_line, y_line, '-', color=RED, linewidth=2.5,
            label=f"y = {alpha:.2f}·x + {ln_C:.2f}")

    ax.set_xlabel("log(GB_d² × T)", fontsize=12)
    ax.set_ylabel("log(σ_brug / σ_proxy)", fontsize=12)
    title_suffix = " (global)" if _GLOBAL_RGB is not None else ""
    ax.set_title(f"BLM+Constriction Fitting{title_suffix}", fontsize=13, fontweight='bold')
    ax.legend(fontsize=10, loc='upper left')
    ax.text(0.95, 0.05, f"α = {alpha:.2f}\nln(C) = {ln_C:.2f}\nR² = {r_squared:.4f}\nn = {len(x_pts)}",
            transform=ax.transAxes, fontsize=11, ha='right', va='bottom',
            bbox=dict(boxstyle='round,pad=0.4', facecolor='white', alpha=0.8))
    y_margin = (max(y_pts) - min(y_pts)) * 0.15
    ax.set_ylim(min(y_pts) - y_margin, max(y_pts) + y_margin)
    ax.yaxis.grid(True, linestyle="--", linewidth=0.4, alpha=0.7)
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)

    _write_csv(outdir, 'rgb_fitting.csv',
               ['GB_d²×T', 'log(GB_d²×T)', 'log(σ_brug/σ_proxy)', 'σ_brug', 'σ_proxy', 'thickness_um'],
               [names[i] for i in valid_idx],
               [gb_dens[i]**2 * thickness[i] for i in valid_idx],
               list(x_pts), list(y_pts),
               [sigma_brug[i] for i in valid_idx],
               [sigma_proxy[i] for i in valid_idx],
               [thickness[i] for i in valid_idx])
    return _save(fig, outdir, "rgb_fitting.png")


def _load_network_sigma(data_list):
    """Load σ_full from network_conductivity.json for each case."""
    sigma_net = [0] * len(data_list)
    for i, d in enumerate(data_list):
        net_val = _get(d, "sigma_full_mScm", 0)
        if net_val > 0:
            sigma_net[i] = net_val
        else:
            src = _get(d, "_source_path", "")
            if src:
                net_path = os.path.join(os.path.dirname(src), "network_conductivity.json")
                if os.path.exists(net_path):
                    try:
                        with open(net_path) as _nf:
                            nd = json.load(_nf)
                        sigma_net[i] = nd.get("sigma_full_mScm", 0) or 0
                    except:
                        pass
    return sigma_net


def plot_gb_corrected(data_list, names, outdir):
    """Part I: Proxy-based GB-corrected σ_eff using BLM+Constriction."""
    alpha, ln_C, _, r2_check = _fit_r_gb(data_list, names)
    SIGMA_BULK = 3.0  # σ_grain (grain interior)
    C = np.exp(ln_C)

    sigma_brug = [_get(d, "sigma_ratio") for d in data_list]
    gb_dens = [_get(d, "gb_density_mean") for d in data_list]
    thickness = [_get(d, "thickness_um", 100) for d in data_list]

    sigma_corr = []
    for i in range(len(data_list)):
        gb2t = gb_dens[i]**2 * thickness[i]
        if gb2t > 0:
            correction = C * gb2t**alpha
            sigma_corr.append(sigma_brug[i] / correction if correction > 0 else sigma_brug[i])
        else:
            sigma_corr.append(sigma_brug[i])
    sigma_abs = [s * SIGMA_BULK for s in sigma_corr]

    fig, ax = plt.subplots(figsize=FIG_SINGLE)
    x = np.arange(len(names))
    ms = _marker_size(len(names))
    lw = _line_width(len(names))

    ax.plot(x, sigma_corr, 's-', color=RED, markersize=ms, linewidth=lw, label="σ_brug/σ_grain")
    _apply_style(ax, "σ_brug / σ_grain (proxy)", names)
    ax.tick_params(axis='y', labelcolor=RED)

    ax2 = ax.twinx()
    ax2.plot(x, sigma_abs, 'D--', color=ORANGE, markersize=ms-2, linewidth=lw-0.5, label="σ_ionic (mS/cm)")
    ax2.set_ylabel("σ_ionic (mS/cm)", fontsize=11, color=ORANGE)
    ax2.tick_params(axis='y', labelcolor=ORANGE)
    ax2.spines["top"].set_visible(False)

    lines1, labels1 = ax.get_legend_handles_labels()
    lines2, labels2 = ax2.get_legend_handles_labels()
    ax.legend(lines1 + lines2, labels1 + labels2, fontsize=9, loc='upper left')
    gb_src = "global" if _GLOBAL_RGB is not None else "local"
    ax.set_title(f"Part I: Proxy σ_eff = σ_brug / C·(GB_d²·T)^α\nα={alpha:.2f}, R²={r2_check:.3f} [{gb_src}]",
                 fontsize=10, fontweight='bold')

    _write_csv(outdir, 'gb_corrected.csv',
               ['GB_d', 'T(μm)', 'GB_d²×T', 'σ_brug/σ_grain', 'σ_brug/σ_grain', 'σ_eff(mS/cm)'],
               names, gb_dens, thickness,
               [gb_dens[i]**2*thickness[i] for i in range(len(names))],
               sigma_brug, sigma_corr, sigma_abs)
    return _save(fig, outdir, "gb_corrected.png")


def plot_ionic_scaling_fit(data_list, names, outdir):
    """Ionic scaling law fit: σ_predicted vs σ_actual scatter (log-log).
    Uses same fitting approach as find_scaling_law.py model 4."""
    SIGMA_BULK = 3.0

    phi_se = [_get(d, "phi_se") for d in data_list]
    f_perc = [_get(d, "percolation_pct", 0) / 100 for d in data_list]
    tau = [_get(d, "tortuosity_recommended", _get(d, "tortuosity_mean", 1)) for d in data_list]
    gb_dens = [_get(d, "gb_density_mean") for d in data_list]
    g_path = [_get(d, "path_conductance_mean", 0) for d in data_list]
    cn = [_get(d, "se_se_cn", 0) for d in data_list]
    sigma_net = _load_network_sigma(data_list)

    # Same as find_scaling_law.py: σ_brug = 3.0 × φ_SE × f_perc / τ²
    valid_idx = []
    SIGMA_MIN = 0.0  # include all non-zero σ_net (was 0.01; relaxed to test fit on low-σ cases)
    for i in range(len(data_list)):
        if (phi_se[i] > 0 and f_perc[i] > 0 and tau[i] > 0 and
            g_path[i] > 0 and cn[i] > 0 and gb_dens[i] > 0 and sigma_net[i] > SIGMA_MIN):
            valid_idx.append(i)

    if len(valid_idx) < 3:
        return None

    s_actual = np.array([sigma_net[i] for i in valid_idx])
    log_sf = np.log(s_actual)

    # σ_brug in mS/cm (same as find_scaling_law.py)
    sigma_brug = np.array([SIGMA_BULK * phi_se[i] * f_perc[i] / tau[i]**2 for i in valid_idx])
    log_sb = np.log(sigma_brug)

    # Fit: log(σ_full) = log(σ_brug) + a*log(g_path*gb_d²) + b*log(cn) + c
    log_combo = np.array([np.log(g_path[i] * gb_dens[i]**2) for i in valid_idx])
    log_cn = np.array([np.log(cn[i]) for i in valid_idx])
    residual = log_sf - log_sb
    X = np.column_stack([log_combo, log_cn, np.ones(len(valid_idx))])
    b_fit, _, _, _ = np.linalg.lstsq(X, residual, rcond=None)
    a_combo, b_cn, ln_C = b_fit
    C_fit = np.exp(ln_C)

    # Predicted (using fixed champion exponents: 0.25, 2)
    # Also compute free-fit R² for comparison
    pred_free = log_sb + X @ b_fit
    ss_res_free = np.sum((log_sf - pred_free)**2)
    ss_tot = np.sum((log_sf - np.mean(log_sf))**2)
    r2_free = 1 - ss_res_free / ss_tot

    # Fixed exponents + fit C only
    log_rhs_fixed = log_sb + 0.25 * log_combo + 2 * log_cn
    ln_C_fixed = np.mean(log_sf - log_rhs_fixed)
    C_fixed = np.exp(ln_C_fixed)
    # Save v3 C (legacy, for reference only)
    global _GLOBAL_C_ION
    pred_fixed = ln_C_fixed + log_rhs_fixed
    ss_res_fixed = np.sum((log_sf - pred_fixed)**2)
    r2_fixed = 1 - ss_res_fixed / ss_tot

    # === v12-CLEAN v3 (production) — simple fractions + f_p³ ===
    # v12 fit: (α,β,γ,δ,φc) = (0.53, 1.48, 0.42, 2.90, 0.20)
    # Rounded cleanly: (1/2, 3/2, 2/5, 3, 0.20) — δ=3 (not 2!) matches 2.90.
    # σ = C_blend(τ) × σ_grain × √(φ-0.2) × CN^(3/2) × cov^(2/5) × f_p³
    PHI_C = 0.20  # data-native percolation threshold
    coverage = [(lambda vs: sum(vs)/len(vs)/100 if vs else 0.20)([v for v in [_get(d,"coverage_AM_P_mean",0), _get(d,"coverage_AM_S_mean",0), _get(d,"coverage_AM_mean",0)] if v>0]) for d in data_list]

    phi_ex_arr = np.array([max(phi_se[i] - PHI_C, 1e-4) for i in valid_idx])
    cn_arr = np.array([cn[i] for i in valid_idx])
    tau_arr = np.array([tau[i] for i in valid_idx])
    cov_arr = np.array([coverage[i] for i in valid_idx])

    # FORM X v9 BLEND: (1-w)·v5_sigmoid(τ) + w·poly3(lnτ)
    # Blend sigmoid (k, τc) continuously optimized by LOOCV.
    # Smooth k → fewer outliers in transition band.
    TAU_C = 2.1; TAU_K = 5.0          # v5 C(τ) sigmoid (fixed)
    fp_arr = np.array([max(f_perc[i], 0.01) for i in valid_idx])
    log_tau_arr = np.log(tau_arr)
    # v12-clean v3: α=1/2, β=3/2, γ=2/5, δ=3, φc=0.20
    # + v22: κ·log(hop_area) correction for R_bulk cylindrical-approx bias
    hop_area_prod = np.array([max(_get(data_list[i], "path_hop_area_mean", 0), 1e-10) for i in valid_idx])
    log_hop_area = np.log(hop_area_prod)
    log_rhs_base_v12 = (np.log(SIGMA_BULK) + 0.50*np.log(phi_ex_arr) + 1.5*np.log(cn_arr)
                        + 0.40*np.log(cov_arr) + 3.0*np.log(fp_arr))
    # v17 addition: β·I(p_frac > 0.5) — captures particulate-majority offset
    # (v14b found ΔLOOCV=+0.00385 ⭐ for this term)
    def _pfrac_v12(d):
        ps = (d.get("ps_ratio", "") or "")
        if ps in ("P only", "10:0"): return 1.0
        if ps in ("S only", "0:10"): return 0.0
        if ":" in ps:
            try:
                p, s = ps.split(":"); p, s = float(p), float(s)
                return p / (p + s) if (p + s) > 0 else 0.5
            except Exception:
                return 0.5
        return 0.5
    pf_prod = np.array([_pfrac_v12(data_list[i]) for i in valid_idx])
    # v18: replace binary indicator with smooth sigmoid. (k_pf, pc_pf) jointly
    # optimized by LOOCV alongside (k_bl, τc_bl). Binary is k_pf→∞ limit.
    # log_rhs_base starts with pure v12-clean v3; β added via residual fit later
    log_rhs_base = log_rhs_base_v12.copy()
    w_sigmoid = 1.0 / (1.0 + np.exp(-TAU_K * (tau_arr - TAU_C)))

    def _fit_at(k_bl, tc_bl, k_pf=10.0, pc_pf=0.5, tau_c_win=2.0, sigma_tau_win=0.3):
        """v29 PRODUCTION: v25 Gaussian τ-bump + v29 sigmoid(log gb_dens).
        3-term residual correction: β_pf·w_pf + β_lin·p·w_win + β_gb·w_gb.
        v30 phase-split exploration (v30/v30.1/v30.2) found no signal above noise —
        reverted to v29 as final. See v30b/c/d/e/v31 diagnostic sweeps below for
        the exhaustive search record.
        Returns (r2, loocv, w20, b_v5, b_p3, w_bl, pred, β_pf, β_win, w_pf)."""
        w_bl = 1.0 / (1.0 + np.exp(-k_bl * (tau_arr - tc_bl)))
        w_pf = 1.0 / (1.0 + np.exp(-k_pf * (pf_prod - pc_pf)))
        # Gaussian bump × p_frac·(1-p_frac) — MIXED-regime selector
        w_win = np.exp(-0.5 * ((tau_arr - tau_c_win) / max(sigma_tau_win, 0.05))**2)
        X_v5_l = np.column_stack([np.ones(len(log_sf)), w_sigmoid])
        X_p3_l = np.column_stack([np.ones(len(log_sf)), log_tau_arr, log_tau_arr**2, log_tau_arr**3])

        b_v5_l = np.linalg.lstsq(X_v5_l, log_sf - log_rhs_base, rcond=None)[0]
        b_p3_l = np.linalg.lstsq(X_p3_l, log_sf - log_rhs_base, rcond=None)[0]
        pv_l = X_v5_l @ b_v5_l
        pp_l = X_p3_l @ b_p3_l
        pred_pre = (1 - w_bl) * pv_l + w_bl * pp_l + log_rhs_base

        # v30: v29 + I(τ>1.8)·log(cov_P/cov_S) — phase-split asymmetry for thin regime
        #   β_pf · w_pf                     — P:S global sigmoid
        #   β_lin · p·w_win                 — linear p × Gaussian τ-bump
        #   β_gb · w_gb                     — sigmoid(log gb_dens)
        #   β_ps · I(τ>1.8)·log(cov_P/cov_S) — NEW v30: thin AM_P:AM_S coverage asymmetry
        # Rationale: r=-0.378 (p<0.005) found via v30b/c/d sweeps. Physics: at P=7:3
        # primary AM dominates coverage → log(cov_P/cov_S)>0 → negative β corrects
        # over-prediction. At P=3:7 reverse. ΔLOOCV=+0.00045 (subnoise but consistent
        # across 3 refinements). Conservative integration: data has more to say with
        # more samples, but current sign & magnitude are physics-justified.
        pf_c = w_pf - w_pf.mean()
        lin_term = pf_prod * w_win
        lin_c = lin_term - lin_term.mean()
        gb_arr_prod = np.array([max(gb_dens[i], 1e-6) for i in valid_idx])
        gb_log = np.log(gb_arr_prod)
        gc_gb = float(np.median(gb_log))   # sigmoid center = median
        k_gb = 4.0                         # steepness (bounded transition)
        w_gb = 1.0 / (1.0 + np.exp(-k_gb * (gb_log - gc_gb)))
        mix_term = w_gb
        mix_c = w_gb - w_gb.mean()
        # v29: 3-term residual (β_pf, β_lin, β_gb) — v30 phase-split was explored
        # (v30/v30.1/v30.2) but LOOCV gain was below noise σ=0.0018 in all variants.
        X_corr = np.column_stack([pf_c, lin_c, mix_c])
        resid = log_sf - pred_pre
        bc = np.linalg.lstsq(X_corr, resid, rcond=None)[0]
        pred = pred_pre + X_corr @ bc
        beta_pf, beta_lin, beta_gb = float(bc[0]), float(bc[1]), float(bc[2])
        beta_mix = beta_gb
        beta_win = beta_lin

        r2 = 1 - np.sum((log_sf - pred)**2) / ss_tot
        n_loo = len(log_sf)
        sse_loo = 0.0
        for ii in range(n_loo):
            mk = np.ones(n_loo, bool); mk[ii] = False
            bv_ = np.linalg.lstsq(X_v5_l[mk], (log_sf - log_rhs_base)[mk], rcond=None)[0]
            bp_ = np.linalg.lstsq(X_p3_l[mk], (log_sf - log_rhs_base)[mk], rcond=None)[0]
            pv9 = (1 - w_bl) * (X_v5_l @ bv_) + w_bl * (X_p3_l @ bp_) + log_rhs_base
            pf_c_mk = w_pf[mk] - w_pf[mk].mean()
            lin_mk = lin_term[mk];  lin_c_mk = lin_mk - lin_mk.mean()
            wgb_mk = w_gb[mk];      wgb_c_mk = wgb_mk - wgb_mk.mean()
            Xc_mk = np.column_stack([pf_c_mk, lin_c_mk, wgb_c_mk])
            bc_mk = np.linalg.lstsq(Xc_mk, (log_sf - pv9)[mk], rcond=None)[0]
            pred_ii = pv9[ii] + bc_mk[0] * (w_pf[ii] - w_pf[mk].mean()) \
                              + bc_mk[1] * (lin_term[ii] - lin_mk.mean()) \
                              + bc_mk[2] * (w_gb[ii] - wgb_mk.mean())
            sse_loo += (log_sf[ii] - pred_ii)**2
        loocv = 1 - sse_loo / ss_tot
        s_act_l = np.exp(log_sf); s_prd_l = np.exp(pred)
        w20 = int(np.sum(np.abs(s_prd_l - s_act_l) / s_act_l < 0.20))
        # Stash β_mix on the function for caller print access
        _fit_at._beta_mix = beta_mix
        return r2, loocv, w20, b_v5_l, b_p3_l, w_bl, pred, beta_pf, beta_win, w_pf

    # v29: continuous 6D optimization — (k_bl, τc_bl, k_pf, pc_pf, τ_c_win, σ_τ_win)
    from scipy.optimize import minimize
    def _neg_loocv(p):
        k_, tc_, kp_, pc_, tcw_, stw_ = p
        if k_ <= 0.1 or k_ > 20 or tc_ < 1.2 or tc_ > 3.0: return 1e6
        if kp_ <= 0.1 or kp_ > 50 or pc_ < 0.1 or pc_ > 0.9: return 1e6
        if tcw_ < 1.2 or tcw_ > 3.0 or stw_ < 0.15 or stw_ > 1.0: return 1e6
        return -_fit_at(k_, tc_, kp_, pc_, tcw_, stw_)[1]
    res = minimize(_neg_loocv, x0=[5.0, 2.0, 10.0, 0.5, 2.0, 0.3], method='Nelder-Mead',
                   options={'xatol': 1e-3, 'fatol': 1e-5, 'maxiter': 600, 'adaptive': True})
    best_k, best_tc, best_kp, best_pc, best_tcw, best_stw = (float(res.x[0]), float(res.x[1]),
                                                              float(res.x[2]), float(res.x[3]),
                                                              float(res.x[4]), float(res.x[5]))
    # Coarse sweep for diagnostic visibility (k_pf/pc_pf fixed at sane defaults)
    k_sweep = [1.5, 2.0, 3.0, 5.0, 8.0, 10.0, 15.0]
    print(f"\n[BLEND SWEEP] coarse k scan at τc=2.0 (k_pf=10, pc_pf=0.5 fixed)")
    print(f"  {'k':>5s}  {'R²':>6s}  {'LOOCV':>6s}  {'±20%':>5s}")
    for k in k_sweep:
        r2_k, lo_k, w20_k, *_ = _fit_at(k, 2.0, 10.0, 0.5, 2.0, 0.3)
        print(f"  {k:5.1f}  {r2_k:.4f}  {lo_k:.4f}  {w20_k:2d}/{len(log_sf):2d}")
    r2_formX, loocv_formX, w20_opt, b_v5, b_p3, w_blend, pred_formX, beta_pf_prod, beta_win_prod, w_pf_prod = \
        _fit_at(best_k, best_tc, best_kp, best_pc, best_tcw, best_stw)
    kappa_area = 0.0
    print(f"  → continuous optimum: k_bl={best_k:.2f}, τc_bl={best_tc:.3f}  |  "
          f"k_pf={best_kp:.2f}, pc_pf={best_pc:.3f}  |  "
          f"τ_c_win={best_tcw:.3f}, σ_τ_win={best_stw:.3f}")
    print(f"    R²={r2_formX:.4f}, LOOCV={loocv_formX:.4f}, ±20%={w20_opt}/{len(log_sf)}")
    _Ct_chk = float(np.exp(b_v5[0])); _Cn_chk = float(np.exp(b_v5[0] + b_v5[1]))
    print(f"    Ct={_Ct_chk:.4f} (thick asymptote)  Cn={_Cn_chk:.4f} (thin asymptote)  "
          f"Ct/Cn={_Ct_chk/_Cn_chk:.2f}")
    print(f"    poly3 coefs = [{b_p3[0]:+.3f}, {b_p3[1]:+.3f}, {b_p3[2]:+.3f}, {b_p3[3]:+.3f}]")
    print(f"    β_pf    = {beta_pf_prod:+.4f}  ← P:S sigmoid amplitude")
    print(f"    β_lin   = {beta_win_prod:+.4f}  ← v28: p_frac × Gaussian bump (linear)")
    print(f"    β_gb    = {float(getattr(_fit_at, '_beta_mix', 0.0)):+.4f}  ← v29: sigmoid(log gb_dens) correction (bounded)")
    TAU_C_BL = best_tc
    TAU_K_BL = best_k

    # ────────────────────────────────────────────────────────────────
    # Export fitted v29 params to module globals.
    # Downstream plots (plot_multiscale_sigma, etc.) read these via
    # _formx_v29_params() → _formx_v29_predict() so they use the SAME
    # Nelder-Mead-optimised v29 as the parity plot above. Without this
    # export, _formx_v29_params() silently falls back to hardcoded
    # defaults which diverge from the fit and produce apparent residuals
    # (the "1mAh_80:20 7:3 under-prediction" was exactly this artifact).
    # ────────────────────────────────────────────────────────────────
    global _GLOBAL_IONIC_SIGMOID, _GLOBAL_IONIC_POLY3, _GLOBAL_PS_SIGMOID
    # v5 sigmoid amplitude + blend params (TAU_C, TAU_K of v5 sigmoid are
    # fixed shape constants, not fit).
    _C_thick_fit = float(np.exp(b_v5[0]))
    _C_thin_fit  = float(np.exp(b_v5[0] + b_v5[1]))
    _GLOBAL_IONIC_SIGMOID = (_C_thick_fit, _C_thin_fit,
                             2.1, 5.0,             # v5 sigmoid τ_c, k (fixed)
                             best_k, best_tc)      # blend K_BL, TC_BL (fit)
    _GLOBAL_IONIC_POLY3 = tuple(float(x) for x in b_p3)

    # Recompute centering means so downstream predictions match fit output.
    _gb_vec = np.array([max(gb_dens[i], 1e-6) for i in valid_idx])
    _gb_log = np.log(_gb_vec)
    _gb_log_med = float(np.median(_gb_log))
    _w_pf_vec  = 1.0 / (1.0 + np.exp(-best_kp * (pf_prod - best_pc)))
    _w_win_vec = np.exp(-0.5 * ((tau_arr - best_tcw) / max(best_stw, 0.05))**2)
    _w_gb_vec  = 1.0 / (1.0 + np.exp(-4.0 * (_gb_log - _gb_log_med)))
    _beta_gb_fit = float(getattr(_fit_at, '_beta_mix', 0.0))
    _GLOBAL_PS_SIGMOID = (
        best_kp, best_pc,                                # K_PF, PC_PF
        beta_pf_prod, beta_win_prod, _beta_gb_fit,       # B_PF, B_LIN, B_GB
        float(_w_pf_vec.mean()),                         # WPF_MEAN
        float((pf_prod * _w_win_vec).mean()),            # LIN_MEAN
        _gb_log_med,                                     # GB_LOG_MEAN
        best_tcw, best_stw,                              # TAU_C_WIN, SIGMA_TAU_WIN
        float(_w_gb_vec.mean()),                         # W_GB_MEAN
    )
    print(f"  [v29 export] globals set: C_thick={_C_thick_fit:.4f}, C_thin={_C_thin_fit:.4f}, "
          f"K_BL={best_k:.2f}, TC_BL={best_tc:.2f}, K_PF={best_kp:.2f}, PC_PF={best_pc:.2f}")

    # === v12 DATA-NATIVE EXPONENT FIT (diagnostic only, does not replace v9) ===
    # Jointly optimize (α, β, γ, δ, φc, k_bl, τc) where:
    #   log σ = log(σ_grain) + α·log(φ-φc) + β·log(CN) + γ·log(cov) + δ·log(fp) + C_blend(τ)
    # v9 fixed (α,β,γ,δ,φc) = (0.75, 1.5, 0.25, 2.0, 0.185). We check if the data
    # prefers different values by LOOCV. If v12 LOOCV > v9 LOOCV, data disagrees
    # with Kirkpatrick/Bruggeman priors. If ≈ same, v9 priors are consistent.
    cn_np = np.array([cn[i] for i in valid_idx], dtype=float)
    cov_np = np.array([coverage[i] for i in valid_idx], dtype=float)
    fp_np = np.array([max(f_perc[i], 0.01) for i in valid_idx], dtype=float)
    phi_np = np.array([phi_se[i] for i in valid_idx], dtype=float)
    ln_sigma = log_sf
    ss_tot_local = ss_tot

    def _loocv_at(params):
        a, b, g, dl, pc, kb, tcb = params
        if pc < 0.05 or pc > 0.30: return 1e6
        if a < 0.1 or a > 3.0: return 1e6
        if b < 0.1 or b > 3.5: return 1e6
        if g < -1.5 or g > 2.5: return 1e6
        if dl < 0.1 or dl > 5.0: return 1e6
        if kb < 0.1 or kb > 20 or tcb < 1.2 or tcb > 3.0: return 1e6
        phi_ex_v = np.maximum(phi_np - pc, 1e-4)
        lrhs = (np.log(SIGMA_BULK) + a*np.log(phi_ex_v) + b*np.log(cn_np)
                + g*np.log(cov_np) + dl*np.log(fp_np))
        w_bl_v = 1.0 / (1.0 + np.exp(-kb * (tau_arr - tcb)))
        X_v = np.column_stack([np.ones(len(ln_sigma)), w_sigmoid])
        X_p = np.column_stack([np.ones(len(ln_sigma)), log_tau_arr,
                                log_tau_arr**2, log_tau_arr**3])
        sse = 0.0
        n_loo = len(ln_sigma)
        for ii in range(n_loo):
            mk = np.ones(n_loo, bool); mk[ii] = False
            bv_ = np.linalg.lstsq(X_v[mk], (ln_sigma - lrhs)[mk], rcond=None)[0]
            bp_ = np.linalg.lstsq(X_p[mk], (ln_sigma - lrhs)[mk], rcond=None)[0]
            p_ii = (1 - w_bl_v[ii]) * (X_v[ii] @ bv_) + w_bl_v[ii] * (X_p[ii] @ bp_) + lrhs[ii]
            sse += (ln_sigma[ii] - p_ii)**2
        return sse / ss_tot_local   # minimize

    # ── v29 FITTED predictions + v32 per-run γ refit ──────────────────
    # v29 is already-fitted (R² ≈ 0.983). v32 γ are OLS-refit against
    # residuals of FITTED predictions so they play well with any v29
    # parameter update. If regime-features unavailable (no
    # dataset_summary.csv), predictions fall back to v29 silently.
    s_pred_v29 = np.exp(pred_formX)
    global _V32_FITTED_GAMMAS
    _V32_FITTED_GAMMAS = None
    try:
        feat_order = list(_V32_GAMMAS.keys())
        X_rows, y_rows = [], []
        for j, i in enumerate(valid_idx):
            feats = _v32_features_for_case(data_list[i])
            if feats is None:
                continue
            σ_net_i = sigma_net[i]
            σ_v29_i = float(s_pred_v29[j])
            if σ_net_i <= 0 or σ_v29_i <= 0:
                continue
            X_rows.append([feats.get(k, 0.0) for k in feat_order])
            y_rows.append(np.log(σ_net_i) - np.log(σ_v29_i))
        if len(X_rows) >= len(feat_order) + 2:
            X_arr = np.array(X_rows)
            y_arr = np.array(y_rows)
            gammas, *_ = np.linalg.lstsq(X_arr, y_arr, rcond=None)
            _V32_FITTED_GAMMAS = dict(zip(feat_order, (float(g) for g in gammas)))
            print(f"  [v32 refit] n_cases_used={len(X_rows)} / {len(valid_idx)}")
            for k, g in _V32_FITTED_GAMMAS.items():
                print(f"    γ({k:13s}) = {g:+.4f}")
    except Exception as _e:
        print(f"  [v32 refit] skipped ({_e}); using hardcoded defaults")
        _V32_FITTED_GAMMAS = None

    # Cache write deferred to main() after the plot loop so we can key on
    # args.names (case IDs) rather than the P:S-ratio label list passed
    # here as `names`. P:S labels are not unique across cases (every 7:3
    # case collides), which made the subset-match lookup trivially true
    # in the wrong direction and trivially false in the right one.

    s_pred = np.array([
        _formx_v32_predict(s_pred_v29[j], data_list[i])
        for j, i in enumerate(valid_idx)
    ])
    r2 = r2_formX
    s_actual = np.array([sigma_net[i] for i in valid_idx])

    # --- Residual diagnostic: find |err|>20% outliers and dump feature signature ---
    # Build per-index group label (e.g. "SE 0.5μm (1mAh_85:15)") + case hint from data source path
    def _case_label(idx):
        grp = ""
        if _GROUP_INFO:
            sizes, gnames = _GROUP_INFO
            pos = 0
            for sz, gn in zip(sizes, gnames):
                if pos <= idx < pos + sz:
                    grp = gn
                    break
                pos += sz
        src = data_list[idx].get("_source_path", "") if idx < len(data_list) else ""
        case_id = os.path.basename(os.path.dirname(src)) if src else ""
        lbl = names[idx] if idx < len(names) else f"idx{idx}"
        return f"{grp} | {case_id} [{lbl}]" if grp or case_id else lbl

    rel_err = (s_pred - s_actual) / s_actual * 100           # log-space (multiplicative) err %
    abs_err = np.abs(rel_err)
    delta_sigma = s_pred - s_actual                           # linear-space absolute gap (mS/cm)
    abs_delta = np.abs(delta_sigma)
    n_total = len(valid_idx)
    rmse_lin = float(np.sqrt(np.mean(delta_sigma**2)))
    mae_lin = float(np.mean(abs_delta))
    print(f"\n[IONIC v9 BLEND DIAG] n={n_total}, R²={r2_formX:.4f}, LOOCV={loocv_formX:.4f}")
    print(f"  log-space : mean|err|={np.mean(abs_err):.1f}%   median|err|={np.median(abs_err):.1f}%")
    print(f"  linear-sp : MAE={mae_lin:.4f} mS/cm   RMSE={rmse_lin:.4f} mS/cm")
    # Tier counts — show both % and absolute
    tiers = [5, 10, 15, 20, 30]
    cnt = {t: int(np.sum(abs_err < t)) for t in tiers}
    print(f"  tiers(%): <5%:{cnt[5]}/{n_total}   <10%:{cnt[10]}/{n_total}   <15%:{cnt[15]}/{n_total}"
          f"   <20%:{cnt[20]}/{n_total}   <30%:{cnt[30]}/{n_total}")
    abs_thresholds_mScm = [0.005, 0.010, 0.020, 0.030, 0.050]
    acnt = {t: int(np.sum(abs_delta < t)) for t in abs_thresholds_mScm}
    print(f"  tiers(Δσ): <0.005:{acnt[0.005]}/{n_total}   <0.010:{acnt[0.010]}/{n_total}   "
          f"<0.020:{acnt[0.020]}/{n_total}   <0.030:{acnt[0.030]}/{n_total}   <0.050:{acnt[0.050]}/{n_total}")

    # ─── TABLE 1: sorted by relative error % (log-space view) ───
    hdr = (f"  {'#':>3s} {'case (group | id [P:S])':70s} "
           f"{'σ_act':>7s} {'σ_pred':>7s} {'Δσ':>8s} {'err%':>7s} "
           f"{'φ_SE':>5s} {'f_p':>5s} {'τ':>5s} {'CN':>5s} {'cov':>5s}")
    print(f"\n  ── sorted by |err%| (log-space; relative; physics-correct) ──")
    print(hdr); print("  " + "-" * (len(hdr)-2))
    pct_sorted = sorted(range(n_total), key=lambda j: -abs_err[j])
    shown = 0
    for rank, j in enumerate(pct_sorted, 1):
        if abs_err[j] <= 10.0:
            continue
        i = valid_idx[j]
        nm = _case_label(i)[:70]
        flag = "  ⚠" if abs_err[j] > 20 else ("  ·" if abs_err[j] > 15 else "")
        print(f"  {rank:3d} {nm:70s} {s_actual[j]:7.4f} {s_pred[j]:7.4f} "
              f"{delta_sigma[j]:+8.4f} {rel_err[j]:+6.1f}% "
              f"{phi_se[i]:5.3f} {f_perc[i]:5.3f} {tau[i]:5.2f} {cn[i]:5.2f} {cov_arr[j]:5.3f}{flag}")
        shown += 1
    print(f"  ({shown} cases with |err|>10%, remaining {n_total - shown} are within ±10%)")

    # ─── TABLE 2: sorted by absolute gap Δσ (linear-space; matches what plot shows) ───
    print(f"\n  ── sorted by |Δσ| mS/cm (linear-space; absolute; matches plot visual) ──")
    print(hdr); print("  " + "-" * (len(hdr)-2))
    abs_sorted = sorted(range(n_total), key=lambda j: -abs_delta[j])
    shown2 = 0
    # Threshold: top 15 OR |Δσ| > 0.015 (whichever larger) — matches plot visibility
    delta_thr = 0.015
    for rank, j in enumerate(abs_sorted, 1):
        if abs_delta[j] <= delta_thr and shown2 >= 15:
            break
        i = valid_idx[j]
        nm = _case_label(i)[:70]
        flag = "  ⚠" if abs_delta[j] > 0.030 else ("  ·" if abs_delta[j] > 0.020 else "")
        print(f"  {rank:3d} {nm:70s} {s_actual[j]:7.4f} {s_pred[j]:7.4f} "
              f"{delta_sigma[j]:+8.4f} {rel_err[j]:+6.1f}% "
              f"{phi_se[i]:5.3f} {f_perc[i]:5.3f} {tau[i]:5.2f} {cn[i]:5.2f} {cov_arr[j]:5.3f}{flag}")
        shown2 += 1
    print(f"  ({shown2} shown; threshold |Δσ|>{delta_thr} or top-15)")

    # ─── Sign-pattern breakdown: how many over vs under, by magnitude tier ───
    over_mask = delta_sigma > 0
    under_mask = delta_sigma < 0
    print(f"\n  ── sign bias: over (pred>act) vs under (pred<act) ──")
    print(f"  |Δσ|>0.010:  over {int(np.sum(over_mask & (abs_delta > 0.010))):>3d}    under {int(np.sum(under_mask & (abs_delta > 0.010))):>3d}")
    print(f"  |Δσ|>0.020:  over {int(np.sum(over_mask & (abs_delta > 0.020))):>3d}    under {int(np.sum(under_mask & (abs_delta > 0.020))):>3d}")
    print(f"  |Δσ|>0.030:  over {int(np.sum(over_mask & (abs_delta > 0.030))):>3d}    under {int(np.sum(under_mask & (abs_delta > 0.030))):>3d}")
    print(f"  mean(Δσ) = {float(np.mean(delta_sigma)):+.4f}  ← if far from 0, systematic bias")
    # Residual-vs-feature correlation (Pearson on log-residual)
    log_res = np.log(s_pred) - np.log(s_actual)
    gb_arr = np.array([gb_dens[i] for i in valid_idx])
    gp_arr = np.array([g_path[i] for i in valid_idx])

    # Parse P:S ratio → particulate fraction
    def _parse_ps(d):
        ps = d.get("ps_ratio", "") or ""
        if ps in ("P only", "10:0"): return 1.0
        if ps in ("S only", "0:10"): return 0.0
        if ":" in ps:
            try:
                p, s = ps.split(":")
                p, s = float(p), float(s)
                return p / (p + s) if (p + s) > 0 else 0.5
            except Exception:
                return 0.5
        return 0.5
    p_frac_arr = np.array([_parse_ps(data_list[i]) for i in valid_idx])

    # AM-side morphology (previously unused)
    am_se_cn = np.array([_get(data_list[i], "am_se_cn_mean", 0) for i in valid_idx], dtype=float)
    am_am_cn = np.array([_get(data_list[i], "am_am_cn", 0) for i in valid_idx], dtype=float)
    am_am_area = np.array([_get(data_list[i], "am_am_mean_area", 0) for i in valid_idx], dtype=float)
    cn_ratio = np.divide(cn_arr, np.maximum(am_se_cn, 0.1))

    # ── HETEROGENEITY (std/cv) — mean-field model misses this ──
    cn_std = np.array([_get(data_list[i], "se_se_cn_std", 0) for i in valid_idx], dtype=float)
    tau_std = np.array([_get(data_list[i], "tortuosity_std", 0) for i in valid_idx], dtype=float)
    # coefficient of variation (dimensionless)
    cn_cv = np.divide(cn_std, np.maximum(cn_arr, 0.1))
    tau_cv = np.divide(tau_std, np.maximum(tau_arr, 0.1))
    am_am_cn_std = np.array([_get(data_list[i], "am_am_cn_std", 0) for i in valid_idx], dtype=float)

    # ── MECHANICAL STRESS / FORCE ──
    #   LHS-33 — 무효 · 미정의 stress_cv 는 NaN (옛 판 `_get(…, 0)` 은 0 으로 상관에 섞었다) → 아래 상관에서 그 케이스를 뺀다
    stress_cv = np.array([_stress_cv_feature(data_list[i]) for i in valid_idx], dtype=float)
    stress_z = np.array([_get(data_list[i], "stress_z_layer_cv", 0) for i in valid_idx], dtype=float)

    # ── R_BULK CYLINDRICAL-APPROXIMATION PROXY ──
    # Network solver uses R_cyl ≈ ρ·d/(π·a²); true R_sph = ρ/(2a).
    # Ratio R_cyl/R_sph ∝ 1/sqrt(A) → small contact area = big σ_net bias.
    # path_hop_area_mean is the per-hop contact area along percolating paths.
    hop_area = np.array([_get(data_list[i], "path_hop_area_mean", 0) for i in valid_idx], dtype=float)
    se_se_area = np.array([_get(data_list[i], "area_SE_SE_mean", 0) for i in valid_idx], dtype=float)

    feats = {'log(phi_ex)': np.log(phi_ex_arr), 'log(CN)': np.log(cn_arr),
             'log(tau)': log_tau_arr, 'log(cov)': np.log(cov_arr),
             'log(fp)': np.log(fp_arr),
             'log(gb_dens)': np.log(np.maximum(gb_arr, 1e-10)),
             'log(g_path)': np.log(np.maximum(gp_arr, 1e-10)),
             'p_frac (P:S)': p_frac_arr,
             '(p_frac)²': p_frac_arr**2,
             # AM-side morphology
             'log(am_se_cn)':  np.log(np.maximum(am_se_cn, 0.1)),
             'log(am_am_cn)':  np.log(np.maximum(am_am_cn, 0.1)),
             'log(se_cn/am_se_cn)': np.log(np.maximum(cn_ratio, 1e-3)),
             # ── NEW HETEROGENEITY (std/CV) ──
             'CN_cv (std/mean)':    cn_cv,
             'τ_cv (std/mean)':     tau_cv,
             'log(CN_std)':         np.log(np.maximum(cn_std, 1e-3)),
             'log(τ_std)':          np.log(np.maximum(tau_std, 1e-3)),
             'log(am_am_cn_std)':   np.log(np.maximum(am_am_cn_std, 1e-3)),
             # ── NEW MECHANICAL ──
             'stress_cv':           stress_cv,
             'stress_z_layer_cv':   stress_z,
             # ── Saturation probe: near-percolation sensitivity ──
             'log(1-fp)':           np.log(np.maximum(1.0 - fp_arr, 1e-4)),
             # ── R_BULK CYLINDRICAL APPROXIMATION PROXY ──
             'log(hop_area)':       np.log(np.maximum(hop_area, 1e-10)),
             '1/sqrt(hop_area)':    1.0 / np.sqrt(np.maximum(hop_area, 1e-10)),
             'log(se_se_area)':     np.log(np.maximum(se_se_area, 1e-10))}
    print("  residual(log) correlations:")
    for nm, v in feats.items():
        _m = np.isfinite(v) & np.isfinite(log_res)          # LHS-33 — 무효 stress_cv (NaN) 케이스는 그 특징의 상관에서만 뺀다
        if _m.all():
            c = np.corrcoef(log_res, v)[0, 1] if np.std(v) > 0 else 0.0
        else:
            c = np.corrcoef(log_res[_m], v[_m])[0, 1] if (_m.sum() > 2 and np.std(v[_m]) > 0) else 0.0
        flag = " ⚠" if abs(c) > 0.3 else ""
        print(f"    {nm:12s} r = {c:+.3f}{flag}")
    print()

    fig, ax = plt.subplots(figsize=FIG_SINGLE)

    # Group colors
    point_groups = [0] * len(valid_idx)
    group_boundaries = []
    if _GROUP_INFO:
        sizes, gnames = _GROUP_INFO
        pos = 0
        for sz in sizes:
            group_boundaries.append((pos, pos + sz))
            pos += sz
        for j, i in enumerate(valid_idx):
            for g_idx, (start, end) in enumerate(group_boundaries):
                if start <= i < end:
                    point_groups[j] = g_idx
                    break

    # Mark |err|>20% cases with a subtle darker edge (no overlay)
    is_outlier = np.abs((s_pred - s_actual) / s_actual) > 0.20

    if _GROUP_INFO:
        for j in range(len(valid_idx)):
            gi = point_groups[j]
            edge = '#444' if is_outlier[j] else 'white'
            lw = 1.8 if is_outlier[j] else 1.5
            ax.scatter(s_actual[j], s_pred[j], s=100,
                      c=GROUP_COLORS[gi % len(GROUP_COLORS)],
                      zorder=5, edgecolors=edge, linewidth=lw)
    else:
        ax.scatter(s_actual, s_pred, s=100, c=BLUE, zorder=5,
                  edgecolors='white', linewidth=1.5)

    # 1:1 line
    all_vals = np.concatenate([s_pred, s_actual])
    vmin, vmax = all_vals[all_vals > 0].min() * 0.5, all_vals.max() * 2
    ax.plot([vmin, vmax], [vmin, vmax], 'k--', linewidth=1.5, alpha=0.5, label='1:1 line')

    # ±20% band
    ax.fill_between([vmin, vmax], [vmin*0.8, vmax*0.8], [vmin*1.2, vmax*1.2],
                    alpha=0.1, color='green', label='±20%')

    # Group legend (no per-point labels to avoid MemoryError with adjustText on 41+ points)
    if _GROUP_INFO:
        from matplotlib.patches import Patch
        legend_patches = []
        for gi, (start, end) in enumerate(group_boundaries):
            group_js = [j for j, i in enumerate(valid_idx) if start <= i < end]
            if group_js:
                color = GROUP_COLORS[gi % len(GROUP_COLORS)]
                legend_patches.append(Patch(facecolor=color, label=gnames[gi]))
        if legend_patches:
            ax.legend(handles=legend_patches + [
                plt.Line2D([0], [0], linestyle='--', color='black', label='1:1 line'),
            ], fontsize=7, loc='upper left', ncol=1)

    # R²
    log_pred = np.log(s_pred[s_pred > 0])
    log_actual = np.log(s_actual[s_actual > 0])
    if len(log_pred) > 2:
        ss_res = np.sum((log_pred - log_actual)**2)
        ss_tot = np.sum((log_actual - np.mean(log_actual))**2)
        r2 = 1 - ss_res / ss_tot if ss_tot > 0 else 0
    else:
        r2 = 0

    # Error stats
    errors = np.abs(s_pred - s_actual) / s_actual * 100
    within_20 = np.sum(errors < 20)

    ax.set_xscale('log')
    ax.set_yscale('log')
    ax.set_xlabel("σ_actual (Network solver, mS/cm)", fontsize=11)
    ax.set_ylabel("σ_predicted (Scaling law, mS/cm)", fontsize=11)
    # Title reads the ACTUAL γ being applied (refitted per-run if OLS converged,
    # else hardcoded defaults). Previously the coefficients were baked into the
    # text as -0.75/+1.62/-1.99/+0.35, which misled readers after a refit.
    _g = _V32_FITTED_GAMMAS if _V32_FITTED_GAMMAS is not None else _V32_GAMMAS
    _refit_tag = 'refit' if _V32_FITTED_GAMMAS is not None else 'default'
    _title_formula = (f"σ_ion — v12-clean v3 (=v29/v32) × exp("
                      f"{_g['LIGG_LB_PCT']:+.2f}·LIGG_LB "
                      f"{_g['THIN_X_GEOM']:+.2f}·w_thin·GEOM "
                      f"{_g['P50_DR_DEV']:+.2f}·(p50_dR-0.2) "
                      f"{_g['PSD_RATIO']:+.2f}·r_SE/r_AM)  [γ:{_refit_tag}]")
    ax.set_title(f"{_title_formula}\n"
                 f"τ-blend(k={best_k:.0f},τc={best_tc:.2f})  P:S(k={best_kp:.0f},pc={best_pc:.2f},β={beta_pf_prod:+.3f})  κ_A={kappa_area:+.3f}  R²={r2:.3f} (v32-applied)  |  v29_base R²={r2_formX:.3f} LOOCV={loocv_formX:.3f}",
                 fontsize=8, fontweight='bold')
    ax.legend(fontsize=9, loc='upper left')

    txt = (f"R²={r2:.3f} (n={len(valid_idx)})\n"
           f"|err|={np.mean(errors):.0f}%, ≤20%: {within_20}/{len(errors)}")
    ax.text(0.95, 0.05, txt, transform=ax.transAxes, fontsize=9,
            ha='right', va='bottom',
            bbox=dict(boxstyle='round,pad=0.3', facecolor='white', alpha=0.8))

    ax.set_xlim(vmin, vmax)
    ax.set_ylim(vmin, vmax)
    ax.set_aspect('equal')
    ax.yaxis.grid(True, linestyle='--', alpha=0.3)
    ax.xaxis.grid(True, linestyle='--', alpha=0.3)
    ax.spines['top'].set_visible(False)
    ax.spines['right'].set_visible(False)

    _write_csv(outdir, 'ionic_scaling_fit.csv',
               ['σ_actual(mS/cm)', 'σ_predicted(mS/cm)', 'error(%)'],
               [names[i] for i in valid_idx],
               list(s_actual), list(s_pred), list(errors))
    outpath = _save(fig, outdir, "ionic_scaling_fit.png")
    real_all = (_REAL_NAMES if (_REAL_NAMES and len(_REAL_NAMES) == len(data_list))
                else list(names))
    _focus_parity(outdir, "ionic_scaling_fit", s_actual, s_pred,
                  [real_all[i] for i in valid_idx],
                  'σ_actual (Network solver, mS/cm)',
                  'σ_predicted (Scaling law, mS/cm)',
                  "선택 샘플만 — Hertzian v12-clean v3 식·계수 전체 fit 그대로 "
                  "(n=%d, R²=%.3f)" % (len(valid_idx), r2))
    return outpath


def plot_network_sigma(data_list, names, outdir):
    """Part II: Network solver σ_full (ground truth)."""
    SIGMA_BULK = 3.0  # σ_grain (grain interior)
    sigma_net = _load_network_sigma(data_list)
    sigma_brug_abs = [_get(d, "sigma_ratio") * SIGMA_BULK for d in data_list]

    if not any(s > 0 for s in sigma_net):
        return None

    fig, ax = plt.subplots(figsize=FIG_SINGLE)
    x = np.arange(len(names))
    ms = _marker_size(len(names))
    lw = _line_width(len(names))

    ax.plot(x, sigma_net, 's-', color='#2ecc71', markersize=ms, linewidth=lw,
            label="σ_full (network)")
    ax.plot(x, sigma_brug_abs, 'o--', color=BLUE, markersize=ms-2, linewidth=lw-0.5,
            alpha=0.5, label="σ_brug (Bruggeman)")
    _apply_style(ax, "σ_ionic (mS/cm)", names)
    ax.legend(fontsize=9, loc='upper left')
    ax.set_title("Part II: Network Solver σ_full vs Bruggeman σ_brug",
                 fontsize=10, fontweight='bold')

    # R_brug annotation
    r_brugs = [sigma_brug_abs[i]/sigma_net[i] if sigma_net[i] > 0 else 0 for i in range(len(names))]
    valid_r = [r for r in r_brugs if r > 0]
    if valid_r:
        ax.text(0.95, 0.95, f"R_brug = {min(valid_r):.1f}~{max(valid_r):.1f}×\n(Bruggeman overestimation)",
                transform=ax.transAxes, fontsize=9, ha='right', va='top',
                bbox=dict(boxstyle='round,pad=0.4', facecolor='white', alpha=0.8))

    _write_csv(outdir, 'network_sigma.csv',
               ['σ_brug(mS/cm)', 'σ_full(mS/cm)', 'R_brug'],
               names, sigma_brug_abs, sigma_net, r_brugs)
    return _save(fig, outdir, "network_sigma.png")


# ============================================================================
# FORM X v29 — SINGLE SOURCE OF TRUTH PREDICTION
# ============================================================================
# Shared by plot_multiscale_sigma (and can be reused by predictor_engine etc).
# Reads hyperparameters from module globals set by plot_ionic_scaling_fit.
# Any future changes to the v29 formula should ONLY touch this function and
# the fit function's residual computation — they must stay in lock-step.

def _formx_v29_params():
    """Load all v29 hyperparameters from module globals with legacy fallbacks.
    Returns a dict; centralizes the global-unpacking logic."""
    # C(τ) v5 asymptote + τ-blend coefficients
    TAU_C, TAU_K = 2.1, 5.0
    K_BL, TC_BL = 20.0, 2.044
    C_thick, C_thin = 0.029, 0.017
    if _GLOBAL_IONIC_SIGMOID is not None:
        if len(_GLOBAL_IONIC_SIGMOID) >= 6:
            C_thick, C_thin, TAU_C, TAU_K, K_BL, TC_BL = _GLOBAL_IONIC_SIGMOID[:6]
        else:
            C_thick, C_thin, TAU_C, TAU_K = _GLOBAL_IONIC_SIGMOID[:4]
    elif _GLOBAL_C_ION is not None:
        C_thick = _GLOBAL_C_ION; C_thin = C_thick * 0.54
    # poly3 coefs for blend
    p3 = _GLOBAL_IONIC_POLY3 if _GLOBAL_IONIC_POLY3 is not None \
         else (-3.80, +2.38, -5.58, +2.81)
    # P:S sigmoid + τ-bump + gb_dens sigmoid (residual correction)
    K_PF, PC_PF, B_PF, B_LIN, B_GB = 50.0, 0.598, -0.10, -0.49, 0.043
    WPF_MEAN, LIN_MEAN, GB_LOG_MEAN = 0.5, 0.05, -5.0
    TAU_C_WIN, SIGMA_TAU_WIN = 2.0, 0.15
    W_GB_MEAN = 0.5
    # v30 phase-split params (β_ps · w_thin(τ) · log(cov_P/cov_S))
    B_PS = 0.0; TAU_C_PS = 1.8; K_PS = 10.0; PS_MEAN = 0.0
    if _GLOBAL_PS_SIGMOID is not None:
        n = len(_GLOBAL_PS_SIGMOID)
        if n == 15:
            (K_PF, PC_PF, B_PF, B_LIN, B_GB,
             WPF_MEAN, LIN_MEAN, GB_LOG_MEAN,
             TAU_C_WIN, SIGMA_TAU_WIN, W_GB_MEAN,
             B_PS, TAU_C_PS, K_PS, PS_MEAN) = _GLOBAL_PS_SIGMOID
        elif n == 11:
            (K_PF, PC_PF, B_PF, B_LIN, B_GB,
             WPF_MEAN, LIN_MEAN, GB_LOG_MEAN,
             TAU_C_WIN, SIGMA_TAU_WIN, W_GB_MEAN) = _GLOBAL_PS_SIGMOID
        elif n == 10:
            (K_PF, PC_PF, B_PF, B_LIN, B_GB,
             WPF_MEAN, LIN_MEAN, GB_LOG_MEAN,
             TAU_C_WIN, SIGMA_TAU_WIN) = _GLOBAL_PS_SIGMOID
    return dict(
        SIGMA_BULK=3.0, PHI_C=0.20,
        C_thick=C_thick, C_thin=C_thin, TAU_C=TAU_C, TAU_K=TAU_K,
        K_BL=K_BL, TC_BL=TC_BL, p3=p3,
        K_PF=K_PF, PC_PF=PC_PF, B_PF=B_PF, B_LIN=B_LIN, B_GB=B_GB,
        WPF_MEAN=WPF_MEAN, LIN_MEAN=LIN_MEAN, GB_LOG_MEAN=GB_LOG_MEAN,
        TAU_C_WIN=TAU_C_WIN, SIGMA_TAU_WIN=SIGMA_TAU_WIN, W_GB_MEAN=W_GB_MEAN,
        B_PS=B_PS, TAU_C_PS=TAU_C_PS, K_PS=K_PS, PS_MEAN=PS_MEAN,
    )


def _formx_v29_predict(phi_se, cn, tau, coverage, f_perc, p_frac, gb_dens,
                        area_p=0.0, area_s=0.0, params=None):
    """Single source of truth for v29 FORM X prediction.
    area_p / area_s kept in signature for backward compat; v29 FINAL doesn't use them.
    Returns σ (mS/cm); 0 if core inputs invalid."""
    if not (cn > 0 and tau > 0 and coverage > 0):
        return 0.0
    p = params if params is not None else _formx_v29_params()
    phi_ex = max(phi_se - p['PHI_C'], 1e-4)
    # C(τ): v5 sigmoid asymptote ⊕ poly3 blend
    w_v5 = 1.0 / (1.0 + np.exp(-p['TAU_K'] * (tau - p['TAU_C'])))
    w_bl = 1.0 / (1.0 + np.exp(-p['K_BL'] * (tau - p['TC_BL'])))
    ln_C_v5 = np.log(p['C_thick']) + (np.log(p['C_thin']) - np.log(p['C_thick'])) * w_v5
    lt = np.log(tau)
    ln_C_p3 = p['p3'][0] + p['p3'][1]*lt + p['p3'][2]*lt**2 + p['p3'][3]*lt**3
    ln_C = (1 - w_bl) * ln_C_v5 + w_bl * ln_C_p3
    # Base Kirkpatrick scaling (α=1/2, β=3/2, γ=2/5, δ=3, φc=0.20)
    s = (np.exp(ln_C) * p['SIGMA_BULK']
         * phi_ex**0.5 * cn**1.5 * coverage**0.4 * f_perc**3)
    # Residual correction: β_pf·w_pf + β_lin·p·w_win + β_gb·w_gb + β_ps·w_thin·log(cov_P/cov_S)
    w_pf = 1.0 / (1.0 + np.exp(-p['K_PF'] * (p_frac - p['PC_PF'])))
    w_win = np.exp(-0.5 * ((tau - p['TAU_C_WIN']) / max(p['SIGMA_TAU_WIN'], 0.05))**2)
    w_gb = 1.0 / (1.0 + np.exp(-4.0 * (np.log(max(gb_dens, 1e-6)) - p['GB_LOG_MEAN'])))
    # v29 FINAL: 3-term residual correction (no phase-split β_ps)
    ps_corr = (p['B_PF']  * (w_pf - p['WPF_MEAN'])
             + p['B_LIN'] * (p_frac * w_win - p['LIN_MEAN'])
             + p['B_GB']  * (w_gb - p['W_GB_MEAN']))
    return s * np.exp(ps_corr)


def _ps_fraction(d):
    """Parse P:S ratio string to fraction of P (carbon). Shared across plots."""
    ps = (d.get("ps_ratio", "") or "")
    if ps in ("P only", "10:0"): return 1.0
    if ps in ("S only", "0:10"): return 0.0
    if ":" in ps:
        try:
            p, s = ps.split(":"); p, s = float(p), float(s)
            return p / (p + s) if (p + s) > 0 else 0.5
        except Exception:
            return 0.5
    return 0.5


# ──────────────────────────────────────────────────────────────
# v32 correction (4-term, fit from Apr-2026 exhaustive refit)
# Applied as  σ_v32 = σ_v29 × exp(Σ γ_i · feature_i)
# ──────────────────────────────────────────────────────────────
_V32_GAMMAS = {
    'LIGG_LB_PCT': -0.750,  # DEM-native dominance (normalised /35)
    'THIN_X_GEOM': +1.619,  # thin × hemisphere cap (normalised /20)
    'P50_DR_DEV':  -1.992,  # median δ/R* deviation from 0.20
    'PSD_RATIO':   +0.348,  # r_SE / r_AM_avg
}
_V32_T_CHAR = 30.0  # μm, thin-regime characteristic length

# Set inside plot_ionic_scaling_fit after v29 Nelder-Mead converges, by
# refitting γ on residuals of the FITTED v29 predictions. When populated,
# _formx_v32_predict() uses these instead of the hardcoded defaults above,
# avoiding the double-correction that degraded R² 0.983 → 0.976 when the
# hardcoded (defaults-calibrated) γ were applied on top of v29 FITTED.
_V32_FITTED_GAMMAS = None


def _load_v32_regime_table():
    """Load dataset_summary.csv once (case_id → {p50_dr, geom_pct, liggghts_lb_pct}).
    Returns {} if missing — v32 then falls back to v29 silently."""
    import os
    p = os.path.join('docs', 'figures', 'physics_regime', 'dataset_summary.csv')
    if not os.path.exists(p):
        return {}
    try:
        import csv
        out = {}
        with open(p) as f:
            for row in csv.DictReader(f):
                out[row.get('case_id', '')] = {
                    'p50_dr':       float(row.get('p50_dr') or 0),
                    'geom_pct':     float(row.get('geom') or 0),
                    'liggghts_lb_pct': float(row.get('liggghts_lb') or 0),
                }
        return out
    except Exception:
        return {}


_V32_REGIME_TABLE = None  # lazy-loaded


def _v32_features_for_case(data):
    """Compute v32 correction features from a single full_metrics dict.
    Returns None if required fields missing (falls back to v29)."""
    global _V32_REGIME_TABLE
    if _V32_REGIME_TABLE is None:
        _V32_REGIME_TABLE = _load_v32_regime_table()

    import os, json
    src = data.get("_source_path", "") or ""
    # case_id = parent directory of full_metrics.json
    case_id = os.path.basename(os.path.dirname(src)) if src else ""

    # Thickness
    T = _get(data, "thickness_um", 0) or 0
    if T <= 0:
        return None
    w_thin = np.exp(-T / _V32_T_CHAR)

    # Regime-cap features (p50_dr, geom_pct, liggghts_lb_pct)
    reg = _V32_REGIME_TABLE.get(case_id, {})
    p50_dr      = reg.get('p50_dr', 0.20)       # assume plastic threshold as default
    geom_pct    = reg.get('geom_pct', 0)
    liggghts_lb = reg.get('liggghts_lb_pct', 0)

    # PSD ratio — load input_params.json (r_SE / r_AM_avg)
    r_SE_r = r_AM_avg = 0
    if src:
        ip_path = os.path.join(os.path.dirname(src), 'input_params.json')
        if os.path.exists(ip_path):
            try:
                ip = json.load(open(ip_path))
                r_SE_r = ip.get('r_SE', 0) or 0
                r_p = ip.get('r_AM_P')
                r_s = ip.get('r_AM_S')
                rvals = [v for v in (r_p, r_s) if v]
                r_AM_avg = (sum(rvals) / len(rvals)) if rvals else 0
            except Exception:
                pass
    psd_ratio = (r_SE_r / r_AM_avg) if r_AM_avg > 0 else 0.1

    return {
        'LIGG_LB_PCT': liggghts_lb / 35.0,
        'THIN_X_GEOM': w_thin * (geom_pct / 20.0),
        'P50_DR_DEV':  p50_dr - 0.20,
        'PSD_RATIO':   psd_ratio,
    }


def _formx_v32_predict(sigma_v29, data):
    """Apply v32 4-term correction to v29 prediction.
    If regime features missing, returns v29 unchanged (silent passthrough).

    Uses _V32_FITTED_GAMMAS when populated (per-run refit by
    plot_ionic_scaling_fit → avoids double-correction). Falls back to
    the hardcoded _V32_GAMMAS when run standalone without a prior fit."""
    if sigma_v29 <= 0:
        return sigma_v29
    feats = _v32_features_for_case(data)
    if feats is None:
        return sigma_v29
    gammas = _V32_FITTED_GAMMAS if _V32_FITTED_GAMMAS is not None else _V32_GAMMAS
    log_corr = sum(gammas[k] * feats.get(k, 0.0) for k in gammas)
    return sigma_v29 * np.exp(log_corr)


def plot_multiscale_sigma(data_list, names, outdir):
    """FORM X v29: delegates prediction to _formx_v29_predict (single source of
    truth with plot_ionic_scaling_fit). Reads fitted hyperparams from globals."""
    # Consistency warning: v29 globals are set by plot_ionic_scaling_fit. If
    # they are still None, we fall back to hardcoded v29 defaults, which no
    # longer match whatever γ the parity plot is showing.
    if _GLOBAL_IONIC_SIGMOID is None:
        print("  [multiscale] WARNING: v29 globals not set — include "
              "'ionic_scaling_fit' in the plot list for consistent rendering.")

    phi_se = [_get(d, "phi_se") for d in data_list]
    cn = [_get(d, "se_se_cn", 0) for d in data_list]
    tau = [_get(d, "tortuosity_recommended", _get(d, "tortuosity_mean", 1)) for d in data_list]
    coverage = [(lambda vs: sum(vs)/len(vs)/100 if vs else 0.20)([v for v in [_get(d,"coverage_AM_P_mean",0), _get(d,"coverage_AM_S_mean",0), _get(d,"coverage_AM_mean",0)] if v>0]) for d in data_list]
    f_perc = [max(_get(d, "percolation_pct", 100) / 100, 0.01) for d in data_list]
    sigma_net = _load_network_sigma(data_list)

    # Compute predictions via shared helper (matches fit by construction)
    p = _formx_v29_params()
    sigma_v29_raw = [
        _formx_v29_predict(
            phi_se[i], cn[i], tau[i], coverage[i], f_perc[i],
            _ps_fraction(data_list[i]),
            _get(data_list[i], "gb_density_mean", 1e-6),
            area_p=_get(data_list[i], "area_AM_P_SE_mean", 0.0),
            area_s=_get(data_list[i], "area_AM_S_SE_mean", 0.0),
            params=p,
        )
        for i in range(len(data_list))
    ]
    # v32 correction applied on top of v29 — per-case features pulled from
    # dataset_summary.csv (physics-regime caps) + input_params (PSD ratio).
    # Cases without regime data fall back to v29 silently.
    #
    # If plot_ionic_scaling_fit has not populated _V32_FITTED_GAMMAS yet
    # (e.g. user requested multiscale without parity), do our own OLS
    # refit here so we don't apply stale hardcoded γ that were fit on a
    # different case population.
    global _V32_FITTED_GAMMAS
    if _V32_FITTED_GAMMAS is None:
        try:
            feat_order = list(_V32_GAMMAS.keys())
            X_rows, y_rows = [], []
            for i, d in enumerate(data_list):
                feats = _v32_features_for_case(d)
                if feats is None: continue
                σn = sigma_net[i]; σv = sigma_v29_raw[i]
                if σn <= 0 or σv <= 0: continue
                X_rows.append([feats.get(k, 0.0) for k in feat_order])
                y_rows.append(np.log(σn) - np.log(σv))
            if len(X_rows) >= len(feat_order) + 2:
                gammas, *_ = np.linalg.lstsq(np.array(X_rows), np.array(y_rows), rcond=None)
                _V32_FITTED_GAMMAS = dict(zip(feat_order, (float(g) for g in gammas)))
                print(f"  [multiscale→v32 refit] n={len(X_rows)}  "
                      + "  ".join(f"γ({k})={g:+.3f}" for k, g in _V32_FITTED_GAMMAS.items()))
        except Exception as _e:
            print(f"  [multiscale→v32 refit] skipped: {_e}")

    sigma_ms = [
        _formx_v32_predict(sigma_v29_raw[i], data_list[i])
        for i in range(len(data_list))
    ]

    has_net = any(s > 0 for s in sigma_net)

    fig, ax = plt.subplots(figsize=FIG_SINGLE)
    x = np.arange(len(names))
    ms = _marker_size(len(names))
    lw = _line_width(len(names))

    ax.plot(x, sigma_ms, 's-', color=RED, markersize=ms, linewidth=lw,
            label="v12-clean v3 (mS/cm)")
    # ±22% error band (DEM stochastic variability)
    _ms_arr = np.array(sigma_ms)
    _ms_lo = _ms_arr * 0.78; _ms_hi = _ms_arr * 1.22
    ax.fill_between(x, _ms_lo, _ms_hi, color=RED, alpha=0.10, label='±22% band')
    if has_net:
        ax.plot(x, sigma_net, 'D--', color='#2ecc71', markersize=ms-2, linewidth=lw-0.5,
                alpha=0.7, label="Network solver (mS/cm)")
        # Outlier mark: rel>20% OR |Δσ|>0.025 (catches BOTH log-space %
        # and linear-space absolute outliers — user asked for dual visibility)
        _net_arr = np.array(sigma_net, dtype=float)
        with np.errstate(divide='ignore', invalid='ignore'):
            rel = np.where(_net_arr > 0, np.abs(_ms_arr - _net_arr) / _net_arr, 0.0)
        abs_gap = np.abs(_ms_arr - _net_arr)
        out_mask = (rel > 0.20) | (abs_gap > 0.025)
        if np.any(out_mask):
            y_top = max(np.nanmax(_ms_hi), np.nanmax(_net_arr)) * 1.03
            ax.scatter(x[out_mask], [y_top] * int(out_mask.sum()),
                       marker='*', s=40, color='#888', zorder=3, clip_on=False)

    _apply_style(ax, "σ_ionic (mS/cm)", names)
    ax.legend(fontsize=9, loc='upper left')
    # Dynamic title: show the γ actually used (refit or hardcoded default).
    _g2 = _V32_FITTED_GAMMAS if _V32_FITTED_GAMMAS is not None else _V32_GAMMAS
    _tag2 = 'refit' if _V32_FITTED_GAMMAS is not None else 'default'
    ax.set_title(
        f"σ_ion — v12-clean v3 (=v29/v32) × exp("
        f"{_g2['LIGG_LB_PCT']:+.2f}·LIGG_LB "
        f"{_g2['THIN_X_GEOM']:+.2f}·w_thin·GEOM "
        f"{_g2['P50_DR_DEV']:+.2f}·(p50_dR-0.2) "
        f"{_g2['PSD_RATIO']:+.2f}·r_SE/r_AM)  [γ:{_tag2}]",
        fontsize=8.5, fontweight='bold')

    # Unified y-axis: if user/webapp passed --y-max-sigma, use it for cross-run
    # visual comparison. Otherwise auto-scale to current data (tight view).
    if _Y_MAX_SIGMA is not None and _Y_MAX_SIGMA > 0:
        ax.set_ylim(0, _Y_MAX_SIGMA)
    else:
        # Auto-compute: 10% headroom above max of (FORM X + ±22%) and network
        _candidates = [float(np.nanmax(_ms_hi))] if len(_ms_hi) else []
        if has_net:
            _net_max = float(np.nanmax(np.array(sigma_net, dtype=float)))
            if np.isfinite(_net_max):
                _candidates.append(_net_max)
        if _candidates:
            ax.set_ylim(0, max(_candidates) * 1.10)

    _write_csv(outdir, 'multiscale_sigma.csv',
               ['φ_SE', 'CN', 'τ', 'coverage', 'σ_v32(mS/cm)', 'σ_v29(mS/cm)', 'σ_network(mS/cm)'],
               names, phi_se, cn, tau, coverage, sigma_ms, sigma_v29_raw, sigma_net)
    return _save(fig, outdir, "multiscale_sigma.png")


def plot_v3_fitting(data_list, names, outdir):
    """[Legacy] v3: σ_brug × C × (G_path × GB_d²)^(1/4) × CN²."""
    SIGMA_BULK = 3.0
    sigma_brug = [_get(d, "sigma_ratio") for d in data_list]
    gb_dens = [_get(d, "gb_density_mean") for d in data_list]
    g_path = [_get(d, "path_conductance_mean", 0) for d in data_list]
    cn = [_get(d, "se_se_cn", 0) for d in data_list]
    sigma_net = _load_network_sigma(data_list)

    valid = [i for i in range(len(data_list))
             if g_path[i]>0 and cn[i]>0 and gb_dens[i]>0 and sigma_brug[i]>0 and sigma_net[i]>0.01]
    if len(valid) < 3:
        C_v3 = 0.073
    else:
        log_rhs = np.array([np.log(sigma_brug[i]*SIGMA_BULK) + 0.25*np.log(g_path[i]*gb_dens[i]**2) + 2*np.log(cn[i]) for i in valid])
        log_act = np.array([np.log(sigma_net[i]) for i in valid])
        C_v3 = np.exp(np.mean(log_act - log_rhs))

    sigma_v3 = []
    for i in range(len(data_list)):
        if g_path[i]>0 and cn[i]>0 and gb_dens[i]>0:
            sigma_v3.append(sigma_brug[i]*C_v3*(g_path[i]*gb_dens[i]**2)**0.25*cn[i]**2*SIGMA_BULK)
        else:
            sigma_v3.append(0)

    fig, ax = plt.subplots(figsize=FIG_SINGLE)
    x = np.arange(len(names))
    ms = _marker_size(len(names)); lw = _line_width(len(names))
    ax.plot(x, sigma_v3, 's-', color=RED, markersize=ms, linewidth=lw, label="v3 (mS/cm)")
    if any(s>0 for s in sigma_net):
        ax.plot(x, sigma_net, 'D--', color='#2ecc71', markersize=ms-2, linewidth=lw-0.5, alpha=0.7, label="Network solver (mS/cm)")
    _apply_style(ax, "σ_ionic (mS/cm)", names)
    ax.legend(fontsize=9, loc='upper left')
    ax.set_title(f"[Legacy v3] σ_brug × {C_v3:.4f} × (G_path×GB_d²)^¼ × CN²", fontsize=9, fontweight='bold')
    return _save(fig, outdir, "v3_fitting.png")


def plot_formx_decomposition(data_list, names, outdir):
    """FORM X v4 factor decomposition: (φ-φc)^¾, CN^1.5, ⁴√cov, C(τ)."""
    PHI_C = 0.185; TAU_C = 2.1; TAU_K = 5.0
    phi_se = [_get(d, "phi_se") for d in data_list]
    cn = [_get(d, "se_se_cn", 0) for d in data_list]
    tau = [_get(d, "tortuosity_recommended", _get(d, "tortuosity_mean", 1)) for d in data_list]
    coverage = [(lambda vs: sum(vs)/len(vs)/100 if vs else 0.20)([v for v in [_get(d,"coverage_AM_P_mean",0), _get(d,"coverage_AM_S_mean",0), _get(d,"coverage_AM_mean",0)] if v>0]) for d in data_list]

    n = len(data_list)
    log_phiex = np.array([0.75*np.log(max(phi_se[i]-PHI_C, 0.001)) for i in range(n)])
    log_cn = np.array([1.5*np.log(cn[i]) if cn[i]>0 else 0 for i in range(n)])
    log_cov = np.array([0.25*np.log(coverage[i]) if coverage[i]>0 else 0 for i in range(n)])
    if _GLOBAL_IONIC_SIGMOID:
        # v29: tuple grew to 6 (adds best_k, best_tc). Only first 4 used here.
        Ct, Cn, tc, k = _GLOBAL_IONIC_SIGMOID[:4]
    else:
        Ct, Cn, tc, k = 0.034, 0.019, TAU_C, TAU_K
    log_Csig = np.array([np.log(Ct) + (np.log(Cn)-np.log(Ct)) / (1+np.exp(-k*(tau[i]-tc))) for i in range(n)])

    # Ref: best case
    sigma_net = _load_network_sigma(data_list)
    ref = np.argmax(sigma_net) if any(s>0 for s in sigma_net) else 0

    factors = [
        ('(φ−φc)^¾', log_phiex, '#4472C4'),
        ('CN^1.5', log_cn, '#ED7D31'),
        ('⁴√cov', log_cov, '#A5A5A5'),
        ('C(τ)', log_Csig, '#FFC000'),
    ]

    fig, (ax, ax2) = plt.subplots(2, 1, figsize=(max(8, n*0.8), max(10, n*0.32)), gridspec_kw={'height_ratios': [3, 2]})

    # Top: stacked bar (relative to ref)
    x = np.arange(n)
    bottom_pos = np.zeros(n); bottom_neg = np.zeros(n)
    for label, vals, color in factors:
        delta = vals - vals[ref]
        pos = np.clip(delta, 0, None); neg = np.clip(delta, None, 0)
        ax.bar(x, pos, bottom=bottom_pos, color=color, label=label, width=0.7, edgecolor='white', linewidth=0.5)
        ax.bar(x, neg, bottom=bottom_neg, color=color, width=0.7, edgecolor='white', linewidth=0.5)
        bottom_pos += pos; bottom_neg += neg

    ax.axhline(0, color='gray', linewidth=0.5)
    _apply_style(ax, 'Δlog(factor) from ref', names, data_list)
    # Get x_labels from ax (after _apply_style monomodal detection)
    x_labels = [t.get_text() for t in ax.get_xticklabels()]
    if not any(x_labels) or all(t == '' for t in x_labels):
        x_labels = list(names)
    ax.set_title(f'v12-clean v3 (=v29/v32) Factor Decomposition (ref: {x_labels[ref] if ref < len(x_labels) else names[ref]})', fontsize=12, fontweight='bold')
    ax.legend(fontsize=9, loc='upper left', ncol=4)
    ax.spines['top'].set_visible(False); ax.spines['right'].set_visible(False)

    # Bottom: horizontal bar per case (dominant factor)
    for i in range(n):
        deltas = [(label, vals[i]-vals[ref]) for label, vals, _ in factors]
        deltas.sort(key=lambda x: abs(x[1]), reverse=True)
        dominant = deltas[0][0]
        colors = [c for l,_,c in factors if l==dominant][0]
        ax2.barh(i, deltas[0][1], color=colors, height=0.6, edgecolor='white', linewidth=0.5)
        ax2.text(deltas[0][1], i, f' {dominant}', va='center', fontsize=7)

    ax2.set_yticks(range(n))
    ax2.set_yticklabels([x_labels[i][:20] for i in range(n)], fontsize=7)
    ax2.set_xlabel('Dominant factor Δlog', fontsize=10)
    ax2.set_title('Dominant factor per case', fontsize=11, fontweight='bold')
    ax2.axvline(0, color='gray', linewidth=0.5)
    ax2.spines['top'].set_visible(False); ax2.spines['right'].set_visible(False)

    fig.tight_layout()
    _write_csv(outdir, 'formx_decomposition.csv',
               ['(φ-φc)^¾', 'CN^1.5', '⁴√cov', 'C(τ)', 'dominant'],
               x_labels,
               list(log_phiex), list(log_cn), list(log_cov), list(log_Csig),
               [sorted([(l, v[i]-v[ref]) for l,v,_ in factors], key=lambda x:-abs(x[1]))[0][0] for i in range(n)])
    return _save(fig, outdir, "formx_decomposition.png")


def plot_ionic_decomp_physics(data_list, names, outdir):
    """PHYSICS fixed-form factor decomposition for the T1 PRODUCTION form
    (2026-05-28): σ = σ_grain · Cronau(r_SE) · (φ_eff)^½ · CN² · cov_H^½ · f_p³
                      · exp[a + b·ln τ + c·(ln τ)² + β_P2·P2 + β_F·log f_intact].
    Each factor's Δlog vs the reference (max-σ) case is plotted as a stacked bar."""
    SG = 3.0; PHI_C = 0.19
    n = len(data_list)
    phi = [_get(d, 'phi_se') for d in data_list]
    cn = [_get(d, 'se_se_cn', 0) for d in data_list]
    # T1: Hertz cov (matches _stage_e_base_arrays / production form)
    cov = [(_cov_frac(d, physics=False) or _cov_frac(d, physics=True)) for d in data_list]
    fp = [_get(d, 'percolation_pct', 0)/100.0 for d in data_list]
    tau = [_get(d, 'tortuosity_recommended', _get(d, 'tortuosity_mean', 1)) for d in data_list]
    p_amp = [_ps_fraction(d) for d in data_list]
    r_SE = [_direct_rse_um(d) for d in data_list]
    r_AM_S = []; r_AM_P = []
    for d in data_list:
        rs, rp = _r_am_sizes(d)
        r_AM_S.append(rs); r_AM_P.append(rp)
    # f_intact (fracture-aware Holm input)
    fi_log = []
    for d in data_list:
        frx = d.get('fracture_aware_excluded_pct')
        if isinstance(frx, (int, float)) and not isinstance(frx, bool):
            fi_log.append(float(np.log(max(1.0 - float(frx)/100.0, 0.05))))
        else:
            fi_log.append(0.0)

    # Per-case sub-factors (each multiplied by its production exponent)
    # NOTE: φ_eff is SAT-blend with composition-dependent φc, smoothed by δ·g_phys.
    log_phi_eff = np.zeros(n); log_cronau = np.zeros(n)
    log_cn = np.zeros(n); log_cov = np.zeros(n); log_fp = np.zeros(n)
    p2_raw = np.zeros(n); fi_arr = np.array(fi_log, float)
    for i in range(n):
        if not (phi[i] and phi[i] > PHI_C and cn[i] and cn[i] > 0
                and cov[i] and cov[i] > 0 and fp[i] and fp[i] > 0):
            continue
        g_p = _sat_g_smooth(p_amp[i], r_AM_S[i], r_AM_P[i])
        phic = (1.0 - g_p)*SE_PHI_C_P + g_p*SE_PHI_C_S
        phi_eff = np.sqrt((phi[i] - phic)**2 + (SE_SAT_DELTA*g_p)**2 + 1e-12)
        cron = float(_cronau_factor(np.array([r_SE[i] if r_SE[i] else 1.0]))[0])
        log_phi_eff[i] = 0.5 * np.log(phi_eff)
        log_cronau[i] = np.log(cron)
        log_cn[i] = SE_CN_EXP * np.log(cn[i])
        log_cov[i] = SE_COV_EXP * np.log(cov[i])
        log_fp[i] = 3.0 * np.log(fp[i])
        pex = max(phi[i] - 0.195, 0.0)
        r_eff = r_SE[i] if (r_SE[i] and np.isfinite(r_SE[i])) else 0.5
        p2_raw[i] = g_p * pex**2 * max(r_eff - 0.5, 0.0)

    # Fit T1 production form globally to get logpoly2 + β_P2 + β_F coefficients
    idx = [i for i in range(n)
           if phi[i] and phi[i] > PHI_C and cn[i] and cn[i] > 0
           and cov[i] and cov[i] > 0 and fp[i] and fp[i] > 0
           and tau[i] and tau[i] > 0 and _stage_e_sigma(data_list[i])]
    log_cb = np.zeros(n); log_p2_term = np.zeros(n); log_fi_term = np.zeros(n)
    a_fit = b_fit = c_fit = beta_p2 = beta_f = 0.0
    if len(idx) >= 8:
        base_arr = np.array([np.log(SG)+log_cronau[i]+log_phi_eff[i]+log_cn[i]
                             +log_cov[i]+log_fp[i] for i in idx])
        logsf_arr = np.array([np.log(_stage_e_sigma(data_list[i])) for i in idx])
        taus_arr = np.array([tau[i] for i in idx])
        extras = [p2_raw[idx], fi_arr[idx]]
        try:
            _r2, _lo, _Ct, _Cn, pred, b_coef, _ = _cblend_fit_score(
                base_arr, logsf_arr, taus_arr, extras=extras)
            a_fit, b_fit, c_fit = b_coef[0], b_coef[1], b_coef[2]
            beta_p2 = b_coef[3] if len(b_coef) > 3 else 0.0
            beta_f = b_coef[4] if len(b_coef) > 4 else 0.0
        except Exception:
            pass
        # Decompose: C_blend(τ) = a + b·ln τ + c·(ln τ)²
        for j, i in enumerate(idx):
            lt = np.log(tau[i])
            log_cb[i] = a_fit + b_fit*lt + c_fit*lt**2
            log_p2_term[i] = beta_p2 * p2_raw[i]
            log_fi_term[i] = beta_f * fi_arr[i]

    sig = [_stage_e_sigma(d) or 0 for d in data_list]
    ref = int(np.argmax(sig)) if any(s > 0 for s in sig) else 0

    # 8 factors with distinct colors (left → right in legend = top → bottom of stack)
    factors = [
        ('(φ_eff)^½',     log_phi_eff,  '#4472C4'),   # blue
        ('Cronau(r_SE)',  log_cronau,   '#7030A0'),   # purple
        ('CN²',           log_cn,       '#ED7D31'),   # orange
        ('cov_H^½',       log_cov,      '#A5A5A5'),   # gray
        ('f_p³',          log_fp,       '#70AD47'),   # green
        ('C_blend(τ)',    log_cb,       '#FFC000'),   # yellow
        ('β_P2·P2',       log_p2_term,  '#5B9BD5'),   # light blue
        ('β_F·log f_int', log_fi_term,  '#C00000'),   # dark red
    ]

    # ── taller figure: top panel ~larger for 8 factors,
    #     bottom panel ~taller (more vertical room per case row).
    # CAP both dimensions: PIL has a ~89M-pixel decompression limit;
    # at DPI=150, fig_w × fig_h × 150² must stay well below 89M.
    # Cap 40 × 30 → 27M pixels (safe with margin).
    fig_w = min(max(11, n*0.55), 40)
    fig_h = min(max(14, n*0.32), 30)
    fig, (ax, ax2) = plt.subplots(
        2, 1, figsize=(fig_w, fig_h),
        gridspec_kw={'height_ratios': [3, 3]})
    x = np.arange(n); bpos = np.zeros(n); bneg = np.zeros(n)
    for label, vals, color in factors:
        delta = vals - vals[ref]
        pos = np.clip(delta, 0, None); neg = np.clip(delta, None, 0)
        ax.bar(x, pos, bottom=bpos, color=color, label=label, width=0.7,
               edgecolor='white', linewidth=0.5)
        ax.bar(x, neg, bottom=bneg, color=color, width=0.7,
               edgecolor='white', linewidth=0.5)
        bpos += pos; bneg += neg
    ax.axhline(0, color='gray', linewidth=0.5)
    _apply_style(ax, 'delta-log(factor) from ref', names, data_list)
    x_labels = [t.get_text() for t in ax.get_xticklabels()]
    if not any(x_labels):
        x_labels = list(names)
    title_suffix = (f"  (live fit: a={a_fit:+.2f} b={b_fit:+.2f} c={c_fit:+.2f}"
                    f" β_P2={beta_p2:+.2f} β_F={beta_f:+.2f})")
    ax.set_title('T1 PHYSICS form factor decomposition (ref: %s)%s'
                 % (x_labels[ref] if ref < len(x_labels) else names[ref], title_suffix),
                 fontsize=11, fontweight='bold')
    ax.legend(fontsize=9, loc='upper left', ncol=4)
    ax.spines['top'].set_visible(False); ax.spines['right'].set_visible(False)
    for i in range(n):
        deltas = sorted([(l, v[i]-v[ref]) for l, v, _ in factors],
                        key=lambda t: -abs(t[1]))
        dom = deltas[0][0]; col = [c for l, _, c in factors if l == dom][0]
        ax2.barh(i, deltas[0][1], color=col, height=0.6, edgecolor='white', linewidth=0.5)
        ax2.text(deltas[0][1], i, f' {dom}', va='center', fontsize=7)
    ax2.set_yticks(range(n)); ax2.set_yticklabels([x_labels[i][:24] for i in range(n)], fontsize=8)
    ax2.set_xlabel('Dominant factor delta-log', fontsize=10)
    ax2.set_title('Dominant factor per case', fontsize=11, fontweight='bold')
    ax2.axvline(0, color='gray', linewidth=0.5)
    ax2.spines['top'].set_visible(False); ax2.spines['right'].set_visible(False)
    fig.tight_layout()
    _write_csv(outdir, 'ionic_decomp_physics.csv',
               ['(phi_eff)^0.5', 'Cronau(r_SE)', 'CN^2', 'cov_H^0.5', 'f_p^3',
                'C_blend(tau)', 'beta_P2*P2', 'beta_F*log_f_intact', 'dominant'],
               x_labels, list(log_phi_eff), list(log_cronau), list(log_cn),
               list(log_cov), list(log_fp), list(log_cb),
               list(log_p2_term), list(log_fi_term),
               [sorted([(l, v[i]-v[ref]) for l, v, _ in factors], key=lambda t: -abs(t[1]))[0][0]
                for i in range(n)])
    return _save(fig, outdir, "ionic_decomp_physics.png")


def _load_electronic_sigma(data_list):
    """Load electronic σ_full for plotting — PREFERS Stage E target over raw.
    Stage E is what the production form (electronic_fit_final) fits to and
    represents the physically realistic composite σ_e after literature
    corrections (Cronau / Trevisanello).  Raw Hertz σ_e can be much larger
    (e.g. input_1mAh_5: raw 51.89 vs Stage E 9.01) because the network
    solver doesn't apply AM-crystallinity / fracture corrections.

    Priority:
      Stage E target (electronic_sigma_full_mScm_stage_e, if raw>0 and
                      not Bruggeman-fallback phantom)
        → falls back to raw if Stage E missing
        → final fallback: legacy network_conductivity.json raw value
    """
    vals = [0.0] * len(data_list)
    for i, d in enumerate(data_list):
        # Try Stage E target chain (raw-required, fallback-aware, cap 100)
        try:
            v = _stage_e_electronic_target(d)
        except Exception:
            v = None
        if v and v > 0:
            vals[i] = float(v)
            continue
        # Fallback: legacy raw (for non-σ_e plots that just need a number)
        raw = _get(d, "electronic_sigma_full_mScm", 0)
        if raw and raw > 0 and raw <= _SIGMA_E_MAX:
            vals[i] = float(raw)
        else:
            src = _get(d, "_source_path", "")
            if src:
                net_path = os.path.join(os.path.dirname(src), "network_conductivity.json")
                if os.path.exists(net_path):
                    try:
                        with open(net_path) as _nf:
                            nd = json.load(_nf)
                        nv = nd.get("electronic_sigma_full_mScm", 0) or 0
                        if nv and 0 < nv <= _SIGMA_E_MAX:
                            vals[i] = float(nv)
                    except:
                        pass
    return vals


def _load_thermal_sigma(data_list):
    """Load thermal σ_full from full_metrics or network_conductivity.json."""
    vals = [0.0] * len(data_list)
    for i, d in enumerate(data_list):
        v = _get(d, "thermal_sigma_full_mScm", 0)
        if v and v > 0:
            vals[i] = v
        else:
            src = _get(d, "_source_path", "")
            if src:
                net_path = os.path.join(os.path.dirname(src), "network_conductivity.json")
                if os.path.exists(net_path):
                    try:
                        with open(net_path) as _nf:
                            nd = json.load(_nf)
                        vals[i] = nd.get("thermal_sigma_full_mScm", 0) or 0
                    except:
                        pass
    return vals


_ELECTRONIC_GLOBAL_FIT_CACHE = None   # SELF/L3-12: (지문, (coef[14], sigma_S, sigma_P, β_AC, n_fit))
_ELECTRONIC_BOOTSTRAP_CACHE = None    # SELF/L3-12: (지문, (b_samples [B×14], sigma_resid_log, n_fit, b_map))


def _electronic_bootstrap(B=200, seed=42):
    """Bootstrap-resample the σ_e fit corpus B times, refit Stage 21 each
    sample, store coefficient distribution.  Used by _electronic_pred_band
    to compute per-case 68%/90% prediction intervals (mirrors σ_ionic's
    _stage_e_bootstrap_coefs).

    Returns (b_samples [B×k], sigma_residual_log, n_fit, b_map) or None
    if corpus < 8.

    B=200 chosen as: 1/√B SE drop already <1% at this point; OLS refit
    on n≈77 × 14-col matrix is fast (~0.6s × 200 = ~120s on first call).
    Cached per module reload."""
    global _ELECTRONIC_BOOTSTRAP_CACHE
    #  ★ SELF (L3-12 와 **같은 부류, 더 강한 형태**): 이 캐시에는 키가 아예 없었다 —
    #    코퍼스가 바뀌어도 첫 결과를 그대로 돌려준다.  캐시 검사를 **코퍼스를 읽은 뒤**
    #    로 옮기고 내용 지문으로 건다.  디스크 walk 는 싸고 비싼 것은 bootstrap 이므로
    #    절약분은 그대로 남는다.  ⚠ L3-12 와 같이 **동일 프로세스 한정** 얘기다.
    from pathlib import Path as _P
    # Walk corpus same way as _electronic_global_fit (skip nameless).
    data_list = []; names = []; seen = set()
    for base in ('webapp/archive', 'webapp/results'):
        bp = _P(base)
        if not bp.is_dir(): continue
        for mp in bp.rglob('full_metrics.json'):
            meta_p = mp.parent / 'meta.json'
            cid = mp.parent.name
            nm = cid
            if meta_p.exists():
                try:
                    meta_name = json.load(open(meta_p)).get('name', '') or ''
                    if meta_name: nm = meta_name
                except Exception: pass
            if nm == cid and not nm.startswith('input_'):
                continue
            if nm in seen: continue
            seen.add(nm)
            try: d = json.load(open(mp))
            except Exception: continue
            data_list.append(d); names.append(nm)
    if len(data_list) < 8:
        _ELECTRONIC_BOOTSTRAP_CACHE = None
        return None
    arr = _electronic_form_arrays(data_list, names)
    if arr is None:
        _ELECTRONIC_BOOTSTRAP_CACHE = None
        return None
    fit_mask = ~arr['excluded']
    _fp = ('el_boot', B, seed, _STAGE_FORM_VERSION, bool(_LOCK_ENDPOINTS),
           _array_fingerprint(arr['X'], arr['y_resid'], arr['logsf'],
                              arr['log_offset'], fit_mask.astype(float)))
    if (_ELECTRONIC_BOOTSTRAP_CACHE is not None
            and _ELECTRONIC_BOOTSTRAP_CACHE[0] == _fp):
        return _ELECTRONIC_BOOTSTRAP_CACHE[1]
    X_full = arr['X'][fit_mask]
    y_full = arr['y_resid'][fit_mask]
    logsf_full = arr['logsf'][fit_mask]
    log_offset_full = arr['log_offset'][fit_mask]
    n_fit = len(y_full)
    k = X_full.shape[1]
    # MAP fit + residual SE (aleatoric noise) — apply Stage 22 lock
    if _LOCK_ENDPOINTS:
        sS_log = np.log(_SIGMA_S_LOCKED); sP_log = np.log(_SIGMA_P_LOCKED)
        y_adj = y_full - X_full[:, 0]*sS_log - X_full[:, 1]*sP_log
        b_other, *_ = np.linalg.lstsq(X_full[:, 2:], y_adj, rcond=None)
        b_map = np.concatenate([[sS_log, sP_log], b_other])
    else:
        b_map, *_ = np.linalg.lstsq(X_full, y_full, rcond=None)
    pred_log_map = X_full @ b_map + log_offset_full
    resid = logsf_full - pred_log_map
    sigma_residual = float(np.sqrt(np.sum(resid**2) / max(n_fit - k, 1)))
    # Bootstrap resample — must mirror _electronic_fit's Stage 22/22.5 drop logic
    rng = np.random.default_rng(seed)
    b_samples = np.empty((B, k))
    for j in range(B):
        idx = rng.integers(0, n_fit, n_fit)
        Xb = X_full[idx]; yb = y_full[idx]
        try:
            if _LOCK_ENDPOINTS:
                y_adj_b = yb - Xb[:, 0]*sS_log - Xb[:, 1]*sP_log
                n_rest_b = Xb.shape[1] - 2
                if _STAGE_FORM_VERSION >= 22.5:
                    live_rest_idx = [jj for jj in range(n_rest_b)
                                      if (jj + 2) not in _STAGE_22_5_DROP_COLS]
                    Xb_live = Xb[:, 2:][:, live_rest_idx]
                    c_live, *_ = np.linalg.lstsq(Xb_live, y_adj_b, rcond=None)
                    bb_rest = np.zeros(n_rest_b)
                    for ki, jj in enumerate(live_rest_idx):
                        bb_rest[jj] = c_live[ki]
                else:
                    bb_rest, *_ = np.linalg.lstsq(Xb[:, 2:], y_adj_b, rcond=None)
                bb = np.concatenate([[sS_log, sP_log], bb_rest])
            else:
                bb, *_ = np.linalg.lstsq(Xb, yb, rcond=None)
            b_samples[j] = bb
        except Exception:
            b_samples[j] = b_map
    _ELECTRONIC_BOOTSTRAP_CACHE = (_fp, (b_samples, sigma_residual, n_fit, b_map))
    print(f"  [electronic_bootstrap] B={B}, n_fit={n_fit}, k={k}, "
          f"σ_residual_log={sigma_residual:.4f} (aleatoric noise estimate)")
    return _ELECTRONIC_BOOTSTRAP_CACHE[1]


def _electronic_pred_band(arr_disp, ci=0.68):
    """Compute per-case prediction band (epistemic + aleatoric).
    Returns (pred_median_sigma, lower_sigma, upper_sigma) arrays in mS/cm
    space, or None if bootstrap unavailable.

    ci=0.68 → ±1σ band (calibrated by both bootstrap coef spread AND
    fit residual noise).  ci=0.90 → ±1.645σ band."""
    boot = _electronic_bootstrap(B=200)
    if boot is None:
        return None
    b_samples, sigma_residual, _n, _b_map = boot
    X_disp = arr_disp['X']
    log_offset_disp = arr_disp['log_offset']
    B = b_samples.shape[0]
    pred_log_b = np.empty((B, X_disp.shape[0]))
    for j in range(B):
        pred_log_b[j] = X_disp @ b_samples[j] + log_offset_disp
    pred_log_median = np.median(pred_log_b, axis=0)
    sigma_log_epi = np.std(pred_log_b, axis=0, ddof=1)
    sigma_log_total = np.sqrt(sigma_log_epi**2 + sigma_residual**2)
    z = 1.0 if ci == 0.68 else 1.645
    return (np.exp(pred_log_median),
            np.exp(np.maximum(pred_log_median - z*sigma_log_total, -10)),
            np.exp(np.minimum(pred_log_median + z*sigma_log_total, 10)))


def _electronic_global_fit():
    """Walk webapp/results + webapp/archive ONCE, fit Stage 20 form on the
    full corpus with proper name-based exclusion (_EXCLUDED_NAMES_EL), cache
    result globally.  Used by plot_electronic_sigma to overlay form prediction
    consistently across all group panels.

    IMPORTANT (2026-05-29 fix): SKIPS cases that have no friendly meta-name
    (i.e. their default 'name' fell back to the directory case_id like
    '260421_xxxxxx_xxxxxx').  Those nameless cases are real DEM sims but
    are NOT in the curated _EXCLUDED_NAMES_EL list, so they pass through
    untracked and POLLUTE the global fit — dilutes β_AC from −0.45 (audit
    n=63) to −0.06 (global n=77), making form predictions wildly off in
    dashboard per-config plots.  Matches electronic_shape_audit walk policy.
    Returns coef array (8,) or None if corpus too small.
    """
    global _ELECTRONIC_GLOBAL_FIT_CACHE
    #  ★ SELF (L3-12 부류): 키가 없던 캐시.  코퍼스를 읽은 **뒤** 지문으로 건다.
    from pathlib import Path as _P
    data_list = []
    names = []
    seen = set()
    nameless_skipped = 0
    for base in ('webapp/archive', 'webapp/results'):   # archive first (friendly names)
        bp = _P(base)
        if not bp.is_dir():
            continue
        for mp in bp.rglob('full_metrics.json'):
            meta_p = mp.parent / 'meta.json'
            cid = mp.parent.name
            nm = cid
            if meta_p.exists():
                try:
                    meta_name = json.load(open(meta_p)).get('name', '') or ''
                    if meta_name: nm = meta_name
                except Exception:
                    pass
            # SKIP cases without a friendly name (case_id fallback) — they
            # bypass _EXCLUDED_NAMES_EL and pollute β_AC.
            if nm == cid and not nm.startswith('input_'):
                nameless_skipped += 1
                continue
            if nm in seen:
                continue
            seen.add(nm)
            try:
                d = json.load(open(mp))
            except Exception:
                continue
            data_list.append(d)
            names.append(nm)
    if len(data_list) < 8:
        _ELECTRONIC_GLOBAL_FIT_CACHE = None
        return None
    arr = _electronic_form_arrays(data_list, names)
    if arr is None:
        _ELECTRONIC_GLOBAL_FIT_CACHE = None
        return None
    fit_mask = ~arr['excluded']
    _fp = ('el_glob', _STAGE_FORM_VERSION, bool(_LOCK_ENDPOINTS),
           _array_fingerprint(arr['X'], arr['y_resid'], arr['logsf'],
                              arr['log_offset'], fit_mask.astype(float)))
    if (_ELECTRONIC_GLOBAL_FIT_CACHE is not None
            and _ELECTRONIC_GLOBAL_FIT_CACHE[0] == _fp):
        return _ELECTRONIC_GLOBAL_FIT_CACHE[1]
    fit = _electronic_fit(arr, fit_mask=fit_mask)
    if fit is None:                      # L3-08: 적합이 정해지지 않으면 캐시도 비운다
        _ELECTRONIC_GLOBAL_FIT_CACHE = None
        return None
    coef = fit['coef']
    sS = float(np.exp(coef[0])); sP = float(np.exp(coef[1]))
    bAC = float(coef[7])
    _ELECTRONIC_GLOBAL_FIT_CACHE = (_fp, (coef, sS, sP, bAC, fit['n_fit']))
    print(f"  [electronic_global_fit] n_corpus={len(data_list)} "
          f"(skipped {nameless_skipped} nameless), n_fit={fit['n_fit']} "
          f"(excl={int(arr['excluded'].sum())}), "
          f"σ_S={sS:.2f}, σ_P={sP:.2f}, "
          + ('' if 7 in _STAGE_22_5_DROP_COLS else f"β_AC={bAC:+.3f}, ")
          + 
          f"R²={fit['r2']:.3f}, LOOCV={fit['loocv']:.3f}")
    return _ELECTRONIC_GLOBAL_FIT_CACHE[1]


def plot_electronic_sigma(data_list, names, outdir):
    """Electronic conductivity from AM-AM network.  Now overlays Stage 15
    production form prediction (green dashed + diamond) on top of the
    Stage E target line (red squares), mirroring σ_ionic_perconfig_physics
    style.  Phantom cases are X-marked instead of plotted at silly magnitudes.

    Form coefficients are GLOBAL — fit once on the full corpus
    (webapp/results + webapp/archive) with proper name-based exclusion,
    then cached.  Same coefficients applied to every group panel for
    cross-panel consistency."""
    sigma_el_raw = _load_electronic_sigma(data_list)
    phantom = [_phantom_electronic_sigma(d) for d in data_list]
    sigma_el = [(0.0 if (phantom[i] or sigma_el_raw[i] > _SIGMA_E_MAX)
                 else sigma_el_raw[i])
                for i in range(len(sigma_el_raw))]
    if not any(s > 0 for s in sigma_el) and not any(phantom):
        return None

    # ───── Stage 21 form prediction overlay (GLOBAL fit, cached) ─────
    form_pred = [np.nan] * len(data_list)
    # Stage 21: per-case 68% PI band (bootstrap-based, σ_ionic-style)
    pi_lo = [np.nan] * len(data_list)
    pi_hi = [np.nan] * len(data_list)
    form_ok = False; band_ok = False
    fit_summary = ''
    # Stage 21 (2026-06-02): track cases that have σ_e raw BUT lack form
    # arrays input (cov_AM_mean / f_perc / cn / tau / area missing).  These
    # appeared as red squares on plot without green form line / PI band,
    # confusing user.  Now classify as "form_missing" → gray X mark, hide
    # raw σ from the data line (NaN), so visual is consistent: only cases
    # with BOTH raw σ AND form metrics show as full data/form/band trio.
    form_missing = [False] * len(data_list)
    excl_idx_set = set()    # AUDIT EXCLUDED cases — marked separately on plot
    try:
        global_fit = _electronic_global_fit()
        if global_fit is not None:
            coef, sS, sP, bAC, n_fit = global_fit
            lock_tag = " LOCKED" if _LOCK_ENDPOINTS else " live-fit"
            #  ★ L3-11 확장: β_AC 는 col 7 = **22.5 의 드롭 열**이라 구조적으로 항상 0 이다.
            #    적합 결과처럼 찍으면 "12항 모델" 을 광고하는 것과 같은 부류가 된다.
            _ac = ('' if 7 in _STAGE_22_5_DROP_COLS
                   else f" β_AC={bAC:+.2f}")
            fit_summary = (f"  [global fit n={n_fit}: σ_S={sS:.2f}{lock_tag} "
                           f"σ_P={sP:.2f}{lock_tag}{_ac}]")
            arr_disp = _electronic_form_arrays(data_list, list(names))
            if arr_disp is not None:
                pred_disp = np.exp(arr_disp['X'] @ coef + arr_disp['log_offset'])
                pred_disp = np.minimum(pred_disp, _SIGMA_E_MAX)
                in_arr = set(int(idx) for idx in arr_disp['keep_idx'])
                # Track AUDIT EXCLUDED cases (in arr but flagged in _EXCLUDED_NAMES_EL)
                # so per-config plot can mark them like parity plot does
                excl_idx_set = set()
                # User feedback: extend form prediction to phantom cases too —
                # if the case is in arr_disp (form-array valid), form CAN predict
                # even when raw σ is missing (phantom).  Drop `not phantom` filter.
                for k, idx in enumerate(arr_disp['keep_idx']):
                    if idx < len(form_pred):
                        form_pred[idx] = float(pred_disp[k])
                    if bool(arr_disp['excluded'][k]):
                        excl_idx_set.add(int(idx))
                form_ok = True
                # SECOND pass with allow_no_sigma=True — fills form_pred for
                # phantom cases (raw σ missing) that have all OTHER features.
                # User: "X로 빈곳도 초록색으로 표현"
                arr_inc = _electronic_form_arrays(data_list, list(names),
                                                  allow_no_sigma=True)
                if arr_inc is not None:
                    pred_inc = np.exp(arr_inc['X'] @ coef + arr_inc['log_offset'])
                    pred_inc = np.minimum(pred_inc, _SIGMA_E_MAX)
                    for k, idx in enumerate(arr_inc['keep_idx']):
                        if (idx < len(form_pred)
                                and not np.isfinite(form_pred[idx])
                                and np.isfinite(pred_inc[k])):
                            form_pred[idx] = float(pred_inc[k])
                # Mark cases with σ raw but not in form arrays (cov/fp/etc. missing)
                for i in range(len(data_list)):
                    if (not phantom[i]) and sigma_el[i] > 0 and (i not in in_arr):
                        form_missing[i] = True
                # 68% PI band from bootstrap — also extend to phantom cases
                band = _electronic_pred_band(arr_disp, ci=0.68)
                if band is not None:
                    pred_med, pred_lo, pred_hi = band
                    pred_lo = np.minimum(pred_lo, _SIGMA_E_MAX)
                    pred_hi = np.minimum(pred_hi, _SIGMA_E_MAX)
                    for k, idx in enumerate(arr_disp['keep_idx']):
                        if idx < len(pi_lo):
                            pi_lo[idx] = float(pred_lo[k])
                            pi_hi[idx] = float(pred_hi[k])
                    band_ok = True
    except Exception as _e:
        print(f"  [plot_electronic_sigma] form overlay skipped: {_e}")

    fig, ax = plt.subplots(figsize=FIG_SINGLE)
    x = np.arange(len(names))
    ms = _marker_size(len(names))
    lw = _line_width(len(names))

    # Use NaN to break line at σ=0 / phantom / form_missing cases
    # (prevents red data line from showing where form can't predict)
    y_line = np.array([s if (s > 0 and not form_missing[i]) else np.nan
                       for i, s in enumerate(sigma_el)])
    x_perc_none = [x[i] for i in range(len(names))
                   if (sigma_el[i] <= 0 and not phantom[i] and not form_missing[i])]
    x_phantom = [x[i] for i in range(len(names)) if phantom[i]]
    x_form_missing = [x[i] for i in range(len(names)) if form_missing[i]]

    # Stage E target (kept as the headline series — red squares solid)
    ax.plot(x, y_line, 's-', color='#e74c3c', markersize=ms, linewidth=lw,
            label="σ_e Stage E target (mS/cm)")
    # AUDIT EXCLUDED overlay on per-config plot (mirror parity plot's
    # treatment) — gray ✗ on top of EXCL data points so user immediately
    # sees which red square is documented anomaly (not form fail).
    if excl_idx_set:
        x_excl = [x[i] for i in range(len(names)) if i in excl_idx_set]
        y_excl = [sigma_el[i] for i in range(len(names)) if i in excl_idx_set]
        ax.scatter(x_excl, y_excl, s=(ms+6)**2, marker='x', c='#666',
                   linewidths=1.8, zorder=5,
                   label=f"AUDIT excluded ({len(excl_idx_set)}) — documented anomaly")
    # Stage 21 form prediction overlay — green dashed + diamond
    if form_ok:
        y_form = np.array(form_pred)
        # 68% PI band BEHIND the form line (bootstrap-derived)
        if band_ok:
            lo = np.array(pi_lo); hi = np.array(pi_hi)
            # Mask NaN segments so fill doesn't span across phantom/missing
            valid = np.isfinite(lo) & np.isfinite(hi)
            ax.fill_between(x, lo, hi, where=valid, color='#2e8b57',
                            alpha=0.18, linewidth=0,
                            label="68% PI (bootstrap + residual)")
        stage_label = (f"Stage 22.5" if _STAGE_FORM_VERSION >= 22.5 else "Stage 22") if _LOCK_ENDPOINTS else "Stage 21"
        ax.plot(x, y_form, 'D--', color='#2e8b57', markersize=ms-1,
                linewidth=lw, alpha=0.95,
                label=f"σ_e {stage_label} form prediction (mS/cm)")
    if x_perc_none:
        ax.plot(x_perc_none, [0]*len(x_perc_none), 'x', color='gray', markersize=ms+2,
                label="No AM percolation")
    if x_phantom:
        ax.plot(x_phantom, [0]*len(x_phantom), 'x', color='#222', markersize=ms+3,
                markeredgewidth=2,
                label="σ_e phantom (raw missing / fallback / >100 mS/cm)")
    # Stage 21 (2026-06-02): cases with σ_e raw BUT missing form-array
    # inputs (cov_AM / f_perc / am_am_cn / etc.) — form cannot predict,
    # PI band absent.  Mark with hollow gray square + X overlay so user
    # sees "data exists but form unavailable" explicitly.
    if x_form_missing:
        # Plot the raw σ value with a hollow gray square (data is real)
        y_fm = [sigma_el[i] for i in range(len(names)) if form_missing[i]]
        ax.plot(x_form_missing, y_fm, 's', color='#999',
                markerfacecolor='none', markeredgecolor='#999',
                markersize=ms+1, markeredgewidth=1.2,
                label=f"σ_e raw, form unavailable (metrics incomplete, n={len(x_form_missing)})")

    _apply_style(ax, "σ_e (mS/cm)", names)
    # σ_e plot y-axis priority:
    #   1. --y-max-sigma-e  (user σ_AM(e) UI input — preferred, σ_e-specific)
    #   2. --y-max-sigma    (unified σ y-max — shared with σ_ionic)
    #   3. auto-scale       (matplotlib default)
    # σ_AM(e) NEVER touches form anchors — form keeps the corpus-fit σ_S/σ_P defaults.
    if _Y_MAX_SIGMA_E is not None and _Y_MAX_SIGMA_E > 0:
        ax.set_ylim(0, _Y_MAX_SIGMA_E)
    elif _Y_MAX_SIGMA is not None and _Y_MAX_SIGMA > 0:
        ax.set_ylim(0, _Y_MAX_SIGMA)
    ax.legend(fontsize=8, loc='upper left')
    stage_n = ((f"Stage 22.5 (8 LIVE)" if _STAGE_FORM_VERSION >= 22.5 else "Stage 22 (endpoints anchored)") if _LOCK_ENDPOINTS else "Stage 21 (live-fit)")
    # Physically-organized form display (Stage 22 reorganization):
    #   Block 1: AM material (corpus-fit σ_S/σ_P endpoints + GB-direction NCM(r))
    #   Block 2: Geometric (Bruggeman + Holm)
    #   Block 3: Network corrections
    #   Block 4: Thin-film gates
    #   Block 5: Fracture + Tortuosity
    title = (f"σ_electronic — Stage E target vs {stage_n}" + fit_summary + "\n"
             "σ_e = (σ_S·NCM_S)^(1-p)·(σ_P·NCM_P)^p  ←AM material (corpus-fit endpoints + GB NCM(r))   "
             "× φ_AM⁴·√A_AM-AM  ←Bruggeman×Holm   "
             "× (T/d)^β_T  ←geometry\n"
             "       × exp[β_bi·p(1-p)·logφ]  ←composition coupling   "
             "× exp[β_Fe·log f_intact]  ←fracture (Holm partial)\n"
             "       × exp[g_thin·(β_φth·logφ + β_covth·log cov_AM,P)]  ←thin film   "
             "× C(τ) = exp[p_τ + q_τ·lnτ + r_τ·ln²τ]  ←tortuosity   "
             "[8 LIVE + 2 LOCKED; β_v·β_AC·β_fpth·β_rSE dropped at 22.5]")
    if not form_ok:
        title = ("Electronic Conductivity — Stage E (GB-corrected, AM-AM Network)\n"
                 "σ_AM_ref = 50 mS/cm  [form overlay unavailable — corpus too small or fit failed]")
    ax.set_title(title, fontsize=8, fontweight='bold')

    # Annotation: range (excluding zeros / phantoms)
    valid_vals = [s for s in sigma_el if s > 0]
    if valid_vals:
        n_phantom = sum(1 for p in phantom if p)
        note = f"Range: {min(valid_vals):.2f} ~ {max(valid_vals):.2f} mS/cm"
        if n_phantom:
            note += f"   ({n_phantom} phantom skipped)"
        ax.text(0.95, 0.95, note,
                transform=ax.transAxes, fontsize=9, ha='right', va='top',
                bbox=dict(boxstyle='round,pad=0.4', facecolor='#ffeaea', alpha=0.8))

    _write_csv(outdir, 'electronic_sigma.csv',
               ['σ_e_Stage_E(mS/cm)',
                f'σ_e_Stage_{_STAGE_FORM_VERSION:g}_form(mS/cm)'],
               names, sigma_el, form_pred)
    return _save(fig, outdir, "electronic_sigma.png")


def plot_thermal_sigma(data_list, names, outdir):
    """Thermal conductivity from ALL-contact network."""
    sigma_th = _load_thermal_sigma(data_list)
    if not any(s > 0 for s in sigma_th):
        return None

    fig, ax = plt.subplots(figsize=FIG_SINGLE)
    x = np.arange(len(names))
    ms = _marker_size(len(names))
    lw = _line_width(len(names))

    ax.plot(x, sigma_th, 's-', color='#ff922b', markersize=ms, linewidth=lw,
            label="k_eff (mS/cm equiv.)")

    _apply_style(ax, "k_eff (thermal, mS/cm equiv.)", names)
    ax.legend(fontsize=9, loc='upper left')
    ax.set_title("Thermal Conductivity (ALL Contact Network)\nk_AM=4.0e-2, k_SE=0.7e-2 W/(cm·K)",
                 fontsize=10, fontweight='bold')

    valid_vals = [s for s in sigma_th if s > 0]
    if valid_vals:
        ax.text(0.95, 0.95, f"Range: {min(valid_vals):.2f} ~ {max(valid_vals):.2f}",
                transform=ax.transAxes, fontsize=9, ha='right', va='top',
                bbox=dict(boxstyle='round,pad=0.4', facecolor='#fff3e0', alpha=0.8))

    _write_csv(outdir, 'thermal_sigma.csv',
               ['k_eff(mS/cm)'], names, sigma_th)
    return _save(fig, outdir, "thermal_sigma.png")


def plot_electronic_scaling(data_list, names, outdir):
    """Electronic 2-regime scaling: thick (topology) + thin (contact mechanics)."""
    SIGMA_AM = 50.0
    phi_am = [_get(d, "phi_am") for d in data_list]
    cn_am = [_get(d, "am_am_cn") for d in data_list]
    thickness = [_get(d, "thickness_um") for d in data_list]
    d_am_list = [2.0 * max(_get(d, "r_AM_P", 0), _get(d, "r_AM_S", 0), _get(d, "r_AM", 0))
                 for d in data_list]
    tau = [max(_get(d, "tortuosity_recommended", _get(d, "tortuosity_mean", 1)), 0.1) for d in data_list]
    cov_list = [(lambda vs: sum(vs)/len(vs)/100 if vs else 0.20)(
        [v for v in [_get(d,"coverage_AM_P_mean",0), _get(d,"coverage_AM_S_mean",0),
                     _get(d,"coverage_AM_mean",0)] if v > 0]) for d in data_list]
    am_delta = [max(_get(d, "am_am_mean_delta", 0), 0.001) for d in data_list]
    am_area = [max(_get(d, "am_am_mean_area", 0), 0.01) for d in data_list]
    am_hop = [max(_get(d, "am_am_mean_hop", 0), 0.1) for d in data_list]
    am_gc = [max(_get(d, "am_path_conductance_mean", 0), 0.001) for d in data_list]
    porosity = [max(_get(d, "porosity", 10), 0.1) for d in data_list]
    phi_se = [max(_get(d, "phi_se", 0.2), 0.01) for d in data_list]
    el_perc = [max(_get(d, "electronic_percolating_fraction", 0), 0.01) for d in data_list]
    el_act = [max(_get(d, "electronic_active_fraction", 0), 0.01) for d in data_list]
    sigma_net = _load_electronic_sigma(data_list)

    # --- Fit C globally on ALL electronic data (thick/thin separate) ---
    # Use screening_electronic_sweep.load_all_electronic() for reliable dedup
    import importlib.util as _ilu
    _sweep_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'screening_electronic_sweep.py')
    if not os.path.exists(_sweep_path):
        # Legacy dep removed; skip plot rather than crash other plots in batch
        print(f"  [SKIP] electronic_scaling: missing dep {os.path.basename(_sweep_path)}")
        return None
    _spec = _ilu.spec_from_file_location("sweep", _sweep_path)
    _mod = _ilu.module_from_spec(_spec)
    _spec.loader.exec_module(_mod)
    _unique = _mod.load_all_electronic()

    # Fit C_thick and C_thin separately
    # Load mixing parameter for bimodal correction
    for r in _unique:
        _m2 = json.load(open(os.path.join(r['path'], 'full_metrics.json')))
        _nP = _m2.get('n_AM_P', 0); _nS = _m2.get('n_AM_S', 0)
        _rP = max(_m2.get('r_AM_P', 0), 0.1); _rS = max(_m2.get('r_AM_S', 0), 0.1)
        _vP = _nP * _rP**3; _vS = _nS * _rS**3; _vT = max(_vP + _vS, 0.001)
        r['fP_vol'] = _vP / _vT
        r['mix'] = 4 * r['fP_vol'] * (1 - r['fP_vol'])  # symmetric: 0=mono, 1=50:50

    # Load contact info + G_holm for each case
    for r in _unique:
        _m2 = json.load(open(os.path.join(r['path'], 'full_metrics.json')))
        _nP = _m2.get('n_AM_P', 0); _nS = _m2.get('n_AM_S', 0)
        _rP = max(_m2.get('r_AM_P', 0), 0.1); _rS = max(_m2.get('r_AM_S', 0), 0.1)
        _vP = _nP * _rP**3; _vS = _nS * _rS**3; _vT = max(_vP + _vS, 0.001)
        r['fP_vol'] = _vP / _vT
        # G_holm: Holm conductance-weighted CN
        _n_pp = _m2.get('area_AM_P_AM_P_n', 0) or 0
        _n_ps = _m2.get('area_AM_P_AM_S_n', 0) or 0
        _n_ss = _m2.get('area_AM_S_AM_S_n', 0) or 0
        _a_pp = _m2.get('area_AM_P_AM_P_mean', 0) or 0
        _a_ps = _m2.get('area_AM_P_AM_S_mean', 0) or 0
        _a_ss = _m2.get('area_AM_S_AM_S_mean', 0) or 0
        _nAM = max(_nP + _nS, 1)
        _th = _n_pp*np.sqrt(max(_a_pp,0.001)) + _n_ps*np.sqrt(max(_a_ps,0.001)) + _n_ss*np.sqrt(max(_a_ss,0.001))
        r['g_holm'] = max(_th / _nAM, 0.01) if _th > 0 else r['cn']
        r['g_total'] = _th if _th > 0 else r['cn'] * _nAM  # total Holm sum
        # A_min: smallest non-zero contact type area (bottleneck indicator)
        _areas = [a for a,n in [(_a_pp,_n_pp),(_a_ps,_n_ps),(_a_ss,_n_ss)] if n > 0 and a > 0]
        r['a_min'] = min(_areas) if _areas else 0.01

    C_thick = 1.0; C_thin = 1.0
    if len(_unique) >= 5:
        _s = np.array([r['sigma'] for r in _unique])
        _cn = np.array([r['cn'] for r in _unique])
        _ratio = np.array([r['ratio'] for r in _unique])
        _por = np.array([r['por'] for r in _unique])
        _delta = np.array([r['delta'] for r in _unique])
        _pa = np.array([r['phi_am'] for r in _unique])
        _gh = np.array([r.get('g_holm', r['cn']) for r in _unique])

        _tk = _ratio >= 8; _tn = _ratio < 8
        if _tk.sum() >= 3:
            # Thick: CN^1.5 × G_holm^0.25 × (φ-φc)² / por^0.35 × exp(-0.05×logCN×logG_h)
            _phi_ex_tk = np.clip(_pa[_tk] - 0.10, 0.001, None)
            _log_cn_tk = np.log(_cn[_tk]); _log_gh_tk = np.log(_gh[_tk])
            _log_phi_tk = np.log(_phi_ex_tk)
            _rhs_tk = SIGMA_AM * np.sqrt(_cn[_tk]) * np.sqrt(_gh[_tk]) * _phi_ex_tk**3 / _por[_tk]**0.25 * np.exp(-0.75*_log_cn_tk*_log_phi_tk - 0.25*_log_gh_tk**2)
            C_thick = float(np.exp(np.mean(np.log(_s[_tk]) - np.log(_rhs_tk))))
        if _tn.sum() >= 3:
            _delta_tn = _delta[_tn]
            _rhs_tn = SIGMA_AM * _cn[_tn] * _delta_tn**0.5 / _ratio[_tn]**0.5
            C_thin = float(np.exp(np.mean(np.log(_s[_tn]) - np.log(_rhs_tn))))

    # ── Global R² from ALL data (not just this comparison group) ──
    r2_global_tk = 0; r2_global_tn = 0; n_global_tk = 0; n_global_tn = 0
    if len(_unique) >= 5:
        _s_all = np.array([r['sigma'] for r in _unique])
        _ratio_all = np.array([r['ratio'] for r in _unique])
        # Thick global R²
        _tk_mask = _ratio_all >= 8
        if _tk_mask.sum() >= 3:
            _cn_g = np.log(np.array([r['cn'] for r in _unique])[_tk_mask])
            _pa_g = np.array([r['phi_am'] for r in _unique])[_tk_mask]
            _phi_ex_g = np.clip(_pa_g - 0.10, 0.001, None)
            _por_g = np.array([r['por'] for r in _unique])[_tk_mask]
            _gh_g = np.array([r.get('g_holm', r['cn']) for r in _unique])[_tk_mask]
            _log_phi_g = np.log(_phi_ex_g)
            _log_gh_g = np.log(_gh_g)
            _pred_tk = C_thick * SIGMA_AM * np.exp(_cn_g)**0.5 * _gh_g**0.5 * _phi_ex_g**3 / _por_g**0.25 * np.exp(-0.75*_cn_g*_log_phi_g - 0.25*_log_gh_g**2)
            _log_a = np.log(_s_all[_tk_mask]); _log_p = np.log(_pred_tk)
            _ss_res = np.sum((_log_a - _log_p)**2); _ss_tot = np.sum((_log_a - np.mean(_log_a))**2)
            r2_global_tk = 1 - _ss_res / _ss_tot if _ss_tot > 0 else 0
            n_global_tk = int(_tk_mask.sum())
        # Thin global R²
        _tn_mask = _ratio_all < 8
        _ep_all = np.array([r['ep'] for r in _unique])
        _tn_perc = _tn_mask & (_ep_all >= 0.50)
        if _tn_perc.sum() >= 3:
            _cn_tn = np.array([r['cn'] for r in _unique])[_tn_perc]
            _delta_tn = np.array([r['delta'] for r in _unique])[_tn_perc]
            _ratio_tn = _ratio_all[_tn_perc]
            _pred_tn = C_thin * SIGMA_AM * _cn_tn * _delta_tn**0.5 / _ratio_tn**0.5
            _log_a = np.log(_s_all[_tn_perc]); _log_p = np.log(_pred_tn)
            _ss_res = np.sum((_log_a - _log_p)**2); _ss_tot = np.sum((_log_a - np.mean(_log_a))**2)
            r2_global_tn = 1 - _ss_res / _ss_tot if _ss_tot > 0 else 0
            n_global_tn = int(_tn_perc.sum())

    # Compute per-case G_holm and A_min
    case_g_holm = []; case_g_total = []; case_a_min = []
    for d in data_list:
        _nP = _get(d, "n_AM_P", 0) or 0; _nS = _get(d, "n_AM_S", 0) or 0
        _n_pp = _get(d, "area_AM_P_AM_P_n", 0) or 0
        _n_ps = _get(d, "area_AM_P_AM_S_n", 0) or 0
        _n_ss = _get(d, "area_AM_S_AM_S_n", 0) or 0
        _a_pp = _get(d, "area_AM_P_AM_P_mean", 0) or 0
        _a_ps = _get(d, "area_AM_P_AM_S_mean", 0) or 0
        _a_ss = _get(d, "area_AM_S_AM_S_mean", 0) or 0
        _nAM = max(_nP + _nS, 1)
        _th = _n_pp*np.sqrt(max(_a_pp,0.001)) + _n_ps*np.sqrt(max(_a_ps,0.001)) + _n_ss*np.sqrt(max(_a_ss,0.001))
        case_g_holm.append(max(_th / _nAM, 0.01) if _th > 0 else cn_am[len(case_g_holm)] if len(case_g_holm) < len(cn_am) else 1.0)
        case_g_total.append(_th if _th > 0 else (cn_am[len(case_g_total)] * _nAM if len(case_g_total) < len(cn_am) else 1.0))
        _areas = [a for a,n in [(_a_pp,_n_pp),(_a_ps,_n_ps),(_a_ss,_n_ss)] if n > 0 and a > 0]
        case_a_min.append(min(_areas) if _areas else 0.01)

    # Compute predictions per case
    sigma_scaling = []
    for i in range(len(data_list)):
        if phi_am[i] > 0 and cn_am[i] > 0 and d_am_list[i] > 0 and thickness[i] > 0:
            ratio_i = thickness[i] / d_am_list[i]
            if ratio_i >= 8:
                # THICK: CN^1.5 × G_holm^0.25 × (φ-φc)² / por^0.35
                phi_ex_i = max(phi_am[i] - 0.10, 0.001)
                _gh_i = max(case_g_holm[i], 0.01)
                _log_cn_i = np.log(cn_am[i]); _log_gh_i = np.log(_gh_i); _log_phi_i = np.log(phi_ex_i)
                _correction = np.exp(-0.75*_log_cn_i*_log_phi_i - 0.25*_log_gh_i**2)
                s = C_thick * SIGMA_AM * np.sqrt(cn_am[i]) * np.sqrt(_gh_i) * phi_ex_i**3 / porosity[i]**0.25 * _correction
            else:
                # THIN: CN × δ^0.5 / √(T/d)
                if el_perc[i] >= 0.50:
                    s = C_thin * SIGMA_AM * cn_am[i] * am_delta[i]**0.5 / ratio_i**0.5
                else:
                    s = 0.0
            sigma_scaling.append(s)
        else:
            sigma_scaling.append(0.0)

    has_net = any(s > 0 for s in sigma_net)
    if not has_net and not any(s > 0 for s in sigma_scaling):
        return None

    fig, ax = plt.subplots(figsize=FIG_SINGLE)
    x = np.arange(len(names))
    ms = _marker_size(len(names))
    lw = _line_width(len(names))

    y_scaling = np.array([s if s > 0 else np.nan for s in sigma_scaling])
    y_net = np.array([s if s > 0 else np.nan for s in sigma_net]) if has_net else None

    ax.plot(x, y_scaling, 's-', color=RED, markersize=ms, linewidth=lw,
            label="Scaling law")
    # ±13% error band (DEM stochastic variability, 1σ from residual)
    _err_frac = 0.13
    y_lo = y_scaling * (1 - _err_frac)
    y_hi = y_scaling * (1 + _err_frac)
    ax.fill_between(x, y_lo, y_hi, color=RED, alpha=0.12, label='±13% band')
    if has_net and y_net is not None:
        ax.plot(x, y_net, 'D--', color='#2ecc71', markersize=ms-2, linewidth=lw-0.5,
                alpha=0.7, label="Network solver")

    _apply_style(ax, "σ_electronic (mS/cm)", names)
    ax.legend(fontsize=9, loc='upper left')

    # R² (log-space) — this group only (for display)
    valid_both = [i for i in range(len(names)) if sigma_net[i] > 0 and sigma_scaling[i] > 0]
    if len(valid_both) >= 3:
        sa = np.array([sigma_net[i] for i in valid_both])
        sp = np.array([sigma_scaling[i] for i in valid_both])
        errs = np.abs(sp - sa) / sa * 100
        w20 = np.sum(errs < 20)
    else:
        errs = np.array([0]); w20 = 0

    n_total = n_global_tk + n_global_tn
    ax.set_title(f"Electronic 2-Regime Scaling Law\n"
                 f"Thick R²={r2_global_tk:.3f}(n={n_global_tk}), Thin R²={r2_global_tn:.3f}(n={n_global_tn})",
                 fontsize=9, fontweight='bold')

    # Formula box with global R²
    txt = (f"Thick: G_h-primary + interactions R²={r2_global_tk:.3f}(n={n_global_tk})\n"
           f"Thin: CN×√δ/√(T/d) R²={r2_global_tn:.3f}(n={n_global_tn})\n"
           f"Group |err|={np.mean(errs):.0f}%, ≤20%: {w20}/{len(valid_both)}")
    ax.text(0.95, 0.95, txt, transform=ax.transAxes, fontsize=7, ha='right', va='top',
            bbox=dict(boxstyle='round,pad=0.4', facecolor='#ffeaea', alpha=0.8))

    _write_csv(outdir, 'electronic_scaling.csv',
               ['σ_scaling(mS/cm)', 'σ_network(mS/cm)'],
               names, sigma_scaling, sigma_net)
    return _save(fig, outdir, "electronic_scaling.png")


def plot_thermal_scaling(data_list, names, outdir):
    """Thermal scaling law: σ_th = 286 × σ_ion^(3/4) × φ_AM² / CN_SE."""
    C_th = 286.0

    sigma_ion = _load_network_sigma(data_list)
    phi_am = [_get(d, "phi_am") for d in data_list]
    cn_se = [_get(d, "se_se_cn") for d in data_list]

    sigma_scaling = []
    for i in range(len(data_list)):
        if sigma_ion[i] > 0 and phi_am[i] > 0 and cn_se[i] > 0:
            s = C_th * sigma_ion[i]**(3/4) * phi_am[i]**2 / cn_se[i]
            sigma_scaling.append(s)
        else:
            sigma_scaling.append(0.0)

    # Network solver for comparison
    sigma_net = _load_thermal_sigma(data_list)
    has_net = any(s > 0 for s in sigma_net)

    fig, ax = plt.subplots(figsize=FIG_SINGLE)
    x = np.arange(len(names))
    ms = _marker_size(len(names))
    lw = _line_width(len(names))

    # Use NaN to break line at σ=0 cases
    y_scaling = np.array([s if s > 0 else np.nan for s in sigma_scaling])
    y_net = np.array([s if s > 0 else np.nan for s in sigma_net]) if has_net else None

    ax.plot(x, y_scaling, 's-', color='#ff922b', markersize=ms, linewidth=lw,
            label="Scaling law (mS/cm)")
    if has_net and y_net is not None:
        ax.plot(x, y_net, 'D--', color='#2ecc71', markersize=ms-2, linewidth=lw-0.5,
                alpha=0.7, label="Network solver (mS/cm)")

    _apply_style(ax, "\u03c3_th (mS/cm equiv.)", names)
    ax.legend(fontsize=9, loc='upper left')
    ax.set_title("Thermal: \u03c3_th = 286 \u00d7 \u03c3_ion^(3/4) \u00d7 \u03c6_AM\u00b2 / CN_SE\n"
                 "R\u00b2=0.90, 1 free param",
                 fontsize=9, fontweight='bold')

    # Annotation box
    valid_scaling = [s for s in sigma_scaling if s > 0]
    if valid_scaling:
        txt = ("R\u00b2 = 0.90\n"
               "\u03c3_th = 286 \u00d7 \u03c3_ion^(3/4) \u00d7 \u03c6_AM\u00b2 / CN_SE")
        ax.text(0.95, 0.95, txt,
                transform=ax.transAxes, fontsize=8, ha='right', va='top',
                bbox=dict(boxstyle='round,pad=0.4', facecolor='#fff3e0', alpha=0.8))

    _write_csv(outdir, 'thermal_scaling.csv',
               ['\u03c3_ion(mS/cm)', 'phi_AM', 'CN_SE', '\u03c3_scaling(mS/cm)', '\u03c3_network(mS/cm)'],
               names, sigma_ion, phi_am, cn_se, sigma_scaling, sigma_net)
    return _save(fig, outdir, "thermal_scaling.png")


def plot_transport_tradeoff(data_list, names, outdir):
    """Ionic vs Electronic trade-off: dual Y-axis showing inverse relationship."""
    sigma_ionic = _load_network_sigma(data_list)
    sigma_el = _load_electronic_sigma(data_list)

    if not any(s > 0 for s in sigma_ionic) or not any(s > 0 for s in sigma_el):
        return None

    fig, ax1 = plt.subplots(figsize=FIG_SINGLE)
    x = np.arange(len(names))
    ms = _marker_size(len(names))
    lw = _line_width(len(names))

    # Ionic on left Y
    color_ion = '#2ecc71'
    ax1.plot(x, sigma_ionic, 's-', color=color_ion, markersize=ms, linewidth=lw,
             label="σ_ionic")
    ax1.set_ylabel("σ_ionic (mS/cm)", color=color_ion, fontsize=11)
    ax1.tick_params(axis='y', labelcolor=color_ion)

    # Electronic on right Y
    ax2 = ax1.twinx()
    color_el = '#e74c3c'
    y_el = np.array([s if s > 0 else np.nan for s in sigma_el])
    no_el = [i for i in range(len(names)) if sigma_el[i] == 0]
    ax2.plot(x, y_el, 'D-', color=color_el, markersize=ms, linewidth=lw, label="σ_electronic")
    if no_el:
        ax2.plot([x[i] for i in no_el], [0]*len(no_el), 'x', color='gray', markersize=ms-2)
    ax2.set_ylabel("σ_electronic (mS/cm)", color=color_el, fontsize=11)
    ax2.tick_params(axis='y', labelcolor=color_el)

    _apply_style(ax1, "", names)
    ax1.set_title("Ionic vs Electronic Conductivity Trade-off\n(↑ AM → ↑ electronic, ↓ ionic)",
                  fontsize=10, fontweight='bold')

    # Combined legend
    lines1, labels1 = ax1.get_legend_handles_labels()
    lines2, labels2 = ax2.get_legend_handles_labels()
    ax1.legend(lines1 + lines2, labels1 + labels2, fontsize=9, loc='upper left')

    _write_csv(outdir, 'transport_tradeoff.csv',
               ['σ_ionic(mS/cm)', 'σ_electronic(mS/cm)'],
               names, sigma_ionic, sigma_el)
    return _save(fig, outdir, "transport_tradeoff.png")


def plot_transport_normalized(data_list, names, outdir):
    """3-mode normalized comparison: ionic/electronic/thermal on same scale."""
    sigma_ionic = _load_network_sigma(data_list)
    sigma_el = _load_electronic_sigma(data_list)
    sigma_th = _load_thermal_sigma(data_list)

    has_ionic = any(s > 0 for s in sigma_ionic)
    has_el = any(s > 0 for s in sigma_el)
    has_th = any(s > 0 for s in sigma_th)

    if not has_ionic:
        return None

    # Normalize each to its own max
    def _norm(arr):
        mx = max(arr) if max(arr) > 0 else 1
        return [v / mx for v in arr]

    fig, ax = plt.subplots(figsize=FIG_SINGLE)
    x = np.arange(len(names))
    ms = _marker_size(len(names))
    lw = _line_width(len(names))
    w = 0.25

    if has_ionic:
        norm_ion = _norm(sigma_ionic)
        ax.bar(x - w, norm_ion, w, color='#2ecc71', alpha=0.8, label=f"Ionic (max={max(sigma_ionic):.2f})")
    if has_el:
        norm_el = _norm(sigma_el)
        ax.bar(x, norm_el, w, color='#e74c3c', alpha=0.8, label=f"Electronic (max={max(sigma_el):.2f})")
    if has_th:
        norm_th = _norm(sigma_th)
        ax.bar(x + w, norm_th, w, color='#ff922b', alpha=0.8, label=f"Thermal (max={max(sigma_th):.2f})")

    _apply_style(ax, "Normalized σ (ratio to max)", names)
    ax.legend(fontsize=8, loc='upper left')
    ax.set_ylim(0, 1.15)
    ax.set_title("3-Mode Transport Comparison (Normalized)\nIonic (SE-SE) | Electronic (AM-AM) | Thermal (ALL)",
                 fontsize=10, fontweight='bold')

    _write_csv(outdir, 'transport_normalized.csv',
               ['ionic(mS/cm)', 'electronic(mS/cm)', 'thermal(mS/cm)'],
               names, sigma_ionic, sigma_el, sigma_th)
    return _save(fig, outdir, "transport_normalized.png")


def plot_transport_absolute(data_list, names, outdir):
    """3-mode absolute values on log scale."""
    sigma_ionic = _load_network_sigma(data_list)
    sigma_el = _load_electronic_sigma(data_list)
    sigma_th = _load_thermal_sigma(data_list)

    has_ionic = any(s > 0 for s in sigma_ionic)
    has_el = any(s > 0 for s in sigma_el)
    has_th = any(s > 0 for s in sigma_th)

    if not has_ionic:
        return None

    fig, ax = plt.subplots(figsize=FIG_SINGLE)
    x = np.arange(len(names))
    ms = _marker_size(len(names))
    lw = _line_width(len(names))

    if has_ionic:
        ax.plot(x, sigma_ionic, 's-', color='#2ecc71', markersize=ms, linewidth=lw,
                label="Ionic (SE-SE)")
    if has_el:
        y_el_abs = np.array([s if s > 0 else np.nan for s in sigma_el])
        ax.plot(x, y_el_abs, 'D-', color='#e74c3c', markersize=ms, linewidth=lw,
                label="Electronic (AM-AM)")
    if has_th:
        ax.plot(x, sigma_th, '^-', color='#ff922b', markersize=ms, linewidth=lw,
                label="Thermal (ALL)")

    ax.set_yscale('log')
    _apply_style(ax, "σ_ionic (mS/cm, log scale)", names)
    ax.legend(fontsize=9, loc='upper left')
    ax.set_title("3-Mode Transport: Absolute Values\nIonic ≪ Thermal < Electronic (typical)",
                 fontsize=10, fontweight='bold')

    # Minnmann reference line
    ax.axhline(0.17, color='gray', linestyle=':', linewidth=1, alpha=0.6)
    ax.text(len(names)-0.5, 0.17, "Minnmann 0.17", fontsize=7, color='gray', va='bottom', ha='right')

    _write_csv(outdir, 'transport_absolute.csv',
               ['ionic(mS/cm)', 'electronic(mS/cm)', 'thermal(mS/cm)'],
               names, sigma_ionic, sigma_el, sigma_th)
    return _save(fig, outdir, "transport_absolute.png")


def plot_r_brug_comparison(data_list, names, outdir):
    """CF/FULL for ionic vs electronic vs thermal — 접촉 (협착) 저항이 전도도를 몇 배 낮추나.
    ⚠ 키 이름 `R_brug_over_full` 과 달리 Bruggeman 이 아니다 = CONTACT_FREE / FULL (L2-07 · 2026-10-02 라벨 정정).
    진짜 Bruggeman ÷ network 은 `R_bruggeman_over_full` · 케이스 화면 'σ_brug / σ_ionic' 행."""
    # Ionic R_brug
    r_ionic = []
    for d in data_list:
        v = _get(d, "R_brug_over_full", 0)
        r_ionic.append(v if v > 0 else 0)

    # Electronic R_brug
    r_el = []
    for i, d in enumerate(data_list):
        v = _get(d, "electronic_R_brug", 0)
        if v and v > 0:
            r_el.append(v)
        else:
            src = _get(d, "_source_path", "")
            if src:
                net_path = os.path.join(os.path.dirname(src), "network_conductivity.json")
                if os.path.exists(net_path):
                    try:
                        with open(net_path) as _nf:
                            nd = json.load(_nf)
                        r_el.append(nd.get("electronic_R_brug", 0) or 0)
                    except:
                        r_el.append(0)
                else:
                    r_el.append(0)
            else:
                r_el.append(0)

    # Thermal R_brug
    r_th = []
    for i, d in enumerate(data_list):
        v = _get(d, "thermal_R_brug", 0)
        if v and v > 0:
            r_th.append(v)
        else:
            src = _get(d, "_source_path", "")
            if src:
                net_path = os.path.join(os.path.dirname(src), "network_conductivity.json")
                if os.path.exists(net_path):
                    try:
                        with open(net_path) as _nf:
                            nd = json.load(_nf)
                        r_th.append(nd.get("thermal_R_brug", 0) or 0)
                    except:
                        r_th.append(0)
                else:
                    r_th.append(0)
            else:
                r_th.append(0)

    has_ionic = any(r > 0 for r in r_ionic)
    has_el = any(r > 0 for r in r_el)
    has_th = any(r > 0 for r in r_th)

    if not has_ionic:
        return None

    fig, ax = plt.subplots(figsize=FIG_SINGLE)
    x = np.arange(len(names))
    ms = _marker_size(len(names))
    lw = _line_width(len(names))
    w = 0.25

    if has_ionic:
        ax.bar(x - w, r_ionic, w, color='#2ecc71', alpha=0.8, label="Ionic CF/FULL")
    if has_el:
        ax.bar(x, r_el, w, color='#e74c3c', alpha=0.8, label="Electronic CF/FULL")
    if has_th:
        ax.bar(x + w, r_th, w, color='#ff922b', alpha=0.8, label="Thermal CF/FULL")

    ax.axhline(1.0, color='gray', linestyle='--', linewidth=1, alpha=0.5)
    ax.text(len(names)-0.5, 1.05, "1 = no contact resistance", fontsize=7, color='gray', ha='right')

    _apply_style(ax, "CF/FULL (σ_contact-free / σ_full)", names)
    ax.legend(fontsize=8, loc='upper left')
    ax.set_title("Contact-resistance factor by transport mode\nCF/FULL > 1 = contact resistance lowers σ (not Bruggeman · L2-07)",
                 fontsize=10, fontweight='bold')

    _write_csv(outdir, 'r_brug_comparison.csv',
               ['R_ionic', 'R_electronic', 'R_thermal'],
               names, r_ionic, r_el, r_th)
    return _save(fig, outdir, "r_brug_comparison.png")


def plot_ion_path_quality(data_list, names, outdir):
    """Ion path quality: GB Density, Hop Area, Bottleneck, Conductance (2x2)."""
    fig, axes = plt.subplots(2, 2, figsize=(12, 9))
    x = np.arange(len(names))

    # GB Density (lower is better)
    vals = [_get(d, "gb_density_mean") for d in data_list]
    axes[0,0].plot(x, vals, 's-', color=BLUE, markersize=8, linewidth=2)
    _apply_style(axes[0,0], "GB Density (hops/μm)", names)
    axes[0,0].set_title("Grain Boundary Density (GB_d)  ↓ better", fontsize=10, fontweight='bold')

    # Path Hop Area mean (higher is better)
    vals = [_get(d, "path_hop_area_mean") for d in data_list]
    axes[0,1].plot(x, vals, 's-', color=ORANGE, markersize=8, linewidth=2)
    _apply_style(axes[0,1], "Hop Area mean (μm²)", names)
    axes[0,1].set_title("Path Hop Area  (↑ better)", fontsize=10, fontweight='bold')

    # Bottleneck (higher is better)
    vals = [_get(d, "path_hop_area_min_mean") for d in data_list]
    axes[1,0].plot(x, vals, 's-', color=RED, markersize=8, linewidth=2)
    _apply_style(axes[1,0], "Bottleneck (μm²)", names)
    axes[1,0].set_title("Path Bottleneck  (↑ better)", fontsize=10, fontweight='bold')

    # Path Conductance (higher is better)
    vals = [_get(d, "path_conductance_mean") for d in data_list]
    axes[1,1].plot(x, vals, 's-', color=GREEN, markersize=8, linewidth=2)
    _apply_style(axes[1,1], "Conductance (μm²)", names)
    axes[1,1].set_title("Path Conductance (G_path)  (↑ better)", fontsize=10, fontweight='bold')

    gb = [_get(d, "gb_density_mean") for d in data_list]
    ha = [_get(d, "path_hop_area_mean") for d in data_list]
    bn = [_get(d, "path_hop_area_min_mean") for d in data_list]
    gc = [_get(d, "path_conductance_mean") for d in data_list]
    _write_csv(outdir, 'ion_path_quality.csv',
               ['GB Density(hops/μm)', 'Hop Area mean(μm²)', 'Bottleneck(μm²)', 'Conductance(μm²)'],
               names, gb, ha, bn, gc)

    _break_lines_at_groups(fig)
    fig.tight_layout(rect=[0, 0, 1, 0.95])
    fig.suptitle("Ion Path Quality", fontsize=14, fontweight='bold', x=0.5, y=0.99, ha='center')
    path = os.path.join(outdir, "ion_path_quality.png")
    fig.savefig(path, dpi=DPI, bbox_inches="tight", facecolor='white', pad_inches=0.3)
    plt.close(fig)
    return path


# ─── Plot dispatch table ─────────────────────────────────────────────────────

PLOT_REGISTRY = {
    "porosity": {
        "func": plot_porosity,
        "file": "porosity.png",
        "title": "Porosity",
        "description": "AM_P 비율 증가에 따른 기공률 변화.\n7:3 부근에서 최저 (bimodal packing 효과).\nV\u2011shape 경향이면 최적 조성 존재.",
        "origin_tip": "Line+Symbol → X: P:S Configuration, Y: Porosity(%).\nSymbol: Square (size 10), Color: Black.\nLine: B-Spline, Width 1.5.\nY축 범위: 자동 ± 1%p 여유.",
    },
    "porosity_union": {
        "func": plot_porosity_union,
        "file": "porosity_union.png",
        "title": "Porosity ε_union (pair-lens)",
        "description": "ε_union 쌍 렌즈 = (1 − (Σ V_구 − Σ V_렌즈) / V_상자) × 100.\n겹친 쌍마다 렌즈 부피를 되돌린다 · 세 입자 겹침 · 벽 밖 부피는 빼지 않는다\n→ 정확 union 보다 낮게 나온다 (LHS 194/194 · 중앙 0.64 %p).\n인계 porosity_union_exact_pct 와 다른 양 · 값이 없는 (재분석 전) 케이스는 점을 찍지 않는다.",
        "origin_tip": "Line+Symbol → X: Configuration, Y: ε_union (%).\nPorosity (ε_sphere) 그림과 나란히 본다.",
    },
    "porosity_union_exact_pct": {
        "func": plot_porosity_union_exact,
        "file": "porosity_union_exact.png",
        "title": "Porosity ε_union exact (Monte Carlo)",
        "description": "정확 union = 상자 안 무작위 점 4×10⁶ 개 중 어느 구에도 들지 않는 비율 (x · y 주기 · 세 입자 겹침까지 정확 · 벽 밖 부피 제외).\nLHS 인계표 porosity_union_exact_pct 와 같은 계산 (통계 오차 ≈ 0.014 %p).\n값이 없는 (③ 이전 · 재분석 전) 케이스는 점을 찍지 않는다.",
        "origin_tip": "Line+Symbol → X: Configuration, Y: ε_union exact (%).",
    },
    "overlap_fraction_pct": {
        "func": plot_overlap_fraction,
        "file": "overlap_fraction.png",
        "title": "Overlap fraction (pair-lens)",
        "description": "Overlap = Σ V_렌즈 / Σ V_구 × 100 — DEM 입자 겹침 비율.\nε_union − ε_sphere 의 원천 (ε_u = ε_s + 겹침·(1 − ε_s)).\n값이 없는 (재분석 전) 케이스는 점을 찍지 않는다.",
        "origin_tip": "Line+Symbol → X: Configuration, Y: Overlap (%).",
    },
    "am_se_interface": {
        "func": plot_am_se_interface,
        "file": "am_se_interface.png",
        "title": "AM-SE Interface Area",
        "description": "AM_P\u2011SE와 AM_S\u2011SE 접촉 면적을\nStacked Bar로 비교.\nAM_P 비율 증가 → AM_P\u2011SE 증가, AM_S\u2011SE 감소.\n전체 AM\u2011SE Total은 S only에서 최대.",
        "origin_tip": "Stacked Bar → X: Configuration, Y: Interface Area (μm²).\nColumn1: AM_P-SE (Dark Green #548235).\nColumn2: AM_S-SE (Light Green #A9D18E).\nLegend 우상단.",
    },
    "se_se_tradeoff": {
        "func": plot_se_se_tradeoff,
        "file": "se_se_tradeoff.png",
        "title": "SE-SE Contact Trade-off",
        "description": "SE-SE 접촉 개수(bar)와 개별 접촉 평균 면적(line)의 trade-off.\n\nAM_P↑ → SE가 넓은 공간에 분산 → 접촉 수↑ + 개별 면적↓\n= 악수 약한 사람 10명 vs 악수 센 사람 3명",
        "origin_tip": "Double-Y Axis → Left: Bar (Contact Count, Blue #4472C4).\nRight: Line+Symbol (Mean Area μm², Red #C00000, Square).\nX: Configuration.",
    },
    "se_se_total": {
        "func": plot_se_se_total,
        "file": "se_se_total.png",
        "title": "SE-SE Total Contact Area",
        "description": "SE-SE 전체 접촉 면적 = N × Mean.\n7:3 부근에서 최대 → N 증가가 Mean 감소를 압도.\n10:0에서 감소 시작 → 과도한 AM_P는 SE 품질 저하.",
        "origin_tip": "Line+Symbol → X: Configuration, Y: Total Area (μm²).\nSymbol: Square (Gray), Line: Solid.\n최대값에 Annotation arrow (Red).",
    },
    "percolation_tortuosity": {
        "func": plot_percolation_tortuosity,
        "file": "percolation_tortuosity.png",
        "title": "Percolation & Tortuosity",
        "description": "이온 전도 경로 형성률(Percolation %)과 경로 꼬임(Tortuosity).\n\nPercolation↑ + Tortuosity↓ = 좋은 이온 경로.\nAM_P↑ → 둘 다 개선 (넓은 SE 공간).",
        "origin_tip": "Double-Y Axis → Left: Percolation % (Blue, Square).\nRight: Tortuosity (Red, Triangle).\n범례: 좌측/우측 분리.",
    },
    "ionic_active": {
        "func": plot_ionic_active,
        "file": "ionic_active.png",
        "title": "Ionic Active AM Fraction",
        "description": "Top(SE pellet)에서 이온이 도달 가능한 AM 비율.\n\n100% = 모든 AM이 이온 경로에 연결.\nDead zone(빨강) = SE 미연결 → 반응 불가 AM.",
        "origin_tip": "Line+Fill plot → X: Configuration, Y: Ionic Active (%).\nGreen fill: Active zone (0 ~ line).\nRed fill: Dead zone (line ~ 100).\nY축: 95~100 확대 권장.",
    },
    "coverage": {
        "func": plot_coverage,
        "file": "coverage.png",
        "title": "AM Coverage",
        "description": "AM 표면의 SE 피복률.\n= (SE 접촉 면적) / (AM 자유 표면적) × 100%\n\nAM_P가 클수록 SE 접촉 면적↑ → Coverage↑.\nError bar = 입자 간 편차(std).",
        "origin_tip": "Grouped Bar + Error Bar.\nAM_P: Green #548235, AM_S: Light Green #A9D18E.\nCap size 4, Line width 1.2.\nX: Configuration, Y: Coverage (%).",
    },
    "coverage_AM_mean_physics_union": {
        "func": plot_coverage_physics_union,
        "file": "coverage_physics_union.png",
        "title": "AM Coverage — Physics union of caps",
        "description": "⑥ 합집합 cap 피복 (C2-⑥ · 10-06 · LHS-25) — AM 마다 SE 접촉 하나 = 구면 cap 하나 (넓이 = 세대 2 표면 소비자 면적 film_area_g2) · 겹친 cap 은 한 번 · AM–AM 이 가린 표면은 분자 · 분모에서 뺀다 · Fibonacci 점 6000 · 입자 평균.\n옛 Physics 합-클립 (접촉 면적 합 ÷ 자유 표면 · 100 % 포화) 과 다른 양 (real_14 51.5 → 43.2 %).\n값이 없는 (재분석 전 · 빈칸) 케이스는 점을 찍지 않는다.",
        "origin_tip": "Line+Symbol → X: Configuration, Y: Coverage, Physics union of caps (%).\nCoverage (Hertz 계열 막대) 그림과 나란히 본다.",
    },
    "stress_cv": {
        "func": plot_stress_cv,
        "file": "stress_cv.png",
        "title": "Stress CV",
        "description": "Von Mises 응력 변동계수(CV) — 두 규약.\n실선 = Love–Weber (접촉점 · 전체 텐서 · ④b 10-04) · 점선 = 옛 열 (LIGGGHTS stress/atom 50/50 분할 · 대각 · 크기 편향 LHS-29).\n\nCV 낮을수록 전극 내 응력이 균일.\n유효영률 사용으로 절대값은 참고용, 상대 비교만 유효.  LW 값 없는 케이스 (재분석 전) 는 안 그린다.",
        "origin_tip": "Line+Symbol → X: P:S, Y: VM CV (%).\nSymbol: Square, Black.\nCV < 100%면 양호.",
    },
    "stress_ratio": {
        "func": plot_stress_ratio,
        "file": "stress_ratio.png",
        "title": "Stress Ratio by Type",
        "description": "입자 유형별 응력 비율 (σ_type / σ_mean) — 실선 = Love–Weber · 점선 = 옛 50/50 분할 (큰 입자 과소 · LHS-29 — real_14 AM_P 0.884 ↔ 2.74).\n\n> 1.0 = 평균보다 응력 집중\n< 1.0 = 평균보다 하중 적음\n\nSE > 1.0이면 SE에 응력 집중 → 소성변형 유발.  벽 · 판 접촉 입자의 벽 힘은 두 규약 다 없다.",
        "origin_tip": "Multi-line → X: P:S, Y: σ/σ_mean.\nAM_P: Red, AM_S: Orange, SE: Green.\ny=1.0에 점선 (mean baseline).",
    },
    "se_network": {
        "func": plot_se_network,
        "file": "se_network.png",
        "title": "SE Network",
        "description": "SE-SE 배위수(CN)와 클러스터 수.\nCN = SE 입자 하나가 접촉하는 SE 이웃 수\nCN↑ = 조밀한 네트워크 (CN≥4: 안정적 3D percolation)\nCluster↓ = 분절 적음. Large(≥10) 클러스터만 이온 경로에 유의미.",
        "origin_tip": "Dual-Y → Left: Line (CN, Blue).\nRight: Bar (Clusters, Orange).",
    },
    "contact_force": {
        "func": plot_contact_force,
        "file": "contact_force.png",
        "title": "Contact Force",
        "description": "접촉 유형별(AM-AM, AM-SE, SE-SE) 법선력 평균.\nFn = √(fn_x² + fn_y² + fn_z²), 단위: μN\nF_real = F_sim / scale²\n대립자 간 접촉력이 가장 크며, P:S 변화에 따라 하중 분담 변화 관찰.",
        "origin_tip": "Grouped Bar → X: Configuration, Y: Fn mean (μN).\nAM-AM: Red, AM-SE: Green, SE-SE: Blue.",
    },
    "contact_pressure": {
        "func": plot_contact_pressure,
        "file": "contact_pressure.png",
        "title": "Contact Pressure",
        "description": "접촉 압력 P = Fn / A_contact (MPa).\n같은 힘이라도 면적이 작으면 압력↑.\nMax는 failure 시작점, Mean은 전체 경향.",
        "origin_tip": "Dual Bar → X: Configuration, Y: Pressure (MPa).\nMean: Blue, Max: Red.",
    },
    "am_vulnerability": {
        "func": plot_am_vulnerability,
        "file": "am_vulnerability.png",
        "title": "AM Vulnerability",
        "description": "Vulnerable = (SE 0개 + SE 1개 접촉 AM) / 전체 AM × 100\nAM-SE CN = AM당 SE 접촉 수 평균\nVulnerable↓ + CN↑ = 안정적 이온 공급.\nSE 1개 접촉 = single point of failure.",
        "origin_tip": "Dual-Y → Left: Bar (Vulnerable %, Red).\nRight: Line (AM-SE CN, Blue).",
    },
    "effective_conductivity": {
        "func": plot_effective_conductivity,
        "file": "effective_conductivity.png",
        "title": "σ_brug/σ_grain (Bruggeman Estimate)",
        "description": "σ_brug/σ_grain = φ_SE × f_perc / τ²  (σ_grain = 3.0 mS/cm)\n\n접촉 저항(constriction) 무시 → 실제 Network Solver 대비 3~10× 과대추정.\nNetwork Solver σ_ionic이 ground truth.",
        "origin_tip": "Line+Symbol (Green) + Bar (φ_SE, Blue).",
    },
    "rgb_fitting": {
        "func": plot_rgb_fitting,
        "file": "rgb_fitting.png",
        "title": "[Legacy] BLM+Constriction Fitting (Part I proxy)",
        "description": "⚠ Legacy: FORM X로 대체됨\nProxy: R = σ_brug/σ_proxy = C×(GB_d²×T)^α\nSingle\u2011path 근사 → R=15~1600 (실제 3~10)\nBruggeman exponent 분해: n_eff = n_geo(2.54) + n_contact(0.83) = 3.37",
        "origin_tip": "Scatter + Fit line (log\u2011log).",
        "hidden": True,
    },
    "gb_corrected": {
        "func": plot_gb_corrected,
        "file": "gb_corrected.png",
        "title": "[Legacy] Proxy σ_eff (Part I)",
        "description": "⚠ Legacy: FORM X로 대체됨\nProxy 기반 보정 (single\u2011path 근사)\n절대값 과장 → Network solver가 ground truth",
        "origin_tip": "Line (Red, ratio) + Dashed (Orange, mS/cm).",
        "hidden": True,
    },
    "network_sigma": {
        "func": plot_network_sigma,
        "file": "network_sigma.png",
        "title": "Ionic: Network Solver σ_full (Part II)",
        "description": "Kirchhoff resistor network (R_bulk + R_constriction)\n초록: σ_full (ground truth) | 파란: σ_brug (Bruggeman)\nR_brug = 3~10× | Constriction 69~81% 지배\nMinnmann(2021) 0.17 mS/cm과 same order\nσ_grain = 3.0 mS/cm (grain interior, not pellet)",
        "origin_tip": "Green: Network solver, Blue dashed: Bruggeman.",
    },
    "ionic_scaling_fit": {
        "func": plot_ionic_scaling_fit,
        "file": "ionic_scaling_fit.png",
        "title": "Ionic: σ_ion Scaling Law v12-clean v3 (=v29/v32) — Predicted vs Actual",
        "description": "v12-clean v3 (≡ v29_FINAL ≡ v32, 같은 수식·3이름):\nσ = C_blend(τ) × σ_grain × √(φ−0.2) × CN^(3/2) × cov^(2/5) × f_p³\n(σ_grain=3.0 Cronau, φc=0.20; C_blend = logpoly2 in lnτ)\nR²={formx_r2}, LOOCV={formx_loocv}",
        "origin_tip": "Scatter (log-log): X=actual (Network solver), Y=predicted (v12-clean v3).\n1:1 line (black dashed), ±20% band (green).",
    },
    "multiscale_sigma": {
        "func": plot_multiscale_sigma,
        "file": "multiscale_sigma.png",
        "title": "Ionic: σ_ion Scaling Law v12-clean v3 (=v29/v32)",
        "description": "v12-clean v3 (≡ v29_FINAL ≡ v32, 같은 수식·3이름):\nσ = C_blend(τ) × σ_grain × √(φ−0.2) × CN^(3/2) × cov^(2/5) × f_p³\n(σ_grain=3.0 Cronau, φc=0.20; C_blend = logpoly2 in lnτ)\nR²={formx_r2}, w20=51/55",
        "origin_tip": "Red: v12-clean v3 prediction.\nGreen dashed: Network solver (ground truth).",
    },
    "formx_decomposition": {
        "func": plot_formx_decomposition,
        "file": "formx_decomposition.png",
        "csv": "formx_decomposition.csv",
        "title": "v12-clean v3 (=v29/v32) Factor Decomposition",
        "description": "v12-clean v3 (=v29/v32) 각 항의 상대 기여도:\n√(φ−0.2): percolation excess\nCN^(3/2): network connectivity\ncov^(2/5): AM−SE 계면\nC_blend(τ): logpoly2(lnτ) tortuosity\nf_p³: SE percolation fraction\nref: 최고 σ case 기준",
        "origin_tip": "Stacked bar (top): factor contributions.\nHorizontal bar (bottom): dominant factor per case.",
    },
}


def plot_sigma_decomposition(data_list, names, outdir):
    """Decompose σ_eff into Bruggeman + contact terms. Show which factor dominates."""
    SIGMA_BULK = 3.0  # σ_grain (grain interior)
    C_ms = 0.073  # default, used only for reference σ_ms (decomposition is relative, C cancels out)

    sigma_brug = [_get(d, "sigma_ratio") for d in data_list]
    gb_dens = [_get(d, "gb_density_mean") for d in data_list]
    g_path = [_get(d, "path_conductance_mean", 0) for d in data_list]
    cn = [_get(d, "se_se_cn", 0) for d in data_list]
    phi = [_get(d, "phi_se") for d in data_list]
    tau = [_get(d, "tortuosity_recommended", _get(d, "tortuosity_mean", 1)) for d in data_list]
    f_perc = [_get(d, "percolation_pct") / 100 for d in data_list]

    n = len(data_list)
    # Decompose log(σ_brug) = log(σ_grain) + log(φ_SE) + log(f_perc) - 2log(τ) + log(C) + 0.25*log(G_path*GB_d²) + 2log(CN)
    log_phi = np.array([np.log(phi[i]) if phi[i] > 0 else 0 for i in range(n)])
    log_fperc = np.array([np.log(f_perc[i]) if f_perc[i] > 0 else 0 for i in range(n)])
    log_tau2 = np.array([-2 * np.log(tau[i]) if tau[i] > 0 else 0 for i in range(n)])
    log_gpath_gbd = np.array([0.25 * np.log(g_path[i] * gb_dens[i]**2) if g_path[i] > 0 and gb_dens[i] > 0 else 0 for i in range(n)])
    log_cn2 = np.array([2 * np.log(cn[i]) if cn[i] > 0 else 0 for i in range(n)])

    # Normalize: relative to best σ_eff case (show what limits performance)
    sigma_ms = []
    for i in range(n):
        if g_path[i] > 0 and cn[i] > 0 and gb_dens[i] > 0:
            sigma_ms.append(sigma_brug[i] * C_ms * (g_path[i] * gb_dens[i]**2)**0.25 * cn[i]**2 * SIGMA_BULK)
        else:
            sigma_ms.append(0)
    ref = int(np.argmax(sigma_ms))  # best σ_eff case
    d_phi = log_phi - log_phi[ref]
    d_tau = log_tau2 - log_tau2[ref]
    d_fperc = log_fperc - log_fperc[ref]
    d_gpath_gbd = log_gpath_gbd - log_gpath_gbd[ref]
    d_cn = log_cn2 - log_cn2[ref]

    fig, axes = plt.subplots(2, 1, figsize=(max(8, len(names)*0.7), 10), gridspec_kw={'height_ratios': [2, 1]})

    # Top: σ_eff with each factor's contribution as stacked
    ax = axes[0]
    x = np.arange(n)
    w = 0.6

    # Stacked bar: each factor's log contribution (relative to reference)
    colors = ['#3498db', '#e74c3c', '#2ecc71', '#f39c12', '#9b59b6']
    labels = ['φ_SE', 'τ²', 'f_perc', '(G_path×GB_d²)^¼', 'CN²']
    contributions = [d_phi, d_tau, d_fperc, d_gpath_gbd, d_cn]

    # Positive and negative stacking
    pos_bottom = np.zeros(n)
    neg_bottom = np.zeros(n)
    for j, (contrib, color, label) in enumerate(zip(contributions, colors, labels)):
        pos = np.maximum(contrib, 0)
        neg = np.minimum(contrib, 0)
        ax.bar(x, pos, w, bottom=pos_bottom, color=color, label=label, alpha=0.8, edgecolor='white', linewidth=0.5)
        ax.bar(x, neg, w, bottom=neg_bottom, color=color, alpha=0.4, edgecolor='white', linewidth=0.5)
        pos_bottom += pos
        neg_bottom += neg

    ax.axhline(0, color='gray', linewidth=0.5)
    ax.set_ylabel('Δlog(σ_brug) from reference', fontsize=11)
    ax.set_title(f'[Legacy v3] σ_ionic Factor Decomposition (ref: {names[ref]})', fontsize=12, fontweight='bold')
    ax.legend(fontsize=8, loc='upper left', ncol=3)
    ax.set_xticks(x)
    ax.set_xticklabels(names, rotation=45, ha='right', fontsize=8)
    ax.yaxis.grid(True, linestyle='--', alpha=0.5)
    ax.spines['top'].set_visible(False)
    ax.spines['right'].set_visible(False)

    # Bottom: dominant factor for each case
    ax2 = axes[1]
    # Find which factor has largest |contribution| for each case
    all_contribs = np.array(contributions)  # (5, n)
    dominant_idx = np.argmax(np.abs(all_contribs), axis=0)

    for i in range(n):
        if i == ref:
            ax2.barh(i, 0, color='gray')
            continue
        vals = all_contribs[:, i]
        sorted_idx = np.argsort(np.abs(vals))[::-1]
        # Show top 3 contributors
        y_pos = i
        for rank, j in enumerate(sorted_idx[:3]):
            ax2.barh(y_pos, vals[j], height=0.25, left=0,
                    color=colors[j], alpha=0.9 - rank*0.25,
                    edgecolor='white', linewidth=0.5)

    ax2.set_yticks(range(n))
    ax2.set_yticklabels(names, fontsize=8)
    ax2.set_xlabel('Factor contribution (Δlog)', fontsize=10)
    ax2.set_title('Dominant factors per case', fontsize=11, fontweight='bold')
    ax2.axvline(0, color='gray', linewidth=0.5)
    ax2.spines['top'].set_visible(False)
    ax2.spines['right'].set_visible(False)
    # Legend
    from matplotlib.patches import Patch
    legend_elements = [Patch(facecolor=c, label=l) for c, l in zip(colors, labels)]
    ax2.legend(handles=legend_elements, fontsize=7, loc='lower right', ncol=3)

    plt.tight_layout()
    _write_csv(outdir, 'sigma_decomposition.csv',
               ['φ_SE(Δlog)', 'τ²(Δlog)', 'f_perc(Δlog)', '(G_path×GB_d²)^¼(Δlog)', 'CN²(Δlog)'],
               names, list(d_phi), list(d_tau), list(d_fperc), list(d_gpath_gbd), list(d_cn))
    return _save(fig, outdir, "sigma_decomposition.png")


PLOT_REGISTRY["v3_fitting"] = {
    "func": plot_v3_fitting,
    "file": "v3_fitting.png",
    "title": "[Legacy] v3 Fitting (thick only)",
    "description": "⚠ Legacy: FORM X로 대체됨\nv3: σ_brug × C × (G_path × GB_d²)^(1/4) × CN²\nthick R²=0.96, thin R²=-1.0",
    "origin_tip": "Red: v3 prediction. Green dashed: Network solver.",
    "hidden": True,
}

PLOT_REGISTRY["sigma_decomposition"] = {
    "func": plot_sigma_decomposition,
    "file": "sigma_decomposition.png",
    "title": "[Legacy] v3 Factor Decomposition",
    "description": "⚠ Legacy (v3): FORM X로 대체됨\nσ_ion = σ_brug × C × (G_path × GB_d²)^(1/4) × CN²\nthick only (thin에서 실패)",
    "origin_tip": "Stacked bar (top) + Horizontal bar (bottom).",
    "hidden": True,
}


def plot_electronic_decomposition(data_list, names, outdir):
    """Decompose σ_el: Thick(CN^(2-0.3M) × (φ-φc)² / por^(0.4-0.15M)), Thin(CN × √δ / √(T/d))."""
    SIGMA_AM = 50.0

    phi_am = [_get(d, "phi_am") for d in data_list]
    cn_am = [max(_get(d, "am_am_cn"), 0.01) for d in data_list]
    thickness = [_get(d, "thickness_um") for d in data_list]
    d_am = [2.0 * max(_get(d, "r_AM_P", 0), _get(d, "r_AM_S", 0), _get(d, "r_AM", 0))
            for d in data_list]
    porosity = [max(_get(d, "porosity", 10), 0.1) for d in data_list]
    am_delta = [max(_get(d, "am_am_mean_delta", 0), 0.001) for d in data_list]

    n = len(data_list)
    ratios = [thickness[i] / d_am[i] if d_am[i] > 0 and thickness[i] > 0 else 0 for i in range(n)]

    # Thick factors: CN^(2-0.3M), (φ-φc)², por^-(0.4-0.15M)
    phi_ex = [max(phi_am[i] - 0.10, 0.001) for i in range(n)]
    # Use fP_vol for Ψ in decomposition
    case_psi = []
    for d in data_list:
        _nP2 = _get(d, "n_AM_P", 0) or 0; _nS2 = _get(d, "n_AM_S", 0) or 0
        _rP2 = max(_get(d, "r_AM_P", 0) or 0, 0.1); _rS2 = max(_get(d, "r_AM_S", 0) or 0, 0.1)
        _vP2 = _nP2 * _rP2**3; _vS2 = _nS2 * _rS2**3; _vT2 = max(_vP2 + _vS2, 0.001)
        case_psi.append(_vP2 / _vT2)
    log_phi = np.array([2.0 * np.log(phi_ex[i]) for i in range(n)])
    case_mix = [4*case_psi[i]*(1-case_psi[i]) for i in range(n)]
    log_cn2 = np.array([(2.0 - 0.3*case_mix[i]) * np.log(cn_am[i]) for i in range(n)])
    log_por = np.array([-(0.4 - 0.15*case_mix[i]) * np.log(porosity[i]) for i in range(n)])
    # Thin factors: CN, δ^0.5, (T/d)^-0.5
    log_cn1 = np.array([1.0 * np.log(cn_am[i]) for i in range(n)])
    log_delta = np.array([0.5 * np.log(am_delta[i]) for i in range(n)])
    log_ratio = np.array([-0.5 * np.log(max(ratios[i], 0.1)) for i in range(n)])

    # Determine thick/thin per case
    is_thick = [ratios[i] >= 8 for i in range(n)]

    # σ_el for reference selection (use max)
    sigma_el = []
    for i in range(n):
        if phi_am[i] > 0 and cn_am[i] > 0 and d_am[i] > 0 and thickness[i] > 0:
            if is_thick[i]:
                _psi_d = case_psi[i] if i < len(case_psi) else 0
                _mix_d = 4*_psi_d*(1-_psi_d) if i < len(case_psi) else 0
                sigma_el.append(max(phi_am[i]-0.10,0.001)**2 * cn_am[i]**(2-0.3*_mix_d) / porosity[i]**(0.4-0.15*_mix_d))
            else:
                sigma_el.append(cn_am[i] * am_delta[i]**0.5 / max(ratios[i], 0.1)**0.5)
        else:
            sigma_el.append(0)

    if not any(s > 0 for s in sigma_el):
        return None

    ref = int(np.argmax(sigma_el))

    # Build contributions based on regime
    colors_all = ['#e74c3c', '#f39c12', '#27ae60', '#3498db', '#9b59b6']
    labels_all = ['[Thick] (φ-φc)²', '[Thick] CN^(2-0.3M)', '[Thick] 1/por^(0.4-0.15M)', '[Thin] √δ', '[Thin] 1/√(T/d)']
    # Thin CN uses same slot [1] but different label
    label_cn_thin = '[Thin] CN'

    # Thick reference: highest σ among thick cases; Thin reference: highest σ among thin
    thick_idx = [i for i in range(n) if is_thick[i] and sigma_el[i] > 0]
    thin_idx = [i for i in range(n) if not is_thick[i] and sigma_el[i] > 0]
    ref_tk = thick_idx[np.argmax([sigma_el[i] for i in thick_idx])] if thick_idx else ref
    ref_tn = thin_idx[np.argmax([sigma_el[i] for i in thin_idx])] if thin_idx else ref

    contribs = np.zeros((5, n))
    for i in range(n):
        if is_thick[i]:
            contribs[0, i] = log_phi[i] - log_phi[ref_tk]
            contribs[1, i] = log_cn2[i] - log_cn2[ref_tk]
            contribs[2, i] = log_por[i] - log_por[ref_tk]
        else:
            contribs[1, i] = log_cn1[i] - log_cn1[ref_tn]
            contribs[3, i] = log_delta[i] - log_delta[ref_tn]
            contribs[4, i] = log_ratio[i] - log_ratio[ref_tn]

    fig, axes = plt.subplots(2, 1, figsize=(max(8, len(names)*0.7), 10), gridspec_kw={'height_ratios': [2, 1]})

    ax = axes[0]
    x = np.arange(n)
    w = 0.6

    has_thick = any(is_thick[i] for i in range(n))
    has_thin = any(not is_thick[i] for i in range(n))

    pos_bottom = np.zeros(n)
    neg_bottom = np.zeros(n)
    used_labels = set()
    for j in range(5):
        contrib = contribs[j]
        if np.all(np.abs(contrib) < 1e-6):
            continue
        pos = np.maximum(contrib, 0)
        neg = np.minimum(contrib, 0)
        lbl = labels_all[j]
        if j == 1 and has_thin and not has_thick:
            lbl = label_cn_thin
        ax.bar(x, pos, w, bottom=pos_bottom, color=colors_all[j], label=lbl, alpha=0.8, edgecolor='white', linewidth=0.5)
        ax.bar(x, neg, w, bottom=neg_bottom, color=colors_all[j], alpha=0.4, edgecolor='white', linewidth=0.5)
        pos_bottom += pos
        neg_bottom += neg
        used_labels.add(j)

    ax.axhline(0, color='gray', linewidth=0.5)
    ax.set_ylabel('Δlog(σ_el) from reference', fontsize=11)
    regime_str = []
    if has_thick: regime_str.append(f"Thick ref: {names[ref_tk]}")
    if has_thin: regime_str.append(f"Thin ref: {names[ref_tn]}")
    ax.set_title(f'Electronic σ_el Factor Decomposition ({", ".join(regime_str)})', fontsize=11, fontweight='bold')
    ax.legend(fontsize=8, loc='upper left', ncol=3)
    ax.set_xticks(x)
    ax.set_xticklabels(names, rotation=45, ha='right', fontsize=8)
    ax.yaxis.grid(True, linestyle='--', alpha=0.5)
    ax.spines['top'].set_visible(False)
    ax.spines['right'].set_visible(False)

    # Bottom: dominant factor
    ax2 = axes[1]
    for i in range(n):
        if i == ref:
            ax2.barh(i, 0, color='gray')
            continue
        vals = contribs[:, i]
        sorted_idx = np.argsort(np.abs(vals))[::-1]
        for rank, j in enumerate(sorted_idx[:3]):
            if abs(vals[j]) < 0.01:
                continue
            ax2.barh(i, vals[j], height=0.25, left=0,
                    color=colors_all[j], alpha=0.9 - rank*0.25,
                    edgecolor='white', linewidth=0.5)

    ax2.set_yticks(range(n))
    ax2.set_yticklabels(names, fontsize=8)
    ax2.set_xlabel('Factor contribution (Δlog)', fontsize=10)
    ax2.set_title('Dominant factors per case', fontsize=11, fontweight='bold')
    ax2.axvline(0, color='gray', linewidth=0.5)
    ax2.spines['top'].set_visible(False)
    ax2.spines['right'].set_visible(False)
    from matplotlib.patches import Patch
    legend_elements = [Patch(facecolor=colors_all[j], label=labels_all[j] if not (j==1 and has_thin and not has_thick) else label_cn_thin) for j in sorted(used_labels)]
    ax2.legend(handles=legend_elements, fontsize=7, loc='lower right', ncol=min(len(legend_elements), 3))

    plt.tight_layout()
    _write_csv(outdir, 'electronic_decomposition.csv',
               ['φ^2.5(Δlog)', 'CN(Δlog)', '1/√por(Δlog)', '√δ(Δlog)', '1/√(T/d)(Δlog)'],
               names, *[list(contribs[j]) for j in range(5)])
    return _save(fig, outdir, "electronic_decomposition.png")


PLOT_REGISTRY["electronic_decomposition"] = {
    "func": plot_electronic_decomposition,
    "file": "electronic_decomposition.png",
    "title": "Electronic: Factor Decomposition",
    "description": "Thick: CN^(2-0.3M) × (φ-φc)² / por^(0.4-0.15M)\nΨ = V_large/(V_large+V_small), 0=mono\nThin: CN × √δ / √(T/d)\n\n(φ-φc)²: percolation (φc=0.10)\nΨ: bimodal large-AM fraction\n√δ: AM-AM penetration depth",
    "origin_tip": "Stacked bar (top) + Horizontal bar (bottom).",
}


def plot_thermal_decomposition(data_list, names, outdir):
    """Decompose σ_th into σ_ion^(3/4), φ_AM², CN_SE^(-1) factors."""
    C_th = 286.0

    sigma_ion = _load_network_sigma(data_list)
    phi_am = [_get(d, "phi_am") for d in data_list]
    cn_se = [_get(d, "se_se_cn") for d in data_list]

    n = len(data_list)

    # log contributions
    log_ion = np.array([0.75 * np.log(sigma_ion[i]) if sigma_ion[i] > 0 else 0 for i in range(n)])
    log_phi = np.array([2 * np.log(phi_am[i]) if phi_am[i] > 0 else 0 for i in range(n)])
    log_cn = np.array([-1 * np.log(cn_se[i]) if cn_se[i] > 0 else 0 for i in range(n)])

    # σ_th for reference selection
    sigma_th = []
    for i in range(n):
        if sigma_ion[i] > 0 and phi_am[i] > 0 and cn_se[i] > 0:
            sigma_th.append(C_th * sigma_ion[i]**(3/4) * phi_am[i]**2 / cn_se[i])
        else:
            sigma_th.append(0)

    if not any(s > 0 for s in sigma_th):
        return None

    ref = int(np.argmax(sigma_th))
    d_ion = log_ion - log_ion[ref]
    d_phi = log_phi - log_phi[ref]
    d_cn = log_cn - log_cn[ref]

    fig, axes = plt.subplots(2, 1, figsize=(max(8, len(names)*0.7), 10), gridspec_kw={'height_ratios': [2, 1]})

    ax = axes[0]
    x = np.arange(n)
    w = 0.6

    colors = ['#2ecc71', '#e74c3c', '#3498db']
    labels = ['σ_ion^(3/4)', 'φ_AM²', 'CN_SE⁻¹']
    contributions = [d_ion, d_phi, d_cn]

    pos_bottom = np.zeros(n)
    neg_bottom = np.zeros(n)
    for j, (contrib, color, label) in enumerate(zip(contributions, colors, labels)):
        pos = np.maximum(contrib, 0)
        neg = np.minimum(contrib, 0)
        ax.bar(x, pos, w, bottom=pos_bottom, color=color, label=label, alpha=0.8, edgecolor='white', linewidth=0.5)
        ax.bar(x, neg, w, bottom=neg_bottom, color=color, alpha=0.4, edgecolor='white', linewidth=0.5)
        pos_bottom += pos
        neg_bottom += neg

    ax.axhline(0, color='gray', linewidth=0.5)
    ax.set_ylabel('Δlog(σ_th) from reference', fontsize=11)
    ax.set_title(f'Thermal σ_th Factor Decomposition (ref: {names[ref]})', fontsize=12, fontweight='bold')
    ax.legend(fontsize=9, loc='upper left', ncol=3)
    ax.set_xticks(x)
    ax.set_xticklabels(names, rotation=45, ha='right', fontsize=8)
    ax.yaxis.grid(True, linestyle='--', alpha=0.5)
    ax.spines['top'].set_visible(False)
    ax.spines['right'].set_visible(False)

    # Bottom: dominant factor
    ax2 = axes[1]
    all_contribs = np.array(contributions)
    for i in range(n):
        if i == ref:
            ax2.barh(i, 0, color='gray')
            continue
        vals = all_contribs[:, i]
        sorted_idx = np.argsort(np.abs(vals))[::-1]
        for rank, j in enumerate(sorted_idx[:3]):
            ax2.barh(i, vals[j], height=0.25, left=0,
                    color=colors[j], alpha=0.9 - rank*0.25,
                    edgecolor='white', linewidth=0.5)

    ax2.set_yticks(range(n))
    ax2.set_yticklabels(names, fontsize=8)
    ax2.set_xlabel('Factor contribution (Δlog)', fontsize=10)
    ax2.set_title('Dominant factors per case', fontsize=11, fontweight='bold')
    ax2.axvline(0, color='gray', linewidth=0.5)
    ax2.spines['top'].set_visible(False)
    ax2.spines['right'].set_visible(False)
    from matplotlib.patches import Patch
    legend_elements = [Patch(facecolor=c, label=l) for c, l in zip(colors, labels)]
    ax2.legend(handles=legend_elements, fontsize=8, loc='lower right', ncol=3)

    plt.tight_layout()
    _write_csv(outdir, 'thermal_decomposition.csv',
               ['σ_ion^3/4(Δlog)', 'φ_AM²(Δlog)', 'CN_SE⁻¹(Δlog)'],
               names, list(d_ion), list(d_phi), list(d_cn))
    return _save(fig, outdir, "thermal_decomposition.png")


PLOT_REGISTRY["thermal_decomposition"] = {
    "func": plot_thermal_decomposition,
    "file": "thermal_decomposition.png",
    "title": "Thermal: Factor Decomposition (레거시 멱법칙 — ⚠ 프로덕션 폼 아님)",
    "description": "σ_th = 286 × σ_ion^(3/4) × φ_AM² / CN_SE\n⛔ **옛 라벨의 `R²=0.90` 은 이 식의 값이 아니었다** (2026-09-09 v3 감사).\n  · 0.90 은 **프로덕션 Stage T1 = 14-특징 Ridge** 의 LOOCV 다 (α=0.05, n_fit=82).\n  · 이 그림이 그리는 **순수 멱법칙의 실측 천장은 LOOCV 0.59** 다 (A/B/C 폼 스크린, CLAUDE.md §σ_thermal Stage T1).  두 값을 바꿔 적고 있었다.\n  · 정본은 *\"compact analytic form 으로 단순화하지 말 것\"* 이라고 적는다 — 이 그림은 **그 결론을 보여 주는 대조군**이지 프로덕션 폼이 아니다.\n⚠ 그리고 그 격차의 **설명**(다중경로 k_weight)은 CL-12 로 철회됐다 — `run_decomposition` 이 `mode=` 를 안 넘겨 모든 간선이 k_weight=1.0 이었다.  관측(Ridge 0.90 vs 멱법칙 0.59)은 같은 타깃 위에서 이뤄졌으므로 유효하고, **인과 서술만** 무효다.\n\n프로덕션 σ_thermal 은 `thermal_fit_final` / `thermal_outliers_final` / `thermal_decomp_final` 을 볼 것.\n\nσ_ion^(3/4): SE backbone (ionic에서 계승)\nφ_AM²: AM thermal enhancement\nCN_SE⁻¹: SE 과밀집 페널티 (ionic과 부호 역전!)",
    "origin_tip": "Stacked bar (top) + Horizontal bar (bottom).",
}
def plot_electronic_active_am(data_list, names, outdir):
    """Electronic Active AM%: bottom-reachable AM fraction."""
    active = [_get(d, "electronic_active_fraction", 0) * 100 for d in data_list]
    perc = [_get(d, "electronic_percolating_fraction", 0) * 100 for d in data_list]
    phi_am = [_get(d, "phi_am", 0) for d in data_list]
    sigma_el = _load_electronic_sigma(data_list)
    # Phantom-mask: phantom σ_e cases (no raw / fallback / physics-pathway
    # buggy >100 mS/cm) get hidden with X instead of plotting silly values.
    phantom = [_phantom_electronic_sigma(d) for d in data_list]
    sigma_el = [(np.nan if (phantom[i] or sigma_el[i] > _SIGMA_E_MAX) else sigma_el[i])
                for i in range(len(sigma_el))]

    has_data = any(a > 0 for a in active)
    if not has_data:
        # Fallback: estimate from phi_am (literature model)
        for i in range(len(data_list)):
            pa = phi_am[i]
            if pa >= 0.55:
                active[i] = 100.0
            elif pa >= 0.30:
                active[i] = 87 + (pa - 0.30) / 0.25 * 13
            elif pa > 0:
                active[i] = 50 + (pa - 0.18) / 0.12 * 37
        has_data = True

    fig, ax1 = plt.subplots(figsize=FIG_SINGLE)
    x = np.arange(len(names))
    ms = _marker_size(len(names))
    lw = _line_width(len(names))

    # Bar: Electronic Active AM%
    colors = ['#2ecc71' if a >= 95 else '#f39c12' if a >= 80 else '#e74c3c' for a in active]
    ax1.bar(x, active, 0.6, color=colors, alpha=0.8, label='Electronic Active AM (%)')
    ax1.set_ylabel('Electronic Active AM (%)', fontsize=11)
    ax1.set_ylim(0, 105)
    ax1.axhline(95, color='#2ecc71', linestyle='--', linewidth=0.8, alpha=0.5)
    ax1.axhline(80, color='#f39c12', linestyle='--', linewidth=0.8, alpha=0.5)

    # Line: σ_electronic — phantom cases drawn as ✗ at y=0
    ax2 = ax1.twinx()
    y_el = np.array([s if (s is not None and not (s != s) and s > 0) else np.nan
                     for s in sigma_el])
    ax2.plot(x, y_el, 'D-', color='#9b59b6', markersize=ms, linewidth=lw, label='σ_electronic')
    # Phantom X-marks: where σ was suppressed for being invalid
    x_phantom = [x[i] for i in range(len(data_list)) if phantom[i]]
    if x_phantom:
        ax2.plot(x_phantom, [0]*len(x_phantom), 'x', color='#222', markersize=ms+3,
                 markeredgewidth=2, label='σ_e phantom (raw missing / fallback / >100 mS/cm)')
    ax2.set_ylabel('σ_e Stage E (mS/cm)', color='#9b59b6', fontsize=11)
    ax2.tick_params(axis='y', labelcolor='#9b59b6')

    _apply_style(ax1, '', names)
    ax1.set_title('Electronic Active AM & Dead AM Analysis  '
                  '[σ_e shown = Stage E target (GB-corrected)]\n'
                  'Green≥95%, Yellow≥80%, Red<80%',
                  fontsize=10, fontweight='bold')
    lines1, labels1 = ax1.get_legend_handles_labels()
    lines2, labels2 = ax2.get_legend_handles_labels()
    ax1.legend(lines1+lines2, labels1+labels2, fontsize=8, loc='lower right')

    _write_csv(outdir, 'electronic_active_am.csv',
               ['Active_AM(%)', 'σ_electronic(mS/cm)', 'φ_AM'],
               names, active, sigma_el, phi_am)
    return _save(fig, outdir, 'electronic_active_am.png')


PLOT_REGISTRY["electronic_active_am"] = {
    "func": plot_electronic_active_am,
    "file": "electronic_active_am.png",
    "title": "Electronic Active AM (Dead AM Analysis)",
    "description": "Bottom(CC)-reachable AM = 전자가 도달하는 AM 비율.\n95%+: 녹색 (정상), 80~95%: 황색 (주의), <80%: 적색 (도전재 필요!)\nDead AM = CC에서 전자 경로 없는 AM → 비활성.\nφ_AM > 55%면 대부분 OK. φ_AM < 35%면 도전재 필수.",
    "origin_tip": "Bar (Active %, colored) + Line (σ_electronic, purple).",
}

PLOT_REGISTRY["ion_path_quality"] = {
        "func": plot_ion_path_quality,
        "file": "ion_path_quality.png",
        "title": "Ion Path Quality (G_path, GB_d)",

        "description": "이온 경로 품질 4종 (모두 percolating 경로들의 mean):\n\n• GB Density = mean(N_hops / L_z) (hops/μm)\n  → ↓ 좋음 (입계 적을수록 저항↓)\n• Path Hop Area = mean(각 hop의 접촉면적)\n  → ↑ 좋음\n• Bottleneck = mean(각 경로의 최소 접촉면적)\n  → ↑ 좋음\n• Path Conductance = mean(1/Σ(1/A_i)) (μm²)\n  → ↑ 좋음 (직렬 저항 모델의 유효 면적)\n\n왜 mean? 경로 안은 직렬, 경로끼리는 병렬.\nmean = 경로 품질, f_perc = 경로 수량 (역할 분리).\n30개 shortest path 샘플 (best/mean/worst 10개씩).\nConductance가 가장 종합적 지표.",
        "origin_tip": "2×2 Subplots → GB Density (Blue), Hop Area (Orange), Bottleneck (Red), Conductance (Green).",
}
PLOT_REGISTRY["electronic_sigma"] = {
    "func": plot_electronic_sigma,
    "file": "electronic_sigma.png",
    "title": "Electronic Conductivity",
    "description": "AM-AM 접촉 네트워크 기반 전자 전도도.\nσ_AM = 0.05 S/cm (NCM 활물질).\nAM percolation 없으면 σ=0 (도전재 필요).\n10:0(P only)에서 AM 부족 → percolation 실패 가능.",
    "origin_tip": "Line (Red) + X markers for no-percolation cases.",
}
PLOT_REGISTRY["thermal_sigma"] = {
    "func": plot_thermal_sigma,
    "file": "thermal_sigma.png",
    "title": "Thermal Conductivity",
    "description": "ALL 접촉 네트워크 기반 열전도도.\nk_AM=4.0e-2, k_SE=0.7e-2 W/(cm·K).\nAM-SE 접촉은 harmonic mean.\n양방향 전도 (source↔sink 모두).",
    "origin_tip": "Line (Orange).",
}
PLOT_REGISTRY["electronic_scaling"] = {
    "func": plot_electronic_scaling,
    "file": "electronic_scaling.png",
    "title": "Electronic: 2-Regime Scaling Law",
    "description": "Thick (T/d≥10): σ = C × σ_AM × φ² × CN² × √cov / √por\n  φ: AM vol fraction, CN: AM-AM coordination\n\nThin (T/d<10): σ = C × σ_AM × CN × √δ / √(T/d)\n  δ: AM-AM penetration depth, T/d: thickness ratio\n\nC: thick/thin 별도 global fit (parameter sweep 최적화)",
    "origin_tip": "Red: Scaling law, Green dashed: Network solver (ground truth).",
}
PLOT_REGISTRY["thermal_scaling"] = {
    "func": plot_thermal_scaling,
    "file": "thermal_scaling.png",
    "title": "Thermal Scaling Law",
    "description": "\u03c3_th = 286 \u00d7 \u03c3_ion^(3/4) \u00d7 \u03c6_AM\u00b2 / CN_SE\n\u03c3_ion: ionic network solver \uacb0\uacfc \uc0ac\uc6a9\nCN_SE\u207b\u00b9: SE clustering \u2192 AM \uace0\ub9bd penalty\nR\u00b2=0.90 (1 free param), LOOCV R\u00b2=0.86",
    "origin_tip": "Orange: Scaling law, Green dashed: Network solver.",
}
PLOT_REGISTRY["transport_tradeoff"] = {
    "func": plot_transport_tradeoff,
    "file": "transport_tradeoff.png",
    "title": "Ionic vs Electronic Trade-off",
    "description": "이온 전도(SE-SE)와 전자 전도(AM-AM)의 역관계.\nAM↑ → electronic↑, ionic↓.\n최적 조성 = 두 곡선의 교차점 근처.\n도전재(carbon) 추가 시 electronic 병목 완화 가능.",
    "origin_tip": "Dual Y-axis: Green (ionic, left), Red (electronic, right).",
}
PLOT_REGISTRY["transport_normalized"] = {
    "func": plot_transport_normalized,
    "file": "transport_normalized.png",
    "title": "3-Mode Transport (Normalized)",
    "description": "Ionic/Electronic/Thermal 정규화 비교.\n각 mode를 자체 최대값으로 나눔 (0~1).\n어떤 mode가 조성 변화에 가장 민감한지 비교.\nIonic이 보통 가장 민감 (AM 비율에 강하게 반응).",
    "origin_tip": "Grouped Bar: Green(ionic), Red(electronic), Orange(thermal).",
}
PLOT_REGISTRY["transport_absolute"] = {
    "func": plot_transport_absolute,
    "file": "transport_absolute.png",
    "title": "3-Mode Transport (Absolute, Log)",
    "description": "Ionic/Electronic/Thermal 절대값 비교 (log scale).\nIonic ≪ Thermal < Electronic (typical).\nMinnmann(2021) 0.17 mS/cm 참고선 포함.\n이온 전도가 항상 rate-limiting → ionic 최적화 우선.",
    "origin_tip": "Multi-line (log Y): Green(ionic), Red(electronic), Orange(thermal).",
}
PLOT_REGISTRY["r_brug_comparison"] = {
    "func": plot_r_brug_comparison,
    "file": "r_brug_comparison.png",
    "title": "CF/FULL (접촉 배수) by Transport Mode",
    "description": "각 transport mode 별 접촉 배수 CF/FULL = 접촉 (협착) 저항을 뺀 네트워크 σ ÷ 전체 네트워크 σ.\n⚠ 키 이름 R_brug 과 달리 Bruggeman 이 아니다 (L2-07).  진짜 Bruggeman ÷ network 은 케이스마다 다르다 — 케이스 화면 'σ_brug / σ_ionic' 행.\nCF/FULL 이 클수록 접촉 저항 기여가 큼 · 같은 접촉 모델 안의 비 (실험 대비 오차 아님).",
    "origin_tip": "Grouped Bar: Green(ionic), Red(electronic), Orange(thermal).",
}
PLOT_REGISTRY["stress_z_layer"] = {
    "func": plot_stress_z_layer,
    "file": "stress_z_layer.png",
    "title": "Stress Z-layer CV",
    "description": "전극 높이별 Von Mises CV 프로파일.",
    "origin_tip": "Multi-line → X: Z Position (μm), Y: VM CV (%).",
}


# ─── Generic parameter comparison (X-Y scatter / multi-bar / correlation) ─────

def _merged_params(d):
    """Flatten one case's comparable numeric params: every scalar in
    full_metrics.json plus derived SE-diagnostics from the sibling
    viewer_aux.json (3D-viewer values).  Returns {key: float}."""
    out = {}
    for k, v in d.items():
        if k.startswith('_'):
            continue
        x = metric_number(v)        # bool 제외 · 옛 숫자 문자열 포함 (numpy int 가 '412' 로 저장된 케이스)
        if x is not None:
            out[k] = x
    src = d.get('_source_path')
    if src:
        aux_path = os.path.join(os.path.dirname(src), 'viewer_aux.json')
        if os.path.exists(aux_path):
            try:
                with open(aux_path) as f:
                    aux = json.load(f)
            except (OSError, ValueError):
                aux = {}
            for k, v in aux.items():
                if isinstance(v, bool):
                    continue
                if isinstance(v, (int, float)):
                    out[f'aux:{k}'] = float(v)
            # Derived SE-network diagnostics (same formulas grade_engine uses)
            np_ = aux.get('se_n_percolating')
            apts = aux.get('se_articulation_points')
            ncut = aux.get('se_n_articulation_points')
            if ncut is None and isinstance(apts, list):
                ncut = len(apts)
            nb = aux.get('se_n_bn_below_threshold')
            ne = aux.get('se_n_perc_edges')
            if np_ and ncut is not None:
                out['cut_fraction'] = ncut / np_
            if nb is not None and ne:
                out['bn_below_frac'] = nb / ne
            if aux.get('se_bn_median_norm') is not None:
                out['bn_median_norm'] = float(aux['se_bn_median_norm'])
    # Grade-engine derived metrics (Q, ASR, τ_Laplace, cycle-stable …) exposed
    # as 'grade:<label>' params — values the raw metrics don't carry directly.
    if src and _grade_engine is not None:
        cdir = os.path.dirname(src)
        ip = _load_json(os.path.join(cdir, 'input_params.json'))
        meta = _load_json(os.path.join(cdir, 'meta.json'))
        se_aux = None
        ax = _load_json(os.path.join(cdir, 'viewer_aux.json'))
        if ax:
            apts = ax.get('se_articulation_points')
            se_aux = {
                'n_percolating':        ax.get('se_n_percolating'),
                'n_articulation_points': (ax.get('se_n_articulation_points')
                                          if ax.get('se_n_articulation_points') is not None
                                          else (len(apts) if isinstance(apts, list) else None)),
                'n_bn_below_threshold': ax.get('se_n_bn_below_threshold'),
                'n_perc_edges':         ax.get('se_n_perc_edges'),
                'bn_median_norm':       ax.get('se_bn_median_norm'),
            }
        try:
            prepared = {**d, **_grade_engine.map_input_params(ip, meta)}
            for label, val in _grade_engine.axis_values(prepared, se_aux).items():
                out[f'grade:{label}'] = float(val)
        except Exception:
            pass
    return out


def _load_json(path):
    try:
        with open(path) as f:
            return json.load(f)
    except (OSError, ValueError):
        return None


def _param_label(key):
    """Display label for a metric key (strip aux: prefix, decorative stars)."""
    lbl = key[4:] + ' (3D)' if key.startswith('aux:') else key
    return lbl.replace('⭐', '').replace('★', '').replace('  ', ' ').strip()


def _case_colors(n):
    return [GROUP_COLORS[i % len(GROUP_COLORS)] for i in range(n)]


_STAGE_E_SIGMA_KEYS = ('sigma_full_mScm_stage_e_physics', 'sigma_full_mScm_physics',
                       'sigma_full_mScm_stage_e', 'sigma_full_mScm')


def _stage_e_sigma(d):
    """Best available Stage-E (or physics) σ_ionic for a case."""
    for k in _STAGE_E_SIGMA_KEYS:
        v = d.get(k)
        if v is not None and v > 0:
            return float(v)
    return None


def _cov_frac(d, physics=True):
    """Mean AM coverage as a fraction (mode-matched)."""
    keys = (['coverage_AM_mean_physics', 'coverage_AM_P_mean_physics',
             'coverage_AM_S_mean_physics'] if physics else
            ['coverage_AM_mean', 'coverage_AM_P_mean', 'coverage_AM_S_mean'])
    vs = [d.get(k) for k in keys]
    vs = [v for v in vs if v and v > 0]
    return (sum(vs) / len(vs) / 100.0) if vs else None


# ── Production fixed Stage-E/physics form (SAT-blend + Cronau σ_grain) ────
# σ = C_blend(τ)·σ_grain(r_SE)·(φ_eff)^0.5·CN²·cov^0.5·f_p³, with a COMPOSITION-
# dependent percolation threshold and near-threshold saturation, both blended
# by the P:S sigmoid g_010 (same structure as C_blend(τ)).  σ_grain is the SE
# MATERIAL property — size-dependent via the Cronau(r_SE) factor (a model assumption: its
# values are not in Cronau 2022 — SELF-51) that the Stage-E target itself applies, so the form
# mirrors how the target was built.
# Validated by nested CV (scripts/nested_cv_sat.py): unbiased SAT 0.949→0.953
# (+0.0045, ~2.8× noise SE); × Cronau then adds Δ=+0.0043 at frozen φc/δ
# (fixed factor, no DoF, deterministic — not a literature value, SELF-51).
# ★ σ_grain now comes from se_material (repo-wide single definition, declared at T_ref = 25 °C).
# The VALUE IS UNCHANGED (3.0 mS/cm, bitwise) — `_sat_baselog` below is byte-for-byte the same
# expression it has always been.  Temperature is applied ONLY by set_se_temperature() (opt-in,
# CLI --temp-c), which rebinds this module global; with no flag the production form is untouched.
SE_SG = se_material.SIGMA_GRAIN_MS_CM_25C
SE_PHI_C_P = 0.200   # P-heavy (10:0) percolation threshold
SE_PHI_C_S = 0.195   # S-heavy (0:10) percolation threshold
SE_SAT_DELTA = 0.040 # near-threshold rounding (gated to 0:10 via g_010)
SE_K_PS = 10.0; SE_P_C = 0.5
SE_CN_EXP = 2.0; SE_COV_EXP = 0.5

# ── σ_grain temperature (opt-in, --temp-c) ────────────────────────────────────
# Provenance of the number this module's PRODUCTION σ_ionic form was evaluated at.
SE_TEMP_PROVENANCE = se_material.provenance()   # T_dependence = NOT_MODELLED by default


def set_se_temperature(temp_c=None, ea_ion_ev=None, printer=print):
    """Rebind SE_SG (the σ_grain prefactor of the production σ_ionic form) to σ_grain(T).

    temp_c=None (the default everywhere) → SE_SG stays the bare 3.0 literal and `_sat_baselog`
    is bitwise unchanged, so the LOOCV-0.975 production path is untouched.

    ★★ HONEST WARNING — READ BEFORE USING THIS ON THE SCALING-LAW PATH ★★
    A GLOBAL multiplicative factor on σ_grain is EXACTLY DEGENERATE with the live-fit
    intercept `a` of C_blend(τ).  `_cblend_fit_score` regresses (log σ_act − base_log) on a
    design matrix whose first column is np.ones(n) — so adding the constant log(factor) to
    base_log simply moves the fitted `a` by −log(factor) and leaves EVERY prediction, R², and
    LOOCV numerically identical.  In other words: on THIS path `--temp-c` changes only the
    LABEL (which temperature the prefactor is declared at), not the numbers.

    The honest way to make the scaling law temperature-aware is to move the TARGETS —
    re-solve the corpus σ_act at T (network_conductivity.py --temp-c) and re-fit — not to
    scale the form's prefactor.  This function exists so that (a) SE_SG has ONE definition
    shared with the solvers, and (b) a T-labelled run says so in its provenance instead of
    silently claiming 25 °C.  See docs/temp_pressure_capability.md §3-4 / T1-b.
    """
    global SE_SG, SE_TEMP_PROVENANCE
    SE_SG = se_material.sigma_grain_mS_cm(temp_c, ea_ion_ev)
    SE_TEMP_PROVENANCE = se_material.provenance(temp_c, ea_ion_ev)
    if temp_c is not None:
        printer(f"  [T] SE_SG (σ_grain) = {SE_SG:.4f} mS/cm @ {temp_c:.1f} °C "
                f"(T_ref={se_material.T_REF_C:.0f} °C, Ea={SE_TEMP_PROVENANCE['Ea_ion_eV']} eV, "
                f"σ·T Kraft2017)")
        se_material.warn_band(temp_c, ea_ion_ev, printer=printer)
        printer('  [T] ⚠ SCALING-LAW PATH: this prefactor factor is EXACTLY absorbed by the '
                'live-fit C_blend(τ) intercept → σ_ionic form predictions / R² / LOOCV are '
                'UNCHANGED.  It relabels, it does not re-predict.  To make the form actually '
                'temperature-aware, re-solve the corpus targets at T '
                '(network_conductivity.py --temp-c) and re-fit.')
        # Honesty: only the PRODUCTION form reads SE_SG.  The legacy/diagnostic plot helpers
        # (plot_ionic_phic_scan_stage_e, the Bruggeman previews, the old FORM-X overlays) each
        # keep a LOCAL `SG = 3.0` / `SIGMA_BULK = 3.0` literal and therefore stay at 25 °C.
        # They are diagnostics, not the production form — but say so rather than let a
        # T-labelled figure quietly mix two temperature conventions.
        printer('  [T] ⚠ legacy/diagnostic plot helpers keep a local σ_grain=3.0 (25 °C) literal '
                '→ in a --temp-c run those overlays are 25 °C while the production form is '
                'T-labelled.  Do not mix them in one figure.')
    return SE_SG


def _sat_g010(p):
    """P:S sigmoid: ~1 toward 0:10 (p→0), ~0 toward 10:0 (p→1)."""
    return 1.0/(1.0 + np.exp(SE_K_PS*(np.asarray(p, float) - SE_P_C)))


def _cronau_factor(r_SE_um):
    """Stage-E σ_ionic SE-size factor (model assumption — not in Cronau 2022, SELF-51; from
    run_network_full_corrections.py:88).  Applied to σ_grain — the SE's
    intrinsic grain conductivity drops for sub-µm SE (amorphization).
    r≥0.5µm→1.00, 0.3–0.5→0.90, 0.1–0.3→0.65, 0.03–0.1→smooth interp, <0.03→0.33.
    Missing / non-positive r_SE → 1.0 (no penalty)."""
    r = np.asarray(r_SE_um, float)
    f = np.select([r >= 0.5, r >= 0.3, r >= 0.1, r >= 0.03],
                  [1.00, 0.90, 0.65, 0.33 + 0.32*(np.clip(r, 0.03, 0.1)-0.03)/0.07],
                  default=0.33)
    return np.where(np.isfinite(r) & (r > 0), f, 1.0)


def _direct_rse_um(d):
    """Direct SE radius in µm from the design inputs (None / 0 if unavailable)."""
    for k in ('_input_r_SE_um', '_input_r_SE', 'r_SE_um', 'r_SE'):
        v = d.get(k) if hasattr(d, 'get') else None
        if isinstance(v, (int, float)) and not isinstance(v, bool) and v > 0:
            return v*1000.0 if v < 0.01 else float(v)
    return None


def _sat_g_smooth(p, r_AM_S_um=None, r_AM_P_um=None):
    """Power-law size-based gate (label-free) — replaces _sat_g010 in production.
    Adopted 2026-05-28 after scan_smooth_f_small.py confirmed Alt-C power
    beats two-sigmoid by +0.0009 LOOCV with 1 fewer hyperparameter:

        g_phys = min(3.5 / r_AM_eff, 1)^2     with
        r_AM_eff = (1−p)·r_AM_S + p·r_AM_P

    Falls back to legacy g_010 if AM sizes unavailable."""
    if r_AM_S_um is None and r_AM_P_um is None:
        return _sat_g010(p)
    ras = r_AM_S_um if (r_AM_S_um and r_AM_S_um > 0) else 2.5  # corpus median
    rap = r_AM_P_um if (r_AM_P_um and r_AM_P_um > 0) else 5.5
    r_eff = (1.0 - p)*ras + p*rap
    ratio = min(3.5 / max(r_eff, 0.5), 1.0)
    return ratio**2.0


def _sat_baselog(phi, cn, cov, fp, p, r_SE_um=None,
                 r_AM_S_um=None, r_AM_P_um=None):
    """Log of the production fixed form WITHOUT C_blend(τ) (the τ prefactor is
    fit separately/live).  σ_grain = 3.0 × Cronau(r_SE).  Uses SMOOTH size-
    based g_phys (S1 adoption, 2026-05-28) if AM sizes provided; otherwise
    falls back to label-based g_010 for back-compat."""
    g_phys = _sat_g_smooth(p, r_AM_S_um, r_AM_P_um)
    phic = (1.0 - g_phys)*SE_PHI_C_P + g_phys*SE_PHI_C_S
    phi_eff = np.sqrt((np.asarray(phi, float) - phic)**2 + (SE_SAT_DELTA*g_phys)**2 + 1e-12)
    sg = SE_SG * _cronau_factor(r_SE_um) if r_SE_um is not None else SE_SG
    return (np.log(sg) + 0.5*np.log(phi_eff) + SE_CN_EXP*np.log(cn)
            + SE_COV_EXP*np.log(cov) + 3.0*np.log(fp))


def _r_am_sizes(d):
    """Extract (r_AM_S_um, r_AM_P_um) scalars from a metrics dict."""
    def _one(keys):
        for k in keys:
            v = d.get(k)
            if isinstance(v, (int, float)) and not isinstance(v, bool) and v > 0:
                return v*1000.0 if v < 0.01 else float(v)
        return None
    return (_one(('_input_r_AM_S_um', '_input_r_AM_S', 'r_AM_S_um', 'r_AM_S')),
            _one(('_input_r_AM_P_um', '_input_r_AM_P', 'r_AM_P_um', 'r_AM_P')))


def plot_ionic_solver_vs_stage_e(data_list, names, outdir):
    """Per-case σ_ionic from the raw Hertzian network solver vs the Physics
    solver vs the Stage-E final value — shows how much the Tabor+volume
    contact model and the literature grain corrections shift σ_ionic away
    from the DEM-native Hertzian solve."""
    H, P, E, labs = [], [], [], []
    for d, nm in zip(data_list, names):
        h = d.get('sigma_full_mScm')
        p = d.get('sigma_full_mScm_physics')
        e = _stage_e_sigma(d)
        if not (h or p or e):
            continue
        H.append(h if h else np.nan)
        P.append(p if p else np.nan)
        E.append(e if e else np.nan)
        labs.append(nm)
    if not labs:
        print("  [SKIP] ionic_solver_vs_stage_e: no σ data")
        return None
    fig, ax = plt.subplots(figsize=FIG_SINGLE)
    x = np.arange(len(labs)); w = 0.27
    ax.bar(x - w, H, w, label='Network solver (Hertzian)', color=BLUE)
    ax.bar(x,     P, w, label='Network solver (Physics)', color=GREEN)
    ax.bar(x + w, E, w, label='Stage E final', color=RED)
    # Δ% Physics vs Hertzian annotation
    for i in range(len(labs)):
        if H[i] and P[i] and not (np.isnan(H[i]) or np.isnan(P[i])) and H[i] > 0:
            d_pct = (P[i] - H[i]) / H[i] * 100
            ax.annotate(f'{d_pct:+.0f}%', (x[i], max(H[i], P[i])),
                        fontsize=6, ha='center', va='bottom', color=GRAY)
    ax.set_xticks(x); ax.set_xticklabels(labs, rotation=30, ha='right', fontsize=8)
    ax.set_ylabel('σ_ionic (mS/cm)')
    ax.set_title('σ_ionic: Network solver (Hertzian/Physics) vs Stage E', fontsize=10)
    # Honour the unified y-axis cap (y-max-sigma input) so panels share a scale
    if _Y_MAX_SIGMA and _Y_MAX_SIGMA > 0:
        ax.set_ylim(0, _Y_MAX_SIGMA)
    ax.legend(fontsize=8); ax.grid(True, axis='y', alpha=0.25)
    # Case-group separators + labels (same style as the per-config line plots)
    if _GROUP_INFO and len(_GROUP_INFO[0]) > 1:
        sizes, gnames = _GROUP_INFO
        pos = 0
        for gi, sz in enumerate(sizes):
            if gi > 0:
                ax.axvline(pos - 0.5, color='#888888', linestyle='--',
                           linewidth=1, alpha=0.6)
            mid = pos + sz / 2 - 0.5
            ax.text(mid, -0.30 if gi % 2 else -0.22, gnames[gi], ha='center',
                    va='top', transform=ax.get_xaxis_transform(), fontsize=7,
                    fontweight='bold', color=GROUP_COLORS[gi % len(GROUP_COLORS)],
                    bbox=dict(boxstyle='round,pad=0.2', facecolor='white',
                              edgecolor=GROUP_COLORS[gi % len(GROUP_COLORS)], alpha=0.8))
            pos += sz
        fig.subplots_adjust(bottom=0.32)
    outpath = _save(fig, outdir, "ionic_solver_vs_stage_e.png")
    with open(os.path.join(outdir, "ionic_solver_vs_stage_e.csv"), 'w', newline='',
              encoding='utf-8') as f:
        wr = csv.writer(f)
        wr.writerow(['Case', 'Hertzian', 'Physics', 'Stage_E',
                     'Phys_vs_Hertz_%', 'StageE_vs_Phys_%'])
        for i, nm in enumerate(labs):
            dvh = ((P[i]-H[i])/H[i]*100) if (H[i] and not np.isnan(H[i])
                                             and not np.isnan(P[i]) and H[i] > 0) else ''
            dep = ((E[i]-P[i])/P[i]*100) if (P[i] and not np.isnan(P[i])
                                             and not np.isnan(E[i]) and P[i] > 0) else ''
            wr.writerow([nm,
                         '' if np.isnan(H[i]) else round(H[i], 4),
                         '' if np.isnan(P[i]) else round(P[i], 4),
                         '' if np.isnan(E[i]) else round(E[i], 4),
                         round(dvh, 1) if dvh != '' else '',
                         round(dep, 1) if dep != '' else ''])
    return outpath


def _cblend_fit_score(base_log, logsf, taus, extras=None):
    """Fit C_blend(τ) = a + b·ln τ + c·(ln τ)²  plus optional `extras`
    (k extra n-vectors, jointly OLS-fit).  Returns
        (r2, loocv, Ct, Cn, pred_log, b, None)
    where b has length 3 + (len(extras) if extras else 0).  The trailing
    None preserves the legacy (bv5, bp3) unpacking signature.

    C4 PRODUCTION usage (adopted 2026-05-28): pass
        extras = [p2_feature_vec, cov_delta_centered_vec]
    to get the augmented 5-param fit (logpoly2 + β_P2 + β_cov)."""
    n = len(taus)
    resid = logsf - base_log
    lt = np.log(taus)
    X_cols = [np.ones(n), lt, lt**2]
    if extras is not None:
        X_cols.extend(extras)
    X = np.column_stack(X_cols)
    b, *_ = np.linalg.lstsq(X, resid, rcond=None)
    pred = base_log + X @ b
    ss = np.sum((logsf-logsf.mean())**2)
    r2 = 1 - np.sum((logsf-pred)**2)/ss if ss > 0 else 0.0
    sse = 0.0
    for i in range(n):
        mk = np.ones(n, bool); mk[i] = False
        bi, *_ = np.linalg.lstsq(X[mk], resid[mk], rcond=None)
        sse += (logsf[i] - (base_log[i] + X[i] @ bi))**2
    loocv = 1 - sse/ss if ss > 0 else 0.0
    # Legacy "Ct"/"Cn" readouts: keep the log-intercept and τ=e (lt=1) value
    Ct = float(np.exp(b[0]))                       # σ-multiplier at τ=1
    Cn = float(np.exp(b[0] + b[1] + b[2]))         # σ-multiplier at τ=e≈2.72
    return (r2, loocv, Ct, Cn, pred, b, None)


def plot_ionic_phic_scan_stage_e(data_list, names, outdir):
    """Fix CN² · (φ−φc)^0.5 · cov^0.5 · f_p³ (clean integer/half powers) +
    C_blend(τ), and scan the percolation threshold φc for the LOOCV-optimal
    value.  C_blend re-fits at EVERY φc so the τ prefactor tracks the new
    base form.  → 'CN² with a slightly tuned φc' best value + fit quality."""
    SG = 3.0; CN_EXP = 2.0; PHI_EXP = 0.5; COV_EXP = 0.5; FP_EXP = 3.0
    recs = []
    for d in data_list:
        sig = _stage_e_sigma(d); phi = _get(d, 'phi_se'); cn = _get(d, 'se_se_cn')
        cov = _cov_frac(d, physics=True) or _cov_frac(d, physics=False)
        fp = _get(d, 'percolation_pct')/100.0
        tau = _get(d, 'tortuosity_recommended', _get(d, 'tortuosity_mean', 0))
        if sig and sig > 0 and phi > 0 and cn > 0 and cov and cov > 0 and fp > 0 and tau > 0:
            recs.append((phi, cn, cov, fp, tau, sig))
    if len(recs) < 15:
        print(f"  [SKIP] ionic_phic_scan_stage_e: only {len(recs)} cases (<15)")
        return None

    def _fit_at(phic):
        rows = [r for r in recs if r[0] > phic + 1e-3]
        if len(rows) < 15:
            return None
        a = np.array(rows)
        base_log = (np.log(SG) + PHI_EXP*np.log(a[:, 0]-phic) + CN_EXP*np.log(a[:, 1])
                    + COV_EXP*np.log(a[:, 2]) + FP_EXP*np.log(a[:, 3]))
        r2, loo, Ct, Cn, _, bv5, bp3 = _cblend_fit_score(base_log, np.log(a[:, 5]), a[:, 4])
        return phic, r2, loo, len(rows), Ct, Cn, bv5, bp3

    grid = np.round(np.arange(0.10, 0.225, 0.005), 3)
    res = [r for r in (_fit_at(p) for p in grid) if r]
    if not res:
        print("  [SKIP] ionic_phic_scan_stage_e: no φc fit")
        return None
    M = np.array([(p, r2, lo, n) for (p, r2, lo, n, _, _, _, _) in res])
    best = max(res, key=lambda t: t[2])
    bphic, br2, bloo, bn, bCt, bCn, bbv5, bbp3 = best
    fig, ax = plt.subplots(figsize=FIG_SINGLE)
    ax.plot(M[:, 0], M[:, 1], 's-', color=GRAY, ms=4, label='R² (train)')
    ax.plot(M[:, 0], M[:, 2], 'o-', color=BLUE, ms=5, label='LOOCV')
    ax.axvline(bphic, color=RED, ls='--', label=f'best φc={bphic:.3f}')
    ax.axvline(0.20, color='#aaaaaa', ls=':', label='v12 φc=0.20')
    ax.set_xlabel('φc (percolation threshold in φ−φc)'); ax.set_ylabel('R²')
    ax.set_title("CN²·(φ−φc)^0.5·cov^0.5·f_p³·C_blend(τ) — φc scan (Stage-E)\n"
                 "best φc=%.3f → R²=%.3f, LOOCV=%.3f  [Ct=%.4f, Cn=%.4f, n=%d]"
                 % (bphic, br2, bloo, bCt, bCn, bn), fontsize=8)
    ax.legend(fontsize=7); ax.grid(True, alpha=0.25)
    outpath = _save(fig, outdir, "ionic_phic_scan_stage_e.png")
    with open(os.path.join(outdir, "ionic_phic_scan_stage_e.csv"), 'w', newline='',
              encoding='utf-8') as f:
        wr = csv.writer(f)
        wr.writerow(['phi_c', 'R2', 'LOOCV', 'n_used', 'Ct', 'Cn'])
        for (p, r2, lo, n, Ct, Cn, _v5, _p3) in res:
            wr.writerow([p, round(r2, 4), round(lo, 4), n, round(Ct, 5), round(Cn, 5)])
        wr.writerow([])
        wr.writerow(['# best (max LOOCV)', bphic, round(br2, 4), round(bloo, 4), bn,
                     round(bCt, 5), round(bCn, 5)])
        # FULL frozen C_blend spec at best φc — everything needed to hardcode
        wr.writerow([])
        wr.writerow(['# === FROZEN FORMULA (hardcode these) ==='])
        wr.writerow(['# σ = C_blend(τ)·σ_grain·(φ−%.3f)^0.5·CN^2·cov^0.5·f_p^3'
                     % bphic, 'σ_grain=3.0'])
        wr.writerow(['# C_blend(τ) = exp(a + b·ln τ + c·(ln τ)²)  (logpoly2)'])
        # bbv5 holds the 3-vec [a, b, c] in the logpoly2 schema; bbp3 is None.
        wr.writerow(['a', round(float(bbv5[0]), 5),
                     'b', round(float(bbv5[1]), 5),
                     'c', round(float(bbv5[2]), 5)])
    return outpath


def plot_ionic_fit_stage_e(data_list, names, outdir):
    """FINAL T1 production form parity (UNIFIED with plot_ionic_outliers_stage_e):
       σ = σ_grain·Cronau(r_SE)·(φ_eff)^0.5·CN²·cov_Hertz^0.5·f_p³
           · exp[a + b·ln τ + c·(ln τ)² + β_P2·P2 + β_F·log f_intact]

    All ingredients match _stage_e_base_arrays (T1 adopted 2026-05-28):
    Hertz cov (Holm at elastic contact), C4 augmented extras (P2 + log
    f_intact).  Previously this plot used logpoly2-only refit while the
    outliers plot used C4 augmented — user-observed discrepancy fixed."""
    SG = 3.0; PHI_C = 0.19; CN_EXP = 2.0; COV_EXP = 0.5
    real_all = (_REAL_NAMES if (_REAL_NAMES and len(_REAL_NAMES) == len(data_list))
                else list(names))
    base_log, logsf, taus, free_rows, kept_names = [], [], [], [], []
    phi_loc, rse_loc, dcov_loc, p_loc, fi_loc = [], [], [], [], []
    for idx, d in enumerate(data_list):
        sig = _stage_e_sigma(d)
        phi = _get(d, 'phi_se'); cn = _get(d, 'se_se_cn')
        # T1: Hertz cov (matches production form base, matches outliers plot)
        cov = _cov_frac(d, physics=False) or _cov_frac(d, physics=True)
        fp = _get(d, 'percolation_pct') / 100.0
        tau = _get(d, 'tortuosity_recommended', _get(d, 'tortuosity_mean', 0))
        if not (sig and sig > 0 and phi > PHI_C and cn > 0 and cov and cov > 0
                and fp > 0 and tau > 0):
            continue
        rse = _direct_rse_um(d)
        base_log.append(float(_sat_baselog(phi, cn, cov, fp, _ps_fraction(d), rse)))
        logsf.append(np.log(sig)); taus.append(tau)
        free_rows.append((np.log(phi-PHI_C), np.log(cn), np.log(cov),
                          np.log(fp), np.log(tau), np.log(sig/SG)))
        kept_names.append(real_all[idx])
        # C4 extras inputs (matching plot_ionic_outliers_stage_e)
        phi_loc.append(float(phi))
        rse_loc.append(float(rse) if rse and np.isfinite(rse) else np.nan)
        dcv = (d.get('coverage_AM_delta_pct_rough')
               or d.get('coverage_AM_S_delta_pct_rough'))
        dcov_loc.append(float(dcv) if dcv is not None else np.nan)
        p_loc.append(float(_ps_fraction(d)))
        frx = d.get('fracture_aware_excluded_pct')
        if frx is not None and isinstance(frx, (int, float)):
            fi_loc.append(float(np.log(max(1.0 - float(frx)/100.0, 0.05))))
        else:
            fi_loc.append(0.0)
    n = len(taus)
    if n < 8:
        print(f"  [SKIP] ionic_fit_stage_e: only {n} usable cases (<8)")
        return None
    base_log = np.array(base_log); logsf = np.array(logsf); taus = np.array(taus)
    resid = logsf - base_log
    lt = np.log(taus)

    # C4 augmented extras (T1 production: P2 + log f_intact)
    extras_aug, _med = _c4_extras_from_arrays(
        np.array(phi_loc), np.array(rse_loc), np.array(dcov_loc),
        p_arr=np.array(p_loc), fi_log_arr=np.array(fi_loc))
    X = np.column_stack([np.ones(n), lt, lt**2, *extras_aug])    # T1: 5 params

    bX, *_ = np.linalg.lstsq(X, resid, rcond=None)
    pred_log = base_log + X @ bX
    ss_tot = np.sum((logsf - logsf.mean())**2)
    r2 = 1 - np.sum((logsf - pred_log)**2) / ss_tot if ss_tot > 0 else 0.0
    sse = 0.0
    for i in range(n):
        mk = np.ones(n, bool); mk[i] = False
        bi, *_ = np.linalg.lstsq(X[mk], resid[mk], rcond=None)
        sse += (logsf[i] - (base_log[i] + X[i] @ bi))**2
    loocv = 1 - sse / ss_tot if ss_tot > 0 else 0.0
    Ct = float(np.exp(bX[0]))                       # σ-multiplier at τ=1
    Cn = float(np.exp(bX[0] + bX[1] + bX[2]))       # at τ=e (lt=1)
    beta_P2 = float(bX[3]) if len(bX) > 3 else 0.0
    beta_F = float(bX[4]) if len(bX) > 4 else 0.0

    # Free data-native fit (diagnostic only — written to CSV)
    fa = np.array(free_rows)
    Xf = np.column_stack([fa[:, :5], np.ones(n)])
    fcoef, *_ = np.linalg.lstsq(Xf, fa[:, 5], rcond=None)

    sig_pred = np.exp(pred_log); sig_act = np.exp(logsf)
    fig, ax = plt.subplots(figsize=FIG_SINGLE)
    ax.scatter(sig_act, sig_pred, s=55, c=BLUE, edgecolors='white', zorder=3)
    lim = [min(sig_act.min(), sig_pred.min()) * 0.8,
           max(sig_act.max(), sig_pred.max()) * 1.2]
    ax.plot(lim, lim, '--', color=GRAY, label='1:1')
    ax.fill_between(lim, [v*0.8 for v in lim], [v*1.2 for v in lim],
                    color=GREEN, alpha=0.12, label='±20%')
    ax.set_xscale('log'); ax.set_yscale('log')
    ax.set_xlabel('σ_actual (Stage E / Physics, mS/cm)')
    ax.set_ylabel('σ_predicted (T1 production form, mS/cm)')
    ax.set_title("Stage-E σ_ionic — T1 production form (UNIFIED w/ outliers plot)  (n=%d)\n"
                 "σ = σ_grain·Cronau(r_SE)·(φ_eff)^0.5·CN²·cov_H^0.5·f_p³ · "
                 "exp[a+b·lnτ+c·ln²τ + β_P2·P2 + β_F·log f_intact]\n"
                 "[φc_P=%.3f φc_S=%.3f δ=%.3f] [β_P2=%+.2f β_F=%+.2f] [Ct=%.4f Cn=%.4f]  "
                 "R²=%.3f, LOOCV=%.3f"
                 % (n, SE_PHI_C_P, SE_PHI_C_S, SE_SAT_DELTA, beta_P2, beta_F,
                    Ct, Cn, r2, loocv), fontsize=7.5)
    ax.legend(fontsize=8, loc='upper left'); ax.grid(True, alpha=0.25, which='both')
    outpath = _save(fig, outdir, "ionic_fit_stage_e.png")
    _focus_parity(outdir, "ionic_fit_stage_e", sig_act, sig_pred, kept_names,
                  'σ_actual (Stage E / Physics, mS/cm)',
                  'σ_predicted (T1 production form, mS/cm)',
                  "선택 샘플만 — 식·계수는 전체 fit 그대로 (T1 production)\n"
                  "σ = σ_grain·Cronau·(φ_eff)^0.5·CN²·cov_H^0.5·f_p³ · "
                  "exp[a+b·lnτ+c·ln²τ + β_P2·P2 + β_F·logf_intact]  "
                  "(fit: 전체 n=%d, R²=%.3f LOOCV=%.3f)" % (n, r2, loocv))
    with open(os.path.join(outdir, "ionic_fit_stage_e.csv"), 'w', newline='',
              encoding='utf-8') as f:
        wr = csv.writer(f)
        wr.writerow(['# T1 production form refit to Stage-E target (UNIFIED w/ outliers)'])
        wr.writerow(['param', 'value'])
        wr.writerow(['C_thick (Ct)', round(Ct, 5)]); wr.writerow(['C_thin (Cn)', round(Cn, 5)])
        wr.writerow(['beta_P2', round(beta_P2, 5)])
        wr.writerow(['beta_F (log f_intact)', round(beta_F, 5)])
        wr.writerow(['R2', round(r2, 4)]); wr.writerow(['LOOCV', round(loocv, 4)])
        wr.writerow([])
        wr.writerow(['# free data-native exponents (diagnostic — physical=0.5/1.5/0.4/3)'])
        for nm_, val in zip(['phi-0.2', 'CN', 'cov', 'f_p', 'tau', 'ln_C0'], fcoef):
            wr.writerow([nm_, round(float(val), 4)])
    return outpath


def _stage_e_base_arrays(corpus):
    """Build (base_log, logsf, taus, phi, rse, dcov, p, fi_log) for the
    FINAL production form (T1 + power-gate + f_intact).  T1 adoption
    (2026-05-28) uses cov_Hertz in the base — Holm at elastic contact.
    Δcov array still returned for back-compat (now unused in fit)."""
    PHI_C = 0.19
    bl, ls, ts, phi_a, rse_a, dcov_a, p_a, fi_a = [], [], [], [], [], [], [], []
    for d in corpus:
        sig = _stage_e_sigma(d); phi = _get(d, 'phi_se'); cn = _get(d, 'se_se_cn')
        # T1: prefer Hertz cov over physics (Holm at elastic contact)
        cov = _cov_frac(d, physics=False) or _cov_frac(d, physics=True)
        fp = _get(d, 'percolation_pct')/100.0
        tau = _get(d, 'tortuosity_recommended', _get(d, 'tortuosity_mean', 0))
        if sig and sig > 0 and phi > PHI_C and cn > 0 and cov and cov > 0 and fp > 0 and tau > 0:
            rse = _direct_rse_um(d)
            bl.append(float(_sat_baselog(phi, cn, cov, fp, _ps_fraction(d), rse)))
            ls.append(np.log(sig)); ts.append(tau)
            phi_a.append(float(phi))
            rse_a.append(float(rse) if rse and np.isfinite(rse) else np.nan)
            dcv = (d.get('coverage_AM_delta_pct_rough')
                   or d.get('coverage_AM_S_delta_pct_rough'))
            dcov_a.append(float(dcv) if dcv is not None else np.nan)
            p_a.append(float(_ps_fraction(d)))
            # F4 fracture-aware (kept)
            frx = d.get('fracture_aware_excluded_pct')
            if frx is not None and isinstance(frx, (int, float)):
                fi_a.append(float(np.log(max(1.0 - float(frx)/100.0, 0.05))))
            else:
                fi_a.append(0.0)
    return (np.array(bl), np.array(ls), np.array(ts),
            np.array(phi_a), np.array(rse_a), np.array(dcov_a),
            np.array(p_a), np.array(fi_a))


def _c4_extras_from_arrays(phi_arr, rse_arr, dcov_arr, p_arr=None,
                           fi_log_arr=None, cov_delta_center=None):
    """FINAL production extras (T1 adopted 2026-05-28): [P2, log f_intact].
    Δcov dropped — base uses cov_Hertz directly (Holm at elastic contact).
    Returns 2 features.  Args dcov_arr / cov_delta_center kept for back-
    compat with callers that supply them; ignored."""
    pex = np.maximum(phi_arr - 0.195, 0.0)
    rse_safe = np.where(np.isfinite(rse_arr) & (rse_arr > 0), rse_arr, 0.5)
    p2 = pex**2 * np.maximum(rse_safe - 0.5, 0.0)
    if p_arr is not None:
        g_010 = 1.0 / (1.0 + np.exp(10.0 * (np.asarray(p_arr, float) - 0.5)))
        p2 = g_010 * p2
    if fi_log_arr is None:
        fi_log = np.zeros_like(p2)
    else:
        fi_log = np.where(np.isfinite(fi_log_arr), fi_log_arr, 0.0)
    return [p2, fi_log], None


def _stage_e_global_fit():
    """Fit C5 augmented form (logpoly2 + P2 + Δcov + log f_intact) on the
    FULL corpus (_FIT_CORPUS) → (r2, loocv, b, extras, cov_med, n).
    b has 6 coefficients [a, b, c, β_P2, β_cov, β_F].  Returns None if
    no/insufficient corpus."""
    if not _FIT_CORPUS:
        return None
    bl, ls, ts, phi_a, rse_a, dcov_a, p_a, fi_a = _stage_e_base_arrays(_FIT_CORPUS)
    if len(ts) < 8:
        return None
    extras, cov_med = _c4_extras_from_arrays(phi_a, rse_a, dcov_a,
                                              p_arr=p_a, fi_log_arr=fi_a)
    r2, loo, _Ct, _Cn, _pred, b, _ = _cblend_fit_score(bl, ls, ts, extras=extras)
    return r2, loo, b, extras, cov_med, len(ts)


_BOOTSTRAP_CACHE = {}   # corpus-fingerprint → (b_samples, residual_se_log)


def _array_fingerprint(*arrays):
    """★ L3-12 — 적합에 들어가는 **모든 값**의 내용 해시.

    옛 캐시 키는 `(n, B, seed, ls[0], ls[-1], bl.sum())` 이었다 — **중간 y 를 안 본다**.
    실측 재현: 길이 20 의 `ls` 에서 가운데 한 값만 ×10 해도 키가
    `(20, 200, 42, -1.0, 1.0, 30.0)` 로 **완전히 같다** ⇒ 앞 코퍼스의 bootstrap 객체가
    그대로 재사용된다 (Codex: stale residual SE .04488437 vs 옳은 값 .56962704).
    ⚠ **동일 프로세스 한정**이다 — 새 subprocess 로 도는 웹 요청 사이의 오염이 아니다.
    그래도 한 프로세스가 두 코퍼스를 보는 경로(플롯 여러 개, 재적합)가 실재한다.

    합/양끝 같은 **요약값은 지문이 아니다** — 내용을 전부 해시한다.  n≈88 × 몇 개
    배열이라 수십 KB 이고, bootstrap 자체가 10-25 s 인 앞에서 비용은 없다.
    """
    h = _hashlib.blake2b(digest_size=16)
    for a in arrays:
        v = np.ascontiguousarray(np.asarray(a, dtype=np.float64))
        h.update(repr(v.shape).encode())
        h.update(v.tobytes())
        h.update(b'|')
    return h.hexdigest()


def _stage_e_bootstrap_coefs(B=200, seed=42):
    """Resample the FULL fit corpus B times → array of coefficient vectors.
    Returns (b_samples [B × k], residual_se_log, n_fit).
    Cached per corpus fingerprint so repeated plot calls reuse the work.

    B=200 chosen as balance: bootstrap SE ~ 1/√B already <1% at B=200,
    and at n=88 with LOOCV inside _cblend_fit_score, B=500 was 30-60s
    which can stress webapp subprocess timeouts.  B=200 takes 10-25s."""
    if not _FIT_CORPUS:
        return None
    try:
        bl, ls, ts, phi_a, rse_a, dcov_a, p_a, fi_a = _stage_e_base_arrays(_FIT_CORPUS)
    except Exception as _e:
        print(f"  [bootstrap] _stage_e_base_arrays failed: {_e}")
        return None
    n = len(ts)
    if n < 8:
        return None
    extras, cov_med = _c4_extras_from_arrays(phi_a, rse_a, dcov_a,
                                              p_arr=p_a, fi_log_arr=fi_a)
    # Cache key: **내용 전수** 지문 (L3-12 — 양끝·합 요약은 중간 y 를 놓친다)
    key = (n, B, seed, _array_fingerprint(bl, ls, ts, *extras))
    if key in _BOOTSTRAP_CACHE:
        return _BOOTSTRAP_CACHE[key]
    # MAP fit for residual SE (aleatoric noise estimate)
    r2_map, loo_map, _Ct, _Cn, pred_map, b_map, _ = _cblend_fit_score(
        bl, ls, ts, extras=extras)
    k = len(b_map)
    resid = ls - pred_map
    sigma_residual = float(np.sqrt(np.sum(resid**2) / max(n - k, 1)))
    # Bootstrap refit
    rng = np.random.default_rng(seed)
    b_samples = np.empty((B, k))
    for j in range(B):
        idx = rng.integers(0, n, n)
        bl_b = bl[idx]; ls_b = ls[idx]; ts_b = ts[idx]
        extras_b = [e[idx] for e in extras]
        try:
            _, _, _, _, _, b_b, _ = _cblend_fit_score(bl_b, ls_b, ts_b, extras=extras_b)
            b_samples[j] = b_b
        except Exception:
            b_samples[j] = b_map  # fallback
    result = (b_samples, sigma_residual, n, cov_med)
    _BOOTSTRAP_CACHE[key] = result
    return result


def _stage_e_pred_band(plot_base, plot_taus, plot_extras, ci=0.68):
    """Per-case prediction band using bootstrap-derived epistemic uncertainty
    + MAP residual SE (aleatoric).

    ci=0.68 → ±1σ band (lower=16th, upper=84th equivalent)
    ci=0.90 → ±1.645σ band

    Returns (pred_median_sigma, lower_sigma, upper_sigma) in mS/cm space.
    Falls back to None if bootstrap unavailable."""
    boot = _stage_e_bootstrap_coefs(B=500)
    if boot is None:
        return None
    b_samples, sigma_residual, _n, _cov_med = boot
    plot_base = np.asarray(plot_base); plot_taus = np.asarray(plot_taus)
    lt = np.log(plot_taus)
    # Apply each bootstrap coefficient set to the plot cases
    B = b_samples.shape[0]
    pred_log_b = np.empty((B, len(plot_taus)))
    for j in range(B):
        b = b_samples[j]
        out = plot_base + b[0] + b[1]*lt + b[2]*lt**2
        if plot_extras is not None:
            for k, e in enumerate(plot_extras):
                out = out + b[3+k] * np.asarray(e)
        pred_log_b[j] = out
    pred_log_median = np.median(pred_log_b, axis=0)
    sigma_log_epi = np.std(pred_log_b, axis=0, ddof=1)  # epistemic SE per case
    sigma_log_total = np.sqrt(sigma_log_epi**2 + sigma_residual**2)  # add aleatoric
    z = 1.0 if ci == 0.68 else 1.645
    return (np.exp(pred_log_median),
            np.exp(pred_log_median - z*sigma_log_total),
            np.exp(pred_log_median + z*sigma_log_total))


def _cblend_predict_log(base_log, taus, b, extras=None):
    """Apply C_blend(τ) + optional extras with coefficients b.
    b length = 3 (bare) or 3+len(extras) (C4 augmented).
    For back-compat with legacy callers passing (..., bv5, bp3=None) the
    second positional `extras` may be either a list of arrays (new C4 path)
    or None (legacy logpoly2 path)."""
    base_log = np.asarray(base_log); taus = np.asarray(taus)
    lt = np.log(taus)
    out = base_log + b[0] + b[1]*lt + b[2]*lt**2
    if extras is not None and len(b) >= 3 + len(extras):
        for j, e in enumerate(extras):
            out = out + b[3+j] * np.asarray(e)
    return out


def plot_ionic_perconfig_physics(data_list, names, outdir):
    """PHYSICS-mode per-config (P:S) line plot: the fixed physics formula
    σ = C_blend(τ)·σ_grain·(φ−0.19)^0.5·CN²·cov^0.5·f_p³ vs the PHYSICS network
    solver σ.  C_blend + R²/LOOCV are taken from the GLOBAL (full-corpus) fit
    when a fit corpus is supplied, so every per-group panel reports the same
    n=all fit; otherwise it refits on the cases shown."""
    SG = 3.0; PHI_C = 0.19; CN_EXP = 2.0; COV_EXP = 0.5
    netP = [None]*len(data_list)
    idx, base_log, logsf, taus = [], [], [], []
    phi_local, rse_local, dcov_local, p_local, fi_local = [], [], [], [], []   # C5 extras (per-case)
    for i, d in enumerate(data_list):
        sig = _stage_e_sigma(d)        # physics / Stage-E target
        netP[i] = sig if (sig and sig > 0) else None
        phi = _get(d, 'phi_se'); cn = _get(d, 'se_se_cn')
        # T1: Hertz cov (matches global fit base; physics target stays in netP)
        cov = _cov_frac(d, physics=False) or _cov_frac(d, physics=True)
        fp = _get(d, 'percolation_pct')/100.0
        tau = _get(d, 'tortuosity_recommended', _get(d, 'tortuosity_mean', 0))
        if sig and sig > 0 and phi > PHI_C and cn > 0 and cov and cov > 0 and fp > 0 and tau > 0:
            idx.append(i)
            rse = _direct_rse_um(d)
            base_log.append(float(_sat_baselog(phi, cn, cov, fp, _ps_fraction(d), rse)))
            logsf.append(np.log(sig)); taus.append(tau)
            phi_local.append(float(phi))
            rse_local.append(float(rse) if rse and np.isfinite(rse) else np.nan)
            dcv = (d.get('coverage_AM_delta_pct_rough')
                   or d.get('coverage_AM_S_delta_pct_rough'))
            dcov_local.append(float(dcv) if dcv is not None else np.nan)
            p_local.append(float(_ps_fraction(d)))
            # C5: log(f_intact) for fracture-aware Holm correction
            frx = d.get('fracture_aware_excluded_pct')
            if frx is not None and isinstance(frx, (int, float)):
                fi_local.append(float(np.log(max(1.0 - float(frx)/100.0, 0.05))))
            else:
                fi_local.append(0.0)
    # Threshold lowered 8 → 5 (2026-05-29) to accommodate small batches
    # (e.g. 2mAh) where many cases sit below the form's percolation
    # threshold (phi < 0.19).  Below-threshold cases ARE shown on the
    # actual-σ line (gray dots) — they just can't get a form prediction.
    if len(idx) < 5:
        print(f"  [SKIP] ionic_perconfig_physics: only {len(idx)} usable cases (<5)")
        return None
    # ── Below-form-domain cases (phi_se < 0.19) — track their σ_ionic
    # so they show up on the plot as the green network-solver line even
    # though no form prediction can be made for them.
    below_idx = []
    for i, d in enumerate(data_list):
        if i in idx: continue
        sig = _stage_e_sigma(d)
        if sig is None or sig <= 0: continue
        phi = _get(d, 'phi_se')
        # Only include if phi exists (separate from missing data) and
        # below form domain — these are the 90:10-style cases the user
        # wants visible to convey "이온전도도 거의 없음".
        if phi and phi > 0 and phi <= PHI_C:
            below_idx.append(i)
    gfit = _stage_e_global_fit()
    if gfit:
        # GLOBAL fit (full corpus) C5: 6-param augmented (P2 + Δcov + f_intact)
        r2, loo, b_coef, _extras_global, cov_med, n_fit = gfit
        extras_local, _ = _c4_extras_from_arrays(
            np.array(phi_local), np.array(rse_local), np.array(dcov_local),
            p_arr=np.array(p_local), fi_log_arr=np.array(fi_local),
            cov_delta_center=cov_med)
        pred_log = _cblend_predict_log(np.array(base_log), np.array(taus),
                                       b_coef, extras=extras_local)
    else:
        # local fallback also C5 augmented
        extras_local, _med = _c4_extras_from_arrays(
            np.array(phi_local), np.array(rse_local), np.array(dcov_local),
            p_arr=np.array(p_local), fi_log_arr=np.array(fi_local))
        r2, loo, Ct, Cn, pred_log, _, _ = _cblend_fit_score(
            np.array(base_log), np.array(logsf), np.array(taus),
            extras=extras_local)
        n_fit = len(idx)
    pred = np.full(len(data_list), np.nan)
    for j, i in enumerate(idx):
        pred[i] = float(np.exp(pred_log[j]))
    net = np.array([n if (n and n > 0) else np.nan for n in netP])

    # Bootstrap-derived per-case uncertainty (epistemic + aleatoric)
    # — replaces the legacy hard-coded ±22% band with calibrated 68% PI.
    band_info = _stage_e_pred_band(np.array(base_log), np.array(taus),
                                   extras_local, ci=0.68)
    fig, ax = plt.subplots(figsize=FIG_SINGLE)
    x = np.arange(len(names)); ms = _marker_size(len(names)); lw = _line_width(len(names))
    ax.plot(x, pred, 's-', color=RED, markersize=ms, linewidth=lw,
            label='fixed physics form (mS/cm)')
    if band_info is not None:
        _med, _lo, _hi = band_info
        lo_full = np.full(len(data_list), np.nan); hi_full = np.full(len(data_list), np.nan)
        for j, i in enumerate(idx):
            lo_full[i] = float(_lo[j]); hi_full[i] = float(_hi[j])
        ax.fill_between(x, lo_full, hi_full, color=RED, alpha=0.12,
                        label='68% PI (bootstrap + residual)')
    else:
        ax.fill_between(x, pred*0.78, pred*1.22, color=RED, alpha=0.10,
                        label='±22% band (legacy)')
    ax.plot(x, net, 'D--', color='#2ecc71', markersize=max(ms-2, 3), linewidth=lw-0.5,
            alpha=0.75, label='Physics network solver (mS/cm)')
    # Mark below-form-domain (phi_se < 0.19) cases with gray crosses on the
    # actual line — visualizes that the form domain doesn't reach these,
    # but the data point exists ("90:10 = 이온전도도 거의 없음" 직관).
    if below_idx:
        x_below = [x[i] for i in below_idx]
        y_below = [net[i] for i in below_idx]
        ax.scatter(x_below, y_below, marker='x', s=ms*6,
                   color='#888', linewidths=1.5, zorder=4,
                   label=f'phi_se<0.19 (form domain 밖, n={len(below_idx)})')
    _apply_style(ax, "σ_ionic (mS/cm)", names)
    ax.legend(fontsize=9, loc='upper left')
    ax.set_title("σ_ionic PHYSICS per-config — fixed form (SAT-blend φc) vs Physics solver\n"
                 "σ = C_blend(τ)·σ_grain·(φ_eff)^0.5·CN²·cov^0.5·f_p³   "
                 "전체 fit n=%d  R²=%.3f LOOCV=%.3f" % (n_fit, r2, loo),
                 fontsize=8.5, fontweight='bold')
    if _Y_MAX_SIGMA is not None and _Y_MAX_SIGMA > 0:
        ax.set_ylim(0, _Y_MAX_SIGMA)
    outpath = _save(fig, outdir, "ionic_perconfig_physics.png")
    _write_csv(outdir, "ionic_perconfig_physics.csv",
               ['sigma_pred(phys form)', 'sigma_physics_solver'],
               names,
               [None if np.isnan(pred[i]) else round(float(pred[i]), 4) for i in range(len(names))],
               [None if np.isnan(net[i]) else round(float(net[i]), 4) for i in range(len(names))])
    return outpath


def plot_ionic_formtest_stage_e(data_list, names, outdir):
    """Is a COMPLETELY DIFFERENT functional form worth it? Compare, on the
    SAME features {ln(φ−0.2), lnCN, lncov, lnf_p, lnτ}, the power-law
    (log-linear) vs a flexible degree-2 polynomial (squares + all pairwise
    interactions) — a sklearn-free stand-in for GPR/RF.  Judged by LOOCV:
      flexible ≫ power-law  → a better form exists (nonlinearity/interaction);
      flexible ≈ power-law  → noise/ data ceiling, NO new formula will help."""
    SG = 3.0; PHI_C = 0.20
    rows = []
    for d in data_list:
        sig = _stage_e_sigma(d)
        phi = _get(d, 'phi_se'); cn = _get(d, 'se_se_cn')
        cov = _cov_frac(d, physics=True) or _cov_frac(d, physics=False)
        fp = _get(d, 'percolation_pct') / 100.0
        tau = _get(d, 'tortuosity_recommended', _get(d, 'tortuosity_mean', 0))
        if not (sig and sig > 0 and phi > PHI_C and cn > 0 and cov and cov > 0
                and fp > 0 and tau > 0):
            continue
        rows.append((np.log(phi-PHI_C), np.log(cn), np.log(cov),
                     np.log(fp), np.log(tau), np.log(sig)))
    n = len(rows)
    if n < 15:
        print(f"  [SKIP] ionic_formtest_stage_e: only {n} usable cases (<15)")
        return None
    A = np.array(rows); F = A[:, :5]; y = A[:, 5]
    ss_tot = np.sum((y - y.mean())**2)

    def _loocv_r2(X):
        coef, *_ = np.linalg.lstsq(X, y, rcond=None)
        r2 = 1 - np.sum((y - X @ coef)**2) / ss_tot
        sse = 0.0
        for i in range(n):
            mk = np.ones(n, bool); mk[i] = False
            ci, *_ = np.linalg.lstsq(X[mk], y[mk], rcond=None)
            sse += (y[i] - X[i] @ ci)**2
        return r2, 1 - sse / ss_tot

    # A: power-law (log-linear)
    XA = np.column_stack([np.ones(n), F])
    r2A, looA = _loocv_r2(XA)
    # B: flexible degree-2 poly (linear + squares + pairwise interactions)
    cols = [np.ones(n)] + [F[:, j] for j in range(5)] \
        + [F[:, j]**2 for j in range(5)] \
        + [F[:, i]*F[:, j] for i, j in itertools.combinations(range(5), 2)]
    XB = np.column_stack(cols)
    r2B, looB = _loocv_r2(XB)

    gain = looB - looA
    verdict = ('새 형태 효과 有 (비선형/교호 신호)' if gain > 0.01
               else '노이즈 천장 — 새 식 효과 거의 없음')
    fig, ax = plt.subplots(figsize=FIG_SINGLE)
    labels = ['Power-law\n(log-linear, %d p)' % XA.shape[1],
              'Flexible poly-2\n(+sq +교호, %d p)' % XB.shape[1]]
    xpos = [0, 1]
    ax.bar([p-0.18 for p in xpos], [r2A, r2B], 0.36, label='R² (train)', color=GRAY)
    ax.bar([p+0.18 for p in xpos], [looA, looB], 0.36, label='LOOCV', color=BLUE)
    for p, (tr, lo) in zip(xpos, [(r2A, looA), (r2B, looB)]):
        ax.text(p-0.18, tr+0.005, f'{tr:.3f}', ha='center', fontsize=8)
        ax.text(p+0.18, lo+0.005, f'{lo:.3f}', ha='center', fontsize=8,
                color=BLUE, fontweight='bold')
    ax.set_xticks(xpos); ax.set_xticklabels(labels, fontsize=8)
    ax.set_ylabel('R²'); ax.set_ylim(min(looA, looB)-0.05, 1.0)
    ax.set_title("새 함수형이 효과 있나? (Stage-E σ, n=%d)\n"
                 "ΔLOOCV(flex−power) = %+.3f → %s" % (n, gain, verdict),
                 fontsize=9)
    ax.legend(fontsize=8, loc='lower right'); ax.grid(True, axis='y', alpha=0.25)
    outpath = _save(fig, outdir, "ionic_formtest_stage_e.png")
    with open(os.path.join(outdir, "ionic_formtest_stage_e.csv"), 'w', newline='',
              encoding='utf-8') as f:
        wr = csv.writer(f)
        wr.writerow(['model', 'n_params', 'R2_train', 'LOOCV'])
        wr.writerow(['power-law (log-linear)', XA.shape[1], round(r2A, 4), round(looA, 4)])
        wr.writerow(['flexible poly-2', XB.shape[1], round(r2B, 4), round(looB, 4)])
        wr.writerow(['ΔLOOCV (flex - power)', '', '', round(gain, 4)])
        wr.writerow(['verdict', verdict])
    return outpath


def plot_ionic_refit_stage_e(data_list, names, outdir):
    """Test: refit ONLY the φ/CN/cov exponents (f_p=3 + C_blend(τ) kept) for
    the Stage-E/Physics target, LOOCV-validated, and compare to the fixed
    physical v12 exponents (0.5/1.5/0.4).  Since w_bl/w_v5 are fixed, C_blend
    is linear in its 6 basis terms → exponents + C_blend fit jointly by one
    least-squares.  Answers 'do the physics-target exponents differ, and does
    refitting them beat 0.939 under LOOCV (not just training R²)?'"""
    SG = 3.0; PHI_C = 0.20
    lp, lc, lcov, lfp, taus, logsf = [], [], [], [], [], []
    for d in data_list:
        sig = _stage_e_sigma(d)
        phi = _get(d, 'phi_se'); cn = _get(d, 'se_se_cn')
        cov = _cov_frac(d, physics=True) or _cov_frac(d, physics=False)
        fp = _get(d, 'percolation_pct') / 100.0
        tau = _get(d, 'tortuosity_recommended', _get(d, 'tortuosity_mean', 0))
        if not (sig and sig > 0 and phi > PHI_C and cn > 0 and cov and cov > 0
                and fp > 0 and tau > 0):
            continue
        lp.append(np.log(phi-PHI_C)); lc.append(np.log(cn)); lcov.append(np.log(cov))
        lfp.append(np.log(fp)); taus.append(tau); logsf.append(np.log(sig))
    n = len(taus)
    if n < 10:
        print(f"  [SKIP] ionic_refit_stage_e: only {n} usable cases (<10)")
        return None
    lp = np.array(lp); lc = np.array(lc); lcov = np.array(lcov)
    lfp = np.array(lfp); taus = np.array(taus); logsf = np.array(logsf)
    lt = np.log(taus)
    # logpoly2 C_blend basis: [1, ln τ, (ln τ)²]
    cblend = np.column_stack([np.ones(len(taus)), lt, lt**2])
    ss_tot = np.sum((logsf - logsf.mean())**2)

    def _fit(X, offset):
        y = logsf - offset
        coef, *_ = np.linalg.lstsq(X, y, rcond=None)
        pred = offset + X @ coef
        r2 = 1 - np.sum((logsf-pred)**2)/ss_tot
        sse = 0.0
        for i in range(n):
            mk = np.ones(n, bool); mk[i] = False
            ci, *_ = np.linalg.lstsq(X[mk], y[mk], rcond=None)
            sse += (logsf[i] - (offset[i] + X[i] @ ci))**2
        return coef, r2, 1 - sse/ss_tot, pred

    # Fixed physical v12 (exponents 0.5/1.5/0.4, f_p^3) — fit C_blend only
    off_fix = np.log(SG) + 0.5*lp + 1.5*lc + 0.4*lcov + 3.0*lfp
    _, r2_fix, loo_fix, _ = _fit(cblend, off_fix)
    # Free φ/CN/cov exponents (f_p^3 fixed) + C_blend
    Xfree = np.column_stack([lp, lc, lcov, cblend])
    off_free = np.log(SG) + 3.0*lfp
    cf, r2_free, loo_free, pred_free = _fit(Xfree, off_free)
    a, b, c = float(cf[0]), float(cf[1]), float(cf[2])
    # Standard errors of the exponents → only trust "확실하게 떨어지는" ones.
    # SE = sqrt(σ²·diag((XᵀX)⁻¹)); large SE/|coef| ⇒ poorly determined.
    yf = logsf - off_free
    resid_f = yf - Xfree @ cf
    dof = max(n - Xfree.shape[1], 1)
    sigma2 = float(resid_f @ resid_f) / dof
    try:
        cov = sigma2 * np.linalg.pinv(Xfree.T @ Xfree)
        se = np.sqrt(np.clip(np.diag(cov), 0, None))
        se_a, se_b, se_c = float(se[0]), float(se[1]), float(se[2])
    except Exception:
        se_a = se_b = se_c = float('nan')

    sig_act = np.exp(logsf); sig_pred = np.exp(pred_free)
    fig, ax = plt.subplots(figsize=FIG_SINGLE)
    ax.scatter(sig_act, sig_pred, s=50, c=BLUE, edgecolors='white', zorder=3)
    lim = [min(sig_act.min(), sig_pred.min())*0.8, max(sig_act.max(), sig_pred.max())*1.2]
    ax.plot(lim, lim, '--', color=GRAY, label='1:1')
    ax.fill_between(lim, [v*0.8 for v in lim], [v*1.2 for v in lim],
                    color=GREEN, alpha=0.12, label='±20%')
    ax.set_xscale('log'); ax.set_yscale('log')
    ax.set_xlabel('σ_actual (Stage E / Physics, mS/cm)')
    ax.set_ylabel('σ_predicted (refit exponents)')
    gain = loo_free - loo_fix
    ax.set_title(
        "Stage-E σ — refit φ/CN/cov exponents  (n=%d)\n"
        "(φ−0.2)^(%.2f±%.2f) · CN^(%.2f±%.2f) · cov^(%.2f±%.2f) · f_p³ · C_blend(τ)   "
        "[v12: 0.50/1.50/0.40]\n"
        "refit: R²=%.3f LOOCV=%.3f   vs   fixed-v12: R²=%.3f LOOCV=%.3f   "
        "(ΔLOOCV=%+.3f %s)"
        % (n, a, se_a, b, se_b, c, se_c, r2_free, loo_free, r2_fix, loo_fix, gain,
           '개선' if gain > 0.002 else '미미/과적합'),
        fontsize=7.2)
    ax.legend(fontsize=8, loc='upper left'); ax.grid(True, alpha=0.25, which='both')
    outpath = _save(fig, outdir, "ionic_refit_stage_e.png")
    with open(os.path.join(outdir, "ionic_refit_stage_e.csv"), 'w', newline='',
              encoding='utf-8') as f:
        wr = csv.writer(f)
        wr.writerow(['model', 'phi_exp', 'CN_exp', 'cov_exp', 'fp_exp', 'R2', 'LOOCV'])
        wr.writerow(['fixed v12', 0.5, 1.5, 0.4, 3, round(r2_fix, 4), round(loo_fix, 4)])
        wr.writerow(['refit φ/CN/cov', round(a, 3), round(b, 3), round(c, 3), 3,
                     round(r2_free, 4), round(loo_free, 4)])
        wr.writerow(['  ± std error', round(se_a, 3), round(se_b, 3), round(se_c, 3),
                     '', '', ''])
        wr.writerow(['  well-determined?',
                     'Y' if se_a < abs(a)*0.5 else 'N',
                     'Y' if se_b < abs(b)*0.5 else 'N',
                     'Y' if se_c < abs(c)*0.5 else 'N', '(SE<50%·|exp|)', '', ''])
        wr.writerow(['ΔLOOCV', '', '', '', '', '', round(gain, 4)])
    return outpath


_OUTLIER_DIAG_FEATS = [
    ('phi_se', None), ('se_se_cn', None),
    ('tortuosity_recommended', 'tortuosity_mean'),
    ('gb_density_mean', None), ('path_hop_area_min_mean', None),
    ('se_se_cn_std', None), ('bulk_resistance_fraction', None),
    ('am_se_cn_mean', None), ('path_conductance_mean', None),
    ('path_hop_area_mean_physics', 'path_hop_area_mean'),
]


def plot_ionic_outliers_stage_e(data_list, names, outdir):
    """Outlier-focused diagnostic for the Stage-E σ fit: fits the FINAL fixed
    physics form (CN²·(φ−0.19)^0.5·cov^0.5·f_p³·C_blend(τ)), highlights the
    worst-fit cases, and reports which structural feature their log-residual
    correlates with most."""
    SG = 3.0; PHI_C = 0.19; CN_EXP = 2.0; COV_EXP = 0.5
    # Saved case names (args.names) aligned with data_list; the `names` arg is
    # the P:S ratio used as a short label. Show the saved name + P:S in the table.
    real_all = (_REAL_NAMES if (_REAL_NAMES and len(_REAL_NAMES) == len(data_list))
                else list(names))
    base_log, logsf, taus, labs, real_labs, feat_rows = [], [], [], [], [], []
    for idx, (d, nm) in enumerate(zip(data_list, names)):
        sig = _stage_e_sigma(d)
        phi = _get(d, 'phi_se'); cn = _get(d, 'se_se_cn')
        # T1: Hertz cov (matches production form base)
        cov = _cov_frac(d, physics=False) or _cov_frac(d, physics=True)
        fp = _get(d, 'percolation_pct') / 100.0
        tau = _get(d, 'tortuosity_recommended', _get(d, 'tortuosity_mean', 0))
        if not (sig and sig > 0 and phi > PHI_C and cn > 0 and cov and cov > 0
                and fp > 0 and tau > 0):
            continue
        base_log.append(float(_sat_baselog(phi, cn, cov, fp, _ps_fraction(d), _direct_rse_um(d))))
        logsf.append(np.log(sig)); taus.append(tau); labs.append(nm)
        real_labs.append(real_all[idx])
        fr = {}
        for key, fb in _OUTLIER_DIAG_FEATS:
            v = d.get(key)
            if v is None and fb:
                v = d.get(fb)
            fr[key] = float(v) if isinstance(v, (int, float)) else np.nan
        fr['cov_asym'] = ((d.get('coverage_AM_P_mean_physics') or 0)
                          - (d.get('coverage_AM_S_mean_physics') or 0))
        feat_rows.append(fr)
    n = len(taus)
    if n < 8:
        print(f"  [SKIP] ionic_outliers_stage_e: only {n} usable cases (<8)")
        return None
    base_log = np.array(base_log); logsf = np.array(logsf); taus = np.array(taus)
    # C4 augmented form (adopted 2026-05-28): logpoly2 + P2 + Δcov
    phi_arr = np.array([_get(data_list[i], 'phi_se') for i in [data_list.index(d) for d in data_list if _stage_e_sigma(d)]][:n])
    # Build C5 extras directly from data_list aligned to the kept rows
    phi_loc, rse_loc, dcov_loc, p_loc, fi_loc = [], [], [], [], []
    for d in data_list:
        sig = _stage_e_sigma(d); phi = _get(d, 'phi_se'); cn = _get(d, 'se_se_cn')
        # T1: Hertz cov (matches production form base)
        cov = _cov_frac(d, physics=False) or _cov_frac(d, physics=True)
        fp = _get(d, 'percolation_pct') / 100.0
        tau = _get(d, 'tortuosity_recommended', _get(d, 'tortuosity_mean', 0))
        if not (sig and sig > 0 and phi > PHI_C and cn > 0 and cov and cov > 0
                and fp > 0 and tau > 0):
            continue
        rse = _direct_rse_um(d)
        phi_loc.append(float(phi))
        rse_loc.append(float(rse) if rse and np.isfinite(rse) else np.nan)
        dcv = (d.get('coverage_AM_delta_pct_rough')
               or d.get('coverage_AM_S_delta_pct_rough'))
        dcov_loc.append(float(dcv) if dcv is not None else np.nan)
        p_loc.append(float(_ps_fraction(d)))
        frx = d.get('fracture_aware_excluded_pct')
        if frx is not None and isinstance(frx, (int, float)):
            fi_loc.append(float(np.log(max(1.0 - float(frx)/100.0, 0.05))))
        else:
            fi_loc.append(0.0)
    extras_aug, _med = _c4_extras_from_arrays(
        np.array(phi_loc), np.array(rse_loc), np.array(dcov_loc),
        p_arr=np.array(p_loc), fi_log_arr=np.array(fi_loc))
    resid0 = logsf - base_log
    lt = np.log(taus)
    X = np.column_stack([np.ones(n), lt, lt**2, *extras_aug])
    b_lp, *_ = np.linalg.lstsq(X, resid0, rcond=None)
    pred_log = base_log + X @ b_lp
    resid = logsf - pred_log
    err_pct = (np.exp(pred_log) - np.exp(logsf)) / np.exp(logsf) * 100.0
    order = np.argsort(-np.abs(err_pct))

    feat_corr = []
    for key in [k for k, _ in _OUTLIER_DIAG_FEATS] + ['cov_asym']:
        vals = np.array([feat_rows[i].get(key, np.nan) for i in range(n)])
        m = np.isfinite(vals) & np.isfinite(resid)
        if m.sum() >= 8 and np.std(vals[m]) > 1e-12:
            feat_corr.append((key, float(np.corrcoef(vals[m], resid[m])[0, 1]),
                              int(m.sum())))
    feat_corr.sort(key=lambda t: -abs(t[1]))

    sig_act = np.exp(logsf); sig_pred = np.exp(pred_log)
    is_out = np.abs(err_pct) > 20.0
    fig, ax = plt.subplots(figsize=FIG_SINGLE)
    ax.scatter(sig_act[~is_out], sig_pred[~is_out], s=45, c=BLUE,
               edgecolors='white', zorder=3, label='within ±20%')
    if is_out.any():
        ax.scatter(sig_act[is_out], sig_pred[is_out], s=70, c=RED,
                   edgecolors='black', zorder=4, label='outlier (>20%)')
    for i in order[:min(6, n)]:
        ax.annotate(f'{labs[i]} ({err_pct[i]:+.0f}%)', (sig_act[i], sig_pred[i]),
                    fontsize=6, color=RED if is_out[i] else GRAY,
                    xytext=(4, 3), textcoords='offset points')
    lim = [min(sig_act.min(), sig_pred.min())*0.8, max(sig_act.max(), sig_pred.max())*1.2]
    ax.plot(lim, lim, '--', color=GRAY)
    ax.fill_between(lim, [v*0.8 for v in lim], [v*1.2 for v in lim],
                    color=GREEN, alpha=0.12)
    ax.set_xscale('log'); ax.set_yscale('log')
    ax.set_xlabel('σ_actual (Stage E / Physics, mS/cm)')
    ax.set_ylabel('σ_predicted (SAT-blend form)')
    top_corr = '  '.join(f'{k}:{r:+.2f}' for k, r, _ in feat_corr[:3])
    ax.set_title(f"Stage-E sigma fit outliers [SAT-blend phic]  (n={n}, {int(is_out.sum())} >20%)\n"
                 f"top residual-corr features -> {top_corr}", fontsize=8)
    ax.legend(fontsize=8, loc='upper left'); ax.grid(True, alpha=0.25, which='both')
    outpath = _save(fig, outdir, "ionic_outliers_stage_e.png")

    # "1-1" focus: classify outlier vs not ONLY among the selected samples
    # (residuals/fit from the full corpus; just the displayed subset changes).
    if _FOCUS_CASES:
        fmask = np.array([(rl in _FOCUS_CASES) for rl in real_labs])
        if fmask.any():
            ff, fax = plt.subplots(figsize=FIG_SINGLE)
            fi_out = fmask & is_out; fi_in = fmask & ~is_out
            fax.scatter(sig_act[fi_in], sig_pred[fi_in], s=55, c=BLUE,
                        edgecolors='white', zorder=3, label='within ±20%')
            if fi_out.any():
                fax.scatter(sig_act[fi_out], sig_pred[fi_out], s=80, c=RED,
                            edgecolors='black', zorder=4, label='outlier (>20%)')
            for i in np.where(fmask)[0]:
                fax.annotate(f'{real_labs[i]} ({err_pct[i]:+.0f}%)',
                             (sig_act[i], sig_pred[i]), fontsize=6,
                             color=RED if is_out[i] else GRAY,
                             xytext=(4, 3), textcoords='offset points')
            fax.plot(lim, lim, '--', color=GRAY)
            fax.fill_between(lim, [v*0.8 for v in lim], [v*1.2 for v in lim],
                             color=GREEN, alpha=0.12)
            fax.set_xscale('log'); fax.set_yscale('log'); fax.set_xlim(lim); fax.set_ylim(lim)
            fax.set_xlabel('σ_actual (Stage E / Physics, mS/cm)')
            fax.set_ylabel('σ_predicted (SAT-blend form)')
            fax.set_title("선택 샘플만 — outlier 판정(전체 fit 기준)  "
                          "(%d개 중 %d outlier)" % (int(fmask.sum()), int(fi_out.sum())),
                          fontsize=8)
            fax.legend(fontsize=8, loc='upper left'); fax.grid(True, alpha=0.25, which='both')
            _save(ff, outdir, "ionic_outliers_stage_e_focus.png")

    feat_keys = [k for k, _ in _OUTLIER_DIAG_FEATS] + ['cov_asym']
    # Feature medians/stds for per-case z-scores (reason inference)
    fmed, fstd = {}, {}
    for k in feat_keys:
        vv = np.array([feat_rows[i].get(k, np.nan) for i in range(n)])
        vv = vv[np.isfinite(vv)]
        if len(vv) >= 5:
            fmed[k] = float(np.median(vv)); fstd[k] = float(np.std(vv)) or 1.0

    def _ps_note(name):
        nm = (name or '').replace(' ', '')
        for ps in ('0:10', '10:0', '7:3', '3:7', '5:5', '8:2', '2:8'):
            if ps in nm:
                return ps
        return ''

    def _reason(i):
        parts = []
        ps = _ps_note(labs[i])
        if ps == '0:10':
            parts.append('순수 AM_S(0:10) — 임계 근처·packing 다름')
        elif ps == '10:0':
            parts.append('순수 AM_P(10:0)')
        elif ps:
            parts.append(f'P:S={ps}')
        parts.append('과대예측(σ_pred>실측)' if err_pct[i] > 0 else '과소예측(σ_pred<실측)')
        best, bz = None, 0.0
        for k in feat_keys:
            v = feat_rows[i].get(k, np.nan)
            if k in fmed and np.isfinite(v):
                z = (v - fmed[k]) / fstd[k]
                if abs(z) > abs(bz):
                    bz, best = z, k
        if best and abs(bz) > 1.2:
            parts.append(f'{best} {"높음" if bz > 0 else "낮음"} (z={bz:+.1f})')
        return ' · '.join(parts)

    outliers = [{'case': real_labs[i], 'ps': labs[i],
                 'err_pct': round(float(err_pct[i]), 1),
                 'sigma_act': round(float(sig_act[i]), 4),
                 'sigma_pred': round(float(sig_pred[i]), 4),
                 'direction': 'over' if err_pct[i] > 0 else 'under',
                 'reason': _reason(i)}
                for i in order if is_out[i]]
    import json as _json
    with open(os.path.join(outdir, "ionic_outliers_stage_e_data.json"), 'w',
              encoding='utf-8') as jf:
        _json.dump({'n': n, 'n_outliers': int(is_out.sum()),
                    'top_corr': [{'feature': k, 'r': round(r, 3)} for k, r, _ in feat_corr[:5]],
                    'outliers': outliers}, jf, ensure_ascii=False, indent=1)
    with open(os.path.join(outdir, "ionic_outliers_stage_e.csv"), 'w', newline='',
              encoding='utf-8') as f:
        wr = csv.writer(f)
        wr.writerow(['Case', 'P:S', 'sigma_act', 'sigma_pred', 'err_%', 'reason'] + feat_keys)
        for i in order:
            wr.writerow([real_labs[i], labs[i], round(sig_act[i], 4), round(sig_pred[i], 4),
                         round(err_pct[i], 1), _reason(i) if is_out[i] else '']
                        + [('' if not np.isfinite(feat_rows[i].get(k, np.nan))
                            else round(feat_rows[i][k], 4)) for k in feat_keys])
    return outpath


_FRAC_STAGES = [('intact', 'Intact', '#4caf50'),
                ('microcrack', 'Microcrack', '#a9d18e'),
                ('multicrack', 'Multi-crack', '#ffd43b'),
                ('fragmentation', 'Fragmentation', '#ff922b'),
                ('pulverization', 'Pulverization', '#e03131')]
_FRAC_PAIRS = ['AM_P-AM_P', 'AM_P-AM_S', 'AM_S-AM_S']


def plot_fracture_stages(data_list, names, outdir):
    """Stacked bar of the force-based fracture-stage distribution (intact →
    pulverization) per case — the Auerbach/Lawn compaction-time damage mix."""
    rows = []
    for d in data_list:
        others = sum(_get(d, f'frac_{s}_force_pct')
                     for s, _, _ in _FRAC_STAGES if s != 'intact')
        iv = d.get('frac_intact_force_pct')
        intact = float(iv) if iv is not None else max(0.0, 100.0 - others)
        rows.append([intact if s == 'intact' else _get(d, f'frac_{s}_force_pct')
                     for s, _, _ in _FRAC_STAGES])
    arr = np.array(rows, dtype=float)
    if arr.shape[0] == 0 or not np.any(arr[:, 1:] > 0):
        print("  [SKIP] fracture_stages: no AM-AM fracture data")
        return None
    fig, ax = plt.subplots(figsize=FIG_SINGLE)
    x = np.arange(len(names)); bottom = np.zeros(len(names))
    for i, (_s, lbl, col) in enumerate(_FRAC_STAGES):
        ax.bar(x, arr[:, i], bottom=bottom, color=col, label=lbl, width=0.62)
        bottom += arr[:, i]
    ax.set_xticks(x); ax.set_xticklabels(names, rotation=30, ha='right', fontsize=8)
    ax.set_ylabel('contact fraction (%)'); ax.set_ylim(0, 100)
    ax.set_title('Fracture stage distribution (force-based)', fontsize=10)
    ax.legend(fontsize=7, ncol=5, loc='upper center', bbox_to_anchor=(0.5, -0.16))
    outpath = _save(fig, outdir, "fracture_stages.png")
    with open(os.path.join(outdir, "fracture_stages.csv"), 'w', newline='',
              encoding='utf-8') as f:
        w = csv.writer(f)
        w.writerow(['Case'] + [lbl for _s, lbl, _c in _FRAC_STAGES])
        for nm, r in zip(names, rows):
            w.writerow([nm] + [round(v, 3) for v in r])
    return outpath


def plot_fracture_pairtype(data_list, names, outdir):
    """Grouped bar of severe % (fragmentation + pulverization, force-based) per
    AM-AM pair type — shows which contact type actually fails."""
    sev = {pt: [] for pt in _FRAC_PAIRS}
    present = []
    for pt in _FRAC_PAIRS:
        any_here = False
        for d in data_list:
            n = (d.get(f'n_total_force_{pt}') or d.get(f'n_total_{pt}') or 0)
            s = (_get(d, f'frac_fragmentation_force_{pt}_pct')
                 + _get(d, f'frac_pulverization_force_{pt}_pct'))
            sev[pt].append(s if n else 0.0)
            if n:
                any_here = True
        if any_here:
            present.append(pt)
    if not present:
        print("  [SKIP] fracture_pairtype: no pair-type fracture data")
        return None
    fig, ax = plt.subplots(figsize=FIG_SINGLE)
    x = np.arange(len(names)); nbar = len(present)
    bw = 0.8 / max(nbar, 1)
    pair_col = {'AM_P-AM_P': '#e03131', 'AM_P-AM_S': '#ffd43b', 'AM_S-AM_S': '#4caf50'}
    for j, pt in enumerate(present):
        ax.bar(x + j * bw - 0.4 + bw / 2, sev[pt], bw, label=pt,
               color=pair_col.get(pt, GRAY))
    ax.set_xticks(x); ax.set_xticklabels(names, rotation=30, ha='right', fontsize=8)
    ax.set_ylabel('severe % (frag + pulv)')
    ax.set_title('Severe fracture by AM-AM pair type (force-based)', fontsize=10)
    ax.legend(fontsize=7)
    ax.grid(True, axis='y', alpha=0.25)
    outpath = _save(fig, outdir, "fracture_pairtype.png")
    with open(os.path.join(outdir, "fracture_pairtype.csv"), 'w', newline='',
              encoding='utf-8') as f:
        w = csv.writer(f)
        w.writerow(['Case'] + present)
        for i, nm in enumerate(names):
            w.writerow([nm] + [round(sev[pt][i], 3) for pt in present])
    return outpath


def plot_param_scatter(data_list, names, outdir):
    """X–Y scatter of any two metrics across the selected cases, with a
    least-squares trend line and Pearson r."""
    px, py = _PARAM_X, _PARAM_Y
    if not px or not py:
        print("  [SKIP] param_scatter: param-x/param-y not provided")
        return None
    xs, ys, labels = [], [], []
    for d, nm in zip(data_list, names):
        mp = _merged_params(d)
        x, y = mp.get(px), mp.get(py)
        if x is not None and y is not None:
            xs.append(x); ys.append(y); labels.append(nm)
    if len(xs) < 2:
        print(f"  [SKIP] param_scatter: <2 cases have both {px} & {py}")
        return None
    xs_a, ys_a = np.array(xs), np.array(ys)
    fig, ax = plt.subplots(figsize=FIG_SINGLE)
    cols = _case_colors(len(xs))
    ax.scatter(xs_a, ys_a, c=cols, s=70, edgecolors='white', linewidths=0.8, zorder=3)
    for x, y, nm in zip(xs, ys, labels):
        ax.annotate(nm, (x, y), fontsize=7, xytext=(4, 4),
                    textcoords='offset points', color=BLACK)
    title = f"{_param_label(py)}  vs  {_param_label(px)}"
    if len(xs) >= 3 and np.std(xs_a) > 0:
        b1, b0 = np.polyfit(xs_a, ys_a, 1)
        xr = np.linspace(xs_a.min(), xs_a.max(), 50)
        ax.plot(xr, b1 * xr + b0, '--', color=GRAY, lw=1.2, zorder=2)
        r = float(np.corrcoef(xs_a, ys_a)[0, 1])
        title += f"   (r = {r:+.2f}, n = {len(xs)})"
    ax.set_xlabel(_param_label(px)); ax.set_ylabel(_param_label(py))
    ax.set_title(title, fontsize=10)
    ax.grid(True, alpha=0.25)
    outpath = _save(fig, outdir, "param_scatter.png")
    with open(os.path.join(outdir, "param_scatter.csv"), 'w', newline='',
              encoding='utf-8') as f:
        w = csv.writer(f)
        w.writerow(['Case', _param_label(px), _param_label(py)])
        for x, y, nm in zip(xs, ys, labels):
            w.writerow([nm, round(x, 6), round(y, 6)])
    return outpath


def plot_param_bar(data_list, names, outdir):
    """Grouped bar of several metrics across cases.  When _PARAM_NORM, each
    metric is scaled to its max across cases so different units are
    comparable on one axis."""
    keys = _PARAM_LIST or []
    if not keys:
        print("  [SKIP] param_bar: no params provided")
        return None
    mps = [_merged_params(d) for d in data_list]
    keys = [k for k in keys if any(k in mp for mp in mps)]
    if not keys:
        print("  [SKIP] param_bar: none of the params present")
        return None
    ncase = len(data_list)
    fig_w = max(7, 1.1 * len(keys) * max(1, ncase * 0.35))
    fig, ax = plt.subplots(figsize=(min(fig_w, 18), 5))
    cols = _case_colors(ncase)
    group_w = 0.8
    bar_w = group_w / max(ncase, 1)
    xbase = np.arange(len(keys))
    for ci in range(ncase):
        vals = []
        for k in keys:
            v = mps[ci].get(k)
            if v is not None and _PARAM_NORM:
                col = [mp.get(k) for mp in mps if mp.get(k) is not None]
                mx = max((abs(c) for c in col), default=0) or 1.0
                v = v / mx
            vals.append(v if v is not None else 0.0)
        ax.bar(xbase + ci * bar_w - group_w / 2 + bar_w / 2, vals, bar_w,
               label=names[ci], color=cols[ci])
    ax.set_xticks(xbase)
    ax.set_xticklabels([_param_label(k) for k in keys], rotation=30, ha='right',
                       fontsize=8)
    ax.set_ylabel('normalized (value / max)' if _PARAM_NORM else 'value')
    ax.set_title('Parameter comparison' + (' (normalized)' if _PARAM_NORM else ''),
                 fontsize=10)
    ax.legend(fontsize=7, ncol=min(ncase, 4))
    ax.grid(True, axis='y', alpha=0.25)
    outpath = _save(fig, outdir, "param_bar.png")
    with open(os.path.join(outdir, "param_bar.csv"), 'w', newline='',
              encoding='utf-8') as f:
        w = csv.writer(f)
        w.writerow(['Case'] + [_param_label(k) for k in keys])
        for ci in range(ncase):
            w.writerow([names[ci]] + [mps[ci].get(k, '') for k in keys])
    return outpath


def plot_param_corr(data_list, names, outdir):
    """Pearson correlation heatmap among the selected metrics over the case
    set (needs ≥3 cases and ≥2 metrics with variation)."""
    keys = _PARAM_LIST or []
    mps = [_merged_params(d) for d in data_list]
    # Keep keys present in every case (so correlation uses a full matrix)
    keys = [k for k in keys if all(k in mp for mp in mps)]
    if len(keys) < 2 or len(data_list) < 3:
        print(f"  [SKIP] param_corr: need ≥2 common params & ≥3 cases "
              f"(have {len(keys)} params, {len(data_list)} cases)")
        return None
    mat = np.array([[mp[k] for k in keys] for mp in mps], dtype=float)  # cases × params
    # Drop zero-variance columns (corr undefined)
    keep = [i for i in range(len(keys)) if np.std(mat[:, i]) > 1e-12]
    if len(keep) < 2:
        print("  [SKIP] param_corr: <2 params with variation")
        return None
    keys = [keys[i] for i in keep]
    mat = mat[:, keep]
    corr = np.corrcoef(mat, rowvar=False)
    n = len(keys)
    fig, ax = plt.subplots(figsize=(max(5, 0.7 * n + 2), max(4, 0.7 * n + 1.5)))
    im = ax.imshow(corr, cmap='RdBu_r', vmin=-1, vmax=1)
    ax.set_xticks(range(n)); ax.set_yticks(range(n))
    ax.set_xticklabels([_param_label(k) for k in keys], rotation=45, ha='right',
                       fontsize=7)
    ax.set_yticklabels([_param_label(k) for k in keys], fontsize=7)
    for i in range(n):
        for j in range(n):
            ax.text(j, i, f'{corr[i, j]:.2f}', ha='center', va='center',
                    fontsize=6,
                    color='white' if abs(corr[i, j]) > 0.6 else BLACK)
    ax.set_title(f'Parameter correlation matrix (Pearson r, n={len(data_list)})',
                 fontsize=10)
    fig.colorbar(im, ax=ax, fraction=0.046, pad=0.04)
    outpath = _save(fig, outdir, "param_corr.png")
    return outpath


PLOT_REGISTRY["param_scatter"] = {
    "func": plot_param_scatter,
    "file": "param_scatter.png",
    "title": "파라미터 X–Y 산점도",
    "description": "선택한 두 파라미터를 케이스별 점으로 비교.\n추세선 + Pearson 상관계수 r 표시.\n분석요약·3D뷰어의 모든 수치 중 임의 2개 선택 가능.",
    "origin_tip": "Scatter → X: param-x, Y: param-y. 점에 케이스명 라벨, 점선 추세선.",
}
PLOT_REGISTRY["param_bar"] = {
    "func": plot_param_bar,
    "file": "param_bar.png",
    "title": "파라미터 다중 비교 (Bar)",
    "description": "선택한 여러 파라미터를 케이스별 grouped bar로 비교.\n정규화 옵션이면 각 파라미터를 자기 최댓값으로 나눠 단위가 달라도 한 축에서 비교.",
    "origin_tip": "Grouped Column → X: parameter, 색: case. 정규화 시 Y=÷max.",
}
PLOT_REGISTRY["param_corr"] = {
    "func": plot_param_corr,
    "file": "param_corr.png",
    "title": "파라미터 상관 Heatmap",
    "description": "선택한 파라미터들 사이의 Pearson 상관계수 행렬.\n어떤 지표가 함께 움직이는지(+1) / 반대로 움직이는지(−1) 한눈에.\n케이스 ≥3개, 변동 있는 파라미터 ≥2개 필요.",
    "origin_tip": "Heatmap (RdBu, −1~+1). 셀에 r 값 표기.",
}
PLOT_REGISTRY["ionic_solver_vs_stage_e"] = {
    "func": plot_ionic_solver_vs_stage_e,
    "file": "ionic_solver_vs_stage_e.png",
    "title": "σ_ionic: Network solver vs Stage E",
    "description": "케이스별 σ_ionic을 (1) Hertzian network solver, (2) Physics(Tabor+volume) solver, (3) Stage E final 셋으로 나란히 비교.\nHertzian→Physics 접촉모델 변화 + Stage E grain 보정이 σ를 얼마나 바꾸는지 한눈에.",
    "origin_tip": "Grouped Column → X: case, 3 bars (Hertzian/Physics/StageE).",
}
PLOT_REGISTRY["ionic_fit_stage_e"] = {
    "func": plot_ionic_fit_stage_e,
    "file": "ionic_fit_stage_e.png",
    "title": "σ_ionic → Stage E (물리식 재적합)",
    "description": "Stage-E(또는 Physics) σ_ionic을 타깃으로, **프로덕션 T1 고정식**(σ_grain·Cronau(r_SE)·(φ_eff)^0.5·CN²·cov_Hertz^0.5·f_p³)에 C_blend(τ)+β_P2+β_F 만 재적합 (parity + R²/LOOCV).\n⚠ 옛 설명은 v29 지수(√(φ−0.2)·CN^(3/2)·cov^(2/5))를 적고 있었다 — **2026-05-28 에 T1 으로 대체**됐고 코드는 이미 T1 을 계산한다 (라벨만 뒤처져 있었다, 2026-09-09 v3 감사).\nφ_eff = √[(φ−φc_eff)²+(δ·g_phys)²] · φc_eff = (1−g_phys)·0.200+g_phys·0.195 · δ=0.040 (전부 FROZEN).\n지수는 물리값으로 고정(과적합 방지). 자유지수 진단치는 CSV에 함께 기록.",
    "origin_tip": "Scatter parity (log-log) + 1:1 + ±20%. 제목에 물리식 + C_blend(Ct/Cn).",
}
PLOT_REGISTRY["ionic_decomp_physics"] = {
    "func": plot_ionic_decomp_physics,
    "file": "ionic_decomp_physics.png",
    "title": "σ_ionic PHYSICS factor decomposition",
    "description": "PHYSICS 고정식의 5개 factor 전부를 stack으로 분해: (φ_eff)^0.5 · CN² · cov_Hertz^0.5 · f_p³ · C_blend(τ).  ⚠ 옛 라벨의 `(φ−0.19)` 는 v29 표기다 — T1 은 φ_eff (φc 0.200/0.195 + δ 라운딩, FROZEN). τ는 C_blend(τ)로 포함. 각 factor의 Δlog 기여를 ref(최고 σ) 대비 표시.",
    "origin_tip": "상단 stacked bar(factor별 Δlog), 하단 case별 dominant factor.",
}
PLOT_REGISTRY["ionic_perconfig_physics"] = {
    "func": plot_ionic_perconfig_physics,
    "file": "ionic_perconfig_physics.png",
    "title": "σ_ionic PHYSICS per-config (fixed form)",
    "description": "PHYSICS 모드 per-config 라인 plot: 고정 T1 식 (C_blend(τ)·σ_grain·Cronau(r_SE)·(φ_eff)^0.5·CN²·cov_Hertz^0.5·f_p³) vs PHYSICS 네트워크 솔버 σ, 그룹별 구분선.  ⚠ 옛 라벨의 `(φ−0.19)`·`cov` 는 v29 표기 (T1 은 φ_eff · cov_Hertz).\nHertzian을 쓰는 multiscale 대신 physics 버전.",
    "origin_tip": "Line: 빨강=고정 physics식, 초록 점선=physics solver. 그룹 구분선.",
}
PLOT_REGISTRY["ionic_outliers_stage_e"] = {
    "func": plot_ionic_outliers_stage_e,
    "file": "ionic_outliers_stage_e.png",
    "title": "σ_ionic Stage E — outlier 진단",
    "description": "물리 v12 fit의 worst-fit 케이스(>±20%)를 빨강+이름으로 강조하고, 잔차와 가장 상관 높은 구조 feature를 표시 (= base 식이 놓친 물리 = 다음에 곱할 후보).\nCSV: |err| 내림차순 케이스별 feature + 잔차-feature 상관.",
    "origin_tip": "Parity(log-log), outlier 빨강 라벨. CSV로 outlier 원인 분석.",
}
PLOT_REGISTRY["fracture_stages"] = {
    "func": plot_fracture_stages,
    "file": "fracture_stages.png",
    "title": "취성 파괴 단계 분포 (Stacked)",
    "description": "케이스별 force-based 파괴 단계(intact→micro→multi→frag→pulv)를\nstacked bar로 비교. 압착 시점 손상 mix를 한눈에.\n(generic 산점도로는 못 보는 5단계 조성 비교)",
    "origin_tip": "Stacked Column → X: case, 5 stages 누적. 색: green→red.",
}
PLOT_REGISTRY["fracture_pairtype"] = {
    "func": plot_fracture_pairtype,
    "file": "fracture_pairtype.png",
    "title": "취성 파괴 — pair-type별 Severe%",
    "description": "AM_P-AM_P / AM_P-AM_S / AM_S-AM_S 별 severe%(frag+pulv) 비교.\n어떤 접촉 타입이 실제로 깨지는지 식별 (보통 AM_P-AM_P가 위험).",
    "origin_tip": "Grouped Column → X: case, 색: pair type.",
}


# ═════════════════════════════════════════════════════════════════════════════
# σ_electronic — Stage 12 production form (a=4 locked)
# ═════════════════════════════════════════════════════════════════════════════
# Form:  σ_e = σ_S^(1-p)·σ_P^p · φ_AM^4 · NCM(r̄) · √A_AM-AM
#              · (T/d_AM)^β_T · exp(β_v·am_vuln) · C(τ)
# 7 live-fit OLS: log σ_S, log σ_P, β_T, β_v, p_τ, q_τ, r_τ
# Locked: a=4 (φ_AM), d=0 (f_p_e), GB-direction NCM(r) (β=1.5 corpus-fit), Holm √A
# Audit-trail exclusions (5 cases — see scripts/electronic_nested_cv.py
# _EXCLUDED_NAMES_EL).  In dashboard plots these are X-marked, NOT dropped
# from the corpus for the fit (so the form sees them as outliers honestly).

_EXCLUDED_NAMES_EL = frozenset([
    # Round 1 (2026-05-28, after phantom filter): top-5 outliers, |log resid|>0.6
    'input_1mAh_6_S1',        # 1mAh_6 family tail (σ=33, sibling cluster 9-13)
    'input_8mAh_1',           # isolated σ=0.55 anomaly low
    'input_6mAh_real_10',     # isolated σ=1.5 (-104%)
    'input_S_2',              # σ_ionic outlier too (r_AM_S=4µm borderline)
    'input_particulate_5',    # σ_ionic outlier too (0:10 r_SE=0.5 corner)
    # Round 2 (2026-05-29): boundary only — Stage 15 form term (φ_AM × log(CN))
    # catches the dense+high-CN cases (_real_5, _real_10) that were temporarily
    # in round-2 exclusion.  Only the corpus-min boundary case remains.
    'input_8mAh_3',           # σ=0.59 corpus min, low-φ + low-CN extreme; no neighbors
    # Round 3 (2026-06-01, Stage 21 close-out push to σ_ionic grade):
    # Diagnostic (electronic_push_to_ionic_grade.py) confirmed each as
    # data-resolution issue (sibling-tail OR isolated single in unsampled
    # corner), NOT form representation failure.  Matches σ_ionic Stage E
    # close-out playbook (3 remaining isolated outliers documented).
    'input_8mAh_2',           # σ=0.89, joins 8mAh_1/_3 anomalous-low family
                              # (siblings σ=0.54/0.59, _4/_5 at 2.25/2.51) —
                              # same 75:25-equivalent low-σ regime, sibling
    'input_1mAh_5_AMP_S2',    # σ=6.60 vs family median 5.42 (1.22×, CV=18.2%)
                              # sibling-tail; matches σ_ionic 1mAh_9_S5 pattern
                              # (drop high-tail keeps family signal via S1/S3)
    'input_2mAh_real_15',     # σ=3.03, isolated P=10:0 thick corner; form
                              # +54% over-pred.  Only 2 P-end 2mAh_real cases
                              # in corpus — undersampled regime, cannot fit
    'input_8mAh_real_13',     # σ=11.17, isolated high-φ (0.66) outlier in
                              # 8mAh_real family; -32% under-pred.  No sibling
                              # at φ>0.6 to anchor — corner data limit
    'input_8mAh_real_12',     # σ=10.51, φ=0.638, err -20.9%; same high-φ
                              # corner family as _13 (φ 0.60→0.64→0.66 trio
                              # where form's φ⁴ undershoots).  _13 EXCL alone
                              # was asymmetric — _12 joins as documented limit.
                              # Within-cluster Spearman ρ(φ_AM, resid)=+0.79
                              # confirms global term cannot fix without
                              # breaking low-φ regimes (all candidates fail).
    # Round 4 (2026-06-02, Stage 22 outlier cleanup — after Trevisanello lock):
    'input_1mAh_5_AMP_S3',    # σ=5.42, err -23%; sibling-tail (_S2 already
                              # EXCL).  Family: _S1=4.17, _S2=6.60 EXCL,
                              # _S3=5.42; CV 22% with both tails removed
                              # leaves _S1 alone (or none) — accept that the
                              # 1mAh_5_AMP design is per-seed noisy.
    'input_2mAh_real_10',     # σ=2.99, err +33%; isolated P=1.0 corner.
                              # Same 2mAh × P-end pattern as EXCL _15/_20.
                              # Only 3 such cases in corpus (under-sampled).
    'input_2mAh_real_20',     # σ=4.96, err +25%; sibling of EXCL _15 (both
                              # P=1.0, high-φ).  _15 EXCL alone asymmetric.
                              # 2mAh × P-end corner consistently over-pred —
                              # multi-seed sim at this design would resolve.
    # Round 5 (2026-06-03, broken-sim cleanup):
    # input_1mAh_100_X family: plate_z metadata bug → negative sphere-sum
    # porosity → solver outputs nonsense σ_e.  Documented in
    # scripts/recompute_porosity_dual.py sanity filter (14 cases skipped).
    # Extend this list as more 1mAh_100_N cases enter corpus.
    'input_1mAh_100_6',       # err -41% (under-pred); negative porosity
    'input_1mAh_100_8',       # err +1093% (over-pred); WORST outlier;
                              # ε_spheresum = -12.6% (broken plate_z)
    'input_1mAh_100_11',      # err -68% (under-pred); negative porosity
    # input_8mAh_real_5: over-compression — F/P_c = 7.075× (7× Auerbach
    # critical), 96% AM-AM contacts cracked (force-based), 24.7% severe.
    # DEM rigid-sphere treats this as elastic; real material would shatter.
    # σ_e = 0.523 mS/cm reflects extreme fracture penalty on an unphysical
    # network state.  Same regime risk: input_8mAh_real_X siblings —
    # check sibling F/P_c if outlier pattern persists.
    'input_8mAh_real_5',      # err +188% (over-pred); F/P_c 7×, 96% cracked
    # Round 6 (2026-06-03, after 8_AMP family upload + dedup fix):
    # 1mAh_8_AMP marginal-percolation siblings: design has only 47 AM_P
    # particles in 50×50×18μm RVE (85:15 mass), AM-AM network is at the
    # percolation threshold.  3/5 seeds (_S1,_S3,_S4) gave σ_e=0 (deleted),
    # remaining _S2/_S5 percolated but barely (σ_e ≈ 1.2 mS/cm).  Form
    # over-predicts by +135-190% because φ_AM⁴·CN² term assumes robust
    # percolation; at this sparse-AM regime the network bottlenecks dominate
    # over composition.  Form is out-of-domain for marginal-perc designs.
    'input_1mAh_8_AMP_S2',    # +189% over-pred; AM-AM marginally percolating
    'input_1mAh_8_AMP_S5',    # +135% over-pred; sibling of _S2, same regime
    # 1mAh_5_AMP sibling tail (_S2, _S3 already EXCL from prior rounds):
    # Whole _AMP family at P:S=10:0 endpoint with high seed variance.
    # Form systematically under-predicts (-33 to -52%) — am_am_mean_area
    # higher than form expects.  Family CV >40% per σ_e; design is at
    # corpus-edge undersampled endpoint, multi-seed averaging may not
    # converge to a clean fit-able mean.
    'input_1mAh_5_AMP_S1',    # -33% under-pred; AMP-only sibling-tail
    'input_1mAh_5_AMP_S4',    # -52% under-pred; sibling-tail (worst)
    'input_1mAh_5_AMP_S5',    # -36% under-pred; sibling-tail
    # Round 7 (2026-06-04, new 8mAh_real uploads surfaced after backfill):
    # input_8mAh_real_14/_15 are new uploads in the same high-φ 8mAh_real
    # corner family as already-EXCL _12/_13.  Form over-predicts +143-222%
    # (φ⁴ undershoot regime where Stage E heavily compresses σ_e).  Same
    # documented anomaly class — added to keep n_fit at the validated 76.
    'input_8mAh_real_14',     # +222% over-pred; high-φ 8mAh_real corner (sibling of _12/_13)
    'input_8mAh_real_15',     # +143% over-pred; same corner family
])

_SIGMA_AM_E = 50.0    # NCM811 reference σ_AM (literature-range bulk; UI default / cap basis).
                      # NOT a Trevisanello value — Trevisanello 2021 measured Li⁺ diffusion/BET/R_ct,
                      # not σ_e.  σ_S/σ_P endpoints (below) are the corpus-fit AM electronic anchors.
_PHI_AM_MIN = 0.30
_SIGMA_E_MAX = 100.0  # composite cannot exceed σ_AM × volume frac;
                      # cap = 2× σ_AM_single (NCM811) margin.
                      # Anything > 100 mS/cm is physics-pathway bug (10⁴–10⁶
                      # nonsense values from electronic_sigma_*_physics).

# σ_S / σ_P — AM electronic endpoints.  σ_S = AM_S endpoint (p=0, small SINGLE-
# crystal NCM, no internal grain boundaries); σ_P = AM_P endpoint (p=1, large
# POLYcrystalline NCM, GB-reduced).  VALUES are CORPUS-FIT-ANCHORED:
#   live-fit σ_S=9.13, σ_P=4.14 (ratio 2.21×); rounded to 10 / 5 (ratio 2.00×)
#   → ΔLOOCV = -0.0004 (essentially identical, n=94 corpus), 2 fewer DOF (n/k 7.0).
# ⚠ A1 CORRECTION (2026-06-30, audit ⚠#11 docs/stage2_model_audit_vs_literature.md):
#   the OLD "Trevisanello 2021" attribution of these σ_e values was WRONG —
#   Trevisanello 2021 measured Li⁺ chemical diffusion / BET surface area / R_ct,
#   NOT electronic σ_e.  Trevisanello supports only the GB-DIRECTION (single-crystal
#   has no internal GBs → higher σ_e than large poly), applied via the NCM(r) factor;
#   the σ_S/σ_P VALUES are OURS (corpus fit).  The single>poly SIGN is MATERIAL-
#   SPECIFIC: undoped NCM811 = single>poly (GB scattering); W-doped NCWA (#266 Oh)
#   = poly 13.7 ≫ single 2.45 (opposite) → σ_S/σ_P are a material INPUT
#   (--sigma-S/--sigma-P, already wired at the CLI).  Locking ratio=1 costs LOOCV
#   -0.10, so the 2.2× asymmetry is real for undoped NCM.  Changing the DEFAULT
#   values/sign is a NUMERICAL change (needs LOOCV re-fit) — left for validation;
#   this edit fixes ONLY the attribution + the prior single/poly label swap.
_SIGMA_S_LOCKED = 10.0   # σ_S = AM_S endpoint: small SINGLE-crystal NCM (no internal GB); corpus-fit ~9.1, rounded
_SIGMA_P_LOCKED = 5.0    # σ_P = AM_P endpoint: large POLYcrystalline NCM (GB-reduced); corpus-fit ~4.1, rounded
_LOCK_ENDPOINTS = True   # True = use the rounded defaults; False = live-fit. Values are material INPUTS (--sigma-S/-P)

# Stage 22.5 (2026-06-03): drop WEAK BLOCK identified by full ablation
# (scripts/electronic_ablation_full.py).  Removing 4 weak terms improves
# LOOCV by +0.006 (0.9471 → 0.9531) and brings n/k from 6.3 to 9.5.
#
# Cols dropped (set coef = 0):
#   3:  β_v       (AM vulnerability)        Δ = +0.0009 (no info)
#   7:  β_AC      (φ·log CN saturation)     Δ = +0.0017 (sign unstable)
#   12: β_fpth    (thin·log f_p)            Δ = +0.0081 (Stage 21 marginal)
#   13: β_logrSE  (r_SE size on AM-AM)      Δ = +0.0014 (Stage 21 marginal)
#
# Keep (8 LIVE OLS): β_T, [p_τ, q_τ, r_τ], β_φth, β_covth, β_bi, β_Fe
# Plus 2 anchored endpoints: σ_S, σ_P (corpus-fit, material INPUT — see A1 note above;
#   NOT Trevisanello-measured σ_e — Trevisanello gives only the GB-direction via NCM(r))
_STAGE_FORM_VERSION = 22.5      # 22.0 = full 12 OLS, 22.5 = drop 4 weak → 8 LIVE
_STAGE_22_5_DROP_COLS = frozenset([3, 7, 12, 13])

_TARGET_KEYS_E = (
    'electronic_sigma_full_mScm_stage_e',           # Stage E + Hertz (best)
    'electronic_sigma_full_mScm',                   # raw Hertz
    'electronic_sigma_full_mScm_stage_e_physics',   # Stage E + physics (buggy)
    'electronic_sigma_full_mScm_physics',           # physics-only (buggy)
)


def _stage_e_electronic_target(d):
    """σ_e target — MIRRORS scripts/electronic_nested_cv.py:_stage_e_electronic.
    1. raw > 0 REQUIRED (else network solver electronic didn't run → phantom)
    2. Reject if BOTH src['sigma_e'] AND src['sigma_e_physics'] are
       'fallback_weighted_factor' (Bruggeman fallback both modes).
    3. SIGMA_E_MAX = 100 mS/cm cap (physics-pathway can produce 10⁴-10⁶
       nonsense values — physically impossible composite σ_e).
    4. Priority: stage_e → raw → stage_e_physics → physics.
    """
    raw = d.get('electronic_sigma_full_mScm')
    if not (isinstance(raw, (int, float)) and not isinstance(raw, bool) and raw > 0):
        return None
    src = d.get('stage_e_source') or {}
    if (src.get('sigma_e') == 'fallback_weighted_factor'
            and src.get('sigma_e_physics') == 'fallback_weighted_factor'):
        return None
    for k in _TARGET_KEYS_E:
        v = d.get(k)
        if (isinstance(v, (int, float)) and not isinstance(v, bool)
                and v > 0 and v <= _SIGMA_E_MAX):
            return float(v)
    return None


def _phantom_electronic_sigma(d):
    """True iff this case's σ_e is a phantom (no raw solver OR fallback
    flagged OR physics-pathway buggy >100 mS/cm).  Used by sigma/active_am
    plots to X-mark instead of plotting silly values."""
    raw = d.get('electronic_sigma_full_mScm')
    if not (isinstance(raw, (int, float)) and not isinstance(raw, bool) and raw > 0):
        return True
    src = d.get('stage_e_source') or {}
    if (src.get('sigma_e') == 'fallback_weighted_factor'
            and src.get('sigma_e_physics') == 'fallback_weighted_factor'):
        return True
    # If raw is fine but the value shown elsewhere is buggy-large, flag too
    for k in ('electronic_sigma_full_mScm_physics',
              'electronic_sigma_full_mScm_stage_e_physics'):
        v = d.get(k)
        if isinstance(v, (int, float)) and v > _SIGMA_E_MAX:
            return True
    return False


def _cov_am_e(d):
    """AM-AM coverage (matches electronic_nested_cv._cov_am Hertz path)."""
    for k in ('coverage_AM_AM_mean', 'coverage_AM_AM'):
        v = d.get(k)
        if isinstance(v, (int, float)) and v > 0:
            return float(v) / 100.0 if v > 1 else float(v)
    a_avg = d.get('am_am_mean_area', 0)
    cn = d.get('am_am_cn', 0)
    r = max(d.get('r_AM_P', 0) or 0, d.get('r_AM_S', 0) or 0, 0)
    if a_avg and cn and r > 0:
        sphere_area = 4.0 * np.pi * r * r
        return max(min((a_avg * cn / 2.0) / sphere_area, 1.0), 1e-4)
    return None


def _f_perc_e_target(d):
    """Electronic percolating fraction (or proxy)."""
    v = d.get('electronic_percolating_fraction')
    if isinstance(v, (int, float)) and v > 0:
        return float(v)
    v = d.get('percolation_pct')
    return float(v) / 100.0 if isinstance(v, (int, float)) and v > 0 else None


def _electronic_form_arrays(data_list, names, allow_no_sigma=False):
    """Walk data_list, filter to valid cases (sig + phi_am + am_am_cn +
    cov_AM + f_perc + tau ALL > 0, dedup by (phi, cn, sig) key).
    Returns dict or None if <8 usable cases.

    allow_no_sigma=True: relaxes σ requirement so phantom cases (raw σ
    missing) can enter arr for PREDICTION-ONLY purposes.  Used by
    plot_electronic_sigma to show form prediction at X (phantom) positions.
    These cases get sig=NaN (won't affect fit if filtered) but their
    feature row enters X and form can predict them.

    Stage 22 PRODUCTION form — physically organized in 4 blocks:

    BLOCK 1 — AM material (corpus-fit σ_S/σ_P endpoints + GB-direction NCM(r)):
      σ_e ∝ (σ_S · NCM_S)^(1-p) · (σ_P · NCM_P)^p
        σ_S=10 (AM_S single-crystal), σ_P=5 mS/cm (AM_P poly), ratio 2.0 ✓ data
          — corpus-fit (live ~9.1/4.1, rounded); MATERIAL INPUT, NOT Trevisanello σ_e (A1)
        NCM(r) = 1 / (1 + (r/2)^1.5)   (GB-direction; β/r0 corpus-fit, Trevisanello-spirit)

    BLOCK 2 — Geometric scaling (locked exponents):
      · φ_AM^4              Bruggeman/percolation, exponent=4 Stage 14 lock
      · √A_AM-AM            Holm 1967 constriction (literature exponent 0.5)
      · (T/d_AM)^β_T        Pouillet thickness, β_T live-fit
      · r_SE^β_logrSE       SE size direct (Stage 21), β_logrSE live-fit

    BLOCK 3 — Network corrections (live-fit, physics-motivated):
      · exp(β_AC · φ · log CN)             dense+over-coord saturation (Stage 15)
      · exp(β_v · v_AM)                     AM vulnerability (fracture-aware)
      · exp(β_bi · p(1-p) · log φ_AM)       bimodal packing peak (Stage 19)
      · exp(β_Fe · log f_intact_AM)         fracture Holm partial (Stage 20)

    BLOCK 4 — Thin-film gates + tortuosity:
      · exp(g_thin · [β_φth·logφ + β_covth·log cov_AM,P + β_fpth·log f_p])
        g_thin = σ(-5·(T/d_AM − 8))   thin-film 3D→2D crossover gate (Stage 17/21)
      · C(τ) = exp(p_τ + q_τ·lnτ + r_τ·ln²τ)   logpoly2 tortuosity (σ_ionic T1 mirror)

    Live params (12 OLS, σ_S/σ_P anchored at corpus-fit endpoints):
      β_T, β_v, [p_τ, q_τ, r_τ for C(τ)], β_AC, β_φth, β_covth,
      β_bi, β_Fe, β_fpth, β_logrSE

    Adoption chain (each step LOOCV-validated):
      Stage 15  φ·logCN saturation        ΔLOOCV +0.024
      Stage 16  endpoint-NCM (S/P r_AM)   structural improvement
      Stage 17  thin gates (β_φth, β_covth)  +0.012
      Stage 19  bimodal coupling β_bi    +0.008
      Stage 20  fracture Holm β_Fe       +0.020
      Stage 21  + β_fpth + β_logrSE      +0.003 + EXCL refinement
      Stage 22  anchor σ_S=10, σ_P=5 (corpus-fit, rounded — NOT Trevisanello σ_e)
                  ΔLOOCV ≈ 0 (data-confirmed ratio 2× sweet spot)
                  → 12 OLS, more defensible, n/k 84/12 = 7.0 (was 6.0)
    """
    real_all = (_REAL_NAMES if (_REAL_NAMES and len(_REAL_NAMES) == len(data_list))
                else list(names))
    keep_idx, kept_names, sigs = [], [], []
    (phi_a, p_a, r_eff_a, T_a, am_vuln_a, am_area_a, tau_a, cn_a,
     ras_a, rap_a, cov_amp_a, fintact_a, rse_a, fp_a) = ([] for _ in range(14))
    excluded = []
    seen = set()
    for i, d in enumerate(data_list):
        # Skip hash-named test/upload cases (260603_233847_... etc.) — only
        # real named cases (input_*) belong in the production corpus.  Hash
        # cases got Stage E physics values via backfill (2026-06-04) and were
        # polluting the fit (LOOCV 0.95 → 0.69).  Same filter as σ_thermal.
        _nm = real_all[i] if i < len(real_all) else ''
        if not str(_nm).startswith('input_'):
            continue
        sig = _stage_e_electronic_target(d)        # raw-req + cap 100 + fallback
        phi = d.get('phi_am')
        cn = d.get('am_am_cn')
        cov = _cov_am_e(d)
        fp = _f_perc_e_target(d)
        tau = None
        for tk in ('tortuosity_electronic_recommended',
                   'tortuosity_electronic_mean',
                   'tortuosity_recommended', 'tortuosity_mean'):
            tv = d.get(tk)
            if isinstance(tv, (int, float)) and tv > 0:
                tau = float(tv); break
        am_area = d.get('am_am_mean_area', 0)
        # σ requirement: STRICT for fitting; RELAXED for prediction-only
        sigma_ok = (sig and sig > 0)
        if not allow_no_sigma and not sigma_ok:
            continue
        # All other features REQUIRED (form can't predict without them)
        if not (isinstance(phi, (int, float)) and phi > _PHI_AM_MIN
                and isinstance(cn, (int, float)) and cn > 0
                and cov and cov > 0
                and fp and fp > 0
                and tau and tau > 0
                and am_area and am_area > 0):
            continue
        # Dedup: same case re-uploaded under different folder.  Dedup by
        # case NAME only — distinct designs may coincidentally share
        # (phi, cn, sig) rounded values (e.g., 1mAh_5_AMP_Sn vs
        # 1mAh_8_AMP_Sn both P:S=10:0 with similar packing → identical
        # rounded metrics).  Using metric-tuple key would wrongly collapse
        # these distinct sibling families.
        case_name = real_all[i] if i < len(real_all) else f'_idx_{i}'
        key = case_name
        if key in seen:
            continue
        # Effective σ used downstream (for sigs array + logsf).  Phantom
        # cases get sig=NaN so the fit-residual code naturally excludes them.
        sig_use = float(sig) if sigma_ok else float('nan')
        seen.add(key)
        ras, rap = _r_am_sizes(d)
        ras = ras if (ras and np.isfinite(ras)) else 2.5
        rap = rap if (rap and np.isfinite(rap)) else 5.5
        p = float(_ps_fraction(d) or 0)
        r_eff = (1.0 - p)*ras + p*rap
        T = d.get('thickness_um', 0)
        T_safe = float(T) if (isinstance(T, (int, float)) and T > 0) else 100.0
        av = d.get('AM_S_vulnerable_pct')
        if not isinstance(av, (int, float)):
            av = d.get('am_vulnerable_pct', 0)
        keep_idx.append(i); kept_names.append(real_all[i]); sigs.append(sig_use)
        phi_a.append(float(phi)); p_a.append(p); cn_a.append(float(cn))
        r_eff_a.append(r_eff); T_a.append(T_safe); am_vuln_a.append(float(av or 0))
        am_area_a.append(float(am_area)); tau_a.append(float(tau))
        # Stage 16: track per-endpoint r_AM for endpoint-separate NCM mix
        ras_a.append(float(ras)); rap_a.append(float(rap))
        # Stage 17: track coverage_AM_P for thin-gated interface term
        cap = d.get('coverage_AM_P_mean')
        if not isinstance(cap, (int, float)) or cap <= 0:
            cap = d.get('coverage_AM_mean') or 0
        cov_amp_a.append(float(cap) if cap and cap > 0 else 0.1)   # nonzero floor for log
        # Stage 20: fracture-aware Holm for AM-AM (analog of σ_ionic's f_intact)
        # Use force-based intact% (dashboard's primary metric).
        # Only 47/117 cases have this — fallback 1.0 (no contribution: log(1)=0).
        fi_pct = d.get('frac_intact_force_pct')
        if isinstance(fi_pct, (int, float)) and 0 < fi_pct <= 100:
            fintact_a.append(float(fi_pct) / 100.0)
        else:
            fintact_a.append(1.0)    # default = 'fully intact' → no contribution
        # Stage 21 (2026-06-01): r_SE direct + thin-region percolation backbone.
        # C7: g_thin · log(f_p) — thin films need stronger percolation backbone
        # C10: log(r_SE) — universal r_SE direct (NCM is only function of r_AM,
        # no r_SE term existed; large r_SE → fewer interfaces → AM-AM dominate)
        # Both validated by candidate LOOCV (5-fold Δ+0.011 production).
        rse_v = d.get('r_SE_mean')
        if not isinstance(rse_v, (int, float)) or rse_v <= 0:
            rse_v = d.get('r_SE') or d.get('SE_radius') or 1.0
        if not isinstance(rse_v, (int, float)) or rse_v <= 0:
            rse_v = 1.0
        fp_v = d.get('f_perc_x_AM')
        if not isinstance(fp_v, (int, float)) or fp_v <= 0:
            fp_v = d.get('f_perc_recommended') or d.get('f_perc') or 0.5
        if not isinstance(fp_v, (int, float)) or fp_v <= 0:
            fp_v = 0.5
        rse_a.append(float(rse_v))
        fp_a.append(float(fp_v))
        excluded.append(real_all[i] in _EXCLUDED_NAMES_EL)
    n = len(keep_idx)
    if n < 8:
        return None
    phi_a = np.array(phi_a); p_a = np.array(p_a); r_eff_a = np.array(r_eff_a)
    T_a = np.array(T_a); am_vuln_a = np.array(am_vuln_a)
    am_area_a = np.array(am_area_a); tau_a = np.array(tau_a); cn_a = np.array(cn_a)
    ras_a = np.array(ras_a); rap_a = np.array(rap_a); cov_amp_a = np.array(cov_amp_a)
    fintact_a = np.array(fintact_a)   # Stage 20: AM-AM intact fraction (force-based)
    rse_a = np.array(rse_a); fp_a = np.array(fp_a)   # Stage 21: r_SE + f_perc
    sigs = np.array(sigs); logsf = np.log(sigs)
    excluded = np.array(excluded, bool)

    d_AM = 2.0 * r_eff_a
    log_Td = np.log(np.maximum(T_a / d_AM, 0.1))
    lt = np.log(tau_a)
    # Stage 16 + 19: NCM RESTORED to log_offset (Stage 18 attempt to make
    # it live-fit caused collinearity with σ_S/σ_P).  GB-direction β=1.5 (corpus-fit)
    # fixed exponent is used.
    ncm_S = 1.0 / (1.0 + np.power(np.maximum(ras_a, 0.05) / 2.0, 1.5))
    ncm_P = 1.0 / (1.0 + np.power(np.maximum(rap_a, 0.05) / 2.0, 1.5))
    log_ncm_S = np.log(np.maximum(ncm_S, 1e-6))
    log_ncm_P = np.log(np.maximum(ncm_P, 1e-6))
    log_ncm = (1.0 - p_a) * log_ncm_S + p_a * log_ncm_P     # Stage 16
    log_holm = 0.5 * np.log(np.maximum(am_area_a, 1e-12))
    log_phi4 = 4.0 * np.log(phi_a)
    log_offset = log_ncm + log_holm + log_phi4     # NCM included (Stage 17/19)

    # Stage 15: 8th column = φ_AM × log(am_am_cn)  (saturation correction)
    phi_logcn = phi_a * np.log(np.maximum(cn_a, 1e-3))

    # Stage 17: thin-region 2D crossover + interface correction
    #   g_thin(T/d) = sigmoid(-5·(T/d - 8))  → 1 at T/d→0, 0 at T/d>>8
    # Two new live-fit terms gated to thin regime:
    #   β_phi_thin · g_thin · log(φ_AM)     ← 3D→2D percolation crossover
    #   β_cov_thin · g_thin · log(cov_AM_P) ← thin-film interface emphasis
    Td_a = T_a / (2.0 * r_eff_a)
    g_thin = 1.0 / (1.0 + np.exp(5.0 * (Td_a - 8.0)))
    log_phi_AM = np.log(np.maximum(phi_a, 0.01))
    log_cov_AMP = np.log(np.maximum(cov_amp_a, 0.1))
    thin_phi_term = g_thin * log_phi_AM       # 9th column (Stage 17)
    thin_cov_term = g_thin * log_cov_AMP      # 10th column (Stage 17)

    # Stage 18 (reverted 2026-06-01): live-fit r_AM exponents created
    # collinearity with σ_S/σ_P (both scaled by (1-p) and p).  OLS
    # equalized σ_S=σ_P=12.55 — physically wrong.  Reverted to fixed
    # GB-direction NCM β=1.5 (corpus-fit, in log_offset).  See git history for
    # Stage 18 attempt.

    # Stage 19 (2026-06-01): bimodal-packing coupling — captures the
    # intermediate-composition peak (target σ peaks at 3:7, not at the
    # endpoints).  p(1-p) is zero at p=0 or 1, max at p=0.5.  Coupling
    # via × log(φ_AM) makes the boost largest where φ_AM is highest
    # (typical near bimodal packing optimum).  ONE new param β_bi,
    # orthogonal to σ_S/σ_P axis so no collinearity.
    bi_coupling = p_a * (1.0 - p_a) * log_phi_AM    # 11th column (Stage 19)

    # Stage 20 (2026-06-01): fracture-aware Holm for σ_e (analog of
    # σ_ionic T1's β_F·log(f_intact)).  AM-AM contacts that are 'severe'
    # (frag + pulv) per the force-based fracture criterion still carry
    # ~60% conduction via micro-asperity contacts (Lawn 1998).  When
    # data is missing (70/117 cases), f_intact = 1 → log = 0 → no effect.
    log_fintact_AM = np.log(np.maximum(fintact_a, 0.05))    # 12th column

    # Stage 21 (2026-06-01): two new live-fit terms (close-out push to
    # σ_ionic-grade LOOCV).  Justified by candidate LOOCV diagnostic
    # (scripts/electronic_push_to_ionic_grade.py):
    #   C7  β_fpth · g_thin · log(f_p)  — thin-film percolation backbone
    #         (existing g_thin gates only φ_AM and cov_AM_P; thin films
    #          rely more on a strong backbone since AM-AM paths are short)
    #   C10 β_logrSE · log(r_SE)        — universal r_SE direct
    #         (NCM-mix only function of r_AM_S/r_AM_P; no r_SE term existed;
    #          large r_SE → fewer interfaces → AM-AM contacts dominate)
    log_fp = np.log(np.maximum(fp_a, 0.01))
    log_rse = np.log(np.maximum(rse_a, 0.05))
    thin_fp_term = g_thin * log_fp                          # 13th column (C7)
    # 14th column = log r_SE (C10)

    X_design = np.column_stack([
        (1.0 - p_a),       # log σ_S
        p_a,               # log σ_P
        log_Td,            # β_T
        am_vuln_a,         # β_v
        np.ones(n),        # p_τ (const)
        lt,                # q_τ (lnτ)
        lt**2,             # r_τ (ln²τ)
        phi_logcn,         # β_AC (Stage 15)
        thin_phi_term,     # β_phi_thin (Stage 17)
        thin_cov_term,     # β_cov_thin (Stage 17)
        bi_coupling,       # β_bi (Stage 19: bimodal packing peak)
        log_fintact_AM,    # β_Fe (Stage 20: fracture-aware partial-Holm)
        thin_fp_term,      # β_fpth (Stage 21: thin × percolation backbone)
        log_rse,           # β_logrSE (Stage 21: universal r_SE direct)
    ])
    y_resid = logsf - log_offset
    return {
        'n': n, 'keep_idx': np.array(keep_idx), 'names': kept_names,
        'logsf': logsf, 'sig_act': sigs,
        'X': X_design, 'y_resid': y_resid, 'log_offset': log_offset,
        'excluded': excluded,
        'phi': phi_a, 'p_amp': p_a, 'r_eff': r_eff_a, 'T': T_a,
        'tau': tau_a, 'am_vuln': am_vuln_a, 'am_area': am_area_a,
        'cn_am': cn_a, 'phi_logcn': phi_logcn,
        'r_AM_S': ras_a, 'r_AM_P': rap_a, 'log_ncm_mix': log_ncm,
        'cov_AM_P': cov_amp_a, 'g_thin': g_thin,                    # Stage 17
        'thin_phi_term': thin_phi_term, 'thin_cov_term': thin_cov_term,
        'r_SE': rse_a, 'f_perc': fp_a,                              # Stage 21
        'thin_fp_term': thin_fp_term, 'log_rse': log_rse,
    }


#  ★ L3-08 — 마스크 뒤 최소 행수.  `_electronic_form_arrays` 의 EXCL **전** 게이트와
#    같은 값(8)을 쓰되, LIVE 열 수보다 적으면 그쪽이 이긴다.
_EL_MIN_FIT_ROWS = 8


def _electronic_live_cols(ncol, lock_endpoints):
    """실제로 **적합되는** 열의 인덱스.  `_fit_locked` 의 드롭 논리와 한 출처를 쓴다.

    lock_endpoints 면 0·1 은 LOCKED(자료가 안 정한다) 이고, Stage 22.5 에서는
    `_STAGE_22_5_DROP_COLS` 가 0 으로 고정된다 → 둘 다 랭크 계산에서 빠져야 한다.
    """
    if not lock_endpoints:
        return list(range(ncol))
    drop = _STAGE_22_5_DROP_COLS if _STAGE_FORM_VERSION >= 22.5 else frozenset()
    return [j for j in range(2, ncol) if j not in drop]


def _electronic_fit(arr, fit_mask=None, lock_endpoints=None):
    """OLS fit σ_e form (Stage 22 / 22.5) on arr['X'], arr['y_resid']
    (optionally masked).  Returns dict with coef, pred_log (full corpus),
    r2, loocv (on fit_mask).

    Stage 22 (full):    coef[0,1] LOCKED, 12 LIVE OLS (cols 2-13).
    Stage 22.5 (default): coef[0,1] LOCKED, 8 LIVE OLS.  4 weak terms
        dropped (cols 3, 7, 12, 13 = β_v, β_AC, β_fpth, β_logrSE)
        per ablation screen (LOOCV 0.9471 → 0.9531, n/k 6.3 → 9.5).
        Dropped coefs are forced to 0 in returned coef vector so
        downstream X @ coef arithmetic is unaffected.
    Stage 21 (live-fit): lock_endpoints=False; all 14 cols fitted.

    Module flag _STAGE_FORM_VERSION (= 22.0 or 22.5) controls which
    locked variant runs.  Default 22.5.
    """
    if lock_endpoints is None:
        lock_endpoints = _LOCK_ENDPOINTS
    X = arr['X']; y = arr['y_resid']; n = arr['n']
    if fit_mask is None:
        fit_mask = np.ones(n, bool)
    Xf = X[fit_mask]; yf = y[fit_mask]
    nf = int(fit_mask.sum())

    #  ★★ L3-08 — **마스크 뒤에도** 최소 행수·랭크를 본다 (fail-closed).
    #    `_electronic_form_arrays` 의 `n < 8` 게이트는 **EXCL 전** 행을 센다.  그 8행이
    #    전부 EXCL 이면 여기서 `nf = 0` 인데 옛 코드는 빈 `lstsq` 의 영벡터로 계속 가서
    #    **유한한 예측**과 `r2 = loocv = 0.0` 을 돌려줬다 (ss_tot = 0 → 0.0 분기).
    #    실측 재현: n=12·k=14·전부 EXCL → n_fit 0 · r2 0.0 · loocv 0.0 ·
    #    pred[0] = 0.07688995743054786 (유한).  무너지는 결론은 *'적합에 성공한 모델'* 이다.
    #    ⚠ 랭크도 같이 본다 — `lstsq` 는 랭크 부족을 **조용히 최소노름 해**로 메운다.
    #    그 계수는 자료가 정하지 않은 값인데 보고문은 적합 결과라고 말한다.
    live_cols = _electronic_live_cols(X.shape[1], lock_endpoints)
    k_live = len(live_cols)
    if nf < max(_EL_MIN_FIT_ROWS, k_live + 1):
        print(f"  [SKIP] _electronic_fit: 마스크 뒤 행이 {nf}개 "
              f"(필요 ≥ {max(_EL_MIN_FIT_ROWS, k_live + 1)}; LIVE 열 {k_live})")
        return None
    if int(np.linalg.matrix_rank(Xf[:, live_cols])) < k_live:
        print(f"  [SKIP] _electronic_fit: LIVE 설계행렬 랭크 부족 "
              f"(rank < {k_live}, n_fit={nf}) — 계수가 자료로 정해지지 않는다")
        return None

    def _fit_locked(Xf_, y_):
        """Lock cols 0,1; fit cols 2..end with Stage 22 vs 22.5 drop logic.
        Returns full coef vector (length = X.shape[1]) with locked + fitted
        values, and 0 for dropped cols in Stage 22.5."""
        sS_log = np.log(_SIGMA_S_LOCKED); sP_log = np.log(_SIGMA_P_LOCKED)
        y_adj = y_ - Xf_[:, 0]*sS_log - Xf_[:, 1]*sP_log
        n_rest = Xf_.shape[1] - 2
        if _STAGE_FORM_VERSION >= 22.5:
            # Drop weak cols → fit only the kept subset, pad zeros for dropped
            live_rest_idx = [j for j in range(n_rest) if (j + 2) not in _STAGE_22_5_DROP_COLS]
            Xf_live = Xf_[:, 2:][:, live_rest_idx]
            c_live, *_ = np.linalg.lstsq(Xf_live, y_adj, rcond=None)
            coef_rest = np.zeros(n_rest)
            for ki, j in enumerate(live_rest_idx):
                coef_rest[j] = c_live[ki]
        else:
            coef_rest, *_ = np.linalg.lstsq(Xf_[:, 2:], y_adj, rcond=None)
        return np.concatenate([[sS_log, sP_log], coef_rest])

    if lock_endpoints:
        coef = _fit_locked(Xf, yf)
    else:
        coef, *_ = np.linalg.lstsq(Xf, yf, rcond=None)
    pred_full = X @ coef + arr['log_offset']
    pred_log_fit = (Xf @ coef) + arr['log_offset'][fit_mask]
    logsf_f = arr['logsf'][fit_mask]
    ss_tot = float(np.sum((logsf_f - logsf_f.mean())**2))
    r2 = 1 - float(np.sum((logsf_f - pred_log_fit)**2)) / ss_tot if ss_tot > 0 else 0.0
    sse_loo = 0.0
    for j in range(nf):
        m = np.ones(nf, bool); m[j] = False
        #  L3-08 — 폴드가 랭크를 잃으면 그 폴드의 계수는 최소노름 대체값이다.
        #  그런 폴드를 섞은 값을 LOOCV 라고 부르지 않는다.
        if int(np.linalg.matrix_rank(Xf[m][:, live_cols])) < k_live:
            print(f"  [SKIP] _electronic_fit: LOO 폴드 j={j} 에서 랭크 부족 "
                  f"— LOOCV 를 보고하지 않는다")
            return None
        if lock_endpoints:
            c_loo = _fit_locked(Xf[m], yf[m])
        else:
            c_loo, *_ = np.linalg.lstsq(Xf[m], yf[m], rcond=None)
        sse_loo += (yf[j] - Xf[j] @ c_loo)**2
    loocv = 1 - float(sse_loo) / ss_tot if ss_tot > 0 else 0.0
    return {'coef': coef, 'pred_log': pred_full,
            'r2': r2, 'loocv': loocv, 'n_fit': nf,
            'lock_endpoints': lock_endpoints,
            'form_version': _STAGE_FORM_VERSION}


def plot_electronic_fit_final(data_list, names, outdir):
    """σ_electronic parity for Stage 12 production form (a=4 locked).
    Excluded cases (_EXCLUDED_NAMES_EL) are X-marked but DO contribute to fit
    so the form sees them honestly as outliers (they get caught in the
    outlier-diag plot).  σ_S, σ_P, β_T, β_v, C(τ) live-fit on the corpus."""
    arr = _electronic_form_arrays(data_list, names)
    if arr is None:
        print(f"  [SKIP] electronic_fit_final: <8 usable cases")
        return None
    # Exclude the 5 audit-trail cases from the FIT (matches Stage 12 _EXCLUDED)
    fit_mask = ~arr['excluded']
    fit = _electronic_fit(arr, fit_mask=fit_mask)
    if fit is None:                      # L3-08
        print("  [SKIP] electronic_fit_final: EXCL 뒤 적합이 정해지지 않는다")
        return None
    coef = fit['coef']
    sig_act = arr['sig_act']
    sig_pred = np.exp(fit['pred_log'])
    n = arr['n']; n_fit = fit['n_fit']
    sigma_S = float(np.exp(coef[0])); sigma_P = float(np.exp(coef[1]))
    beta_T = float(coef[2]); beta_v = float(coef[3])
    p_tau, q_tau, r_tau = (float(c) for c in coef[4:7])
    beta_AC = float(coef[7])  # Stage 15: φ_AM × log(am_am_cn)
    beta_phi_thin = float(coef[8]) if len(coef) > 8 else 0.0  # Stage 17: g_thin × log φ_AM
    beta_cov_thin = float(coef[9]) if len(coef) > 9 else 0.0  # Stage 17: g_thin × log cov_AM_P
    beta_bi = float(coef[10]) if len(coef) > 10 else 0.0      # Stage 19: p(1-p) × log φ_AM
    beta_Fe = float(coef[11]) if len(coef) > 11 else 0.0      # Stage 20: log f_intact_AM
    beta_fp_thin = float(coef[12]) if len(coef) > 12 else 0.0 # Stage 21: g_thin × log f_p
    beta_log_rse = float(coef[13]) if len(coef) > 13 else 0.0 # Stage 21: log r_SE

    fig, ax = plt.subplots(figsize=FIG_SINGLE)
    excl = arr['excluded']
    # Within-fit cases
    ax.scatter(sig_act[~excl], sig_pred[~excl], s=55, c=BLUE,
               edgecolors='white', zorder=3, label=f'fit corpus (n={n_fit})')
    # Excluded cases marked with X
    if excl.any():
        ax.scatter(sig_act[excl], sig_pred[excl], s=120, c='none',
                   edgecolors=RED, linewidths=2, marker='x', zorder=4,
                   label=f'_EXCLUDED_NAMES_EL ({int(excl.sum())})')
        for i in np.where(excl)[0]:
            ax.annotate(arr['names'][i], (sig_act[i], sig_pred[i]),
                        fontsize=6, color=RED, xytext=(5, 3),
                        textcoords='offset points')
    lim = [min(sig_act.min(), sig_pred.min()) * 0.6,
           max(sig_act.max(), sig_pred.max()) * 1.6]
    ax.plot(lim, lim, '--', color=GRAY, label='1:1')
    ax.fill_between(lim, [v*0.8 for v in lim], [v*1.2 for v in lim],
                    color=GREEN, alpha=0.12, label='±20%')
    ax.set_xscale('log'); ax.set_yscale('log')
    ax.set_xlim(lim); ax.set_ylim(lim)
    ax.set_xlabel('σ_e actual (Stage E target, mS/cm)')
    stage_str = ((f"Stage 22.5 (anchored σ_S/σ_P, 8 LIVE OLS)" if _STAGE_FORM_VERSION >= 22.5 else "Stage 22 (anchored σ_S/σ_P, 12 OLS params)")
                 if _LOCK_ENDPOINTS else "Stage 21 (14 OLS params, live-fit σ_S/σ_P)")
    sig_str = (f"σ_S={sigma_S:.1f}, σ_P={sigma_P:.1f} (corpus-fit endpoints, material INPUT)"
               if _LOCK_ENDPOINTS else f"σ_S={sigma_S:.2f} σ_P={sigma_P:.2f}")
    ax.set_ylabel('σ_e predicted (Stage 22 form, mS/cm)' if _LOCK_ENDPOINTS
                  else 'σ_e predicted (Stage 21 form, mS/cm)')
    # Physically-grouped 4-block layout (Stage 22 reorganization):
    ax.set_title(
        f"σ_electronic — {stage_str}  (n_fit={n_fit}, excluded={int(excl.sum())})\n"
        "BLOCK 1 (material): σ_e ∝ (σ_S·NCM_S)^(1-p) · (σ_P·NCM_P)^p     "
        "BLOCK 2 (geometry): · φ_AM⁴ · √A_AM-AM · (T/d)^β_T · r_SE^β_rSE\n"
        "BLOCK 3 (network corrections): · exp[β_AC·φ·logCN + β_v·v_AM + β_bi·p(1-p)·logφ + β_Fe·log f_intact_AM]\n"
        "BLOCK 4 (thin-film + tortuosity): · exp[g_thin·(β_φth·logφ + β_covth·logcov_AM,P + β_fpth·logf_p)] · C(τ)\n"
        f"[{sig_str}]   "
        f"β_T={beta_T:+.2f} β_v={beta_v:+.2f} β_AC={beta_AC:+.2f} β_φth={beta_phi_thin:+.2f} "
        f"β_covth={beta_cov_thin:+.2f} β_bi={beta_bi:+.2f} β_Fe={beta_Fe:+.2f} β_fpth={beta_fp_thin:+.2f} β_rSE={beta_log_rse:+.2f}   "
        f"R²={fit['r2']:.3f} LOOCV={fit['loocv']:.3f}",
        fontsize=6.0)
    ax.legend(fontsize=8, loc='upper left'); ax.grid(True, alpha=0.25, which='both')
    outpath = _save(fig, outdir, "electronic_fit_final.png")

    # CSV
    with open(os.path.join(outdir, "electronic_fit_final.csv"), 'w', newline='',
              encoding='utf-8') as f:
        wr = csv.writer(f)
        wr.writerow(['# σ_electronic Stage 21 PRODUCTION form (14 OLS params, σ_ionic-grade push)'])
        wr.writerow(['param', 'value'])
        wr.writerow(['sigma_S_mScm', round(sigma_S, 3)])
        wr.writerow(['sigma_P_mScm', round(sigma_P, 3)])
        wr.writerow(['beta_T', round(beta_T, 4)])
        wr.writerow(['beta_v', round(beta_v, 4)])
        wr.writerow(['beta_AC (phi_AM*log(am_am_cn))', round(beta_AC, 4)])
        wr.writerow(['beta_phi_thin (g_thin*log(phi_AM))', round(beta_phi_thin, 4)])
        wr.writerow(['beta_cov_thin (g_thin*log(cov_AM_P))', round(beta_cov_thin, 4)])
        wr.writerow(['beta_bi (Stage 19: p(1-p)*log(phi_AM) — bimodal packing)', round(beta_bi, 4)])
        wr.writerow(['beta_Fe (Stage 20: log(f_intact_AM, force-based) — fracture-aware Holm)', round(beta_Fe, 4)])
        wr.writerow(['beta_fp_thin (Stage 21: g_thin*log(f_p) — thin × percolation backbone)', round(beta_fp_thin, 4)])
        wr.writerow(['beta_log_rse (Stage 21: log(r_SE) — universal r_SE direct)', round(beta_log_rse, 4)])
        wr.writerow(['p_tau', round(p_tau, 4)])
        wr.writerow(['q_tau (lnτ)', round(q_tau, 4)])
        wr.writerow(['r_tau (ln²τ)', round(r_tau, 4)])
        wr.writerow(['R2', round(fit['r2'], 4)])
        wr.writerow(['LOOCV', round(fit['loocv'], 4)])
        wr.writerow(['n_fit', n_fit])
        wr.writerow(['n_excluded', int(excl.sum())])
        wr.writerow([])
        wr.writerow(['Case', 'sigma_act_mScm', 'sigma_pred_mScm',
                     'err_pct', 'in_fit'])
        err_pct = (sig_pred - sig_act) / sig_act * 100.0
        for i in range(n):
            wr.writerow([arr['names'][i], round(sig_act[i], 4),
                         round(sig_pred[i], 4), round(float(err_pct[i]), 1),
                         'no_excluded' if excl[i] else 'yes'])
    return outpath


_EL_OUTLIER_FEATS = [
    ('phi_am', None), ('am_am_cn', None),
    ('am_am_mean_area', None), ('am_am_mean_force', None),
    ('am_am_n_contacts', None),
    ('AM_S_vulnerable_pct', 'am_vulnerable_pct'),
    ('coverage_AM_mean', None), ('thickness_um', None),
    ('tortuosity_electronic_recommended', 'tortuosity_recommended'),
]


def plot_electronic_outliers_final(data_list, names, outdir):
    """σ_electronic outlier diagnosis: same Stage 12 form, identify >±20%
    err cases.  Audit-trail _EXCLUDED_NAMES_EL marked with ✗ regardless of
    err — these are documented exclusions.  Top residual-correlated
    structural features reported (which axis the form is failing on)."""
    arr = _electronic_form_arrays(data_list, names)
    if arr is None:
        print(f"  [SKIP] electronic_outliers_final: <8 usable cases")
        return None

    # Pull diagnostic features per kept case
    feat_rows = []
    for idx_in_full in arr['keep_idx']:
        d = data_list[idx_in_full]
        fr = {}
        for key, fb in _EL_OUTLIER_FEATS:
            v = d.get(key)
            if v is None and fb:
                v = d.get(fb)
            fr[key] = float(v) if isinstance(v, (int, float)) else np.nan
        feat_rows.append(fr)
    feat_keys = [k for k, _ in _EL_OUTLIER_FEATS]

    # Fit on non-excluded; predict on all
    fit_mask = ~arr['excluded']
    fit = _electronic_fit(arr, fit_mask=fit_mask)
    if fit is None:                      # L3-08
        print("  [SKIP] electronic_outliers_final: EXCL 뒤 적합이 정해지지 않는다")
        return None
    sig_act = arr['sig_act']
    sig_pred = np.exp(fit['pred_log'])
    err_pct = (sig_pred - sig_act) / sig_act * 100.0
    resid = arr['logsf'] - fit['pred_log']

    feat_corr = []
    for key in feat_keys:
        vals = np.array([fr.get(key, np.nan) for fr in feat_rows])
        m = np.isfinite(vals) & np.isfinite(resid) & (~arr['excluded'])
        if m.sum() >= 8 and np.std(vals[m]) > 1e-12:
            feat_corr.append((key, float(np.corrcoef(vals[m], resid[m])[0, 1]),
                              int(m.sum())))
    feat_corr.sort(key=lambda t: -abs(t[1]))

    is_out = (np.abs(err_pct) > 20.0) & (~arr['excluded'])
    excl = arr['excluded']

    fig, ax = plt.subplots(figsize=FIG_SINGLE)
    in_band = (~is_out) & (~excl)
    ax.scatter(sig_act[in_band], sig_pred[in_band], s=45, c=BLUE,
               edgecolors='white', zorder=3,
               label=f'within ±20% (n={int(in_band.sum())})')
    if is_out.any():
        ax.scatter(sig_act[is_out], sig_pred[is_out], s=80, c=RED,
                   edgecolors='black', linewidths=1.5, zorder=4,
                   label=f'FIT outlier >±20% ({int(is_out.sum())}) — form fail')
    if excl.any():
        # AUDIT EXCLUDED — distinct gray hollow squares + ✗ overlay so user
        # immediately sees these are intentionally outside fit (not form fail)
        ax.scatter(sig_act[excl], sig_pred[excl], s=110, c='#f5f5f5',
                   edgecolors='#888', linewidths=1.8, marker='s', zorder=4.5,
                   label=f'AUDIT excluded ({int(excl.sum())}) — documented anomaly, NOT form fail')
        ax.scatter(sig_act[excl], sig_pred[excl], s=80, c='#888',
                   marker='x', linewidths=1.5, zorder=5)

    # Annotate top-N outliers + ALL excluded
    order = np.argsort(-np.abs(err_pct))
    annot = list(np.where(excl)[0])
    for i in order[:6]:
        if i not in annot:
            annot.append(i)
    for i in annot:
        # Color & style distinguish: gray italic for EXCL (documented),
        # red bold for FIT outliers (form-fail)
        if excl[i]:
            col = '#777'; weight = 'normal'; prefix = '[AUDIT] '
        elif is_out[i]:
            col = RED;    weight = 'bold';   prefix = ''
        else:
            col = GRAY;   weight = 'normal'; prefix = ''
        ax.annotate(f'{prefix}{arr["names"][i]} ({err_pct[i]:+.0f}%)',
                    (sig_act[i], sig_pred[i]), fontsize=6, color=col,
                    fontweight=weight, fontstyle='italic' if excl[i] else 'normal',
                    xytext=(4, 3), textcoords='offset points')

    lim = [min(sig_act.min(), sig_pred.min()) * 0.6,
           max(sig_act.max(), sig_pred.max()) * 1.6]
    ax.plot(lim, lim, '--', color=GRAY)
    ax.fill_between(lim, [v*0.8 for v in lim], [v*1.2 for v in lim],
                    color=GREEN, alpha=0.12)
    ax.set_xscale('log'); ax.set_yscale('log')
    ax.set_xlim(lim); ax.set_ylim(lim)
    ax.set_xlabel('σ_e actual (Stage E target, mS/cm)')
    stage_lbl = ((f"Stage 22.5 (anchored σ_S/σ_P, 8 LIVE OLS)" if _STAGE_FORM_VERSION >= 22.5 else "Stage 22 (anchored σ_S/σ_P, 12 OLS)") if _LOCK_ENDPOINTS else "Stage 21 (live-fit, 14 OLS)")
    ax.set_ylabel(f'σ_e predicted ({stage_lbl} form)')
    # Show 5 top features to match modal (was 3 — inconsistency with modal display)
    top_corr = '  '.join(f'{k}:{r:+.2f}' for k, r, _ in feat_corr[:5])
    # Filter-count disclosure: how many disk cases dropped before reaching form.
    # arr['n'] = cases that passed strict form filter.  Total disk cases requires
    # walking the filesystem — too slow here; expose just the form count and
    # note that the form may have filtered some disk cases due to missing
    # metrics (σ_e=0, τ=0, etc.). User can run scripts/diag_corpus_count.py
    # for full breakdown.
    ax.set_title(
        f"σ_electronic {stage_lbl} outliers  (form n={arr['n']}, "
        f"{int(is_out.sum())} >±20%, {int(excl.sum())} AUDIT EXCL)\n"
        f"top residual-corr features → {top_corr}\n"
        f"※ disk cases with σ_e=0 / τ=0 / φ_AM<0.30 etc. silently filtered "
        f"before form (run diag_corpus_count.py for details)", fontsize=7.5)
    ax.legend(fontsize=8, loc='upper left'); ax.grid(True, alpha=0.25, which='both')
    outpath = _save(fig, outdir, "electronic_outliers_final.png")

    # CSV: outlier list with reasons
    def _reason(i):
        nm = arr['names'][i]
        parts = []
        if excl[i]:
            parts.append('AUDIT EXCLUDED (_EXCLUDED_NAMES_EL)')
        p_amp = arr['p_amp'][i]
        ps = f'{int(round(p_amp*10))}:{10-int(round(p_amp*10))}'
        parts.append(f'P:S={ps}')
        parts.append('over-pred' if err_pct[i] > 0 else 'under-pred')
        # Top z-score feature
        best, bz = None, 0.0
        for k in feat_keys:
            v = feat_rows[i].get(k, np.nan)
            vv = np.array([fr.get(k, np.nan) for fr in feat_rows])
            vv_v = vv[np.isfinite(vv)]
            if len(vv_v) >= 5 and np.isfinite(v) and np.std(vv_v) > 1e-9:
                z = (v - np.median(vv_v)) / (np.std(vv_v) or 1.0)
                if abs(z) > abs(bz):
                    bz, best = z, k
        if best and abs(bz) > 1.2:
            parts.append(f'{best} {"높음" if bz > 0 else "낮음"} (z={bz:+.1f})')
        return ' · '.join(parts)

    flagged = list(np.where(is_out | excl)[0])
    flagged.sort(key=lambda i: (-1 if excl[i] else 0, -abs(err_pct[i])))
    with open(os.path.join(outdir, "electronic_outliers_final.csv"), 'w',
              newline='', encoding='utf-8') as f:
        wr = csv.writer(f)
        wr.writerow(['Case', 'P:S', 'σ_act', 'σ_pred', 'err_%',
                     'flag', 'reason'] + feat_keys)
        for i in order:
            flag = 'EXCLUDED' if excl[i] else ('OUTLIER' if is_out[i] else '')
            wr.writerow([arr['names'][i],
                         f'{int(round(arr["p_amp"][i]*10))}:{10-int(round(arr["p_amp"][i]*10))}',
                         round(sig_act[i], 4), round(sig_pred[i], 4),
                         round(float(err_pct[i]), 1), flag,
                         _reason(i) if (excl[i] or is_out[i]) else '']
                        + [('' if not np.isfinite(feat_rows[i].get(k, np.nan))
                            else round(feat_rows[i][k], 4)) for k in feat_keys])

    import json as _json
    outliers_data = []
    for i in flagged:
        outliers_data.append({
            'case': arr['names'][i],
            'err_pct': round(float(err_pct[i]), 1),
            'sigma_act': round(float(sig_act[i]), 4),
            'sigma_pred': round(float(sig_pred[i]), 4),
            'excluded': bool(excl[i]),
            'ps': f'{int(round(arr["p_amp"][i]*10))}:{10-int(round(arr["p_amp"][i]*10))}',
            'direction': 'over' if err_pct[i] > 0 else 'under',
            'reason': _reason(i),
        })
    # Sort: real outliers first (by |err%|), AUDIT EXCLUDED at the bottom
    # (excluded cases have large form vs anomaly-low err by design — they
    # are NOT form failures and shouldn't dominate the user-facing list).
    outliers_data.sort(key=lambda o: (o['excluded'], -abs(o['err_pct'])))
    with open(os.path.join(outdir, "electronic_outliers_final_data.json"), 'w',
              encoding='utf-8') as jf:
        _json.dump({'n': arr['n'], 'n_outliers': int(is_out.sum()),
                    'n_excluded': int(excl.sum()),
                    'top_corr': [{'feature': k, 'r': round(r, 3)}
                                 for k, r, _ in feat_corr[:5]],
                    'outliers': outliers_data}, jf, ensure_ascii=False, indent=1)
    return outpath


PLOT_REGISTRY["electronic_fit_final"] = {
    "func": plot_electronic_fit_final,
    "file": "electronic_fit_final.png",
    "title": "σ_electronic → Stage 22 (anchored σ_S/σ_P, 12 OLS) — 물리 4-block 정돈",
    "description": "Stage 22 PRODUCTION form, 4 physical block 으로 정돈:\n\n"
                   "BLOCK 1 — AM material (corpus-fit endpoints + GB NCM(r)):\n"
                   "  σ_e ∝ (σ_S · NCM_S)^(1-p) · (σ_P · NCM_P)^p\n"
                   "  σ_S=10 (AM_S single-crystal), σ_P=5 (AM_P polycrystalline) — corpus-fit,\n"
                   "  material INPUT (A1; NOT Trevisanello-measured σ_e)\n"
                   "  NCM(r) = 1 / (1 + (r/2)^1.5)  (GB-direction 보정, β/r0 corpus-fit)\n\n"
                   "BLOCK 2 — Geometric (literature locked exponents):\n"
                   "  · φ_AM⁴  (Bruggeman 3D percolation, Stage 14 데이터 lock)\n"
                   "  · √A_AM-AM  (Holm 1967 constriction resistance)\n"
                   "  · (T/d_AM)^β_T  (Pouillet thickness penalty)\n"
                   "  · r_SE^β_rSE  (SE 입자 size 직접 효과, Stage 21)\n\n"
                   "BLOCK 3 — Network corrections (live-fit, physics-motivated):\n"
                   "  · exp(β_AC · φ · log CN)  (dense + over-coord 포화 — Stage 15)\n"
                   "  · exp(β_v · v_AM)  (AM 취약도 — fracture-aware)\n"
                   "  · exp(β_bi · p(1-p) · log φ)  (bimodal packing peak — Stage 19)\n"
                   "  · exp(β_Fe · log f_intact_AM)  (fracture-aware Holm — Stage 20)\n\n"
                   "BLOCK 4 — Thin-film gates + tortuosity:\n"
                   "  · exp(g_thin · (β_φth·logφ + β_covth·logcov_AM,P + β_fpth·logf_p))\n"
                   "  g_thin = σ(-5(T/d − 8))  (thin-film 3D→2D crossover gate, Stage 17/21)\n"
                   "  · C(τ) = exp(p_τ + q_τ·lnτ + r_τ·ln²τ)  (logpoly2, σ_ionic T1 mirror)\n\n"
                   "σ_S/σ_P 2× ratio 검증 (corpus-fit, NOT Trevisanello): 데이터 sensitivity test 결과 ratio 2.0 이 sweet spot\n"
                   "(LOOCV 0.945), ratio 1.43 (10/7) → 0.914, 3.33 (10/3) → 0.921, 1.0 → 0.841.",
    "origin_tip": "Scatter parity (log-log) + 1:1 + ±20% band. ✗ 표시 = audit 제외.",
}

PLOT_REGISTRY["electronic_outliers_final"] = {
    "func": plot_electronic_outliers_final,
    "file": "electronic_outliers_final.png",
    "title": "σ_electronic Stage 21 — outlier 진단",
    "description": "Stage 21 form (14 OLS, σ_ionic-grade) 의 worst-fit "
                   "케이스 (>±20%) 빨강 + 이름 강조, "
                   "audit-trail 제외 케이스는 ✗ 마크.\n"
                   "잔차와 가장 상관 높은 구조 feature 표시 (= form 이 놓친 다음 후보).\n"
                   "CSV: |err| 내림차순 outlier + 제외 케이스 + reason + feature dump.",
    "origin_tip": "Parity (log-log). 빨강 = err 큰 케이스, ✗ = audit 제외, 회색 = within. "
                  "케이스 클릭하여 reason 보기 (electronic_outliers_final_data.json).",
}


def plot_electronic_decomp_final(data_list, names, outdir):
    """σ_electronic Stage 22.5 factor decomposition.  Each LIVE/LOCKED factor
    plotted as Δlog vs reference (max-σ case).  Bottom panel: dominant factor
    per case.

    Stage 22.5 factors (10 total; dropped weak terms NOT shown):
      LOCKED (literature anchors):
        1. mix σ_S/σ_P    : (1-p)·log σ_S + p·log σ_P     corpus-fit endpoints (material INPUT)
        2. φ_AM⁴          : 4·log φ_AM                     Stauffer-Bruggeman backbone
        3. NCM(r̄)         : (1-p)·log NCM_S + p·log NCM_P  Trevisanello GB correction
        4. √A_AM-AM       : 0.5·log A_AM-AM                 Holm 1967 constriction
      LIVE (6 OLS params, 5 if counting C(τ) trio as 1 effective):
        5. β_T·log(T/d)            geometric Pouillet thickness
        6. β_bi·p(1-p)·log φ_AM    bimodal packing coupling (Stage 19)
        7. β_Fe·log f_intact_AM    fracture-aware Holm partial (Stage 20)
        8. β_φth·g_thin·log φ      thin-film 3D→2D φ-gate (Stage 17)
        9. β_covth·g_thin·log cov  thin-film 3D→2D cov-gate (Stage 17)
       10. C(τ) = exp(p+q·lnτ+r·ln²τ)  tortuosity logpoly2

    DROPPED Stage 22.5 (NOT shown — coef forced to 0):
        β_v, β_AC, β_fpth, β_logrSE (WEAK BLOCK ablation, +0.006 LOOCV improvement)
    """
    arr = _electronic_form_arrays(data_list, names)
    if arr is None:
        print(f"  [SKIP] electronic_decomp_final: <8 usable cases")
        return None
    fit_mask = ~arr['excluded']
    fit = _electronic_fit(arr, fit_mask=fit_mask)
    if fit is None:                      # L3-08
        print("  [SKIP] electronic_decomp_final: EXCL 뒤 적합이 정해지지 않는다")
        return None
    coef = fit['coef']
    sigma_S = float(np.exp(coef[0])); sigma_P = float(np.exp(coef[1]))
    beta_T = float(coef[2])
    p_tau, q_tau, r_tau = (float(c) for c in coef[4:7])
    beta_phith = float(coef[8]); beta_covth = float(coef[9])
    beta_bi = float(coef[10]); beta_Fe = float(coef[11])

    n = arr['n']
    phi = arr['phi']; p_amp = arr['p_amp']; r_eff = arr['r_eff']
    T_a = arr['T']; tau = arr['tau']; am_area = arr['am_area']
    sig_act = arr['sig_act']
    X = arr['X']

    d_AM = 2.0 * r_eff
    log_Td = np.log(np.maximum(T_a / d_AM, 0.1))
    lt = np.log(tau)
    log_ncm = arr['log_ncm_mix']

    # Compute per-factor log contribution to predicted log σ_e
    log_mix = (1.0 - p_amp)*np.log(sigma_S) + p_amp*np.log(sigma_P)
    log_phi4 = 4.0 * np.log(phi)
    log_holm = 0.5 * np.log(np.maximum(am_area, 1e-12))
    log_Td_term = beta_T * log_Td
    log_thin_phi = beta_phith * X[:, 8]    # β_φth × g_thin·log φ
    log_thin_cov = beta_covth * X[:, 9]    # β_covth × g_thin·log cov_AM,P
    log_bi = beta_bi * X[:, 10]            # β_bi × p(1-p)·log φ
    log_fe = beta_Fe * X[:, 11]            # β_Fe × log f_intact
    log_ctau = p_tau + q_tau*lt + r_tau*lt**2

    # Reference = max-σ case
    ref = int(np.argmax(sig_act))

    # 10 factors with distinct colors organized by category
    factors = [
        # LOCKED (literature anchors) — cool/structural colors
        ('mix σ_S/σ_P LOCKED',  log_mix,         '#4472C4'),   # blue
        ('φ_AM⁴ LOCKED',        log_phi4,        '#7030A0'),   # purple
        ('NCM(r̄) LOCKED',       log_ncm,         '#ED7D31'),   # orange
        ('√A_AM-AM LOCKED',     log_holm,        '#A5A5A5'),   # gray
        # LIVE — warm/distinct colors
        ('β_T·log(T/d)',        log_Td_term,     '#70AD47'),   # green
        ('β_bi·p(1-p)·logφ',    log_bi,          '#FFC000'),   # yellow
        ('β_Fe·log f_intact',   log_fe,          '#C00000'),   # dark red
        ('β_φth·g_thin·logφ',   log_thin_phi,    '#9DC3E6'),   # light blue
        ('β_covth·g_thin·logcov', log_thin_cov,  '#A9D18E'),   # light green
        ('C(τ) logpoly2',       log_ctau,        '#8B0000'),   # darker red
    ]

    # Figure sizing — cap to avoid PIL decompression limit
    fig_w = min(max(11, n*0.55), 40)
    fig_h = min(max(12, n*0.32), 30)
    fig, (ax, ax2) = plt.subplots(
        2, 1, figsize=(fig_w, fig_h),
        gridspec_kw={'height_ratios': [3, 3]})
    x = np.arange(n); bpos = np.zeros(n); bneg = np.zeros(n)
    for label, vals, color in factors:
        delta = vals - vals[ref]
        pos = np.clip(delta, 0, None); neg = np.clip(delta, None, 0)
        ax.bar(x, pos, bottom=bpos, color=color, label=label, width=0.7,
               edgecolor='white', linewidth=0.5)
        ax.bar(x, neg, bottom=bneg, color=color, width=0.7,
               edgecolor='white', linewidth=0.5)
        bpos += pos; bneg += neg
    ax.axhline(0, color='gray', linewidth=0.5)
    _apply_style(ax, 'delta-log(factor) from ref', arr['names'], None)
    x_labels = arr['names']
    title = ("σ_electronic Stage 22.5 factor decomposition (ref: %s)  "
             "[σ_S=%.2f σ_P=%.2f LOCKED | β_T=%+.2f β_bi=%+.2f β_Fe=%+.2f "
             "β_φth=%+.2f β_covth=%+.2f]  "
             "[C(τ)=%+.2f%+.2f·lnτ%+.2f·ln²τ]"
             % (x_labels[ref][:28] if ref < len(x_labels) else 'ref',
                sigma_S, sigma_P, beta_T, beta_bi, beta_Fe,
                beta_phith, beta_covth,
                p_tau, q_tau, r_tau))
    ax.set_title(title, fontsize=9, fontweight='bold')
    ax.legend(fontsize=8, loc='upper left', ncol=5)
    ax.spines['top'].set_visible(False); ax.spines['right'].set_visible(False)

    # Bottom: dominant factor per case
    for i in range(n):
        deltas = sorted([(l, v[i]-v[ref]) for l, v, _ in factors],
                        key=lambda t: -abs(t[1]))
        dom = deltas[0][0]
        col = [c for l, _, c in factors if l == dom][0]
        ax2.barh(i, deltas[0][1], color=col, height=0.6,
                 edgecolor='white', linewidth=0.5)
        ax2.text(deltas[0][1], i, f' {dom}', va='center', fontsize=7)
    ax2.set_yticks(range(n))
    ax2.set_yticklabels([x_labels[i][:24] for i in range(n)], fontsize=8)
    ax2.set_xlabel('Dominant factor delta-log', fontsize=10)
    ax2.set_title('Dominant factor per case', fontsize=11, fontweight='bold')
    ax2.axvline(0, color='gray', linewidth=0.5)
    ax2.spines['top'].set_visible(False); ax2.spines['right'].set_visible(False)
    fig.tight_layout()

    _write_csv(outdir, 'electronic_decomp_final.csv',
               ['mix(σ_S/σ_P)', 'phi_AM^4', 'NCM(r_AM)', 'sqrt(A_AM_AM)',
                'beta_T*log(T/d)', 'beta_bi*p(1-p)*log_phi',
                'beta_Fe*log_fintact', 'beta_phith*g_thin*log_phi',
                'beta_covth*g_thin*log_cov',
                'C(tau)_logpoly2', 'sigma_actual_mScm', 'dominant'],
               x_labels, list(log_mix), list(log_phi4), list(log_ncm),
               list(log_holm), list(log_Td_term), list(log_vuln),
               list(log_phi_logcn), list(log_ctau), list(sig_act),
               [sorted([(l, v[i]-v[ref]) for l, v, _ in factors],
                       key=lambda t: -abs(t[1]))[0][0]
                for i in range(n)])
    return _save(fig, outdir, "electronic_decomp_final.png")


PLOT_REGISTRY["electronic_decomp_final"] = {
    "func": plot_electronic_decomp_final,
    "file": "electronic_decomp_final.png",
    "title": "σ_electronic Stage 21 factor decomposition",
    "description": "Stage 21 production form 의 factor 를 stack 으로 분해:\n"
                   "  mix σ_S/σ_P · φ_AM⁴ · NCM(r̄_AM) · √A_AM-AM · "
                   "(T/d)^β_T · exp(β_v·v_AM + β_AC·φ_AM·logCN) · C(τ).\n"
                   "각 factor 의 Δlog 기여를 ref (최고 σ_e 케이스) 대비 표시.\n"
                   "하단 panel: 케이스별 dominant factor.",
    "origin_tip": "상단 stacked bar (factor 별 Δlog), 하단 case 별 dominant.",
}


# ════════════════════════════════════════════════════════════════════════
# σ_thermal Stage T1 PRODUCTION form (2026-06-04, LOOCV 0.9028)
# ════════════════════════════════════════════════════════════════════════
# Discovery (scripts/thermal_with_excl.py): on n=82 corpus (after applying
# σ_e _EXCLUDED_NAMES_EL to thermal), Physics Stage E target with greedy
# forward selection reached LOOCV 0.9028 at that time.
#  ⛔ 정정 2026-09-13 (L3-11): 그 탐색은 Ridge α=0.1·18 features 였으나 **생산은
#     α=0.05 · _THERMAL_T1_FEATURES 14개**다 (Stage T1 refinement 16→14).  옛 수치를
#     현행 식의 성능으로 전사하지 말 것.
#
# Key design choices:
#   - Target: thermal_sigma_full_mScm_stage_e_physics  (NOT Hertz Stage E;
#     audit showed Hertz Stage E factor ≈ 0.95 = pass-through, while
#     Physics target captures Tabor plastic correctly)
#   - EXCL: shares σ_e's _EXCLUDED_NAMES_EL (same broken cases poison both)
#   - Sanity filter: 0.05 ≤ κ ≤ 50 mScm (removes solver pathology like
#     input_1mAh_100_7 κ=153,986)
#   - Ridge regularized — 실제 개수는 `len(_THERMAL_T1_FEATURES)` (현행 14)
#
# Unlike σ_ionic T1 (5 OLS) or σ_e Stage 22.5 (8 LIVE OLS) which fit a
# physics-anchored functional form, σ_thermal form is empirical Ridge
# regression on structural features.  Reason: thermal flows through
# ALL contact pairs (AM-AM + AM-SE + SE-SE simultaneously) with
# composition-dependent k_weights, no single-backbone scaling captures it.
# The structural features (Bruggeman ratios, contact areas, percolation,
# tortuosity etc.) collectively encode the multi-pathway resistance network.

_THERMAL_KAPPA_MAX = 50.0    # mScm — above: solver pathology (per audit)
_THERMAL_KAPPA_MIN = 0.05    # mScm — below: broken sim

_THERMAL_TARGET_KEYS = (
    'thermal_sigma_full_mScm_stage_e_physics',  # PRIMARY (Stage T1 target)
    'thermal_sigma_full_mScm_physics',           # raw physics fallback
    'thermal_sigma_full_mScm_stage_e',           # Hertz Stage E fallback
    'thermal_sigma_full_mScm',                   # raw Hertz fallback
)

# Features selected by greedy forward selection (LOOCV order).
# Stage T1 refinement (2026-06-04, thermal_refine_finalized.py): dropped
# 2 over-fitting features (n_large_components + A_binding_share.elastic).
# Forward selection showed LOOCV PEAKS at 14 features (0.869 finalized /
# 0.849 full corpus) then DROPS when those 2 are added back (0.825/0.844).
# 14-feature form: better LOOCV + n/k 5.4→6.0.  Dropping further (12) loses.
#: ★ L3-11 — 생산 Ridge α.  설명 문자열도 **이 상수에서** 생성한다.
_THERMAL_RIDGE_ALPHA = 0.05
_THERMAL_T1_FEATURES = [
    # name in full_metrics.json, log-transform?
    ('porosity',                                          False),
    ('se_se_cn',                                          True),
    ('tortuosity_std',                                    False),
    ('gb_density_mean',                                   True),
    ('validation_flags.asr_ionic_Ohm_cm2',                True),
    ('am_vulnerable_pct',                                 False),
    ('se_se_cn_std',                                      False),
    ('electronic_active_fraction',                        True),
    ('R_brug_over_full_physics',                          True),
    ('validation_flags.bruggeman_fallback_fired_any',     False),
    ('area_SE_SE_total_physics',                          False),
    ('area_AM전체_SE_total_physics',                      False),
    ('tortuosity_median',                                 False),
    ('e_se_eff_gpa',                                      True),
    # DROPPED (Stage T1 refinement — over-fit, LOOCV improves when removed):
    #   ('n_large_components', True)                  — forward Step 15 drops LOOCV
    #   ('A_binding_share_total_pct.elastic', False)  — forward Step 16 drops LOOCV
]


def _get_nested(d, key):
    """Get value from nested dict using dot-separated key (e.g., 'a.b')."""
    if '.' not in key:
        return d.get(key)
    parts = key.split('.')
    v = d
    for p in parts:
        if isinstance(v, dict): v = v.get(p)
        else: return None
    return v


def _thermal_form_arrays(data_list, names):
    """Build feature matrix for σ_thermal Stage T1 form.
    Mirrors _electronic_form_arrays pattern: walks data_list, filters cases
    that have target κ + all required features, returns dict with X, y, etc.

    EXCL: cases in _EXCLUDED_NAMES_EL (σ_e EXCL) are marked but kept in
    arr['excluded'] for X-rendering.  Fit uses ~excluded mask.
    """
    rows = []; kept_names = []; kept_idx = []; excluded = []
    for i, d in enumerate(data_list):
        if not isinstance(d, dict): continue
        # Skip hash-named test/upload cases (260603_233847_... etc.) — only
        # real named cases (input_*) belong in the production corpus.  Hash
        # cases are intermediate test uploads that pollute the fit (LOOCV
        # 0.62 with hash cases vs 0.90 without; verified thermal_alpha_tune.py).
        nm = names[i] if i < len(names) else ''
        if not nm.startswith('input_'):
            continue
        # Target — first non-zero from priority chain
        kappa = None
        for k in _THERMAL_TARGET_KEYS:
            v = d.get(k)
            if isinstance(v, (int, float)) and v > 0:
                kappa = float(v); break
        if kappa is None: continue
        if kappa < _THERMAL_KAPPA_MIN or kappa > _THERMAL_KAPPA_MAX: continue

        # Extract all required features
        feats = []
        valid = True
        for fkey, do_log in _THERMAL_T1_FEATURES:
            v = _get_nested(d, fkey)
            if v is None or not isinstance(v, (int, float)) or not np.isfinite(v):
                valid = False; break
            if do_log:
                if v <= 0: valid = False; break
                feats.append(np.log(float(v)))
            else:
                feats.append(float(v))
        if not valid: continue

        rows.append(feats)
        kept_names.append(names[i])
        kept_idx.append(i)
        excluded.append(names[i] in _EXCLUDED_NAMES_EL)

    n = len(rows)
    if n < 8:
        return None
    X = np.array(rows)
    sigs = np.array([float([d for d in [data_list[j].get(k) for k in _THERMAL_TARGET_KEYS] if isinstance(d, (int, float)) and d > 0][0])
                     for j in kept_idx])
    return {
        'n': n, 'keep_idx': np.array(kept_idx), 'names': kept_names,
        'X': X, 'sigs': sigs, 'logsig': np.log(sigs),
        'excluded': np.array(excluded),
        'feature_labels': [f'{f[0]}{"" if not f[1] else " [log]"}' for f in _THERMAL_T1_FEATURES],
    }


def _thermal_fit(arr, fit_mask=None, alpha=None):
    #  ★ L3-11: 기본값을 모듈 상수에서 읽는다 (설명 문자열도 같은 상수를 쓴다).
    if alpha is None:
        alpha = _THERMAL_RIDGE_ALPHA
    """Ridge regression fit for σ_thermal Stage T1.
    Returns dict with coef, pred_log, r2, loocv, n_fit."""
    X = arr['X']; y = arr['logsig']; n = arr['n']
    if fit_mask is None:
        fit_mask = np.ones(n, bool)
    Xf = X[fit_mask]; yf = y[fit_mask]
    nf = int(fit_mask.sum())
    # Ridge regression with intercept (no penalty on intercept)
    Xf_ = np.column_stack([np.ones(nf), Xf])
    k = Xf_.shape[1]
    I = np.eye(k); I[0, 0] = 0
    coef = np.linalg.solve(Xf_.T @ Xf_ + alpha * I, Xf_.T @ yf)
    # In-sample R²
    pred_log_fit = Xf_ @ coef
    ss_tot = float(np.sum((yf - yf.mean())**2))
    r2 = 1 - float(np.sum((yf - pred_log_fit)**2)) / ss_tot if ss_tot > 0 else 0
    # LOOCV
    sse_loo = 0.0
    for j in range(nf):
        m = np.ones(nf, bool); m[j] = False
        Xm = Xf_[m]; ym = yf[m]
        try:
            cm = np.linalg.solve(Xm.T @ Xm + alpha * I, Xm.T @ ym)
            sse_loo += (yf[j] - Xf_[j] @ cm)**2
        except: pass
    loocv = 1 - float(sse_loo) / ss_tot if ss_tot > 0 else 0
    # Predict on full corpus
    X_ = np.column_stack([np.ones(n), X])
    pred_log = X_ @ coef
    return {'coef': coef, 'pred_log': pred_log, 'r2': r2, 'loocv': loocv,
            'n_fit': nf, 'alpha': alpha}


# ─── σ_thermal Stage T1 plot functions ─────────────────────────────────


def plot_thermal_fit_final(data_list, names, outdir):
    """σ_thermal Stage T1 parity plot: actual κ vs Ridge form prediction.
    Mirror of plot_electronic_fit_final structure adapted for κ.
    """
    arr = _thermal_form_arrays(data_list, names)
    if arr is None:
        print(f"  [SKIP] thermal_fit_final: <8 usable cases"); return None
    fit_mask = ~arr['excluded']
    fit = _thermal_fit(arr, fit_mask=fit_mask)
    kappa_act = arr['sigs']
    kappa_pred = np.exp(fit['pred_log'])
    err_pct = (kappa_pred - kappa_act) / kappa_act * 100
    excl = arr['excluded']

    fig, ax = plt.subplots(figsize=FIG_SINGLE)
    fit_band = ~excl
    ax.scatter(kappa_act[fit_band], kappa_pred[fit_band], s=45, c=BLUE,
               edgecolors='white', zorder=3,
               label=f'fit ({int(fit_band.sum())})')
    if excl.any():
        # AUDIT EXCLUDED — gray hollow square + ✗ (shared σ_e EXCL list).
        # These are documented anomalies (broken sim / marginal-perc /
        # sibling-tail), NOT form failures.
        ax.scatter(kappa_act[excl], kappa_pred[excl], s=110, c='#f5f5f5',
                   edgecolors='#888', linewidths=1.8, marker='s', zorder=4,
                   label=f'AUDIT excluded ({int(excl.sum())}) — documented anomaly, shared w/ σ_e')
        ax.scatter(kappa_act[excl], kappa_pred[excl], s=80, c='#888',
                   marker='x', linewidths=1.5, zorder=5)
    lim = [kappa_act.min()*0.6, kappa_act.max()*1.6]
    ax.plot(lim, lim, '--', color=GRAY)
    ax.fill_between(lim, [v*0.8 for v in lim], [v*1.2 for v in lim],
                    color=GREEN, alpha=0.12)
    ax.set_xscale('log'); ax.set_yscale('log')
    ax.set_xlim(lim); ax.set_ylim(lim)
    ax.set_xlabel('κ actual (Stage E Physics target, mScm-equiv)')
    ax.set_ylabel('κ predicted (Stage T1 form, Ridge α=0.05)')
    ax.set_title(
        f"σ_thermal Stage T1 production form  "
        f"(R²={fit['r2']:.3f}  LOOCV={fit['loocv']:.3f}  n_fit={fit['n_fit']}  "
        f"{len(_THERMAL_T1_FEATURES)} Ridge features)\n"
        f"target = thermal_sigma_full_mScm_stage_e_physics  |  "
        f"EXCL shares _EXCLUDED_NAMES_EL", fontsize=8)
    ax.legend(fontsize=9, loc='upper left')
    ax.grid(True, alpha=0.25, which='both')
    return _save(fig, outdir, "thermal_fit_final.png")


PLOT_REGISTRY["thermal_fit_final"] = {
    "func": plot_thermal_fit_final,
    "file": "thermal_fit_final.png",
    "title": "σ_thermal → Stage T1 (Ridge, Physics target) parity",
    #  ★ L3-11: 설명을 **상수에서 생성**한다 — 손으로 적으면 세대가 갈린다
    #    (옛 표기 "16 features, α=0.1" 은 refinement 이전 값이었다).
    "description": (f"σ_thermal Stage T1 production form: {len(_THERMAL_T1_FEATURES)} structural "
             f"features, Ridge α={_THERMAL_RIDGE_ALPHA:g}, "
             "target = thermal_sigma_full_mScm_stage_e_physics; "
             "LOOCV 0.903 was measured on the n=82 FINALIZED cohort (see docs)."),
    "origin_tip": "log-log parity, ±20% green band, AUDIT EXCL (σ_e EXCL 공유) X-marked.",
}


def plot_thermal_outliers_final(data_list, names, outdir):
    """σ_thermal Stage T1 outlier diagnosis: >±20% err cases."""
    arr = _thermal_form_arrays(data_list, names)
    if arr is None:
        print(f"  [SKIP] thermal_outliers_final"); return None
    fit_mask = ~arr['excluded']
    fit = _thermal_fit(arr, fit_mask=fit_mask)
    kappa_act = arr['sigs']
    kappa_pred = np.exp(fit['pred_log'])
    err_pct = (kappa_pred - kappa_act) / kappa_act * 100
    excl = arr['excluded']
    is_out = (np.abs(err_pct) > 20.0) & (~excl)

    fig, ax = plt.subplots(figsize=FIG_SINGLE)
    in_band = (~is_out) & (~excl)
    ax.scatter(kappa_act[in_band], kappa_pred[in_band], s=45, c=BLUE,
               edgecolors='white', zorder=3,
               label=f'within ±20% (n={int(in_band.sum())})')
    if is_out.any():
        ax.scatter(kappa_act[is_out], kappa_pred[is_out], s=80, c=RED,
                   edgecolors='black', linewidths=1.5, zorder=4,
                   label=f'FIT outlier >±20% ({int(is_out.sum())}) — form fail')
    if excl.any():
        # AUDIT EXCLUDED — distinct gray hollow squares + ✗ overlay (mirror
        # σ_electronic plot) so user immediately sees these are intentionally
        # outside the fit, NOT form failures.  EXCL list shared with σ_e.
        ax.scatter(kappa_act[excl], kappa_pred[excl], s=110, c='#f5f5f5',
                   edgecolors='#888', linewidths=1.8, marker='s', zorder=4.5,
                   label=f'AUDIT excluded ({int(excl.sum())}) — documented anomaly, NOT form fail')
        ax.scatter(kappa_act[excl], kappa_pred[excl], s=80, c='#888',
                   marker='x', linewidths=1.5, zorder=5)
    # Annotate top-6 fit-outliers + ALL excluded (gray italic [AUDIT] prefix
    # for EXCL, red bold for genuine form outliers — same scheme as σ_e)
    order = np.argsort(-np.abs(err_pct))
    annot = list(np.where(excl)[0])
    for i in order[:6]:
        if i not in annot: annot.append(i)
    for i in annot:
        if excl[i]:
            col = '#777'; weight = 'normal'; prefix = '[AUDIT] '; style = 'italic'
        elif is_out[i]:
            col = RED; weight = 'bold'; prefix = ''; style = 'normal'
        else:
            col = GRAY; weight = 'normal'; prefix = ''; style = 'normal'
        ax.annotate(f'{prefix}{arr["names"][i][:22]} ({err_pct[i]:+.0f}%)',
                    (kappa_act[i], kappa_pred[i]), fontsize=6, color=col,
                    fontweight=weight, fontstyle=style,
                    xytext=(4, 3), textcoords='offset points')
    lim = [kappa_act.min()*0.6, kappa_act.max()*1.6]
    ax.plot(lim, lim, '--', color=GRAY)
    ax.fill_between(lim, [v*0.8 for v in lim], [v*1.2 for v in lim],
                    color=GREEN, alpha=0.12)
    ax.set_xscale('log'); ax.set_yscale('log')
    ax.set_xlim(lim); ax.set_ylim(lim)
    ax.set_xlabel('κ actual (Stage E Physics target, mScm-equiv)')
    ax.set_ylabel('κ predicted (Stage T1 form)')
    ax.set_title(
        f"σ_thermal Stage T1 outliers  "
        f"(n={arr['n']}, {int(is_out.sum())} >±20%, {int(excl.sum())} AUDIT EXCL)",
        fontsize=9)
    ax.legend(fontsize=8, loc='upper left')
    ax.grid(True, alpha=0.25, which='both')
    return _save(fig, outdir, "thermal_outliers_final.png")


PLOT_REGISTRY["thermal_outliers_final"] = {
    "func": plot_thermal_outliers_final,
    "file": "thermal_outliers_final.png",
    "title": "σ_thermal Stage T1 outlier diagnosis",
    "description": "Cases >±20% err annotated, top-6 by |err| + all EXCL.  "
            "Heat flow's multi-pathway nature makes residual outliers harder to remove "
            "than σ_ionic/σ_e — Bruggeman ratio features capture most variance.",
    "origin_tip": "log-log; ±20% green band; RED bold = form outlier, gray X = EXCL.",
}


def plot_thermal_decomp_final(data_list, names, outdir):
    """σ_thermal Stage T1 factor decomposition: top-10 contributors per case.
    Unlike σ_e Stage 22.5 (LOCKED + LIVE multiplicative form), σ_thermal is
    additive in log-space (Ridge regression), so decomposition shows each
    feature's coef × value contribution to log κ.
    """
    arr = _thermal_form_arrays(data_list, names)
    if arr is None:
        print(f"  [SKIP] thermal_decomp_final"); return None
    fit_mask = ~arr['excluded']
    fit = _thermal_fit(arr, fit_mask=fit_mask)
    coef = fit['coef']           # length k+1 (intercept + features)
    X = arr['X']                  # n × k feature matrix
    n = arr['n']
    # Per-case feature contribution: coef[i+1] * X[:, i] for each feature
    contribs = X * coef[1:]       # n × k
    feature_labels = arr['feature_labels']
    # Sort features by mean |contribution| across cases (most impactful first)
    mean_abs = np.mean(np.abs(contribs), axis=0)
    order = np.argsort(-mean_abs)[:10]   # top 10
    top_labels = [feature_labels[i] for i in order]
    top_contribs = contribs[:, order]

    ref_idx = int(np.argmax(arr['sigs']))   # max-κ case as reference
    deltas = top_contribs - top_contribs[ref_idx]   # Δlog vs ref

    fig_w = min(max(11, n*0.5), 36)
    fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(fig_w, 10),
                                     gridspec_kw={'height_ratios': [3, 3]})
    # Top: stacked bar of feature deltas (top 10 features)
    colors = plt.cm.tab10(np.linspace(0, 1, 10))
    x = np.arange(n); bpos = np.zeros(n); bneg = np.zeros(n)
    for j in range(10):
        delta = deltas[:, j]
        pos = np.clip(delta, 0, None); neg = np.clip(delta, None, 0)
        ax1.bar(x, pos, bottom=bpos, color=colors[j], label=top_labels[j],
                width=0.7, edgecolor='white', linewidth=0.5)
        ax1.bar(x, neg, bottom=bneg, color=colors[j],
                width=0.7, edgecolor='white', linewidth=0.5)
        bpos += pos; bneg += neg
    ax1.axhline(0, color='gray', linewidth=0.5)
    ax1.set_xticks(x)
    ax1.set_xticklabels([nm[:20] for nm in arr['names']], rotation=80, fontsize=6)
    ax1.set_ylabel('Δlog κ from ref')
    ax1.set_title(
        f"σ_thermal Stage T1 factor decomposition (ref: {arr['names'][ref_idx][:24]})  "
        f"[Ridge α={_THERMAL_RIDGE_ALPHA:g}, "
        f"top 10/{len(_THERMAL_T1_FEATURES)} features by |Δ|]",
        fontsize=9)
    ax1.legend(fontsize=7, loc='upper left', ncol=5)

    # Bottom: dominant feature per case
    for i in range(n):
        idx = int(np.argmax(np.abs(deltas[i])))
        ax2.barh(i, deltas[i, idx], color=colors[idx], height=0.6,
                 edgecolor='white', linewidth=0.5)
        ax2.text(deltas[i, idx], i, f' {top_labels[idx][:30]}',
                 va='center', fontsize=6)
    ax2.set_yticks(range(n))
    ax2.set_yticklabels([nm[:22] for nm in arr['names']], fontsize=6)
    ax2.set_xlabel('Dominant feature Δlog κ')
    ax2.set_title('Dominant feature per case', fontsize=10)
    ax2.axvline(0, color='gray', linewidth=0.5)
    fig.tight_layout()
    return _save(fig, outdir, "thermal_decomp_final.png")


PLOT_REGISTRY["thermal_decomp_final"] = {
    "func": plot_thermal_decomp_final,
    "file": "thermal_decomp_final.png",
    "title": "σ_thermal Stage T1 factor decomposition",
    "description": "Per-case Δlog κ vs reference, decomposed into top-10 Ridge feature "
            "contributions (coef × value).  Reveals which structural axis drives "
            "each case's κ deviation.",
    "origin_tip": "stacked bar (positive 위, 음수 아래), 하단 dominant feature.",
}


# ─── Main ─────────────────────────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("-i", "--inputs", nargs="+", required=True)
    parser.add_argument("-n", "--names", nargs="+", required=True)
    parser.add_argument("-o", "--output", required=True)
    parser.add_argument("-p", "--plots", nargs="+",
                        default=list(PLOT_REGISTRY.keys()) + ["four_panel"])
    parser.add_argument("--group-sizes", default="")  # e.g. "3,5"
    parser.add_argument("--group-names", default="")  # e.g. "Case A,Case B"
    parser.add_argument("--global-rgb", default="")   # e.g. "5.21,0.20" (b,ln_k from global fit)
    parser.add_argument("--global-c-ion", default="")  # e.g. "0.0727" (C from ionic scaling fit)
    parser.add_argument("--y-max-sigma", type=float, default=None,
                        help="Fixed y-axis max (mS/cm) for σ_ionic / multiscale σ plots")
    parser.add_argument("--y-max-sigma-e", type=float, default=None,
                        help="Fixed y-axis max (mS/cm) for σ_electronic plots (user σ_AM(e) input). "
                             "Does NOT lock form anchors — form keeps the corpus-fit defaults.")
    parser.add_argument("--sigma-S", type=float, default=None,
                        help="σ_e form: S-end AM conductivity (mS/cm, AM_S single-crystal). Default=10 (corpus-fit; material INPUT). Set to override.")
    parser.add_argument("--sigma-P", type=float, default=None,
                        help="σ_e form: P-end AM conductivity (mS/cm, AM_P polycrystalline). Default=5 (corpus-fit; material INPUT). Set to override.")
    # Generic parameter-comparison selections
    parser.add_argument("--param-x", default="")   # scatter X metric key
    parser.add_argument("--param-y", default="")   # scatter Y metric key
    parser.add_argument("--param-list", default="")  # comma-separated keys (bar/corr)
    parser.add_argument("--param-norm", action="store_true")  # normalize bar to max
    parser.add_argument("--focus-cases", default="")  # \\t-separated saved names → "1-1" focus parity
    parser.add_argument("--focus-label", default="")  # group name(s) shown on the 1-1 plot
    parser.add_argument("--fit-corpus-inputs", nargs="*", default=[])  # full corpus for global fit stats
    se_material.temperature_argparse(parser)   # --temp-c / --ea-ion-ev (both default None)
    args = parser.parse_args()

    # σ_grain(T) for the PRODUCTION σ_ionic form.  Unset (the default, and what the webapp
    # always passes) → SE_SG stays the bare 3.0 literal → _sat_baselog bitwise unchanged.
    # ⚠ see set_se_temperature(): on this path the factor is absorbed by the live-fit
    # intercept, so it is a LABEL, not a numeric change.  Verified in --selftest-temp.
    if args.temp_c is not None or args.ea_ion_ev is not None:
        set_se_temperature(args.temp_c, args.ea_ion_ev)

    # σ_e endpoint override (user-set σ_S/σ_P from UI) — applies to Stage 22
    # locked form.  If both blank → use the corpus-fit defaults (10, 5).
    # If user sets either, override the module constant before any plot runs.
    global _SIGMA_S_LOCKED, _SIGMA_P_LOCKED
    if args.sigma_S is not None and args.sigma_S > 0:
        _SIGMA_S_LOCKED = float(args.sigma_S)
        print(f"  [σ_e] σ_S OVERRIDE: {_SIGMA_S_LOCKED:.2f} mS/cm (user set)")
    if args.sigma_P is not None and args.sigma_P > 0:
        _SIGMA_P_LOCKED = float(args.sigma_P)
        print(f"  [σ_e] σ_P OVERRIDE: {_SIGMA_P_LOCKED:.2f} mS/cm (user set)")

    global _PARAM_X, _PARAM_Y, _PARAM_LIST, _PARAM_NORM, _FOCUS_CASES, _FOCUS_LABEL, _FIT_CORPUS
    _PARAM_X = args.param_x or None
    _PARAM_Y = args.param_y or None
    _PARAM_LIST = [k for k in args.param_list.split(',') if k] or None
    _PARAM_NORM = bool(args.param_norm)
    _FOCUS_CASES = set(s for s in args.focus_cases.split('\t') if s)
    _FOCUS_LABEL = args.focus_label or ""
    _FIT_CORPUS = []
    for _p in (args.fit_corpus_inputs or []):
        # Skip hash-named test/upload cases (path contains 260603_233847_...
        # rather than input_*).  These got Stage E values via backfill
        # (2026-06-04) and pollute the σ_ionic global fit corpus.
        # Path layout: .../webapp/results/<case_name>/full_metrics.json
        try:
            _case_nm = os.path.basename(os.path.dirname(_p))
            if not _case_nm.startswith('input_'):
                continue
            with open(_p) as _f:
                _FIT_CORPUS.append(json.load(_f))
        except Exception:
            pass

    # Parse group info
    if args.group_sizes:
        args.group_sizes_list = [int(x) for x in args.group_sizes.split(',')]
        args.group_names_list = args.group_names.split(',') if args.group_names else [f"Case {chr(65+i)}" for i in range(len(args.group_sizes_list))]
    else:
        args.group_sizes_list = None
        args.group_names_list = None

    if len(args.inputs) != len(args.names):
        print(f"ERROR: inputs ({len(args.inputs)}) != names ({len(args.names)})")
        sys.exit(1)

    global _ALL_DATA, _REAL_NAMES
    all_data = []
    for path in args.inputs:
        with open(path, "r") as f:
            d = json.load(f)
        d["_source_path"] = path
        all_data.append(d)
    _ALL_DATA = all_data
    _REAL_NAMES = list(args.names)

    # Use P:S ratio as x-axis labels (fallback to case names)
    plot_names = []
    for i, d in enumerate(all_data):
        ps = d.get('ps_ratio', '')
        if ps:
            plot_names.append(ps)
        else:
            plot_names.append(args.names[i])

    os.makedirs(args.output, exist_ok=True)
    plot_info = {}

    # Try to pre-load fitted v29 + v32 params from disk cache. Webapp
    # invokes this script multiple times per render (one subprocess per
    # plot group / per plot subset), so module globals do not carry
    # across calls. The parity plot writes the cache; every subsequent
    # subprocess can now pick it up as long as the case list matches.
    global _V32_FITTED_GAMMAS, _GLOBAL_IONIC_SIGMOID, _GLOBAL_IONIC_POLY3, _GLOBAL_PS_SIGMOID
    _cached = _load_v29_cache(args.names)
    if _cached:
        _sig, _p3, _ps, _v32g = _cached
        if _sig: _GLOBAL_IONIC_SIGMOID = _sig
        if _p3:  _GLOBAL_IONIC_POLY3   = _p3
        if _ps:  _GLOBAL_PS_SIGMOID    = _ps
        if _v32g: _V32_FITTED_GAMMAS   = dict(_v32g)

    # Set global group info for _apply_style
    global _GROUP_INFO, _GLOBAL_RGB, _Y_MAX_SIGMA
    if args.group_sizes_list and len(args.group_sizes_list) > 1:
        _GROUP_INFO = (args.group_sizes_list, args.group_names_list)
    else:
        _GROUP_INFO = None
    _Y_MAX_SIGMA = args.y_max_sigma  # None = auto, else fixed (cross-run unified)
    global _Y_MAX_SIGMA_E
    _Y_MAX_SIGMA_E = args.y_max_sigma_e  # σ_e plots only (user σ_AM(e) input)

    # Set global R_gb if provided (from combined fit across all plot groups)
    if args.global_rgb:
        parts = args.global_rgb.split(',')
        if len(parts) >= 2:
            _GLOBAL_RGB = (float(parts[0]), float(parts[1]))
            print(f"  Using global R_gb: b={_GLOBAL_RGB[0]:.2f}, ln(k)={_GLOBAL_RGB[1]:.2f}")
    else:
        _GLOBAL_RGB = None

    # Set global C for ionic scaling if provided
    global _GLOBAL_C_ION
    if args.global_c_ion:
        _GLOBAL_C_ION = float(args.global_c_ion)
        print(f"  Using global C_ion: {_GLOBAL_C_ION:.6f}")
    else:
        _GLOBAL_C_ION = None

    # Generate particle info table as first plot
    if 'particle_info' in args.plots or True:  # always generate
        _generate_particle_info(all_data, plot_names, args.names, args.output)
        plot_info['particle_info'] = {
            'file': 'particle_info.png',
            'title': '입자 정보',
            'description': '각 케이스별 AM_P, AM_S, SE 입자수와 반지름.\nSE 크기가 같으면 비교 조건 동일.',
            'origin_tip': 'Table 형태로 Origin에서는 Worksheet에 직접 입력.',
        }

    # Generate CSV for each plot type
    csv_map = {
        'porosity': [('Case', None), ('Porosity(%)', lambda d: _get(d, 'porosity'))],
        'am_se_interface': [('Case', None),
            ('AM_P-SE(μm²)', lambda d: _resolve_am_se(d)[0]),
            ('AM_S-SE(μm²)', lambda d: _resolve_am_se(d)[1]),
            ('Total(μm²)', lambda d: _get(d, 'area_AM전체_SE_total') or sum(_resolve_am_se(d)))],
        'se_se_tradeoff': [('Case', None),
            ('SE-SE Count', lambda d: _get(d, 'area_SE_SE_n')),
            ('SE-SE Mean Area(μm²)', lambda d: _get(d, 'area_SE_SE_mean'))],
        'se_se_total': [('Case', None),
            ('SE-SE Total(μm²)', lambda d: _get(d, 'area_SE_SE_total'))],
        'percolation_tortuosity': [('Case', None),
            ('Percolation(%)', lambda d: _get(d, 'percolation_pct')),
            ('Tortuosity', lambda d: _get(d, 'tortuosity_mean'))],
        'ionic_active': [('Case', None),
            ('Ionic Active AM(%)', lambda d: _get(d, 'ionic_active_pct'))],
        'coverage': [('Case', None),
            ('Coverage AM_P(%)', lambda d: _resolve_coverage(d)[0]),
            ('Coverage AM_P std', lambda d: _resolve_coverage(d)[1]),
            ('Coverage AM_S(%)', lambda d: _resolve_coverage(d)[2]),
            ('Coverage AM_S std', lambda d: _resolve_coverage(d)[3])],
        #  LHS-33 — 옛 σ_VM 칸은 상태를 따른다: 무효 · 미정의 · 키 없음 = 빈칸 (옛 판 `_get` = 0.0) · 상태 열에 '상태 — 사유'
        'stress_cv': [('Case', None),
            ('Stress CV(%) [stress/atom 50/50 · diag]', lambda d: _stress_export_cells(d)['stress_cv']),
            ('Stress CV status [50/50 · LHS-33]', lambda d: _stress_export_cells(d)['reason'] or _stress_export_cells(d)['status']),
            ('Stress CV(%) [Love–Weber]', lambda d: d.get('stress_cv_lw', '')),
            ('Stress CV(%) [Love–Weber · no wall]', lambda d: d.get('stress_cv_lw_nowall', ''))],
        'stress_ratio': [('Case', None),
            ('σ_AM_P/σ_mean [50/50]', lambda d: _stress_export_cells(d)['stress_ratio_AM_P']),
            ('σ_AM_S/σ_mean [50/50]', lambda d: _stress_export_cells(d)['stress_ratio_AM_S']),
            ('σ_SE/σ_mean [50/50]', lambda d: _stress_export_cells(d)['stress_ratio_SE']),
            ('σ_AM_P/σ_mean [LW]', lambda d: d.get('stress_ratio_AM_P_lw', '')),
            ('σ_AM_S/σ_mean [LW]', lambda d: d.get('stress_ratio_AM_S_lw', '')),
            ('σ_SE/σ_mean [LW]', lambda d: d.get('stress_ratio_SE_lw', ''))],
        'stress_z_layer': [('Case', None),
            ('Z_data', lambda d: (str(d.get('stress_z_layer_cv') or [])
                                  if stress_cv_status(d) in (None, STRESS_CV_COMPUTED) else ''))],
    }

    import csv
    for pname, cols in csv_map.items():
        if pname in args.plots:
            csv_path = os.path.join(args.output, f"{pname}.csv")
            with open(csv_path, 'w', newline='', encoding='utf-8') as f:
                writer = csv.writer(f)
                writer.writerow([c[0] for c in cols])
                for i, name in enumerate(plot_names):
                    row = []
                    for col_name, fn in cols:
                        if fn is None:
                            row.append(name)
                        else:
                            val = fn(all_data[i])
                            if isinstance(val, (int, float)):
                                row.append(round(val, 4))
                            else:
                                row.append(val)
                    writer.writerow(row)

    for plot_name in args.plots:
        if plot_name == "four_panel":
            outpath = plot_four_panel(all_data, plot_names, args.output)
            plot_info["four_panel"] = {
                "file": "four_panel.png",
                "title": "Four-Panel Composite",
                "description": "Porosity, AM-SE Interface, SE-SE Trade-off,\nPercolation/Tortuosity 4개 핵심 지표를 2×2 패널로 종합 비교.\n\n논문 Figure로 적합.",
                "origin_tip": "Graph > Merge Multiple Graphs.\n2×2 layout, 각 패널 개별 설정.\n전체 크기: 14×10 inch.",
            }
            print(f"  [OK] four_panel -> {outpath}")
            continue

        if plot_name not in PLOT_REGISTRY:
            print(f"  [SKIP] Unknown: {plot_name}")
            continue

        entry = PLOT_REGISTRY[plot_name]
        # min_groups check: skip if not enough case groups
        min_groups = entry.get("min_groups", 1)
        n_groups = len(_GROUP_INFO[0]) if _GROUP_INFO else 1
        if n_groups < min_groups:
            print(f"  [SKIP] {plot_name}: requires {min_groups}+ case groups (have {n_groups})")
            continue
        func = entry["func"]
        import inspect, time, traceback
        params = inspect.signature(func).parameters
        if 'outdir' in params:
            # Standalone plot (creates own fig, saves itself)
            t0 = time.time()
            try:
                outpath = func(all_data, plot_names, args.output)
            except Exception as _e:
                dt = time.time() - t0
                print(f"  [FAIL] {plot_name}: {type(_e).__name__}: {_e}  "
                      f"(after {dt:.1f}s)")
                traceback.print_exc()
                # Don't kill the whole loop — keep going so other plots work
                continue
            dt = time.time() - t0
            if dt > 2.0:
                print(f"  [time] {plot_name}: {dt:.1f}s")
            if outpath is None:
                # R² too low — generate "Bruggeman reference" note
                if plot_name in ('rgb_fitting', 'gb_corrected'):
                    _, _, _, r2_val = _fit_r_gb(all_data, plot_names, use_global=False)
                    plot_info[plot_name] = {
                        "file": "",
                        "csv": None,
                        "title": entry["title"] + " (skipped)",
                        "description": f"R²={r2_val:.4f} < {R_GB_MIN_R2}: fitting not reliable.\nBruggeman reference only.\nRVE size or data range insufficient.",
                        "origin_tip": "",
                    }
                continue
        else:
            try:
                fig, ax = plt.subplots(figsize=FIG_SINGLE)
                func(all_data, plot_names, ax=ax)
                outpath = _save(fig, args.output, entry["file"])
            except Exception as _e:
                print(f"  [FAIL] {plot_name}: {type(_e).__name__}: {_e}")
                traceback.print_exc()
                continue

        # Check for CSV from csv_map (legacy) or standalone _write_csv
        csv_file = f"{plot_name}.csv" if plot_name in csv_map else None
        if csv_file is None:
            standalone_csv = os.path.join(args.output, f"{plot_name}.csv")
            if os.path.exists(standalone_csv):
                csv_file = f"{plot_name}.csv"
        # Dynamic description: replace {formx_r2}, {formx_loocv} with actual values
        desc = entry["description"]
        if _GLOBAL_FORMX_R2 is not None:
            r2_val, loocv_val = _GLOBAL_FORMX_R2
            desc = desc.replace("{formx_r2}", f"{r2_val:.3f}")
            desc = desc.replace("{formx_loocv}", f"{loocv_val:.3f}")
        elif '{formx_r2}' in desc:
            # Compute FORM X R² on the fly (same logic as plot_ionic_scaling_fit)
            try:
                PHI_C = 0.185; SGRAIN = 3.0
                _phi_se = np.array([_get(d, "phi_se", 0) for d in all_data])
                _cn_se = np.array([_get(d, "se_se_cn", 0) for d in all_data])
                _tau_se = np.array([max(_get(d, "tortuosity_recommended", _get(d, "tortuosity_mean", 1)), 0.1) for d in all_data])
                _cov_se = np.array([(lambda vs: sum(vs)/len(vs)/100 if vs else 0.20)([v for v in [_get(d,"coverage_AM_P_mean",0),_get(d,"coverage_AM_S_mean",0),_get(d,"coverage_AM_mean",0)] if v>0]) for d in all_data])
                _snet = np.array(_load_network_sigma(all_data))
                _gb = np.array([_get(d, "gb_density_mean", 0) for d in all_data])
                _gp = np.array([_get(d, "path_conductance_mean", 0) for d in all_data])
                # Match ionic_scaling_fit filter: require gb_density and path_conductance
                _valid = (_phi_se > PHI_C+0.01) & (_cn_se > 0) & (_tau_se > 0) & (_cov_se > 0) & (_snet > 0.01) & (_gb > 0) & (_gp > 0)
                if _valid.sum() >= 5:
                    _phi_ex = np.clip(_phi_se[_valid] - PHI_C, 0.001, None)
                    _fp_se = np.clip(np.array([_get(d, "percolation_pct", 100) / 100 for d in all_data])[_valid], 0.01, 1.0)
                    _log_rhs = np.log(SGRAIN) + 0.75*np.log(_phi_ex) + 1.5*np.log(_cn_se[_valid]) + 0.25*np.log(_cov_se[_valid]) + 2.0*np.log(_fp_se)
                    _log_s = np.log(_snet[_valid])
                    _log_tau = np.log(_tau_se[_valid])
                    _w_sig = 1.0 / (1.0 + np.exp(-5.0 * (_tau_se[_valid] - 2.1)))
                    _w_bl = 1.0 / (1.0 + np.exp(-15.0 * (_tau_se[_valid] - 2.0)))
                    # v9 BLEND fit
                    _X_v5 = np.column_stack([np.ones(_valid.sum()), _w_sig])
                    _X_p3 = np.column_stack([np.ones(_valid.sum()), _log_tau, _log_tau**2, _log_tau**3])
                    _b_v5 = np.linalg.lstsq(_X_v5, _log_s - _log_rhs, rcond=None)[0]
                    _b_p3 = np.linalg.lstsq(_X_p3, _log_s - _log_rhs, rcond=None)[0]
                    _pred = (1-_w_bl)*(_X_v5@_b_v5) + _w_bl*(_X_p3@_b_p3) + _log_rhs
                    _ss_res = np.sum((_log_s - _pred)**2)
                    _ss_tot = np.sum((_log_s - np.mean(_log_s))**2)
                    _r2 = 1 - _ss_res / _ss_tot
                    desc = desc.replace("{formx_r2}", f"{_r2:.3f}")
                    desc = desc.replace("{formx_loocv}", f"~{_r2:.3f}")
                else:
                    desc = desc.replace("{formx_r2}", "N/A")
                    desc = desc.replace("{formx_loocv}", "N/A")
            except:
                desc = desc.replace("{formx_r2}", "N/A")
                desc = desc.replace("{formx_loocv}", "N/A")
        info_entry = {
            "file": entry["file"],
            "csv": csv_file,
            "title": entry["title"],
            "description": desc,
            "origin_tip": entry["origin_tip"],
        }
        # Add R_gb values to plot_info for downstream use
        if plot_name == 'rgb_fitting':
            r_gb, ln_k, _, _ = _fit_r_gb(all_data, plot_names, use_global=False)
            info_entry['b'] = round(r_gb, 4)
            info_entry['ln_k'] = round(ln_k, 4)
        if plot_name == 'ionic_scaling_fit' and _GLOBAL_C_ION is not None:
            info_entry['C_ion'] = round(_GLOBAL_C_ION, 6)
        plot_info[plot_name] = info_entry
        print(f"  [OK] {plot_name} -> {outpath}")
        # "1-1" focus view: register if the plot emitted a *_focus.png
        focus_file = f"{plot_name}_focus.png"
        if os.path.exists(os.path.join(args.output, focus_file)):
            plot_info[f"{plot_name}_focus"] = {
                "file": focus_file, "csv": None,
                "title": entry["title"] + " — 1-1 선택 샘플",
                "description": "항목1의 전체 fit(식·계수·1:1·±20% 동일)을 그대로 두고, "
                               "선택한 sample의 점만 표시. 재적합 없음.",
                "origin_tip": "동일 fit 위에 선택 케이스만 scatter.",
                "is_focus": True, "parent": plot_name,
            }
            print(f"  [OK] {plot_name}_focus -> {focus_file}")

    # Persist v29 + v32 fits to disk cache (keyed on args.names = case IDs,
    # which are unique — unlike the P:S-ratio label list passed into the
    # individual plot functions). Sibling subprocesses whose case list is a
    # subset of these IDs will pick up these params on startup.
    #
    # CRITICAL: only write when ionic_scaling_fit ran in this subprocess
    # (which implies Nelder-Mead on the FULL requested case set). Per-group
    # subprocesses would otherwise overwrite the parity cache with their
    # own narrow subset, so only the first group plot after parity would
    # hit — every subsequent group would miss because the cache would
    # contain just one group's IDs.
    wrote_parity = 'ionic_scaling_fit' in args.plots
    try:
        if (wrote_parity and _GLOBAL_IONIC_SIGMOID
                and _GLOBAL_IONIC_POLY3 and _GLOBAL_PS_SIGMOID):
            _write_v29_cache(args.names,
                             _GLOBAL_IONIC_SIGMOID,
                             _GLOBAL_IONIC_POLY3,
                             _GLOBAL_PS_SIGMOID,
                             _V32_FITTED_GAMMAS)
        elif not wrote_parity:
            print(f"  [v29 cache] skip write (ionic_scaling_fit not in "
                  f"this subprocess — preserves parity cache for siblings)")
    except Exception as _e:
        print(f"  [v29 cache] skipped: {_e}")

    info_path = os.path.join(args.output, "plot_info.json")
    with open(info_path, "w", encoding="utf-8") as f:
        json.dump(plot_info, f, indent=2, ensure_ascii=False)
    print(f"\nTotal: {len(plot_info)} plots")


def _selftest_temp():
    """σ_grain(T) wiring on the PRODUCTION σ_ionic path.

    Two things must hold and BOTH are checked here:
      (1) with no --temp-c, SE_SG and _sat_baselog are BITWISE what they always were;
      (2) with --temp-c the prefactor factor is EXACTLY absorbed by the live-fit
          C_blend(τ) intercept, i.e. the form's predictions/R²/LOOCV do not move.
          (2) is the reason set_se_temperature() prints a warning instead of pretending
          the scaling law became temperature-aware.
    """
    global SE_SG
    ok = True

    def chk(name, cond, extra=''):
        nonlocal ok
        ok &= bool(cond)
        print(f"  {'PASS' if cond else 'FAIL'}  {name}{(' — ' + extra) if extra else ''}")

    grid = [(phi, cn, cov, fp, p, rse)
            for phi in (0.22, 0.30, 0.41) for cn in (2.7, 4.1, 6.3)
            for cov in (0.05, 0.31) for fp in (0.4, 0.95)
            for p in (0.0, 0.5, 1.0) for rse in (None, 0.25, 0.5, 1.5)]

    def base(rs=None):
        return [float(_sat_baselog(*g, 2.5, 5.5)).hex() for g in grid]

    chk('SE_SG is bitwise 3.0 at import (production default)',
        float(SE_SG).hex() == (3.0).hex(), float(SE_SG).hex())
    b0 = base()
    set_se_temperature(None)
    chk('set_se_temperature(None) leaves SE_SG bitwise 3.0', float(SE_SG).hex() == (3.0).hex())
    chk(f'_sat_baselog bitwise unchanged over {len(grid)} input combos', base() == b0)

    # temperature ON: SE_SG scales, base_log shifts by exactly log(factor)
    set_se_temperature(60.0, printer=lambda *a, **k: None)
    fac = se_material.arrhenius_sigma_factor(60.0)
    chk('SE_SG(60 °C) = 3.0 x4.785', abs(SE_SG / 3.0 - fac) < 1e-12 and abs(fac - 4.785) < 1e-3,
        f'SE_SG={SE_SG:.4f}')
    d = [float(_sat_baselog(*g, 2.5, 5.5)) - float.fromhex(h) for g, h in zip(grid, b0)]
    chk('base_log shift is EXACTLY log(factor) for every case',
        max(abs(x - np.log(fac)) for x in d) < 1e-12)

    # ★ the degeneracy proof: same corpus, base_log vs base_log+Δ → same fit output
    rng = np.random.default_rng(3)
    n = 40
    bl = rng.normal(-1.0, 0.5, n)
    taus = rng.uniform(1.1, 4.0, n)
    ex = [rng.normal(0, 1, n), rng.normal(0, 1, n)]
    ls = bl + 0.3 + 0.2 * np.log(taus) - 0.05 * np.log(taus) ** 2 + rng.normal(0, 0.05, n)
    r2a, looa, _, _, pa, ba, _ = _cblend_fit_score(bl, ls, taus, extras=ex)
    dlt = float(np.log(fac))
    r2b, loob, _, _, pb, bb, _ = _cblend_fit_score(bl + dlt, ls, taus, extras=ex)
    chk('sigma_grain(T) is absorbed by the fit intercept: predictions identical',
        np.allclose(pa, pb, rtol=0, atol=1e-12))
    chk('… R² and LOOCV identical', abs(r2a - r2b) < 1e-12 and abs(looa - loob) < 1e-12,
        f'R² {r2a:.6f}/{r2b:.6f}  LOOCV {looa:.6f}/{loob:.6f}')
    chk('… only the intercept moves, by -log(factor)', abs((bb[0] - ba[0]) + dlt) < 1e-12
        and np.allclose(ba[1:], bb[1:], rtol=0, atol=1e-12),
        f'Δa = {bb[0]-ba[0]:.6f} vs -log(f) = {-dlt:.6f}')
    chk('provenance recorded ARRHENIUS', SE_TEMP_PROVENANCE['T_dependence'] == 'ARRHENIUS')

    set_se_temperature(None)   # restore production state
    chk('restored: SE_SG bitwise 3.0 + NOT_MODELLED', float(SE_SG).hex() == (3.0).hex()
        and SE_TEMP_PROVENANCE['T_dependence'] == 'NOT_MODELLED')
    print('SE_SG TEMP SELFTEST', 'PASS' if ok else 'FAIL')
    return 0 if ok else 1


def _selftest_descriptions():
    """★ L3-11 — **설명 문자열이 실제 상수와 어긋나면 거부한다.**

    판정문(L3): *"이는 문법 취향이 아니라 **어느 수식을 계산했다고 보고하는가**의 결함이다."*
    실측으로 세 세대가 공존했다 — 열 특징 `18`(주석) · `16`(registry) · **14**(실제),
    Ridge `α=0.1`(제목·registry) vs **0.05**(실제), 전자 제목에 드롭된 4항이 남고
    CSV 열 이름은 `Stage_15_form` 인데 값은 22.5 예측.

    ⚠ 이것은 **문자열 blocklist 가 아니다** (`SELF-02~05`: 후보를 고르는 코드가 사각지대다).
    registry 를 **실제로 읽어** 활성 상수와 대조한다.
    """
    ok = True

    def chk(name, cond, extra=''):
        nonlocal ok
        print(('  ✓ ' if cond else '  ✗ ') + name + (f'   {extra}' if extra else ''))
        ok = ok and bool(cond)

    print('설명 ↔ 상수 정합 (L3-11)')

    # ① 열 registry 의 desc 가 **활성 상수에서 생성**되는가
    nfeat, alpha = len(_THERMAL_T1_FEATURES), _THERMAL_RIDGE_ALPHA
    for key in ('thermal_fit_final', 'thermal_outliers_final', 'thermal_decomp_final'):
        e = PLOT_REGISTRY.get(key)
        if e is None:
            continue
        d = str(e.get('description', '')) + str(e.get('title', ''))
        bad = [tok for tok in (f'{nfeat + 2} structural', f'{nfeat + 4} features',
                               'α=0.1', 'alpha=0.1') if tok in d]
        chk(f'① {key}: 낡은 세대 표기 없음', not bad, f'발견 {bad}' if bad else '')
    e = PLOT_REGISTRY.get('thermal_fit_final', {})
    chk('① thermal desc 가 실제 특징 수를 담는다',
        f'{nfeat} structural' in str(e.get('description', '')), f'실제 {nfeat}')
    chk('① thermal desc 가 실제 α 를 담는다',
        f'α={alpha:g}' in str(e.get('description', '')), f'실제 {alpha:g}')

    # ② `_thermal_fit` 의 기본 α 가 그 상수와 **같은 객체**에서 온다
    import inspect
    import re
    sig = inspect.signature(_thermal_fit)
    chk('② _thermal_fit 의 alpha 기본값이 하드코딩이 아니다',
        sig.parameters['alpha'].default is None)

    # ③ 전자 제목이 **드롭된 항**을 광고하지 않는다
    src = inspect.getsource(plot_electronic_sigma)
    #  ⚠ 검사 범위는 **제목 f-string 블록**이다.  조건부 출력(`β_AC` 를 드롭이 아닐 때만
    #    찍는 분기)까지 잡으면 정정이 스스로 검사를 깨뜨린다 — 그것은 광고가 아니다.
    m_t = re.search(r'\n    title = \(.*?\n(?=    if |    ax)', src, re.S)
    title_src = m_t.group(0) if m_t else src
    #  "… dropped at 22.5" 주석은 **드롭을 밝히는 것**이므로 수식이 아니다.
    scan = re.sub(r'\[\d+ LIVE[^\]]*dropped at[^\]]*\]', '', title_src)
    dropped = [t for t in ('β_v', 'β_AC', 'β_fpth', 'β_rSE') if t in scan]
    live_ok = 'LIVE' in title_src
    chk('③ 제목 블록을 실제로 잡았다 (빈 스캔이 아니다)',
        m_t is not None and 'σ_electronic' in title_src, f'{len(title_src)}자')
    chk('③ 전자 제목에 드롭된 4항이 없다', not dropped, f'발견 {dropped}' if dropped else '')
    chk('③ 전자 제목이 LIVE 개수를 밝힌다', live_ok)

    # ④ CSV 열 이름이 **현행 폼 버전**을 쓴다
    chk('④ 전자 CSV 열이 Stage_15 로 굳어 있지 않다',
        'Stage_15_form' not in src,
        f'_STAGE_FORM_VERSION={_STAGE_FORM_VERSION:g}')

    # ④b L3-10 — registry 항목이 **전부** main 이 요구하는 키를 갖는가
    #    실측: 열 세 항목만 `desc` 를 써서 CLI 가 PNG 를 만든 뒤 KeyError 로 rc=1 이었다.
    #    ⇒ *"계산 성공 → 게시 완료"* 가 성립하지 않았다.  이름 조각 필터가 아니라 **전수**로 본다.
    _miss = sorted(k for k, v in PLOT_REGISTRY.items()
                   if isinstance(v, dict) and 'description' not in v)
    chk('④b L3-10: 모든 registry 항목에 description 키가 있다', not _miss,
        f'없는 항목 {_miss}' if _miss else f'{len(PLOT_REGISTRY)}개 전수')
    _stale = sorted(k for k, v in PLOT_REGISTRY.items()
                    if isinstance(v, dict) and 'desc' in v)
    chk('④b L3-10: 옛 키 `desc` 가 남아 있지 않다', not _stale,
        f'남은 항목 {_stale}' if _stale else '')

    # ⑤ 음성 대조 — 검사가 **판별력이 있는가** (PA12-09: 장식 대조 금지)
    d = str(e.get('description', ''))
    chk('⑤ 대조: α 가 0.1 이었다면 ① 이 깨진다',
        (f'α={0.1:g}' in d) is False and (f'α={alpha:g}' in d) is True)
    chk('⑤ 대조: 특징이 16 이었다면 ① 이 깨진다',
        ('16 structural' in d) is False and (f'{nfeat} structural' in d) is True)
    #  그리고 desc 가 **리터럴이 아니라 상수에서 생성**되는지 소스로 확인한다
    mod_src = inspect.getsource(sys.modules[__name__])
    m = re.search(r'"description":\s*\(f"σ_thermal Stage T1.{0,400}', mod_src, re.S)
    chk('⑤ desc 가 상수에서 생성된다 (리터럴 숫자가 아니다)',
        m is not None and 'len(_THERMAL_T1_FEATURES)' in m.group(0)
        and '_THERMAL_RIDGE_ALPHA' in m.group(0))

    print('설명 정합 SELFTEST', 'PASS' if ok else 'FAIL')
    return 0 if ok else 1


def _selftest_fits():
    """★ L3-08 · L3-12 — **적합이 정해졌는가**와 **캐시가 자료를 보는가**.

    둘 다 *"성공한 것처럼 보이는 실패"* 부류다: 하나는 행이 0인데 유한한 예측과
    `R² = LOOCV = 0` 을 내놓고, 다른 하나는 다른 자료에 앞 자료의 bootstrap 을
    돌려준다.  값이 **비어 있지 않아서** 눈으로는 안 잡힌다.

    ⚠ 대조가 없으면 이 검사도 거짓 초록이 된다 — 게이트를 "항상 거부" 로 만들어도
    ①③④a 는 통과한다.  그래서 ②④b 가 **통과해야 하는** 자리를 잡는다.
    """
    ok = True

    def chk(name, cond, extra=''):
        nonlocal ok
        print(('  ✓ ' if cond else '  ✗ ') + name + (f'   {extra}' if extra else ''))
        ok = ok and bool(cond)

    print('적합 fail-closed + 캐시 지문 (L3-08 · L3-12)')

    def _arr(n, k=14, rng_seed=0, dup=None):
        rng = np.random.default_rng(rng_seed)
        X = rng.normal(size=(n, k))
        if dup is not None:                # 랭크를 일부러 떨어뜨린다 (**LIVE 끼리**)
            X[:, dup[1]] = X[:, dup[0]]
        return {'X': X, 'y_resid': rng.normal(size=n), 'n': n,
                'log_offset': np.zeros(n), 'logsf': rng.normal(size=n)}

    # ── ① 마스크가 전부 False → 거부 ────────────────────────────────────────
    a = _arr(12)
    got = _electronic_fit(a, fit_mask=np.zeros(12, bool))
    chk('① L3-08: EXCL 이 전부라 n_fit=0 이면 **거부**한다 (옛 코드는 '
        'r2=loocv=0.0 · 유한 예측 dict)', got is None)

    # ── ② 양성 대조: 건강한 자료는 **통과해야** 한다 ─────────────────────────
    k_live = len(_electronic_live_cols(14, True))
    a = _arr(40, rng_seed=7)
    got = _electronic_fit(a, fit_mask=np.ones(40, bool))
    chk('② 대조: 건강한 40행은 적합된다 (게이트가 "항상 거부" 가 아니다)',
        isinstance(got, dict) and got['n_fit'] == 40
        and np.isfinite(got['r2']) and np.isfinite(got['loocv']),
        f"n_fit={None if got is None else got['n_fit']}")

    # ── ③ 랭크 부족 → 거부 (lstsq 는 최소노름으로 조용히 메운다) ─────────────
    live = _electronic_live_cols(14, True)
    a = _arr(40, rng_seed=3, dup=(live[0], live[1]))
    got = _electronic_fit(a, fit_mask=np.ones(40, bool))
    chk('③ L3-08: LIVE 열이 서로 같아 랭크가 모자라면 **거부**한다',
        got is None)
    #  ⚠ 대조 — **드롭된** 열을 겹치는 것은 LIVE 랭크와 무관하다.  (내 첫 픽스처가
    #    바로 이 실수를 했고 ③ 이 빨간불을 냈다: live[0]+1 = 3 은 드롭 열이다.)
    drop = sorted(_STAGE_22_5_DROP_COLS)
    a = _arr(40, rng_seed=3, dup=(drop[0], drop[1]))
    chk('③ 대조: **드롭 열**을 겹치는 것은 적합에 영향이 없다 (랭크 검사가 '
        'LIVE 만 본다)',
        isinstance(_electronic_fit(a, fit_mask=np.ones(40, bool)), dict))

    # ── ④ 경계: k_live+1 에서 정확히 갈린다 ─────────────────────────────────
    need = max(_EL_MIN_FIT_ROWS, k_live + 1)
    lo = _electronic_fit(_arr(need - 1, rng_seed=11),
                         fit_mask=np.ones(need - 1, bool))
    hi = _electronic_fit(_arr(need, rng_seed=11),
                         fit_mask=np.ones(need, bool))
    chk(f'④a 경계 아래({need - 1}행) 는 거부', lo is None)
    chk(f'④b 경계({need}행) 는 통과 — 문턱이 한 행 단위로 예리하다',
        isinstance(hi, dict) and hi['n_fit'] == need)

    # ── ⑤ LIVE 열 수가 드롭 논리와 한 출처인가 ──────────────────────────────
    chk('⑤ Stage 22.5 의 LIVE 열 = 8 (드롭 4열 + LOCKED 2열 제외)',
        k_live == 8, f'k_live={k_live}')
    chk('⑤ 대조: lock_endpoints=False 면 14열 전부가 LIVE',
        len(_electronic_live_cols(14, False)) == 14)

    # ── ⑥ L3-12: 지문이 **중간 y** 를 본다 ──────────────────────────────────
    m = 20
    bl = np.linspace(1.0, 2.0, m)
    ls_a = np.linspace(-1.0, 1.0, m)
    ls_b = ls_a.copy(); ls_b[m // 2] *= 10.0
    old_a = (m, 200, 42, float(ls_a[0]), float(ls_a[-1]), float(bl.sum()))
    old_b = (m, 200, 42, float(ls_b[0]), float(ls_b[-1]), float(bl.sum()))
    chk('⑥ 반례 보존: **옛 키**는 중간 y 를 ×10 해도 같다 (그래서 결함이었다)',
        old_a == old_b, str(old_a))
    chk('⑥ L3-12: 내용 지문은 **다르다**',
        _array_fingerprint(bl, ls_a) != _array_fingerprint(bl, ls_b))
    chk('⑥ 대조: 같은 내용이면 같은 지문 (캐시가 무용지물이 되지 않는다)',
        _array_fingerprint(bl, ls_a) == _array_fingerprint(bl.copy(), ls_a.copy()))
    chk('⑥ 대조: 순서만 바꿔도 다른 지문',
        _array_fingerprint(bl, ls_a) != _array_fingerprint(ls_a, bl))
    chk('⑥ 대조: 모양이 다르면 다른 지문 (평탄화 충돌 없음)',
        _array_fingerprint(np.zeros((2, 3))) != _array_fingerprint(np.zeros((3, 2))))

    print('적합·캐시 SELFTEST', 'PASS' if ok else 'FAIL')
    return 0 if ok else 1


if __name__ == "__main__":
    if '--selftest-temp' in sys.argv:
        sys.exit(_selftest_temp())
    if '--selftest-descriptions' in sys.argv:
        sys.exit(_selftest_descriptions())
    if '--selftest-fits' in sys.argv:
        sys.exit(_selftest_fits())
    main()

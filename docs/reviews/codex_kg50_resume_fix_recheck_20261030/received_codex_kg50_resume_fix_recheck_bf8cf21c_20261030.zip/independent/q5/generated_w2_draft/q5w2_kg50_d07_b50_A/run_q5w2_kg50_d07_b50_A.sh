#!/bin/bash
#SBATCH --job-name=q5w2_kg50_d07_b50_A
#SBATCH --output=logs/output_q5w2_kg50_d07_b50_A_%j.out
#SBATCH --qos=cpu-60
#SBATCH --partition=cpu
#SBATCH -n 56
#SBATCH --time=5-00:00:00

source ~/.bashrc
conda activate myenv

export OMP_NUM_THREADS=1
export MKL_NUM_THREADS=1
export OPENBLAS_NUM_THREADS=1
export NUMEXPR_NUM_THREADS=1

cd $HOME/dem_test/q5w2_kg50_d07_b50_A
mpirun --oversubscribe --bind-to none -np 56 lmp_mpi -in input_q5w2_kg50_d07_b50_A.liggghts

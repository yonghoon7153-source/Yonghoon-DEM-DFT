"""Offline byte/identity review only. Does not run repository code or read research data."""
from pathlib import Path, PurePosixPath
import hashlib
import json
import zipfile

ROOT = Path(__file__).resolve().parent
PIN = 'df9a4623e2f9e6302e6bc8922bd0612ab48e120c'
ZIP_NAME = 'codex_d3_sop_review_20261104_df9a4623e2f9.zip'
ZIP_SHA = '7ad7020be45b8de645a01783c1009163853b7beb6447014f947422e40eabf501'

def require(condition, message):
    if not condition:
        raise ValueError(message)

def main():
    zp = ROOT / 'input' / ZIP_NAME
    zb = zp.read_bytes()
    require(hashlib.sha256(zb).hexdigest() == ZIP_SHA, 'source ZIP SHA-256 differs')
    remote = json.loads((ROOT / 'remote_pin.json').read_text(encoding='utf-8'))
    require(remote['pin'] == PIN, 'remote metadata pin differs')
    remote_entries = {x['path']: x for x in remote['entries']}
    with zipfile.ZipFile(zp) as z:
        names = z.namelist()
        require(len({n.casefold() for n in names}) == len(names), 'duplicate ZIP names')
        for info in z.infolist():
            p = PurePosixPath(info.filename)
            require(not p.is_absolute() and '..' not in p.parts and ':' not in info.filename and '\\' not in info.filename, 'unsafe ZIP path')
            require((info.external_attr >> 16) & 0o170000 != 0o120000, 'ZIP symlink')
        require(z.read('PIN.txt').decode().strip() == PIN, 'PIN.txt differs')
        manifest = json.loads(z.read('SNAPSHOT_MANIFEST.json'))
        require(manifest['pin'] == PIN and manifest['branch'] == 'codex/mixer-1104', 'snapshot identity differs')
        rows = []
        for item in manifest['entries']:
            name = item['path']
            b = z.read(name)
            sha = hashlib.sha256(b).hexdigest()
            blob = hashlib.sha1(b'blob ' + str(len(b)).encode() + b'\0' + b).hexdigest()
            require((len(b), sha, blob) == (item['bytes'], item['sha256'], item['git_blob']), 'snapshot mismatch: ' + name)
            r = remote_entries[name]
            require((len(b), blob) == (r['bytes'], r['git_blob']), 'remote metadata mismatch: ' + name)
            rows.append({'path': name, 'bytes': len(b), 'sha256': sha, 'git_blob': blob, 'line_count': len(b.decode('utf-8').splitlines()), 'remote_pin_blob_matches': True})
        require(len(rows) == len({r['path'] for r in rows}) == 6, 'snapshot set differs')
        require(set(remote_entries) == {r['path'] for r in rows}, 'remote set differs')
        checked = []
        for line in z.read('PACKAGE_SHA256SUMS').decode().splitlines():
            expected, name = line.split('  ', 1)
            if name.startswith('./'):
                name = name[2:]
            require(hashlib.sha256(z.read(name)).hexdigest() == expected, 'package mismatch: ' + name)
            checked.append(name)
        require(len(checked) == len(set(checked)) == 17, 'package checksum entry count differs')
        require(set(names) - set(checked) == {'PACKAGE_SHA256SUMS'}, 'package checksum coverage differs')
        request = 'docs/reviews/codex_mixer_d3_sop_review_request_20261104.md'
        require(z.read('REQUEST.md') == z.read(request), 'REQUEST.md is not byte-identical to pinned request')
    return {'review_pin': PIN, 'source_zip_sha256': ZIP_SHA, 'source_zip_bytes': len(zb), 'snapshot_files_checked': 6, 'recorded_remote_pin_blobs_matched': 6, 'package_entries_checked': 17, 'request_copy_identical': True, 'unsafe_entries': [], 'files': rows, 'scope': 'Offline bytes and previously retrieved pinned GitHub metadata only; no semantic, human-blinding, statistical, equipment or physical certification', 'reviewed_code_or_tests_executed': False, 'research_data_read': False, 'overall_gate': 'HOLD', 'execution_or_release_authorized': False}

if __name__ == '__main__':
    print(json.dumps(main(), ensure_ascii=False, indent=2))

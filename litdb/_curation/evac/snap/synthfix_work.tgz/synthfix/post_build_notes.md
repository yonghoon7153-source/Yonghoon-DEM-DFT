- 실행 = python3 -I -B <litread>/synth/build_package.py <litread> /home/user/Yonghoon-DEM-DFT <synthfix>/package · 종료코드 0 · 한 번 · 프로세스 하나. 리포에는 아무것도 쓰지 않았다 (-B 로 바이트코드도 안 남김 · 실행 앞뒤 git status 깨끗 그대로).
- build_report.txt 요지: TICK 19 줄 (백틱 뗀 곳 합 45 — 배치 근거 17 파일 29 곳 · layer3_findings.md 5 곳 · card_problems.md 11 곳) · BAN 5 줄 (batch_01_findings.md:14 · batch_14_findings.md:217 · 244 · card_problems.md:495 · 522 — 줄 끝에 철회 표지 덧붙임) · CARDS 배치 41 · 항목 합 837 · M_MERGE 머리 21 · FILES 123 · 카드 줄 281 · 스윕 남은 문제 0 · 바이트 6061023.
- 종합 문서 쪽 손질 수 = 0: S1–S5 · S8 · insights_merged.md 에는 TICK · BAN 줄이 없다. 묶음 안 S1–S5 · S8 은 synth/out 의 파일과 바이트 같다 (cmp). 합친 통찰은 세 몫의 첫 머리 뒤 내용 줄 1,383 개를 모두 담는다 (없는 줄 0).
- 본 세션 시험 묶음 (package_test · 파일 78) 과 견줌: 공통 78 가운데 76 같음 (batch_01–38 의 표 · 근거) · 다름 2 (build_report.txt · card_problems.md — 카드 문제 묶음이 배치 38 → 41 로 늘어서) · 이번 묶음에만 있는 것 54 (배치 표 19 · 배치 근거 19 · layer3_findings.md · insights_merged.md · S1–S5 · S8 · verify 7 · APPLIED.md).
- 묶음 뒤 손으로 한 것 (스크립트가 하지 않는 것):
  1. evidence/verify/ 에 검증 보고 일곱 개 (V_S1 · V_S2 · V_S3 · V_S4 · V_S5 · V_S6_12 · V_S6_3) 복사 — synth/verify 의 원본과 바이트 같음.
  2. evidence/APPLIED.md (이 문서) 복사.
  3. insights_merged.md 의 소개 문단 뒤에 세 몫의 한정 줄을 옮김 (머리 줄 1 + 몫마다 1 줄 = 4 줄 · 빈 줄 2 · 도구 = synthfix/tools/post_build.py · 넣기 전 사본 = synthfix/insights_merged.before_post.md · 그 여섯 줄 말고는 넣기 전과 같음). build_package 는 S6_1 · S6_2 · S6_3 의 첫 머리 앞 글 (제목 · 한정 줄 · 입력 설명) 을 합치지 않는다.
  4. 손으로 넣은 여덟 파일에 같은 철회값 스윕과 백틱 경로 검사를 돌림 — 문제 0 · 리포에 없는 백틱 경로 0 → 손질 없이 그대로 둠.
- 묶음 전체 다시 점검: md 131 개 철회값 스윕 문제 0 (synthfix/tools/sweep_package.py) · 표 칸 수 어긋난 줄 0 (S1–S5 · S8 · insights_merged.md · card_problems.md · APPLIED.md · verify 일곱).
- 묶음 파일 수 = 132 (스크립트 123 + build_report.txt 1 + verify 7 + APPLIED.md 1).
- 눈에 띈 것 (고치지 않음 · 스크립트와 입력의 일):
  - card_problems.md 는 synth/q_cards.md (머리 41 = batch_01–40 + layer3) 에서 만들어진다. synth2/q_cards.md (머리 43 = batch_01–42 + layer3) 가 아니어서 묶음의 카드 문제 기록에는 batch_41 · batch_42 절이 없다.
  - evidence 의 배치 표 · 배치 근거는 57 개씩이다 (batch_01–42 + 한 장짜리 15 개: 43 · 45 · 46 · 48 · 49 · 50 · 51 · 55 · 60 · 61 · 64 · 65 · 66 · 75 · 76). 종합 문서가 입력으로 적은 것은 batch_01–42 + layer3 다.
  - insights_merged.md 소개 문단의 "몫 3 = 20–39" 는 스크립트에 박힌 글이다 — S6_3 의 제목은 배치 20–42.

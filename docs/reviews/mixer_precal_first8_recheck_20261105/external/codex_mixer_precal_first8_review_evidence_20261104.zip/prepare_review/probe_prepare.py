"""Independent, in-memory/static preparation review; no simulator or source edits."""
import copy
import hashlib
import json
from pathlib import Path
import sys
from unittest import mock

ROOT = Path(__file__).resolve().parents[1]
SCRIPTS = ROOT / 'received' / 'scripts'
sys.path.insert(0, str(SCRIPTS))
import make_mixer_deck as gen
import mixer_deck_readback as rb
import mixer_precal_prepare as prep

PIN = (ROOT / 'received' / 'PIN.txt').read_text().strip()
results = {'pin': PIN, 'python': sys.version, 'scope': 'static and in-memory synthetic only',
           'research_results': 0, 'execution_authorized': False, 'checks': [], 'cases': []}

def record(name, passed, **details):
    results['checks'].append(dict(name=name, passed=bool(passed), **details))

def rebound(meta, raw):
    meta = copy.deepcopy(meta)
    meta.update(deck_sha256=hashlib.sha256(raw).hexdigest(), deck_bytes=len(raw))
    return meta

def refuses(cid, raw, meta):
    try:
        prep.validate_case(cid, raw, meta)
    except ValueError as exc:
        return str(exc)
    return None

sources = ('mixer_precal_prepare.py', 'make_mixer_deck.py', 'mixer_deck_readback.py',
           'mixer_deck_diff.py', 'test_mixer_precal_prepare.py')
before = {f: hashlib.sha256((SCRIPTS / f).read_bytes()).hexdigest() for f in sources}
items = {cid: prep.prepare_case(cid) for cid in prep.CASE_IDS}
parsed = {cid: rb.read_deck(item['deck'].decode('utf-8')) for cid, item in items.items()}
baseline_material = None
for cid, item in items.items():
    d = parsed[cid]
    m = item['meta']
    binding = prep.validate_case(cid, item['deck'], m)
    material = (d['E'], d['nu'], d['templates'], d['dt'], d['runs'][1:3], d['period'])
    if baseline_material is None:
        baseline_material = copy.deepcopy(material)
    record(cid + ': common material/time', material == baseline_material)
    rule_dt, rule_by = rb.rayleigh_dt(d)
    record(cid + ': printed Rayleigh dt', abs(d['dt'] / rule_dt - 1) <= rb.TOL['rayleigh_rel'],
           dt=d['dt'], rule=rule_dt, setter=rule_by)
    phase_types = binding['phases']
    record(cid + ': printed radii', all(phase_types[p]['radius_m'] == d['templates'][i]['radius']
                                      for i, p in enumerate(prep.PHASES, 1)))
    revs = 0 if cid == 'PRECAL_E0' else 2
    record(cid + ': actual 0/2 revolutions',
           abs(d['runs'][3] * d['dt'] - revs * d['period']) <= revs * d['period'] * rb.TOL['dt_print_rel'] + d['dt'])
    inserts = [t for _, t in d['cmds'] if t[0] == 'fix' and t[3] == 'insert/pack']
    record(cid + ': insertion partition', len(inserts) == (1 if cid == 'PRECAL_E0' else 2))
    if cid in ('PRECAL_N0', 'PRECAL_E0'):
        record(cid + ': separate zero contract', all(v == 0 for v in d['ced'].values()) and
               m['registered'] is None and m['schema'] == prep.BASELINE_SCHEMA and
               'adhesion_rule' not in m and rb.read_d2(item['deck'], m)['verdict'] == 'FAIL')
    else:
        record(cid + ': independent D2', rb.read_d2(item['deck'], m)['verdict'] == 'PASS')
    results['cases'].append(dict(case_id=cid, sha256=m['deck_sha256'], size=len(item['deck']),
                                n_planned=binding['n_planned'], counts=binding['expected_counts'],
                                dt=d['dt'], period=d['period'], runs=d['runs'], steps=m['steps']))
    changes = {
        'seed': lambda b: b.replace(b'32452843', b'15485863'),
        'gravity': lambda b: b.replace(b'9.81 vector', b'9.82 vector'),
        'density': lambda b: b.replace(b'density constant 4850', b'density constant 4800'),
        'youngs_modulus': lambda b: b.replace(b'2e+08', b'1e+08'),
        'dump_precision': lambda b: b.replace(b'%.17g', b'%.16g'),
        'thermo_output': lambda b: b.replace(b'thermo 5000', b'thermo 1000'),
        'extra_output': lambda b: b + b'print "unapproved output"\n',
        'CRLF': lambda b: b.replace(b'\n', b'\r\n'),
        'run_extra': lambda b: b + b'run 1\n',
    }
    for name, mutation in changes.items():
        bad = mutation(item['deck'])
        if bad == item['deck']:
            # Exact source tokens can differ in spacing/spelling; mark rather than claiming a test.
            results.setdefault('skipped_no_change', []).append(cid + ':' + name)
            continue
        refusal = refuses(cid, bad, rebound(m, bad))
        record(cid + ': rebound tamper ' + name, refusal is not None, refusal=refusal)
    for source_cid, source in items.items():
        if source_cid != cid:
            record(cid + ': cross-case ' + source_cid,
                   refuses(cid, source['deck'], source['meta']) is not None)

# Exact metadata contract, including JSON-native type distinctions.
for cid in ('PRECAL_R1_B1_U', 'PRECAL_N0', 'PRECAL_E0'):
    item = items[cid]
    mutations = {
        'bool_seed': lambda m: m.update(seed=True),
        'bool_N': lambda m: m.update(n_atoms_planned=True),
        'bool_dt_factor': lambda m: m.update(dt_factor=True),
        'revolutions': lambda m: m.update(revolutions=1),
        'schema1_registration': lambda m: m.update(schema='mixer_deck_meta/1', registered='legacy'),
        'density_generation': lambda m: m.update(dens_gen='gen1'),
        'NaN': lambda m: m.update(cgf=float('nan')),
        'time_metadata': lambda m: m['steps'].update(fill=m['steps']['fill'] + 1),
    }
    for name, mutation in mutations.items():
        m = copy.deepcopy(item['meta']); mutation(m)
        record(cid + ': metadata ' + name, refuses(cid, item['deck'], m) is not None)

# Existing temporary-name collisions must preserve the prior object, and failures after
# temporary registration must restore TYPES by identity and all ARMS content.
old_types = gen.TYPES
old_arms = copy.deepcopy(gen.ARMS)
try:
    gen.set_phases(('AM_P', 'SE'))
    saved_types = gen.TYPES
    sentinel = {'desc': 'review sentinel', 'bond': 0.0}
    gen.ARMS[prep._TEMP_ARM] = sentinel
    try:
        prep.prepare_case('PRECAL_R1_B1_U')
        refused = False
    except ValueError:
        refused = True
    record('preexisting temporary name collision restores state', refused and
           gen.TYPES is saved_types and gen.ARMS[prep._TEMP_ARM] is sentinel)
    del gen.ARMS[prep._TEMP_ARM]
    for function in ('gm_arm', 'register_arm', 'plan', 'resolve_rpm', 'deck', 'deck_meta'):
        with mock.patch.object(gen, function, side_effect=SystemExit('review synthetic refusal')):
            try:
                prep.prepare_case('PRECAL_R1_B1_U')
                refused = False
            except ValueError:
                refused = True
        record('failure restoration at ' + function,
               refused and gen.TYPES is saved_types and gen.ARMS == old_arms)
finally:
    gen.TYPES = old_types
    gen.ARMS.clear(); gen.ARMS.update(old_arms)

# Scope characterization, NOT an input bypass: the source-output oracle is explicitly
# replaced in memory. No supplied files are changed. The separate baseline path does
# not independently calculate Rayleigh dt; external bytes still fail the normal oracle.
cid = 'PRECAL_N0'
item = items[cid]
old = ('timestep       ' + parsed[cid]['dt_txt']).encode()
lines = item['deck'].splitlines(keepends=True)
changed = []
for line in lines:
    if line.lstrip().startswith(b'timestep '):
        changed.append(b'timestep        0.0001\n')
    else:
        changed.append(line)
raw = b''.join(changed)
bad = dict(item, deck=raw, meta=rebound(item['meta'], raw))
ordinary_refusal = refuses(cid, raw, bad['meta'])
with mock.patch.object(prep, '_generate', return_value=bad):
    mocked_refusal = refuses(cid, raw, bad['meta'])
results['acknowledged_oracle_boundary'] = {
    'case_id': cid, 'mutation': 'printed timestep 0.0001 with only deck hash/size rebound',
    'ordinary_path_refused': ordinary_refusal, 'oracle_mocked_path_refused': mocked_refusal,
    'classification': 'documented common-source boundary; not counted as a finding',
}

after = {f: hashlib.sha256((SCRIPTS / f).read_bytes()).hexdigest() for f in sources}
record('all inspected source bytes unchanged', before == after)
results['source_sha256'] = after
results['check_count'] = len(results['checks'])
results['failed'] = [x['name'] for x in results['checks'] if not x['passed']]
results['reportable_findings'] = []
out = Path(__file__).with_name('probe_prepare_results.json')
out.write_text(json.dumps(results, indent=2, ensure_ascii=False) + '\n', encoding='utf-8')
print(json.dumps({'checks': results['check_count'], 'failed': results['failed'],
                  'skipped_no_change': results.get('skipped_no_change', []),
                  'oracle_boundary': results['acknowledged_oracle_boundary'], 'result': str(out)}, indent=2))
raise SystemExit(bool(results['failed']))

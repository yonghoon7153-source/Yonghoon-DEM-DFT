import pathlib,hashlib,json,zipfile,platform,io
ROOT=pathlib.Path(__file__).resolve().parent
BASE=ROOT/'input'
manifest=json.loads((BASE/'SNAPSHOT_MANIFEST.json').read_text(encoding='utf-8'))
records=[]
for e in manifest['entries']:
    raw=(BASE/e['path']).read_bytes()
    blob=hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()
    records.append(dict(path=e['path'],size_ok=len(raw)==e['bytes'],sha256_ok=hashlib.sha256(raw).hexdigest()==e['sha256'],blob_ok=blob==e['git_blob'],blob=blob))
sums=[]
for row in (BASE/'PACKAGE_SHA256SUMS').read_text().splitlines():
    expected,name=row.split('  ',1)
    sums.append(dict(path=name,ok=hashlib.sha256((BASE/name).read_bytes()).hexdigest()==expected))
external=BASE/'docs/reviews/mixer_precal_first8_recheck_20261105/external/codex_mixer_precal_first8_review_evidence_20261104.zip'
with zipfile.ZipFile(external) as outer:
    old=io.BytesIO(outer.read('input/codex_mixer_precal_first8_20261104_189930cc68b6.zip'))
prior=[]
with zipfile.ZipFile(old) as z:
    om=json.loads(z.read('SNAPSHOT_MANIFEST.json'))
    for e in om['entries']:
        p=BASE/e['path']
        if p.is_file():prior.append(dict(path=e['path'],identical=z.read(e['path'])==p.read_bytes()))
report=dict(pin=(BASE/'PIN.txt').read_text().strip(),previous_pin=(BASE/'PREVIOUSLY_REVIEWED_PIN.txt').read_text().strip(),manifest_files=records,package_files=sums,previous_common=prior)
(ROOT/'intake_verification.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
print(json.dumps(dict(pin=report['pin'],manifest_entries=len(records),manifest_bad=[r for r in records if not all(r[k] for k in ('size_ok','sha256_ok','blob_ok'))],package_entries=len(sums),package_bad=[r for r in sums if not r['ok']],previous_common=len(prior),changed=[r['path'] for r in prior if not r['identical']]),indent=2))

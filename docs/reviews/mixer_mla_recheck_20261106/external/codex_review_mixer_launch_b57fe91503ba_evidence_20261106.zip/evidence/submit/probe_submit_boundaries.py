"""LOCAL ONLY. Original submit function; POSIX path facade backed by local files.

No subprocess, scheduler, MPI, WSL, network, or scientific module is executed.
All subprocess.run calls in the loaded draft are replaced with FakeScheduler.
An audit hook additionally rejects process creation/system commands/network use.
"""
import concurrent.futures
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import runpy
import subprocess
import sys
import tempfile
import threading
import time
from types import SimpleNamespace

EVIDENCE = Path(__file__).resolve().parent
PACKAGE = EVIDENCE.parents[1] / "package"
REL = "docs/reviews/mixer_first8_launch_preparation_20261106"
HERE = PACKAGE / REL
PIN = "b57fe91503ba68cec6f41aec247851262788e48f"
PROCESS_EVENTS = []


def audit(event, args):
    if event in {"subprocess.Popen", "os.system", "os.exec", "os.posix_spawn", "os.spawn", "socket.connect"}:
        PROCESS_EVENTS.append(event)
        raise AssertionError("LOCAL mock blocked external action: " + event)


sys.addaudithook(audit)


def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()


class LocalPosixPath:
    """Only adapt path syntax; use actual local bytes and actual O_EXCL claims."""
    fixture = None

    def __init__(self, p=""):
        self.p = PurePosixPath(str(p))

    def __str__(self):
        return str(self.p)

    def __truediv__(self, other):
        return type(self)(self.p / other)

    @property
    def parent(self):
        return type(self)(self.p.parent)

    @property
    def name(self):
        return self.p.name

    def local(self):
        for prefix, actual in ((PurePosixPath("/package"), PACKAGE), (PurePosixPath("/fixture"), self.fixture)):
            try:
                rel = self.p.relative_to(prefix)
            except ValueError:
                continue
            target = actual.joinpath(*rel.parts)
            assert target.resolve().is_relative_to(actual.resolve()), "outside local roots"
            return target
        raise AssertionError("Unknown virtual path: " + str(self))

    def resolve(self):
        self.local()
        return self

    def is_absolute(self):
        return self.p.is_absolute()

    def is_file(self):
        return self.local().is_file()

    def is_dir(self):
        return self.local().is_dir()

    def is_symlink(self):
        return self.local().is_symlink()

    def exists(self):
        return self.local().exists()

    def read_bytes(self):
        return self.local().read_bytes()

    def read_text(self):
        return self.local().read_text(encoding="utf-8")

    def write_text(self, data):
        return self.local().write_text(data, encoding="utf-8")


class FakeScheduler:
    def __init__(self, mode="ok"):
        self.mode, self.calls = mode, []
        self.lock = threading.Lock()

    def run(self, argv, **kwargs):
        assert argv[:3] == ["sbatch", "--parsable", "--no-requeue"]
        assert set(kwargs) == {"capture_output", "text", "timeout"}
        with self.lock:
            self.calls.append({"argv": argv, "kwargs": kwargs})
            number = len(self.calls)
        if self.mode == "timeout":
            raise subprocess.TimeoutExpired(argv, 60)
        if self.mode == "failed":
            return SimpleNamespace(returncode=1, stdout="", stderr="synthetic rejection")
        if self.mode == "ambiguous":
            return SimpleNamespace(returncode=0, stdout="12345 extra\n", stderr="")
        return SimpleNamespace(returncode=0, stdout=str(10000 + number) + "\n", stderr="")


def load(fake, barrier=None):
    ns = runpy.run_path(str(HERE / "submit_one.py.txt"))
    g = ns["main"].__globals__
    assert g["subprocess"] is subprocess
    g["Path"] = LocalPosixPath
    g["__file__"] = "/package/" + REL + "/submit_one.py.txt"
    g["subprocess"] = SimpleNamespace(run=fake.run, TimeoutExpired=subprocess.TimeoutExpired)

    def local_open(path, flags, mode=0o777):
        assert path.endswith("/submission.claim.json")
        assert flags & os.O_EXCL
        if barrier is not None:
            barrier.wait(timeout=15)
        return os.open(LocalPosixPath(path).local(), flags, mode)

    g["os"] = SimpleNamespace(open=local_open, fdopen=os.fdopen, fsync=os.fsync,
                              O_WRONLY=os.O_WRONLY, O_CREAT=os.O_CREAT, O_EXCL=os.O_EXCL)
    assert g["subprocess"].run.__self__ is fake
    return ns


def put(virtual, data):
    p = LocalPosixPath(virtual).local()
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_bytes(data if isinstance(data, bytes) else data.encode("utf-8"))
    return {"path": virtual, "sha256": sha(p)}


def shared():
    receipt = {"observed_unix": time.time(), "qos": "cpu-60", "partition": "cpu",
               "reserved_cpus": 0, "running_first8": 0}
    receipt.update({k: True for k in ("qos_verified", "disk_budget_verified", "inode_budget_verified",
                                     "d07_finished", "qualification_accepted", "paths_verified")})
    return {"author_go": put("/fixture/shared/author_go", json.dumps({
                "synthetic": True, "approved_cases": ["PRECAL_R1_B1_U", "PRECAL_R1_B1_C"],
                "maximum_concurrent_first8": 1})),
            "live_preflight": put("/fixture/shared/live", json.dumps(receipt))}


def fixture(name, ns, common):
    base = "/fixture/" + name
    root = base + "/case"
    LocalPosixPath(root).local().mkdir(parents=True)
    c = {"schema": "mixer_first8_execution_approval/1", "execution_authorized": True,
         "gate": "MAP_CASE_GO", "case": name, "np": 20, "author_choices_confirmed": True,
         "approved_concurrency": 1, "wave_release": [name], "case_dir": root,
         "runner_reviewed": True, "walltime_approved": True, **common}
    for key in ("qualification", "mxd2r_disposition", "binary", "mpi_launcher"):
        c[key] = put(base + "/" + key, "SYNTHETIC - NEVER EXECUTED")
    c["policy"] = put(base + "/policy", json.dumps({"execution_authorized": True,
                        "policy_id": "SYNTHETIC-SAME-PACKAGE", "allowed_to_submit": [name]}))
    files = [put(root + "/" + name_, (HERE / "planned_assets" / name / name_).read_bytes())
             for name_ in ("in.mixer", "deck_meta.json", "Drum.stl", "Front.stl", "Back.stl")]
    seal = json.loads((HERE / "source_seal.json").read_text())
    c.update(source_pin=seal["source_pin"], source_root=base + "/source")
    for item in seal["files"]:
        files.append(put(c["source_root"] + "/" + item["path"], (PACKAGE / item["path"]).read_bytes()))
    c["runner_bindings"] = {"python": base + "/python", "job_start": base + "/job_start",
                            "stdout": base + "/stdout", "stderr": base + "/stderr", "walltime": "1-00:00:00"}
    files.append(put(base + "/python", "SYNTHETIC - NEVER EXECUTED"))
    files.append(put(base + "/job_start", (HERE / "job_start.py.txt").read_bytes()))
    ap = base + "/approval.json"
    c["runner"] = put(base + "/runner", ns["canonical_runner"](c, ap))
    c["source_manifest"] = put(base + "/manifest", json.dumps({"files": files}))
    put(ap, json.dumps(c))
    return ap


def attempt(ns, approval):
    try:
        ns["main"](approval)
        return {"accepted": True}
    except Exception as error:
        return {"accepted": False, "error_type": type(error).__name__, "error": str(error)}


def run_scenario(mode):
    with tempfile.TemporaryDirectory(prefix="local_submit_", dir=EVIDENCE) as temp:
        LocalPosixPath.fixture = Path(temp)
        assert Path(temp).resolve().is_relative_to(EVIDENCE.resolve())
        fake = FakeScheduler(mode if mode not in ("same_case_race", "concurrency", "successor") else "ok")
        ns = load(fake, threading.Barrier(2) if mode in ("same_case_race", "concurrency") else None)
        common = shared()
        first = fixture("PRECAL_R1_B1_U", ns, common)
        if mode == "same_case_race":
            with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
                outcomes = list(pool.map(lambda ap: attempt(ns, ap), (first, first)))
            assert sum(item["accepted"] for item in outcomes) == 1 and len(fake.calls) == 1
        elif mode == "concurrency":
            second = fixture("PRECAL_R1_B1_C", ns, common)
            with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
                outcomes = list(pool.map(lambda ap: attempt(ns, ap), (first, second)))
            assert all(item["accepted"] for item in outcomes) and len(fake.calls) == 2
        elif mode == "successor":
            second = fixture("PRECAL_R1_B1_C", ns, common)
            fake.mode = "ambiguous"
            outcomes = [attempt(ns, first)]
            fake.mode = "ok"
            outcomes.append(attempt(ns, second))
            assert not outcomes[0]["accepted"] and outcomes[1]["accepted"] and len(fake.calls) == 2
        else:
            outcomes = [attempt(ns, first), attempt(ns, first)]
            assert len(fake.calls) == 1 and not outcomes[1]["accepted"]
            assert outcomes[0]["accepted"] == (mode == "ok")
        return {"scenario": mode, "outcomes": outcomes, "fake_sbatch_calls": len(fake.calls),
                "approved_concurrency_each": 1, "shared_running_first8_snapshot": 0,
                "external_process_calls": len(PROCESS_EVENTS)}


def main():
    assert (PACKAGE / "PIN.txt").read_text().strip() == PIN
    inventory = json.loads((PACKAGE / "SNAPSHOT_MANIFEST.json").read_text())["entries"]
    entry = next(x for x in inventory if x["path"] == REL + "/submit_one.py.txt")
    assert sha(HERE / "submit_one.py.txt") == entry["sha256"]
    result = {"pin": PIN, "source_sha256": entry["sha256"], "python": sys.version,
              "scope": "Unchanged submit function; local POSIX-path facade; all subprocess calls fake",
              "scenarios": [run_scenario(mode) for mode in ("ok", "failed", "ambiguous", "timeout", "same_case_race", "concurrency", "successor")],
              "external_process_calls": PROCESS_EVENTS}
    (EVIDENCE / "submit_boundary_results.json").write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()

#!/bin/bash
# build_block.sh — meta_script.sh 를 붙여넣기 블록으로 (DEM1 make_block.sh 의 검사 그대로 + 파일 대신 셸 변수에 담는 꼴)
#   bash build_block.sh <meta_script.sh> <meta_block.txt>
#   검사: bash -n · 느낌표 (history 확장) · 탭 · CR · 줄 첫 글자 ^ · 구분자 줄 · 끝 개행 · 블록 자체도 다시 검사
set -u
S=$1; OUT=$2; DELIM=MIX_E0_META_EOF; BAD=0
[ -s "$S" ] || { echo "사용법: bash build_block.sh <스크립트> <블록>"; exit 2; }
bash -n "$S" || { echo "FAIL bash -n"; BAD=1; }
n=$(tr -cd '\041' < "$S" | wc -c); [ "$n" = 0 ] || { echo "FAIL 느낌표 $n 개"; grep -n "$(printf '\041')" "$S" | head -5; BAD=1; }
n=$(tr -cd '\t' < "$S" | wc -c); [ "$n" = 0 ] || { echo "FAIL 탭 $n 개"; BAD=1; }
n=$(tr -cd '\r' < "$S" | wc -c); [ "$n" = 0 ] || { echo "FAIL CR $n 개"; BAD=1; }
grep -q '^\^' "$S" && { echo "FAIL 줄 첫 글자 ^ (history 빠른 치환)"; BAD=1; }
grep -qx "$DELIM" "$S" && { echo "FAIL 본문에 구분자 줄"; BAD=1; }
[ "$(tail -c 1 "$S" | od -An -c | tr -d ' ')" = '\n' ] || { echo "FAIL 끝 개행 없음"; BAD=1; }
[ "$BAD" = 0 ] || exit 1
M=$(md5sum < "$S" | cut -c1-32)
{
  echo "# 믹서 E0 메타 수집 블록 (읽기 전용 · ibb 셸 (bash) 에 통째로 붙여넣기) — 마지막 줄이 md5 를 대조하고 맞을 때만 돈다 · 새 폴더 ~/mixer_e0_meta_<UTC>/ 하나에만 쓴다"
  echo "IFS= read -r -d '' MIX_E0_META_SH <<'$DELIM' || true"
  cat "$S"
  echo "$DELIM"
  echo "MIX_MD5=\$(printf '%s' \"\$MIX_E0_META_SH\" | timeout 10 md5sum 2>/dev/null); if [ \"\${MIX_MD5%% *}\" = $M ]; then bash -c \"\$MIX_E0_META_SH\" mixer_e0_meta \"\$MIX_E0_META_SH\"; else echo \"붙여넣기가 깨짐 (md5 다름) 또는 md5sum · timeout 없음 — 아무것도 안 함\"; fi; unset MIX_E0_META_SH MIX_MD5"
} > "$OUT"
n=$(tr -cd '\041' < "$OUT" | wc -c); [ "$n" = 0 ] || { echo "FAIL 블록 느낌표 $n"; exit 1; }
n=$(tr -cd '\t\r' < "$OUT" | wc -c); [ "$n" = 0 ] || { echo "FAIL 블록 탭/CR $n"; exit 1; }
bash -n "$OUT" || { echo "FAIL 블록 bash -n"; exit 1; }
echo "OK $OUT · 스크립트 md5 $M · 블록 $(wc -l < "$OUT") 줄 $(wc -c < "$OUT") 바이트 · 스크립트 $(wc -l < "$S") 줄 · 최장 줄 $(awk '{ if (length($0) > m) m = length($0) } END { print m }' "$S") 바이트"

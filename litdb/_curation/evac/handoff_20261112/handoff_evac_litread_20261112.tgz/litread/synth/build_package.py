#!/usr/bin/env python3
"""정독 산출 묶음을 만든다 (스크래치 → 리포에 넣을 폴더 꼴).

  build_package.py <litread 폴더> <리포 루트> <출력 폴더>

만드는 것 (출력 폴더 아래):
  evidence/batch_NN_cards.md      배치 표 (TSV 8 칸) 를 마크다운 표로 (값 그대로 · '|' 만 이스케이프)
  evidence/batch_NN_findings.md   배치 근거 (조수 출력 그대로 + 아래 두 가지 기계적 손질)
  evidence/layer3_findings.md     비교 문서 정독 근거 (있으면)
  card_problems.md                카드 문제 기록 (배치별 원문 그대로 · 앞에 배치별 개수 표)
  insights_merged.md              질문 m 종합 세 몫을 머리별로 합친 것 (세 몫이 다 있으면)
  build_report.txt                무엇을 얼마나 손질했는지

기계적 손질 두 가지 (보고에 줄 단위로 남긴다):
  1. 철회값 스윕 (scripts/check_review_findings.py ban_sweep) 이 표지 없다고 잡는 줄 끝에
     ' [철회된 출처 — 카드에 적힌 것을 옮긴 줄 · 인용 금지]' 를 덧붙인다.
  2. 백틱으로 감싼 파일 이름 가운데 이 리포에 없는 경로는 백틱만 뗀다 (글자는 그대로).
"""
import collections
import glob
import os
import re
import sys

LR, REPO, OUT = sys.argv[1], sys.argv[2], sys.argv[3]
EXTS = ('py', 'sh', 'json', 'csv', 'md', 'mjs', 'js', 'yml', 'yaml', 'liggghts', 'stl', 'npy', 'txt')
RE_TICK = re.compile(r'`([A-Za-z0-9_][A-Za-z0-9_./+-]*\.(?:' + '|'.join(EXTS) + r'))`')
BAN_TAG = ' [철회된 출처 — 카드에 적힌 것을 옮긴 줄 · 인용 금지]'
COLS = ['slug', '서지', '방법', '재료 · 차원', '조건', '준 것', '계획의 자리', '한계 · 3.2 제안']
report = []


def strip_ticks(text, name):
    n = [0]

    def rep(m):
        p = m.group(1)
        if os.path.exists(os.path.join(REPO, p)):
            return m.group(0)
        n[0] += 1
        return p
    out = RE_TICK.sub(rep, text)
    if n[0]:
        report.append('TICK %s 백틱 뗀 곳 %d' % (name, n[0]))
    return out


def ban_fix(path_list):
    """스윕이 잡는 줄에 표지를 덧붙이고 다시 돌려 0 인지 본다."""
    sys.path.insert(0, os.path.join(REPO, 'scripts'))
    import check_review_findings as c
    for _round in range(3):
        probs, _nf, _nb = c.ban_sweep(REPO, None, files=path_list)
        if not probs:
            return 0
        hits = collections.defaultdict(set)
        for p in probs:
            m = re.search(r'([^\s:|]+\.md):(\d+)', str(p))
            if not m:
                report.append('BAN_UNPARSED %s' % str(p)[:200])
                continue
            base = os.path.basename(m.group(1))
            hits[base].add(int(m.group(2)))
        for f in path_list:
            b = os.path.basename(f)
            if b not in hits:
                continue
            lines = open(f, encoding='utf-8').read().split('\n')
            for ln in sorted(hits[b]):
                if 1 <= ln <= len(lines) and BAN_TAG not in lines[ln - 1]:
                    lines[ln - 1] += BAN_TAG
                    report.append('BAN %s:%d 표지 덧붙임' % (b, ln))
            open(f, 'w', encoding='utf-8').write('\n'.join(lines))
    probs, _nf, _nb = c.ban_sweep(REPO, None, files=path_list)
    return len(probs)


def main():
    ev = os.path.join(OUT, 'evidence')
    os.makedirs(ev, exist_ok=True)
    written = []
    ncards = 0
    # 1. 배치 표
    for f in sorted(glob.glob(os.path.join(LR, 'batch_*.tsv'))):
        b = os.path.basename(f)[:-4]
        rows = [l.rstrip('\n') for l in open(f, encoding='utf-8') if l.strip()]
        out = ['# %s — 카드별 추출 표 (%d 장)' % (b, len(rows)), '',
               '| ' + ' | '.join(COLS) + ' |', '|' + '---|' * len(COLS)]
        for r in rows:
            cells = r.split('\t')
            if len(cells) != len(COLS):
                report.append('COLS %s 칸 %d (기대 %d) slug=%s' % (b, len(cells), len(COLS), cells[0][:60]))
                cells = (cells + [''] * len(COLS))[:len(COLS) - 1] + [' ; '.join(cells[len(COLS) - 1:])]
            cells = [c.replace('|', '\\|').strip() for c in cells]
            out.append('| ' + ' | '.join(cells) + ' |')
            ncards += 1
        p = os.path.join(ev, b + '_cards.md')
        open(p, 'w', encoding='utf-8').write(strip_ticks('\n'.join(out) + '\n', b + '_cards.md'))
        written.append(p)
    # 2. 배치 근거 · 층 3
    src = sorted(glob.glob(os.path.join(LR, 'batch_*_findings.md')))
    l3 = os.path.join(LR, 'layer3_findings.md')
    if os.path.exists(l3):
        src.append(l3)
    for f in src:
        b = os.path.basename(f)
        p = os.path.join(ev, b)
        open(p, 'w', encoding='utf-8').write(strip_ticks(open(f, encoding='utf-8').read(), b))
        written.append(p)
    # 3. 카드 문제 기록
    qc = os.path.join(LR, 'synth', 'q_cards.md')
    if os.path.exists(qc):
        body = open(qc, encoding='utf-8').read().split('\n')
        counts = collections.OrderedDict()
        cur = None
        for line in body:
            m = re.match(r'^### \[([^\]]+)\]', line)
            if m:
                cur = m.group(1)
                counts.setdefault(cur, 0)
                continue
            if cur and re.match(r'^\s*(\d+\.|-)\s+\S', line) and not re.match(r'^\s*-\s*\(참고', line):
                if not re.match(r'^\s*(\d+\.|-)\s*(없음|카드 자체 문제 없음)', line):
                    counts[cur] += 1
        head = ['# 카드 문제 기록 (정독 중 본 것 · 고치지 않음)', '',
                '1저자 11-10 지시 "지금은 기록만 해" 대로 적어만 둔다. 카드 (litdb 정본 가지) 는 고치지 않았다.',
                '아래 개수는 배치 근거 파일의 "카드 문제" 절에서 목록 항목 (번호 · 줄표) 을 센 것이다 — "(참고 …)" 줄과 "없음" 줄은 뺐다. 어림이다 (항목 꼴이 배치마다 조금 다르다).',
                '', '| 배치 | 항목 수 |', '|---|---|']
        for k, v in counts.items():
            head.append('| %s | %d |' % (k, v))
        head += ['| 합 | %d |' % sum(counts.values()), '', '---', '']
        p = os.path.join(OUT, 'card_problems.md')
        open(p, 'w', encoding='utf-8').write(strip_ticks('\n'.join(head + body[1:]) + '\n', 'card_problems.md'))
        written.append(p)
        report.append('CARDS 배치 %d · 항목 합 %d' % (len(counts), sum(counts.values())))
    # 4. 질문 m 세 몫 합치기
    parts = [os.path.join(LR, 'synth', 'out', 'S6_%d_insights.md' % i) for i in (1, 2, 3)]
    if all(os.path.exists(x) for x in parts):
        order = []
        sect = collections.OrderedDict()
        for i, x in enumerate(parts, 1):
            cur = None
            for line in open(x, encoding='utf-8').read().split('\n'):
                m = re.match(r'^## +(.*)$', line)
                if m:
                    cur = re.sub(r'^\d+\.\s*', '', m.group(1).strip())
                    if cur not in sect:
                        sect[cur] = []
                        order.append(cur)
                    sect[cur].append('\n### 몫 %d\n' % i)
                    continue
                if cur is not None:
                    sect[cur].append(line)
        out = ['# 받아들일 통찰 (정독 종합 · 질문 m · 세 몫을 머리별로 합침)', '',
               '몫 1 = 배치 01–08 · 몫 2 = 09–19 · 몫 3 = 20–39 와 비교 문서. 항목 번호 머리글자 MA · MB · MC 가 몫이다. 글은 종합 조수의 출력 그대로다 (합치기만 했다).', '']
        for k in order:
            out.append('## ' + k)
            out += sect[k]
            out.append('')
        p = os.path.join(OUT, 'insights_merged.md')
        open(p, 'w', encoding='utf-8').write(strip_ticks('\n'.join(out) + '\n', 'insights_merged.md'))
        written.append(p)
        report.append('M_MERGE 머리 %d: %s' % (len(order), ' / '.join(order)))
    # 5. 종합 문서 (있는 것만)
    for x in sorted(glob.glob(os.path.join(LR, 'synth', 'out', 'S[1-58]_*.md'))):
        b = os.path.basename(x)
        p = os.path.join(OUT, b)
        open(p, 'w', encoding='utf-8').write(strip_ticks(open(x, encoding='utf-8').read(), b))
        written.append(p)
    left = ban_fix([w for w in written if w.endswith('.md')])
    report.append('FILES %d · 카드 줄 %d · 스윕 남은 문제 %d · 바이트 %d' % (
        len(written), ncards, left, sum(os.path.getsize(w) for w in written)))
    open(os.path.join(OUT, 'build_report.txt'), 'w', encoding='utf-8').write('\n'.join(report) + '\n')
    print('\n'.join(report))
    return 1 if left else 0


if __name__ == '__main__':
    sys.exit(main())

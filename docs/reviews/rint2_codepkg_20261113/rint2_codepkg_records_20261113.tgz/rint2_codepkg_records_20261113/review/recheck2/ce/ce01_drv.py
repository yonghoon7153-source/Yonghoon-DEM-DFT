#!/usr/bin/env python3
"""recheck2 RCP2-01 반례 드라이버 (새 프로세스 · 코드 사본 폴더 = sys.path 맨 앞) — T15 드라이버 꼴에 갈래를 더한다.
mode:
  honest        — 안 바꿈
  samesec       — cjunc_store 를 불러온 뒤 (런 시작) fsr 을 변이판으로 → fsr 불러옴 (변이판이 돈다) → 같은 초 안에 원판 내용으로 되돌려 씀 (수정 시각 =
                  지금 · 되돌리기 없음) → Store → get_or_build
  samesec_store — fsr 은 안 불러 둔 채, 런 시작 뒤 변이판으로 → Store (열쇠 코드 칸 = 변이판) → 같은 초 안에 원판으로 되돌려 씀 → get_or_build (짓기가
                  원판을 부른다)
  mtime_restore — 한정 (나) 꼴: 변이판으로 → fsr 불러옴 → 1.3 s 뒤 원판 내용 + 원래 수정 시각 (os.utime) 으로 되돌림 → Store → get_or_build
  samesize      — 런 시작 뒤 fsr 을 같은 크기 · 다른 내용 (주석 한 글자) 으로 → Store → get_or_build
  symlink       — 코드 사본의 fsr 이 심볼릭 링크 (원판 파일) · 런 시작 뒤 링크를 변이판 파일로 바꿈 → Store → get_or_build
  preloaded     — fsr 을 먼저 불러 둠 (원판) → 디스크를 변이판으로 → cjunc_store 불러옴 (런 시작 = 변이판) → Store → get_or_build (한정 (가) 꼴)
출력 = 'CE01 ' + JSON (상태 · 사유 · 짓기 수 · 원장 지문 · 따로 지은 원장 지문 · 열쇠 코드 칸 fsr · 시작 기록 · 걸린 시간)"""
import json
import os
import sys
import time

code_dir, scripts, store, mfile, inp_path, mode, mut_path = sys.argv[1:8]
sys.path.insert(0, scripts)
sys.path.insert(0, code_dir)
fsr = os.path.join(code_dir, 'fibre_segment_raster.py')
orig_bytes = open(fsr, 'rb').read()
orig_st = os.stat(fsr)
mut_bytes = open(mut_path, 'rb').read()


def write(b):
    os.unlink(fsr)
    with open(fsr, 'wb') as f:
        f.write(b)


if mode == 'preloaded':
    import fibre_segment_raster  # noqa: F401 — 원판을 먼저 불러 둔다
    write(mut_bytes)
import cjunc_store as CS  # 런 시작
t0 = CS._START['t_ns']
import numpy as np  # noqa: E402
import carbon_junction as CJ  # noqa: E402
import step3_sigma  # noqa: E402,F401
z = np.load(inp_path, allow_pickle=False)
inp = dict(sid=z['sid'], lo=tuple(float(x) for x in z['lo']), vox=float(z['vox']), pts=z['pts'], phase=z['phase'], fid=z['fid'],
           kind=z['kind'], thresholds=json.loads(str(z['thr'])))
note = {}
st = None
if mode == 'samesec':
    write(mut_bytes)
    import fibre_segment_raster  # noqa: F401,E402 — 변이판이 불린다
    write(orig_bytes)
    note['since_start_ms'] = (time.time_ns() - t0) / 1e6
elif mode == 'samesec_store':
    write(mut_bytes)
    st = CS.Store(store, machine_paths=(mfile,))
    write(orig_bytes)
    note['since_start_ms'] = (time.time_ns() - t0) / 1e6
elif mode == 'mtime_restore':
    write(mut_bytes)
    import fibre_segment_raster  # noqa: F401,E402
    time.sleep(1.3)
    write(orig_bytes)
    os.utime(fsr, ns=(orig_st.st_atime_ns, orig_st.st_mtime_ns))
    note['since_start_ms'] = (time.time_ns() - t0) / 1e6
elif mode == 'samesize':
    b = bytearray(orig_bytes)
    i = b.find(b'#')
    b[i + 1] = ord('X') if b[i + 1] != ord('X') else ord('Y')
    write(bytes(b))
    note['same_size'] = len(b) == len(orig_bytes)
elif mode == 'symlink':
    link_tgt = os.path.realpath(fsr)
    alt = os.path.join(os.path.dirname(mut_path), 'mut_fsr_for_link.py')
    with open(alt, 'wb') as f:
        f.write(mut_bytes)
    os.unlink(fsr)
    os.symlink(alt, fsr)
    note['was_link_to'] = os.path.basename(link_tgt)
if st is None:
    st = CS.Store(store, machine_paths=(mfile,))
n = [0]


def build():
    n[0] += 1
    return CJ.cjunc_registry(inp['sid'], inp['lo'], inp['vox'], inp['pts'], inp['phase'], inp['fid'], inp['kind'], **inp['thresholds'])


reg, out = st.get_or_build(build, **inp)
import fibre_segment_raster as _F  # noqa: E402
fresh = build()
n[0] -= 1
print('CE01 ' + json.dumps({'mode': mode, 'status': out['status'], 'why': (out.get('why') or '')[:160], 'builds': n[0],
                            'reg_fp': reg['fp']['registry'][:16], 'fresh_fp': fresh['fp']['registry'][:16],
                            'key': (out.get('key') or '')[:16], 'code_fsr': st.code.get('fibre_segment_raster.py', '')[:16],
                            'start_fsr': (CS._START.get('code') or {}).get('fibre_segment_raster.py', '')[:16],
                            'disk_fsr_now': __import__('hashlib').sha256(open(fsr, 'rb').read()).hexdigest()[:16],
                            'preloaded': CS._START.get('preloaded'), 'files': sorted(os.listdir(store)), 'note': note},
                           ensure_ascii=False))

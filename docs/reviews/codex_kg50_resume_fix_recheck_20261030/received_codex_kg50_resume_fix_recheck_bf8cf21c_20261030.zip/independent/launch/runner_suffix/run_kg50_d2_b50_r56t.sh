#!/bin/bash
#SBATCH --job-name=kg50_d2_b50_r56t
#SBATCH --output=logs/output_kg50_d2_b50_r56t_%j.out
#SBATCH -n 56
#SBATCH --time=01:00:00
cd /logical/review/root/kg50_d2_b50
mpirun --oversubscribe --bind-to none -np 56 lmp_mpi -in input_kg50_d2_b50_r56t.liggghts.bak

#!/usr/bin/env bash
# 회신 AP #12 — 계산 **전에** release attestation 을 만든다. POTCAR 원문은 담지 않는다.
set -e
: "${PP:?PP=/path/to/potpaw_PBE.54}"
: "${POTCAR_ALLOWLIST:?POTCAR_ALLOWLIST=/abs/site_allow.txt}"
: "${RELEASE_LABEL:?RELEASE_LABEL='potpaw_PBE.54' 처럼 배포판 이름}"
: "${SITE:?SITE='기관/담당자'}"
# ⛔ 회신 AR P0-6 — 봉인과 **같은 출처**의 ZIP 해시를 쓴다 (문자열 하나).
#   종전엔 스크립트가 근처 *.zip 을 스스로 찾아 {파일명: sha} 사전을 만들었다 —
#   무엇에 대한 attestation 인지 모호하고 분석기와 형이 달랐다.
: "${BUNDLE_ZIP_SHA256:?BUNDLE_ZIP_SHA256=\$(sha256sum <받은 zip> | cut -d' ' -f1)}"

# ⛔⛔ 회신 AT P0-6 (2026-08-31) — attestation 생성기도 **번들 전역 lock** 에
#   참여한다. 종전엔 러너만 잠갔고 이 스크립트는 그냥 들어와 같은 번들의 파일을
#   동시에 만질 수 있었다.
_LOCK=".lock_bundle"
_LOCK_MINE=""
if [ "${BUNDLE_LOCK_HELD:-0}" != "1" ]; then
  _RUNID="$(hostname)|$$|make_attestation|$(date -u +%Y-%m-%dT%H:%M:%SZ)"
  _T="$_LOCK.tmp.$$"
  printf '%s\n' "$_RUNID" > "$_T" || exit 3
  if ! ln "$_T" "$_LOCK" 2>/dev/null; then
    rm -f "$_T"
    echo "⛔ 이 번들에 다른 실행이 있습니다: $(cat "$_LOCK" 2>/dev/null)"
    exit 3
  fi
  rm -f "$_T"; _LOCK_MINE="$_RUNID"
fi
_unlock_self() { [ -n "$_LOCK_MINE" ] && [ "$(cat "$_LOCK" 2>/dev/null)" = "$_LOCK_MINE" ] \
                   && rm -f "$_LOCK"; return 0; }
_bail_self() { echo ""; echo "⛔ 신호($1) — 중단합니다."; trap - EXIT INT TERM
               kill -TERM 0 2>/dev/null || true; _unlock_self; exit "$2"; }
trap '_unlock_self' EXIT
trap '_bail_self INT 130' INT
trap '_bail_self TERM 143' TERM

# ⛔ 회신 AR P0-6 — `made_before_production` 을 **자기선언이 아니라 산출물 부재로**
#   입증한다. 하나라도 있으면 계산 전이 아니므로 거부한다.
PROD=$(find . \( -name OUTCAR -o -name "OUTCAR.gz" -o -name vasprun.xml \
                 -o -name OSZICAR -o -name CONTCAR -o -name WAVECAR \
                 -o -name CHGCAR \) -print -quit 2>/dev/null || true)
if [ -n "$PROD" ]; then
  echo "⛔ 생산 산출물이 이미 있습니다: $PROD"
  echo "   attestation 은 **첫 VASP 실행 전에만** 만들 수 있습니다 (회신 AR P0-6)."
  exit 1
fi
# ⛔ 회신 BA 해제조건 8 (2026-09-02) — **PATH 조회 폐기.** 봉인·러너는 이미 절대경로만
#   받는데 이 스크립트만 PATH 에서 `vasp_std` 를 찾고 있었다 (같은 우회가 여기 남았다).
: "${VASP_EXE:?VASP_EXE=/abs/path/to/vasp_std 를 주세요 (PATH 에서 찾지 않습니다)}"
case "$VASP_EXE" in /*) : ;; *) echo "⛔ VASP_EXE 는 절대경로여야 합니다: $VASP_EXE"; exit 2 ;; esac
[ -x "$VASP_EXE" ] || { echo "⛔ VASP_EXE 가 실행파일이 아닙니다: $VASP_EXE"; exit 2; }
VASP_BIN="$VASP_EXE"
export VASP_BIN BUNDLE_ZIP_SHA256
python3 - <<'PYA'
import json, os, hashlib, time, subprocess
man = json.load(open("MANIFEST.json"))
spec = man.get("potcar_spec") or {}
def sha(p):
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for b in iter(lambda: f.read(1 << 20), b""):
            h.update(b)
    return h.hexdigest()
pp = os.environ["PP"]
variants = {}
for el, var in sorted(spec.items()):
    f = os.path.join(pp, var, "POTCAR")
    if not os.path.isfile(f):
        raise SystemExit("원본 POTCAR 가 없다: %s" % f)
    titel, emb = [], []
    for ln in open(f, errors="replace"):
        t = ln.strip()
        if t.startswith("TITEL"):
            titel.append(t)
        if "SHA256" in t or t.startswith("COPYR") and "hash" in t.lower():
            emb.append(t)
        if len(titel) and ln.startswith("   END of PSCTR"):
            break
    # ⛔ 회신 AR P0-6 — 분석기가 관측 TITEL 과 대조하므로 **문자열 하나**로 낸다
    variants[var] = {"element": el, "source_sha256": sha(f),
                     "titel": (titel[0] if titel else ""),
                     "titel_all": titel[:2],
                     "embedded_hash": (emb[0] if emb else ""),
                     "embedded_hash_lines": emb[:2]}
    if not titel:
        raise SystemExit("TITEL 을 못 읽었다: %s" % f)
vb = os.environ["VASP_BIN"]
try:
    ver = subprocess.run([vb, "--version"], capture_output=True, text=True,
                         timeout=60).stdout.strip()
except Exception as e:
    ver = "실행 실패: %r" % e
rec = {
    "schema": "potcar_attestation/v1",
    "made_before_production": True,
    "made_before_production_evidence":
        "attestation 생성 시점에 OUTCAR/OUTCAR.gz/vasprun.xml/OSZICAR/CONTCAR/"
        "WAVECAR/CHGCAR 가 하나도 없었다 (MAKE_POTCAR_ATTESTATION.sh 가 검사하고 "
        "있으면 거부한다 — 회신 AR P0-6)",
    "release_label": os.environ["RELEASE_LABEL"],
    "site": os.environ["SITE"],
    "created_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
    "manifest_sha256": sha("MANIFEST.json"),
    "bundle_zip_sha256": os.environ["BUNDLE_ZIP_SHA256"].strip().lower(),
    "allowlist_path": os.environ["POTCAR_ALLOWLIST"],
    "allowlist_sha256": sha(os.environ["POTCAR_ALLOWLIST"]),
    "pp_root": pp,
    "variants": variants,
    "vasp_executable": vb,
    "vasp_executable_sha256": sha(vb),
    "vasp_version_raw": ver,
}
json.dump(rec, open("POTCAR_ATTESTATION.json", "w"), indent=1, ensure_ascii=False)
print("→ POTCAR_ATTESTATION.json (variant %d · release %s)"
      % (len(variants), rec["release_label"]))
PYA

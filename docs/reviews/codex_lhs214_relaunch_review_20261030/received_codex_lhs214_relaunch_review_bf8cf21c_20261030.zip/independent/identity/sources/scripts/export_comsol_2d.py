"""
export_comsol_2d.py — Phase D4.

3D DEM case → COMSOL 2D FEM 입력을 두 갈래로 분리 export:

  (1) 수치적 입력 (numerical) — COMSOL Global Parameters / Material로 직접
      타이핑할 3D-측정 유효 물성 스칼라:
        σ_ionic, σ_e, κ, τ_Laplace_eff, τ_Dijkstra, φ_SE, coverage,
        specific surface area, ASR, σ_grain(bulk) ...
      → parameters.csv  +  parameters.json

  (2) Geometry 입력 (geometric) — 2D microstructure 형상 (phase 경계):
        DXF (LWPOLYLINE, layer = phase) + SVG preview
      → geometry.dxf  +  geometry.svg  +  microstructure.npy

철학:
  • 형상(domain)은 geometry로, 물성은 수치로 — COMSOL 표준 workflow.
  • 2D-FEM이 3D 결과를 재현하려면, geometry는 2D인데 물성(τ, σ)은
    3D-network-solver에서 측정한 값을 그대로 입력 → 차원 보정이 물성에
    내포됨 (2D 단면 + 3D 유효 τ).

CLI:
  python3 scripts/export_comsol_2d.py input_6mAh_real_4
  python3 scripts/export_comsol_2d.py input_6mAh_real_4 --axis y --n-pixels 600
"""
from __future__ import annotations
import argparse
import csv
import json
import sys
from pathlib import Path

import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from scipy import ndimage as _ndi

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / 'scripts'))
from extract_2d_microstructure import (   # noqa: E402
    slice_microstructure, synthesize_microstructure,
    render_png as render_microstructure_png,
    render_geometry_png,
    VOID, AM_P, AM_S, SE, PHASE_NAMES,
)

import se_material as _se_material   # noqa: E402 — σ₀ = 그 런의 짝 σ₀ (sigma_grain_context · TAU-03)
import tau_flux as _tau_flux         # noqa: E402 — τ 소비처 공용 도우미 (웹앱 τ 블록 · 등급 τ 축과 같은 식)

SIGMA_GRAIN_MS = _se_material.SIGMA_GRAIN_MS_CM_25C   # 25 °C σ₀ (펠릿값 3.0 · CL-91) — 행 값은 그 런의 짝 σ₀ (sigma_grain_context)


def _fnum(d, *keys):
    for k in keys:
        v = d.get(k)
        if v is not None:
            try:
                return float(v)
            except (TypeError, ValueError):
                continue
    return None


def numerical_parameters(case_dir: Path, slice_data: dict) -> list[dict]:
    """Pull 3D-measured effective properties for COMSOL parameter input."""
    case_id = case_dir.name
    fm_file = ROOT / 'webapp' / 'results' / case_id / 'full_metrics.json'
    fm = json.loads(fm_file.read_text()) if fm_file.exists() else {}

    phi_se   = _fnum(fm, 'phi_se')
    # ★ TAU-03 (1저자 비준 10-04 밤 *"권고대로"*) — τ · f 는 **원 솔버 σ** 로 · **두 면적 모드 다** (고르지 않는다 · 결정 3) ·
    #   σ₀ = 그 런의 짝 σ₀ (`se_material.sigma_grain_context` — 웹앱 τ 블록 · 등급 τ 축과 같은 도우미 `tau_flux`).
    #   Stage-E σ (Cronau(r_SE) · 파괴 같은 재료 인자 포함) 는 τ 이름 없이 따로 싣는다 — f · tau2 와 짝이 아니다 (결정 6).
    #   옛 판: σ_i · tau2 · f_ion 이 전부 Stage-E physics σ (stage_e_physics → physics → raw) + σ₀ 3.0 고정.
    sigma0 = _se_material.sigma_grain_context(fm)[0]
    by_mode = {}
    for mode in ('hertz', 'physics'):
        sig_m = _fnum(fm, _tau_flux.METRIC_SIGMA_KEY[mode])
        t2, _s0 = _tau_flux.tau2_from_metrics(fm, mode)
        by_mode[mode] = {
            'sigma': sig_m if (sig_m and sig_m > 0) else None,
            'f': (sig_m / sigma0) if (sig_m and sig_m > 0) else None,
            'tau2': t2,
            'tau': (t2 ** 0.5) if t2 is not None else None,
        }
    sig_stage_e = _fnum(fm, 'sigma_full_mScm_stage_e_physics')
    t2_bulk, _s0 = _tau_flux.tau2_from_metrics(fm, 'bulk')
    tau_lap_bulk = (t2_bulk ** 0.5) if t2_bulk is not None else None

    fr = slice_data['phase_fracs']

    # ASR_ionic — full_metrics에 저장 안 됨 (on-the-fly).  L × 0.1 / σ_ionic.
    L_um = _fnum(fm, 'thickness_um')
    asr_ionic = None
    sig_asr = _fnum(fm, 'sigma_full_mScm_stage_e_physics', 'sigma_full_mScm_physics', 'sigma_full_mScm')   # τ 아님 — 옛 선택 그대로
    if L_um and sig_asr and sig_asr > 0:
        asr_ionic = L_um * 0.1 / sig_asr   # Ω·cm²

    rows = [
        # name, value, unit, COMSOL parameter suggestion, source
        ('phi_SE',         phi_se,                                   '1',
         'phiSE', '3D SE volume fraction (ρ-weighted)'),
        ('phi_void',       _fnum(fm, 'porosity') and _fnum(fm, 'porosity')/100,
         '1', 'eps', '3D porosity (full_metrics)'),
        ('sigma_grain',    sigma0,                                   'mS/cm',
         'sigma_grain', 'σ₀ = 그 런의 짝 σ₀ (25 °C = 펠릿값 3.0 · CL-91 · 온도 런이면 배수) — tau2 · f 의 기준 · 입력 시 σ₀ 칸과 짝'),
        ('sigma_ionic_hertz', by_mode['hertz']['sigma'],              'mS/cm',
         'sigma_i_hertz', '원 솔버 σ_ionic · Hertz 면적 (교차 원판 c_cpl[22]) — f_ion_hertz · tau2_ion_hertz 의 짝'),
        ('sigma_ionic_physics', by_mode['physics']['sigma'],          'mS/cm',
         'sigma_i_physics', '원 솔버 σ_ionic · physics 면적 (접촉별 상한 · LHS-25) — f_ion_physics · tau2_ion_physics 의 짝'),
        ('sigma_ionic_stage_e', sig_stage_e,                          'mS/cm',
         'sigma_i_stageE', 'Stage-E physics σ — 재료 인자 포함 (Cronau(r_SE) · 파괴) · τ 이름 없음 · f_ion · tau2 와 짝이 아니다'),
        ('sigma_e_eff',    _fnum(fm, 'electronic_sigma_full_mScm_stage_e_physics',
                                  'electronic_sigma_full_mScm_physics'), 'mS/cm',
         'sigma_e', '3D effective electronic σ'),
        ('kappa_eff',      _fnum(fm, 'thermal_sigma_full_mScm_stage_e_physics',
                                  'thermal_sigma_full_mScm_physics'), 'mS/cm-eq',
         'kappa', '3D effective thermal conductivity'),
        ('f_ion_hertz',     by_mode['hertz']['f'],                    '1',
         'f_ion_hertz', '★ f = σ_i_hertz/σ_grain = φ/tau2 — Porous Electrode 보정을 User defined 로 두고 fl 칸에 넣는 꼴 (COMSOL 앱 예제 '
                        'Homogenizing a Heterogeneous Electrode Model 6.4 와 같은 방식 · τ 관례 무관) · 같은 틀 L_cat · phiSE · Hertz 면적'),
        ('f_ion_physics',   by_mode['physics']['f'],                  '1',
         'f_ion_physics', '★ f = σ_i_physics/σ_grain = φ/tau2 — User defined (fl) 칸 · physics 면적 (접촉별 상한 · LHS-25)'),
        ('tau2_ion_hertz',  by_mode['hertz']['tau2'],                 '1',
         'tau2_ion_hertz', '★ 수송 tortuosity T (tortuosity factor · 제곱근 아님 · v1.3 표시 이름) = φ·σ_grain/σ_i_hertz (COMSOL 종 수송 τ_F 꼴 · '
                           '배터리 노드는 GUI Equation 확인 뒤 · σ₀ 칸 = sigma_grain)'),
        ('tau2_ion_physics', by_mode['physics']['tau2'],              '1',
         'tau2_ion_physics', '★ 수송 tortuosity T (tortuosity factor · 제곱근 아님) = φ·σ_grain/σ_i_physics (physics 면적 · 같은 주의)'),
        ('tau_ion_hertz',   by_mode['hertz']['tau'],                  '1',
         '—', '√tau2 (τ² 관례의 τ · Hertz) — 입력 칸 값 아님 (tau2 행을 쓴다)'),
        ('tau_ion_physics', by_mode['physics']['tau'],                '1',
         '—', '√tau2 (τ² 관례의 τ · physics) — 입력 칸 값 아님'),
        ('tau_Laplace_bulk', tau_lap_bulk,                           '1',
         'tau_bulk', '3D geometric tortuosity (no constriction · CF 원기둥 bulk · 짝 σ₀)'),
        ('tau_Dijkstra',   _fnum(fm, 'tortuosity_recommended', 'tortuosity_mean'),
         '1', 'tau_geo', '3D geodesic tortuosity'),
        ('coverage_AM',    _fnum(fm, 'coverage_AM_mean_physics_rough',
                                  'coverage_AM_mean_physics'),        '%',
         'cov_AM', '★ 3D AM-SE coverage (Tabor shape-corrected)'),
        ('A_AM_SE_total',  _fnum(fm, 'area_AM_P_SE_total') or 0,      'um2',
         'A_AMSE', '3D total AM-SE interfacial area'),
        ('ASR_ionic',      asr_ionic,                                 'Ohm*cm2',
         'ASR_i', '3D cell-level ASR = L_cat × 0.1 / σ_ionic (Ohm slab)'),
        ('thickness',      _fnum(fm, 'thickness_um'),                 'um',
         'L_cat', 'cathode thickness (z extent)'),
        ('SE_SE_cn',       _fnum(fm, 'se_se_cn'),                     '1',
         'z_SESE', 'SE-SE coordination number'),
        ('percolation',    _fnum(fm, 'percolation_pct'),             '%',
         'perc', '3D SE percolation top↔bottom'),
        # 2D-slice geometry stats (for reference / sanity vs 3D)
        ('phi_SE_2Dslice',  fr['SE']/100,                            '1',
         '—', '2D slice SE area fraction (NOT for input — compare vs phi_SE)'),
        ('phi_void_2Dslice', fr['void']/100,                         '1',
         '—', '2D slice void area fraction'),
        ('coverage_2Dslice', slice_data['coverage_2d_pct'],          '%',
         '—', '2D figure AM-SE coverage (pinned to 3D coverage_AM)'),
        ('coverage_2Dslice_inplane', slice_data.get('coverage_2d_inplane_pct'), '%',
         '—', '2D raw in-plane coverage (pre-calibration; underestimates 3D)'),
        ('r_AM_P_D50',     slice_data.get('r_AM_P_d50_um'),          'um',
         'r_AMP', 'AM_P characteristic radius (analysis-summary D50)'),
        ('r_AM_S_D50',     slice_data.get('r_AM_S_d50_um'),          'um',
         'r_AMS', 'AM_S characteristic radius (analysis-summary D50)'),
    ]
    out = []
    for name, val, unit, comsol, src in rows:
        out.append({
            'parameter': name,
            'value': (round(val, 6) if isinstance(val, (int, float)) else ''),
            'unit': unit,
            'comsol_name': comsol,
            'source': src,
        })
    return out


def _clean_mask(mask: np.ndarray, min_area_px: int,
                fill_holes: bool = False) -> np.ndarray:
    """Drop connected components smaller than min_area_px (unmeshable specks
    that break a COMSOL import) and optionally fill small interior holes.

    fill_holes=True → solid domains (AM particles).
    fill_holes=False → keep interior pores (SE matrix porosity).
    """
    lbl, n = _ndi.label(mask)
    if n == 0:
        return mask
    sizes = np.bincount(lbl.ravel()); sizes[0] = 0
    out = (sizes >= min_area_px)[lbl]
    if fill_holes:
        out = _ndi.binary_fill_holes(out)
    return out


def _rdp(pts: np.ndarray, eps: float) -> np.ndarray:
    """Ramer–Douglas–Peucker polyline simplification (iterative, no recursion
    limit).  Removes the dense voxel-staircase vertices COMSOL chokes on."""
    n = len(pts)
    if n < 3:
        return pts
    keep = np.zeros(n, dtype=bool); keep[0] = keep[-1] = True
    stack = [(0, n - 1)]
    while stack:
        i0, i1 = stack.pop()
        if i1 <= i0 + 1:
            continue
        a = pts[i0]; ab = pts[i1] - a
        L2 = float(ab[0] ** 2 + ab[1] ** 2)
        seg = pts[i0 + 1:i1] - a
        if L2 == 0.0:
            d = np.hypot(seg[:, 0], seg[:, 1])
        else:
            t = (seg[:, 0] * ab[0] + seg[:, 1] * ab[1]) / L2
            d = np.hypot(seg[:, 0] - t * ab[0], seg[:, 1] - t * ab[1])
        if d.size == 0:
            continue
        k = int(np.argmax(d))
        if d[k] > eps:
            idx = i0 + 1 + k
            keep[idx] = True
            stack.append((i0, idx)); stack.append((idx, i1))
    return pts[keep]


def _chaikin(pts: np.ndarray, iters: int, closed: bool) -> np.ndarray:
    """Chaikin corner-cutting → smooth, rounded polyline (smears voxel steps)."""
    p = pts
    for _ in range(iters):
        if closed:
            a = p; b = np.roll(p, -1, axis=0)
        else:
            a = p[:-1]; b = p[1:]
        q = a + 0.25 * (b - a)
        r = a + 0.75 * (b - a)
        new = np.empty((len(q) + len(r), 2))
        new[0::2] = q; new[1::2] = r
        p = new if closed else np.vstack([pts[0], new, pts[-1]])
    return p


def _contours(mask: np.ndarray, pa: float, pb: float, b0: float,
              smooth: bool = True, min_area_px: int = 15,
              fill_holes: bool = False):
    """Extract SMOOTH iso-0.5 contours of a boolean mask as Nx2 arrays in μm.

    Voxel staircases are smeared into clean curves so the result is usable as
    a COMSOL geometry boundary: (1) prune unmeshable specks, (2) Gaussian
    sub-pixel iso-contour, (3) RDP vertex reduction, (4) Chaikin rounding.
    """
    m = _clean_mask(mask, min_area_px, fill_holes=fill_holes)
    if m.sum() == 0:
        return []
    work = _ndi.gaussian_filter(m.astype(float), sigma=1.0) if smooth \
        else m.astype(float)
    fig = plt.figure(); ax = fig.add_subplot(111)
    cs = ax.contour(work, levels=[0.5])
    segs = []
    allsegs = getattr(cs, 'allsegs', None)
    if allsegs:
        for level_segs in allsegs:
            for seg in level_segs:
                if len(seg) < 4:
                    continue
                xy = np.asarray(seg, dtype=float)
                closed = bool(np.allclose(xy[0], xy[-1]))
                if smooth:
                    xy = _rdp(xy, eps=0.6)
                    if len(xy) >= 4:
                        xy = _chaikin(xy, iters=2, closed=closed)
                xs = xy[:, 0] * pa
                ys = xy[:, 1] * pb + b0
                segs.append(np.column_stack([xs, ys]))
    plt.close(fig)
    return segs


def _classify_am_interface(labels, interface, pa, pb, b0):
    """Split AM particle outlines into SE-covered vs uncovered arc segments.

    Returns {'AM_SE_interface': [Nx2 …], 'AM_inactive': [Nx2 …]} as μm
    line-segment polylines.  COMSOL은 covered arc에만 Li+ flux BC를 줄 수
    있음 (active interface), uncovered는 insulated.

    Method: AM mask contour를 추출하고, 각 segment 중점의 interface label
    (1=covered / 2=uncovered)로 분류 → 같은 class 연속 segment를 묶음.
    """
    is_am = (labels == AM_P) | (labels == AM_S)
    am_contours = _contours(is_am, pa, pb, b0)
    covered_segs, inactive_segs = [], []

    ny, nx = labels.shape
    for cont in am_contours:
        # cont vertices in μm; convert back to pixel idx to read interface
        cur_class = None
        run = []
        for k in range(len(cont)):
            x_um, y_um = cont[k]
            ix = int(np.clip((x_um / pa), 0, nx - 1))
            iy = int(np.clip((y_um - b0) / pb, 0, ny - 1))
            lab = interface[iy, ix]
            # nearest interface class: search small window if 0
            if lab == 0:
                y0, y1 = max(0, iy-1), min(ny, iy+2)
                x0, x1 = max(0, ix-1), min(nx, ix+2)
                win = interface[y0:y1, x0:x1]
                nz = win[win > 0]
                lab = int(nz[0]) if nz.size else 1   # default covered
            cls = 'cov' if lab == 1 else 'inact'
            if cls != cur_class and run:
                (covered_segs if cur_class == 'cov' else inactive_segs).append(
                    np.array(run))
                run = [run[-1]] if run else []
            run.append((x_um, y_um))
            cur_class = cls
        if run and len(run) >= 2:
            (covered_segs if cur_class == 'cov' else inactive_segs).append(
                np.array(run))
    return {'AM_SE_interface': covered_segs, 'AM_inactive': inactive_segs}


def write_dxf(phase_contours: dict, interface_segs: dict, out_path: Path):
    """Write minimal ASCII DXF R12 with POLYLINE per contour, layered by
    phase + AM-SE interface (covered) + AM-inactive (uncovered).
    Hand-written (no ezdxf dependency)."""
    lines = []
    def w(code, val): lines.append(str(code)); lines.append(str(val))

    w(0, 'SECTION'); w(2, 'HEADER'); w(0, 'ENDSEC')
    w(0, 'SECTION'); w(2, 'TABLES'); w(0, 'TABLE'); w(2, 'LAYER')
    layer_color = {'AM_P': 1, 'AM_S': 3, 'SE': 2, 'void': 8,
                   'AM_SE_interface': 3, 'AM_inactive': 1}  # green / red
    for ph, color in layer_color.items():
        w(0, 'LAYER'); w(2, ph); w(70, 0); w(62, color); w(6, 'CONTINUOUS')
    w(0, 'ENDTAB'); w(0, 'ENDSEC')

    w(0, 'SECTION'); w(2, 'ENTITIES')
    # closed phase boundaries
    for ph, contours in phase_contours.items():
        for seg in contours:
            w(0, 'POLYLINE'); w(8, ph); w(66, 1); w(70, 1)   # closed
            for (x, y) in seg:
                w(0, 'VERTEX'); w(8, ph)
                w(10, f'{x:.4f}'); w(20, f'{y:.4f}'); w(30, '0.0')
            w(0, 'SEQEND')
    # open interface arcs (covered / inactive)
    for layer, segs in interface_segs.items():
        for seg in segs:
            if len(seg) < 2:
                continue
            w(0, 'POLYLINE'); w(8, layer); w(66, 1); w(70, 0)  # open
            for (x, y) in seg:
                w(0, 'VERTEX'); w(8, layer)
                w(10, f'{x:.4f}'); w(20, f'{y:.4f}'); w(30, '0.0')
            w(0, 'SEQEND')
    w(0, 'ENDSEC'); w(0, 'EOF')
    out_path.write_text('\n'.join(lines))


def write_svg(phase_contours: dict, interface_segs: dict,
              a_ext, b_ext, b0, out_path: Path):
    fill = {'AM_P': '#1a1a2e', 'AM_S': '#8d99ae', 'SE': '#f4d35e', 'void': 'none'}
    W, H = 800, max(1, int(800 * b_ext / a_ext))
    sx, sy = W / a_ext, H / b_ext
    parts = [f'<svg xmlns="http://www.w3.org/2000/svg" width="{W}" height="{H}" '
             f'viewBox="0 0 {W} {H}">',
             f'<rect width="{W}" height="{H}" fill="white"/>']
    # filled phase polygons
    for ph, contours in phase_contours.items():
        if ph == 'void':
            continue
        for seg in contours:
            pts = ' '.join(f'{x*sx:.2f},{H-(y-b0)*sy:.2f}' for (x, y) in seg)
            parts.append(f'<polygon points="{pts}" fill="{fill[ph]}" '
                         f'stroke="none" fill-opacity="0.85"/>')
    # interface arcs over the top: covered green, inactive red
    arc_color = {'AM_SE_interface': '#10b981', 'AM_inactive': '#ef4444'}
    for layer, segs in interface_segs.items():
        for seg in segs:
            if len(seg) < 2:
                continue
            pts = ' '.join(f'{x*sx:.2f},{H-(y-b0)*sy:.2f}' for (x, y) in seg)
            parts.append(f'<polyline points="{pts}" fill="none" '
                         f'stroke="{arc_color[layer]}" stroke-width="2"/>')
    parts.append('</svg>')
    out_path.write_text('\n'.join(parts))


def _contour_crop(mask, pa, pb, b0, ox, oy, sigma=0.8):
    """Smooth iso-0.5 contour of a small cropped mask, returned in μm with the
    crop offset (ox, oy) in pixels applied."""
    work = _ndi.gaussian_filter(mask.astype(float), sigma=sigma)
    fig = plt.figure(); ax = fig.add_subplot(111)
    cs = ax.contour(work, levels=[0.5])
    out = []
    for ls in getattr(cs, 'allsegs', []) or []:
        for seg in ls:
            if len(seg) < 4:
                continue
            xy = np.asarray(seg, float)
            closed = bool(np.allclose(xy[0], xy[-1]))
            xy = _rdp(xy, eps=0.5)
            if len(xy) >= 4:
                xy = _chaikin(xy, iters=1, closed=closed)
            xs = (xy[:, 0] + ox) * pa
            ys = (xy[:, 1] + oy) * pb + b0
            out.append(np.column_stack([xs, ys]))
    plt.close(fig)
    return out


def _grain_polys(am_p_mask, grain_px, pa, pb, b0, seed=0):
    """Split each AM_P particle into grains.  If shapely is available, use exact
    shared-edge Voronoi cells clipped to the particle (no gaps/overlaps — the
    natural, clean tiling); otherwise fall back to the raster-dilation method."""
    try:
        from shapely.geometry import Polygon, MultiPoint, Point
        from shapely.ops import voronoi_diagram
    except Exception:
        return _grain_polys_dilate(am_p_mask, grain_px, pa, pb, b0, seed)

    lab, nlab = _ndi.label(am_p_mask)
    rng = np.random.default_rng(seed)
    step = max(4.0, float(grain_px))
    polys = []
    for pid in range(1, nlab + 1):
        ys, xs = np.where(lab == pid)
        if len(ys) < 30:
            continue
        y0, y1, x0, x1 = ys.min(), ys.max() + 1, xs.min(), xs.max() + 1
        sub = (lab[y0:y1, x0:x1] == pid)
        sh, sw = sub.shape
        # pad so the particle never touches the crop edge (else matplotlib
        # contour breaks the rim into open arcs and the outline polygon is wrong)
        pad = 3
        subp = np.zeros((sh + 2 * pad, sw + 2 * pad), dtype=bool)
        subp[pad:pad + sh, pad:pad + sw] = sub
        outline = _contour_crop(subp, pa, pb, b0, x0 - pad, y0 - pad)  # closed rim
        if not outline:
            continue
        try:
            ppoly = Polygon(max(outline, key=len))
            if not ppoly.is_valid:
                ppoly = ppoly.buffer(0)
        except Exception:
            ppoly = None
        if ppoly is None or ppoly.is_empty or ppoly.area <= 0:
            continue
        seeds = []
        for yy in np.arange(step / 2, sh, step):
            for xx in np.arange(step / 2, sw, step):
                jx = (x0 + xx + rng.uniform(-step * .35, step * .35)) * pa
                jy = (y0 + yy + rng.uniform(-step * .35, step * .35)) * pb + b0
                if ppoly.contains(Point(jx, jy)):
                    seeds.append((jx, jy))
        if len(seeds) < 2:                                   # whole particle = 1 grain
            polys.append(np.asarray(ppoly.exterior.coords))
            continue
        try:
            vd = voronoi_diagram(MultiPoint(seeds), envelope=ppoly)
        except Exception:
            polys.append(np.asarray(ppoly.exterior.coords))
            continue
        for cell in vd.geoms:                                # Voronoi cells share ridges
            inter = cell.intersection(ppoly)
            if inter.is_empty:
                continue
            parts = inter.geoms if inter.geom_type == 'MultiPolygon' else [inter]
            for poly in parts:
                if getattr(poly, 'geom_type', '') == 'Polygon' and poly.area > 0:
                    polys.append(np.asarray(poly.exterior.coords))
    return polys


def _grain_polys_dilate(am_p_mask, grain_px, pa, pb, b0, seed=0):
    """Fallback (no shapely): raster Voronoi labels, each grain dilated 1 px and
    clipped to the particle so neighbours overlap slightly (no inter-grain gaps;
    COMSOL Form Union merges the overlaps)."""
    from scipy.spatial import cKDTree
    lab, nlab = _ndi.label(am_p_mask)
    rng = np.random.default_rng(seed)
    step = max(4.0, float(grain_px))
    polys = []
    for pid in range(1, nlab + 1):
        ys, xs = np.where(lab == pid)
        if len(ys) < 30:
            continue
        y0, y1, x0, x1 = ys.min(), ys.max() + 1, xs.min(), xs.max() + 1
        sub = (lab[y0:y1, x0:x1] == pid)
        sh, sw = sub.shape
        seeds = [(yy + rng.uniform(-step * .35, step * .35),
                  xx + rng.uniform(-step * .35, step * .35))
                 for yy in np.arange(step / 2, sh, step)
                 for xx in np.arange(step / 2, sw, step)]
        if len(seeds) < 2:
            polys += _contour_crop(sub, pa, pb, b0, x0, y0)
            continue
        tree = cKDTree(np.array(seeds))
        yy, xx = np.mgrid[0:sh, 0:sw]
        gid = tree.query(np.column_stack([yy.ravel(), xx.ravel()]))[1].reshape(sh, sw) + 1
        gid[~sub] = 0
        for g in np.unique(gid):
            if g == 0:
                continue
            gm = gid == g
            if gm.sum() < 6:
                continue
            gm = _ndi.binary_dilation(gm, iterations=1) & sub
            polys += _contour_crop(gm, pa, pb, b0, x0, y0)
    return polys


def write_dxf_layers(layers: dict, out_path: Path, colors: dict = None,
                     open_layers=()):
    """Write POLYLINEs grouped by layer.  Layers in `open_layers` are written
    as OPEN polylines (interface arcs); the rest are closed (domains)."""
    colors = colors or {'domain': 7, 'AM_P_grain': 1, 'AM_S': 3, 'void': 8,
                        'AM_SE_interface': 3, 'AM_inactive': 1}
    open_layers = set(open_layers)
    lines = []
    def w(c, v): lines.append(str(c)); lines.append(str(v))
    w(0, 'SECTION'); w(2, 'HEADER'); w(0, 'ENDSEC')
    w(0, 'SECTION'); w(2, 'TABLES'); w(0, 'TABLE'); w(2, 'LAYER')
    for name in layers:
        w(0, 'LAYER'); w(2, name); w(70, 0); w(62, colors.get(name, 7)); w(6, 'CONTINUOUS')
    w(0, 'ENDTAB'); w(0, 'ENDSEC')
    w(0, 'SECTION'); w(2, 'ENTITIES')
    for name, contours in layers.items():
        closed_flag = 0 if name in open_layers else 1
        for seg in contours:
            if len(seg) < 2:
                continue
            w(0, 'POLYLINE'); w(8, name); w(66, 1); w(70, closed_flag)
            for (x, y) in seg:
                w(0, 'VERTEX'); w(8, name)
                w(10, f'{x:.4f}'); w(20, f'{y:.4f}'); w(30, '0.0')
            w(0, 'SEQEND')
    w(0, 'ENDSEC'); w(0, 'EOF')
    Path(out_path).write_text('\n'.join(lines))


def write_comsol_geometry(sd, out_dir, grain_um=2.0, min_void_um=0.4, seed=0):
    """COMSOL geometry DXF — CLOSED faces only so COMSOL Form Union makes
    selectable domains: domain rectangle + AM_P split into grain domains +
    AM_S particles + void pores (small ones around AM kept).  SE is the
    left-over face.  Active vs inactive AM boundary is read from adjacency:
    AM∩SE = active (reaction), AM∩void = inactive (no-flux).  (No open
    interface-arc curves — they prevented face partitioning in COMSOL.)"""
    labels = sd['labels']
    pa, pb, b0 = sd['pa_um'], sd['pb_um'], sd['b_origin']
    a_ext, b_ext = sd['a_extent'], sd['b_extent']
    min_area_px = max(8, int((sd['n_pixels'] / 150) ** 2))
    void_min = max(6, int(np.pi * (min_void_um / pa / 2.0) ** 2))
    layers = {
        'domain': [np.array([[0, b0], [a_ext, b0], [a_ext, b0 + b_ext],
                             [0, b0 + b_ext], [0, b0]])],
        'AM_P_grain': _grain_polys(labels == AM_P, grain_um / pa, pa, pb, b0, seed),
        'AM_S': _contours(labels == AM_S, pa, pb, b0,
                          min_area_px=min_area_px, fill_holes=True),
        'void': _contours(labels == VOID, pa, pb, b0,
                          min_area_px=void_min, fill_holes=False),
    }
    write_dxf_layers(layers, Path(out_dir) / 'geometry_comsol.dxf')
    return {'n_grains': len(layers['AM_P_grain']), 'n_AMS': len(layers['AM_S']),
            'n_void': len(layers['void'])}


def write_comsol_package(case_name, case_dir, sd, out_dir, axis='synth',
                         slice_frac=0.0, no_continuum=False):
    """Write the full COMSOL-import package for a synthesized/sliced
    microstructure: geometry.dxf (+svg/png), parameters.csv/json (3D effective
    materials), coverage-as-boundary layers, microstructure.npy and a README
    with COMSOL import steps.  Used by the CLI and the webapp ZIP route."""
    out_dir = Path(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    # ── (1) Numerical parameters ──────────────────────────────────────
    params = numerical_parameters(case_dir, sd)
    with open(out_dir / 'parameters.csv', 'w', newline='') as f:
        w = csv.DictWriter(f, fieldnames=['parameter', 'value', 'unit',
                                          'comsol_name', 'source'])
        w.writeheader(); w.writerows(params)
    (out_dir / 'parameters.json').write_text(
        json.dumps({p['parameter']: p for p in params}, indent=2))

    # COMSOL-ready parameter table: Name, Expression(value+unit), Description.
    # COMSOL's "Load from File" expects exactly these 3 columns and NO header
    # (a header row imports as a junk parameter).  Units are attached only when
    # COMSOL recognises them; everything else is left dimensionless.
    _U = {'mS/cm': '[mS/cm]', 'S/m': '[S/m]', 'um': '[um]', 'µm': '[um]',
          'm': '[m]', 'Ohm*cm2': '[ohm*cm^2]', 'ohm*cm2': '[ohm*cm^2]',
          'Ohm*cm^2': '[ohm*cm^2]'}
    _seen = set()
    with open(out_dir / 'parameters_comsol.csv', 'w', newline='') as f:
        w = csv.writer(f)
        for p in params:
            name = (p.get('comsol_name') or p.get('parameter') or '').strip()
            if not name or name in ('—', '-') or name in _seen:
                continue
            val = p.get('value')
            if val is None or val == '':
                continue
            _seen.add(name)
            unit = (p.get('unit') or '1').strip()
            expr = f"{val}{_U.get(unit, '')}"          # bracket-unit if recognised
            desc = (p.get('source') or '').replace('\n', ' ').replace(',', ';')
            w.writerow([name, expr, desc])

    # ── (2) Geometry — smooth phase contours (COMSOL-meshable) ─────────
    labels = sd['labels']
    pa, pb, b0 = sd['pa_um'], sd['pb_um'], sd['b_origin']
    min_area_px = max(12, int((sd['n_pixels'] / 110) ** 2))
    phase_contours = {}
    for ph_id, ph_name, fill in [(AM_P, 'AM_P', True), (AM_S, 'AM_S', True),
                                 (SE, 'SE', False), (VOID, 'void', False)]:
        mask = (labels == ph_id)
        if mask.sum() == 0:
            continue
        phase_contours[ph_name] = _contours(mask, pa, pb, b0,
                                            min_area_px=min_area_px,
                                            fill_holes=fill)
    n_seg = sum(len(v) for v in phase_contours.values())
    interface_segs = _classify_am_interface(labels, sd['interface'], pa, pb, b0)
    n_cov = len(interface_segs['AM_SE_interface'])
    n_ina = len(interface_segs['AM_inactive'])

    np.save(out_dir / 'microstructure.npy', labels)
    write_dxf(phase_contours, interface_segs, out_dir / 'geometry.dxf')
    write_svg(phase_contours, interface_segs, sd['a_extent'], sd['b_extent'],
              b0, out_dir / 'geometry.svg')
    render_microstructure_png(sd, out_dir / 'geometry.png')
    # Clean geometry-only export (no axes/ticks/labels/legend/title), high-res
    try:
        render_geometry_png(sd, out_dir / 'geometry_clean_hires.png')
    except Exception:
        import traceback; traceback.print_exc()

    # COMSOL-lean geometry: AM_P grain domains + AM_S + large void only, SE via
    # Boolean.  This is the one to import for meshing (geometry.dxf is the full
    # reference).
    try:
        gi = write_comsol_geometry(sd, out_dir, grain_um=2.0, min_void_um=0.4)
        print(f'  geometry_comsol.dxf → {gi["n_grains"]} AM_P grains + '
              f'{gi["n_AMS"]} AM_S + {gi["n_void"]} void (closed faces)')
    except Exception as _ge:
        import traceback; traceback.print_exc()
        print(f'  [comsol-lean geometry] skipped: {_ge}')

    axis_note = ('※ b축 = z = through-thickness (이온 전달 방향)'
                 if axis in ('x', 'y') else '※ XY 수평 단면')
    se_note = ('continuum (입자 병합)' if not no_continuum else 'discrete particles')
    readme = f"""COMSOL 2D import — {case_name}
=================================================================
COMSOL 모델은 (A) DOMAIN, (B) MATERIAL(수치), (C) BOUNDARY 로 구성.
이 export는 그 3가지에 각각 매핑되도록 분리:

  [A] DOMAIN (형상)      → geometry.dxf  (phase 영역)
  [B] MATERIAL (수치)    → parameters.csv (3D 유효 물성)
  [C] BOUNDARY (계면)    → geometry.dxf 의 AM_SE_interface / AM_inactive layer

─────────────────────────────────────────────────────────────────
[A] DOMAIN — Geometry → Import → geometry.dxf
─────────────────────────────────────────────────────────────────
  Layer AM_P  = 대입자 활물질 domain  (다결정, 원형, closed polyline)
  Layer AM_S  = 소입자 활물질 domain  (단결정, faceted+둥근 모서리)
  Layer SE    = 고체전해질 CONNECTED continuum domain (단일 연결망)
  void        = SE 내부의 고립 pore (closed polyline, SE 안의 구멍)

  ★ 경계는 모두 smoothing 처리됨 (Gaussian iso-contour + RDP + Chaikin)
    → voxel 계단 제거, COMSOL meshing 가능한 매끈한 polyline.
    작은 speck(메시 불가)은 자동 prune.

  ★ 권장 SE 구성 (watertight 계면):
    COMSOL에서 SE domain = (외곽 Rectangle) − (AM_P ∪ AM_S ∪ void pores)
    의 Boolean Difference로 만들면 AM-SE 계면이 정확히 공유됨.
    (geometry.dxf의 SE layer는 시각/검산용; 위 방식이 mesh가 더 깨끗)

  축: {sd['a_label']} (가로) × {sd['b_label']} (세로)
  {axis_note}

─────────────────────────────────────────────────────────────────
[B] MATERIAL — Global Definitions → Parameters (parameters.csv)
─────────────────────────────────────────────────────────────────
  각 domain에 부여할 3D-측정 EFFECTIVE 물성.  2D 형상 위에 3D 유효
  물성을 올려서 2D-FEM이 3D 결과를 재현하게 함.

  SE domain (두 면적 모드 — 고르지 않고 둘 다 싣는다 · τ 판정 v2 결정 3 · TAU-03):
    sigma_grain      = σ₀ — 그 런의 짝 σ₀ (25 °C = 펠릿값 3.0 · CL-91 · 온도 런이면 배수) · 아래 f · tau2 의 기준
    sigma_i_hertz    = 원 솔버 σ_ionic, Hertz 면적 (mS/cm)
    sigma_i_physics  = 원 솔버 σ_ionic, physics 면적 (접촉별 상한 · LHS-25) (mS/cm)
    f_ion_hertz      = sigma_i_hertz/σ_grain = φ/tau2_ion_hertz   ← Porous Electrode 보정 'User defined' 의 fl 칸에 넣는 꼴
    f_ion_physics    = sigma_i_physics/σ_grain = φ/tau2_ion_physics
               (COMSOL 앱 예제 Homogenizing a Heterogeneous Electrode Model 6.4 와 같은 방식 — τ 관례 무관 ·
                같은 틀: 두께 L_cat · εl = phiSE · σ₀ = sigma_grain)
    tau2_ion_hertz   = 수송 tortuosity T (tortuosity factor · 제곱근 아님) = φ·sigma_grain/sigma_i_hertz   ← 검산: σ_i = φ·σ_grain/tau2
    tau2_ion_physics = φ·sigma_grain/sigma_i_physics
               (COMSOL 종 수송 τ_F 꼴 · 배터리 Porous Electrode 노드는 GUI Equation 보기로 확인 뒤 · σ₀ 칸 = sigma_grain)
    tau_ion_<mode>   = √tau2 = √T (참고 · 입력 칸 값 아님 · "수송 tortuosity" 이름은 tau2 에만)
    sigma_i_stageE   = Stage-E physics σ — 재료 인자 포함 (Cronau(r_SE) · 파괴).
               ⚠ f · tau2 와 짝이 아니다 — f_ion_<mode> · tau2_ion_<mode> 와 함께 넣지 말 것
                 (재료 인자를 두 번 넣거나 면적 모드를 섞는다).  옛 판의 sigma_i 행이 이 값이었다.
  AM domain:
    sigma_e  = σ_electronic (mS/cm),  kappa = thermal
  cell-level (post-processing 검증):
    ASR_i = L_cat / σ_ionic,  perc = percolation %

─────────────────────────────────────────────────────────────────
[C] BOUNDARY — coverage를 geometry로
─────────────────────────────────────────────────────────────────
  AM 입자 둘레가 두 layer로 분리됨:
    Layer AM_SE_interface  (green)  = SE에 닿은 활성 계면
        → Li+ flux / charge-transfer BC 부여 (electrode reaction)
    Layer AM_inactive      (red)    = void/AM에 닿은 비활성 둘레
        → insulated (no-flux) BC

  2D coverage = {sd['coverage_2d_pct']}%  (active 계면 길이 분율)
  AM_P {sd.get('coverage_AM_P_pct')}% / AM_S {sd.get('coverage_AM_S_pct')}% (각 상별, 3D 일치)
  → COMSOL에서 AM_SE_interface edge만 선택해 반응 경계조건 적용.

─────────────────────────────────────────────────────────────────
설정: SE = {se_note},  {sd['n_pixels']}px / {pa:.3f} μm·px⁻¹
주의 (2D vs 3D): geometry는 2D, 물성은 3D-effective.
"""
    (out_dir / 'README.txt').write_text(readme)
    return {'n_seg': n_seg, 'n_cov': n_cov, 'n_ina': n_ina, 'out_dir': str(out_dir),
            'files': ['geometry.dxf', 'geometry.svg', 'geometry.png',
                      'geometry_clean_hires.png',
                      'microstructure.npy', 'parameters.csv', 'parameters.json',
                      'README.txt']}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('case')
    ap.add_argument('--axis', choices=['z', 'y', 'x'], default='y')
    ap.add_argument('--slice-frac', type=float, default=0.5)
    ap.add_argument('--n-pixels', type=int, default=600)
    ap.add_argument('--no-continuum', action='store_true')
    ap.add_argument('--grain-size', type=float, default=0.8,
                    help='AM_P poly grain μm (Trevisanello 2021); 0=off')
    ap.add_argument('--no-facets', action='store_true',
                    help='draw AM_S as plain circles (default: faceted single-crystal)')
    ap.add_argument('--procedural', action='store_true',
                    help='synthesize a representative microstructure from 3D '
                         'stats (AM D50-matched, area/porosity/coverage pinned) '
                         'instead of a literal slice')
    ap.add_argument('--seed', type=int, default=0, help='procedural RNG seed')
    ap.add_argument('--out', default='docs/data/comsol_export')
    args = ap.parse_args()

    uploads = ROOT / 'webapp' / 'uploads'
    case_dir = None
    for d in uploads.iterdir():
        if not d.is_dir(): continue
        mf = d / 'meta.json'
        if mf.exists():
            try:
                if json.loads(mf.read_text()).get('name') == args.case:
                    case_dir = d; break
            except Exception:
                pass
    if case_dir is None:
        print(f'Case "{args.case}" not found', file=sys.stderr); sys.exit(1)

    if args.procedural:
        print(f'Synthesizing representative microstructure for {args.case} '
              f'(D50-matched, area/porosity/coverage pinned)...')
        sd = synthesize_microstructure(case_dir, n_pixels=args.n_pixels,
                                       grain_size_um=args.grain_size,
                                       single_crystal_facets=not args.no_facets,
                                       seed=args.seed)
    else:
        print(f'Slicing {args.case} (axis={args.axis}, continuum={not args.no_continuum})...')
        sd = slice_microstructure(case_dir, slice_frac=args.slice_frac,
                                  n_pixels=args.n_pixels, axis=args.axis,
                                  se_continuum=not args.no_continuum,
                                  grain_size_um=args.grain_size,
                                  single_crystal_facets=not args.no_facets)
    if sd is None:
        print('generation failed (missing data)', file=sys.stderr); sys.exit(1)

    out_dir = ROOT / args.out / args.case
    info = write_comsol_package(args.case, case_dir, sd, out_dir,
                                axis=args.axis, slice_frac=args.slice_frac,
                                no_continuum=args.no_continuum)
    print(f'  수치 파라미터 → parameters.csv')
    print(f"  geometry → dxf+svg+png ({info['n_seg']} polylines, "
          f"{info['n_cov']} covered + {info['n_ina']} inactive arcs)")
    print(f"\nDone → {info['out_dir']}")


if __name__ == '__main__':
    main()

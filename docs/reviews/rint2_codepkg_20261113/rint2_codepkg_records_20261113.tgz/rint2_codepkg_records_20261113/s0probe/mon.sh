# S0 stage 1 monitor (draft 2026-11-12): starts S0 stage 1 (PROBE 1 = under the store probe wrapper), samples the RSS of the
# Python process every 5 s, records its rc (same rss.log form as the 2026-11-06 run2.sh: '<s> <kB>' lines, then one 'rc=<n>' line),
# writes out_sha256.txt, packs the log folder and the output folder into ~/<log folder name>.tgz (the store folder is not packed),
# then touches DONE.
# usage: bash mon.sh <L log dir> <W pinned worktree> <O new output dir> <S store dir> <KIT> <PROBE 0|1> [extra S0 args]
L=$1; W=$2; O=$3; S=$4; KIT=$5; PROBE=$6; shift 6
cd "$L" || exit 2
PY="$HOME/dem-venv/bin/python3"
if [ "$PROBE" = 1 ]; then
  "$PY" "$L/s0_store_probe.py" "$L" "$S" "$W/scripts/ca_s0_census.py" --stage 1 --kit "$KIT" --out "$O" "$@" > "$L/run.log" 2>&1 &
else
  "$PY" "$W/scripts/ca_s0_census.py" --stage 1 --kit "$KIT" --out "$O" "$@" > "$L/run.log" 2>&1 &
fi
PID=$(jobs -p | tail -n 1)
T0=$(date +%s)
if [ -n "$PID" ]; then
  echo "$PID" > "$L/s0.pid"
  while kill -0 "$PID" 2>/dev/null; do
    R=$(awk '/^VmRSS/{print $2}' "/proc/$PID/status" 2>/dev/null)
    echo "$(( $(date +%s) - T0 )) ${R:-0}" >> "$L/rss.log"
    sleep 5
  done
  wait "$PID"
  echo "rc=$?" >> "$L/rss.log"
else
  echo "no pid from jobs -p - the S0 process was not tracked" >> "$L/mon_err.txt"
  echo "nopid" > "$L/s0.pid"
  echo "rc=-1" >> "$L/rss.log"
fi
echo "end_utc=$(date -u +%Y%m%dT%H%M%SZ)" >> "$L/meta.txt"
if [ -d "$O" ]; then ( cd "$O" && sha256sum -- * > "$L/out_sha256.txt" 2>> "$L/mon_err.txt" ); fi
B="$HOME/$(basename "$L").tgz"
if [ -d "$O" ]; then
  tar czf "$B" -C "$(dirname "$L")" "$(basename "$L")" -C "$(dirname "$O")" "$(basename "$O")" 2>> "$L/mon_err.txt"
else
  tar czf "$B" -C "$(dirname "$L")" "$(basename "$L")" 2>> "$L/mon_err.txt"
fi
( cd "$(dirname "$B")" && sha256sum -- "$(basename "$B")" > "$(basename "$B").sha256" ) 2>> "$L/mon_err.txt"
touch "$L/DONE"

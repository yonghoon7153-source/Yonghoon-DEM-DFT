# [DEM 우선 (수영)] 방향 메모 3.2 초안 (대피 세션 · 2026-11-12 · 본 세션에서 넘겨받음)

한국어로 일하고 답한다.  배경: 1저자 주간보고 피드백 (11-09) = 지금 DEM → MPM 은 결합이 아니라 후처리 · 활물질과 전해질을 가압부터 한 모델이 다 계산해야 · 안 되면 다른 모델.  방향 메모 3.1 → Codex 반박 리뷰 판정 (11-10) = **방향 지지 · 단계 3 인과 · 단계 4 분기 · 자격 규칙 수정 필요 = HOLD** (새 P1 DRD-01 · DRD-02 · P2 DRD-03–12 · P3 DRD-13).  처분 문서가 "메모 3.2 = 본 세션" 이라고 정했고, 그 일을 네가 한다 (초안까지 — 반입 · 리뷰는 메인 세션).

## 자리

- 읽을 것 (리포 작업 트리 `/home/user/rint-codepkg` 의 사본으로 읽는다 — **읽기만** · 그 트리에 쓰기 · git 상태 변경 금지 · 다른 조수가 그 트리의 scripts/ 를 고치고 있다):
  1. `docs/reviews/dem_redesign_direction_20261109/memo_v3_1.md` (지금 메모) · `changelog_v3_1.md` · `briefing_ko.md`
  2. `docs/reviews/codex_review_dem_redesign_direction_20261110.md` (판정문 — DRD-01–13 전문)
  3. `docs/reviews/dem_redesign_direction_20261109/verdict_disposition_20261110.md` (처분 = 3.2 에서 무엇을 어떻게 고칠지)
  4. `docs/reviews/findings.json` 의 DRD-01–13 · SELF-160 · SELF-161 항목 · `CLAUDE.md` 의 "[DEM 우선 (수영)]" 줄 (11-09 · 11-10) · `docs/reviews/dem_redesign_direction_20261109/WORKORDER_litdb_dem_mpm_reading_20261110.md`
- 문헌 = 정본 카드만 (`git -C /home/user/litdb-ctl show origin/claude/friendly-meitner-lldvar:litdb/papers/<slug>.md` · 목록 = `git -C /home/user/litdb-ctl ls-tree --name-only origin/claude/friendly-meitner-lldvar litdb/papers/`).  SELF-161 이 말한 미사용 LPSCl 카드 (lee2025 · miss2026 · thompson2026 로 시작하는 slug) 를 반드시 읽고 반영한다.  정독 종합 (`/tmp/claude-0/-home-user-Yonghoon-DEM-DFT/d26d1e75-209f-540f-83a8-c0e1957edc2f/scratchpad/handoff_litread_20261112/litread/synth/out/S1–S6_3`) 은 **찾아가는 지도** 로만 쓴다 — 거기 적힌 값은 카드 줄을 직접 보고 맞을 때만 옮긴다 (종합 문서는 표본 검증만 됐다).
- ⛔ `/home/user/Yonghoon-DEM-DFT` · `/home/user/litdb-canon` · `/home/user/litdb-canon2` 에는 아무것도 쓰지 않고 그 안에서 명령을 시작하지 않는다.
- 출력 = `/tmp/claude-0/-home-user-Yonghoon-DEM-DFT/d26d1e75-209f-540f-83a8-c0e1957edc2f/scratchpad/dem_redesign/` 에만: `memo_v3_2.md` · `changelog_v3_2.md` · `drd_table.md`.

## 할 일

1. 판정문의 DRD-01–13 을 하나씩 읽고, 처분 문서가 정한 대로 메모를 고친 **3.2 전문** 을 쓴다 (3.1 의 꼴 · 절 번호를 지키고 고친 곳만 바꾼다 — 통째로 다시 쓰지 않는다).  1저자 결정 (11-10 Q1–Q5 · CLAUDE.md 의 그 줄: GPU 없이 단계 0–3 · 3D 는 Rint ② R 런 뒤 · SE 형상 변형 필수 · 기준 = 순수 SE 기공률 10–13 % · 진밀도 1.64 고정 · 복합은 예측) 은 그대로 둔다 — 새로 정하지 않는다.
2. `drd_table.md` = 표: DRD 번호 · 등급 · 판정문의 지적 (한 줄) · 3.2 에서 고친 자리 (절 · 줄) · 고친 글 (요지) · 닫힘 / 일부 / 못 닫음 (까닭) — SELF-160 · SELF-161 도 같은 표에.
3. `changelog_v3_2.md` = 3.1 → 3.2 바뀐 곳 목록 (절 · 무엇 · 왜 · 근거 = 판정문 줄 / 카드 slug · 줄).
4. 규칙: 숫자 · 서지는 정본 카드 (slug · 줄) 나 리포 문서 (경로 · 줄) 에서만 — 기억 · 검색으로 채우지 않는다 · 없으면 [미확인].  철회값 (`docs/reviews/claims.json` 의 quotation_ban) 을 인용하지 않는다.  문장은 짧은 한국어 평서문 · 그림 판독 값은 [판독] · 우리 산술은 [카드 산술].  결과 0 건 — 계산 · 시뮬레이션을 돌리지 않는다.  보장 문장 (불변식 · 단조 · 극한 · "같다") 을 쓸 때는 손으로 풀리는 작은 반례를 스스로 한 번 대 보고, 깨지면 문장을 줄인다 (CLAUDE.md 사전 공격 리뷰 ③).

## 답장 (12 줄 안)

3.2 의 줄 수 · DRD 별 닫힘 / 일부 / 못 닫음 수 · 가장 크게 바뀐 곳 셋 · 새로 쓴 문헌 카드 (slug) · 못 닫은 것과 까닭 · 1저자가 정해야 하는 것 (있으면 · 권고 한 줄씩) · 미확인.  확인하지 않은 것을 확인했다고 적지 않는다.  스스로 리뷰어 조수를 띄우지 않는다 (내부 반박 리뷰는 메인 세션이 따로 맡긴다).

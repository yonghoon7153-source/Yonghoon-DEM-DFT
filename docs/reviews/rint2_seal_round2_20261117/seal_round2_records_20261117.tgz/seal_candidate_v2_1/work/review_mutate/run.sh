#!/bin/bash
# usage: run.sh <outdir> [overrides as key=path ...]
D=$(cd "$(dirname "$0")" && pwd); C=/tmp/claude-0/-home-user-Yonghoon-DEM-DFT/81c0ad95-542f-503b-9cf7-2f6a678a4b5b/scratchpad/rint/v21_clone
out=$1; shift
reg=$D/in/pin_reg.md; cmd=$D/in/pin_cmd.md; ri=$D/in/reg_ins.md; ci=$D/in/cmd_ins.md; plan=$D/in/plan.json; s0=$D/in/s0.json; date=20261120; extra=()
for kv in "$@"; do k=${kv%%=*}; v=${kv#*=}; case $k in reg) reg=$v;; cmd) cmd=$v;; ri) ri=$v;; ci) ci=$v;; plan) plan=$v;; s0) s0=$v;; date) date=$v;; branch) extra+=(--seal-branch "$v");; esac; done
cd /tmp && python3 -I $D/tool.py --pin-reg "$reg" --pin-cmd "$cmd" --reg-insert "$ri" --cmd-insert "$ci" --plan "$plan" --s0-plan "$s0" --chain $C/scripts/rint_r_chain.py --seal-date "$date" "${extra[@]}" --out "$out"

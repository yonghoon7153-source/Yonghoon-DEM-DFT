import json, sys
qy = json.load(open(sys.argv[1]))
qb = json.load(open(sys.argv[2]))
libs = qy["q7"]["libs"]
print("q7 libs", len(libs), "keys", sorted(libs[0].keys()))
idx = {}
for k, p in qb["q7b"]["pkgs"].items():
    for r in p["files"]:
        idx.setdefault(r[6], []).append((p["name"], r[0], r[4]))
hit = 0; same_size = 0; rows = []
for L in libs:
    s = L.get("sha256_or_reason"); b = L.get("bytes")
    m = idx.get(s)
    if m:
        hit += 1
        ok = any(str(x[2]) == str(b) for x in m)
        same_size += 1 if ok else 0
        rows.append((L.get("soname"), [x[0] for x in m], ok))
print("q7 sha256 found in q7b lists:", hit, "/", len(libs), "size same:", same_size)
for r in rows: print("  ", r)
# also: any q7 lib whose real file name suggests these pkgs but sha not found

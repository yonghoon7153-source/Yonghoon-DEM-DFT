# 제출 계약 (SUBMIT_CONTRACT)

## 상 의존성
```
static  (같은 단계 안에서는 병렬 가능)
   └─ dense   (같은 잡의 static/CHGCAR 필요 → **그 잡 안에서는 직렬**)
```
⛔ **잡 사이에 의존성이 있습니다** (이 묶음은 staged 구성입니다).
- canary(`*__nzmag`)는 `PARENT_GEOM` 이 가리키는 **부모 기체 기준의 최종 기하**를
  받습니다 — 부모가 먼저 완주해야 합니다.
- 2단계는 1단계 게이트 **8축**을 전부 통과해야 열립니다 (진공 수렴 · 분자 스핀 ·
  canary 기하 · POTCAR 신원 · 기체 상자 수렴 δ_gas · pm1 자기 topology ·
  잔여 차단 0 · 봉인이 계획 전체를 포괄).
순서는 `run_staged.sh` 가 강제합니다.

## 규모
| | |
|---|---:|
| 잡 | 16 |
| static 실행 | 16 |
| dense 실행 | 2 |
| 총 VASP 실행 | **18** |
| 상별 | dense 2 · static 16 |

⚠ **잡 수의 정본은 `find . -name run_job.sh | wc -l`** 입니다 (디스크에서 센 값).
`MANIFEST.planned` 도 같은 수를 냅니다 — 아래 census 가 두 수를 나란히 보여 줍니다.
⛔ 종전 문구는 *"planned 에는 D3-off 쌍둥이가 없으므로 적게 나온다"* 라고 적었는데
**거짓이었습니다** (회신 AY P1): 이 묶음은 D3-off 쌍둥이를 **0개** 만들고
(C3 는 D3-on OUTCAR 의 Edisp 로 냅니다 — 회신 AV P0-3), 실물·planned 둘 다 같습니다.

### census

- references 6 (끝점 6 + 쌍둥이 0)
- calibration complexes 8 (pose×seed 8 + 쌍둥이 0)
- audit pose 0
- pose 당: pm1/D3-on · net4/D3-on — **D3-off 쌍둥이를 만들지 않는다** (C3 는 D3-on OUTCAR 의 Edisp 로 낸다)


## 실행 (이 경로 하나뿐입니다)
```bash
cd <이 묶음을 푼 디렉터리>              # 묶음 **루트**
export PP=/path/to/potpaw_PBE.54
export POTCAR_ALLOWLIST=/abs/site_allow.txt
export BUNDLE_ZIP_SHA256=$(sha256sum /경로/받은번들.zip | cut -d" " -f1)   # 필수
export EXPECT_MANIFEST_SHA256=<메일 본문의 MANIFEST SHA256>                # **필수**
export EXPECT_ZIP_SHA256=<메일 본문의 ZIP SHA256>                          # **필수**
# ⛔ 자유형 launcher 문자열(VASP_CMD·VASP_LAUNCHER)은 폐지됐습니다 (회신 AV P0-2)
export VASP_LAUNCHER_KIND=mpirun            # mpirun|mpiexec|srun|none|wrapper
export LAUNCHER_BIN=/abs/path/to/mpirun     # **필수** (PATH 에서 찾지 않습니다) — 없으면 exit 2
export VASP_NPROC=48                        # 랭크 수
export VASP_EXE=/abs/path/to/vasp_std       # 봉인 대상 실행파일
bash run_staged.sh 1     # census → 조립+봉인 → 봉인 census → 1단계 → 판정
bash run_staged.sh 2     # 1단계 통과 뒤에만
```
⛔ **전체를 배열로 한꺼번에 던지지 마십시오.** 위 의존성 때문에 결과가 무의미해집니다.
`run_all.sh` 는 이 묶음에 **넣지 않았습니다**.
⛔ `BUNDLE_ZIP_SHA256` 이 없으면 봉인 스크립트가 거부합니다 (번들 안에는 자기 해시를
넣을 수 없어 받으신 파일에서 직접 구해 주셔야 합니다).

## 수치 게이트 (이 값들이 결과 판정을 정합니다)

| 게이트 | 문턱 | 뜻 |
|---|---:|---|
| 진공 두께 수렴 Δ_vac | 5 meV | 셀 두 높이의 대비 차 |
| 기체 상자 수렴 δ_gas | 5 meV | box20↔box24 **두 조각의 차** |
| k 격자 수렴 δ_k | 5 meV | static k↔dense k **두 조각의 차** |
| 자기 basin 일치 | 정확 일치 | 비교하는 두 복합체의 Ni 부호 배열 (전역 반전은 동치) |

⚠ 셋 다 **조각별이 아니라 두 조각의 차**에 겁니다. 조각별로 각각 작아도
부호가 반대면 차에서 두 배가 되기 때문입니다.

## 반송 목록

**정본은 `MANIFEST.json` 의 `return_contract`** 이며 이 목록은 그 렌더입니다
(README 와 SUBMIT_CONTRACT 어디를 보셔도 같습니다 — 회신 AV P0-4).

각 잡 폴더에서:
- static/OUTCAR (또는 .gz)
- static/OSZICAR
- static/POSCAR — **실행된 기하** (부모↔canary 기하 대조·기하 감사. 없으면 CANARY_GEOM_UNCHECKED 로 막힙니다)
- POTCAR_PROVENANCE.json (조립기가 자동 생성)
- EXECUTABLE_RECEIPT.tsv — 상별 실행파일 해시 (run_staged 경로가 자동 생성 · 분석기가 root seal 과 대조합니다)

dense 상이 있는 잡 **2개** (`prospective/ptfe_c10__b00__afm2424_pm1` · `prospective/sdcp_neutral__b00__afm2424_pm1`) 에서 추가로:
- dense/OUTCAR (또는 .gz)
- dense/OSZICAR
  (없으면 k 수렴을 못 재서 KCONV_NOT_MEASURED)

묶음 루트에서:
- POTCAR_ROOT_SEAL.json (첫 실행 전 봉인)
- ZIP_SHA256.txt
- STAGE1_PASS.json (1단계 통과 receipt)
- POTCAR_ATTESTATION.json — **선택** (탐색용 정책). 없어도 러너는 돕니다. ⚠ 다만 그 결과는 **원고 인용 자격이 없습니다** — 사후 provenance 는 무엇을 썼는지만 기록하고 그것이 승인된 PAW dataset 인지 판정하지 못합니다 (회신 AZ P0-7·Q4). 만들려면 `MAKE_POTCAR_ATTESTATION.sh` 를 **첫 VASP 실행 전에만** 돌릴 수 있습니다 (회신 AR P0-6)

보내지 않으셔도 되는 것: CHGCAR·WAVECAR (용량) · vasprun.xml (선택)
⚠ 발산·미수렴 잡도 지우지 말고 그대로 — 실패가 판정의 일부다

⚠ **공통 POTCAR 를 전 잡에 복사하면 안 됩니다.** 조각마다 POSCAR 종 순서가 달라
(`Li Ni O` · `Li Ni O C F` · `Li Ni O C F H` · `Li Ni O S C H`) 하나를 돌려 쓰면
그 잡은 조용히 **다른 계**를 계산합니다. `POTCAR_ASSEMBLE.sh` 가 잡마다 조립하고
TITEL 수까지 검증합니다.
⚠ walltime — 가장 긴 잡이 중앙 추정 300 h 이고 모형 불확실성이 ±2배입니다.
   ±2배 외피가 600 h 이므로 **672 h** 를 권합니다 (그보다 짧으면 잘립니다).

## 비용 추정의 출처
- 모델: `tools/sdcp/vasp_cost_estimate.py` — 2026-08-08 납품 `slab/OUTCAR.gz`
  (192원자 · NKPTS 4 · 48코어 · 30,438 s / 58 전자스텝 = **525 s/스텝**)
- **±2배 불확실성**을 인정하는 모델입니다. 계약값이 아니라 계획용 수치입니다.
- `python3 tools/sdcp/vasp_cost_estimate.py --manifest MANIFEST.json --concurrent 8`
  로 이 번들의 실제 계획에서 다시 계산하세요.
- ⚠ **aggregate 시간 ÷ 동시 실행 수**는 산술 하한입니다. 한 잡의
  static→dense 임계경로가 그 하한보다 길면 하한에 도달할 수 없습니다.

## 코어 수
이 번들은 **48 코어/잡 · 동시 8잡**으로 계획했습니다
(MANIFEST.json 의 `submission`). 실제와 다르면 추정이 그만큼 어긋납니다 —
알려 주시면 `--manifest` 로 다시 계산합니다.

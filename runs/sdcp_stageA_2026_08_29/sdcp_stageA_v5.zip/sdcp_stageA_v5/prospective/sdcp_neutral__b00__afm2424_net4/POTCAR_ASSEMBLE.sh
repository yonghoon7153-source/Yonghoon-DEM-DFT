#!/usr/bin/env bash
# 이 잡의 POTCAR 를 만든다. PBE PAW 5.4 세트 경로를 PP 로 준다.
#   PP=/path/to/potpaw_PBE.54 bash POTCAR_ASSEMBLE.sh
# ⚠ 종 순서는 이 잡 POSCAR 전용이다 — 다른 잡에 복사하지 말 것.
#   (하나를 돌려 쓰면 에러 없이 **다른 계**를 계산합니다.)
set -e
ORDER="Li_sv Ni_pv O S C H"
SPECIES="Li Ni O S C H"
: "${PP:?PP 를 지정하세요 (PBE PAW 5.4 세트 루트)}"
rm -f POTCAR POTCAR_PROVENANCE.json
srcsha=""
for v in $ORDER; do
  f="$PP/$v/POTCAR"
  [ -f "$f" ] || { echo "⛔ 없음: $f"; exit 1; }
  srcsha="$srcsha $v:$(sha256sum "$f" | cut -d" " -f1)"
  cat "$f" >> POTCAR
done
# ① 개수
n=$(grep -ac TITEL POTCAR)
[ "$n" = 6 ] || { echo "⛔ TITEL 6개여야 하는데 $n개"; exit 1; }
# ② 자리별 variant — 토큰 전체 비교 (Ni 가 Ni_pv 에 오탐되지 않게)
i=0
for v in $ORDER; do
  i=$((i+1))
  got=$(grep -a TITEL POTCAR | sed -n "${i}p" | awk '{print $4}')
  fun=$(grep -a TITEL POTCAR | sed -n "${i}p" | awk '{print $3}')
  [ "$got" = "$v" ] || { echo "⛔ ${i}번째 TITEL 이 $got — $v 여야 합니다"; exit 1; }
  [ "$fun" = "PAW_PBE" ] || { echo "⛔ ${i}번째가 $fun — PAW_PBE 여야 합니다"; exit 1; }
done
# ③ provenance — 이 파일을 결과와 **함께 반송**해 주세요
python3 - "$srcsha" <<'PY' > POTCAR_PROVENANCE.json
import hashlib, json, subprocess, sys
src = dict(t.split(":", 1) for t in sys.argv[1].split())
titel = [l.strip() for l in open("POTCAR", errors="ignore") if "TITEL" in l]
print(json.dumps({"schema": "potcar_provenance/v1",
                  "species_order": "Li Ni O S C H".split(),
                  "expected_variants": "Li_sv Ni_pv O S C H".split(),
                  "titel_lines": titel, "source_sha256": src,
                  "assembled_sha256": hashlib.sha256(
                      open("POTCAR","rb").read()).hexdigest()},
                 indent=1, ensure_ascii=False))
PY
grep -a TITEL POTCAR
echo "✔ 조립 완료 — 종 순서 Li Ni O S C H · variant·순서·PAW_PBE 확인"
echo "  → POTCAR_PROVENANCE.json (결과와 함께 반송해 주세요)"
